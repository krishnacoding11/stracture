define([], function() { return ` window.compareSystemFieldValue && window.compareSystemFieldValue("", "==", "null", "undefined") ;
`});