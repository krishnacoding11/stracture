/**
 * Config module.
 * This module will initialize the configuration for requireJs.
 * @module Config
 */
require.config({
	waitSeconds: 60,
	baseUrl:'/scripts/htmlform',
	urlArgs: "ver=" + (window.staticContentVersion || Date.now()),
	paths: {
		'angular': './lib/angular/ng',
		'underscore': './lib/underscore/underscore.min',
		'text': './lib/requirejs/plugins/text',
		'json': './lib/requirejs/plugins/json',
		'angular-translate': "./lib/angular-translate/ng-translate.min",
		'textAngular-rangy': "./lib/textAngular/ng-textAngular-rangy.min",
		'textAngular-sanitize': "./lib/textAngular/ng-textAngular-sanitize.min",
		'textAngular': "./lib/textAngular/ng-textAngular.min",
		'angular-spectrum': './lib/spectrum/ng-spectrum-colorpicker.min',
		'spectrum': './lib/spectrum/spectrum',
		'stripe': '//js.stripe.com/v3?'
	},
	shim: {
		'angular': {
			exports: 'angular'
		},
		'angular-translate':{
			deps: ['angular'],
		}
	}
});