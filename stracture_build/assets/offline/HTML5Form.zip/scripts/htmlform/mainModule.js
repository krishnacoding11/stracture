/**
 * Angular module.
 * This module will return main application module for angular.
 * @module Anguler-module
 */
define(['angular'], function(angular) {
	
	'use strict';
	
	if(window.ProviderObject) {
		return angular.module('adoddle');
	}
	
	return angular.module('app', ['pascalprecht.translate', 'textAngular', 'ngSanitize', 'angularSpectrumColorpicker','ui.bootstrap','ui.bootstrap.datetimepicker', 'dynamicNumber', 'appBuilderHelper', 'utilHelper', 'createFormHelper']);
});