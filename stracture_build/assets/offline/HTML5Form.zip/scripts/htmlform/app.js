/**
 * App module.
 * This module will initialize the application.
 * @module App
 */
define([
    'angular',
	'mainModule',
	'angular-translate',
    'textAngular-rangy',
    'textAngular-sanitize',
    'textAngular',
    'angular-spectrum',
    'spectrum',
	'text',
	'json',
    './services/main',
    './components/modal',
    './components/datepicker',
    './components/timepicker',
    './components/datetimepicker',
    './components/charLimit',
], function(angular, mainModule) {
	
    'use strict';
    
     /**
     * @constructor
     * @alias module:App/init
     * @param {string} controllerName - Controller to be loaded.
     * This function will load the custom controller.
     */
    var init = function(customController) {
    	
    	function ctrl(customCtrl) {
        	
        	// new angular create form with html5 form
        	if(window.ProviderObject && !document.body.getAttribute('ng-app') && !window.offlineFormView) {
        		mainModule.controller('FormController', customCtrl);
        		angular.bootstrap(document, ['adoddle']);
        		return;
        	}
        	
        	// new angular view form with html5 form
        	else if(window.ProviderObject) {
        		var queuebefore = angular.copy(mainModule._invokeQueue);
                var registeredProvider = queuebefore.map(function(value) {
                    return value[2][0];
                });
                mainModule.controller('FormController', customCtrl);

                // Here I cannot get the controller function directly so I
                // need to loop through the module's _invokeQueue to get it
                var queue = mainModule._invokeQueue;
                for (var i = 0; i < queue.length; i++) {
                    var call = queue[i];
                    var unregistered = ["modal", "datepicker", "commonApi", "filterOptions", "asiteSignature", "folderSelection", "itemSelection", "numbformat", "inlineattachment", "appHeader", "richTextField", "rtfNicEdit", "radioGroupSwitch", "multipleinlineattachment", "customDropdown","searchFilter", "createFormHelper", "asiteTextbox", "asiteTextarea", "appBuilderHelper", "locationAssociationHelper", "textBoxHelper", "utilHelper",
                     "asiteCheckbox", "asiteRadio", "asiteRichTextarea", "asiteHyperlink", "asiteToggleButton", "asiteButton", "asiteSiteLocationButton", "asiteLabel","asiteDropdown","dropdownHelper","asiteDatetime","asiteTimepicker","datetimeHelper","timepickerHelper", "asiteRating", "asiteMap", "asiteControlLabel", "asiteImage", "asiteDisplayField", "formApiHelper", "asitemultipleinlineattachment", "asiteNewSignature"];
                    if (registeredProvider.indexOf(call[2][0]) == -1 || (!window.dyCompRegistered && unregistered.indexOf(call[2][0]) != -1)) {
                        window.ProviderObject[call[0]][call[1]](call[2][0], call[2][1]);
                    }
                }
                window.dyCompRegistered = true;
        	    
        	    var el = document.getElementById('formWrapper');
        	    var element = angular.element(el);
            	var injector = element.injector();
        		injector.invoke(function($compile) {
        			var scope = element.scope();
        			$compile(el)(scope);
        			
        			window.setTimeout(function() {
        				try {
        					scope.$apply();
        				} catch(e) {}
        			}, 0);
        		});
            	return;
        	}
        	
        	// old ui with html5 form
            var element = angular.element(document);
            var injector = element.injector();
            if (!injector) {
            	mainModule.controller('FormController', customCtrl);
                !window.offlineFormView && angular.bootstrap(document, ['app']);
            } else {
            	injector.invoke(function($compile) {
                    var scope = angular.element(element).scope();
                    $compile(document)(scope);
                });
            }
        }
    	
    	if(typeof customController == 'function'){
    		ctrl(customController);
    	} else {
    		var customControllerPath = './controllers/' + customController;
            require([customControllerPath], function(customCtrl) {
            	ctrl(customCtrl);
            });
    	}
        
    };

    return init;
});