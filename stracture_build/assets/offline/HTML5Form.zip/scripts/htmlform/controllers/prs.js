/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
 
// Global flags

var oldPMuserId = null,
oldSPMuserId = null,
oldPROuserId = null,
oldPEuserId = null,
DS_PPMT_GET_PRS_CWRS = null;

define(['angular', './base'], function(angular, baseController) {
    'use strict';

    function PrintViewController($scope, $element, $window, commonApi, $timeout) {
        var monthName = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
        $scope.isActual = function(parent, month) {
            return parent.expenditureTypeData['Expenditure_Detail_Groups']['Expenditure_Groups'][0]['isActual'].split('|')[monthName.indexOf(month)] == 1;
        };
        $scope.isLoading = false;
        $scope.oriprintviewtabs = [{
            title: 'Details',
            url: 'details.html',
            isVisible: true
        }, {
            title: 'Roles',
            url: 'roles.html',
            isVisible: true
        }, {
            title: 'Milestone',
            url: 'milestone.html',
            isVisible: true
        }, {
            title: 'Expenditure',
            url: 'expenditure.html',
            isVisible: true
        }, {
            title: 'Funding',
            url: 'funding.html',
            isVisible: true
        }, {
            title: 'Targets',
            url: 'targets.html',
            isVisible: true
        }, /* {
            title: 'Issue Log',
            url: 'issuelog.html',
            isVisible: true
        }, */{
            title: 'Project Details',
            url: 'projectdetails.html',
            isVisible: true
        }, {
            title: 'CWRs',
            url: 'cwrs.html',
            isVisible: true
        }, {
            title: 'Reports',
            url: 'reports.html',
            isVisible: true
        }];
        $scope.currentOriPrintViewTab = 'details.html';

        $scope.expendituretabs = [{
            title: 'Pre Business Case/Low Risk Project',
            url: 'prebusinesscase.html'
        }, {
            title: 'Post Business Case',
            url: 'postbusinesscase.html'
        }, {
            title: 'Annual Totals',
            url: 'annualtotals.html'
        }];
        $scope.currentExpenditureTab = 'prebusinesscase.html';

        function toManageUIofTable(boolFocusFlag) {
        	$timeout(function () {
        		var objWrapDiv = document.querySelectorAll('.commonInnerWrapDiv')[0] || document.querySelectorAll('.bodyFreezDivs')[0],
        		objCwrTable = document.querySelectorAll('.commonHeaderTable')[0],
        		objIssueLogTable = document.querySelectorAll('.issueLogTable')[0],
        		objCommonFreezHeaderDiv = document.querySelectorAll('.commonFreezHeaderDiv')[0],
        		strCalc = "";

        		if (objWrapDiv) {
        			if (boolFocusFlag) {
        				objWrapDiv.scrollTop = objWrapDiv.scrollHeight;
        			}

        			if (objCwrTable && !objIssueLogTable) {
        				strCalc = objWrapDiv.scrollHeight - objWrapDiv.offsetHeight;
        				if (strCalc > 2) {
        					//objCwrTable.style.width = '100%';
        					//objCommonFreezHeaderDiv.style.paddingRight = '17px';
        					objCommonFreezHeaderDiv.classList.add("paddingRightFreezeHeader");
        				} else {
        					objCommonFreezHeaderDiv.classList.remove("paddingRightFreezeHeader");
        					//objCwrTable.style.width = '101%';
        					//objCommonFreezHeaderDiv.style.paddingRight = '1%';
        				}
        			}
        		}

        		var expFreezHeaderDiv = document.querySelectorAll(".expFreezHeaderDiv")[0],
        		bodyFreezDivs = document.querySelectorAll(".bodyFreezDivs")[0] || document.querySelectorAll(".bodyFreezDivsPrint")[0];

        		if ((!objWrapDiv || objIssueLogTable) && bodyFreezDivs && bodyFreezDivs) {
        			if (bodyFreezDivs.scrollHeight > bodyFreezDivs.offsetHeight) {
        				$(expFreezHeaderDiv).addClass('expIssueHeaderMargin');
        			} else {
        				$(expFreezHeaderDiv).removeClass('expIssueHeaderMargin');
        			}
        		}

        	}, 0, false);
        }

        $scope.onClickTab = function(tab, calledform) {
            if (tab.url) {
                switch (tab.url) {
                    case 'details.html':
                        $timeout(function() {
                            $scope.expandTextAreaOnLoad();
                        }, 1000);
                        break;
                    case 'roles.html':
                        $scope.filterRolesRecords($scope.rolesFilter);
                        break;
                    case 'milestone.html':
                        $scope.filterMilestoneRecords($scope.milestoneFilter);
                        break;
                    case 'expenditure.html':
                        $scope.filterExpenditureRecords($scope.expenditureFilter);
                        break;
                    case 'funding.html':
                        $scope.filterFundingRecords($scope.fundingFilter);
                        break;
                    case 'targets.html':
                        $scope.filterTargetRecords($scope.targetsFilter);
                        break;
                    case 'issuelog.html':
                        $scope.filterIssueLogRecords($scope.issueLogFilter);
                        break;
                    case 'projectdetails.html':
                        $scope.filterProjectDetailRecords($scope.projectdetailFilter);
                        break;
                }
            }

            if (calledform == "ori_print_view_main") {
                $scope.currentOriPrintViewTab = tab.url;
                if (tab.url === "expenditure.html") {
                    setUpExpenditureData();
                }
            } else if (calledform == "expenditure") {
                $scope.currentExpenditureTab = tab.url;
                if (tab.url === "prebusinesscase.html") {
                    $scope.showSpentDatePreFlag = true;
                } else {
                    $scope.showSpentDatePreFlag = false;
                }
                if (tab.url === "postbusinesscase.html") {
                    $scope.showSpentDatePostFlag = true;
                } else {
                    $scope.showSpentDatePostFlag = false;
                }
            }

            $timeout(function() {
                var STATIC_DOM_CACHE = {
                    expFreezHeaderDiv : document.querySelectorAll(".expFreezHeaderDiv")[0],
                    bodyColumnFreezTable : document.querySelectorAll(".bodyColumnFreezDivs")[0],
                    expOverContainer : document.querySelectorAll('.expOverContainer')[0],
                    bodyFreezDivs : document.querySelectorAll(".bodyFreezDivs")[0] || document.querySelectorAll(".bodyFreezDivsPrint")[0]
                }
                
                if(STATIC_DOM_CACHE.bodyFreezDivs){
                    STATIC_DOM_CACHE.bodyFreezDivs.onscroll = function(e){
                        freezeDivScrollForExpTab(e , STATIC_DOM_CACHE)
                    };
                }

                var bodyColumnFreezDivs = document.querySelectorAll(".innerColumnFreezDivs")[0];
                if (bodyColumnFreezDivs && bodyColumnFreezDivs.addEventListener) {
                    // IE9, Chrome, Safari, Opera
                    bodyColumnFreezDivs.addEventListener("mousewheel", function(e){ MouseWheelHandler(e , STATIC_DOM_CACHE) }, false);
                    // Firefox
                    bodyColumnFreezDivs.addEventListener("DOMMouseScroll", function(e){ MouseWheelHandler(e , STATIC_DOM_CACHE) }, false);

                    bodyColumnFreezDivs.onscroll = function(e){
                        MouseWheelHandler(e , STATIC_DOM_CACHE)
                    }
                }
                // IE 6/7/8
                else bodyColumnFreezDivs && bodyColumnFreezDivs.attachEvent("onmousewheel", MouseWheelHandler);
                
            }, 0, false);
            toManageUIofTable();
        }

        function MouseWheelHandler(e , DOM){
            var event = window.event || e,
                bodyFreezDivs = DOM.bodyFreezDivs;

            event.returnValue = false;//This is for prevent window scroll in Chrome , Moz
            if(event.wheelDelta){
                bodyFreezDivs.scrollTop -= event.wheelDelta
            }else{
                event.target.scrollTop = 0;
            }

            if(bodyFreezDivs.scrollTop == 0 || ( bodyFreezDivs.scrollTop + bodyFreezDivs.offsetHeight ) >= bodyFreezDivs.scrollHeight){
               event.returnValue = true;
            }

            if (event.preventDefault && !event.returnValue) {
                event.preventDefault();//This is for prevent window scroll in IE11
            }
        }

        function freezeDivScrollForExpTab(event, DOM_CACHE ){
            var headerFreezDivs = DOM_CACHE.expFreezHeaderDiv,
                bodyColumnFreezDivs = DOM_CACHE.bodyColumnFreezTable;
            
            if( headerFreezDivs ){
                headerFreezDivs.scrollLeft = event.target.scrollLeft;
            }

            if( bodyColumnFreezDivs ){
                bodyColumnFreezDivs.scrollTop = event.target.scrollTop; 
            }
        }

        $scope.isActiveTab = function(tabUrl, calledform) {
            if (calledform == "ori_print_view_main") {
                return tabUrl == $scope.currentOriPrintViewTab;
            } else if (calledform == "expenditure") {
                return tabUrl == $scope.currentExpenditureTab;
            }
        }

        $scope.fomatedValue = function() {
            var tmpNo = 0;
            _.each(arguments, function(ele) {
                if (ele)
                    tmpNo += parseFloat(ele)
            })
            return tmpNo;
        }

        $scope.substringAfter = function(str, from) {
            return str.substring(str.indexOf(from) + 1);
        }

        $scope.monthsDataArr = [];
        var currMonth = 4;
        var monthName = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
        for (var i = 0; i < 12; i++) {
            $scope.monthsDataArr.push({
                mNo: currMonth,
                mName: monthName[i],
                year: currMonth > 12 ? $scope.currentYearValue + 1 : $scope.currentYearValue
            });
            currMonth++;
        }

        $scope.ishideBlock = false;

        $scope.cwrToggleExpShowHide = function() {
            $scope.ishideBlock = !$scope.ishideBlock;
        }

        $scope.downloadReport = function(form_template_name, Report_format) {
            $window.showSelectedReportfromApp(form_template_name, Report_format);
        }

        $scope.setPrintViewDefaultData = function() {
            $scope.capworksReports = $scope.getValueOfOnLoadData("DS_PPMT_ALL_CAPWORKS_REPORTS");

            //Project Details Tab
            $scope.Project_Defrawag = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_DEFRAWAG");
            $scope.dsPpmtGetMilestibeData = $scope.getValueOfOnLoadData("DS_PPMT_GET_MILESTONEDATA");
            $scope.dsPpmtGetMilestoneExpenditureData = $scope.getValueOfOnLoadData("DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA");
            $scope.dsPpmtGetMilestoneFundingData = $scope.getValueOfOnLoadData("DS_PPMT_GET_MILESTONE_FUNDING_DATA");
            $scope.defrawagProjectDetails = $scope.getValueOfOnLoadData("DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS");
            $scope.govtInitiatives = $scope.getValueOfOnLoadData("DS_PPMT_GET_GOVT_INITIATIVES");
            $scope.progNameData = $scope.getValueOfOnLoadData("DS_PPMT_PROGRAMME_NAME");
            $scope.projectdetailFilter = "Submitted";

            //Issue Log Tab
            $scope.IssueLogTabData = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_ISSUE_LOG");
            $scope.issueLogFilter = "Submitted";

            //Targets Tab
            $scope.targetsSubTabData = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_TARGETS");
            $scope.targetsFilter = "Submitted";

            //Funding Tab
            $scope.fundingSubTabData = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_FUNDING");
            $scope.fundingDataCash = commonApi._.filter($scope.fundingSubTabData, function(val) {
                return val.Value39.indexOf('Kind') == -1
            });
            $scope.fundingDataInKind = commonApi._.filter($scope.fundingSubTabData, function(val) {
                return val.Value39.indexOf('Kind') != -1
            });
            $scope.fundingFilter = "Submitted";

            //Roles Tab
            $scope.rolesSubTabData = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_ROLES");
            $scope.rolesFilter = "Submitted";

            //Milestone Tab
            $scope.milestoneRow = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_MILESTONES");
            $scope.milestoneFilter = "Submitted";

            //Expenditure Tab
            $scope.expenditureFilter = "Submitted";
        }

        function setUpExpenditureData() {
            var ORI_MSG_Custom_Fields = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields'];
            $scope.allApprovalGroup = ORI_MSG_Custom_Fields['All_Approval_Group'];
            $scope.ExpenditureHeader = ORI_MSG_Custom_Fields["Expenditure_Header"];

            Map_Approval_Details();
            Map_Expenditure_Details();
            var parGroups = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups']
            var xpnChkPPNode = parGroups && $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'][1];
            if (!xpnChkPPNode) {
                $scope.setBlankPostParNode();
            }
            resetExpanditureData()
        }

        function resetExpanditureData() {
            var ORI_MSG_Custom_Fields = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields'];

            $scope.expPreRiskValue = [];
            $scope.expenditureRowPre = [];
            $scope.expPostRiskValue = [];
            $scope.expenditureRowPost = [];
            $scope.preRiskValue = {};
            $scope.postRiskValue = {};
            $scope.preTotalWithoutSalary = {};
            $scope.postTotalWithoutSalary = {};
            $scope.allTypesOfPreTotal = {};
            $scope.allTypesOfPostTotal = {};

            var preParData = commonApi._.filter(ORI_MSG_Custom_Fields['All_PAR_Group']['PAR_Groups'], function(val) {
                return val.PAR_TYPE == "PRE-PAR";
            });
            if (preParData.length) {
                $scope.expPreRiskValue = preParData[0];
                $scope.expenditureRowPre = preParData[0]["All_Expenditure_Group"]["All_Exp_Types_Group"]["Expenditure_Types"];
                var preRiskValue = commonApi._.filter($scope.expenditureRowPre, function(val) {
                    return val.Expenditure_Type.indexOf('Risk') != -1;
                });
                if (preRiskValue.length)
                    $scope.preRiskValue = preRiskValue[0];
            }
            calculateWithoutSalariesTotal($scope.expenditureRowPre, 'preTotalWithoutSalary');

            var postParData = commonApi._.filter(ORI_MSG_Custom_Fields['All_PAR_Group']['PAR_Groups'], function(val) {
                return val.PAR_TYPE == "POST-PAR";
            });
            if (postParData.length) {
                $scope.expPostRiskValue = postParData[0];
                $scope.expenditureRowPost = postParData[0]["All_Expenditure_Group"]["All_Exp_Types_Group"]["Expenditure_Types"];
                var postRiskValue = commonApi._.filter($scope.expenditureRowPost, function(val) {
                    return val.Expenditure_Type.indexOf('Risk') != -1;
                });
                if (postRiskValue.length)
                    $scope.postRiskValue = postRiskValue[0];
            }
            calculateWithoutSalariesTotal($scope.expenditureRowPost, 'postTotalWithoutSalary');
        }

        var columnArray = ['Prev_Year', 'Prev_Year_Adj', 'Act_Apr', 'Act_May', 'Act_Jun', 'Act_Jul', 'Act_Aug', 'Act_Sep', 'Act_Oct', 'Act_Nov', 'Act_Dec', 'Act_Jan', 'Act_Feb', 'Act_Mar', 'FCST_Apr', 'FCST_May', 'FCST_Jun', 'FCST_Jul', 'FCST_Aug', 'FCST_Sep', 'FCST_Oct', 'FCST_Nov', 'FCST_Dec', 'FCST_Jan', 'FCST_Feb', 'FCST_Mar', 'FCST_Y1_Q1', 'FCST_Y1_Q2', 'FCST_Y1_Q3', 'FCST_Y1_Q4', 'FCST_Y2', 'FCST_Y3', 'FCST_Y4', 'FCST_Y5', 'FCST_Y6', 'FCST_Y7', 'FCST_Y8', 'FCST_Y9', 'FCST_Y10', 'FCST_Y11_Y15', 'FCST_Y16_Y20', 'OB_Approval_Value', 'G1_Approval_Value', 'G2_Approval_Value', 'G3_Approval_Value', 'G4_Approval_Value', 'G5_Approval_Value', 'Line_Total'];
        var expApproval = ['OB_Approval_Value', 'G1_Approval_Value', 'G2_Approval_Value', 'G3_Approval_Value', 'G4_Approval_Value', 'G5_Approval_Value'];
        $scope.initFlag = {
            prePar: true,
            postPar: true
        };
        $scope.Exp_GroupsPreTypesOfTotal = {};
        $scope.Exp_GroupsPostTypesOfTotal = {};
        $scope.allTypesOfPreTotal = [];
        $scope.allTypesOfPostTotal = [];

        function calculateWithoutSalariesTotal(data, name) {
            if (!data.length)
                return;
            for (var i = 0; i < columnArray.length; i++) {
                var allGrops = [];
                for (var j = 0; j < data.length; j++) {
                    var allExpGroup = data[j]['Expenditure_Detail_Groups']['Expenditure_Groups'];
                    allExpGroup = commonApi._.filter(allExpGroup, function(val) {
                        return val.Ref_Exp_Type.indexOf('Salaries') == -1;
                    });
                    for (var k = 0; k < allExpGroup.length; k++) {
                        allGrops.push(allExpGroup[k]);
                    }
                }
                var allSeleObj = _.pluck(allGrops, columnArray[i]);
                var sum = _.reduce(allSeleObj, function(a, b) {
                    return parseFloat(a) + parseFloat(b);
                }, 0);
                $scope[name][columnArray[i]] = parseFloat(sum).toFixed(2);
            }
        }

        $scope.$watch('expenditureRowPre', function(newValue, oldValue) {
            if (newValue && newValue.length) {
                commonApi._.each(columnArray, function(obj) {
                    var OldAray = findInJSON(oldValue, obj);
                    var NewAray = findInJSON(newValue, obj);
                    var isMatch = _.isEqual(OldAray, NewAray);
                    if (!isMatch || $scope.isPrintView || $scope.initFlag.prePar) {
                        Expenditure_Groups_Total(newValue, obj, 'Exp_GroupsPreTypesOfTotal');
                        doCalculationOfExpData(newValue, obj, 'allTypesOfPreTotal');
                    }
                });

                $scope.allTypesOfPreTotal['curntYrTotal'] = 0;
                spentToDateAndMostLikelyExpCalc();
                $scope.initFlag.prePar = false;
            }
        }, true);

        $scope.$watch('expenditureRowPost', function(newValue, oldValue) {
            if (newValue && newValue.length) {
                commonApi._.each(columnArray, function(obj) {
                    var OldAray = findInJSON(oldValue, obj);
                    var NewAray = findInJSON(newValue, obj);
                    var isMatch = _.isEqual(OldAray, NewAray);
                    if (!isMatch || $scope.isPrintView || $scope.initFlag.postPar) {
                        Expenditure_Groups_Total(newValue, obj, 'Exp_GroupsPostTypesOfTotal');
                        doCalculationOfExpData(newValue, obj, 'allTypesOfPostTotal');
                    }
                });
                $scope.allTypesOfPostTotal['curntYrTotal'] = 0;
                spentToDateAndMostLikelyExpCalc();
                $scope.initFlag.postPar = false;
            }
        }, true);

        function Expenditure_Groups_Total(mainData, argKey, viewScope) {
            commonApi._.each(mainData, function(ele, index) {
                var allGroup = ele['Expenditure_Detail_Groups']['Expenditure_Groups'];
                var allSeleObj = _.pluck(allGroup, argKey);
                var sum = _.reduce(allSeleObj, function(a, b) {
                    return parseFloat(a) + parseFloat(b);
                }, 0);
                if (!$scope[viewScope][index]) {
                    $scope[viewScope][index] = [];
                }
                $scope[viewScope][index][argKey] = parseFloat(sum).toFixed(2);
            })
        }

        function doCalculationOfExpData(mainData, keyArray, viewScope) {
            var isRiskArry = [];
            _.each(mainData, function(ele, ind) { //without Risk Forcast total
                if (ele.Expenditure_Type.toLowerCase().indexOf('risk forecast') > -1) {
                    isRiskArry[ind] = ele.Expenditure_Type
                }
            })
            if ($scope[viewScope]['withOutRisk'] == undefined) { //without Risk Forcast total
                $scope[viewScope]['withOutRisk'] = {}
            }
            var ObjData = [keyArray] || [],
                _arrayTotal = 0,
                _arrayTotal_WRF = 0,
                allRiskKeys = _.allKeys(isRiskArry);

            if (ObjData.length == 0) {
                ObjData = columnArray;
            }

            _.each(ObjData, function(obj) {

                var NAray = [];
                _arrayTotal = 0;
                _arrayTotal_WRF = 0; //without Risk Forcast total

                if (expApproval.indexOf(obj) > -1) {
                    var tNewAray = _.pluck(mainData, obj);

                    _.each(tNewAray, function(ele) {
                        var sd = [];
                        sd[obj] = [ele];
                        NAray.push(sd);
                    });

                } else {
                    NAray = findInJSON(mainData, obj)
                }
                _.each(NAray, function(ele, index) {

                    var sum = _.reduce(ele[obj], function(a, b) {
                        return parseFloat(a) + parseFloat(b);
                    }, 0);

                    _arrayTotal += parseFloat(sum);

                    if (isRiskArry[index] == undefined || keyArray == "Prev_Year_Adj") { //without Risk Forcast total
                        _arrayTotal_WRF += parseFloat(sum);
                    }

                })

                $scope[viewScope][obj] = parseFloat(_arrayTotal).toFixed(2);
                $scope[viewScope]['withOutRisk'][obj] = parseFloat(_arrayTotal_WRF).toFixed(2); //without Risk Forcast total
            });
        }

        function spentToDateAndMostLikelyExpCalc() {
            var curntYrTotalPre = 0;
            var curntYrTotalPost = 0;
            $scope.spentToDatePreBusiness = 0;
            $scope.spentToDatePostBusiness = 0;
            $scope.obj = {
                allActuals: 0
            };
            var spentTotalPreBusiness = 0;
            var spentTotalPostBusiness = 0;
            var MostLikeExpTotal = 0;
            var allActuals = 0;

            _.each($scope.Exp_GroupsPreTypesOfTotal, function(ele) {
                for (var key in ele) {
                    if (key && !isNaN(ele[key]) && (key.indexOf('Act_') > -1 || key.indexOf('Prev_Year') > -1 || key.indexOf('Prev_Year_Adj') > -1)) {
                        spentTotalPreBusiness += parseFloat(ele[key] || 0);
                    }
                    if (key && !isNaN(ele[key]) && (key.indexOf('Apr') > -1 || key.indexOf('May') > -1 || key.indexOf('Jun') > -1 || key.indexOf('Jul') > -1 || key.indexOf('Aug') > -1 || key.indexOf('Sep') > -1 || key.indexOf('Oct') > -1 || key.indexOf('Nov') > -1 || key.indexOf('Dec') > -1 || key.indexOf('Jan') > -1 || key.indexOf('Feb') > -1 || key.indexOf('Mar') > -1)) {
                        MostLikeExpTotal += parseFloat(ele[key] || 0);
                        curntYrTotalPre += parseFloat(ele[key] || 0);
                    }
                    if (key && !isNaN(ele[key]) && (key.indexOf('Act_') > -1)) {
                        allActuals += parseFloat(ele[key] || 0);
                    }
                }
            });

            _.each($scope.Exp_GroupsPostTypesOfTotal, function(ele) {
                for (var key in ele) {
                    if (key && !isNaN(ele[key]) && (key.indexOf('Act_') > -1 || key.indexOf('Prev_Year') > -1 || key.indexOf('Prev_Year_Adj') > -1)) {
                        spentTotalPostBusiness += parseFloat(ele[key]);
                    }
                    if (key && !isNaN(ele[key]) && (key.indexOf('Apr') > -1 || key.indexOf('May') > -1 || key.indexOf('Jun') > -1 || key.indexOf('Jul') > -1 || key.indexOf('Aug') > -1 || key.indexOf('Sep') > -1 || key.indexOf('Oct') > -1 || key.indexOf('Nov') > -1 || key.indexOf('Dec') > -1 || key.indexOf('Jan') > -1 || key.indexOf('Feb') > -1 || key.indexOf('Mar') > -1)) {
                        MostLikeExpTotal += parseFloat(ele[key] || 0);
                        curntYrTotalPost += parseFloat(ele[key] || 0);
                    }
                    if (key && !isNaN(ele[key]) && (key.indexOf('Act_') > -1)) {
                        allActuals += parseFloat(ele[key] || 0);
                    }
                }
            });
            $scope.obj.allActuals = parseFloat(allActuals).toFixed(2);
            $scope.spentToDatePreBusiness = parseFloat(spentTotalPreBusiness).toFixed(2);
            $scope.spentToDatePostBusiness = parseFloat(spentTotalPostBusiness).toFixed(2);
            $scope.Most_Likely_Value = parseFloat(MostLikeExpTotal).toFixed(2);
            $scope.allTypesOfPostTotal['curntYrTotal'] = parseFloat(curntYrTotalPost).toFixed(2);
            $scope.allTypesOfPreTotal['curntYrTotal'] = parseFloat(curntYrTotalPre).toFixed(2);
        }

        function findInJSON(jsonData, argKey) {
            var retVal = [];
            getDataFromJSON(jsonData, argKey);

            function getDataFromJSON(jsonData, argKey) {
                angular.forEach(jsonData, function(ele) {
                    var pluckData = _.pluck(ele, argKey).filter(function(elems) {
                        return elems;
                    });
                    if (pluckData && pluckData.length > 0) {
                        var asd = {};
                        asd[argKey] = pluckData;
                        retVal.push(asd)
                    }
                    if (typeof ele == 'object') {
                        for (var key in ele) {
                            if (typeof ele[key] == 'object') {
                                getDataFromJSON(ele[key], argKey)
                            }
                        }
                    }
                });
            }
            return retVal;
        }

        function resetViewState() {
            $scope.showOBC = false;
            $scope.showG1 = false;
            $scope.showG2 = false;
            $scope.showG3 = false;
            $scope.showG4 = false;
            $scope.showG5 = false;

            if (!$scope.allApprovalGroup['PRE_G1_Approval_Type'] && !$scope.allApprovalGroup['PRE_G2_Approval_Type'] && !$scope.allApprovalGroup['PRE_G3_Approval_Type'] && !$scope.allApprovalGroup['PRE_G4_Approval_Type'] && !$scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showOBC = true;
            }

            if ($scope.allApprovalGroup['PRE_G1_Approval_Type'] && !$scope.allApprovalGroup['PRE_G2_Approval_Type'] && !$scope.allApprovalGroup['PRE_G3_Approval_Type'] && !$scope.allApprovalGroup['PRE_G4_Approval_Type'] && !$scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showG1 = true;
            }

            if ($scope.allApprovalGroup['PRE_G2_Approval_Type'] && !$scope.allApprovalGroup['PRE_G3_Approval_Type'] && !$scope.allApprovalGroup['PRE_G4_Approval_Type'] && !$scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showG2 = true;
            }

            if ($scope.allApprovalGroup['PRE_G3_Approval_Type'] && !$scope.allApprovalGroup['PRE_G4_Approval_Type'] && !$scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showG3 = true;
            }

            if ($scope.allApprovalGroup['PRE_G4_Approval_Type'] && !$scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showG4 = true;
            }

            if ($scope.allApprovalGroup['PRE_G5_Approval_Type']) {
                $scope.showG5 = true;
            }
        }

        function Map_Approval_Details(data) {
            var approvals = data || $scope.getValueOfOnLoadData("DS_PPMT_GET_EXPENDITURE_APPROVALS");
            if (approvals.length) {
                for (var i = 0; i < approvals.length; i++) {
                    var All_Approval_Group = $scope.allApprovalGroup;
                    if (approvals[i]["Value1"].toString().trim() != "") {
                        All_Approval_Group['PRE_OB_Approval_Type'] = approvals[i]["Value1"] || '';
                        All_Approval_Group['PRE_OB_FSoD_Code'] = approvals[i]["Value2"] || '';
                        All_Approval_Group['PRE_OB_Approval_Body'] = approvals[i]["Value3"] || '';
                        All_Approval_Group['PRE_OB_FSoD_Sig_Date'] = approvals[i]["Value4"] || '';
                        All_Approval_Group['PRE_G1_Approval_Type'] = approvals[i]["Value5"] || '';
                        All_Approval_Group['PRE_G1_FSoD_Code'] = approvals[i]["Value6"] || '';
                        All_Approval_Group['PRE_G1_Approval_Body'] = approvals[i]["Value7"] || '';
                        All_Approval_Group['PRE_G1_FSoD_Sig_Date'] = approvals[i]["Value8"] || '';
                        All_Approval_Group['PRE_G2_Approval_Type'] = approvals[i]["Value9"] || '';
                        All_Approval_Group['PRE_G2_FSoD_Code'] = approvals[i]["Value10"] || '';
                        All_Approval_Group['PRE_G2_Approval_Body'] = approvals[i]["Value11"] || '';
                        All_Approval_Group['PRE_G2_FSoD_Sig_Date'] = approvals[i]["Value12"] || '';
                        All_Approval_Group['PRE_G3_Approval_Type'] = approvals[i]["Value13"] || '';
                        All_Approval_Group['PRE_G3_FSoD_Code'] = approvals[i]["Value14"] || '';
                        All_Approval_Group['PRE_G3_Approval_Body'] = approvals[i]["Value15"] || '';
                        All_Approval_Group['PRE_G3_FSoD_Sig_Date'] = approvals[i]["Value16"] || '';
                        All_Approval_Group['PRE_G4_Approval_Type'] = approvals[i]["Value17"] || '';
                        All_Approval_Group['PRE_G4_FSoD_Code'] = approvals[i]["Value18"] || '';
                        All_Approval_Group['PRE_G4_Approval_Body'] = approvals[i]["Value19"] || '';
                        All_Approval_Group['PRE_G4_FSoD_Sig_Date'] = approvals[i]["Value20"] || '';
                        All_Approval_Group['PRE_G5_Approval_Type'] = approvals[i]["Value21"] || '';
                        All_Approval_Group['PRE_G5_FSoD_Code'] = approvals[i]["Value22"] || '';
                        All_Approval_Group['PRE_G5_Approval_Body'] = approvals[i]["Value23"] || '';
                        All_Approval_Group['PRE_G5_FSoD_Sig_Date'] = approvals[i]["Value24"] || '';

                        All_Approval_Group['POST_OB_Approval_Type'] = approvals[i]["Value25"] || '';
                        All_Approval_Group['POST_OB_FSoD_Code'] = approvals[i]["Value26"] || '';
                        All_Approval_Group['POST_OB_Approval_Body'] = approvals[i]["Value27"] || '';
                        All_Approval_Group['POST_OB_FSoD_Sig_Date'] = approvals[i]["Value28"] || '';
                        All_Approval_Group['POST_G1_Approval_Type'] = approvals[i]["Value29"] || '';
                        All_Approval_Group['POST_G1_FSoD_Code'] = approvals[i]["Value30"] || '';
                        All_Approval_Group['POST_G1_Approval_Body'] = approvals[i]["Value31"] || '';
                        All_Approval_Group['POST_G1_FSoD_Sig_Date'] = approvals[i]["Value32"] || '';
                        All_Approval_Group['POST_G2_Approval_Type'] = approvals[i]["Value33"] || '';
                        All_Approval_Group['POST_G2_FSoD_Code'] = approvals[i]["Value34"] || '';
                        All_Approval_Group['POST_G2_Approval_Body'] = approvals[i]["Value35"] || '';
                        All_Approval_Group['POST_G2_FSoD_Sig_Date'] = approvals[i]["Value36"] || '';
                        All_Approval_Group['POST_G3_Approval_Type'] = approvals[i]["Value37"] || '';
                        All_Approval_Group['POST_G3_FSoD_Code'] = approvals[i]["Value38"] || '';
                        All_Approval_Group['POST_G3_Approval_Body'] = approvals[i]["Value39"] || '';
                        All_Approval_Group['POST_G3_FSoD_Sig_Date'] = approvals[i]["Value40"] || '';
                        All_Approval_Group['POST_G4_Approval_Type'] = approvals[i]["Value41"] || '';
                        All_Approval_Group['POST_G4_FSoD_Code'] = approvals[i]["Value42"] || '';
                        All_Approval_Group['POST_G4_Approval_Body'] = approvals[i]["Value43"] || '';
                        All_Approval_Group['POST_G4_FSoD_Sig_Date'] = approvals[i]["Value44"] || '';
                        All_Approval_Group['POST_G5_Approval_Type'] = approvals[i]["Value45"] || '';
                        All_Approval_Group['POST_G5_FSoD_Code'] = approvals[i]["Value46"] || '';
                        All_Approval_Group['POST_G5_Approval_Body'] = approvals[i]["Value47"] || '';
                        All_Approval_Group['POST_G5_FSoD_Sig_Date'] = approvals[i]["Value48"] || '';

                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Min_Exp_Value'] = approvals[i]["Value49"] || '';
                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Max_Exp_Value'] = approvals[i]["Value51"] || '';
                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Expenditure_Notes'] = approvals[i]["Value50"] || '';
                    } else {
                        All_Approval_Group['POST_OB_Approval_Type'] = approvals[i]["Value24"] || '';
                        All_Approval_Group['POST_OB_FSoD_Code'] = approvals[i]["Value25"] || '';
                        All_Approval_Group['POST_OB_Approval_Body'] = approvals[i]["Value26"] || '';
                        All_Approval_Group['POST_OB_FSoD_Sig_Date'] = approvals[i]["Value27"] || '';
                        All_Approval_Group['POST_G1_Approval_Type'] = approvals[i]["Value28"] || '';
                        All_Approval_Group['POST_G1_FSoD_Code'] = approvals[i]["Value29"] || '';
                        All_Approval_Group['POST_G1_Approval_Body'] = approvals[i]["Value30"] || '';
                        All_Approval_Group['POST_G1_FSoD_Sig_Date'] = approvals[i]["Value31"] || '';
                        All_Approval_Group['POST_G2_Approval_Type'] = approvals[i]["Value32"] || '';
                        All_Approval_Group['POST_G2_FSoD_Code'] = approvals[i]["Value33"] || '';
                        All_Approval_Group['POST_G2_Approval_Body'] = approvals[i]["Value34"] || '';
                        All_Approval_Group['POST_G2_FSoD_Sig_Date'] = approvals[i]["Value35"] || '';
                        All_Approval_Group['POST_G3_Approval_Type'] = approvals[i]["Value36"] || '';
                        All_Approval_Group['POST_G3_FSoD_Code'] = approvals[i]["Value37"] || '';
                        All_Approval_Group['POST_G3_Approval_Body'] = approvals[i]["Value38"] || '';
                        All_Approval_Group['POST_G3_FSoD_Sig_Date'] = approvals[i]["Value39"] || '';
                        All_Approval_Group['POST_G4_Approval_Type'] = approvals[i]["Value40"] || '';
                        All_Approval_Group['POST_G4_FSoD_Code'] = approvals[i]["Value41"] || '';
                        All_Approval_Group['POST_G4_Approval_Body'] = approvals[i]["Value42"] || '';
                        All_Approval_Group['POST_G4_FSoD_Sig_Date'] = approvals[i]["Value43"] || '';
                        All_Approval_Group['POST_G5_Approval_Type'] = approvals[i]["Value44"] || '';
                        All_Approval_Group['POST_G5_FSoD_Code'] = approvals[i]["Value45"] || '';
                        All_Approval_Group['POST_G5_Approval_Body'] = approvals[i]["Value46"] || '';
                        All_Approval_Group['POST_G5_FSoD_Sig_Date'] = approvals[i]["Value47"] || '';

                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Min_Exp_Value'] = approvals[i]["Value48"] || '';
                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Max_Exp_Value'] = approvals[i]["Value50"] || '';
                        $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Expenditure_Header']['Expenditure_Notes'] = approvals[i]["Value49"] || '';
                    }
                }
            }
            resetViewState();
        }

        function Map_Expenditure_Details(data) {
            var xpnitmpExpNodes = data || $scope.getValueOfOnLoadData("DS_PPMT_GET_EXPENDITURE_DETAILS");
            delete $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            if (xpnitmpExpNodes.length) {
                for (var i = 0; i < xpnitmpExpNodes.length; i++) {
                    var iExpCount = 1;
                    var strChkParType = xpnitmpExpNodes[i].Value1.toString().trim();
                    var strChkExpType = xpnitmpExpNodes[i].Value14.toString().trim();
                    var strChkExpLineItemNo = xpnitmpExpNodes[i].Value21.toString().trim();
                    if (!check_Par_Type_Mapping(strChkParType)) {
                        mapParType(xpnitmpExpNodes[i]);
                    } else {
                        iExpCount = iExpCount + 1;
                        if (!check_Exp_Type_Mapping(strChkParType, strChkExpType)) {
                            iExpCount = 1;
                            mapExpenditureType(xpnitmpExpNodes[i], strChkParType);
                        } else {
                            if (!check_Exp_Details_Mapping(strChkParType, strChkExpType, strChkExpLineItemNo)) {
                                mapExpenditureLineItem(xpnitmpExpNodes[i], strChkParType, strChkExpType);
                            }
                        }
                    }

                }
            }
        }

        function check_Par_Type_Mapping(chkParType) {
            var tmpSearchParTypes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            var tempObj = commonApi._.filter(tmpSearchParTypes, function(val) {
                return val.PAR_TYPE == chkParType;
            })
            return !!tempObj.length;
        }

        function check_Exp_Type_Mapping(chkParType, chkExpType) {
            var tmpSearchParTypes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            var tempObj = commonApi._.filter(tmpSearchParTypes, function(val) {
                return val.PAR_TYPE == chkParType;
            });
            if (tempObj.length) {
                var obj = tempObj[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'];
                var o = commonApi._.filter(obj, function(val) {
                    return val.Expenditure_Type == chkExpType;
                });
                return !!o.length;
            }
            return false;
        }

        function check_Exp_Details_Mapping(strChkParType, strChkExpType, strChkLineItemNo) {
            var tmpSearchParTypes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            var tempObj = commonApi._.filter(tmpSearchParTypes, function(val) {
                return val.PAR_TYPE == strChkParType;
            });
            if (tempObj.length) {
                var obj = tempObj[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'];
                var o = commonApi._.filter(obj, function(val) {
                    return val.Expenditure_Type == strChkExpType;
                });
                if (o.length) {
                    var temp = o[0]['Expenditure_Detail_Groups']['Expenditure_Groups'];
                    var tempO = commonApi._.filter(temp, function(val) {
                        return val.Exp_Line_Item_No == strChkLineItemNo;
                    });
                    return !!tempO.length;
                }
            }
            return false;
        }

        function mapExpenditureType(xpntmpLoopNode, strtmpParType) {
            var parGroups = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            var tempObj = commonApi._.filter(parGroups, function(val) {
                return val.PAR_TYPE == strtmpParType;
            });
            if (!tempObj.length)
                return;

            if (!tempObj[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'])
                tempObj[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'] = [];

            var xpnExpType_insert_point = tempObj[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'];

            var strtmpIsActEditable = "1";
            var strtmpIsActuals = xpntmpLoopNode.Value73 || '';
            var strPrevYrAdj = xpntmpLoopNode.Value72 || '';
            var strdblLineTotal = getExpLineTotal(xpntmpLoopNode, strPrevYrAdj, strtmpIsActuals);

            var strShw_ECC_PSC_Supp = "";
            var strT_expType = xpntmpLoopNode.Value14.toString().trim();
            var straSplit_expType = strT_expType.split('|');
            var strExp_Type = "";
            if (straSplit_expType.length > 3) {
                strExp_Type = straSplit_expType[3].trim();
            }

            if (strExp_Type == "Construction" || strExp_Type == "Consultants") {
                if (xpntmpLoopNode.Value69.toString().trim() == "") {
                    strShw_ECC_PSC_Supp = xpntmpLoopNode.Value68.toString().trim();
                } else {
                    strShw_ECC_PSC_Supp = xpntmpLoopNode.Value69.toString().trim();
                }
            }

            xpnExpType_insert_point.push({
                Expenditure_Type: xpntmpLoopNode.Value14 || '',
                OB_Approval_Value: xpntmpLoopNode.Value15 || '',
                G1_Approval_Value: xpntmpLoopNode.Value16 || '',
                G2_Approval_Value: xpntmpLoopNode.Value17 || '',
                G3_Approval_Value: xpntmpLoopNode.Value18 || '',
                G4_Approval_Value: xpntmpLoopNode.Value19 || '',
                G5_Approval_Value: xpntmpLoopNode.Value20 || '',
                Ref_PAR_TYPE: xpntmpLoopNode.Value1 || '',
                Exp_Line_Item_Count: xpntmpLoopNode.Value71 || '',
                Expenditure_Detail_Groups: {
                    Expenditure_Groups: [{
                        Exp_Line_Item_No: xpntmpLoopNode.Value21 || '',
                        Streamlining_Target: xpntmpLoopNode.Value22 || '',
                        Act_Apr: xpntmpLoopNode.Value27 || '',
                        Act_May: xpntmpLoopNode.Value28 || '',
                        Act_Jun: xpntmpLoopNode.Value29 || '',
                        Act_Jul: xpntmpLoopNode.Value30 || '',
                        Act_Aug: xpntmpLoopNode.Value31 || '',
                        Act_Sep: xpntmpLoopNode.Value32 || '',
                        Act_Oct: xpntmpLoopNode.Value33 || '',
                        Act_Nov: xpntmpLoopNode.Value34 || '',
                        Act_Dec: xpntmpLoopNode.Value35 || '',
                        Act_Jan: xpntmpLoopNode.Value36 || '',
                        Act_Feb: xpntmpLoopNode.Value37 || '',
                        Act_Mar: xpntmpLoopNode.Value38 || '',
                        FCST_Apr: isForecastApplicable(xpntmpLoopNode.Value39, strtmpIsActuals, 4),
                        FCST_May: isForecastApplicable(xpntmpLoopNode.Value40, strtmpIsActuals, 5),
                        FCST_Jun: isForecastApplicable(xpntmpLoopNode.Value41, strtmpIsActuals, 6),
                        FCST_Jul: isForecastApplicable(xpntmpLoopNode.Value42, strtmpIsActuals, 7),
                        FCST_Aug: isForecastApplicable(xpntmpLoopNode.Value43, strtmpIsActuals, 8),
                        FCST_Sep: isForecastApplicable(xpntmpLoopNode.Value44, strtmpIsActuals, 9),
                        FCST_Oct: isForecastApplicable(xpntmpLoopNode.Value45, strtmpIsActuals, 10),
                        FCST_Nov: isForecastApplicable(xpntmpLoopNode.Value46, strtmpIsActuals, 11),
                        FCST_Dec: isForecastApplicable(xpntmpLoopNode.Value47, strtmpIsActuals, 12),
                        FCST_Jan: isForecastApplicable(xpntmpLoopNode.Value48, strtmpIsActuals, 1),
                        FCST_Feb: isForecastApplicable(xpntmpLoopNode.Value49, strtmpIsActuals, 2),
                        FCST_Mar: isForecastApplicable(xpntmpLoopNode.Value50, strtmpIsActuals, 3),
                        FCST_Y1_Q1: xpntmpLoopNode.Value51 || '',
                        FCST_Y1_Q2: xpntmpLoopNode.Value52 || '',
                        FCST_Y1_Q3: xpntmpLoopNode.Value53 || '',
                        FCST_Y1_Q4: xpntmpLoopNode.Value54 || '',
                        FCST_Y2: xpntmpLoopNode.Value55 || '',
                        FCST_Y3: xpntmpLoopNode.Value56 || '',
                        FCST_Y4: xpntmpLoopNode.Value57 || '',
                        FCST_Y5: xpntmpLoopNode.Value58 || '',
                        Exp_Role: '',
                        Exp_Details: xpntmpLoopNode.Value22 || '',
                        Exp_Supplier_Id: xpntmpLoopNode.Value75 || '',
                        Exp_Comments: xpntmpLoopNode.Value26 || '',
                        Exp_Framework: xpntmpLoopNode.Value24 || '',
                        Exp_Order_No: xpntmpLoopNode.Value69 || '',
                        Exp_IBIS_No: '',
                        Line_Total: strdblLineTotal,
                        FCST_Y6: xpntmpLoopNode.Value59 || '',
                        FCST_Y7: xpntmpLoopNode.Value60 || '',
                        FCST_Y8: xpntmpLoopNode.Value61 || '',
                        FCST_Y9: xpntmpLoopNode.Value62 || '',
                        FCST_Y10: xpntmpLoopNode.Value63 || '',
                        Supplier_Name: '',
                        FCST_Y11_Y15: xpntmpLoopNode.Value64 || '',
                        FCST_Y16_Y20: xpntmpLoopNode.Value65 || '',
                        Supplier_Id: xpntmpLoopNode.Value67 + " # " + strShw_ECC_PSC_Supp,
                        Salary_Role: xpntmpLoopNode.Value23 || '',
                        isActual: xpntmpLoopNode.Value73 || '',
                        Ref_Exp_Type: xpntmpLoopNode.Value14 || '',
                        Prev_Year: xpntmpLoopNode.Value66 || '',
                        isActEditable: strtmpIsActEditable,
                        isExpRowEditable: 1,
                        Prev_Year_Adj: xpntmpLoopNode.Value72 || '',
                        Ref_L_Par_Type: xpntmpLoopNode.Value1 || '',
                        Land_Purchase: xpntmpLoopNode.Value78 || '',
                        Compensation: xpntmpLoopNode.Value79 || '',
                        ThirdParty_Cost: xpntmpLoopNode.Value80 || '',
                        Oth_ThirdParty_Cost: xpntmpLoopNode.Value81 || '',
                        Framework: xpntmpLoopNode.Value82 || ''
                    }]
                }
            });
        }

        function mapExpenditureLineItem(xpntmpLoopNode, strtmpParType, strtmpExpType) {
            var parGroups = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];
            var parType = commonApi._.filter(parGroups, function(val) {
                return val.PAR_TYPE == strtmpParType;
            });
            if (!parType.length)
                return;

            var expenditureTypes = parType[0]['All_Expenditure_Group']['All_Exp_Types_Group']['Expenditure_Types'];
            var expenditureType = commonApi._.filter(expenditureTypes, function(val) {
                return val.Expenditure_Type == strtmpExpType;
            });
            if (!expenditureType.length)
                return;


            var xpnExpLineItem_insert_point = expenditureType[0]['Expenditure_Detail_Groups']['Expenditure_Groups']
            var strtmpIsActEditable = "1";
            var strtmpIsActuals = xpntmpLoopNode.Value73 || '';
            var strPrevYrAdj = xpntmpLoopNode.Value72 || '';
            var strdblLineTotal = getExpLineTotal(xpntmpLoopNode, strPrevYrAdj, strtmpIsActuals);
            var strshw_ECC_PSC_Supp = "";
            var strT_expType = xpntmpLoopNode.Value14.toString().trim();
            var straSplit_expType = strT_expType.split('|');

            var strExp_Type = "";
            if (straSplit_expType.length > 3) {
                strExp_Type = straSplit_expType[3].trim();
            }

            if (strExp_Type == "Construction" || strExp_Type == "Consultants") {
                if (xpntmpLoopNode.Value69.toString().trim() == "") {
                    strshw_ECC_PSC_Supp = xpntmpLoopNode.Value68.toString().trim();
                } else {
                    strshw_ECC_PSC_Supp = xpntmpLoopNode.Value69.toString().trim();
                }
            }

            xpnExpLineItem_insert_point.push({
                Exp_Line_Item_No: xpntmpLoopNode.Value21 || '',
                Streamlining_Target: xpntmpLoopNode.Value22 || '',
                Act_Apr: xpntmpLoopNode.Value27 || '',
                Act_May: xpntmpLoopNode.Value28 || '',
                Act_Jun: xpntmpLoopNode.Value29 || '',
                Act_Jul: xpntmpLoopNode.Value30 || '',
                Act_Aug: xpntmpLoopNode.Value31 || '',
                Act_Sep: xpntmpLoopNode.Value32 || '',
                Act_Oct: xpntmpLoopNode.Value33 || '',
                Act_Nov: xpntmpLoopNode.Value34 || '',
                Act_Dec: xpntmpLoopNode.Value35 || '',
                Act_Jan: xpntmpLoopNode.Value36 || '',
                Act_Feb: xpntmpLoopNode.Value37 || '',
                Act_Mar: xpntmpLoopNode.Value38 || '',
                FCST_Apr: isForecastApplicable(xpntmpLoopNode.Value39, strtmpIsActuals, 4),
                FCST_May: isForecastApplicable(xpntmpLoopNode.Value40, strtmpIsActuals, 5),
                FCST_Jun: isForecastApplicable(xpntmpLoopNode.Value41, strtmpIsActuals, 6),
                FCST_Jul: isForecastApplicable(xpntmpLoopNode.Value42, strtmpIsActuals, 7),
                FCST_Aug: isForecastApplicable(xpntmpLoopNode.Value43, strtmpIsActuals, 8),
                FCST_Sep: isForecastApplicable(xpntmpLoopNode.Value44, strtmpIsActuals, 9),
                FCST_Oct: isForecastApplicable(xpntmpLoopNode.Value45, strtmpIsActuals, 10),
                FCST_Nov: isForecastApplicable(xpntmpLoopNode.Value46, strtmpIsActuals, 11),
                FCST_Dec: isForecastApplicable(xpntmpLoopNode.Value47, strtmpIsActuals, 12),
                FCST_Jan: isForecastApplicable(xpntmpLoopNode.Value48, strtmpIsActuals, 1),
                FCST_Feb: isForecastApplicable(xpntmpLoopNode.Value49, strtmpIsActuals, 2),
                FCST_Mar: isForecastApplicable(xpntmpLoopNode.Value50, strtmpIsActuals, 3),
                FCST_Y1_Q1: xpntmpLoopNode.Value51 || '',
                FCST_Y1_Q2: xpntmpLoopNode.Value52 || '',
                FCST_Y1_Q3: xpntmpLoopNode.Value53 || '',
                FCST_Y1_Q4: xpntmpLoopNode.Value54 || '',
                FCST_Y2: xpntmpLoopNode.Value55 || '',
                FCST_Y3: xpntmpLoopNode.Value56 || '',
                FCST_Y4: xpntmpLoopNode.Value57 || '',
                FCST_Y5: xpntmpLoopNode.Value58 || '',
                Exp_Role: '',
                Exp_Details: xpntmpLoopNode.Value22 || '',
                Exp_Supplier_Id: xpntmpLoopNode.Value75 || '',
                Exp_Comments: xpntmpLoopNode.Value26 || '',
                Exp_Framework: xpntmpLoopNode.Value24 || '',
                Exp_Order_No: xpntmpLoopNode.Value69 || '',
                Exp_IBIS_No: '',
                Line_Total: strdblLineTotal,
                FCST_Y6: xpntmpLoopNode.Value59 || '',
                FCST_Y7: xpntmpLoopNode.Value60 || '',
                FCST_Y8: xpntmpLoopNode.Value61 || '',
                FCST_Y9: xpntmpLoopNode.Value62 || '',
                FCST_Y10: xpntmpLoopNode.Value63 || '',
                Supplier_Name: '',
                FCST_Y11_Y15: xpntmpLoopNode.Value64 || '',
                FCST_Y16_Y20: xpntmpLoopNode.Value65 || '',
                Supplier_Id: xpntmpLoopNode.Value67 + " # " + strshw_ECC_PSC_Supp,
                Salary_Role: xpntmpLoopNode.Value23 || '',
                isActual: xpntmpLoopNode.Value73 || '',
                Ref_Exp_Type: xpntmpLoopNode.Value14 || '',
                Prev_Year: xpntmpLoopNode.Value66 || '',
                isActEditable: strtmpIsActEditable,
                isExpRowEditable: 1,
                Prev_Year_Adj: xpntmpLoopNode.Value72 || '',
                Ref_L_Par_Type: xpntmpLoopNode.Value1 || '',
                Land_Purchase: xpntmpLoopNode.Value78 || '',
                Compensation: xpntmpLoopNode.Value79 || '',
                ThirdParty_Cost: xpntmpLoopNode.Value80 || '',
                Oth_ThirdParty_Cost: xpntmpLoopNode.Value81 || '',
                Framework: xpntmpLoopNode.Value82 || ''
            });
        }

        function isForecastApplicable(xpnNode, strIsActuals, iMonth) {
            var straSplitActuals = strIsActuals.split('|');
            if (straSplitActuals.length) {
                if (iMonth > 3)
                    iMonth -= 4;
                else
                    iMonth += 8;

                if (straSplitActuals[iMonth] == "1") {
                    return "0";
                } else {
                    return xpnNode.trim();
                }
            }
            return "";
        }

        function getExpLineTotal(xpntmpLoopNode, strPrevYrAdj, strtmpIsActuals) {
            return parseFloat(xpntmpLoopNode["Value27"].toString().trim()) + parseFloat(xpntmpLoopNode["Value28"].toString().trim()) + parseFloat(xpntmpLoopNode["Value29"].toString().trim()) + parseFloat(xpntmpLoopNode["Value30"].toString().trim()) + parseFloat(xpntmpLoopNode["Value31"].toString().trim()) + parseFloat(xpntmpLoopNode["Value32"].toString().trim()) + parseFloat(xpntmpLoopNode["Value33"].toString().trim()) + parseFloat(xpntmpLoopNode["Value34"].toString().trim()) + parseFloat(xpntmpLoopNode["Value35"].toString().trim()) + parseFloat(xpntmpLoopNode["Value36"].toString().trim()) + parseFloat(xpntmpLoopNode["Value37"].toString().trim()) + parseFloat(xpntmpLoopNode["Value38"].toString().trim()) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value39"], strtmpIsActuals, 4)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value40"], strtmpIsActuals, 5)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value41"], strtmpIsActuals, 6)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value42"], strtmpIsActuals, 7)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value43"], strtmpIsActuals, 8)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value44"], strtmpIsActuals, 9)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value45"], strtmpIsActuals, 10)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value46"], strtmpIsActuals, 11)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value47"], strtmpIsActuals, 12)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value48"], strtmpIsActuals, 1)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value49"], strtmpIsActuals, 2)) + parseFloat(isForecastApplicable(xpntmpLoopNode["Value50"], strtmpIsActuals, 3)) + parseFloat(xpntmpLoopNode["Value51"].toString().trim()) + parseFloat(xpntmpLoopNode["Value52"].toString().trim()) + parseFloat(xpntmpLoopNode["Value53"].toString().trim()) + parseFloat(xpntmpLoopNode["Value54"].toString().trim()) + parseFloat(xpntmpLoopNode["Value55"].toString().trim()) + parseFloat(xpntmpLoopNode["Value56"].toString().trim()) + parseFloat(xpntmpLoopNode["Value57"].toString().trim()) + parseFloat(xpntmpLoopNode["Value58"].toString().trim()) + parseFloat(xpntmpLoopNode["Value59"].toString().trim()) + parseFloat(xpntmpLoopNode["Value60"].toString().trim()) + parseFloat(xpntmpLoopNode["Value61"].toString().trim()) + parseFloat(xpntmpLoopNode["Value62"].toString().trim()) + parseFloat(xpntmpLoopNode["Value63"].toString().trim()) + parseFloat(xpntmpLoopNode["Value64"].toString().trim()) + parseFloat(xpntmpLoopNode["Value65"].toString().trim());
        }

        function mapParType(xpntmpLoopNode) {
            var strtmpIsActEditable = "1";
            var strtmpIsActuals = xpntmpLoopNode["Value73"];
            var strPrevYrAdj = xpntmpLoopNode["Value72"];
            var strdblLineTotal = getExpLineTotal(xpntmpLoopNode, strPrevYrAdj, strtmpIsActuals);
            var strshw_ECC_PSC_Supp = "";
            var strT_expType = xpntmpLoopNode["Value14"].toString().trim();
            var strasplit_expType = strT_expType.split('|');
            var strExp_Type = "";

            if (strasplit_expType.length > 3) {
                strExp_Type = strasplit_expType[3].toString().trim();
            }

            if (strExp_Type == "Construction" || strExp_Type == "Consultants") {
                if (xpntmpLoopNode["Value69"].toString().trim() == "") {
                    strshw_ECC_PSC_Supp = xpntmpLoopNode.Value68.toString().trim();
                } else {
                    strshw_ECC_PSC_Supp = xpntmpLoopNode.Value69.toString().trim();
                }
            }

            if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups']) {
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'] = [];
            }

            var xpnParType_insert_point = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'];

            xpnParType_insert_point.push({
                PAR_TYPE: xpntmpLoopNode.Value1 || '',
                OB_95_Risk_Value: xpntmpLoopNode.Value2 || '',
                G1_95_Risk_Value: xpntmpLoopNode.Value3 || '',
                G2_95_Risk_Value: xpntmpLoopNode.Value4 || '',
                G3_95_Risk_Value: xpntmpLoopNode.Value5 || '',
                G4_95_Risk_Value: xpntmpLoopNode.Value6 || '',
                G5_95_Risk_Value: xpntmpLoopNode.Value7 || '',
                OB_50_Risk_Value: xpntmpLoopNode.Value8 || '',
                G1_50_Risk_Value: xpntmpLoopNode.Value9 || '',
                G2_50_Risk_Value: xpntmpLoopNode.Value10 || '',
                G3_50_Risk_Value: xpntmpLoopNode.Value11 || '',
                G4_50_Risk_Value: xpntmpLoopNode.Value12 || '',
                G5_50_Risk_Value: xpntmpLoopNode.Value13 || '',
                All_Expenditure_Group: {
                    All_Exp_Types_Group: {
                        Expenditure_Types: [{
                            Expenditure_Type: xpntmpLoopNode.Value14 || '',
                            OB_Approval_Value: xpntmpLoopNode.Value15 || '',
                            G1_Approval_Value: xpntmpLoopNode.Value16 || '',
                            G2_Approval_Value: xpntmpLoopNode.Value17 || '',
                            G3_Approval_Value: xpntmpLoopNode.Value18 || '',
                            G4_Approval_Value: xpntmpLoopNode.Value19 || '',
                            G5_Approval_Value: xpntmpLoopNode.Value20 || '',
                            Ref_PAR_TYPE: xpntmpLoopNode.Value1 || '',
                            Exp_Line_Item_Count: xpntmpLoopNode.Value71 || '',
                            Expenditure_Detail_Groups: {
                                Expenditure_Groups: [{
                                    Exp_Line_Item_No: xpntmpLoopNode.Value21 || '',
                                    Streamlining_Target: xpntmpLoopNode.Value22 || '',
                                    Act_Apr: xpntmpLoopNode.Value27 || '',
                                    Act_May: xpntmpLoopNode.Value28 || '',
                                    Act_Jun: xpntmpLoopNode.Value29 || '',
                                    Act_Jul: xpntmpLoopNode.Value30 || '',
                                    Act_Aug: xpntmpLoopNode.Value31 || '',
                                    Act_Sep: xpntmpLoopNode.Value32 || '',
                                    Act_Oct: xpntmpLoopNode.Value33 || '',
                                    Act_Nov: xpntmpLoopNode.Value34 || '',
                                    Act_Dec: xpntmpLoopNode.Value35 || '',
                                    Act_Jan: xpntmpLoopNode.Value36 || '',
                                    Act_Feb: xpntmpLoopNode.Value37 || '',
                                    Act_Mar: xpntmpLoopNode.Value38 || '',
                                    FCST_Apr: isForecastApplicable(xpntmpLoopNode.Value39, strtmpIsActuals, 4),
                                    FCST_May: isForecastApplicable(xpntmpLoopNode.Value40, strtmpIsActuals, 5),
                                    FCST_Jun: isForecastApplicable(xpntmpLoopNode.Value41, strtmpIsActuals, 6),
                                    FCST_Jul: isForecastApplicable(xpntmpLoopNode.Value42, strtmpIsActuals, 7),
                                    FCST_Aug: isForecastApplicable(xpntmpLoopNode.Value43, strtmpIsActuals, 8),
                                    FCST_Sep: isForecastApplicable(xpntmpLoopNode.Value44, strtmpIsActuals, 9),
                                    FCST_Oct: isForecastApplicable(xpntmpLoopNode.Value45, strtmpIsActuals, 10),
                                    FCST_Nov: isForecastApplicable(xpntmpLoopNode.Value46, strtmpIsActuals, 11),
                                    FCST_Dec: isForecastApplicable(xpntmpLoopNode.Value47, strtmpIsActuals, 12),
                                    FCST_Jan: isForecastApplicable(xpntmpLoopNode.Value48, strtmpIsActuals, 1),
                                    FCST_Feb: isForecastApplicable(xpntmpLoopNode.Value49, strtmpIsActuals, 2),
                                    FCST_Mar: isForecastApplicable(xpntmpLoopNode.Value50, strtmpIsActuals, 3),
                                    FCST_Y1_Q1: xpntmpLoopNode.Value51 || '',
                                    FCST_Y1_Q2: xpntmpLoopNode.Value52 || '',
                                    FCST_Y1_Q3: xpntmpLoopNode.Value53 || '',
                                    FCST_Y1_Q4: xpntmpLoopNode.Value54 || '',
                                    FCST_Y2: xpntmpLoopNode.Value55 || '',
                                    FCST_Y3: xpntmpLoopNode.Value56 || '',
                                    FCST_Y4: xpntmpLoopNode.Value57 || '',
                                    FCST_Y5: xpntmpLoopNode.Value58 || '',
                                    Exp_Role: '',
                                    Exp_Details: xpntmpLoopNode.Value22 || '',
                                    Exp_Supplier_Id: xpntmpLoopNode.Value75 || '',
                                    Exp_Comments: xpntmpLoopNode.Value26 || '',
                                    Exp_Framework: xpntmpLoopNode.Value24 || '',
                                    Exp_Order_No: xpntmpLoopNode.Value69 || '',
                                    Exp_IBIS_No: '',
                                    Line_Total: strdblLineTotal,
                                    FCST_Y6: xpntmpLoopNode.Value59 || '',
                                    FCST_Y7: xpntmpLoopNode.Value60 || '',
                                    FCST_Y8: xpntmpLoopNode.Value61 || '',
                                    FCST_Y9: xpntmpLoopNode.Value62 || '',
                                    FCST_Y10: xpntmpLoopNode.Value63 || '',
                                    Supplier_Name: '',
                                    FCST_Y11_Y15: xpntmpLoopNode.Value64 || '',
                                    FCST_Y16_Y20: xpntmpLoopNode.Value65 || '',
                                    Supplier_Id: xpntmpLoopNode.Value67 + " # " + strshw_ECC_PSC_Supp,
                                    Salary_Role: xpntmpLoopNode.Value23 || '',
                                    isActual: xpntmpLoopNode.Value73 || '',
                                    Ref_Exp_Type: xpntmpLoopNode.Value14 || '',
                                    Prev_Year: xpntmpLoopNode.Value66 || '',
                                    isActEditable: strtmpIsActEditable,
                                    isExpRowEditable: 1,
                                    Prev_Year_Adj: xpntmpLoopNode.Value72 || '',
                                    Ref_L_Par_Type: xpntmpLoopNode.Value1 || '',
                                    Land_Purchase: xpntmpLoopNode.Value78 || '',
                                    Compensation: xpntmpLoopNode.Value79 || '',
                                    ThirdParty_Cost: xpntmpLoopNode.Value80 || '',
                                    Oth_ThirdParty_Cost: xpntmpLoopNode.Value81 || '',
                                    Framework: xpntmpLoopNode.Value82 || ''
                                }]
                            }
                        }]
                    }
                }
            });
        }

        $scope.parseFloat = parseFloat;

        $scope.filterExpenditureRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_EXPENDITURE_APPROVALS,DS_PPMT_GET_EXPENDITURE_DETAILS,DS_PPMT_GET_CWR_FUNDING",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_EXPENDITURE_APPROVALS",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_EXPENDITURE_DETAILS",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_CWR_FUNDING",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_EXPENDITURE_APPROVALS = JSON.parse(response.data['DS_PPMT_GET_EXPENDITURE_APPROVALS']);
                    if (DS_PPMT_GET_EXPENDITURE_APPROVALS.Items && DS_PPMT_GET_EXPENDITURE_APPROVALS.Items.Item) {
                        Map_Approval_Details(DS_PPMT_GET_EXPENDITURE_APPROVALS.Items.Item);
                    }
                    var DS_PPMT_GET_EXPENDITURE_DETAILS = JSON.parse(response.data['DS_PPMT_GET_EXPENDITURE_DETAILS']);
                    if (DS_PPMT_GET_EXPENDITURE_DETAILS.Items && DS_PPMT_GET_EXPENDITURE_DETAILS.Items.Item) {
                        Map_Expenditure_Details(DS_PPMT_GET_EXPENDITURE_DETAILS.Items.Item);
                        var parGroups = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups']
                        var xpnChkPPNode = parGroups && $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'][1];
                        if (!xpnChkPPNode) {
                            $scope.setBlankPostParNode();
                        }
                        resetExpanditureData()
                    }
                    var DS_PPMT_GET_CWR_FUNDING = JSON.parse(response.data['DS_PPMT_GET_CWR_FUNDING']);
                    if (DS_PPMT_GET_CWR_FUNDING.Items && DS_PPMT_GET_CWR_FUNDING.Items.Item) {
                        $scope.fundingSubTabData = DS_PPMT_GET_CWR_FUNDING.Items.Item;
                        $scope.fundingDataCash = commonApi._.filter($scope.fundingSubTabData, function(val) {
                            return val.Value39.indexOf('Kind') == -1
                        });
                        $scope.fundingDataInKind = commonApi._.filter($scope.fundingSubTabData, function(val) {
                            return val.Value39.indexOf('Kind') != -1
                        });
                    }
                }
                toManageUIofTable();
            });
        };

        $scope.filterMilestoneRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_MILESTONES",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_MILESTONES",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_MILESTONES = JSON.parse(response.data['DS_PPMT_GET_CWR_MILESTONES']);
                    if (DS_PPMT_GET_CWR_MILESTONES.Items && DS_PPMT_GET_CWR_MILESTONES.Items.Item) {
                        $scope.milestoneRow = DS_PPMT_GET_CWR_MILESTONES.Items.Item;
                    }
                }
                toManageUIofTable()
            });
        };

        $scope.filterRolesRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_ROLES",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_ROLES",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_ROLES = JSON.parse(response.data['DS_PPMT_GET_CWR_ROLES']);
                    if (DS_PPMT_GET_CWR_ROLES.Items && DS_PPMT_GET_CWR_ROLES.Items.Item) {
                        $scope.rolesSubTabData = DS_PPMT_GET_CWR_ROLES.Items.Item;
                    }
                }
                toManageUIofTable()
            });
        };

        $scope.filterFundingRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_FUNDING",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_FUNDING",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_FUNDING = JSON.parse(response.data['DS_PPMT_GET_CWR_FUNDING']);
                    if (DS_PPMT_GET_CWR_FUNDING.Items && DS_PPMT_GET_CWR_FUNDING.Items.Item) {
                        $scope.fundingSubTabData = DS_PPMT_GET_CWR_FUNDING.Items.Item;
                        $scope.fundingDataCash = commonApi._.filter($scope.fundingSubTabData, function(val) {
                            return val.Value39.indexOf('Kind') == -1
                        });
                        $scope.fundingDataInKind = commonApi._.filter($scope.fundingSubTabData, function(val) {
                            return val.Value39.indexOf('Kind') != -1
                        });
                    }
                }
            });
        };

        $scope.filterTargetRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_TARGETS",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_TARGETS",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_TARGETS = JSON.parse(response.data['DS_PPMT_GET_CWR_TARGETS']);
                    if (DS_PPMT_GET_CWR_TARGETS.Items && DS_PPMT_GET_CWR_TARGETS.Items.Item) {
                        $scope.targetsSubTabData = DS_PPMT_GET_CWR_TARGETS.Items.Item;
                    }
                }
            });
        };

        $scope.filterIssueLogRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_ISSUE_LOG",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_ISSUE_LOG",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_ISSUE_LOG = JSON.parse(response.data['DS_PPMT_GET_CWR_ISSUE_LOG']);
                    if (DS_PPMT_GET_CWR_ISSUE_LOG.Items && DS_PPMT_GET_CWR_ISSUE_LOG.Items.Item) {
                        $scope.IssueLogTabData = DS_PPMT_GET_CWR_ISSUE_LOG.Items.Item;
                    }
                }
                toManageUIofTable()
            });
        };

        $scope.filterProjectDetailRecords = function(value) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_CWR_DEFRAWAG,DS_PPMT_GET_MILESTONEDATA,DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA,DS_PPMT_GET_MILESTONE_FUNDING_DATA,DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_CWR_DEFRAWAG",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_MILESTONEDATA",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_MILESTONE_FUNDING_DATA",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }, {
                        "fieldName": "DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS",
                        "fieldValue": $scope.dsFormId + ',' + value
                    }]
                },
                'DS_FORMGROUPCODE': 'PRS'
            };
            $scope.isLoading = true;
            $scope.getCallbackData(form).then(function(response) {
                $scope.isLoading = false;
                if (response.data) {
                    var DS_PPMT_GET_CWR_DEFRAWAG = JSON.parse(response.data['DS_PPMT_GET_CWR_DEFRAWAG']);
                    var DS_PPMT_GET_MILESTONEDATA = JSON.parse(response.data['DS_PPMT_GET_MILESTONEDATA']);
                    var DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA = JSON.parse(response.data['DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA']);
                    var DS_PPMT_GET_MILESTONE_FUNDING_DATA = JSON.parse(response.data['DS_PPMT_GET_MILESTONE_FUNDING_DATA']);
                    var DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS = JSON.parse(response.data['DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS']);

                    if (DS_PPMT_GET_CWR_DEFRAWAG.Items && DS_PPMT_GET_CWR_DEFRAWAG.Items.Item) {
                        $scope.Project_Defrawag = DS_PPMT_GET_CWR_DEFRAWAG.Items.Item;
                    }
                    if (DS_PPMT_GET_MILESTONEDATA.Items && DS_PPMT_GET_MILESTONEDATA.Items.Item) {
                        $scope.dsPpmtGetMilestibeData = DS_PPMT_GET_MILESTONEDATA.Items.Item;
                    }
                    if (DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA.Items && DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA.Items.Item) {
                        $scope.dsPpmtGetMilestoneExpenditureData = DS_PPMT_GET_MILESTONE_EXPENDITURE_DATA.Items.Item;
                    }
                    if (DS_PPMT_GET_MILESTONE_FUNDING_DATA.Items && DS_PPMT_GET_MILESTONE_FUNDING_DATA.Items.Item) {
                        $scope.dsPpmtGetMilestoneFundingData = DS_PPMT_GET_MILESTONE_FUNDING_DATA.Items.Item;
                    }
                    if (DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS.Items && DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS.Items.Item) {
                        $scope.defrawagProjectDetails = DS_PPMT_GET_DEFRAWAG_PROJECT_DETAILS.Items.Item;
                    }
                }
            });
        }

        $scope.getFundingTotal = function(key, Cash_InKind, forGrandTotal) {
            var source = [];

            if (forGrandTotal) {
                source = $scope.fundingSubTabData;
            } else if (Cash_InKind == 'In Kind') {
                source = $scope.fundingDataInKind;
            } else {
                source = $scope.fundingDataCash;
            }

            var total = 0;
            for (var i = 0; i < source.length; i++) {
                total += parseFloat(source[i][key]);
            }
            return total;
        }
    }

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
             $timeout(function() {
                $scope.loaded = true;
                $element.addClass('loaded');                
              }, 500);
            }
        });

        if ($scope.isPrintView) {
            $controller(PrintViewController, {
                $scope: $scope,
                $element: $element
            });
            $scope.setPrintViewDefaultData();
        }

        $scope.regForNumbersOnly = '\\d+';
        $scope.regForRef = '\\d{3}[a-zA-z]{1}$';
        $scope.regForTwelve = '[a-zA-z]{2}\\s\\d{4}\\s\\d{4}$';
        $scope.regForTen = '[F][R]\\/\\d{2}\\/[S]\\d{3}$';

        (function setPickListValues() {
            var pickLists = $scope.getValueOfOnLoadData("DS_PPMT_GET_PICKLISTS");
            $scope.projectTeamsForSE = commonApi._.filter(pickLists, function(val) {
                return val.Value5.indexOf("SE - E and B") != -1 && val.Value6 != -1;
            });

            var obj = {
                committees: [],
                cfmps: [],
                projectTypes: [],
                ncpms: [],
                projectPlans: [],
                assets: [],
                projectStatuses: [],
                strategies: [],
                countries: [],
                regions: [],
                area: [],
                coastalGroups: [],
                counties: [],
                authorityTypes: [],
                functions: [],
                projectTeamsForUi: [],
                operatingAuthorities: {
                    36: [],
                    164: [],
                    183: [],
                    162: [],
                    154: [],
                },
                fundingCodes: [],
                eaLevels: [],
                frmDeliveryRisks: [],
                categories: [],
                moderationEvidencies: [],
                idbGrantRates: [],
                contributingRFCC1s: [],
            };

            for (var i = 0; i < pickLists.length; i++) {
                switch (parseInt(pickLists[i].Value1)) {
                    case 64:
                        obj.committees.push(pickLists[i]);
                        break;
                    case 65:
                        obj.cfmps.push(pickLists[i]);
                        break;
                    case 66:
                        obj.projectTypes.push(pickLists[i]);
                        break;
                    case 19:
                        obj.ncpms.push(pickLists[i]);
                        break;
                    case 57:
                        obj.projectPlans.push(pickLists[i]);
                        break;
                    case 4:
                        obj.assets.push(pickLists[i]);
                        break;
                    case 13:
                        obj.projectStatuses.push(pickLists[i]);
                        break;
                    case 49:
                        obj.strategies.push(pickLists[i]);
                        break;
                    case 14:
                        obj.countries.push(pickLists[i]);
                        break;
                    case 43:
                        obj.regions.push(pickLists[i]);
                        break;
                    case 3:
                        obj.area.push(pickLists[i]);
                        break;
                    case 8:
                        obj.coastalGroups.push(pickLists[i]);
                        break;
                    case 103:
                        obj.counties.push(pickLists[i]);
                        break;
                    case 5:
                        obj.authorityTypes.push(pickLists[i]);
                        break;
                    case 26:
                        obj.functions.push(pickLists[i]);
                        break;
                    case 21:
                        obj.projectTeamsForUi.push(pickLists[i]);
                        break;
                    case 36:
                        obj.operatingAuthorities['36'].push(pickLists[i]);
                        break;
                    case 164:
                        obj.operatingAuthorities['164'].push(pickLists[i]);
                        break;
                    case 183:
                        obj.operatingAuthorities['183'].push(pickLists[i]);
                        break;
                    case 162:
                        obj.operatingAuthorities['162'].push(pickLists[i]);
                        break;
                    case 154:
                        obj.operatingAuthorities['154'].push(pickLists[i]);
                        break;
                    case 6:
                        obj.fundingCodes.push(pickLists[i]);
                        break;
                    case 22:
                        obj.eaLevels.push(pickLists[i]);
                        break;
                    case 20:
                        obj.frmDeliveryRisks.push(pickLists[i]);
                        break;
                    case 30:
                        obj.categories.push(pickLists[i]);
                        break;
                    case 34:
                        obj.moderationEvidencies.push(pickLists[i]);
                        break;
                    case 17:
                        obj.idbGrantRates.push(pickLists[i]);
                        break;
                    case 72:
                        obj.contributingRFCC1s.push(pickLists[i]);
                        break;
                }

            }

            $scope.committees = obj.committees;
            $scope.cfmps = obj.cfmps;
            $scope.projectTypes = obj.projectTypes;
            $scope.ncpms = obj.ncpms;
            $scope.projectPlans = commonApi._.filter(obj.projectPlans, function(val) {
                return val.Value6 != -1;
            });
            $scope.assets = obj.assets;
            $scope.projectStatuses = obj.projectStatuses;
            $scope.strategies = commonApi._.filter(obj.strategies, function(val) {
                return val.Value6 != -1;
            });

            $scope.countries = obj.countries;
            $scope.regions = obj.regions;
            $scope.area = commonApi._.filter(obj.area, function(val) {
                val.Value5 == '' && (val.Value5 = undefined);
                return val.Value6 != -1;
            });
            $scope.coastalGroups = obj.coastalGroups;
            $scope.counties = commonApi._.filter(obj.counties, function(val) {
                return val.Value6 != -1;
            });

            $scope.authorityTypes = obj.authorityTypes;
            $scope.functions = commonApi._.filter(obj.functions, function(val) {
                return val.Value6 != -1;
            });
            $scope.projectTeamsForUi = commonApi._.filter(obj.projectTeamsForUi, function(val) {
                return val.Value6 != -1;
            });
            $scope.operatingAuthorities = {
                36: obj.operatingAuthorities['36'],
                164: obj.operatingAuthorities['164'],
                183: obj.operatingAuthorities['183'],
                162: obj.operatingAuthorities['162'],
                154: obj.operatingAuthorities['154']
            }

            $scope.fundingCodes = obj.fundingCodes;
            $scope.eaLevels = obj.eaLevels;
            $scope.frmDeliveryRisks = obj.frmDeliveryRisks;
            $scope.categories = obj.categories;
            $scope.moderationEvidencies = obj.moderationEvidencies;
            $scope.idbGrantRates = obj.idbGrantRates;
            $scope.contributingRFCC1s = commonApi._.filter(obj.contributingRFCC1s, function(val) {
                val.Value5 == '' && (val.Value5 = undefined);
                return val.Value6 != -1;
            });

        })();

        $scope.checkProjectNumber = function(form) {
            if (!$scope.projectRecord.NPrjNo_Committee || !$scope.projectRecord.NPrjNo_Plan2 || !$scope.projectRecord.NPrjNo_Plan3 || !form.NPrjNo_Plan3.$valid || !$scope.projectRecord.NPrjNo_Plan4 || !$scope.projectRecord.NPrjNo_Strategy1 || !form.NPrjNo_Strategy1.$valid || !$scope.projectRecord.NPrjNo_Prj_Rev_Status || !form.NPrjNo_Prj_Rev_Status.$valid)
                return;

            var national_Project_No = $scope.projectRecord.NPrjNo_Committee.split('|')[3] + $scope.projectRecord.NPrjNo_Plan2.split('|')[3] + $scope.projectRecord.NPrjNo_Plan3 + $scope.projectRecord.NPrjNo_Plan4.split('|')[3] + "/" + $scope.projectRecord.NPrjNo_Strategy1 + "/" + $scope.projectRecord.NPrjNo_Prj_Rev_Status;
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_CHK_NATIONAL_PROJ_NO",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_CHK_NATIONAL_PROJ_NO",
                        "fieldValue": national_Project_No
                    }]
                }
            };

            $scope.getCallbackData(form).then(function(response) {
                if (response.data) {
                    var value = JSON.parse(response.data['DS_PPMT_CHK_NATIONAL_PROJ_NO']);
                    if (value['Items']['Item'][0].Name == "YES") {
                        $scope.projectRecord.National_Project_No = '';
                        $scope.National_Project_No_Validation = {
                            show: true,
                            title: 'Invalid National Project Number specified !!!\n\nThe National Project Number specified is already being used for some other project'
                        };
                    } else {
                        $scope.National_Project_No_Validation = {
                            show: false,
                            title: ''
                        };
                        $scope.projectRecord.National_Project_No = national_Project_No;
                        $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'] = national_Project_No;
                        $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = national_Project_No;
                    }
                    $scope.formCustomFields['ORI_MSG_Custom_Fields']['isValidNProject_No'] = value['Items']['Item'][0].Name;
                }
            });

        }

        $scope.checkIbisNumber = function(form) {
            if (!$scope.projectRecord.IBISNo1 || !$scope.projectRecord.IBISNo2 || !$scope.projectRecord.IBISNo3 || !form.IBISNo2.$valid)
                return;

            var ibsi_Project_No = $scope.projectRecord.IBISNo1 + $scope.projectRecord.IBISNo2 + $scope.projectRecord.IBISNo3;
            var reg = /[a-zA-z]{3}\d{7}[a-zA-z]{1}$/;
            var isValid = reg.test(ibsi_Project_No);
            if (!isValid) {
                form.IBISNo2.$valid = false;
                return;
            }

            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_CHK_IBIS_NUMBER",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_CHK_IBIS_NUMBER",
                        "fieldValue": ibsi_Project_No
                    }]
                }
            };

            $scope.getCallbackData(form).then(function (response) {
            	if (response.data) {
            		var value = JSON.parse(response.data['DS_PPMT_CHK_IBIS_NUMBER']);
            		if (value['Items']['Item'][0].Name == "YES") {
            			$scope.IBIS_Project_No_Validation = {
            				show: true,
            				title: 'Invalid SOP Project Number specified !!!\n\nThe SOP Project Number specified is already being used for some other project'
            			};
            			$scope.projectRecord.IBIS_Project_No = '';
            		} else {
            			$scope.IBIS_Project_No_Validation = {
            				show: false,
            				title: ''
            			};
            			$scope.projectRecord.IBIS_Project_No = ibsi_Project_No;
            			$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT2'] = ibsi_Project_No;
            		}
            		$scope.formCustomFields['ORI_MSG_Custom_Fields']['isValidIBISNumber'] = value['Items']['Item'][0].Name;
            	}
            	$scope.checkSOPField();
            });
        }

        if (!String.prototype.trim) {
            String.prototype.trim = function() {
                return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
            };
        }

        $scope.restrictCharPaste = function(event) {
            var inputValue;
            if ($window.clipboardData) {
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }

            if (inputValue.match(/[|<>#&]/gi)) {
                ADODDLE.alert({
                    title: "Restrict Character Entered!!!",
                    msg: "Restricted Characters specified!!! Restricted Characters # | < &"
                });
                event.preventDefault();
                return false;
            }
        };

        $scope.restrictChar = function(event, inputValue) {
            switch (event.keyCode) {
                case 188:
                case 190:
                case 219:
                case 221:
                case 51:
                case 55:
                case 220:
                    if (event.shiftKey) {
                        ADODDLE.alert({
                            title: "Restrict Character Entered!!!",
                            msg: "Restricted Characters specified!!! Restricted Characters | < > #"
                        });
                        event.preventDefault();
                    }
                    break;
            }
        };

        $scope.expandTextArea = function expandTextArea(event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = event.currentTarget.scrollHeight + 'px';
        };

        $scope.delayedResize = function delayedResize(event) {
            $window.setTimeout($scope.expandTextArea(event), 1000);
        }

        $scope.addRepeatingRowPrs = function(items) {
            $scope.addRepeatingRow(items, {
                "Function": ""
            });
        }

        $scope.expandTextAreaOnLoad = function() {
            var textAreaObj = document.getElementsByTagName('textarea');
            if (textAreaObj) {
                for (var i = 0; i < textAreaObj.length; i++) {
                    textAreaObj[i].style.height = 'auto';
                    textAreaObj[i].style.height = textAreaObj[i].scrollHeight + 'px';
                }
            }
        }

        $scope.checkSOPField = function() {
            if ($scope.projectRecord.IBIS_Project_No == '' && $scope.projectTeams.Authority_Type != '' && ($scope.projectTeams.Authority_Type.indexOf('5|30|') == 0 || $scope.projectTeams.Authority_Type.indexOf('5|1835|') == 0) && $scope.projectRecord.Project_Status.toLowerCase().indexOf('candidate') == -1 && $scope.projectRecord.Project_Status.indexOf('Archive') == -1) {
                $scope.myform.IBIS_Project_No.$setValidity('required', false);
                document.getElementById('ibsiNoErrorImg').style.display = 'block';
            } else {
                $scope.myform.IBIS_Project_No.$setValidity('required', true);
                document.getElementById('ibsiNoErrorImg').style.display = 'none';
            }
        }

        $scope.filterProjectTeamsForAnglian = function(teams) {
            return (teams.Value5.indexOf(($scope.projectLocation.Region || '').split('|')[3]) != -1 || teams.Value4.indexOf('ncpms - Lateral') != -1 || teams.Value4.indexOf('NEAS - Lateral') != -1)
        }

        $scope.filterProjectTeamsForMidlands = function(teams) {
            return (teams.Value5.indexOf(($scope.projectLocation.Region || '').split('|')[3]) != -1 || teams.Value8.indexOf('--- ncpms - Midlands') != -1 || teams.Value8.indexOf('Lateral') != -1 || teams.Value8.indexOf('--- NEAS - Midlands') != -1)
        }

        $scope.maskValueOnFocus = function(event , scopeVal){
            event.currentTarget.select();
            switch(scopeVal) {
                case "searchPMPanelFlag":
                    //$scope.searchPMPanelFlag = false;
                    $scope.searchPEPanelFlag = false;
                    $scope.searchPROPanelFlag = false;
                    $scope.searchSPMPanelFlag = false;
                    break;
                case "searchPEPanelFlag":
                    $scope.searchPMPanelFlag = false;
                    //$scope.searchPEPanelFlag = false;
                    $scope.searchPROPanelFlag = false;
                    $scope.searchSPMPanelFlag = false;
                    break;
                case "searchPROPanelFlag":
                    $scope.searchPMPanelFlag = false;
                    $scope.searchPEPanelFlag = false;
                    //$scope.searchPROPanelFlag = false;
                    $scope.searchSPMPanelFlag = false;
                    break;
                case "searchSPMPanelFlag":
                    $scope.searchPMPanelFlag = false;
                    $scope.searchPEPanelFlag = false;
                    $scope.searchPROPanelFlag = false;
                    //$scope.searchSPMPanelFlag = false;
                    break;
            }
        }

        function setDefaultData() {
        	$scope.dsFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'];
        	$scope.printBy = $scope.data['myFields']['Asite_System_Data_Read_Only']['_2_Printing_Data']['DS_PRINTEDBY'];
        	$scope.projectRoles = $scope.getValueOfOnLoadData("DS_PROJUSERS_ROLE");
        	$scope.projectExecutives = commonApi._.filter($scope.projectRoles, function (value) {
        			return value.Value.indexOf('Project Executive') == 0;
        		});
        	$scope.projectRecordOwners = commonApi._.filter($scope.projectRoles, function (value) {
        			return value.Value.indexOf('Project Record Owner') == 0;
        		});
        	$scope.projectManagers = commonApi._.filter($scope.projectRoles, function (value) {
        			return value.Value.indexOf('Project Manager') == 0;
        		});

        	/*Below fields used in serach dropdown*/
        	$scope.search_Project_Manager = "";
        	$scope.searchPMPanelFlag = false;

        	$scope.search_Project_Executive = "";
        	$scope.searchPEPanelFlag = false;

        	$scope.search_Project_Record_Owner = "";
        	$scope.searchPROPanelFlag = false;

        	$scope.search_Secondary_PM = "";
        	$scope.searchSPMPanelFlag = false;

        	$scope.formCustomFields = $scope.data['myFields']['FORM_CUSTOM_FIELDS'];
        	$scope.projectRecord = $scope.formCustomFields['ORI_MSG_Custom_Fields']['PROJECT_RECORD'];
        	if (!$scope.projectRecord['PROJECT_LOCATION'])
        		$scope.projectRecord['PROJECT_LOCATION'] = {
        			"Area": "",
        			"RFDC": "",
        			"Coastal_Group": "",
        			"Country": "",
        			"Region": "",
        			"FCRM_System_No": "",
        			"National_Grid_Ref": "",
        			"Scheme_Location": "",
        			"County": ""
        		};
        	$scope.projectLocation = $scope.projectRecord['PROJECT_LOCATION'];
        	if (!$scope.projectRecord['PROJECT_TEAMS'])
        		$scope.projectRecord['PROJECT_TEAMS'] = {};
        	$scope.projectTeams = $scope.projectRecord['PROJECT_TEAMS'];

        	if (!$scope.projectTeams['All_Functions']) {
        		$scope.projectTeams['All_Functions'] = {
        			'Functions': [{
        					Function: ''
        				}
        			]
        		}
        	}
        	if (!$scope.projectTeams['All_Functions']['Functions']) {
        		$scope.projectTeams['All_Functions']['Functions'] = [{
        				Function: ''
        			}
        		]
        	}

        	if (!$scope.formCustomFields['ORI_MSG_Custom_Fields']['MilestoneDates'])
        		$scope.formCustomFields['ORI_MSG_Custom_Fields']['MilestoneDates'] = {};
        	$scope.milestoneDates = $scope.formCustomFields['ORI_MSG_Custom_Fields']['MilestoneDates'];
        	if (!$scope.formCustomFields['ORI_MSG_Custom_Fields']['PROJECT_FUNDING'])
        		$scope.formCustomFields['ORI_MSG_Custom_Fields']['PROJECT_FUNDING'] = {};
        	$scope.projectFunding = $scope.formCustomFields['ORI_MSG_Custom_Fields']['PROJECT_FUNDING'];

        	!$scope.projectRecord.IBISNo3 && ($scope.projectRecord.IBISNo3 = 'C');
        	!$scope.projectRecord.IBISNo1 && ($scope.projectRecord.IBISNo1 = 'ENV');
        	!$scope.projectRecord.Description && ($scope.projectRecord.Description = "N/A");
        	!$scope.formCustomFields.Exp_Tab && ($scope.formCustomFields.Exp_Tab = "Pre Business Case/ Low Risk Project");
        	!$scope.projectFunding.Actual_Evidence && ($scope.projectFunding.Actual_Evidence = "N/A");
        	!$scope.projectTeams.LDW_CPW_IDB_No && ($scope.projectTeams.LDW_CPW_IDB_No = "N/A");

        	$scope.projFormTitle = $scope.data['myFields']['Asite_System_Data_Read_Only']['_3_Project_Data']['DS_PROJECTNAME'];
        	angular.element('#custFormTD') && angular.element('#custFormTD').width(window.innerWidth - 50 + "px");

        	$timeout(function () {
        		if (!($scope.isPrintView)) {
        			$scope.checkSOPField();
        			/*var oldPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'];
        			var oldSPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'];
        			var oldPRO = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'];
        			var oldPE = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'];*/
        			//Get userId of onloadUser - extracting userId for condition check

        			/*var strProjManager = oldPM;
        			oldPMuserId = getUserId(strProjManager);

        			var strSProjManager = oldSPM;
        			oldSPMuserId = getUserId(strSProjManager);

        			var strProjRecordOwner = oldPRO;
        			oldPROuserId = getUserId(strProjRecordOwner);

        			var strProjExecutive = oldPE;
        			oldPEuserId = getUserId(strProjExecutive);*/
        			var oldUserValues = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Old_Users_Values'];
        			if (oldUserValues != "") {
        				oldUserValues = oldUserValues.split('|');
        				oldPMuserId = oldUserValues[0];
        				oldSPMuserId = oldUserValues[1];
        				oldPROuserId = oldUserValues[2];
        				oldPEuserId = oldUserValues[3];
        			}
        			roleChanged();					
        		}
        	}, 10);

        }

        function On_Form_Load() {
            var strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].toString().trim();
            if (strFormId) {
                update_CurrentActivity();
            }
            var xpnChkPPNode = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group']['PAR_Groups'][1];
            if (!xpnChkPPNode) {
                $scope.setBlankPostParNode();
            }
            var Auto_Deactivate_Actions = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions'];
            if (Auto_Deactivate_Actions && Auto_Deactivate_Actions['Auto_Deactivate_Action_List']) {
                delete $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'];
            }
            if (!Auto_Deactivate_Actions) {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions'] = {};
            }
            $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['DS_ADA_TYPE'] = '0';
            setCWRDetails();
            syncFormStatus();
        }

        function update_CurrentActivity() {
            
            var xpni_CWR_Miles_nodes = $scope.getValueOfOnLoadData("DS_PPMT_GET_CWR_MILESTONES_FOR_CURRENT_ACTIVITY"),
            pickListsValue = null , xpniNodeAllPLists = null,
            xpnLoop = null,
            strSetC_act_to = "",
            str_C_MStone = null,
            stra_C_MStone_dtls = null,
            strCMStone_Dtls = "",
            xpniPList_Values = null;

            xpni_CWR_Miles_nodes = _.filter(xpni_CWR_Miles_nodes , function(node){
                return node.Name != ""
            });
            
            if (xpni_CWR_Miles_nodes.length > 0)
            {
                pickListsValue = $scope.getValueOfOnLoadData("DS_PPMT_GET_PICKLISTS");
                xpniNodeAllPLists = _.filter(pickListsValue , function(node){
                    return node.Value1 == "33"
                })

                if (xpniNodeAllPLists.length != 0)
                {
                    alert("No Current Activity Picklist Found");
                    return;
                }
                for (var i=0; i< xpni_CWR_Miles_nodes.length;i++)
                {
                    xpnLoop = xpni_CWR_Miles_nodes[i];
                    strSetC_act_to = "";
                    str_C_MStone = xpnLoop["Value1"].trim();
                    stra_C_MStone_dtls = str_C_MStone.split('|');
                    strCMStone_Dtls = "";
                    if (stra_C_MStone_dtls.length > 3)
                    {
                        strCMStone_Dtls = stra_C_MStone_dtls[3].trim();
                    }

                    switch (strCMStone_Dtls) {
                    case "Earliest possible start date":
                    case "Handover to NCPMS":
                    case "Initial Assessment Start":
                    case "SOC Delivered":
                    case "SOC Approval":
                    case "Gateway 0":
                    	strSetC_act_to = "G0 - G1";
                    	break;
                    case "GATEWAY 1 (Business Justification)":
                    case "OBC Delivered":
                    case "OBC Approval":
                    	strSetC_act_to = "G1 - G2";
                    	break;
                    case "GATEWAY 2 (Delivery Strategy)":
                    case "FBC Delivered":
                    case "Detailed Design Start":
                    case "Detailed Design Finish":
                    case "FBC Approval":
                    	strSetC_act_to = "G2 - G3";
                    	break;
                    case "GATEWAY 3 (Investment Decision)":
                    case "Contract Award":
                    case "Construction Start":
                    case "Construction Finish":
                    case "Commissioning Start":
                    case "Commissioning Finish":
                    case "Outcome Claimed":
                    	strSetC_act_to = "G3 - G4";
                    	break;
                    case "GATEWAY 4 (Readiness for service)":
                    case "Hand back to Ops Team":
                    case "Defects Complete":
                    	strSetC_act_to = "G4 - G5";
                    	break;
                    case "GATEWAY 5 (Operational Review and Benefits Realisation)":
                    case "GATEWAY 6 (Project Closure)":
                    	strSetC_act_to = "G5 - G6";
                    	break;
                    case "Others":
                    	strSetC_act_to = "";
                    	break;
                    }
                    if (strSetC_act_to.trim() != "")
                    {
                        xpniPList_Values = _.filter(pickListsValue , function(node){
                            return node.Value1 == "39" && node.Value8.indexOf(strSetC_act_to) > -1
                        });
                        if (xpniPList_Values.length > 0)
                        {
                            for(var j=0; j < xpniPList_Values.length ; j++)
                            {
                                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['PROJECT_TEAMS']['Current_Activity'] = xpniPList_Values[j]["Value7"].trim();
                            }
                        }
                    }
                }
            }
        }

        $scope.setBlankPostParNode = function() {
            var strIsActuals = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Actuals_Flag'].toString().trim();
            var strIsActEditable = "1";

            var xpnParType_insert_point = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['All_PAR_Group'];
            var sbParType_xml = '';
            if (!xpnParType_insert_point['PAR_Groups'])
                xpnParType_insert_point['PAR_Groups'] = [];
            xpnParType_insert_point['PAR_Groups'].push({
                "G5_50_Risk_Value": 0,
                "OB_50_Risk_Value": 0,
                "All_Expenditure_Group": {
                    "All_Exp_Types_Group": {
                        "Expenditure_Types": [{
                            "OB_Approval_Value": 0,
                            "Exp_Line_Item_Count": 1,
                            "Expenditure_Type": "",
                            "Expenditure_Detail_Groups": {
                                "Expenditure_Groups": [{
                                    "Act_Sep": 0,
                                    "Act_Mar": 0,
                                    "FCST_Y8": 0,
                                    "FCST_Y9": 0,
                                    "isActual": "",
                                    "Exp_Role": "",
                                    "Land_Purchase": "",
                                    "Act_May": 0,
                                    "Prev_Year_Adj": 0,
                                    "Exp_Line_Item_No": 1,
                                    "FCST_Y10": 0,
                                    "FCST_Nov": 0,
                                    "Compensation": "",
                                    "Exp_Comments": "",
                                    "Act_Nov": 0,
                                    "Exp_Order_No": "",
                                    "FCST_Y11_Y15": 0,
                                    "FCST_Sep": 0,
                                    "FCST_Mar": 0,
                                    "FCST_Y1_Q2": 0,
                                    "FCST_Y1_Q1": 0,
                                    "FCST_May": 0,
                                    "Streamlining_Target": "",
                                    "FCST_Y1_Q4": 0,
                                    "FCST_Y1_Q3": 0,
                                    "Ref_L_Par_Type": "POST-PAR",
                                    "Act_Aug": 0,
                                    "Exp_Supplier_Id": "",
                                    "Act_Oct": 0,
                                    "FCST_Jun": 0,
                                    "FCST_Dec": 0,
                                    "Ref_Exp_Type": "",
                                    "FCST_Jul": 0,
                                    "Exp_Details": "",
                                    "FCST_Feb": 0,
                                    "Act_Apr": 0,
                                    "Salary_Role": "",
                                    "Supplier_Name": "",
                                    "Supplier_Id": "",
                                    "FCST_Jan": 0,
                                    "Act_Jan": 0,
                                    "ThirdParty_Cost": "",
                                    "FCST_Oct": 0,
                                    "isExpRowEditable": 1,
                                    "Framework": "",
                                    "Exp_IBIS_No": "",
                                    "Line_Total": 0,
                                    "FCST_Apr": 0,
                                    "Act_Jun": 0,
                                    "Act_Feb": 0,
                                    "Act_Dec": 0,
                                    "Act_Jul": 0,
                                    "isActEditable": 1,
                                    "FCST_Aug": 0,
                                    "Prev_Year": 0,
                                    "FCST_Y2": 0,
                                    "Oth_ThirdParty_Cost": "",
                                    "FCST_Y3": 0,
                                    "Exp_Framework": "",
                                    "FCST_Y16_Y20": 0,
                                    "FCST_Y6": 0,
                                    "FCST_Y7": 0,
                                    "FCST_Y4": 0,
                                    "FCST_Y5": 0
                                }]
                            },
                            "Ref_PAR_TYPE": "POST-PAR",
                            "G1_Approval_Value": 0,
                            "G2_Approval_Value": 0,
                            "G5_Approval_Value": 0,
                            "G4_Approval_Value": 0,
                            "G3_Approval_Value": 0
                        }]
                    }
                },
                "OB_95_Risk_Value": 0,
                "G5_95_Risk_Value": 0,
                "G4_50_Risk_Value": 0,
                "G4_95_Risk_Value": 0,
                "G3_50_Risk_Value": 0,
                "PAR_TYPE": "POST-PAR",
                "G3_95_Risk_Value": 0,
                "G2_50_Risk_Value": 0,
                "G1_95_Risk_Value": 0,
                "G2_95_Risk_Value": 0,
                "G1_50_Risk_Value": 0
            });
        }

        function setCWRDetails() {
            var xpniXmlAllPMs = $scope.getValueOfOnLoadData('DS_PPMT_GET_CURRENT_PROJECT_MANAGER_NAME');
            if (xpniXmlAllPMs.length) {
                var xpnInsertPoint = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_FUNDING']['All_Funding_Sources']["Funding_Sources"];
                var sbfSouceXml = [];
                if(!(_.isArray(xpnInsertPoint) )){
                    xpnInsertPoint = [ xpnInsertPoint ];
                }
                for (var i = 0; i < xpniXmlAllPMs.length; i++) {
                    sbfSouceXml.push({
                        Funding_Source: xpniXmlAllPMs[i]["Name"].toString().trim()
                    })
                }
                if (sbfSouceXml.length) {
                    for (var i = 0; i < sbfSouceXml.length; i++) {
                        xpnInsertPoint.push(sbfSouceXml[i]);
                    }
                }
            }
        }

        function On_FormEvents_ViewSwitched(view) {
            var strImported = $scope.data['myFields']['isImported'];
            if (strImported != "") {
                $scope.data['myFields']['isImported'] = '';
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Dum_NProject_No'] = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['National_Project_No'];
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Dum_IBIS_Project_No_Filter'] = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['IBIS_Project_No'];
                setFormTitle();
                setProjectManager();
                syncFormStatus();
                setAllFormContents();
            }

            var strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'];
            var strIsDraft = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_ISDRAFT'];
            var srtWorkingUser = $scope.data['myFields']['Asite_System_Data_Read_Only']['_1_User_Data']['DS_WORKINGUSER'];
            if (!$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']) {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group'] = {
                    Auto_Distribute_Users: []
                }
            }
            if (strFormId != "" && strIsDraft == "NO") {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            }
            if (strFormId == "" && srtWorkingUser != "") {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            }
        }

        function setFormTitle() {
            var strProjTitle = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Title'].trim();
            $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'] = strProjTitle;
        }

        function setProjectManager() {
            var strChkProjectManager = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'].toString().trim();
            var straChkPMId = strChkProjectManager.split('#');

            if (strChkProjectManager) {
                var xpniXmlProjectManagers = $scope.getValueOfOnLoadData("DS_PROJUSERS_ROLE");
                xpniXmlProjectManagers = commonApi._.filter(xpniXmlProjectManagers, function(val) {
                    return val.Value.indexOf('Project Manager') > -1;
                });
                if (xpniXmlProjectManagers.length) {
                    for (var i = 0; i < xpniXmlProjectManagers.length; i++) {;
                        var straSplitPM = xpniXmlProjectManagers[i]["Value"].split('|');
                        var straSplitPMId = straSplitPM[2].split('#');

                        if (straSplitPMId[0] && straChkPMId[0] && straSplitPMId[0].trim() == straChkPMId[0].trim()) {
                            $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'] = xpniXmlProjectManagers[i]["Value"].trim();
                            $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_AUTODISTRIBUTE'] = "3";
                            setAutoDistribution("PM");
                            setFormContent3();
                        }
                    }
                }
            }

            var strchkProgrammeManager = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'].toString().trim();
            var straChkProgMId = strchkProgrammeManager.split('#');

            if (strchkProgrammeManager) {
                var xpniXmlProgManagers = $scope.getValueOfOnLoadData("DS_PROJUSERS_ROLE");
                xpniXmlProgManagers = commonApi._.filter(xpniXmlProgManagers, function(val) {
                    return val.Value.indexOf('Programme Manager') > -1;
                });
                if (xpniXmlProgManagers.length) {
                    for (var i = 0; i < xpniXmlProgManagers.length; i++) {
                        var straSplitPM = xpniXmlProgManagers[i]["Value"].split('|');
                        var straSplitPMId = straSplitPM[2].split('#');
                        if (straSplitPMId[0] && straChkProgMId[0] && straSplitPMId[0].Trim() == straChkProgMId[0].Trim()) {
                            $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'] = xpniXmlProgManagers[i]["Value"].trim();
                            $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_AUTODISTRIBUTE'] = "3";
                            setAutoDistribution("PRO");
                            setFormContent3();
                        }
                    }
                }
            }
        }

        function syncFormStatus() {
            var strFormStatus = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Status'].trim();
            var straSplitSelStatus = strFormStatus.split('|');
            if (!straSplitSelStatus.length)
                return;

            var straSelStatus = [];

            if (straSplitSelStatus[3]) {
                straSelStatus = straSplitSelStatus[3].split('(');
                var strRetSelStatus = "";
                if (straSelStatus[0]) {
                    strRetSelStatus = straSelStatus[0].trim();
                }
                var strRetStatus = getFormStatus(strRetSelStatus);
                if (strRetStatus != "-1") {
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strRetStatus;
                } else {
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = '';
                }
            } else {
                $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = '';
            }
        }

        function setAllFormContents() {
            $scope.setFormContent();
            setFormContent3();
            setFormContent2();
            setFormContent1();
        }

        function setFormContent2() {
            var strIBISNumber = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['IBIS_Project_No'].toString().trim();
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT2'] = strIBISNumber;
        }

        function setFormContent1() {
            var strNatProjNumber = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['National_Project_No'].toString().trim();
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = strNatProjNumber;
            $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'] = strNatProjNumber;
        }

        function getFormStatus(strStatus) {
            var xpniXmlAllFormStatus = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
            if (xpniXmlAllFormStatus.length) {
                for (var i = 0; i < xpniXmlAllFormStatus.length; i++) {;
                    var strXmlStatusName = xpniXmlAllFormStatus[i]["Name"].toString().trim();
                    if (strXmlStatusName == strStatus) {
                        return xpniXmlAllFormStatus[i]["Value"].toString().trim();
                    }
                }
            }
            return "-1";
        }

        $scope.Project_Status_Changed = function(newValue) {
            if (!newValue)
                return
            var straSplitSelStatus = newValue.trim().split('|');
            if (!straSplitSelStatus.length)
                return;

            if (straSplitSelStatus[3]) {
                var straSelStatus = straSplitSelStatus[3].split('(');
                var strRetSelStatus = "";
                if (straSelStatus[0]) {
                    strRetSelStatus = straSelStatus[0].trim();
                }
                var strRetStatus = getFormStatus(strRetSelStatus);
                if (strRetStatus != "-1") {
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strRetStatus;
                } else {
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = '';
                }
            } else {
                $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = '';
            }
            $scope.setFormContent();
        }

        $scope.setFormContent = function() {
            var strProjectPlan = "";
            var strStrategy = "";
            var strAssetType = "";
            var strProjectStatus = "";
            var strExp_Tab = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['Exp_Tab'].trim();

            var straSplitProjectPlan = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Plan'];
            if (straSplitProjectPlan && straSplitProjectPlan.split('|')[3]) {
                strProjectPlan = straSplitProjectPlan.split('|')[3].trim();
            }
            var straSplitStrategy = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Strategy'];
            if (straSplitStrategy && straSplitStrategy.split('|')[3]) {
                strStrategy = straSplitStrategy.split('|')[3].trim();
            }

            var straSplitAssetType = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Asset_Type'];
            if (straSplitAssetType && straSplitAssetType.split('|')[3]) {
                strAssetType = straSplitAssetType.split('|')[3].trim();
            }

            var straSplitProjectStatus = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Status'];
            if (straSplitProjectStatus && straSplitProjectStatus.split('|')[3]) {
                strProjectStatus = straSplitProjectStatus.split('|')[3].trim();
            }

            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT'] = strProjectPlan + "|" + strStrategy + "|" + strAssetType + "|" + strProjectStatus + "|" + strExp_Tab;
        }

        function setAutoDistribution(strUserType) {
        	switch (strUserType) {
        	case "PM":
        		var strPM_Edited = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PM_Edited'].toString().trim();
        		if (strPM_Edited == "1") {
        			var strPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'];
        			if (strPM) {
        				var straSplitPM = strPM.split('|');
        				setAutoDistributeUser(straSplitPM[2].trim());
        			}
        		}
        		break;
        	case "SPM":
        		var strSPM_Edited = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['SPM_Edited'].toString().trim();
        		if (strSPM_Edited == "1") {
        			var strSPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'];
        			if (strSPM) {
        				var straSplitPM = strSPM.split('|');
        				setAutoDistributeUser(straSplitPM[2].trim());
        			}
        		}
        		break;
        	case "PRO":
        		var strPRO_Edited = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PRO_Edited'].toString().trim();
        		if (strPRO_Edited == "1") {
        			var strPRO = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'];
        			if (strPRO) {
        				var straSplitPRO = strPRO.split('|');
        				setAutoDistributeUser(straSplitPRO[2].trim());
        			}
        		}
        		break;
        	case "PE":
        		var strPE_Edited = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PE_Edited'].toString().trim();
        		if (strPE_Edited == "1") {
        			var strPE = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'];
        			if (strPE) {
        				var straSplitPE = strPE.split('|');
        				setAutoDistributeUser(straSplitPE[2].trim());
        			}
        		}
        		break;
        	case "UGRP":
        		var xpniXmlAllGroupUsers = $scope.getValueOfOnLoadData("DS_USER_GROUP_USERS");
        		if (xpniXmlAllGroupUsers.length) {
        			for (var i = 0; i < xpniXmlAllGroupUsers.length; i++) {
        				var strSelUser = xpniXmlAllGroupUsers[i]["Value"].toString().trim();
        				setAutoDistributeUser(strSelUser);
        			}
        		}
        		break;
        	}

        }

        function setAutoDistributeUser(strselectedUser) {
            var strInstAction = "7#For Information";
            var checkUser = checkDistributionUser(strselectedUser);
            if (strselectedUser && checkUser == "NO") {
                if (!$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users']) {
                    $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                }
                var xpnInsertPointUsers = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'];
                xpnInsertPointUsers.push({
                    DS_PROJDISTUSERS: strselectedUser,
                    DS_FORMACTIONS: strInstAction,
                    DS_ACTIONDUEDATE: ''
                });
            }
        }

        function checkDistributionUser(strSelectedUser) {
            var strCheckUser = "NO";
            var xpniAlreadyAddedNode = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'];
            if (xpniAlreadyAddedNode.length) {
                for (var i = 0; i < xpniAlreadyAddedNode.length; i++) {
                    var strSelUser = xpniAlreadyAddedNode[i]['DS_PROJDISTUSERS'].toString().trim();
                    if (strSelUser == strSelectedUser)
                        strCheckUser = "YES";
                }
            }
            return strCheckUser;
        }

        function setFormContent3() {
            var strProjectManagerId = "",
                strProjectROId = "";
            if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content']) {
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'] = '';
            }
            if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content']) {
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'] = '';
            }

            var strPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'].toString().trim();
            var strPRO = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'].toString().trim();
            var straSplitPMID = strPM.split('|');
            if (straSplitPMID.length && strPM && straSplitPMID[2]) {
                var straSplitProjMgr = straSplitPMID[2].split('#');
                strProjectManagerId = straSplitProjMgr[0].trim();
            }

            var straSplitPROID = strPRO.split('|');
            if (straSplitPROID.length && strPRO && straSplitPROID[2] != "") {
                var straSplitProjRecOwner = straSplitPROID[2].split('#');
                strProjectROId = straSplitProjRecOwner[0].trim();
            }
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT3'] = strProjectManagerId + "|" + strProjectROId;
        }

        function getCwrs(forRemoval, straGetRUser_ID) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_PPMT_GET_PRS_CWRS",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_PPMT_GET_PRS_CWRS",
                        "fieldValue": $scope.projectRecord.Project_Manager.content + ',' + $scope.projectRecord.Project_Record_Owner.content
                    }]
                }
            };
            $scope.getCallbackData(form).then(function(response) {
                if (response.data) {
                    DS_PPMT_GET_PRS_CWRS = JSON.parse(response.data['DS_PPMT_GET_PRS_CWRS']);
                    if (DS_PPMT_GET_PRS_CWRS.Items && DS_PPMT_GET_PRS_CWRS.Items.Item && DS_PPMT_GET_PRS_CWRS.Items.Item.length && DS_PPMT_GET_PRS_CWRS.Items.Item[0].Value != '') {
                        if (forRemoval) {
                            //removeUsers(DS_PPMT_GET_PRS_CWRS.Items.Item, straGetRUser_ID)
                        } else {
                            Set_Distribution_on_CWRs(DS_PPMT_GET_PRS_CWRS.Items.Item);
                        }
                    }
                }
            });
        }

        function Set_Distribution_on_CWRs(xpniCWR_List) {
            $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['Auto_Distribution_Actions']['Auto_Distribute_Action'] = [];
            $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['Auto_Distribution_Actions']['DS_AUTODISTRIBUTE_OTHERS'] = "1";

            var xpnInsertPoint = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['Auto_Distribution_Actions']['Auto_Distribute_Action'];

            var strPM_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PM_Edited'];
            var strSPM_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['SPM_Edited'];
            var strPRO_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PRO_Edited'];
            var strPE_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PE_Edited'];
            var strActDT = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['CWR_ActDueDate'];

            for (var i = 0; i < xpniCWR_List.length; i++) {
                var strTmp_CWR = xpniCWR_List[i]["Value1"].toString().trim();
                var strPMId = "";
                var strSPMId = "";
                var strPROId = "";
                var strPEId = "";
                if (strPM_edited_Flg == "1") {
                    var strEdited_PM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'];
                    if (strEdited_PM) {
                    	var straSplitPM = strEdited_PM.split('|');
                    	var straSplitPMId = straSplitPM[2].split('#');
                    	strPMId = straSplitPMId[0].trim();
                    }
                }
                if (strSPM_edited_Flg == "1") {
                    var strEdited_SPM = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'];
                    if (strEdited_SPM) {
                    	var straSplitSPM = strEdited_SPM.split('|');
                    	var straSplitSPMId = straSplitSPM[2].split('#');
                    	strSPMId = straSplitSPMId[0].trim();
                    }
                }
                if (strPRO_edited_Flg == "1") {
                    var strEdited_PRO = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'];
                    if (strEdited_PRO) {
                    	var straSplitPRO = strEdited_PRO.split('|');
                    	var straSplitPROId = straSplitPRO[2].split('#');
                    	strPROId = straSplitPROId[0].trim();
                    }
                }
                if (strPE_edited_Flg == "1") {
                    var strEdited_PE = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'];
                    if (strEdited_PE) {
                    	var straSplitPE = strEdited_PE.split('|');
                    	var straSplitPEId = straSplitPE[2].split('#');
                    	strPEId = straSplitPEId[0].trim();
                    }
                }
                if (strPM_edited_Flg != "0") {
                    xpnInsertPoint.push({
                        DS_ADO_TYPE: 3,
                        DS_ADO_FORM: strTmp_CWR,
                        DS_ADO_MSG_TYPE: "ORI",
                        DS_ADO_FORMACTIONS: "32#Info - Publisher",
                        DS_ADO_PROJDISTGROUPS: '',
                        DS_ADO_ACTIONDUEDATE: strActDT,
                        DS_ADO_PROJDISTUSERS: strPMId
                    });
                }
                if (strSPM_edited_Flg != "0") {
                    xpnInsertPoint.push({
                        DS_ADO_TYPE: 3,
                        DS_ADO_FORM: strTmp_CWR,
                        DS_ADO_MSG_TYPE: "ORI",
                        DS_ADO_FORMACTIONS: "32#Info - Publisher",
                        DS_ADO_PROJDISTGROUPS: '',
                        DS_ADO_ACTIONDUEDATE: strActDT,
                        DS_ADO_PROJDISTUSERS: strSPMId
                    });
                }
                if (strPE_edited_Flg != "0") {
                    xpnInsertPoint.push({
                        DS_ADO_TYPE: 3,
                        DS_ADO_FORM: strTmp_CWR,
                        DS_ADO_MSG_TYPE: "ORI",
                        DS_ADO_FORMACTIONS: "32#Info - Publisher",
                        DS_ADO_PROJDISTGROUPS: '',
                        DS_ADO_ACTIONDUEDATE: strActDT,
                        DS_ADO_PROJDISTUSERS: strPEId
                    });
                }
                if (strPRO_edited_Flg != "0") {
                    if (strPRO_edited_Flg == 1 && xpniCWR_List[i]['Name'].indexOf('DRAFT') != -1)
                        continue;
                    xpnInsertPoint.push({
                        DS_ADO_TYPE: 3,
                        DS_ADO_FORM: strTmp_CWR,
                        DS_ADO_MSG_TYPE: "ORI",
                        DS_ADO_FORMACTIONS: "32#Info - Publisher",
                        DS_ADO_PROJDISTGROUPS: '',
                        DS_ADO_ACTIONDUEDATE: strActDT,
                        DS_ADO_PROJDISTUSERS: strPROId
                    });
                }
            }
        }

        /*function RemoveOld_UserAccess(strRemoveUser, strUserType) {
        	var straSplitRUser = strRemoveUser.split('#');
        	var straGetRUser_ID = straSplitRUser[0].split('|');
        	if (straGetRUser_ID[2].trim() == '')
        		return;

        	var strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].toString().trim();

        	var strProjManager = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'];
        	var strProjManagerID = getUserId(strProjManager);

        	var strSProjManager = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'];
        	var strSProjManagerID = getUserId(strSProjManager);

        	var strProjRecordOwner = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'];
        	var strProjRecordOwnerID = getUserId(strProjRecordOwner);

        	var strProjExecutive = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'];
        	var strProjExecutiveID = getUserId(strProjExecutive);

        	$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['DS_ADA_TYPE'] = "1";

        	if (!$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'])
        		$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'] = [];

        	var xpnInsertPoint = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'];

        	if (straGetRUser_ID[2].trim() != strProjManagerID && straGetRUser_ID[2].trim() != strProjRecordOwnerID && straGetRUser_ID[2].trim() != strProjExecutiveID && straGetRUser_ID[2].trim() != strSProjManagerID) {
        		xpnInsertPoint.push({
        			DS_ADA_USERID: straGetRUser_ID[2].trim(),
        			DS_ADA_Forms: strFormId,
        			DS_ADA_Actions: '',
        			DS_ACTION_REMARKS: "Access Removed",
        			DS_ADA_MSGTYPE: 'ORI'
        		})
        	}

        	if ($scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'].length) {
        		var strDAUserID = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'][0]['DS_ADA_USERID'];
        		if (strDAUserID == strProjManagerID || strDAUserID == strProjRecordOwnerID || strDAUserID == strProjExecutiveID || strDAUserID == strSProjManagerID) {
        			$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'] = [];
        		}
        	}

        	getCwrs(true, straGetRUser_ID);
        }*/

        /*function removeUsers(xpniCWR_List, straGetRUser_ID) {
            var strPM_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PM_Edited'];
            var strSPM_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['SPM_Edited'];
            var strPRO_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PRO_Edited'];
            var strPE_edited_Flg = $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PE_Edited'];
            if (!strPM_edited_Flg || !strPE_edited_Flg || !strPRO_edited_Flg || !strSPM_edited_Flg)
                return;
            var xpnInsertPoint = $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'] || [];

            for (var i = 0; i < xpniCWR_List.length; i++) {
                var strTmp_CWR = xpniCWR_List[i]["Value1"].toString().trim();
                xpnInsertPoint.push({
                    DS_ADA_USERID: straGetRUser_ID,
                    DS_ADA_Forms: strTmp_CWR,
                    DS_ADA_Actions: '',
                    DS_ACTION_REMARKS: "Access Removed",
                    DS_ADA_MSGTYPE: 'ORI'
                })
            }
			$scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Deactivate_Actions']['Auto_Deactivate_Action_List'] = xpnInsertPoint;
        }*/

        $scope.SetProjectTeam = function() {
            var strFun_Region = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['PROJECT_LOCATION']['Region'].toString().trim();
            var straChktmp_FunReg = strFun_Region.split('|');
            if (straChktmp_FunReg.length && straChktmp_FunReg[1] == "560") {
                var xpniFun_Nodes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['PROJECT_TEAMS']['All_Functions']['Functions'];
                if (xpniFun_Nodes.length) {
                    for (var i = 0; i < xpniFun_Nodes.length; i++) {
                        var strChktmpFunValue = xpniFun_Nodes[i]['Function'].toString().trim();
                        if (strChktmpFunValue) {
                            var straChktmpFunValue = strChktmpFunValue.Split('|');
                            if (straChktmpFunValue.length) {
                                var strValue = "";
                                if (straChktmpFunValue[1].trim() == "1637" || straChktmpFunValue[1].trim() == "337" || straChktmpFunValue[1].trim() == "1638" || straChktmpFunValue[1].trim() == "1639") {
                                    strValue = "ProjectTeamS-E";
                                }
                                $scope.data['myFields']['Asite_System_Data_Read_Only']['_2_Printing_Data']['DS_PRINTEDBY'] = strValue;
                            }
                        }
                    }
                }
            }
        }

        angular.element(document).click(function(e){
            //searchBox
            if(e.target && e.target.className.indexOf('searchBox') > -1){
                return
            }            
            $scope.searchPMPanelFlag = false;
            $scope.searchPEPanelFlag = false;
            $scope.searchPROPanelFlag = false;
            $scope.searchSPMPanelFlag = false;
        });

        /* 
        * This function open search box to search pecklist data in dropdown
        * hideFlag @ to hide and show searchBox
        * resetSearchFld @ to apply filter on search dropdown like search string
        * event @ angular event
        */
        $scope.openSerchBox = function(hideFlag , resetSearchFld, event){
            $scope[ hideFlag ] = true;
            $scope[ resetSearchFld ] = "";
            $timeout(function() {
                angular.element(event.target).next().focus()
            }, 10);
        }


        $scope.catchKeyDown = function(event){
            if(event && event.keyCode == 40 && event.key.indexOf("Down") > -1 ){
                isBlankFlag = {
                    Project_Manager : true,
                    Secondary_PM : true,
                    Project_Record_Owner : true,
                    Project_Executive : true
                }

                angular.element(event.target).next().children().focus();
            }

            if(event && event.keyCode == 27 && event.key == "Escape" ){
                var nextObj = angular.element(event.target).parent().parent();
                nextObj.next().find('input').focus();
                nextObj.trigger('click');
            }
        }

        $scope.catchKeyEnter = function(event , modelName){
            if(event && ( ( event.keyCode == 27 && event.key == "Escape" ) || ( event.keyCode == 13 && event.key == "Enter" ) || ( event.keyCode == 9 && event.key == "Tab" && event.shiftKey == false)) ){
                $scope.setModelValue(modelName);
                angular.element(event.target).trigger('click');
            }
        }

        var isBlankFlag = {
            Project_Manager : false,
            Secondary_PM : false,
            Project_Record_Owner : false,
            Project_Executive : false
        };

        /*$scope.$watch("data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content']", function(newValue, oldValue) {
            if (newValue && newValue != oldValue) {
                
                if(!isBlankFlag.Project_Manager){
                //This scope use to reset search box and hide dropdown
                $scope.search_Project_Manager = "";
                $scope.searchPMPanelFlag = false;
                    isBlankFlag.Project_Manager = false;
                }

                Project_Manager_Changed(newValue, oldValue);
            }else if( oldValue && ( newValue == null || !newValue) ){
                //This fields use in searchBox for reset default value if user only search but not not change value
                isBlankFlag.Project_Manager = true
                if( $scope.data['myFields']['FORM_CUSTOM_FIELDS']){
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'] = oldValue;
                }
            }
        }, true);
        
        $scope.$watch("data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content']", function(newValue, oldValue) {
            if (newValue && newValue != oldValue ) {
                
                if(!isBlankFlag.Secondary_PM){
    	    	$scope.search_Secondary_PM = "";
	        $scope.searchSPMPanelFlag = false;
                    isBlankFlag.Secondary_PM = false;
                }

                SProject_Manager_Changed(newValue, oldValue);
            }else if( oldValue && ( newValue == null || !newValue) ){
                isBlankFlag.Secondary_PM = true
                if( $scope.data['myFields']['FORM_CUSTOM_FIELDS']){
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'] = oldValue
                }
            }
        }, true);        

        $scope.$watch("data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content']", function(newValue, oldValue) {
            if (newValue && newValue != oldValue) {
                
                if(!isBlankFlag.Project_Record_Owner){
                $scope.search_Project_Record_Owner = "";
                $scope.searchPROPanelFlag = false;
                    isBlankFlag.Project_Record_Owner = false;
                }

                Project_Record_Owner_Changed(newValue, oldValue);
            }else if( oldValue && ( newValue == null || !newValue) ){
                isBlankFlag.Project_Record_Owner = true
                if( $scope.data['myFields']['FORM_CUSTOM_FIELDS']){
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'] = oldValue
                }
            }
        }, true);

        $scope.$watch("data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content']", function(newValue, oldValue) {
            if (newValue && newValue != oldValue) {

                if(!isBlankFlag.Project_Executive){
                $scope.search_Project_Executive = "";
                $scope.searchPEPanelFlag = false;
                    isBlankFlag.Project_Executive = false;
                }
                
                Project_Executive_Changed(newValue, oldValue);
            }else if( oldValue && ( newValue == null || !newValue) ){
                isBlankFlag.Project_Executive = true
                if( $scope.data['myFields']['FORM_CUSTOM_FIELDS']){
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'] = oldValue
                }
            }
        }, true);*/


        /*
        * This function used on search dropdown's onchange event
        * purpos of this function to reset blank dropdown value
        * modelVal @ string value passed from UI to user role wise 
        */
        $scope.setModelValue = function(modelVal){
            if (!$scope.projectRecord[modelVal].content) {
            	$scope.projectRecord[modelVal].content = ""
            }
        }

        function roleChanged() {
            $scope.data['myFields']['Asite_System_Data_Read_Write']['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            setAutoDistribution("PM");
            setAutoDistribution("SPM");
            setAutoDistribution("PRO");
            setAutoDistribution("PE");
            setFormContent3();
            getCwrs();
        }

        $scope.Project_Manager_Changed = function () {
        	$scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PM_Edited'] = "1";
        	roleChanged();
        	/*var newUser = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Manager']['content'],
        	strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].trim(),
        	strProjManagerID = getUserId(newUser);
        	if (strFormId) {
        		if (strProjManagerID != oldPMuserId) {
        			getCwrs(true, oldPMuserId);
        		}
        	}*/
        }

        $scope.SProject_Manager_Changed = function () {
        	$scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['SPM_Edited'] = "1";
        	roleChanged();
        	/*var newUser = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Secondary_PM']['content'],
        	strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].trim(),
        	strSProjManagerID = getUserId(newUser);
        	if (strFormId) {
        		if (strSProjManagerID != oldSPMuserId) {
        			getCwrs(true, oldSPMuserId);
        		}
        	}*/
        }

        $scope.Project_Record_Owner_Changed = function () {
        	$scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PRO_Edited'] = "1";
        	roleChanged();
        	/*var newUser = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Record_Owner']['content'],
        	strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].trim(),
        	strProjRecordOwnerID = getUserId(newUser);
        	if (strFormId) {
        		if (strProjRecordOwnerID != oldPROuserId) {
        			getCwrs(true, oldPROuserId);
        		}
        	}*/
        }

        $scope.Project_Executive_Changed = function () {
        	$scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PE_Edited'] = "1";
        	roleChanged();
        	/*var newUser = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['PROJECT_RECORD']['Project_Executive']['content'],
        	strFormId = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'].trim(),
        	strProjExecutiveID = getUserId(newUser);
        	if (strFormId) {
        		if (strProjExecutiveID != oldPEuserId) {
        			getCwrs(true, oldPEuserId);
        		}
        	}*/
        }

        angular.element('#viewFormMainSection').find('.restored').click();

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        On_Form_Load();
        setDefaultData();
        $scope.showProjectNoCreationSection = true;
        $scope.showibisNoCreationSection = true;
        if ($scope.projectRecord.National_Project_No) {
        	var strSystemRoles = $scope.getValueOfOnLoadData("DS_GET_USR_SYS_ROLE");
        	if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] != "") {
        		if ($scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_ISDRAFT'] == "NO") {
        			if (strSystemRoles) {
        				for (var i = 0; i < strSystemRoles.length; i++) {
        					var strTmpSysRoles = strSystemRoles[i]["Value1"].trim();
        					if (strTmpSysRoles == "Asite Sysadmin Role" || strTmpSysRoles == "EA Super Administrators - Kate and Pippa only") {
        						$scope.showProjectNoCreationSection = true;
        					} else {
        						$scope.showProjectNoCreationSection = false;
        					}
        				}
        			}
        		}
        	}
        	On_FormEvents_ViewSwitched();
        	$timeout(function () {
        		$scope.expandTextAreaOnLoad();
        	}, 1000);
        }
        if ($scope.projectRecord.IBIS_Project_No) {
            $scope.showibisNoCreationSection = false;
            $timeout(function() {
                $scope.expandTextAreaOnLoad();
            }, 1000);
        }
        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] != "") {
            if ($scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_ISDRAFT'] == "NO") {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_AU_OTH_FORM'] = 1;
            }
            if ($scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_ISDRAFT'] == "YES") {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PM_Edited'] = "0";
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['SPM_Edited'] = "0";
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PRO_Edited'] = "0";
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['PE_Edited'] = "0";
            }
        }
        $scope.data['myFields']['Asite_System_Data_Read_Write']['AutoDist_on_CWRs']['Auto_Distribution_Actions']['DS_AUTODISTRIBUTE_OTHERS'] = "0";
         
        $scope.update();
    }
	
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	var from_Container = document.querySelectorAll('.form-container')[0];
	var parentController = angular.element(from_Container).scope();
	if (parentController) {
		var obj = parentController.data.myFields.Asite_System_Data_Read_Write.Auto_Deactivate_Actions,
		strFormId = parentController.data.myFields.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMID.trim(),
		newPMUser = parentController.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.PROJECT_RECORD.Project_Manager.content,
		strProjManagerID = newPMUser && getUserId(newPMUser),
		newSPMUser = parentController.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.PROJECT_RECORD.Secondary_PM.content,
		strSProjManagerID = newSPMUser && getUserId(newSPMUser),
		newProjExeUser = parentController.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.PROJECT_RECORD.Project_Executive.content,
		strProjExecutiveID = newProjExeUser && getUserId(newProjExeUser),
		newPROUser = parentController.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.PROJECT_RECORD.Project_Record_Owner.content,
		strProjRecordOwnerID = newPROUser && getUserId(newPROUser),
		objDataReadWrite = parentController.data.myFields.Asite_System_Data_Read_Write,
		strPM_edited_Flg = objDataReadWrite.AutoDist_on_CWRs["PM_Edited"],
		strSPM_edited_Flg = objDataReadWrite.AutoDist_on_CWRs["SPM_Edited"],
		strPRO_edited_Flg = objDataReadWrite.AutoDist_on_CWRs["PRO_Edited"],
		strPE_edited_Flg = objDataReadWrite.AutoDist_on_CWRs["PE_Edited"],
		oldUserValues = [];
		oldUserValues.push(strProjManagerID);
		oldUserValues.push(strSProjManagerID);
		oldUserValues.push(strProjRecordOwnerID);
		oldUserValues.push(strProjExecutiveID);
		oldUserValues = oldUserValues.join('|');
		parentController.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.Old_Users_Values = oldUserValues;		
		if (strFormId != "") {
			obj.DS_ADA_TYPE = "1";

			if (!obj.Auto_Deactivate_Action_List) {
				obj.Auto_Deactivate_Action_List = [];
			}

			var xpnInsertPoint = obj.Auto_Deactivate_Action_List;

			if (strProjManagerID != "" && oldPMuserId != strProjManagerID && strPM_edited_Flg) {
				insertNodeToDeactivationListPRS(xpnInsertPoint, oldPMuserId, strFormId);
				removeUsersActionFromCWR(oldPMuserId, xpnInsertPoint);
			}
			if (strSProjManagerID == "" || (strSProjManagerID != "" && oldSPMuserId != strSProjManagerID && strSPM_edited_Flg)) {
				insertNodeToDeactivationListPRS(xpnInsertPoint, oldSPMuserId, strFormId);
				removeUsersActionFromCWR(oldSPMuserId, xpnInsertPoint);
			}
			if (strProjRecordOwnerID != "" && oldPROuserId != strProjRecordOwnerID && strPRO_edited_Flg) {
				insertNodeToDeactivationListPRS(xpnInsertPoint, oldPROuserId, strFormId);
				removeUsersActionFromCWR(oldPROuserId, xpnInsertPoint);
			}
			if (strProjExecutiveID == "" || (strProjExecutiveID != "" && oldPEuserId != strProjExecutiveID && strPE_edited_Flg)) {
				insertNodeToDeactivationListPRS(xpnInsertPoint, oldPEuserId, strFormId);
				removeUsersActionFromCWR(oldPEuserId, xpnInsertPoint);
			}

			var strDAUserID = obj.Auto_Deactivate_Action_List[0] && obj.Auto_Deactivate_Action_List[0]['DS_ADA_USERID'];
			if (obj.Auto_Deactivate_Action_List.length && strDAUserID != "") {
				if (strDAUserID == strProjManagerID || strDAUserID == strProjRecordOwnerID || strDAUserID == strProjExecutiveID || strDAUserID == strSProjManagerID) {
					obj.Auto_Deactivate_Action_List = [];
				}
			}
		}
	}
}

function insertNodeToDeactivationListPRS(xpnInsertPoint, oldUserId, strFormId) {
	if (oldUserId != "") {
		xpnInsertPoint.push({
			DS_ADA_USERID: oldUserId,
			DS_ADA_Forms: strFormId,
			DS_ADA_Actions: '',
			DS_ACTION_REMARKS: "Access Removed",
			DS_ADA_MSGTYPE: 'ORI'
		})
	}
}

function getUserId(tempStr) {
	var tempId = '';
	if (tempStr) {
		var strSplit = tempStr.split('|');
		var strTemp_ID = strSplit[2].split('#');
		tempId = strTemp_ID[0].trim();
	}
	return tempId;
}

function removeUsersActionFromCWR(oldUserID, xpnInsertPoint) {
	if (DS_PPMT_GET_PRS_CWRS && DS_PPMT_GET_PRS_CWRS.Items && DS_PPMT_GET_PRS_CWRS.Items.Item && DS_PPMT_GET_PRS_CWRS.Items.Item.length && DS_PPMT_GET_PRS_CWRS.Items.Item[0].Value != '') {
		var xpniCWR_List = DS_PPMT_GET_PRS_CWRS.Items.Item;
		for (var i = 0; i < xpniCWR_List.length; i++) {
			var strTmp_CWR = xpniCWR_List[i]["Value1"].toString().trim();
			if (oldUserID != "") {
				xpnInsertPoint.push({
					DS_ADA_USERID: oldUserID,
					DS_ADA_Forms: strTmp_CWR,
					DS_ADA_Actions: '',
					DS_ACTION_REMARKS: "Access Removed",
					DS_ADA_MSGTYPE: 'ORI'
				})
			}
		}
	}
}