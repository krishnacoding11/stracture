/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout, Notification) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();                   
                    isfunctionToCall && setInlineAttachmentNodes();
                    // remove loaded class after modal's get opened.
                    $element.addClass('loaded');
                }, 150);
            }
        });

        var currServerDate = '';
        $scope.getServerTime(function (serverDate) {
            currServerDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;

        var RESTRICT_CHAR_MSG = "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #";

        var STATIC_OBJ_DATA = {
            DS_Stoppage_Detail: {
                isSelected: false,
                Stoppage: "",
                Stoppage_Reason: "",
                Stoppage_Comments: "",
                Stoppage_Attachments: [{
                    Stoppage_Attachment: ""
                }]
            },
            DS_Visitor_Details: {
                VD_isSelected: false,
                Visitor_Organisation: "",
                Visit_Reason: "",
                Notices_Issued: "",
                Notice_Type: "",
                Notice_Attachment: "",
                Notice_Comments: "",
                DS_VGroup: {
                    DS_NIssuedGroup: ""
                }
            },
            DS_Plant_Details: {
                Plant_on_Site: "",
                Owned_or_Subcontractor: "",
                Activity_Comments_Charges: "",
                Plant_No: "",
                DS_isPlantNew: ""
            },
            DS_Employee_Details: {
                ED_isSelected: false,
                Employee_No: "",
                Employee_Hours: "",
                Employee_Duties: "",
                Employee_Name: "",
                DS_Employee_Total: ""
            },
            DS_Worker_Details: {
                TD_isSelected: false,
                Trade_on_site: "",
                Trade_Worker_No: "",
                Worker_Hours: "",
                Worker_Duties: "",
                DS_Worker_Total: "",
                DS_isNew: ""
            },
            DS_HSE_Incidents: {
                HSEI_isCreated: 0,
                HSEI_isSelected: false,
                Incident_Type: "",
                Trade_Attributed: "",
                Body_Location: "",
                Injury_Classification: "",
                Injury_Type: "",
                Task_Performed: "",
                Incident_No: "",
                DS_HSE_Group: ""
            },
            DS_Hazards: {
                HZ_isCreated: 0,
                HZ_isSelected: false,
                Hazard_No: "",
                Hazard_Reported_By: "",
                Hazard_Trade: "",
                Hazard_Category: ""
            },
            DS_Complaints: {
                Com_isCreated: 0,
                Com_isSelected: false,
                Complaint_No: "",
                Complaint_Source: "",
                Complaint_Type: "",
                Other_Complaint_Details: "",
                Complaint: "",
                DS_Complaint_Group: "",
                Complainant_Attachment: ""
            },
            DS_Waste_Tracking: {
                Wst_isSelected: false,
                Waste_Tracking_No: "",
                Waste_date: "",
                Waste_IandE: "",
                Waste_DescOfMaterial: "",
                Waste_Classification: "",
                Waste_Volume: "",
                Waste_Weight: "",
                Waste_DisposalSrcLoc: "",
                WasteAndMaterialPickList: []
            },
            DS_Inductions: {
                Ind_isSelected: "false",
                Induction_No: "",
                Total_Inducted: ""
            },
            DS_Injury_Details: {
                Name: '',
                Gender: '',
                Date_of_Birth: '',
                Occupation: '',
                Employer: '',
                Supervisor: '',
                First_aid_provided: '',
                First_aid_by: '',
                First_aid_details: '',
                Injury_Outcome: '',
                Medical_aid_provided: '',
                Medical_aid_by: '',
                Medical_aid_details: '',
                Body_Location: '',
                Body_Location_Side: '',
                Nature_of_Injury: '',
                Mechanics_of_Injury: '',
                Agency_of_Injury: ''
            },
            DS_All_Witnesses: {
                Witness_Name: '',
                Witness_Contact_details: ""
            },
            Incident_Report: {
                Incident_FORMTITLE: '',
                showTable: false,
                hasDateSelected: false,
                DS_Incident_Date: '',
                Reported_To: '',
                Incident_Time: '',
                Location: '',
                DS_Date_Reported: '',
                Task: '',
                Time_Reported: '',
                Primary_Category: '',
                Secondary_Category: '',
                Days_Lost: '',
                Incident_Attachment: '',
                DS_Injury_Details: [{
                    Name: '',
                    Gender: '',
                    Date_of_Birth: '',
                    Occupation: '',
                    Employer: '',
                    Supervisor: '',
                    First_aid_provided: '',
                    First_aid_by: '',
                    First_aid_details: '',
                    Injury_Outcome: '',
                    Medical_aid_provided: '',
                    Medical_aid_by: '',
                    Medical_aid_details: '',
                    Body_Location: '',
                    Body_Location_Side: '',
                    Nature_of_Injury: '',
                    Mechanics_of_Injury: '',
                    Agency_of_Injury: ''
                }],
                DS_Initial_Classification: '',
                Description: '',
                Witness: '',
                DS_All_Witnesses: [{
                    Witness_Name: '',
                    Witness_Contact_details: ""
                }],
                Hazard_Identified_PRM_Plan: '',
                Hazard_Identified_SWMS: '',
                People_Trained: '',
                SWMS_Followed: '',
                People_Instructed: '',
                Induction_Completed: '',
                Immidiate_Actions: '',
                Incident_Attachment_JSEA: ''
            },
            ACF_02_FORM: {
                ACF_02_CREATED_BY: "",
                ACF_02_ORI_USERREF: "",
                ACF_02_ORI_FORMTITLE: "",
                ACF_02_DS_FORMTITLE: "",
                ACF_02_DS_ALL_FORMSTATUS: "",
                ACF_02_DS_Incident_Date: "",
                ACF_02_Reported_To: "",
                ACF_02_DS_AUTODISTRIBUTE: "",
                ACF_02_Incident_Time: "",
                ACF_02_Location: "",
                ACF_02_DS_Date_Reported: "",
                ACF_02_Date_Reported:"",
                ACF_02_Task: "",
                ACF_02_Time_Reported: "",
                ACF_02_Primary_Category: "",
                ACF_02_Secondary_Category: "",
                ACF_02_Days_Lost: "",
                ACF_02_DS_Initial_Classification: "",
                ACF_02_Description: "",
                ACF_02_Witness: "",
                ACF_02_Hazard_Identified_PRM_Plan: "",
                ACF_02_Hazard_Identified_SWMS: "",
                ACF_02_People_Trained: "",
                ACF_02_SWMS_Followed: "",
                ACF_02_People_Instructed: "",
                ACF_02_Induction_Completed: "",
                ACF_02_Immidiate_Actions: "",
                ACF_02_Incident_Attachment: "",
                ACF_02_Incident_Attachment_JSEA: "",
                ACF_02_DS_FORMCONTENT1: "<<DS_Form_ID>>",
                ACF_02_REPEATING_VALUES: {
                    ACF_02_DS_Witness_Group: {
                        ACF_02_DS_All_Witnesses: [{
                            ACF_02_Witness_Name: "",
                            ACF_02_Witness_Contact_details: ""
                        }]
                    },
                    ACF_02_DS_Injury_Group: {
                        ACF_02_DS_Injury_Details: [{
                            ACF_02_Name: "",
                            ACF_02_Gender: "",
                            ACF_02_Date_of_Birth: "",
                            ACF_02_Occupation: "",
                            ACF_02_Employer: "",
                            ACF_02_Supervisor: "",
                            ACF_02_First_aid_provided: "",
                            ACF_02_First_aid_by: "",
                            ACF_02_First_aid_details: "",
                            ACF_02_Injury_Outcome: "",
                            ACF_02_Medical_aid_provided: "",
                            ACF_02_Medical_aid_by: "",
                            ACF_02_Medical_aid_details: "",
                            ACF_02_Body_Location: "",
                            ACF_02_Body_Location_Side: "",
                            ACF_02_Nature_of_Injury: "",
                            ACF_02_Mechanics_of_Injury: "",
                            ACF_02_Agency_of_Injury: ""
                        }]
                    },
                    ACF_02_DS_AutoDistribute_User_Group: {
                        ACF_02_DS_AutoDistribute_Users: [{
                            ACF_02_DS_PROJDISTUSERS: "",
                            ACF_02_DS_FORMACTIONS: "",
                            ACF_02_DS_ACTIONDUEDATE: ""
                        }]
                    }
                }
            },
            Hazard_Report: {
                Hazard_FORMTITLE: '',
                DS_Date_Reported: '',
                Company: '',
                Time_Reported: '',
                Trade: '',
                Location: '',
                Category: '',
                Completed: '',
                Reported_By: '',
                DS_Action_Completed: ''
            },
            ACF_03_FORM: {
                ACF_03_ORI_FORMTITLE: "",
                ACF_03_CREATED_BY: "",
                ACF_03_DS_AUTODISTRIBUTE: "",
                ACF_03_DS_ALL_FORMSTATUS: "",
                ACF_03_DS_FORMTITLE: "",
                ACF_03_DS_Date_Reported: "",
                ACF_03_Date_Reported:"",
                ACF_03_Company: "",
                ACF_03_Time_Reported: "",
                ACF_03_Trade: "",
                ACF_03_Location: "",
                ACF_03_Category: "",
                ACF_03_Completed: "",
                ACF_03_Reported_By: "",
                ACF_03_DS_Action_Completed: "",
                ACF_03_DS_FORMCONTENT1: "<<DS_Form_ID>>",
                ACF_03_REPEATING_VALUES: {
                    ACF_03_DS_AutoDistribute_User_Group: {
                        ACF_03_DS_AutoDistribute_Users: [{
                            ACF_03_DS_PROJDISTUSERS: "",
                            ACF_03_DS_FORMACTIONS: "",
                            ACF_03_DS_ACTIONDUEDATE: ""
                        }]
                    }
                }
            },
            Complaint: {
                Complaint_FORMTITLE: '',
                DS_Date_Reported: '',
                Issue_Category: '',
                Time_Reported: '',
                Complaint_Source: '',
                Location: '',
                Completed: '',
                Raised_By: '',
                Complainant_Name: '',
                Complainant_Phone_No: '',
                Complainant_Address: '',
                Complainant_Attachment: '',
                DS_Action_Completed: '',
                Complainant_Action: ''
            },
            Stoppage_Attachments: {
                Stoppage_Attachment: ""
            },
            Environmental_Attachments: {
                Environmental_Attachment: ""
            },
            General_Attachments: {
                General_Attachment: ""
            },
            ACF_04_FORM: {
                ACF_04_ORI_FORMTITLE: "",
                ACF_04_CREATED_BY: "",
                ACF_04_DS_AUTODISTRIBUTE: "",
                ACF_04_DS_ALL_FORMSTATUS: "",
                ACF_04_DS_FORMTITLE: "",
                ACF_04_DS_Date_Reported: "",
                ACF_04_Date_Reported: "",
                ACF_04_Issue_Category: "",
                ACF_04_Time_Reported: "",
                ACF_04_Complaint_Source: "",
                ACF_04_Location: "",
                ACF_04_Completed: "",
                ACF_04_Complainant_Name: "",
                ACF_04_Complainant_Phone_No: "",
                ACF_04_Complainant_Address: "",
                ACF_04_Raised_By: "",
                ACF_04_DS_Action_Completed: "",
                ACF_04_DS_FORMCONTENT1: "<<DS_Form_ID>>",
                ACF_04_REPEATING_VALUES: {
                    ACF_04_DS_AutoDistribute_User_Group: {
                        ACF_04_DS_AutoDistribute_Users: [{
                            ACF_04_DS_PROJDISTUSERS: "",
                            ACF_04_DS_FORMACTIONS: "",
                            ACF_04_DS_ACTIONDUEDATE: ""
                        }]
                    }
                }
            },
            AUTOCREATE_FORM_LOOKUP:{
                ACF_CODE:"",
                ACF_LOOKUP_SEQ:""
            },
        };

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.disabledDate = false;
        $scope.requests = {};
        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Incident_Report);

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.tableUtilSettings = {
            DS_Stoppage_Detail: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Stoppage_Detail),
                ADD_NEW_BEFORE_TIP: "Insert before Stoppage Detail",
                ADD_NEW_AFTER_TIP: "Insert after Stoppage Detail",
                deleteAllRowTooltip: "Remove all Stoppage Detail",
                deleteCurrRowMsg: "Remove Stoppage Detail",
                deleteSelectedMsg: "Remove selected Stoppage Detail"
            },
            DS_Visitor_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "VD_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Visitor_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Visitor Record",
                ADD_NEW_AFTER_TIP: "Insert after Visitor Record",
                deleteAllRowTooltip: "Remove all Visitor Records",
                deleteCurrRowMsg: "Remove Visitor Record",
                deleteSelectedMsg: "Remove selected Visitor Record"
            },
            DS_Employee_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "ED_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Employee_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Employee Detail",
                ADD_NEW_AFTER_TIP: "Insert after Employee Detail",
                deleteAllRowTooltip: "Remove all Employee Detail",
                deleteCurrRowMsg: "Remove Employee Detail",
                deleteSelectedMsg: "Remove selected Employee Detail",
                addItemCallBack: employeeCallBackForUtil,
                deleteItemCallBack: employeeCallBackForUtil
            },
            DS_Inductions: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "Ind_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Inductions),
                ADD_NEW_BEFORE_TIP: "Insert before Induction Detail",
                ADD_NEW_AFTER_TIP: "Insert after Induction Detail",
                deleteAllRowTooltip: "Remove all Induction Detail",
                deleteCurrRowMsg: "Remove Induction Detail",
                deleteSelectedMsg: "Remove selected Induction Detail"
            },
            DS_Waste_Tracking: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "Wst_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Waste_Tracking),
                ADD_NEW_BEFORE_TIP: "Insert before Waste and Material Detail",
                ADD_NEW_AFTER_TIP: "Insert after Waste and Material Detail",
                deleteAllRowTooltip: "Remove all Waste and Material Detail",
                deleteCurrRowMsg: "Remove Waste and Material Detail",
                deleteSelectedMsg: "Remove selected Waste and Material Detail"
            },
            DS_HSE_Incidents: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                editRowCallBack: editIncidentModal,
                checkboxModelKey: "HSEI_isSelected",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_HSE_Incidents),
                deleteAllRowTooltip: "Remove all Incidents Detail",
                deleteCurrRowMsg: "Remove Incidents Detail",
                deleteSelectedMsg: "Remove selected Incidents Detail"
            },
            DS_Hazards: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                editRowCallBack: editHazardModal,
                checkboxModelKey: "HZ_isSelected",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Hazards),
                deleteAllRowTooltip: "Remove all Hazard Detail",
                deleteCurrRowMsg: "Remove Hazard Detail",
                deleteSelectedMsg: "Remove selected Hazard Detail"
            },
            DS_Complaints: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                editRowCallBack: editComplaintModal,
                checkboxModelKey: "Com_isSelected",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Complaints),
                deleteAllRowTooltip: "Remove all Complaint Detail",
                deleteCurrRowMsg: "Remove Complaint Detail",
                deleteSelectedMsg: "Remove selected Complaint Detail"
            },
            DS_Worker_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "TD_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Trades_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Trades Onsite Detail",
                ADD_NEW_AFTER_TIP: "Insert after Trades Onsite Detail",
                deleteAllRowTooltip: "Remove all Trades Onsite Detail",
                deleteCurrRowMsg: "Remove Trades Onsite Detail",
                deleteSelectedMsg: "Remove selected Trades Onsite Detail",
            }
        }

        function employeeCallBackForUtil() {
            $timeout(function () {
                addRemoveRowCallBack('DS_Employee_Details');
                $scope.countDirectEmployeeHours();
            });
        }

        function editIncidentModal(rowData) {
            $scope.openModal('incident-report', rowData);
        }

        function editHazardModal(rowData) {
            $scope.openModal('hazard-report', rowData);
        }

        function editComplaintModal(rowData) {
            $scope.openModal('complaint', rowData);
        }
        
        function getInlineAttachmentNodes() {
            var attachmentList = [];            
            for (var key in $scope.oriMsgCustomFields.incidentModalData) {
                if ($scope.oriMsgCustomFields.incidentModalData[key]){
                    attachmentList.push($scope.oriMsgCustomFields.incidentModalData[key].Incident_Attachment);
                    attachmentList.push($scope.oriMsgCustomFields.incidentModalData[key].Incident_Attachment_JSEA);                    
                }
            }

            for (var key in $scope.oriMsgCustomFields.complaintModalData) {
                if ($scope.oriMsgCustomFields.complaintModalData[key]){
                    attachmentList.push($scope.oriMsgCustomFields.complaintModalData[key].Complainant_Attachment);
                }
            }

            return attachmentList;
        }

        var isfunctionToCall = (currentViewName == "ORI_VIEW" && $scope.data.myFields.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMID);
        function setInlineAttachmentNodes() {
            var inlineAttachmentList = getInlineAttachmentNodes(),
                attachMentObj = {};
            for(var i= 0 ; i<inlineAttachmentList.length; i++) {
                attachMentObj = inlineAttachmentList[i];

                if(typeof attachMentObj != 'object') {
                    continue
                }

                $scope.insertAttachmentField({
                    xdName : attachMentObj['@inline'],
                    xdocId : attachMentObj['@inline'].split(':')[0],
                    content : attachMentObj.content
                });
            }
        }

        $scope.DistributionStructure = {
            AutoDist_Id: "",
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.completeActionStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];

        $scope.dsAllStepFields = $scope.formCustomFields["DS_ALL_STEP_FIELDS"];
        $scope.dsStep1Fields = $scope.formCustomFields["DS_STEP1_FIELDS"];
        $scope.dsStep2Fields = $scope.formCustomFields["DS_STEP2_FIELDS"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;

        var dsAllActiveFormStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var dsProjUsersAllRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
        var strIsDraftFWD = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_FWD_MSG;
        var submitFlag = false;
        var isFormEditOri = false;
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');

        $scope.dsProjOrganisations.push({
            Value: "Other",
            Name: "Other"
        });
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';


        //var dsAllFormStatus = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }


        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');

        $scope.dsAllStepFields['DS_Is_Complaint_Required'] = 'Yes';
        $scope.dsAllStepFields['DS_Is_Waste_Tracking_Required'] = 'Yes';
        $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'] = [];
        $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'] = [];
        $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'] = [];

        $scope.solidLiquidArrayForTitle = {
            S: 'Solid (S)',
            L: 'Liquid (L)',
            P: 'Sludge (P)',
            M: 'Mixture (M)'
        };
        var picklistData = [];
        initFormsData();

        var tmpVisitorOrgList = [];
        var tmpIncidentTypelist = [];
        var tmpTradeAttributedlist = [];
        var tmpInjuryTypeList = [];
        var tmpInjuryClassificationList = [];
        var tmpBody_LocationList = [];
        var tmpHazard_CategoryList = [];
        var tmpComplaint_SourceList = [];
        var tmpComplaint_TypeList = [];
        var tmpBody_Location_Sidelist = [];
        var tmpMechanics_of_Injurylist = [];
        var tmpAgency_of_Injurylist = [];
        var tmpTradelist = [];

        for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
            var element = dsAsiConfigurableAttributes[index];

            if (element.Value3 === "Visitor Organisation") {
                tmpVisitorOrgList.push(element);
            } else if (element.Value3 === "Incident_Category") {
                tmpIncidentTypelist.push(element);
            } else if (element.Value3 === "Site Diary Worker List") {
                tmpTradeAttributedlist.push(element);
            } else if (element.Value3 === "Incident_Nature_of_Injury") {
                tmpInjuryTypeList.push(element);
            } else if (element.Value3 === "Incident_Classification") {
                tmpInjuryClassificationList.push(element);
            } else if (element.Value3 === "Incident_Body_Location") {
                tmpBody_LocationList.push(element);
            } else if (element.Value3 === "Hazard_Category") {
                tmpHazard_CategoryList.push(element);
            } else if (element.Value3 === "Complaint Source") {
                tmpComplaint_SourceList.push(element);
            } else if (element.Value3 === "Complaint_Issue_Category") {
                tmpComplaint_TypeList.push(element);
            } else if (element.Value3 === "Incident_Body_Location_Side") {
                tmpBody_Location_Sidelist.push(element);
            } else if (element.Value3 === "Incident_Mechanics_of_Injury") {
                tmpMechanics_of_Injurylist.push(element);
            } else if (element.Value3 === "Incident_Agency_of_Injury") {
                tmpAgency_of_Injurylist.push(element);
            } else if (element.Value3 === "Trade") {
                tmpTradelist.push(element);
            }
        }

        $scope.visitorOrglist = tmpVisitorOrgList;
        $scope.IncidentTypelist = tmpIncidentTypelist;
        $scope.TradeAttributedlist = tmpTradeAttributedlist;
        $scope.InjuryTypeList = tmpInjuryTypeList;
        $scope.InjuryClassificationList = tmpInjuryClassificationList;
        $scope.Body_LocationList = tmpBody_LocationList;
        $scope.Hazard_CategoryList = tmpHazard_CategoryList;
        $scope.Complaint_SourceList = tmpComplaint_SourceList;
        $scope.Complaint_TypeList = tmpComplaint_TypeList;
        $scope.Body_Location_Sidelist = tmpBody_Location_Sidelist;
        $scope.Mechanics_of_Injurylist = tmpMechanics_of_Injurylist;
        $scope.Agency_of_Injurylist = tmpAgency_of_Injurylist;
        $scope.Tradelist = tmpTradelist;

        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] == '') {

            $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'] = [];
            $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'] = [];
            $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'] = [];

            showAllPlants();
            showAllWorkerDetails();
        }

        $scope.dsPydDsdChkData = [];
        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] && currentViewName == 'ORI_PRINT_VIEW') {
            $scope.dsPydDsdChkData = $scope.getValueOfOnLoadData('DS_PYD_DSD_CHK_GET_ALL_REGSTR_DTL');
        }

        addRemoveRowCallBack('DS_Employee_Details');
        /***** Initialize db fields ******/


        $scope.update();

        // Load Plant Details data from Custom Attributes
        function showAllPlants() {
            $scope.dsStep1Fields['DS_Plant_Group']['DS_Plant_Details'] = [];
            var strPlantNameCategory = $scope.dsStep1Fields['DS_Plant_Attribute_Name'];
            strPlantNameCategory = strPlantNameCategory && strPlantNameCategory.trim();

            var dataPlantDetails = commonApi._.filter(dsAsiConfigurableAttributes, function (element) {
                return element.Value3 === strPlantNameCategory
            });

            for (var index = 0; index < dataPlantDetails.length; index++) {
                var element = dataPlantDetails[index];
                var tmpNomde = angular.copy(STATIC_OBJ_DATA.DS_Plant_Details);
                tmpNomde.Plant_on_Site = element.Value8;
                tmpNomde.DS_isPlantNew = 'No';

                $scope.dsStep1Fields['DS_Plant_Group']['DS_Plant_Details'].push(tmpNomde);
            }
        }

        function initFormsData() {
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_DB_INSERT = 'false';
            if (currentViewName == "ORI_VIEW" && $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] != '' && $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT == 'NO') {
                if ($scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT_EDITORI == 'NO') {
                    isFormEditOri = true;
                    setEditOriData();
                    setLookupData();
                } else {
                    $scope.disabledDate = true;
                }
            } else if (currentViewName == "ORI_VIEW" && $scope.dsStep1Fields['Date_Created'] !== "" && $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT == 'YES') {
               dateCreatedOnChange(false, false);
            }
            if (currentViewName == "ORI_VIEW") {
                $scope.strCanReply = "";
                setNumericiData();

                if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                    $scope.strCanReply = "yes";
                }
                if ($scope.strFormId == "" && $scope.strIsDraft == "NO") {
                    $scope.dsStep1Fields.DSI_SiteDiary_Org = dsWorkingUserId;
                }
                if ($scope.strFormId != "" && $scope.strIsDraft == "NO" && strIsDraftFWD == "NO") {
                    $scope.dsStep1Fields.Status = "";
                    $scope.dsStep1Fields.Approved_Comments = "";
                }
                if ($scope.strFormId != "" && $scope.strIsDraft == "NO") {
                    var userid = dsWorkingUserId;

                    var actionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                        return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(userid) != -1
                    });
                    if (actionData && actionData.length) {
                        $scope.strCanReply = "yes";
                    }
                }
            }
            $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['DS_AUTOCREATE_FORM'] = '';

            delete $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_01_FORM'];
            
            fetchPicklistData();
            
        }

        $scope.wamPicklistChange = function (item, currRow) {

            currRow['Waste_Classification'] = "";

            for (var i = 0; i < picklistData.length; i++) {
                if (picklistData[i].Value5 == item.displayValue) {
                    currRow['waste_classificationList'] = picklistData[i].Name.split(',');
                }
            }

        }
        $scope.isDisabled = function(strVal) {
            return strVal === $scope.DS_FORMSTATUS
        };

        function fetchPicklistData() {
            picklistData = $scope.getValueOfOnLoadData('DS_PYD_GET_SITE_DIARY_PICKLIST');
            var tmpData = [];
            var tmpGroupData = [];

            for (var i = 0; i < picklistData.length; i++) {
                if (picklistData[i].Value3 == 0) {
                    tmpGroupData.push({
                        name: picklistData[i].Value5,
                        id: picklistData[i].Value2
                    });
                }
            }

            var tempOptionData = [];
            for (var k = 0; k < tmpGroupData.length; k++) {
                var tmpData = [];
                for (var i = 0; i < picklistData.length; i++) {
                    if (tmpGroupData[k].id == picklistData[i].Value3) {
                        tmpData.push({
                            displayValue: picklistData[i].Value5,
                            modelValue: picklistData[i].Value5,
                            checked: false
                        });
                    }
                }

                tempOptionData.push({
                    optlabel: tmpGroupData[k].name,
                    options: tmpData
                });
            }

            STATIC_OBJ_DATA.DS_Waste_Tracking['WasteAndMaterialPickList'] = angular.copy(tempOptionData);

            $scope.tableUtilSettings.DS_Waste_Tracking.newStaticObject = angular.copy(STATIC_OBJ_DATA.DS_Waste_Tracking);

            addAndRemoveListData($scope.dsStep1Fields['DS_Waste_Tracking_Group']['DS_Waste_Tracking'], 'WasteAndMaterialPickList', tempOptionData, true);
        }

        function addAndRemoveListData(objArray, keyName, keyValue, addRemoveFlag) {
            for (var index = 0; index < objArray.length; index++) {
                var element = objArray[index];
                if (addRemoveFlag) {// True for insert
                    element[keyName] = angular.copy(keyValue);
                }
                else {// false for remove
                    delete element[keyName];
                }
            }
        }
        function clearAction() {
            if (DS_INCOMPLETE_ACTIONS && DS_INCOMPLETE_ACTIONS.length) {
                var actionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                    return val.Name == 'Assign Status';
                });
                if (actionData && actionData.length) {
                    var lstsplit = actionData[0].Value.split('|');
                    if (lstsplit.length > 2) {

                        $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                        $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                        var insertpoint = $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                        var userid = dsWorkingUserId;
                        for (var i = 1; i < lstsplit.length - 1; i++) {
                            if (lstsplit[i] && lstsplit[i] != userid) {
                                var AutocompleteActionStructure = angular.copy($scope.completeActionStructure);
                                AutocompleteActionStructure.DS_MSG_AC_TYPE = "clear";
                                AutocompleteActionStructure.DS_MSG_AC_FORM = AppId;
                                AutocompleteActionStructure.DS_MSG_AC_MSG_TYPE = "ORI001";
                                AutocompleteActionStructure.DS_MSG_AC_USERID = lstsplit[i];
                                AutocompleteActionStructure.DS_MSG_AC_ACTION = "2";
                                AutocompleteActionStructure.DS_MSG_AC_ACTION_REMARKS = "clear actions";
                                insertpoint.push(AutocompleteActionStructure);
                            }
                        }
                    }
                }
            }
        }
        function setRolewiseDistribution(strRole) {

            var strusers = commonApi._.filter(dsProjUsersAllRoles, function (val) {
                return val.Value.toLowerCase().indexOf(strRole.toLowerCase()) != -1
            });
            $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
            if (strusers && strusers.length) {
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter(dsProjDistUsers, function (val) {
                        return val.Value.indexOf(strUserId) != -1
                    });

                    if (strdisuser) {
                        if (strRole == "Project Manager") {
                            setAutoDistribution('', strdisuser[0].Value, "2#", calculateDistDate(3));
                        }
                        else
                            setAutoDistribution('incident-form', strdisuser[0].Value, "2#", calculateDistDate(3));
                    }
                }
            }
        }
        function setRolewiseForInfo(strRole) {

            var strusers = commonApi._.filter(dsProjUsersAllRoles, function (val) {
                var roleNameLowerCase = val.Value.toLowerCase(),
                    roleNamePipe = roleNameLowerCase.split('|')[0].trim(),
                    roleNamePipeSplit = roleNamePipe.split(','),
                    roleName = null;
                    if(roleNameLowerCase.toLowerCase().indexOf(strRole.toLowerCase()) != -1)
                    {
                        for (var i = 0; i < roleNamePipeSplit.length; i++) {
                            roleName = roleNamePipeSplit[i].trim();
                            if (roleName == strRole.toLowerCase()) {
                                return val.Value
                            }
                        }
                    }
            });


            if (strusers && strusers.length) {
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter(dsProjDistUsers, function (val) {
                        return val.Value.indexOf(strUserId) != -1
                    });

                    if (strdisuser) {
                        setAutoDistribution('ForInfo', strdisuser[0].Value, "7#", calculateDistDate(7));
                    }
                }
            }
        }
        function calculateDistDate(days) {
            var strDueDate = "";
            if (days) {
                //var d = new Date();
                var d = new Date(currServerDate);
                d.setDate(d.getDate() + days);
                var month = d.getMonth() + 1;
                var day = d.getDate();
                var strDueDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;
            }
            return strDueDate;
        }

        function setAutoDistribution(formName, strUser, strAction, strDueDate) {

            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            if (formName == 'incident-form') {
                var tmpIndex = $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'].length;
                tmpIndex = tmpIndex == 0 ? 0 : tmpIndex - 1;
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'][tmpIndex]['ACF_02_REPEATING_VALUES']['ACF_02_DS_AutoDistribute_User_Group']['ACF_02_DS_AutoDistribute_Users'] = [];
                var structDistricution = angular.copy(STATIC_OBJ_DATA['ACF_02_FORM']['ACF_02_REPEATING_VALUES']['ACF_02_DS_AutoDistribute_User_Group']['ACF_02_DS_AutoDistribute_Users'][0])
                structDistricution.ACF_02_DS_PROJDISTUSERS = strUser;
                structDistricution.ACF_02_DS_FORMACTIONS = strAction;
                structDistricution.ACF_02_DS_ACTIONDUEDATE = strDueDate;

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'][tmpIndex]['ACF_02_REPEATING_VALUES']['ACF_02_DS_AutoDistribute_User_Group']['ACF_02_DS_AutoDistribute_Users'].push(structDistricution);
            } else if (formName == 'hazard-form') {
                var tmpIndex = $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'].length;
                tmpIndex = tmpIndex == 0 ? 0 : tmpIndex - 1;
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'][tmpIndex]['ACF_03_REPEATING_VALUES']['ACF_03_DS_AutoDistribute_User_Group']['ACF_03_DS_AutoDistribute_Users'] = [];
                var structDistricution = angular.copy(STATIC_OBJ_DATA['ACF_03_FORM']['ACF_03_REPEATING_VALUES']['ACF_03_DS_AutoDistribute_User_Group']['ACF_03_DS_AutoDistribute_Users'][0])
                structDistricution.ACF_03_DS_PROJDISTUSERS = strUser;
                structDistricution.ACF_03_DS_FORMACTIONS = strAction;
                structDistricution.ACF_03_DS_ACTIONDUEDATE = strDueDate;

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'][tmpIndex]['ACF_03_REPEATING_VALUES']['ACF_03_DS_AutoDistribute_User_Group']['ACF_03_DS_AutoDistribute_Users'].push(structDistricution);
            } else if (formName == 'complain-form') {
                var tmpIndex = $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'].length;
                tmpIndex = tmpIndex == 0 ? 0 : tmpIndex - 1;
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'][tmpIndex]['ACF_04_REPEATING_VALUES']['ACF_04_DS_AutoDistribute_User_Group']['ACF_04_DS_AutoDistribute_Users'] = [];
                var structDistricution = angular.copy(STATIC_OBJ_DATA['ACF_04_FORM']['ACF_04_REPEATING_VALUES']['ACF_04_DS_AutoDistribute_User_Group']['ACF_04_DS_AutoDistribute_Users'][0])
                structDistricution.ACF_04_DS_PROJDISTUSERS = strUser;
                structDistricution.ACF_04_DS_FORMACTIONS = strAction;
                structDistricution.ACF_04_DS_ACTIONDUEDATE = strDueDate;

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'][tmpIndex]['ACF_04_REPEATING_VALUES']['ACF_04_DS_AutoDistribute_User_Group']['ACF_04_DS_AutoDistribute_Users'].push(structDistricution);
            }
            else if (formName == 'ForInfo') {
                $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                var structDistricution = angular.copy($scope.DistributionStructure)
                structDistricution.DS_PROJDISTUSERS = strUser;
                structDistricution.DS_FORMACTIONS = strAction;
                structDistricution.DS_ACTIONDUEDATE = strDueDate;
                $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users.push(structDistricution);
            }
            else {
                //get copy of distribution and set user ,date ,action to distribute
                $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                var structDistricution = angular.copy($scope.DistributionStructure)
                structDistricution.DS_PROJDISTUSERS = strUser;
                structDistricution.DS_FORMACTIONS = strAction;
                structDistricution.DS_ACTIONDUEDATE = strDueDate;
                $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users.push(structDistricution);
            }
        }

        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (dsAllActiveFormStatus != null && dsAllActiveFormStatus.length > 0) {
                var DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(dsAllActiveFormStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (DS_ALL_ACTIVE_FORM_STATUS.length) {
                    return DS_ALL_ACTIVE_FORM_STATUS[0].Value;
                }
            }
            return "";
        }

        // Load Worker Details data from Custom Attributes
        function showAllWorkerDetails() {
            $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'] = [];
            var strPlantNameCategory = $scope.dsStep1Fields['DS_Worker_Attribute_Name'];
            strPlantNameCategory = strPlantNameCategory && strPlantNameCategory.trim();

            var dataPlantDetails = commonApi._.filter(dsAsiConfigurableAttributes, function (element) {
                return element.Value3 === strPlantNameCategory
            });

            for (var index = 0; index < dataPlantDetails.length; index++) {
                var element = dataPlantDetails[index];
                var tmpNomde = angular.copy(STATIC_OBJ_DATA.DS_Worker_Details);
                tmpNomde.Trade_on_site = element.Value8;
                tmpNomde.DS_isNew = 'No';

                $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'].push(tmpNomde);
            }
        }

        // Get and set Incident , Complaint, Hazard Register data
        $scope.urlFields = {};
        function setAllRegisterData(tData) {
            var tempIncidentData = [];
            var tempComplaintData = [];
            var tempHazardData = [];
            for (var index = 0; index < tData.length; index++) {
                var element = tData[index];

                $scope.urlFields[element.Value11] = element.URL11;
                if (element.Value4 == 'ASI-INR') {
                    var tmpData = angular.copy(STATIC_OBJ_DATA.DS_HSE_Incidents);
                    tmpData.HSEI_isCreated = 1;
                    tmpData.Incident_No = element.Value5;
                    tmpData.Incident_Type = element.Value21;
                    tmpData.Trade_Attributed = element.Value12;
                    tmpData.Task_Performed = element.Value13;

                    tempIncidentData.push(tmpData);

                } else if (element.Value4 == 'ASI-COMP') {

                    var tmpData = angular.copy(STATIC_OBJ_DATA.DS_Complaints);
                    tmpData.Com_isCreated = 1;
                    tmpData.Complaint_No = element.Value5;
                    tmpData.Complaint = element.Value6;
                    tmpData.Complaint_Source = element.Value16;
                    tmpData.Complaint_Type = element.Value17;

                    tempComplaintData.push(tmpData);

                } else if (element.Value4 == 'ASI-HAZ') {

                    var tmpData = angular.copy(STATIC_OBJ_DATA.DS_Hazards);
                    tmpData.HZ_isCreated = 1;
                    tmpData.Hazard_No = element.Value5;
                    tmpData.Hazard_Reported_By = element.Value10;
                    tmpData.Hazard_Trade = element.Value19;
                    tmpData.Hazard_Category = element.Value20;

                    tempHazardData.push(tmpData);

                }

            }

            if (tempIncidentData.length > 0) {
                $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'] = angular.copy(tempIncidentData);
            }

            if (tempComplaintData.length > 0) {
                $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'] = angular.copy(tempComplaintData);
            }

            if (tempHazardData.length > 0) {
                $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'] = angular.copy(tempHazardData);
            }
        }

        $scope.checkDuplicateValueForEvent = function (args) {
            var strVal = args.curObj[args.objName];
            var cureentIndex = args.repeatObj.indexOf(args.curObj);
            angular.forEach(args.repeatObj, function (item, index) {
                if (cureentIndex != index && strVal != "" && item[args.objName] == strVal) {
                    alert("Duplicate " + args.msg + " selected !!! \n\n Select a different " + args.msg);
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }

        $scope.inValidDate = false;
        $scope.isXHRon = false;
        $scope.dateCreatedOnChange = dateCreatedOnChange;
        function dateCreatedOnChange(isSubmitValidation, callBackFun) {            
            $scope.inValidDate = false;
            $scope.isXHRon = false;
            $scope.disabledDate = false;

            var selectedDate = $scope.dsStep1Fields['Date_Created'];
            selectedDate = new Date(selectedDate);
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dayName = days[selectedDate.getDay()];

            $scope.dsStep1Fields['Site_Diary_Day'] = dayName;

            if ($scope.dsStep1Fields['Date_Created'] == '') {
                return;
            }

            var formatedDate = $scope.formatDate(selectedDate, 'dd/mm/yy');
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.ORI_FORMTITLE = "Site Diary for :: " + formatedDate;

            var dataSourceName = "DS_PYD_DSD_CHK_GET_ALL_REGSTR_DTL";
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": $scope.dsStep1Fields['Date_Created']
                    }]
                }
            };

            $scope.requests['chkDateFetchRegstrData'] = true;
            $scope.add({
                name: "chkDateFetchRegstrData",
                status: "incomplete"
            });

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;

                $scope.requests['chkDateFetchRegstrData'] = false;
                $scope.update({
                    name: "chkDateFetchRegstrData",
                    status: "completed"
                });

                if (resData) {
                    var spData = angular.fromJson(response.data[dataSourceName]);
                    spData = spData['Items']["Item"] || [];

                    if (!spData.length) {
                        return;
                    }

                    if (spData[0] && spData[0].Value2 === 'Yes') {
                        $scope.inValidDate = true;
                    } else if(!isSubmitValidation) {
                        $scope.disabledDate = true;
                        setAllRegisterData(spData);
                    }
                    
                    callBackFun && callBackFun();
                }
            });
        }
        function setNumericiData() {
            var employeeData = $scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details'];
            var workData = $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'];
            for (var i = 0; i < employeeData.length; i++) {
                if (employeeData[i].Employee_Hours)
                    employeeData[i].Employee_Hours = parseFloat(employeeData[i].Employee_Hours)
            }
            for (var i = 0; i < workData.length; i++) {
                if (workData[i].Worker_Hours)
                    workData[i].Worker_Hours = parseFloat(workData[i].Worker_Hours)
            }
        }
        function setEditOriData() {
            var complaintData = $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'];
            var incidentData = $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'];
            var hazardData = $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'];

            for (var i = 0; i < complaintData.length; i++) {
                complaintData[i].Com_isCreated = 1;
                complaintData[i].Com_isSelected = false;
            }
            for (var i = 0; i < incidentData.length; i++) {
                incidentData[i].HSEI_isCreated = 1;
                incidentData[i].HSEI_isSelected = false;
            }
            for (var i = 0; i < hazardData.length; i++) {
                hazardData[i].HZ_isCreated = 1;
                hazardData[i].HZ_isSelected = false;
            }
        }
        function setLookupData() {
            var tempAutoCreateLookup = [];            
            for (var i = 2; i < 5; i++) {
                if (i == 2) {
                    var newRowObject = {
                        ACF_CODE:"ASI-INR",
                        ACF_LOOKUP_SEQ:"2"
                    };                   
                } else if (i == 3) {
                    var newRowObject = {
                        ACF_CODE:"ASI-HAZ",
                        ACF_LOOKUP_SEQ:"3"
                    };
                } else {
                    var newRowObject = {
                        ACF_CODE:"ASI-COMP",
                        ACF_LOOKUP_SEQ:"4"
                    }; 
                }
                tempAutoCreateLookup.push(newRowObject) 
            }
            $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['AUTOCREATE_FORM_LOOKUP'] = tempAutoCreateLookup;
        }

        //if item is deleted than make one entry mandatory
        $scope.deleteItem = function (obj, repeatingData) {

            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);

        };

        $scope.dateRepotedValidation = function (parentNode, reportedDate, matchDate) {
            if (reportedDate && matchDate) {
                var reportedDateObj = commonApi.parseDate('yy-mm-dd', parentNode[reportedDate]);
                var matchDateObj = commonApi.parseDate('yy-mm-dd', parentNode[matchDate]);

                if (matchDateObj && reportedDateObj && matchDateObj.getTime() > reportedDateObj.getTime()) {
                    parentNode[reportedDate] = "";
                    $window.alert("Validation \n\n Date reported should be greater than Incident date.");
                }
            }
        }

        $scope.incidentTimeValidation = function (currFields) {
            var formObj = $scope.myform;
            formObj['Inc_Incident_Time'].$setValidity('valid', true);
            formObj['Inc_Time_Reported'].$setValidity('valid', true);

            var dateOfIncident = $scope.modelData['DS_Incident_Date'];
            var dateOfReported = $scope.modelData['DS_Date_Reported'];

            var timeOfIncident = $scope.modelData['Incident_Time'];
            var timeOfReported = $scope.modelData['Time_Reported'];

            if (dateOfIncident && dateOfReported && dateOfIncident == dateOfReported && timeOfIncident && timeOfReported) {
                var incDate = commonApi.parseDate('yy-mm-dd', dateOfIncident);
                var repDate = commonApi.parseDate('yy-mm-dd', dateOfReported);

                var incTime = get24HrDate(timeOfIncident);
                var repTime = get24HrDate(timeOfReported);

                var incDateParse = mergeTimeInDate(incDate, incTime);
                var repDateParse = mergeTimeInDate(repDate, repTime);

                if (incDateParse > repDateParse) {
                    if (currFields) {
                        formObj[currFields].$setValidity('valid', false);
                    } else {
                        formObj['Inc_Incident_Time'].$setValidity('valid', false);
                        formObj['Inc_Time_Reported'].$setValidity('valid', false);
                    }
                }
            }
        }

        $scope.hseqChangeEvt = function(weeklyInspection, key) {
            $scope.dsStep1Fields['DS_Inspection_Group']['DS_Inspections'][key] = "0";
            if(weeklyInspection == 'Yes') {
                $scope.dsStep1Fields['DS_Inspection_Group']['DS_Inspections'][key] = "";
            } 
        };

        $scope.defaultValueCondtion = function (inspectionNo, key) {
            if(!parseInt(inspectionNo) > 0) {
                Notification.error({
					title: 'Validation Error',
					message: 'Value must be greater than 0.'
                });
                $scope.dsStep1Fields['DS_Inspection_Group']['DS_Inspections'][key] = "";
            }
        };

        function get24HrDate(strTime) {
            var tmpTime = strTime.split(':');
            if (strTime.indexOf('PM') > -1 && tmpTime[0] < 12) {
                tmpTime[0] = parseInt(tmpTime[0]) + 12;
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            } else {
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }
        }

        function mergeTimeInDate(dateObj, timeArray) {
            dateObj.setHours(timeArray[0]);
            dateObj.setMinutes(timeArray[1]);

            return dateObj;
        }

        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            addRemoveRowCallBack(objKeyName);

            $scope.expandTextAreaOnLoad();
        };

        $scope.openModal = function (modalId, rowData) {
            switch (modalId) {
                case 'incident-report':
                    if (rowData) {
                        var tmpIndex = 'row' + rowData.index;
                        $scope.modelData = angular.copy($scope.incidentAutoCreateFeilds[tmpIndex]);
                        $scope.modelData['rowIndex'] = rowData.index;
                    } else {
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Incident_Report);
                        $scope.modelData.DS_Incident_Date = $scope.dsStep1Fields['Date_Created'];
                    }
                    break;
                case 'hazard-report':
                    if (rowData) {
                        var tmpIndex = 'row' + rowData.index;
                        $scope.modelData = angular.copy($scope.hazardAutoCreateFeilds[tmpIndex]);
                        $scope.modelData['rowIndex'] = rowData.index;
                    } else {
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Hazard_Report);
                        $scope.modelData['Reported_By'] = $scope.dsWorkingUser;
                        $scope.modelData.DS_Date_Reported = $scope.dsStep1Fields['Date_Created'];
                    }
                    break;
                case 'complaint':
                    if (rowData) {
                        var tmpIndex = 'row' + rowData.index;
                        $scope.modelData = angular.copy($scope.complaintAutoCreateFeilds[tmpIndex]);
                        $scope.modelData['rowIndex'] = rowData.index;
                    } else {
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Complaint);
                        $scope.modelData['Raised_By'] = $scope.dsWorkingUser;
                        $scope.modelData.DS_Date_Reported = $scope.dsStep1Fields['Date_Created'];
                    }
                    break;
            }

            if ($scope.dsStep1Fields['Date_Created'] && !$scope.inValidDate) {
                $scope.modelData.hasDateSelected = true;
            }

            $scope.showModal(modalId);
        }

        $scope.hideModal = function () {
            $timeout(function () {
                ctrl.model.modelId = "";
            });
        };
        //incident
        if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['incidentModalData']) {
            $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['incidentModalData'] = {};
        }
        //hazard
        if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['hazardModalData']) { $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['hazardModalData'] = {} }

        //complaint
        if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['complaintModalData']) { $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['complaintModalData'] = {} }

        $scope.hazardAutoCreateFeilds = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['hazardModalData'];
        $scope.complaintAutoCreateFeilds = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['complaintModalData'];
        $scope.incidentAutoCreateFeilds = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['incidentModalData'];
        $scope.updateRecord = function () {
            var modalId = ctrl.model.modelId;

            switch (modalId) {
                case 'incident-report':
                    if (validateIncidentForm()) {

                        var rowLength = 'row' + $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'].length;
                        var rowIndex = $scope.modelData['rowIndex'];
                        if (rowIndex > -1) {
                            rowLength = 'row' + rowIndex;
                        }

                        var tmpDS_HSE_Incidents = angular.copy(STATIC_OBJ_DATA.DS_HSE_Incidents)
                        tmpDS_HSE_Incidents.Incident_Type = $scope.modelData['Primary_Category'];
                        tmpDS_HSE_Incidents.Trade_Attributed = $scope.modelData['DS_Initial_Classification'];
                        tmpDS_HSE_Incidents.Task_Performed = $scope.modelData['Task'];

                        if ($scope.incidentAutoCreateFeilds[rowLength] && rowIndex > -1) { // For edit Modal Popup
                            $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'][rowIndex] = tmpDS_HSE_Incidents;
                        } else { // First time create
                            $scope.dsStep1Fields['DS_HSE_Incidents_Group']['DS_HSE_Incidents'].push(tmpDS_HSE_Incidents);
                        }

                        $scope.incidentAutoCreateFeilds[rowLength] = angular.copy($scope.modelData);

                    } else {
                        alert('Validation\n\nPlease fill mandatory fields.');
                        return;
                    }
                    break;
                case 'hazard-report':
                    if (validateHazardForm()) {

                        var rowLength = 'row' + $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'].length;
                        var rowIndex = $scope.modelData['rowIndex'];
                        if (rowIndex > -1) {
                            rowLength = 'row' + rowIndex;
                        }

                        var tmpDS_Hazards = angular.copy(STATIC_OBJ_DATA.DS_Hazards)
                        tmpDS_Hazards.Hazard_Reported_By = $scope.modelData['Reported_By'];
                        tmpDS_Hazards.Hazard_Trade = $scope.modelData['Trade'];
                        tmpDS_Hazards.Hazard_Category = $scope.modelData['Category'];

                        if ($scope.hazardAutoCreateFeilds[rowLength] && rowIndex > -1) { // For edit Modal Popup
                            $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'][rowIndex] = tmpDS_Hazards;
                        } else { // First time create
                            $scope.dsStep1Fields['DS_Hazards_Group']['DS_Hazards'].push(tmpDS_Hazards);
                        }

                        $scope.hazardAutoCreateFeilds[rowLength] = angular.copy($scope.modelData);

                    } else {
                        alert('Validation\n\nPlease fill mandatory fields.');
                        return;
                    }
                    break;
                case 'complaint':
                    if (validateComplaintForm()) {

                        var rowLength = 'row' + $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'].length;
                        var rowIndex = $scope.modelData['rowIndex'];
                        if (rowIndex > -1) {
                            rowLength = 'row' + rowIndex;
                        }

                        var tmpDS_Complaints = angular.copy(STATIC_OBJ_DATA.DS_Complaints)
                        tmpDS_Complaints.Complaint = $scope.modelData['Complaint_FORMTITLE'];
                        tmpDS_Complaints.Complaint_Source = $scope.modelData['Complaint_Source'];
                        tmpDS_Complaints.Complaint_Type = $scope.modelData['Issue_Category'];

                        if ($scope.complaintAutoCreateFeilds[rowLength] && rowIndex > -1) { // For edit Modal Popup
                            $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'][rowIndex] = tmpDS_Complaints;
                        } else { // First time create
                            $scope.dsStep1Fields['DS_Complaints_Group']['DS_Complaints'].push(tmpDS_Complaints);
                        }

                        $scope.complaintAutoCreateFeilds[rowLength] = angular.copy($scope.modelData);

                    } else {
                        alert('Validation\n\nPlease fill mandatory fields.');
                        return;
                    }
                    break;
                default:
                    break;
            }

            $timeout(function () {
                $scope.hideModal();
            });
        }

        ctrl.model = {
            modelId: "",
            update: $scope.updateRecord,
            hideModal: $scope.hideModal,
            showloader: false,
            readOnly: false
        };

        $scope.showModal = function (id) {
            // show modal
            ctrl.model.modelId = id;
        };

        function validateComplaintForm() {
            var validaFlag = true;
            var mandatoryIncidentFields = ["Complaint_FORMTITLE", "DS_Date_Reported", "Issue_Category", "Time_Reported", "Complaint_Source", "Location", "Completed", "Complainant_Name", "Complainant_Phone_No", "DS_Action_Completed"];

            for (var index = 0; index < mandatoryIncidentFields.length; index++) {
                var element = mandatoryIncidentFields[index];
                var strElem = $scope.modelData[element];
                if (!strElem) {
                    validaFlag = false;
                    break;
                }
            }
            return validaFlag;
        }

        function validateHazardForm() {
            var validaFlag = true;
            var mandatoryIncidentFields = ['Hazard_FORMTITLE', 'DS_Date_Reported', 'Company', 'Time_Reported', 'Trade', 'Location', 'Category', 'Completed', 'DS_Action_Completed'];

            for (var index = 0; index < mandatoryIncidentFields.length; index++) {
                var element = mandatoryIncidentFields[index];
                var strElem = $scope.modelData[element];
                if (!strElem) {
                    validaFlag = false;
                    break;
                }
            }
            return validaFlag;
        }

        function validateIncidentForm() {
            var mandatoryIncidentFields = ['Incident_FORMTITLE', 'DS_Incident_Date', 'Reported_To', 'Incident_Time', 'Location', 'DS_Date_Reported',
                'DS_Initial_Classification', 'Witness', 'Hazard_Identified_PRM_Plan', 'Hazard_Identified_SWMS', 'People_Instructed', 'Induction_Completed', 'Time_Reported', 'Immidiate_Actions'];
            var validaFlag = true;
            for (var index = 0; index < mandatoryIncidentFields.length; index++) {
                var element = mandatoryIncidentFields[index];
                var strElem = $scope.modelData[element];
                if (!strElem) {
                    validaFlag = false;
                    break;
                }
            }

            if (!$scope.myform.Inc_Incident_Time.$valid || !$scope.myform.Inc_Time_Reported.$valid) {
                validaFlag = false;
            }

            if ($scope.modelData['Primary_Category'] && $scope.modelData['Primary_Category'].toLowerCase().indexOf('injury') > -1 && validaFlag) {
                var mandatoryInjuryFields = ['Name', 'Gender', 'Date_of_Birth', 'First_aid_provided', 'First_aid_by', 'First_aid_details', 'Injury_Outcome', 'Medical_aid_provided', 'Medical_aid_by', 'Medical_aid_details', 'Body_Location', 'Body_Location_Side', 'Nature_of_Injury', 'Mechanics_of_Injury', 'Agency_of_Injury'];

                for (var k = 0; k < $scope.modelData['DS_Injury_Details'].length; k++) {
                    var injDet = $scope.modelData['DS_Injury_Details'][k];
                    for (var index = 0; index < mandatoryInjuryFields.length; index++) {
                        var element = mandatoryInjuryFields[index];
                        var strElem = injDet[element];
                        if (((element == 'First_aid_by' || element == 'First_aid_details') && injDet.First_aid_provided == "No") || ((element == 'Medical_aid_by' || element == 'Medical_aid_details') && injDet.Medical_aid_provided == "No")) {
                            continue;
                        }

                        if (!strElem) {
                            validaFlag = false;
                            break;
                        }
                    }

                    if (!validaFlag) {
                        break;
                    }
                }

            }

            return validaFlag;
        }

        function addRemoveRowCallBack(area) {
            switch (area) {
                case 'DS_Employee_Details':
                    $scope.dsStep1Fields['DS_Employee_Group']['Sum_Employee_No'] = $scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details'].length;
                    break;
            }
        }


        $scope.deleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };

        $scope.checkDuplicateValue = function (args) {
            var strVal = args.curObj[args.objName]
            var cureentIndex = args.repeatObj.indexOf(args.curObj);
            angular.forEach(args.repeatObj, function (item, index) {
                if (cureentIndex != index && strVal != "" && item[args.objName] == strVal) {
                    alert("Duplicate " + args.msg + " selected !!! \n\n Select a different " + args.msg);
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }

        $scope.countDirectEmployeeHours = function () {
            var tmpTotal = 0;
            var tempEmployeeDetail = angular.copy($scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details']);
            for (var index = 0; index < tempEmployeeDetail.length; index++) {
                var element = tempEmployeeDetail[index];
                if (element.Employee_Hours) {
                    tmpTotal += (parseFloat(element.Employee_Hours) || 0);
                }
            }

            $scope.dsStep1Fields['DS_Employee_Group']['Sum_Direct_Employee_hours'] = tmpTotal.toFixed(1);
            $scope.dsStep1Fields['Total_Direct_Employee_Hours'] = tmpTotal.toFixed(1);
        }

        function createAutoCreateNodes() {

            var incFormStatus = getFormStatusId("Raised");
            incFormStatus = incFormStatus ? incFormStatus.split('#')[0].trim() : '';

            var hzFormStatus = getFormStatusId("Closed");
            hzFormStatus = hzFormStatus ? hzFormStatus.split('#')[0].trim() : '';

            for (var key in $scope.incidentAutoCreateFeilds) {
                var tmpIncidentNode = $scope.incidentAutoCreateFeilds[key];
                var autoCreateIncident = angular.copy(STATIC_OBJ_DATA.ACF_02_FORM);

                autoCreateIncident['ACF_02_ORI_FORMTITLE'] = tmpIncidentNode['Incident_FORMTITLE'];
                autoCreateIncident['ACF_02_DS_FORMTITLE'] = tmpIncidentNode['Incident_FORMTITLE'];
                autoCreateIncident['ACF_02_DS_Incident_Date'] = tmpIncidentNode['DS_Incident_Date'];
                autoCreateIncident['ACF_02_Reported_To'] = tmpIncidentNode['Reported_To'];
                autoCreateIncident['ACF_02_Incident_Time'] = tmpIncidentNode['Incident_Time'];
                autoCreateIncident['ACF_02_Location'] = tmpIncidentNode['Location'];
                autoCreateIncident['ACF_02_DS_Date_Reported'] = tmpIncidentNode['DS_Date_Reported'];
                autoCreateIncident['ACF_02_Date_Reported'] = $scope.formatDate(new Date(tmpIncidentNode['DS_Date_Reported']), 'dd/mm/yy');
                autoCreateIncident['ACF_02_Task'] = tmpIncidentNode['Task'];
                autoCreateIncident['ACF_02_Time_Reported'] = tmpIncidentNode['Time_Reported'];
                autoCreateIncident['ACF_02_Primary_Category'] = tmpIncidentNode['Primary_Category'];
                autoCreateIncident['ACF_02_Secondary_Category'] = tmpIncidentNode['Secondary_Category'];
                autoCreateIncident['ACF_02_Days_Lost'] = tmpIncidentNode['Days_Lost'];
                autoCreateIncident['ACF_02_DS_Initial_Classification'] = tmpIncidentNode['DS_Initial_Classification'];
                autoCreateIncident['ACF_02_Description'] = tmpIncidentNode['Description'];
                autoCreateIncident['ACF_02_Witness'] = tmpIncidentNode['Witness'];
                autoCreateIncident['ACF_02_Hazard_Identified_PRM_Plan'] = tmpIncidentNode['Hazard_Identified_PRM_Plan'];
                autoCreateIncident['ACF_02_Hazard_Identified_SWMS'] = tmpIncidentNode['Hazard_Identified_SWMS'];
                autoCreateIncident['ACF_02_People_Trained'] = tmpIncidentNode['People_Trained'];
                autoCreateIncident['ACF_02_SWMS_Followed'] = tmpIncidentNode['SWMS_Followed'];
                autoCreateIncident['ACF_02_People_Instructed'] = tmpIncidentNode['People_Instructed'];
                autoCreateIncident['ACF_02_Induction_Completed'] = tmpIncidentNode['Induction_Completed'];
                autoCreateIncident['ACF_02_Immidiate_Actions'] = tmpIncidentNode['Immidiate_Actions'];
                autoCreateIncident['ACF_02_Incident_Attachment'] = tmpIncidentNode['Incident_Attachment'];
                autoCreateIncident['ACF_02_Incident_Attachment_JSEA'] = tmpIncidentNode['Incident_Attachment_JSEA'];
                autoCreateIncident['ACF_02_CREATED_BY'] = dsWorkingUserId;

                var allAutoAllWitness = [];
                for (var k = 0; k < tmpIncidentNode['DS_All_Witnesses'].length; k++) {
                    var autoCreateAllWitness = angular.copy(STATIC_OBJ_DATA.ACF_02_FORM.ACF_02_REPEATING_VALUES.ACF_02_DS_Witness_Group.ACF_02_DS_All_Witnesses[0]);
                    var tmpElem = tmpIncidentNode['DS_All_Witnesses'][k];
                    autoCreateAllWitness['ACF_02_Witness_Name'] = tmpElem['Witness_Name']
                    autoCreateAllWitness['ACF_02_Witness_Contact_details'] = tmpElem['Witness_Contact_details']

                    allAutoAllWitness.push(autoCreateAllWitness);
                }

                var allAutoInjuryDetails = [];
                for (var k = 0; k < tmpIncidentNode['DS_Injury_Details'].length; k++) {
                    var autoCreateIjuryDetail = angular.copy(STATIC_OBJ_DATA.ACF_02_FORM.ACF_02_REPEATING_VALUES.ACF_02_DS_Injury_Group.ACF_02_DS_Injury_Details[0]);

                    var tmpElem = tmpIncidentNode['DS_Injury_Details'][k];
                    autoCreateIjuryDetail['ACF_02_Name'] = tmpElem['Name']
                    autoCreateIjuryDetail['ACF_02_Gender'] = tmpElem['Gender']
                    autoCreateIjuryDetail['ACF_02_Date_of_Birth'] = tmpElem['Date_of_Birth']
                    autoCreateIjuryDetail['ACF_02_Occupation'] = tmpElem['Occupation']
                    autoCreateIjuryDetail['ACF_02_Employer'] = tmpElem['Employer']
                    autoCreateIjuryDetail['ACF_02_Supervisor'] = tmpElem['Supervisor']
                    autoCreateIjuryDetail['ACF_02_First_aid_provided'] = tmpElem['First_aid_provided']
                    autoCreateIjuryDetail['ACF_02_First_aid_by'] = tmpElem['First_aid_by']
                    autoCreateIjuryDetail['ACF_02_First_aid_details'] = tmpElem['First_aid_details']
                    autoCreateIjuryDetail['ACF_02_Injury_Outcome'] = tmpElem['Injury_Outcome']
                    autoCreateIjuryDetail['ACF_02_Medical_aid_provided'] = tmpElem['Medical_aid_provided']
                    autoCreateIjuryDetail['ACF_02_Medical_aid_by'] = tmpElem['Medical_aid_by']
                    autoCreateIjuryDetail['ACF_02_Medical_aid_details'] = tmpElem['Medical_aid_details']
                    autoCreateIjuryDetail['ACF_02_Body_Location'] = tmpElem['Body_Location']
                    autoCreateIjuryDetail['ACF_02_Body_Location_Side'] = tmpElem['Body_Location_Side']
                    autoCreateIjuryDetail['ACF_02_Nature_of_Injury'] = tmpElem['Nature_of_Injury']
                    autoCreateIjuryDetail['ACF_02_Mechanics_of_Injury'] = tmpElem['Mechanics_of_Injury']
                    autoCreateIjuryDetail['ACF_02_Agency_of_Injury'] = tmpElem['Agency_of_Injury'];

                    allAutoInjuryDetails.push(autoCreateIjuryDetail);
                }

                autoCreateIncident['ACF_02_REPEATING_VALUES']['ACF_02_DS_Witness_Group']['ACF_02_DS_All_Witnesses'] = allAutoAllWitness;
                autoCreateIncident['ACF_02_REPEATING_VALUES']['ACF_02_DS_Injury_Group']['ACF_02_DS_Injury_Details'] = allAutoInjuryDetails;

                autoCreateIncident['ACF_02_DS_ALL_FORMSTATUS'] = incFormStatus;
                autoCreateIncident['ACF_02_DS_AUTODISTRIBUTE'] = '3';

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'].push(autoCreateIncident);

                setRolewiseDistribution("HSE Team");
            }

            for (var key in $scope.hazardAutoCreateFeilds) {
                var tmpHazarNode = $scope.hazardAutoCreateFeilds[key];
                var autoCreateIncident = angular.copy(STATIC_OBJ_DATA.ACF_03_FORM);

                autoCreateIncident['ACF_03_ORI_FORMTITLE'] = tmpHazarNode['Hazard_FORMTITLE'];
                autoCreateIncident['ACF_03_DS_FORMTITLE'] = tmpHazarNode['Hazard_FORMTITLE'];

                autoCreateIncident['ACF_03_DS_Date_Reported'] = tmpHazarNode['DS_Date_Reported'];
                autoCreateIncident['ACF_03_Date_Reported'] = $scope.formatDate(new Date(tmpHazarNode['DS_Date_Reported']), 'dd/mm/yy');
                autoCreateIncident['ACF_03_Company'] = tmpHazarNode['Company'];
                autoCreateIncident['ACF_03_Time_Reported'] = tmpHazarNode['Time_Reported'];
                autoCreateIncident['ACF_03_Trade'] = tmpHazarNode['Trade'];
                autoCreateIncident['ACF_03_Location'] = tmpHazarNode['Location'];
                autoCreateIncident['ACF_03_Category'] = tmpHazarNode['Category'];
                autoCreateIncident['ACF_03_Completed'] = tmpHazarNode['Completed'];
                autoCreateIncident['ACF_03_Reported_By'] = tmpHazarNode['Reported_By'];
                autoCreateIncident['ACF_03_DS_Action_Completed'] = tmpHazarNode['DS_Action_Completed'];

                if (tmpHazarNode['DS_Action_Completed'] == 'No') {
                    autoCreateIncident['ACF_03_DS_ALL_FORMSTATUS'] = '';
                    autoCreateIncident['ACF_03_DS_AUTODISTRIBUTE'] = '3';
                } else {
                    autoCreateIncident['ACF_03_DS_ALL_FORMSTATUS'] = hzFormStatus;
                    autoCreateIncident['ACF_03_DS_AUTODISTRIBUTE'] = '';
                }

                autoCreateIncident['ACF_03_CREATED_BY'] = dsWorkingUserId;

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'].push(autoCreateIncident);

                if (tmpHazarNode['DS_Action_Completed'] == 'No') {
                    setAutoDistribution('hazard-form', dsWorkingUserId, "3#", calculateDistDate(3));//complain-form
                }
            }


            for (var key in $scope.complaintAutoCreateFeilds) {
                var tmpComplaintNode = $scope.complaintAutoCreateFeilds[key];
                var autoCreateIncident = angular.copy(STATIC_OBJ_DATA.ACF_04_FORM);

                autoCreateIncident['ACF_04_ORI_FORMTITLE'] = tmpComplaintNode['Complaint_FORMTITLE'];
                autoCreateIncident['ACF_04_DS_FORMTITLE'] = tmpComplaintNode['Complaint_FORMTITLE'];

                autoCreateIncident['ACF_04_DS_Date_Reported'] = tmpComplaintNode['DS_Date_Reported'];
                autoCreateIncident['ACF_04_Date_Reported'] = $scope.formatDate(new Date(tmpComplaintNode['DS_Date_Reported']), 'dd/mm/yy');
                autoCreateIncident['ACF_04_Issue_Category'] = tmpComplaintNode['Issue_Category'];
                autoCreateIncident['ACF_04_Time_Reported'] = tmpComplaintNode['Time_Reported'];
                autoCreateIncident['ACF_04_Complaint_Source'] = tmpComplaintNode['Complaint_Source'];
                autoCreateIncident['ACF_04_Location'] = tmpComplaintNode['Location'];
                autoCreateIncident['ACF_04_Completed'] = tmpComplaintNode['Completed'];
                autoCreateIncident['ACF_04_Raised_By'] = tmpComplaintNode['Raised_By'];
                autoCreateIncident['ACF_04_Complainant_Name'] = tmpComplaintNode['Complainant_Name'];
                autoCreateIncident['ACF_04_Complainant_Phone_No'] = tmpComplaintNode['Complainant_Phone_No'];
                autoCreateIncident['ACF_04_Complainant_Address'] = tmpComplaintNode['Complainant_Address'];
                autoCreateIncident['ACF_04_DS_Action_Completed'] = tmpComplaintNode['DS_Action_Completed'];
                autoCreateIncident['ACF_04_Complainant_Attachment'] = tmpComplaintNode['Complainant_Attachment'];
                autoCreateIncident['ACF_04_Complainant_Action'] = tmpComplaintNode['Complainant_Action'];
                if (tmpComplaintNode['DS_Action_Completed'] == 'No') {
                    autoCreateIncident['ACF_04_DS_ALL_FORMSTATUS'] = '';
                    autoCreateIncident['ACF_04_DS_AUTODISTRIBUTE'] = '3';
                } else {
                    autoCreateIncident['ACF_04_DS_ALL_FORMSTATUS'] = hzFormStatus;
                    autoCreateIncident['ACF_04_DS_AUTODISTRIBUTE'] = '';
                }

                autoCreateIncident['ACF_04_CREATED_BY'] = dsWorkingUserId;

                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'].push(autoCreateIncident);

                if (tmpComplaintNode['DS_Action_Completed'] == 'No') {
                    setAutoDistribution('complain-form', dsWorkingUserId, "3#", calculateDistDate(3));//complain-form
                }
            }


            return false;
        }

        var submitFormFun = function() {
            if (!$scope.strCanReply) {
                alert("You are not authorized to Edit the form contact your Administrator");
                return true;
            }

            var isValid = createAutoCreateNodes();

            $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['DS_AUTOCREATE_FORM'] = "24";

            if ($scope.inValidDate) {
                $window.alert('Validation\n\nForm already created agaist selected date!')
                return true;
            }

            if ($scope.strFormId == "" || $scope.strIsDraft == "YES" || $scope.DS_FORMSTATUS.toLowerCase() == "rejected") {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = calculateDistDate(7);
                var strFormStatusId = getFormStatusId("Under Review");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                    setRolewiseDistribution("Project Manager");
                    setRolewiseForInfo("Contract Administrator");
                    setRolewiseForInfo("Construction Manager");
                }
            }

            if ($scope.DS_FORMSTATUS.toLowerCase() == "under review") {

                var strFormStatusId = getFormStatusId($scope.dsStep1Fields.Status);

                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                    $scope.asiteSystemDataReadwrite.ORI_MSG_Fields.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
                    if ($scope.dsStep1Fields.Status == "Rejected") {
                        setAutoDistribution('', $scope.dsStep1Fields.DSI_SiteDiary_Org, "2#", calculateDistDate(3));
                    }
                    else {
                        setRolewiseForInfo("HSEQ Manager");
                        setRolewiseForInfo("HSEQ Coordinator");
                    }
                    clearAction();
                }
            }


            if ($scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'] && $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'].length == 0) {
                delete $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM'];
            }

            if ($scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'] && $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'].length == 0) {
                delete $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'];
            }

            if ($scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'] && $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'].length == 0) {
                delete $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'];
            }

            if (!$scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_04_FORM'] && !$scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_03_FORM'] && !$scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_02_FORM']) {
                $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['DS_AUTOCREATE_FORM'] = "";
            }

            if (!isValid) {
                $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_DB_INSERT = 'true';
                addAndRemoveListData($scope.dsStep1Fields['DS_Waste_Tracking_Group']['DS_Waste_Tracking'], 'WasteAndMaterialPickList', null, false);
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['hazardModalData']={};
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['complaintModalData']={};
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['incidentModalData']={};

                submitFlag = true;
                $window.submitForm(1);
            }
        };

        $window.pydSiteDiaryFinalCallBack = function () {
            if (submitFlag) {	
				return false;				
            }
            
            if ($scope.inValidDate) {
                $window.alert('Validation\n\nForm already created agaist selected date!')
                return true;
            }
           
            if(isFormEditOri) {
                submitFormFun();
            } else {
                dateCreatedOnChange(true, function () {
                    submitFormFun();
                });
            }

            return true;
        }

        $scope.countWorkDetailNo = function () {
            var tmpNoTotal = 0;
            var tmpHoursTotal = 0;
            var tmpWorkerDetails = angular.copy($scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details']);
            for (var index = 0; index < tmpWorkerDetails.length; index++) {
                var element = tmpWorkerDetails[index];
                if (element.Trade_Worker_No) {
                    tmpNoTotal += (parseFloat(element.Trade_Worker_No) || 0);
                }

                if (element.Trade_Worker_No && element.Worker_Hours) {
                    tmpHoursTotal += ((parseFloat(element.Trade_Worker_No) || 0) * (parseFloat(element.Worker_Hours) || 0));
                }
            }

            $scope.dsStep1Fields['Sum_Trade_No'] = tmpNoTotal.toFixed(1);
            $scope.dsStep1Fields['Sum_Trade_hours'] = tmpHoursTotal.toFixed(1);
            $scope.dsStep1Fields['Total_Subcontractor_Hours'] = tmpHoursTotal.toFixed(1);
        }
        $scope.clearComplaintAction = function (modelData) {
            if (modelData.DS_Action_Completed != "Yes") {
                modelData.Complainant_Action = "";
            }
        }

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pydSiteDiaryFinalCallBack !== "undefined") {
        return pydSiteDiaryFinalCallBack();
    }
}