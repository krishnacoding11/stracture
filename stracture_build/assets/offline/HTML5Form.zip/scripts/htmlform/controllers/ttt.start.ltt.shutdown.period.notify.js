
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        //autoSaveDraft timeout from client side
        $scope.stopAutoSaveDraftTimerFromClientSide();

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var STATIC_OBJ_DATA = {
            Doc_Form_Details: {
                Doc_Form_SeqID: "",
                Doc_Form_SeqHeader: "",
                Document_Details_Grp: {
                    Document_Details: [{
                        Doc_Form_SubSeqId: "",
                        Doc_Rev_ID: "",
                        Doc_ID: "",
                        Form_ID: "",
                        Doc_User_Ref: "",
                        Doc_Form_Title: "",
                        Doc_Form_Status: "",
                        Doc_Form_Workspace: "",
                        Doc_Form_Type: "",
                        Doc_TWEXNET: "",
                        Doc_Dep_Guid: ""
                    }]
                }
            },
            Document_Details: {
                Doc_Form_SubSeqId: "",
                Doc_Rev_ID: "",
                Doc_ID: "",
                Form_ID: "",
                Doc_User_Ref: "",
                Doc_Form_Title: "",
                Doc_Form_Status: "",
                Doc_Form_Workspace: "",
                Doc_Form_Type: "",
                Doc_TWEXNET: "",
                Doc_Dep_Guid: ""
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
        };

        var TTT_CONSTANT = {
            //define status
            notification_status: "Issued",
            notification_Accepted: "Accepted",
            ttt_notification_group: "TTT_Notification_Group",
            ttt_notification_CC_group: "TTT_Notification_CC_Group",
            scm: "System Commissioning Manager"
        }

        /** Initialize db fields */
        $scope.logo = "/images/htmlform/commenting/tideway.png";

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.ori_msg_Custom_Fields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.notification_issuedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["Notification_issuedBy"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.ds_Projdistgroups = $scope.getValueOfOnLoadData("DS_PROJDISTGROUPS");
        $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Get_Dashboard_Formwise_Details');
        var DS_TTT_TIDP_Validate_and_Get_Document_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Validate_and_Get_Document_Details');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var submitFlag = false;
        var submitXhrCall = {
            'notification-group': false,
            'notification-cc-group': false
        };

        $scope.dbFormId = $scope.formdata5['DS_FORMID'];
        $scope.isDraft = $scope.formdata5['DS_ISDRAFT'];

        $scope.ori_msg_Custom_Fields.MainTitle = "START LTT SHUT-DOWN PERIOD NOTIFICATION";
        $scope.setTitle = "STATEMENTS";

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsWorkingUser = dsWorkingUserId;
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        var todayDate = '';
        var todayDateDbFormat = '';
        $scope.getServerTime(function (serverDate) {
            todayDate = serverDate;
            todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            initORIview();
        });

        function initORIview() {
            if (currentViewName == "ORI_VIEW") {
                if ($scope.dbFormId != "" && $scope.isDraft == "NO") {
                    $scope.xhr = false;
                    binddocumentList();
                }
                if ($scope.dbFormId == "" || $scope.isDraft == "YES") {
                    filluserreflist();
                    $scope.hideSaveDraftButton();
                    $scope.setandvalidatedata($scope.ori_msg_Custom_Fields.Certi_Ref);
                }
                if ($scope.ori_msg_Custom_Fields.Certi_Ref == "") {
                    $scope.validatedocumentFlag = true;
                }
            }

            if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
                angular.element('.export-btn').hide();
                binddocumentList();
            }
            settabs();
        }


        function settabs() {
            $scope.oriviewtabs = [{
                title: 'Statements',
                url: 'Statements.html'
            }]

            $scope.currentOriViewTab = 'Statements.html';
            /****************************************/
            $scope.isActiveTab = function (tabUrl, calledform) {
                if (calledform == "ori_print_view_main") {
                    return tabUrl == $scope.currentOriPrintViewTab;
                } else if (calledform == "ori_view_main") {
                    return tabUrl == $scope.currentOriViewTab;
                }
            }
            /****************************************/

            $scope.setTitle = "STATEMENTS";
            
            $scope.onClickTab = function (tab, calledform) {
                var strFlag = "STATEMENTS";
                
                if (calledform == "ori_view_main") {
                    $scope.currentOriViewTab = tab.url;
                }
                if (calledform == "ori_print_view_main") {
                    $scope.currentOriPrintViewTab = tab.url;
                }
                $scope.setTitle = strFlag;

                $timeout(function () {
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        }
        $window.TTT_AssociateDocsAndForms = function () {
            if (submitFlag) {
                return false;
            }
            $scope.setflow();
            return true;
        }

        $scope.setflow = function () {
            var workingUserName = dsWorkingUser && dsWorkingUser.split(',')[0].trim();
            var workingUserOrg = dsWorkingUser && dsWorkingUser.split(',')[1].trim();
            var strTodayDate = todayDateDbFormat;
            $scope.formdata5.DS_DB_INSERT = true;

            //set notify by details
            $scope.notification_issuedBy.issuedBy_Date = strTodayDate;
            $scope.notification_issuedBy.issuedBy_Name = workingUserName;
            $scope.notification_issuedBy.issuedBy_ID = dsWorkingUserId.split('|')[0];
            $scope.notification_issuedBy.issuedBy_Position = TTT_CONSTANT.scm;
            $scope.notification_issuedBy.issuedBy_onbehalfof = workingUserOrg;

            //set distributr id for ORIview
            $scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3";
            $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

            //associate documents
            assocformsanddocs();

            //set distribution for mandatory group
            var notificationgroup = commonApi._.filter($scope.ds_Projdistgroups, function (item) {
                return item.Value.indexOf(TTT_CONSTANT.ttt_notification_group) > -1;
            });
            if (notificationgroup.length) {
                fillTTTGroup(notificationgroup[0].Value, 'notification-group');
            }

            //set distribution for CC group
            if ($scope.ori_msg_Custom_Fields['CC_Group'] == 'Yes') {
                var notification_CCgroup = commonApi._.filter($scope.ds_Projdistgroups, function (item) {
                    return item.Value.indexOf(TTT_CONSTANT.ttt_notification_CC_group) > -1;
                });

                if (notification_CCgroup.length) {
                    fillTTTGroup(notification_CCgroup[0].Value, 'notification-cc-group');
                }
            }

            //update form status
            updateFormStatus(TTT_CONSTANT.notification_status);
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = TTT_CONSTANT.notification_Accepted;
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strTodayDate;
        }
        var fillTTTGroup = function (value, callFor) {
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": "DS_GET_DIST_GROUP_USERS_ROLES",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_GET_DIST_GROUP_USERS_ROLES",
                        "fieldValue": value
                    }]
                }
            };

            submitXhrCall[callFor] = $scope.getCallbackData(form).then(function (response) {
                submitXhrCall[callFor] = false;
                if (response.data) {
                    var ds_get_dist_group_users_roles = angular.fromJson(response.data['DS_GET_DIST_GROUP_USERS_ROLES']).Items.Item;

                    if (ds_get_dist_group_users_roles && ds_get_dist_group_users_roles.length) {
                        for (var i = 0; i < ds_get_dist_group_users_roles.length; i++) {
                            var loopNode = ds_get_dist_group_users_roles[i];
                            if (loopNode.Name) {
                                $scope.ori_msg_Custom_Fields.userList.push({
                                    userName: ds_get_dist_group_users_roles[i].Value2
                                });
                                var strUserId = loopNode.Value1.trim();
                                setDistribution(strUserId, "7#For Information", "3");
                            }
                        }
                    }
                }
                if (!submitXhrCall['notification-group'] && !submitXhrCall['notification-cc-group']) {
                    submitFlag = true;
                    $window.submitForm(1);
                }
            });
        };

        function assocformsanddocs() {
            var assoFormsStr = ':#';
            var assoDocsStr = "";
            var strdsvalidatedocumentdata = DS_TTT_TIDP_Validate_and_Get_Document_Details;
            for (var index = 0; index < strdsvalidatedocumentdata.length; index++) {
                var strvalidate = strdsvalidatedocumentdata[index].Value1.trim();
                if (strvalidate == "0") {
                    var assocflag = strdsvalidatedocumentdata[index].Value16;
                    if (assocflag == 'Yes') {
                        if (strdsvalidatedocumentdata[index].Value15 != "") {
                            if (assoFormsStr == ":#") {
                                assoFormsStr += ':' + strdsvalidatedocumentdata[index].Value15;
                            } else {
                                assoFormsStr += ',:' + strdsvalidatedocumentdata[index].Value15;
                            }
                        }
                        if (strdsvalidatedocumentdata[index].Value7 != "") {
                            assoDocsStr += strdsvalidatedocumentdata[index].Value7 + "#" + strdsvalidatedocumentdata[index].Value14 + "#" + strdsvalidatedocumentdata[index].Value13 + ",";
                        }
                    }
                }
            }
            if (assoFormsStr.length > 2) {
                $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = assoFormsStr;
            }
            $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = assoDocsStr;
        }

        function updateFormStatus(StrStatus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : DS_ALL_ACTIVE_FORM_STATUS,
                strStatus : StrStatus.toLowerCase()
            });
            $scope.formdata5['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
        }

       function setDistribution(UsertoDist, Action, DS_AUTODist, strDate){
            var tempList = [];

            tempList.push({
                strUser: UsertoDist,
                strAction: Action,
                strDate: strDate
            });

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: DS_AUTODist
            });
        }


        function filluserreflist() {
            $scope.objuserref = [];
            var element = $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details;
            for (var index = 0; index < element.length; index++) {
                if (element[index].Value2 && element[index].Value3) {
                    var struserref = element[index].Value2.trim();
                    var strguid = element[index].Value3.trim();
                    var strconcate = struserref + "||" + strguid;
                    $scope.objuserref.push({
                        optlabel: "",
                        options: [{
                            displayValue: struserref,
                            modelValue: strconcate,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.setandvalidatedata = function (strcerti) {
            if (strcerti) {
                var strGUID = strcerti.split("||")[1].trim();
                $scope.ori_msg_Custom_Fields.ORI_USERREF = strcerti.split("||")[0].trim();
                $scope.ori_msg_Custom_Fields.Cer_GUID = strGUID;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strcerti.split("||")[0].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strcerti.split("||")[1].trim();
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": "DS_TTT_TIDP_Validate_and_Get_Document_Details",
                        "fieldValue": strGUID
                    }],
                    successCallback: getcallbackcertidata
                };
                $scope.xhr = true;
                $scope.getCallbackSPdata(spParam);
            }

        }


        function getcallbackcertidata(responseList) {
            $scope.xhr = false;
            if (responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"]) {
                DS_TTT_TIDP_Validate_and_Get_Document_Details = responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"];
                $scope.ori_msg_Custom_Fields.ORI_FORMTITLE = DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value20;
            }
            binddocumentList();
        }

        function binddocumentList() {
            if (DS_TTT_TIDP_Validate_and_Get_Document_Details.length) {
                if (DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value1 == '1') {
                    $scope.validatedocumentFlag = true;
                    $scope.formdata5["DS_SEND_MSG"] = '1|You can not create/update the form.Please verify validation message.';
                    $scope.hideSaveDraftButton();
                }
                else {
                    var objSaveDraftBtn = document.getElementById('btnSaveDraft');
                    $scope.validatedocumentFlag = false;
                    $scope.formdata5["DS_SEND_MSG"] = '0|';
                    setDocumentFormHeaders(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                    setDocumentFormdetails(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                    objSaveDraftBtn && (objSaveDraftBtn.style.display = 'inline-block');
                }
            }
        }
        function onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
        }

        function setDocumentFormHeaders(dsvalidatedocumentdata) {
            //$scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details.Document_Details_Grp.Document_Details = [];
            $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details = [];
            var insertPointparent = $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details,
                strdocumentdet = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    var unique = [];
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();
                        if (strvalidate == "0") {
                            var strheader = dsvalidatedocumentdata[index].Value10.trim() + "|$|" + dsvalidatedocumentdata[index].Value11.trim();
                            unique.push(strheader);
                        }
                    }
                    if (unique.length) {
                        unique = unique.filter(onlyUnique);
                        for (var i = 0; i < unique.length; i++) {
                            var seqnum = unique[i].split('|$|')[0].trim();
                            var seqheader = unique[i].split('|$|')[1].trim();
                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Doc_Form_Details);
                            strdocumentdet.Doc_Form_SeqID = seqnum;
                            strdocumentdet.Doc_Form_SeqHeader = seqheader;
                            insertPointparent.push(strdocumentdet);
                        }
                    }
                }
            }
        }
        function setDocumentFormdetails(dsvalidatedocumentdata) {
            var strdocumentdet = "";
            var seqcount, headerseqold = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();

                        if (strvalidate == "0") {
                            var strheaderseq = dsvalidatedocumentdata[index].Value10.trim()
                            var strheadertitle = dsvalidatedocumentdata[index].Value11.trim();

                            var insertPoint = commonApi._.filter($scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details, function (Obj) {
                                return Obj.Doc_Form_SeqID == strheaderseq && Obj.Doc_Form_SeqHeader == strheadertitle;
                            });

                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Document_Details);
                            if (strheaderseq == headerseqold) {
                                seqcount = seqcount + 1;
                            }
                            else {
                                seqcount = 1;
                            }
                            var checksubseqid = insertPoint[0]['Document_Details_Grp']['Document_Details'][0]['Doc_Form_SubSeqId'];
                            if (checksubseqid == "") {
                                insertPoint[0]['Document_Details_Grp']['Document_Details'] = [];
                            }
                            strdocumentdet.Doc_Form_SubSeqId = strheaderseq + "." + seqcount;
                            strdocumentdet.Doc_Form_Title = dsvalidatedocumentdata[index].Value2;
                            strdocumentdet.Doc_Form_Status = dsvalidatedocumentdata[index].Value4;
                            strdocumentdet.Doc_User_Ref = dsvalidatedocumentdata[index].Value3;
                            strdocumentdet.Doc_Form_Type = dsvalidatedocumentdata[index].Value6;
                            strdocumentdet.Doc_Form_Workspace = dsvalidatedocumentdata[index].Value5;
                            strdocumentdet.Form_ID = dsvalidatedocumentdata[index].Value9;
                            strdocumentdet.Doc_Rev_Link = dsvalidatedocumentdata[index].URL17;
                            strdocumentdet.Doc_Rev_ID = dsvalidatedocumentdata[index].Value12;
                            strdocumentdet.Doc_ID = dsvalidatedocumentdata[index].Value8;
                            strdocumentdet.Doc_Dep_Guid = dsvalidatedocumentdata[index].Value18;
                            if (dsvalidatedocumentdata[index].Value19 != "") {
                                strdocumentdet.Doc_TWEXNET = dsvalidatedocumentdata[index].Value19;
                            }
                            insertPoint[0]['Document_Details_Grp']['Document_Details'].push(strdocumentdet);

                            headerseqold = strheaderseq;
                        }
                    }
                }
            }
        }

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}