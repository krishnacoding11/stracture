
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	function FormController($scope, $element, commonApi, $controller, $window, $timeout, $filter) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});

		$scope.stopAutoSaveDraftTimerFromClientSide();
		angular.element(".export-btn").hide();
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.URL_FIELD = $scope.getValueOfOnLoadData('DS_GET_Form_All_Data_By_FormContent');
		$scope.CurrStage = $scope.oriMsgCustomFields.CurrStage;
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID'),
			DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'),
			DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		
			var timeZoneMap = {
				"Africa/Bangui": "W. Central Africa Standard Time",
				"Africa/Cairo": "Egypt Standard Time",
				"Africa/Casablanca": "Morocco Standard Time",
				"Africa/Harare": "South Africa Standard Time",
				"Africa/Johannesburg": "South Africa Standard Time",
				"Africa/Lagos": "W. Central Africa Standard Time",
				"Africa/Monrovia": "Greenwich Standard Time",
				"Africa/Nairobi": "E. Africa Standard Time",
				"Africa/Windhoek": "Namibia Standard Time",
				"America/Anchorage": "Alaskan Standard Time",
				"America/Argentina/San_Juan": "Argentina Standard Time",
				"America/Asuncion": "Paraguay Standard Time",
				"America/Bahia": "Bahia Standard Time",
				"America/Bogota": "SA Pacific Standard Time",
				"America/Buenos_Aires": "Argentina Standard Time",
				"America/Caracas": "Venezuela Standard Time",
				"America/Cayenne": "SA Eastern Standard Time",
				"America/Chicago": "Central Standard Time",
				"America/Chihuahua": "Mountain Standard Time (Mexico)",
				"America/Cuiaba": "Central Brazilian Standard Time",
				"America/Denver": "Mountain Standard Time",
				"America/Fortaleza": "SA Eastern Standard Time",
				"America/Godthab": "Greenland Standard Time",
				"America/Guatemala": "Central America Standard Time",
				"America/Halifax": "Atlantic Standard Time",
				"America/Puerto_Rico": "Atlantic Standard Time",
				"America/Indianapolis": "US Eastern Standard Time",
				"America/Indiana/Indianapolis": "US Eastern Standard Time",
				"America/La_Paz": "SA Western Standard Time",
				"America/Los_Angeles": "Pacific Standard Time",
				"America/Mexico_City": "Mexico Standard Time",
				"America/Montevideo": "Montevideo Standard Time",
				"America/New_York": "Eastern Standard Time",
				"America/Noronha": "Fernando de Noronha Time",
				"America/Phoenix": "US Mountain Standard Time",
				"America/Regina": "Canada Central Standard Time",
				"America/Santa_Isabel": "Pacific Standard Time (Mexico)",
				"America/Santiago": "Pacific SA Standard Time",
				"America/Sao_Paulo": "Brazil Time",
				"America/St_Johns": "Newfoundland Standard Time",
				"America/Tijuana": "Pacific Standard Time",
				"Antarctica/McMurdo": "New Zealand Standard Time",
				"Atlantic/South_Georgia": "UTC-02",
				"Asia/Almaty": "Central Asia Standard Time",
				"Asia/Amman": "Jordan Standard Time",
				"Asia/Baghdad": "Arabia Standard Time",
				"Asia/Baku": "Azerbaijan Standard Time",
				"Asia/Bangkok": "SE Asia Standard Time",
				"Asia/Beirut": "Middle East Standard Time",
				"Asia/Calcutta": "India Standard Time",
				"Asia/Colombo": "Sri Lanka Standard Time",
				"Asia/Damascus": "Syria Standard Time",
				"Asia/Dhaka": "Bangladesh Standard Time",
				"Asia/Dubai": "Gulf Standard Time",
				"Asia/Irkutsk": "North Asia East Standard Time",
				"Asia/Jerusalem": "Israel Standard Time",
				"Asia/Kabul": "Afghanistan Standard Time",
				"Asia/Kamchatka": "Kamchatka Standard Time",
				"Asia/Karachi": "Pakistan Standard Time",
				"Asia/Katmandu": "Nepal Standard Time",
				"Asia/Kolkata": "India Standard Time",
				"Asia/Krasnoyarsk": "North Asia Standard Time",
				"Asia/Kuala_Lumpur": "Singapore Standard Time",
				"Asia/Kuwait": "Arab Standard Time",
				"Asia/Magadan": "Magadan Standard Time",
				"Asia/Muscat": "Arabian Standard Time",
				"Asia/Novosibirsk": "N. Central Asia Standard Time",
				"Asia/Oral": "West Asia Standard Time",
				"Asia/Rangoon": "Myanmar Standard Time",
				"Asia/Riyadh": "Arab Standard Time",
				"Asia/Seoul": "Korea Standard Time",
				"Asia/Shanghai": "China Standard Time",
				"Asia/Singapore": "Singapore Standard Time",
				"Asia/Saigon": "Indochina Time",
				"Asia/Taipei": "Taipei Standard Time",
				"Asia/Tashkent": "West Asia Standard Time",
				"Asia/Tbilisi": "Georgian Standard Time",
				"Asia/Tehran": "Iran Standard Time",
				"Asia/Tokyo": "Japan Standard Time",
				"Asia/Ulaanbaatar": "Ulaanbaatar Standard Time",
				"Asia/Vladivostok": "Vladivostok Standard Time",
				"Asia/Yakutsk": "Yakutsk Standard Time",
				"Asia/Yekaterinburg": "Ekaterinburg Standard Time",
				"Asia/Yerevan": "Armenian Standard Time",
				"Atlantic/Azores": "Azores Standard Time",
				"Atlantic/Cape_Verde": "Cape Verde Standard Time",
				"Atlantic/Reykjavik": "Greenwich Standard Time",
				"Australia/Adelaide": "Cen. Australia Standard Time",
				"Australia/Brisbane": "E. Australia Standard Time",
				"Australia/Darwin": "AUS Central Standard Time",
				"Australia/Hobart": "Eastern Standard Time (Tasmania)",
				"Australia/Perth": "W. Australia Standard Time",
				"Australia/Sydney": "Eastern Standard Time (New South Wales)",
				"Australia/Canberra": "Eastern Standard Time (New South Wales)",
				"Australia/Melbourne": "AUS Eastern Standard Time",
				"Etc/GMT": "UTC",
				"Etc/GMT+11": "UTC-11",
				"Etc/GMT+12": "Dateline Standard Time",
				"Etc/GMT+2": "UTC-02",
				"Etc/GMT-12": "UTC+12",
				"Europe/Amsterdam": "W. Europe Standard Time",
				"Europe/Athens": "GTB Standard Time",
				"Europe/Belgrade": "Central Europe Standard Time",
				"Europe/Berlin": "W. Europe Standard Time",
				"Europe/Brussels": "Central European Time",
				"Europe/Budapest": "Central Europe Standard Time",
				"Europe/Dublin": "GMT Standard Time",
				"Europe/Helsinki": "FLE Standard Time",
				"Europe/Istanbul": "Eastern European Time",
				"Europe/Kiev": "FLE Standard Time",
				"Europe/London": "GMT Standard Time",
				"Europe/Minsk": "E. Europe Standard Time",
				"Europe/Moscow": "Russian Standard Time",
				"Europe/Paris": "Central European Time",
				"Europe/Sarajevo": "Central European Standard Time",
				"Europe/Warsaw": "Central European Standard Time",
				"Europe/Lisbon": "Western European Time",
				"Indian/Mauritius": "Mauritius Standard Time",
				"Pacific/Apia": "West Samoa Time",
				"Pacific/Auckland": "New Zealand Standard Time",
				"Pacific/Fiji": "Fiji Standard Time",
				"Pacific/Guadalcanal": "Solomon Islands Time",
				"Pacific/Guam": "Chamorro Standard Time",
				"Pacific/Honolulu": "Hawaiian Standard Time",
				"Pacific/Pago_Pago": "Samoa Standard Time",
				"Pacific/Port_Moresby": "Papua New Guinea Time",
				"Pacific/Tongatapu": "Tonga Standard Time",
				"Pacific/Midway": "Samoa Standard Time",
				"Pacific/Enderbury": "Phoenix Is. Time",
				"Pacific/Kiritimati": "Line Islands Standard Time"
			};

		$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		
		if($scope.isOriView){
			var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo'),
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');

			if ($scope.dSFormId == "") {
				$scope.oriMsgCustomFields.ORI_FORMTITLE = "";
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = "";
				$scope.oriMsgCustomFields.Task_Type = "";
				$scope.oriMsgCustomFields.Task_Detail = "";
				$scope.oriMsgCustomFields.Task_Assigned_TO = "";
				$scope.oriMsgCustomFields.Task_Verification_Required = "";
				$scope.oriMsgCustomFields.RaisedOnDate = "";
            }
			setBasicList();
			setClientlogo();
		}
		if($scope.isRespView){
			$scope.CurStatus = $scope.resMsgCustomFields.Task_Status;
			var respList = $scope.myFields.FORM_CUSTOM_FIELDS.respViewList;
			if(respList.length){
				var lastResp = respList[respList.length - 1];
				$scope.resMsgCustomFields.Task_Prev_Status = lastResp.Task_Status;
				$scope.resMsgCustomFields.Task_Prev_Comments = lastResp.Task_Comments;
				$scope.resMsgCustomFields.Task_Prev_Responder = lastResp.Task_Responder;
				$scope.resMsgCustomFields.Task_Prev_Respond_Date = lastResp.Task_Respond_Date;
			}
			$scope.resMsgCustomFields.Task_Status = "";
			$scope.resMsgCustomFields.Task_Comments = "";
			$scope.resMsgCustomFields.Task_Responder = WorkingUserID['0'].Value.trim();
			$scope.isAuthorized = true;
			var actionAvailable = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
				return val.Name.indexOf('Respond') > -1 && val.Value.indexOf($scope.currentUserid) != -1;
			});
			if(!actionAvailable.length){
				$scope.isAuthorized = false;
			}
		}

		function setBasicList(){
			$scope.projUserList = commonApi.getItemSelectionList({
				arrayObject: projAllRolesList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
		}

		function setClientlogo() {
            if (WorkingUserID.length) {
                var strOrgName = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
		}

		function getDateTimeFromZone() {
			var userTimeZone = timeZoneMap[$window.USP.timezoneId];
			var serverDatemilisec = new Date($scope.serverDate).getTime();
			var utcActualTime = serverDatemilisec - 3600000;
			var offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
			var nd = new Date(parseInt(utcActualTime) + parseInt(offset));
			nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
			return nd + " " + userTimeZone;
		}

		function getDateFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}
		
		function setORIWorkFLow() {
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			$scope.oriMsgCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
            var tempList = [];
			var AssignedTo = $scope.oriMsgCustomFields.Task_Assigned_TO;
			$scope.oriMsgCustomFields.LastReviewer = WorkingUserID['0'].Value.trim();
			$scope.oriMsgCustomFields.CurrStage = 2;
            if (AssignedTo) {
                var distDate = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE;

                tempList.push({
                    strUser: AssignedTo.split('|')[2].trim(),
                    strAction: '3#Respond',
                    strDate: distDate
                });

                commonApi.setDistributionNode({
                    actionNodeList: tempList,
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: 3
				});
				setFormStatus('open');
            }
		}
		
		function setRESPWorkFLow(){
			if($scope.oriMsgCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users.length){
				$scope.oriMsgCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
			}
			var lastReviewer = $scope.oriMsgCustomFields.LastReviewer ? $scope.oriMsgCustomFields.LastReviewer.split('|')[0].trim() : "";
			var lastResolver = $scope.oriMsgCustomFields.LastResolver ? $scope.oriMsgCustomFields.LastResolver.split('|')[0].trim() : "";
			var distDate = commonApi.calculateDistDateFromDays({ baseDate: getDateFromZone() , days: 7 });
			if($scope.oriMsgCustomFields.CurrStage == 2){
				$scope.oriMsgCustomFields.CurrStage = 3;
			}else{
				$scope.oriMsgCustomFields.CurrStage = 2;
			}
			if($scope.oriMsgCustomFields.Task_Verification_Required.toLowerCase() == 'yes'){
				if($scope.resMsgCustomFields.Task_Status.toLowerCase() == 'approved'){
					$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
					setDistribution(lastResolver, '7#For Information', 13, '');
					setFormStatus('closed');
				}
				if($scope.resMsgCustomFields.Task_Status.toLowerCase() == 'resubmit'){
					setDistribution(lastResolver, '3#Respond', 13, distDate);
					$scope.oriMsgCustomFields.LastReviewer = WorkingUserID['0'].Value.trim();
					setFormStatus('resubmit');
				}
				if($scope.resMsgCustomFields.Task_Status.toLowerCase() == 'completed'){
					setDistribution(lastReviewer, '3#Respond', 13, distDate);
					setFormStatus('completed');
					$scope.oriMsgCustomFields.LastResolver = WorkingUserID['0'].Value.trim();
				}
			}else{
				if($scope.resMsgCustomFields.Task_Status.toLowerCase() == 'completed'){
					$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
					setDistribution(lastReviewer, '7#For Information', 13, '');
					setFormStatus('closed');
				}
			}
		}

		function setDistribution(UsertoDist, Action, DS_AUTODist, strDate){
			var tempList = [];
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

			tempList.push({
				strUser: UsertoDist,
				strAction: Action,
				strDate: strDate
			});

			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODist
			});
		}

		function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {             
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		}

		$scope.update();

		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView){
				if(!$scope.submitFlag){
					$scope.getServerTime(function (serverDate) { //latttest timeand date of uk
						$scope.serverDate = serverDate;
						$scope.submitFlag = true;
						$window.submitForm(1);
					});
					return true;
				}
				$scope.oriMsgCustomFields.Task_Type = "AD-HOC";
				$scope.oriMsgCustomFields.RaisedOnDate = getDateTimeFromZone();
				setORIWorkFLow();
			}
			if($scope.isRespView){
				if(!$scope.isAuthorized){
					alert('You are not authorized to Respond');
					return true;
				}
				$scope.resMsgCustomFields.Task_Respond_Date = getDateFromZone();
				setRESPWorkFLow();
				$scope.myFields.FORM_CUSTOM_FIELDS.respViewList.push(angular.copy($scope.resMsgCustomFields));
			}
			return false;
		};

		$window.draftSubmitCallBack = function () {
			return false;
		};
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}