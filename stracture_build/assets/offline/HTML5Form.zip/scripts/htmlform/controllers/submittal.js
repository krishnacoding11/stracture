/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var tempData = $scope.getFormData();

        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });
        $scope.isDataLoaded = true;
		$scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.ORI_MSG_Fields = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields;
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
		$scope.msgid = $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_MSGCREATOR;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.Client_Logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});
		$scope.Client_Logo =$scope.Client_Logo[0].Value8;
		//console.log($scope.Client_Logo);
		$scope.formCustomFields.Client_Logo = $scope.Client_Logo;
        $scope.Packages = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'Package' && val.Value11.indexOf('Active') != -1
        });
		//console.log($scope.Packages);
		$scope.Reasons = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
				return val.Value3 == 'Reason' && val.Value11.indexOf('Active') != -1
		});		
		//console.log($scope.Reasons);
        $scope.allAttchment = $scope.getValueOfOnLoadData('DS_DOC_ATTACHMENTS_ALL');
        $scope.allAssoc = $scope.getValueOfOnLoadData('DS_DOC_ASSOCIATIONS_ALL_MSG');
		//$scope.msgid = $scope.getValueOfOnLoadData('DS_MSGID');
       

		$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
			$scope.STATIC_OBJ_DATA = {
			 Responses: {
              RFI_ResponseBy: "",
			  RFI_Response: "",
			  RFI_ResponseDate: "",
			  Response_Is: "New"
            }
		}
		
/* 		$scope.docs = $scope.formCustomFields.docs || [];
		  $window.updateDocsDetailsInXSN = function () {
			getDefinedValueFromAssocDoc();
		 }
	function getDefinedValueFromAssocDoc() {
		var tmpArray = null;
		console.log($window.assocDocsObj);
		if($window.assocDocsObj){
		for (var i = 0; i < $window.assocDocsObj.length; i++) {
		tmpArray = $window.assocDocsObj[i];
		singleDeleteButtonClicked((tmpArray.revisionId && tmpArray.revisionId.split('$$')[0])); //remove if exist
		$scope.docs.push({
			uploadFilename: tmpArray.uploadFilename || tmpArray.fileName || '',
			docRef: (tmpArray.isPrivate == true ? tmpArray.docRef.split('#')[0] : tmpArray.docRef) || '',
			docTitle: (tmpArray.title) || '',
			revisionId: (tmpArray.revisionId && tmpArray.revisionId.split('$$')[0]) || '',
			revisionNum: (tmpArray.revisionNum) || '',
			publishDate : tmpArray.publishDate ? tmpArray.publishDate.split('#')[0] : '',
			allinfo:JSON.parse(JSON.stringify(tmpArray)),
			});
		}
		$scope.formCustomFields.docs=$scope.docs;
		console.log($scope.docs);
		}
		}
		
     $window.removeDocsDetailsFromXSN = function (delRowRevId, delAllFlag) {
     	if (!delAllFlag) {
     		var tmpJsonStr = singleDeleteButtonClicked(delRowRevId);
     	} else {
     		$scope.docs = [];
			$scope.formCustomFields.docs=$scope.docs;
     	}
     }

		function singleDeleteButtonClicked(delRowRevId) {
			var currDelRowRevID = delRowRevId.split('$$')[0];
			console.log(currDelRowRevID);
			console.log(delRowRevId);
			for (var i = 0; i < $scope.docs.length; i++) {
				if ($scope.docs[i].revisionId == currDelRowRevID) {
					$scope.docs.splice(i, 1);
				}
			}
			$scope.formCustomFields.docs=$scope.docs;
		} */

        
       $scope.getServerTime(function (serverDate) {
		   $scope.curdate=$scope.formatDate(new Date(serverDate), 'yy-mm-dd');
	   });
	   $scope.curuser=WorkingUserID['0'].Value.trim();
	   
	   
	   
        $window.submitalFinalCallBack = function () {

            if ($scope.submitFlag) {
                return false;
            }
              console.log($scope.strFormId);
            if (currentViewName == "ORI_VIEW") {
             $scope.submitFlag = true;
             $window.submitForm(1);
			 
            } 
			if (currentViewName == "RES_VIEW") {
				   if (WorkingUserID) {
					   $scope.resMsgCustomFields.RESPONSES.RFI_ResponseBy = WorkingUserID['0'].Value.trim();
					   $scope.getServerTime(function (serverDate) {
						   
						var insertPoint = $scope.resMsgCustomFields.RESPONSES;
						for (var index = 0; index < insertPoint.length; index++) {
							insertPoint[index].Response_Is = "Old";
							if(index==insertPoint.length-1)
							{
							 insertPoint[index].RFI_ResponseBy =  WorkingUserID['0'].Value.trim();
							 insertPoint[index].RFI_ResponseDate =  $scope.formatDate(new Date(serverDate), 'yy-mm-dd');	
							}
						}
						$element.removeClass('loaded');
						var structResponses = angular.copy($scope.STATIC_OBJ_DATA.Responses);
						structResponses.Response_Is="New";
						insertPoint.push(structResponses);
						
						
						$scope.submitFlag = true;
						$window.submitForm(1);
                });
            }
         
            }
			
            return true;
        }
		$scope.update();
    };
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof submitalFinalCallBack !== "undefined") {
        return submitalFinalCallBack();
    }
}