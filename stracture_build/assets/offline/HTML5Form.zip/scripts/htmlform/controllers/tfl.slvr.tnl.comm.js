/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		var ctrl = this;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
		$scope.commUserRolesList = $scope.oriMsgCustomFields.commUserRolesList;
		$scope.commReferenceClauses = $scope.oriMsgCustomFields.commReferenceClauses;
		$scope.commExternalReference = $scope.oriMsgCustomFields.commExternalReference;		
		$scope.rolesList = [];
		$scope.tempToUsersList = [];
		$scope.tempCopyToUsersList = [];
		$scope.rfcList = [];
		$scope.formStatusList = [];
		$scope.contractNoList = [];
		$scope.contractNameList = [];
		$scope.referenceClausesList = [];
		$scope.allRespMsgList = [];
		$scope.isOriView = (currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (currentViewName == 'RES_VIEW');
		$scope.isRespPrintView = (currentViewName == 'RES_PRINT_VIEW');
		$scope.xhr = {
			guIdXhr: false,
			platformXhr: false
		};
		
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			selectedRoles = {
				toList : [],
				copyToList : []
			},	fieldNameKeyMap = {
				'to-role': 'toList',
				'copy-to-role': 'copyToList'
			},	listNameKeyMap = {
				'to-role' : 'toRole',
				'copy-to-role' : 'copyToRole',
			},	userListKeyMap = {
				'to-role' : 'toUsersStr',
				'copy-to-role' : 'copyToUsersStr',
			}, 	tempListKeyMap = {
				'to-role' : 'tempToUsersList',
				'copy-to-role' : 'tempCopyToUsersList'
			}, 	strKeyRevMap = {
				'to-role-users' : 'to-role',
				'copy-to-role-users' : 'copy-to-role'	
			};

		$scope.serverDate = "";
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.userFormatedDate = "";
		$scope.getServerTime(function (serverDate) {			
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		$scope.noAccessToPerform = false;

		// to get Custom Attribute On Load.
		var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
			logo = commonApi._.findWhere(customAttr, {
				Value3: "LOGO",
				Value7: "LOGO"
			}) || {},
			allRoleUsersList = [],			
			allUsersList = [],
			allRolesList = [],
			configAttributesList = [],
			incompletedActionList = [],			
			availFormStatuses = [],			
			contractData = [],
			workingUserObj = {},
			formActionDays = {},
			contDataList = [],
			strRespondDays = '',			
			_5_Form_Data = $scope.Asite_System_Data_Read_Only['_5_Form_Data'];
		$scope.Logo = logo.Value8 || '/images/asiteWhite60x200.png';
		
		/**All Common functions will be start from here */
		

		/**
		* Value22 contains selected actions and it's days from the form Setting
		**/ 
		var setFormSettingActionDays = function (formsSettings) {			
			var allActions = formsSettings.Value22.split(':')[1],
				actionsList = allActions.split(','),
				actionSplited = '';
			for(var i=0; i<actionsList.length; i++) {
				actionSplited = actionsList[i].split('|');
				formActionDays[actionSplited[0]] = actionSplited[1];
			}
			// default value for Respond action set 3 as per decision.
			strRespondDays = formActionDays['Respond'] || 3;
		};

		var setIncompleteAction = function () {						
			workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
			incompletedActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');			
			// set working user Id.
			$scope.workingUserId = workingUserObj.Value.split('|')[0].trim() ||'';
		};

		var getSetSPValues = function() {
			allRoleUsersList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			allUsersList = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
			allRolesList = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES');
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');			
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');			
			contractData = $scope.getValueOfOnLoadData('DS_STT_BL_NNEC_NEC_ORG_CONTRACT');
			setFormSettingActionDays($scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails')[0]);

			// from Replated Flags's values
			isDraft = _5_Form_Data["DS_ISDRAFT"];
			isEditOriDraft = _5_Form_Data["DS_ISDRAFT_EDITORI"];
			isResMsgDraft = _5_Form_Data["DS_ISDRAFT_FWD_MSG"];            
			isRespDraft = _5_Form_Data["DS_ISDRAFT_RES"];
			isRespMsgDraft = _5_Form_Data["DS_ISDRAFT_RES_MSG"];
		};

		var checkUserHasAction = function(userId, strActionName) {
            if(incompletedActionList.length) {                
				var splitedVal = '',
	                incompleteActionObj = commonApi._.find(incompletedActionList, function(obj) {					
						splitedVal = obj.Value.split('#');
						return splitedVal[0].trim().indexOf(userId)>-1 && splitedVal[1].trim() == strActionName;
					}) || {};

                if(incompleteActionObj.Value) {
                    return true;
                }
            } else if(!incompletedActionList.length && ($scope.dSFormId == "")) {
				return true;
            }
            return false;
		};
				
		var structureItemList = function(setFor, availList) {    			
			var tempList=[],
				optlabel = '';  				
			switch (setFor) {
				case 'role-list':
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Name, 							
							modelValue:  item.Value					
						});	
					});
					optlabel = 'Roles list';
					break;
				case 'user-list':
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Name.split(',')[0].trim(),                         
							modelValue:  item.Value					
						});	
					});
					optlabel = 'Users list';
					break;
				case 'rfc-list':
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Value8,                         
							modelValue:  item.Value7 + '#' + item.Value8
						});	
					});
					optlabel = 'Reason For Communication list';
					break;
				case 'status-list':
						angular.forEach(availList, function(item){
							tempList.push({
								displayValue: item.Name,
								modelValue:  item.Value
							});	
						});
						optlabel = 'Form Status list';
						break;
				case 'ref-clauses-list':					
					angular.forEach(availList, function(item){
						tempList.push({							
							displayValue: item.displayValue,                         
							modelValue:  item.modelValue + '|' + item.displayValue
						});	
					});
					optlabel = 'Clauses list';
					break;
				case 'contract-no-list':
				case 'contract-name-list':
					var splitedArray = [],
						formAppBuildCode = "",
						formCode = "",
						formDiscription = "",
						displayName = "";
					angular.forEach(availList, function(item){
						splitedArray = item.split('|');
						formAppBuildCode = splitedArray[0].trim();
						formCode = splitedArray[2].trim();
						formDiscription = splitedArray[splitedArray.length-1].trim();
						displayName = setFor == 'contract-no-list' ? formCode : formDiscription;
						tempList.push({
							displayValue: displayName, 
							modelValue: formCode + '|' + formAppBuildCode + '|' + formDiscription
						});	
					});
					optlabel = 'Available Contracts';
					break;
			}             	

			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};	
		
		var updateContractLists = function (isContNoUpdate, isContNameUpdate) {
			// contract No List	 &&  contract Name List			
			if(isContNoUpdate){
				$scope.contractNoList = structureItemList('contract-no-list', contDataList);
			} 

			if(isContNameUpdate){
				$scope.contractNameList = structureItemList('contract-name-list', contDataList);
			} 
		};	

		var setUpdateBindSPData = function () {			
			// Prepare list and bind it for html template
			$scope.rolesList = structureItemList('role-list', allRolesList);
			$scope.rfcList = structureItemList('rfc-list', configAttributesList.filter(function(attrObj) {
				return attrObj.Value3.toLowerCase() == 'reason for communication' && attrObj.Value11 == 'Active';
			}));
			// form Status' List 
			$scope.formStatusList = structureItemList('status-list', availFormStatuses);
			contDataList = contractData.map(function(contObj) {
				return contObj.Value1;
			});			
			// set both list for update
			updateContractLists(true, true);

			//Dummy data for Reference Clauses as other form changes is pending from other developer.			
			$scope.referenceClausesList = structureItemList('ref-clauses-list', [{
				displayValue : 'Clause-1',
				modelValue : '0001'
			},{
				displayValue : 'Clause-2',
				modelValue : '0002'
			},{
				displayValue : 'Clause-3',
				modelValue : '0003'
			},{
				displayValue : 'Clause-4',
				modelValue : '0004'
			},{
				displayValue : 'Clause-5',
				modelValue : '0005'
			},{
				displayValue : 'Clause-6',
				modelValue : '0006'
			},{
				displayValue : 'Clause-7',
				modelValue : '0007'
			},{
				displayValue : 'Clause-8',
				modelValue : '0008'
			},{
				displayValue : 'Clause-9',
				modelValue : '0009'
			},{
				displayValue : 'Clause-10',
				modelValue : '0010'
			}]);
			
		};
		
		var setUsersOnRoleSelection = function (forField, index, roleName) {		
			if(roleName) {
				roleName = roleName.split('#')[0].trim();
				$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allRoleUsersList.filter(function(userRoleObj){
					return userRoleObj.Value.indexOf(roleName) > -1
				}));
			} else {
				$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allUsersList);	
			}
			// Prepare list and bind it for html template
			$scope.rolesList = structureItemList('role-list', allRolesList);			
		};
		
		var checkAndSetSelectedRoleExist = function (forField, index, roleName) {
			var currList = selectedRoles[fieldNameKeyMap[forField]],
				currIndex = currList.indexOf(roleName);
			if(roleName && currList.length && currIndex != index && currIndex > -1) {
				Notification.warning({
					title: "Role is Already Selected.",
					message: "You can not select already selected Role again."
				});	
				selectedRoles[fieldNameKeyMap[forField]][index] = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][userListKeyMap[forField]] = '';
				$scope[tempListKeyMap[forField]][index] = [];				
				// Prepare list and bind it for html template
				$scope.rolesList = structureItemList('role-list', allRolesList);
			} else {
				selectedRoles[fieldNameKeyMap[forField]][index] = roleName;
				setUsersOnRoleSelection(forField, index, roleName);
			}
		};

		/**
		 *  All Needed ORI functions will be initiated form here if user has action or user creating it for the first time.
		 * 	Else 'noAccessToPerform' flag will be set to true that will not allow any user perform action.
		 */
		var setOriResViewBase = function () {
			setIncompleteAction();
			if(checkUserHasAction($scope.workingUserId, 'Respond')) {
				getSetSPValues();
				setUpdateBindSPData();				
				$scope.oriMsgCustomFields.commFormName = $scope.Asite_System_Data_Read_Only['_4_Form_Type_Data']['DS_FORMNAME'];
				$scope.oriMsgCustomFields.commWorkspaceName = $scope.Asite_System_Data_Read_Only['_3_Project_Data']['DS_PROJECTNAME'];	
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']["DS_SEND_MSG"] = "0";
				if($scope.isRespView) {
					var keyNames = ['to-role','copy-to-role'],
						currNodeNameStr = '',
						currList = [],
						currObj = {};	
					for(var i=0; i<keyNames.length; i++) {
						currNodeNameStr = keyNames[i];
						currList = $scope.commUserRolesList[fieldNameKeyMap[currNodeNameStr]];
						for(var k=0; k<currList.length; k++) {
							currObj = currList[k];
							for(var j=0; j<currObj[[userListKeyMap[currNodeNameStr]]].length ; j++) {
								// passing K as it's row's index
								setUsersOnRoleSelection(currNodeNameStr, k, currObj[listNameKeyMap[currNodeNameStr]].split('#')[0].trim());
							}
						}
					}
					// As Per Discussion Flushing Out commResponse field for response
					$scope.oriMsgCustomFields.commResponse = '';
				} else if($scope.isOriView) {
					// for the first time Initializing the Array.
					setUsersOnRoleSelection('to-role', 0, '');
					setUsersOnRoleSelection('copy-to-role', 0, '');
				}
			} else {
				$scope.noAccessToPerform = true;				
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not authorised to respond this form. You therefore cannot respond, please click the cancel button at the bottom of the form.";
			}
		};

		var setPrintViewBase = function() {
			$scope.allRespMsgList = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
		};

		/**All Common functions will be End from here */

		$scope.insertNewItems = function (addToList, insertFor) { 
			var newObj = {};
			switch(insertFor) {
				case 'to-role-users':
					newObj = {
						toRole : '',
						toUsersStr : []
					};
					break;
				case 'copy-to-role-users':
					newObj = {
						copyToRole : '',
						copyToUsersStr : []
					};
					break;					
				case 'reference-clauses':
					newObj = {
						clauseName : "",
						clauseValue: ""
					};
					break;
				case 'external-reference':
					newObj = {
						refValue : ""
					};
					break;
			}
			//Add item in items
			$scope.addRepeatingRow(addToList, newObj);   
			if(insertFor == 'to-role-users' || insertFor == 'copy-to-role-users') {
				setUsersOnRoleSelection(strKeyRevMap[insertFor], addToList.length-1, '');
			} 
		};

		$scope.removeItem = function(index, list, forField) {
			if(forField) {
				$scope[tempListKeyMap[forField]][index] = [];
				selectedRoles[fieldNameKeyMap[forField]].splice(index, 1);
			}
			list.splice(index, 1);
		};

		$scope.resetRow = function(forField, index){
			$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = "";
			$scope.changeItemSelectionEvent(forField, index)
		};

		// common item selection modal End
		var contractNameNoFieldUpdate = function (forField) {
			var contractNoSplitted = $scope.oriMsgCustomFields.commContractNo.split('|');
			$scope.oriMsgCustomFields.commContractData = commonApi._.find(function(contObj){
				return contObj.Value1.split('|')[0].trim() == contractNoSplitted[1];
			});
			if(forField == 'contract-no') {
				// updateList accordingly.			
				$scope.oriMsgCustomFields.commContractName = $scope.oriMsgCustomFields.commContractNo;
				updateContractLists(false, true);
			} else {
				// updateList accordingly.			
				$scope.oriMsgCustomFields.commContractNo = $scope.oriMsgCustomFields.commContractName;
				updateContractLists(true, false);
			}
			$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_FORMCONTENT1'] = contractNoSplitted[1];
		};

		$scope.changeItemSelectionEvent = function (forField, index) {
			switch(forField) {
				case 'to-role':								
				case 'copy-to-role':					
					var roleName = $scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]];
					checkAndSetSelectedRoleExist(forField, index, roleName);
					break;				
				case 'contract-no':
				case 'contract-name':
					contractNameNoFieldUpdate(forField);
					break;
			}
		};

		/**
		* Form's workflow logic		
		*/

		var setWorkflow = function() {            
			var allListName = ['toList', 'copyToList'],
				currNodeName = "",
				tempList = [],
				tempNodeObj = {},
				childNodeObj = {},
				strRespActionDate = commonApi.calculateDistDateFromDays({
					baseDate: $scope.serverDate,
					days : parseInt(strRespondDays)
				}),
				autoDistNodeVal = $scope.isRespView ? '13' : '3';
			for (var i =0; i<allListName.length; i++) {			
				currNodeName = allListName[i];
				tempNodeObj = $scope.commUserRolesList[currNodeName];
				for(var j =0; j<tempNodeObj.length; j++) {
					childNodeObj = tempNodeObj[j];
					if(currNodeName == 'toList') {						
						for(var k=0; k<childNodeObj.toUsersStr.length; k++) {							
							tempList.push({
								strUser : childNodeObj.toUsersStr[k].indexOf('|') > -1 ? childNodeObj.toUsersStr[k].split('|')[2].trim() : childNodeObj.toUsersStr[k],
								strAction : "3#Respond",
								strDate : strRespActionDate
							});
						}
					} else {
						for(var k=0; k<childNodeObj.copyToUsersStr.length; k++) {
							tempList.push({
								strUser : childNodeObj.copyToUsersStr[k].indexOf('|') > -1 ? childNodeObj.copyToUsersStr[k].split('|')[2].trim() : childNodeObj.copyToUsersStr[k],
								strAction : "7#For Information",
								strDate : ""             
							});
						}
					}
				}
			}
			$scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = []; 
			// Distribution Will be made from here
			commonApi.setDistributionNode({
				actionNodeList : tempList,
				autoDistributeUsers : $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users,				
				asiteSystemDataReadWrite: $scope.Asite_System_Data_Read_Write,
				DS_AUTODISTRIBUTE : autoDistNodeVal
			});

			// Form's Staus will be set from below code.
			var strFormStatusId = commonApi.getFormStatusId({
				availFormStatusesList : availFormStatuses,
				strStatus : $scope.oriMsgCustomFields.commFormStatus.split('#')[1].trim()
			});
			if (strFormStatusId) {             
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
			// Form Title Set from here
			$scope.oriMsgCustomFields['ORI_FORMTITLE'] = $scope.oriMsgCustomFields.commSubject;
		};

		if ($scope.isOriView || $scope.isRespView) {
			setOriResViewBase();
		} else if ($scope.isOriPrintView || $scope.isRespPrintView) {
			setPrintViewBase();
		}

		
	    $scope.isCallForDraft = false;
		var formSubmitCallBack = function () {
			!$scope.isCallForDraft && setWorkflow();
			return false;
		};
		
		$scope.update();

		$window.oriformSubmitCallBack = function() {			
			formSubmitCallBack();
		};

		$window.respformSubmitCallBack = function() {			
			formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {            
            $scope.isCallForDraft = true;
            formSubmitCallBack();
        }
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {		
		return oriformSubmitCallBack();
	} 
}

function customHTMLMethodBeforeCreate_RES() {
	if (typeof respformSubmitCallBack !== "undefined") {		
		return respformSubmitCallBack();
	} 
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}