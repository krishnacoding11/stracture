/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './upload', 'mainModule'], function(angular, uploadController, mainModule) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window) {
		var ctrl = this;

		$scope.items = [{
			name: 'a'
		}, {
			name: 'b'
		}, {
			name: 'c'
		}];

		$controller(uploadController, {
			$scope: $scope,
			$element: $element
		});

	}

	return FormController;
});