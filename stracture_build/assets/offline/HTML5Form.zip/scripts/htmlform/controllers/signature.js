/**
 * Base Controller module.
 * This module will return Base Controller.
 * @module Base-Controller
 */

window.getJSONData = function() {};
window.getTemplateJSONData = function() {};
define(['angular', './base', '../components/signature'], function(angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Base-Controller/BaseController
	 * Example: <asite-signature width="600px" parent="data" key="sigData" disable="true"></asite-signature>
	 */
	function SignatureController($scope, $element, $controller, $window, commonApi, $q, $httpParamSerializer, $timeout) {

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.loaded = true;
		$element.addClass('loaded');
		
		$scope.data = {};

		var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }
	}

	return SignatureController;
});
