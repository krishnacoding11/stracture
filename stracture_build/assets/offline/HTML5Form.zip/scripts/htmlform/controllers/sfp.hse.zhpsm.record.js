/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/signature', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		var ctrl = this;

		// restrict autosave Draft and hide Save Draft button.		
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
		$scope.xhr = {
			guIdXhr: false,
			platformXhr: false
		};

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",			
			_5_Form_Data = $scope.asiteSystemDataReadOnly['_5_Form_Data'],
			isDraft = (_5_Form_Data.DS_ISDRAFT.toLowerCase() == 'yes'),			
			STATIC_OBJ = {
				CONFIG_JSON : [],
				hazardIdentification: {
					criticalRisksList: [],
					highRiskActivitiesList: {
						firstList: [],
                        secondList: []
					},
					environmentalRisksList: []
				},
				siteSpecificRequirements: {
					requirementsList: []
				},
				risksListObj: {
					riskName: '',
					isRiskSelected: false
				},
				shiftActivitiesObj: {
					activityItem: '',
					activitySeqNo: '',
					activityGuId: '',
					activityNameToBeUndertaken: '',
					isActivityShow: ''
				},
				siteSpecificHazardsObj: {
					hazardItem: '',
					hazardSeqNo: '',
					hazardGuId: '',
					hazardNotCovered: '',
					hazardControls: '',
					isHazardShow: ''
				}, requirementsObj: {
					reqItem: '',
					reqSeqNo: '',
					reqItemName: '',
					reqItemValue: '',
					reqItemNote: '',
					isReqItemShow: '',
					isDefaultReq: false
				}, meetingAttendeesObj: {
					attendeeName: '',
					attendeeSignature: ''
				},
				firstAidOfficers : {
					officerName : ""
				},
				attachmentObj : {
					attachedDoc : ""
				},
				worksiteAttachments : {
					attachedDoc : "",
					attachmentComment : ""
				}
			},
			insertItemKeyObjMap = {
				'shift-activities' : STATIC_OBJ.shiftActivitiesObj,
				'specific-hazards' : STATIC_OBJ.siteSpecificHazardsObj,
				'specific-requirement' : STATIC_OBJ.requirementsObj,
				'meeting-attendee' : STATIC_OBJ.meetingAttendeesObj,
				'first-aid-officers' : STATIC_OBJ.firstAidOfficers,
				'attachmentObj' : STATIC_OBJ.attachmentObj,
				'worksiteAttachments' : STATIC_OBJ.worksiteAttachments
			};

		$scope.userDateFormat = userDateFormat;
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			var serverDateObj = new Date(serverDate);
			$scope.todayDateDbFormat = $scope.formatDate(serverDateObj, 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(serverDateObj, 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(serverDateObj, userDateFormat);
			$scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields']['preMeetingRecord']['serverDateObj'] = serverDateObj;
		});
		$scope.Logo = '/images/htmlform/sfp/sfpjv-logo.png';
		$scope.oriMsgCustomFields.DS_Logo = $scope.Logo;
		$scope.oriMsgCustomFields.isDefaultLogo = true;
		// 24 hours Format	
		$scope.regFortime12hr = /((1[0-2]|0?[1-9]):([0-5][0-9]) ?([AaPp][Mm]))/g;
		$scope.isRiskSelectedFound = false;		

		/**All Common functions will be start from here */
		
		var setallLists = function () {
			$scope.preMeetingRecord = $scope.oriMsgCustomFields.preMeetingRecord;
			$scope.generalDetails = $scope.preMeetingRecord.generalDetails;
			$scope.hazardIdentification = $scope.preMeetingRecord.hazardIdentification;
			$scope.shiftActivities = $scope.preMeetingRecord.shiftActivities;
			$scope.siteSpecificHazards = $scope.preMeetingRecord.siteSpecificHazards;
			$scope.worksiteDiagram = $scope.preMeetingRecord.worksiteDiagram;
			$scope.siteSpecificRequirements = $scope.preMeetingRecord.siteSpecificRequirements;
			$scope.meetingAttendees = $scope.preMeetingRecord.meetingAttendees;
		};

		var setOriViewBase = function () {
			setallLists();
			$timeout(function () {	
				// get system's date time Object.
				var serverDateObj = new Date();
				if(!$scope.generalDetails.meetingDate){
					$scope.generalDetails.meetingDate = $scope.formatDate(serverDateObj, 'yy-mm-dd');
				}
				// set Inductee and Inductor's Date prepopulated.		
				if(!$scope.generalDetails.meetingTime){
					$scope.generalDetails.meetingTime = serverDateObj.toLocaleTimeString('en-au', {hour:"2-digit",minute:"2-digit"}).replace(/[^ -~]/g,'');
				}
			}, 1000);

			// add first node.			
			if(!$scope.generalDetails.firstAidOfficers.length) {
				$scope.insertNewItems($scope.generalDetails.firstAidOfficers, 'first-aid-officers');
			}
		};

		var setOriPrintViewBase = function() {
			setallLists();
		};

		/**
		 * Get Onload config data
		 */
		var loadConfig = function () {
			$scope.xhr.platformXhr = true;					
			$scope.loadConfig(function () {					
				// set default available config data to reset fields purpose.
				STATIC_OBJ.CONFIG_JSON = angular.copy($scope.data.config);
				if(!isDraft){					
					$scope.oriMsgCustomFields.preMeetingRecord.hazardIdentification = angular.copy(STATIC_OBJ.CONFIG_JSON['hazardIdentification']) || STATIC_OBJ.hazardIdentification;
					$scope.oriMsgCustomFields.preMeetingRecord.siteSpecificRequirements = angular.copy(STATIC_OBJ.CONFIG_JSON['siteSpecificRequirements']) || STATIC_OBJ.siteSpecificRequirements;
				}			
				setOriViewBase();
				$scope.isConfigDataNotAvail = false;
				$scope.xhr.platformXhr = false;
			},	function(xhr) {
				$scope.isConfigDataNotAvail = true;
				$scope.xhr.platformXhr = false;
				Notification.error({
					title: 'Server Error While Fetching Data',
					message: 'Error while fetching config data!!'
				});
				// set Save and Save Draft button to hide if config data is not available.									
				angular.element('#btnSaveForm').hide();
				angular.element('#btnSaveDraft').hide();
			});
		};

		/**
		* Form's workflow logic		
		*/

		var isFormCustomValid = function () {
			if(!$scope.generalDetails.siteMapCompleted || $scope.generalDetails.siteMapCompleted == 'no' || !$scope.generalDetails.authorisedToWork || $scope.generalDetails.authorisedToWork == 'no' ) {
				Notification.warning({
					title: "Field's value is not as expected.",
					message: "1.Site map completed? <i>(see section 6)</i> And 2.Are all personnel authorised to work on site? <p>Both fields value must be Yes to continue further process.</p>"
				});				
				return false;
			}

			var firstRowObj = $scope.siteSpecificRequirements.requirementsList[0];
			if($scope.isRiskSelectedFound && firstRowObj &&  firstRowObj.reqItemValue != 'yes') {
				Notification.warning({
					title: "Field's value is not as expected.",
					message: "<p>if you have selected any Risk from <b>SECTION 2</b> below field value must be selected <b>'Yes'</b><p>" + firstRowObj.reqItemName + "</p>Please check.!!!"
				});
				return false;
			}

			return true;
		};

		var setFormWorkflow = function () {
			// Form Title Set from here
			$scope.oriMsgCustomFields['ORI_FORMTITLE'] = $scope.oriMsgCustomFields.commSubject;
			// set Date to Show on the Print Views.
			$scope.oriMsgCustomFields['formCreatedServerDate'] = $scope.serverDate;
			// remove config data not needed.
			delete $scope.data.config;
		};

		$scope.insertNewItems = function (addToList, insertFor) {
			var newObj = angular.copy(insertItemKeyObjMap[insertFor]);
			//Add item in items
			$scope.addRepeatingRow(addToList, newObj);
		};

		$scope.removeItem = function (index, list) {
			list.splice(index, 1);
		};

		// to reset attachment
		$scope.resetAttachment = function(queObj, resetFor) {			
			queObj[resetFor] = [{attachedDoc: ""}];
		};

		/**
		 * this function is seprate to remove inline attachment.
		 */
		$scope.deleteAttchmentItem = function (obj, repeatingData) {
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
		};

		var setIsRiskSelectedFlag = function(objectToCheck) {
			for (var key in objectToCheck) {
				// skip loop if the property is from prototype
				if (!objectToCheck.hasOwnProperty(key)) continue;			
				var obj = objectToCheck[key];
				if(obj.length) {
					for (var i=0; i<obj.length; i++) {
						if(obj[i].isRiskSelected){
							$scope.isRiskSelectedFound = true;
							break;
						}
					}
				} else {
					setIsRiskSelectedFlag(obj);
				}
								
				if($scope.isRiskSelectedFound){					
					break;
				}
			}
		};

		$scope.riskChangeEvent = function(isRiskSelected) {	
			$scope.isRiskSelectedFound = false;
			setIsRiskSelectedFlag($scope.hazardIdentification);
		};

		$scope.setAllowAttachmentFlag = function(index, reqItemValue) {
			if(index == 0 && reqItemValue == 'yes') {
				$scope.siteSpecificRequirements.requirementsList[0].isAttachmentAllowed = true;
			} else if(index == 0 && reqItemValue == 'no') {
				$scope.siteSpecificRequirements.requirementsList[0].reqAttachments = [{
					"attachedDoc": ""
				}];
				$scope.siteSpecificRequirements.requirementsList[0].isAttachmentAllowed = false;
			}		
		};

		if ($scope.isOriView) {			
			loadConfig();			
		} else if ($scope.isOriPrintView) {
			setOriPrintViewBase();
		}

		$scope.isCallForDraft = false;
		var formSubmitCallBack = function () {
			if(!$scope.isCallForDraft && isFormCustomValid()) {
				setFormWorkflow();
				return false;
			}
			return true;
		};

		$scope.update();
		$window.oriformSubmitCallBack = function () {		
			return formSubmitCallBack();		
		};

		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;	
			// remove config data not needed.
			delete $scope.data.config;		
		}
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}