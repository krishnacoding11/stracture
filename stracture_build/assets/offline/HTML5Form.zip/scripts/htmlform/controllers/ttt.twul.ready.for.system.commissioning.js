
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';

    /**
         * removeToobarOptions : @taOptions required,
         * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
         * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
         * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
         */
    var hideOnOutside = function () {
        angular.element('body').on('click', function (event) {
            var $eventTarget = angular.element(event.target),
                targetClassList = event.target.classList,
                targetParentClassList = event.target.parentElement.classList,
                $editorToolbar = angular.element('.artf-editor-toolbar');
            if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
                !$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
                $editorToolbar.find('.font-name').removeClass('open-fonts-list');
            }
            if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
                !$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
                $editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
            }
        });
    }, addTextAngularOptions = function ($provide) {
        $provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
            taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                []
            ];
            return taRegisterTool("backgroundColor", {
                display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                action: function (color) {
                    var me = this;
                    if (this.$editor().wrapSelection) {
                        return this.$editor().wrapSelection("backColor", color)
                    }
                },
                options: {
                    replacerClassName: "fa fa-paint-brush",
                    showButtons: !1
                },
                color: "#fff"
            }),
                taRegisterTool("fontColor", {
                    display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                    action: function (color) {
                        var me = this;
                        if (this.$editor().wrapSelection) {
                            return this.$editor().wrapSelection("foreColor", color)
                        }
                    },
                    options: {
                        replacerClassName: "fa fa-font",
                        showButtons: !1,
                        showAlpha: !1
                    },
                    color: "#000"
                }),
                taRegisterTool('fontName', {
                    display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>" + "</button>",
                    action: function (event, font) {
                        //Ask if event is really an event.					
                        if (!!event.stopPropagation) {
                            //With this, you stop the event of textAngular.
                            event.stopPropagation();
                            //Then click in the body to close the dropdown.
                            angular.element("body").trigger("click");
                        }
                        angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
                        this.$element.toggleClass('open-fonts-list');
                        return this.$editor().wrapSelection('fontName', font);
                    },
                    disabled: function () { },
                    options: [
                        { name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
                        { name: 'Serif', css: "'times new roman', serif" },
                        { name: 'Wide', css: "'arial black', sans-serif" },
                        { name: 'Narrow', css: "'arial narrow', sans-serif" },
                        { name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
                        { name: 'Courier New', css: "'courier new', monospace" },
                        { name: 'Garamond', css: 'garamond, serif' },
                        { name: 'Georgia', css: 'georgia, serif' },
                        { name: 'Tahoma', css: 'tahoma, sans-serif' },
                        { name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
                        { name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
                        { name: 'Verdana', css: 'verdana, sans-serif' },
                        { name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
                    ]
                }),
                taRegisterTool('fontSize', {
                    display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",
                    action: function (event, size) {
                        //Ask if event is really an event.					
                        if (!!event.stopPropagation) {
                            //With this, you stop the event of textAngular.
                            event.stopPropagation();
                            //Then click in the body to close the dropdown.
                            angular.element("body").trigger("click");
                        }
                        angular.element('.open-fonts-list').removeClass('open-fonts-list');
                        this.$element.toggleClass('open-fonts-size-list');
                        return this.$editor().wrapSelection('fontSize', parseInt(size));
                    },
                    disabled: function () { },
                    options: [
                        { name: 'xx-small', css: 'xx-small', value: 1 },
                        { name: 'x-small', css: 'x-small', value: 2 },
                        { name: 'small', css: 'small', value: 3 },
                        { name: 'medium', css: 'medium', value: 4 },
                        { name: 'large', css: 'large', value: 5 },
                        { name: 'x-large', css: 'x-large', value: 6 },
                        { name: 'xx-large', css: 'xx-large', value: 7 }

                    ]
                }),
                taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'), taOptions;
        }
        ]);
    };

	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function ($translateProvider, $provide) {
        addTextAngularOptions($provide);
        hideOnOutside();
    });

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        //autoSaveDraft timeout from client side
        $scope.stopAutoSaveDraftTimerFromClientSide();

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var STATIC_OBJ_DATA = {
            Doc_Form_Details: {
                Doc_Form_SeqID: "",
                Doc_Form_SeqHeader: "",
                Document_Details_Grp: {
                    Document_Details: [{
                        Doc_Form_SubSeqId: "",
                        Doc_Rev_ID: "",
                        Doc_ID: "",
                        Form_ID: "",
                        Doc_User_Ref: "",
                        Doc_Form_Title: "",
                        Doc_Form_Status: "",
                        Doc_Form_Workspace: "",
                        Doc_Form_Type: "",
                        Doc_TWEXNET: "",
                        Doc_Dep_Guid: ""
                    }]
                }
            },
            Document_Details: {
                Doc_Form_SubSeqId: "",
                Doc_Rev_ID: "",
                Doc_ID: "",
                Form_ID: "",
                Doc_User_Ref: "",
                Doc_Form_Title: "",
                Doc_Form_Status: "",
                Doc_Form_Workspace: "",
                Doc_Form_Type: "",
                Doc_TWEXNET: "",
                Doc_Dep_Guid: ""
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
        };

        var TTT_CONSTANT = {
            //define status
            accept_status: "Accept",
            reject_status: "Reject",
            overall_accept_status: "Accepted",
            overall_reject_status: "Rejected",
            submit_Status: "Submitted",
            reviewInProgress: "Review In Progress",
            tidewayscm: "Tideway SCM",
            representative: "Representative",
            scm: "System Commissioning Manager"
        }

        /** Initialize db fields */
        $scope.logo = "/images/htmlform/tideway/TidewayAndTWULPartnership.jpg";

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.ori_msg_Custom_Fields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.certificate_preparedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_preparedBy"];
        $scope.certificate_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_ApprovedBy"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Get_Dashboard_Formwise_Details');
        var DS_TTT_TIDP_Validate_and_Get_Document_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Validate_and_Get_Document_Details');
        var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        $scope.dbFormId = $scope.formdata5['DS_FORMID'];
        $scope.isDraft = $scope.formdata5['DS_ISDRAFT'];

        $scope.ori_msg_Custom_Fields.MainTitle = "TWUL READY FOR SYSTEM COMMISSIONING CERTIFICATE";
        $scope.setTitle = "STATEMENTS";
        $scope.setPartNo = "1";

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsWorkingUser = dsWorkingUserId;
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        var todayDate = '';
        var todayDateDbFormat = '';
        $scope.getServerTime(function (serverDate) {
            todayDate = serverDate;
            todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            initORIview();
        });

        function initORIview() {
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                var isdsIsdraftRes = $scope.formdata5['DS_ISDRAFT_RES'];
                var isdsIsdraftResMsg = $scope.formdata5['DS_ISDRAFT_RES_MSG'];
                setRolewiseUser();
                if (currentViewName == "ORI_VIEW") {

                    //check and discard all draft forms before creating new form.
                    if ($scope.dbFormId != "" && $scope.isDraft == "NO") {
                        $scope.xhr = false;
                        binddocumentList();
                    }
                    if ($scope.dbFormId == "" || $scope.isDraft == "YES") {
                        filluserreflist();
                        $scope.hideSaveDraftButton();
                        $scope.setandvalidatedata($scope.ori_msg_Custom_Fields.Certi_Ref);
                    }
                    if ($scope.ori_msg_Custom_Fields.Certi_Ref == "") {
                        $scope.validatedocumentFlag = true;
                    }

                    //set precise and statements
                    if ($scope.dbFormId == "" && $scope.isDraft == "NO") {
                        $scope.ori_msg_Custom_Fields.Precise_Limits = "<center> <u><b>TWUL System Works </b></u> <br>" +
                            "<b>TWUL System Works</b> means the TWUL Works described in paragraph 1.2 of Part C of the Project Requirements (Interface Agreement Schedule 1)<br><br>" +
                            "Shad Thames Pumping Station Contract (C492) <br>" +
                            "Beckton Sewage Treatment Works Contract (C492) <br>" +
                            "Bekesbourne Street Works Contract (C492) </center> ";

                        $scope.ori_msg_Custom_Fields.Statement = "Pursuant to the Interface Agreement Schedule 13 (Pre-System Commissioning and System Commissioning Protocol) <b>We</b> confirm that:<br><br>" +

                            "1. Operator training has been completed in accordance with the System Commissioning Plan so that <b>We</b> understand how to perform our role during the System Commissioning Period, as required by Paragraph 3.14.1 item iv (part f)<br><br>" +

                            "2. Arrangements are in place to respond to emergencies during the System Commissioning Period associated with the Operational Sites; the existing storm pumping stations; and the TWUL System Works, as required by Paragraph 4.11.5 <br><br>" +

                            "3. Arrangements are in place to maintain the TWUL System Works during the System Commissioning Period, as required by Paragraph 3.8.4 item xvi.<br><br>" +

                            "4. People, plant, materials and plans are in place as required by Paragraph 4.5.2 in order to:<br><br>" +
                            "- coordinate and manage the operation of the Sewer Network <br>" +
                            "- undertake flow diversions or other flow management activities within the existing Sewer Network to facilitate the removal of the equipment provided by the Infrastructure Provider to hydraulically isolate the works from the Sewer Network.<br>" +
                            "- undertake System Commissioning activities in accordance with the System Commissioning Plan<br>" +
                            "- support and facilitate the Infrastructure Provider's testing of the SCADA plant and modifications to the existing control systems in accordance with the System Commissioning Plan<br>" +
                            "- support the analysis of the System Commissioning test results and monitoring data in accordance with the System Commissioning Plan<br>" +
                            "- undertake adjustments to the TWUL System Works (where reasonable and requested by the System Commissioning Manager) <br> <br>" +

                            "5. <b>We</b> have consulted with the EA and obtained the Environmental Permits and and agreed the Operating Techniques as required by Paragraph 3.11";

                            $scope.ori_msg_Custom_Fields.SCM_Statement = "I have checked this TWUL Ready for System Commissioning Certificate and I am satisfied that the information provided is complete.";
                    }
                }
                if (currentViewName == "RES_VIEW") {
                    //check and discard all draft forms before creating new form.
                    if (isdsIsdraftResMsg == "NO" && isdsIsdraftRes == "YES") {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEditDraft = true;
                        $scope.formdata5["DS_SEND_MSG"] = "1|You are not authorised to create this form. please click the cancel button at the bottom of the form. \n \n If you want to create the new form than please discard draft forms.";
                        $scope.hideSaveDraftButton();
                        $scope.update();
                        return;
                    } else {
                        $scope.flagIsAllowEditDraft = false;
                        $scope.formdata5["DS_SEND_MSG"] = "0|";
                    }

                    // check assign status for working user.
                    var isrequired = checkPendingAction(dsWorkingUserId);
                    if (isrequired == false) {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEdit = true;
                        $scope.formdata5["DS_SEND_MSG"] = "1|You are not authorised to create or edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                        $scope.hideSaveDraftButton();
                        $scope.update();
                        return;

                    } else {
                        $scope.flagIsAllowEdit = false;
                        $scope.formdata5["DS_SEND_MSG"] = "0|";
                    }
                    $scope.xhr = false;
                    binddocumentList();
                }
            }
            if (isdsIsdraftRes == "NO" && isdsIsdraftResMsg == "NO") {
                $scope.ori_msg_Custom_Fields["DSI_CurrentStage"] = $scope.ori_msg_Custom_Fields["DSI_NextStage"];

                // doc and form association wipe out on onload...
                $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = "";
                $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = ""; 

                if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '0' && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 == 'Rejected') {

                    //set prepered by details
                    $scope.certificate_preparedBy.preparedBy_Date = '';
                    $scope.certificate_preparedBy.preparedBy_Name = '';
                    $scope.certificate_preparedBy.preparedBy_ID = '';
                    $scope.certificate_preparedBy.preparedBy_Position = '';
                    $scope.certificate_preparedBy.preparedBy_onbehalfof = '';
                    $scope.certificate_preparedBy.preparedBy_Comment = '';

                     //set approved by's details
                    $scope.certificate_ApprovedBy.ApprovedBy_Date = '';
                    $scope.certificate_ApprovedBy.ApprovedBy_Name = '';
                    $scope.certificate_ApprovedBy.ApprovedBy_Position = '';
                    $scope.certificate_ApprovedBy.ApprovedBy_onbehalfof = '';
                    $scope.certificate_ApprovedBy.ApprovedBy_Comment = '';

                    $scope.ori_msg_Custom_Fields.Certificate_Status = '';
                    
                    setRolewiseUser();

                }
            }
            if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
                angular.element('.export-btn').hide();
                setURLofAssocDoc();
            }
            settabs();
        }
        
        function checkPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            DS_INCOMPLETE_ACTIONS_BYMSG = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Respond";
            });
            if (DS_INCOMPLETE_ACTIONS_BYMSG) {
                for (var i = 0; i < DS_INCOMPLETE_ACTIONS_BYMSG.length; i++) {
                    var strUserId = DS_INCOMPLETE_ACTIONS_BYMSG[i].Value1;

                    if (strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }

        function settabs() {
            $scope.oriviewtabs = [{
                title: 'Statements',
                url: 'Statements.html'
            }, {
                title: 'Package Listing',
                url: 'packageListing.html'
            }]

            $scope.currentOriViewTab = 'Statements.html';
            /****************************************/
            $scope.isActiveTab = function (tabUrl, calledform) {
                if (calledform == "ori_print_view_main") {
                    return tabUrl == $scope.currentOriPrintViewTab;
                } else if (calledform == "ori_view_main") {
                    return tabUrl == $scope.currentOriViewTab;
                }
            }
            /****************************************/

            $scope.setTitle = "STATEMENTS";
            $scope.setPartNo = "1";
            $scope.onClickTab = function (tab, calledform) {
                var strFlag = "STATEMENTS",
                    intPartNo = "1";
                if (calledform == "ori_view_main") {
                    $scope.currentOriViewTab = tab.url;
                }
                if (calledform == "ori_print_view_main") {
                    $scope.currentOriPrintViewTab = tab.url;
                }

                if (tab.title == "Package Listing") {
                    strFlag = "PACKAGE LISTING";
                    intPartNo = "2";
                }
                $scope.setTitle = strFlag;
                $scope.setPartNo = intPartNo;

                $timeout(function () {
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        }


        function setRolewiseUser() {
            if (DS_PROJUSERS_ROLE.length) {
                var lstcontractor = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                    if (val.Value.split('|')[0].trim() == TTT_CONSTANT.tidewayscm) {
                        return val.Value;
                    }
                });

                $scope.objroleuser = commonApi.getItemSelectionList({
                    arrayObject: lstcontractor,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
            }
        }

        $window.TTT_AssociateDocsAndForms = function () {
            return $scope.setflow();
        }

        $scope.setflow = function () {
            var currentstage = $scope.ori_msg_Custom_Fields["DSI_CurrentStage"];
            var workingUserName = dsWorkingUser && dsWorkingUser.split(',')[0].trim();
            var workingUserOrg = dsWorkingUser && dsWorkingUser.split(',')[1].trim();
            var strTodayDate = todayDateDbFormat;
            $scope.formdata5.DS_DB_INSERT = true;

            if (currentstage == "0") {
                $scope.ori_msg_Custom_Fields["DSI_NextStage"] = "1";

                //set prepered by details
                $scope.certificate_preparedBy.preparedBy_Date = strTodayDate;
                $scope.certificate_preparedBy.preparedBy_Name = workingUserName;
                $scope.certificate_preparedBy.preparedBy_ID = dsWorkingUserId.split('|')[0];
                $scope.certificate_preparedBy.preparedBy_Position = TTT_CONSTANT.representative;
                $scope.certificate_preparedBy.preparedBy_onbehalfof = workingUserOrg;

                var approver = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_preparedBy"]["SentTo_ApprovedBy"];
                var approverVal = approver && approver.split('|')[2].trim().split(' ')[0];

                //set distribution
                var strdate = commonApi.calculateDistDateFromDays({
                    baseDate: todayDate,
                    days: 10
                });

                if (currentViewName == "ORI_VIEW") {
                    //set distributr id for ORIview
                    setDistribution(approverVal, "3#Respond", "3", strdate);
                }
                else {
                    setDistribution(approverVal, "3#Respond", "13", strdate);
                }

                //update status
                updateFormStatus(TTT_CONSTANT.reviewInProgress);
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = TTT_CONSTANT.submit_Status;

                assocformsanddocs();
            }
            if (currentstage == "1") {
                var certificatestatus = $scope.ori_msg_Custom_Fields["Certificate_Status"];
                var strdate = commonApi.calculateDistDateFromDays({
                    baseDate: todayDate,
                    days: 10
                });

                //set approved by's details
                $scope.certificate_ApprovedBy.ApprovedBy_Date = strTodayDate;
                $scope.certificate_ApprovedBy.ApprovedBy_Name = workingUserName;
                $scope.certificate_ApprovedBy.ApprovedBy_Position = TTT_CONSTANT.scm;
                $scope.certificate_ApprovedBy.ApprovedBy_onbehalfof = workingUserOrg;

                if (certificatestatus == TTT_CONSTANT.accept_status) {
                    updateFormStatus(TTT_CONSTANT.overall_accept_status);
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = TTT_CONSTANT.overall_accept_status;
                }

                if (certificatestatus == TTT_CONSTANT.reject_status) {
                    $scope.ori_msg_Custom_Fields["DSI_NextStage"] = "0";

                    //set distribution
                    var approver = $scope.certificate_preparedBy.preparedBy_ID;
                    setDistribution(approver, "3#Respond", "13", strdate);

                    //update status
                    updateFormStatus(TTT_CONSTANT.overall_reject_status);
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = TTT_CONSTANT.overall_reject_status;

                }
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
            }

            return validatemandatoryfields();
        }

        $scope.validateUrlLink = function (objCurrentRepeatingNode) {

            var pattern = /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/;
            var regex = new RegExp(pattern);

            if (objCurrentRepeatingNode.Doc_TWEXNET && !regex.test(objCurrentRepeatingNode.Doc_TWEXNET)) {
                alert('please enter valid url');
                objCurrentRepeatingNode.Doc_TWEXNET = "";
            }
        }

        $scope.onPasteUrlValidation = function (event) {
            var inputValue;
            var regex = new RegExp(/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/);

            if ($window.clipboardData) {
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }

            if (inputValue && !regex.test(inputValue)) {
                alert('please enter valid url');
                event.preventDefault();
                return false;
            }
        }

        function validatemandatoryfields() {
            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '0' && (!$scope.ori_msg_Custom_Fields.TWUL_Statement.certificate_preparedBy.SentTo_ApprovedBy || !$scope.ori_msg_Custom_Fields.Precise_Limits)) {
                $window.alert('Validation\n\n Please fill mandatory field(s)!');
                return true;
            }
            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '1') {
                if (!$scope.ori_msg_Custom_Fields.Certificate_Status || !$scope.ori_msg_Custom_Fields.Statement || !$scope.ori_msg_Custom_Fields.SCM_Statement || ($scope.ori_msg_Custom_Fields.Certificate_Status == 'Reject' && !$scope.ori_msg_Custom_Fields.TWUL_Statement.certificate_ApprovedBy.ApprovedBy_Comment)) {
                    $window.alert('Validation\n\n Please fill mandatory field(s)!');
                    return true;
                }
            }
            return false;
        }

        /**
         * set URL for associated doc in printview
         * These URL comes from SP
         */
        function setURLofAssocDoc() {
            var AssocDocdata = $scope.getValueOfOnLoadData('DS_GEN_DOC_ASSOCIATIONS_CROSS_DC_LIST');
            var AssocFormdata = $scope.getValueOfOnLoadData('DS_GEN_FORM_ASSOCIATIONS_CROSS_DC_LIST');
            var elem2 = null, element3 = null, element4 = null, element = null;

            for (var m = 0; m < $scope.ori_msg_Custom_Fields['Doc_Form_Grp']['Doc_Form_Details'].length; m++) {
                element = $scope.ori_msg_Custom_Fields['Doc_Form_Grp']['Doc_Form_Details'][m];

                for (var n = 0; n < element['Document_Details_Grp']['Document_Details'].length; n++) {
                    elem2 = element['Document_Details_Grp']['Document_Details'][n];

                    for (var j = 0; j < AssocDocdata.length; j++) {
                        element3 = AssocDocdata[j];
                        if (element3.Value18 == elem2.Doc_ID) {
                            elem2.Doc_Rev_Link = element3.URL15;
                        }
                    }
                    for (var l = 0; l < AssocFormdata.length; l++) {
                        element4 = AssocFormdata[l];
                        if (element4.Value8 == elem2.Form_ID) {
                            elem2.Doc_Rev_Link = element4.URL11;
                        }
                    }
                }
            }
        }

        function assocformsanddocs() {
            var assoFormsStr = ':#';
            var assoDocsStr = "";
            var strdsvalidatedocumentdata = DS_TTT_TIDP_Validate_and_Get_Document_Details;
            for (var index = 0; index < strdsvalidatedocumentdata.length; index++) {
                var strvalidate = strdsvalidatedocumentdata[index].Value1.trim();
                if (strvalidate == "0") {
                    var assocflag = strdsvalidatedocumentdata[index].Value16;
                    if (assocflag == 'Yes') {
                        if (strdsvalidatedocumentdata[index].Value15 != "") {
                            if (assoFormsStr == ":#") {
                                assoFormsStr += ':' + strdsvalidatedocumentdata[index].Value15;
                            } else {
                                assoFormsStr += ',:' + strdsvalidatedocumentdata[index].Value15;
                            }
                        }
                        if (strdsvalidatedocumentdata[index].Value7 != "") {
                            assoDocsStr += strdsvalidatedocumentdata[index].Value7 + "#" + strdsvalidatedocumentdata[index].Value14 + "#" + strdsvalidatedocumentdata[index].Value13 + ",";
                        }
                    }
                }
            }
            if (assoFormsStr.length > 2) {
                $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = assoFormsStr;
            }
            $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = assoDocsStr;
        }

        function updateFormStatus(StrStatus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: StrStatus.toLowerCase()
            });
            $scope.formdata5['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
        }

       function setDistribution(UsertoDist, Action, DS_AUTODist, strDate){
            var tempList = [];
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

            tempList.push({
                strUser: UsertoDist,
                strAction: Action,
                strDate: strDate
            });

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: DS_AUTODist
            });
        }

        function filluserreflist() {
            $scope.objuserref = [];
            var element = $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details;
            for (var index = 0; index < element.length; index++) {
                if (element[index].Value2 && element[index].Value3) {
                    var struserref = element[index].Value2.trim();
                    var strguid = element[index].Value3.trim();
                    var strconcate = struserref + "||" + strguid;
                    $scope.objuserref.push({
                        optlabel: "",
                        options: [{
                            displayValue: struserref,
                            modelValue: strconcate,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.setandvalidatedata = function (strcerti) {
            if (strcerti) {
                var strGUID = strcerti.split("||")[1].trim();
                $scope.ori_msg_Custom_Fields.ORI_USERREF = strcerti.split("||")[0].trim();
                $scope.ori_msg_Custom_Fields.Cer_GUID = strGUID;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strcerti.split("||")[0].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strcerti.split("||")[1].trim();
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": "DS_TTT_TIDP_Validate_and_Get_Document_Details",
                        "fieldValue": strGUID
                    }],
                    successCallback: getcallbackcertidata
                };
                $scope.xhr = true;
                $scope.getCallbackSPdata(spParam);
            }
        }
        function getcallbackcertidata(responseList) {
            $scope.xhr = false;
            if (responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"]) {
                DS_TTT_TIDP_Validate_and_Get_Document_Details = responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"];
                $scope.ori_msg_Custom_Fields.ORI_FORMTITLE = DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value20;
            }
            binddocumentList();
        }

        function binddocumentList() {
            if (DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value1 == '1') {
                $scope.validatedocumentFlag = true;
                $scope.formdata5["DS_SEND_MSG"] = '1|You can not create/update the form.Please verify validation message.';
                $scope.hideSaveDraftButton();
            }
            else {
                var objSaveDraftBtn = document.getElementById('btnSaveDraft');
                $scope.validatedocumentFlag = false;
                $scope.formdata5["DS_SEND_MSG"] = '0|';
                if ($scope.isDraft == "NO") {
                    setDocumentFormHeaders(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                    setDocumentFormdetails(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                }
                objSaveDraftBtn && (objSaveDraftBtn.style.display = 'inline-block');
            }
        }
        function onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
        }

        function setDocumentFormHeaders(dsvalidatedocumentdata) {
            //$scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details.Document_Details_Grp.Document_Details = [];
            $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details = [];
            var insertPointparent = $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details,
                strdocumentdet = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    var unique = [];
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();
                        if (strvalidate == "0") {
                            var strheader = dsvalidatedocumentdata[index].Value10.trim() + "|$|" + dsvalidatedocumentdata[index].Value11.trim();
                            unique.push(strheader);
                        }
                    }
                    if (unique.length) {
                        unique = unique.filter(onlyUnique);
                        for (var i = 0; i < unique.length; i++) {
                            var seqnum = unique[i].split('|$|')[0].trim();
                            var seqheader = unique[i].split('|$|')[1].trim();
                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Doc_Form_Details);
                            strdocumentdet.Doc_Form_SeqID = seqnum;
                            strdocumentdet.Doc_Form_SeqHeader = seqheader;
                            insertPointparent.push(strdocumentdet);
                        }
                    }
                }
            }
        }
        function setDocumentFormdetails(dsvalidatedocumentdata) {
            var strdocumentdet = "";
            var seqcount, headerseqold = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();

                        if (strvalidate == "0") {
                            var strheaderseq = dsvalidatedocumentdata[index].Value10.trim()
                            var strheadertitle = dsvalidatedocumentdata[index].Value11.trim();

                            var insertPoint = commonApi._.filter($scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details, function (Obj) {
                                return Obj.Doc_Form_SeqID == strheaderseq && Obj.Doc_Form_SeqHeader == strheadertitle;
                            });

                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Document_Details);
                            if (strheaderseq == headerseqold) {
                                seqcount = seqcount + 1;
                            }
                            else {
                                seqcount = 1;
                            }
                            var checksubseqid = insertPoint[0]['Document_Details_Grp']['Document_Details'][0]['Doc_Form_SubSeqId'];
                            if (checksubseqid == "") {
                                insertPoint[0]['Document_Details_Grp']['Document_Details'] = [];
                            }
                            strdocumentdet.Doc_Form_SubSeqId = strheaderseq + "." + seqcount;
                            strdocumentdet.Doc_Form_Title = dsvalidatedocumentdata[index].Value2;
                            strdocumentdet.Doc_Form_Status = dsvalidatedocumentdata[index].Value4;
                            strdocumentdet.Doc_User_Ref = dsvalidatedocumentdata[index].Value3;
                            strdocumentdet.Doc_Form_Type = dsvalidatedocumentdata[index].Value6;
                            strdocumentdet.Doc_Form_Workspace = dsvalidatedocumentdata[index].Value5;
                            strdocumentdet.Form_ID = dsvalidatedocumentdata[index].Value9;
                            strdocumentdet.Doc_Rev_Link = dsvalidatedocumentdata[index].URL17;
                            strdocumentdet.Doc_Rev_ID = dsvalidatedocumentdata[index].Value12;
                            strdocumentdet.Doc_ID = dsvalidatedocumentdata[index].Value7; //Value7 stores Doc db Revision_Id
                            strdocumentdet.Doc_Dep_Guid = dsvalidatedocumentdata[index].Value18;
                            if (dsvalidatedocumentdata[index].Value19 != "") {
                                strdocumentdet.Doc_TWEXNET = dsvalidatedocumentdata[index].Value19;
                            }
                            insertPoint[0]['Document_Details_Grp']['Document_Details'].push(strdocumentdet);

                            headerseqold = strheaderseq;
                        }
                    }
                }
            }
        }

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}

function customHTMLMethodBeforeCreate_RES() {

    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}