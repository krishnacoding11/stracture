/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment', '../components/signature'], function (angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout, htmlformservice) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd MM yy');
            $scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
        });

        $scope.currentOriTab = 'general.html';
        $scope.currentOriSubTab = '';

        $window.addEventListener('scroll', function () {
            if ($window.scrollY || document.documentElement.scrollTop) {
                $element.addClass('scroll-top');
                return;
            }
            $element.removeClass('scroll-top');
        });

        /** Initialize db fields */
        var STATIC_OBJECTS = {
            SignDetails: {
                Name: "",
                Sign: "",
                Role: "",
                Organization: ""
            },
            AppendixDetails: {
                Acknowledge: "",
                AppendixName: "",
                AppendixDescription: "",
                AppendixOrder: ""
            },
            SubContractCompletionDetails: {
                SubContractWorksOrPart: "",
                WorkStartDate: "",
                WorkEndDate: "",
                WorkPeriodOfWeek: ""
            },
            Appendices: {
                AppendixName: "",
                AppendixDescription: "",
                AppendixDocRef: "",
                Comments: "",
                Status: "",
                LORRemarks: "",
                SelectClause: "",
                AttachmentDetailsGroup: {
                    AttachmentDetails: [{
                        Attachment_Sequence: "",
                        Attachment_Reference: ""
                    }]
                }
            },
            AttachmentDetails: {
                Attachment_Sequence: "",
                Attachment_Reference: ""
            },
            appendixTable: "appendixTable"
        };
        var currentViewName = $window.currentViewName;
        var ASSOC_BACKUP = {};
        ASSOC_BACKUP[STATIC_OBJECTS.appendixTable] = {};
        var assocFileService;
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.acf01 = $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS && $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;
        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.resAppendicesDetails = $scope.resMsgCustomFields["Appendices"];
        $scope.resSignatoriesDetails = $scope.resMsgCustomFields["Signatories"];
        $scope.oriSignatoriesSubContractor = $scope.oriMsgCustomFields["Signatories_SubContractor"];
        $scope.oriSignatoriesLOR = $scope.oriMsgCustomFields["Signatories_LOR"];
        $scope.oriSignatoriesSubContractorSelfBilling = $scope.oriMsgCustomFields["Signatories_SubContractor_SelfBilling"];
        $scope.oriSignatoriesContractorSelfBilling = $scope.oriMsgCustomFields["Signatories_Contractor_SelfBilling"];
        $scope.AppendixDetails = $scope.oriMsgCustomFields.SubContractParticulars.AppendicesAndAnnexures;
        $scope.SubContractPeriodOfCompletionDetails = $scope.oriMsgCustomFields.SubContractParticulars.SubContractPeriodForCompletion;

        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.DS_PROJUSERS = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        $scope.dsWorkingUserId = $scope.getWorkingUserId();
        $scope.showCorrectValue = true;

        $scope.isCommercialTeamUser = ($scope.getWorkspaceRole().indexOf('Commercial Team') !== -1);
        $scope.isContractor = ($scope.getWorkspaceRole().indexOf("Sub Contractor") !== -1 || $scope.getWorkspaceRole().indexOf("Sub Contractor Director") !== -1);
        $scope.isProcurement = ($scope.getWorkspaceRole().indexOf('Procurement') !== -1);

        $scope.launchCommmentingForm = function () {
            $scope.setValuesOfLaunchButton();
            launchCreateForm("LOR-NEC-DISC");
            $scope.disableLaunchButton = true;
        }

        $scope.setValuesOfLaunchButton = function () {
            var selectedAppendixNo = [];
            $scope.resMsgCustomFields["Appendices"].forEach(function (item) {
                if (item.SelectClause) {
                    selectedAppendixNo.push(item.AppendixName);
                }
            });
            selectedAppendixNo = selectedAppendixNo.join('-');
            var DS_GET_FORM_MSG_DTLS = $scope.getValueOfOnLoadData('DS_GET_FORM_MSG_DTLS');
            DS_GET_FORM_MSG_DTLS = DS_GET_FORM_MSG_DTLS[0].Value6;
            selectedAppendixNo = DS_GET_FORM_MSG_DTLS + "|" + selectedAppendixNo;
            $window.DP_DOC_ASSOC = '';
            $window.DS_ASSOCIATED_DOCS_UPDATES = '';
            $window.DP_FORM_ASSOC_CURRENT = '';
            $window.DS_ATTACH_AUTOASSOCIATE_MSG = '';
            $window.DS_COPY_CONTENT = 'Yes';
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '3';
            $window.prePopulatemapping['SRC1'] = selectedAppendixNo;
            $window.prePopulatemapping['TG1'] = 'SelectedAppendicesDetails';
            $window.prePopulatemapping['SRC2'] = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields['ORI_USERREF'];
            $window.prePopulatemapping['TG2'] = 'ORI_USERREF';
            $window.prePopulatemapping['SRC3'] = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields['ORI_FORMTITLE'];
            $window.prePopulatemapping['TG3'] = 'ORI_FORMTITLE';
        }

        $scope.isOriView = (window.currentViewName == 'ORI_VIEW');
        $scope.isRespView = (window.currentViewName == 'RES_VIEW');
        $scope.isDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'YES');
        $scope.appMsgId = $scope.asiteSystemDataReadOnly['_6_Form_MSG_Data']['DS_MSGID'];
        var msgIncompleteActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var allUserByRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData("DS_ASI_GET_Organization_Logo");
        $scope.contractors = commonApi._.filter(allUserByRoles, function (obj) {
            return obj.Value.indexOf("Lor Director") > -1;
        });
        // make unique contractors...
        $scope.contractors = commonApi._.uniq($scope.contractors, function (item) {
            return item.Value.split("|")[2].split("#")[0].trim()
        });
        var logoURLFromServer = '/images/htmlform/LOR/lor-logo.jpg';
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        // to get Custom Attribute On Load.
        var logo = commonApi._.findWhere(dsAsiConfigurableAttributes, {
            Value3: "LOR Logo",
            Value7: "LOR Logo"
        }) || {};
        $scope.oriMsgCustomFields.DS_Logo = logo.Value8 ? logo.Value8 : logoURLFromServer;

        var autocompleteMsgStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }

        $scope.setAppendixNameForDropDown = function () {
            $scope.allAppendixNo = [];

            for (var appendix in $scope.AppendixDetails.AllAppendix) {
                $scope.allAppendixNo.push($scope.AppendixDetails.AllAppendix[appendix].docRef);
            }
        };

        // this function is made for pdf platform which is set on submit
        $scope.getEmailIdByUserId = function (objParent, userId) {
            var fieldValue = userId && userId.split('#')[0];
            if (fieldValue) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_PROJUSER_DETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_PROJUSER_DETAILS",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_PROJUSER_DETAILS']);
                        strGetDetails = strGetDetails.Items.Item;
                        objParent.Email = strGetDetails[0].Value.split('|')[3].trim();
                    }
                }, function (error) {
                    window.console && window.console.log(error);
                });
            }
        }

        var currentUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.split('|')[0].trim();
        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = "";
        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "";
        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
        if (currentViewName == "ORI_VIEW") {
            var onloadCallFlag = true;
            setBackupAssocList();

            //Select contactors
            $scope.subContractors = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                return (val.Value.split('#')[0].split('|')[0].trim().indexOf('Sub Contractor') === 0);
            });

            // make unique subContractors...
            $scope.subContractors = commonApi._.uniq($scope.subContractors, function (item) {
                return item.Value.split("|")[2].split("#")[0].trim()
            });

            // set contractor registration number baased on contractor company...
            $scope.setContractorRegNo = function(contractCompany){
                if(contractCompany == 'Laing O’Rourke Construction Limited'){
                    $scope.acf01.ACF_01_ContractorRegistrationNo = '4309402';
                    $scope.acf01.ACF_01_LOR_CompanyNumber = '549 3477 06';
                } else if(contractCompany == 'Laing O’Rourke Infrastructure Limited'){
                    $scope.acf01.ACF_01_ContractorRegistrationNo = '4309441';
                    $scope.acf01.ACF_01_LOR_CompanyNumber = '549 3477 06';
                } else if(contractCompany == 'Select Plant Hire Limited'){
                    $scope.acf01.ACF_01_ContractorRegistrationNo = '1973463';
                    $scope.acf01.ACF_01_LOR_CompanyNumber = '549 3477 06';
                } else if(contractCompany == 'Expanded Limited'){
                    $scope.acf01.ACF_01_ContractorRegistrationNo = '5117890';
                    $scope.acf01.ACF_01_LOR_CompanyNumber = '549 3477 06';
                }
            }

            //Clear auto destribution node
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

            if ($scope.strFormId == "") {
                $scope.resMsgCustomFields.OriginatorId = currentUserId;
            }

            $scope.isPendingAction = true;
            if ($scope.isContractor) {
                $scope.isPendingAction = false;
            }

            if ($scope.isPendingAction) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_DRAFT_MSG = "0";
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_DRAFT_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
            }
        }

        if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
            if ($scope.isContractor) {
                $element.addClass('contractor-view');
            }
            $scope.showMsg = ""
            var userIdArray = [];
            var msgActionList = $scope.getValueOfOnLoadData('DS_GET_MSG_DISTRIBUTION_LIST');
            if (msgActionList.length) {
                //adding user id of action distributed
                for (var i = 0; i < msgActionList.length; i++) {
                    userIdArray.push(msgActionList[i].Value8);
                }

                //adding user id of message creator
                userIdArray.push(msgActionList[0].Value10);

                if (userIdArray.indexOf($scope.dsWorkingUserId) < 0 && $scope.isContractor) {
                    $scope.showMsg = "Restricted View";
                }
            }

            setURLofAssocDoc();

        }

        $scope.commercialTeamResposeActionDetails = $scope.resMsgCustomFields.CommercialTeamResposeActionDetails;
        $scope.procurementTeamResposeActionDetails = $scope.resMsgCustomFields.ProcurementTeamResposeActionDetails;
        if (currentViewName == "RES_VIEW") {
            $scope.oriMsgCustomFields.DSI_PreviousMsgId = msgIncompleteActionList.length ? msgIncompleteActionList[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId;
            $scope.setAppendixNameForDropDown();
            $scope.originator = currentUserId === $scope.resMsgCustomFields.OriginatorId;

            if ($scope.isContractor) {
                $scope.resMsgCustomFields.ContractorComment = "";
            }
            if ($scope.originator) {
                $scope.resMsgCustomFields.ContractAdminComment = "";
            }

            if ($scope.resMsgCustomFields.SendForSignature) {
                setAutomatedSignature();
            }

            $scope.selectAll = function (checkboxValue) {
                var AllAppendices = $scope.AppendixDetails.AllAppendix;
                var i = 0;
                for (; i < AllAppendices.length; i++) {
                    if (checkboxValue) {
                        AllAppendices[i].Acknowledge = true;
                    } else {
                        AllAppendices[i].Acknowledge = false;
                    }
                }
            }

            $scope.commercialTeamResposeActionDetails = {
                Status: ($scope.isCommercialTeamUser) ? "" : $scope.resMsgCustomFields.CommercialTeamResposeActionDetails.Status,
                Comment: ($scope.isCommercialTeamUser) ? "" : $scope.resMsgCustomFields.CommercialTeamResposeActionDetails.Comment
            };

            $scope.procurementTeamResposeActionDetails = {
                Status: ($scope.isProcurement && $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == 'Issued to Procurement team') ? "ACCEPTED" : "",
                Comment: ($scope.isProcurement) ? "" : $scope.resMsgCustomFields.ProcurementTeamResposeActionDetails.Comment
            };

            $scope.isPendingAction = commonApi.checkPendingActionOnMsg({
                incompleteActionsByMsgList: DS_INCOMPLETE_ACTIONS_BYMSG,
                actionName: 'Respond',
                strUser: $scope.dsWorkingUserId,
                isCheckMsgId: false,
                strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
            });

            if ($scope.isPendingAction) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_DRAFT_MSG = "0";
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_DRAFT_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
            }

            var objAssociationBtn = document.getElementsByClassName('associationBtn');
            if ($scope.resMsgCustomFields.SendForSignature) {
                $timeout(function () {
                    var objAttachmentBtn = document.getElementsByClassName('attachmentBtn');
                    if (objAttachmentBtn && objAttachmentBtn.length) {
                        objAttachmentBtn[0].style.display = 'none';
                    }
                }, 10);
                if (objAssociationBtn && objAssociationBtn.length) {
                    objAssociationBtn[0].style.display = 'none';
                }
            }
        }

        $scope.editorNativePasteEvent = function ($html) {
            return $html;
        };
        $scope.setCurrentSection = function (tabURL) {
            $scope.currentOriTab = tabURL;
            $scope.setCurrentSubTabSelection("");
            $scope.scrollToTop();
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 10);
        };

        $scope.setCurrentSubTabSelection = function (subTabId) {
            $scope.currentOriSubTab = subTabId || '';
            scrollIntoView(subTabId);
        };

        $scope.scrollToTop = function () {
            scrollToView(0);
        };

        $scope.removeClausesNotSubmitted = function () {
            var appendixFlag = false;
            $scope.subContractorCanSign = false;
            $scope.resMsgCustomFields.SignStage = "";
            $scope.resAppendicesDetails.forEach(function (appendixObj) {
                if (!appendixObj.Status) {
                    appendixFlag = true;
                }
            });
            if (appendixFlag) {
                if (confirm("All appendices which have not been submitted to Procurement prior to this response will be removed. Do you wish to continue?")) {
                    if (appendixFlag) {
                        $scope.resAppendicesDetails = $scope.resAppendicesDetails.filter(function (appendixObj) {
                            return appendixObj.Status;
                        })
                        $scope.resMsgCustomFields["Appendices"] = $scope.resAppendicesDetails;
                    }
                } else {
                    $scope.resMsgCustomFields.SendForSignature = false;
                }
            }
            if ($scope.resMsgCustomFields.SendForSignature) {
                if ($scope.oriSignatoriesSubContractor[0].Name.split('#')[0].trim() == $scope.dsWorkingUserId) {
                    $scope.subContractorCanSign = true;
                    $scope.resMsgCustomFields.SignStage = 0;
                    $scope.oriSignatoriesSubContractor[0].isSubContractorApproved1 = true;
                }
                if ($scope.subContractorCanSign) {
                    setAutomatedSignature();
                }
            } else {
                $scope.AppendixDetails.AllAppendix.forEach(function (appendixObj) {
                    if (appendixObj.Acknowledge) {
                        appendixObj.Acknowledge = false;
                    }
                });
            }
        }

        $scope.addNewSignItem = function (listToImport) {
            $scope.addRepeatingRow(listToImport, angular.copy(STATIC_OBJECTS.SignDetails));
        };

        $scope.addNewAppendixItem = function (listToImport) {
            $scope.addRepeatingRow(listToImport, angular.copy(STATIC_OBJECTS.AppendixDetails));
        };

        $scope.addNewSubContractCompletionItem = function (listToImport) {
            $scope.addRepeatingRow(listToImport, angular.copy(STATIC_OBJECTS.SubContractCompletionDetails));
        };

        $scope.addNewAppendixByContractorItem = function (listToImport) {
            $scope.addRepeatingRow(listToImport, angular.copy(STATIC_OBJECTS.Appendices));
        };

        $scope.addNewAttachment = function (listToImport) {
            $scope.addRepeatingRow(listToImport, angular.copy(STATIC_OBJECTS.AttachmentDetails));
        };
        1
        /**
         * This htmlformservice used when user associated files and close assoc modal
         * @param {assocObj.tempListSelection}: Array of associated files
         */
        htmlformservice.associateCloseCompleate = function (assocObj) {
            var tempList = assocObj.tempListSelection;
            var tempArray = [];
            tempArray = ASSOC_BACKUP[STATIC_OBJECTS.appendixTable];
            var alreadyAssocFiles = commonApi._.map(tempArray, function (obj) {
                return obj.revId;
            });
            if (tempList && tempList.length) {
                var newAsscoList = [];
                for (var i = 0; i < tempList.length; i++) {
                    var element = tempList[i];
                    if (alreadyAssocFiles.indexOf(getPureId(element.revisionId)) === -1) {
                        newAsscoList.push(element);
                    }

                }

                if (newAsscoList.length) {
                    setAssocDocs(angular.copy(newAsscoList));
                } else {
                    $window.alert('Files are already associated');
                }
            }

            assocFileService = htmlformservice.assocFileService;
            onloadCallFlag = false;
            setBackupAssocList();
        }

        /**
         * This htmlformservice used when user remove/remove all associated files
         * @param {delObj.deleteObj}: if remove single it return Object , if remove all it return Array
         */
        htmlformservice.associateDeleteCompleate = function (delObj) {
            var tempDeleteObj = delObj.deleteObj;
            var tempRevisionList = tempDeleteObj.revisionId ? getPureId(tempDeleteObj.revisionId) : 0;
            if (tempRevisionList) {
                for (var k = 0; k < $scope.AppendixDetails.AllAppendix.length; k++) {
                    var elem2 = $scope.AppendixDetails.AllAppendix[k];
                    if (elem2.revId && tempRevisionList.indexOf(elem2.revId) > -1) {
                        $scope.AppendixDetails.AllAppendix.splice(k, 1);
                        break;
                    }
                }
            } else {
                $scope.AppendixDetails.AllAppendix = [];
            }
            onloadCallFlag = false;
            setBackupAssocList();

        }

        /**
         * set Signature image url in scope
         */
        function setAutomatedSignature() {
            $scope.autoShow = false;
            var strUserId = "";
            for (var i = 0; i < DS_ASI_GET_Organization_Logo.length; i++) {
                strUserId = DS_ASI_GET_Organization_Logo[i].Value2 && DS_ASI_GET_Organization_Logo[i].Value2.split("|")[2].trim();
                if ($scope.getWorkingUserId() == strUserId) {
                    $scope.autoShow = true;
                    if ($scope.oriSignatoriesLOR[0].isLOR_Approved1 == false && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.subContractorAutomatedSignOne = DS_ASI_GET_Organization_Logo[i].Value4;
                        $scope.subContractorAutomatedSignSelfBilling = DS_ASI_GET_Organization_Logo[i].Value4;
                        break;
                    }
                    if ($scope.oriSignatoriesLOR[0].isLOR_Approved1 == true && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.contractorAutomatedSignOne = DS_ASI_GET_Organization_Logo[i].Value4;
                        $scope.contractorAutomatedSignSelfBilling = DS_ASI_GET_Organization_Logo[i].Value4;
                        break;
                    }
                }
            }
        }

        /**
         * set backup of association list
         * which used to remove platform's association view form
         */
        function setBackupAssocList() {
            $timeout(function () {
                if (!onloadCallFlag) {
                    $window.scrollTo(0, document.body.scrollHeight);
                }
                ASSOC_BACKUP[STATIC_OBJECTS.appendixTable] = angular.copy($scope.AppendixDetails.AllAppendix);
            });
        }

        /**
         * Function used to get id without hashing
         * @param {string} hashedId
         */
        function getPureId(hashedId) {
            return hashedId && (hashedId.indexOf('$$') > -1 ? hashedId.split('$$')[0] : hashedId);
        }

        /**
         * set URL for associated doc in printview
         * These URL comes from SP
         */
        function setURLofAssocDoc() {
            $scope.assocSPdata = $scope.getValueOfOnLoadData('DS_GEN_DOC_ASSOCIATIONS_CROSS_DC_LIST');
            var objAllAppendix = $scope.AppendixDetails.AllAppendix;
            for (var k = 0; k < objAllAppendix.length; k++) {
                var elem2 = objAllAppendix[k];
                for (var j = 0; j < $scope.assocSPdata.length; j++) {
                    var element3 = $scope.assocSPdata[j];
                    if (element3.Value16 == elem2.docId) {
                        elem2['URL'] = element3.URL15;
                        elem2['docRev'] = element3.Value4;
                        elem2['docOrignator'] = element3.Value11 + ' ' + element3.Value12;
                        elem2['purposeOfIssue'] = element3.Value7;
                        elem2['docStatus'] = element3.Value9;
                    }
                }
            }
        }

        /**
         * Set associated doc value in form
         * @param {Array} docArray
         */
        function setAssocDocs(docArray) {
            var tempObj = [];
            var autoSeq = $scope.AppendixDetails.AllAppendix.length;
            for (var i = 0; i < docArray.length; i++) {
                var element = docArray[i];
                autoSeq = autoSeq + 1;
                tempObj.push({
                    docRef: element.isPrivate ? element.docRef.split('#filetype')[0] : element.docRef,
                    docTitle: element.title,
                    docOrignator: element.publisher,
                    purposeOfIssue: element.purposeOfIssue,
                    docStatus: element.status,
                    docRev: element.revisionNum,
                    revId: getPureId(element.revisionId),
                    docId: getPureId(element.documentId),
                    docOrignatorId: getPureId(element.publisherId),
                    docProjectId: getPureId(element.projectId),
                    Association_ProjectId_RevisionId: getPureId(element.projectId) + "#" + getPureId(element.revisionId),
                    AppendixOrder: autoSeq,
                    Acknowledge: "",
                    Association_RevisionId_ProjectId_FolderId: getPureId(element.revisionId) + "#" + getPureId(element.projectId) + "#" + getPureId(element.folderId)
                });
            }

            $scope.AppendixDetails.AllAppendix = $scope.AppendixDetails.AllAppendix.concat(angular.copy(tempObj));

            // setting sequence for AppendixOrder...
            var order = 0;
            for (; order < $scope.AppendixDetails.AllAppendix.length; order++) {
                $scope.AppendixDetails.AllAppendix[order].AppendixOrder = order + 1;
            }

        }

        /**
         * Function used to remove Association from platform via form
         * @param {Array} removedDocs : Array of revision id which are removed
         */
        function removeAssocDocs(removedDocs) {
            var isAnyRemoved = false;
            if (!assocFileService) {
                assocFileService = htmlformservice.assocFileService;
            }
            if (assocFileService && assocFileService.ctrl.assoc.files.data && assocFileService.ctrl.assoc.files.data.length) {
                for (var i = 0; i < assocFileService.ctrl.assoc.files.data.length; i++) {
                    var element = assocFileService.ctrl.assoc.files.data[i];
                    if (removedDocs.indexOf(getPureId(element.revisionId)) > -1) {
                        assocFileService.scope.deleteItemTL(undefined, undefined, element, i, assocFileService.scope.listing.files.listingType);
                        isAnyRemoved = true;
                        break;
                    }
                }
            }

            if (isAnyRemoved) {
                removeAssocDocs(removedDocs);
                var filesData = angular.copy(assocFileService.scope.listing.files);
                filesData.data = angular.copy(assocFileService.ctrl.assoc.files.data);
                filesData.totalDocs = assocFileService.ctrl.assoc.files.data.length;
                assocFileService.scope.listing.files = angular.copy(filesData);
            }
        }

        /**
         * Delete item Association when remove item from table
         * And also need to associted doc
         */
        $scope.deleteAssociationItem = function (index, tableName) {
            var arrayTable = [];

            $scope.AppendixDetails.AllAppendix.splice(index, 1);
            arrayTable = $scope.AppendixDetails.AllAppendix;

            var backupRevIds = [];
            var tempAssocBackupArray = ASSOC_BACKUP[tableName];
            for (var key in tempAssocBackupArray) {
                if (tempAssocBackupArray.hasOwnProperty(key)) {
                    var element = tempAssocBackupArray[key];
                    element && backupRevIds.push(element.revId)
                }
            }

            var afterRemoveList = [];
            for (var k = 0; k < arrayTable.length; k++) {
                arrayTable[k] && afterRemoveList.push(arrayTable[k].revId)
            }

            var removedDocs = commonApi._.difference(backupRevIds, afterRemoveList);

            removeAssocDocs(removedDocs);
        }

        // Attachment logic
        $scope.AttachmentNode = {
            "Attachment_Sequence": "",
            "Attachment_Reference": ""
        }

        $scope.AddNewRow = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        }

        //reorder button click order association
        $scope.reOrderAssociation = function () {
            var objAllDocAssoc = $scope.AppendixDetails.AllAppendix;
            objAllDocAssoc = commonApi._.sortBy(objAllDocAssoc, function (element) {
                return parseInt(element.AppendixOrder)
            });
            if (objAllDocAssoc) {
                $scope.AppendixDetails.AllAppendix = [];
                $scope.AppendixDetails.AllAppendix = objAllDocAssoc;
            }
        }

        //appendix name button click in response view
        $scope.onAppendixNameChange = function (objCurrent) {
            for (var i = 0; i < $scope.AppendixDetails.AllAppendix.length; i++) {
                if ($scope.AppendixDetails.AllAppendix[i].docRef == objCurrent.AppendixName) {
                    objCurrent.AppendixDescription = $scope.AppendixDetails.AllAppendix[i].docTitle;
                    objCurrent.AppendixDocRef = $scope.AppendixDetails.AllAppendix[i].docRef;
                    break;
                }
            }
        }

        //delete button click in response view used. this generic function for this app
        $scope.DeleteRow = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        }

        /**
         * Click event to add new assocition button to open association view
         */
        $scope.openCustomDocAssoc = function () {
            ASSOC_BACKUP[STATIC_OBJECTS.appendixTable] = angular.copy($scope.AppendixDetails.AllAppendix);
            $scope.openAssociation('files');
        }

        // formating date with suffix i.e. 1st, 2nd,...
        function dayFormat(day) {

            var month = day.split(" ")[1];
            var year = day.split(" ")[2];
            day = day.split(" ")[0];

            if (day >= 11 && day <= 13) {
                day = day + "_th";
            } else {
                var day2 = (day / 10).toString().split(".")[1];
                if (day == 1 || day2 == '1') {
                    day = day + "_st";
                } else if (day == 2 || day2 == '2') {
                    day = day + "_nd";
                } else if (day == 3 || day2 == '3') {
                    day = day + "_rd";
                } else {
                    day = day + "_th";
                }
            }

            return (day + " " + month + " " + year);

        }

        $window.subcontractAgreementFinalCallBack = function () {
            var strCurrentFormStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
            if (currentViewName == "ORI_VIEW") {
                var flag = validationAcrossAllTabs();
                if (flag == "1") {
                    alert("Please fill all mandatory fields in sub contract agreement tab");
                    return true;
                }
                if (flag == "2") {
                    alert("Please fill all mandatory fields in self billing agreement tab");
                    return true;
                }
                $scope.acf01.ACF_01_DS_CLOSE_DUE_DATE = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'];
                var concatAllUsers = $scope.oriSignatoriesSubContractor.concat($scope.oriSignatoriesLOR);

                for (var i = 0; i < concatAllUsers.length; i++) {
                    $scope.asiteSystemDataReadWrite.Auto_PDF_Distribution_Group.Auto_PDF_Distribution_Users.push({
                        DS_PDF_DISTRIBUTION: concatAllUsers[i].Name.split('#')[0].trim() + "#" + concatAllUsers[i].Email || ''
                    });
                }

                if (!$scope.oriMsgCustomFields.Contractor) {
                    alert("Please select contractor for distribution.");
                    return true;
                }

                $scope.asiteSystemDataReadWrite.DS_USER_ROLE_ASSIGNMENT_FLAG = true;
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMAUTONO_PREFIX'] + "<<NEXT_AUTONO>>";
                //format of ori form title : Workspace Name | "Folio" / "Sub Ref" | "In relation to | Subcontractor Name"
                var strFormTitle = $scope.asiteSystemDataReadOnly._3_Project_Data.DS_PROJECTNAME + " | " + $scope.oriMsgCustomFields.ContractFolio + " / " + $scope.oriMsgCustomFields.ContractSubRef + " | " + $scope.oriMsgCustomFields.InRelationTo + " | " + $scope.acf01.ACF_01_SubcontractName;
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_FORMTITLE = strFormTitle.substr(0, 100);
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: 1
                });
                $scope.oriMsgCustomFields.Coins_Refname = $scope.oriMsgCustomFields.ContractFolio + " / " + $scope.oriMsgCustomFields.ContractSubRef;

                $scope.acf01.ACF_01_SelfBilleContractDate =  dayFormat( $scope.oriMsgCustomFields.SelfBilleContractDate_ori_view);

                var commercialTeam = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                    return (val.Value.split('#')[0].split('|')[0].trim().indexOf('Commercial Team') === 0);
                });

                if (commercialTeam.length) {
                    //Clear respond actions
                    clearAction();

                    var tempList = [];
                    for (var j = 0; j < commercialTeam.length; j++) {
                        tempList.push({
                            strUser: commercialTeam[j].Value.split('|')[2].trim(),
                            strAction: "3#Respond",
                            strDate: commonApi.calculateDistDateFromDays({
                                baseDate: $scope.serverDate,
                                days: 3
                            })
                        });
                    }

                    commonApi.setDistributionNode({
                        actionNodeList: tempList,
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: 3
                    });

                    mergeAssocAndAttachmentDataInGenericTable();

                    setFormStatus('Issued to Commercial team');
                    return false;
                } else {
                    alert("There is no user exist in Commercial Team Role. Please Contact your Workspace Administrator");
                    return true;
                }
            } else if (currentViewName == "RES_VIEW") {
                if ($scope.isCommercialTeamUser) {
                    $scope.resMsgCustomFields.CommercialTeamResposeActionDetails = $scope.commercialTeamResposeActionDetails;
                }

                if ($scope.isProcurement && ($scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == 'Issued to Procurement team' || ($scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == 'Under-Review' && isAllCommentsRejectedByContractor()))) {
                    $scope.resMsgCustomFields.ProcurementTeamResposeActionDetails = $scope.procurementTeamResposeActionDetails;

                    // confirmation for send...
                    if (!confirm('You are sending the agreement to the subcontractor, do you wish to continue?')) {
                        return true;
                    }
                }

                //Clear respond actions
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                clearAction();

                if ($scope.resMsgCustomFields.SendForSignature) {
                    // validation across all tabs for res_view signatories workflow...
                    if ($scope.resMsgCustomFields.SignStage == '0') {
                        var flag1 = validationAcrossAllTabResponse();
                        if (flag1 == "sub-contract sign empty") {
                            alert("Please ensure that the subcontract agreement has been signed.");
                            return true;
                        }
                        if (flag1 == "self billing sign empty") {
                            alert("Please ensure the self-billing agreement has been signed.");
                            return true;
                        }
                        if (flag1 == "1") {
                            alert("Please fill all mandatory fields in subcontract agreement tab");
                            return true;
                        }
                    }
                    if ($scope.oriMsgCustomFields.SubContractorSignatoryOne == 'Automated' && $scope.oriSignatoriesLOR[0].isLOR_Approved1 == false && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.oriSignatoriesSubContractor[0].Sign = $scope.subContractorAutomatedSignOne;
                    }
                    if ($scope.oriMsgCustomFields.ContractorSignatoryOne == 'Automated' && $scope.oriSignatoriesLOR[0].isLOR_Approved1 == true && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.oriSignatoriesLOR[0].Sign = $scope.contractorAutomatedSignOne;
                    }
                    if ($scope.oriMsgCustomFields.SubContractorSignatorySelfBilling == 'Automated' && $scope.oriSignatoriesLOR[0].isLOR_Approved1 == false && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.oriSignatoriesSubContractorSelfBilling.Sign = $scope.subContractorAutomatedSignSelfBilling;
                    }
                    if ($scope.oriMsgCustomFields.ContractorSignatorySelfBilling == 'Automated' && $scope.oriSignatoriesLOR[0].isLOR_Approved1 == true && $scope.resMsgCustomFields.SignStage == "0") {
                        $scope.oriSignatoriesContractorSelfBilling.Sign = $scope.contractorAutomatedSignSelfBilling;
                    }
                    var responseUserId = "";
                    if ($scope.oriSignatoriesSubContractor[0].isSubContractorApproved1 == false) {
                        $scope.oriSignatoriesSubContractor[0].isSubContractorApproved1 = true;
                        $scope.resMsgCustomFields.SignStage = 0;
                        responseUserId = $scope.oriSignatoriesSubContractor[0].Name.split('#')[0].trim();
                        setFormStatus('Issue For Signature');
                    } else if ($scope.oriSignatoriesSubContractor[0].isSubContractorApproved1 &&
                        $scope.oriSignatoriesLOR[0].isLOR_Approved1 == false) {
                        $scope.oriSignatoriesLOR[0].isLOR_Approved1 = true;
                        responseUserId = $scope.oriSignatoriesLOR[0].Name.split('#')[0].trim();
                        setFormStatus('Issue For Signature');
                    } else if ($scope.oriSignatoriesLOR[0].isLOR_Approved1) {
                        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = "LOR-SLF-BLG";
                        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "1";
                        $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";

                        $scope.acf01.ACF_01_SelfBillingAgreementDate = dayFormat($scope.todayDateUKFormat);
                        $scope.acf01.ACF_01_SubcontractDate = dayFormat($scope.todayDateUKFormat);
                        $scope.oriMsgCustomFields.subContractorDate = dayFormat($scope.todayDateUKFormat);

                        $scope.acf01.ACF_01_SubcontractReference = $scope.oriMsgCustomFields.ContractFolio + " / " + $scope.oriMsgCustomFields.ContractSubRef;

                        //formcontent1
                        $scope.acf01.ACF_01_DS_FORMCONTENT1 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AppBuilderID'];

                        $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AUTO_ASSOC_DOCS'] = "";
                        var arrayAllDocDetails = [];
                        var objAllDocAssoc = $scope.AppendixDetails.AllAppendix;
                        objAllDocAssoc = commonApi._.sortBy(objAllDocAssoc, function (element) {
                            return parseInt(element.AppendixOrder)
                        });
                        for (var i = 0; i < objAllDocAssoc.length; i++) {
                            if (objAllDocAssoc[i].docRef != "Self Billing") {
                                arrayAllDocDetails.push(objAllDocAssoc[i].Association_RevisionId_ProjectId_FolderId);
                            }
                        }
                        $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AUTO_ASSOC_DOCS'] = arrayAllDocDetails.join();

                        $scope.acf01.ACF_01_REPEATING_VALUES.ACF_01_Signatories_SubContractor_Group.ACF_01_Signatories_SubContractor_USERS = [];
                        $scope.acf01.ACF_01_REPEATING_VALUES.ACF_01_Signatories_Contractor_Group.ACF_01_Signatories_Contractor_USERS = [];
                        var oriSignatoriesSubContractorSelfBilling = $scope.oriMsgCustomFields["Signatories_SubContractor_SelfBilling"];
                        var oriSignatoriesContractorSelfBilling = $scope.oriMsgCustomFields["Signatories_Contractor_SelfBilling"];
                        var oriSignatoriesSubContractor = $scope.oriMsgCustomFields["Signatories_SubContractor"];
                        var oriSignatoriesLOR = $scope.oriMsgCustomFields["Signatories_LOR"];
                        if (oriSignatoriesSubContractorSelfBilling.Sign) {
                            $scope.acf01.ACF_01_REPEATING_VALUES.ACF_01_Signatories_SubContractor_Group.ACF_01_Signatories_SubContractor_USERS.push({
                                name: oriSignatoriesSubContractor[0].Name.split('#')[1].split(',')[0].trim(),
                                dbUserId: oriSignatoriesSubContractor[0].Name.split('#')[0].trim(),
                                sign: oriSignatoriesSubContractorSelfBilling.Sign,
                                automatedAndManualFlag: $scope.oriMsgCustomFields.SubContractorSignatorySelfBilling,
                                role: oriSignatoriesSubContractor[0].Role
                            })
                        }

                        if (oriSignatoriesContractorSelfBilling.Sign) {
                            $scope.acf01.ACF_01_REPEATING_VALUES.ACF_01_Signatories_Contractor_Group.ACF_01_Signatories_Contractor_USERS.push({
                                name: oriSignatoriesLOR[0].Name.split('#')[1].split(',')[0].trim(),
                                dbUserId: oriSignatoriesLOR[0].Name.split('#')[0].trim(),
                                sign: oriSignatoriesContractorSelfBilling.Sign,
                                automatedAndManualFlag: $scope.oriMsgCustomFields.ContractorSignatorySelfBilling,
                                role: oriSignatoriesLOR[0].Role
                            })
                        }
                        var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
                        var currFormStaus = 'Signed';
                        // Form's Staus will be set from below code.
                        var strFormStatusId = commonApi.getFormStatusId({
                            availFormStatusesList: availFormStatuses,
                            strStatus: currFormStaus
                        });
                        $scope.acf01.ACF_01_DS_ALL_FORMSTATUS = strFormStatusId && strFormStatusId.split("#")[0].trim();
                        setFormStatus('Signed');
                    }

                    commonApi.setDistributionNode({
                        actionNodeList: [{
                            strUser: responseUserId,
                            strAction: "3#Respond",
                            strDate: commonApi.calculateDistDateFromDays({
                                baseDate: $scope.serverDate,
                                days: 3
                            })
                        }],
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: 13
                    });

                    $scope.showCorrectValue = false;

                    if ($scope.AppendixDetails.AllAppendix.length > 0 && $scope.AppendixDetails.AllAppendix[0].Acknowledge) {
                        $scope.oriMsgCustomFields.firstContractorAgreeAppendices = true;
                        $scope.oriMsgCustomFields.ContractOrderDate = $scope.todayDateUKFormat;
                    }

                    return false;
                } else if (($scope.isProcurement && $scope.procurementTeamResposeActionDetails.Status === "ACCEPTED") ||
                    ($scope.isProcurement && !$scope.resMsgCustomFields.SendForSignature && isAllCommentsRejectedByContractor())) {
                    commonApi.setDistributionNode({
                        actionNodeList: [{
                            strUser: $scope.oriMsgCustomFields.Contractor,
                            strAction: "3#Respond",
                            strDate: commonApi.calculateDistDateFromDays({
                                baseDate: $scope.serverDate,
                                days: 3
                            })
                        }],
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: 13
                    });

                    if ($scope.resMsgCustomFields.IssuedFirstTimeByCT) {
                        setFormStatus('Under-Review');
                    } else {
                        $scope.resMsgCustomFields.IssuedFirstTimeByCT = true;
                        setFormStatus('Issued to Sub-Contractor');
                    }
                } else {
                    var team = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                        if (($scope.isProcurement && $scope.procurementTeamResposeActionDetails.Status === "REJECTED") || ($scope.isCommercialTeamUser && $scope.commercialTeamResposeActionDetails.Status === "REJECTED") || ($scope.isContractor && !$scope.resMsgCustomFields.SendForSignature) || ($scope.isCommercialTeamUser && $scope.commercialTeamResposeActionDetails.Status === "ACCEPTED")) {
                            return val.Value.indexOf($scope.resMsgCustomFields.OriginatorId) !== -1 && val.Value.indexOf('Procurement') !== -1;
                        }
                        return (val.Value.indexOf('Commercial Team') !== -1);
                    });

                    if (team.length) {
                        var tempList = [];
                        for (var j = 0; j < team.length; j++) {
                            tempList.push({
                                strUser: team[j].Value.split('|')[2].trim(),
                                strAction: "3#Respond",
                                strDate: commonApi.calculateDistDateFromDays({
                                    baseDate: $scope.serverDate,
                                    days: 3
                                })
                            });
                        }

                        commonApi.setDistributionNode({
                            actionNodeList: tempList,
                            autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                            asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                            DS_AUTODISTRIBUTE: 13
                        });

                        if (strCurrentFormStatus != 'Issue For Signature') {
                            if ($scope.isCommercialTeamUser && $scope.commercialTeamResposeActionDetails.Status === "ACCEPTED") {
                                setFormStatus('Issued to Procurement team');
                            } else if ($scope.isCommercialTeamUser && $scope.commercialTeamResposeActionDetails.Status === "REJECTED") {
                                setFormStatus('Rejected by Commercial team');
                            } else if ($scope.isProcurement && $scope.procurementTeamResposeActionDetails.Status === "REJECTED") {
                                setFormStatus('Rejected by Procurement team');
                            } else if ($scope.isContractor) {
                                if ($scope.resMsgCustomFields.SendForSignature) {
                                    setFormStatus('Issue For Signature');
                                } else {
                                    setFormStatus('Under-Review');
                                }
                            } else {
                                setFormStatus('Issued to Commercial team');
                            }
                        }
                        if ($scope.isContractor && (strCurrentFormStatus == "Issued to Sub-Contractor" || strCurrentFormStatus == "Under-Review")) {
                            mergeAssocAndAttachmentDataInGenericTable();
                        }
                    } else {
                        alert("The user to whom this form is being sent to, is not in the correct role.");
                        return true;
                    }
                }
            }

            return false;
        }

        function mergeAssocAndAttachmentDataInGenericTable() {
            $scope.oriMsgCustomFields.DSi_Seq.DSi_Seq_Table = [];
            var objAllDocAssoc = $scope.AppendixDetails.AllAppendix;
            objAllDocAssoc = commonApi._.sortBy(objAllDocAssoc, function (element) {
                return parseInt(element.AppendixOrder)
            });
            for (var i = 0; i < objAllDocAssoc.length; i++) {
                if (objAllDocAssoc[i].docRef == "Self Billing") {
                    $scope.oriMsgCustomFields.DSi_Seq.DSi_Seq_Table.push({
                        "DSi_Flag": "FA",
                        "DSi_Sequence": objAllDocAssoc[i].AppendixOrder,
                        "DSi_Reference": projectId && projectId.split('$$')[0] + "#<<DS_DBformid_Child24>>"
                    });
                } else {
                    $scope.oriMsgCustomFields.DSi_Seq.DSi_Seq_Table.push({
                        "DSi_Flag": "AS",
                        "DSi_Sequence": objAllDocAssoc[i].AppendixOrder,
                        "DSi_Reference": objAllDocAssoc[i].Association_ProjectId_RevisionId
                    });
                }
            }
        }

        var getAllCommentsStatus = function () {
            var aCommentStatus = [];

            $scope.resAppendicesDetails.forEach(function (item) {
                aCommentStatus.push(item.Status);
            });

            return aCommentStatus;
        }

        var isAllCommentsRejectedByContractor = function () {
            var aCommentStatus = getAllCommentsStatus();
            return (!!aCommentStatus.length && aCommentStatus.indexOf('ACCEPTED') === -1);
        }

        /**
         * Form's workflow logic
         */
        function setFormStatus(status) {
            var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
            var currFormStaus = status || 'Open';
            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: availFormStatuses,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }
        };

        function scrollIntoView(elementId) {
            var ele = elementId && document.getElementById(elementId);
            if (ele) {
                scrollToView(ele.offsetTop);
            }
        }

        function scrollToView(top) {
            window.scrollTo(0, top);
        }

        function clearAction() {
            var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == 'Respond';
            });
            if (ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                for (var i = 0; i < ActionData.length; i++) {
                    var AutocompleteMsg = angular.copy(autocompleteMsgStructure);
                    AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
                    AutocompleteMsg.DS_MSG_AC_FORM = AppId;
                    AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
                    AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
                    AutocompleteMsg.DS_MSG_AC_ACTION = "3";
                    AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                    insertpoint.push(AutocompleteMsg);
                }
            }
        }

        function validationAcrossAllTabResponse() {
            if ($scope.oriSignatoriesLOR[0].isLOR_Approved1 == false) {
                // valition for general tab...          
                if (($scope.oriMsgCustomFields.SubContractorSignatoryOne == "Manual" && !$scope.oriSignatoriesSubContractor[0].Sign) || !$scope.oriSignatoriesSubContractor[0].Role) {
                    return "sub-contract sign empty";
                }

                // validation for self billing tab...
                if (($scope.oriMsgCustomFields.SubContractorSignatorySelfBilling == 'Manual' && !$scope.oriSignatoriesSubContractorSelfBilling.Sign) || !$scope.oriSignatoriesSubContractor[0].Role) {
                    return "self billing sign empty";
                }

                // for checking Appendices and Annexures...
                for (var item1 = 0; item1 < $scope.AppendixDetails.AllAppendix.length; item1++) {
                    if (!$scope.AppendixDetails.AllAppendix[item1].Acknowledge) {
                        return "1";
                    }
                }
            }

            if ($scope.oriSignatoriesLOR[0].isLOR_Approved1 == true) {
                if (($scope.oriMsgCustomFields.ContractorSignatoryOne == 'Manual' && !$scope.oriSignatoriesLOR[0].Sign) || !$scope.oriSignatoriesLOR[0].Role) {
                    return "sub-contract sign empty";
                }

                // validation for self billing tab...
                if (($scope.oriMsgCustomFields.ContractorSignatorySelfBilling == "Manual" && !$scope.oriSignatoriesContractorSelfBilling.Sign) || !$scope.oriSignatoriesLOR[0].Role) {
                    return "self billing sign empty";
                }
            }
        }

        // validation across all tabs for 
        function validationAcrossAllTabs() {

            // for checking Appendices and Annexures...
            var item2 = 0;
            for (; item2 < $scope.AppendixDetails.AllAppendix.length; item2++) {
                if (!$scope.AppendixDetails.AllAppendix[item2].AppendixOrder || !$scope.AppendixDetails.AllAppendix[item2].docTitle || !$scope.AppendixDetails.AllAppendix[item2].docRef) {
                    return "1";
                }
            }

            // validation for general tab...
            if (!$scope.oriMsgCustomFields.ContractFolio || !$scope.oriMsgCustomFields.ContractSubRef || !$scope.oriMsgCustomFields.InRelationTo) {
                return "1";
            }

            // validation for self billing...
            if (!$scope.acf01.ACF_01_LOR_CompanyNumber || !$scope.acf01.ACF_01_ContractorRegistrationNo || !$scope.acf01.ACF_01_SubcontractName || !$scope.acf01.ACF_01_SubcontractCompanyNo || !$scope.acf01.ACF_01_SubcontractAddress || !$scope.acf01.ACF_01_SubcontractRegistrationNo || !$scope.oriMsgCustomFields.SelfBilleContractDate_ori_view) {
                return "2";
            }
        }

        $scope.update();
    }

    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof subcontractAgreementFinalCallBack !== "undefined") {
        return subcontractAgreementFinalCallBack();
    }
}