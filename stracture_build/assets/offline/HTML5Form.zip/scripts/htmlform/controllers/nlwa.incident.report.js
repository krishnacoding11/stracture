/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayTime = commonApi.convertTimeformat(serverDate, true).toUpperCase();

            if($scope.strFormId == "") {
                $scope.oriMsgCustomFields.IncidentDetail.ReportedDate = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');;
                $scope.oriMsgCustomFields.IncidentDetail.ReportedTime = $scope.todayTime;
                $scope.oriMsgCustomFields.IncidentReportedDetail.Date = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');;
                $scope.oriMsgCustomFields.IncidentReportedDetail.Time = $scope.todayTime;
            }
        });

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');

        $scope.update();

        if(currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.Originator = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
            $scope.oriMsgCustomFields.IncidentReportedDetail.PersonName = $scope.oriMsgCustomFields.Originator.Name;

            var IncidentClassificationRoleConfigurableAttributes = $scope.getValueOfOnLoadData('DS_GET_ATTRIBUTE_SET_DTLS');
            $scope.typeWiseRoles = {};

            $scope.incidentClassificationRoleConfigurableAttributeType = [ ];
            IncidentClassificationRoleConfigurableAttributes.forEach(function(data) {
                if(data.Value8 !== "Incident Roles") {
                return; 
                }

                if($scope.typeWiseRoles[data.Value7]) {
                    $scope.typeWiseRoles[data.Value7].push(data.Value9);
                    return;
                }

                $scope.typeWiseRoles[data.Value7] = [data.Value9];
                $scope.incidentClassificationRoleConfigurableAttributeType.push({
                    modelValue: data.Value7,
                    displayValue: data.Value6
                });
            });
            
            $scope.incidentClassificationRoleConfigurableAttributeType.sort(function(item1, item2) {
                if(item1.modelValue === item2.modelValue) {
                    return 0;
                }
                if(item1.modelValue < item2.modelValue) {
                    return -1;
                }
                return 1;
            });
            
        }

        $scope.dateRepotedValidation = function(){
            var reportedDate = $scope.oriMsgCustomFields.IncidentDetail.ReportedDate;
            var incidentDate = $scope.oriMsgCustomFields.IncidentReportedDetail.Date;
            if(reportedDate && incidentDate){
                var reportedDateObj = commonApi.parseDate('dd/mm/yy', reportedDate);
                var incidentDateObj = commonApi.parseDate('dd/mm/yy', incidentDate);

                if( incidentDateObj && reportedDateObj && incidentDateObj.getTime() > reportedDateObj.getTime()) {
                    $window.alert("Validation \n\n Date reported should be greater than Incident date.");
                    $scope.invalidReportedDate = true;
                    return false;
                }
            }

            $scope.invalidReportedDate = false;
            return true;
        }

        $scope.incidentTimeValidation = function(){
            var dateOfIncident = $scope.oriMsgCustomFields.IncidentReportedDetail.Date;
            var dateOfReported = $scope.oriMsgCustomFields.IncidentDetail.ReportedDate;

            var timeOfIncident = $scope.oriMsgCustomFields.IncidentReportedDetail.Time;
            var timeOfReported = $scope.oriMsgCustomFields.IncidentDetail.ReportedTime;

            if(dateOfIncident && dateOfReported && timeOfIncident && timeOfReported && dateOfIncident == dateOfReported){
                var incDate = commonApi.parseDate('dd/mm/yy', dateOfIncident);
                var repDate = commonApi.parseDate('dd/mm/yy', dateOfReported);

                var incTime = get24HrDate(timeOfIncident);
                var repTime = get24HrDate(timeOfReported);

                var incDateParse = mergeTimeInDate(incDate, incTime);
                var repDateParse = mergeTimeInDate(repDate, repTime);
                
                if(incDateParse > repDateParse) {
                    $window.alert("Validation \n\n Time reported should be greater than Incident time.");
                    $scope.invalidReportedTime = true;
                    return false;
                }
            }

            $scope.invalidReportedTime = false;
            return true;
        }

        function get24HrDate(strTime){
            var tmpTime = strTime.toUpperCase().split(':');
            if(strTime.indexOf('PM') > -1 && tmpTime[0] < 12){
                tmpTime[0] = parseInt(tmpTime[0])+12;
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }else{
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }
        }

        function mergeTimeInDate(dateObj , timeArray){
            dateObj.setHours(timeArray[0]);
            dateObj.setMinutes(timeArray[1]);
            
            return dateObj;
        }

        $window.nlwaIncidentFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {

                if($scope.invalidReportedDate) {
                    $window.alert("Validation \n\n Date reported should be greater than Incident date.");
                    return true;
                }

                if($scope.invalidReportedTime) {
                    $window.alert("Validation \n\n Time reported should be greater than Incident time.");
                    return true;
                }

                var allRoles = $scope.typeWiseRoles[$scope.oriMsgCustomFields.InitialClassificationDetails.ListOfIncidents] || [];
                var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
                var members = commonApi._.filter(DS_PROJUSERS_ROLE, function (member) {
                    return (allRoles.indexOf(member.Value.split('|')[0].trim()) !== -1)
                });

                if (members.length) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    $scope.oriMsgCustomFields.CreationDate = $scope.todayDateDbFormat;
                    $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF = $scope.todayDateDbFormat;
                    $scope.asiteSystemDataReadWrite.ORI_FORMTITLE = $scope.oriMsgCustomFields.IncidentDetail.Title;
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;

                    var teamList = [];
                    members.forEach(function(member) {
                        teamList.push({
                            strUser: member.Value.split('|')[2].trim(),
                            strAction: "7#For Information",
                            strDate : ""   
                        });
                    });

                    commonApi.setDistributionNode({
                        actionNodeList: teamList,
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: 3
                    });
                    return false;
                }else {
                    alert("There is no user exist in selected Role.");
                    return true;
                }
            }
            
            return false;
        }

        $window.nlwaDraftSubmitCallBack = function () {
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
            return false;
        }
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {
    if (typeof nlwaIncidentFinalCallBack !== "undefined") {
        return nlwaIncidentFinalCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return nlwaDraftSubmitCallBack();
	}
}