/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.data.myFields.FORM_CUSTOM_FIELDS.Todays_Date = $scope.todayDateDbFormat;
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();
        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        $scope.isRespond = false;

        var STATIC_OBJ_DATA = {
            sections: {
                "sectionName": "",
                "activityCode": "",
                "nopDropdown": "",
                "originalPrice": "",
                "totalAddition": "",
                "currentAddition": "",
                "fee": "",
                "revisedPrice": "",
                "impactStartDate": "",
                "impactEndDate": ""
            },
            Impacted_Key_Dates: {
                "Key_Date_Id": "",
                "Date_Description": "",
                "KD_Current_Additions": "",
                "Date_Type": "",
                "Date_Ref": "",
                "KD_Sel": "",
                "key_isSelected": ""
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                dist_isSelected: false,
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
            allClauseComment: {
                "clause": "",
                "cls_isSelected": "",
                "clauseComment": ""
            }
        };

        $scope.tableUtilSettings = {
            allClauseComment: {
                tooltip: "Remove Clause details",
                editRowCallBack: "",
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "cls_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.allClauseComment),
                deleteAllRowTooltip: "Remove all Clause details",
                deleteCurrRowMsg: "Remove Clause details",
                deleteSelectedMsg: "Remove selected Clause details",
                deleteItemCallBack: function () { }
            },
            sections: {
                tooltip: "Remove Clause details",
                editRowCallBack: "",
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sections),
                deleteAllRowTooltip: "Remove all Clause details",
                deleteCurrRowMsg: "Remove Clause details",
                deleteSelectedMsg: "Remove selected Clause details",
                deleteItemCallBack: function () { }
            },
            Impacted_Key_Dates: {
                tooltip: "Remove Clause details",
                editRowCallBack: "",
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "key_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Impacted_Key_Dates),
                deleteAllRowTooltip: "Remove all Clause details",
                deleteCurrRowMsg: "Remove Clause details",
                deleteSelectedMsg: "Remove selected Clause details",
                deleteItemCallBack: function () { }
            }
        }

        var DS_GET_ALL_PREV_FORMS;
        var PAA_CONSTANT = {
            refered: "Referred",

            respond: "Respond",
            forInformation: "For Information",
            oriDistNumb: 3,
            resDistNumb: 13,
            Open: 'Open',
            Closed: 'Closed',

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
        }

        $scope.clauseList = [];

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.clauseCommentGroup = $scope.oriMsgCustomFields["clauseCommentGroup"];
        $scope.SectionsGroup = $scope.oriMsgCustomFields["SectionsGroup"];
        $scope.Prog_Changes = $scope.oriMsgCustomFields["Prog_Changes"];
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
        $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var DS_PAA_Contract_Activity_Group_dtls = $scope.getValueOfOnLoadData('DS_PAA_Contract_Activity_Group_dtls');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        $scope.DS_PAA_MPC_IS_USER_CONTRACTOR = $scope.getValueOfOnLoadData('DS_PAA_MPC_IS_USER_CONTRACTOR');
        $scope.DS_PAA_MPC_GET_REF_FORM_URL_DTLS = $scope.getValueOfOnLoadData('DS_PAA_MPC_GET_REF_FORM_URL_DTLS');

        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        $scope.sectionGroup = $scope.resMsgCustomFields.Cost_Changes;
        $scope.keyMilestones = $scope.resMsgCustomFields.Prog_Changes;
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;

        $scope.selectionlist = {
            setContractlist: [],
            dearUserlist: [],
            EVNList: [],
            SectionList: [],
        }
        var SECTION_ARRAY = [];
        var DS_PAA_MPC_KEY_DATES_SUMMARY;
        $scope.oriMsgFields.DS_DB_INSERT = false;
        if (currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            if ($scope.strFormId && $scope.strIsDraft == "NO") {
                $scope.oriMsgFields.DS_AUTODISTRIBUTE = "";
            }
            $scope.resMsgCustomFields.All_Responses.Responses = [];
            var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
            $scope.selectionlist.setContractlist = commonApi.getItemSelectionList({
                arrayObject: contractData,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        if (currentViewName == "RES_VIEW") {
            $scope.isRespond = true;
            $scope.resMsgCustomFields.Responder_Name = $scope.dsWorkingUser;
        }
        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break;
                }
            }
        }
        if (currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields.Contract) {
            onContractchangeFn($scope.oriMsgCustomFields.Contract, true);
        }

        $scope.update();
        $scope.addNewItem = function (repeatingData, objKeyName, parentRow) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);
                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        /**
         * function used to set value in referenceForms field which used to get URL in print view
         * referenceForms value i.e PAA-MPC-ENA|ENA012,PAA-MPC-ENO|ENO014
         * @param {Array|string} refVal : if item selection is multiple then refVal is array otherwise string
         */
        $scope.onRefChange = function (refVal) {
            $scope.oriMsgCustomFields['referenceForms'] = "";
            if (refVal) {
                var selObj = commonApi._.map(DS_GET_ALL_PREV_FORMS, function (obj) {
                    return refVal.indexOf(obj.NewValue) > -1 ? obj.Value6 + "|" + obj.Value2 : "";
                }).filter(function (obj) { return !!obj });
                if (selObj) {
                    $scope.oriMsgCustomFields['referenceForms'] = selObj.join(',');
                }
            }
        }

        $scope.onContractchange = onContractchangeFn;
        function onContractchangeFn(conVal, onloadFlag) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var strParam = conVal.split('|')[0].trim();
                var strAppcode = $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS, DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, DS_PAA_MPC_KEY_DATES_SUMMARY,DS_PAA_MPC_SETUP_SECTIONS, DS_PAA_MPC_NEC_ASITE_DM_USED, DS_PAA_MPC_NEC_REASONCODE, DS_PAA_MPC_NEC_FUNDINGTYPE, DS_PAA_Contract_Activity_Group_dtls,DS_GET_ALL_PREV_FORMS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_KEY_DATES_SUMMARY",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_SETUP_SECTIONS",
                            "fieldValue": strParam + ',' + strAppcode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_ASITE_DM_USED",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_REASONCODE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_FUNDINGTYPE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_Contract_Activity_Group_dtls",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_GET_ALL_PREV_FORMS",
                            "fieldValue": "PAA-MPC-ENO | Open | " + strParam + ' | ' + $window.AppBuilderFormIDCode + "$$ PAA-MPC-ENA | Open | " + strParam + " | " + $window.AppBuilderFormIDCode + "$$" + "PAA-MPC-ENO | Open | " + strParam + ' | ' + 'PAA-MPC-AES' + "$$" + "PAA-MPC-ENA | Open | " + strParam + ' | ' + 'PAA-MPC-AES'
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        $scope.isDataLoaded = true;
                        if (!onloadFlag) {
                            DS_PAA_Contract_Activity_Group_dtls = angular.fromJson(response.data['DS_PAA_Contract_Activity_Group_dtls']).Items.Item;
                            $scope.SectionsGroup.sections = [];
                            $scope.Prog_Changes.Impacted_Key_Dates = [];
                        }

                        setKeyDate(response);
                        setEwnList(response);
                        setSectionList(response);
                        setUserList(response);
                        if ($scope.strFormId) {
                            checkUserCanRespond(response);
                        }
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
                        if ($scope.oriMsgCustomFields.Can_Forward) {
                            var chkPermission = strIsUserDraftOnly(response);
                            if (chkPermission.toLowerCase() == "yes") {
                                setSendPermission("Draft");
                            } else {
                                setSendPermission("Send");
                            }
                        }
                    }
                });
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[11].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                setFormContent();

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
            }
        }
        function checkUserCanRespond(response){
            var isrequired = CheckPendingAction(dsWorkingUserId);
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft");
            $scope.oriMsgCustomFields.Can_Forward = "No";
            var userList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
            var objData = commonApi._.filter(userList, function (val) {
                return val.Value.split('|')[2].split('#')[0].trim() == dsWorkingUserId;
            });
            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1";
            }
            if($scope.strIsDraft == "YES"  && isrequired && !strReviewDraft && !$scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "No";
            } else if($scope.strIsDraft == "YES" && !strReviewDraft && $scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
        }
        function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + dsWorkingUserId + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
        }
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.editDraft = "";
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (strNodes) {
                var strUserId = "",
                    strCheckRespond = "";
                for (var i = 0; i < strNodes.length; i++) {
                    $scope.editDraft = "Yes";
                    strUserId = strNodes[i].Value1;
                    strCheckRespond = strNodes[i].Value4;
                    if (strCheckRespond == "Review Draft" && strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }

        function strIsUserDraftOnly(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS)) {
                var resList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < resList.length; i++) {
                    strValue = resList[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "alliance_technical_lead") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft" || !$scope.oriMsgCustomFields.Can_Reply) {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }

        function setUserList(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS)) {
                var resList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
                var ownerUserList = commonApi._.filter(resList, function (obj) {
                    return obj.Value && obj.Value.toLowerCase().indexOf('alliance_leadership_team') > -1;
                });

                $scope.selectionlist.dearUserlist = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(ownerUserList, function (obj) { return obj.Name }),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name",
                    allowBlankSelection: true
                });
            }
        }

        $scope.setKeydatedata = function (currObj, strVal) {
            if (strVal) {
                var objKeydata = commonApi._.filter(DS_PAA_MPC_KEY_DATES_SUMMARY, function (val) {
                    return val.Value2 == strVal
                });
                if (objKeydata.length) {
                    currObj.Key_Date_Id = strVal;
                    currObj.Date_Description = objKeydata[0].Value3;
                    currObj.Date_Type = objKeydata[0].Value7;
                    currObj.Date_Ref = objKeydata[0].Value8
                } else {
                    currObj.Date_Description = ""
                }
            } else {
                $scope.objKeydate = angular.copy($scope.objKeydate);
            }
        }

        $scope.onSectionChange = function (currRow) {
            var selectedSection = commonApi._.filter(SECTION_ARRAY, function (obj) {
                return obj.sectionName == currRow.sectionName;
            })[0];
            if (selectedSection && selectedSection.sectionName) {
                currRow.activityCode = selectedSection.activityCode;
                currRow.nopDropdown = selectedSection.nopDropdown;
                currRow.originalPrice = selectedSection.originalPrice;
                currRow.totalAddition = selectedSection.totalAddition;
            }

            $scope.selectionlist.SectionList = angular.copy($scope.selectionlist.SectionList);
        }

        function setEwnList(response) {
            DS_GET_ALL_PREV_FORMS = angular.fromJson(response.data['DS_GET_ALL_PREV_FORMS']).Items.Item;
            if (DS_GET_ALL_PREV_FORMS && DS_GET_ALL_PREV_FORMS.length) {
                DS_GET_ALL_PREV_FORMS = commonApi._.filter(DS_GET_ALL_PREV_FORMS, function (obj) {
                    obj.NewValue = obj.Value2 + " | " + obj.Value3;
                    return obj;
                });
                $scope.selectionlist.EVNList = commonApi.getItemSelectionList({
                    arrayObject: DS_GET_ALL_PREV_FORMS,
                    groupNameKey: "",
                    modelKey: "NewValue",
                    displayKey: "NewValue"
                });
            }
        }

        function setSectionList(response) {

            if (JSON.parse(response.data.DS_PAA_Contract_Activity_Group_dtls)) {
                var resList = JSON.parse(response.data.DS_PAA_Contract_Activity_Group_dtls).Items.Item;
                for (var i = 0; i < resList.length; i++) {
                    SECTION_ARRAY.push({
                        sectionName: resList[i].Value3.trim() + " | " + resList[i].Value16.trim() + " | " + resList[i].Value9,
                        activityCode: resList[i].Value12.trim(),
                        nopDropdown: resList[i].Value15.trim(),
                        originalPrice: resList[i].Value6.trim(),
                        totalAddition: resList[i].Value14.trim(),
                    });
                }

                $scope.selectionlist.SectionList = commonApi.getItemSelectionList({
                    arrayObject: SECTION_ARRAY,
                    groupNameKey: "",
                    modelKey: "sectionName",
                    displayKey: "sectionName",
                    allowBlankSelection: true
                });

            }
        }

        function setKeyDate(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_KEY_DATES_SUMMARY) && JSON.parse(response.data.DS_PAA_MPC_KEY_DATES_SUMMARY.length)) {
                var keyList = JSON.parse(response.data.DS_PAA_MPC_KEY_DATES_SUMMARY).Items.Item;
                DS_PAA_MPC_KEY_DATES_SUMMARY = angular.copy(keyList);
                $scope.objKeydate = [];
                for (var i = 0; i < keyList.length; i++) {
                    $scope.objKeydate.push({
                        optlabel: "",
                        options: [{
                            displayValue: keyList[i].Name,
                            modelValue: keyList[i].Value2,
                            checked: false
                        }]
                    })
                }
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var strConequences = $scope.oriMsgCustomFields.Consequences;
            var strProbability = $scope.oriMsgCustomFields.Probability;
            var strActionComments = $scope.resMsgCustomFields.Actions_and_Comments;
            var strRRMNotes = $scope.resMsgCustomFields.RRM_Notes;
            var strIncreasePrice = $scope.oriMsgCustomFields.Increase_Price;

            strFormContent = strConAppid + "|" + strConequences + "|" + strProbability + "|" + strActionComments + "|" + strRRMNotes + "|" + strIncreasePrice + "|";

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        function assignUserAction(userToDist, action) {
            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: userToDist,
                    strAction: action,
                    strDate: ''
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: PAA_CONSTANT.oriDistNumb
            });
        }

        /**
         * Function used to change status for reference form
         */
        function changeEWNStatus() {
            var referredStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: PAA_CONSTANT.refered
            });

            var selObj = commonApi._.map(DS_GET_ALL_PREV_FORMS, function (obj) {
                return $scope.oriMsgCustomFields.ewnlist.indexOf(obj.NewValue) > -1 ? obj.Value6.split('-')[0] + '-' + obj.Value6.split('-')[1] + "-" + obj.Value2 : "";
            }).filter(function (obj) { return !!obj });

            var newStatusId = "";
            for (var index = 0; index < selObj.length; index++) {
                newStatusId += index == selObj.length - 1 ? referredStatusId.split('#')[0].trim() : referredStatusId.split('#')[0].trim() + ",";
            }

            selObj = selObj.length && selObj.join(',');

            if (selObj && newStatusId) {
                $scope.asiteSystemDataReadwrite['Form_Status_Change'] = {
                    DS_CHANGE_STATUS_FORMS: selObj,
                    DS_CHANGE_STATUS_IDS: newStatusId
                }
            }
        }

        $window.svrFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not authorised to edit this Draft message. Please click on cancel button to exit.");
					return true;
				}
                if (!$scope.oriMsgCustomFields.Can_Reply) {
                    alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
                    return true;
                }
            }
            if (currentViewName == 'ORI_VIEW') {
                var actionUser = $scope.oriMsgCustomFields.dearUser && $scope.oriMsgCustomFields.dearUser.split('|')[2].trim();
                assignUserAction(actionUser, PAA_CONSTANT.forInfoNumber);
            }
            $scope.oriMsgFields.DS_DB_INSERT = true;
            return false;
        };
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof svrFinalCallBack !== "undefined") {
        return svrFinalCallBack();
    }
}