/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';


	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		var ctrl = this;
		// restrict autosave Draft and hide Save Draft button.
		var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
		$saveDraftBtn && ($saveDraftBtn.style.display = 'none'); 
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					headerScrollBind();
				}, 500);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		var STATIC_OBJECTS = {
			deliverablesDetails : {
				isShow: true,
				placeHolderStatus:"",
				placeHolderUrl:"",
				deDe_isSelected:"",
				guId:"",
				rowIndex:"",				
				selectedFolderName : "",
				folderData : {
					rowIndex:"",
					folderName:"",
					folderPath:"",
					folderId:""
				},
				docRef:"",
				asignee:"",
				fileName:"",
				vdrCodeTitle:"",
				vdrMilestone:"",
				vdrMilestoneDate:"",
				placeHolderCreationDate:"",
				remainingDays : "",
				isNegativeDays : "",
                resubmissionDate:"",
                publishDate:"",			
				BID:"no",
				MDR:"no",
				IOM:"no",				
				docFormat:"",
				docRev:"-",
				docStatus:"",
				docRemarks:"",
				docSysMetaData:{
					rowIndex:""
				},
				selectedDisiplinVal : "",				
				selectedVdrCodeVal:"",
				docCustomMetaData:{
					rowIndex:"",
					attrDiscipline : {                        
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName:""
                    },
                    attrVdrCode : {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName:""
                    }
				},
				trackerDetails : {
					rowIndex:"",
                    documentIds: "",
					revisionIds: "",
					transactionId: "",
					creationStatus : "",
					filterCode: ""
				}
			}
		},	dsProjUsersAllRolse = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			projDistUsersAll = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS'),            
			workspaceFolderPath = $scope.getValueOfOnLoadData('DS_MSP_Get_WorkspaceFolderpath'),
			workspacePOIList = $scope.getValueOfOnLoadData('DS_ProjectPOIList'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
			allRoles = [],			
			submitFlag = false,
			guidNotAvailList = [],
			customAttrValueMap = {
				'selectedDisiplinVal': 'attrDiscipline',				
				'selectedVdrCodeVal': 'attrVdrCode'
			},
			custAttrNameListMap = {
				'selectedDisiplinVal': 'disiplinCustAttr',
				'selectedVdrCodeVal':'vdrCodeCustAttr'
			},
			avilRowDocRefFolderWise = {},		
			distributionNodeStr = {
				DS_PROJDISTUSERS: '',
				DS_FORMACTIONS: '',
				DS_ACTIONDUEDATE: ''
			},
			onLoadJsonBackup = {
				resubmissionDays : '', 
				deliveryToSite : '',
				noOfDays : '',
				readyExWorks: '',
				runDate: '',
				deliverablesDetails : []
			};

			
		$scope.myFields = $scope.data['myFields'];
		$scope.serverDate = "";
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			if(!$scope.DSFormId){				
				var serverDateObj = new Date(serverDate);
					serverDateObj.setDate(serverDateObj.getDate()+5);
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');				
			}
		});
		$scope.ORI_MSG_Custom_Fields = $scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
		$scope.titleDetails = $scope.ORI_MSG_Custom_Fields['titleDetails'];
		$scope.packageDetails = $scope.ORI_MSG_Custom_Fields['packageDetails'];
		$scope.deliverablesDetails = $scope.ORI_MSG_Custom_Fields['deliverablesDetails'] || [];
		$scope.deliverableNotes = $scope.ORI_MSG_Custom_Fields['deliverableNotes'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.DSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID']; 
		$scope.dsDbInserted = $scope.Asite_System_Data_Read_Write['ORI_MSG_Fields']['DS_DB_INSERT'];
		$scope.isFieldsDisplayOnly = ($scope.dsDbInserted && $scope.packageDetails.isStatusAwarded == 'Yes');
		$scope.workspaceName = $scope.Asite_System_Data_Read_Only['_3_Project_Data']["DS_PROJECTNAME"];
		$scope.packageEngineersList = [];
		$scope.availableFoldersList = [];
		$scope.userAsigneeList = [];
		$scope.workspacePOIList = [];
		$scope.hashedFoldersList = [];
		$scope.allUsersList = [];
		$scope.actionList = [];
		$scope.attributeList = [];
		$scope.cutomAttrList = [];
		$scope.disiplinCustAttr = {};
		$scope.docTypeCustAttr ={};
		$scope.vdrCodeCustAttr ={};
		$scope.item = { 
			folderName : '',
			folderPath : '',
			folderId : '',
			rowIndex: '',
			isForBulkApply : false        
		};
		$scope.xhr = {			
			activeAjaxCallCount : 0,
			guIdXhr : false,
			placeholder: false,
			platformXhr: false
		};
		$scope.tableUtilSettings = {
			deliverablesDetails: {
				tooltip: "select to remove/remove all/Insert new Deliverables data",
				hasDefaultRecord: true,
				checkboxModelKey: "deDe_isSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore:0,
					deleteAllRow:0
				},
				newStaticObject: angular.copy(STATIC_OBJECTS.deliverablesDetails),
				ADD_NEW_BEFORE_TIP: "Insert before Deliverables Details",
				ADD_NEW_AFTER_TIP: "Insert after Deliverables Details",
				deleteAllRowTooltip: "Remove all Deliverables Details",
				deleteCurrRowMsg: "Remove Deliverables Details",
				deleteSelectedMsg: "Remove selected Deliverables Details",
				addItemCallBack: function () {
					
				},
				editRowCallBack: function () {
					
				},
				deleteItemCallBack: function () {
					updateAvailalbeDocRefList();
				}
			}
		};		
		$scope.isBulkApply = false;
		$scope.bulkApplyObj = {			
			selectedFolderName : "",
			folderData : {
				rowIndex:"",
				folderName:"",
				folderPath:"",
				folderId:""
			},
			docRef:"",
			asignee:"",
			fileName:"",
			vdrCodeTitle:"",
			vdrMilestone:"",
			vdrMilestoneDate:"",			
			placeHolderCreationDate:"",
			BID:"no",
			MDR:"no",
			IOM:"no",
			docFormat:"",
			docRev:"-",
			docStatus:"",
			docRemarks:"",
			selectedDisiplinVal : "",			
			selectedVdrCodeVal:"",
			docCustomMetaData:{				
				attrDiscipline : {                        
					attributeId: "",
					attributeValue: "",
					inputTypeId: "",
					defaultName:""
				},
				attrVdrCode : {
					attributeId: "",
					attributeValue: "",
					inputTypeId: "",
					defaultName:""
				}
			}
		};
		$scope.filterObj = {
			isIncludeFailed : false,
			dateStatus : "all",
			placeHolderDocStatus : 'all'
		};
		// used it from https://www.w3.org/TR/html5/sec-forms.html#email-state-typeemail
		// which is used for input type=Email.
		$scope.emailRegExPattern = new RegExp(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/);
		$scope.wamRegExPattern = '([\+\-]?[0-9]{0,3})((A|D|E)|(a|d|e))';		
		var isImported = $scope.ORI_MSG_Custom_Fields.isImported.trim().toLowerCase(),
			strIsDraft = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'].toLowerCase(),
			dateFormatMap = {"en_GB":"dd-M-yy","fr_FR":"d M yy","es_ES":"dd-M-yy","ru_RU":"dd.mm.yy","en_AU":"dd/mm/yy","en_CA":"d-M-yy","en_US":"M d, yy","zh_CN":"yy-m-d","de_DE":"dd.mm.yy","ga_IE":"d M yy","en_ZA":"dd M yy","ja_JP":"yy/mm/dd","ar_SA":"dd/mm/yy","en_IE":"dd-M-yy"},
    		userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy";
        		
		$scope.notCreatedPlaceHolder = [];
		$scope.isEditORI =	($scope.DSFormId != '' && strIsDraft == 'no');
		$scope.invalidDataLoaded = false;
        // to get Custom Attribute On Load.
		var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),		
			logo = commonApi._.findWhere(customAttr, {
			Value3: "LOGO",
			Value7: "LOGO"
		}) || {};
		$scope.Logo = logo.Value8 || '/images/asiteWhite60x200.png';		

		var findFolder = function(list, folderId) {
			for (var i = 0; i < list.length; i++) {
				var folder = list[i];
				var targetFolderId = (folderId + "").split('$$')[0];
				var currentFolderId = (folder.folderId + "").split('$$')[0];
				if(currentFolderId === targetFolderId) {
					return folder;
				} else if(folder.childFolders && folder.childFolders.length) {
					var found = findFolder(folder.childFolders, folderId);
					if(found) {
						return found;
					}
				}
			}
		},  structureItemList = function(setFor, availList, optlabel) {            
			var foldersList=[];                
			if(setFor == 'for-folder-path') {
				angular.forEach(availList, function(item){
					foldersList.push({
						displayValue: item.Name, 
						folderName : item.Value1,
						modelValue:  item.Value2					
					});	
				});
			} else if(setFor == 'for-user-asignee') {
				angular.forEach(availList, function(item){
					foldersList.push({
						displayValue: item.Name.split(',')[0].trim(),                         
						modelValue:  item.Value					
					});	
				});
			}
			return [{
				optlabel: optlabel,
				options: foldersList
			}];
		},	getFormStatusId = function (strStatus) {
            //get status according pass parameter          
            if (availFormStatuses && availFormStatuses.length > 0) {
                var statudObj = commonApi._.filter(availFormStatuses, function (val) {
                    return val.Name.trim().toLowerCase() == strStatus.trim().toLowerCase();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
		},	setCustomAttributeFields = function(){
			for(var i=0; i<$scope.attributeList.length; i++) {
				var attrObj = $scope.attributeList[i];
				if (attrObj.attributeId > 1000) {
					$scope.cutomAttrList.push(attrObj);
					if(attrObj.attributeName.toLowerCase() == "discipline") {
						$scope.disiplinCustAttr = attrObj;
					} else if(attrObj.attributeName.toLowerCase() == "doc type" || attrObj.attributeName.toLowerCase() == "doctype") {
						$scope.docTypeCustAttr = attrObj;
					} else if(attrObj.attributeName.toLowerCase() == "vdr code" || attrObj.attributeName.toLowerCase() == "vdrcode") {
						$scope.vdrCodeCustAttr = attrObj;
					}
				}
			}
		},	fetchActionAndAttributeDetails = function(folderId) {
			// get list from the first Folder Only.		
			$scope.xhr.platformXhr = true;
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getActionAndAttributeDetails",
				method: 'post',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/x-www-form-urlencoded'
				},				
				data : "projectId=" + $scope.projectId + '&folderId=' + folderId + '&KeyToSearchAction=UploadController117&subActionType=2'
			}).then(function(response) {							
				var data = response.data || {};
				$scope.actionList = (data.myHashMap || {}).actionVOList || [];	
				$scope.attributeList = ((data.myHashMap || {}).filesAttributeDataVO || {}).allAttributesList || [];
				if($scope.attributeList){
					setCustomAttributeFields();
				}	
				if(isImported == "yes" && !$scope.DSFormId) {				
					setRemainingDataForImport();
				}		
				$scope.xhr.platformXhr = false;	
			}, function() {
				$scope.xhr.platformXhr = false;
				Notification.error({
					title: 'Server Error', 
					message: 'Error while loading Attribute list!!'
				});
			});
		},	allHashedFolderList = function() {
			$scope.xhr.platformXhr = true;
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/folder/getAllFoldersForProject",
				method: 'post',
				withCredentials: true,
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : "projectId=" + $scope.projectId
			}).then(function(response) {
				$scope.xhr.platformXhr = false;
				var data = response.data || [];
				data = data[0] || {};
				data = data.childFolders || [];				
				$scope.hashedFoldersList = data;
				if($scope.hashedFoldersList.length) {									
					var folderId = workspaceFolderPath.length && workspaceFolderPath[0].Value2 || '',
						f = findFolder($scope.hashedFoldersList, folderId);
					if(f) {
						folderId = f.folderId;
					} else {
						folderId = $scope.hashedFoldersList[0].folderId || '';
					}
					folderId && fetchActionAndAttributeDetails(folderId);
				}
			}, function() {
				$scope.xhr.platformXhr = false;
				Notification.error({
					title: 'Server Error', 
					message: 'Error while fetching folders list of current workspace'
				});
			});
		},	setAllRolesList = function () {			
			allRoles = dsProjUsersAllRolse.map(function(roleObj){
				return roleObj.Value.split('|')[0].trim();
			});
			allRoles = commonApi._.uniq(allRoles);			
		},	fetchAllRolesUserList = function(role) {						
			var role = allRoles.join(',').replace(/,/g, '#');
			$scope.xhr.platformXhr = true;		
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/role/getUsersByProjectRoleName",
				method: 'post',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : "projectId=" + $scope.projectId + '&roleNames=' + encodeURIComponent(role)
			}).then(function(response) {
				$scope.xhr.platformXhr = false;
				$scope.allUsersList = response.data || [];				
			}, function() {
				$scope.xhr.platformXhr = false;
				Notification.error({
					title: 'Server Error', 
					message: 'Error while fetching users list of current workspace'
				});
			});
		},	getAllFoldersForProject = function() {
			$scope.availableFoldersList = structureItemList('for-folder-path', workspaceFolderPath, "Workspace Folders' List");
		},  setPOIforWorkspace = function() {
			$scope.workspacePOIList = workspacePOIList;
		},  setUserAsigneeList = function () {           
			$scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Asignee Users' List");
		},	setPackageEngineerList = function() {
			$scope.packageEngineersList = commonApi._.filter(dsProjUsersAllRolse, function (roleUserObj) {				
				var roleNameString = roleUserObj.Value.trim().toLowerCase();
				return (roleNameString.indexOf('z cn')>-1);				
			});			
		},	getDistDetails = function(user, action, actionDueDate) {
			var obj = {
				selectedDistGroups: "",
				selectedDistUsers: [{
					hUserID: user.userID,
					fname: user.fname,
					lname: user.lname,
					user_type: user.user_type,
					hActionID: action,
					actionDueDate: actionDueDate,
					email: 'true'
				}],
				selectedDistOrgs: [],
				selectedDistRoles: [],
				tempId: 0
			};						
			return encodeURIComponent(angular.toJson(obj));
		},	addZeroPad = function(number, minChar) {
			number = number + "";
			while(number.length < minChar) {
				number = "0" + number;
			}
			
			return number;
		},	getCurrentTime = function() {
			var date = new Date();
			var h = addZeroPad(date.getHours(), 2);
			var m = addZeroPad(date.getMinutes(), 2);
			var s = addZeroPad(date.getSeconds(), 2);
			
			return (h + ":" + m + ":" + s);
		},	getCustomAttrValues = function(deliverablesDetailsObj) {			
			var customAttrs = [];	
			for (var property in deliverablesDetailsObj.docCustomMetaData) {
				if (deliverablesDetailsObj.docCustomMetaData.hasOwnProperty(property)) {
					// Do things here
					(typeof deliverablesDetailsObj.docCustomMetaData[property] == "object") && customAttrs.push(deliverablesDetailsObj.docCustomMetaData[property]);
				}
			}
			return customAttrs; 
		},	createPlaceHolders = function (deliverablesDetailsObj, callbackFun, currentIndex) {
			var placeholderDetail = {
				"placeholderList": [{
					"filename": "Not Uploaded",
					"documentRef": deliverablesDetailsObj.docRef,					
					"revision": '-',	// "revision": deliverablesDetailsObj.docRev,
					"documentTitle": deliverablesDetailsObj.vdrCodeTitle,
					"purposeOfIssue": '0', 	// 0 for ---
					"isPrivateRevision": false,
					"revisionNotes": '',	// deliverablesDetailsObj.docRemarks,
					"zipFileName": "",
					"paperSize": "",
					"scale": "",
					"customAttributes": getCustomAttrValues(deliverablesDetailsObj),
					"tempId": 0,
					"isCheckIn": false
				}]
			};	
			// Initialize blank Dist Obj
			var distObj =  encodeURIComponent(angular.toJson({"selectedDistGroups":"","selectedDistUsers":[],"selectedDistOrgs":[],"selectedDistRoles":[],"tempId":0}));
			if(deliverablesDetailsObj.asignee) {
				var userAsigneeId = deliverablesDetailsObj.asignee.split('#')[0],
					user = commonApi._.filter($scope.allUsersList, function(userObj){
						return userObj.hUserID == userAsigneeId;
					})[0] || {},	
					publishActionObj = commonApi._.filter($scope.actionList, function(actionObj){
						return actionObj.actionName == 'For Publishing';
					})[0] || {};	// for Upload
				distObj = getDistDetails(user, publishActionObj.actionID, (commonApi.formatDate(userDateFormat, new Date(deliverablesDetailsObj.placeHolderCreationDate), {lang: true}) + " " + getCurrentTime()));
			}	
			var folderId = deliverablesDetailsObj.folderData.folderId;
			var f = findFolder($scope.hashedFoldersList, folderId);
			if(f) {
				folderId = f.folderId;
			}

			$scope.xhr.placeholder = commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/document/createPlaceholder",
				method: 'post',
				withCredentials: true,
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				rowIndex : currentIndex+1,
				data : "projectId=" + $scope.projectId + '&folderId=' + folderId + 
					'&filename1=Not Uploaded' +
					'&docRef1=' + deliverablesDetailsObj.docRef +
					'&revision1=---' +
					'&hasAttachment1=true' +
					'&rowNumbers=1' +
					'&forPublishing=false' +
					'&validationType=2' +
					'&isFromPlaceholder=true' +
					'&subject=' +
					'&noAccessUsers=' +
					'&isValidationRequired=true' +	// this parameter will check the platforms validations while creating placeholder if true is there.
					'&placeholderDetails='+ encodeURIComponent(angular.toJson(placeholderDetail)) +
					'&distributionDetails=' + distObj
			}).then(function(response) {				
				$scope.xhr.activeAjaxCallCount++;				
				var data = response.data || {};

				if(data.errorCode) {
					if(data.allowContinue) {
						Notification.warning({
							title: 'The Doc Ref already exists',
							message: 'The Doc Ref shown below already has a revision uploaded\n\n- ' + data.docRef 
						});
						$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['creationStatus'] = "The Doc Ref already exists";
					} else if(data.errorCode == 2031) {		
						Notification.warning({
							title: 'Deactivated placeholder exists',
							message: 'The Doc Ref shown below has a deactivated placeholder as a latest revision\n\n- ' + data.docRef 
						});
						$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['creationStatus'] = "Deactivated placeholder exists.";
					} else {
						Notification.warning({
							title: 'The Doc Ref already has an empty Placeholder',
							message: 'The Doc Ref shown below already has an empty Placeholder\n\n- ' + data.docRef + 
							'\n\nSystem will not create placeholder for the above Doc Ref.\n Please remove that placeholder first.'
						});
						$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['creationStatus'] = "Duplicate Placeholder";
					}
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['filterCode'] = "ERR";
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['revisionIds'] = data.revisionId.split('$$')[0];
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['documentIds'] = data.documentId.split('$$')[0];
				} else if(data.myHashMap) {
					var createdPlaceHolderDetail = data.myHashMap.savedPlaceholderDetails;
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['revisionIds'] = createdPlaceHolderDetail.revisionIds;
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['documentIds'] = createdPlaceHolderDetail.documentIds;
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['transactionId'] = createdPlaceHolderDetail.transactionId;
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['creationStatus'] = "Success";
					$scope.deliverablesDetails[response.config.rowIndex-1]['trackerDetails']['filterCode'] = "SUCCESS";
					Notification.success('<div class="text-center"> New placeholder for '+ $scope.deliverablesDetails[response.config.rowIndex-1]['docRef'] +' created successfully !</div>');
				}				
				if((!$scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.deliverablesDetails.length) || ($scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.notCreatedPlaceHolder.length)){
					$scope.xhr.placeholder = false;
					callbackFun();
				}
			}, function(errorObj) {
				$scope.xhr.activeAjaxCallCount++;
				$scope.deliverablesDetails[errorObj.config.rowIndex-1]['trackerDetails']['creationStatus'] = "-";
				$scope.deliverablesDetails[errorObj.config.rowIndex-1]['trackerDetails']['filterCode'] = "ERR";
				$scope.xhr.placeholder = false;
				Notification.error({
					title: 'Server Error', 
					message: 'Error while creating placeholder!!\nPlease check Permissions.'
				});
			});
		},	getGUIdOnCallBack = function(totalNodes, callback) {
			var allNodes = [];
			var fieldValue = totalNodes;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_GET_GUID",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_GET_GUID",
							"fieldValue": fieldValue
						}]
					}
				};				
				$scope.xhr.platformXhr = true;
				$scope.xhr.guIdXhr = $scope.getCallbackData(form).then(function (response) {					
					if (response.data) {
						var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
						var strGetDetailsLength = strGetDetails.Items.Item.length;
						for (var i = 0; i < strGetDetailsLength; i++) {
							allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
						}
					}
					callback(allNodes);
				}, function (error) {
					$scope.xhr.platformXhr = false;
					$scope.xhr.guIdXhr = false;
					var errorMsg = 'Error retriving DocumentData<br/>' + error;
					Notification.error({
						title: 'Server Error', 
						message: errorMsg 
					});
				});
			}
		}, 	headerScrollBind = function(){
			// bind header's vertical scrolling with table's inner scroll.
			$element.find('.details-table-wrapper .table-body-inner').bind('scroll', function(event){
				$element.find('.details-table-wrapper .table-header').scrollLeft(angular.element(event.target).scrollLeft());
			});
		}, 	setRemainingDataForImport = function() {
			$scope.ORI_MSG_Custom_Fields.isDataCreatedByXsl = true;
			var deliverableList = [],
				xslImportedData = $scope.deliverablesDetails;
			$scope.ORI_MSG_Custom_Fields.xslImportedData = xslImportedData;
			for(var i=0; i<xslImportedData.length; i++) {
				$scope.insertNewItems(deliverableList);
				deliverableList[i].docRef = xslImportedData[i].docRef;			
				deliverableList[i].vdrCodeTitle = xslImportedData[i].vdrCodeTitle;
				deliverableList[i].vdrMilestone = xslImportedData[i].vdrMilestone;
				deliverableList[i].vdrMilestoneDate = xslImportedData[i].vdrMilestoneDate;
				deliverableList[i].BID = xslImportedData[i].BID.trim().toLowerCase();
				deliverableList[i].MDR = xslImportedData[i].MDR.trim().toLowerCase();
				deliverableList[i].IOM = xslImportedData[i].IOM.trim().toLowerCase();				
				deliverableList[i].docFormat = xslImportedData[i].docFormat;
				deliverableList[i].docRev = xslImportedData[i].docRev;
				deliverableList[i].docRemarks = xslImportedData[i].docRemarks;								
				// set Vdr Code Cust Attr
				if (xslImportedData[i].selectedVdrCodeVal) {
					var selectedVdrCodeAttrObj = $scope.vdrCodeCustAttr.inputValueList.filter(function(valObj) {
						return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].selectedVdrCodeVal.trim().toLowerCase();
					})[0] || {};
					deliverableList[i].docCustomMetaData.attrVdrCode.attributeId = $scope.vdrCodeCustAttr.attributeId;
					deliverableList[i].selectedVdrCodeVal = selectedVdrCodeAttrObj.value;
					deliverableList[i].docCustomMetaData.attrVdrCode.attributeValue = selectedVdrCodeAttrObj.value;
					deliverableList[i].docCustomMetaData.attrVdrCode.inputTypeId = $scope.vdrCodeCustAttr.inputTypeId;
					deliverableList[i].docCustomMetaData.attrVdrCode.defaultName = selectedVdrCodeAttrObj.defaultName;					
				}
				// set Dicipline Cust Attr
				if (xslImportedData[i].selectedDisiplinVal) {
					var selectedDispAttrObj = $scope.disiplinCustAttr.inputValueList.filter(function(valObj) {
						return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].selectedDisiplinVal.trim().toLowerCase();
					})[0] || {};
					deliverableList[i].docCustomMetaData.attrDiscipline.attributeId = $scope.disiplinCustAttr.attributeId;
					deliverableList[i].selectedDisiplinVal = selectedDispAttrObj.value;
					deliverableList[i].docCustomMetaData.attrDiscipline.attributeValue = selectedDispAttrObj.value;
					deliverableList[i].docCustomMetaData.attrDiscipline.inputTypeId = $scope.disiplinCustAttr.inputTypeId;
					deliverableList[i].docCustomMetaData.attrDiscipline.defaultName = selectedDispAttrObj.defaultName;					
				}				
			}
			if(deliverableList.length){
				$scope.deliverablesDetails.length = 0;
				$scope.deliverablesDetails = deliverableList;				
				$scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.deliverablesDetails.length = 0;
				$scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.deliverablesDetails = deliverableList;
				$scope.update();			
			}
		},	updateAvailalbeDocRefList = function(){
			for(var i=0; i<$scope.deliverablesDetails.length; i++) {
				var docRef = $scope.deliverablesDetails[i].docRef || '',
					docRef = docRef.trim().toLowerCase(),
					folderId = $scope.deliverablesDetails[i].folderData.folderId || '';
				if(docRef && folderId) {								
					avilRowDocRefFolderWise[i] = folderId+'_'+docRef;					
				}
			};	
		}, 	bulkApplyOnField = function(fieldName){			
			for (var t=0; t<$scope.deliverablesDetails.length; t++) {
				if(!$scope.deliverablesDetails[t].trackerDetails.revisionIds) {
					if ($scope.bulkApplyObj[fieldName] == '') {
						$scope.deliverablesDetails[t][fieldName] = '';
						continue;
					} 
					if (fieldName == 'folderData') {
						$scope.deliverablesDetails[t][fieldName]['folderName'] = $scope.bulkApplyObj[fieldName]['folderName'];
						$scope.deliverablesDetails[t][fieldName]['folderPath'] = $scope.bulkApplyObj[fieldName]['folderPath'];
						$scope.deliverablesDetails[t][fieldName]['folderId'] = $scope.bulkApplyObj[fieldName]['folderId'];
					} else if(fieldName == 'asignee') {
						$scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];	
						$scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Asignee Users' List");
					} else {
						if (!$scope.deliverablesDetails[t][fieldName] || $scope.deliverablesDetails[t][fieldName] == '' || $scope.deliverablesDetails[t][fieldName] == 'no' || $scope.deliverablesDetails[t][fieldName] == 'yes') {
							$scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];							
							if(fieldName == 'asignee') {
								$scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Asignee Users' List");							
							} else if (fieldName == 'selectedDisiplinVal' || fieldName == 'selectedVdrCodeVal') {
								$scope.custAttrSelection($scope.deliverablesDetails[t]['docCustomMetaData'][customAttrValueMap[fieldName]], $scope[custAttrNameListMap[fieldName]], $scope.bulkApplyObj[fieldName])
							}
						}
					}
					$scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
				} else if ((fieldName == 'vdrMilestone' || fieldName == 'docRemarks') && (!$scope.deliverablesDetails[t][fieldName] || $scope.deliverablesDetails[t][fieldName] == '') ) {					
					$scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];	
					$scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
				}
			}			
			$scope.expandTextAreaOnLoad();
		},	setDistributionNode = function (strUser, strAction, strDays) {            
            var distributionNode = angular.copy(distributionNodeStr);
            distributionNode.DS_PROJDISTUSERS = strUser;
            distributionNode.DS_FORMACTIONS = strAction;           
            distributionNode.DS_ACTIONDUEDATE = strDays;
            $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users.push(distributionNode);
            $scope.Asite_System_Data_Read_Write["DS_AUTODISTRIBUTE"] = "3";
		},	setPackageEngWorkFlow = function(packageEngineer) {
			if(!packageEngineer) {
				return;
			}
			setDistributionNode(packageEngineer.split('|')[2].trim(), "7#For Information", '');  
		},	setDocumentControllerFlow = function() {
			// set For Information to all Document Controller Role's User.
			var documentControllersList = commonApi._.filter(dsProjUsersAllRolse, function (roleUserObj) {				
				var roleNameString = roleUserObj.Value.trim().toLowerCase();
				return (roleNameString.indexOf('doc controller') > -1 || roleNameString.indexOf('doccontroller') > -1 );
			});	

			for(var i=0; i<documentControllersList.length; i++) {
				var roleUserObj = documentControllersList[i];
				setDistributionNode(roleUserObj.Value.split('|')[2].trim(), "7#For Information", '');  
			}
		},	setAutoDistUsersNodes = function () {			
			setPackageEngWorkFlow($scope.packageDetails.packageEnginner);
			setDocumentControllerFlow();
		},  setOldJsonBackup = function() {			
			var onLoadJson = angular.fromJson($element.find('.json_data').val()).myFields,
				oriMsg = onLoadJson.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields,
				titleDetails = oriMsg.titleDetails;
			
			// set required old data backup of json.
			onLoadJsonBackup = {
				resubmissionDays : oriMsg.packageDetails.resubmissionDate, 
				deliveryToSite : titleDetails.deliveryToSite,
				noOfDays : titleDetails.noOfDays,
				readyExWorks: titleDetails.readyExWorks,
				runDate: titleDetails.runDate,
				deliverablesDetails : oriMsg.deliverablesDetails
			};
		};
	
		$scope.custAttrSelection = function(custAttrObj, parentObj, selectedVal) {			
			var selectedValObj = parentObj.inputValueList.filter(function(valueObj) {
				return valueObj.value == selectedVal;
			})[0] || {};
			custAttrObj.attributeId = parentObj.attributeId;
			custAttrObj.attributeValue = selectedVal;
			custAttrObj.inputTypeId = parentObj.inputTypeId;
			custAttrObj.defaultName = selectedValObj && selectedValObj.defaultName;
		};

		var commonValidationFuncs = {
			duplicateDocRefValidation : function(value, index, isFolderEvent, folderId){								
				var docRef = value || $scope.deliverablesDetails[index].docRef || '',
					docRef = docRef.trim().toLowerCase(),
					isFolderEvent = isFolderEvent || false;
					
				if(!isFolderEvent) {
					folderId = $scope.deliverablesDetails[index].folderData.folderId;					
				}

				if(docRef && folderId) {
					var uniqRef = folderId+'_'+docRef;
					// resetting the object key to put latest.
					avilRowDocRefFolderWise[index] = '';
					if (Object.values(avilRowDocRefFolderWise).indexOf(uniqRef) > -1) {
						if(!isFolderEvent) {
							Notification.warning({
								title: "Duplicate 'Doc Ref'",
								message: "Duplicate 'Doc Ref' entered, please enter different 'Doc Ref'"
							});						
						 	$scope.deliverablesDetails[index].docRef = '';
						} else {
							Notification.warning({
								title: "Duplicate 'Doc Ref' in same Folder",
								message: "Duplicate 'Doc Ref' entered for the same folder, please select another folder from available list\n Either change 'Doc Ref' for current row."
							});	
							$scope.item.folderName = '';
							$scope.item.folderPath = '';
							$scope.item.folderId = '';
						}
						return false;
					} else {
						avilRowDocRefFolderWise[index] = uniqRef;
					}
				}
				return true;
			},	docrefInvalidChars: function(value, index) {
				var MSG_TITLE = 'Special character validation',
					MSG_BODY = 'Enter valid characters only. (Restricted Characters ",/,\\,:,*,?,<,>,|,;,%,#,~ or any character with ASCII value less than 32)';
				if (value) {
					var nospecial = /"|#|:|;|\x3F|\x7C|<|>|%|\\|\/|~|\*|—/;
					var matches = value.match(nospecial);
					if (matches && matches.length > 0) {					
						Notification.warning({
							title: MSG_TITLE,
							message: MSG_BODY
						});
						$scope.deliverablesDetails[index].docRef = '';
					} else {
						for (var i = 0; i < value.length; i++) {
							if (value.charCodeAt(i) < 32) {
								Notification.warning({
									title: MSG_TITLE,
									message: MSG_BODY
								});
								$scope.deliverablesDetails[index].docRef = '';
								break;
							}
						}
					}
				}
			}
		};

		$scope.commonValidations = function(validationsString, index, value) {
			var validationsList = validationsString.split(',');
			for(var h=0; h<validationsList.length; h++) {
				var func = validationsList[h];				
				commonValidationFuncs[func] && commonValidationFuncs[func].apply(this, [value, index]);
			}
		};

		// common item selection modal Start

		$scope.showModal = function (id, index, isForBulkApply) {    
			if(!isForBulkApply){
				$scope.item.rowIndex = index;            
				$scope.item.folderName =  $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderName || '';
				$scope.item.folderPath =  $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderPath || '';
				$scope.item.folderId = $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderId || '';
			} else {
				$scope.item.folderName =  '';
				$scope.item.folderPath =  '';
				$scope.item.folderId = '';
			}
			// to hide the update button        
			$scope.item.isForBulkApply = isForBulkApply;
			ctrl.model.readOnly = true;
			ctrl.model.modelId = id;
		};

		$scope.hideModal = function () { 
			if(!$scope.item.isForBulkApply) {
				if(!commonValidationFuncs.duplicateDocRefValidation($scope.deliverablesDetails[$scope.item.rowIndex].docRef, $scope.item.rowIndex, true, $scope.item.folderId)) {
					return;
				} else {
					$scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderName = $scope.item.folderName;
					$scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderPath = $scope.item.folderPath;
					$scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderId = $scope.item.folderId;
				}
			} else {
				if($scope.item.isForBulkApply){
					$scope.bulkApplyObj.folderData.folderName = $scope.item.folderName;
					$scope.bulkApplyObj.folderData.folderPath = $scope.item.folderPath;
					$scope.bulkApplyObj.folderData.folderId = $scope.item.folderId;
				}
			}        
			$scope.backup.item = $scope.item;           
			ctrl.model.modelId = '';
		};

		$scope.updateModal = function () {
			$scope.hideModal();
		};

		ctrl.model = {
			modelId: "",
			showModal: $scope.showModal,
			update: $scope.updateModal,
			hideModal: $scope.hideModal,
			readOnly : $scope.readOnly
		};

		$scope.backup = {
			item: {
				folderName : '',
				folderPath : '',
				folderId : '',
				rowIndex: '',
				isForBulkApply : false            
			}
		};

		// common item selection modal End

		$scope.setFocusToLastAddedElement = function(tableId){
			$timeout(function () {
				angular.element('#'+tableId+'>tbody>tr:last input').last().focus();                
			}, 50);           
		};

		// below function is to call report
		$scope.exportMspReport = function(event) {			
			$window.showSelectedReportfromApp && $window.showSelectedReportfromApp('MSP_Vendor_Package_Report', 'XLSM', 'Ext', '', '');
		};

		$scope.insertNewItems = function (listToImport) { 
			var newStaticObject = angular.copy(STATIC_OBJECTS.deliverablesDetails);
			//Add item in items
			$scope.addRepeatingRow(listToImport, newStaticObject);    
		};

		$scope.changeItemSelectionEvent = function(item, dropDownFor, isForBulkApply) {            
			if(!isForBulkApply) {
				if (dropDownFor == 'folderpath-dropdown') {
					$scope.item.folderPath = item.displayValue;
					$scope.item.folderName = item.folderName;
					$scope.item.folderId = item.modelValue;
				}
			}
		};

		$scope.setStatusAccordingly = function(selectedStatus) {			
			var strFormStatusId = getFormStatusId(selectedStatus.trim().toLowerCase());
			if (strFormStatusId) {             
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		};
		
		var mathOperation = {
			'+': function (x, y) { 
				return x + y 
			},
			'-': function (x, y) { 
				return x - y;
			}
		}, calculateMileStoneDays = function(paramObj) {
			if(!paramObj.vdrMilestone){
				return 7;
			}
			var totalDays = 0,
				splitedVal = paramObj.vdrMilestone.split(/(\d+)/);
				splitedVal[0] = splitedVal[0] || '+';			
			if(['D','d'].indexOf(splitedVal[2])>-1) {
				totalDays = mathOperation[splitedVal[0]](Number(paramObj.deliveryToSite), Number(splitedVal[1])) * Number(paramObj.noOfDays);
			} else if(['E','e'].indexOf(splitedVal[2])>-1) {
				totalDays = mathOperation[splitedVal[0]](Number(paramObj.readyExWorks), Number(splitedVal[1])) * Number(paramObj.noOfDays);
			} else if(['A','a'].indexOf(splitedVal[2])>-1) {
				totalDays = Number(splitedVal[1]) * Number(paramObj.noOfDays);
			}
			return totalDays;
		};

		$scope.applyRunDateChange = function(selectedDate) {
			var todayServerDateObj = new Date($scope.serverDate),
				noOfDays = $scope.titleDetails.noOfDays || 7,
				selectedDateObj = '',
				deObj = {},
				oldDeObj = {},
				isWamValueUpdated = false;			
			for (var i=0; i<$scope.deliverablesDetails.length; i++) {

				selectedDateObj = new Date(selectedDate);
				deObj = $scope.deliverablesDetails[i];
				oldDeObj = (onLoadJsonBackup.deliverablesDetails.length && onLoadJsonBackup.deliverablesDetails[i]) || {},
				isWamValueUpdated = (deObj.vdrMilestone != oldDeObj.vdrMilestone);

				if(deObj.vdrMilestone && (!deObj.guId || !deObj.trackerDetails.revisionIds || isWamValueUpdated)) {
					var calculatedDays = calculateMileStoneDays({
						vdrMilestone 	:	deObj.vdrMilestone,
						noOfDays		:	noOfDays,
						deliveryToSite	:	$scope.titleDetails.deliveryToSite || '46',
						readyExWorks	:	$scope.titleDetails.readyExWorks || '37'
					});
					// NaN occuress set default Week Days to 7.
					isNaN(calculatedDays) && (calculatedDays = 7);
					var dueDate = selectedDateObj.setDate(selectedDateObj.getDate()+calculatedDays);
					typeof dueDate == 'number' && (dueDate = new Date(dueDate));
					if (!selectedDate) {	
						$scope.deliverablesDetails[i].vdrMilestoneDate = '';
					} else if(dueDate >= todayServerDateObj) {
						!deObj.trackerDetails.revisionIds && ($scope.deliverablesDetails[i].placeHolderCreationDate = $scope.formatDate(dueDate, 'yy-mm-dd'));
						$scope.deliverablesDetails[i].vdrMilestoneDate = $scope.formatDate(dueDate, 'yy-mm-dd');
					} else {
						!deObj.trackerDetails.revisionIds && ($scope.deliverablesDetails[i].placeHolderCreationDate = $scope.todayDateDbFormat);
						$scope.deliverablesDetails[i].vdrMilestoneDate = $scope.formatDate(dueDate, 'yy-mm-dd');
					}
				}				
			}
		};
		
		$scope.bulkApplyOnField = function(fieldName, valueObj){
			bulkApplyOnField(fieldName, valueObj);
		};

		/***
		 * 
		 *	isIncludeFailed: true/false	----> filterCode: ERR or Not ERR
		 *	dateStatus: all,due,overdue	----> remainingDays: due days in positive, overdue days in negative.
		 *	placeHolderDocStatus: all,submitted,notsubmitted ----> placeHolderStatus: submitted not prepublished, notsubmitted prepublished
		 *
		 * */			

		var checkMultiConditions = function (filterObj, conditionsObj) {
			if((filterObj.dateStatus == 'all') || (filterObj.dateStatus == 'due' && conditionsObj.isdateStatusDue) || (filterObj.dateStatus == 'overdue' && conditionsObj.isdateStatusOverDue) || (filterObj.dateStatus == 'submitted' && conditionsObj.isSubmitted)){
				return true;
			} 			
			return false;
		};

		$scope.applyFilterCriteria = function(filterObj) {
			// set default to all i f blank is there.
			!filterObj.dateStatus && (filterObj.dateStatus = 'all');
			!filterObj.placeHolderDocStatus && (filterObj.placeHolderDocStatus = 'all');
			
			var conditionsObj = {},
				successHyphen = ['-','success'],
				prepublishHyphen = ['-','prepublished'];
			for(var s=0; s<$scope.deliverablesDetails.length; s++) {
				var currObj = $scope.deliverablesDetails[s];
				conditionsObj.isNotInclude = (currObj.trackerDetails.filterCode && successHyphen.indexOf(currObj.trackerDetails.filterCode.toLowerCase()) > -1) || (currObj.placeHolderStatus.toLowerCase() != 'deactivated') || false;
				conditionsObj.isdateStatusOverDue = (!isNaN(currObj.remainingDays) && currObj.remainingDays.indexOf('-')>-1) || false;
				conditionsObj.isdateStatusDue = (currObj.remainingDays && !conditionsObj.isdateStatusOverDue) || false;
				conditionsObj.isNotSubmitted  = (currObj.placeHolderStatus && prepublishHyphen.indexOf(currObj.placeHolderStatus.toLowerCase()) > -1) || false;
				conditionsObj.isSubmitted = !conditionsObj.isNotSubmitted;				
				$scope.deliverablesDetails[s].isShow = false;
				if((!filterObj.isIncludeFailed && conditionsObj.isNotInclude && checkMultiConditions(filterObj, conditionsObj)) || (filterObj.isIncludeFailed && checkMultiConditions(filterObj, conditionsObj))) {
					$scope.deliverablesDetails[s].isShow = true;
				} 
			}			
		};

		var updateUnavailableGuidStatus = function(){
			// get All Indexes of the row without guid to make ajax call for only those elements.
			for(var i=0; i<$scope.deliverablesDetails.length; i++){
				if($scope.deliverablesDetails[i].guId == '') {
					guidNotAvailList.push(i);
				}
			}
		},	recursiveFunCall = function(guidNotAvailList, callbackFun) {			
			// loop to create placeholders.			
			for(var i=0; i<$scope.deliverablesDetails.length; i++) {
				var delivObj = $scope.deliverablesDetails[i];
				if(delivObj.guId && delivObj.guId != '' && !guidNotAvailList.length && !delivObj.trackerDetails.revisionIds && $scope.packageDetails.isStatusAwarded.toLowerCase() == 'yes') {
					createPlaceHolders(delivObj, callbackFun, i);						
				} else if (!$scope.xhr.guIdXhr) {
					if(guidNotAvailList.length != 0) {
						getGUIdOnCallBack(guidNotAvailList.length, function (allGUID) {
							if (allGUID.length) {								
								angular.forEach(guidNotAvailList, function (index, i) {									
									$scope.deliverablesDetails[index].guId = allGUID[i];								
								});		
								$scope.xhr.platformXhr = false;	
								$scope.xhr.guIdXhr = false;	
								guidNotAvailList = [];						
								recursiveFunCall(guidNotAvailList, callbackFun);						
							}
						});
					} else if(!guidNotAvailList.length && $scope.packageDetails.isStatusAwarded.toLowerCase() == 'no') {
						callbackFun();
					}				
				} 
			}
		};

		$window.mspVendorPackageSubmit = function () {  
			//check package number duplicate or not
			if($scope.duplicatemessage){
				return true;
			}
			
			if (submitFlag) {	
				return false;				
			}

			// set ORI form title
			$scope.ORI_MSG_Custom_Fields['ORI_FORMTITLE'] = $scope['ORI_MSG_Custom_Fields']['packageDetails']['package'] + ' - ' + $scope['ORI_MSG_Custom_Fields']['packageDetails']['title'];
			// set Package title in DS_FORMCONTENT for SP Use.
			$scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMCONTENT'] = $scope['ORI_MSG_Custom_Fields']['packageDetails']['package'];
			$scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
			// set Auto User Distribution Nodes.
			setAutoDistUsersNodes();

			var execBizzLogic = function () {
				var callbackFun = function () {	
					submitFlag = true;
					// remove loaded class to show loader
					$element.removeClass('loaded');	
					$window.submitForm(1);
				};				
				guidNotAvailList = [];
				updateUnavailableGuidStatus();				
				recursiveFunCall(guidNotAvailList, callbackFun);
			};

			if($scope.packageDetails.isStatusAwarded.toLowerCase() == 'yes') {					
				// updating list of not created PlaceHolders
				var placeholderCreatedList = $scope.deliverablesDetails && $scope.deliverablesDetails.filter(function(deObj) {
					return deObj.trackerDetails.revisionIds;
				}) || [];
				if(placeholderCreatedList.length == $scope.deliverablesDetails.length) {
					submitFlag = true;
					// remove loaded class to show loader	
					$element.removeClass('loaded');	
					$window.submitForm(1);
				} else {
					// reset while clicking on submit button.
					$scope.xhr.activeAjaxCallCount = 0;
					$scope.notCreatedPlaceHolder = $scope.deliverablesDetails && $scope.deliverablesDetails.filter(function(deObj) {
						return !deObj.trackerDetails.revisionIds;
					}) || [];
				}
			} else if($scope.packageDetails.isStatusAwarded.toLowerCase() == 'no'){
				// set pre defined Status to - for both creation and placeHolder as well.
				for(var i=0; i<$scope.deliverablesDetails.length; i++) {
					$scope.deliverablesDetails[i].placeHolderStatus = "-";
					$scope.deliverablesDetails[i].trackerDetails.creationStatus = "-";
					$scope.deliverablesDetails[i].trackerDetails.filterCode = "-";
				};				
				$element.removeClass('loaded');				
			}	
			if($scope.packageDetails.isAwarded == 'Awarded') {
				$scope.Asite_System_Data_Read_Write['ORI_MSG_Fields']['DS_DB_INSERT'] = 'true';				
				execBizzLogic();
				//($scope.packageDetails.isStatusAwarded == 'Yes') && execBizzLogic();
			}else if($scope.packageDetails.isAwarded == 'Not Awarded') {
				submitFlag = true;
				// remove loaded class to show loader	
				$element.removeClass('loaded');	
				$window.submitForm(1);
			}		
			return true;
		};

		// View Base Functions called from here.
		if($scope.deliverablesDetails.length) {
			if(currentViewName == 'ORI_VIEW') {  
				// to set old Json to compare WAM and Other fields that change vdrMilestoneDate.
				$scope.isEditORI && setOldJsonBackup(); 
				
				setAllRolesList();
				allHashedFolderList();          
				fetchAllRolesUserList();
				getAllFoldersForProject(false);
				setPOIforWorkspace();
				setUserAsigneeList();	
				setPackageEngineerList();		
				$scope.setStatusAccordingly($scope.packageDetails.isStatusAwarded.toLowerCase());
				// include new row if all records are created and not showing					
				$scope.notCreatedPlaceHolder = $scope.deliverablesDetails.filter(function(deObj) {
					return !deObj.trackerDetails.revisionIds;
				}) || [];							
				$scope.isEditORI && updateAvailalbeDocRefList();		
				if($scope.dsDbInserted && $scope.packageDetails['isStatusAwarded'] == 'Yes' && $scope.titleDetails.runDate) {
					$scope.displayRunDate = commonApi.formatDate('dd/mm/yy', new Date($scope.titleDetails.runDate));		
				}
				// blank Distribution node when form gets loaded.
				$scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];

				//set default Not Awarded Status
				if($scope.DSFormId == '') {
					var selectedStatus = "Not Awarded";
					var strFormStatusId = getFormStatusId(selectedStatus.trim().toLowerCase());
					if (strFormStatusId) {             
						$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
					}
				}

			} else if(currentViewName == 'ORI_PRINT_VIEW') {			
				var placeholderDocStatus = $scope.getValueOfOnLoadData('DS_MSP_Placeholder_Doc_Status'),
					isSDDLStatus = ($scope.packageDetails.isStatusAwarded == 'Yes'),
					FIXED_STATUS_LIST = ['ifc', 'ifu', 'ifi', 'can'];
				$scope.titleDetails.runDate =  $scope.titleDetails.runDate && commonApi.formatDate('dd/mm/yy', new Date($scope.titleDetails.runDate));
				for (var h=0; h<$scope.deliverablesDetails.length; h++) {
					var dObj = $scope.deliverablesDetails[h];
					//	Initial Due Date. 
					$scope.deliverablesDetails[h].vdrMilestoneDate = dObj.vdrMilestoneDate && commonApi.formatDate('dd/mm/yy', new Date(dObj.vdrMilestoneDate));
					if(isSDDLStatus) {
						for(var i=0; i<placeholderDocStatus.length; i++){
							var plObj = placeholderDocStatus[i];
							if(dObj.guId == plObj.Value2) {	
								
								//  'Due Date' is vdrMilestone date 
								//  'resubmissionDate' is the date calculated after another placeholder created over document.
								//  'remainingDays' is calculated on bases of resubmissionDate.
								//  'isNegativeDays' is node which will describe remaining days are negative ot positive.
								//  'publishDate' is the actual Document's publish date.							
								// 	Document's current Status.				
								$scope.deliverablesDetails[h].placeHolderStatus = plObj.Value3 || '-';
								//	Resubmission Due Date.
								$scope.deliverablesDetails[h].resubmissionDate = plObj.Value7 || '-';
								// 	Date Received / Publish Date.
								$scope.deliverablesDetails[h].publishDate = plObj.Value6 || '-';
								//	Remaining Days and Days Late. 
								$scope.deliverablesDetails[h].remainingDays = plObj.Value9 || '-';
								// 	To check Whether negative days there in remaining Days Column.
								$scope.deliverablesDetails[h].isNegativeDays = !isNaN(plObj.Value9) && parseInt(plObj.Value9) < 0;
								// 	flag is to highlight the StrikeThrough.
								$scope.deliverablesDetails[h].isDocRefHighlight = false;
								// 	to show deactivated Doc ref's in failed filter							
								if(plObj.Value3 == 'Deactivated') {
									$scope.deliverablesDetails[h].trackerDetails.filterCode = "ERR";
									// 	set true if latest revision get found deactivated hence stricking through the whole TR.
									$scope.deliverablesDetails[h].isDocRefHighlight = true;
								}
								if(dObj.placeHolderStatus && dObj.placeHolderStatus != '-') {
									$scope.deliverablesDetails[h].placeHolderUrl = plObj.URL4;
								}
								
								//  Client's Requirement to show few things on condition bases. 
								// 	set blank to Initial Due Date, Remaining Days, Days Late, Resubmission Due Date.
								//  if ('ifc', 'ifu', 'ifi', 'can') any of these status available for latest revisioned doc from SP.
								
								if(FIXED_STATUS_LIST.indexOf(plObj.Value3.toLowerCase()) > -1) {
									//	Initial Due Date.
									$scope.deliverablesDetails[h].vdrMilestoneDate = '';
									//	Remaining Days and Days Late. 
									$scope.deliverablesDetails[h].remainingDays = '';
									//	Resubmission Due Date.
									$scope.deliverablesDetails[h].resubmissionDate = '';
								}

								// if Resubmission Due Date OR Date Received / Publish Date available then Initial Due Date to blank 
								// Value7 --> Resubmission Due Date
								// Value6 --> Date Received / Publish Date
								if(plObj.Value7 || plObj.Value6) {
									//	Initial Due Date.
									$scope.deliverablesDetails[h].vdrMilestoneDate = '';
								}
							}
						}
					}
				}			
				$scope.applyFilterCriteria($scope.filterObj);
			}
		} else {
		 	$scope.invalidDataLoaded = true;
		}
		//get callback data
		$scope.duplicatemessage = false;
		$scope.checkDuplicate = function(strpackage)
		{
			var dataSourceName = "DS_MSP_CheckPackageDuplicate";
			//var paramvalue = $scope.packageDetails['package'];
			var form = {
				"projectId":$scope.projectId,
				"formId": $scope.formId,
				"fields": dataSourceName,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": dataSourceName,
						"fieldValue": strpackage
					}]
				}
			};
			
			$scope.getCallbackData(form).then(function (response) {
				var resData = response.data;
				$scope.update({
					name: dataSourceName
				});

				if(resData){
					var spData = angular.fromJson(response.data[ dataSourceName ]);
					spData = spData['Items']["Item"] || [];
					var isduplicate = spData[0]['Value'].split('#');
					if(isduplicate[0].trim() == "Yes")
					{$scope.duplicatemessage=true;}
					else
					{$scope.duplicatemessage=false;}
				}
			}, throwCallBackError);
	 	}
		function throwCallBackError(error){
            console.log(error)
            $window.alert("Error\n\nDatasource callback failed!")
        }

		$timeout(function () {
			$scope.expandTextAreaOnLoad();
		}, 1000);

		$scope.update();
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof mspVendorPackageSubmit !== "undefined") {
		return mspVendorPackageSubmit();
	}
}