/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, Notification) {

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});

		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}


		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isResView = (window.currentViewName == 'RES_VIEW');
		$scope.q716Select = [];
		$scope.q711Select = [];
		$scope.q711Loading = false;
		$scope.q716Loading = false;
		$scope.isDataFetching = false;
		$scope.requestForInspection = $scope.oriMsgCustomFields.requestForInspection;
		$scope.requestForInspection.isDataFetched = ($scope.requestForInspection.isDataFetched || $scope.requestForInspection.isDataFetched == 'true');

		var todayDate = '';
		$scope.getServerTime(function (serverDate) {
			todayDate = serverDate;			
			initORIview();
		});

		var CONSTANTS_OBJ = {
				IMAGE_ASITE_DEFAULT_STR: '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR: 'images/htmlform/interserve/interserve-logo.png',
				DS_INS_INSP_QSRefList: 'DS_INS_INSP_QSRefList',
				DIST_USER_LIST_KEY: 'dist-user-list',
				QS_REF_LABEL: 'Qs Reference List',
				DS_INS_INSP_BOQList: 'DS_INS_INSP_BOQList',
				DS_INS_INSP_BOQList_LABEL: 'Boq Details list',
				SUB_CONTRACTOR_LIST_KEY: 'sub-contractor-list',
				SUB_CONTRACTOR_LIST_KEY_LABEL: 'Sub Contractors list',
				DS_INS_RequestForInformation_Details: 'DS_INS_RequestForInformation_Details',
				NOTIFICTION_LIST_FOR_Q711_KEY: "Q711",
				NOTIFICTION_LIST_FOR_Q716_KEY: "Q716",
				NOTIFICTION_LIST_FOR_Q711_LABEL: 'Notification list for Q711',
				NOTIFICTION_LIST_FOR_Q716_LABEL: 'Notification list for Q716',
				DS_INS_INSP_RoomList: 'DS_INS_INSP_RoomList',
				DS_INS_INSP_RoomList_LABEL: 'Location'
			},
			STATIC_OBJ = {
				rfiList: {
					recordGuid: '',
					isRecordSelected: false,
					isRecordShow: true,
					isRecordDeleted: false,
					isRecordHeader: false,
					isLoading: false,
					rfiQsRef: "",
					rfiQsRefList: [],
					recordBoQItemList: [{
						recordBoQItemsList: [],
						rfiQsRef: "",
						recordBoqItemActivity: "",
						rfiRoomNo: [{
							rfiQsRef: "",
							recordBoqItemActivity: "",
							roomNo: "",
							recordRoomNoList: [],
							commentList: [{
								rfiQsRef: "",
								recordBoqItemActivity: "",
								roomNo: "",
								DrawingNo: "",
								rfiSpeciinput: "",
								criteriainput: ""
							}]
						}]
					}]
				},
				recordBoQItemList: {
					recordBoQItemsList: [],
					rfiQsRef: "",
					recordBoqItemActivity: "",
					rfiRoomNo: [{
						recordRoomNoList: [],
						rfiQsRef: "",
						recordBoqItemActivity: "",
						roomNo: "",
						commentList: [{
							rfiQsRef: "",
							recordBoqItemActivity: "",
							roomNo: "",
							DrawingNo: "",
							rfiSpeciinput: "",
							criteriainput: ""
						}]
					}]
				},
				rfiRoomNo: {
					recordRoomNoList: [],
					rfiQsRef: "",
					recordBoqItemActivity: "",
					roomNo: "",
					commentList: [{
						rfiQsRef: "",
						recordBoqItemActivity: "",
						roomNo: "",
						DrawingNo: '',
						rfiSpeciinput: '',
						criteriainput: ''
					}]
				},
				commentList: {
					rfiQsRef: "",
					recordBoqItemActivity: "",
					roomNo: "",
					DrawingNo: '',
					rfiSpeciinput: '',
					criteriainput: ''
				},
				userPresent: {
					userName: ""
				}
			},
			callBackRespForQSelect = {},
			callBackRespForBoQItems = {},
			callBackRespForRoomItems = {},
			callBackRespForQsRef = {},
			isDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'YES'),
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
			FORMID = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] || '',
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');

		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		$scope.oriMsgCustomFields.isDefaultLogo = true;

		$scope.tableUtilSettings = {
			rfiList: {
				tooltip: "select to remove/remove all/Insert new RFI Record data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRecordSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore: 0,
					deleteAllRow: 0,
					deleteSelected: 0,
					insertAfter : 0
				},
				newStaticObject: angular.copy(STATIC_OBJ.rfiList),
				ADD_NEW_BEFORE_TIP: "Insert before RFI Record Details",
				ADD_NEW_AFTER_TIP: "Insert after RFI Record Details",
				deleteAllRowTooltip: "Remove all RFI Record Details",
				deleteCurrRowMsg: "Remove RFI Record Details",
				deleteSelectedMsg: "Remove selected RFI Record Details",
				addItemCallBack: function () {
					refreshQsRefList();
				},
				deleteItemCallBack: function () {
					refreshQsRefList();
				}
			}
		};

		$scope.onQsRefSelectionChanged = function (QsRef, currentRow) {
			refreshQsRefList();
			currentRow.recordBoQItemList.splice(0);
			currentRow.recordBoQItemList.push(angular.copy(STATIC_OBJ.recordBoQItemList));
			getBOQByQsRef(QsRef, currentRow.recordBoQItemList, currentRow);
		};

		$scope.onBoQItemSelectionChanged = function (BoQItem, qsRef, curRow, list, qselectName, index) {
			refreshQsBoQItemsList(list, qsRef);
			list[index].rfiRoomNo.splice(0);
			list[index].rfiRoomNo.push(angular.copy(STATIC_OBJ.rfiRoomNo));
			getRoomItemsDetails(BoQItem, qsRef, list[index].rfiRoomNo, curRow);
		};

		$scope.onRoomSelectionChanged = function (BoQItem, qsRef, list) {
			refreshRoomNoList(list, qsRef, BoQItem);
		};

		$scope.changeItemSelectionEvent = function(list, key) {
			// get selected appbuilderids.		
			var selectedAppIds = list[0] && (list[0].options.filter(function(formObj) {
				return formObj.checked;
			}) || []).map(function(checkedObj){
				return checkedObj.appBuilderId
			}).join() || '';

			if(key == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY) {
				$scope.requestForInspection.strQ711AppbuilderId = selectedAppIds;
				$scope.requestForInspection.strQ711Select = $scope.requestForInspection.q711Select.join(',');
				$scope.requestForInspection.strQ716Select = '';
			}else if(key == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY) {
				$scope.requestForInspection.strQ716AppbuilderId = selectedAppIds;
				$scope.requestForInspection.strQ716Select = $scope.requestForInspection.q716Select.join(',');
				$scope.requestForInspection.strQ711Select = '';
			}
		};

		$scope.onQselectChanged = function (selectedList, qselect) {
			resetRFITabel();
			if(qselect == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY) {
				$scope.requestForInspection.strQ711Select = selectedList.join(',');
				$scope.oriMsgCustomFields.ORI_FORMTITLE = 'Request for Inspection for '+ $scope.requestForInspection.strQ711Select;
				$scope.requestForInspection.q716Select = '';
				$scope.requestForInspection.strQ716Select = '';	
			}else if(qselect == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY) {
				$scope.requestForInspection.strQ716Select = selectedList.join(',');
				$scope.oriMsgCustomFields.ORI_FORMTITLE = 'Request for Inspection for '+ $scope.requestForInspection.strQ716Select;
				$scope.requestForInspection.q711Select = '';
				$scope.requestForInspection.strQ711Select = '';
			}
			getQsRefDetail(selectedList, $scope.requestForInspection.rfiList[0]);
		};

		$scope.onTypeOfTestChange = function (selectedItem) {
			$scope.requestForInspection.testTypeLabel = selectedItem.displayValue || "";
		};

		$scope.insertNewItems = function (list, fromStructure, qsRef, BoQItem) {
			$scope.addRepeatingRow(list, angular.copy(STATIC_OBJ[fromStructure]));

			if (fromStructure == 'rfiList') {
				refreshQsRefList();
				return;
			}
			if (fromStructure == 'recordBoQItemList') {
				refreshQsBoQItemsList(list, qsRef);
				return;
			}

			if (fromStructure == 'rfiRoomNo') {
				refreshRoomNoList(list, qsRef, BoQItem);
				return;
			}

		};

		$scope.deleteItem = function (list, index, listName, qsRef, BoQItem) {
			list.splice(index, 1);

			if (listName === 'rfiRoomNo') {
				refreshRoomNoList(list, qsRef, BoQItem);
				return;
			}
			if (listName === 'recordBoQItemList') {
				refreshQsBoQItemsList(list, qsRef);
				return;
			}
		};

		$scope.q7111chek = function () {
			if ($scope.requestForInspection.q711Node == "Yes") {
				$scope.requestForInspection.q716Node = "No";
				$scope.requestForInspection.q716Select = '';
				$scope.requestForInspection.strQ716Select = '';
				getQSelectDetail();
			} else {
				$scope.requestForInspection.q711Select = '';
				$scope.requestForInspection.strQ711Select = '';
				$scope.requestForInspection.isDataFetched = false;
			}
			!$scope.requestForInspection.isDataFetched && resetRFITabel();
		}
		$scope.q7116chek = function () {
			if ($scope.requestForInspection.q716Node == "Yes") {
				$scope.requestForInspection.q711Node = "No";
				$scope.requestForInspection.q711Select = '';
				$scope.requestForInspection.strQ711Select = '';
				getQSelectDetail();
			} else {
				$scope.requestForInspection.q716Select = '';
				$scope.requestForInspection.strQ716Select = '';
				$scope.requestForInspection.isDataFetched = false;
			}
			!$scope.requestForInspection.isDataFetched && resetRFITabel();
		}

		if ($scope.isOriView) {
			setOriViewBase();
		} else if ($scope.isResView) {			
			$scope.requestForInspection.inspectedBy = document.getElementById('DS_WORKINGUSER').value;
			$scope.requestForInspection.inspectedDate = '';
			$scope.requestForInspection.inspectedTime = '';
			$scope.requestForInspection.rfiInspectionStatus = '';
			if($scope.requestForInspection.nextStage == 'at trust user') {
				$scope.requestForInspection.currentStage = 'at trust user';
				$scope.requestForInspection.nextStage = 'at originator';
			} else if($scope.requestForInspection.nextStage == 'at originator') {
				$scope.requestForInspection.currentStage = 'at originator';
				$scope.requestForInspection.nextStage = 'at trust user';
			}
		}

		if ($scope.isOriView && FORMID == '') {
			var workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
			var workingUser = workingUserObj.Value.split('#')[0];
			$scope.requestForInspection.distUserDetails.originatorUser = workingUser.replace('|', '#').trim();
		}

		$scope.update();
		function initORIview() {
			if ($scope.isOriView) {
				$scope.oriMsgCustomFields['Originator'] = $scope.getWorkingUserId() + ' # ' + document.getElementById('DS_WORKINGUSER').value;
				$scope.oriMsgCustomFields['OriginatorResDate'] = $scope.formatDate(new Date(todayDate), 'dd/mm/yy');
			}
		}

		function resetRFITabel() {
			$scope.requestForInspection.rfiList.splice(0);
			$scope.requestForInspection.rfiList.push(angular.copy(STATIC_OBJ.rfiList));
		}

		function getSelectedQRecordName() {
			if ($scope.requestForInspection.q711Node == 'Yes') {
				return CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY;
			}

			if ($scope.requestForInspection.q716Node == 'Yes') {
				return CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY;
			}
		};

		function getQSelectedName() {
			var qselectName = getSelectedQRecordName();
			if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY) {
				return $scope.requestForInspection.q711Select;
			}
			if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY) {
				return $scope.requestForInspection.q716Select;
			}
		};

		function getQSelectDetail() {
			var qselectName = getSelectedQRecordName();
			callBackRespForQSelect[qselectName] = [];
			if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY) {
				$scope.q711Loading = true;
			}else if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY) {
				$scope.q716Loading = true;
			}

			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": CONSTANTS_OBJ.DS_INS_RequestForInformation_Details,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": CONSTANTS_OBJ.DS_INS_RequestForInformation_Details,
						"fieldValue": qselectName
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				if (response.data) {
					callBackRespForQSelect[qselectName] = angular.fromJson(response.data[CONSTANTS_OBJ.DS_INS_RequestForInformation_Details]).Items.Item;
					if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY) {
						$scope.q711Loading = false;
						refreshQ711SelectList();
					}else if(qselectName == CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY) {
						refreshQ716SelectList();
						$scope.q716Loading = false;
					}
				}

				$scope.update();
			}, function (error) {
				$scope.update();
				$scope.q711Loading = false;
				$scope.q716Loading = false;
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error',
					message: errorMsg
				});
			});
		};

		function setSelectedFormTypeCode(qselectName, qselect) {
			var respList = callBackRespForQsRef[qselectName][qselect], listByQsRef = {}, rfiObj={}, updatedRfiList=[];
			for(var i=0; i<respList.length; i++) {
				rfiObj = respList[i];
				if(listByQsRef[rfiObj.Value1]) {
					if(listByQsRef[rfiObj.Value1].listByBoq[rfiObj.Value3]) {
						listByQsRef[rfiObj.Value1].listByBoq[rfiObj.Value3].push(rfiObj);
					} else {
						listByQsRef[rfiObj.Value1].listByBoq = {};
						listByQsRef[rfiObj.Value1].listByBoq[rfiObj.Value3] = [rfiObj];
						listByQsRef[rfiObj.Value1].push(rfiObj);
					}
				} else {
					listByQsRef[rfiObj.Value1] = [rfiObj];
					listByQsRef[rfiObj.Value1].listByBoq = {};
					listByQsRef[rfiObj.Value1].listByBoq[rfiObj.Value3] = [rfiObj];
				}
			}			
			var rfiObj = {}, boQItemObj = {}, roomListObj = {};
			for (var key in listByQsRef) {
				if (listByQsRef[key]) {
					rfiObj = angular.copy(STATIC_OBJ.rfiList);
					rfiObj.rfiQsRef = key;
					rfiObj.recordBoQItemList = [];
					for (var arrayKey in listByQsRef[key]) { 
						if(arrayKey != 'listByBoq') {
							boQItemObj = angular.copy(STATIC_OBJ.recordBoQItemList);
							boQItemObj.rfiQsRef = key;
							boQItemObj.recordBoqItemActivity = (listByQsRef[key][arrayKey].Value3 || '').trim();
							boQItemObj.rfiRoomNo = [];	
							rfiObj.recordBoQItemList.push(boQItemObj);
							roomListObj = angular.copy(STATIC_OBJ.rfiRoomNo);
							roomListObj.rfiQsRef = key;
							roomListObj.recordBoqItemActivity = (listByQsRef[key][arrayKey].Value3 || '').trim();
							roomListObj.roomNo = (listByQsRef[key][arrayKey].Value4 || '').trim();
							roomListObj.commentList[0].rfiQsRef = key;
							roomListObj.commentList[0].recordBoqItemActivity = (listByQsRef[key][arrayKey].Value3 || '').trim();
							roomListObj.commentList[0].roomNo = (listByQsRef[key][arrayKey].Value4 || '').trim();
							boQItemObj.rfiRoomNo.push(roomListObj);						
						} else if(arrayKey == 'listByBoq') {
							for(var listByBoqKey in listByQsRef[key][arrayKey]) {
								if(listByQsRef[key][arrayKey][listByBoqKey]) {										
									for(var boqKey in listByQsRef[key][arrayKey][listByBoqKey]) {
										if(listByQsRef[key][arrayKey][listByBoqKey][boqKey]) {
											roomListObj = angular.copy(STATIC_OBJ.rfiRoomNo);
											roomListObj.rfiQsRef = key;
											roomListObj.recordBoqItemActivity = (listByQsRef[key][arrayKey][listByBoqKey][boqKey].Value3 || '').trim();
											roomListObj.roomNo = (listByQsRef[key][arrayKey][listByBoqKey][boqKey].Value4 || '').trim();
											if(!commonApi._.find(boQItemObj.rfiRoomNo, function(roleObj) {
												return roleObj.roomNo == roomListObj.roomNo;
											})) {	
												roomListObj.commentList[0].rfiQsRef = key;
												roomListObj.commentList[0].recordBoqItemActivity = (listByQsRef[key][arrayKey][listByBoqKey][boqKey].Value3 || '').trim();
												roomListObj.commentList[0].roomNo = (listByQsRef[key][arrayKey][listByBoqKey][boqKey].Value4 || '').trim();											
												boQItemObj.rfiRoomNo.push(roomListObj);
											}								
										}
									}
								}
							}
						}
					}
					updatedRfiList.push(rfiObj);
				}
			}			
			$scope.requestForInspection.rfiList = updatedRfiList;
		}

		function getQsRefDetail(qselect, curRow) {
			var qselectName = getSelectedQRecordName();
			if(!qselectName || !qselect) {				
				return;
			}
			
			$scope.isDataFetching = true;
			curRow.isLoading = true;			
			callBackRespForQsRef[qselectName] = [];
			callBackRespForQsRef[qselectName][qselect] = {};

			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": CONSTANTS_OBJ.DS_INS_INSP_QSRefList,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": CONSTANTS_OBJ.DS_INS_INSP_QSRefList,
						"fieldValue": qselectName + ' | ' + qselect
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				curRow.isLoading = false;
				if (response.data) {
					callBackRespForQsRef[qselectName][qselect] = angular.fromJson(response.data[CONSTANTS_OBJ.DS_INS_INSP_QSRefList]).Items.Item;					
					refreshQsRefList();
					setSelectedFormTypeCode(qselectName, qselect);
				}
				$scope.isDataFetching = false;
				$scope.requestForInspection.isDataFetched = true;
				$scope.update();
			}, function (error) {
				curRow.isLoading = false;
				$scope.isDataFetching = false;
				$scope.update();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error',
					message: errorMsg
				});
			});
		};

		function getBOQByQsRef(qsRef, list, currentRow) {
			if (callBackRespForBoQItems[qsRef]) {
				refreshQsBoQItemsList(list, qsRef);
				return;
			}
			
			currentRow.isLoading = true;
			callBackRespForBoQItems[qsRef] = {};

			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": CONSTANTS_OBJ.DS_INS_INSP_BOQList,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": CONSTANTS_OBJ.DS_INS_INSP_BOQList,
						"fieldValue": getSelectedQRecordName() + ' | ' + getQSelectedName() +  ' | ' + qsRef
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				if (response.data) {
					callBackRespForBoQItems[qsRef][CONSTANTS_OBJ.DS_INS_INSP_BOQList] = angular.fromJson(response.data[CONSTANTS_OBJ.DS_INS_INSP_BOQList]).Items.Item;
					refreshQsBoQItemsList(list, qsRef);
				}
				currentRow.isLoading = false;
				$scope.update();
			}, function (error) {
				currentRow.isLoading = false;
				$scope.update();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error',
					message: errorMsg
				});
			});
		};

		function getRoomItemsDetails(BoQItem, qsRef, list, curRow) {
			if (callBackRespForRoomItems[qsRef] && callBackRespForRoomItems[qsRef][BoQItem]) {
				refreshRoomNoList(list, qsRef, BoQItem);
				return;
			}

			if (!callBackRespForRoomItems[qsRef]) {
				callBackRespForRoomItems[qsRef] = {};
			}

			callBackRespForRoomItems[qsRef][BoQItem] = {}
			curRow.isLoading = true;

			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": CONSTANTS_OBJ.DS_INS_INSP_RoomList,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": CONSTANTS_OBJ.DS_INS_INSP_RoomList,
						"fieldValue": getSelectedQRecordName() + ' | ' + getQSelectedName() + ' | ' + qsRef + ' | ' + BoQItem
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				curRow.isLoading = false;
				if (response.data) {
					callBackRespForRoomItems[qsRef][BoQItem][CONSTANTS_OBJ.DS_INS_INSP_RoomList] = angular.fromJson(response.data[CONSTANTS_OBJ.DS_INS_INSP_RoomList]).Items.Item;
					refreshRoomNoList(list, qsRef, BoQItem);
				}

				$scope.update();
			}, function (error) {
				curRow.isLoading = false;
				$scope.update();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error',
					message: errorMsg
				});
			});
		};

		function refreshQ711SelectList() {
			$scope.q711Select = structureItemList(CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY, callBackRespForQSelect[CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY]);
		};

		function refreshQ716SelectList() {
			$scope.q716Select = structureItemList(CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY, callBackRespForQSelect[CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY]);
		}

		function refreshQsRefList() {
			var selectedQsRef = [];
			$scope.requestForInspection.rfiList.forEach(function (record) {
				if (record.rfiQsRef) {
					selectedQsRef.push(record.rfiQsRef);
				}
			});

			var qselectName = getSelectedQRecordName();
			var qselect = getQSelectedName();
			$scope.requestForInspection.rfiList.forEach(function (record) {
				var excludeQsRef = angular.copy(selectedQsRef);
				var ind = excludeQsRef.indexOf(record.rfiQsRef);
				if (ind != -1) {
					excludeQsRef.splice(ind, 1);
				}

				record.rfiQsRefList = structureItemList(CONSTANTS_OBJ.DS_INS_INSP_QSRefList, callBackRespForQsRef[qselectName][qselect], excludeQsRef);
			});
		};

		function refreshQsBoQItemsList(list, qsRef) {
			if (!qsRef || !callBackRespForBoQItems[qsRef]) {
				return;
			}
			var selectedBoQItems = [];
			list.forEach(function (record) {
				if (record.recordBoqItemActivity) {
					selectedBoQItems.push(record.recordBoqItemActivity);
				}
			});

			var boqItems = callBackRespForBoQItems[qsRef][CONSTANTS_OBJ.DS_INS_INSP_BOQList].filter(function(boqItem) {
				return (boqItem.Value1 === qsRef);
			});

			list.forEach(function (record) {
				var excludeBoQItems = angular.copy(selectedBoQItems);
				var ind = excludeBoQItems.indexOf(record.recordBoqItemActivity);
				if (ind != -1) {
					excludeBoQItems.splice(ind, 1);
				}
				record.recordBoQItemsList = structureItemList(CONSTANTS_OBJ.DS_INS_INSP_BOQList, boqItems, excludeBoQItems);
			});
		};

		function refreshRoomNoList(list, qsRef, BoQItem) {
			if (!qsRef || !BoQItem || !callBackRespForRoomItems[qsRef] || !callBackRespForRoomItems[qsRef][BoQItem]) {
				return;
			}

			var selectedRoomNo = [];
			list.forEach(function (record) {
				if (record.roomNo) {
					selectedRoomNo.push(record.roomNo);
				}
			});

			var roomItems = callBackRespForRoomItems[qsRef][BoQItem][CONSTANTS_OBJ.DS_INS_INSP_RoomList].filter(function(roomItem) {
				return (roomItem.Value3 === BoQItem);
			});

			list.forEach(function (record) {
				var excludeRoomNo = angular.copy(selectedRoomNo);
				var ind = excludeRoomNo.indexOf(record.roomNo);
				if (ind != -1) {
					excludeRoomNo.splice(ind, 1);
				}
				record.recordRoomNoList = structureItemList(CONSTANTS_OBJ.DS_INS_INSP_RoomList, roomItems, excludeRoomNo);
			});
		};
		
		function structureItemList(setFor, availList, excludedModels) {
			var tempList = [],
				optlabel = '';

			if (!excludedModels) {
				excludedModels = [];
			}
			switch (setFor) {
				case CONSTANTS_OBJ.DS_INS_INSP_QSRefList:
					angular.forEach(availList, function (item) {
						if (excludedModels.indexOf(item.Value1) == -1) {
							tempList.push({
								displayValue: item.Value1,
								rectRef: item.Value1,
								modelValue: item.Value1
							});
						}
					});
					optlabel = CONSTANTS_OBJ.DS_INS_INSP_QSRefList_LABEL;
					break;
				case CONSTANTS_OBJ.DS_INS_INSP_BOQList:
					angular.forEach(availList, function (item) {
						if (excludedModels.indexOf(item.Value2) == -1) {
							tempList.push({
								displayValue: item.Value2.split('|')[1].trim(),
								modelValue: item.Value2
							});
						}

					});
					optlabel = CONSTANTS_OBJ.DS_INS_INSP_BOQList_LABEL;
					break;
				case CONSTANTS_OBJ.DIST_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.DIST_USER_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value.trim()
						});
					});
					optlabel = CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_KEY:
						angular.forEach(availList, function (item) {
							tempList.push({
								displayValue: item.Value2,
								modelValue: item.Value2,
								appBuilderId: item.Value4
							});
						});
						optlabel = CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q711_LABEL;
						break;
				case CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value2,
							modelValue: item.Value2,
							appBuilderId: item.Value4
						});
					});
					optlabel = CONSTANTS_OBJ.NOTIFICTION_LIST_FOR_Q716_LABEL;
					break;
				case CONSTANTS_OBJ.DS_INS_INSP_RoomList:
					angular.forEach(availList, function (item) {
						if (excludedModels.indexOf(item.Value1) == -1) {
							tempList.push({
								displayValue: item.Value1.split('|')[1].trim(),
								modelValue: item.Value1
							});
						}
					});
					optlabel = CONSTANTS_OBJ.DS_INS_INSP_RoomList_LABEL;
					break;
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};

		function setOriViewBase() {
			$scope.userTODitrubute = structureItemList(CONSTANTS_OBJ.DIST_USER_LIST_KEY, commonApi.roleUsersListByRoleName('trust', projAllRolesList));
			$scope.requestForInspection.contract = $scope.asiteSystemDataReadOnly._3_Project_Data.DS_PROJECTNAME;
			$scope.projectOrg = structureItemList(CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_KEY, $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS').filter(function (org) {
				return org.Value.toLowerCase().indexOf('interserve') == -1;
			}));

			// contract number list
			if(!$scope.requestForInspection.contractNo) {
				// default set 5.
				var blockNo = (configAttributesList.filter(function(attrObj) {
					return ((attrObj.Value3.toLowerCase() == 'block number' || attrObj.Value3.toLowerCase() == 'blocknumber')) && attrObj.Value11 == 'Active';
				})[0] || {Value7 : '05'}).Value7;

				switch(blockNo) {
					case '05':
						$scope.contractNumberList = [{
							displayName : '63421 (Block 05)',
							value : '63421 (Block 05)'
						}];
						$scope.requestForInspection.contractNo = '63421 (Block 05)';
						break;
					case '10':
						$scope.contractNumberList = [{
							displayName : '63422 (Block 10)',
							value : '63422 (Block 10)'
						}];
						$scope.requestForInspection.contractNo = '63422 (Block 10)';
						break;
					case '16':
						$scope.contractNumberList = [{
							displayName : '63420 (Block 16)',
							value : '63420 (Block 16)'
						}];
						$scope.requestForInspection.contractNo = '63420 (Block 16)';
						break;
				}
			}

			if(!FORMID) {
				$scope.requestForInspection.rfiList = [];
			}
			$scope.requestForInspection.currentStage = 'at originator';
			$scope.requestForInspection.nextStage = 'at trust user';

			// make a call while drfat and if form type is selected.
			if(isDraft) {
				var formTypeList = [],
					formTypekey = '';
				if ($scope.requestForInspection.q711Node == "Yes") {
					$scope.q7111chek();
					formTypeList = $scope.requestForInspection.q711Select;
					formTypekey = 'Q711';
				} else if($scope.requestForInspection.q716Node == "Yes") {
					$scope.q7116chek();
					formTypeList = $scope.requestForInspection.q716Select;
					formTypekey = 'Q716';
				}

				if(!$scope.requestForInspection.isDataFetched && formTypeList.length && formTypekey) {
					$scope.onQselectChanged(formTypeList, formTypekey);
				}
			}
		};

		var setFormWorkflow = function () {
			var userTodistribute = '',
				currFormStaus = '',
				autoDistNode = '3';

			// Distribution Will be made from here
			// resetting auto distribution node.
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if($scope.isOriView) {
				userTodistribute = $scope.requestForInspection.distUserDetails.distUser;
				currFormStaus = 'for approval';
			} else if($scope.isResView) {
				currFormStaus = $scope.requestForInspection.rfiInspectionStatus || 'for approval';
			} 

			if(userTodistribute) {
				commonApi.setDistributionNode({
					actionNodeList : [{
						strUser : userTodistribute,
						strAction : "3#Respond",
						strDate : commonApi.calculateDistDateFromDays({
							baseDate: todayDate,
							days : 7
						})                    
					}],
					autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE : autoDistNode
				});
			}

            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {  
				$scope.requestForInspection.rfiInspectionStatus = currFormStaus;           
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
			}
		},	setOtherFormStatus = function () {
			var currFormStaus, formAppIds, formAppIdsCount = 0, strStatusId;
			// set either or fields to changes that status of used Forms.
			if($scope.requestForInspection.strQ711AppbuilderId){
				currFormStaus = 'not accepted';
				formAppIds = $scope.requestForInspection.strQ711AppbuilderId;
			} else if($scope.requestForInspection.strQ716AppbuilderId) {
				currFormStaus = 'rejected';
				formAppIds = $scope.requestForInspection.strQ716AppbuilderId;
			}
			
			var strFormStatusId = (commonApi.getFormStatusId({
				availFormStatusesList : availFormStatuses,
				strStatus : currFormStaus
			}).split('#')[0] || '').trim();

			// set count of selected forms on bases set statuses.
			// , count in formAppbuilder status.
			formAppIdsCount = formAppIds.split(",").length - 1;
			strStatusId = strFormStatusId;
			for (var i = 0; i < formAppIdsCount; i++) {				
				strStatusId += ',' + strFormStatusId;
			}
			
			$scope.asiteSystemDataReadWrite.Form_Status_Change = {
				DS_CHANGE_STATUS_FORMS: formAppIds,
				DS_CHANGE_STATUS_IDS: strStatusId
			};
		};
		
		$window.oriformSubmitCallBack = function () {
			if($scope.requestForInspection.rfiList.length && !$scope.requestForInspection.rfiList[0].recordGuid) {
				setFormWorkflow();			
				// set OTH Flag
				$scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = "0";
				if($scope.isResView && $scope.requestForInspection.rfiInspectionStatus  == 'rejected') {
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = "1";
					setOtherFormStatus();
				}
				return false;
			}

			Notification.error({
				title: 'Alert',
				message: 'There is no records is created for Inspection, Please get data and fill it accordingly.' 
			});

			return true;
		};

		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			return false;
		}
	}
	
	return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}