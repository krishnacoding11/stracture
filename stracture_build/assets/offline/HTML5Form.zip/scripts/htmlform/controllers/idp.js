/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function(angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
		var ctrl = this;
		
		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
            onComplete: function () {
            	$timeout(function() {
            		$scope.loaded = true;
            		$element.addClass('loaded');                
            	}, 50);
            }
        });
		
		var projectInpt = document.getElementById('DS_PROJECTNAME');
		var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if(projectId == "null") {
        	projectId = $window.currProjId;
        }

        if(!$window.USP || !$window.USP.email) {
        	$window.alert('Fetal Error > User detail not found');
        }
        
		var printedBy = $window.USP ? $window.USP.email : "";
		var printedOn = "";
		
		$scope.project = projectInpt ? projectInpt.value : "";
		$scope.ptemplate = "";
		
		$scope.data = {};
//		$scope.data.pref = "";
		
		// filter scope variables
		$scope.showDeliverables = true;
		$scope.showComment = true;
		$scope.showItem = true;
		$scope.showBlank = true;
		$scope.showMask = false;
		$scope.onlyThreeD = false;
		$scope.onlyMPDT = false;
		$scope.filterRole = "";
		$scope.filterStage = "";
		$scope.filterLOD = "";
		
		var staticValMap = "IDP_File_Type,IDP_Plan_Status,IDP_RAG,IDP_Item_Role";
		var staticValues = {};
		$scope.staticValues = {};
		var setStaticListObj = function() {
			var staticValMapArray = staticValMap.split(',');
			for (var i = 0; i < staticValMapArray.length; i++) {
				var type = staticValMapArray[i];
				staticValues[type] = {};
				var el = document.getElementById('select' + type);
				if(!el) {
					continue;
				}
				
				for (var j = 0; j < el.options.length; j++) {
					var option = el.options[j];
					var dataText = angular.element(option).text().split(':');
					var code = dataText[0] || 'firstValue';
					staticValues[type][code] = dataText[1];
				}
			}
			
			$scope.staticValues = staticValues;
		}
		
		setStaticListObj();
		
		var getStaticValue = function(type, code) {
			var staticObj = $scope.staticValues[type];
			return staticObj[(code || 'firstValue')];
		};
		
		var getDynamicValue = function(array, code) {
			for (var i = 0; i < array.length; i++) {
				var item = array[i];
				if(item.code == code) {
					var name = item.displayValue || '';
					return name.replace(code + ':', '')
					break;
				}
			}
		};
		
		var getRoleMap = function() {
			var user_role_map = $element.find('.user_role_map').val();
			var roleMap = user_role_map ? angular.fromJson(user_role_map) : {TM: "TM", EPM: "EPM", SIM: "SIM", SUP: "SUPPLIER", OTH: "OTHER"};
			return roleMap;
		};
		
		$scope.user = {
			roles: [],
			org: "",
			usp: {
				email: $window.USP.email,
				orgID: $window.USP.orgID,
				orgCode: "",
				tpdOrgName: $window.USP.tpdOrgName,
				tpdUserName: $window.USP.tpdUserName,
				userID: ($window.USP.userID || "").split('$$')[0]
			}
		};
		
		var defineRole = function() {
			var userRoles = $scope.getWorkspaceRole() || [];
			var roleMap = getRoleMap();
			var roleArray = [];
			
			for(var key in roleMap) {
				var role = roleMap[key].split(",");
				for(var i = 0; i < role.length; i++) {
					var r = role[i];
					if(userRoles.indexOf(r || key) > -1) {
						roleArray.push(key);
					}
				}
			}
			
			$scope.user.roles = roleArray;
		};
		
		defineRole();
		
		$scope.orgList = [];
		$scope.volumeList = [];
		$scope.locationList = [];
		$scope.regionList = [];
		$scope.pCodeList = [];
		$scope.stageStatList = []; 
		$scope.capabilityList = [];
		$scope.openFormatList = []; 
		$scope.lodList = [];
		function fetchDynamicLists() {
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/dynamicContent",
				method: "post",
				withCredentials: true,
				headers : {
					 "Content-Type": "application/x-www-form-urlencoded"
				},
				data : "projectId=" + projectId + "&typeNames=Organization,Volume,Location,Region,"+
				"Project Number,Project Code,Stage Status,Capability,Open Format,LOD"
			}).then(function(response) {
				var list = response.data || {};
				$scope.orgList = list.Organization || [];
				
				// set the user role based on organization
				var userOrg = $window.USP ? $window.USP.tpdOrgName : "";
				var orgObj = commonApi._.findWhere($scope.orgList, { name: userOrg }) || {};
				
				$scope.user.org = orgObj.code;
				$scope.user.usp.orgCode = orgObj.code;
				
				if(!$scope.user.org) {
					$scope.user.roles = ['OTH'];
				}
				
				$scope.volumeList = list.Volume || [];
				$scope.locationList = list.Location || [];
				$scope.regionList = list.Region || [];
				$scope.stageStatList = list['Stage Status'] || []; 
				$scope.capabilityList = list.Capability || [];
				$scope.openFormatList = list['Open Format'] || [];
				$scope.lodList = list.LOD || []; 
				
				$scope.pCodeList = list['Project Number'] || [];
				if(!$scope.pCodeList.length) {
					$scope.pCodeList = list['Project Code'] || [];
				}
				
				if(!$scope.data.pref && $scope.pCodeList.length) {
					$scope.data.pref = $scope.pCodeList[0].code;
				}
			}, function() {
//				$window.alert('error');
			});
		}
		
		fetchDynamicLists();
		
		/**
		 * identify that row has atleast one stage filled or not
		 * @param {object} deliverable
		 * @returns {boolean} isBlank
		 */
		$scope.isBlankRow = function(deliverable) {
			if(!deliverable)
				return;
			
			var isBlank = true;
			if(deliverable.stage) {
				for(var k = 0; k < deliverable.stage.length; k++) {
					var stage = deliverable.stage[k];
					if(stage.role || stage.load) {
						isBlank = false;
						break;
					}
				}
			}
			
			return isBlank;
		};
		
		var getStageIndex = function() {
			if(!$scope.filterStage)
				return;
			
			var index = 0;
			if($scope.data.programme && $scope.data.programme.pstage) {
				for(var k = 0; k < $scope.data.programme.pstage.length; k++) {
					var stage = $scope.data.programme.pstage[k];
					if(stage.stageRef == $scope.filterStage) {
						index = k;
						break;
					}
				}
			}
			
			return index;
		};
		
		/**
		 * check that row has at list one column with specific role
		 * @param {object} deliverable
		 * @returns {boolean} hasRole
		 */
		$scope.hasRole = function(deliverable) {
			if(!deliverable)
				return;
			
			var hasRole = true;
			if(deliverable.stage) {
				for(var k = 0; k < deliverable.stage.length; k++) {
					var stage = deliverable.stage[k];
					if(stage.role == $scope.filterRole) {
						hasRole = false;
						break;
					}
				}
			}
			
			return hasRole;
		};
		
		/**
		 * check that row has at list one column with specific stage
		 * @param {number} index
		 * @param {object} deliverable
		 * @returns {boolean} hasStage
		 */
		$scope.hasStage = function(deliverable) {
			if(!deliverable)
				return;
			
			var index = getStageIndex();
			var hasStage = true;
			
			if(deliverable.stage) {
				var stage = deliverable.stage[index];
				if(stage && (stage.role || stage.lod)) {
					hasStage = false;
				}
			} else {
				hasStage = true;
			}
			
			return hasStage;
		};
		
		/**
		 * check that row has at list one column with specific lod
		 * @param {object} deliverable
		 * @returns {boolean} hasLod
		 */
		$scope.hasLod = function(deliverable) {
			if(!deliverable)
				return;
			
			var hasLod = true;
			if(deliverable.stage) {
				for(var k = 0; k < deliverable.stage.length; k++) {
					var stage = deliverable.stage[k];
					if(stage.lod == $scope.filterLOD) {
						hasLod = false;
						break;
					}
				}
			}
			
			return hasLod;
		};
		
		/**
		 * check that row has at list one column with file link
		 * @param {object} item
		 * @returns {boolean} hasFileLink
		 */
		$scope.hasFileLink = function(item) {
			if(!item)
				return;
			
			var hasFileLink = false;
			if(item.stage) {
				for(var k = 0; k < item.stage.length; k++) {
					var stage = item.stage[k];
					if(stage.file_link) {
						hasFileLink = true;
						break;
					}
				}
			}
			
			return hasFileLink;
		};
		
		/**
		 * highlight cell according to filter
		 * @param {object} stage
		 * @returns {boolean} highlight
		 */
		$scope.isMatch = function(stage) {
			if(!stage)
				return;
			
			var index = getStageIndex();
			
			var highlight = false;
			if((!$scope.filterStage || stage.stgno == index) && 
			   (stage.role && (!$scope.filterRole || stage.role == $scope.filterRole)) && 
			   (!$scope.filterLOD || stage.lod == $scope.filterLOD)) {
				highlight = true;
			}
			
			return highlight;
		};
		
		// parse Questions' deliverables.
		var parseQuestionDeliverables = function(data) {
			var i, j, stage, q;
			if(data.programme && data.programme.pstage) {
				for(i = 0; i < data.programme.pstage.length; i++) {
					stage = data.programme.pstage[i];
					if(stage.questions) {
						for(j = 0; j < stage.questions.length; j++) {
							q = stage.questions[j];
							if(typeof q.deliverables == "string") {
								q.deliverables = q.deliverables.split(',');
							}
							
							if(q.deliverables && q.deliverables.length == 1) {
								var d = q.deliverables[0];
								if(angular.isObject(d)) {
									if(d.content) {
										q.deliverables[0] = d.content;
									} else {
										q.deliverables = [];
									}
								}
							}
						}
					}
				}
			}
		};
		
		var sortSections = function(data) {
			if(data.section && data.section.length) {
				data.section = commonApi._.reject(data.section, function(o) {
					return !o.setitle;
				});
				
				data.section = commonApi._.sortBy(data.section, function(o) {
					sortDeliverables(o);
					return o.seref;
				});
			}
		};
		
		var sortDeliverables = function(section) {
			if(section.deliverable && section.deliverable.length) {
				section.deliverable = commonApi._.sortBy(section.deliverable, function(o) {
					if(!o.createdBy) {
						o.createdBy = printedBy;
					}
					
					if(!o.originator) {
						o.originator = $scope.user.usp;
					}
					
					return parseInt(o.dref.substr(1));
				});
				
				getServerTime(function(date) {
					for (var i = 0; i < section.deliverable.length; i++) {
						if(!section.deliverable[i].createdOn) {
							section.deliverable[i].createdOn = date;
						}
					}
				});
			}
		};
		
		var disableSaveActions = function() {
            var saveEle = document.getElementById('btnSaveForm');
            if(saveEle) {
                saveEle.disabled = true;
                saveEle.className += " btn-disabled";
            }
            var draftEle = document.getElementById('btnSaveDraft');
            if(draftEle) {
                draftEle.disabled = true;
                draftEle.className += " btn-disabled";
            }
            
            if($window.stopAutoSaveTimer) {
            	$window.stopAutoSaveTimer();
            } else if($window.oAutoSaveTimer) {
                $window.clearTimeout($window.oAutoSaveTimer);
                $window.oAutoSaveTimer = null;
            }
        };

		// update the sticky header postion on scroll
		$scope.scrollTop = 0;
		$scope.left = {};
		$scope.headerTop = 100;
		var header = $element.find('#tbl-header')[0];
		if(header) {
			var rect = header.getBoundingClientRect ? header.getBoundingClientRect() : {};
			$scope.headerTop = rect.top || header.offsetTop;
		}
		var body = document.body;
		var docElement = document.documentElement;
		/*$window.onscroll = angular.bind(ctrl, function(){
			$scope.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
			$scope.left = -(body.scrollLeft || (docElement && docElement.scrollLeft) || 0) + 'px';
			$scope.$digest();
		});*/
		
		/**
		 * fetch the date from server
		 * @param {fn} callback
		 */
		var getServerTime = function(callback) {
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/serverDateTime",
				method: 'POST',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/x-www-form-urlencoded'
				},
				transformResponse : function(data, headersGetter, status) {
					return "" + data;
				}
			}).then(function(response) {
				var data = response.data || {};
				printedOn = data || printedOn;
				callback(printedOn);
			}, function() {
				// $window.alert('error');
			});
		};
		
		/**
		 * invoke on project detail save
		 */
		var loadTemplate = function(tpl) {
			if(tpl) {
				$window.loadingImageBar && $window.loadingImageBar(true, angular.element('body'), true, 4);
				commonApi.ajax({
					url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/formXmlData",
					method: 'POST',
					withCredentials: true,
					headers : {
						 'Content-Type': 'application/x-www-form-urlencoded'
					},
					data: "formTitle=" + tpl + "&appBuilderCode=EA_IDP_TEMPLATE&projectId=" + projectId
				}).then(function(response) {
					var data = response.data || {};
					var ORI_FORMTITLE = $scope.data.ORI_FORMTITLE || "Information Delivery Plan";
					angular.merge($scope.data, (data.myFields || data));
					$scope.ptemplate = $scope.data.ptemplate = tpl;
					$scope.data.ORI_FORMTITLE = ORI_FORMTITLE;
					$scope.data.ptitle = $scope.project;
					
					if(!$scope.data.pref && $scope.pCodeList.length) {
						$scope.data.pref = $scope.pCodeList[0].code;
					}
					
					$scope.data.createdBy = printedBy;
					
					getServerTime(function(date) {
						$window.loadingImageBar && $window.loadingImageBar(false, angular.element('body'), true, 4);
						$scope.data.createdOn = date;
						
						// update data on server
						saveFormData();
					});
					
					$scope.updateCount();
				}, function() {
					$window.loadingImageBar && $window.loadingImageBar(false, angular.element('body'), true, 4);
					$window.alert('error');
				});
				
				return;
			}
			
			var tempData = $scope.getFormData();
			if(tempData.ptemplate) {
				sortSections(tempData);
				parseQuestionDeliverables(tempData);
				
				if(tempData.isValid != 'Yes') {
					disableSaveActions();
				}
				
				$scope.data = tempData;
				$scope.data.ORI_FORMTITLE = $scope.data.ORI_FORMTITLE || "Information Delivery Plan";
				$scope.ptemplate = $scope.data.ptemplate;
				$scope.data.ptitle = $scope.project;
				
				if(!$scope.data.pref && $scope.pCodeList.length) {
					$scope.data.pref = $scope.pCodeList[0].code;
				}
				
				if(!$scope.data.createdBy) {
					$scope.data.createdBy = printedBy;
				}
				
				if(!$scope.data.originator) {
					$scope.data.originator = $scope.user.usp;
				}
				
				if(!$scope.data.createdOn) {
					getServerTime(function(date) {
						$scope.data.createdOn = date;
					});
				}
				
				$scope.updateCount();
			}
		};
		
		$scope.onRegionChange = function(item) {
			var name = getDynamicValue($scope.regionList, item.region);
			item.regionName = name;
		};
		
		$scope.onPlanChange = function(item) {
			var name = getStaticValue('IDP_Plan_Status', item.status);
			item.statusName = name;
		};
		
		$scope.onCapabilityChange = function(item) {
			var name = getDynamicValue($scope.capabilityList, item.capability);
			item.capabilityName = name;
		};
		
		$scope.onFormatChange = function(item) {
			var name = getDynamicValue($scope.openFormatList, item.open_format);
			item.openFormatName = name;
		};
		
		$scope.onSupplierRoleChange = function(item) {
			var name = getDynamicValue($scope.orgList, item.role);
			item.roleName = name;
		};
		
		$scope.onLODChange = function(item) {
			var name = getDynamicValue($scope.lodList, item.lod);
			item.lodName = name;
		};
		
		$scope.onRagChange = function(item) {
			var name = getStaticValue('IDP_RAG', item.rag);
			item.ragName = name;
		};
		
		$scope.onProjInfoChange = function(item) {
			var name = getDynamicValue($scope.orgList, item.projInfoMan);
			item.projInfoManName = name;
		};
		
		$scope.onStageStatChange = function(item) {
			var name = getDynamicValue($scope.stageStatList, item.stageStat);
			item.stageStatName = name;
		};
		
		$scope.onVolumeChange = function(item) {
			var name = getDynamicValue($scope.volumeList, item.volume);
			item.volumeName = name;
		};
		
		$scope.onLocationChange = function(item) {
			var name = getDynamicValue($scope.locationList, item.location);
			item.locationName = name;
		};
		
		$scope.onFileTypeChange = function(item) {
			var name = getStaticValue('IDP_File_Type', item.file_type);
			item.fileTypeName = name;
		};
		
		$scope.onItemRoleChange = function(item) {
			var name = getStaticValue('IDP_Item_Role', item.role);
			item.roleName = name;
		};
		
		$scope.onAuthorChange = function(item) {
			var name = getDynamicValue($scope.orgList, item.role);
			item.roleName = name;
		};
		
		$scope.onSubStgLODChange = function(item) {
			var name = getDynamicValue($scope.lodList, item.lod);
			item.lodName = name;
		};
		
		$scope.onSupplierChange = function(item) {
			var name = getDynamicValue($scope.orgList, item.supplier);
			item.supplierName = name;
		};
		
		// refresh the total deliverable count at the bottom of the form
		$scope.updateCount = function() {
			if(!$scope.data) {
				$scope.data = {};
			}
			
			var sectionsCount = 0;
			var deliverablesCount = 0;
			var commentsCount = 0;
			var visibleComments = 0;
			var itemsCount = 0;
			if($scope.data.section && $scope.data.section.length) {
				sectionsCount = $scope.data.section.length;
				for(var i = 0; i < $scope.data.section.length; i++) {
					var section = $scope.data.section[i];
					if(section.deliverable) {
						deliverablesCount += section.deliverable.length;
						
						for (var j = 0; j < section.deliverable.length; j++) {
							var d = section.deliverable[j];
							if(d.comments) {
								commentsCount += d.comments.length;
								if($scope.user.roles.indexOf('EPM') > -1) {
									visibleComments += d.comments.length;
								} else {
									for (var k = 0; k < d.comments.length; k++) {
										var c = d.comments[k];
										if($scope.user.org && $scope.user.org == c.originator.orgCode) {
											visibleComments++;
										}
									}
								}
							}
							
							if(d.sub_items) {
								itemsCount += d.sub_items.length;
							}
						}
					}
				}
			}
			
			$scope.data.counts = {
				sections: sectionsCount,
				deliverables: deliverablesCount,
				comments: commentsCount,
				visibleComments: visibleComments,
				items: itemsCount
			};
			
			return (sectionsCount + ' Sections, ' + deliverablesCount + ' Deliverables, ' + visibleComments + ' Comments, ' + itemsCount + ' Items');
		};
		
		/**
		 * generate the mask based on mask key
		 * mask key : [ProjRef]-[Author]-[Volume]-[Location]-[Type]-[Role]-[FileNum]-[Status]-[Rev]-[DelRef]-[Stage]-[LOD]-[Title].ext
		 * @param {object} item
		 * @param {object} stage
		 * @param {object} pstage
		 */
		$scope.updateMask = function(item, stage, pstage) {
			if(!stage.role)
				return;
			
			var pref = $scope.data.pref;
			stage.file_mask = pref + '-' + stage.role + '-?-?-?-?-?-?-?-' + item.dref + '-' + pstage.stageRef + '-' + (stage.lod || '?') + '-' + (item.dtitle || '?') + '.ext';
			return stage.file_mask;
		};
		
		/**
		 * generate the mask based on mask key
		 * mask key : [ProjRef]-[Author]-[Volume]-[Location]-[Type]-[Role]-[FileNum]-[Status]-[Rev]-[DelRef]-[Stage]-[LOD]-[Title].ext
		 * @param {object} item
		 * @param {object} stage
		 * @param {object} pstage
		 */
		$scope.updateSubMask = function(item, stage, pstage) {
			if(!stage.role)
				return;
			
			var pref = $scope.data.pref;
			stage.file_mask = pref + '-' + (stage.role || '?') + '-' + 
							  (item.volume || '?') + '-' +
							  (item.location || '?') + '-' + 
							  (item.file_type || '?') + '-' + 
							  (item.role || '?') + '-' +
							  (item.number || '?') + '-[Status]-[Rev]-' + item.dref + '-' + pstage.stageRef + '-' + (stage.lod || '?') + '-' + (item.dtitle || '?');
			stage.stageRef = pstage.stageRef;
			return stage.file_mask;
		};
		
		var addZeroPad = function(number) {
			number = number + "";
			if(number.length < 4) {
				number = "0" + number;
			}
			
			return number;
		};
		
		$scope.canCreateComment = function(item) {
			if($scope.user.roles.indexOf('EPM') > -1) {
				return true;
			}
			
			if($scope.user.roles.indexOf('SIM') > -1 && $scope.data.programme && $scope.data.programme.pstage) {
				for(var k = 0; k < $scope.data.programme.pstage.length; k++) {
					var stage = $scope.data.programme.pstage[k];
					if($scope.user.org && stage.projInfoMan == $scope.user.org) {
						return true;
					}
				}
			}
			
			for (var i = 0; i < item.stage.length; i++) {
				if($scope.user.org && item.stage[i].role == $scope.user.org) {
					return true;
				}
			}
			
			return false;
		};
		
		$scope.canCreateItem = function(item) {
			for (var i = 0; i < item.stage.length; i++) {
				if($scope.user.org && item.stage[i].role == $scope.user.org) {
					return true;
				}
			}
			
			return false;
		};
		
		$scope.hasVisibleComments = function(comments) {
			if($scope.user.roles.indexOf('EPM') > -1) {
				return true;
			}
			
			for (var i = 0; i < comments.length; i++) {
				if($scope.user.org && comments[i].originator.orgCode == $scope.user.org) {
					return true;
				}
			}
			
			return false;
		};
		
		$scope.canChangeRole = function(stg, item) {
			if((!item.sub_items || !item.sub_items.length) && (!item.comments || !item.comments.length)) {
				return true;
			}
			
			if($scope.backup.stg && !$scope.backup.stg.role) {
				return true;
			}
			
			if(item.sub_items && item.sub_items.length) {
				for (var i = 0; i < item.sub_items.length; i++) {
					var subItm = item.sub_items[i];
					if(subItm.originator.orgCode == stg.role) {
						return false;
					}
				}
			}
			
			/*if(item.comments && item.comments.length) {
				for (var i = 0; i < item.comments.length; i++) {
					var com = item.comments[i];
					if(com.originator.orgCode == stg.role) {
						return false;
					}
				}
			}*/
			
			return true;
		};
		
		$scope.isModalReadOnly = function(name) {
			var readOnly = '';
			if(!$scope.user.org) {
				return 'readOnly';
			}
			switch(name) {
				case 'projectdetails':
				case 'itemdeliverables':
				case 'stagedeliverables':
				case 'stagemanagement':
					if($scope.user.roles.indexOf('EPM') == -1) {
						readOnly = 'readOnly';
					}
					break;
				case 'subitemdeliverables':
				case 'deliverablecomment':
				case 'stagecomment':
					if($scope.subitem && $scope.user.usp.userID != $scope.subitem.originator.userID) {
						readOnly = 'readOnly';
					}
					break;
				case 'subitemstage':
					if($scope.subitem && $scope.stg && ($scope.user.org != $scope.subitem.originator.orgCode || $scope.user.org != $scope.stg.role)) {
						readOnly = 'readOnly';
					}
					break;
				case 'stage':
					break;
			}
			
			return readOnly;
		};
		
		var getMaxRef = function(deliverables, item, idx) {
			var len = deliverables.length, deliverable, dref, prefix, number; 
			var targetDref = item.dref;
			var targetPrefix = targetDref.substr(0, 1);
			var maxDref = parseInt(targetDref.substr(1));
			var floorNumber = Math.floor(maxDref / 100);
			var index = idx;
			
			for(var i = idx; i < deliverables.length; i++) {
				deliverable = deliverables[i];
				dref = deliverable['dref'];
				prefix = dref.substr(0, 1);
				number = parseInt(dref.substr(1));
				if(maxDref == floorNumber + '99') {
					floorNumber = floorNumber + 1;
				}
				
				if(Math.floor(number/100) > floorNumber) {
					break;
				}
				
				index = i;
				maxDref = Math.max(maxDref, number);
			}
			
			maxDref = addZeroPad(maxDref + 1);
			return {dref : targetPrefix + maxDref, index : index + 1};
		};
		
		/**
		 * insert new row below the targe row
		 * @param {number} ixd
		 * @param {object} item
		 * @param {object} deliverable
		 */ 
		$scope.addRow = function(item, deliverables) {
			deliverables = deliverables || [];
			if(!deliverables.length) {
				var sections = $scope.data.section;
				for(var i = 0; i < sections.length; i++) {
					deliverables = sections[i].deliverable || [];
					if(deliverables.indexOf(item) > -1) {
						break;
					}
				}
			}
			
			var ixd = deliverables.indexOf(item);
			ixd = Math.max(0, ixd);
			
			// add blank deliverable item object
			var ref = getMaxRef(deliverables, item, ixd);
			var newRef = ref.dref;
			if(parseInt(newRef.substr(1)) > 99999) {
				return;
			}
			
			var ragName = getStaticValue('IDP_RAG', "AOK") || '';
			
			var newDeliverable = {
				dref : ref.dref,
				spref : item.dref,
				dtitle : "???",
				native_format : null,
				assurance : null,
				capability : null,
				capabilityName : null,
				open_format : null,
				openFormatName : null,
				file_type : null,
				fileTypeName : null,
				ProductionDate : "LOD",
				OriginalAuthor : "LOD",
				CopyrightHolder : "LOD",
				SharedInBusiness : "LOD",
				DataProtectionLevel : "LOD",
				Licence : "LOD",
				OutputData : "LOD",
				createdBy : printedBy,
				createdOn : printedOn,
				originator : $scope.user.usp,
				stage : [ { "stgno": "0", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" }, 
				          { "stgno": "1", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "2", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "3", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "4", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "5", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "6", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" },
				          { "stgno": "7", "pdref": ref.dref, "role": null, "roleName": null, "lod": null, "lodName": null, "file_mask": null, "rag": "AOK", "ragName": ragName, "dnote" : "", "createdBy": "", "createdOn": "" } ]
			};
			
			getServerTime(function(date) {
				newDeliverable.createdOn = date;
			});
			
			if(!ref.index) {
				deliverables.push(newDeliverable);					// append object in array
			} else {
				deliverables.splice(ref.index, 0, newDeliverable);	// insert object in array
			}
			
			$scope.hideModal();
			
			// TODO: if want to edit directly the new comment then uncomment below line
//			$scope.showModal('itemdeliverables', newDeliverable, currentIndex, deliverables);
		};
		
		/**
		 * add new item under deliverable row in item table
		 * @param {object} item
		 */ 
		$scope.addItem = function(item, subItem) {
			if (!item.sub_items)
				item.sub_items = [];
			
			var lastSubItem = item.sub_items[item.sub_items.length - 1];
			var index = "1", newItem;
			if(lastSubItem)
				index = parseInt(lastSubItem.id) + 1;
	
			var newStages = [ 
			    {"stgno": "0", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "1", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "2", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "3", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "4", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "5", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "6", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" },
		        {"stgno": "7", "role": null, "roleName": null, "lodName": null, "lod": null, "file_link": null, "createdBy": "", "createdOn": "" } 
		    ];
			
			if(subItem) {
				newItem = angular.copy(subItem);
				newItem.stage = newStages;
			} else {
				newItem = {
					dref : item.dref,
					dtitle : null,
					volume : null,
					volumeName : null,
					location : null,
					locationName : null,
					role : null,
					roleName : null,
					file_type: null,
					fileTypeName: null,
					ProductionDate : "LOD",
					OriginalAuthor : "LOD",
					CopyrightHolder : "LOD",
					SharedInBusiness : "LOD",
					DataProtectionLevel : "LOD",
					Licence : "LOD",
					OutputData : "LOD",
					createdOn : printedOn,
					stage: newStages
				};
			}
			
			newItem.id = index;
			newItem.number = item.dref + '_' + index;
			newItem.createdBy = printedBy;
			newItem.originator = $scope.user.usp;
			
			getServerTime(function(date) {
				newItem.createdOn = date;
			});
			
			item.sub_items.push(newItem);
			$scope.showModal('subitemdeliverables', item, newItem, (item.sub_items.length - 1));
		};
		
		/**
		 * add new comment under deliverable row in item table
		 * @param {object} item
		 */ 
		$scope.addComment = function(item) {
			if (!item.comments)
				item.comments = [];
			
			var lastComment = item.comments[item.comments.length - 1];
			var index = "1";
			if(lastComment)
				index = parseInt(lastComment.id) + 1;
	
			var newComment = {
				id: index,
				supplier: null,
				supplierName: null,
				comment: null,
				author: printedBy,
				createdBy : printedBy,
				createdOn : printedOn,
				originator: $scope.user.usp,
				stage: [ { "stgno": "0", "comment": null },
				         { "stgno": "1", "comment": null },
						 { "stgno": "2", "comment": null },
						 { "stgno": "3", "comment": null },
					   	 { "stgno": "4", "comment": null },
					   	 { "stgno": "5", "comment": null },
					   	 { "stgno": "6", "comment": null },
					   	 { "stgno": "7", "comment": null } ]
			};
			
			getServerTime(function(date) {
				newComment.createdOn = date;
			});
			
			item.comments.push(newComment);
			$scope.showModal('deliverablecomment', item, newComment, (item.comments.length - 1));
		};
		
		/**
		 * remove deliverable row
		 * @param {number} index
		 * @param {object} deliverables
		 */ 
		$scope.removeRow = function(index, deliverables) {
			// remove object from array 
			deliverables.splice(index, 1);
			
			// update bottom count
			$scope.hideModal();
		};
		
		/**
		 * remove deliverable items of deliverable
		 * @param {number} index
		 * @param {object} deliverable
		 */ 
		$scope.removeItem = function(index, deliverable) {
			if(!deliverable.sub_items.length)
				return;
			
			// remove object from array 
			deliverable.sub_items.splice(index, 1);
			$scope.hideModal();
		};
		
		/**
		 * remove deliverable row
		 * @param {number} index
		 * @param {object} deliverable
		 */ 
		$scope.removeComment = function(index, deliverable) {
			if(!deliverable.comments.length)
				return;
			
			// remove object from array 
			deliverable.comments.splice(index, 1);
			$scope.hideModal();
		};
		
		/**
		 * Update the data on server 
		 * @private
		 */
		var saveFormData = function() {
			if(angular.element('#editORI').val() != "true") {
				$window.submitForm && $window.submitForm(1);			// create the form on first time modal update click for create form page only
				return;
			}
			
			var jsonData = $window.getJSONData && $window.getJSONData();
			if (!jsonData) {
				$window.alert('No form data found');
				return;
			}

			var inpt = document.getElementById('html_json_data');
			if (!inpt) {
				inpt = document.createElement('input');
				inpt.id = "html_json_data";
				inpt.name = "jsonData";
				inpt.type = "hidden";
				document.myform.appendChild(inpt);
			}

			inpt.value = jsonData;
			
			var $form = angular.element('#myform');
			commonApi.ajax({
				url: $form.attr("action"),
				method: 'post',
				withCredentials: true,
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : $form.serialize() + '&isAjaxCall=true'
			}).then(function(response) {
				var data = response.data || {};
//				angular.element('#lastModifiedTime').val(data.lastModifiedTime);
			}, function() {
				//				$window.alert('error');
			});
//			checkForConcurrency($form, function() { });
		};
		
		/**
		 * update subitem stage rag on parent stage rag change
		 */
		var updateSubRag = function() {
			if(!$scope.backup.item || !$scope.backup.item.sub_items || !$scope.backup.item.sub_items.length) {
				return;
			}
			
			for(var i = 0; i < $scope.backup.item.sub_items.length; i++) {
				var subItem = $scope.backup.item.sub_items[i];
				var subStage = subItem.stage[$scope.backup.stg.stgno];
				subStage.rag = $scope.backup.stg.rag;
				$scope.onRagChange(subStage);
			}
		};
		
		var isModified = function(oldObj, newObj) {
			if(!angular.isObject(oldObj) || !angular.isObject(newObj)) {
				return false;
			}
			
			for (var key in newObj) {
				if(newObj[key] !== oldObj[key]) {
					return true;
				}
			}
			
			return false;
		};
		
		var setStageHistory = function() {
			switch (ctrl.model.modelId) {
			case 'stagemanagement':
			case 'stagedeliverables':
				if(isModified($scope.backup.stg, $scope.stg)) {
					$scope.stg.lastModifier = $scope.user.usp;
					
					if(!$scope.stg.createdBy && $scope.stg.role) {
						$scope.stg.createdBy = printedBy;
					}
					
					getServerTime(function(date) {
						$scope.backup.stg.modifiedOn = date;
						
						if(!$scope.backup.stg.createdOn && $scope.backup.stg.role) {
							$scope.backup.stg.createdOn = date;
						}
					});
				}
				break;
			case 'subitemstage':
			case 'stagecomment':
				if(isModified($scope.backup.substg, $scope.substg)) {
					$scope.substg.lastModifier = $scope.user.usp;
					
					var isCreated = ((ctrl.model.modelId == "subitemstage" && $scope.substg.role) || (ctrl.model.modelId == "stagecomment" && $scope.substg.comment));
					
					if(!$scope.substg.createdBy && isCreated) {
						$scope.substg.createdBy = printedBy;
					}
					
					getServerTime(function(date) {
						$scope.backup.substg.modifiedOn = date;
						
						if(!$scope.backup.substg.createdOn && isCreated) {
							$scope.backup.substg.createdOn = date;
						}
					});
				}
			default:
				break;
			}
		};
		
		// hold the data edited by user in modal 
		$scope.backup = {
			item: {},
			stg: {}
		};
		
		/**
		 * apply changes on update click
		 */ 
		$scope.updateRecord = function() {
			if(ctrl.model.modelId == "projectdetails" && !$scope.item.ptemplate) {
				return;
			}
				    
			if(angular.isObject($scope.backup.item) && angular.isObject($scope.item))
				angular.merge($scope.backup.item, $scope.item);
	
			if(angular.isObject($scope.backup.subitem) && angular.isObject($scope.subitem))
				angular.merge($scope.backup.subitem, $scope.subitem);
			
			setStageHistory();
			
			if(angular.isObject($scope.backup.stg) && angular.isObject($scope.stg)) {
				angular.merge($scope.backup.stg, $scope.stg);
			}
	
			if(angular.isObject($scope.backup.substg) && angular.isObject($scope.substg)) {
				angular.merge($scope.backup.substg, $scope.substg);
			}
			
			if(ctrl.model.modelId == "stage" && $scope.pstg) {
				var onEditingItems = commonApi._.filter($scope.pstg.questions, function(item) {
					return item.editing == true
				});
				if (onEditingItems.length) {
					for (var i = 0; i < onEditingItems.length; i++) {
						angular.merge(onEditingItems[i], onEditingItems[i].oldData);
					}
				}
				$scope.backup.pstg.questions = $scope.pstg.questions;
				angular.merge($scope.backup.pstg, $scope.pstg);
			}
			
			if(ctrl.model.modelId == "stagedeliverables") {
				updateSubRag();
			}
			
			if($scope.item && $scope.backup.stg && $scope.pstg)
				$scope.updateMask($scope.item, $scope.backup.stg, $scope.pstg);
			
			if($scope.subitem && $scope.backup.substg && $scope.pstg)
				$scope.updateSubMask($scope.subitem, $scope.backup.substg, $scope.pstg);
			
			if(ctrl.model.modelId == "itemdeliverables" && $scope.backup.item) {
				for(var i = 0; i < $scope.backup.item.stage.length; i++) {
					var stge = $scope.backup.item.stage[i];
					var pstge = $scope.data.programme.pstage[i];
					$scope.updateMask($scope.backup.item, stge, pstge);
				}
			} else if(ctrl.model.modelId == "subitemdeliverables" && $scope.backup.subitem) {
				for(var i = 0; i < $scope.backup.subitem.stage.length; i++) {
					var stge = $scope.backup.subitem.stage[i];
					var pstge = $scope.data.programme.pstage[i];
					$scope.updateSubMask($scope.backup.subitem, stge, pstge);
				}
			}
						
			// fetch the template data on template selection
			if(ctrl.model.modelId == "projectdetails" && !$scope.ptemplate) {
				$scope.ptemplate = $scope.item.ptemplate;
				loadTemplate($scope.ptemplate);
			} else {
				// update data on server
				saveFormData();
			}
		      
			$scope.hideModal();
		};
		
		/**
		 * open the specific modal dialog
		 * @param {number} id
		 * @param {object} item
		 * @param {object} subitem
		 * @param {object} stage
		 * @param {object} substg
		 * @param {object} pstage
		 */
		var prevModalId = undefined; 
		$scope.showModal = function(id, item, subitem, stage, substg, pstage, prevModal) {
			if($scope.isPrintView) {
				return;
			}
			
			$scope.hideModal();
			prevModalId = prevModal;
			
			if(!$scope.user.org || ($scope.user.roles.indexOf('EPM') == -1 && $scope.user.roles.indexOf('SIM') == -1 && 
					$scope.user.roles.indexOf('SUP') == -1 && $scope.user.roles.indexOf('OTH') > -1 && 
					id != "projectdetails" && id != "stagemanagement") || 	// if other supplier tries to open open other than project detail and stage management
					(id == "subitemstage" && $scope.user.roles.indexOf('EPM') == -1 && 
					($scope.user.org != subitem.originator.orgCode || $scope.user.org != stage.role))) {										// if supplier tries to open stage popup
				return;
			}
			
			// apply data on modal
			$scope.item = angular.copy(item);
			
			if (id == "stage") {
				commonApi._.each(pstage.questions, function(p) {
					p.editing = false;
				});
			}
			
			if(id != 'itemdeliverables') {
				$scope.subitem = angular.copy(subitem);
				$scope.stg = angular.copy(stage);
				$scope.substg = angular.copy(substg);
				$scope.pstg = angular.copy(pstage);
			}
			
			if(id == 'itemdeliverables') {
				$scope.idx = subitem;
				$scope.deliverableArray = stage;
			} else if(id == 'subitemdeliverables' || id == 'deliverablecomment') {
				$scope.idx = stage;
			}
			
			if(!$scope.readOnly && id == 'deliverablecomment' && !$scope.subitem.supplier) {
				$scope.subitem.supplier = $scope.user.org;
				$scope.onSupplierChange($scope.subitem);
			}
			
			// inherit the parent role and lod
			if(!$scope.readOnly && id == 'subitemstage') {
				if(!$scope.substg.role) {
					$scope.substg.role = $scope.stg.role;
					$scope.onAuthorChange($scope.substg);
				}
				
				if(!$scope.substg.lod) {
					$scope.substg.lod = $scope.stg.lod;
					$scope.onSubStgLODChange($scope.substg);
				}
			}
			
			if(!$scope.readOnly && id == 'stagedeliverables' && !$scope.stg.role && $scope.user.roles.indexOf('EPM') > -1) {
				$scope.stg.role = $scope.pstg.projInfoMan;
				$scope.onSupplierRoleChange($scope.stg);
			}
			
			// backup the original data
			$scope.backup.item = item;
			$scope.backup.subitem = subitem;
			$scope.backup.stg = stage;
			$scope.backup.substg = substg;
			$scope.backup.pstg = pstage;
			
			// make mockup object for project detail for popup
			if(id == "projectdetails") {
//				fetchTemplateList();
				$scope.item = {
					pref: $scope.data.pref,
				    ptitle: $scope.data.ptitle,
				    pfacility: $scope.data.pfacility,
				    ptemplate: $scope.data.ptemplate,
				    pmanager: $scope.data.pmanager,
				    region: $scope.data.region + "",
				    regionName: $scope.data.regionName + "",
				    status: $scope.data.status + "",
				    statusName: $scope.data.statusName + "",
				    ORI_FORMTITLE: $scope.data.ORI_FORMTITLE || "Information Delivery Plan"
				};
				
				$scope.backup.item = $scope.data;
			}
			
			// show modal
			ctrl.model.modelId = id;
			
			var $body = $document.find('body');
			$body.addClass('mOpen');
			if($window.innerHeight < body.scrollHeight) {
				$body.addClass('hasScroll');
			}
		};
		
		/**
		 * close the modal dialog
		 */
		$scope.hideModal = function() {
			if(prevModalId) {
				prevModalId = undefined;
				
				// special case : show stage modal after sub item stage modal hides
				$scope.showModal('stage', null, null, null, null, $scope.backup.pstg);
			} else {
				ctrl.model.modelId = "";
			}
			var $body = $document.find('body');
			$body.removeClass('mOpen');
			$body.removeClass('hasScroll');
		};
		
		$scope.templateList = [];
		function fetchTemplateList() {
			if($scope.data.ptemplate) {
				return;
			}
			
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/formTitles",
				method: 'post',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : "appBuilderCode=EA_IDP_TEMPLATE&projectId=" + projectId
			}).then(function(response) {
				var list = response.data || {};
				list = list.dataList || list || [];
				if(list == "No records" || !list.length) {
					$window.alert('No IDP Template is available. Please create one.');
					list = [];
				}
				$scope.templateList = list;
			}, function() {
				$window.alert('No IDP Template is available. Please create one.');
			});
		}
		
		function fetchUserList(role, callback) {
			var role = getRoleMap()[role];
			if(!role)
				return;
			
			// prepare roles for ajax call
			var epmRoles = role.split(',');
			var rolArgs = "";
			for(var i = 0; i < epmRoles.length; i++) {
				rolArgs += '&roleNames=' + epmRoles[i];
			}
			
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/usersByRoleName",
				method: 'post',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : "projectId=" + projectId + rolArgs
			}).then(function(response) {
				var list = response.data || {};
				list = list.dataList || list || [];
				callback && callback(list);
			}, function() {
//				$window.alert('error');
			});
		}
		
		// fetch user with Project manager based roles
		$scope.userList = undefined;
		function loadEpmList() {
			fetchUserList('EPM', function(list) {
				$scope.userList = list || [];
				var users = [];
				
				for (var i = 0; i < $scope.userList.length; i++) {
					var u = $scope.userList[i];
					users.push(u.username);
				}
				
				$scope.data.pmanager = users.join(', ');
			});
		} 
		
		// fetch user with Template manager based roles
		$scope.epmEmails = "";
		function loadTMList() {
			fetchUserList('TM', function(list) {
				var emails = "";
				for(var i = 0; i < list.length; i++) {
					var user = list[i];
					emails += user.email;
					if(i != (list.length - 1)) {
						emails += ";"
					}
				}
				$scope.epmEmails = emails;
			});
		} 
		
		$scope.saveRow = function(item) {
			delete item.editing;
			delete item.oldData;
		};
		
		$scope.editRow = function(item) {
			item.oldData = angular.copy(item);
			item.editing = true;
		};
		
		$scope.cancelEditRow = function(item) {
			item.note = item.oldData.note || "";
			delete item.editing;
			delete item.oldData;
		};
		
		$scope.printPLQs = function(id) {
			var prtContent = document.getElementById(id);
			var WinPrint = $window.frames['print_frame'].contentWindow || $window.frames['print_frame'];
			
			var title = 'IDP_'+ $scope.project +'_PLQ'
			var tempTitle = document.title;
			document.title = title;
			WinPrint.document.title = title;
			angular.element(WinPrint.document.body).html('<style>body {margin: 0;font-family: Arial, sans-serif;font-size: 16px;line-height: 20px;color: #333;background-color: #fff;}p{margin:0}.m-close,.m-footer,.modal-action-container,.m-header,input,.que-action-wrap,.ng-hide,.del-inpt-wrap{display:none !important}.plq-table td > span,.print-header,.plq-stage-links a{display:block !important}.plq-table tr{background-color: #eee;}.plq-table td{border: 1px solid #FFF;padding: 5px 7px;font-size: 13px;}.plq-note{display: block;word-break: break-word;word-wrap: break-word;max-width: 280px;}</style>' + prtContent.innerHTML);
			WinPrint.focus();
			WinPrint.print();
			document.title = tempTitle;
		};
		
		$scope.allPstg = [];
		$scope.printAllPLQs = function() {
			if($scope.data.programme && $scope.data.programme.pstage) {
				for(var k = 0; k < $scope.data.programme.pstage.length; k++) {
					var stage = $scope.data.programme.pstage[k];
//					if(stage.stageStat == 'CR') {
						$scope.allPstg.push(stage);
//					}
				}
			}
			
			$timeout(function() {
				$scope.printPLQs('all-current-plqs');
				$scope.allPstg.length = 0;
			});
		}
		
		$scope.printForm = function() {
			try {
				document.getElementById('viewformheaderimages').childNodes[0].click();
			} catch(e) {
				$window.print();
			}
		}
		
		$scope.generateCOBie = function() {
			var obj = {
				cobieReportJson: angular.toJson({ myFields: $scope.data }),
				appBuilderCode: "",
				projectId: projectId
			};
			
			var prevForm = document.getElementById('IDP_COBie_FORM');
			prevForm && prevForm.remove && prevForm.remove();
			
			var form = document.createElement('form');
			form.id = "IDP_COBie_FORM";
			form.method = "POST";
			form.target = "COBIE_DOWNLOAD";
			form.action = ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/cobieReportData";
			
			for(var key in obj) {
				var inpt = document.createElement('input');
				inpt.type = "hidden";
				inpt.name = key;
				inpt.value = obj[key];
				form.appendChild(inpt);
			}
			
			document.body.appendChild(form);
			form.submit();
		};
		
		var getValidateJSON = function(index) {
			var sections = $scope.data.section;
			if(!sections || !sections.length)
				return;
			
			var obj = { section : [] };
			
			for(var i = 0; i < sections.length; i++) {
				var section = sections[i];
				var deliverables = section.deliverable;
				if(!deliverables || !deliverables.length)
					continue;
				
				var sectionObj = { seref: section.seref, deliverable: [] };
				for(var j = 0; j < deliverables.length; j++) {
					var deliverable = deliverables[j];
					var subItems = deliverable.sub_items;
					if(!subItems || !subItems.length)
						continue;
					
					var delObj = { 
						dref: deliverable.dref, 
						stage: [deliverable.stage[index]], 
						sub_items: [] 
					};
					
					for(var k = 0; k < subItems.length; k++) {
						var subItem = subItems[k];
						delObj.sub_items.push({dref: subItem.dref, role: subItem.role, number: subItem.number, stage:[subItem.stage[index]]});
					}
					
					delObj.sub_items.length && sectionObj.deliverable.push(delObj);
				}
				
				sectionObj.deliverable.length && obj.section.push(sectionObj);
			}
			
			if(!obj.section.length)
				return;
			
			return obj;
		};
		
		var setValidateJSON = function(data) {
			var sections = data.section;
			var originalSections = $scope.data.section;
			
			for(var i = 0; i < sections.length; i++) {
				var section = sections[i];
				var targetSection = commonApi._.findWhere(originalSections, {seref: section.seref});
				
				var deliverables = section.deliverable;
				for(var j = 0; j < deliverables.length; j++) {
					var deliverable = deliverables[j];
					var targetDeliverable = commonApi._.findWhere(targetSection.deliverable, {dref: deliverable.dref});
					var delStage = deliverable.stage[0];
					
					// update rag of deliverable stage
					targetDeliverable.stage[delStage.stgno].rag = delStage.rag;
					
					var subItems = deliverable.sub_items;
					for(var k = 0; k < subItems.length; k++) {
						var subItem = subItems[k];
						var targetSubItem = commonApi._.findWhere(targetDeliverable.sub_items, {number: subItem.number});
						var subStage = subItem.stage[0];
						
						// update rag of sub item stage
						targetSubItem.stage[subStage.stgno].rag = subStage.rag;
						targetSubItem.stage[subStage.stgno].file_link = subStage.file_link;
					}
				}
			}
		};
		
		$scope.refreshCOBie = function(pstage) {
			if(pstage.stageStat != "CR")
				return;
			
			var validateJsonData = getValidateJSON(pstage.id);
			if(!validateJsonData)
				return;
			
			commonApi.ajax({
				url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/validateCobieReportData",
				method: 'post',
				withCredentials: true,
				headers : {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				data : "typeNames=IDP_RAG&projectId=" + projectId + "&stageId=" + pstage.stageRef + "&validateJsonData=" + encodeURIComponent(angular.toJson(validateJsonData)) + "&stageDueDate=" + pstage.stageEnd + "&projectRef=" + $scope.data.pref 
			}).then(function(response) {
				var data = response.data || {};
				setValidateJSON(data);
			}, function() {
//				$window.alert('error');
			});
		};

		ctrl.model = {
			modelId : "",
			update : $scope.updateRecord,
			hideModal : $scope.hideModal,
			readOnly : $scope.readOnly
		};
		
		// fetch template data if template is available initially
		loadTemplate();
		
		// fetch EPM user list
		!$scope.readOnly && loadEpmList();
		
		// load with Template Manager role
		!$scope.readOnly && loadTMList();
		
		// update the Manager (Editors) fields
		$scope.editors = $scope.data.editors || "";
		var editorList = $scope.editors ? $scope.editors.split(', ') : [];
		$scope.editorChange = function() {
			var select = document.getElementById('newman');
			var editor = select ? select.value : '';
			editor && editorList.push(editor);
			editorList = commonApi._.uniq(editorList);
			$scope.editors = $scope.data.editors = editorList.join(', ');
		};
		
		// show form in maximize pane only for IDP form
		angular.element('#viewFormMainSection').find('.restored').click();
		$scope.update();
	}

	return FormController;
});
