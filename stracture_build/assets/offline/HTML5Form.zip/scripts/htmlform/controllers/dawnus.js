﻿/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId')
            .value || '';

        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });

        $scope.requests = {};

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.actionsDropDown = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');

        //declare structure for repeating
        $scope.structConwy = {
            Dawnus_Array: "", Dawnus_Check: false, Dawnus_Status: ""
        };
        $scope.logo = "https://adoddleak.asite.com/adoddlepublic/dpd/587apaUkqbpBktq5nxM";
        $scope.isReadOnlyAfterCreation = "";
        if (currentViewName == "ORI_VIEW") {
            $timeout(function () {
                $scope.expandTextAreaOnLoad();

            }, 1000);

            //flag to allow user to edit 
            $scope.flagIsAllowEdit = true;
            //flag to allow user to edit old or new sections
            $scope.flagIsNew = true;
            $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
            if ($scope.oriMsgCustomFields['Assign_To'] != "")
                $scope.assigneePerson = $scope.oriMsgCustomFields['Assign_To'].split('#')[1].trim();

            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = "";

            var strFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
            var strIsDraft = $scope.asiteSystemDataReadWrite['DS_ISDRAFT'];
            if (strIsDraft == "NO" && strFormId == "") {
                //initialize all variables on form load
                $scope.oriMsgCustomFields.Dawnus = [];
                $scope.arrDawnusMainResult = [];
                $scope.strFilterConwy = "";
                $scope.loaderFlag = false;
            }
            else {
                //if form status is raised than check is user have assign status or not
                var strFormStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
                if (strFormStatus.indexOf("Raised") > -1) {
                    $scope.flagIsNew = false;
                    $scope.flagIsAssignee = true;
                    //if raised than check user have assignsttus or not
                    var strWorkinguser = $scope.WorkingUserID[0].Value;
                    var isrequired = CheckPendingAction(strWorkinguser.split('|')[0].trim());
                    if (isrequired == false) {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEdit = false;
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not authorised to Edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    }
                    else {

                        $scope.flagIsAllowEdit = true;
                    }
                }
                else {
                    //fill repeating on load with resped to conwy
                    functFillRepeating($scope.oriMsgCustomFields['Conwy']);
                }
            }
        }
        if (currentViewName == "ORI_PRINT_VIEW") {
            $timeout(function () {
                $scope.expandTextAreaOnLoad();

            }, 1000);
            var strFormStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            //set user name
            if ($scope.oriMsgCustomFields['Assign_To'] != "")
                $scope.assigneePerson = $scope.oriMsgCustomFields['Assign_To'].split('#')[1].trim();
            //if status is blank or open than hide mainview else editable view
            if (strFormStatus == "" || strFormStatus.indexOf("Open") > -1) {
                $scope.flagIsNewPrint = true;
            }
            else {
                $scope.flagIsNewPrint = false;
            }
        }
        $scope.expandTextAreaOnLoad = function () {
            var textAreaObj = document.querySelectorAll('.momcontainer textarea');
            if (textAreaObj) {
                for (var i = 0; i < textAreaObj.length; i++) {
                    textAreaObj[i].style.height = 'auto';
                    textAreaObj[i].style.height = textAreaObj[i].scrollHeight + 'px';
                }
            }
        }
        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.DS_INCOMPLETE_ACTIONS = _.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == "Assign Status";
            });
            if ($scope.DS_INCOMPLETE_ACTIONS != null) {
                var strStatus = $scope.DS_INCOMPLETE_ACTIONS[0].Value;
                if (strStatus != null) {
                    var split = strStatus.split('#')[0].split('|');
                    for (var i = 0; i < split.length; i++) {
                        if (split[i] != "" && split[i] == strUser.trim()) {
                            return true;
                        }
                    }
                }
            }
            return IsAction;
        };
        //Fill Repeater
        function functFillRepeating(Conwy) {
            //if budget dropdown is not null than get data on callback and bind buget
            if (Conwy != null && Conwy != "") {
                $scope.loaderFlag = true;
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_Dawnus_Combine_Data",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_Dawnus_Combine_Data",
                            "fieldValue": Conwy
                        }]
                    }
                };
                var unique = [], uniqueRef = [];
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        //call stored procedure on call back
                        $scope.dataDawnusCombine = angular.fromJson(response.data['DS_Dawnus_Combine_Data']).Items.Item;
                        $scope.arrDawnusMainResult = [];
                        $scope.arrDawnusRefResult = [];
                        if ($scope.dataDawnusCombine != null) {
                            angular.forEach($scope.dataDawnusCombine, function (item, index) {
                                if (!unique[item.Value1]) {
                                    var arrConwyResult = angular.copy($scope.structConwy);
                                    arrConwyResult.Dawnus_Array = item.Value1;
                                    arrConwyResult.Dawnus_Check = false;
                                    $scope.arrDawnusMainResult.push(arrConwyResult);
                                    unique[item.Value1] = item.Value1;
                                }
                                if (!uniqueRef[item.Value2]) {
                                    var arrConwyResult = angular.copy($scope.structConwy);
                                    arrConwyResult.Value2 = item.Value2;
                                    $scope.arrDawnusRefResult.push(arrConwyResult);
                                    uniqueRef[item.Value2] = item.Value2;
                                }
                            });

                            var istemplate = $scope.oriMsgCustomFields['Is_Template'];
                            if (istemplate) {
                                checkDuplicateValue($scope.oriMsgCustomFields['Specification_Reference_Number']);
                                if ($scope.oriMsgCustomFields['Specification_Reference_Number'] != "") {
                                    var strAssignTo = $scope.oriMsgCustomFields.Assign_To;
                                    if (strAssignTo && istemplate) {
                                        $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = "True";
                                        $scope.submitFlag = true;
                                        $window.submitForm(1);
                                    }

                                }
                            }


                        }

                    }
                    $scope.loaderFlag = false;
                });
            }
        };
        $scope.cownyOnChange = function (Conwy) {
            $scope.oriMsgCustomFields.Dawnus = [];
            functFillRepeating(Conwy)
            $scope.oriMsgCustomFields['Specification_Reference_New'] = "";
        };
        $scope.restrictChar = function (event, inputValue) {
            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert("Restricted Characters specified!!! Restricted Characters | < > #");
                        event.preventDefault();
                    }
                    break;
                case 32:
                    if (inputValue == "") {
                        event.preventDefault();
                    }
                    break;
            }
        };

        $scope.restrictCharPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (inputValue.match(/[|<>#]/gi)) {
                alert("Restricted Characters specified!!! Restricted Characters | < > #");
                event.preventDefault();
                return false;
            }
        };
        //expand textbox area on enter
        $scope.delayedResize = function (event) {
            $timeout(function () {
                $scope.expandTextArea(event);
            }, 1000);
        }
        $scope.expandTextArea = function (event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = event.currentTarget.scrollHeight + 'px';
        }
        $scope.arrConwyNewResult = [];

        $scope.addNewConwy = function () {
            //Add Freetext to array
            $scope.Freetext = $scope.oriMsgCustomFields.Specification_Reference_Description;
            if ($scope.Freetext) {
                var arrConwyResult = angular.copy($scope.structConwy);
                arrConwyResult.Dawnus_Array = $scope.Freetext;
                arrConwyResult.Dawnus_Check = true;
                $scope.arrDawnusMainResult.push(arrConwyResult);
            }
            //check any checkbox is checked or not
            $scope.checkBoxes = _.filter($scope.arrDawnusMainResult, function (val) {
                return val.Dawnus_Check == true;
            });

            if ($scope.checkBoxes != null && $scope.checkBoxes.length > 0) {
                //add checked records to main repeating to show
                angular.forEach($scope.checkBoxes, function (item, index) {
                    var arrConwyResult = angular.copy($scope.structConwy);
                    var strIsExists = "";
                    //check if record is already exits than not to add into main repeating
                    if ($scope.oriMsgCustomFields.Dawnus != null && $scope.oriMsgCustomFields.Dawnus.length > 0) {
                        strIsExists = _.filter($scope.oriMsgCustomFields.Dawnus, function (val) {
                            return val.Dawnus_Array == item.Dawnus_Array;
                        });
                    }
                    if (strIsExists == "") {
                        arrConwyResult.Dawnus_Array = item.Dawnus_Array;
                        $scope.oriMsgCustomFields.Dawnus.push(arrConwyResult);
                    }
                });
            }
            $scope.strFilterConwy = "";
            angular.forEach($scope.arrDawnusMainResult, function (item, index) {
                //make all checkbox uncheck
                if (item.Dawnus_Check == true) {
                    item.Dawnus_Check = false;
                }
            });
            $scope.oriMsgCustomFields.Specification_Reference_Description = "";
        };
        $scope.FillRefData = function (StrVal) {
            $scope.oriMsgCustomFields.Dawnus = [];
            $scope.FilterData = commonApi._.filter($scope.dataDawnusCombine, function (Item) {
                return Item.Value2 == StrVal;
            });
            if ($scope.FilterData != null && $scope.FilterData.length > 0) {
                angular.forEach($scope.FilterData, function (item, index) {
                    var arrConwyResult = angular.copy($scope.structConwy);
                    var strIsExists = "";
                    if ($scope.oriMsgCustomFields.Dawnus != null && $scope.oriMsgCustomFields.Dawnus.length > 0) {
                        strIsExists = commonApi._.filter($scope.oriMsgCustomFields.Dawnus, function (val) {
                            return val.Dawnus_Array == item.Value1;
                        });
                    }
                    if (strIsExists == "") {
                        arrConwyResult.Dawnus_Array = item.Value1;
                        $scope.oriMsgCustomFields.Dawnus.push(arrConwyResult);
                    }
                });
            }
        };
        $scope.ValidateRefNo = function (StrVal) {
            checkDuplicateValue(StrVal);
        };
        function checkDuplicateValue(StrVal) {

            var workReport = $scope.oriMsgCustomFields['Conwy'];
            var ref_num = workReport + StrVal;
            $scope.oriMsgCustomFields['Specification_Reference_New'] = ref_num;
            if ($scope.arrDawnusRefResult != null && $scope.arrDawnusRefResult.length > 0) {
                for (var i = 0; i < $scope.arrDawnusRefResult.length; i++) {
                    if (StrVal && $scope.arrDawnusRefResult[i].Value2.toLowerCase() == ref_num.toLowerCase()) {
                        alert("Reference Number Already Used");
                        $scope.oriMsgCustomFields['Specification_Reference_New'] = "";
                        $scope.oriMsgCustomFields['Specification_Reference_Number'] = "";
                        return true;
                        break;
                    }
                }
                return false;
            }
        }


        //Declare structure of model repeating
        $scope.strcut_Type_of_Test_Equipment_Used_Main = {
            strcut_Type_of_Test_Equipment_Used: "",
            Model: ""
        };
        //declare structure of person carrying out maintenence task main
        $scope.strcut_Name_of_Person_Carrying_Out_Maintenance_Task_Main = {
            Name_of_Person_Carrying_Out_Maintenance_Task: "",
            Signature: ""
        };
        $scope.AddNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };
        $scope.DeleteItem = function (obj, repeatingData) {
            //delete data by index
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };
        $window.DWS_FinalCallBack = function () {
            return $scope.checkMandatoryFields();
        }
        $scope.checkMandatoryFields = function () {

            if ($scope.submitFlag) {
                return false;
            }
            if ($scope.oriMsgCustomFields.Specification_Reference == "") {
                alert("Please enter Specification Reference!");
                return true;
            }
            else {
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_FORMTITLE = $scope.oriMsgCustomFields.Specification_Reference;
            }
            var strAssignTo = $scope.oriMsgCustomFields.Assign_To;
            var istemplate = $scope.oriMsgCustomFields.Is_Template;
            //Check user status
            var strFormStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            if (strFormStatus.indexOf("Raised") > -1) {
                //if any status is not selected than dont allow to update
                var strLocationStatus = checkAnyPendingLocation();
                if (strLocationStatus == true) {
                    alert("select all checklists!");
                    return true;
                }
                UpdateFormStatus("Closed");


            }
            else if ((strFormStatus == "" || strFormStatus.indexOf("Open") > -1) && strAssignTo) {
                Set_Auto_Distribution(strAssignTo.split('#')[0].trim(), "2#");
                UpdateFormStatus("Raised");
                if (istemplate) {
                    functFillRepeating($scope.oriMsgCustomFields['Conwy']);
                    return true;
                }

            }
            else if (strFormStatus == "" && strAssignTo == "") {
                UpdateFormStatus("Open");
            }

            return false;
        };
        function checkAnyPendingLocation() {
            //check if any status is pending or not
            var count = 0;
            if ($scope.oriMsgCustomFields['Dawnus'] != null) {
                //add checked records to main repeating to show
                angular.forEach($scope.oriMsgCustomFields['Dawnus'], function (item, index) {
                    if (item.Dawnus_Status == "") {
                        count++;
                    }
                });
            }
            if (count > 0) {
                return true;
            }
            else {
                return false;
            }
        };
        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        };
        function Set_Auto_Distribution(strUser, strAction) {
            //copy structure of distribution nodes
            var d = new Date();
            d.setDate(d.getDate() + 7);
            var month = d.getMonth() + 1;
            var day = d.getDate();
            var strDueDate = d.getFullYear() + '-' +
                (month < 10 ? '0' : '') + month + '-' +
                (day < 10 ? '0' : '') + day;
            //get copy of distribution and set user ,date ,action to distribute
            var structDistricution = angular.copy($scope.DistributionStructure)
            structDistricution.DS_PROJDISTUSERS = strUser.split('|')[2].trim();
            structDistricution.DS_FORMACTIONS = strAction;
            structDistricution.DS_ACTIONDUEDATE = strDueDate;
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "3";
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistricution);
        };
        function UpdateFormStatus(StrStatus) {
            //get status according pass parameter
            if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null && $scope.DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                $scope.DS_ALL_ACTIVE_FORM_STATUS = _.filter($scope.DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name == StrStatus;
                });
                //set status
                if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null) {
                    var strStatus = $scope.DS_ALL_ACTIVE_FORM_STATUS[0].Value;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatus;
                }
            }
        }
    };
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof DWS_FinalCallBack !== "undefined") {
        return DWS_FinalCallBack();
    }
}