/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], 
function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $timeout, htmlformservice) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		var currentViewName = window.currentViewName;
		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.ORIMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.usersigndetails = $scope.ORIMsgCustomFields["User_Signature"];
		$scope.tmpusersigndetails = $scope.ORIMsgCustomFields["Tmp_User_Signature"];
		$scope.distributiondetails = $scope.ORIMsgCustomFields["Organisation_Structure"]["Distribution_Details"];
		var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		var dsUserdetailsFiltered = $scope.getValueOfOnLoadData('DS_USERDETAILS_FILTERED');

		$scope.update();

		$scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
		$scope.strIsDraft = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT;
		$scope.docDetails = $scope.getValueOfOnLoadData('DS_Doc_Associations_All_Custom_Attribute');
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		var STATIC_OBJ_DATA = {
			userSignatureStructure: {
				Sig_UserName: "",
				Sig_Organisation: "",
				Sig_Phone: "",
				Sig_Email: "",
				Sig_JobTitle: ""
			},
			tmpUserSignature: {
				Tmp_Sig_UserName: "",
				Tmp_Sig_Organisation: "",
				Tmp_Sig_Phone: "",
				Tmp_Sig_Email: "",
				Tmp_Sig_JobTitle: ""
			},
			transmittalFormAutoCreateNode: {
				ACF_01_CREATED_BY: '',
				ACF_01_ORI_FORMTITLE: '',
				ACF_01_DS_FORMTITLE: '',
				ACF_01_DS_CLOSE_DUE_DATE: '',
				ACF_01_Transmittal_Description: '',
				ACF_01_Transmittal_Reason: '',
				ACF_01_Add_ORI_Signature: '',
				ACF_01_Sig_UserName: '',
				ACF_01_Sig_Organisation: '',
				ACF_01_Sig_Phone: '',
				ACF_01_Sig_Email: '',
				ACF_01_Sig_JobTitle: '',
				ACF_01_Tmp_Sig_UserName: '',
				ACF_01_Tmp_Sig_Organisation: '',
				ACF_01_Tmp_Sig_Phone: '',
				ACF_01_Tmp_Sig_Email: '',
				ACF_01_Transmittal_Date: '',
				ACF_01_Tmp_Sig_JobTitle:'',
				ACF_01_Subcontractor_Package: '',
				ACF_01_Format_Soft_Copy: '',
				ACF_01_Format_Hard_Copy: '',
				ACF_01_Format_Hand: '',
				ACF_01_Format_Courier: '',
				ACF_01_Issued_By: '',
				ACF_01_ORI_USERREF: '',
				ACF_01_DS_FORMAUTONO_PREFIX:'PCON-TRA-',
				ACF_01_DS_AUTODISTRIBUTE: '3',

				ACF_01_REPEATING_VALUES: {
					ACF_01_DS_AutoDistribute_User_Group: {
						ACF_01_DS_AutoDistribute_Users: []
					}
				}
			}
		}

		$scope.getServerTime(function (serverDate) {
			var strDays = (new Date(serverDate)).getTime() + (86400000 * 3);
			var strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
			$scope.strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date($scope.strTime), 'dd-M-yy');
			$scope.ORIMsgCustomFields.Transmittal_Date = serverDate;
			$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = strCloseDueDate;

		});
		

		// auto create nodes set on submit button. only distribution nodes set in one xml node and only distribution logic in this function.
		$scope.setAutoCreateNodesAndDistribution = function () {
			// distribution from top code starts here
			var getAllDistributionNodes = htmlformservice.distSelect.$ctrl.selection;
			var allOrgStructure = [];
			if ($scope.strFormId != "" && $scope.strIsDraft == "NO") {
				allOrgStructure = allOrgStructure.concat($scope.ORIMsgCustomFields.Organisation_Structure.Distribution_Details);
			}
			var allOrgs = [];
			var allRoles = [];
			var allUsers = [];
			var allDists = [];
			var allOrgIds = [];

			var actionOrgUserId = "";
			var actionOrgUserName = "";
			var actionOrgUserDueDate = "";
			var actionOrgUserDueDays = "";

			var actionDistUserId = "";
			var actionDistUserName = "";
			var actionDistUserDueDate = "";
			var actionDistUserDueDays = "";

			var actionRoleUserId = "";
			var actionRoleUserName = "";
			var actionRoleUserDueDate = "";
			var actionRoleUserDueDays = "";

			var actionUserId = "";
			var actionUserName = "";
			var actionUserDueDate = "";
			var actionUserDueDays = "";

			var boolOrgMatch = true;
			var boolRoleUserMatch = true;
			var boolUserMatch = true;
			var boolDistMatch = true;

			angular.forEach(getAllDistributionNodes, function (item) {
				if (item.prefix == "O") {
					allOrgs.push(item);
				}
				if (item.prefix == "R") {
					allRoles.push(item)
				}
				if (item.prefix == "U") {
					allUsers.push(item)
				}
				if (item.prefix == "D") {
					allDists.push(item)
				}
			});

			// filling all orgs in org structure
			angular.forEach(allOrgs, function (currentNode) {
				actionOrgUserId = currentNode.action.actionID.split("$$")[0];
				actionOrgUserName = currentNode.action.actionName;
				actionOrgUserDueDate = currentNode.due.date;
				actionOrgUserDueDays = currentNode.due.days;

				allOrgIds.push(currentNode.item.orgID);

				angular.forEach(allOrgStructure, function (currOrg) {
					boolOrgMatch = true;
					if (allOrgIds.indexOf(parseFloat(currOrg.orgId)) < 0) {
						allOrgIds.push(parseFloat(currOrg.orgId));
					}
					if (currOrg.orgId == currentNode.item.orgID) {
						boolOrgMatch = false;
					}
				});

				if (boolOrgMatch) {
					allOrgStructure.push({
						orgId: currentNode.item.orgID,
						orgName: currentNode.item.orgName,
						orgAutocreateFlag: "New",
						userDetails: []
					});
				}
			});

			// filling user data as per org and org users in org structure
			angular.forEach(allOrgs, function (currentNode) {
				actionOrgUserId = currentNode.action.actionID.split("$$")[0];
				actionOrgUserName = currentNode.action.actionName;
				actionOrgUserDueDate = currentNode.due.date;
				actionOrgUserDueDays = currentNode.due.days;

				angular.forEach(allOrgStructure, function (orgStructureNode) {
					if (orgStructureNode.orgId == currentNode.item.orgID && orgStructureNode.orgAutocreateFlag == "New") {
						angular.forEach(currentNode.users, function (users) {
							orgStructureNode.userDetails.push({
								userId: users.id,
								userName: users.text,
								actionIDAndName: actionOrgUserId + "#" + actionOrgUserName,
								actionDate: actionOrgUserDueDate,
								actionDays: actionOrgUserDueDays
							})
						});
					}
				});
			});

			allOrgIds = commonApi._.uniq(allOrgIds);

			// filling all distribution user in org structure and distribution users in org structure (Add orgs which is not there in main structure)
			// for filling orgIds which is not in allOrgIds common array and fill org structure
			angular.forEach(allDists, function (currentNode) {
				angular.forEach(currentNode.users, function (users) {
					if (allOrgIds.indexOf(users.item.orgID) < 0) {
						allOrgIds.push(users.item.orgID);
						allOrgStructure.push({
							orgId: users.item.orgID,
							orgName: users.item.orgName,
							orgAutocreateFlag: "New",
							userDetails: []
						});
					}
				});
			});

			// filling all distribution user in org structure and distribution users in org structure
			angular.forEach(allDists, function (currentNode) {

				// filling users in org structure
				angular.forEach(currentNode.users, function (users) {
					actionDistUserId = users.item.actionID.split("$$")[0];
					actionDistUserName = users.item.actionName;
					actionDistUserDueDate = users.due.date;
					actionDistUserDueDays = users.due.days;
					angular.forEach(allOrgStructure, function (allOrg) {
						if (allOrg.orgId == users.item.orgID) {
							boolDistMatch = true;
							angular.forEach(allOrg.userDetails, function (orgUsers) {
								if (orgUsers.userId == users.item.userID.split("$$")[0]) {
									boolDistMatch = false;
								}
							});
							if (boolDistMatch) {
								allOrg.userDetails.push({
									userId: users.item.userID.split("$$")[0],
									userName: users.text,
									actionIDAndName: actionDistUserId + "#" + actionDistUserName,
									actionDate: actionDistUserDueDate,
									actionDays: actionDistUserDueDays
								})
							}
						}
					});
				});
			});

			// filling all roles user in org structure and roles users in org structure (Add orgs which is not there in main structure)
			// for filling orgIds which is not in allOrgIds common array and fill org structure
			angular.forEach(allRoles, function (currentNode) {
				angular.forEach(currentNode.users, function (users) {
					if (allOrgIds.indexOf(users.item.orgID) < 0) {
						allOrgIds.push(users.item.orgID);
						allOrgStructure.push({
							orgId: users.item.orgID,
							orgName: users.item.orgName,
							orgAutocreateFlag: "New",
							userDetails: []
						});
					}
				});
			});

			// filling all roles user in org structure and roles users in org structure
			angular.forEach(allRoles, function (currentNode) {
				actionRoleUserId = currentNode.action.actionID.split("$$")[0];
				actionRoleUserName = currentNode.action.actionName;
				actionRoleUserDueDate = currentNode.due.date;
				actionRoleUserDueDays = currentNode.due.days;

				// filling users in org structure
				angular.forEach(currentNode.users, function (users) {
					angular.forEach(allOrgStructure, function (allOrg) {
						if (allOrg.orgId == users.item.orgID) {
							boolRoleUserMatch = true;
							angular.forEach(allOrg.userDetails, function (orgUsers) {
								if (orgUsers.userId == users.item.id) {
									boolRoleUserMatch = false;
								}
							});
							if (boolRoleUserMatch) {
								allOrg.userDetails.push({
									userId: users.id,
									userName: users.text,
									actionIDAndName: actionRoleUserId + "#" + actionRoleUserName,
									actionDate: actionRoleUserDueDate,
									actionDays: actionRoleUserDueDays
								})
							}
						}
					});
				});
			});

			// filling all users in org structure and users in org structure (Add orgs which is not there in main structure)
			// for filling orgIds which is not in allOrgIds common array and fill org structure
			angular.forEach(allUsers, function (users) {
				if (allOrgIds.indexOf(users.item.orgID) < 0) {
					allOrgIds.push(users.item.orgID);
					allOrgStructure.push({
						orgId: users.item.orgID,
						orgName: users.item.orgName,
						orgAutocreateFlag: "New",
						userDetails: []
					});
				}
			});

			// filling all roles user in org structure and roles users in org structure
			angular.forEach(allUsers, function (users) {
				actionUserId = users.action.actionID.split("$$")[0];
				actionUserName = users.action.actionName;
				actionUserDueDate = users.due.date;
				actionUserDueDays = users.due.days;

				// filling users in org structure
				angular.forEach(allOrgStructure, function (allOrg) {
					if (allOrg.orgId == users.item.orgID) {
						boolUserMatch = true;
						angular.forEach(allOrg.userDetails, function (orgUsers) {
							if (orgUsers.userId == users.item.userID.split('$$')[0]) {
								boolUserMatch = false;
							}
						});
						if (boolUserMatch) {
							allOrg.userDetails.push({
								userId: users.id,
								userName: users.text,
								actionIDAndName: actionUserId + "#" + actionUserName,
								actionDate: actionUserDueDate,
								actionDays: actionUserDueDays
							})
						}
					}
				});
			});

			$scope.ORIMsgCustomFields.Organisation_Structure.Distribution_Details = [];
			$scope.ORIMsgCustomFields.Organisation_Structure.Distribution_Details = allOrgStructure.concat($scope.ORIMsgCustomFields.Organisation_Structure.Distribution_Details);
			// distribution from top code ends here

			//clear selection of distribution of top after setting nodes
			htmlformservice.distSelect.clearSelection();
		}

		if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
			$scope.strCanReply = "yes";
			$scope.ORIMsgCustomFields.originator_Id = $scope.getWorkingUserId();
		}

		if (currentViewName == "ORI_VIEW" && $scope.strFormId != "" && $scope.strIsDraft == "NO") {
			var objFlagsToHide = {
				AssociationFlag: true,
				AttachmentFlag: true,
				ImportFromExcelFlag: false
			}
			$scope.hideAttachmentAssociationAndImportButton(objFlagsToHide);
		}

		// to get Custom Attribute On Load.
		var logo = commonApi._.findWhere(dsAsiConfigurableAttributes, {
			Value3: "Logo",
			Value7: "Logo"
		}) || {};
		initFormsData();

		$scope.setUserDetails = function(){
			if (dsUserdetailsFiltered.length && $scope.ORIMsgCustomFields.Add_ORI_Signature == 'Yes') {
				$scope.usersigndetails.Sig_UserName = dsUserdetailsFiltered[0].Value7 + " " + dsUserdetailsFiltered[0].Value8;
				$scope.usersigndetails.Sig_Phone = dsUserdetailsFiltered[0].Value5;
				$scope.usersigndetails.Sig_Email = dsUserdetailsFiltered[0].Value6;
				$scope.usersigndetails.Sig_JobTitle = dsUserdetailsFiltered[0].Name;
				$scope.usersigndetails.Sig_Organisation = dsUserdetailsFiltered[0].Value3;

				$scope.tmpusersigndetails.Tmp_Sig_UserName = dsUserdetailsFiltered[0].Value7 + " " + dsUserdetailsFiltered[0].Value8;
				$scope.tmpusersigndetails.Tmp_Sig_Phone = dsUserdetailsFiltered[0].Value5;
				$scope.tmpusersigndetails.Tmp_Sig_Email = dsUserdetailsFiltered[0].Value6;
				$scope.tmpusersigndetails.Tmp_Sig_JobTitle = dsUserdetailsFiltered[0].Name;
				$scope.tmpusersigndetails.Tmp_Sig_Organisation = dsUserdetailsFiltered[0].Value3;
			}
			else{
				$scope.usersigndetails.Sig_UserName = "";
				$scope.usersigndetails.Sig_Phone = "";
				$scope.usersigndetails.Sig_Email = "";
				$scope.usersigndetails.Sig_JobTitle = "";
				$scope.usersigndetails.Sig_Organisation = "";

				$scope.tmpusersigndetails.Tmp_Sig_UserName = "";
				$scope.tmpusersigndetails.Tmp_Sig_Phone = "";
				$scope.tmpusersigndetails.Tmp_Sig_Email = "";
				$scope.tmpusersigndetails.Tmp_Sig_JobTitle = "";
				$scope.tmpusersigndetails.Tmp_Sig_Organisation = "";
			}
		}

		if (currentViewName == "ORI_VIEW") {
			$scope.setUserDetails();
			var transmittal_Reasons = [];

			for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
				var element = dsAsiConfigurableAttributes[index];

				if (element.Value3 === "Transmittal_Reasons") {
					transmittal_Reasons.push(element);
				}
			}
			$scope.Transmittal_Reasons = transmittal_Reasons;
		}

		function initFormsData() {
			if (currentViewName == "ORI_VIEW") {
				$scope.ORIMsgCustomFields.DS_Logo = logo.Value8 || '/images/asiteWhite60x200.png';
			}
		}

		function setFormWorkflow() {
			var getAllDistributionNodes = htmlformservice.distSelect.$ctrl.selection;
			if (getAllDistributionNodes.length) {
				alert("You will need to Set Distribution via the button");
				return true;
			} else {
				//Auto create logic in else part
				$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
				var TaskDays = '21';
				var strDuedays = '';

				strDuedays = commonApi.calculateDistDateFromDays({
					baseDate: $scope.todayDateDbFormat,
					days: TaskDays
				});
				
				angular.forEach($scope.ORIMsgCustomFields.Organisation_Structure.Distribution_Details, function (objOrg) {
					if (objOrg.orgAutocreateFlag != "Old") {
						var newTaskNode = angular.copy(STATIC_OBJ_DATA.transmittalFormAutoCreateNode);
						var userDetailsOrgWise = objOrg.userDetails;
						objOrg.orgAutocreateFlag = "Old";
						$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
						newTaskNode.ACF_01_CREATED_BY = $scope.getWorkingUserId();
						newTaskNode.ACF_01_ORI_FORMTITLE = $scope.ORIMsgCustomFields.ORI_FORMTITLE;
						newTaskNode.ACF_01_DS_FORMTITLE = $scope.ORIMsgCustomFields.ORI_FORMTITLE
						newTaskNode.ACF_01_DS_CLOSE_DUE_DATE = strDuedays;
						newTaskNode.ACF_01_Transmittal_Description = $scope.ORIMsgCustomFields.Transmittal_Description;
						newTaskNode.ACF_01_Transmittal_Reason = $scope.ORIMsgCustomFields.Transmittal_Reason;
						newTaskNode.ACF_01_Add_ORI_Signature = $scope.ORIMsgCustomFields.Add_ORI_Signature;
						newTaskNode.ACF_01_Sig_UserName = $scope.usersigndetails.Sig_UserName;
						newTaskNode.ACF_01_Sig_Organisation = $scope.usersigndetails.Sig_Organisation;
						newTaskNode.ACF_01_Sig_Phone = $scope.usersigndetails.Sig_Phone;
						newTaskNode.ACF_01_Sig_Email = $scope.usersigndetails.Sig_Email;
						newTaskNode.ACF_01_Sig_JobTitle = $scope.usersigndetails.Sig_JobTitle;
						newTaskNode.ACF_01_Tmp_Sig_UserName = $scope.tmpusersigndetails.Tmp_Sig_UserName;
						newTaskNode.ACF_01_Tmp_Sig_Organisation = $scope.tmpusersigndetails.Tmp_Sig_Organisation;
						newTaskNode.ACF_01_Tmp_Sig_Phone = $scope.tmpusersigndetails.Tmp_Sig_Phone;
						newTaskNode.ACF_01_Tmp_Sig_Email = $scope.tmpusersigndetails.Tmp_Sig_Email;
						newTaskNode.ACF_01_Tmp_Sig_JobTitle = $scope.tmpusersigndetails.Tmp_Sig_JobTitle;
						newTaskNode.ACF_01_Subcontractor_Package = $scope.ORIMsgCustomFields.Subcontractor_Package;
						newTaskNode.ACF_01_Format_Soft_Copy = $scope.ORIMsgCustomFields.Format_Soft_Copy;
						newTaskNode.ACF_01_Format_Hard_Copy = $scope.ORIMsgCustomFields.Format_Hard_Copy;
						newTaskNode.ACF_01_Format_Hand = $scope.ORIMsgCustomFields.Format_Hand;
						newTaskNode.ACF_01_Format_Courier = $scope.ORIMsgCustomFields.Format_Courier;
						newTaskNode.ACF_01_Issued_By = $scope.ORIMsgCustomFields.Issued_By;
						newTaskNode.ACF_01_ORI_USERREF = "PCON-TRA-" + "<<NEXT_AUTONO>>";
						newTaskNode.ACF_01_DS_FORMAUTONO_PREFIX = "PCON-TRA-";
						newTaskNode.ACF_01_DS_AUTODISTRIBUTE = "3";	
						newTaskNode.ACF_01_Transmittal_Date = $scope.ORIMsgCustomFields.Transmittal_Date;


						angular.forEach(userDetailsOrgWise, function (objUser) {
							newTaskNode.ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users.push({
								ACF_01_DS_PROJDISTUSERS: objUser.userId +'#'+ objUser.userName,
								ACF_01_DS_FORMACTIONS: objUser.actionIDAndName,
								ACF_01_DS_ACTIONDUEDATE: strDuedays,
								ACF_01_DS_DUEDAYS: TaskDays
							})
						});
						$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);
					}
				});
			}

			if(($scope.strFormId == "" && $scope.strIsDraft == "NO") || ($scope.strFormId != "" && $scope.strIsDraft == "YES")){
				var strPrefix = "PCON-DTRA";
				$scope.Form_Data['DS_FORMAUTONO_PREFIX'] = strPrefix;
				$scope.ORIMsgCustomFields["ORI_USERREF"] = strPrefix + "-" + "<<NEXT_AUTONO>>";
			}
			
			return false;
		}

		window.oriformSubmitCallBack = function () {
			return setFormWorkflow();
		};
	}
	return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}