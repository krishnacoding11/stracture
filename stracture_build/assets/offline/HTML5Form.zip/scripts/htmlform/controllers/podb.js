/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format'], function(angular, baseController) {
    'use strict';

    function PrintViewController($scope, $element, $window, commonApi, $timeout) {
        $scope.oriprintviewtabs = [{
            title: 'Dashboard',
            url: 'dashboard.html',
            isVisible: true
        }, {
            title: 'Reports',
            url: 'reports.html',
            isVisible: true
        }];
        $scope.currentOriPrintViewTab = 'dashboard.html';

        $scope.onClickTab = function(tab) {
            $scope.currentOriPrintViewTab = tab;

            if(tab=== 'dashboard.html'){
                $timeout(function() {
                    var bodyFreezDivs = document.querySelectorAll(".bodyFreezDivs")[0] || document.querySelectorAll(".bodyFreezDivsPrint")[0];
                    if(bodyFreezDivs){                  
                        var staic_offsetWidth = bodyFreezDivs && bodyFreezDivs.offsetWidth;
                        bodyFreezDivs.onscroll = function(e){
                            freezeDivScrollForExpTab(e , staic_offsetWidth);
                        };
                    }

                    var bodyColumnFreezDivs = document.querySelectorAll(".bodyColumnFreezDivs")[0];
                    if(bodyColumnFreezDivs){
                        bodyColumnFreezDivs.onscroll = function(e){
                            MovingDivScroll(e);
                        };

                        bodyColumnFreezDivs.addEventListener('DOMMouseScroll', _onWheel, false ); // For FF and Opera
                        bodyColumnFreezDivs.addEventListener('mousewheel', _onWheel, false ); // For others

                    }

                    $timeout(function() {
                        dynamicSetParentTableWidth();
                        podbAdjustTableRowHeights();
                    }, 10);
                }, 0, false);
            }
        };

        /**
         * Handle mouse scroll event
         * @param {event} e - scroll event
         */
        function _onWheel(e) {
            // Do what you want here
             MovingDivScroll(e);
        }
 
        /**
         * Handle mouse scroll event for fixed frozen div
         * @param {event} e - scroll event
         * @param {number} STATIC_WIDTH - offset widh of div
         */
        function freezeDivScrollForExpTab(event , STATIC_WIDTH ){

            var expFreezHeaderDiv = document.querySelectorAll(".expFreezHeaderDiv")[0]
            var bodyColumnFreezTable = document.querySelectorAll(".bodyColumnFreezTable")[0];            
            
            if( expFreezHeaderDiv ){
                expFreezHeaderDiv.scrollLeft = event.target.scrollLeft;
            }

            if( bodyColumnFreezTable ){
                bodyColumnFreezTable.style.marginTop = -event.target.scrollTop +"px";                
            }
        }

        function MovingDivScroll(event){
            var bodyFreezDivs =document.querySelectorAll(".bodyFreezDivs")[0];
            if( bodyFreezDivs ){
                if(event.deltaY){
                bodyFreezDivs.scrollTop += event.deltaY;              
            }
            else if(event.wheelDelta){
                bodyFreezDivs.scrollTop += -event.wheelDelta
            }
            else{
                event.target.scrollTop = 0;
            }
             
            }
        }

        /**
         * Check current active tab is Reposrts or dashboard
         * @param {string} tabUrl - current tab
         */
        $scope.isActiveTab = function(tabUrl) {
            return tabUrl === $scope.currentOriPrintViewTab;
        };


        $scope.downloadReport = function(form_template_name, Report_format) {
            $window.showSelectedReportfromApp(form_template_name, Report_format);
        };
    }

    /**
     * Set max height of corresponding rows for fixed and scrollable table so they are aligned together.
     */
    function podbAdjustTableRowHeights(){
        var fixedFreezeTableBody =  document.querySelectorAll(".bodyColumnFreezTable")[0];
        var scrollableTableBody =  document.querySelectorAll(".podbBodyFreezDivTable")[0];

        if(!fixedFreezeTableBody){
            return;
        }
        if(fixedFreezeTableBody && !fixedFreezeTableBody.rows.length){
            return;
        }
       
       for(var i=0; i<=fixedFreezeTableBody.rows.length-1; i++){
            if(scrollableTableBody.rows[i].offsetHeight >= fixedFreezeTableBody.rows[i].offsetHeight){
                fixedFreezeTableBody.rows[i].style.height = scrollableTableBody.rows[i].offsetHeight + 'px';
            } else{
                scrollableTableBody.rows[i].style.height = fixedFreezeTableBody.rows[i].offsetHeight + 'px';
            }           
       }
    }

    function dynamicSetParentTableWidth(){
       var flg = document.URL.indexOf('adoddle') > 0;
        // console.log("ADODDLE???" + !flg);
        if(!flg){
            var windowWidth = window.innerWidth;
            windowWidth = windowWidth * 94 / 100;
            angular.element('.expOverContainer') && angular.element('.expOverContainer').width(windowWidth + "px");    
        } else {
            angular.element('.expOverContainer') && angular.element('.expOverContainer').width("100%");
        }
    }

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.projectId || window.currProjId;
        if ($scope.projectId === "null"){
            $scope.projectId = window.currProjId;
        }
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        $scope.regForNumbersOnly = '\\d+';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
             $timeout(function() {
                $scope.loaded = true;
                $element.addClass('loaded');                
              }, 500);
            }
        });

        if ($scope.isPrintView) {
            $controller(PrintViewController, {
                $scope: $scope,
                $element: $element
            });
        }

        if (!String.prototype.trim) {
            String.prototype.trim = function() {
                return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
            };
        }

        var newRowEmptyObj = {
            Exp_FC_Vs_Budget: {
                "EFCB_A_From": 5,
                "EFCB_R_To": '',
                "EFCB_G_To": 5,
                "EFCB_G_From": 0,
                "EFCB_A_To": 15,
                "EFCB_From": 0,
                "EFCB_To": 250000,
                "EFCB_R_From": 15
            },
            Exp_FC_Vs_Baseline: {
                "EFCBL_G_From": 0,
                "EFCBL_R_From": 15,
                "EFCBL_A_From": 5,
                "EFCBL_From": 0,
                "EFCBL_R_To": '',
                "EFCBL_A_To": 15,
                "EFCBL_To": 250000,
                "EFCBL_G_To": 5
            },
            Exp_Current_Vs_Previous: {
                "EFCPrev_To": 1000000,
                "EFCPrev_RAG": "Green",
                "EFCPrev_From": 0
            },
            Exp_Outofturn_Forecast: {
                "EOutFC_To": 2,
                "EOutFC_From": -2,
                "EOutFC_RAG": "Green"
            },
            Exp_Forecast_Vs_Actuals: {
                "EFcAct_RAG": "Green",
                "EFcAct_From": 0,
                "EFcAct_To": 85
            }
        }
        
        /**
         *  Insert a blank new item in items array
         *  @param{array} items : the array in whjich a new items is to be added
         *  @param{string} item : the key for blank item to be added 
         */
        $scope.addNewRowPodb = function(items, item) {
            var blankItem = angular.copy(newRowEmptyObj[item]);
            $scope.addRepeatingRow(items, blankItem);
        };

        /**
         * Click event of Apply preferences button
         */
        $scope.On_Apply_Preferences_Click = function(isSetDefaultPreferences){
            if(isSetDefaultPreferences){
                setDS_PPMT_GET_USER_PREFERENCES();
            }
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["Filtered_Projects_fltrStr"] = getFiltered_Projects_fltrStr();
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["Page_Sel"] = "";
        };

        /**
         * On change event of filters 
         */
        $scope.onFiltersDropDownChange = function(){
            $scope.On_Apply_Preferences_Click(false);
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["Page_Sel"] = "";
        };

        /**
         * Validation : Restrict & check for Proj manager. 
         */
        $scope.validateProjectManager = function(projManager){
            if(projManager.trim().indexOf('0XXXXX0') === 0){
                ADODDLE.alert({
                    title: "Group Name selected !!!",
                    msg: "Select Pick list value"
                });
            }
        };

        /**
         * Click event of FILTER PROJECTS button. Call SP and fetch data
         */
         $scope.On_Filter_Projects_Click = function(){
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]['isFiltered'] = 0;
            var strProjFilter = getFiltered_Projects_fltrStr()

            //SP call for DS_PPMT_GET_FILTERED_PROJECTS & DS_PPMT_GET_PRS_COUNT
            var form = {
              "projectId": $scope.projectId,
              "formId": $scope.formId,
              "fields": "DS_PPMT_GET_FILTERED_PROJECTS, DS_PPMT_GET_PRS_COUNT", 
              "callbackParamVO": {
                  "customFieldVOList": [{
                      "fieldName": "DS_PPMT_GET_FILTERED_PROJECTS",
                      "fieldValue": strProjFilter
                  },{
                      "fieldName": "DS_PPMT_GET_PRS_COUNT",
                      "fieldValue": strProjFilter
                  }]
              },
              "DS_FORMGROUPCODE": "PODB",
              "appBuilderId": "EA-PPMT-PODB",
              'Filtered_Projects_fltrStr': strProjFilter
           };

           if(document.URL.indexOf('adoddle') > 0){
                form["callerApp"] = 10; //NOODLE-61708
            }

           $scope.filterInProgress = true;
           $scope.getCallbackData(form).then(function(response) {
            $scope.filterInProgress = false;
                if (response.data) {
                    var DS_PPMT_GET_FILTERED_PROJECTS = JSON.parse(response.data['DS_PPMT_GET_FILTERED_PROJECTS']);
                    if (DS_PPMT_GET_FILTERED_PROJECTS.Items && DS_PPMT_GET_FILTERED_PROJECTS.Items.Item) {
                        $scope.DS_PPMT_GET_FILTERED_PROJECTS = DS_PPMT_GET_FILTERED_PROJECTS.Items.Item;
                        $timeout(function() {
                          angular.element('#Dashboard').triggerHandler('click');//Calls onClickTab() function
                         //podbAdjustTableRowHeights();
                        }, 100);
                        setPagingData();
                    }
                }
            });
         };

        /**
         * Handle on paste event for checking & restricting special char | # < &
         * @param {event} e - paste
         */
        $scope.restrictCharPaste = function(event){
            var inputValue;
            if($window.clipboardData){ //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }                

            if (inputValue.match(/[|<&#]/gi)) {
                ADODDLE.alert({
                    title: "Restrict Character Entered!!!",
                    msg: "Restricted Characters specified!!! Restricted Characters | < > #"
                });
                event.preventDefault();
                return false;
            }
        };

        /**
         * Handle key press for checking & restricting special char | # < &
         * @param {event} e - paste
         * @param {string} inputValue 
         */
        $scope.restrictChar = function(event, inputValue){
            switch(event.keyCode){
                case 51 :
                case 55 :
                case 188 :
                case 220 :
                if(event.shiftKey){
                    ADODDLE.alert({
                        title: "Restrict Character Entered!!!",
                        msg: "Restricted Characters specified!!! Restricted Characters # | & <"
                    });
                    event.preventDefault();
                }
                break;
            }
        };

        $scope.checkPrevValue = function(currentVal, PrevValue, form, name, equalsCheck) {
            $timeout(function() {
                if (!form[name])
                    return;
                if (PrevValue === '' && currentVal === ''){
                    form[name].$setValidity("prevVal", true);
                    return;
                }

                if (PrevValue === '')
                    PrevValue = parseInt(currentVal === '' ? 0 : currentVal) + 1;
                if (!PrevValue) {
                    PrevValue = 0;
                }
                if (currentVal === '') {
                    currentVal = parseInt(PrevValue === '' ? 0 : PrevValue) + 1;
                }
                if (!currentVal) {
                    currentVal = 0;
                }
                if (equalsCheck) {
                    if (parseInt(PrevValue) >= parseInt(currentVal)) {
                        form[name].$setValidity("prevVal", false);
                    } else {
                        form[name].$setValidity("prevVal", true);
                    }
                } else {
                    if (parseInt(PrevValue) > parseInt(currentVal)) {
                        form[name].$setValidity("prevVal", false);
                    } else {
                        form[name].$setValidity("prevVal", true);
                    }
                }
            }, 100);
        };

        $scope.hasValidationError = function(form, key, index) {
            return form[key + index].$error.prevVal;
        };

        $scope.returnValidationMsg = function(form, key, index, from, equalsCheck) {
            if (!form[key + index]){
                return '';
            }
            if (equalsCheck) {
                if (from === 'prevRow') {
                    return form[key + index].$error.prevVal ? 'Specify From value more then the previous To value' : '';
                } else {
                    return form[key + index].$error.prevVal ? 'Sepcify to value greater then the from value' : '';
                }
            } else {
                if (from === 'prevRow') {
                    return form[key + index].$error.prevVal ? 'Specify From value more then or equal to the previous To value' : '';
                } else {
                    return form[key + index].$error.prevVal ? 'Sepcify to value greater then or equal to the from value' : '';
                }
            }
        };

        $scope.checkTempValue = function(tempObj, newVal) {
            var tempVal = $scope.customFileds['ORI_MSG_Custom_Fields'][tempObj];
            var add = 0;
            if (tempObj === 'tmpToRange_EFCB'){
                add = 1;
            }
            if (!tempVal) {
                $scope.customFileds['ORI_MSG_Custom_Fields'][tempObj] = (parseInt(newVal) + add);
                return;
            }
            if (parseInt(tempVal) < parseInt(newVal)) {
                $scope.customFileds['ORI_MSG_Custom_Fields'][tempObj] = (parseInt(newVal) + add);
            }
        };

        $scope.showHideFiltersClick = function(){
            $scope.isShowhideFilters = !$scope.isShowhideFilters;
            dynamicSetParentTableWidth();             
        }

        /**
        * Function to set default values in scope for the first time
        */
        function setDefaultData() {         


            $scope.customFileds = $scope.data['myFields']['FORM_CUSTOM_FIELDS'];
            $scope.projFormTitle = $scope.data['myFields']['Asite_System_Data_Read_Only']['_3_Project_Data']['DS_PROJECTNAME'];

            $scope.isShowhideFilters = false//$scope.data['myFields']['HideShowSection']['isVisible'] || false;

            var allRagGroups = $scope.customFileds['ORI_MSG_Custom_Fields']['All_RAG_Groups'];
            $scope.Exp_FC_Vs_Budget = allRagGroups['Exp_FC_Vs_Budget_Group']['Exp_FC_Vs_Budget'];
            $scope.Exp_FC_Vs_Baseline = allRagGroups['Exp_FC_Vs_Baseline_Group']['Exp_FC_Vs_Baseline'];
            $scope.Exp_Current_Vs_Previous = allRagGroups['Exp_Current_Vs_Previous_Group']['Exp_Current_Vs_Previous'];
            $scope.Exp_Outofturn_Forecast = allRagGroups['Exp_Outofturn_Forecast_Group']['Exp_Outofturn_Forecast'];
            $scope.Exp_Forecast_Vs_Actuals = allRagGroups['Exp_Forecast_Vs_Actuals_Group']['Exp_Forecast_Vs_Actuals'];
            $scope.Mil_FD_Vs_Bas = allRagGroups['Mil_FD_Vs_Bas_Group']['Mil_FD_Vs_Bas'];
            $scope.RAG_Statuses = $scope.customFileds['All_RAG_Statuses']['RAG_Statuses'];

            $scope.Dashboard_Preferences = $scope.customFileds['Dashboard_Preferences'];
            $scope.Tabbed_Paging = $scope.customFileds['Tabbed_Paging'];

            var podbDashboardData = $scope.getValueOfOnLoadData("DS_PPMT_GET_FILTERED_PROJECTS") || [];
            if(!podbDashboardData.length) {
            	podbDashboardData = [];
            }
           $scope.DS_PPMT_GET_FILTERED_PROJECTS = podbDashboardData;
           setDS_PPMT_GET_USER_PREFERENCES();           

        }

        function setDS_PPMT_GET_USER_PREFERENCES(){
            $scope.Dashboard_Preferences = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['Dashboard_Preferences'];
            var DS_PPMT_GET_USER_PREFERENCES = $scope.getValueOfOnLoadData("DS_PPMT_GET_USER_PREFERENCES"); 
            if(DS_PPMT_GET_USER_PREFERENCES.length) {
                var index = DS_PPMT_GET_USER_PREFERENCES.length - 1;
                $scope.Dashboard_Preferences['National_Project_No'] = DS_PPMT_GET_USER_PREFERENCES[index].Value2;
                $scope.Dashboard_Preferences['IBIS_Project_No'] = DS_PPMT_GET_USER_PREFERENCES[index].Value3;
                $scope.Dashboard_Preferences['Project_Title'] = DS_PPMT_GET_USER_PREFERENCES[index].Value4;
                $scope.Dashboard_Preferences['Country'] = DS_PPMT_GET_USER_PREFERENCES[index].Value5;
                $scope.Dashboard_Preferences['Region'] = DS_PPMT_GET_USER_PREFERENCES[index].Value6;
                $scope.Dashboard_Preferences['Area'] = DS_PPMT_GET_USER_PREFERENCES[index].Value7;
                $scope.Dashboard_Preferences['Delivery_Team'] = DS_PPMT_GET_USER_PREFERENCES[index].Value8;
                $scope.Dashboard_Preferences['Function'] = DS_PPMT_GET_USER_PREFERENCES[index].Value9;
                $scope.Dashboard_Preferences['Project_Manager'] = DS_PPMT_GET_USER_PREFERENCES[index].Value10;
                $scope.Dashboard_Preferences['Project_Status'] = DS_PPMT_GET_USER_PREFERENCES[index].Value11;
                $scope.Dashboard_Preferences['Sort_On'] = DS_PPMT_GET_USER_PREFERENCES[index].Value12;
                $scope.Dashboard_Preferences['Sort_Type'] = DS_PPMT_GET_USER_PREFERENCES[index].Value13;
                $scope.Dashboard_Preferences['Delivery_Owner'] = DS_PPMT_GET_USER_PREFERENCES[index].Value14;
                $scope.Dashboard_Preferences['Project_Executive'] = DS_PPMT_GET_USER_PREFERENCES[index].Value10;
            } else {
                $scope.Dashboard_Preferences['National_Project_No'] = "";
                $scope.Dashboard_Preferences['IBIS_Project_No'] = "";
                $scope.Dashboard_Preferences['Project_Title'] = "";
                $scope.Dashboard_Preferences['Country'] = "";
                $scope.Dashboard_Preferences['Region'] = ""
                $scope.Dashboard_Preferences['Area'] = "";
                $scope.Dashboard_Preferences['Delivery_Team'] = "";
                $scope.Dashboard_Preferences['Function'] = "";
                $scope.Dashboard_Preferences['Project_Manager'] = "";
                $scope.Dashboard_Preferences['Project_Status'] = "";
                $scope.Dashboard_Preferences['Sort_On'] = "";
                $scope.Dashboard_Preferences['Sort_Type'] = "";
                $scope.Dashboard_Preferences['Delivery_Owner'] = "";
                $scope.Dashboard_Preferences['Project_Executive'] = "";
            }
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["Filtered_Projects_fltrStr"] = getFiltered_Projects_fltrStr();
        }

        function getFiltered_Projects_fltrStr() {
            var Dashboard_Preferences =  $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]['Dashboard_Preferences'];
            var Page_Slice = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["Page_Slice"];

            var National_Project_No = Dashboard_Preferences['National_Project_No'] || "";
            var IBIS_Project_No = Dashboard_Preferences['IBIS_Project_No'] || "";
            var Project_Title = Dashboard_Preferences['Project_Title'] || "";
            var Country = Dashboard_Preferences['Country'] || "";
            var Region = Dashboard_Preferences['Region'] || "";
            var Area = Dashboard_Preferences['Area'] || "";
            var Delivery_Team = Dashboard_Preferences['Delivery_Team'] || "";
            var strFunction = Dashboard_Preferences['Function'] || "";
            var Project_Manager = Dashboard_Preferences['Project_Manager'] || "";
            var Project_Status = Dashboard_Preferences['Project_Status'] || "";
            var Sort_On = Dashboard_Preferences['Sort_On'] || "";
            var Sort_Type = Dashboard_Preferences['Sort_Type'] || "";
            var Delivery_Owner = Dashboard_Preferences['Delivery_Owner'] || "";
            var Project_Executive = Dashboard_Preferences['Project_Executive'] || "";
            // var Page_Sel = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['Page_Sel']
            // var pageSelUppperlimit = parseInt(Page_Sel.split('-')[1]);
            
            var PageRange = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['Page_Sel'] || "1-" + Page_Slice;
            // debugger;

            var Filtered_Projects_fltrStr = "XXXXX" + "#" + 
                National_Project_No + "#" + 
                IBIS_Project_No + "#" + 
                Project_Title + "#" +
                Country + "#" + 
                Region + "#" + 
                Area + "#" + 
                Delivery_Team + "#" + 
                strFunction + "#"+ 
                Project_Manager + "#" + 
                Project_Status + "#" + 
                Sort_On + "#" + 
                Sort_Type + "#" + 
                Delivery_Owner + "#" + 
                PageRange + "#"+ 
                Project_Executive;

                console.log(Filtered_Projects_fltrStr);
                return Filtered_Projects_fltrStr;
        }

        /**
        * Function to get dropdown values for filter
        */
        function getDsPpmtGetPicklists() { 
            var form = {
              "projectId": $scope.projectId,
              "formId": $scope.formId,
              "fields": "DS_PPMT_GET_PICKLISTS",
              "callbackParamVO": {
                "customFieldVOList": [{
                 "fieldName": "DS_PPMT_GET_PICKLISTS",
                 "fieldValue": "EA-PPMT-CWR|14,43,3,21,26,13,19"
               }]
             }
           };

           $scope.getCallbackData(form).then(function(response) {
                if (response.data) {
                    var countryNo = 14,regionNo = 43,areaNo = 3,deliveryTeamNo = 21,functionNo = 26,projectStatusNo = 13,ncpmsDeliveryNo = 19;
                    var drpDwnJson = JSON.parse(response.data.DS_PPMT_GET_PICKLISTS);
                    
                    $scope.countryDropDown = drpDwnJson.Items.Item[countryNo];
                    $scope.regionDropDown =  drpDwnJson.Items.Item[regionNo];
                    $scope.areaDropDown =  drpDwnJson.Items.Item[areaNo];
                    $scope.deliveryTeamDropDown =  drpDwnJson.Items.Item[deliveryTeamNo];
                    $scope.functionDropDown =  drpDwnJson.Items.Item[functionNo];
                    $scope.projectStatusDropDown =  drpDwnJson.Items.Item[projectStatusNo];
                    $scope.ncpmsDeliveryDropDown =  drpDwnJson.Items.Item[ncpmsDeliveryNo];
                    // setPagingData();
                }
            });
         }

         

        function On_FormEvents_ViewSwitched(view) {
            if (view !== "ORI_VIEW") {
                setPagingData();
                var tmpFirstRecord = $scope.customFileds.Tabbed_Paging.Pages[0];
                if (tmpFirstRecord && tmpFirstRecord.Page_Range !== "") {
                    $scope.customFileds.Page_Sel = tmpFirstRecord.Page_Range;
                }
            }
        }

        function On_CTRL403_7_Clicked() {
            setPagingData();
            var isFiltered = $scope.customFileds.isFiltered;
            if (isFiltered === "1") {
                var tmpFirstRecord = $scope.customFileds.Tabbed_Paging.Pages[0];
                if (tmpFirstRecord && tmpFirstRecord.Page_Range !== "") {
                    $scope.customFileds.Page_Sel = tmpFirstRecord;
                }
            }
            $scope.customFileds.isFiltered = "0";
        }

        function setPagingData() {
            var iPageSlice = 0;
            var iTotalCount = setTotalCount();
            var temp = parseInt($scope.customFileds['Page_Slice'].toString().trim());
            if (!isNaN(temp)){
                iPageSlice = temp;
            }

            $scope.customFileds['Tabbed_Paging']['Pages'] = [];

            if (iTotalCount > iPageSlice) {
                var iStart = 1;

                while (iStart < iTotalCount) {
                    var iEnd = iStart + (iPageSlice - 1);

                    if (iEnd > iTotalCount) {
                        iEnd = iTotalCount;
                    }
                    var tmpPageRange = iStart + "-" + iEnd;
                    $scope.customFileds['Tabbed_Paging']['Pages'].push({
                        Page_Range: tmpPageRange
                    });
                    iStart += iPageSlice;
                }
            } else {
                var tmpPageRange = "";
                if (iTotalCount === 0) {
                    tmpPageRange = "0-" + iTotalCount.toString();

                } else {
                    tmpPageRange = "1-" + iTotalCount.toString();
                }
                $scope.customFileds['Tabbed_Paging']['Pages'].push({
                    Page_Range: tmpPageRange
                });
            }

        }

        function setTotalCount() {
            var iTmpTotalCount = 0;
            var xmlAllNodes =  $scope.DS_PPMT_GET_FILTERED_PROJECTS;// $scope.getValueOfOnLoadData("DS_PPMT_GET_FILTERED_PROJECTS");
            if (xmlAllNodes.length) {
                for (var i = 0; i < xmlAllNodes.length; i++) {
                    var temp = parseInt(xmlAllNodes[i].Value34.toString().trim());
                    if (!isNaN(temp)){
                        iTmpTotalCount = temp;
                    }
                    break;
                }
            }
            $scope.customFileds['Total_Pages'] = iTmpTotalCount;
            return iTmpTotalCount;
        }

        angular.element('#viewFormMainSection').find('.restored').click();

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }
        getDsPpmtGetPicklists();
        setDefaultData();
        
        
        $timeout(function() {
            podbAdjustTableRowHeights();
        }, 10);

        //Trigger click for scrolling of left and right table together
        $timeout(function() {
            angular.element('#Dashboard').triggerHandler('click');//Calls onClickTab() function
        }, 500);
        

        //TODO: Call below function on edit ori
        On_FormEvents_ViewSwitched();
         $scope.update();
    }
    return FormController;
});
