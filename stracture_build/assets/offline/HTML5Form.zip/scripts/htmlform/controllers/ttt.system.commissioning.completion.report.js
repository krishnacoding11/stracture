
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';

    /**
         * removeToobarOptions : @taOptions required,
         * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
         * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
         * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
         */
    var hideOnOutside = function () {
        angular.element('body').on('click', function (event) {
            var $eventTarget = angular.element(event.target),
                targetClassList = event.target.classList,
                targetParentClassList = event.target.parentElement.classList,
                $editorToolbar = angular.element('.artf-editor-toolbar');
            if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
                !$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
                $editorToolbar.find('.font-name').removeClass('open-fonts-list');
            }
            if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
                !$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
                $editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
            }
        });
    }, addTextAngularOptions = function ($provide) {
        $provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
            taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                []
            ];
            return taRegisterTool("backgroundColor", {
                display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                action: function (color) {
                    var me = this;
                    if (this.$editor().wrapSelection) {
                        return this.$editor().wrapSelection("backColor", color)
                    }
                },
                options: {
                    replacerClassName: "fa fa-paint-brush",
                    showButtons: !1
                },
                color: "#fff"
            }),
                taRegisterTool("fontColor", {
                    display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                    action: function (color) {
                        var me = this;
                        if (this.$editor().wrapSelection) {
                            return this.$editor().wrapSelection("foreColor", color)
                        }
                    },
                    options: {
                        replacerClassName: "fa fa-font",
                        showButtons: !1,
                        showAlpha: !1
                    },
                    color: "#000"
                }),
                taRegisterTool('fontName', {
                    display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>" + "</button>",
                    action: function (event, font) {
                        //Ask if event is really an event.					
                        if (!!event.stopPropagation) {
                            //With this, you stop the event of textAngular.
                            event.stopPropagation();
                            //Then click in the body to close the dropdown.
                            angular.element("body").trigger("click");
                        }
                        angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
                        this.$element.toggleClass('open-fonts-list');
                        return this.$editor().wrapSelection('fontName', font);
                    },
                    disabled: function () { },
                    options: [
                        { name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
                        { name: 'Serif', css: "'times new roman', serif" },
                        { name: 'Wide', css: "'arial black', sans-serif" },
                        { name: 'Narrow', css: "'arial narrow', sans-serif" },
                        { name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
                        { name: 'Courier New', css: "'courier new', monospace" },
                        { name: 'Garamond', css: 'garamond, serif' },
                        { name: 'Georgia', css: 'georgia, serif' },
                        { name: 'Tahoma', css: 'tahoma, sans-serif' },
                        { name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
                        { name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
                        { name: 'Verdana', css: 'verdana, sans-serif' },
                        { name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
                    ]
                }),
                taRegisterTool('fontSize', {
                    display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",
                    action: function (event, size) {
                        //Ask if event is really an event.					
                        if (!!event.stopPropagation) {
                            //With this, you stop the event of textAngular.
                            event.stopPropagation();
                            //Then click in the body to close the dropdown.
                            angular.element("body").trigger("click");
                        }
                        angular.element('.open-fonts-list').removeClass('open-fonts-list');
                        this.$element.toggleClass('open-fonts-size-list');
                        return this.$editor().wrapSelection('fontSize', parseInt(size));
                    },
                    disabled: function () { },
                    options: [
                        { name: 'xx-small', css: 'xx-small', value: 1 },
                        { name: 'x-small', css: 'x-small', value: 2 },
                        { name: 'small', css: 'small', value: 3 },
                        { name: 'medium', css: 'medium', value: 4 },
                        { name: 'large', css: 'large', value: 5 },
                        { name: 'x-large', css: 'x-large', value: 6 },
                        { name: 'xx-large', css: 'xx-large', value: 7 }

                    ]
                }),
                taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'), taOptions;
        }
        ]);
    };

    /**
     * configuring and Binding the created text-angular options to the MainModule.
     */
    mainModule.config(function ($translateProvider, $provide) {
        addTextAngularOptions($provide);
        hideOnOutside();
    });

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        //autoSaveDraft timeout from client side
        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId || window.projectId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;
        var ctrl = this;
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var STATIC_OBJ_DATA = {
            Doc_Form_Details: {
                Doc_Form_SeqID: "",
                Doc_Form_SeqHeader: "",
                Document_Details_Grp: {
                    Document_Details: [{
                        Doc_Form_SubSeqId: "",
                        Doc_Rev_ID: "",
                        Doc_ID: "",
                        Form_ID: "",
                        Doc_User_Ref: "",
                        Doc_Form_Title: "",
                        Doc_Form_Status: "",
                        Doc_Form_Workspace: "",
                        Doc_Form_Type: "",
                        Doc_TWEXNET: "",
                        Doc_Dep_Guid: ""
                    }]
                }
            },
            Document_Details: {
                Doc_Form_SubSeqId: "",
                Doc_Rev_ID: "",
                Doc_ID: "",
                Form_ID: "",
                Doc_User_Ref: "",
                Doc_Form_Title: "",
                Doc_Form_Status: "",
                Doc_Form_Workspace: "",
                Doc_Form_Type: "",
                Doc_TWEXNET: "",
                Doc_Dep_Guid: ""
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
        };

        var TTT_CONSTANT = {
            overall_accept_status: "Accepted",
            overall_reject_status: "Rejected",
            issuedstatus: "Accepted",
            reviewInProgress: "Review In Progress",
            tdmwuser: "Tideway Delivery Manager - West",
            tdmcuser: "Tideway Delivery Manager - Central",
            tdmeuser: "Tideway Delivery Manager - East",
            tdmsiuser: "Tideway Delivery Manager - System Integrator",
            cpdwuser: "Contractor's Project Director - West",
            cpdcuser: "Contractor's Project Director - Central",
            cpdeuser: "Contractor's Project Director - East",
            cpdsiuser: "Contractor's Project Director - System Integrator",
            twulrep: "TWUL Representative",
            scm: "System Commissioning Manager",
            scmRoleName: "Tideway SCM",
            popupimage: "popupimage"
        }
        $scope.setflag = function (strflag, strimg) {
            $scope.showhideimage = false;
            $scope.imagedisplay = strimg;
            if (strflag == 'show') {
                $scope.showhideimage = true;
                $('html,body').scrollTop(0);
            }

        }
        /** Initialize db fields */
        $scope.logo = "/images/htmlform/tideway/Alliance_Logo.png";

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.ori_msg_Custom_Fields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.certificate_TDMW_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TDMW_ApprovedBy"];
        $scope.certificate_TDMC_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TDMC_ApprovedBy"];
        $scope.certificate_TDME_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TDME_ApprovedBy"];
        $scope.certificate_TDMSI_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TDMSI_ApprovedBy"];
        $scope.certificate_CPDW_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_CPDW_ApprovedBy"];
        $scope.certificate_CPDC_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_CPDC_ApprovedBy"];
        $scope.certificate_CPDE_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_CPDE_ApprovedBy"];
        $scope.certificate_CPDSI_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_CPDSI_ApprovedBy"];
        $scope.certificate_TWULRep_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TWULRep_ApprovedBy"];
        $scope.certificate_SCM_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_SCM_ApprovedBy"];

        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Get_Dashboard_Formwise_Details');
        var DS_TTT_TIDP_Validate_and_Get_Document_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Validate_and_Get_Document_Details');
        $scope.DS_TTT_GET_PARENT_MSG_RESPONSE_DETAILS = $scope.getValueOfOnLoadData('DS_TTT_GET_PARENT_MSG_RESPONSE_DETAILS');
        var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        $scope.dbFormId = $scope.formdata5['DS_FORMID'];
        $scope.isDraft = $scope.formdata5['DS_ISDRAFT'];
        var submitFlag = false;

        $scope.ori_msg_Custom_Fields.MainTitle = "SYSTEM COMMISSIONING COMPLETION REPORT";
        $scope.setTitle = "PURPOSE & CONDITIONS";
        $scope.setPartNo = "1";

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsWorkingUser = dsWorkingUserId;
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        $scope.roleObj = {
            roletdmc: [],
            roletdme: [],
            roletdmsi: [],
            roletdmw: [],
            rolecpdw: [],
            rolecpde: [],
            rolecpdc: [],
            rolecpdsi: [],
            roletwulrep: []
        };
        var todayDate = '';
        var todayDateDbFormat = '';
        $scope.getServerTime(function (serverDate) {
            todayDate = serverDate;
            todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            initORIview();
        });

        function initORIview() {
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                var isdsIsdraftRes = $scope.formdata5['DS_ISDRAFT_RES'];
                var isdsIsdraftResMsg = $scope.formdata5['DS_ISDRAFT_RES_MSG'];
                if (currentViewName == "ORI_VIEW") {
                    $scope.roleObj.roletdmc = setRolewiseUser(TTT_CONSTANT.tdmcuser);
                    $scope.roleObj.roletdme = setRolewiseUser(TTT_CONSTANT.tdmeuser);
                    $scope.roleObj.roletdmw = setRolewiseUser(TTT_CONSTANT.tdmwuser);
                    $scope.roleObj.roletdmsi = setRolewiseUser(TTT_CONSTANT.tdmsiuser);
                    $scope.roleObj.rolecpdw = setRolewiseUser(TTT_CONSTANT.cpdwuser);
                    $scope.roleObj.rolecpdc = setRolewiseUser(TTT_CONSTANT.cpdcuser);
                    $scope.roleObj.rolecpde = setRolewiseUser(TTT_CONSTANT.cpdeuser);
                    $scope.roleObj.rolecpdsi = setRolewiseUser(TTT_CONSTANT.cpdsiuser);
                    $scope.roleObj.roletwulrep = setRolewiseUser(TTT_CONSTANT.twulrep);

                    var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');

                    //check and discard all draft forms before creating new form.
                    if ($scope.dbFormId != "" && $scope.isDraft == "NO") {
                        $scope.xhr = false;
                        binddocumentList();
                    }
                    if ($scope.dbFormId == "" || $scope.isDraft == "YES") {
                        filluserreflist();
                        $scope.hideSaveDraftButton();
                        $scope.setandvalidatedata($scope.ori_msg_Custom_Fields.Certi_Ref);
                    }
                    if ($scope.ori_msg_Custom_Fields.Certi_Ref == "") {
                        $scope.validatedocumentFlag = true;
                    }

                    //set precise and statements
                    if ($scope.dbFormId == "" && $scope.isDraft == "NO") {

                        $scope.ori_msg_Custom_Fields.Purpose = "<center>This Report presents the evidence to demonstrate that the System Commissioning Completion criteria has been met.</center>";


                        $scope.ori_msg_Custom_Fields.Necessary_condition = "<center>The conditions necessary for completing System Commissioning are detailed in WI 5200 (Commissioning management) and in IA Schedule 13 (Pre-System Commissioning and Commissioning Protocol). The following figures summarise the WI and IA requirements, and lists the evidence used to demonstrate that the conditions have been met. The 'Primary Evidence' listed is attached to this Report.</center>";

                        $scope.ori_msg_Custom_Fields.SCM_Statement = "<b>I</b> have checked Parts 1, 2 and 3 of this Report and <b>I</b> recommend that the System Commissioning Completion Interface Agreement Certificate is issued for signature.";
                    }
                }
                if (currentViewName == "RES_VIEW") {
                    //check and discard all draft forms before creating new form.
                    if (isdsIsdraftResMsg == "NO" && isdsIsdraftRes == "YES") {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEditDraft = true;
                        $scope.formdata5["DS_SEND_MSG"] = "1|You are not authorised to create this form. please click the cancel button at the bottom of the form. \n \n If you want to create the new form than please discard draft forms.";
                        $scope.hideSaveDraftButton();
                        $scope.update();
                        return;
                    } else {
                        $scope.flagIsAllowEditDraft = false;
                        $scope.formdata5["DS_SEND_MSG"] = "0|";
                    }
                    // check assign status for working user.
                    var isrequired = checkPendingAction(dsWorkingUserId);
                    if (isrequired == false) {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEdit = true;
                        $scope.formdata5["DS_SEND_MSG"] = "1|You are not authorised to create or edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                        $scope.hideSaveDraftButton();
                        $scope.update();
                        return;

                    } else {
                        $scope.flagIsAllowEdit = false;
                        $scope.formdata5["DS_SEND_MSG"] = "0|";
                    }
                    $scope.xhr = false;
                    binddocumentList();

                    if (isdsIsdraftRes == "NO" && isdsIsdraftResMsg == "NO") {
                        var dsiNextstage = $scope.ori_msg_Custom_Fields["DSI_NextStage"];
                        $scope.ori_msg_Custom_Fields["DSI_CurrentStage"] = dsiNextstage;

                        // doc and form association wipe out on onload...
                        $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = "";
                        $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = "";
                    }
                    showhidecontentforsignrolewise();
                }
            }
            if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
                angular.element('.export-btn').hide();
                setURLofAssocDoc();
            }
            settabs();
        }
        function setRolewiseUser(rolename) {
            if (DS_PROJUSERS_ROLE.length) {
                var lstcontractor = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                    if (val.Value.split('|')[0].trim() == rolename) {
                        return val.Value;
                    }
                });

                var objroleuser = commonApi.getItemSelectionList({
                    arrayObject: lstcontractor,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
            }
            return objroleuser
        }
        function showhidecontentforsignrolewise() {
            $scope.isShowhidetdmw = false; $scope.isShowhidetdmc = false; $scope.isShowhidetdme = false; $scope.isShowhidetdmsi = false;
            $scope.isShowhidecpdw = false; $scope.isShowhidecpdc = false; $scope.isShowhidecpde = false; $scope.isShowhidecpdsi = false;
            $scope.isShowhiderep = false; $scope.isShowhidescm = false;

            var intTDMW_ApprovedBy_ID = $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_ID;
            var intTDMC_ApprovedBy_ID = $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_ID;
            var intTDME_ApprovedBy_ID = $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_ID;
            var intTDMSI_ApprovedBy_ID = $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_ID;
            var intCPDW_ApprovedBy_ID = $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_ID;
            var intCPDC_ApprovedBy_ID = $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_ID;
            var intCPDE_ApprovedBy_ID = $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_ID;
            var intCPDSI_ApprovedBy_ID = $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_ID;
            var intTWULRep_ApprovedBy_ID = $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_ID;
            var intSCM_ApprovedBy_ID = $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID;

            if (DS_WORKINGUSER_ALL_ROLES) {
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.tdmwuser.toLowerCase()) != -1 && intTDMW_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidetdmw = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.tdmcuser.toLowerCase()) != -1 && intTDMC_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidetdmc = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.tdmeuser.toLowerCase()) != -1 && intTDME_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidetdme = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.tdmsiuser.toLowerCase()) != -1 && intTDMSI_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidetdmsi = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.cpdwuser.toLowerCase()) != -1 && intCPDW_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidecpdw = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.cpdcuser.toLowerCase()) != -1 && intCPDC_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidecpdc = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.cpdeuser.toLowerCase()) != -1 && intCPDE_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidecpde = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.cpdsiuser.toLowerCase()) != -1 && intCPDSI_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidecpdsi = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.twulrep.toLowerCase()) != -1 && intTWULRep_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhiderep = true;
                }
                if (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf(TTT_CONSTANT.scmRoleName.toLowerCase()) != -1 && intSCM_ApprovedBy_ID == $scope.getWorkingUserId()) {
                    $scope.isShowhidescm = true;
                }
            }
        }

        function checkPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            DS_INCOMPLETE_ACTIONS_BYMSG = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Respond";
            });
            if (DS_INCOMPLETE_ACTIONS_BYMSG) {
                for (var i = 0; i < DS_INCOMPLETE_ACTIONS_BYMSG.length; i++) {
                    var strUserId = DS_INCOMPLETE_ACTIONS_BYMSG[i].Value1;

                    if (strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }

        function settabs() {
            $scope.oriviewtabs = [{
                title: 'Purpose & Conditions',
                url: 'purpose.html'
            }, {
                title: 'Statements',
                url: 'Statements.html'
            }, {
                title: 'Package Listing',
                url: 'packageListing.html'
            }]

            $scope.currentOriViewTab = 'purpose.html';
            /****************************************/
            $scope.isActiveTab = function (tabUrl, calledform) {
                if (calledform == "ori_print_view_main") {
                    return tabUrl == $scope.currentOriPrintViewTab;
                } else if (calledform == "ori_view_main") {
                    return tabUrl == $scope.currentOriViewTab;
                }
            }
            /****************************************/

            $scope.setTitle = "PURPOSE & CONDITIONS";
            $scope.setPartNo = "1";
            $scope.onClickTab = function (tab, calledform) {
                var strFlag = "PURPOSE & CONDITIONS",
                    intPartNo = "1";
                if (calledform == "ori_view_main") {
                    $scope.currentOriViewTab = tab.url;
                }
                if (calledform == "ori_print_view_main") {
                    $scope.currentOriPrintViewTab = tab.url;
                }

                if (tab.title == "Statements") {
                    strFlag = "STATEMENTS";
                    intPartNo = "2";
                }
                if (tab.title == "Package Listing") {
                    strFlag = "PACKAGE LISTING";
                    intPartNo = "3";
                }
                $scope.setTitle = strFlag;
                $scope.setPartNo = intPartNo;

                $timeout(function () {
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        }
        $window.TTT_AssociateDocsAndForms = function () {
            if (submitFlag) {
                return false;
            }
            $scope.setflow();
            return true;
        }

        $scope.setflow = function () {
            var currentstage = $scope.ori_msg_Custom_Fields["DSI_CurrentStage"];
            var workingUserName = dsWorkingUser && dsWorkingUser.split(',')[0].trim();
            var workingUserOrg = dsWorkingUser && dsWorkingUser.split(',')[1].trim();
            var strTodayDate = todayDateDbFormat;
            var approver = "";
            var intApproverId = "";
            var strTDMW_Status = $scope.certificate_TDMW_ApprovedBy.TDMW_Status;
            var strTDMC_Status = $scope.certificate_TDMC_ApprovedBy.TDMC_Status;
            var strTDME_Status = $scope.certificate_TDME_ApprovedBy.TDME_Status;
            var strTDMSI_Status = $scope.certificate_TDMSI_ApprovedBy.TDMSI_Status;
            var strCPDW_Status = $scope.certificate_CPDW_ApprovedBy.CPDW_Status;
            var strCPDC_Status = $scope.certificate_CPDC_ApprovedBy.CPDC_Status;
            var strCPDE_Status = $scope.certificate_CPDE_ApprovedBy.CPDE_Status;
            var strCPDSI_Status = $scope.certificate_CPDSI_ApprovedBy.CPDSI_Status;
            var strTWULRep_Status = $scope.certificate_TWULRep_ApprovedBy.TWULRep_Status;
            $scope.formdata5.DS_DB_INSERT = true;

            if (currentstage) {
                switch (currentstage) {
                    case '0':
                        $scope.ori_msg_Custom_Fields["DSI_NextStage"] = "1";

                        //set prepared by details
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID = dsWorkingUserId.split('|')[0];

                        //set distributr id for ORIview
                        $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                        var strdate = commonApi.calculateDistDateFromDays({
                            baseDate: todayDate,
                            days: 10
                        });

                        approver = $scope.ori_msg_Custom_Fields.TDMW_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.TDMC_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.TDME_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.TDMSI_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.CPDW_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.CPDE_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.CPDSI_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.CPDC_Users;
                        checkduplicateandsentaction(approver, strdate);
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_ID = intApproverId;

                        approver = $scope.ori_msg_Custom_Fields.TWUL_Representative;
                        intApproverId = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
                        $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_ID = intApproverId;

                        //update status
                        updateFormStatus(TTT_CONSTANT.reviewInProgress);
                        $scope.formdata5.DS_FORMCONTENT2 = TTT_CONSTANT.overall_accept_status;
                        assocformsanddocs();

                        break;

                    case '1':

                        $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

                        //set user details
                        if (strTDMW_Status == "Yes" && $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_Flag == "") {
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_Name = workingUserName;
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_Position = TTT_CONSTANT.tdmwuser;
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_Flag = "Done";
                        }
                        if (strTDMC_Status == "Yes" && $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_Flag == "") {
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_Name = workingUserName;
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_Position = TTT_CONSTANT.tdmcuser;
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_Flag = "Done";
                        }
                        if (strTDME_Status == "Yes" && $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_Flag == "") {
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_Name = workingUserName;
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_Position = TTT_CONSTANT.tdmeuser;
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_Flag = "Done";
                        }
                        if (strTDMSI_Status == "Yes" && $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_Flag == "") {
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_Name = workingUserName;
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_Position = TTT_CONSTANT.tdmsiuser;
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_Flag = "Done";
                        }
                        if (strCPDW_Status == "Yes" && $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_Flag == "") {
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_Name = workingUserName;
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_Position = TTT_CONSTANT.cpdwuser;
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_Flag = "Done";
                        }
                        if (strCPDE_Status == "Yes" && $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_Flag == "") {
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_Name = workingUserName;
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_Position = TTT_CONSTANT.cpdeuser;
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_Flag = "Done";
                        }
                        if (strCPDC_Status == "Yes" && $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_Flag == "") {
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_Name = workingUserName;
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_Position = TTT_CONSTANT.cpdcuser;
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_Flag = "Done";
                        }
                        if (strCPDSI_Status == "Yes" && $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_Flag == "") {
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_Name = workingUserName;
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_Position = TTT_CONSTANT.cpdsiuser;
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_Flag = "Done";
                        }

                        var strdate = commonApi.calculateDistDateFromDays({
                            baseDate: todayDate,
                            days: 10
                        });

                        // sending for info action to originator...
                        setDistribution($scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID, "7#For Information", "13", strdate);

                        var form = {
                            "projectId": $scope.projectId,
                            "formId": $scope.formId,
                            "fields": "DS_ASI_GET_MSG_ALL_ACTIONS_INCOMPLETE",
                            "callbackParamVO": {
                                "customFieldVOList": [{
                                    "fieldName": "DS_ASI_GET_MSG_ALL_ACTIONS_INCOMPLETE",
                                    "fieldValue": "ORI001" // uimsgid
                                }]
                            }
                        };
                        submitFlag = false;
                        $scope.getCallbackData(form).then(function (response) {
                            if (response.data) {
                                var data = JSON.parse(response.data['DS_ASI_GET_MSG_ALL_ACTIONS_INCOMPLETE']);
                                if (data.Items && data.Items.Item) {
                                    var strAllData = data.Items.Item;
                                    strAllData = commonApi._.filter(strAllData, function (val) {
                                        return val.Value4 == "Respond";
                                    });
                                    if (strAllData.length == 1 && strAllData[0].Value1 == dsWorkingUserId) {
                                        $scope.ori_msg_Custom_Fields["DSI_NextStage"] = "2";
                                        var twulApprover = $scope.ori_msg_Custom_Fields.TWUL_Representative;
                                        strdate = commonApi.calculateDistDateFromDays({
                                            baseDate: todayDate,
                                            days: 10
                                        });
                                        checkduplicateandsentaction(twulApprover, strdate);
                                    }
                                    validatemandatoryfields();
                                }
                            }
                        });
                        break;
                    case '2':
                        if (strTWULRep_Status == "Yes" && $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_Flag == "") {
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_Date = strTodayDate;
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_Name = workingUserName;
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_ID = dsWorkingUserId.split('|')[0];;
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_Position = TTT_CONSTANT.twulrep;
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_onbehalfof = workingUserOrg;
                            $scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_Flag = "Done";

                            strdate = commonApi.calculateDistDateFromDays({
                                baseDate: todayDate,
                                days: 10
                            });
                            $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

                            // sending for info action to originator...
                            setDistribution($scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID, "7#For Information", "13", strdate);
                        
                            approver = $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID;
                            setDistribution(approver, "3#Respond", "13", strdate);
                            $scope.formdata5['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                            $scope.ori_msg_Custom_Fields["DSI_NextStage"] = "3";
                        }
                        break;
                    case '3':
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_Date = strTodayDate;
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_Name = workingUserName;
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_Position = TTT_CONSTANT.scm;
                        $scope.certificate_SCM_ApprovedBy.SCM_ApprovedBy_onbehalfof = workingUserOrg;

                        $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

                        strdate = commonApi.calculateDistDateFromDays({
                            baseDate: todayDate,
                            days: 10
                        });

                        // set for info to all users...
                        setDistribution($scope.certificate_TDMW_ApprovedBy.TDMW_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_TDMC_ApprovedBy.TDMC_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_TDME_ApprovedBy.TDME_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_TDMSI_ApprovedBy.TDMSI_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_CPDW_ApprovedBy.CPDW_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_CPDE_ApprovedBy.CPDE_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_CPDSI_ApprovedBy.CPDSI_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_CPDC_ApprovedBy.CPDC_ApprovedBy_ID, "7#For Information", "13", strdate);

                        setDistribution($scope.certificate_TWULRep_ApprovedBy.TWULRep_ApprovedBy_ID, "7#For Information", "13", strdate);

                        updateFormStatus(TTT_CONSTANT.issuedstatus);
                        break;
                }
            }
            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] != '1') {
                validatemandatoryfields();
            }
        }

        function checkduplicateandsentaction(approver, strdate) {
            var isDuplicate = "";
            var approverVal = approver ? approver.split('|')[2].trim().split(' ')[0] : '';
            var strView = "";

            isDuplicate = checkDuplicateData(approverVal);
            if (isDuplicate == 1) {
                if (currentViewName == 'ORI_VIEW') {
                    strView = "3";
                } else {
                    strView = "13";
                }
                setDistribution(approverVal, "3#Respond", strView, strdate);
            }
        }

        function validatemandatoryfields() {
            var strtdmw = $scope.ori_msg_Custom_Fields.TDMW_Users;
            var strtdmc = $scope.ori_msg_Custom_Fields.TDMC_Users;
            var strtdme = $scope.ori_msg_Custom_Fields.TDME_Users;
            var strtdmsi = $scope.ori_msg_Custom_Fields.TDMSI_Users;
            var strcpdw = $scope.ori_msg_Custom_Fields.CPDW_Users;
            var strcpdc = $scope.ori_msg_Custom_Fields.CPDC_Users;
            var strcpde = $scope.ori_msg_Custom_Fields.CPDE_Users;
            var strcpdsi = $scope.ori_msg_Custom_Fields.CPDSI_Users;
            var strrep = $scope.ori_msg_Custom_Fields.TWUL_Representative;

            submitFlag = true;

            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '0') {
                if (strtdmw == '' || strtdmc == '' || strtdme == '' || strtdmsi == '' || strcpdw == '' || strcpdc == '' || strcpde == '' || strcpdsi == '' || strrep == '' || !$scope.ori_msg_Custom_Fields.TDMReference || !$scope.ori_msg_Custom_Fields.Purpose || !$scope.ori_msg_Custom_Fields.Necessary_condition) {
                    submitFlag = false;
                    $window.alert('Validation\n\n Please fill mandatory field(s)!');
                }
            }

            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '1') {
                if (($scope.isShowhidetdmw != false && $scope.certificate_TDMW_ApprovedBy.TDMW_Status != 'Yes') ||
                    ($scope.isShowhidetdmc != false && $scope.certificate_TDMC_ApprovedBy.TDMC_Status != 'Yes') ||
                    ($scope.isShowhidetdme != false && $scope.certificate_TDME_ApprovedBy.TDME_Status != 'Yes') ||
                    ($scope.isShowhidetdmsi != false && $scope.certificate_TDMSI_ApprovedBy.TDMSI_Status != 'Yes') ||
                    ($scope.isShowhidecpdw != false && $scope.certificate_CPDW_ApprovedBy.CPDW_Status != 'Yes') ||
                    ($scope.isShowhidecpdc != false && $scope.certificate_CPDC_ApprovedBy.CPDC_Status != 'Yes') ||
                    ($scope.isShowhidecpde != false && $scope.certificate_CPDE_ApprovedBy.CPDE_Status != 'Yes') ||
                    ($scope.isShowhidecpdsi != false && $scope.certificate_CPDSI_ApprovedBy.CPDSI_Status != 'Yes')) {
                    submitFlag = false;
                    $window.alert('Validation\n\n Please fill mandatory field(s)!');
                }
            }

            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '2') {
                if ($scope.isShowhiderep != false && $scope.certificate_TWULRep_ApprovedBy.TWULRep_Status != 'Yes') {
                    submitFlag = false;
                    $window.alert('Validation\n\n Please fill mandatory field(s)!');
                }
            }

            if ($scope.ori_msg_Custom_Fields["DSI_CurrentStage"] == '3') {
                if ($scope.isShowhidescm != false && $scope.certificate_SCM_ApprovedBy.SCM_Status != 'Yes' || !$scope.ori_msg_Custom_Fields.SCM_Statement) {
                    submitFlag = false;
                    $window.alert('Validation\n\n Please fill mandatory field(s)!');
                }
            }

            if (submitFlag == true) {
                $window.submitForm(1);
            }
        }

        function checkDuplicateData(username) {
            var stralldata = $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'];
            var validatedata = "";
            if (username != "") {
                validatedata = commonApi._.filter(stralldata, function (obj) {
                    return username.indexOf(obj.DS_PROJDISTUSERS) > -1;
                });
                if (validatedata.length) {
                    return 0;
                }
            }
            return 1;
        }

        /**
         * set URL for associated doc in printview
         * These URL comes from SP
         */
        function setURLofAssocDoc() {
            var AssocDocdata = $scope.getValueOfOnLoadData('DS_GEN_DOC_ASSOCIATIONS_CROSS_DC_LIST');
            var AssocFormdata = $scope.getValueOfOnLoadData('DS_GEN_FORM_ASSOCIATIONS_CROSS_DC_LIST');
            var elem2 = null, element3 = null, element4 = null, element = null;

            for (var m = 0; m < $scope.ori_msg_Custom_Fields['Doc_Form_Grp']['Doc_Form_Details'].length; m++) {
                element = $scope.ori_msg_Custom_Fields['Doc_Form_Grp']['Doc_Form_Details'][m];

                for (var n = 0; n < element['Document_Details_Grp']['Document_Details'].length; n++) {
                    elem2 = element['Document_Details_Grp']['Document_Details'][n];

                    for (var j = 0; j < AssocDocdata.length; j++) {
                        element3 = AssocDocdata[j];
                        if (element3.Value18 == elem2.Doc_ID) {
                            elem2.Doc_Rev_Link = element3.URL15;
                        }
                    }
                    for (var l = 0; l < AssocFormdata.length; l++) {
                        element4 = AssocFormdata[l];
                        if (element4.Value8 == elem2.Form_ID) {
                            elem2.Doc_Rev_Link = element4.URL11;
                        }
                    }
                }
            }
        }

        function assocformsanddocs() {
            var assoFormsStr = ':#';
            var assoDocsStr = "";
            var strdsvalidatedocumentdata = DS_TTT_TIDP_Validate_and_Get_Document_Details;
            for (var index = 0; index < strdsvalidatedocumentdata.length; index++) {
                var strvalidate = strdsvalidatedocumentdata[index].Value1.trim();
                if (strvalidate == "0") {
                    var assocflag = strdsvalidatedocumentdata[index].Value16;
                    if (assocflag == 'Yes') {
                        if (strdsvalidatedocumentdata[index].Value15 != "") {
                            if (assoFormsStr == ":#") {
                                assoFormsStr += ':' + strdsvalidatedocumentdata[index].Value15;
                            } else {
                                assoFormsStr += ',:' + strdsvalidatedocumentdata[index].Value15;
                            }
                        }
                        if (strdsvalidatedocumentdata[index].Value7 != "") {
                            assoDocsStr += strdsvalidatedocumentdata[index].Value7 + "#" + strdsvalidatedocumentdata[index].Value14 + "#" + strdsvalidatedocumentdata[index].Value13 + ",";
                        }
                    }
                }
            }
            if (assoFormsStr.length > 2) {
                $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = assoFormsStr;
            }
            $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = assoDocsStr;
        }

        function updateFormStatus(StrStatus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: StrStatus.toLowerCase()
            });
            $scope.formdata5['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
        }

        function setDistribution(UsertoDist, Action, DS_AUTODist, strDate) {
            var tempList = [];

            tempList.push({
                strUser: UsertoDist,
                strAction: Action,
                strDate: strDate
            });

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: DS_AUTODist
            });
        }

        function filluserreflist() {
            $scope.objuserref = [];
            var element = $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details;
            for (var index = 0; index < element.length; index++) {
                if (element[index].Value2 && element[index].Value3) {
                    var struserref = element[index].Value2.trim();
                    var strguid = element[index].Value3.trim();
                    var strconcate = struserref + "||" + strguid;
                    $scope.objuserref.push({
                        optlabel: "",
                        options: [{
                            displayValue: struserref,
                            modelValue: strconcate,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.setandvalidatedata = function (strcerti) {
            if (strcerti) {
                var strGUID = strcerti.split("||")[1].trim();
                $scope.ori_msg_Custom_Fields.ORI_USERREF = strcerti.split("||")[0].trim();
                $scope.ori_msg_Custom_Fields.Cer_GUID = strGUID;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strcerti.split("||")[0].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strcerti.split("||")[1].trim();
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": "DS_TTT_TIDP_Validate_and_Get_Document_Details",
                        "fieldValue": strGUID
                    }],
                    successCallback: getcallbackcertidata
                };
                $scope.xhr = true;
                $scope.getCallbackSPdata(spParam);
            }
        }
        function getcallbackcertidata(responseList) {
            $scope.xhr = false;
            if (responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"]) {
                DS_TTT_TIDP_Validate_and_Get_Document_Details = responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"];
                $scope.ori_msg_Custom_Fields.ORI_FORMTITLE = DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value20;
            }
            binddocumentList();
        }

        function binddocumentList() {
            if (DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value1 == '1') {
                $scope.validatedocumentFlag = true;
                $scope.formdata5["DS_SEND_MSG"] = '1|You can not create/update the form.Please verify validation message.';
                $scope.hideSaveDraftButton();
            }
            else {
                var objSaveDraftBtn = document.getElementById('btnSaveDraft');
                $scope.validatedocumentFlag = false;
                $scope.formdata5["DS_SEND_MSG"] = '0|';
                setDocumentFormHeaders(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                setDocumentFormdetails(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                objSaveDraftBtn && (objSaveDraftBtn.style.display = 'inline-block');
            }
        }
        function onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
        }

        function setDocumentFormHeaders(dsvalidatedocumentdata) {
            //$scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details.Document_Details_Grp.Document_Details = [];
            $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details = [];
            var insertPointparent = $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details,
                strdocumentdet = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    var unique = [];
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();
                        if (strvalidate == "0") {
                            var strheader = dsvalidatedocumentdata[index].Value10.trim() + "|$|" + dsvalidatedocumentdata[index].Value11.trim();
                            unique.push(strheader);
                        }
                    }
                    if (unique.length) {
                        unique = unique.filter(onlyUnique);
                        for (var i = 0; i < unique.length; i++) {
                            var seqnum = unique[i].split('|$|')[0].trim();
                            var seqheader = unique[i].split('|$|')[1].trim();
                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Doc_Form_Details);
                            strdocumentdet.Doc_Form_SeqID = seqnum;
                            strdocumentdet.Doc_Form_SeqHeader = seqheader;
                            insertPointparent.push(strdocumentdet);
                        }
                    }
                }
            }
        }
        function setDocumentFormdetails(dsvalidatedocumentdata) {
            var strdocumentdet = "";
            var seqcount, headerseqold = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();

                        if (strvalidate == "0") {
                            var strheaderseq = dsvalidatedocumentdata[index].Value10.trim()
                            var strheadertitle = dsvalidatedocumentdata[index].Value11.trim();

                            var insertPoint = commonApi._.filter($scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details, function (Obj) {
                                return Obj.Doc_Form_SeqID == strheaderseq && Obj.Doc_Form_SeqHeader == strheadertitle;
                            });

                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Document_Details);
                            if (strheaderseq == headerseqold) {
                                seqcount = seqcount + 1;
                            }
                            else {
                                seqcount = 1;
                            }
                            var checksubseqid = insertPoint[0]['Document_Details_Grp']['Document_Details'][0]['Doc_Form_SubSeqId'];
                            if (checksubseqid == "") {
                                insertPoint[0]['Document_Details_Grp']['Document_Details'] = [];
                            }
                            strdocumentdet.Doc_Form_SubSeqId = strheaderseq + "." + seqcount;
                            strdocumentdet.Doc_Form_Title = dsvalidatedocumentdata[index].Value2;
                            strdocumentdet.Doc_Form_Status = dsvalidatedocumentdata[index].Value4;
                            strdocumentdet.Doc_User_Ref = dsvalidatedocumentdata[index].Value3;
                            strdocumentdet.Doc_Form_Type = dsvalidatedocumentdata[index].Value6;
                            strdocumentdet.Doc_Form_Workspace = dsvalidatedocumentdata[index].Value5;
                            strdocumentdet.Form_ID = dsvalidatedocumentdata[index].Value9;
                            strdocumentdet.Doc_Rev_Link = dsvalidatedocumentdata[index].URL17;
                            strdocumentdet.Doc_Rev_ID = dsvalidatedocumentdata[index].Value12;
                            strdocumentdet.Doc_ID = dsvalidatedocumentdata[index].Value7; //Value7 stores Doc db Revision_Id
                            strdocumentdet.Doc_Dep_Guid = dsvalidatedocumentdata[index].Value18;

                            insertPoint[0]['Document_Details_Grp']['Document_Details'].push(strdocumentdet);

                            headerseqold = strheaderseq;
                        }
                    }
                }
            }
        }

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}

function customHTMLMethodBeforeCreate_RES() {

    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}
