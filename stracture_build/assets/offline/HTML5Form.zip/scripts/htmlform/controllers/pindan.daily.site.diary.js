/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/number-format', '../components/table.util'], function(angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var currServerDate = '';
        $scope.getServerTime(function(serverDate) {
            currServerDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;

        var RESTRICT_CHAR_MSG = "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #";

        var STATIC_OBJ_DATA = {
            DS_Stoppage_Detail: {
                isSelected: false,
                Stoppage: "",
                Stoppage_Reason: "",
                Stoppage_Comments: ""
            },
            DS_Visitor_Details: {
                VD_isSelected: false,
                Visitor_Name: "",
                Visitor_Organisation: "",
                Visit_Reason: "",
                Visitor_Time_Onsite: "",
                Notices_Issued: "",
                Notice_Type: "",
                Notice_Attachment: "",
                Notice_Comments: "",
                DS_VGroup: {
                    DS_NIssuedGroup: ""
                }
            },
            DS_Plant_Details: {
                PS_isSelected: false,
                Plant_on_Site: "",
                Owned_or_Subcontractor: "",
                Activity_Comments_Charges: "",
                Plant_No: "",
                DS_isPlantNew: ""
            },
            DS_Employee_Details: {
                ED_isSelected: false,
                Employee_No: "",
                Employee_Hours: "",
                Employee_Duties: "",
                Employee_Name: "",
                DS_Employee_Total: ""
            },
            DS_Worker_Details: {
                WD_isSelected: false,
                Trade_on_site: "",
                Trade_Worker_No: "",
                Worker_Hours: "",
                Worker_Duties: "",
                DS_Worker_Total: "",
                DS_isNew: ""
            },
            DS_Waste_Tracking: {
                Wst_isSelected: false,
                Waste_Tracking_No: "",
                Waste_date: "",
                Waste_IandE: "",
                Waste_DescOfMaterial: "",
                Waste_Classification: "",
                Waste_Volume: "",
                Waste_Weight: "",
                Waste_DisposalSrcLoc: "",
                WasteAndMaterialPickList: []
            },
            DS_Inductions: {
                Ind_isSelected: "false",
                Induction_No: "",
                Total_Inducted: ""
            },
            DS_Injury_Details: {
                Name: '',
                Gender: '',
                Date_of_Birth: '',
                Occupation: '',
                Employer: '',
                Supervisor: '',
                First_aid_provided: '',
                First_aid_by: '',
                First_aid_details: '',
                Injury_Outcome: '',
                Medical_aid_provided: '',
                Medical_aid_by: '',
                Medical_aid_details: '',
                Body_Location: '',
                Body_Location_Side: '',
                Nature_of_Injury: '',
                Mechanics_of_Injury: '',
                Agency_of_Injury: ''
            },
            DS_All_Witnesses: {
                Witness_Name: '',
                Witness_Contact_details: ""
            }
        };

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.disabledDate = false;
        $scope.requests = {};

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.tableUtilSettings = {
            DS_Stoppage_Detail: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Stoppage_Detail),
                ADD_NEW_BEFORE_TIP: "Insert before Stoppage Detail",
                ADD_NEW_AFTER_TIP: "Insert after Stoppage Detail",
                deleteAllRowTooltip: "Remove all Stoppage Detail",
                deleteCurrRowMsg: "Remove Stoppage Detail",
                deleteSelectedMsg: "Remove selected Stoppage Detail"
            },
            DS_Visitor_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "VD_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Visitor_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Visitor Record",
                ADD_NEW_AFTER_TIP: "Insert after Visitor Record",
                deleteAllRowTooltip: "Remove all Visitor Records",
                deleteCurrRowMsg: "Remove Visitor Record",
                deleteSelectedMsg: "Remove selected Visitor Record"
            },
            DS_Plant_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "PS_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Plant_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Plant Detail",
                ADD_NEW_AFTER_TIP: "Insert after Plant Detail",
                deleteAllRowTooltip: "Remove all Plant Detail",
                deleteCurrRowMsg: "Remove Plant Detail",
                deleteSelectedMsg: "Remove selected Plant Detail"
            },
            DS_Employee_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "ED_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Employee_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Employee Detail",
                ADD_NEW_AFTER_TIP: "Insert after Employee Detail",
                deleteAllRowTooltip: "Remove all Employee Detail",
                deleteCurrRowMsg: "Remove Employee Detail",
                deleteSelectedMsg: "Remove selected Employee Detail",
                addItemCallBack: employeeCallBackForUtil,
                deleteItemCallBack: employeeCallBackForUtil
            },
            DS_Worker_Details: {
                tooltip: "select to remove/remove all data",
                hasDefaultRecord: true,
                checkboxModelKey: "WD_isSelected",
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Worker_Details),
                deleteAllRowTooltip: "Remove all Work Detail",
                deleteCurrRowMsg: "Remove Work Detail",
                deleteSelectedMsg: "Remove selected Work Detail"

            },
            DS_Inductions: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "Ind_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DS_Inductions),
                ADD_NEW_BEFORE_TIP: "Insert before Induction Detail",
                ADD_NEW_AFTER_TIP: "Insert after Induction Detail",
                deleteAllRowTooltip: "Remove all Induction Detail",
                deleteCurrRowMsg: "Remove Induction Detail",
                deleteSelectedMsg: "Remove selected Induction Detail"
            }
        }

        $scope.structDistribution = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        };

        function employeeCallBackForUtil() {
            $timeout(function() {
                $scope.countDirectEmployeeNo();
                $scope.countDirectEmployeeHours();
            });
        }

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];

        $scope.dsAllStepFields = $scope.formCustomFields["DS_ALL_STEP_FIELDS"];
        $scope.dsStep1Fields = $scope.formCustomFields["DS_STEP1_FIELDS"];
        $scope.dsStep2Fields = $scope.formCustomFields["DS_STEP2_FIELDS"];

        var dsAllActiveFormStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var dsProjUsersAllRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');

        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';


        //var dsAllFormStatus = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }


        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        // to get Custom Attribute On Load.
        var logo = commonApi._.findWhere(dsAsiConfigurableAttributes, {
            Value3: "Logo",
            Value7: "Logo"
        }) || {};
        $scope.dsAllStepFields['DS_Is_Complaint_Required'] = 'Yes';
        $scope.dsAllStepFields['DS_Is_Waste_Tracking_Required'] = 'Yes';
        $scope.solidLiquidArrayForTitle = {
            S: 'Solid (S)',
            L: 'Liquid (L)',
            P: 'Sludge (P)',
            M: 'Mixture (M)'
        };
        var picklistData = [];
        initFormsData();

        var tmpVisitorOrgList = [];
        var tmpIncidentTypelist = [];
        var tmpTradeAttributedlist = [];
        var tmpInjuryTypeList = [];
        var tmpInjuryClassificationList = [];
        var tmpBody_LocationList = [];
        var tmpHazard_CategoryList = [];
        var tmpComplaint_SourceList = [];
        var tmpComplaint_TypeList = [];
        var tmpBody_Location_Sidelist = [];
        var tmpMechanics_of_Injurylist = [];
        var tmpAgency_of_Injurylist = [];
        var tmpTradelist = [];

        for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
            var element = dsAsiConfigurableAttributes[index];

            if (element.Value3 === "Visitor Organisation") {
                tmpVisitorOrgList.push(element);
            } else if (element.Value3 === "Incident_Category") {
                tmpIncidentTypelist.push(element);
            } else if (element.Value3 === "Site Diary Worker List") {
                tmpTradeAttributedlist.push(element);
            } else if (element.Value3 === "Incident_Nature_of_Injury") {
                tmpInjuryTypeList.push(element);
            } else if (element.Value3 === "Incident_Classification") {
                tmpInjuryClassificationList.push(element);
            } else if (element.Value3 === "Incident_Body_Location") {
                tmpBody_LocationList.push(element);
            } else if (element.Value3 === "Hazard_Category") {
                tmpHazard_CategoryList.push(element);
            } else if (element.Value3 === "Complaint Source") {
                tmpComplaint_SourceList.push(element);
            } else if (element.Value3 === "Complaint_Issue_Category") {
                tmpComplaint_TypeList.push(element);
            } else if (element.Value3 === "Incident_Body_Location_Side") {
                tmpBody_Location_Sidelist.push(element);
            } else if (element.Value3 === "Incident_Mechanics_of_Injury") {
                tmpMechanics_of_Injurylist.push(element);
            } else if (element.Value3 === "Incident_Agency_of_Injury") {
                tmpAgency_of_Injurylist.push(element);
            } else if (element.Value3 === "Trade") {
                tmpTradelist.push(element);
            }
        }

        $scope.visitorOrglist = tmpVisitorOrgList;
        $scope.IncidentTypelist = tmpIncidentTypelist;
        $scope.TradeAttributedlist = tmpTradeAttributedlist;
        $scope.InjuryTypeList = tmpInjuryTypeList;
        $scope.InjuryClassificationList = tmpInjuryClassificationList;
        $scope.Body_LocationList = tmpBody_LocationList;
        $scope.Hazard_CategoryList = tmpHazard_CategoryList;
        $scope.Complaint_SourceList = tmpComplaint_SourceList;
        $scope.Complaint_TypeList = tmpComplaint_TypeList;
        $scope.Body_Location_Sidelist = tmpBody_Location_Sidelist;
        $scope.Mechanics_of_Injurylist = tmpMechanics_of_Injurylist;
        $scope.Agency_of_Injurylist = tmpAgency_of_Injurylist;
        $scope.Tradelist = tmpTradelist;

        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] == '') {
            showAllWorkerDetails();
        }

        $scope.dsPydDsdChkData = [];
        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] && currentViewName == 'ORI_PRINT_VIEW') {
            $scope.dsPydDsdChkData = $scope.getValueOfOnLoadData('DS_PYD_DSD_CHK_GET_ALL_REGSTR_DTL');
        }

        /***** Initialize db fields ******/
        $scope.update();

        function prepareTemperatureList() {
            var availTempList = [];
            for (var t = -2; t < 46; t++) {
                availTempList.push(t + '');
            }
            return availTempList;
        }

        function initFormsData() {
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_DB_INSERT = 'false';
            if (currentViewName == "ORI_VIEW" && $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] != '' && $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT == 'NO') {
                $scope.disabledDate = true;
            } else if (currentViewName == "ORI_VIEW" && $scope.dsStep1Fields['Date_Created'] !== "" && $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT == 'YES') {
                dateCreatedOnChange();
            }

            $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['DS_AUTOCREATE_FORM'] = '';

            delete $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['ACF_01_FORM'];
            removeUnnecesoryAutoFields(1);
            fetchPicklistData();
            if (currentViewName == "ORI_VIEW") {
                $scope.availTempList = prepareTemperatureList();
                $scope.dsAllStepFields.DS_Logo = logo.Value8 || '/images/asiteWhite60x200.png';
            }
        }

        $scope.wamPicklistChange = function(item, currRow) {

            currRow['Waste_Classification'] = "";

            for (var i = 0; i < picklistData.length; i++) {
                if (picklistData[i].Value5 == item.displayValue) {
                    currRow['waste_classificationList'] = picklistData[i].Name.split(',');
                }
            }

        }

        function fetchPicklistData() {
            picklistData = $scope.getValueOfOnLoadData('DS_PYD_GET_SITE_DIARY_PICKLIST');
            var tmpData = [];
            var tmpGroupData = [];

            for (var i = 0; i < picklistData.length; i++) {
                if (picklistData[i].Value3 == 0) {
                    tmpGroupData.push({
                        name: picklistData[i].Value5,
                        id: picklistData[i].Value2
                    });
                }
            }

            var tempOptionData = [];
            for (var k = 0; k < tmpGroupData.length; k++) {
                var tmpData = [];
                for (var i = 0; i < picklistData.length; i++) {
                    if (tmpGroupData[k].id == picklistData[i].Value3) {
                        tmpData.push({
                            displayValue: picklistData[i].Value5,
                            modelValue: picklistData[i].Value5,
                            checked: false
                        });
                    }
                }

                tempOptionData.push({
                    optlabel: tmpGroupData[k].name,
                    options: tmpData
                });
            }
        }

        var setAutoDistributionNodes = function(strUser, strAction) {
            var structDistribution = angular.copy($scope.structDistribution)
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            $scope.data['myFields']['Asite_System_Data_Read_Write']["ORI_MSG_Fields"]["DS_AutoDistribute_User_Group"]["DS_AutoDistribute_Users"].push(structDistribution);
        };

        function setRolewiseDistribution(strRole) {

            var strusers = commonApi._.filter(dsProjUsersAllRoles, function(val) {
                return val.Value.toLowerCase().indexOf(strRole.toLowerCase()) != -1
            });

            if (strusers && strusers.length) {
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter(dsProjDistUsers, function(val) {
                        return val.Value.indexOf(strUserId) != -1
                    })[0];

                    if (strdisuser && strdisuser.Value) {
                        setAutoDistributionNodes(strdisuser.Value, '7#');
                    }
                }
            }
        }

        // Load Worker Details data from Custom Attributes
        function showAllWorkerDetails() {
            $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'] = [];
            var strPlantNameCategory = $scope.dsStep1Fields['DS_Worker_Attribute_Name'];
            strPlantNameCategory = strPlantNameCategory && strPlantNameCategory.trim();

            var dataPlantDetails = commonApi._.filter(dsAsiConfigurableAttributes, function(element) {
                return element.Value3 === strPlantNameCategory
            });

            for (var index = 0; index < dataPlantDetails.length; index++) {
                var element = dataPlantDetails[index];
                var tmpNomde = angular.copy(STATIC_OBJ_DATA.DS_Worker_Details);
                tmpNomde.Trade_on_site = element.Value8;
                tmpNomde.DS_isNew = 'No';

                $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'].push(tmpNomde);
            }
        }


        $scope.checkDuplicateValueForEvent = function(args) {
            var strVal = args.curObj[args.objName];
            var cureentIndex = args.repeatObj.indexOf(args.curObj);
            angular.forEach(args.repeatObj, function(item, index) {
                if (cureentIndex != index && strVal != "" && item[args.objName] == strVal) {
                    alert("Duplicate " + args.msg + " selected !!! \n\n Select a different " + args.msg);
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }

        $scope.inValidDate = false;
        $scope.isXHRon = false;
        $scope.dateCreatedOnChange = dateCreatedOnChange;

        function dateCreatedOnChange() {
            $scope.inValidDate = false;
            $scope.isXHRon = false;
            $scope.disabledDate = false;

            var selectedDate = $scope.dsStep1Fields['Date_Created'];
            selectedDate = new Date(selectedDate);
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dayName = days[selectedDate.getDay()];

            $scope.dsStep1Fields['Site_Diary_Day'] = dayName;

            if ($scope.dsStep1Fields['Date_Created'] == '') {
                return;
            }

            var formatedDate = $scope.formatDate(selectedDate, 'dd/mm/yy');
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.ORI_FORMTITLE = $scope.data.myFields.Asite_System_Data_Read_Only['_3_Project_Data']["DS_PROJECTNAME"] + " :: Site Diary :: " + formatedDate;

            var dataSourceName = "DS_PD_DSD_CHK_GET_ALL_REGSTR_DTL";
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": $scope.dsStep1Fields['Date_Created']
                    }]
                }
            };

            $scope.requests['chkDateFetchRegstrData'] = true;
            $scope.add({
                name: "chkDateFetchRegstrData",
                status: "incomplete"
            });

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function(response) {
                var resData = response.data;
                $scope.isXHRon = false;

                $scope.requests['chkDateFetchRegstrData'] = false;
                $scope.update({
                    name: "chkDateFetchRegstrData",
                    status: "completed"
                });

                if (resData) {
                    var spData = angular.fromJson(response.data[dataSourceName]);
                    spData = spData['Items']["Item"] || [];

                    if (!spData.length) {
                        return;
                    }

                    if (spData[0] && spData[0].Value2 === 'Yes') {
                        $scope.inValidDate = true;
                    } else {
                        $scope.disabledDate = true;
                    }
                }
            });
        }

        $scope.restrictCharOnlyNumber = function() {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(RESTRICT_CHAR_MSG);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }

        }

        //if item is deleted than make one entry mandatory
        $scope.deleteItem = function(obj, repeatingData) {

            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);

        };

        $scope.restrictCharOnlyNumberPaste = function(event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                event.preventDefault();
                return false;
            }
        };

        $scope.dateRepotedValidation = function(parentNode, reportedDate, matchDate) {
            if (reportedDate && matchDate) {
                var reportedDateObj = commonApi.parseDate('yy-mm-dd', parentNode[reportedDate]);
                var matchDateObj = commonApi.parseDate('yy-mm-dd', parentNode[matchDate]);

                if (matchDateObj && reportedDateObj && matchDateObj.getTime() > reportedDateObj.getTime()) {
                    parentNode[reportedDate] = "";
                    $window.alert("Validation \n\n Date reported should be greater than Incident date.");
                }
            }
        }

        $scope.incidentTimeValidation = function(currFields) {
            var formObj = $scope.myform;
            formObj['Inc_Incident_Time'].$setValidity('valid', true);
            formObj['Inc_Time_Reported'].$setValidity('valid', true);

            var dateOfIncident = $scope.modelData['DS_Incident_Date'];
            var dateOfReported = $scope.modelData['DS_Date_Reported'];

            var timeOfIncident = $scope.modelData['Incident_Time'];
            var timeOfReported = $scope.modelData['Time_Reported'];

            if (dateOfIncident && dateOfReported && dateOfIncident == dateOfReported && timeOfIncident && timeOfReported) {
                var incDate = commonApi.parseDate('yy-mm-dd', dateOfIncident);
                var repDate = commonApi.parseDate('yy-mm-dd', dateOfReported);

                var incTime = get24HrDate(timeOfIncident);
                var repTime = get24HrDate(timeOfReported);

                var incDateParse = mergeTimeInDate(incDate, incTime);
                var repDateParse = mergeTimeInDate(repDate, repTime);

                if (incDateParse > repDateParse) {
                    if (currFields) {
                        formObj[currFields].$setValidity('valid', false);
                    } else {
                        formObj['Inc_Incident_Time'].$setValidity('valid', false);
                        formObj['Inc_Time_Reported'].$setValidity('valid', false);
                    }
                }
            }
        }

        function get24HrDate(strTime) {
            var tmpTime = strTime.split(':');
            if (strTime.indexOf('PM') > -1 && tmpTime[0] < 12) {
                tmpTime[0] = parseInt(tmpTime[0]) + 12;
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            } else {
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }
        }

        function mergeTimeInDate(dateObj, timeArray) {
            dateObj.setHours(timeArray[0]);
            dateObj.setMinutes(timeArray[1]);

            return dateObj;
        }


        /***
         * This function to auto fill the specific data from the previous active form section wise as well all sections data.
         * set Previous form's historic data section wise code : START
         */

        $scope.spXhr = {
            'DS_PYD_DSD_GET_PREVIOUS_FORM_VISITOR_DETAILS': false,
            'DS_PYD_DSD_GET_PREVIOUS_FORM_PLANT_DETAILS': false,
            'DS_PYD_DSD_GET_PREVIOUS_FORM_DIRECT_EMPLOYEE_DETAILS': false,
            'DS_PYD_DSD_GET_PREVIOUS_FORM_WORKER_DETAILS': false
        };

        var setVistorDetailsData = function(prevVisitorDetails) {
                var prevVisitorDetailsObj = {},
                    tempList = [];
                for (var i = 0; i < prevVisitorDetails.length; i++) {
                    var visitorObj = angular.copy(STATIC_OBJ_DATA.DS_Visitor_Details);
                    prevVisitorDetailsObj = prevVisitorDetails[i];
                    visitorObj.Visitor_Time_Onsite = prevVisitorDetailsObj.Value3;
                    visitorObj.Visitor_Name = prevVisitorDetailsObj.Value4;
                    visitorObj.Visit_Reason = prevVisitorDetailsObj.Value5;
                    visitorObj.Visitor_Organisation = prevVisitorDetailsObj.Value7;
                    tempList.push(visitorObj);
                }
                $scope.dsStep1Fields['DS_Visitor_Group']['DS_Visitor_Details'] = tempList;
            },
            setPlantDetailsData = function(prevPlantDetails) {
                var prevPlantDetailsObj = {},
                    tempList = [];
                for (var i = 0; i < prevPlantDetails.length; i++) {
                    var plantObj = angular.copy(STATIC_OBJ_DATA.DS_Plant_Details);
                    prevPlantDetailsObj = prevPlantDetails[i];
                    plantObj.Pindan_or_Hired = prevPlantDetailsObj.Value3;
                    plantObj.Plant_on_Site = prevPlantDetailsObj.Value4;
                    plantObj.Activity_Comments_Charges = prevPlantDetailsObj.Value5;
                    tempList.push(plantObj);
                }
                $scope.dsStep1Fields['DS_Plant_Group']['DS_Plant_Details'] = tempList;
            },
            setDirectEmployeeDetailsData = function(prevDirectEmployeeDetails) {
                var prevDirectEmployeeDetailsObj = {},
                    tempList = [];
                for (var i = 0; i < prevDirectEmployeeDetails.length; i++) {
                    var employeeObj = angular.copy(STATIC_OBJ_DATA.DS_Employee_Details);
                    prevDirectEmployeeDetailsObj = prevDirectEmployeeDetails[i];
                    employeeObj.Employee_Hours = prevDirectEmployeeDetailsObj.Value5;
                    employeeObj.Employee_Name = prevDirectEmployeeDetailsObj.Value7;
                    employeeObj.Employee_Duties = prevDirectEmployeeDetailsObj.Value8;
                    tempList.push(employeeObj);
                }
                $scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details'] = tempList;
                // set value after previous data.
                employeeCallBackForUtil();
            },
            setWorkerDetailsData = function(prevWorkerDetails) {
                var prevWorkerDetailsObj = {},
                    tempList = [];
                for (var i = 0; i < prevWorkerDetails.length; i++) {
                    var workerObj = angular.copy(STATIC_OBJ_DATA.DS_Worker_Details);
                    prevWorkerDetailsObj = prevWorkerDetails[i];
                    workerObj.Worker_Hours = prevWorkerDetailsObj.Value4;
                    workerObj.Trade_on_site = prevWorkerDetailsObj.Value5;
                    workerObj.Trade_Worker_No = prevWorkerDetailsObj.Value8;
                    workerObj.Worker_Duties = prevWorkerDetailsObj.Value9;
                    tempList.push(workerObj);
                }
                $scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details'] = tempList;
                $scope.countWorkDetailNo();
            };

        var setPreviousFormsDetails = function(spStr, response) {
            switch (spStr) {
                case 'DS_PYD_DSD_GET_PREVIOUS_FORM_VISITOR_DETAILS':
                    setVistorDetailsData(response);
                    break;
                case 'DS_PYD_DSD_GET_PREVIOUS_FORM_PLANT_DETAILS':
                    setPlantDetailsData(response);
                    break;
                case 'DS_PYD_DSD_GET_PREVIOUS_FORM_DIRECT_EMPLOYEE_DETAILS':
                    setDirectEmployeeDetailsData(response);
                    break;
                case 'DS_PYD_DSD_GET_PREVIOUS_FORM_WORKER_DETAILS':
                    setWorkerDetailsData(response);
                    break;
                default:
                    // set all data.
                    setVistorDetailsData(response);
                    setPlantDetailsData(response);
                    setDirectEmployeeDetailsData(response);
                    setWorkerDetailsData(response);
            }
            $timeout(function() {
                $scope.expandTextAreaOnLoad();
            }, 100);
        };

        var prepareSPParamContent = function(spStr) {
            var splitedSPName = spStr.split(','),
                appBldrCode = $document.find('#DS_FORM_APP_BLDR_CODE').val() || 'PCON-DSD',
                spsObjList = [];

            for (var i = 0; i < splitedSPName.length; i++) {
                spsObjList.push({
                    fieldName: splitedSPName[i],
                    fieldValue: appBldrCode
                });
            }

            return {
                spStr: spStr,
                spsObjList: spsObjList
            }
        };

        var getPreviousFormsDetails = function(spParamObj) {
            var form = {
                projectId: projectId,
                formId: formId,
                fields: spParamObj.spStr,
                callbackParamVO: {
                    customFieldVOList: spParamObj.spsObjList
                }
            };

            $scope.spXhr[spParamObj.spStr] = true;
            $scope.getCallbackData(form).then(function(response) {
                if (!response.data) {
                    return;
                }
                setPreviousFormsDetails(spParamObj.spStr, angular.fromJson(response.data[spParamObj.spStr]).Items.Item);
                $scope.spXhr[spParamObj.spStr] = false;
            });
        };

        $scope.fillOutPrevFormDetails = function(spName) {
            getPreviousFormsDetails(prepareSPParamContent(spName));
        };
        //set Previous form's historic data section wise code : END

        $scope.addNewItem = function(repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function() {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        

        $scope.deleteRow = function(index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };

        $scope.countDirectEmployeeNo = function(){
            var tempEmployeeDetail = angular.copy($scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details']);
            var icount = 0;
            for (var index = 0; index < tempEmployeeDetail.length; index++) {
                var element = tempEmployeeDetail[index];
                if (element.Employee_Hours != 0 && element.Employee_Hours != "") {
                    icount++;
                }
            }

            $scope.dsStep1Fields['DS_Employee_Group']['Sum_Employee_No'] = icount;  
        }

        $scope.checkDuplicateValue = function(args) {
            var strVal = args.curObj[args.objName]
            var cureentIndex = args.repeatObj.indexOf(args.curObj);
            angular.forEach(args.repeatObj, function(item, index) {
                if (cureentIndex != index && strVal != "" && item[args.objName] == strVal) {
                    alert("Duplicate " + args.msg + " selected !!! \n\n Select a different " + args.msg);
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }

        $scope.countDirectEmployeeHours = function() {
            var tmpTotal = 0;
            var tempEmployeeDetail = angular.copy($scope.dsStep1Fields['DS_Employee_Group']['DS_Employee_Details']);
            for (var index = 0; index < tempEmployeeDetail.length; index++) {
                var element = tempEmployeeDetail[index];
                if (element.Employee_Hours) {
                    tmpTotal += (parseFloat(element.Employee_Hours) || 0);
                }
            }

            $scope.dsStep1Fields['DS_Employee_Group']['Sum_Direct_Employee_hours'] = tmpTotal.toFixed(1);
            $scope.dsStep1Fields['Total_Direct_Employee_Hours'] = tmpTotal.toFixed(1);
        }

        $window.pindanSiteDiaryFinalCallBack = function() {
            if ($scope.inValidDate) {
                $window.alert('Validation\n\nForm already created agaist selected date!')
                return true;
            }
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_DB_INSERT = 'true';
            return false;
        }

        function removeUnnecesoryAutoFields(fornNo) {
            var tempAutoCreateLookup = angular.copy($scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['AUTOCREATE_FORM_LOOKUP']);
            for (var index = 0; index < tempAutoCreateLookup.length; index++) {
                var element = tempAutoCreateLookup[index];

                if (element.ACF_LOOKUP_SEQ == fornNo) {
                    tempAutoCreateLookup.splice(index, 1);
                    break;
                }
            }

            $scope.data['myFields']['Asite_System_Data_Read_Write']['AUTOCREATE_FORM_FIELDS']['AUTOCREATE_FORM_LOOKUP'] = angular.copy(tempAutoCreateLookup);
        }

        $scope.countWorkDetailNo = function() {
            var tmpNoTotal = 0;
            var tmpHoursTotal = 0;
            var tmpWorkerDetails = angular.copy($scope.dsStep2Fields['DS_Worker_Group']['DS_Worker_Details']);
            for (var index = 0; index < tmpWorkerDetails.length; index++) {
                var element = tmpWorkerDetails[index];
                if (element.Trade_Worker_No) {
                    tmpNoTotal += (parseFloat(element.Trade_Worker_No) || 0);
                }

                if (element.Trade_Worker_No && element.Worker_Hours) {
                    tmpHoursTotal += ((parseFloat(element.Trade_Worker_No) || 0) * (parseFloat(element.Worker_Hours) || 0));
                }
            }

            $scope.dsStep1Fields['Sum_Trade_No'] = tmpNoTotal.toFixed(1);
            $scope.dsStep1Fields['Sum_Trade_hours'] = tmpHoursTotal.toFixed(1);
            $scope.dsStep1Fields['Total_Subcontractor_Hours'] = tmpHoursTotal.toFixed(1);

        }

        $scope.setSafetyIssuesFlow = function(Safety_Issues_Present) {
            $scope.data['myFields']['Asite_System_Data_Read_Write']["ORI_MSG_Fields"]["DS_AutoDistribute_User_Group"]["DS_AutoDistribute_Users"] = [];
            if (Safety_Issues_Present == "Yes") {
                setRolewiseDistribution("HSE Team");
                if ($scope.data['myFields']['Asite_System_Data_Read_Write']["ORI_MSG_Fields"]["DS_AutoDistribute_User_Group"]["DS_AutoDistribute_Users"].length) {
                    $scope.data['myFields']['Asite_System_Data_Read_Write']["ORI_MSG_Fields"]["DS_AUTODISTRIBUTE"] = "3";
                }
            } else {
                $scope.data['myFields']['Asite_System_Data_Read_Write']["ORI_MSG_Fields"]["DS_AUTODISTRIBUTE"] = "";
            }
        };

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof pindanSiteDiaryFinalCallBack !== "undefined") {
        return pindanSiteDiaryFinalCallBack();
    }
}