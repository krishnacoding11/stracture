/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', 'mainModule', './base', '../components/inlineattachment', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular,mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;
        
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();
        
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 100);
            }
        });

        var STATIC_OBJ_DATA = {

            autocompleteMsgStructure: {
                DS_MSG_AC_TYPE: "",
                DS_MSG_AC_FORM: "",
                DS_MSG_AC_MSG_TYPE: "",
                DS_MSG_AC_USERID: "",
                DS_MSG_AC_ACTION: "",
                DS_MSG_AC_ACTION_REMARKS: ""
            },
            Lot_Des: {
                Lot_Des_input: "",
                Lot_Number:""
            },
            Select_Lot_No:{
                Lot_selected:"",
                Guid:"",
                Ins_TenderGroup:{
                    Ins_Tend_Names:[{
                        Ins_Tend_Name_input:"",
                        Tend_Names:"Tender User Name",
					    InsTendNames_Guid:"",
                        NoOfSubmission:"",
                        TenOutComes:"",
                        TenderRank:"",
                        Sub_Cont_App:"",
                        Success_Contract:"",
                        FurInfoRequestData:{
                            FurInfoReqGroup:[{
                                FurInfoReq:"",
                                FurInfoReqyesText:""
                            }],
                        }
                    }],
                },
                Contract_One_Of_Req: {
                    Con_One_Of_Total_Cont_cost: "",
					Con_One_Of_Total_Cont_Cost_Rate: "",
                    Con_One_Of_Actual_Cost: "",
                    Con_One_Of_Actual_Cost_Rate: "",
                    Con_One_Of_Cost_saving: "",
                    Con_One_Of_Cost_saving_Rate: "",
                    Con_One_Of_Cost_Avoidance: "",
                    Con_One_Of_Cost_Avoidance_Rate: "",
                    Contract_One_Of_Req_Notes:""
                },
               
                selectSuccesFullUsers:[{
                    Ins_Tend_Name_input:"",
                    TenOutComes:"",
                    TenderRank:"",
                    Sub_Cont_App:"",
                    FurInfoReq:""
                }],
                Num_Reject_Sub:"",
                Ins_Reje_Tend_Name:"",
                Unsuccess_Tend_Name:"",
                Winning_Ten_Name:"",
                Eval_Signoff: "",
                 Eval_Signoff_Attach: "",
                 Eval_Team_Member: [{
                 Eval_Team_Member_input: ""
                }],
                Add_Draw_Qty: [{
                    Add_Draw_Qty_input: ""
                }],
                AwardStagedataLotWise:{
                    ForeSecSavings:"",
                    ForeSecSavingsYear:"",
                    ExteCon_End_Date:"",
                    Ini_Con_End_Date:"",
                    ConCommencement_date:"",
                    Ini_Cont_Duration:"",
                    ConExtension_Group:{
                        ConExtension_Month:[{
                            Exte_Con_End_Date:"",
                            ConExtension_Month_input:"",
                            ConExteMonth:"Yes"
                        }]
                    }
                },
                
                Upload_Eval_Comment:""
            },
            Ins_Tend_Names:{
                Ins_Tend_Name_input:"",
                Tend_Names:"Tender User Name",
                InsTendNames_Guid:"",
                NoOfSubmission:"",
                TenOutComes:"",
                TenderRank:"",
                Sub_Cont_App:"",
                Success_Contract:"",
                FurInfoRequestData:{
                    FurInfoReqGroup:[{
                        FurInfoReq:"",
                        FurInfoReqyesText:""
                    }]
                }
            },
            FurInfoReqGroup:{
                FurInfoReq:"",
				FurInfoReqyesText:""
            },
            InsTendNames: {
                Tenderers: "",
                Tender_Outcome:"",
                Sub_contractors:"",
                successUserContract:"",
                furInfoReqTenders:"",
                furInfoRequest:{
                    FurInfoReqGroups:[{
                        isfurInfoReqSelected:"",
                        TenderfurInfoReq:"",
                        furInfoReqTenderyes:""
                    }]
                }
            },
            FurInfoReqGroups:{
                isfurInfoReqSelected:"",
                TenderfurInfoReq:"",
                furInfoReqTenderyes:""
            },
            selectSuccesFullUsers:{
                Ins_Tend_Name_input:"",
                TenOutComes:"",
                TenderRank:"",
                Sub_Cont_App:"",
                FurInfoReq:""
            },
            WinningTenName: {
                WinningTenNameSelect: ""
            },
            unsuccessTenName: {
                unsuccessTenNameSelect: ""
            },
            Eval_Team_Member: {
                Eval_Team_Member_input: ""
            },
            Cost_Code: {
                Cost_Code_input: ""
            },
            PO_Number: {
                PO_Number_input: ""
            },
            Add_Draw_Qty: {
                Add_Draw_Qty_input: ""
            },
            
            Win_Ten_Lots_Apply: {
                Win_Ten_input: ""
            },
            Log_Con_Esc: {
                Log_Con_Esc_Date: "",
                Log_Risk_Esc_Input: "",
                Esc_Remedy_Input: ""
            },
            Cont_Frame_Cov: {
                Cont_Frame_Cov_Input: "",
            },
            Unsucces_Tend: {
                Unsucces_Tend_input: ""
            },

            ConExtension_Month:{
                Exte_Con_End_Date:"",
                 ConExtension_Month_input:"",
                 ConExteMonth:"Yes"
            },
            Supplier_Performance: {
                Date_Of_Review: "",
                DeliveryOfSer: "",
                System_Availability: "",
                TechnicalSupp_Res_Times: "",
                Training_Doc: "",
                Management_Info: "",
                Environmental: "",
                Account_Management_Que: "",
                Invoices_Payments: "",
                Communication1: "",
                Overall_Satisfaction: ""
            },
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            },   
        };

        $scope.tableUtilSettings = {
            Lot_Des: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Lot_DesSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Lot_Des),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            ConExtension_Month: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "extConDurationAndEndDate",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.ConExtension_Month),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Select_Lot_No: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "isSelectedlotNo",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Select_Lot_No),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Ins_Tend_Names: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "isInsTendName",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Ins_Tend_Names),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Eval_Team_Member: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Eval_Team_MemberSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Eval_Team_Member),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Add_Draw_Qty: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Add_Draw_QtySelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Add_Draw_Qty),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            FurInfoReqGroup: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "FurInfoReqGroupSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.FurInfoReqGroup),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            FurInfoReqGroups: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "isfurInfoReqSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.FurInfoReqGroups),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Log_Con_Esc: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Log_Con_EscSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Log_Con_Esc), 
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Cont_Frame_Cov: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Cont_Frame_CovSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Cont_Frame_Cov), 
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Cost_Code: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Cost_CodeSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Cost_Code),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            PO_Number: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "PO_NumberSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.PO_Number),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Win_Ten_Lots_Apply: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Win_Ten_Lots_ApplySelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Win_Ten_Lots_Apply),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            },
            Unsucces_Tend: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow : 0,
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: deleteRowCallbackAppliedvalue,
                checkboxModelKey: "Unsucces_TendSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Unsucces_Tend),
                ADD_NEW_BEFORE_TIP : "Insert before document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg : "Remove document",
                deleteSelectedMsg : "Remove selected document"
            }
        };
        
        var CMS_CONSTANT = {
           yymmdddateformate: 'yy-mm-dd',
           projectInitiation:"Project Initiation",
           projectDocClarification:"Tender Docs and Clarifications",
           gtmSubmissions: "GTM Submissions",
           evaluation: "Evaluation",
           award: "Award",
           admin: "Admin",
           cmsetup: "CM Setup",
           initiation: "Initiation",
           cmsetupCancelled:"CM Setup - Project Cancelled",
           cmsetupCompleted:"CM Setup - Project Completed",
           initiationCancelled:"Initiation - Project Cancelled",
           initiationCompleted:"Initiation - Project Completed",
           tenClarificationCancelled:"Tender Docs & Clarifications - Project Cancelled",
           tenClarificationCompleted:"Tender Docs & Clarifications - Project Completed",
           tenSubEcalCancelled:"Tender Sub & Evaluation -  Project Cancelled",
           tenSubEcalCompleted:"Tender Sub & Evaluation - Project Completed",
           awardCancelled:"Award - Project Cancelled",
           awardCompleted:"Award - Project Completed",
           tendocClarification: "Tender Documents & Clarifications",
           tenSubEcal: "Tender Submissions and Evaluation",
           conmanagement: "Contract Management",
           categorymanager: "Category Manager",
           operationmanager: "Operations Manager",
           Admin: "Admin",
           buyer: "Buyer",
           validanErrorConfigMsg: 'Error while loading Config!'
            
        };    

        function deleteRowCallbackAppliedvalue () {
            $timeout(function () {
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "4") {
                    onLotlist();
                }
                getTotal();
            }, 200);
        }

        $scope.selectionList = {
            categorymanagerList: [],
            operationmanagerList: [],
            adminList: [],
            buyerList: [],
            selectLotList: [],
            submissionList:[],
            NoOfRejectData:[],
            noOfSuccessFullUser:[],
            SuccesFullUsers:[]
        };


/** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formdata5 = $scope.asiteSystemDataReadOnly._5_Form_Data;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.formCustomFields.ORI_MSG_Custom_Fields;
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var ds_Get_Attributes_Set_Dtls = $scope.getValueOfOnLoadData('DS_GET_ATTRIBUTE_SET_DTLS');
        var ds_Asi_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var incompleteActionsByMsg = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS_BYMSG") || [];
        var incompleteMessageAction = $scope.getValueOfOnLoadData("DS_INCOMPLETE_MSG_ACTIONS") || [];
        $scope.DS_ORIGINATOR = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ORIGINATOR;
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.strIsDraft_Res = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES;
        $scope.strIsDraft_Res_Msg = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
        $scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
        $scope.selectionlst = {
            categoryanagerList: []
        };
        $scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

        
        $scope.addNewItem = function (repeatingData, objKeyName ){
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName] );
            repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad();           
        };

        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length == 1) {
                return;
            }
            repeatindData.splice(index, 1);
        };

        $scope.setFillupUser = function(fillupUserRole) {
            $scope.oriMsgCustomFields.fillUpUserRole =  fillupUserRole;
            $scope.oriMsgCustomFields.fillUserRoleSet =  fillupUserRole.split('|')[0].trim();
            $scope.oriMsgCustomFields.CayegoryManagerId = fillupUserRole.split('|')[2].split('#')[0].trim();
        };

        $scope.fillupUserRoleBuyers = function(userRoleBuyers) {
            $scope.oriMsgCustomFields.fillUserRoleBuyers =  userRoleBuyers.split('|')[0].trim();
            $scope.oriMsgCustomFields.BuyersID = userRoleBuyers.split('|')[2].split('#')[0].trim();
        };
        
        $scope.resetRow = function (node, nodeKey,$index) {
            if (node == $scope.oriMsgCustomFields.Cms_Details.Par_Arrang) {
                nodeKey.Par_Arrang = '';
                $scope.ParntAgree = commonApi.getItemSelectionList({
                    arrayObject:  getSubCategoryAndParentArrMent($scope.oriMsgCustomFields.Cms_Details.mater_Category,"Parent Arrangement"),
                    groupNameKey: "",
                    modelKey: "Value9",
                    displayKey: "Value9"
                });
            } else if (node == $scope.oriMsgCustomFields.Cms_Details.Cen_Gov_Body) {
                nodeKey.Cen_Gov_Body = '';
                $scope.CentGovBody = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("Central Govt Body"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Cont_Status){
                nodeKey.Cont_Status='';
                var projStatus = commonApi._.sortBy(getConfigurableAttriburteByType("Project Status"), 'Value8');
                $scope.ProjectStatus = commonApi.getItemSelectionList({
                    arrayObject:  projStatus,
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Domain){
                nodeKey.Domain='';
                $scope.oriMsgCustomFields.Cms_Details.Sub_Domain = "";
                $scope.Domain = commonApi.getItemSelectionList({
                    arrayObject : geAttributesSetDitails($scope.oriMsgCustomFields.Cms_Details.Sub_Cate_Code,'Domain'),
                    groupNameKey: "",
                    modelKey : 'Value9',
                    displayKey : 'Value9'
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Sub_Domain){
                nodeKey.Sub_Domain ='';
                $scope.SubDomain = commonApi.getItemSelectionList({
                    arrayObject:  geAttributesSetDitails($scope.oriMsgCustomFields.Cms_Details.Domain,'Sub Domain'),
                    groupNameKey: "",
                    modelKey: "Value9",
                    displayKey: "Value9"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.threshold){
                nodeKey.threshold ='';
                $scope.Threshold = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("Threshold"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Project_Decision){
                nodeKey.Project_Decision = "";
                $scope.Projectdecision = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("Project Decision"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Incoterms){
                nodeKey.Incoterms ='';
                $scope.Incoterms = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("IncoTerms"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Fund_Body){
                nodeKey.Fund_Body ='';
                $scope.FundBody = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("Funding Body"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.New_Ex_Demo){
                nodeKey.New_Ex_Demo ='';
                $scope.NewExDemo = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("New or Ex-Demo"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Conf_Inter){
                nodeKey.Conf_Inter ='';
                $scope.ConficIss = commonApi.getItemSelectionList({
                    arrayObject:  getConfigurableAttriburteByType("Conflict of Interest Issued"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
            } else if(node == $scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                nodeKey.Project_Stage_ConManagement ='';
                ProjectStageList();
            } 
        };
        $scope.currentOriTab = 'general.html';
        $scope.currentOriSubTab = '';

        $scope.setCurrentSection = function (tabURL) {
            $scope.currentOriTab = tabURL;
            $scope.setCurrentSubTabSelection("");
            $scope.scrollToTop();
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
			}, 10);
        };
        $scope.setCurrentSubTabSelection = function (subTabId) {
            $scope.currentOriSubTab = subTabId || '';
            scrollIntoView(subTabId);
        };

        function scrollIntoView(elementId) {
            var ele = elementId && document.getElementById(elementId);
            if(ele) {
                scrollToView(ele.offsetTop);
            }
        }
        $scope.scrollToTop = function () {
            scrollToView(0);
        };
        function scrollToView(top) {
            top = top - parseInt(100);
            window.scrollTo(0, top);
        }

        $scope.getServerTime(function (serverDate) {
            initORIview(serverDate);
        });
        
        $scope.addCustomClass = function () {
            angular.element(document.querySelector(".addisable")).addClass("customclass");
        };

        $scope.updatelist =function(objVal, objKey){
             if(objVal == $scope.oriMsgCustomFields.Cms_Details.Recur_Cont){
                objKey.Recur_Cont ='';
               $scope.RecurrContract = commonApi.getItemSelectionList({
                   arrayObject:  getConfigurableAttriburteByType("Recurring Contract"),
                   groupNameKey: "",
                   modelKey: "Value8",
                   displayKey: "Value8"
               });
           }
       };
        $scope.onNumberChange = function (currObj, repeatingObj) {
            for (var i = 0; i < repeatingObj.length; i++) {
                if ((currObj.Lot_Number <= 0 || currObj.Lot_Number >= 100) && currObj.Lot_Number != '') {
                    alert("Value should be between 1 - 99");
                    currObj.Lot_Number = "";
                }
            }
        };

        $scope.onValueofScore = function(currObj){
            if (currObj.node[currObj.selecteValue]) {
                if (currObj.node[currObj.selecteValue] >= 6 || currObj.node[currObj.selecteValue] <= 0) {
                    alert("Value should be between 1 - 5");
                    currObj.node[currObj.selecteValue] = '';
                } 
            }
        };
        
        //Tender Submissions & Evaluation : select value is unique
        $scope.onActivityChange = function (currObj, repeatingObj, $index) {
            for (var i = 0; i < repeatingObj.length; i++) {
                if (currObj.Lot_selected && i != $index &&
                    repeatingObj[i].Lot_selected == currObj.Lot_selected) {
                    alert("Select lot should not be same. please select different lot");
                    currObj.Lot_selected = "";
                    var noOfLotSelectArray = $scope.oriMsgCustomFields.Cms_Details.Lot_Number_Group.Lot_Des;
                    var noOfLots = [];
                    for (var i = 0; i < noOfLotSelectArray.length; i++) {
                        noOfLots.push({
                            options: [{
                                displayValue: noOfLotSelectArray[i].Lot_Number,
                                modelValue: noOfLotSelectArray[i].Lot_Number,
                                Lot_Number: noOfLotSelectArray[i].Lot_Number,
                                Lot_Des_input: noOfLotSelectArray[i].Lot_Des_input
                            }]
                        });
                    }
                    $scope.oriMsgCustomFields.LotList = angular.copy(noOfLots);
                }
            }
        };
        $scope.onselectedLot = function () {
            var noOfLotSelectdLot = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No;
            for (var i = 0; i < noOfLotSelectdLot.length; i++) {
                for (var j = 0; j < noOfLotSelectdLot[i].Add_Draw_Qty.length; j++) {
                    noOfLotSelectdLot[i].Add_Draw_Qty[j].selected_Lot_value = noOfLotSelectdLot[i].Lot_selected;
                }
            }
        };
        
        $scope.onSelectSuccessfull = function (currObj, repeatingObj, $index) {
            for (var i = 0; i < repeatingObj.length; i++) {
                if (currObj.TenderRank && i != $index &&
                    repeatingObj[i].TenderRank == currObj.TenderRank) {
                    alert("Enter Rank should not be same. please Enter different Rank");
                    currObj.TenderRank = "";
                }
            }
        };


        $scope.calculateRanking = function (currObj) {
            var countInsTenList = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No;
            for (var i = 0; i < countInsTenList.length; i++) {
                var newGuID = commonApi.guId();
                countInsTenList[i].Guid = newGuID;
                countInsTenList[i].rankGroup = [];
                var iCountlist = 1;
                for (var j = 0; j < countInsTenList[i].Ins_TenderGroup.Ins_Tend_Names.length; j++) {
                    if (countInsTenList[i].Ins_TenderGroup.Ins_Tend_Names[j].TenOutComes == "Successful") {
                        countInsTenList[i].rankGroup.push(iCountlist);
                        iCountlist++;
                    } 
                }
            }
            for (var i = 0; i < countInsTenList.length; i++) {
                for (var j = 0; j < countInsTenList[i].Ins_TenderGroup.Ins_Tend_Names.length; j++) {
                    if (countInsTenList[i].Ins_TenderGroup.Ins_Tend_Names[j].TenderRank <= countInsTenList[i].rankGroup.length) {
                        currObj.TenderRank= currObj.TenderRank;
                    } else{
                        countInsTenList[i].Ins_TenderGroup.Ins_Tend_Names[j].TenderRank = "";
                    } 
                }
            }
        };

        $scope.onchangeSuccssUser = function (currObj) {
            if(currObj.TenOutComes != "Successful" ){
                currObj.TenderRank= "";
            }
        };
        $scope.calculateNoOfSubmission = function (obj) {
            if (obj) {
                var unikId = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No;
                for (var i = 0; i < unikId.length; i++) {
                    for (var j = 0; j < unikId[i].Ins_TenderGroup.Ins_Tend_Names.length; j++) {
                        if (unikId[i].Ins_TenderGroup.Ins_Tend_Names[j].Ins_Tend_Name_input) {
                            unikId[i].Ins_TenderGroup.Ins_Tend_Names[j].InsTendNames_Guid = commonApi.guId();
                        }
                    }
                }
            }
        };
        $scope.calculateTenOutComes = function (currObj) {
            var countReject = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No,
                rejectData,
                successfuldata,
                unsuccessfuldata,
                withdrawndata,
                totalNoOfSub;
            if (currObj) {
                for (var i = 0; i < countReject.length; i++) {
                    rejectData = 1;
                    successfuldata = 1;
                    unsuccessfuldata= 1;
                    withdrawndata= 1;
                    totalNoOfSub = 1;
                    for (var j = 0; j < countReject[i].Ins_TenderGroup.Ins_Tend_Names.length; j++) {
                        if (countReject[i].Ins_TenderGroup.Ins_Tend_Names[j].Ins_Tend_Name_input) {
                            countReject[i].totalNoOfSubmission = totalNoOfSub;
                            totalNoOfSub++;
                        }
                        if(countReject[i].Ins_TenderGroup.Ins_Tend_Names[j].TenOutComes == "Rejected"){
                            countReject[i].totalNoOfRejected = rejectData;
                            rejectData++;
                        }
                        if(countReject[i].Ins_TenderGroup.Ins_Tend_Names[j].TenOutComes == "Successful"){
                            countReject[i].totalNoOfSuccessful = successfuldata;
                            successfuldata++;
                        }
                        if(countReject[i].Ins_TenderGroup.Ins_Tend_Names[j].TenOutComes == "Unsuccessful"){
                            countReject[i].totalNoOfUnsuccessful = unsuccessfuldata;
                            unsuccessfuldata++;
                        }
                        if(countReject[i].Ins_TenderGroup.Ins_Tend_Names[j].TenOutComes == "Withdrawn"){
                            countReject[i].totalNoOfWithdrawn = withdrawndata;
                            withdrawndata++;
                        }
                    }
                }
            } 
        };
        
        $scope.isweekend = function (date) {
            if (date.node[date.selecteDate]) {
                var dt = new Date(date.node[date.selecteDate]);
                if (dt.getDay() == 6 || dt.getDay() == 0) {
                    alert('Weekends not allowed');
                    date.node[date.selecteDate] = '';
                } 
            }
        };
        $scope.dateChangeEvent = function (curObj) {
            if (curObj == $scope.oriMsgCustomFields.Cms_Details.Est_Final_Draft_Doc) {
                var startDate = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Final_Draft_Doc);
                var endDate = "",
                    noOfDaysToAdd = parseInt(7),
                    count = 0;
                while (count < noOfDaysToAdd) {
                    endDate = new Date(startDate.setDate(startDate.getDate() + 1));
                    if (endDate.getDay() != 0 && endDate.getDay() != 6) {
                        count++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date = $scope.formatDate(endDate, 'yy-mm-dd');
                var day = parseInt($scope.oriMsgCustomFields.Cms_Details.GTM_Period),
                    day2 = parseInt($scope.oriMsgCustomFields.Cms_Details.Eval_Period),
                    day3 = parseInt($scope.oriMsgCustomFields.Cms_Details.Stands_Period);

                var startDategtm1 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var estComClosedate1 = "",
                    noOfDaysToAdd1 = parseInt(day),
                    count1 = 0;
                while (count1 < noOfDaysToAdd1) {
                    estComClosedate1 = new Date(startDategtm1.setDate(startDategtm1.getDate() + 1));
                    if (estComClosedate1.getDay() != 0 && estComClosedate1.getDay() != 6) {
                        count1++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Est_Com_Close = $scope.formatDate(estComClosedate1, 'yy-mm-dd');
                var startDategtm2 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var issNotiLrtterdategtm2 = "",
                    noOfDaysToAddgtm2 = parseInt(day2 + day + 7),
                    countftm2 = 0;
                while (countftm2 < noOfDaysToAddgtm2) {
                    issNotiLrtterdategtm2 = new Date(startDategtm2.setDate(startDategtm2.getDate() + 1));
                    if (issNotiLrtterdategtm2.getDay() != 0 && issNotiLrtterdategtm2.getDay() != 6) {
                        countftm2++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Iss_Noti_Lrtter = $scope.formatDate(issNotiLrtterdategtm2, 'yy-mm-dd');
                var startDategtm3 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var possContSignoffdategtm3 = "",
                    noOfDaysToAddgtm3 = parseInt(day + day2 + day3 + 7),
                    countgtm3 = 0;
                while (countgtm3 < noOfDaysToAddgtm3) {
                    possContSignoffdategtm3 = new Date(startDategtm3.setDate(startDategtm3.getDate() + 1));
                    if (possContSignoffdategtm3.getDay() != 0 && possContSignoffdategtm3.getDay() != 6) {
                        countgtm3++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Poss_Cont_Signoff = $scope.formatDate(possContSignoffdategtm3,'yy-mm-dd');
            } else if (curObj == $scope.oriMsgCustomFields.Cms_Details.GTM_Period ) {
                var strDate1 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var gtmday = parseInt($scope.oriMsgCustomFields.Cms_Details.GTM_Period),
                    gtmday2 = parseInt($scope.oriMsgCustomFields.Cms_Details.Eval_Period),
                    gtmday3 = parseInt($scope.oriMsgCustomFields.Cms_Details.Stands_Period);
                var estComClosedate = "",
                    noOfDaysAdd = parseInt(gtmday),
                    count5 = 0;
                while (count5 < noOfDaysAdd) {
                    estComClosedate = new Date(strDate1.setDate(strDate1.getDate() + 1));
                    if (estComClosedate.getDay() != 0 && estComClosedate.getDay() != 6) {
                        count5++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Est_Com_Close = $scope.formatDate(estComClosedate,'yy-mm-dd');
                var startDategtmp2 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var issNotiLrtterdategtmp2 = "",
                    noOfDaysToAddgtmp2 = parseInt(gtmday2 + gtmday + 7),
                    countftmp2 = 0;
                while (countftmp2 < noOfDaysToAddgtmp2) {
                    issNotiLrtterdategtmp2 = new Date(startDategtmp2.setDate(startDategtmp2.getDate() + 1));
                    if (issNotiLrtterdategtmp2.getDay() != 0 && issNotiLrtterdategtmp2.getDay() != 6) {
                        countftmp2++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Iss_Noti_Lrtter = $scope.formatDate(issNotiLrtterdategtmp2,'yy-mm-dd');
                var startDategtmp3 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var possContSignoffdategtmp3 = "",
                    noOfDaysToAddgtmp3 = parseInt(gtmday + gtmday2 + gtmday3 + 7),
                    countgtmp3 = 0;
                while (countgtmp3 < noOfDaysToAddgtmp3) {
                    possContSignoffdategtmp3 = new Date(startDategtmp3.setDate(startDategtmp3.getDate() + 1));
                    if (possContSignoffdategtmp3.getDay() != 0 && possContSignoffdategtmp3.getDay() != 6) {
                        countgtmp3++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Poss_Cont_Signoff = $scope.formatDate(possContSignoffdategtmp3,'yy-mm-dd');
                return true;

            } else if (curObj == $scope.oriMsgCustomFields.Cms_Details.Eval_Period) {
                var evalPeriodday2 = parseInt($scope.oriMsgCustomFields.Cms_Details.Eval_Period),
                evalPeriodday = parseInt($scope.oriMsgCustomFields.Cms_Details.GTM_Period),
                evalPeriodday3 = parseInt($scope.oriMsgCustomFields.Cms_Details.Stands_Period);
                var startdate = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var estComCloseDate = "",
                    noOfDaysToAdd9 = parseInt(evalPeriodday),
                    count9 = 0;
                while (count9 < noOfDaysToAdd9) {
                    estComCloseDate = new Date(startdate.setDate(startdate.getDate() + 1));
                    if (estComCloseDate.getDay() != 0 && estComCloseDate.getDay() != 6) {
                        count9++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Est_Com_Close = $scope.formatDate(estComCloseDate,'yy-mm-dd');
                var startDate1 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var issNotiLrtterdate = "",
                    noOfDaysToAdd2 = parseInt(evalPeriodday + evalPeriodday2 + 7),
                    count2 = 0;
                while (count2 < noOfDaysToAdd2) {
                    issNotiLrtterdate = new Date(startDate1.setDate(startDate1.getDate() + 1));
                    if (issNotiLrtterdate.getDay() != 0 && issNotiLrtterdate.getDay() != 6) {
                        count2++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Iss_Noti_Lrtter = $scope.formatDate(issNotiLrtterdate,'yy-mm-dd');
                var startDate14 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var possContSignoffdate14 = "",
                    noOfDaysToAdd4 = parseInt(evalPeriodday + evalPeriodday2 + evalPeriodday3 + 7),
                    count14 = 0;
                while (count14 < noOfDaysToAdd4) {
                    possContSignoffdate14 = new Date(startDate14.setDate(startDate14.getDate() + 1));
                    if (possContSignoffdate14.getDay() != 0 && possContSignoffdate14.getDay() != 6) {
                        count14++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Poss_Cont_Signoff = $scope.formatDate(possContSignoffdate14,'yy-mm-dd');
                return true;
            } else if (curObj == $scope.oriMsgCustomFields.Cms_Details.Stands_Period) {
                var staPeriodday = parseInt($scope.oriMsgCustomFields.Cms_Details.GTM_Period),
                    staPeriodday2 = parseInt($scope.oriMsgCustomFields.Cms_Details.Eval_Period),
                    staPeriodday3 = parseInt($scope.oriMsgCustomFields.Cms_Details.Stands_Period);

                var startDategtmsp1 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var estComClosedatesp1 = "",
                    noOfDaysToAddSp1 = parseInt(staPeriodday),
                    countsp1 = 0;
                while (countsp1 < noOfDaysToAddSp1) {
                    estComClosedatesp1 = new Date(startDategtmsp1.setDate(startDategtmsp1.getDate() + 1));
                    if (estComClosedatesp1.getDay() != 0 && estComClosedatesp1.getDay() != 6) {
                        countsp1++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Est_Com_Close = $scope.formatDate(estComClosedatesp1,'yy-mm-dd');
                var startDategtmsp2 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var issNotiLrtterdateSp2 = "",
                    noOfDaysToAddSp2 = parseInt(staPeriodday2 + staPeriodday + 7),
                    countSp = 0;
                while (countSp < noOfDaysToAddSp2) {
                    issNotiLrtterdateSp2 = new Date(startDategtmsp2.setDate(startDategtmsp2.getDate() + 1));
                    if (issNotiLrtterdateSp2.getDay() != 0 && issNotiLrtterdateSp2.getDay() != 6) {
                        countSp++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Iss_Noti_Lrtter = $scope.formatDate(issNotiLrtterdateSp2,'yy-mm-dd') ;
                var startDateSp3 = new Date($scope.oriMsgCustomFields.Cms_Details.Est_Pub_Date);
                var possContSignoffdateSp3 = "",
                    noOfDaysToAddSp3 = parseInt(staPeriodday + staPeriodday2 + staPeriodday3 + 7),
                    countSp3 = 0;
                while (countSp3 < noOfDaysToAddSp3) {
                    possContSignoffdateSp3 = new Date(startDateSp3.setDate(startDateSp3.getDate() + 1));
                    if (possContSignoffdateSp3.getDay() != 0 && possContSignoffdateSp3.getDay() != 6) {
                        countSp3++;
                    }
                }
                $scope.oriMsgCustomFields.Cms_Details.Poss_Cont_Signoff = $scope.formatDate(possContSignoffdateSp3,'yy-mm-dd');
            }
        };

        $scope.dateChangeValidation = function (valiDate) {
            // date comparison with other date logic 
            if (valiDate.node[valiDate.compareDate1] && valiDate.node[valiDate.compareDate2]) {
                var date1 = new Date(valiDate.node[valiDate.compareDate1]),
                    date2 = new Date(valiDate.node[valiDate.compareDate2]);

                if (valiDate.comparionMethod == 'greater' && date1 >= date2) {
                    alert('Clarification End Date should be Greater than of Publication Date');
                    valiDate.node[valiDate.compareDate1] = '';
                } else if (valiDate.comparionMethod == 'less' && date1 <= date2) {
                    alert('Clarification End Date should be Greater than of Publication Date');
                    valiDate.node[valiDate.compareDate1] = '';
                }
            }
            if (valiDate.node[valiDate.compareDate7] && valiDate.node[valiDate.compareDate8]) {
                var date7 = new Date(valiDate.node[valiDate.compareDate7]),
                    date8 = new Date(valiDate.node[valiDate.compareDate8]);
                if (valiDate.comparionMethod4 == 'greater' && date7 >= date8) {
                    alert('Competition Close Date should be Greater than Clarification End Date');
                    valiDate.node[valiDate.compareDate7] = '';
                } else if (valiDate.comparionMethod4 == 'less' && date7 <= date8) {
                    alert('Competition Close Date should be Greater than Clarification End Date');
                    valiDate.node[valiDate.compareDate7] = '';
                }
            }

            if (valiDate.node[valiDate.compareDate5] && valiDate.node[valiDate.compareDate6]) {
                var date5 = new Date(valiDate.node[valiDate.compareDate5]),
                    date6 = new Date(valiDate.node[valiDate.compareDate6]);

                if (valiDate.comparionMethod3 == 'greater' && date5 >= date6) {
                   alert('OJEU Notice Date should be Greater than eTenders - Date tender published');
                    valiDate.node[valiDate.compareDate5] = '';
                } else if (valiDate.comparionMethod3 == 'less' && date5 <= date6) {
                    alert('OJEU Notice Date should be Greater than eTenders - Date tender published');
                    valiDate.node[valiDate.compareDate5] = '';
                }
            }
        };

        $scope.addMonths = function (curVal, repeatingLots) {
            for (var i = 0; i < repeatingLots.length; i++) {
                if (curVal.Lot_selected == repeatingLots[i].Lot_selected) {
                    var ConCommdate = new Date(repeatingLots[i].AwardStagedataLotWise.ConCommencement_date),
                        d = ConCommdate.getDate(),
                        day = parseInt(repeatingLots[i].AwardStagedataLotWise.Ini_Cont_Duration);
                        ConCommdate.setMonth(ConCommdate.getMonth() + + day);
                    if (ConCommdate.getDate() != d) {
                        ConCommdate.setDate(0);
                    }
                    repeatingLots[i].AwardStagedataLotWise.Ini_Con_End_Date = $scope.formatDate(ConCommdate, 'yy-mm-dd');
                    if (repeatingLots[i].AwardStagedataLotWise.Ini_Con_End_Date) {
                        var IniConEndDate = new Date(repeatingLots[i].AwardStagedataLotWise.Ini_Con_End_Date);
                        for (var j = 0; j < repeatingLots[i].AwardStagedataLotWise.ConExtension_Group.ConExtension_Month.length; j++) {
                            var dt = IniConEndDate.getDate();
                            var refGuID = commonApi.guId();
                              
                            var conExtmonday = parseInt(repeatingLots[i].AwardStagedataLotWise.ConExtension_Group.ConExtension_Month[j].ConExtension_Month_input);
                            IniConEndDate.setMonth(IniConEndDate.getMonth() + conExtmonday);
                            if (IniConEndDate.getDate() != dt) {
                                IniConEndDate.setDate(0);
                            }
                            repeatingLots[i].AwardStagedataLotWise.ConExtension_Group.ConExtension_Month[j].Exte_Con_End_Date = $scope.formatDate(IniConEndDate, 'yy-mm-dd');
                            repeatingLots[i].AwardStagedataLotWise.ConExtension_Group.ConExtension_Month[j].Ref_GUID = refGuID;
                        }
                    }
                }
            }

        };

        $scope.removeRow = function (index, repeatindData) {
            if (repeatindData.length == 1) {
                $scope.oriMsgCustomFields.AwardStage.ConExtension_Group.ConExtension_Month = [{}];
                return;
            }
            repeatindData.splice(index, 1);
        };
        

        $scope.remainingQty = function (curVal,repeatingObj) {
            var  tmpTotal = 0;
            for (var index = 0; index < repeatingObj.length; index++) {
                var total = repeatingObj[index];
                if (total.Add_Draw_Qty_input) {
                    tmpTotal += (parseInt(total.Add_Draw_Qty_input) || 0);
                }
            }
            var remaiQty = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No;
            for (var i = 0; i < remaiQty.length; i++) {
                for (var j = 0; j < repeatingObj.length; j++) {
                    if (remaiQty[i].Lot_selected == repeatingObj[0].selected_Lot_value && curVal.Add_Draw_Qty_input) {
                        var remainQty = parseInt($scope.oriMsgCustomFields.Cms_Details.QTY) - parseInt(tmpTotal);
                        if (remainQty <= 0) {
                            remaiQty[i].Total_Drawdown_Remaining = 0;
                        } else {
                            remaiQty[i].Total_Drawdown_Remaining = remainQty;
                        }
                    }
                }
            }
            
        };
        $scope.ContractOneoff = function(curVal,repeatingData){
            for (var index = 0; index < repeatingData.length; index++) {
                if (curVal.Lot_selected == repeatingData[index].Lot_selected && repeatingData[index].Contract_One_Of_Req.Con_One_Of_Total_Cont_cost) {
                    var costSavingValue = parseInt(repeatingData[index].Contract_One_Of_Req.Con_One_Of_Total_Cont_cost) - parseInt(curVal.Contract_One_Of_Req.Con_One_Of_Actual_Cost);
                    if(costSavingValue <= 0 ){
                        repeatingData[index].Contract_One_Of_Req.Con_One_Of_Cost_saving = 0;
                    } else {
                        repeatingData[index].Contract_One_Of_Req.Con_One_Of_Cost_saving = costSavingValue;
                    }
                }
            }
        };
        $scope.oneoffPurCosSaveCount = function () {
            if ($scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Total_Contrac_Cost) {
                var subValue = parseInt($scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Total_Contrac_Cost) - parseInt($scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Actual_Cost);
                if (subValue <= 0) {
                    $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Cost_saving = 0;
                } else {
                    $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Cost_saving = subValue;
                }
            }
        };

        //Award Stage :Contract One Off : Total Lot Summary Table
        $scope.contractOneofLotSummary= function(lotSummary,key){
            var element = "",
                totalLotValue = 0,
                actualLotCost = 0,
                lotCostSavings = 0,
                lotCostAvoidance = 0;
            for (var index = 0; index < lotSummary.length; index++) {
                element = lotSummary[index];
                if (element.Contract_One_Of_Req.Con_One_Of_Total_Cont_cost && key == 'Total Lot Value') {
                    totalLotValue += (parseInt(element.Contract_One_Of_Req.Con_One_Of_Total_Cont_cost) || 0);
                    $scope.oriMsgCustomFields.AwardStage.total_Lot_Value = totalLotValue;
                }
                if (element.Contract_One_Of_Req.Con_One_Of_Actual_Cost && key == 'Actual Lot Cost') {
                    actualLotCost += (parseInt(element.Contract_One_Of_Req.Con_One_Of_Actual_Cost) || 0);
                    $scope.oriMsgCustomFields.AwardStage.total_Actual_Lot_Cost = actualLotCost;
                }
                if (element.Contract_One_Of_Req.Con_One_Of_Cost_saving || element.Contract_One_Of_Req.Con_One_Of_Cost_saving == 0) {
                    lotCostSavings += (parseInt(element.Contract_One_Of_Req.Con_One_Of_Cost_saving) || 0);
                    $scope.oriMsgCustomFields.AwardStage.total_Lot_Cost_Savings = lotCostSavings;
                }
                if (element.Contract_One_Of_Req.Con_One_Of_Cost_Avoidance && key == 'Lot Cost Avoidance') {
                    lotCostAvoidance += (parseInt(element.Contract_One_Of_Req.Con_One_Of_Cost_Avoidance) || 0);
                    $scope.oriMsgCustomFields.AwardStage.total_Lot_Cost_Avoidance = lotCostAvoidance;
                }
            }
        };
        function onLotlist() {
            var noOfLotArray = $scope.oriMsgCustomFields.Cms_Details.Lot_Number_Group.Lot_Des;
            var noofLots = [];
            for (var i = 0; i < noOfLotArray.length; i++) {
                noofLots.push({
                    options: [{
                        displayValue: noOfLotArray[i].Lot_Number,
                        modelValue: noOfLotArray[i].Lot_Number,
                        Lot_Number: noOfLotArray[i].Lot_Number,
                        Lot_Des_input: noOfLotArray[i].Lot_Des_input,
                    }]
                });
            }
            $scope.oriMsgCustomFields.LotList = angular.copy(noofLots);
            if($scope.oriMsgCustomFields.LotList[0].options[0].displayValue){
                $scope.oriMsgCustomFields.isShowLotlist = true;
            } else{
                $scope.oriMsgCustomFields.isShowLotlist = false;
            }
        }

        
        function setshowfiled() {
            var currentstage = $scope.oriMsgCustomFields.DSI_CurrentStage;
            if (currentstage) {
                switch (currentstage) {
                    case '0': 
                        $scope.oriMsgCustomFields.isShowOtherField = true;
                    break;   
                    case '1':
                        $scope.oriMsgCustomFields.isShowCMSetup = true;
                    break;    
                    case '2':
                        $scope.oriMsgCustomFields.isShowInitiation =  true;
                        break;    
                    case '3':
                        $scope.oriMsgCustomFields.isShowTenDocCla =  true;
                    break;    
                    case '4':
                        $scope.oriMsgCustomFields.isShowTenSubEva =  true;
                    break;  
                    case '5':
                        $scope.oriMsgCustomFields.isShowAward =  true;
                    break;
                    case '6':
                        $scope.oriMsgCustomFields.isShowContractManagement = true;
                    break;
                }
            } 
        }

        if (currentViewName == "RES_PRINT_VIEW") {
            $scope.CmFormDetailList = $scope.getValueOfOnLoadData('DS_IRE_EPS_CMSL_LetestCMData');
            if($scope.CmFormDetailList.length && $scope.CmFormDetailList[0].Value3){
                $scope.oriMsgCustomFields.DSI_CurrentStage = '6';
            }
            $scope.launchCmForm = function () {
                $window.prePopulatemapping = new Object();
                $window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '6';
                $window.prePopulatemapping['SRC1'] = $scope.strFormId;
                $window.prePopulatemapping['TG1'] = 'SelectedFormIdDetails';
                $window.prePopulatemapping['SRC2'] = $scope.oriMsgCustomFields.AwardStage.Cont_Management_Req;
                $window.prePopulatemapping['TG2'] = 'Con_Mana_Ment_Req';
                $window.prePopulatemapping['SRC3'] = $scope.oriMsgCustomFields.AwardStage.Framework_Or_Contract;
                $window.prePopulatemapping['TG3'] = 'Framework_Or_Contract';
                $window.prePopulatemapping['SRC4'] = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                $window.prePopulatemapping['TG4'] = 'ParentAppBuilderID';
                $window.prePopulatemapping['SRC5'] = $scope.oriMsgCustomFields.ORI_FORMTITLE;
                $window.prePopulatemapping['TG5'] = 'CM_Titlt';
                $window.prePopulatemapping['SRC6'] = $scope.oriMsgCustomFields.Project_Code;
                $window.prePopulatemapping['TG6'] = 'CMS_Project_Code';
                if (localStorage) {
                    localStorage.setItem("formcode_num", $scope.strFormId);
                }
                launchCreateForm("IRE-EPS-CM");
            };
        }
        if (currentViewName == 'RES_VIEW') {
            var currencyset = $scope.oriMsgCustomFields.Cms_Details.Vat_Rate;
            var currency = $scope.oriMsgCustomFields.Cms_Details.Select_Lot_No;
            if(currency.length){
                for (var i = 0; i < currency.length; i++) {
                    currency[i].Contract_One_Of_Req.Con_One_Of_Total_Cont_Cost_Rate = currencyset;
                    currency[i].Contract_One_Of_Req.Con_One_Of_Actual_Cost_Rate = currencyset;
                    currency[i].Contract_One_Of_Req.Con_One_Of_Cost_saving_Rate= currencyset;
                    currency[i].Contract_One_Of_Req.Con_One_Of_Cost_Avoidance_Rate = currencyset;
                }
            }
            $scope.oriMsgCustomFields.AwardStage.Estimated_Annual_Value_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.Val_Sav_cal_Framework_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.Total_Annual_Sec_Sav_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.Est_Total_Value_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.Total_For_Sec_Sav_Rate = currencyset;
            $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Actual_Cost_Rate = currencyset;
            $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Cost_saving_Rate = currencyset;
            $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Cost_Avoidance_Rate = currencyset;
            $scope.oriMsgCustomFields.Cms_Details.purchase_Scenario.Total_Contract_Cost_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.total_Lot_Value_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.total_Actual_Lot_Cost_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.total_Lot_Cost_Savings_Rate = currencyset;
            $scope.oriMsgCustomFields.AwardStage.total_Lot_Cost_Avoidance_Rate = currencyset;
        }
        if (currentViewName == 'RES_VIEW') {
            if ($scope.strIsDraft_Res_Msg == 'NO') {
                $scope.oriMsgCustomFields.DSI_MSGID = getMsgId();
            }
            if ($scope.strFormId != '' && $scope.strIsDraft == 'NO') {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = '0';
                $scope.strCanReply = '';
                if($scope.oriMsgCustomFields.fillUpUserRole != '' && $scope.oriMsgCustomFields.fillUpUserRole != undefined){
                    var roleUse = $scope.oriMsgCustomFields.fillUpUserRole.split('|')[2].split('#')[0].trim();
                    $scope.oriMsgCustomFields.CayegoryManagerId = roleUse;
                }
                if (roleUse != '' && roleUse != undefined && roleUse == currentUserid) {
                    $scope.categorymanagerId = currentUserid;
                    $scope.strCanReply = 'yes';
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                } else {
                    setSendPermission(checkUserIncompleteActions());
                }
            }
            getMsgIdOfIncompleteAction();
        }
        

        function checkUserIncompleteActions() {
            var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Value.indexOf('Respond') > -1 && val.Value.indexOf(currentUserid) != -1
            });
            if (ActionData && ActionData.length) {
                return "YES";
            } else {
                return "NO";
            }
        }

        function setSendPermission(strpermission) {

            if (strpermission && strpermission == 'YES') {
                var strMessageId = getMsgIdOfIncompleteAction();
                var currentMsgId = $scope.oriMsgCustomFields.DSI_MSGID;

                if (strMessageId && currentMsgId) {
                    if (strMessageId.toLowerCase().trim() == currentMsgId.toLowerCase().trim()) {

                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                        $scope.strCanReply = 'yes';
                        $scope.buyerId = currentUserid;
                    } else {
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                        $scope.oriMsgCustomFields.DSI_Errormsg = 'You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                        $scope.strCanReply = '';
                    }
                } else {
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                    $scope.strCanReply = 'yes';
                    $scope.buyerId = currentUserid;
                }
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                $scope.oriMsgCustomFields.DSI_Errormsg = 'You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                $scope.strCanReply = '';
            }
        }
        
        function getMsgIdOfIncompleteAction() {
            var allPendingRespondNodes = commonApi._.filter(incompleteActionsByMsg, function (obj) {
                return obj.Value4 == "Respond"
            });
            for (var i = 0; i < allPendingRespondNodes.length; i++) {
                var strUserId = allPendingRespondNodes[i].Value1;
                var strMsgId = allPendingRespondNodes[i].Value3;

                if (currentUserid == strUserId) {
                    return strMsgId;
                }
            }
            return '';
        }
        function getMsgId() {
            var strMessageId = "";
            if (incompleteMessageAction && incompleteMessageAction[0]) {
                strMessageId = incompleteMessageAction[0].Value.split("|")[2].trim();
                return strMessageId;
            }
        }
       
        $scope.setflow = function() {
            var currentstage = $scope.oriMsgCustomFields.DSI_CurrentStage;
            var strdate = $scope.setDbDateClientSide(5);
            if (currentstage != '0') {
                var buyers = $scope.oriMsgCustomFields.Cms_Details.Ass_Buyer,
                    buyersVal = buyers.split('|')[2].trim().split(' ')[0];
                var admin = commonApi._.filter(ds_Projusers_Role, function (val) {
                    return val.Name.split(',')[0].trim() == $scope.DS_ORIGINATOR.split(',')[0].trim() && val.Value.split('|')[0].trim() == 'Admin';
                });
                if(admin && admin != '' && admin != undefined){
                    var adminuserId = admin[0].Value.split('|')[2].split('#')[0].trim();
                }
            }
            if (currentstage) {
                switch (currentstage) {
                    case '0': 
                        $scope.oriMsgCustomFields.DSI_NextStage = "1";
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "3";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        setFormStatus(CMS_CONSTANT.admin);
                        var catman = $scope.oriMsgCustomFields.Category_Manager;
                        var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                        setAutoDistribution(catemanVal,"3#",strdate,"0");  
                        if ($scope.oriMsgCustomFields.Cms_Details.mater_Category == "E - Education Specific") {
                            var opertaionman = $scope.selectionList.operationmanagerList;
                            angular.forEach(opertaionman, function (value, key) {
                                if (value.options[0].modelValue != null && value.options[0].modelValue != undefined) {
                                    var operatioManager = value.options[0].modelValue.split('|')[2].trim().split(' ')[0];
                                    setAutoDistribution(operatioManager, "7#", strdate, "0");
                                }
                            });
                        }
                    break;   
                    case '1':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];  
                        if($scope.oriMsgCustomFields.Project_Code == '' && $scope.oriMsgCustomFields.Cms_Details.Project_Decision !="Reject" && $scope.oriMsgCustomFields.Cms_Details.Project_Decision !="Awaiting Decision"){
                            var subCategoryCode = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val){
                                return val.Value3=='Sub Category Code' && val.Value8 == $scope.oriMsgCustomFields.Cms_Details.Sub_Cate_Code; 
                            });
                            var ProcedureType = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val) {
                                return val.Value3== 'Procedure Type' && val.Value8 == $scope.oriMsgCustomFields.Cms_Details.Proc_Type;
                            });
                            var formId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID.split('CMS')[1];
                            formId = formId.length < 4 ? formId.padStart(4,'0') : formId;
                            $scope.oriMsgCustomFields.Project_Code = subCategoryCode[0].Value7 + formId + ProcedureType[0].Value7;
                        }
                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm == "Admin") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "0";
                            var adminUser = commonApi._.filter(ds_Projusers_Role, function (val) {
                                return val.Name.split(',')[0].trim() == $scope.DS_ORIGINATOR.split(',')[0].trim() && val.Value.split('|')[0].trim() == 'Admin';
                            });
                            if(adminUser && adminUser != '' && adminUser != undefined && adminUser != null){
                                var adminUserId = adminUser[0].Value.split('|')[2].split('#')[0].trim();
                                    setAutoDistribution(adminUserId, "3#", strdate, "0");
                            }
                            currentViewName = "ORI_VIEW";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Skip_to_Award == 'Yes' && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm == "Stage 5 - Award"){
                             setAutoDistribution(buyersVal, "3#", strdate, "0");
                             $scope.oriMsgCustomFields.DSI_NextStage = "5";
                             setFormStatus(CMS_CONSTANT.cmsetup);
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm == 'Stage 1 - Initiation') {
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "2";
                            setFormStatus(CMS_CONSTANT.cmsetup);
                        } else if($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed') {
                            setFormStatus(CMS_CONSTANT.cmsetupCompleted);
                        } else if($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.3 project cancelled') {
                            setFormStatus(CMS_CONSTANT.cmsetupCancelled);
                        } else {
                            setFormStatus(CMS_CONSTANT.cmsetup);
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
           
                    break;    
                    case '2':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed') {
                            setFormStatus(CMS_CONSTANT.initiationCompleted);
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.3 project cancelled') {
                            setFormStatus(CMS_CONSTANT.initiationCancelled);
                        } else {
                            setFormStatus(CMS_CONSTANT.initiation);
                        }
                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi == "CM Setup") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "1";
                            var catman = $scope.oriMsgCustomFields.Category_Manager;
                            var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                            setAutoDistribution(catemanVal, "3#", strdate, "0");
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi == "Stage 2 - Tender Documents & Clarifications"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "3";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi == "Stage 3 & 4 - Tender Submissions & Evaluation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "4";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi == "Stage 5 - Award"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "5";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi == "Stage 6 - Contract Management"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "6";
                        } else {
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
                        break;    
                    case '3':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed') {
                            setFormStatus(CMS_CONSTANT.tenClarificationCompleted);
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.3 project cancelled') {
                            setFormStatus(CMS_CONSTANT.tenClarificationCancelled);
                        } else {
                            setFormStatus(CMS_CONSTANT.tendocClarification);
                        }
                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "CM Setup") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "1";
                            var catman = $scope.oriMsgCustomFields.Category_Manager;
                            var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                            setAutoDistribution(catemanVal, "3#", strdate, "0");
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "Stage 2 - Tender Documents & Clarifications"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "3";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "Stage 3 & 4 - Tender Submissions & Evaluation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "4";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "Stage 1 - Initiation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "2";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "Stage 5 - Award"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "5";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc == "Stage 6 - Contract Management"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "6";
                        } else {
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
                    break;    
                    case '4':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed') {
                            setFormStatus(CMS_CONSTANT.tenSubEcalCompleted);
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.3 project cancelled') {
                            setFormStatus(CMS_CONSTANT.tenSubEcalCancelled);
                        } else {
                            setFormStatus(CMS_CONSTANT.tenSubEcal);
                        }
                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "CM Setup") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "1";
                            var catman = $scope.oriMsgCustomFields.Category_Manager;
                            var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                            setAutoDistribution(catemanVal, "3#", strdate, "0");
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "Stage 2 - Tender Documents & Clarifications"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "3";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "Stage 3 & 4 - Tender Submissions & Evaluation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "4";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "Stage 1 - Initiation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "2";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "Stage 5 - Award"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "5";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub == "Stage 6 - Contract Management"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "6";
                        } else {
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
                    break;  
                    case '5':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed') {
                            setFormStatus(CMS_CONSTANT.awardCompleted);
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.3 project cancelled') {
                            setFormStatus(CMS_CONSTANT.awardCancelled);
                        } else {
                            setFormStatus(CMS_CONSTANT.award);
                        }

                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "CM Setup") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "1";
                            var catman = $scope.oriMsgCustomFields.Category_Manager;
                            var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                            setAutoDistribution(catemanVal, "3#", strdate, "0");
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "Stage 2 - Tender Documents & Clarifications"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "3";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "Stage 3 & 4 - Tender Submissions & Evaluation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "4";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "Stage 1 - Initiation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "2";   
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "Stage 5 - Award"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                             $scope.oriMsgCustomFields.DSI_NextStage = "5";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award == "Stage 6 - Contract Management"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                             $scope.oriMsgCustomFields.DSI_NextStage = "6";
                        } else {
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
                    break;
                    case '6':
                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "13";
                        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        setFormStatus(CMS_CONSTANT.conmanagement); 
                        if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "CM Setup") {
                            $scope.oriMsgCustomFields.DSI_NextStage = "1";
                            var catman = $scope.oriMsgCustomFields.Category_Manager;
                            var catemanVal = catman.split('|')[2].trim().split(' ')[0];
                            setAutoDistribution(catemanVal, "3#", strdate, "0");
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "Stage 2 - Tender Documents & Clarifications"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "3";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "Stage 3 & 4 - Tender Submissions & Evaluation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "4";
                        } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "Stage 1 - Initiation"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                            $scope.oriMsgCustomFields.DSI_NextStage = "2";   
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "Stage 5 - Award"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                             $scope.oriMsgCustomFields.DSI_NextStage = "5";
                        } else if ($scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement == "Stage 6 - Contract Management"){
                            setAutoDistribution(buyersVal, "3#", strdate, "0");
                             $scope.oriMsgCustomFields.DSI_NextStage = "6";
                        } else {
                            setAutoDistribution(adminuserId,"7#",strdate,"0");  
                        }
                    break;
                }
            } 
            
        };             

        $scope.OnSectorChange=function(sector){
            $scope.oriMsgCustomFields.Cms_Details.Cont_Autho= "";
            $scope.oriMsgCustomFields.Cms_Details.hse_schools_text = "";
            $scope.ContractAutho = commonApi.getItemSelectionList({
                arrayObject : geAttributesSetDitails(sector,'Contracting Authority'),
                groupNameKey: "",
                modelKey : 'Value9',
                displayKey : 'Value9'
            });
            if($scope.oriMsgCustomFields.Cms_Details.Sector){
                $scope.freetext = $scope.oriMsgCustomFields.Cms_Details.Sector.toLowerCase().trim();
                if($scope.freetext == 'other' || $scope.freetext == 'hse' || $scope.freetext == 'schools - 1st & 2nd level'){
                    $scope.oriMsgCustomFields.Cms_Details.hse_schools_text = "Yes";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.hse_schools_text = "No";
                }
            }
        };

        $scope.onSubCategoryChange = function(subCategory){
            $scope.oriMsgCustomFields.Cms_Details.Domain= "";
            $scope.oriMsgCustomFields.Cms_Details.Sub_Domain = "";
            $scope.Domain = commonApi.getItemSelectionList({
                arrayObject : geAttributesSetDitails(subCategory,'Domain'),
                groupNameKey: "",
                modelKey : 'Value9',
                displayKey : 'Value9'
            });
        };

        $scope.OnDomainChange=function(domain){
            $scope.oriMsgCustomFields.Cms_Details.Sub_Domain = "";
            $scope.SubDomain = commonApi.getItemSelectionList({
                arrayObject : geAttributesSetDitails(domain,'Sub Domain'),
                groupNameKey: "",
                modelKey : 'Value9',
                displayKey : 'Value9'
            });
        };

        $scope.onSkipStageChange = function (skipOption) {
            if (skipOption) {
                $scope.oriMsgCustomFields.Cms_Details.Skip_to_Award = "";
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm ="";
                ProjectStageList();
            }
        }
        $scope.onNextStageChange = function (nextStage) {
            if (nextStage) {
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm = "";
                ProjectStageList();
            }
        };
        $scope.OnProjectStatusChange = function(){
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '1'){
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm = "";
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '2'){
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi = "";
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '3'){
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc = "";
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '4'){
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub = "";
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '5'){
                $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award = "";
            }
            ProjectStageList();
        }

        $scope.projectStatusOnChange = function(status){
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '1'){
                $scope.pro_Stastus = status.toLowerCase().trim();
                if($scope.pro_Stastus == '6.1 project completed' || $scope.pro_Stastus == '6.3 project cancelled' || $scope.pro_Stastus == '6.4 project declined (less than 25k)' || $scope.pro_Stastus == '6.5 redirected to client - out of scope - non-addressable spend' || $scope.pro_Stastus == '6.6 redirected to client - self-procure' || $scope.pro_Stastus == '6.7 redirected to client - 3rd party framework in place'){
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Cm_Show = "No";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Cm_Show = "Yes";
                }
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '2'){
                $scope.pro_Stastus = status.toLowerCase().trim();
                if($scope.pro_Stastus == '6.1 project completed' || $scope.pro_Stastus == '6.3 project cancelled' || $scope.pro_Stastus == '6.4 project declined (less than 25k)' || $scope.pro_Stastus == '6.5 redirected to client - out of scope - non-addressable spend' || $scope.pro_Stastus == '6.6 redirected to client - self-procure' || $scope.pro_Stastus == '6.7 redirected to client - 3rd party framework in place'){
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Initi_Show = "No";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Initi_Show = "Yes";
                }
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '3'){
                $scope.pro_Stastus = status.toLowerCase().trim();
                if($scope.pro_Stastus == '6.1 project completed' || $scope.pro_Stastus == '6.3 project cancelled' || $scope.pro_Stastus == '6.4 project declined (less than 25k)' || $scope.pro_Stastus == '6.5 redirected to client - out of scope - non-addressable spend' || $scope.pro_Stastus == '6.6 redirected to client - self-procure' || $scope.pro_Stastus == '6.7 redirected to client - 3rd party framework in place'){
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_tenDoc_Show = "No";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_tenDoc_Show = "Yes";
                }
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '4'){
                $scope.pro_ten_Sub = status.toLowerCase().trim();
                if($scope.pro_ten_Sub == '6.1 project completed' || $scope.pro_ten_Sub == '6.3 project cancelled' || $scope.pro_ten_Sub == '6.4 project declined (less than 25k)' || $scope.pro_ten_Sub == '6.5 redirected to client - out of scope - non-addressable spend' || $scope.pro_ten_Sub == '6.6 redirected to client - self-procure' || $scope.pro_ten_Sub == '6.7 redirected to client - 3rd party framework in place'){
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_tenSub_Show = "No";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_tenSub_Show = "Yes";
                }
            }
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '5'){
                $scope.award_Stage = status.toLowerCase().trim();
                if($scope.award_Stage == '6.1 project completed' || $scope.award_Stage == '6.3 project cancelled' || $scope.award_Stage == '6.4 project declined (less than 25k)' || $scope.award_Stage == '6.5 redirected to client - out of scope - non-addressable spend' || $scope.award_Stage == '6.6 redirected to client - self-procure' || $scope.award_Stage == '6.7 redirected to client - 3rd party framework in place'){
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Award_Show = "No";
                } else{
                    $scope.oriMsgCustomFields.Cms_Details.Pro_Stage_Award_Show = "Yes";
                }
            }
        }

        $scope.getStage=function(findSatge){
            switch(findSatge)
            {
                case '0':
                return 'Admin';
                case '1':
                return 'CM Setup';
                case '2':
                return 'Stage 1 - Initiation';
                case '3':
                return 'Stage 2 - Tender Documents & Clarifications';
                case '4':
                return 'Stage 3 & 4 - Tender Submissions & Evaluation';
                case '5':
                return 'Stage 5 - Award';
                case '6':
                return 'Stage 6 - Contract Management';
            }
        }; 
               
        function ProjectStageList() {
            var dsProjectstage = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val) {
                return val.Value3.indexOf('Project Stage') != -1;
            });
            if($scope.oriMsgCustomFields.CayegoryManagerId == currentUserid && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm != ''){
                if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications";
                    });  
                } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation";
                    });
                } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 5 - Award";
                    }); 
                } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation";
                    });   
                    
                } else if($scope.oriMsgCustomFields.Cms_Details.Project_Stage_Cm && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Initi && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenDoc && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_tenSub && $scope.oriMsgCustomFields.Cms_Details.Project_Stage_Award && !$scope.oriMsgCustomFields.Cms_Details.Project_Stage_ConManagement){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation" || val.Value8.trim() == "Stage 5 - Award";
                    });  
                }
            } else {
                if($scope.oriMsgCustomFields.DSI_CurrentStage == "0"){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" ;
                    });  
                }
                if($scope.oriMsgCustomFields.DSI_CurrentStage == "1"){
                    if($scope.oriMsgCustomFields.Cms_Details.Skip_to_Award =='Yes'){
                        dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                            return val.Value8.trim() == "Stage 5 - Award";
                        });
                    } else{
                        dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                            return val.Value8 == "Admin" || val.Value8 == "Stage 1 - Initiation";
                        });
                    }
                      
                } 
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "2") {
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications";
                    });
                }
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "3") {
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation";
                    });
                }
                if($scope.oriMsgCustomFields.DSI_CurrentStage == "4"){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 5 - Award";
                    });  
                }
                if($scope.oriMsgCustomFields.DSI_CurrentStage == "5"){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation";
                    });  
                }
                if($scope.oriMsgCustomFields.DSI_CurrentStage == "6"){
                    dsProjectstage = commonApi._.filter(dsProjectstage, function (val) {
                        return val.Value8 == "CM Setup" || val.Value8.trim() == "Stage 1 - Initiation" || val.Value8.trim() == "Stage 2 - Tender Documents & Clarifications" || val.Value8.trim() == "Stage 3 & 4 - Tender Submissions & Evaluation" || val.Value8.trim() == "Stage 5 - Award";
                    });  
                } 
            }
            
            if (dsProjectstage.length) {
                var secParam = {
                    arrayObject : dsProjectstage,
                    groupNameKey: "",
                    modelKey : "Value8",
                    displayKey : "Value8"
                };      
            $scope.Projectstage = commonApi.getItemSelectionList(secParam);
            }
        } 
            
        function loadConfig(callback) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getConfigJson",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&appBuilderId=" + $window.AppBuilderFormIDCode
            }).then(function (response) {
                if(!$scope.isDraft && !$scope.dbFormId){
                    var configAssign_Respons = response.data.Assign_Respons || [];
                    assignResponsibility(configAssign_Respons);
                    var configCont_Status = response.data.Cont_Status || [];
                    ContactStatus(configCont_Status)
                    var configIncoterms = response.data.Incoterms || [];
                    IncotermsSel(configIncoterms)
                    
                }
                callback && callback();
            },
            function (xhr) {
                $window.alert(DTUP_CONSTANT.validanErrorConfigMsg);
            });
        }
        
        function assignResponsibility(configAssign_Respons) {
            $scope.selectionList.Assignrespons = commonApi.getItemSelectionList({
                arrayObject: configAssign_Respons,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        function IncotermsSel(configIncoterms) {
            $scope.selectionList.IncotermsList = commonApi.getItemSelectionList({
                arrayObject: configIncoterms,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        function geAttributesSetDitails(type, list) {
            var dsContractAutho = commonApi._.filter(ds_Get_Attributes_Set_Dtls, function (val) {
                return val.Value8.indexOf(list) != -1;
            });
            if (type != null && type != '' && type != undefined) {
                var dsCMSDetailsList = commonApi._.filter(dsContractAutho, function (val) {
                    return val.Value6 == type;
                });
                if(dsCMSDetailsList.length){
                    dsContractAutho = dsCMSDetailsList;
                }
            }
           
            var uniContractAutho = [];
            if (dsContractAutho.length) {
                for (var i = 0; i < dsContractAutho.length; i++) {
                    var isFound = false;
                    if (uniContractAutho.length == 0) {
                        uniContractAutho.push(dsContractAutho[i]);
                    } else {
                        for (var j = 0; j < uniContractAutho.length; j++) {
                            if (uniContractAutho[j].Value9 == dsContractAutho[i].Value9) {
                                isFound = true;
                                break;
                            }
                        }
                        if (!isFound) {
                            uniContractAutho.push(dsContractAutho[i]);
                        }
                    }
                }
            }
            return uniContractAutho;
        }

        function geAttributesSetDtls(type){
            var dsSector = commonApi._.filter(ds_Get_Attributes_Set_Dtls, function (val) {
                return val.Value5.indexOf(type) != -1;
            });
            var uniqueSector = [];
            if (dsSector.length) {
                for(var i=0; i< dsSector.length; i++){
                    var isFound = false;
                    if(uniqueSector.length == 0){
                        uniqueSector.push(dsSector[i]);
                    }else{
                        for(var j=0; j<uniqueSector.length; j++){
                            if(uniqueSector[j].Value6 == dsSector[i].Value6){
                                isFound = true;
                                break;
                            }
                        }
                        if(!isFound){
                            uniqueSector.push(dsSector[i]);
                        }
                    }
                }
            }
           return uniqueSector;
        }

        function getConfigurableAttriburteByType(type){
            var AttributeByType = [];
            if(type){
                AttributeByType = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val) {
                  return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
              });
          }
           return AttributeByType;
        }

        function getSubCategoryAndParentArrMent(Categorytype, list){
            var subcatAndParr = [];
            subcatAndParr = commonApi._.filter(ds_Get_Attributes_Set_Dtls, function (val) {
                return val.Value6 == Categorytype && val.Value8.indexOf(list) != -1
            });
          return subcatAndParr;
        }
        function initORIview(serverDate){
            if(currentViewName == "ORI_VIEW")
                {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSEDUEDATE = serverDate;
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = serverDate;
                var dbFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
                var isForwardDraftbyMSG = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_FWD_MSG;
                var isDraftEditOri = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_EDITORI;
                var isDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
                
                if(dbFormId != "" && isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO"){
                    var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
                    $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
                }
                
            }
            /* set Contracting Authority configurable attributes list as per selected Sector */
            function SectorAttribute(sector){
                $scope.ContractAutho = commonApi.getItemSelectionList({
                    arrayObject : geAttributesSetDitails(sector,'Contracting Authority'),
                    groupNameKey: "",
                    modelKey : 'Value9',
                    displayKey : 'Value9'
                });
                if($scope.oriMsgCustomFields.Cms_Details.Sector){
                    $scope.freetext = $scope.oriMsgCustomFields.Cms_Details.Sector.toLowerCase().trim();
                    if($scope.freetext == 'other' || $scope.freetext == 'hse' || $scope.freetext == 'schools - 1st & 2nd level'){
                        $scope.oriMsgCustomFields.Cms_Details.hse_schools_text = "Yes";
                    } else{
                        $scope.oriMsgCustomFields.Cms_Details.hse_schools_text = "No";
                    }
                }
            };

            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                if ($scope.oriMsgCustomFields.Cms_Details.next_stage == 'Yes' && !$scope.oriMsgCustomFields.Proj_Status_disabled) {
                    $scope.oriMsgCustomFields.Cms_Details.Cont_Status = '';
                }
                if ($scope.oriMsgCustomFields.LotList.length) {
                    $timeout(function () {
                        onLotlist();
                        $scope.$apply();
                    });

                }
                $scope.selectionList.categorymanagerList = commonApi.getItemSelectionList({
                    arrayObject: setRolewiseUser(CMS_CONSTANT.categorymanager),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                $scope.selectionList.buyerList = commonApi.getItemSelectionList({
                    arrayObject: setRolewiseUser(CMS_CONSTANT.buyer),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                $scope.selectionList.adminList = commonApi.getItemSelectionList({
                    arrayObject: setRolewiseUser(CMS_CONSTANT.Admin),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                $scope.selectionList.operationmanagerList = commonApi.getItemSelectionList({
                    arrayObject: setRolewiseUser(CMS_CONSTANT.operationmanager),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
                $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
                $scope.CentGovBody = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Central Govt Body"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.TenderOutcome = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Tender Outcome"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.FurInfoRequests = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Further Information Requests"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.FurtherInfo = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Sub Contractors"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.Threshold = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Threshold"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.RecurrContract = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Recurring Contract"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.ParntAgree = commonApi.getItemSelectionList({
                    arrayObject: getSubCategoryAndParentArrMent($scope.oriMsgCustomFields.Cms_Details.mater_Category, "Parent Arrangement"),
                    groupNameKey: "",
                    modelKey: "Value9",
                    displayKey: "Value9"
                });
                $scope.NewExDemo = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("New or Ex-Demo"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.ConficIss = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Conflict of Interest Issued"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.FundBody = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Funding Body"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.ProjectComplex = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Project Complexity"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.TypeContract = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Type of Contract"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.ContractValue = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Total Contact Value Ex VAT"),
                    groupNameKey: "",
                    modelKey: "Value7",
                    displayKey: "Value7"
                });
                $scope.CovrReq = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("cover requirement"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.ProcedureType = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Procedure Type"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.ReqPlan = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Existing Framework"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.RedirectClient = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Redirecting Client"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                var projStatus = commonApi._.sortBy(getConfigurableAttriburteByType("Project Status"), 'Value8');
                $scope.ProjectStatus = commonApi.getItemSelectionList({
                    arrayObject: projStatus,
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.Projectdecision = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Project Decision"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.sectorData = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Sector"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "0" && $scope.oriMsgCustomFields.Cms_Details.Sector) {
                    var sectordata = $scope.sectorData[0].options,
                        sector = 'No',
                        element = '',
                        configdata = '',
                        selectedSector = '';
                    for (var i = 0; i < sectordata.length; i++) {
                        element = sectordata[i];
                        selectedSector = $scope.oriMsgCustomFields.Cms_Details.Sector.replace('&amp;', '&');
                        configdata = selectedSector.indexOf(element.modelValue);
                        if (configdata != -1) {
                            sector = 'Yes';
                            $scope.oriMsgCustomFields.Cms_Details.Sector = selectedSector;
                            SectorAttribute($scope.oriMsgCustomFields.Cms_Details.Sector);
                        }
                    }
                    if (sector == 'No') {
                        $scope.oriMsgCustomFields.Cms_Details.Sector = '';
                        $scope.oriMsgCustomFields.Cms_Details.Cont_Autho = '';
                    }

                }

                $scope.MasterCat = commonApi.getItemSelectionList({
                    arrayObject: geAttributesSetDtls("Master Category"),
                    groupNameKey: "",
                    modelKey: "Value6",
                    displayKey: "Value6"
                });
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "0" && $scope.oriMsgCustomFields.Cms_Details.mater_Category) {
                    var masterCat = $scope.MasterCat[0].options,
                        master = 'No',
                        tempMasterCat = '',
                        masterCatagory = '',
                        configMaster = '';
                    for (var i = 0; i < masterCat.length; i++) {
                        tempMasterCat = masterCat[i];
                        masterCatagory = $scope.oriMsgCustomFields.Cms_Details.mater_Category.replace('&amp;', '&');
                        configMaster = masterCatagory.indexOf(tempMasterCat.modelValue);
                        if (configMaster != -1) {
                            master = 'Yes';
                            $scope.oriMsgCustomFields.Cms_Details.mater_Category = masterCatagory;
                        }
                    }
                    if (master == 'No') {
                        $scope.oriMsgCustomFields.Cms_Details.mater_Category = '';
                    }
                }
                if (!$scope.oriMsgCustomFields.Cms_Details.Cont_Autho && !$scope.oriMsgCustomFields.Cms_Details.Sector) {
                    $scope.ContractAutho = commonApi.getItemSelectionList({
                        arrayObject: geAttributesSetDitails("", 'Contracting Authority'),
                        groupNameKey: "",
                        modelKey: 'Value9',
                        displayKey: 'Value9'
                    });
                }
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "0" && $scope.oriMsgCustomFields.Cms_Details.Cont_Autho) {
                    var ConAutho = $scope.ContractAutho[0].options;
                    var ConAhthoData = 'No',
                        tempCon = '',
                        configCon = '';
                    for (var i = 0; i < ConAutho.length; i++) {
                        tempCon = ConAutho[i];
                        configCon = $scope.oriMsgCustomFields.Cms_Details.Cont_Autho.indexOf(tempCon.modelValue);
                        if (configCon != -1) {
                            ConAhthoData = 'Yes';
                            SectorAttribute($scope.oriMsgCustomFields.Cms_Details.Sector);
                        }
                    }
                    if (ConAhthoData == 'No' && $scope.oriMsgCustomFields.Cms_Details.hse_schools_text != "Yes") {
                        $scope.oriMsgCustomFields.Cms_Details.Cont_Autho = '';
                    }
                }
                $scope.Domain = commonApi.getItemSelectionList({
                    arrayObject: geAttributesSetDitails("", 'Domain'),
                    groupNameKey: "",
                    modelKey: 'Value9',
                    displayKey: 'Value9'
                });
                $scope.SubDomain = commonApi.getItemSelectionList({
                    arrayObject: geAttributesSetDitails("", 'Sub Domain'),
                    groupNameKey: "",
                    modelKey: 'Value9',
                    displayKey: 'Value9'
                });

                $scope.Incoterms = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("IncoTerms"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });
                $scope.SubCategoryCode = commonApi.getItemSelectionList({
                    arrayObject: getSubCategoryAndParentArrMent($scope.oriMsgCustomFields.Cms_Details.mater_Category, "Sub Category Code"),
                    groupNameKey: "",
                    modelKey: "Value9",
                    displayKey: "Value9"
                });

                ProjectStageList();
                $scope.disableForAdmin = false;
                $scope.disablefileds = false;
                if ($scope.oriMsgCustomFields.DSI_CurrentStage == "0") {
                    $scope.disableForAdmin = true;
                }
                loadConfig(function () {
                    $timeout(function () { });
                    $scope.update();
                });
            }
        }    
           
        function setRolewiseUser(strRole) {
            //set role wise list dropdown
            var setUserRolle = [];
            if (ds_Projusers_Role.length) {
                setUserRolle = commonApi._.filter(ds_Projusers_Role, function (val) {
                    if (val.Value.split('|')[0].trim() == strRole) {
                        return val.Value;
                    }
                });
            }
            return setUserRolle;
        }
        function setAutoDistribution(strUser, strAction, strDueDate,strDueDays) {
            commonApi.setDistributionNode({
				actionNodeList : [{
					strUser : strUser,
					strAction :strAction,
					strDate : commonApi.calculateDistDateFromDays({
						baseDate: $scope.formatDate(new Date(strDueDate), CMS_CONSTANT.yymmdddateformate),
						days : strDueDays
					})
				}],
				autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE :  (currentViewName == 'RES_VIEW') ? 13 : 3
			});
        }
        function setFormStatus(strstatus) {  
			// Form's Staus will be set from below code.
			var strFormStatusId = commonApi.getFormStatusId({
				availFormStatusesList : availFormStatuses,
				strStatus : strstatus
            });
            
			if (strFormStatusId) {             
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}   
                    
        }

        function formpemission(){
            if (currentViewName == "RES_VIEW") {
				if ($scope.strCanReply == '') {
					alert("You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.");
					return true;
				}
            }
            return false;
        }

        function clearActionByMsg() {
            var ActionData = commonApi._.filter(incompleteActionsByMsg, function (val) {
                return val.Value4 == 'Respond';
            });
            if (ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                for (var i = 0; i < ActionData.length; i++) {
                    var AutocompleteMsg = angular.copy(STATIC_OBJ_DATA.autocompleteMsgStructure);
                    AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
                    AutocompleteMsg.DS_MSG_AC_FORM = AppId;
                    AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
                    AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
                    AutocompleteMsg.DS_MSG_AC_ACTION = "3";
                    AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                    insertpoint.push(AutocompleteMsg);
                }
            }
        }
        angular.element('.export-btn').hide();
        $scope.isCallForDraft = false;
        $scope.update();

        $window.CMS_FinalCallback = function () {
            formpemission();
            clearActionByMsg();
            if ($scope.oriMsgCustomFields.DSI_CurrentStage == "2") {
                onLotlist();
            }
            $scope.addCustomClass();
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';
            $scope.oriMsgCustomFields.Cms_Details.next_stage = 'Yes';
            if($scope.oriMsgCustomFields.DSI_CurrentStage == '5'){
                if($scope.oriMsgCustomFields.Cms_Details.Cont_Status.toLowerCase().trim() == '6.1 project completed'){
                    $scope.disableItem = true;
                    $scope.oriMsgCustomFields.Proj_Status_disabled = true;
                }
            }
            setshowfiled();
            return $scope.setflow();
        };
        $window.draftSubmitCallBack = function () {
            $scope.isCallForDraft = true;
            $scope.oriMsgCustomFields.Cms_Details.next_stage = 'No';
            setshowfiled()
        }
       
    }
    return FormController;
});  

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof CMS_FinalCallback !== "undefined") {
		return CMS_FinalCallback();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}