define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, $filter, Notification) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		if($scope.$parent.priv && $scope.$parent.priv.canPrint){
			$scope.$parent.priv.canPrint = false;
		}
		angular.element("#btnSaveDraft").hide();
		
		$scope.isXHRon = false;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.MeetingItems = $scope.oriMsgCustomFields.Meeting_Items_Group.Items;
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		$scope.isDSFormId = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] != '');
		$scope.isEditORI = ($scope.isDSFormId && ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'NO'));
		$scope.TaskFormList = $scope.getValueOfOnLoadData('DS_ASI_Task_FormDetail');
		$scope.curStatus = $scope.oriMsgCustomFields.Meeting_Status || "in progress";
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			STATIC_OBJ = {
				participant: {
					"Participant_Name": "",
					"Participant_Is_External_user": "No",
					"Participation_Status": ""
				},
				Previous_Task: {
					"PrevTaskNo":"",
					"PrevParentNo":"",
					"PrevStatus":"",
					"PrevAssignedTo":"",
					"PrevTaskTitle": "",
					"FormURL":""
				},
				task: {
					"TaskName": "",
					"TaskAssignedTO": "",
					"TaskAssignedToExternal": "",
					"TaskDays": "",
					"TaskVerificationRequired": "",
					"TaskDetails": ""
				},
				taskFormAutoCreateNode: {
					ACF_01_DS_Logo: '',
					ACF_01_ActivityId: '',
					ACF_01_ORI_FORMTITLE: '',
					ACF_01_DS_FORMTITLE: '',
					ACF_01_Task_Type: '',
					ACF_01_Task_GUID: '',
					ACF_01_CREATED_BY: '',
					ACF_01_Task_Detail: '',
					ACF_01_DS_CLOSE_DUE_DATE: '',
                    ACF_01_Task_Assigned_TO: '',
					ACF_01_Task_Verification_Required: '',
					ACF_01_Task_Reference: '<<DS_Form_ID>>',
					ACF_01_LastReviewer: '',
					ACF_01_CurrStage: '2', 
					ACF_01_DS_FORMCONTENT1: '<<DS_Form_ID>>',
					ACF_01_DS_FORMCONTENT2: '',
					ACF_01_DS_AUTODISTRIBUTE: '3',
					ACF_01_AUTOCREATE_INDEX: '',
                    ACF_01_REPEATING_VALUES: {
                        ACF_01_DS_AutoDistribute_User_Group: {
                            ACF_01_DS_AutoDistribute_Users: [{
                                ACF_01_DS_PROJDISTUSERS: '',
                                ACF_01_DS_FORMACTIONS: '',
                                ACF_01_DS_ACTIONDUEDATE: '',
                                ACF_01_DS_DUEDAYS: ''
                            }]
                        }
                    }
				}
			},
			WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID'),
			DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'),
			DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_WS_STATUS'),
			prevNotes = $scope.getValueOfOnLoadData('DS_ASI_TEMP_MMLatestNotes');
			$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
			$scope.allFromOpenTask = $scope.getValueOfOnLoadData('DS_ASI_TEMP_MMAllOpenTask');
		
			var timeZoneMap = {
				"Africa/Bangui": "W. Central Africa Standard Time",
				"Africa/Cairo": "Egypt Standard Time",
				"Africa/Casablanca": "Morocco Standard Time",
				"Africa/Harare": "South Africa Standard Time",
				"Africa/Johannesburg": "South Africa Standard Time",
				"Africa/Lagos": "W. Central Africa Standard Time",
				"Africa/Monrovia": "Greenwich Standard Time",
				"Africa/Nairobi": "E. Africa Standard Time",
				"Africa/Windhoek": "Namibia Standard Time",
				"America/Anchorage": "Alaskan Standard Time",
				"America/Argentina/San_Juan": "Argentina Standard Time",
				"America/Asuncion": "Paraguay Standard Time",
				"America/Bahia": "Bahia Standard Time",
				"America/Bogota": "SA Pacific Standard Time",
				"America/Buenos_Aires": "Argentina Standard Time",
				"America/Caracas": "Venezuela Standard Time",
				"America/Cayenne": "SA Eastern Standard Time",
				"America/Chicago": "Central Standard Time",
				"America/Chihuahua": "Mountain Standard Time (Mexico)",
				"America/Cuiaba": "Central Brazilian Standard Time",
				"America/Denver": "Mountain Standard Time",
				"America/Fortaleza": "SA Eastern Standard Time",
				"America/Godthab": "Greenland Standard Time",
				"America/Guatemala": "Central America Standard Time",
				"America/Halifax": "Atlantic Standard Time",
				"America/Puerto_Rico": "Atlantic Standard Time",
				"America/Indianapolis": "US Eastern Standard Time",
				"America/Indiana/Indianapolis": "US Eastern Standard Time",
				"America/La_Paz": "SA Western Standard Time",
				"America/Los_Angeles": "Pacific Standard Time",
				"America/Mexico_City": "Mexico Standard Time",
				"America/Montevideo": "Montevideo Standard Time",
				"America/New_York": "Eastern Standard Time",
				"America/Noronha": "Fernando de Noronha Time",
				"America/Phoenix": "US Mountain Standard Time",
				"America/Regina": "Canada Central Standard Time",
				"America/Santa_Isabel": "Pacific Standard Time (Mexico)",
				"America/Santiago": "Pacific SA Standard Time",
				"America/Sao_Paulo": "Brazil Time",
				"America/St_Johns": "Newfoundland Standard Time",
				"America/Tijuana": "Pacific Standard Time",
				"Antarctica/McMurdo": "New Zealand Standard Time",
				"Atlantic/South_Georgia": "UTC-02",
				"Asia/Almaty": "Central Asia Standard Time",
				"Asia/Amman": "Jordan Standard Time",
				"Asia/Baghdad": "Arabia Standard Time",
				"Asia/Baku": "Azerbaijan Standard Time",
				"Asia/Bangkok": "SE Asia Standard Time",
				"Asia/Beirut": "Middle East Standard Time",
				"Asia/Calcutta": "India Standard Time",
				"Asia/Colombo": "Sri Lanka Standard Time",
				"Asia/Damascus": "Syria Standard Time",
				"Asia/Dhaka": "Bangladesh Standard Time",
				"Asia/Dubai": "Gulf Standard Time",
				"Asia/Irkutsk": "North Asia East Standard Time",
				"Asia/Jerusalem": "Israel Standard Time",
				"Asia/Kabul": "Afghanistan Standard Time",
				"Asia/Kamchatka": "Kamchatka Standard Time",
				"Asia/Karachi": "Pakistan Standard Time",
				"Asia/Katmandu": "Nepal Standard Time",
				"Asia/Kolkata": "India Standard Time",
				"Asia/Krasnoyarsk": "North Asia Standard Time",
				"Asia/Kuala_Lumpur": "Singapore Standard Time",
				"Asia/Kuwait": "Arab Standard Time",
				"Asia/Magadan": "Magadan Standard Time",
				"Asia/Muscat": "Arabian Standard Time",
				"Asia/Novosibirsk": "N. Central Asia Standard Time",
				"Asia/Oral": "West Asia Standard Time",
				"Asia/Rangoon": "Myanmar Standard Time",
				"Asia/Riyadh": "Arab Standard Time",
				"Asia/Seoul": "Korea Standard Time",
				"Asia/Shanghai": "China Standard Time",
				"Asia/Singapore": "Singapore Standard Time",
				"Asia/Saigon": "Indochina Time",
				"Asia/Taipei": "Taipei Standard Time",
				"Asia/Tashkent": "West Asia Standard Time",
				"Asia/Tbilisi": "Georgian Standard Time",
				"Asia/Tehran": "Iran Standard Time",
				"Asia/Tokyo": "Japan Standard Time",
				"Asia/Ulaanbaatar": "Ulaanbaatar Standard Time",
				"Asia/Vladivostok": "Vladivostok Standard Time",
				"Asia/Yakutsk": "Yakutsk Standard Time",
				"Asia/Yekaterinburg": "Ekaterinburg Standard Time",
				"Asia/Yerevan": "Armenian Standard Time",
				"Atlantic/Azores": "Azores Standard Time",
				"Atlantic/Cape_Verde": "Cape Verde Standard Time",
				"Atlantic/Reykjavik": "Greenwich Standard Time",
				"Australia/Adelaide": "Cen. Australia Standard Time",
				"Australia/Brisbane": "E. Australia Standard Time",
				"Australia/Darwin": "AUS Central Standard Time",
				"Australia/Hobart": "Eastern Standard Time (Tasmania)",
				"Australia/Perth": "W. Australia Standard Time",
				"Australia/Sydney": "Eastern Standard Time (New South Wales)",
				"Australia/Canberra": "Eastern Standard Time (New South Wales)",
				"Australia/Melbourne": "AUS Eastern Standard Time",
				"Etc/GMT": "UTC",
				"Etc/GMT+11": "UTC-11",
				"Etc/GMT+12": "Dateline Standard Time",
				"Etc/GMT+2": "UTC-02",
				"Etc/GMT-12": "UTC+12",
				"Europe/Amsterdam": "W. Europe Standard Time",
				"Europe/Athens": "GTB Standard Time",
				"Europe/Belgrade": "Central Europe Standard Time",
				"Europe/Berlin": "W. Europe Standard Time",
				"Europe/Brussels": "Central European Time",
				"Europe/Budapest": "Central Europe Standard Time",
				"Europe/Dublin": "GMT Standard Time",
				"Europe/Helsinki": "FLE Standard Time",
				"Europe/Istanbul": "Eastern European Time",
				"Europe/Kiev": "FLE Standard Time",
				"Europe/London": "GMT Standard Time",
				"Europe/Minsk": "E. Europe Standard Time",
				"Europe/Moscow": "Russian Standard Time",
				"Europe/Paris": "Central European Time",
				"Europe/Sarajevo": "Central European Standard Time",
				"Europe/Warsaw": "Central European Standard Time",
				"Europe/Lisbon": "Western European Time",
				"Indian/Mauritius": "Mauritius Standard Time",
				"Pacific/Apia": "West Samoa Time",
				"Pacific/Auckland": "New Zealand Standard Time",
				"Pacific/Fiji": "Fiji Standard Time",
				"Pacific/Guadalcanal": "Solomon Islands Time",
				"Pacific/Guam": "Chamorro Standard Time",
				"Pacific/Honolulu": "Hawaiian Standard Time",
				"Pacific/Pago_Pago": "Samoa Standard Time",
				"Pacific/Port_Moresby": "Papua New Guinea Time",
				"Pacific/Tongatapu": "Tonga Standard Time",
				"Pacific/Midway": "Samoa Standard Time",
				"Pacific/Enderbury": "Phoenix Is. Time",
				"Pacific/Kiritimati": "Line Islands Standard Time"
			};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		
		if($scope.isOriPrintView){
			$scope.NoClosedTask = 'Yes';
			// adding task url in meeting Items
			if($scope.TaskFormList.length){
				$timeout(function () {
					angular.forEach($scope.TaskFormList, function(item){
						if(item.URL3 && angular.element('#'+item.Value23)[0]){
							angular.element('#'+item.Value23)[0].href = item.URL3;
						}
						if(item.Value11 && item.Value11.split('|')[1]  && item.Value11.split('|')[1].trim().toLowerCase() == 'closed'){
							$scope.NoClosedTask = 'No';
						}
					});
				}, 500);
			}
		}

		$scope._onObrRadioChange = function(rowObrItem, option){
			if(rowObrItem.value){
				rowObrItem.selectedRadioLabel = option.Label;
			}else{
				rowObrItem.selectedRadioLabel = "";
			}
		};

		$scope.getPreviousRecordNote = function(recordItem){
			if(prevNotes.length && recordItem.Item_GUID){
				var foundObj = commonApi._.find(prevNotes, function(item){
					return item.Value2 == recordItem.Item_GUID;
				});
				if(foundObj.Value3){
					recordItem.MeetingNotes = foundObj.Value3;
					$timeout(function () {
						$scope.expandTextAreaOnLoad();
					}, 100);
				}
			}
		};
		
		$scope.showAllOpenTasks = function(){
			$scope.oriMsgCustomFields.ShowAllOpenTask = "Yes";
			for(var r=0; r<$scope.MeetingItems.length; r++){
				var recordItem = $scope.MeetingItems[r];
				if(recordItem.sectionType != 'Section'){
					if(!recordItem.Previous_Task_group){
						recordItem.Previous_Task_group = {};
						recordItem.Previous_Task_group.Previous_Task = [];
					}
					recordItem.Previous_Task_group.Previous_Task = [];
					if($scope.allFromOpenTask.length && recordItem.Item_GUID){
						for(var i=0; i<$scope.allFromOpenTask.length; i++){
							if($scope.allFromOpenTask[i].Value6.split('---')[0].trim() == recordItem.Item_GUID){
								var tempData = angular.copy(STATIC_OBJ.Previous_Task);
								tempData.PrevTaskNo = $scope.allFromOpenTask[i].Value1;
								tempData.PrevParentNo = $scope.allFromOpenTask[i].Value2;
								tempData.PrevAssignedTo = $scope.allFromOpenTask[i].Value3;
								tempData.FormURL = $scope.allFromOpenTask[i].Value4;
								tempData.PrevStatus = $scope.allFromOpenTask[i].Value5;
								tempData.PrevTaskTitle = $scope.allFromOpenTask[i].Value7;
								recordItem.Previous_Task_group.Previous_Task.push(tempData);	
							}
						}
					}
				}
			}
		};

		// date comparison with other date logic 
		$scope.dateChangeEvent = function (paramObj) {
			if (paramObj.node[paramObj.compareDate1] && paramObj.node[paramObj.compareDate2]) {
				var date1 = new Date(paramObj.node[paramObj.compareDate1]),
					date2 = new Date(paramObj.node[paramObj.compareDate2]);

				if (paramObj.comparionMethod == 'greater' && date1 >= date2) {
					Notification.error({
						title: 'Validation Error',
						message: paramObj.fieldName2 + ' should be smaller than ' + paramObj.fieldName1
					});
					paramObj.node[paramObj.compareDate1] = '';
				} else if (paramObj.comparionMethod == 'less' && date1 <= date2) {
					Notification.error({
						title: 'Validation Error',
						message: paramObj.fieldName1 + ' should be greater than ' + paramObj.fieldName2
					});
					paramObj.node[paramObj.compareDate1] = '';
				}
			}
		};

		$scope.onExtUserCheckboxChange = function(participant){
			participant.Participant_Name = "";
		};
		$scope.onIsAssignedToExternalChange = function(taskItem){
			taskItem.TaskAssignedTO = "";
		};
		$scope.onParticipantNameChange = function(participant, index){
			var participants = $scope.oriMsgCustomFields.Participants_Group.Participants;
			if(participant.Participant_Name){
				for(var i = 0; i< participants.length; i++){
					if(i != index && participants[i].Participant_Name == participant.Participant_Name){
						alert('Duplicate Participant');
						participant.Participant_Name = "";
						if(participant.Participant_Is_External_user.toLowerCase() == 'no'){
							$scope.participantList = commonApi.getItemSelectionList({
								arrayObject: projAllRolesList,
								groupNameKey: "",
								modelKey: "Value",
								displayKey: "Name"
							});
						}
						break;
					}
				}
			}
		};
		
		function addAttendeesToList(attendeesList){
			if(!attendeesList.length){
				return;
			}
			var partinpents = $scope.oriMsgCustomFields.Participants_Group.Participants;
			var partee;
			angular.forEach(attendeesList, function (item) {
				partee = angular.copy(STATIC_OBJ.participant);
				partee.Participant_Name = item.Value3.indexOf('||') != -1 ? item.Value3.split('||').join('#') : item.Value3;
				partee.Participant_Is_External_user = item.Value4 == "" ? "No" : item.Value4;
				partinpents.push(partee);
			});
		}
		function addMeetingItemsTOList(rawItems){
			var Items = [];
			var finalItemsList = [];
			angular.forEach(rawItems, function (item, index) {
				var number_control = item.Value13 && item.Value13 != 'false' ? true : false;
				var range_control = item.Value18 && item.Value18 != 'false' ? true : false;
				var meetingItem = {
					"Item_No": item.Value4,
					"Item_GUID": item.Value5,
					"Item_Label": item.Value3,
					"Observation": {
						"control": item.Value12,
						"is_number_control": number_control,
						"is_range_control": range_control,
						"is_required": item.Value19,
						"optionsGroup": {
							"options": []
						},
						"field_label": item.Value10,
						"field_name": item.Value16,
						"value": item.Value22,
						"min_field_label": item.Value11,
						"max_field_label": item.Value7,
						"min_field_name": item.Value8,
						"max_field_name": item.Value21,
						"min_value": item.Value17,
						"max_value": item.Value23,
						"min_valid_value": item.Value14,
						"max_valid_value": item.Value15,
						"AddRemarks":  item.Value20
					},
					"sectionType": item.Value6,
					"MeetingNotes": "",
					"TaskListGroup": {
						"TaskList": []
					},
					"Previous_Task_group": { 
						"Previous_Task": []
					}
				};
				Items.push(meetingItem);
			});
			finalItemsList = commonApi._.uniq(Items, function(item){
				return item.Item_GUID;
			});
			var Grouped = commonApi._.groupBy(rawItems, function(item){
				return item.Value5;
			});
			angular.forEach(finalItemsList, function(finalItem){
				var groupedItem = Grouped[finalItem.Item_GUID];
				if(groupedItem && groupedItem.length) {
					for(var i = 0; i < groupedItem.length; i++){
						finalItem.Observation.optionsGroup.options.push({
							"Label": groupedItem[i].Value24,
							"Value": groupedItem[i].Value25
						});
					}
				}
			});
			$scope.MeetingItems = finalItemsList;
			$scope.oriMsgCustomFields.Meeting_Items_Group.Items = $scope.MeetingItems;
			$scope.expandTextAreaOnLoad();
		}
		$scope.addNewItem = function (list, addItemFor) {
			$scope.addRepeatingRow(list, angular.copy(STATIC_OBJ[addItemFor]));
		};
		$scope.deleteItem = function (list, index) {
			list.splice(index, 1);
		};
		$scope.scrollTOListItem = function (eID) {
            if (eID !== '') {
                $timeout(function () {
                    var newId = "#ID_" + eID;
                    var offset = $(newId).offset();
                    if (offset) {
                        var scrollTotal = offset.top - 100;
                        $('html,body').animate({
                            scrollTop: scrollTotal
                        }, 500);
                    }
                }, 500);
            }
		};
		
		if($scope.isOriPrintView){
			$scope.hasAttendee = commonApi._.some($scope.oriMsgCustomFields.Participants_Group.Participants, function(item){
				return item.Participation_Status.toLowerCase() == "attendee";
			});
			$scope.hasApologies = commonApi._.some($scope.oriMsgCustomFields.Participants_Group.Participants, function(item){
				return item.Participation_Status.toLowerCase() == "apologies";
			});
			$scope.hasDitribution = commonApi._.some($scope.oriMsgCustomFields.Participants_Group.Participants, function(item){
				return item.Participation_Status.toLowerCase() == "ditribution";
			});
		}
		if($scope.isOriView){
			var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo'),
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			if(!$scope.dSFormId){
				var meetingItemsLIst = $scope.getValueOfOnLoadData('DS_ASI_TEMP_MM_Items_Group');
				var attendeesItemsList = $scope.getValueOfOnLoadData('DS_ASI_TEMP_MMAttendees');
				if(meetingItemsLIst.length){
					$scope.oriMsgCustomFields.Date = getDateFromZone();
					addMeetingItemsTOList(meetingItemsLIst);
					addAttendeesToList(attendeesItemsList);
				}else{
					$scope.noApprovedTemplate = true;
				}
			}
			setBasicList();
			if(!$scope.isEditORI){
				setClientlogo();
			}
			if($scope.oriMsgCustomFields.ShowAllOpenTask){
				$scope.showAllOpenTasks();
			}
		}

		function setBasicList(){
			$scope.projUserList = commonApi.getItemSelectionList({
				arrayObject: projAllRolesList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
			$scope.participantList = commonApi.getItemSelectionList({
				arrayObject: projAllRolesList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
		}

		function setClientlogo() {
            if (WorkingUserID.length) {
                var strOrgName = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
		}
		
		function getDateTimeFromZone() {
			var userTimeZone = timeZoneMap[$window.USP.timezoneId];
			var serverDatemilisec = new Date($scope.serverDate).getTime();
			var utcActualTime = serverDatemilisec - 3600000;
            var offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            var nd = new Date(parseInt(utcActualTime) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
            return nd + " " + userTimeZone;
		}

		function getDateFromZone(){
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}

		$scope.getDateFromZone = function(){
			return getDateFromZone();
		};

		function setAutocreateNodesTask(){
			var autoCrtIndex = 0;
			var items = $scope.MeetingItems;
			$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
			var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : 'open'
			});
            if (items.length) {
				var newTaskNode = {},
					Workinguser = WorkingUserID['0'].Value.trim(),
                    strAction = '3#',
                    strDuedays = '';
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
                for (var i = 0; i < items.length; i++) {
					var meetingItem = items[i];
					var taskList = meetingItem.TaskListGroup.TaskList;
					for (var j = 0; j < taskList.length; j++) {
						if(taskList[j].TaskCreated && taskList[j].TaskCreated == '1'){
							continue;
						}
						var TaskDays = !isNaN(taskList[j].TaskDays) && parseInt(taskList[j].TaskDays) || 3;
						newTaskNode = angular.copy(STATIC_OBJ.taskFormAutoCreateNode);
						strDuedays = commonApi.calculateDistDateFromDays({
							baseDate: $scope.todayDateDbFormat,
							days: TaskDays
						});
						var taskAssignedTo = taskList[j].TaskAssignedTO;
						if(taskList[j].TaskAssignedToExternal.toLowerCase() == 'yes'){
							taskAssignedTo = commonApi._.find(projAllRolesList, function(userItem){
								return userItem.Value.split('|')[2].split('#')[0].trim() ==  $scope.currentUserid;
							});
							taskAssignedTo = taskAssignedTo.Value;
						}
						autoCrtIndex = autoCrtIndex + 1;
						taskList[j].TaskCreated ="1";
						taskList[j].Task_GUID = commonApi.guId();
						newTaskNode.ACF_01_DS_Logo = $scope.oriMsgCustomFields.DS_Logo;
						newTaskNode.ACF_01_ActivityId = items[i].Item_GUID + '---' + items[i].Item_No;
						newTaskNode.ACF_01_Task_GUID =  taskList[j].Task_GUID;
						newTaskNode.ACF_01_ORI_FORMTITLE = taskList[j].TaskName;
						newTaskNode.ACF_01_DS_FORMTITLE = taskList[j].TaskName;
						newTaskNode.ACF_01_Task_Type = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMGROUPNAME;
						newTaskNode.ACF_01_Task_Detail = taskList[j].TaskDetails;
						newTaskNode.ACF_01_DS_CLOSE_DUE_DATE = strDuedays;
						newTaskNode.ACF_01_Task_Assigned_TO = taskAssignedTo;
						newTaskNode.ACF_01_CREATED_BY = Workinguser.split('|')[0].trim();
						newTaskNode.ACF_01_Task_Verification_Required =  taskList[j].TaskVerificationRequired || 'No';
						newTaskNode.ACF_01_Task_Reference =  '<<DS_Form_ID>>';
						newTaskNode.ACF_01_LastReviewer =  Workinguser;
						newTaskNode.ACF_01_CurrStage =  '2';
						newTaskNode.ACF_01_DS_FORMCONTENT1 =  '<<DS_Form_ID>>';
						newTaskNode.ACF_01_DS_AUTODISTRIBUTE =  '3';
						newTaskNode.ACF_01_DS_FORMCONTENT2 =  items[i].Item_GUID;
						newTaskNode.ACF_01_DS_ALL_FORMSTATUS = strFormStatusId.split('#')[0].trim();
						newTaskNode.ACF_01_DS_Ref_AppId = $window.AppBuilderFormIDCode;
						newTaskNode.ACF_01_AUTOCREATE_INDEX = autoCrtIndex;
						newTaskNode.ACF_01_RaisedOnDate = getDateTimeFromZone();
						var childNodes = newTaskNode.ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users;
						if (childNodes && childNodes.length) {
							for (var k = 0; k < childNodes.length; k++) {
								childNodes[k].ACF_01_DS_PROJDISTUSERS = taskAssignedTo.split('|')[2].split('#')[0].trim();
								childNodes[k].ACF_01_DS_FORMACTIONS = strAction;
								childNodes[k].ACF_01_DS_ACTIONDUEDATE = strDuedays;
								childNodes[k].ACF_01_DS_DUEDAYS = TaskDays;
							}
						}
						$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);
					}
                }
            }
		}

		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}
		function setWorkFlow(){
			var tempList = [];
			$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			angular.forEach($scope.oriMsgCustomFields.Participants_Group.Participants, function(item){
				if(item.Participant_Name && item.Participant_Is_External_user == 'No' && item.Participant_Name.split('|')[2]){
					tempList.push({
						strUser: item.Participant_Name.split('|')[2].trim(),
						strAction: '7#For Information',
						strDate: ''
					});
				}
			});
			if(tempList.length){
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE:  "3"
				});
			}
		}

		$scope.update();
		$window.oriformSubmitCallBack = function () {
			if($scope.noApprovedTemplate){
				alert('No approved template found for use');
				return true;
			}
			if($scope.isOriView){
				$scope.oriMsgCustomFields.ORI_FORMTITLE =  $scope.oriMsgCustomFields.Title +" :: " + $scope.formatDate($scope.oriMsgCustomFields.Date, 'dd-M-yy', 'yy-mm-dd');
				updateFormStatus($scope.oriMsgCustomFields.Meeting_Status.toLowerCase());
				if($scope.oriMsgCustomFields.Meeting_Status.toLowerCase() == "closed"){
					setWorkFlow();
					setAutocreateNodesTask();
				}
			}
			return false;
		};
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}