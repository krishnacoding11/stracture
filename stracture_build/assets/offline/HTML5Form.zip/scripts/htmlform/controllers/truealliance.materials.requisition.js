/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection', '../components/table.util', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        }
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;
        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });
        $scope.stopAutoSaveDraftTimerFromClientSide();
        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        $scope.isRespond = false;
        var STATIC_OBJ_DATA = {
            RequisitionsList: {
                RequisitionisSelected: false,
                TechnicalSpecification: "",
                RequisitionsDesc: "",
                RequisitionsQty: "",
                RequisitionsUnit: "",
                RequisitionsRate: "",
                RequisitionsTotal: "",
                RequisitionsTargetCost: "",
                RequisitionsDeliveryDate: "",
                RequisitionsContractNo: "",
                RequisitionsWBS: "",
                RequisitionsCBS: ""
            },
            ResponseList: {
                Role_Name: "",
                User_Name: "",
                Res_Date: "",
                PM_USer:"",
                User_Response: "",
                User_Comments: "",
                Response_By: "",
                Lable_Display:"",
                Is_Old: "New"
            }
        }

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.clauseCommentGroup = $scope.oriMsgCustomFields["clauseCommentGroup"];
        $scope.triggerChangeGroup = $scope.oriMsgCustomFields["triggerChangeGroup"];
        $scope.approvalGroup = $scope.oriMsgCustomFields["approvalGroup"];
        $scope.alliancePrinciples = $scope.oriMsgCustomFields["alliancePrinciples"];
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var submitFlag=false;
        $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
        $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.DS_PAA_MPC_IS_USER_CONTRACTOR = $scope.getValueOfOnLoadData('DS_PAA_MPC_IS_USER_CONTRACTOR');
        var dsAsiConfigSets = $scope.getValueOfOnLoadData("DS_GET_ATTRIBUTE_SET_DTLS");
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        $scope.disableFlag=true;
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        if (currentViewName == "ORI_VIEW") {
            var logo = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                return val.Value3.indexOf('Client_Logo') > -1;
            })[0] || {};
            $scope.oriMsgCustomFields.Client_Logo = logo.Value8 || '/images/asiteWhite60x200.png';
            $scope.unitList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Unit"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value7",
                allowBlankSelection: true
            });
            $scope.wbsList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("WBS Code"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8",
                allowBlankSelection: true
            });
          
        }
        function structureItemList(availList) {
            var tempList = [];
            angular.forEach(availList, function (item) {
                tempList.push({
                    displayValue: item.split('#')[1].trim(),
                    modelValue: item
                });
            });
            return [{
                options: tempList
            }];
        }
     
         function getConfigurableAttriburteByType(type) {
            var AttributeByType = [];
            if (type) {
                AttributeByType = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return AttributeByType;
        }
        
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;
      
        function setEmailPhoneOfContactPerson(strVal) {
            if (strVal) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_PROJUSER_DETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_PROJUSER_DETAILS",
                            "fieldValue": strVal
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var datauser = angular.fromJson(response.data['DS_PROJUSER_DETAILS']);
                        if (datauser && datauser.Items.Item.length) {
                            var strValue = datauser.Items.Item[0].Value.trim();
                            $scope.oriMsgCustomFields.DeliveryContactTel = strValue.split('|')[2].trim();
                            $scope.oriMsgCustomFields.DeliveryEmailAddress = strValue.split('|')[3].trim();
                            if(strValue.split('|')[2].trim()==""){
                                document.getElementById('DTel').removeAttribute('readonly');
                            }
                        }
                    }});
            } else {
                $scope.formCustomFields.Bid_Opportunity.Contact_No = "";
                $scope.formCustomFields.Bid_Opportunity.Email_Address = "";
            }
        }
        $scope.onProjectChange = function(obj) {
            var uniqList = [],tempList=[];
            var tempList = commonApi._.filter(dsAsiConfigSets, function(val) {
                if (uniqList.indexOf(val.Value9 + val.Value8 + val.Value6) === -1 && obj.RequisitionsContractNo) {
                    uniqList.push(val.Value9 + val.Value8 + val.Value6);
                    return val.Value8.indexOf("CBS Code") != -1 && val.Value6.indexOf(obj.RequisitionsContractNo) != -1
                }
            });
            obj.CBSData = commonApi.getItemSelectionList({
                arrayObject: tempList,
                modelKey: "Value9",
                displayKey: "Value9",
                allowBlankSelection: true
            });
            var foundObj = commonApi._.find(tempList, function(item) {
                return item.Value9 == obj.RequisitionsCBS
            });
            if (!foundObj) {
                obj.RequisitionsCBS = ""
            }
        }
  
        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.strCanReply = "";
            var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
            $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;

            $scope.SetContactInformation = function (strVal) {
                var strUserId = "";
                if (strVal) {
                    strUserId = strVal.split("|")[2].split("#")[0].trim();
                }
                setEmailPhoneOfContactPerson(strUserId);
            };
            $scope.projectList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Project Number"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8",
                allowBlankSelection: true
            });
        }
        if (currentViewName == "ORI_VIEW" && workingUserAllRole && $scope.oriMsgCustomFields.DSI_CurrentStage == "1") {
            $scope.strCanReply = "yes";
            //commited the as per BLDBTR-3986(who has rights can create the form) 
            // if (workingUserAllRole[0].Value.toLowerCase().indexOf("project team") != -1) {
            //     $scope.strCanReply = "yes";
            // }
        }
        if ($scope.oriMsgCustomFields.DSI_CurrentStage > "1") {
            var actionData = commonApi._.filter(incompleteAction, function (val) {
                return val.Name.indexOf('Respond') > -1 && val.Value.indexOf(dsWorkingUserId) != -1;
            });
            if (actionData && actionData.length) {
                $scope.strCanReply = "yes";
            }
        }
        if (currentViewName == "ORI_VIEW") {
            $scope.procurementList = structureItemList(commonApi.roleUsersListByRoleName('procurement lead', ds_Projusers_Role));
            var allUser=commonApi._.uniq(ds_Projusers_Role, function(item){
                return item.Value.split("|")[2].split("#")[0].trim()});
            $scope.userList =  commonApi.getItemSelectionList({
                arrayObject:allUser,
                groupNameKey: "",
                displayKey: "Name",
                modelKey: "Value",
                allowBlankSelection: true
             }); 
            $scope.Msg = "You are not authorised to create the form currently. For more information, contact your Administrator."
        }
        if (currentViewName == "RES_VIEW") {
            $scope.Msg = "You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form."
            var reqTotal = parseFloat($scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsGrandTotal);
            $scope.cleraDataOnchange=function(currentObj){
                if(currentObj.User_Response=='Yes')
                {
                    currentObj.User_Name='';
                }
            }
            if (reqTotal > 1000000 ) {
                $scope.Reqamt = "uptoALT";
            } else if (reqTotal > 500000 && reqTotal <= 1000000) {
                $scope.Reqamt = "uptoAlianceManger";
            }  else if (reqTotal > 250000 && reqTotal <= 500000 ) {
                $scope.Reqamt = "uptoAMT";
            }
            else if (reqTotal > 50000 && reqTotal <= 250000 ) {
                $scope.Reqamt = "uptoLead";
            }else
                $scope.Reqamt = "uptoPM";

            $scope.procurementList = structureItemList(commonApi.roleUsersListByRoleName('procurement lead', ds_Projusers_Role));
            if($scope.resMsgCustomFields.isRES_Done!="Yes" && $scope.oriMsgCustomFields.SupplierContact!=""){
                $scope.disableFlag=false;
            }
            if ($scope.oriMsgCustomFields.DSI_CurrentStage != "2" || $scope.resMsgCustomFields.isRES_Done == 'No') {
                //add new Row of Response
                $scope.resMsgCustomFields.ALL_Responses.ResponseList.push(angular.copy(STATIC_OBJ_DATA.ResponseList));
            }
            if ($scope.oriMsgCustomFields.DSI_CurrentStage == "2") {
                $scope.qsPMList =structureItemList(commonApi.roleUsersListByRoleName('quantity surveyor', ds_Projusers_Role));
                setRolename("Procurement Lead");
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "3") {
                setRolename("Quantity Surveyor");
                $scope.pmList =structureItemList(commonApi.roleUsersListByRoleName('project manager', ds_Projusers_Role));
                $scope.seniorList = structureItemList(commonApi.roleUsersListByRoleName('senior project lead', ds_Projusers_Role));    
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "4") {
                setRolename("Project Manager");
                $scope.PLeadList = structureItemList(commonApi.roleUsersListByRoleName('senior project lead', ds_Projusers_Role));
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "5") {
                setRolename("Senior Project Lead");
                $scope.AMList = structureItemList(commonApi.roleUsersListByRoleName('alliance commercial manager', ds_Projusers_Role));
                $scope.AMTList = structureItemList(commonApi.roleUsersListByRoleName('alliance management team', ds_Projusers_Role));
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "6") {
                setRolename("Alliance Management Team");//amt
                $scope.AMList = structureItemList(commonApi.roleUsersListByRoleName('alliance commercial manager', ds_Projusers_Role));
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "7") {
                setRolename("Alliance Commercial Manager");
                $scope.AManagerList = structureItemList(commonApi.roleUsersListByRoleName('alliance manager', ds_Projusers_Role));
                $scope.ALTList = structureItemList(commonApi.roleUsersListByRoleName('alliance leadership team', ds_Projusers_Role));
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == "8") {
                setRolename("Alliance Leadership Team");
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 9) {
                setRolename("Alliance Manager");
            }
        }
        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
        }
        function setRolename(rolename) {
            var Rlist = $scope.resMsgCustomFields.ALL_Responses.ResponseList;
            for (var i = 0; i < Rlist.length; i++) {
                if (Rlist[i].Is_Old == 'New') {
                    Rlist[i].Role_Name = rolename;
                    if (rolename == 'Commercial Lead' || rolename == "Alliance Leadership Team") {
                        Rlist[i].User_Name = Rlist[0].User_Name;
                    }
                    break;
                }
            }
        }
        $scope.update();

        $scope.tableUtilSettings = {
            RequisitionsList: {
                tooltip: "select to remove/remove all data",
                hasDefaultRecord: true,
                checkboxModelKey: "RequisitionisSelected",
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                deleteItemCallBack: deleteItemCallBack,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.RequisitionsList),
            }
        };
        function deleteItemCallBack() {
            $timeout(function () {
                $scope.totalAll();
            });
        }
        $scope.rowTotal = function (index) {
            var element,
                Qty = 0,
                Rate = 0;
            element = $scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsList[index];
            Qty = (parseFloat(element.RequisitionsQty) || 0);
            Rate = (parseFloat(element.RequisitionsRate) || 0);
            element.RequisitionsTotal = (Qty * Rate).toFixed(2);
            $scope.totalAll();
        };
        $scope.totalAll = function () {
            var element = 0;
            var RTotal = 0;
            var costTotal = 0;
            for (var index = 0; index < $scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsList.length; index++) {
                element = $scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsList[index];
                if (element.RequisitionsTotal) { RTotal += (parseFloat(element.RequisitionsTotal) || 0) }
                if (element.RequisitionsTargetCost) { costTotal += (parseFloat(element.RequisitionsTargetCost) || 0) }
            }
            $scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsGrandTotal = RTotal.toFixed(2);
            $scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsTargetTotal = costTotal.toFixed(2);
            setVariance();
        };
        function setVariance() {
            $scope.oriMsgCustomFields.RequisitionsGroup.Variance = (parseFloat($scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsGrandTotal) || 0) - (parseFloat($scope.oriMsgCustomFields.RequisitionsGroup.RequisitionsTargetTotal) || 0)
        }
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
        };
        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (allformStatus && allformStatus.length > 0) {
                var statudObj = commonApi._.filter(allformStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        function setStatus(statusname) {
            var strFormStatusId = getFormStatusId(statusname);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }
        function formSubmit(issubmit)
        { 
            submitFlag=true;
            $window.submitForm(1);
        }
        function setAppWorkflow() {
            var userTodistribute = '',
            userTodistributeoth = '',
            autoDistNode = currentViewName == "ORI_VIEW" ? '3' : '13';
            // Distribution Will be made from here
            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if (!$scope.strCanReply) {
                alert($scope.Msg);
                return true;
            }
            var cStage = $scope.oriMsgCustomFields.DSI_CurrentStage;
            if (currentViewName == "RES_VIEW") {
                //Make filed balnak
                if ($scope.resMsgCustomFields.isRES_Done == 'No') {
                    $scope.resMsgCustomFields.isRES_Done = '';
                }
                //set old to all
                var resData = "";
                for (var i = 0; i < $scope.resMsgCustomFields.ALL_Responses.ResponseList.length; i++) {
                    if ($scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Is_Old == 'New') {
                        resData = $scope.resMsgCustomFields.ALL_Responses.ResponseList[i];
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Is_Old = 'Old';
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Res_Date = $scope.formatDate(new Date($scope.todayDate), 'dd/mm/yy');
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Response_By = $scope.dsWorkingUser;
                        break;
                    }
                }
            }
            if (cStage == "1") {
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                setStatus("Open");
            } else if (cStage == "2") {
                if ($scope.resMsgCustomFields.isRES_Done == '') {
                    userTodistribute = resData.User_Name;
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                    setStatus("Procurement Lead Approved");
                } else if ($scope.resMsgCustomFields.isRES_Done == 'Yes') {
                    setStatus("Closed");
                }
            } else if (cStage == "3") {
                if(resData.User_Response=='Yes'){
                    userTodistribute = resData.User_Name;
                    if($scope.Reqamt == "uptoLead" || $scope.Reqamt == "uptoPM")
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                    else
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2;
                    setStatus("QS Approved");
                }
                else{
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                    setStatus("Revise Resubmit");
                }
            } else if (cStage == "4") {
                if(resData.User_Response=='Yes'&& $scope.Reqamt != "uptoPM" ){
                    userTodistribute = resData.User_Name;                
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                }else{
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response=='Yes'?setStatus("PM Approved"):setStatus("Revise Resubmit");
            } else if (cStage == "5") {
                if(resData.User_Response=='Yes'&& $scope.Reqamt != "uptoLead" ){
                    userTodistribute = resData.User_Name;                
                    if($scope.Reqamt == "uptoAMT")
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                    else
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2
                }else{
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response=='Yes'?setStatus("Project Lead Approved"):setStatus("Revise Resubmit");
            } else if (cStage == "6") {
                if(resData.User_Response=='Yes'&& $scope.Reqamt != "uptoAMT" ){
                    userTodistribute = resData.User_Name;                
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                }else{
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response=='Yes'?setStatus("AMT Approved"):setStatus("Revise Resubmit");
            }
            else if (cStage == "7") {
                if(resData.User_Response=='Yes' ){
                    userTodistribute = resData.User_Name;                
                    if($scope.Reqamt == "uptoAlianceManger"){
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2;
                    }
                    else if($scope.Reqamt == "uptoALT")
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                }else{
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response=='Yes'?setStatus("Commercial Manager Approved"):setStatus("Revise Resubmit");
            }
            else if (cStage == "8") {
                if(resData.User_Response=='Yes'){
                    setStatus("ALT Approved");
                }else{
                    setStatus("Revise Resubmit");
                }
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                $scope.oriMsgCustomFields.DSI_NextStage = 2;
            }
            else if (cStage == "9") {
                if (resData.User_Response == 'Yes') {
                    setStatus("Alliance Manager Approved");
                } else {
                    setStatus("Revise Resubmit");
                }
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                $scope.oriMsgCustomFields.DSI_NextStage = 2;
            }
            if (userTodistribute) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistribute.split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: commonApi.calculateDistDateFromDays({
                            baseDate: $scope.todayDate,
                            days: 7
                        })
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }
            if (userTodistributeoth) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistributeoth.split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: commonApi.calculateDistDateFromDays({
                            baseDate: $scope.todayDate,
                            days: 7
                        })
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }
            formSubmit("");
        }

        $window.svrFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                if (!$scope.strCanReply) {
                    alert($scope.Msg);
                    return true;
                }
                if (submitFlag) {
                    $element.removeClass('loaded');
                    return false;
                }
                setAppWorkflow();
                return true;
            }
        };

    }
    return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof svrFinalCallBack !== "undefined") {
        return svrFinalCallBack();
    }
} 