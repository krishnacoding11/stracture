/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = $window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
        });

        var dateFormatMap = {
            "en_GB": "dd-M-yy",
            "fr_FR": "d M yy",
            "es_ES": "dd-M-yy",
            "ru_RU": "dd.mm.yy",
            "en_AU": "dd/mm/yy",
            "en_CA": "d-M-yy",
            "en_US": "M d, yy",
            "zh_CN": "yy-m-d",
            "de_DE": "dd.mm.yy",
            "ga_IE": "d M yy",
            "en_ZA": "dd M yy",
            "ja_JP": "yy/mm/dd",
            "ar_SA": "dd/mm/yy",
            "en_IE": "dd-M-yy",
            "nl_NL": "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var costCodeDataArray = [];
        var linkFormDataArray = [];

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation: "Submitted for Information",
            forInformation: "For Information",
            forAcceptance: "For Acceptance",
            respond: "Respond",
            openStatus: "Open",
            subjectToChangeAppraisal: "Subject to Change Appraisal",
            icaRaised: "ICA raised",
            subjectToConfirmationNotice: "Subject to Change Confirmation Notice",
            acceptQuote: "Accept Quote",
            reviseAndResubmit: "Revise and Resubmit",
            WithdrawnPCN: "Withdraw PCN",
            Withdrawn: 'Withdrawn',
            subjectToICA: "Subject to ICA",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",

            // Appbuidler codes of forms
            changeAppraisal: "STT-CAF",
            supplierChangeNotice: "STT-SCN",
            projectChangeNotice: "STT-PCN",
            changeAppraisalInstruction: "STT-CAI",
            changeConfirmNotice: "STT-CCN",
            initChangeAppraisal: "STT-ICA",
            compensationEvent: "STT-NCE",

            // Static role used in Code
            tflRepresentative: "TFL Representative",
            preojectManager: "Project Manager",
            contractor: "Contractor",

            // Data source 
            dsSttNnecSertuoSections: "DS_STT_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_STT_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_STT_SECTION_USERS",
            dsSttNnecSecLck: "DS_STT_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_STT_ALL_CONTRACT_TEAM_MEMBERS",
            dsSttNnecGetFormDetailsByStatus: "DS_STT_GET_FORM_DETAILS_BY_STATUS",
            dsAllActiveWsStatus: "DS_ALL_ACTIVE_WS_STATUS",
            dsAsiGetCurrencyFromContract: "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
            dsSttNecKeyContractDates: "DS_STT_NEC_KEY_CONTRACT_DATES"
        }

        var STATIC_OBJ_DATA = {
            Costcode: {
                "sections": "",
                "costCodes": "",
                "costValue": "",
                "CC_isSelected": "",
                "ccGuId": ""
            },
            costOptions: {
                "CO_isSelected": "",
                "optionName": "Option 1",
                "CostcodeGroup": {
                    "Costcode": [{
                        "sections": "",
                        "costCodes": "",
                        "costValue": "",
                        "CC_isSelected": "",
                        "ccGuId": ""
                    }],
                    "costValueTotal": ""
                }
            },
            sectionDetails: {
                "sectionName": "",
                "workName": "",
                "comDate": "",
                "sd_isSelected": "",
                "sdGuId": ""
            },
            Auto_Distribute_Users: {
                "DS_PROJDISTUSERS": "",
                "DS_FORMACTIONS": "",
                "DS_ACTIONDUEDATE": "",
                "DS_DUEDAYS": "",
                "AutoDist_Id": 1,
                "dist_isSelected": false,
                "isEditable": "1"
            }
        }

        $scope.tableUtilSettings = {
            Costcode: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "CC_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Costcode),
                deleteItemCallBack: estimateCostTotalOnDelete
            },
            costOptions: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "CO_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.costOptions)
            },
            sectionDetails: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "sd_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sectionDetails)
            },
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sectionDetails)
            }
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.arrCostOptionGroup = $scope.oriMsgCustomFields["costOptionGroup"];
        $scope.arrSectionDetailGroups = $scope.oriMsgCustomFields["sectionDetailGroups"];

        var dsSttBlNnecNecOrgConctract = $scope.getValueOfOnLoadData('DS_STT_NEC_ORG_CONTRACT');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var dsAllActiveWsStatus = $scope.getValueOfOnLoadData(TFL_CONSTANT.dsAllActiveWsStatus);
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_INCOMPLETE_MSG_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_STT_NEC_CONTRACT');
        var DS_STT_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_STT_ALL_CONTRACT_TEAM_MEMBERS');
        var dsWorkingUserId = $scope.getWorkingUserId();

        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();

        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.isConSelected = false;
            $scope.dropdownObj = {
                contractList: [],
                tflReprentList: [],
                distSectionsList: [],
                sectionsList: [],
                distUsersList: [],
                formActionList: [],
                contractorList: [],
                linkFormList: [],
                statusList: [],
                optionsList: []
            };

            fillDropwdowns();
            initFormData();
            $scope.update();
        } else {
            $scope.linkFielURL = $scope.getValueOfOnLoadData('DS_STT_GET_URL_DETAILS');
            $scope.linkFielURL = $scope.linkFielURL[0] && $scope.linkFielURL[0].URL;

            for (var i = 0; i < $scope.linkContractURL.length; i++) {

                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            }

            $scope.update();
        }


        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);

            if (objKeyName == "costOptions") {
                var newOptionNumber = repeatingData.length + 1;
                newRowObject.optionName = "Option " + newOptionNumber;
                newRowObject.CostcodeGroup.Costcode[0].ccGuId = "Option " + newOptionNumber
            }

            if (objKeyName == "Costcode") {
                newRowObject.ccGuId = repeatingData[0].ccGuId;
            }

            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.onContractChange = onContractChange;

        function onContractChange() {
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            if (contractNumber) {
                var changeAppraisalFor = $scope.oriMsgCustomFields['changeType'];
                var tempConAppCode = commonApi._.filter(contractDataArray, function (mapObj) {
                    return mapObj.contractID == contractNumber;
                })[0];

                if ($scope.linkContractURL.length) {
                    if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                        var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                            return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                        });
                        if (notesObj.length) {
                            var strValue = notesObj[0].Name,
                                strNotes = strValue.split('|')[3].trim()
                            if (strNotes) {
                                $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                            }    
                        }
                    }    
                }

                loadClientLogo(tempConAppCode);
                tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

                var paramForICA = "";
                if (changeAppraisalFor == "PCN") {
                    paramForICA = tempConAppCode + "|" + TFL_CONSTANT.projectChangeNotice + "|" + TFL_CONSTANT.openStatus;
                    $scope.oriMsgCustomFields.parentNodeLabel = "Project Change Notice";
                } else if (changeAppraisalFor == "NCE") {
                    paramForICA = tempConAppCode + "|" + TFL_CONSTANT.compensationEvent + "|" + TFL_CONSTANT.subjectToICA;
                    $scope.oriMsgCustomFields.parentNodeLabel = "Compensation Event";
                }

                if (tempConAppCode) {
                    $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
                    var spParam = {
                        dataSourceArray: [{
                            "fieldName": TFL_CONSTANT.dsSttNnecSertuoSections,
                            "fieldValue": tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNnecNecContractSummary,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus,
                            "fieldValue": paramForICA
                        }, {
                            "fieldName": TFL_CONSTANT.dsAsiGetCurrencyFromContract,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNecKeyContractDates,
                            "fieldValue": tempConAppCode
                        }],

                        successCallback: contractChangeCallback
                    };

                    $scope.getCallbackSPdata(spParam);
                }
            } else {
                alert('Please select Contract');
                $scope.oriMsgCustomFields['changeType'] = "";
            }
        }

        $scope.onDaysChange = function(enteredDaysNode, ContractDaysNode, replyDateNode) {
            var enteredDays = $scope.oriMsgCustomFields[enteredDaysNode];
            var contractDays = $scope.oriMsgCustomFields[ContractDaysNode];
            if ((enteredDays && contractDays && parseInt(enteredDays) < parseInt(contractDays)) || (!enteredDays && contractDays)) {
                alert("Entered days cannnot be less than contract days");
                $scope.oriMsgCustomFields[enteredDaysNode] = $scope.oriMsgCustomFields[ContractDaysNode];
            }
            var replyDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days : $scope.oriMsgCustomFields[enteredDaysNode]
            });
            $scope.oriMsgCustomFields[replyDateNode] = replyDate;
        }


        $scope.onSectionChange = function (strVal) {

            if (strVal) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue": strParam
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue": strParam
                    }],
                    successCallback: sectionChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        /**
         * To Clear all objection checkbox on change objection ye/no
         */
        $scope.icaObjectCheckChange = function () {
            $scope.oriMsgCustomFields['objectionFlags']['Illegal'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['Contravene'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['Materially'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['natureProject'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['Technically'] = 'No';
        }

        // To create ICA form form PCN
        $scope.launchICAForm = function () {
            $window.launchCreateForm(TFL_CONSTANT.initChangeAppraisal);
        }

        // To reset cost optins while check/uncheck TFL agree flag
        $scope.resetCostOption = function () {
            $scope.oriMsgCustomFields['costOption'] = ""
        }

        // To fill cost code dropdown while selecting sections in CA and ICA
        $scope.fillConstCodes = function (currObj) {
            var strSecname = commonApi._.filter(costCodeDataArray, function (val) {
                return val.Value3 == currObj.sections;
            });

            currObj.Section_Name = strSecname[0] && strSecname[0].Value4 || "";

            currObj.costCodes = "";

            currObj.costList = commonApi.getItemSelectionList({
                arrayObject: strSecname,
                groupNameKey: "",
                modelKey: "Value14",
                displayKey: "Value14"
            });
        }

        // on Activity change
        $scope.onActivityChange = function (currObj, repeatingObj, $index) {
            for (var i = 0; i < repeatingObj.length; i++) {
                if (currObj.costCodes && currObj.sections && i != $index &&
                    repeatingObj[i].sections == currObj.sections && repeatingObj[i].costCodes == currObj.costCodes) {
                    alert("Section and Activity should not be same. please select different activity");
                    currObj.costCodes = "";
                    var strSecname = commonApi._.filter(costCodeDataArray, function (val) {
                        return val.Value3 == currObj.sections;
                    });
                    currObj.costList = commonApi.getItemSelectionList({
                        arrayObject: strSecname,
                        groupNameKey: "",
                        modelKey: "Value14",
                        displayKey: "Value14"
                    });
                }
            }
        }

        // Change Event of PCN/ICN Dropdwon list
        $scope.pcnListChange = function (dataKey, flag) {
            var matchItem = "";
            var strPcnNo = $scope.oriMsgCustomFields[dataKey];
            var isMatch = false;
            for (var i = 0; i < linkFormDataArray.length; i++) {
                if (flag == 'OnloadAutoLoadFlag') {
                    matchItem = linkFormDataArray[i].pcnNo;
                    strPcnNo = $scope.oriMsgCustomFields['PCN_AppNumber_LaunchButton'];
                } else {
                    matchItem = linkFormDataArray[i].pcnTitle;
                }
                if (matchItem == strPcnNo) {
                    isMatch = true;
                    $scope.oriMsgCustomFields.PCN_AppBuilderId = linkFormDataArray[i].pcnFormCode;
                    break;
                }
            }
            //DS_FORMCONTENT
            if (currentViewName == "ORI_VIEW") {
                var icaTitleVal = strPcnNo;
                if (icaTitleVal && isMatch) {
                    icaTitleVal = icaTitleVal ? icaTitleVal.split("|")[0].trim() : icaTitleVal;
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = icaTitleVal + "|" + $scope.oriMsgCustomFields.PCN_AppBuilderId;
                }
            }
        }

        $scope.onTFLAgreeChange = function () {
            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
            if ($scope.oriMsgCustomFields['projCoObjFlag'] == 'No') {
                if ($scope.oriMsgCustomFields['isTFLagreed'] == 'Yes') {
                    var statusIds = $scope.getFormStatus({
                        spName: TFL_CONSTANT.dsAllActiveWsStatus,
                        status: TFL_CONSTANT.subjectToChangeAppraisal
                    });
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
                    $scope.oriMsgCustomFields.costOption = "";
                }
            }
        }

        function fillDropwdowns() {

            // Contract downdown

            for (var i = 0; i < dsSttBlNnecNecOrgConctract.length; i++) {
                var element = dsSttBlNnecNecOrgConctract[i];
                element = element.Value ? element.Value.split('|') : [];
                if (element.length) {
                    contractDataArray.push({
                        contractID: element[2].trim(),
                        contractorLogo: element[4].trim(),
                        clientLogo: element[5].trim(),
                        contractName: element[8].trim(),
                        contractAppCode: element[0].trim(),
                        contractIdName: dsSttBlNnecNecOrgConctract[i].Name
                    });
                }
            }

            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });


            // TFL Reprensetative downdown
            var tflRepresentativeArray = [];
            for (var i = 0; i < dsProjUserRole.length; i++) {
                var element = dsProjUserRole[i];
                if (element.Value.indexOf(TFL_CONSTANT.tflRepresentative) > -1) {
                    tflRepresentativeArray.push({
                        userName: element.Name,
                        userID: element.Value
                    });
                }
            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject: tflRepresentativeArray,
                groupNameKey: "",
                modelKey: "userID",
                displayKey: "userName"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });


          
            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });


            $scope.dropdownObj.optionsList = commonApi.getItemSelectionList({
                arrayObject: $scope.arrCostOptionGroup['costOptions'],
                groupNameKey: "",
                modelKey: "optionName",
                displayKey: "optionName"
            });

            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
        }

        function setActionDropdownList(tflAgreFlag) {
            // Dropdown for Status list in RES_VIEW
            var tempStatuses = [];
            if (tflAgreFlag == 'No') {
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus, function (obj) {
                    return (obj.Name == TFL_CONSTANT.Withdrawn || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            } else {
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus, function (obj) {
                    return (obj.Name == TFL_CONSTANT.subjectToChangeAppraisal || obj.Name == TFL_CONSTANT.Withdrawn || obj.Name == TFL_CONSTANT.acceptQuote || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            }
            $scope.dropdownObj.statusList = commonApi.getItemSelectionList({
                arrayObject: tempStatuses,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })
        }

        // To reset Option Index while remove CostOptions
        function optionIndexReset() {
            $timeout(function () {
                var costOptions = $scope.arrCostOptionGroup['costOptions'];
                for (var i = 0; i < costOptions.length; i++) {
                    costOptions[i].optionName = "Option " + (i + 1);
                }
            }, 200);
        }

        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(tempConAppCode) {
            $scope.oriMsgCustomFields.contractorLogo = tempConAppCode.contractorLogo || TFL_CONSTANT.defaultLogo;
            $scope.oriMsgCustomFields.clientLogo = tempConAppCode.clientLogo || TFL_CONSTANT.defaultLogo;
        }

        function strIsUserDraftOnly() {
            if (DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_STT_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        } 

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsSttNnecSectionUsers];
            var distLockflag = spDataList[TFL_CONSTANT.dsSttNnecSecLck];

            if (distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');
                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }

                var strMatchAction = nodeVal[2].trim() + '#' +nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";
                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                tempList.push({
                    strUser: nodeVal[0].trim() + "#" + userName.trim(),
                    strAction: strAction, //"7#For Information",
                    strDate: distDate
                });
            }

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
        }

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList) {
            $scope.isConSelected = true;
            // Sections dropdown data based on setup form
            if (responseList[TFL_CONSTANT.dsSttNnecSertuoSections]) {
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[TFL_CONSTANT.dsSttNnecSertuoSections],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }
            var contractCurrency = responseList[TFL_CONSTANT.dsAsiGetCurrencyFromContract];
            if (contractCurrency) {
                $scope.oriMsgCustomFields['currency'] = contractCurrency[0].Value2.trim();
            }

            // Contract Activity Summry Data
            costCodeDataArray = responseList[TFL_CONSTANT.dsSttNnecNecContractSummary]
            var tempCostCodeDataArray = angular.copy(costCodeDataArray);
            if (tempCostCodeDataArray.length) {
                tempCostCodeDataArray = commonApi._.uniq(tempCostCodeDataArray, 'Value3');
                $scope.dropdownObj.sectionsList = commonApi.getItemSelectionList({
                    arrayObject: tempCostCodeDataArray,
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value18"
                })
            }

            // Contractor Data list
            var contractTeamMemberList = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers]
            if (contractTeamMemberList.length) {
                //contractTeamMemberList = commonApi._.uniq(contractTeamMemberList,'Value3');
                var matchRole = TFL_CONSTANT.preojectManager
                var tempVal = [],
                    tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if (tempVal.indexOf(element.Value) == -1 && roleName == matchRole) {
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            var linkFormList = responseList[TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus];
            if (linkFormList) {
                linkFormDataArray = [];
                for (var index = 0; index < linkFormList.length; index++) {
                    var element = linkFormList[index];
                    linkFormDataArray.push({
                        pcnNo: element.Value1,
                        pcnTitle: element.Value1 + ' | ' + element.Value2,
                        pcnFormCode: element.Value3
                    })
                }

                $scope.dropdownObj.linkFormList = commonApi.getItemSelectionList({
                    arrayObject: linkFormDataArray,
                    groupNameKey: "",
                    modelKey: "pcnTitle",
                    displayKey: "pcnTitle"
                })
            }

            var strPcnNumberCode = $scope.oriMsgCustomFields['PCN_AppNumber_LaunchButton'];
            if (strPcnNumberCode) {
                $scope.pcnListChange('pcnNumber', 'OnloadAutoLoadFlag');
                for (var i = 0; i < linkFormDataArray.length; i++) {
                    if (linkFormDataArray[i].pcnNo == strPcnNumberCode) {
                        $scope.oriMsgCustomFields.pcnNumber = linkFormDataArray[i].pcnTitle;
                        break;
                    }
                }
            }

            // Contractor response days Data list
            var contractResponseDaysList = responseList[TFL_CONSTANT.dsSttNecKeyContractDates]
            if (contractResponseDaysList.length) {
                var responseDaysCo = "";
                var responseDaysTfl = "";
                for (var i = 0; i < contractResponseDaysList.length; i++) {
                    if (contractResponseDaysList[i].Value2 == "4") {
                        responseDaysCo = contractResponseDaysList[i].Value4;
                    }
                    if (contractResponseDaysList[i].Value2 == "5") {
                        responseDaysTfl = contractResponseDaysList[i].Value4;
                    }
                }

                $scope.oriMsgCustomFields['ICA_TFL_Reply_Days'] = responseDaysTfl;
                $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'] = responseDaysCo;
                $scope.oriMsgCustomFields['ICA_TFL_Reply_Days_Backup'] = responseDaysTfl;
                $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days_Backup'] = responseDaysCo;
                var replyDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: responseDaysTfl
                });
                var replyDateResponse = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: responseDaysCo
                });
                $scope.oriMsgCustomFields['Reply_Date'] = replyDate;
                $scope.oriMsgCustomFields['Reply_Date_Response'] = replyDateResponse;
            }
            DS_STT_ALL_CONTRACT_TEAM_MEMBERS = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers];
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");

        }

        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            var strLastMsgId = $scope.oriMsgCustomFields.DSI_PreviousMsgId;
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (!strNodes.length) {
                strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                    return val.Value4 == "Respond";
                });
            }
            if (strNodes) {
                var strUserId = strNodes[0] && strNodes[0].Value1;
                var strMsgId = strNodes[0] && strNodes[0].Value3;
                var strCheckRespond = strNodes[0] && strNodes[0].Value4;
                if (strUserId) {
                    if (strCheckRespond == "Respond" && strUserId && strUserId == strUser.trim() && strLastMsgId == strMsgId) {
                        return true;
                    } else if (strUserId && strUserId == strUser.trim()){
                        return true;
                    }
                }
            }
            return IsAction;
        }


        /**
         * Initialize all form data on load
         */
        function initFormData() {
            if ($scope.oriMsgCustomFields['ContractNo'] && currentViewName == "ORI_VIEW") {
                onContractChange();
            }
            $scope.notAllow = true;
            $scope.notAllowMessage = "";
            $scope.oriMsgCustomFields.DSI_PreviousMsgId = DS_INCOMPLETE_MSG_ACTIONS.length ? DS_INCOMPLETE_MSG_ACTIONS[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId;
            if (currentViewName == "RES_VIEW") {
                var isrequired = CheckPendingAction($scope.getWorkingUserId());
                if (isrequired == false) {
                    //if not than dont allow to edit
                    $scope.notAllowMessage = "You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    $scope.notAllow = false;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    return;
                } else {
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
                }
                $scope.isRespond = true;
                $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

                if ($scope.oriMsgCustomFields['stageFlow'] == 0) {
                    onContractChange();
                    $scope.oriMsgCustomFields['Comment'] = "";
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
                    $scope.oriMsgCustomFields['PM_Comment'] = "";
                }

            } else {
                $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            }
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
        }


        /**
         * @param {Integer} distNumber : it defines DS_AUTODISTRIBUTE value which require to send auto distribute
         * it will be 3 for OR and 13 for Respond 
         */
        function setDistributionNodeForPM(distNumber) {

            var actionStr = TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond;

            setAutoDistributeNode({
                autoDistFlag: distNumber,
                action: actionStr,
                days: $scope.oriMsgCustomFields['ICA_TFL_Reply_Days'],
                users: $scope.oriMsgCustomFields['TFL_Representative'].split('|')[2].trim()
            });
        }

        function setDistributionNodeForContractor() {
            var tmpUserID = commonApi._.filter(dsProjUserRole, function (obj) {
                return obj.Value.indexOf($scope.oriMsgCustomFields.Originator_Id) > -1;
            })[0];

            tmpUserID = tmpUserID.Value && tmpUserID.Value.split('|')[2].trim();
            if (tmpUserID) {
                tmpUserID = tmpUserID.split('#');
                setAutoDistributeNode({
                    action: TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond,
                    autoDistFlag: TFL_CONSTANT.resDistNumb,
                    days: $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'],
                    users: tmpUserID[0].trim() + "#" + tmpUserID[1].trim()
                });
            }
        }

        function setForInfoDistributionNodeForContractor() {
            var tmpUserID = commonApi._.filter(dsProjUserRole, function (obj) {
                return obj.Value.indexOf($scope.oriMsgCustomFields.Originator_Id) > -1;
            })[0];

            tmpUserID = tmpUserID.Value && tmpUserID.Value.split('|')[2].trim();
            if (tmpUserID) {
                tmpUserID = tmpUserID.split('#');
                setAutoDistributeNode({
                    action: TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation,
                    autoDistFlag: TFL_CONSTANT.resDistNumb,
                    days: $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'],
                    users: tmpUserID[0].trim() + "#" + tmpUserID[1].trim()
                });
            }
        }

        /**
         * 
         * @param {String} param.action : pass action name like For Information/Respond
         * @param {Interger} param.days : pass days in number which indicates due date
         * @param {String} param.user : set User id which you want to send action
         * @param {Interger} param.autoDistFlag : this flag vary distribution ORI and RES view
         */
        function setAutoDistributeNode(param) {
            var actionStr = param.action;
            var days = param.days;
            var users = param.users;
            var autoDistFlag = param.autoDistFlag

            var distDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days: days
            });

            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: users,
                    strAction: actionStr,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: autoDistFlag
            });
        }

        function estimateCostTotalOnDelete() {
            $timeout(function () {
                var allOptions = $scope.arrCostOptionGroup['costOptions'];
                for (var i = 0; i < allOptions.length; i++) {
                    if (allOptions[i]) {
                        $scope.calcFieldTotal({
                            repData: allOptions[i]['CostcodeGroup']['Costcode'],
                            calcKey: 'costValue',
                            parObject: allOptions[i]['CostcodeGroup'],
                            totalKey: 'costValueTotal'
                        });
                    }
                }
            }, 100);
        }

        // To set workflow for ICA forms
        function icaFormsFlow() {
            var tempStageFlow = (parseInt($scope.oriMsgCustomFields['stageFlow']) || 0) + 1
            var tempPcnFormCode = $scope.oriMsgCustomFields['PCN_AppBuilderId'];
            var statusIds = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.icaRaised
            });

            var statusIdWithdrawn = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.Withdrawn
            });

            var statusIdSubToChangeAppraisal = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.subjectToChangeAppraisal
            });

            var statusIdSubToICA = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.subjectToICA
            });

            var statusIdReviseAndResubmit = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.reviseAndResubmit
            });

            var statusIdOpen = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.openStatus
            });

            if ($scope.isRespond) {
                if ($scope.oriMsgCustomFields['stageFlow'] == 0) { // contractor
                    setDistributionNodeForPM(TFL_CONSTANT.resDistNumb);
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdOpen;
                } else if ($scope.oriMsgCustomFields['projCoObjFlag'] == "No") { // No Objection, objection check box checked with no objection
                    if ($scope.oriMsgCustomFields['isTFLagreed'] == 'No') { // TFL Project Manager Agree or disagree
                        var strCurrentFormStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS;
                        if (strCurrentFormStatus == statusIdReviseAndResubmit) {
                            statusIds = statusIdSubToICA;
                        } else {
                            setForInfoDistributionNodeForContractor();
                            statusIds = statusIdWithdrawn;
                            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                        }
                        if (strCurrentFormStatus && strCurrentFormStatus.indexOf(TFL_CONSTANT.reviseAndResubmit) > -1) {
                            setDistributionNodeForContractor();
                            // Set Stage 1 becasue it send back to Contractor
                            tempStageFlow = 0;
                        }
                    } else {
                        setForInfoDistributionNodeForContractor();
                        statusIds = statusIdSubToChangeAppraisal;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    }
                } else if ($scope.oriMsgCustomFields['projCoObjFlag'] == "Yes") { // have Objection, objection check box checked with objection
                    if ($scope.oriMsgCustomFields['isTFLagreed'] == 'Yes') { // TFL Project Manager Agree or disagree
                        statusIds = statusIdWithdrawn;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    } else {
                        statusIds = statusIdSubToChangeAppraisal;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    }
                    setForInfoDistributionNodeForContractor();
                }
            } else {
                if ($scope.oriMsgCustomFields['TFL_Representative']) {
                    setDistributionNodeForPM(TFL_CONSTANT.oriDistNumb);
                }
            }

            if (statusIds) {
                $scope.asiteSystemDataReadwrite["Form_Status_Change"] = {
                    "DS_CHANGE_STATUS_FORMS": tempPcnFormCode, // i.e TFL-STT-PCN001
                    "DS_CHANGE_STATUS_IDS": statusIds.split("#")[0].trim() // Integer
                };
            }

            // To display loader on screen;
            $element.removeClass('loaded');

            /** 
             * Define stage for workflow based form. 
             * stageFlow=0 i.e ORI_VEW/RES_VEW by Contractor
             * stageFlow=1 i.e RES_VEW by PM
             * */
            $scope.oriMsgCustomFields['stageFlow'] = tempStageFlow;
        }

        $window.pcnFinalCallBack = function () {
            var returnFlag = false;
            var checkObjectValueSelectedOrNot = $scope.oriMsgCustomFields['projCoObjFlag'] == 'Yes' 
            && $scope.oriMsgCustomFields['objectionFlags']['Technically'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['Illegal'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['Contravene'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['Materially'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['natureProject'] == 'No';
            if (checkObjectValueSelectedOrNot) {
                alert("Please select any objection");
                returnFlag = true;
            } else {
                icaFormsFlow();
            }    
            return returnFlag;
        }

    };
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pcnFinalCallBack !== "undefined") {
        return pcnFinalCallBack();
    }
}