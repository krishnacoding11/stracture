/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/inlineattachment', '../components/signature'], function (angular, mainModule, baseController) {
    'use strict';
      
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $controller, $window, $timeout, commonApi) {

        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
		}
		
		$scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.Approval.CreationDate = $scope.todayDateDbFormat;
        });

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.Approval = $scope.oriMsgCustomFields.Approval;
		$scope.NoImpact = $scope.oriMsgCustomFields.NoImpact;
		var DS_MTA_EPP_contractDOBNo_List  = $scope.getValueOfOnLoadData('DS_MTA_EPP_contractDOBNo_List');
        $scope.DS_MTA_EPP_DetailsBasedOncontractDOBNo = $scope.getValueOfOnLoadData('DS_MTA_EPP_DetailsBasedOncontractDOBNo'); 
        $scope.docDetails = $scope.getValueOfOnLoadData('DS_Doc_Associations_All_Custom_Attribute');
        var ds_Asi_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        
        var APL_CONSTANT = {
            Issued: 'Issued',
        }

        if (currentViewName == 'ORI_PRINT_VIEW') {
            //to Hide Export Button in print view
            $scope.hideExportBtn();
        }
        if (currentViewName == 'ORI_VIEW') {
            var DS_WORKINGUSER_WITHOUT_ROLE = $scope.getValueOfOnLoadData('DS_WORKINGUSER_WITHOUT_ROLE')[0];
            $scope.oriMsgCustomFields.workingUser = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value1.split('|')[0].trim();
            
            $scope.addNewItem = function (repeatingData, addItemFor) {
                var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
                repeatingData.push(newRowObject);
            };

            $scope.removeItem = function (nodeObj, list) {
                var index = list.indexOf(nodeObj);
                list.splice(index, 1);
            }; 
			
			setDobContractNumber();
            setFormStatus(APL_CONSTANT.Issued);
            
			$scope.onDobContractNoChange = function (strVal) {
				if (strVal) {
					var form = {
						"projectId": projectId,
						"formId": formId,
						"fields": "DS_MTA_EPP_DetailsBasedOncontractDOBNo",
						"callbackParamVO": {
							"customFieldVOList": [{
								"fieldName": "DS_MTA_EPP_DetailsBasedOncontractDOBNo",
								"fieldValue": strVal
							}]
						}
					};
					$scope.isDataLoaded = false;
					$scope.getCallbackData(form).then(function (response) {
						if (response.data) {
                            var dataObj = angular.fromJson(response.data['DS_MTA_EPP_DetailsBasedOncontractDOBNo']).Items.Item;
                            if (dataObj.length) {
								$scope.Approval.ActFirstName = dataObj[0].Value6;
								$scope.Approval.ActLastName = dataObj[0].Value3;
								$scope.Approval.ActCompanyName = dataObj[0].Value4;
								$scope.Approval.ActEmailId = dataObj[0].Value5;
								$scope.Approval.ActPhoneNo = dataObj[0].Value7;
								$scope.Approval.ActRelProject = dataObj[0].Value8;
                                $scope.Approval.ActSubmission = dataObj[0].Value9;
                                $scope.oriMsgCustomFields.ORI_FORMTITLE = dataObj[0].Value10;
                                $scope.Approval.PlBorough = dataObj[0].Value11;
                                $scope.Approval.PlHouseNumber = dataObj[0].Value12;
                                $scope.Approval.PlOtherDetails = dataObj[0].Value13;
                                $scope.Approval.PlStreetName = dataObj[0].Value14;
                                $scope.Approval.PlBlock = dataObj[0].Value15;
                                $scope.Approval.PlLotNo = dataObj[0].Value16; 
                                $scope.Approval.PlZipCode = dataObj[0].Value17;
                                $scope.Approval.PlStreetInt = dataObj[0].Value18;
                                $scope.Approval.PlStationName = dataObj[0].Value19;
                                $scope.Approval.PlTransitType = dataObj[0].Value20;
								$scope.Approval.PlLineName = dataObj[0].Value21;
                                $scope.Approval.PlApproxDist = dataObj[0].Value22;
                                $scope.Approval.NysFirstName = dataObj[0].Value23;
                                $scope.Approval.NysLastName = dataObj[0].Value24;
                                $scope.Approval.NysCompanyName = dataObj[0].Value25;
                                $scope.Approval.NysFullAddress = dataObj[0].Value26;
								$scope.Approval.NysEmail = dataObj[0].Value27;
								$scope.Approval.NysPhoneNo = dataObj[0].Value28;                                                      
                                $scope.isDataLoaded = true;
                                if (dataObj[0].Value10 == 'Adjacency'){
                                    $scope.Approval.SpecificText = "Dear Sir:<br><br>" +
                                    "The above applicant recently submitted drawings of proposed building construction at the above location for our review and approval.<br><br>" +
                                    "The drawings listed above have been reviewed only for possible adverse effects on existing New York City Transit facilities resulting from the proposed building construction.<br><br><br>" +
                                    "<b>Subject To:	</b><br>" +
                                    "&emsp;&emsp;1. All work being performed in accordance with the approved drawings.<br>" +
                                    "&emsp;&emsp;2. The building plans meeting the Department of Buildings approval in all other respects.<br>" +
                                    "&emsp;&emsp;3. The construction materials being used for this project, the testing of materials and the inspection of the work meeting the requirements of the Department of Buildings.<br>" +
                                    "&emsp;&emsp;4. NYCT review will be required for any revisions to this proposed construction or for the use of cranes for construction in this vicinity.<br><br>" +
                                    "A copy of each of the above listed drawings, imprinted with the New York City Transit approval stamp dated <b style='color: #1d6bb3;'>MM/DD/YYYY</b> were transmitted to the applicant for submission to your Department for a building permit.<br><br>" +
                                    "<i>This letter does not constitute certification by the NYCT pursuant to the Zoning Resolution of the City of New York as to any matter, including, but not limited to, matters arising under Section 95-041 thereof.</i>";
                                }else if(dataObj[0].Value10 == 'Public Agency/Utility Project'){
                                    $scope.Approval.SpecificText = "Dear Sir/Madam:<br><br>" +
                                    "This is in reply to your submission of drawing(s) listed below for review and approval.<br><br>" +
                                    "We are transmitting the herewith as indicated.<br><br>";
                                }  
							}
						}
					});
                }                     
            } 
            
		}

		function setDobContractNumber(){
            var DobContractNo = DS_MTA_EPP_contractDOBNo_List || {};
            $scope.reportByList = commonApi.getItemSelectionList({
                arrayObject: DobContractNo,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Value"
            });
		}
		
        $scope.update();
        
        function setFormStatus(currFormStaus){
                // Form's Staus will be set from below code.
				 var strFormStatusId = commonApi.getFormStatusId({
					availFormStatusesList : availFormStatuses,
					strStatus : currFormStaus
				});
				
				if (strFormStatusId) {  
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
				}
        }
        $window.oriformSubmitCallBack = function () {          
            $scope.oriMsgCustomFields.ORI_USERREF = $scope.Approval.ConractDOBNo;
           return false;
        };
    }
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}