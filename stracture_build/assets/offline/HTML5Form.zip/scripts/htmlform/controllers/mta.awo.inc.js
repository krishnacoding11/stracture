
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule",'./base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, mainModule,baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
      
        var STATIC_OBJ_DATA = {
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            }
        };
        var MTA_CONSTANT = {
            yymmdddateformate:'yy-mm-dd',
        }

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        var ds_MTA_AWO_Get_Contract_Basic_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_Contract_Basic_Details');
        $scope.strFormId = $scope.formdata5.DS_FORMID;
        var strIsDraft = $scope.formdata5.DS_ISDRAFT;

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
            $scope.ds_Workinguserid = dsWorkingUserId;
        }
      
        initFormsData();
        function initFormsData()
        {
            if(currentViewName == "ORI_PRINT_VIEW" || currentViewName == "ORI_PRINT_VIEW_HTML")
            {
               var strformcontent = $scope.formdata5['DS_FORMCONTENT'].split('$$');
               var strCIFformid = strformcontent[2].trim();
               //CIF id
               $scope.oriMsgCustomFields['CIF_ID'] = strCIFformid;
                
               //Section Code
               var strSeccode = strformcontent[3].trim();
               $scope.oriMsgCustomFields['Section_Code'] = strSeccode;
              

               //contract details
               var strcondetail = strformcontent[0].split('||');
               
               //COntract Number
               var strcontractno = strcondetail[1].trim();
               $scope.oriMsgCustomFields['Contract_No'] = strcontractno;

               getContractUrl();

            }
        }

        $window.mtaAWOFinalCallBack = function () {
            return setflow();
            }
        $scope.alertMsg = 'This form is meant to be autocreated. You will not be able to create this form manually';
        function setflow(){
            alert($scope.alertMsg);
            return true;
        } 

        function getContractUrl() {
            //get status according pass parameter   
            var conUrlLink = $scope.formdata5['DS_FORMCONTENT1'];     
            if (ds_MTA_AWO_Get_Contract_Basic_Details && ds_MTA_AWO_Get_Contract_Basic_Details.length > 0) {
                var conUrlLinkObj = commonApi._.filter(ds_MTA_AWO_Get_Contract_Basic_Details, function (val) {
                    return val.Value2.toLowerCase().trim() == conUrlLink.toLowerCase().trim();
                });
                if (conUrlLinkObj.length) {
                    $scope.oriMsgCustomFields['ContractURL'] = conUrlLinkObj[0].URL7;
                }
            }
            return "";
        }

       $scope.update();
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof mtaAWOFinalCallBack !== "undefined") {
        return mtaAWOFinalCallBack();
    }
}