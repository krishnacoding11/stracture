/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
        });

        var dateFormatMap = {
            "en_GB": "dd-M-yy",
            "fr_FR": "d M yy",
            "es_ES": "dd-M-yy",
            "ru_RU": "dd.mm.yy",
            "en_AU": "dd/mm/yy",
            "en_CA": "d-M-yy",
            "en_US": "M d, yy",
            "zh_CN": "yy-m-d",
            "de_DE": "dd.mm.yy",
            "ga_IE": "d M yy",
            "en_ZA": "dd M yy",
            "ja_JP": "yy/mm/dd",
            "ar_SA": "dd/mm/yy",
            "en_IE": "dd-M-yy",
            "nl_NL": "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var costCodeDataArray = [];
        var extArray = [];

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation: "Submitted for Information",
            forInformation: "For Information",
            forAction: "For Action",
            forAcceptance: "For Acceptance",
            respond: "Respond",
            openStatus: "Open",
            subjectToChangeAppraisal: "Subject to Change Appraisal",
            subjectToConfirmationNotice: "Subject to Change Confirmation Notice",
            acceptQuote: "Accept Quote",
            reviseAndResubmit: "Revise and Resubmit",
            WithdrawnPCN: "Withdraw PCN",
            Withdrawn: 'Withdrawn',
            Closed: 'Closed',
            EmergencyPCN: 'Emergency PCN',
            Approved: 'Approved',
            Rejected: 'Rejected',

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
            forActionNumber: "36#",

            // Appbuidler codes of forms
            changeAppraisal: "STT-CAF",
            supplierChangeNotice: "STT-SCN",
            projectChangeNotice: "STT-PCN",
            changeAppraisalInstruction: "STT-CAI",
            changeConfirmNotice: "STT-CCN",
            initChangeAppraisal: "STT-ICA",

            // Static role used in Code
            tflRepresentative: "TFL Representative",
            projectManager: "Project Manager",
            contractor: "Contractor",

            // Data source 
            dsSttNnecSertuoSections: "DS_STT_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_STT_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_STT_SECTION_USERS",
            dsSttNnecSecLck: "DS_STT_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_STT_ALL_CONTRACT_TEAM_MEMBERS",
            dsSttNnecGetFormDetailsByStatus: "DS_STT_GET_FORM_DETAILS_BY_STATUS",
            dsAllActiveWsStatus: "DS_ALL_ACTIVE_WS_STATUS",
            dsSttAllIcaSubmission: "DS_STT_ALL_ICA_SUBMISSION",
            dsStt_ICA_CAI_CAF_SCONC_CONC_Validate: "DS_STT_ICA_CAI_CAF_SCONC_CONC_VALIDATE"
        }

        var STATIC_OBJ_DATA = {
            Auto_Distribute_Users: {
                "DS_PROJDISTUSERS": "",
                "DS_FORMACTIONS": "",
                "DS_ACTIONDUEDATE": "",
                "DS_DUEDAYS": "",
                "AutoDist_Id": 1,
                "dist_isSelected": false,
                "isEditable": "1"
            }
        }

        $scope.tableUtilSettings = {
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            }
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;

        var dsSttBlNnecNecPMContract = $scope.getValueOfOnLoadData('DS_STT_NEC_EMP_CONTRACT');
        var dsSttBlNnecNecOrgContract = $scope.getValueOfOnLoadData('DS_STT_NEC_ORG_CONTRACT');
        var dsWorkingUserAllRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_STT_NEC_CONTRACT');
        var isContractor = dsWorkingUserAllRoles[0] && dsWorkingUserAllRoles[0].Name.indexOf('Contractor') > -1;
        var DS_STT_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_STT_ALL_CONTRACT_TEAM_MEMBERS');

        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            $scope.isConSelected = false;
            $scope.dropdownObj = {
                contractList: [],
                tflReprentList: [],
                distSectionsList: [],
                sectionsList: [],
                distUsersList: [],
                formActionList: [],
                contractorList: [],
                statusList: []
            };

            fillDropwdowns();
            initFormData();
            $scope.update();
        } else {
            $scope.linkFielURL = $scope.getValueOfOnLoadData('DS_STT_GET_URL_DETAILS');
            $scope.linkFielURL = $scope.linkFielURL[0] && $scope.linkFielURL[0].URL;
            for (var i = 0; i < $scope.linkContractURL.length; i++) {
                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            }
            var strContractor = $scope.oriMsgCustomFields['TFL_Representative'];
            var checkRole = strContractor && strContractor.split('|')[1].trim();
            strContractor = strContractor && strContractor.split('|')[2].trim();
            $scope.checkContractorOrNot = false;
            var strWorkingId = $scope.getWorkingUserId();
            if (strContractor && checkRole == TFL_CONSTANT.contractor) {
                strContractor = strContractor.split('#')[0].trim();
                if (strWorkingId && strContractor == strWorkingId) {
                    $scope.checkContractorOrNot = true;
                }
            }

            $scope.update();
        }

        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.onContractChange = onContractChange;

        function onContractChange() {
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            var tempConAppCode = commonApi._.filter(contractDataArray, function (mapObj) {
                return mapObj.contractID == contractNumber;
            })[0];

            if (isContractor) {
                $scope.oriMsgCustomFields.ToProjectCoOrTflLabel = "TfL Representative";
            } else {
                $scope.oriMsgCustomFields.ToProjectCoOrTflLabel = "Project Co";
            }

            if ($scope.linkContractURL.length) {
                if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                    var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                        return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes) {
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                        }
                    }
                }
            }

            loadClientLogo(tempConAppCode);

            tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

            var paramAppbuilderCode = TFL_CONSTANT.projectChangeNotice;
            var paramStatus = TFL_CONSTANT.openStatus;

            if (tempConAppCode) {
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSertuoSections,
                        "fieldValue": tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecNecContractSummary,
                        "fieldValue": tempConAppCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                        "fieldValue": tempConAppCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus,
                        "fieldValue": tempConAppCode + "|" + paramAppbuilderCode + "|" + paramStatus
                    }],

                    successCallback: contractChangeCallback,

                };

                $scope.getCallbackSPdata(spParam);

            }
        }

        $scope.onSectionChange = function (strVal) {
            if (strVal) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue": strParam
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue": strParam
                    }],
                    successCallback: sectionChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        // Change Event of extension to Dropdown list
        $scope.setExtensionToValues = function (strCurrentSelectedValue) {
            if (strCurrentSelectedValue) {
                if (strCurrentSelectedValue == 'Submit Initial Change Appraisal') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "Project Co";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Initial Change Appraisal";
                    $scope.oriMsgCustomFields.Ext_Type = "ICA";
                }
                if (strCurrentSelectedValue == 'Reply to Initial Change Appraisal') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "TfL";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Initial Change Appraisal";
                    $scope.oriMsgCustomFields.Ext_Type = "ICA";
                }
                if (strCurrentSelectedValue == 'Submit Change Appraisal') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "Project Co";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Change Appraisal";
                    $scope.oriMsgCustomFields.Ext_Type = "CAF";
                }
                if (strCurrentSelectedValue == 'Reply to Change Appraisal') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "TfL";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Change Appraisal";
                    $scope.oriMsgCustomFields.Ext_Type = "CAF";
                }
                if (strCurrentSelectedValue == 'Reply to Project Co Compensation Event') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "TfL";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Project Co Compensation Event";
                    $scope.oriMsgCustomFields.Ext_Type = "NCE";
                }
                if (strCurrentSelectedValue == 'Reply to Project Co Change Notice') {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ProjectManagerOrContractorLabel = "TfL";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestExtensionTypeLabel = "Project Co Change Notice";
                    $scope.oriMsgCustomFields.Ext_Type = "SCN";
                }

                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "|" + strCurrentSelectedValue;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttAllIcaSubmission,
                        "fieldValue": strParam
                    }],
                    successCallback: requestExtToChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
                $scope.oriMsgCustomFields.Request_Extension_Details.ExtendToDate = "";
                $scope.oriMsgCustomFields.Request_Extension_Details.RequestedExtDays = "";
                $scope.oriMsgCustomFields.Request_Extension_Details.SelectionFilter = "";
            }
        }

        // returns request extension to callback data fill data in item selection
        function requestExtToChangeCallback(responseList) {
            var contractICAList = responseList[TFL_CONSTANT.dsSttAllIcaSubmission];
            extArray = [];
            if (contractICAList.length) {
                for (var i = 0; i < contractICAList.length; i++) {
                    extArray.push({
                        contractAppCode: contractICAList[i].Value3,
                        extCode: contractICAList[i].Value4,
                        contractCode: contractICAList[i].Value2,
                        extTitle: contractICAList[i].Value7,
                        extAppCode: contractICAList[i].Value5,
                        extDate: contractICAList[i].Value8,
                        extUserRef: contractICAList[i].Value9,
                        extDbFormIdAndMsgID: contractICAList[i].Value10 + "|" + contractICAList[i].Value11,
                        extCodeAndTitle: contractICAList[i].Value4 + " | " + contractICAList[i].Value7
                    });
                }
            }
            $scope.dropdownObj.extList = commonApi.getItemSelectionList({
                arrayObject: extArray,
                groupNameKey: "",
                modelKey: "extCode",
                displayKey: "extCodeAndTitle"
            })
        }

        // Change Event of extension for to Dropdown list
        $scope.setExtensionForValues = function (strCurrentSelectedValue) {
            if (strCurrentSelectedValue) {
                var extNumber = $scope.oriMsgCustomFields.Request_Extension_Details.SelectionFilter;
                var objExt = commonApi._.filter(extArray, function (mapObj) {
                    return mapObj.extCode == extNumber;
                })[0];
                $scope.oriMsgCustomFields.ExtAppBuilderId = objExt.extAppCode;
                $scope.oriMsgCustomFields.Request_Extension_Details.ExtendToDate = objExt.extDate;
                $scope.oriMsgCustomFields.ExtDbFormIdAndMsgId = objExt.extDbFormIdAndMsgID;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = strCurrentSelectedValue;
            }
        }

        function fillDropwdowns() {
            // Contract downdown
            var allContractorData = "";
            if (isContractor) {
                allContractorData = dsSttBlNnecNecOrgContract;
            } else {
                allContractorData = dsSttBlNnecNecPMContract;
            }

            for (var i = 0; i < allContractorData.length; i++) {
                var element = allContractorData[i];
                element = element.Value ? element.Value.split('|') : [];
                if (isContractor && element.length) {
                    contractDataArray.push({
                        contractID: element[2].trim(),
                        contractorLogo: element[5].trim(),
                        clientLogo: element[4].trim(),
                        contractName: element[8].trim(),
                        contractAppCode: element[0].trim(),
                        contractIdName: allContractorData[i].Name
                    });
                } else if (element.length) {
                    contractDataArray.push({
                        contractID: element[5].trim(),
                        contractorLogo: element[2].trim(),
                        clientLogo: element[3].trim(),
                        contractName: element[7].trim(),
                        contractAppCode: element[0].trim(),
                        contractIdName: allContractorData[i].Name
                    });
                }
            }

            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });

            // TFL Reprensetative downdown
            var tflRepresentativeArray = [];
            for (var i = 0; i < dsProjUserRole.length; i++) {
                var element = dsProjUserRole[i];
                if (element.Value.indexOf(TFL_CONSTANT.tflRepresentative) > -1) {
                    tflRepresentativeArray.push({
                        userName: element.Name,
                        userID: element.Value
                    });
                }
            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject: tflRepresentativeArray,
                groupNameKey: "",
                modelKey: "userID",
                displayKey: "userName"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

            if (currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields['Request_Extension_Selected'] && $scope.oriMsgCustomFields.CON_AppBuilderId) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "|" + $scope.oriMsgCustomFields['Request_Extension_Selected'];
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttAllIcaSubmission,
                        "fieldValue": strParam
                    }],
                    successCallback: requestExtToOnLoadCallback
                };

                extArray = [];
                $scope.dropdownObj.extList = commonApi.getItemSelectionList({
                    arrayObject: extArray,
                    groupNameKey: "",
                    modelKey: "extCode",
                    displayKey: "extCodeAndTitle"
                })

                $scope.getCallbackSPdata(spParam);
            }

        }

        function requestExtToOnLoadCallback(responseList) {
            var extNumber = $scope.oriMsgCustomFields.Request_Extension_Details.SelectionFilter;
            if (extNumber) {
                var contractICAList = responseList[TFL_CONSTANT.dsSttAllIcaSubmission];
                extArray = [];
                if (contractICAList.length) {
                    for (var i = 0; i < contractICAList.length; i++) {
                        extArray.push({
                            contractAppCode: contractICAList[i].Value3,
                            extCode: contractICAList[i].Value4,
                            contractCode: contractICAList[i].Value2,
                            extTitle: contractICAList[i].Value7,
                            extAppCode: contractICAList[i].Value5,
                            extDate: contractICAList[i].Value8,
                            extUserRef: contractICAList[i].Value9,
                            extDbFormIdAndMsgID: contractICAList[i].Value10 + "|" + contractICAList[i].Value11,
                            extCodeAndTitle: contractICAList[i].Value4 + " | " + contractICAList[i].Value7
                        });
                    }
                }
                var objExt = commonApi._.filter(extArray, function (mapObj) {
                    return mapObj.extCode == extNumber;
                })[0];
                if (!objExt) {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ExtendToDate = "";
                    $scope.oriMsgCustomFields.Request_Extension_Details.RequestedExtDays = "";
                    $scope.oriMsgCustomFields.Request_Extension_Details.SelectionFilter = "";
                    $scope.dropdownObj.extList = commonApi.getItemSelectionList({
                        arrayObject: extArray,
                        groupNameKey: "",
                        modelKey: "extCode",
                        displayKey: "extCodeAndTitle"
                    })
                } else {
                    $scope.oriMsgCustomFields.Request_Extension_Details.ExtendToDate = objExt.extDate;
                }
            }
        }

        function strIsUserDraftOnly() {
            if (DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_STT_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }

        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(contractData) {
            var logoUrl = contractData.clientLogo;
            $scope.oriMsgCustomFields['Logo'] = logoUrl || TFL_CONSTANT.defaultLogo;
        }

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsSttNnecSectionUsers];
            var distLockflag = spDataList[TFL_CONSTANT.dsSttNnecSecLck];

            if (distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            var alreadyAddedArray = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');

                if (alreadyAddedArray.indexOf(nodeVal[0]) > -1) {
                    continue;
                }

                alreadyAddedArray.push(nodeVal[0].trim());

                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }
                var strMatchAction = nodeVal[2].trim() + '#' + nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";

                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                tempList.push({
                    strUser: nodeVal[0].trim() + "#" + userName.trim(),
                    strAction: strAction,
                    strDate: distDate
                });
            }

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
        }

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList) {
            $scope.isConSelected = true;
            // Sections dropdown data based on setup form
            if (responseList[TFL_CONSTANT.dsSttNnecSertuoSections]) {
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[TFL_CONSTANT.dsSttNnecSertuoSections],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            // Contract Activity Summry Data
            costCodeDataArray = responseList[TFL_CONSTANT.dsSttNnecNecContractSummary]
            var tempCostCodeDataArray = angular.copy(costCodeDataArray);
            if (tempCostCodeDataArray.length) {
                tempCostCodeDataArray = commonApi._.uniq(tempCostCodeDataArray, 'Value3');
                $scope.dropdownObj.sectionsList = commonApi.getItemSelectionList({
                    arrayObject: tempCostCodeDataArray,
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value18"
                })
            }

            // Contractor Data list
            var contractTeamMemberList = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers]
            if (contractTeamMemberList.length) {
                var matchRole = '';
                if (isContractor) {
                    matchRole = TFL_CONSTANT.projectManager;
                } else {
                    matchRole = TFL_CONSTANT.contractor;
                }
                var tempVal = [],
                    tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if (tempVal.indexOf(element.Value) == -1 && roleName == matchRole) {
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            DS_STT_ALL_CONTRACT_TEAM_MEMBERS = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers];
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");

            if (isContractor) {
                $scope.dropdownObj.requestExtList = commonApi.getItemSelectionList({
                    arrayObject: [{
                        modelValue: 'Submit Initial Change Appraisal',
                        displayValue: 'Submit Initial Change Appraisal'
                    }, {
                        modelValue: 'Submit Change Appraisal',
                        displayValue: 'Submit Change Appraisal'
                    }],
                    groupNameKey: "",
                    modelKey: "modelValue",
                    displayKey: "displayValue"
                });
            } else {
                $scope.dropdownObj.requestExtList = commonApi.getItemSelectionList({
                    arrayObject: [{
                        modelValue: 'Reply to Initial Change Appraisal',
                        displayValue: 'Reply to Initial Change Appraisal'
                    }, {
                        modelValue: 'Reply to Change Appraisal',
                        displayValue: 'Reply to Change Appraisal'
                    }, {
                        modelValue: 'Reply to Project Co Compensation Event',
                        displayValue: 'Reply to Project Co Compensation Event'
                    }, {
                        modelValue: 'Reply to Project Co Change Notice',
                        displayValue: 'Reply to Project Co Change Notice'
                    }],
                    groupNameKey: "",
                    modelKey: "modelValue",
                    displayKey: "displayValue"
                });
            }

        }

        /**
         * Initialize all form data on load
         */
        function initFormData() {
            if ($scope.oriMsgCustomFields['ContractNo'] && currentViewName == "ORI_VIEW") {
                onContractChange();
                $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            }
            if (currentViewName == "RES_VIEW") {
                var chkPermission = strIsUserDraftOnly();
                if (chkPermission.toLowerCase() == "yes")
                    setSendPermission("Draft");
                else
                    setSendPermission("Send");
            }
        }

        /**
         * @param {Integer} distNumber : it defines DS_AUTODISTRIBUTE value which require to send auto distribute
         * it will be 3 for OR and 13 for Respond 
         */
        function setDistributionNodeForPM(distNumber, actionFlag) {
            var actionStr = "";
            var actionDays = "";
            if (actionFlag == "for Info") {
                actionStr = TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation;
            } else {
                actionStr = TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond;
                actionDays = "3";
            }

            setAutoDistributionNode({
                autoDistFlag: distNumber,
                action: actionStr,
                days: actionDays,
                users: $scope.oriMsgCustomFields['TFL_Representative'].split('|')[2].trim()
            });
        }

        /**
         * 
         * @param {String} param.action : pass action name like For Information/Respond
         * @param {Interger} param.days : pass days in number which indicates due date
         * @param {String} param.user : set User id which you want to send action
         * @param {Interger} param.autoDistFlag : this flag vary distribution ORI and RES view
         */
        function setAutoDistributionNode(param) {
            var actionStr = param.action;
            var days = param.days;
            var users = param.users;
            var autoDistFlag = param.autoDistFlag

            var distDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days: days
            });

            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: users,
                    strAction: actionStr,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: autoDistFlag
            });
        }

        function setFormContentAndFlow() {
            var statusIdApproved = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.Approved
            });

            var statusIdRejected = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.Rejected
            });

            var actionFlag = "";
            if ($scope.oriMsgCustomFields['TFL_Representative']) {
                if (isContractor) {
                    actionFlag = "respond";
                } else {
                    actionFlag = "for Info";
                }
                setDistributionNodeForPM(TFL_CONSTANT.oriDistNumb, actionFlag);
            }

            var extAppCode = $scope.oriMsgCustomFields.ExtAppBuilderId;
            var contractAppCode = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var extType = $scope.oriMsgCustomFields.Ext_Type;

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = contractAppCode + "|" + extAppCode + "|" + extType;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = extAppCode;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = $scope.oriMsgCustomFields.Request_Extension_Details.RequestedExtDays;

            //set OTH FLAGS
            if (isContractor) {
                $scope.oriMsgCustomFields.DS_AU_OTH_FORM = "0";
            }

            var isTflAgreed = $scope.oriMsgCustomFields.tflAgreeWithProjCoFlag;
            if (currentViewName == "RES_VIEW" && isTflAgreed) {
                if (isTflAgreed == "agree") {
                    $scope.oriMsgCustomFields.DS_AU_OTH_FORM = "1";
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdApproved;
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdRejected;
                }
            } else {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdApproved;
            }
        }

        $window.extFinalCallBack = function () {
            if ($scope.submitFlag) {
                return false;
            }
            setFormContentAndFlow();
            var strParam = $scope.oriMsgCustomFields.ExtDbFormIdAndMsgId;
            var spParam = {
                dataSourceArray: [{
                    "fieldName": TFL_CONSTANT.dsStt_ICA_CAI_CAF_SCONC_CONC_Validate,
                    "fieldValue": strParam
                }],
                successCallback: function (responseList) {
                    if (responseList[TFL_CONSTANT.dsStt_ICA_CAI_CAF_SCONC_CONC_Validate][0].Value2 == "No") {
                        alert("Unable to Extend the Date.");
                    } else {
                        $scope.submitFlag = true;
                        $window.submitForm(1);
                    }
                }
            };

            $scope.getCallbackSPdata(spParam);

            return true;
        }

    };
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof extFinalCallBack !== "undefined") {
        return extFinalCallBack();
    }
}