/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util','../components/item.selection'], function(angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
            var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
		$scope.getServerTime(function (serverDate) {			
			$scope.serverDate = serverDate;
		});

        var dateFormatMap = {"en_GB":"dd-M-yy","fr_FR":"d M yy","es_ES":"dd-M-yy","ru_RU":"dd.mm.yy","en_AU":"dd/mm/yy","en_CA":"d-M-yy","en_US":"M d, yy","zh_CN":"yy-m-d","de_DE":"dd.mm.yy","ga_IE":"d M yy","en_ZA":"dd M yy","ja_JP":"yy/mm/dd","ar_SA":"dd/mm/yy","en_IE":"dd-M-yy","nl_NL":"dd-M-yy"};
    	$scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var costCodeDataArray = [];

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation :"Submitted for Information",
            forInformation : "For Information",
            forAction : "For Action",
            forAcceptance : "For Acceptance",
            respond: "Respond",
            openStatus: "Open",
            subjectToChangeAppraisal: "Subject to Change Appraisal",
            subjectToConfirmationNotice: "Subject to Change Confirmation Notice",
            acceptQuote : "Accept Quote",
            reviseAndResubmit: "Revise and Resubmit",
            WithdrawnPCN: "Withdraw PCI",
            Withdrawn: 'Withdrawn',
            Closed: 'Closed',
            EmergencyPCN: 'Emergency PCI',

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
            forActionNumber: "36#",

            // Appbuidler codes of forms
            changeAppraisal: "RVL-CAFC",
            supplierChangeNotice: "RVL-CCN",
            projectChangeNotice: "RVL-PCI",
            changeAppraisalInstruction: "RVL-CAIC",
            changeConfirmNotice: "RVL-CCNC",
            initChangeAppraisal: "RVL-ICAC",

            // Static role used in Code
            tflRepresentative : "TFL Representative",
            preojectManager: "Project Manager",
            contractor: "Contractor",

            // Data source 
            dsSttNnecSertuoSections : "DS_RVL_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_RVL_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_RVL_SECTION_USERS",
            dsSttNnecSecLck: "DS_RVL_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_RVL_ALL_CONTRACT_TEAM_MEMBERS",
            dsSttNnecGetFormDetailsByStatus: "DS_RVL_GET_FORM_DETAILS_BY_STATUS",
            dsAllActiveWsStatus: "DS_ALL_ACTIVE_WS_STATUS",
            dsSttNecAllEwn: "DS_RVL_NEC_ALL_EWN",
            dsSttNecKeyContractDates: "DS_RVL_NEC_KEY_CONTRACT_DATES",
            dsRvlSetupSubject : "DS_RVL_SUB_DIST_DETAILS",
            dsRvlSetupSubjectUsers : "DS_RVL_SUBJECT_USERS"
        }

        var STATIC_OBJ_DATA = {
            Costcode : {
                "sections":"",
                "costCodes":"",
                "costValue":"",
                "CC_isSelected": "",
                "ccGuId" :""
            },
            sectionDetails: {
                "sectionName":"",
                "workName":"",
                "comDate":"",
                "sd_isSelected":"",
                "sdGuId":""
            },
            Auto_Distribute_Users :{
				"DS_PROJDISTUSERS" : "",
				"DS_FORMACTIONS" : "",
				"DS_ACTIONDUEDATE" : "",
				"DS_DUEDAYS" : "",
				"AutoDist_Id": 1,
				"dist_isSelected": false,
				"isEditable": "1"
            },
            Section_Users: {
                Sec_AutoDistId: "",
                User_Name: "",
                User_Action: "",
                Sec_IsEditable: "1",
                Sec_IsSelected: false,
                User_Action_Due_Date:"",
                User_Action_Due_Days:""
            }
        }

        $scope.tableUtilSettings = {
            Costcode : {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "CC_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Costcode)
            },
            sectionDetails : {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "sd_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sectionDetails)
            },
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sectionDetails)
            }
        }
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.arrCostcodeGroup = $scope.oriMsgCustomFields["CostcodeGroup"];
        $scope.arrSectionDetailGroups = $scope.oriMsgCustomFields["sectionDetailGroups"];
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;

        var dsSttBlNnecNecOrgConctract = $scope.getValueOfOnLoadData('DS_RVL_NEC_EMP_CONTRACT');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var dsAllActiveWsStatus = $scope.getValueOfOnLoadData(TFL_CONSTANT.dsAllActiveWsStatus);
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_RVL_NEC_CONTRACT');
        var DS_RVL_SUB_DIST_DETAILS = $scope.getValueOfOnLoadData('DS_RVL_SUB_DIST_DETAILS'); 
        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        if(currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW"){
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            $scope.isConSelected = false;
            $scope.dropdownObj = {
                contractList : [],
                tflReprentList: [],
                distSectionsList: [],
                sectionsList: [],
                distUsersList: [],
                formActionList: [],
                contractorList: [],
                projectManagerList:[],
                statusList: [],
                ewnList: [],
                distSubjectList:[]
            };
            fillDropwdowns();
            initFormData();
            $scope.update();
        } else{
            for (var i = 0; i < $scope.linkContractURL.length; i++) {
                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            }
            $scope.linkEarlyWarningURL = $scope.getValueOfOnLoadData('DS_RVL_NEC_EWN_LINK');
            for (var i = 0; i < $scope.linkEarlyWarningURL.length; i++) {
                if ($scope.linkEarlyWarningURL[i] && $scope.linkEarlyWarningURL[i].Value && $scope.linkEarlyWarningURL[i].Value.indexOf($scope.oriMsgCustomFields.EWN_ID) > -1) {
                    $scope.linkEarlyWarningURL = $scope.linkEarlyWarningURL[i].URL;
                    break;
                }
            }
            var strContractor = $scope.oriMsgCustomFields['TFL_Representative'];
            var checkRole = strContractor && strContractor.split('|')[1].trim();
            strContractor = strContractor && strContractor.split('|')[2].trim();
            $scope.checkContractorOrNot = false;
            var strWorkingId = $scope.getWorkingUserId();
            if (strContractor && checkRole == TFL_CONSTANT.contractor) {
            	strContractor = strContractor.split('#')[0].trim();
            	if (strWorkingId && strContractor == strWorkingId) {
            		$scope.checkContractorOrNot = true;
            	}
            }
            $scope.update();
        }

        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.onContractChange = onContractChange;
        
        function onContractChange(){
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            var tempConAppCode = commonApi._.filter(contractDataArray, function(mapObj){
                return mapObj.contractID == contractNumber;
            })[0];

            if ($scope.linkContractURL.length) {
                if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                    var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                        return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes) {
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                        }    
                    }
                }    
            }

            loadClientLogo(tempConAppCode);

            tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

            var paramAppbuilderCode = TFL_CONSTANT.projectChangeNotice;
            var paramStatus = TFL_CONSTANT.openStatus;

            if(tempConAppCode){
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
                var spParam = {
                    dataSourceArray : [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSertuoSections,
                        "fieldValue":  tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNnecNecContractSummary,
                        "fieldValue":  tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                        "fieldValue":  tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus,
                        "fieldValue":  tempConAppCode+"|"+paramAppbuilderCode+"|"+ paramStatus
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNecAllEwn,
                        "fieldValue": tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNecKeyContractDates,
                        "fieldValue": tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsRvlSetupSubject,
                        "fieldValue": tempConAppCode
                    }],                    
                    successCallback : contractChangeCallback,
                };
                $scope.getCallbackSPdata(spParam);   
            }
        }

        $scope.onDaysChange = function(enteredDaysNode, ContractDaysNode, replyDateNode) {
            var enteredDays = $scope.oriMsgCustomFields[enteredDaysNode];
            var contractDays = $scope.oriMsgCustomFields[ContractDaysNode];
            if ((enteredDays && contractDays && parseInt(enteredDays) < parseInt(contractDays)) || (!enteredDays && contractDays)) {
                alert("Entered days cannnot be less than contract days");
                $scope.oriMsgCustomFields[enteredDaysNode] = $scope.oriMsgCustomFields[ContractDaysNode];
            }
            var replyDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days : $scope.oriMsgCustomFields[enteredDaysNode]
            });
            $scope.oriMsgCustomFields[replyDateNode] = replyDate;
        }

        $scope.onSectionChange = function(strVal){
            
            if(strVal){
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray : [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue":  strParam
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue":  strParam
                    }],
                    successCallback : sectionChangeCallback
                };
    
                $scope.getCallbackSPdata(spParam);    
            }
        }

        $scope.onSubjectChange = function(strVal){
            
            if(strVal){
                var strParam = strVal.trim();                
                var Revno = commonApi._.filter(DS_RVL_SUB_DIST_DETAILS, function (val) {
                    return val.Value3 == strVal;
                })[0];
                if(Revno){
                    $scope.oriMsgCustomFields.Subject = Revno.Value2;
                }
                var spParam = {
                    dataSourceArray : [{
                        "fieldName": TFL_CONSTANT.dsRvlSetupSubjectUsers,
                        "fieldValue":  strParam
                    }],
                    successCallback : subjectChangeCallback                   
                };
                $scope.getCallbackSPdata(spParam);    
            }
        }

        /**
         * To Clear all objection checkbox on change objection ye/no
         */
        $scope.icaObjectCheckChange = function(){
            $scope.oriMsgCustomFields['objectionFlags']['groundCond'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['geoTechIssue'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['faultyDesign'] = 'No';
            resetSetctionsGroup();
        }

        // To create ICA form form PCN
        $scope.launchICAForm = function () {
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '3';
            $window.prePopulatemapping['SRC1'] = $scope.oriMsgCustomFields.ContractNo;
            $window.prePopulatemapping['TG1'] = 'ContractNo';
            $window.prePopulatemapping['SRC2'] = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
            $window.prePopulatemapping['TG2'] = 'PCN_AppNumber_LaunchButton';
            $window.prePopulatemapping['SRC3'] = "PCN";
            $window.prePopulatemapping['TG3'] = 'changeType';
            $window.launchCreateForm(TFL_CONSTANT.initChangeAppraisal);
        }

        // To reset cost optins while check/uncheck TFL agree flag
        $scope.resetCostOption = function(){
            $scope.oriMsgCustomFields['costOption'] = ""
        }
        
        // To fill cost code dropdown while selecting sections in CA and ICA
        $scope.fillConstCodes = function(currObj){
            var strSecname = commonApi._.filter(costCodeDataArray, function (val) {
                return val.Value3 == currObj.sections;
            });
           
            currObj.costCodes1 = "";

            currObj.costList = commonApi.getItemSelectionList({
                arrayObject: strSecname,
                groupNameKey: "",
                modelKey: "Value14",
                displayKey: "Value14"
            });
        }

        // Change Event of PCN/ICN Dropdwon list
        $scope.pcnListChange = function(dataKey){
            //DS_FORMCONTENT
            if($scope.oriMsgCustomFields[ dataKey ]){
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = $scope.oriMsgCustomFields[ dataKey ].split("|")[0].trim();
            }
        }

        // on EWN Reference Change
        $scope.onEWN_Change = function () {
            var ewnRef = $scope.oriMsgCustomFields.DS_RVL_NEC_ALL_EWN;
            $scope.oriMsgCustomFields.EWN_ID = ewnRef.split('#')[1].split('|')[0].trim();
            if (ewnRef) {
                var ewnAppId = ewnRef.split('|')[4].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = ewnAppId;
            }
        }

        $scope.onTFLAgreeChange = function(){
            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
            if($scope.oriMsgCustomFields['projCoObjFlag'] == 'No'){
                if($scope.oriMsgCustomFields['isTFLagreed']=='Yes'){
                    var statusIds = $scope.getFormStatus({
                        spName : TFL_CONSTANT.dsAllActiveWsStatus,
                        status : TFL_CONSTANT.subjectToChangeAppraisal
                    });
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                }else{
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
                }
            }
        }
        
        function fillDropwdowns(){

            // Contract downdown

            for (var i = 0; i < dsSttBlNnecNecOrgConctract.length; i++) {
            	var element = dsSttBlNnecNecOrgConctract[i];
            	element = element.Value ? element.Value.split('|') : [];
            	if (element.length) {
            		contractDataArray.push({
            			contractID: element[5].trim(),
            			contractorLogo: element[2].trim(),
            			clientLogo: element[3].trim(),
            			contractName: element[7].trim(),
            			contractAppCode: element[0].trim(),
            			contractIdName: dsSttBlNnecNecOrgConctract[i].Name
                    });
            	}
            }

            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });

            // TFL Reprensetative downdown
            var tflRepresentativeArray = [];
            for (var i = 0; i < dsProjUserRole.length; i++) {
                var element = dsProjUserRole[i];
                if(element.Value.indexOf( TFL_CONSTANT.tflRepresentative ) > -1){
                    tflRepresentativeArray.push({
                        userName : element.Name,
                        userID : element.Value
                    });
                }
            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject: tflRepresentativeArray,
                groupNameKey: "",
                modelKey: "userID",
                displayKey: "userName"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
        }

        function setActionDropdownList(tflAgreFlag){
            // Dropdown for Status list in RES_VIEW
            var tempStatuses = [];
            if(tflAgreFlag == 'No'){
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus,function(obj){
                    return (obj.Name == TFL_CONSTANT.WithdrawnPCN || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            }else{
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus,function(obj){
                    return (obj.Name == TFL_CONSTANT.subjectToChangeAppraisal || obj.Name == TFL_CONSTANT.WithdrawnPCN || obj.Name == TFL_CONSTANT.acceptQuote || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            }
            $scope.dropdownObj.statusList = commonApi.getItemSelectionList({
                arrayObject: tempStatuses,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })
        }

        function strIsUserDraftOnly(strMatch, data) {
            if (data.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < data.length; i++) {
                    strValue = data[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == strMatch) {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }   

        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(contractData){
            var logoUrl = contractData.clientLogo;            
            $scope.oriMsgCustomFields['Logo'] = logoUrl || TFL_CONSTANT.defaultLogo;
        }

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsSttNnecSectionUsers];
            var distLockflag = spDataList[TFL_CONSTANT.dsSttNnecSecLck];
            var removeFromUser="";
            if (distLockflag && distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            var alreadyAddedArray = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');

                if (alreadyAddedArray.indexOf(nodeVal[0]) > -1) {
                    continue;
                }

                alreadyAddedArray.push(nodeVal[0].trim());

                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }
                var strMatchAction = nodeVal[2].trim() + '#' + nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";

                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                removeFromUser=checkDuplicateFromUser(nodeVal[0].trim(), strAction);
                var strDistusersp = setRecipientUser(nodeVal[0].trim());
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                if(removeFromUser=="NO"){

                    tempList.push({
                        strUser: strDistusersp.trim(),
                        strAction: strAction,
                        strDate: distDate
                    });
                }
                
            }
            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
            $scope.oriMsgCustomFields.All_Section_Users.Section_Users = [];
            setSectionUsers(tempList);
        }

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function subjectChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsRvlSetupSubjectUsers];
            var removeUser = "";
            var removeFromUser="";
            var tempList = [];
            var alreadyAddedArray = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');

                if (alreadyAddedArray.indexOf(nodeVal[0]) > -1) {
                    continue;
                }

                alreadyAddedArray.push(nodeVal[0].trim());

                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }
                var strMatchAction = nodeVal[2].trim() + '#' + nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";
                removeUser = checkDuplicateUsersInDistribution(nodeVal[0].trim(), strAction);
                removeFromUser=checkDuplicateFromUser(nodeVal[0].trim(), strAction);
                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                var strDistusersp = setRecipientUser(nodeVal[0].trim());
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                if (removeUser == "NO" && removeFromUser=="NO") {

                    tempList.push({
                        strUser: strDistusersp.trim(),
                        strAction: strAction,
                        strDate: distDate
                    });
                }
            }
            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
            setSectionUsers(tempList);
        }        
        $scope.onSendReviewDraftChange = function (strVal) {

            if (strVal && strVal == "Yes") {

                var fromUser = $scope.oriMsgCustomFields.From_Users;
                var tempList = [];
                var removeUser="";
                if (fromUser && fromUser.length) {

                    var stFromruser = fromUser.split('|')[2].trim().split('#')[0].trim();
                    var strDistusersp = setRecipientUser(stFromruser);
                    var strFromAction = "34#Review Draft";
                    removeUser = checkDuplicateUsersInDistribution(stFromruser, strFromAction);
                    var distDate = "3"
                    if (distDate) {
                        distDate = commonApi.calculateDistDateFromDays({
                            baseDate: $scope.serverDate,
                            days: parseInt(distDate.trim())
                        })
                    }
                    if(removeUser=="NO"){

                        tempList.push({
                            strUser: strDistusersp,
                            strAction: strFromAction,
                            strDate: distDate
                        });
    
                    }
                    
                    commonApi.setDistributionNode({
                        actionNodeList: tempList,
                        autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                        DS_AUTODISTRIBUTE: 3
                    });
                }
            }
        }
        function setSectionUsers(userList) {

            if (userList && userList.length) {

                for (var i = 0; i < userList.length; i++) {

                    var structSectionUsers = angular.copy(STATIC_OBJ_DATA.Section_Users)
                    structSectionUsers.Sec_AutoDistId = "";
                    structSectionUsers.User_Name = userList[i].strUser;
                    structSectionUsers.User_Action = userList[i].strAction;
                    structSectionUsers.User_Action_Due_Date = userList[i].strDate;
                    structSectionUsers.User_Action_Due_Days = "";
                    $scope.oriMsgCustomFields.All_Section_Users.Section_Users.push(structSectionUsers);
                }
            }
        }
        function checkDuplicateUsersInDistribution(subUserId, subUserAction) {

            var recipientList = $scope.oriMsgCustomFields.All_Section_Users.Section_Users;
            var duplicateUser = "NO"
            if (recipientList && recipientList.length) {

                for (var i = 0; i < recipientList.length; i++) {

                    var userName = recipientList[i].User_Name.split('#')[0];
                    var userAction = recipientList[i].User_Action;

                    if (userName && userName.length && userName == subUserId) {

                        if (userAction && userAction.length && userAction == subUserAction) {
                            duplicateUser = "YES";
                        }
                    }
                }
                return duplicateUser;
            }
        }
        function setRecipientUser(strUserid) {
            var usersObj = commonApi._.filter(dsProjDistUsers, function (val) {
                return val.Value.trim().indexOf(strUserid) > -1;
            });
            if (usersObj.length) {
                return usersObj[0].Value.trim();
            }
            return "";
        }

        function checkDuplicateFromUser(userId, userAction) {

            var fromUser = $scope.oriMsgCustomFields.From_Users;
            var duplicateFromUser = "NO";
            if (fromUser && fromUser.length) {

                var stFromuser = fromUser.split('|')[2].trim().split('#')[0].trim();
                var strFromAction = "34#Review Draft";

                if (userId && userId.length && userAction && userAction.length) {

                    if (stFromuser == userId && strFromAction == userAction) {

                        duplicateFromUser = "YES";
                        return duplicateFromUser;
                    }
                }
                return duplicateFromUser;
            }
            return duplicateFromUser;
        }

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList){
            $scope.isConSelected = true;
            // Sections dropdown data based on setup form
            if(responseList[ TFL_CONSTANT.dsSttNnecSertuoSections ]){
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[ TFL_CONSTANT.dsSttNnecSertuoSections ],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            //Subject List
            if(responseList[ TFL_CONSTANT.dsRvlSetupSubject ]){
                $scope.dropdownObj.distSubjectList = commonApi.getItemSelectionList({
                    arrayObject: responseList[ TFL_CONSTANT.dsRvlSetupSubject ],
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value2"
                })
            }


            //ewn list
            if (responseList[TFL_CONSTANT.dsSttNecAllEwn]) {
                var allNodes = responseList[TFL_CONSTANT.dsSttNecAllEwn];
                var match = true;
                var matchNode = "";
                $scope.dropdownObj.ewnList = commonApi.getItemSelectionList({
                    arrayObject: allNodes,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
                if ($scope.oriMsgCustomFields['EWN_ID']) {
                    for (var i = 0; i < allNodes.length; i++) {
                        matchNode = allNodes[i].Name.split('|')[0].trim();
                        if (matchNode == $scope.oriMsgCustomFields['EWN_ID']) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        $scope.oriMsgCustomFields['DS_RVL_NEC_ALL_EWN'] = "";
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = "";
                        $scope.oriMsgCustomFields['EWN_ID'] = "";
                        $scope.linkEarlyWarningURL = "";
                    }
                }    
            }

            // Contract Activity Summry Data
            costCodeDataArray = responseList[ TFL_CONSTANT.dsSttNnecNecContractSummary ]
            var tempCostCodeDataArray = angular.copy(costCodeDataArray);
            if( tempCostCodeDataArray.length ){
                tempCostCodeDataArray = commonApi._.uniq(tempCostCodeDataArray,'Value3');
                $scope.dropdownObj.sectionsList = commonApi.getItemSelectionList({
                    arrayObject: tempCostCodeDataArray,
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value18"
                })
            }

            // Contractor Data list
            var contractTeamMemberList = responseList[ TFL_CONSTANT.dsSttNnecAllContractTeamMembers ]
            if( contractTeamMemberList.length ){
                var matchRole = TFL_CONSTANT.contractor;
                var tempVal = [], tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if(tempVal.indexOf(element.Value) == -1 && roleName == matchRole){
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            //Project Manager Data List

            var contractTeamMemberList = responseList[ TFL_CONSTANT.dsSttNnecAllContractTeamMembers ]
            if( contractTeamMemberList.length ){
                var matchRole = TFL_CONSTANT.preojectManager;
                var tempVal = [], tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if(tempVal.indexOf(element.Value) == -1 && roleName == matchRole){
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.projectManagerList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            // Contractor response days Data list
            var contractResponseDaysList = responseList[TFL_CONSTANT.dsSttNecKeyContractDates]
            if (contractResponseDaysList.length) {
                var responseDays = "";
                for (var i = 0; i < contractResponseDaysList.length; i++) {
                    if (contractResponseDaysList[i].Value2 == "4") {
                        responseDays = contractResponseDaysList[i].Value4;
                    }
                }
                $scope.oriMsgCustomFields['ICA_Reply_Days'] = responseDays;
                $scope.oriMsgCustomFields['ICA_Reply_Days_Backup'] = responseDays;
                var replyDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: responseDays
                });
                $scope.oriMsgCustomFields['Reply_Date'] = replyDate;
            }

            var chkPermission = strIsUserDraftOnly("draft only", responseList[ TFL_CONSTANT.dsSttNnecAllContractTeamMembers ]);
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");

        }

        /**
         * To reset/blank section's data
         */
        function resetSetctionsGroup(){
            $scope.arrCostcodeGroup['Costcode'] = [ angular.copy(STATIC_OBJ_DATA.Costcode) ];
            $scope.arrCostcodeGroup['costValueTotal'] = 0;
        }


        /**
         * Initialize all form data on load
         */
        function initFormData(){
            $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            if ($scope.oriMsgCustomFields['ContractNo']) {
                onContractChange();
            }
        }

        /**
         * @param {Integer} distNumber : it defines DS_AUTODISTRIBUTE value which require to send auto distribute
         * it will be 3 for OR and 13 for Respond 
         */
        function setDistributionNodeForPM(distNumber, actionFlag) {
            var actionStr = "";
            if (actionFlag == "for Info") {
                actionStr = TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation;
            } else {
                actionStr = TFL_CONSTANT.forActionNumber + TFL_CONSTANT.forAction;
            }
            var tfluser = $scope.oriMsgCustomFields['TFL_Representative'].split('|')[2].trim();
            var representative = setRecipientUser(tfluser.split('#')[0].trim());
            setAutoDistributionNode({
                autoDistFlag: distNumber,
                action: actionStr,
                days: $scope.oriMsgCustomFields['ICA_Reply_Days'],
                users: representative
            });
        }

        /**
         * 
         * @param {String} param.action : pass action name like For Information/Respond
         * @param {Interger} param.days : pass days in number which indicates due date
         * @param {String} param.user : set User id which you want to send action
         * @param {Interger} param.autoDistFlag : this flag vary distribution ORI and RES view
         */
        function setAutoDistributionNode(param){
            var actionStr = param.action;
            var days = param.days;
            var users = param.users;
            var autoDistFlag = param.autoDistFlag
    
            var distDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days : days
            });

            commonApi.setDistributionNode({
                actionNodeList : [{
                    strUser : users,
                    strAction : actionStr,
                    strDate : distDate
                }],
                autoDistributeUsers : $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,				
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE : autoDistFlag
            });
        }
        
        function setEwnData() {
            var ewnRef = $scope.oriMsgCustomFields.DS_RVL_NEC_ALL_EWN;
            if (ewnRef) {
                var ewnAppId = ewnRef.split('|')[4].trim();
                var statusIds = $scope.getFormStatus({
                    spName: TFL_CONSTANT.dsAllActiveWsStatus,
                    status: TFL_CONSTANT.Closed
                });
                if (statusIds) {
                    $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = ewnAppId;
                    $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = statusIds.split('#')[0].trim();
                }
            }

            var statusIdEmergencyPCN = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.EmergencyPCN
            });

            var actionFlag = "";
            if ($scope.oriMsgCustomFields['TFL_Representative']) {
                if ($scope.oriMsgCustomFields['changeType'] == "Emergency Change") {
                    actionFlag = "for Action";
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdEmergencyPCN;
                } else {
                    actionFlag = "for Info";
                }
                if (actionFlag) {
                    setDistributionNodeForPM(TFL_CONSTANT.oriDistNumb, actionFlag);
                }
            }
        }

        $window.pcnFinalCallBack = function(){
            if (currentViewName == "ORI_VIEW") {
                setEwnData();
            }            
            return false;
        }

    };
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pcnFinalCallBack !== "undefined") {
        return pcnFinalCallBack();
    }
}