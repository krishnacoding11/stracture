/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util','../components/number-format'], function (angular, mainModule, baseController) {
	'use strict';

		/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {	
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement && event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if(!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') && 
			!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if(!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') && 
			!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function(taRegisterTool, taOptions) {
			taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                []
            ];
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
			taRegisterTool("fontColor", {
				display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("foreColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-font",
					showButtons: !1,
                    showAlpha : !1
				},
				color: "#000"
			}),
			taRegisterTool('fontName', {
				display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>"+"</button>",
				action: function (event, font) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
					this.$element.toggleClass('open-fonts-list');
					return this.$editor().wrapSelection('fontName', font);
				},	
				disabled: function() {},			
				options: [
					{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
					{ name: 'Serif', css: "'times new roman', serif" },
					{ name: 'Wide', css: "'arial black', sans-serif" },
					{ name: 'Narrow', css: "'arial narrow', sans-serif" },
					{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
					{ name: 'Courier New', css: "'courier new', monospace" },
					{ name: 'Garamond', css: 'garamond, serif' },
					{ name: 'Georgia', css: 'georgia, serif' },
					{ name: 'Tahoma', css: 'tahoma, sans-serif' },
					{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
					{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
					{ name: 'Verdana', css: 'verdana, sans-serif' },
					{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
				]
			}),
			taRegisterTool('fontSize', {
				display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",				
				action: function (event, size) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-list').removeClass('open-fonts-list');
					this.$element.toggleClass('open-fonts-size-list');					
					return this.$editor().wrapSelection('fontSize', parseInt(size));					
				},			                
				disabled: function() {},
				options: [
					{ name: 'xx-small', css: 'xx-small', value: 1 },
					{ name: 'x-small', css: 'x-small', value: 2 },
					{ name: 'small', css: 'small', value: 3 },
					{ name: 'medium', css: 'medium', value: 4 },
					{ name: 'large', css: 'large', value: 5 },
					{ name: 'x-large', css: 'x-large', value: 6 },
					{ name: 'xx-large', css: 'xx-large', value: 7 }

				]
			}),
			taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'),taOptions;
		}
		]);
	};
	
	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
    });

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
		
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		var ctrl = this;
		var modelRowIndex = -1;
		$scope.modalData = {};
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		$scope.getServerTime(function (serverDate) {
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
		});

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadwrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
		$scope.dSDraft = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'];
		var dSDraftRESMsg = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		var dsWorkingUser = $scope.Asite_System_Data_Read_Only._1_User_Data.DS_WORKINGUSER;
		var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
		var DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS');
		var DS_ASI_STD_FIDIC_NEC_COMM_TYPES = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_COMM_TYPES');
		var DS_ASI_STD_FIDIC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_CONTRACT');
		var DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES');
		var DS_ASI_STD_FIDIC_NEC_ALL_EWN = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ALL_EWN');
		$scope.DS_RES_COUNT = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_RES_COUNT'];
		var DS_ASI_STD_FIDIC_SETUP_SECTIONS = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_SETUP_SECTIONS');
		var DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY');
		var DS_ASI_STD_FIDIC_KEY_DATES_SUMMARY = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_KEY_DATES_SUMMARY');
		var DS_ASI_GET_CURRENCY_FROM_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_GET_CURRENCY_FROM_CONTRACT');
		var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
		var DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		$scope.sectionGroup = $scope.resMsgCustomFields.Cost_Changes;
		$scope.keyMilestones = $scope.resMsgCustomFields.Prog_Changes;
		$scope.isUserOriginator = $scope.oriMsgCustomFields.Originator_Id == $scope.currentUserid;
		$scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
		$scope.isDataLoaded = true;
		$scope.dropdownObj = {
			contractNoList: [],
			distSectionsList: [],
			engineerlist: [],
			communicationList: [],
			clausesList: [],
			groupUsers: [],
			ewnList:[],
			employerlist: [],
			forInfoUserslist:[],
			objSectionCode: [],
			objActivity: [],
			objKeydate: [],
			valueEngList:[],
			noticeList:[]
		};

		var STATIC_OBJ_DATA = {

			CEN_EVENT_CLAUSES: {
				"ClauseNo": "",
				"Clause_Text": "",
				"isClauseSelected": false
			},
			CEN_EVENT_RES_CLAUSES: {
				"ClauseNoRes": "",
				"Clause_TextRes": "",
				"isClauseSelectedRes": false
			},
			All_Responses: {
				"DSI_ResID": "",
				"Response_Remarks": "",
				"Response_Creator": "",
				"Response_Date": "",
				"DSI_ResFlag": "",
				"ClausesListRes":"",
				"Header_Label":"",
				"Reason_For_Notice":"",
				"Response_User_Role":"",
				"Latest_Response_Flag":"",
				"Response_Communication_Type":"",
				"Response_Cancel_Variation":"",
				"CEN_EVENT_ALL_RES_CLAUSES":{
					"CEN_EVENT_RES_CLAUSES": []
				}
			},
			Sections: {
				Section_Code: "",
				Section_Name: "",
				Activity_Code: "",
				Activity_Name: "",
				Act_Current_Additions: "0.00",
				Act_Sel: "",
				sec_isSelected: false,
				Unit:"",
                Quantity:0,
				Currency_Data_Table: {
					Currency_Table: []
				}
			},
			Impacted_Key_Dates: {
				Key_Date_Id: "",
				Date_Description: "",
				KD_Current_Additions: "",
				Date_Type: "",
				Date_Ref: "",
				KD_Sel: "",
				key_isSelected: false,
			},
            Currency_table: {
                other_Currency: "",
                other_Cur_Exc_Rate:0
            }
		}

		var FIDIC_CONSTANT = {
			UNAUTHORIZED_MSG: "1|You are not authorised to respond this form. You therefore cannot respond, please click the cancel button at the bottom of the form.",
			RESPOND_ACTION: '3#Respond',
			INFO_ACTION: '7#For Information',
			ROLE_ALREADY_TITLE: 'Role is already selected',
			ROLE_ALREADY_MSG: 'Please select different role.',
			SERVER_ERROR_TITLE: 'Server Error',
			SECTION_SERVER_ERROR_MSG: 'Error while getting Section Data.',
			employer: 'Employer',
			engineer: 'Engineer',
			contractor: 'Contractor',
			referred:'Referred',
			mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
			priceBreakDown: 'price-breakdown',
			keyContractDates: 'key-contract-dates'
		};

		$scope.tableUtilSettings = {
			
			Impacted_Activities: {
				tooltip: "Select to Edit/Remove/Remove all data",
				hasDefaultRecord: false,
				editRowCallBack: editSectionModal,
				hideControlIcon: {
					insertBefore: 0,
					insertAfter: 0,
				},
				deleteItemCallBack: contractTotalOfPriceBreakDown,
				checkboxModelKey: "sec_isSelected",
				DELETE_ALL_CONFIRM_MSG: "Do you want to remove all estimate of cost changes?",
				newStaticObject: angular.copy(STATIC_OBJ_DATA.Sections),
				ADD_NEW_BEFORE_TIP: "Insert before cost change estimate",
				ADD_NEW_AFTER_TIP: "Insert after cost change estimate",
				deleteAllRowTooltip: "Remove all cost change estimate",
				deleteCurrRowMsg: "Remove cost change estimate",
				deleteSelectedMsg: "Remove selected cost change estimate"
			},
			Impacted_Key_Dates: {
				tooltip: "Select to Edit/Remove/Remove all data",
				hasDefaultRecord: false,
				editRowCallBack: editKeyModal,
				hideControlIcon: {
					insertBefore: 0,
					insertAfter: 0,
				},
				deleteItemCallBack: "",
				checkboxModelKey: "key_isSelected",
				newStaticObject: angular.copy(STATIC_OBJ_DATA.Impacted_Key_Dates),
				ADD_NEW_BEFORE_TIP: "Insert before programme change estimate",
				ADD_NEW_AFTER_TIP: "Insert after programme change estimate",
				deleteAllRowTooltip: "Remove all programme change estimate",
				deleteCurrRowMsg: "Remove programme change estimate",
				deleteSelectedMsg: "Remove selected programme change estimate"
			}
		}

		if (currentViewName == "ORI_VIEW") {

			if($scope.dSFormId == ""){
				$scope.oriMsgCustomFields.Originator_Id = $scope.currentUserid;
			}
			if ($scope.dSFormId && $scope.dSDraft == "NO") {
				$scope.oriMsgCustomFields.Can_Forward = "";
				$scope.hideSaveDraftButton();
			}
			var contractData = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ORG_CONTRACT');
			$scope.dropdownObj.contractNoList = commonApi.getItemSelectionList({
				arrayObject: contractData,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var chkPermission = strIsUserDraftOnly();
			if (chkPermission.toLowerCase() == "yes")
				setSendPermission("Draft");
			else
				setSendPermission("Send");

			if ($scope.dSDraft == "YES") {
				fillDropwdowns();
			}
		}

		if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
			if ($scope.dSFormId) {
				checkUserCanRespond();
				fillDropwdowns();
				setOtherCurrTable();
			}
			var chkPermission = strIsUserDraftOnly();
			if (chkPermission.toLowerCase() == "yes")
				setSendPermission("Draft");
			else
				setSendPermission("Send");
		}

		if (currentViewName == "RES_VIEW") {
			$scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "";
			$scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = "";
			$scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = "";

			$scope.loadConfig(function () {
				var noticeData = $scope.data.config['Notices'] || {};
				$scope.dropdownObj.noticeList = commonApi.getItemSelectionList({
					arrayObject: noticeData,
					groupNameKey: "",
					modelKey: "Reason_For_Notice",
					displayKey: "Reason_For_Notice"
				});
				delete $scope.data.config;
			});
			
			if (dSDraftRESMsg == "NO") {
				
				var strResCount = $scope.resMsgCustomFields.DSI_Res_Counter,
					insertPoint = $scope.resMsgCustomFields.RESPONSES.All_Responses,
					originatorId = $scope.oriMsgCustomFields.Originator_Id,
					strRole = $scope.oriMsgCustomFields.Filter_Role;

				if (originatorId != $scope.currentUserid) {
					$scope.oriMsgCustomFields.Response_Required_By = "";
					$scope.oriMsgCustomFields.Cancel_Variation = "";
					$scope.oriMsgCustomFields.Response_Required = "";
				}
				if (insertPoint.length) {
					for (var i = 0; i < insertPoint.length; i++) {
						if (insertPoint[i].Response_Remarks) {
							insertPoint[i].DSI_ResFlag = "Old";
							if (strRole == 'Contractor') {
								insertPoint[i].Latest_Response_Flag = '';
							}
						}
					}
				}
				$scope.getServerTime(function (serverDate) {
					strResCount++;
					var resNodes = angular.copy(STATIC_OBJ_DATA.All_Responses);
					resNodes.DSI_ResID = strResCount;
					resNodes.Response_Creator = dsWorkingUser;
					resNodes.Response_Date = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
					insertPoint.push(resNodes);
					hideClause();
					setHeader();
					$scope.resMsgCustomFields.DSI_Res_Counter = strResCount;
				});
			} else {
				hideClause();
				setHeader();
				var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
					return val.DSI_ResFlag != "Old";
				});
                if (responseObj.length) {
                    responseObj[0].Response_Creator = dsWorkingUser;
                    $scope.getServerTime(function (serverDate) {
                        responseObj[0].Response_Date = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
                    });
				}
			}
		}

		if (currentViewName == "ORI_PRINT_VIEW"  || currentViewName == "RES_PRINT_VIEW") {
			var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
			var urlObj = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_CONTRACT, function (val) {
				return val.Value.split('|')[0].trim() == strConAppid.trim();
			});
			if (urlObj.length) {
				$scope.oriMsgCustomFields.Contract_URL = urlObj[0].URL;
			}

			var ewnUrlObj = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_EWN_LINK');
			if(ewnUrlObj.length){
				$scope.oriMsgCustomFields.EWN_URL = ewnUrlObj[0].URL;
			}

			if(DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG.length){
				$scope.oriMsgCustomFields.valEng_URL = DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG[0].URL3;
			}
			angular.element('.export-btn').hide();
		}

		$scope.onContractchange = function (conVal) {
			if (conVal) {
				$scope.isDataLoaded = false;
				var tempConAppCode = conVal.split('|')[0].trim();
				var tempCon = conVal.split('|');
				$scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
				$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
				$scope.oriMsgCustomFields.Client_Logo = tempCon[5].trim();
				$scope.oriMsgCustomFields.Contractor_Logo = tempCon[4].trim();
				$scope.oriMsgCustomFields.Engineer_Logo = tempCon[6].trim();
				$scope.oriMsgCustomFields.Contract_Code = tempCon[2].trim();
				var spParam = {
					dataSourceArray: [{
						"fieldName": "DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_EWN",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_COMM_Details",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_COMM_TYPES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_KEY_CONTRACT_DATES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_SETUP_SECTIONS",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG",
						"fieldValue": tempConAppCode
					}],
					successCallback: contractChangeCallback
				};

				$scope.getCallbackSPdata(spParam);
			}
		}

		function contractChangeCallback(responseList) {

			if (responseList["DS_ASI_STD_FIDIC_SETUP_SECTIONS"]) {
				DS_ASI_STD_FIDIC_SETUP_SECTIONS = responseList["DS_ASI_STD_FIDIC_SETUP_SECTIONS"];
			}
			
			if (responseList["DS_ASI_STD_FIDIC_NEC_ALL_EWN"]) {
				DS_ASI_STD_FIDIC_NEC_ALL_EWN = responseList["DS_ASI_STD_FIDIC_NEC_ALL_EWN"];
			}
			if (responseList["DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS"]) {
				DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS = responseList["DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS"];
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_COMM_TYPES"]) {
				DS_ASI_STD_FIDIC_NEC_COMM_TYPES = responseList["DS_ASI_STD_FIDIC_NEC_COMM_TYPES"];
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES"]) {
				DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES = responseList["DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES"];
			}

			if (responseList["DS_ASI_GET_CURRENCY_FROM_CONTRACT"]) {
				DS_ASI_GET_CURRENCY_FROM_CONTRACT = responseList["DS_ASI_GET_CURRENCY_FROM_CONTRACT"];
				$scope.oriMsgCustomFields.Currency = DS_ASI_GET_CURRENCY_FROM_CONTRACT[0].Value2.trim();
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG"]) {
				DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG = responseList["DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG"];
			}
			var keyDatesObj = responseList["DS_ASI_STD_FIDIC_NEC_KEY_CONTRACT_DATES"];
			if (keyDatesObj.length) {
				var appCode = $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
				var keyObj = commonApi._.filter(keyDatesObj, function (val) {
					return val.Value5 == appCode;
				});
				if (keyObj.length) {
					var days = keyObj[0].Value4.trim();
					$scope.oriMsgCustomFields.Reply_Due_Days = days;
					$scope.oriMsgCustomFields.Reply_Due_Date = commonApi.calculateDistDateFromDays({
						baseDate: $scope.todayDateDbFormat,
						days: days
					});
				}
			}
			fillDropwdowns();
			setOtherCurrTable();

			var chkPermission = strIsUserDraftOnly();
			if (chkPermission.toLowerCase() == "yes")
				setSendPermission("Draft");
			else
				setSendPermission("Send");

			$scope.isDataLoaded = true;
		}


		function setWorkflow() {

			$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var tempList = [];
			var allUsers = $scope.oriMsgFields.DS_PROJUSERS_ALL_ROLES;
			if (allUsers) {
				var distDate = $scope.oriMsgCustomFields.Reply_Due_Date;

				tempList.push({
					strUser: allUsers.split('|')[2].trim(),
					strAction: FIDIC_CONSTANT.RESPOND_ACTION,
					strDate: distDate
				});

				var infoUsers = $scope.oriMsgCustomFields.Dist_Group_Users;
				if (infoUsers.length) {
					for (var j = 0; j < infoUsers.length; j++) {
						tempList.push({
							strUser: infoUsers[j].split('|')[2].trim(),
							strAction: FIDIC_CONSTANT.INFO_ACTION,
							strDate: ""
						});
					}
				}
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
					DS_AUTODISTRIBUTE: 3
				});
			}
		}

		function fillDropwdowns() {

			$scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_SETUP_SECTIONS,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var objdata = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return (val.Value.split('|')[1].trim() == FIDIC_CONSTANT.contractor) && val.Value.split('|')[2].split('#')[0].trim() != $scope.currentUserid;
			});
			$scope.dropdownObj.engineerlist = commonApi.getItemSelectionList({
				arrayObject: objdata,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			$scope.dropdownObj.forInfoUserslist = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			$scope.dropdownObj.communicationList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_COMM_TYPES,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			$scope.dropdownObj.ewnList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_EWN,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var currUserObj = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return val.Value.split('|')[2].split('#')[0].trim() == $scope.currentUserid;
			});

			if (currUserObj.length) {
				$scope.oriMsgCustomFields.Filter_Role = currUserObj[0].Value.split('|')[1].trim();
			}

			$scope.dropdownObj.clausesList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES,
				groupNameKey: "",
				modelKey: "Value3",
				displayKey: "Value5"
			});

			var tempSectionArray = commonApi._.uniq(DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY, 'Value3');
			$scope.dropdownObj.objSectionCode = commonApi.getItemSelectionList({
				arrayObject: tempSectionArray,
				groupNameKey: "",
				modelKey: "Value3",
				displayKey: "Value18"
			});

			$scope.dropdownObj.objKeydate = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_KEY_DATES_SUMMARY,
				groupNameKey: "",
				modelKey: "Value2",
				displayKey: "Name"
			});
			DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG, function (val) {
				return  val.Value2.indexOf('CVAR') > -1;
			});
			$scope.dropdownObj.valueEngList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_VALUE_ENG,
				groupNameKey: "",
				modelKey: "Value2",
				displayKey: "Value5"
			});

		}

		$scope.onEwnChange = function (strVal) {
			if (strVal) {
				var arrSplit = strVal.split('|');
				$scope.oriMsgCustomFields.Ewn_AppID = arrSplit[4].trim();
				$scope.oriMsgCustomFields.ewnId = arrSplit[5].trim();
			}
		}

		function setEwnStatus() {
			var ewnAppId = $scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1;
			if (ewnAppId) {
				var statusIds = $scope.getFormStatus({
					spName: "DS_ALL_ACTIVE_WS_STATUS",
					status: FIDIC_CONSTANT.referred
				});
				if (statusIds) {
					$scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = ewnAppId;
					$scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = statusIds.split('#')[0].trim();
				}
			}
		}
		function strIsUserDraftOnly() {
            if (DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == $scope.currentUserid)
                            return "Yes";
                    }
                }
            }
            return "No";
		}
		
		function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.Asite_System_Data_Read_Only._5_Form_Data.DS_SEND_MSG = strMsg;
		}

		function checkUserCanRespond()
		{
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft"),
            strRespond = filterdata("Respond"),
            strForAction = filterdata("For Action");

            var objData = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
                return val.Value.split('|')[2].split('#')[0].trim() == $scope.currentUserid;
            });

            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1"
            }
            if (!strReviewDraft && !strRespond && !strForAction && currentViewName == "RES_VIEW") {
                strCanReplay = "";
                strCanReplayStatus = "2"
            }
            
            if(!strCanReplay){
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
		}

		function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + $scope.currentUserid + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
		}
		
		$scope.resetEwnRow = function () {
			$scope.oriMsgCustomFields.DS_ASI_STD_FIDIC_NEC_ALL_EWN = "";
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = "";
			$scope.oriMsgCustomFields.ewnId = ""
			$scope.dropdownObj.ewnList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_EWN,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			})
		}
		
		function setDistribution() {

			var originatorId = $scope.oriMsgCustomFields.Originator_Id;
			var distDate = $scope.oriMsgCustomFields.Response_Required_By;
			var tempList = [];
			$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if (originatorId == $scope.currentUserid) {
				var cancelVar = $scope.oriMsgCustomFields.Cancel_Variation,
					resReq = $scope.oriMsgCustomFields.Response_Required;
				var commType = $scope.oriMsgCustomFields.Res_Comm_Type;

				if ((cancelVar == 'cancellation of instruction' && commType == 'Notice of response') || (resReq != 'Yes' && commType == 'Submission of proposal')) {
					tempList.push({
						strUser: $scope.oriMsgFields.DS_PROJUSERS_ALL_ROLES.split('|')[2].trim(),
						strAction: FIDIC_CONSTANT.INFO_ACTION,
						strDate: distDate
					});
				} else {
					tempList.push({
						strUser: $scope.oriMsgFields.DS_PROJUSERS_ALL_ROLES.split('|')[2].trim(),
						strAction: FIDIC_CONSTANT.RESPOND_ACTION,
						strDate: distDate
					});
				}
			} else {
				tempList.push({
					strUser: originatorId,
					strAction: FIDIC_CONSTANT.RESPOND_ACTION,
					strDate: commonApi.calculateDistDateFromDays({
						baseDate: $scope.todayDateDbFormat,
						days: $scope.oriMsgCustomFields.Reply_Due_Days
					})
				});
			}
			if (tempList.length) {
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
					DS_AUTODISTRIBUTE: 13
				});
			}
		}


		$scope.setSectionName = function (currObj, strVal, strOpenfrom) {

			var strSecname = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY, function (val) {
				return val.Value3 == strVal;
			});
			if (strSecname.length) {
				currObj.Section_Name = strSecname[0].Value4.trim();
			}
			if (!strOpenfrom) {
				currObj.Act_Sel = "";
			}
			$scope.dropdownObj.objActivity = commonApi.getItemSelectionList({
				arrayObject: strSecname,
				groupNameKey: "",
				modelKey: "Value14",
				displayKey: "Value14"
			});
		}

		$scope.setActivitydata = function (currObj, strVal) {
			currObj.Activity_Name = strVal.split('|')[1].trim();
			currObj.Activity_Code = strVal.split('|')[0].trim();
		}

		$scope.setKeydatedata = function (currObj, strVal) {

			var objKeydata = commonApi._.filter(DS_ASI_STD_FIDIC_KEY_DATES_SUMMARY, function (val) {
				return val.Value2 == strVal;
			});
			if (objKeydata.length) {
				currObj.Key_Date_Id = strVal;
				currObj.Date_Description = objKeydata[0].Value3;
				currObj.Date_Type = objKeydata[0].Value7;
				currObj.Date_Ref = objKeydata[0].Value8;
			} else {
				currObj.Date_Description = "";
			}
		}

		function validateNumber(modaldata) {
			var strVal = modaldata.KD_Current_Additions;
			if (strVal && isNaN(strVal)) {
				alert("Please Enter only numbers");
				strVal = "";
				return false;
			}
			return true;
		}

		function setFirstKeyDate() {
			var strFirstkey = "";
			var keysObj = commonApi._.filter($scope.keyMilestones['Impacted_Key_Dates'], function (val) {
				return val.Key_Date_Id.trim() == '1';
			});
			if (keysObj.length) {
				strFirstkey = keysObj[0].KD_Current_Additions;
			}
			$scope.resMsgCustomFields.Total_Programme_Change = strFirstkey;
		}

		function setFormContent1() {
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = $scope.oriMsgCustomFields.Ewn_AppID + '|' + $scope.oriMsgCustomFields.valEngId;
		}

		function setFormContent2() {
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT2 = $scope.resMsgCustomFields.Total_Cost_Change;
		}

		function setFormContent3() {
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT3 = $scope.resMsgCustomFields.Total_Programme_Change;
		}

		$scope.calculateCost = function (currObj) {
            var Qty = currObj.Quantity || 0,
                exchangeRate = 0;
            if (currObj && currObj.Currency_Data_Table.Currency_Table.length) {
                var currTbl = currObj.Currency_Data_Table.Currency_Table,
                    CurrVal = 0, Total = 0;
                for (var i = 0; i < currTbl.length; i++) {
                    CurrVal = currTbl[i].CurrValue || 0;
                    exchangeRate = currTbl[i].CurrExRate || 0;
                    currTbl[i].CurrTotal = (parseFloat(CurrVal) * parseFloat(Qty)).toFixed(2);
                    Total = i == 0 ? parseFloat(CurrVal) * parseFloat(Qty) : parseFloat(Total) + parseFloat(CurrVal) * parseFloat(Qty) * parseFloat(exchangeRate);
                }
            }
            currObj.Act_Current_Additions = Total.toFixed(2);
        }
	
		$scope.openModal = function (viewId, rowData) {
			// rowData used when user edit row , rowData come from table.util component as param
			modelRowIndex = -1;
			if (angular.element('.m-wrap .m-content')) {
                angular.element('.m-wrap .m-content')[0].style = "width:650px";
            }
			switch (viewId) {
				case FIDIC_CONSTANT.priceBreakDown:
					if (angular.element('.m-wrap .m-content')) {
                        angular.element('.m-wrap .m-content')[0].style = "width:" + $scope.containerTableWidth;
                    }
					if (rowData) {
						modelRowIndex = rowData.index;
						$scope.modalData = angular.copy(rowData.row);
						$scope.setSectionName($scope.modalData, $scope.modalData['Section_Code'], "edit");
					} else {
						$scope.modalData = angular.copy(STATIC_OBJ_DATA.Sections);
					}
					break;
				case FIDIC_CONSTANT.keyContractDates:
					if (rowData) {
						modelRowIndex = rowData.index;
						$scope.modalData = angular.copy(rowData.row);
					} else {
						$scope.modalData = angular.copy(STATIC_OBJ_DATA.Impacted_Key_Dates);
					}
					break;
			}

			showModal(viewId)
		}

		ctrl.model = {
			modelId: "",
			update: updateRecord,
			hideModal: hideModal,
			showloader: false,
			readOnly: false,
			scrollTop: 0
		};

		function showModal(id) {

            var body = document.body;
            var docElement = document.documentElement;
            ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            if(currentViewName == "RES_VIEW"){
				$window.parent.postMessage("scrollToTop", '*');
            }
            // show modal
            ctrl.model.modelId = id;

            $timeout(function(){
                var focusElem = $element.find('[autofocus]');
                focusElem[0] && focusElem[0].focus();
            })
        };

		function hideModal() {
            ctrl.model.modelId = '';

            $timeout(function () {
                var scrollObj = document.body
                if (scrollObj.scrollTop == 0) {
                    scrollObj = document.documentElement;
                }
                if(currentViewName == "RES_VIEW" && scrollObj.scrollTop == 0){
                    $window.parent.postMessage("scrollTo:"+ ctrl.model.scrollTop, '*');
                }else{
					scrollObj.scrollTop = ctrl.model.scrollTop;
				}
            }, 200)
        }

		function editSectionModal(rowData) {
			$scope.openModal(FIDIC_CONSTANT.priceBreakDown, rowData);
		}

		function editKeyModal(rowData) {
			$scope.openModal(FIDIC_CONSTANT.keyContractDates, rowData);
		}
		function contractTotalOfPriceBreakDown() {
			$timeout(function () {
				$scope.calcFieldTotal({
					repData: $scope.sectionGroup['Impacted_Activities'],
					calcKey: 'Act_Current_Additions',
					parObject: $scope.resMsgCustomFields,
					totalKey: 'Total_Cost_Change'
				});
			}, 200)
		}

		function updateRecord() {
			var rowIndex = modelRowIndex,
				newNode = angular.copy($scope.modalData);

			if (!validateModalForm(ctrl.model.modelId)) {
				$window.alert(FIDIC_CONSTANT.mandatoryValMsg);
				return;
			}
			var backUpObject = "",
				index = "",
				isDuplicate = "";
			switch (ctrl.model.modelId) {
				case FIDIC_CONSTANT.priceBreakDown:
					updateChildRef(newNode);
					backUpObject = angular.copy($scope.sectionGroup['Impacted_Activities']);
					if (rowIndex > -1) {
						$scope.sectionGroup['Impacted_Activities'][rowIndex] = newNode;
					} else {
						$scope.sectionGroup['Impacted_Activities'].push(newNode);
					}
					if (rowIndex > -1)
						index = rowIndex;
					else
						index = $scope.sectionGroup.Impacted_Activities.length - 1;
					isDuplicate = $scope.checkDuplicateValue({
						key: 'Act_Sel',
						model: $scope.modalData,
						index: index,
						repetObj: $scope.resMsgCustomFields.Cost_Changes.Impacted_Activities,
						msg: 'Acivity'
					});
					if (!isDuplicate) {
						$scope.sectionGroup['Impacted_Activities'] = angular.copy(backUpObject);
						$scope.setSectionName($scope.modalData, $scope.modalData['Section_Code']);
						return;
					}
					contractTotalOfPriceBreakDown();
					break;
				case FIDIC_CONSTANT.keyContractDates:
					if (!validateNumber($scope.modalData)) {
						return;
					}
					backUpObject = angular.copy($scope.keyMilestones['Impacted_Key_Dates']);
					if (rowIndex > -1) {
						$scope.keyMilestones['Impacted_Key_Dates'][rowIndex] = newNode;
					} else {
						$scope.keyMilestones['Impacted_Key_Dates'].push(newNode);
					}

					if (rowIndex > -1)
						index = rowIndex;
					else
						index = $scope.keyMilestones.Impacted_Key_Dates.length - 1;
					isDuplicate = $scope.checkDuplicateValue({
						key: 'KD_Sel',
						model: $scope.modalData,
						index: index,
						repetObj: $scope.resMsgCustomFields.Prog_Changes.Impacted_Key_Dates,
						msg: 'Key Date'
					});
					if (!isDuplicate) {
						$scope.keyMilestones['Impacted_Key_Dates'] = angular.copy(backUpObject);
						$scope.dropdownObj.objKeydate = commonApi.getItemSelectionList({
							arrayObject: DS_ASI_STD_FIDIC_KEY_DATES_SUMMARY,
							groupNameKey: "",
							modelKey: "Value2",
							displayKey: "Name"
						})
						return;
					}
					setFirstKeyDate();
					break;
			}
			$timeout(function () {
				hideModal();
			})

		}

		function validateModalForm(modalId) {
			var mandatorySingleFieldArray = [],
				mandatoryRepeatFieldArray = [],
				validaFlag = true,
				repeatindData = null;
			switch (modalId) {
				case FIDIC_CONSTANT.priceBreakDown:
					mandatorySingleFieldArray = ['Section_Code', 'Act_Sel', 'Act_Current_Additions','Unit'];
					mandatoryRepeatFieldArray = [];
					repeatindData = $scope.modalData['Currency_Data_Table']['Currency_Table'];
					break;
				case FIDIC_CONSTANT.keyContractDates:
					mandatorySingleFieldArray = ['KD_Sel', 'KD_Current_Additions'];
					break;
			}

			validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

			if (repeatindData && validaFlag) {
				for (var k = 0; k < repeatindData.length; k++) {
					if (validaFlag) {
						validaFlag = checkFieldValueInObject(repeatindData[k], mandatoryRepeatFieldArray);
					} else {
						break;
					}
				}
			}

			function checkFieldValueInObject(objectData, keyArray) {
				var strElem = "";
				for (var index = 0; index < keyArray.length; index++) {
					var element = keyArray[index];
					strElem = objectData[element];
					if (!strElem) {
						return false;
					}
				}
				return true;
			}
			return validaFlag;
		}

		$scope.onCommunicationTypeChange = function (currObj) {
			currObj.Reason_For_Notice = "";
			$scope.oriMsgCustomFields.Res_Comm_Type = currObj.Response_Communication_Type;
		}

		$scope.hideClause = hideClause;
		function hideClause() {
			var cancelVar = "",
				resConmmType = $scope.oriMsgCustomFields.Res_Comm_Type;
			var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
				return val.DSI_ResFlag != "Old";
			});
			if (responseObj.length) {
				cancelVar = $scope.oriMsgCustomFields.Cancel_Variation = responseObj[0].Response_Cancel_Variation;
			}
			$scope.ishideClauses = true;
			$scope.isResponseDate = true;
			if (($scope.DS_RES_COUNT > 0 && resConmmType == 'Submission of proposal')) {
				$scope.ishideClauses = false;
			}

			if (($scope.isUserOriginator && (resConmmType == 'Notice that Contractor cannot comply' || resConmmType == 'Notice of response') && (cancelVar == 'cancellation of instruction' || !cancelVar)) || ($scope.oriMsgCustomFields.Response_Required != 'Yes' && resConmmType == 'Submission of proposal') || $scope.DS_RES_COUNT == '0' ||  !$scope.isUserOriginator) {
				$scope.isResponseDate = false;
			}
		}

		$scope.setHeader = setHeader;
		function setHeader() {
			var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
				return val.DSI_ResFlag != "Old";
			});
			if (responseObj.length) {
				var strRole = $scope.oriMsgCustomFields.Filter_Role,
					strHeader = "",
					resConmmType = $scope.oriMsgCustomFields.Res_Comm_Type;
				if (strRole == 'Contractor') {
					strHeader = resConmmType == "Notice that Contractor cannot comply" ? "Contractor's Notice of Contractor cannot comply" : "Contractor's submission of proposal";
				} else if (strRole == 'Engineer') {
					strHeader = resConmmType == "Notice that Contractor cannot comply" ? "Engineer's Notice of response" : "Engineer's response to Contractor's submission";
				}
				responseObj[0].Header_Label = strHeader;
				responseObj[0].Response_User_Role = strRole;
				responseObj[0].Latest_Response_Flag = '1';
				if(resConmmType == 'Notice that Contractor cannot comply' && $scope.isUserOriginator){
					$scope.oriMsgCustomFields.Res_Comm_Type = responseObj[0].Response_Communication_Type = "Notice of response";
				}
			}
		}

		$scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
			$timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    bodypartObj.scrollTop = bodypartObj.scrollHeight;
                }
            });
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 100);
		};
		
		function updateChildRef(currObj) {
			var childObj = currObj.Currency_Data_Table.Currency_Table;
			if (childObj.length) {
				for (var i = 0; i < childObj.length; i++) {
					childObj[i].Ref_Section_Code = currObj.Section_Code;
					childObj[i].Ref_Activity_Code = currObj.Activity_Code;
				}
			}
		}

		$scope.setClauses = function () {
			$scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES = [];
			var selectedClauses = $scope.oriMsgCustomFields.clauses,
				insertPoint = $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES,
				structClauses = "";

			var tempClausesobj = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES, function (itm) {
				for (var i = 0; i < selectedClauses.length; i++) {
					if (itm.Value3 == selectedClauses[i]) {
						return true;
					}
				}
			});

			if (tempClausesobj.length) {
				for (var i = 0; i < tempClausesobj.length; i++) {
					structClauses = angular.copy(STATIC_OBJ_DATA.CEN_EVENT_CLAUSES);
					structClauses.ClauseNo = tempClausesobj[i].Value3;
					structClauses.Clause_Text = tempClausesobj[i].Value4;
					insertPoint.push(structClauses);
				}
			}
		}

		$scope.setClausesResponse = function (currobj) {
			currobj.CEN_EVENT_ALL_RES_CLAUSES.CEN_EVENT_RES_CLAUSES = [];
			var selectedClauses = currobj.ClausesListRes,
				insertPoint = currobj.CEN_EVENT_ALL_RES_CLAUSES.CEN_EVENT_RES_CLAUSES,
				structClauses = "";

			var tempClausesobj = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES, function (itm) {
				for (var i = 0; i < selectedClauses.length; i++) {
					if (itm.Value3 == selectedClauses[i]) {
						return true;
					}
				}
			});

			if (tempClausesobj.length) {
				for (var i = 0; i < tempClausesobj.length; i++) {
					structClauses = angular.copy(STATIC_OBJ_DATA.CEN_EVENT_RES_CLAUSES);
					structClauses.ClauseNoRes = tempClausesobj[i].Value3;
					structClauses.Clause_TextRes = tempClausesobj[i].Value4;
					insertPoint.push(structClauses);
				}
			}
		}

		$scope.restrictCharOnlyNumber = function (event, isfloat) {
            $scope.restrictChar(event);
            var validKeys = [];
            if (isfloat == true)
                validKeys = [46, 8, 9, 27, 13, 110, 190];
            else
                validKeys = [46, 8, 9, 27, 13, 109, 189];
            // Allow: backspace, delete, tab, escape, enter and .
            if (validKeys.indexOf(event.keyCode) !== -1 ||
                // Allow: Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X, Command+A
                ((event.keyCode == 65 || event.keyCode == 86 || event.keyCode == 88 || event.keyCode == 67) && (event.ctrlKey === true || event.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (event.keyCode >= 35 && event.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if (((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) || (event.shiftKey && event.keyCode > 57)) {
                event.preventDefault();
            }
        }

        // this function checks weather input value is number otherwise blank it
        $scope.checkValueNumber = function (currObj, inputValue, key) {
            if (inputValue && isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                currObj[key] = "";
            }
        }

		function setOtherCurrTable() {
			var other_Curr_Obj = [],
			other_Curr = "",
			other_Curr_List = [],
			other_ExRate_List = [],
			Currency_table,
			insertpoint = $scope.oriMsgCustomFields.Other_Currency_Data.Currency_table;
			if (DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY.length) {
				other_Curr = DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY[0].Value34;
				other_Curr_List = other_Curr.split('|');

				if (other_Curr_List.length && insertpoint.length != other_Curr_List.length) {
					other_ExRate_List = DS_ASI_STD_FIDIC_NEC_CONTRACT_ACTIVITY_SUMMARY[0].Value35.split('|');
					for (var i = 0; i < other_Curr_List.length; i++) {
						if (insertpoint.length < other_Curr_List.length) {
							Currency_table = angular.copy(STATIC_OBJ_DATA.Currency_table);
							Currency_table.other_Currency = other_Curr_List[i];
							Currency_table.other_Cur_Exc_Rate = other_ExRate_List[i];
							insertpoint.push(Currency_table);
						}
						other_Curr_Obj.push({
							"Curr": other_Curr_List[i],
							"CurrValue": 0,
							"CurrExRate": other_ExRate_List[i],
							"CurrTotal": 0
						});
					}
				} else {
					if (insertpoint.length) {
						for (var i = 0; i < insertpoint.length; i++) {
							other_Curr_Obj.push({
								"Curr": insertpoint[i].other_Currency,
								"CurrValue": 0,
								"CurrExRate": insertpoint[i].other_Cur_Exc_Rate,
								"CurrTotal": 0
							});
						}
					}
				}
			}

			if (other_Curr_Obj.length) {
                $scope.oriMsgCustomFields.Column_Count = $scope.column_count = parseInt(other_Curr_Obj.length) * 2;
                $scope.currencyCount = other_Curr_Obj.length;
				STATIC_OBJ_DATA.Sections.Currency_Data_Table.Currency_Table = angular.copy(other_Curr_Obj);
            }
            setContainerWidth();
        }
        function setContainerWidth() {
            var int_constWidth = 73,
                initWidth = 3,
                countColumn = $scope.currencyCount;
            var addDifferentWidth = (countColumn * initWidth);
            $scope.containerTableWidth = (addDifferentWidth + int_constWidth) + "%";
		}
		
		$scope.onExchangeRateChange = function (currObj) {
			var sectionObj = $scope.resMsgCustomFields.Cost_Changes.Impacted_Activities,
				staticObj =  STATIC_OBJ_DATA.Sections.Currency_Data_Table.Currency_Table,
                currencyObj;
            if (sectionObj.length) {
                for (var i = 0; i < sectionObj.length; i++) {
                    if (sectionObj[i].Currency_Data_Table.Currency_Table.length) {
                        currencyObj = commonApi._.filter(sectionObj[i].Currency_Data_Table.Currency_Table, function (val) {
                            return val.Curr == currObj.other_Currency;
                        });
                        if (currencyObj.length) {
                            currencyObj[0].CurrExRate = currObj.other_Cur_Exc_Rate;
                            $scope.calculateCost(sectionObj[i]);
                        }
                    }
                }
                contractTotalOfPriceBreakDown();
			}
			
			if (staticObj.length) {
                currencyObj = commonApi._.filter(staticObj, function (val) {
                    return val.Curr == currObj.other_Currency;
                });
                if (currencyObj.length) {
                    currencyObj[0].CurrExRate = currObj.other_Cur_Exc_Rate;
                }
            }
        }
		
		$scope.update();
		$scope.isCallForDraft = false;
		function formSubmitCallBack() {

			if (currentViewName == "ORI_VIEW") {


				if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not permitted to edit this form, please cancel this process and use the Distribute option to forward to additional recipients.");
					return true;
				}

				if (!$scope.oriMsgCustomFields.Can_Reply) {
					alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
					return true;
				}

				if($scope.oriMsgCustomFields.Reply_Due_Date < $scope.todayDateDbFormat){
					alert("Response date cannot be past Date");
					return true;
				}

				setFormContent1();
				setEwnStatus()
				setWorkflow();
			}

			if (currentViewName == "RES_VIEW") {

				if ($scope.oriMsgCustomFields.Can_Reply_Status == '2') {
					alert("You currently do not have 'Respond' action and therefore you can not reply on the form.");
					return true;
				}

				if ($scope.oriMsgCustomFields.Can_Reply_Status == '1') {
					alert("You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.");
					return true;
				}
				var cancelVar = $scope.oriMsgCustomFields.Cancel_Variation;
				if ((cancelVar && cancelVar != 'cancellation of instruction' && $scope.isUserOriginator || $scope.oriMsgCustomFields.Response_Required == 'Yes') && $scope.oriMsgCustomFields.Response_Required_By < $scope.todayDateDbFormat) {
					alert("Response Required by Date cannot be less then today date");
					return true;
				}
				
				setFormContent2();
				setFormContent3();
				setDistribution();
			}
			return false;
		};

		$window.oriformSubmitCallBack = function () {
			return formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			setFormContent1();
		}
	}

	return FormController;
});

// Final Call back fuction before common function get's controll.

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}