define(['angular', './base', '../components/folder.selection', '../components/inlineattachment', '../components/item.selection', '../components/signature'], function (angular, baseController) {
	'use strict';
	/**
	 * FieldType used in Apps
	 * Input: 1
	 * Dropdown: 2
	 * Checkbox: 3
	 * Textarea : 4
	 * Radiobutton: 5
	 * readOnly: 6
	 * */

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, myConfig, $document, Notification, lang, attachmentApi) {
		var ctrl = this;
		var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
		if (projectId == "null")
			projectId = $window.currProjId;
		var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var editDraft = document.getElementById('editDraft') ? document.getElementById('editDraft').value : null;
		var currentViewName = $window.currentViewName;
		var userRef = '---';
		var sendObj = {};
		var isDraft = false;
		var dcId;
		var actionDataByFormId = {};
		var weightageId = 0;
        $scope.otherTextBox=false;
		if ($scope.msgThread) {
			isDraft = $scope.msgThread.isDraft;
		}else{
			isDraft = editDraft == "true";
		}

		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		var STATIC_OBJ_DATA = {
			projectExperience: {
				"projectName": "",
				"projectValue": "",
				"location": "",
				"year": "",
				"client": "",
				"mainContractor": "",
				"mainContractorReference": "",
				"summaryOfDesign": "",
				"projectDuration": "",
				"anyDocument": ""
			},
			riskRegisterDetails: {
				"significantRisk": "",
				"proposedControl": ""
			},
			personnelItem: {
				"name": "",
				"title": "",
				"telephoneNo": ""
			},
			qualificationItem: {
				"name": "",
				"position": "",
				"qualification": ""
			},
			qualificationAttachmentItem: {
				"name": "",
				"qualificationAttachment": ""
			},
			riskAssessmentItem : {
				"risk": ""
			},
			riskAssessmentItem : {
				"cooperatingWork": ""
			},
			jobDetails: {
				"scheme": "",
				"jobTitle": "",
				"jobName": ""
			},
			supplierManufactorer: {
				"contractorElement": "",
				"supplierName": ""
			},
			enforcementAction: {
				"actDate": "",
				"noticeServed": "",
				"comment": ""
			},
			afrPerYear: {
				"afrYear": "",
				"afrValue": ""
			}
		}
		$scope.productList = [];
		$scope.currentTab = 1;
		$scope.canEvalution = true;
		$scope.uopAttachments = [];
		$scope.isForSaveDraft = false;
		//$scope.data.products.tradeDetails='';
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});
		
		/**
		 * To get WeighategFormDetails based on buyerOrgId and WeightageId
		 */
		$scope.getWeitageDetails = function () {
			if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_VIEW_PRINT") {
				$scope.getProductList();
				var iframeUrl = decodeURIComponent($window.location.href);
				var dataString = iframeUrl && iframeUrl.split('?');
				var canEvalution = $scope.getValueOfOnLoadData('DS_IS_USER_ACTION_INCOMPLETE');
				if (canEvalution.length && canEvalution[0].Value == "Y") {
					$scope.canEvalution = true;
				} else {
					$scope.canEvalution = false;
				}
				console.log($scope.data)
				var dataArray = dataString[1] && dataString[1].split('&');
				if (currentViewName == "ORI_VIEW" && dataArray && !isDraft) {
					$scope.data.buyerOrgId = 0;
					for (var i = 0; i < dataArray.length; i++) {
						if (dataArray[i].indexOf('mailrecipient') > -1) {
							$scope.data.recipient = dataArray[i].split('=')[1];
						}
						if (dataArray[i].indexOf('formSelectRadiobutton') > -1) {
							var tempData = dataArray[i].split('=')[1];
							dcId = tempData.split('_')[0];
						}
						if (dataArray[i].indexOf('buyerOrgId') > -1) {
							var buyerOrgId = dataArray[i].split('=')[1];
							$scope.data.buyerOrgId = buyerOrgId.split('$$')[0];
							commonApi.ajax({
								url: top.marketPlaceServiceURL + "/marketplace/uop/getUOPByOrgId/" + $scope.data.buyerOrgId,
								method: 'GET',
								withCredentials: true,
								data: {},
								headers: {
									'Content-Type': 'application/json',
									'ApiKey': top.marketPlaceApiKey
								},
							}).then(function (response) {
								if (response.status === 200) {
									$scope.data.buyerOrgName = response.data.companyName;
									$scope.update();
									resizeTextarea()
								}
							}, function (error) {
								$window.alert("Error \n\n Probelm while fetching UOP by Org ID");
								console.log(error)
								$scope.update();
								resizeTextarea()
							});
						}
						if (dataArray[i].indexOf('weightage') > -1) {
							weightageId = dataArray[i].split('=')[1];
						}

						if (dataArray[i].indexOf('userRef') > -1) {
							userRef = dataArray[i].split('=')[1];
						}
					}

					$scope.data.sectionHideFlag = {};
					if (currentViewName == "ORI_VIEW") {
						getUOPData();
						
					}

					commonApi.ajax({
						url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages?boid=" + $scope.data.buyerOrgId + "&weightageId=" + weightageId,
						method: 'GET',
						withCredentials: true,
						data: {},
						headers: {
							'Content-Type': 'application/json',
							'ApiKey': top.marketPlaceApiKey
						},
					}).then(function (response) {
						if (response.status === 200) {
							$scope.WeitageDetails = response.data;
							setViewFlag();
					$scope.getProductList();
							$scope.update();
							resizeTextarea();
						}
					}, function (error) {
						$window.alert("Error \n\n Probelm while fetching weightage template");
						console.log(error)
						$scope.update();
						resizeTextarea();
					});
				} else {
					weightageId = $scope.data.referenceResourceId;
					setCollapseFlagForCustomSection();
					$scope.update();
					resizeTextarea();
				}
			} else if (currentViewName == "PREQUAL_RES_VIEW") {
				$scope.companyName = $scope.data.ORI_FORMTITLE;
				weightageId = $scope.data.weightageId;
				getPrequalWeightages();
				actionDataByFormId = $scope.getValueOfOnLoadData('DS_GET_FORM_DATA_BY_DB_FORM_ID');
			} else if (currentViewName == "PREQUAL_RES_VIEW_PRINT") {
				$scope.jsonWeightage = $scope.data;
				$scope.showCancelButton = angular.element("input[name =DS_FORMSTATUS]").val() != $scope.data.cancelStatus;
				//hide the cancel button for vendor after preqaulification
				if(angular.element("#DS_WORKINGUSERROLE").val() == "Vendor"){
					$scope.showCancelButton = false;
				}
				$scope.update();
				resizeTextarea();
			}
		}

		$scope.getProductList = function() {
			$scope.supplierArray=$scope.data.category_array.supplier;
			$scope.consultantArray=$scope.data.category_array.consultant;
			$scope.contractorArray=$scope.data.category_array.contractor;
		  if($scope.data['workRole'] == 'Suppliers'||$scope.data['workRole']=='') {
				$scope.productList =  commonApi.getItemSelectionList({
					arrayObject: $scope.supplierArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				});
				
			}
			if($scope.data['workRole'] == 'Consultant'){
				$scope.productList =  commonApi.getItemSelectionList({
					arrayObject: $scope.consultantArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				});
			} 
			if($scope.data['workRole'] == 'Contractor'){
				$scope.productList =  commonApi.getItemSelectionList({
					arrayObject: $scope.contractorArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				});
			}
		};

		ctrl.$onInit = function () {
			$scope.data = $scope.getFormData();
			$scope.mainSections = $scope.data.Sections;
			$scope.section = {
				appendix_A: {
					isHide: false
				},
				appendix_B: {
					isHide: false
				},
				appendix_C: {
					isHide: false
				},
				appendix_D: {
					isHide: false
				},
				appendix_E: {
					isHide: false
				},
				appendix_F: {
					isHide: false
				},
				appendix_G: {
					isHide: false
				},
				appendix_H: {
					isHide: false
				},
				appendix_I: {
					isHide: false
				},
				appendix_J: {
					isHide: false
				},
				appendix_K: {
					isHide: false
				},
				appendix_L: {
					isHide: false
				},
				appendix_M: {
					isHide: false
				},
				GeneralIns: {
					isHide: false
				},
				appendix: {
					isHide: false
				},
			}
			$scope.getWeitageDetails();
			$scope.productList.name = $scope.data.products.tradeDetails.split(",");
			
			if($scope.productList.name.indexOf("Other") != -1)
				$scope.otherTextBox = true;

			
		}

		/**
		 * Toggle section/div to hide/show based on user interaction
		 */
		$scope.toggleSetion = function (secObj) {
			secObj.isHide = !secObj.isHide;
		}

		$scope.openReplyView = function(){
			$window.scrollTo(0,0);
			$timeout(function(){
				$scope.reply('all','','','',$scope.data.vendorOrgId);
			},100);
		}

		/**
		 * Expand only one section/div as per user interaction
		 */
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ? $scope.currentTab = ' ' : $scope.currentTab = eID;
		};

		/**
		 * Calculate rating based on value/percentage added in Evalution stage
		 */
		$scope.calculateRating = function (section, subsection) {
			var totalWeightageOfSubsection = 0;
			for (var i = 0; i < section.subSections.length; i++) {
				if (section.subSections[i].isSubSectionActive && section.subSections[i].evalutionWeightageValue) {
					totalWeightageOfSubsection += (parseInt(section.subSections[i].subSectionPercentage) * parseInt(section.subSections[i].evalutionWeightageValue))
				}
			}
			var tempWeightage = (totalWeightageOfSubsection / 100);
			section.evalutionWeightageValue = tempWeightage;
			finalRatingCountCalculate();
			var ratingInput = document.getElementsByClassName("ratingInput");
			for (var i = 0; i < ratingInput.length; i++) {
				if (parseInt(ratingInput[i].value) >= 0 && parseInt(ratingInput[i].value) <= 100) {
					$scope.validateRating = false
				} else {
					$scope.validateRating = true;
					return
				}
			}
		}

		$scope.cancelInvitation = function () {
			var FormId = $("input[name ='formId']").val();
			var ProjectId = $("input[name ='projectId']").val();
			ProjectId = ProjectId.split("$$")[0];
			var formTypeId = $("input[name ='formTypeId']").val();
			if ($scope.showCancelButton) {
				$scope.clickCancel = true;
				commonApi.ajax({
					url: top.marketPlaceServiceURL + "/marketplace/prequal/resetPreqaulProcess",
					method: 'post',
					withCredentials: true,
					headers: {
						'ApiKey': top.marketPlaceApiKey,
						'Content-Type': 'application/json'
					},
					data: {
						formId: FormId,
						projectId: ProjectId,
						isApprove: true,
						formTypeId: formTypeId,
						prequalType: 1,
						evaluationStatus: $scope.data.cancelStatus || 'Cancelled',

					}
				}).then(function (response) {
					$scope.showCancelButton = false;
					if (response.data) {
						alert('Prequalification Cancelled Successfully')
						if (window.top && window.top.opener) {
							sendObj.refreshStatus = true;
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
							window.close();
							window.top.close();
							return;
						}
					}else {
						alert('The operation failed to excute')
					}
					window.location = top.marketPlaceServiceURL+"?origin=true";
				})
			}
		}

		/**
		 * Submit all prequal data to marketplace API rather than addodle apps
		 * because there are some value need to extract and store them to marketplace DB
		 */
		$scope.savePrequalWeightage = function (approve) {
			var FormError = $scope.$parent.myform.$error;
			if (FormError && !commonApi._.isEmpty(FormError)) {
				var validateMSG = lang.get("form-submit-validation-msg");
				Notification.error({ title: lang.get('alert'), message: validateMSG });
				return;
			}

			$scope.clickApprove = true;
			if (approve) {
				$scope.clickApprove = false;
				$scope.clickReject = true;
			} else {
				var getJsonData = $window.getJSONData && JSON.parse(window.getJSONData());
				var refData = "";
				if (getJsonData && getJsonData.myFields) {
					$scope.jsonWeightage.prequalType = getJsonData.myFields.prequalType;
					refData = $scope.jsonWeightage.referenceResourceId = getJsonData.myFields.referenceResourceId;

				}
				var jsonReadWrite = {
					"Asite_System_Data_Read_Only": {
						"_5_Form_Data": {
							"DS_FORMCONTENT1": refData
						}
					},
					"Asite_System_Data_Read_Write": {
						"Auto_Distribution_Msg_Actions": {
							"DS_AUTODISTRIBUTE_OTHERS_MSG_APP_ID": 1,
							"Auto_Distribution_Msg_Action": [{
								"DS_MSG_ADO_TYPE": 2,
								"DS_MSG_ADO_FORM": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value2,
								"DS_MSG_ADO_MSG_TYPE": "ORI001",
								"DS_MSG_ADO_FORMACTIONS": "3#Respond",
								"DS_MSG_ADO_PROJDISTGROUPS": "",
								"DS_MSG_ADO_ACTIONDUEDATE": 7,
								"DS_MSG_ADO_PROJDISTUSERS": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value5
							}]
						}
					}
				}
				$scope.jsonWeightage && angular.extend($scope.jsonWeightage, jsonReadWrite);
			}
			$scope.jsonWeightage.ORI_FORMTITLE = $scope.companyName;
			$scope.data && angular.extend($scope.data, $scope.jsonWeightage);

			$scope.appendAttachmentHiddenFields && $scope.appendAttachmentHiddenFields(window.getJSONData());
			$scope.appendAttachHiddenFields();

			var formJson = {
				jsonData: {
					myFields: $scope.data
				},
				projectId: $("input[name ='projectId']").val().split('$$')[0],
				formTypeId: top.$("input[name ='formTypeId']").val(),
				msgId: $("input[name ='msgId']").val(),
				formId: formId,
				msgTypeId: 2,
				parentMsgId: $("input[name ='parent_msg_id']").val(),
				isApprove: $scope.clickApprove,
				vendorOrgId: $scope.data.vendorOrgId,
				evaluationStatus: $scope.clickApprove ? $scope.approveStatus : $scope.rejectStatus
			};

			formJson.inlineAttachments = [];
			var $attachInputs = $("input[name^='xdoc_']");
			for (var i = 0; i < $attachInputs.length; i++) {
				formJson.inlineAttachments.push(
					{ "name": $attachInputs[i].name, "value": $attachInputs[i].value }
				)
			}
			formJson.jsonData.myFields.attachments = [];

			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				formJson.jsonData.myFields[$fakepathids[i].name] = $fakepathids[i].value;
			}

			
			var attachdocs = angular.element("input[name=attachedDocs]");
			var attachdocs_ = angular.element("input[name=attachedDocs_]");
			if(attachdocs.length)
			formJson.attachedDocs = [];

			if(attachdocs_.length)
			formJson.attachedDocs_ = [];
			for(var i=0;i<attachdocs.length;i++){
				if(formJson.attachedDocs.indexOf(attachdocs[i].value == -1))
				formJson.attachedDocs.push(attachdocs[i].value);
			}
			for(var i=0;i<attachdocs_.length;i++){
				if(formJson.attachedDocs_.indexOf(attachdocs_[i].value == -1))
				formJson.attachedDocs_.push(attachdocs_[i].value);
			}

			var attachxdoc_ = angular.element("input[id^=attchment_xdoc_]");
			var xdoc_ = angular.element("input[id^=xdoc_]");			

			formJson.dataMap = {};
			for(var i=0;i<attachxdoc_.length;i++){
				var attachxdoc_Name = attachxdoc_[i].name;				
				formJson.dataMap[attachxdoc_Name]=attachxdoc_[i].value;
			}
			// for(var i=0;i<xdoc_.length;i++){
			// 	var xdoc_Name = xdoc_[i].name;
			// 	formJson.dataMap[xdoc_Name]=xdoc_[i].value;
			// }
			
			formJson.eOriDraftMsgId = $("input[name ='msgId']").val();

			formJson.attachDocFolderID = $("input[name ='attachDocFolderID']").val();
			formJson.jsonData = angular.toJson(formJson.jsonData);
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveeval",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					alert("Evaluation Submitted Successfully");
					if (window.top && window.top.opener) {
						window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						window.close();
						window.top.close();
					} else {
						window.location = top.marketPlaceServiceURL+"?origin=true";
					}
				}
			}, function () {
				alert("Error In Evaluation Submit.");
				$scope.clickApprove = false;
			});
		}

		/**
		 * To UOP data vendor to pre fill some data
		 */
		var getUOPData = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/uop/orgregionuop?regionId=" + dcId + "&orgId=" + USP.orgID,
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				mergeUOPData(response.data);
			}, function () {

			});
		}

		/**
		 * set company name and id based on UOP data
		 */
		var mergeUOPData = function (data) {
			$scope.companyName = data.companyName
			$scope.data.uopId = data.uopId;

			var UOP_FIELDS = getObjByFieldId(data.uopData);
			var ADDRESS_UOP = UOP_FIELDS[4].value[0];
			$scope.data.basicInformation.basicDetails.name = UOP_FIELDS[1].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.address = ADDRESS_UOP[0].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.city = ADDRESS_UOP[2].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.country = ADDRESS_UOP[3].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.postCode = ADDRESS_UOP[5].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.phoneNo = ADDRESS_UOP[6].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.email = ADDRESS_UOP[8].value || "";
			$scope.data.basicInformation.basicDetails.addressDetails.faxNo = ADDRESS_UOP[7].value || "";
			
			$scope.data.basicInformation.basicDetails.addressDetails.website = UOP_FIELDS[13].value || "";
			$scope.data.basicInformation.basicDetails['tradingAddressGroup']['tradingAddress'] = UOP_FIELDS[16] && UOP_FIELDS[16].value || "";

			$scope.data.basicInformation.basicDetails.bankDetails.bankName = UOP_FIELDS[57] && UOP_FIELDS[57].value || "";
			$scope.data.basicInformation.basicDetails.bankDetails.acoountNo = UOP_FIELDS[235] && UOP_FIELDS[235].value || "";

			$scope.data.basicInformation.basicDetails.vatNumber = UOP_FIELDS[20].value || "";
			$scope.data.basicInformation.basicDetails.companyNumber = UOP_FIELDS[236] && UOP_FIELDS[236].value || "";

			$scope.data.basicInformation.basicDetails.AccountsContactDetails.contactName = UOP_FIELDS[477].value[0][1] && UOP_FIELDS[477].value[0][1].value || "";
			$scope.data.basicInformation.basicDetails.AccountsContactDetails.contactEmail = UOP_FIELDS[477].value[0][6] && UOP_FIELDS[477].value[0][6].value || "";
			$scope.data.basicInformation.basicDetails.AccountsContactDetails.contactPhone = UOP_FIELDS[477].value[0][5] && UOP_FIELDS[477].value[0][5].value || "";

			$scope.data.projectsDetails.projectExperience[0].projectName = UOP_FIELDS[478].value[0][0] && UOP_FIELDS[478].value[0][0].value || "";
			$scope.data.projectsDetails.projectExperience[0].projectValue = UOP_FIELDS[478].value[0][1] && UOP_FIELDS[478].value[0][1].value || "";
			$scope.data.projectsDetails.projectExperience[0].projectDuration = UOP_FIELDS[478].value[0][3] && UOP_FIELDS[478].value[0][1].value || "";

			$scope.data.healthAndSafety.arrangmenDetails.managementChart = UOP_FIELDS[37] && UOP_FIELDS[37].value || "";
			$scope.data.healthAndSafety.arrangmenDetails.keyPositionPerson = UOP_FIELDS[35] && UOP_FIELDS[35].value || "";
			$scope.data.healthAndSafety.trainingAndInformation.process = UOP_FIELDS[47] && UOP_FIELDS[47].value || "";
			$scope.data.healthAndSafety.trainingAndInformation.externalCDM = UOP_FIELDS[48] && UOP_FIELDS[48].value || "";
			$scope.data.healthAndSafety.accidentReportinAndEnforcementAction.prohibitionNotice = UOP_FIELDS[49] && UOP_FIELDS[49].value || "";
			

			setAnnualTurnOver(UOP_FIELDS);
		}

		/**
		 * function used to resize textarea in all fields
		 * to display all context of fields after angular/api data loaded
		 */
		function resizeTextarea(){
			$timeout(function(){
				$scope.expandTextAreaOnLoad();
			}, 1000);
		}
		
		/**
		 * 
		 * @param {Array} uopFields : array of UOP fields data
		 * set annual turnover data from UOP
		 */
		function setAnnualTurnOver(uopFields){
			var ANNUAL_TURNOVER = uopFields[50].value;
			var strAnnualTurnover = '';
			for (var i = 0; i < ANNUAL_TURNOVER.length; i++) {
				var element = ANNUAL_TURNOVER[i];
				if(element[0].value && element[1].value){
					strAnnualTurnover += element[0].value + ": " + element[1].value + "   ";
				}
			}
			$scope.data.financialDetails.annualTurnOver = strAnnualTurnover;
		}

		/**
		 * 
		 * @param {Array} data : Array data of UOP,
		 * function return key value paired json with Key UOP field key and object as its value 
		 */
		function getObjByFieldId(data) {
			var obj = {};
			if (data.length) {
				for (var i = 0; i < data.length; i++) {
					var subDataA = data[i];
					if (subDataA.data.length) {
						for (var j = 0; j < subDataA.data.length; j++) {
							var subDataB = subDataA.data[j];
							if (subDataB.data.length) {
								for (var k = 0; k < subDataB.data.length; k++) {
									var subDataC = subDataB.data[k];
									subDataC.fieldId && (obj[parseInt(subDataC.fieldId)] = subDataC);
								}
							}
						}
					}
				}
			}
			return obj;
		};

		/**
		 * Final rating calculation based on value added evalution stage
		 */
		var finalRatingCountCalculate = function () {
			$scope.jsonWeightage.finalRatingCount = 0;
			for (var i = 0; i < $scope.jsonWeightage.Sections.length; i++) {
				if ($scope.jsonWeightage.Sections[i].evalutionWeightageValue) {
					var sectionPerValue = (parseInt($scope.jsonWeightage.Sections[i].sectionPercentage) * $scope.jsonWeightage.Sections[i].evalutionWeightageValue) / 100;
					$scope.jsonWeightage.finalRatingCount = $scope.jsonWeightage.finalRatingCount + sectionPerValue;
				}
			}
		}

		/**
		 * To insert new row in repeating table based on param
		 * @param { Array } repeatingData: repeating data 
		 * @param { String } objKeyName: object key used to fetch static object from STATIC_OBJ_DATA
		 */
		$scope.addNewItem = function (repeatingData, objKeyName) {
			var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
			repeatingData.push(newRowObject);

			resizeTextarea();
		};

		/**
		 * Scroll to given id element
		 * @param { String } elemtnId: Id of element
		 */
		$scope.scrollToElement = function (elemtnId) {
			if(!$(elemtnId).length) {
				return;
			}

			var top = $(elemtnId)[0].getBoundingClientRect().top + ($window.scrollY || document.documentElement.scrollTop) - 50;
			if($window.scrollTo) {
				$window.scrollTo(0, top);
			}
		};

		$scope.onChangeApplicableForSSIP = function() {
			$scope.data.healthAndSafety.disApplicableForSSIP = '';
		};

		$scope.onChangeDisApplicableForSSIP = function() {
			$scope.data.healthAndSafety.applicableForSSIP = '';
		};
        $scope.briberyChange= function(value){
			$scope.data.antiBriberyCompanySelfPolicy=value;
			console.log($scope.briberyChange)
		}
		/**
		 * set custom section data which fetched from API to display in print view
		 */
		function setViewFlag() {
			var allSections = $scope.WeitageDetails.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.Sections;
			$scope.data['workRole'] = $scope.WeitageDetails.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.workRole;
							
			$scope.data['customSections'] = $scope.WeitageDetails.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.customSections;
			for (var index = 0; index < allSections.length; index++) {
				var element = allSections[index];
				$scope.data.sectionHideFlag[element.sectionId] = element.isSectionActive;

				for (var subIndex = 0; subIndex < element.subSections.length; subIndex++) {
					var subElement = element.subSections[subIndex];
					$scope.data.sectionHideFlag[subElement.subSectionId] = subElement.isSubSectionActive;
				}
			}
			setCollapseFlagForCustomSection();
		}

		/**
		 * Enable collapse/expand for custom section which inherited from Weightage form
		 */
		function setCollapseFlagForCustomSection() {
			if ($scope.data['customSections']) {
				for (var index = 0; index < $scope.data['customSections'].length; index++) {
					$scope.section['custom_' + (index + 1)] = {
						isHide: false
					}
				}
			}
		}
		
		/**
		 * Get weighateg details in evalution stage
		 */
		function getPrequalWeightages() {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages?boid=" + $scope.data.buyerOrgId + "&weightageId=" + weightageId,
				method: 'GET',
				withCredentials: true,
				data: {},
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
			}).then(function (response) {
				if (window.currentViewName == "PREQUAL_RES_VIEW") {
					var resMyFields = response.data && response.data.myFields;
					if (resMyFields) {
						$scope.jsonWeightage = resMyFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;

						for (var i = 0; i < $scope.jsonWeightage.customSections.length; i++) {
							var custSection = $scope.jsonWeightage.customSections[i];
							var tempSubObj = [];
							for (var k = 0; k < custSection.customSubSections.length; k++) {
								var subElement = custSection.customSubSections[k];
								tempSubObj.push({
									"parenRef": custSection.customSectionId,
									"subSectionPercentage": subElement.customSubPercentage,
									"isSubSectionValid": subElement.isCustomSubSectionValid,
									"isSubSectionActive": subElement.isCustomSubActive,
									"evalutionWeightageValue": "",
									"subSectionId": subElement.customSubSectionId,
									"subSectionName": subElement.label
								});
							}
							$scope.jsonWeightage.Sections.push({
								"sectionName": custSection.label,
								"sectionPercentage": custSection.customPercentage,
								"isSubSectionValid": custSection.isCustomSectionValid,
								"evalutionWeightageValue": "",
								"sectionId": custSection.customSectionId,
								"isSectionValid": custSection.isCustomSectionValid,
								"isSectionActive": custSection.isCustomActive,
								"subSections": tempSubObj
							})
						}

						$scope.approveStatus = $scope.data.approveStatus;
						$scope.rejectStatus = $scope.data.rejectStatus;
						$scope.update();
						resizeTextarea();
					}
				} else {
					$scope.prequalJsonWeightage = response.data.myFields;
					showHidePrequalSection();
					$scope.currentSubItem = $scope.data.uopData[0].data[0].id;
					$scope.currentSubItemData = $scope.data.uopData[0].data[0];
					$scope.uopJSON = $scope.data;
					$scope.update();
					resizeTextarea();
				}

			}, function () {
			});
		}

		/**
		 * Canel button event to close form
		 */
		$scope.cancel = function () {
			$window.top.postMessage("closeCreateFormIframe:-1",'*');
		}
		$scope.onChangeEvent = function (param, array) {
			$scope.otherTextBox = param.indexOf("Other") == -1 ? false : true;
			$scope.data.products.tradeDetails=param.join(",");
		}
		/**
		 * save prequal form using marketplace API
		 */
		$scope.savePrequalForm = function (isForSaveDraft) {
			if (!weightageId || !$scope.data.buyerOrgId) {
				Notification.error({ title: lang.get('alert'), message: "Form does not have buyer or questionnaire template" });
				return;
			}

			var FormError = $scope.$parent.myform.$error;
			if (FormError && !commonApi._.isEmpty(FormError) && !isForSaveDraft) {
				var validateMSG = lang.get("form-submit-validation-msg");
				Notification.error({ title: lang.get('alert'), message: validateMSG });
				return;
			}

			var validationObj = attachmentApi.validate(); 
			if(!validationObj.valid) {
				if(validationObj.type == "confirm") {
					if(!confirm(validationObj.msg)) {
						return false;
					}
				} else {
					Notification.error({ title : lang.get('alert'), message : validationObj.msg });
					return false;
				}
			}

			$scope.appendAttachmentHiddenFields && $scope.appendAttachmentHiddenFields(window.getJSONData());
			$scope.appendAttachHiddenFields();

			$scope.isForSaveDraft = isForSaveDraft;
			$scope.data.vendorOrgId = USP.orgID;
			$scope.data.ORI_FORMTITLE = $scope.companyName
			$scope.data.vendorOrgName = USP.tpdOrgName;
			$scope.data.prequalType = myConfig.prequalType ? myConfig.prequalType : 1;
			$scope.data.referenceResourceId = myConfig.referenceResourceId ?  myConfig.referenceResourceId.split("$$")[0] : "0";
			$scope.data.weightageId = weightageId;
			$scope.data.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = $scope.data.referenceResourceId;

			var formJson = {
				jsonData: {
					myFields: $scope.data
				},
				projectId: projectId  && (projectId.indexOf('$$') > 0 ? projectId.split('$$')[0] : projectId),
				formTypeId: formTypeId && formTypeId.split('$$')[0],
				userRef: userRef,
				uopAttachments: []
			}
			formJson.inlineAttachments = [];
			var $attachInputs = $("input[name^='xdoc_']");
			for (var i = 0; i < $attachInputs.length; i++) {
				if($attachInputs[i].id != "xdoc_attachment_fields"){
					formJson.inlineAttachments.push(
						{ "name": $attachInputs[i].name, "value": $attachInputs[i].value }
					)
				}
			}
			formJson.jsonData.myFields.attachments = [];

			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				formJson.jsonData.myFields[$fakepathids[i].name] = $fakepathids[i].value;
			}

			formJson.attachDocFolderID = $("input[name ='attachDocFolderID']").val();
			formJson.msgId = $("input[name ='msgId']").val();
			formJson.formId = formId;
			
			if ($scope.isForSaveDraft) {
				formJson.saveAsDraft = true;
			}
			formJson.editOri = false;
			if ($("input[name ='editDraft']").val() == "true") {
				formJson.formAction = 'edit';
			} else {
				formJson.formAction = 'create';
			}
			
			var attachdocs = angular.element("input[name=attachedDocs]");
			var attachdocs_ = angular.element("input[name=attachedDocs_]");
			if(attachdocs.length)
			formJson.attachedDocs = [];

			if(attachdocs_.length)
			formJson.attachedDocs_ = [];
			for(var i=0;i<attachdocs.length;i++){
				if(formJson.attachedDocs.indexOf(attachdocs[i].value == -1))
				formJson.attachedDocs.push(attachdocs[i].value);
			}
			for(var i=0;i<attachdocs_.length;i++){
				if(formJson.attachedDocs_.indexOf(attachdocs_[i].value == -1))
				formJson.attachedDocs_.push(attachdocs_[i].value);
			}

			var attachxdoc_ = angular.element("input[id^=attchment_xdoc_]");
			var xdoc_ = angular.element("input[id^=xdoc_]");

			formJson.dataMap = {};
			for(var i=0;i<attachxdoc_.length;i++){
				var attachxdoc_Name = attachxdoc_[i].name;
				formJson.dataMap[attachxdoc_Name]=attachxdoc_[i].value;
			}

			// formJson.dataMap = {};
			// for(var i=0;i<attachxdoc_.length;i++){
			// 	var attachxdoc_Name = attachxdoc_[i].name;
			// 	formJson.dataMap[attachxdoc_Name]=attachxdoc_[i].value;
			// }
			// for(var i=0;i<xdoc_.length;i++){
			// 	var xdoc_Name = xdoc_[i].name;
			// 	formJson.dataMap[xdoc_Name]=xdoc_[i].value;
			// }
			
			formJson.eOriDraftMsgId = $("input[name ='msgId']").val();

			formJson.jsonData = angular.toJson(formJson.jsonData);
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/save",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					$scope.isForSaveDraft ? $window.alert("Form Saved as Draft.") : $window.alert("Prequalification Submitted Successfully.");
					if (window.top && window.top.opener) {
						if (ie_ver && ie_ver() > 0) {
							window.opener.reloadPublicURL && window.opener.reloadPublicURL();
						} else {
							window.top.opener.postMessage("PublicURLreload", "*");
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						}
						window.top.close();
					} else {
						window.location = top.marketPlaceServiceURL+"?origin=true";
					}
				}
			}, function () {
				$window.alert("Error In Prequalification Submit.");
				$scope.clickSave = false;
				$scope.isForSaveDraft = false;
			});
		}
	}
	return FormController;
});