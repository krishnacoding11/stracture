/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element,commonApi, $controller, $window, $timeout) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		$scope.logo = "/images/htmlform/commenting/tideway.png";
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.ORIMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];

		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.ResponseInfo = $scope.ORIMsgCustomFields.RES_MSG_Custom_Fields.Response_Info;

		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');

		var DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_GEO_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_GEO_STD_TNDR_GetITBs');
		var DS_PROJUSERS = $scope.getValueOfOnLoadData('DS_PROJUSERS');

		$scope.update();

		$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].ACF_01_FORM;

		// Update Form Status

		function updateFormStatus(StrStatus) {
			//get status according pass parameter
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				//set status
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var strStatus = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatus;
				}
			}
		}

		$scope.setFormStatus = function () {
			//setResponses function code on response change
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].ACF_01_FORM;
			$scope.ACF_01_FORM.ACF_01_Response = $scope.ResponseInfo.Response;

			//form closed
			updateFormStatus('Closed');
		}

		$scope.logo = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});

		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
		var strResDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		var strCloseDueDate = "";
		var strDays
		$scope.getServerTime(function (serverDate) {
			strDays = (new Date(serverDate)).getTime() + (86400000 * 7);
			strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
			$scope.strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date($scope.strTime), 'dd-M-yy');
		});
		if (window.currentViewName == "ORI_VIEW") {
			var strPrefix = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMAUTONO_PREFIX'];

			if (strFormId == "" || strIsDraft == "YES") {
				$scope.ORIMsgCustomFields['ORI_USERREF'] = strPrefix + "<<NEXT_AUTONO>>";
				$scope.ORIMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
				$scope.ORIMsgCustomFields.DSI_isLoading = false;
				$timeout(function () {
					if (localStorage) {
						var numVal = localStorage.getItem('formcode_num');
						if (numVal) {
							if (numVal) {
								$scope.setFormContentOnITBChange(numVal);
							}
							localStorage.removeItem('formcode_num');
						}
					}
					$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = strCloseDueDate;
				}, 1000);
			}
		}

		var strCallBackData = [];
		$scope.setFormContentOnITBChange = function (selectedITBValue) {
			var strSel_ITB = selectedITBValue && selectedITBValue.split('-')[0].trim();

			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
						"fieldValue": strSel_ITB
					}
					]
				}
			}
			if(strSel_ITB) {
				$scope.ORIMsgCustomFields.DSI_isLoading = true;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						strCallBackData = angular.fromJson(response.data['DS_GEO_STD_TNDR_GET_ITBSDETAILS']);
						if (strCallBackData && strCallBackData.Items.Item.length) {
							strCallBackData = strCallBackData.Items.Item;
							var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
								return val.Value1.indexOf(strSel_ITB) != -1;
							});
							$scope.ORIMsgCustomFields['Select_ITB'] = dropDownValueObj[0].Value1;
							var strBidAdmin = strCallBackData[0].Value5;
							var strOrgTitle = strCallBackData[0].Value3;
							var strOrgUserRef = strCallBackData[0].Value4;
							var strItbId = strCallBackData[0].Value1;
							$scope.ORIMsgCustomFields['ORI_FORMTITLE'] = strOrgTitle;
							$scope.ORIMsgCustomFields['ORI_USERREF'] = strOrgUserRef;
							$scope.ORIMsgCustomFields['Bid_Administrator'] = strBidAdmin;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = strItbId;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT2'] = strSel_ITB;
							var strContactNumber = strCallBackData[0].Value10;
							var strCOntactPerson = strCallBackData[0].Value11;
							var strContactPersonId = strCallBackData[0].Value9.trim();
							if (strCOntactPerson) {
								strCOntactPerson = strCOntactPerson.split(',')[0].trim();
							}
							$scope.ORIMsgCustomFields['TenderContactPerson'] = strCOntactPerson;
							$scope.ORIMsgCustomFields['TenderContactNumber'] = strContactNumber;
							$scope.ORIMsgCustomFields.DSI_isLoading = false;
							if (strContactPersonId) {
								var allNodes = commonApi._.filter(DS_PROJUSERS, function (val) {
									return val.Value.split('#')[0].trim() == strContactPersonId;
								});
								if (allNodes.length) {
									var strDueDate = $scope.setDbDateClientSide(3);
									$scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3";
									$scope.data.myFields.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [{
										DS_PROJDISTUSERS: allNodes[0].Value,
										DS_FORMACTIONS: "3# Respond",
										DS_ACTIONDUEDATE: strDueDate,
										DS_DUEDAYS: ""
									}];
								}
							}
						}
					}
				});
			} else {
				$scope.ORIMsgCustomFields.DSI_isLoading = false;
			}	
			var strOrgPrefix = "";
			var strWorkingUser = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'];
			if (strWorkingUser.length > 1) {
				strOrgPrefix = strWorkingUser.split(',')[1].trim().substring(0, 3);
			}
			$scope.ORIMsgCustomFields['Bidder_Org_Prefix'] = strOrgPrefix;
			var strOrgUserRef = $scope.ORIMsgCustomFields['ORI_USERREF'].trim();
			$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMAUTONO_PREFIX'] = strOrgUserRef + "/" + strOrgPrefix;
		}

		if (window.currentViewName == "ORI_PRINT_VIEW" || window.currentViewName == "FORM_PRINT_VIEW" || window.currentViewName == "RES_PRINT_VIEW") {
			var strSel_ITB = $scope.ORIMsgCustomFields['Select_ITB'];
			var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
				return val.Value1.trim() == strSel_ITB.trim();
			});
			if (dropDownValueObj.length) {
				$scope.ORIMsgCustomFields['ITB_URL'] = dropDownValueObj[0].URL6;
			}
		}

		if (window.currentViewName == "RES_VIEW") {
			var strToday = $scope.setDbDateClientSide(0);
			$scope.ResponseInfo.Response_Date = strToday;

			var strWorkingUserNameNode = WorkingUserID[0].Name;
			if (strWorkingUserNameNode) {
				$scope.ResponseInfo.Response_Creator = strWorkingUserNameNode.trim();
			}

			if (strIsDraft == "YES" || strResDraft == "YES") {
				resetDueDateOnDraft();
			}
		}

		if (strFormId != "" && strIsDraft == "NO") {
			$scope.ORIMsgCustomFields.DSI_isLoading = false;
		}

		function resetDueDateOnDraft() {
			var strDueDate = $scope.setDbDateClientSide(3);
			var allDistUsers = $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'];
			if (allDistUsers.length > 0) {
				angular.forEach(allDistUsers, function (item, index) {
					allDistUsers.DS_ACTIONDUEDATE = strDueDate;
				});
			}
		}

		$scope.On_ISCirculate_Changed = function (str) {
			deleteAutocreteRows();
			if (str == true) {
				setAutoCreateNodesValues();
			}
		}

		function deleteAutocreteRows() {
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].DS_AUTOCREATE_FORM = "0";
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].ACF_01_FORM;

			$scope.ACF_01_FORM.ACF_01_ITB = "";
			$scope.ACF_01_FORM.ACF_01_DS_Logo = "";
			$scope.ACF_01_FORM.ACF_01_Response = "";
			$scope.ACF_01_FORM.ACF_01_Response_Creator = "";
			$scope.ACF_01_FORM.ACF_01_DS_FORMTITLE = "";
			$scope.ACF_01_FORM.ACF_01_CREATED_BY = "";
			$scope.ACF_01_FORM.ACF_01_DS_AUTODISTRIBUTE = "";
			$scope.ACF_01_FORM.ACF_01_IsRespond = "";
			$scope.ACF_01_FORM.ACF_01_Addenda_Notes = "";
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT1 = "";
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT2 = "";
			$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Auto_Distribute_Group.ACF_01_Auto_Distribute_Users = [];
		}

		function setAutoCreateNodesValues() {
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].ACF_01_FORM;

			var strWorkingId = WorkingUserID[0].Value && WorkingUserID[0].Value.split("|")[0].trim();
			$scope.ACF_01_FORM.ACF_01_Addenda_Notes = $scope.ORIMsgCustomFields['Bidder_Query'];
			$scope.ACF_01_FORM.ACF_01_ITB= $scope.ORIMsgCustomFields['Select_ITB'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMTITLE = $scope.ORIMsgCustomFields['ORI_FORMTITLE'];
			$scope.ACF_01_FORM.ACF_01_CREATED_BY = strWorkingId;
			$scope.ACF_01_FORM.ACF_01_Response = $scope.ResponseInfo.Response;
			$scope.ACF_01_FORM.ACF_01_DS_Logo = $scope.ORIMsgCustomFields.DS_Logo;
			$scope.ACF_01_FORM.ACF_01_IsRespond = "true";

			//auto distribute nodes
			$scope.ACF_01_FORM.ACF_01_DS_AUTODISTRIBUTE = "3";
			var strSel_ITB = $scope.ORIMsgCustomFields['Select_ITB'].split('-')[0];
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": "DS_GEO_STD_ADD_BM_Bid_Recipients",
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": "DS_GEO_STD_ADD_BM_Bid_Recipients",
						"fieldValue": strSel_ITB
					}
					]
				}
			}
			$scope.ORIMsgCustomFields.DSI_isLoading = true;
			$scope.getCallbackData(form).then(function (response) {
				if (response.data) {
					var DS_GEO_STD_ADD_BM_Bid_Recipients = angular.fromJson(response.data['DS_GEO_STD_ADD_BM_Bid_Recipients']);
					if (DS_GEO_STD_ADD_BM_Bid_Recipients && DS_GEO_STD_ADD_BM_Bid_Recipients.Items.Item.length) {
						DS_GEO_STD_ADD_BM_Bid_Recipients = DS_GEO_STD_ADD_BM_Bid_Recipients.Items.Item;
						var xpnAllnodes = commonApi._.filter(DS_GEO_STD_ADD_BM_Bid_Recipients, function (val) {
							return val.Value7.indexOf('Rejected') < 0;
						});
						$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Auto_Distribute_Group.ACF_01_Auto_Distribute_Users = [];
						if (xpnAllnodes.length > 0) {
							angular.forEach(xpnAllnodes, function (item, index) {
								var strvalue = item.Value5;
								var strName = item.Value6;
								addAutoDistributeNodesACF(strvalue, strName);
							});
						}
						$scope.ORIMsgCustomFields.DSI_isLoading = false;
					}
				}
			});

			//formstatus and close due date and other flags
			var formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];
			$scope.ACF_01_FORM.ACF_01_DS_ALL_FORMSTATUS = formStatus && formStatus.split('#')[0].trim();
			$scope.ACF_01_FORM.ACF_01_DS_CLOSE_DUE_DATE = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'];
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS[0].DS_AUTOCREATE_FORM = "24";

			//set form content
			$scope.ACF_01_FORM.ACF_01_ORI_USERREF = $scope.ORIMsgCustomFields['ORI_USERREF'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT1 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT2 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT2'];

		}

		function addAutoDistributeNodesACF(strvalue, strName) {
			var strDueDate = $scope.setDbDateClientSide(0);
			$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Auto_Distribute_Group.ACF_01_Auto_Distribute_Users.push({
				ACF_01_DS_PROJDISTUSERS: strvalue,
				ACF_01_DS_FORMACTIONS: "7#For Information",
				ACF_01_DS_ACTIONDUEDATE: strDueDate,
				ACF_01_Dist_Organisation: "",
				ACF_01_DS_User_Name: strName
			});
		}

		$timeout(function () {
			$scope.expandTextAreaOnLoad();
		}, 500);

	}

	return FormController;
});