define(['angular', "mainModule", './base', '../../nicEdit', '../components/item.selection', '../components/number-format'], function (angular, mainModule, baseController) {
	'use strict';
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
					addRichtext();
				}, 100);
			}
		});
		
		$scope.stopAutoSaveDraftTimerFromClientSide();
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.Contract_Item_Group = $scope.oriMsgCustomFields.Contract_Item_Group;
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.editForward = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT != 'YES';
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isResPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.CurrformStatus  = angular.element('#DS_FORMSTATUS').val() || "";
		$scope.xhr = {
			ContractListXHR: false,
			budContractDetailsXHR: false,
			ReviseDateXHR: false,
		}
		var STATIC_OBJ = {
			CODE_GROUP: {
				Group_Code: "",
				Group_Name: "",
				Group_Code_GUID: "",
				Contract_Code_group: {
					Contract_Code_list: []
				}
			},
			COST_CODE: {
				Code: "",
				Cost_Name: "",
				Code_GUID: "",
				Code_Parent_GUID: "",
				Approved_Budget: "",
				Managed_Budget: "",
				Contract_Amount: "",
				Previous_Amendment: "",
				Current_Amendment: "",
				Final_Contract_Amount: "",
				Is_itemIncluded: 'no',
				Is_defaultIncluded: 'no'
			}
		},
		CONSTANTS_OBJ = {
			IMAGE_DEFAULT_STR: 'images/asite.gif',
			BUD_PROJ_LIST:'budget-proj-list',
			CONTRACT_LIST:'contract-list',
			OPEN: "Open",
			APPROVED_FINAL:"approved - final",
			APPROVED:"approved",
			REVISE_RESUBMIT: "revise and resubmit",
			COST_ORIGINATOR: "Amendment Originator",
			FOR_INFO: "7#For Information",
			ORI_ACTION_CODE: "3",
		},
		dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'],
		DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var isDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT == 'NO' ? false : true;
		var budSummaryFormList = $scope.getValueOfOnLoadData('DS_IKEA_Approved_Final_Forms_Dtls'),
		contractFormsList = [];
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			if (!dSFormId || isDraft) {
				var serverDateObj = new Date(serverDate);
				serverDateObj.setDate(serverDateObj.getDate() + 7);
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
			}
		});

		$scope.selectionlist = {
			BudgetedProjList: [],
			ContractList: [],
			typesList: []
        }

		if($scope.isOriView){
			var curStatus = $scope.CurrformStatus.toLowerCase();
			$scope.isCostOriginator = hasCostOriginatorinROle();
			$scope.hideSaveDraftButton();
			if(!$scope.editForward){
				var logos = getLefRightLogo();
				$scope.oriMsgCustomFields.leftLogo =  logos[0];
				$scope.oriMsgCustomFields.rightLogo =  logos[1];
				$scope.selectionlist.BudgetedProjList = structureItemList(budSummaryFormList, CONSTANTS_OBJ.BUD_PROJ_LIST);
				$scope.selectionlist.typesList = commonApi.getItemSelectionList({
					arrayObject: getConfigurableAttriburteByType('Contract Amendment Values'),
					groupNameKey: "",
					modelKey: "Value8",
					displayKey: "Value8",
					allowBlankSelection: true
				});
			}
			if(!isDraft && !$scope.editForward && $scope.oriMsgCustomFields.Project_Name && $scope.oriMsgCustomFields.Contract_No){
				$scope.oriMsgCustomFields.isFromLauch = true;
				var selectedProj = commonApi._.find(budSummaryFormList, function(item){
					return $scope.oriMsgCustomFields.Project_Name.split('|')[0].trim() == item.Value2;
				});
				if(selectedProj){
					$scope.oriMsgCustomFields.Project_Name  = selectedProj.Value2 + ' | ' + selectedProj.Value6 + ' | ' + selectedProj.Value4;
				}
				getContractFormList($scope.oriMsgCustomFields.Project_Name, true);
			}
			// to edit and forward availabel for given status
			$scope.isAvailforEditAndForward = (curStatus == CONSTANTS_OBJ.REVISE_RESUBMIT)
			
			if((isDraft && $scope.oriMsgCustomFields.Contract_No) || ($scope.editForward && $scope.isAvailforEditAndForward)){
				isDraft && getContractFormList($scope.oriMsgCustomFields.Project_Name);
				$scope.Backup_Contract_Items = $scope.Contract_Item_Group.Contract_Items;
				getbudgetContractDetails($scope.oriMsgCustomFields.ContractFormID, $scope.Backup_Contract_Items);
			}
		}
		if($scope.isRespView){
			var curUserId = $scope.getWorkingUserId();
			var currUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
			$scope.hasResponseAction = false;
			var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS').filter(function(item){
				return item.Name.toLowerCase() == 'respond'  && item.Value.indexOf(curUserId) > -1;
				});
			if(incompleteAction.length){
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
				$scope.resMsgCustomFields.Comments = "";
				if(currUser && currUser.length){
					$scope.resMsgCustomFields.responseBy = currUser[0].Name;
				}

				$scope.availableStatus = commonApi.getItemSelectionList({
					arrayObject: $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
					groupNameKey: "",
					modelKey: "Value",
					displayKey: "Name"
				});
				$scope.hasResponseAction = true;
			}
		}

		if($scope.isOriPrintView || $scope.isResPrintView){
			$scope.hideExportBtn();
			$scope.contractFOrmDetails = $scope.getValueOfOnLoadData('DS_GET_Form_All_Data_By_FormContent');
		}

		function getLefRightLogo(){
			var logos = getConfigurableAttriburteByType('Logo');
			var logoLeft = CONSTANTS_OBJ.IMAGE_DEFAULT_STR, logoRight = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
			angular.forEach(logos, function(item){
				if(item.Value7 && item.Value7.toLowerCase() == 'left logo'){
					logoLeft = item.Value8;
				}
				if(item.Value7 && item.Value7.toLowerCase() == 'right logo'){
					logoRight = item.Value8;
				}
			})
			return [logoLeft, logoRight];
		}

		/**
		 * return array custom attribute is matched with attribute name
		 * @param {string} type: confugured attrbite name
		 */
		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		/**
		 * Return true if working yuser has cost originator role
		 */
		function hasCostOriginatorinROle(){
			var aUserRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
			if(aUserRoles && aUserRoles.length && aUserRoles[0].Value){
				var found = commonApi._.find(aUserRoles[0].Value.split(','), function(item){
					return item.trim().toLowerCase() == CONSTANTS_OBJ.COST_ORIGINATOR.toLowerCase();
				})
				return !!found;
			}else{
				return false;
			}
		}

		function structureItemList(availList, setFor){
			var tempList = [];
			var displayVal, modelVal, optlabel = '';
			switch (setFor) {
				case CONSTANTS_OBJ.BUD_PROJ_LIST:
					angular.forEach(availList, function (item) {
						displayVal = item.Value6 + " | " + item.Value4 ;
						modelVal = item.Value2 + ' | ' + item.Value6 + ' | ' + item.Value4;
						tempList.push({
							displayValue: displayVal,
							modelValue: modelVal
						});
					});
				break;
				case CONSTANTS_OBJ.CONTRACT_LIST:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value4,
							modelValue: item.Value4
						});
					});
				break;
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		}

		function addRichtext() {
			if (window.nicEditor) {
				if (currentViewName == 'ORI_VIEW') {
					createRichtext("Amendment_Description");
					createRichtext("Terms");
				}
			}
		}

		function createRichtext(elemId) {
			var editor = new nicEditor({
				buttonList: ['bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'indent', 'outdent', 'image', 'link', 'unlink', 'forecolor', 'bgcolor', 'fontSize', 'fontFamily', 'strikethrough', 'subscript', 'superscript', 'removeformat', 'hr'],
				iconsPath: '../images/nicEditorIcons_new.gif',
				maxHeight: 300
			}).panelInstance(elemId);

			var editorInstance = nicEditors.findEditor(elemId);
			var content = editorInstance.getContent();
			if (content == "" || content == "<br>") {
				content = "";
			}
			if ((isDraft && content == "") || $scope.editForward) {
				content = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'][elemId];
				editorInstance.setContent(content);
			}
			editor.addEvent('blur', function () {
				// Your code here that is called whenever the user blurs (stops editing) the nicedit instance
				editorInstance = nicEditors.findEditor(elemId);
				content = editorInstance.getContent();
				if (content == "" || content == "<br>") {
					content = "";
				}
				$scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'][elemId] = content;
			});
		}

		/**
		 * return user with given role
		 * @param {array} role: array of role names 
		 */
		function getArrayOfUserbyRole(role){
			var projUserWithRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			var userArray= [], added;
			for(var i=0; i<projUserWithRole.length; i++){
				var userRoles = projUserWithRole[i].Value.split('|')[0].split(',');
				added = false;
				for(var j=0; j<userRoles.length; j++){
					if(!added && userRoles[j].toLowerCase().trim() == role.toLowerCase()){
						userArray.push(projUserWithRole[i].Value.split('|')[2].trim());
						added = true;
					}
				}
			}
			return userArray;
		}

		/**
		 * set form status
		 * @param {string} StrStatus: status to set
		 */
		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}

		/**
		 * Commen function to assing action to user
		 * @param {*} userToDist: array or string users list or sing user 
		 * @param {string} action: action to assign
		 * @param {string} DS_AUTODISTRIBUTE
		 * @param {*} distDate: due date fo action
		 */
		function assignActionToUser(userToDist, action, DS_AUTODISTRIBUTE, distDate){
			var tempList = [];
			if(angular.isArray(userToDist) && userToDist.length){
				for (var j = 0; j < userToDist.length; j++) {
					tempList.push({
						strUser: userToDist[j],
						strAction: action,
						strDate: distDate
					});
				}
			}else{
				tempList.push({
					strUser: userToDist,
					strAction: action,
					strDate: distDate
				});
			}
			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODISTRIBUTE
			});
		}

		function getContractFormList(selectedProject, isFromLauch){
			if(!selectedProject){
				contractFormsList = [];
				$scope.selectionlist.ContractList = [];
				return;
			}
			var sp = "DS_IKEA_Approved_Contract_List";
			$scope.xhr.ContractListXHR = true;
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": sp,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": sp,
						"fieldValue": selectedProject.split('|')[0].trim()
					}]
				}
			};

			$scope.getCallbackData(form).then(function (response) {
				contractFormsList = angular.fromJson(response.data[sp]).Items.Item;
				$scope.selectionlist.ContractList = structureItemList(contractFormsList, CONSTANTS_OBJ.CONTRACT_LIST);
				if(isFromLauch){
					$scope.onContractSelection();
				}
				$scope.xhr.ContractListXHR = false;
			}, function (errorObj) {
				contractFormsList = [];
				Notification.error({
					title: 'Server Error',
					message: 'Error while Fetching Data.'
				});
				$scope.xhr.ContractListXHR = false;
			});
		}

		$scope.onProjectSelection = function(){
			resetContractDetails();
			$scope.oriMsgCustomFields.Contract_No = ""
			contractFormsList = [];
			$scope.selectionlist.ContractList = [];
			getContractFormList($scope.oriMsgCustomFields.Project_Name);
		};

		$scope.onContractSelection = function(){
			var selectedContractNO = $scope.oriMsgCustomFields.Contract_No;
			if(selectedContractNO){
				var foundbud = commonApi._.find(contractFormsList, function(item){
					return item.Value4 == selectedContractNO;
				});
				if(foundbud){
					$scope.oriMsgCustomFields.Contact_Title = foundbud.Value5;
					$scope.oriMsgCustomFields.Contact_For = foundbud.Value6;
					$scope.oriMsgCustomFields.Role = foundbud.Value7;
					$scope.oriMsgCustomFields.Start_Date = foundbud.Value8;
					$scope.oriMsgCustomFields.End_Date = foundbud.Value9;
					$scope.oriMsgCustomFields.Tax = foundbud.Value10;
					$scope.oriMsgCustomFields.Currency = foundbud.Value11;
					$scope.oriMsgCustomFields.ContractFormID = foundbud.Value2;
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3  = foundbud.Value2;
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1  = foundbud.Value2;
					getbudgetContractDetails($scope.oriMsgCustomFields.ContractFormID);
				}
			}else{
				resetContractDetails();
			}
		};

		function resetContractDetails(){
			$scope.oriMsgCustomFields.Contact_Title = "";
			$scope.oriMsgCustomFields.Contact_For = "";
			$scope.oriMsgCustomFields.Role = "";
			$scope.oriMsgCustomFields.Start_Date = "";
			$scope.oriMsgCustomFields.End_Date = "";
			$scope.oriMsgCustomFields.Tax = "";
			$scope.oriMsgCustomFields.Currency = "";
			$scope.oriMsgCustomFields.ContractFormID = "";
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = "";
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1  = "";
		}

		/**
		 * called on load for update and set updated date edit and distribte and draft case
		 * @param {array} backup_List: list of backed up contract item of chenged
		 */
		function updateInBudgetContractList(backup_List){
			var backupGroup, backupcode;
			if(!backup_List){
				return;
			}
			angular.forEach($scope.Contract_Item_Group.Contract_Items, function(item){
				backupGroup = commonApi._.find(backup_List, function(backupgroupItem){
					return backupgroupItem.Group_Code_GUID == item.Group_Code_GUID;
				})
				if(backupGroup){
					angular.forEach(item.Contract_Code_group.Contract_Code_list, function(subitem){
						backupcode = commonApi._.find(backupGroup.Contract_Code_group.Contract_Code_list, function(backupCodeItem){
							return backupCodeItem.Code_GUID == subitem.Code_GUID;
						})
						if(backupcode && (backupcode.Is_itemIncluded == 'yes' || subitem.Is_itemIncluded == 'yes') ){
							subitem.Is_itemIncluded = 'yes'
							subitem.Current_Amendment = backupcode.Current_Amendment;
						}
					});
				}
			})
		}

		function getFormDetails(sp, fieldName){
			return {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": sp,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": sp,
						"fieldValue": fieldName
					}]
				}
			};
		}

		/**
		 * called on contract selection or onload for edit ori or draft ori, 
		 * need to add backuplist when calling from edit and forward or draft
		 * @param {string} contractForm: contract form no 
		 * @param {array} Backup_List: backup list
		 */
		function getbudgetContractDetails(contractForm, Backup_List){
			var sp = "DS_IKEA_Form_BSF_CON_CAM_Dtls";
			$scope.xhr.budContractDetailsXHR = true;
			$scope.Contract_Item_Group.Contract_Items = [];
			var form = getFormDetails(sp, contractForm.trim());
			$scope.getCallbackData(form).then(function (response) {
				var listData = angular.fromJson(response.data[sp]).Items.Item;
				setbudgetContractDetails(listData);
				if(!$scope.editForward && !$scope.oriMsgCustomFields.Revised_End_Date){
					getSetRevisedDate(contractForm.trim());
				}
				if(Backup_List){
					updateInBudgetContractList(Backup_List);
				}
				$scope.xhr.budContractDetailsXHR = false;
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Fetching Data.'
				});
				$scope.xhr.budContractDetailsXHR = false;
			});
		}

		function getSetRevisedDate(contractForm){
			var sp = "DS_IKEA_Form_CAM_Dtls";
			$scope.xhr.ReviseDateXHR = true;
			var form = getFormDetails(sp, contractForm.trim());
			$scope.getCallbackData(form).then(function (response) {
				var listData = angular.fromJson(response.data[sp]).Items.Item;
				if(listData && listData.length){
					$scope.oriMsgCustomFields.Revised_End_Date =   listData[0].Value6;
				}
				$scope.xhr.ReviseDateXHR = false;
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Fetching Data.'
				});
				$scope.xhr.ReviseDateXHR = false;
			});
		}

		/**
		 * setting data in contact items list
		 * @param {array} list: list of budget sumamry cost code got by sp
		 */
		function setbudgetContractDetails(list){
			var parentObj = {}, childObj = {}, groupTrack = {};
			angular.forEach(list, function(item){
				if(!groupTrack.hasOwnProperty(item.Value9)){
					groupTrack[item.Value9] = 'no';
				}
				if(groupTrack.hasOwnProperty(item.Value9) && groupTrack[item.Value9] == 'no'){
					parentObj = angular.copy(STATIC_OBJ.CODE_GROUP);
					parentObj.Group_Code_GUID = item.Value9;
					parentObj.Group_Code = item.Value7;
					parentObj.Group_Name = item.Value8;
				}
				angular.forEach(list, function(subitem){
					if(item.Value9 == subitem.Value9 && groupTrack[item.Value9] == 'no'){
						childObj = angular.copy(STATIC_OBJ.COST_CODE);
						childObj.Code_GUID = subitem.Value12;
						childObj.Code = subitem.Value10;
						childObj.Cost_Name = subitem.Value11;
						childObj.Code_Parent_GUID = subitem.Value9;
						childObj.Approved_Budget =  subitem.Value15 || 0;
						childObj.Managed_Budget =  subitem.Value14 || 0;
						childObj.approvedPlusManagedBud = Number(childObj.Approved_Budget) + Number(childObj.Managed_Budget);
						childObj.Contract_Amount =  subitem.Value4;
						childObj.Current_Amendment =  "";
						childObj.Previous_Amendment = subitem.Value16;
						childObj.Is_defaultIncluded =  subitem.Value17;
						childObj.Is_itemIncluded = childObj.Is_defaultIncluded;
						parentObj.Contract_Code_group.Contract_Code_list.push(childObj);
					}
				});

				if(groupTrack.hasOwnProperty(item.Value9) && groupTrack[item.Value9] == 'no'){
					$scope.Contract_Item_Group.Contract_Items.push(parentObj);
					groupTrack[item.Value9] = 'yes';
				}
			});
		}

		function setGropuVisibleValueforPrint(){
			var hasAnyWithChecked;
			angular.forEach($scope.Contract_Item_Group.Contract_Items, function(item){
				hasAnyWithChecked = commonApi._.find(item.Contract_Code_group.Contract_Code_list ,function(subitem){
					return subitem.Is_itemIncluded == 'yes';
				});
				if(hasAnyWithChecked){
					item.hasAnyWithChecked = 'yes';
				}else{
					item.hasAnyWithChecked = 'no';
				}
			});
		}

		function setContractAmendmentTotal(){
			var contractTotal = 0, previousamdTOtal = 0, currentAmendTotal = 0, ApprovedBudTotal = 0, ManagedBudTotal = 0;
			angular.forEach($scope.Contract_Item_Group.Contract_Items, function(item){
				angular.forEach(item.Contract_Code_group.Contract_Code_list ,function(subitem){
					if(subitem.Is_itemIncluded == 'yes'){
						contractTotal = contractTotal + Number(subitem.Contract_Amount);
						previousamdTOtal = previousamdTOtal + Number(subitem.Previous_Amendment);
						currentAmendTotal = currentAmendTotal + Number(subitem.Current_Amendment);
						subitem.Final_Contract_Amount = Number(subitem.Contract_Amount) + Number(subitem.Previous_Amendment) + Number(subitem.Current_Amendment);
						ApprovedBudTotal = ApprovedBudTotal + Number(subitem.Approved_Budget);
						ManagedBudTotal = ManagedBudTotal + Number(subitem.Managed_Budget);
					}
				});
			});
			$scope.oriMsgCustomFields.Total_Approved_budget_Amount = ApprovedBudTotal;
			$scope.oriMsgCustomFields.Total_Managed_budget_Amount = ManagedBudTotal;
			$scope.oriMsgCustomFields.Total_Contract_Amount = contractTotal;
			$scope.oriMsgCustomFields.Total_Previous_Amendment = previousamdTOtal;
			$scope.oriMsgCustomFields.Total_Current_Amendment = currentAmendTotal;
			$scope.oriMsgCustomFields.Total_Final_Contract_Amount = contractTotal + previousamdTOtal + currentAmendTotal;
		}

		$scope.onCurrentAmendChange = function(curitem){
			if(curitem.Is_defaultIncluded != 'yes' && curitem.Current_Amendment && Number(curitem.Current_Amendment) == 0){
				alert('Current amendment should not be zero for new selected');
				curitem.Current_Amendment = "";
			}
		};

		$scope.onCodeItemCheckChange = function(curitem){
			if(curitem.Is_itemIncluded != 'yes'){
				curitem.Current_Amendment = "";
			}
		};

		/**
		 * check for date comarission validation and give alert
		 * @param {string} date1: start date
		 * @param {string} date2: end date
		 * @param {string} changedfield: which field is changed in oriMsgCustomFields
		 */
		$scope.validateMinMaxDate = function(date1, date2, changedfield){
			if(date1 && date2 && date1 > date2 ){
				alert('Revised end date should not be less than start date.');
				$scope.oriMsgCustomFields[changedfield] = "";
			}
		}

		$scope.update();
		
		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView){
				if($scope.editForward && !$scope.isCostOriginator){
					alert('You are not allowed to edit and forward')
					return true;
				}
				if($scope.editForward && $scope.isCostOriginator && !$scope.isAvailforEditAndForward){
					alert('Approval in progress')
					return true;
				}
				if($scope.oriMsgCustomFields.Contract_No){
					$scope.oriMsgCustomFields.ORI_FORMTITLE =  "Amendment to:" +  $scope.oriMsgCustomFields.Contract_No;
				}
				setGropuVisibleValueforPrint();
				setContractAmendmentTotal();
				assignActionToUser(getArrayOfUserbyRole(CONSTANTS_OBJ.COST_ORIGINATOR), CONSTANTS_OBJ.FOR_INFO, CONSTANTS_OBJ.ORI_ACTION_CODE, '');
				updateFormStatus(CONSTANTS_OBJ.OPEN);
				$scope.oriMsgCustomFields.isRespView = 'no';
			}
			if($scope.isRespView){
				if(!$scope.hasResponseAction){
					alert('You are not authorized to response.');
					return true;
				}
				$scope.oriMsgCustomFields.isRespView = 'yes';
				
			}
			return false;
		};
		$window.draftSubmitCallBack = function () {
			if($scope.isOriView){
				if($scope.editForward && !$scope.isCostOriginator){
					alert('You are not allowed to edit and forward')
					return true;
				}
				if($scope.editForward && $scope.isCostOriginator && !$scope.isAvailforEditAndForward){
					alert('Approval in progress')
					return true;
				}
				if($scope.oriMsgCustomFields.Contract_No){
					$scope.oriMsgCustomFields.ORI_FORMTITLE =  "Amendment to:" +  $scope.oriMsgCustomFields.Contract_No;
				}
				setGropuVisibleValueforPrint();
				$scope.oriMsgCustomFields.isRespView = 'no';
			}
			return false;
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}