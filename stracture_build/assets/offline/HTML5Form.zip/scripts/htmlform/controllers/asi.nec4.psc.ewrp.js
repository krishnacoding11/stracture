/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;
        var modelRowIndex = -1;
        $scope.modalData = {};

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        
        $scope.STATIC_OBJ_DATA = {
            Sections: {
                Section_Code: "",
                Section_Name: "",
                Activity_Code: "",
                Activity_Name: "",
                Act_Current_Additions: "0.00",
                Act_Sel: "",
                Act_Dup_Verify:"",
                sec_isSelected: false,
            },
            Impacted_Key_Dates: {
                Key_Date_Id: "",
                Date_Description: "",
                KD_Current_Additions: "",
                Date_Type: "",
                Date_Ref: "",
                KD_Sel: "",
                key_isSelected: false,
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                dist_isSelected: false,
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
            Referenced_Docs: {
                Doc_Hyperlink: "",
                Doc_Description: "",
                doc_isSelected: false,
            },
            Responses: {
                Response_Remarks: "",
                Response_Creator: "",
                Response_Date: "",
                DSI_Is_Old: "New"
            }
        };

        $scope.tableUtilSettings = {
            Impacted_Activities: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: editSectionModal,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: contractTotalOfPriceBreakDown,
                checkboxModelKey: "sec_isSelected",
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all estimate of cost changes?",
                newStaticObject: angular.copy($scope.STATIC_OBJ_DATA.Sections),
                ADD_NEW_BEFORE_TIP: "Insert before cost change estimate",
                ADD_NEW_AFTER_TIP: "Insert after cost change estimate",
                deleteAllRowTooltip: "Remove all cost change estimate",
                deleteCurrRowMsg: "Remove cost change estimate",
                deleteSelectedMsg: "Remove selected cost change estimate"
            },
            Impacted_Key_Dates: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: editKeyModal,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                deleteItemCallBack: setFirstKeyDate,
                checkboxModelKey: "key_isSelected",
                newStaticObject: angular.copy($scope.STATIC_OBJ_DATA.Impacted_Key_Dates),
                ADD_NEW_BEFORE_TIP: "Insert before programme change estimate",
                ADD_NEW_AFTER_TIP: "Insert after programme change estimate",
                deleteAllRowTooltip: "Remove all programme change estimate",
                deleteCurrRowMsg: "Remove programme change estimate",
                deleteSelectedMsg: "Remove selected programme change estimate"
            },
            Auto_Distribute_Users: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: editDistModal,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy($scope.STATIC_OBJ_DATA.Auto_Distribute_Users),
                ADD_NEW_BEFORE_TIP: "Insert before recipient",
                ADD_NEW_AFTER_TIP: "Insert after recipient",
                deleteAllRowTooltip: "Remove all recipients",
                deleteCurrRowMsg: "Remove recipient",
                deleteSelectedMsg: "Remove selected recipient"
            },
            Referenced_Docs: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "doc_isSelected",
                newStaticObject: angular.copy($scope.STATIC_OBJ_DATA.Referenced_Docs),
                ADD_NEW_BEFORE_TIP: "Insert before reference document",
                ADD_NEW_AFTER_TIP: "Insert after reference document",
                deleteAllRowTooltip: "Remove all reference document",
                deleteCurrRowMsg: "Remove reference document",
                deleteSelectedMsg: "Remove selected reference document"
            }
        }
        var NEC4_CONSTANT = {
            restrictedCharMsg: "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #",
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
            priceBreakDown: 'price-breakdown',
            keyContractDates: 'key-contract-dates',
            distribution: 'distribution'
        }

        $scope.openModal = function (viewId, rowData) { // rowData used when user edit row , rowData come from table.util component as param
            modelRowIndex = -1;

            switch (viewId) {
                case NEC4_CONSTANT.priceBreakDown:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                        $scope.setSectionName($scope.modalData, $scope.modalData['Section_Code'],"edit");
                    } else {
                        $scope.modalData = angular.copy($scope.STATIC_OBJ_DATA.Sections);
                    }
                    break;
                case NEC4_CONSTANT.keyContractDates:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        $scope.modalData = angular.copy($scope.STATIC_OBJ_DATA.Impacted_Key_Dates);
                    }
                    break;
                case NEC4_CONSTANT.distribution:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        $scope.modalData = angular.copy($scope.STATIC_OBJ_DATA.Auto_Distribute_Users);
                    }
                    break;
            }

            showModal(viewId)
        }

        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false,
            scrollTop: 0
        };

        function showModal(id) {
            var body = document.body;
            var docElement = document.documentElement;
            ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            // show modal
            ctrl.model.modelId = id;

            $timeout(function(){
                var focusElem = $element.find('[autofocus]');
                focusElem[0] && focusElem[0].focus();
            })
        };

        function hideModal() {
            ctrl.model.modelId = '';

            $timeout(function(){
                var scrollObj = document.body
                if(scrollObj.scrollTop == 0){
                    scrollObj = document.documentElement;
                } 
                 scrollObj.scrollTop = ctrl.model.scrollTop;
            },200)
        }

        function editSectionModal(rowData) {
            $scope.openModal(NEC4_CONSTANT.priceBreakDown, rowData);
        }

        function editKeyModal(rowData) {
            $scope.openModal(NEC4_CONSTANT.keyContractDates, rowData);
        }

        function editDistModal(rowData) {
            $scope.openModal(NEC4_CONSTANT.distribution, rowData);
        }

        function contractTotalOfPriceBreakDown() {
            $timeout(function () {
            $scope.calcFieldTotal({
                repData: $scope.sectionGroup['Impacted_Activities'],
                calcKey: 'Act_Current_Additions',
                parObject: $scope.resMsgCustomFields,
                totalKey: 'Total_Cost_Change'
            });
            }, 200)
        }

        function updateRecord() {
            var rowIndex = modelRowIndex,
                newNode = angular.copy($scope.modalData);

            if (!validateModalForm(ctrl.model.modelId)) {
                $window.alert(NEC4_CONSTANT.mandatoryValMsg);
                return;
            }
            var backUpObject = "",
                index = "",
                isDuplicate = "";
            switch (ctrl.model.modelId) {
                case NEC4_CONSTANT.priceBreakDown:
                    backUpObject = angular.copy($scope.sectionGroup['Impacted_Activities']);
                    if (rowIndex > -1) {
                        $scope.sectionGroup['Impacted_Activities'][rowIndex] = newNode;
                    } else {
                        $scope.sectionGroup['Impacted_Activities'].push(newNode);
                    }
                    if (rowIndex > -1)
                        index = rowIndex;
                    else
                        index = $scope.sectionGroup.Impacted_Activities.length - 1;
                    isDuplicate = $scope.checkDuplicateValue({
                        key: 'Act_Dup_Verify',
                        model: $scope.modalData,
                        index: index,
                        repetObj: $scope.resMsgCustomFields.Cost_Changes.Impacted_Activities,
                        msg: 'Acivity'
                    });
                    if (!isDuplicate) {
                        $scope.sectionGroup['Impacted_Activities'] = angular.copy(backUpObject);
                        $scope.setSectionName($scope.modalData, $scope.modalData['Section_Code']);
                        return;
                    }
                    contractTotalOfPriceBreakDown();
                    break;
                case NEC4_CONSTANT.keyContractDates:
                    if (!validateNumber($scope.modalData)) {
                        return;
                    }
                    backUpObject = angular.copy($scope.keyMilestones['Impacted_Key_Dates']);
                    if (rowIndex > -1) {
                        $scope.keyMilestones['Impacted_Key_Dates'][rowIndex] = newNode;
                    } else {
                        $scope.keyMilestones['Impacted_Key_Dates'].push(newNode);
                    }
                    
                    if (rowIndex > -1)
                        index = rowIndex;
                    else
                        index = $scope.keyMilestones.Impacted_Key_Dates.length - 1;
                    isDuplicate = $scope.checkDuplicateValue({
                        key: 'KD_Sel',
                        model: $scope.modalData,
                        index: index,
                        repetObj: $scope.resMsgCustomFields.Prog_Changes.Impacted_Key_Dates,
                        msg: 'Key Date'
                    });
                    if (!isDuplicate) {
                        $scope.keyMilestones['Impacted_Key_Dates'] = angular.copy(backUpObject);
                        buildKeydatelist();
                        return;
                    }
                    setFirstKeyDate();
                    break;
                case NEC4_CONSTANT.distribution:
                    if (rowIndex > -1) {
                        $scope.autoDistNodes['Auto_Distribute_Users'][rowIndex] = newNode;
                    } else {
                        $scope.autoDistNodes['Auto_Distribute_Users'].push(newNode);
                    }
                    break;
            }
            $timeout(function () {
                hideModal();
            })

        }

        function validateModalForm(modalId) {
            var mandatorySingleFieldArray = [];
            var validaFlag = true;
            switch (modalId) {
                case NEC4_CONSTANT.priceBreakDown:
                    mandatorySingleFieldArray = ['Section_Code', 'Act_Sel', 'Act_Current_Additions'];
                    break;
                case NEC4_CONSTANT.keyContractDates:
                   
                    mandatorySingleFieldArray = ['KD_Sel', 'KD_Current_Additions'];
                    break;
                case NEC4_CONSTANT.distribution:
                    if ($scope.modalData.DS_FORMACTIONS.indexOf("7#") < 0) {
                        mandatorySingleFieldArray = ['DS_PROJDISTUSERS', 'DS_FORMACTIONS', 'DS_ACTIONDUEDATE'];
                    } else {
                        mandatorySingleFieldArray = ['DS_PROJDISTUSERS', 'DS_FORMACTIONS'];
                    }
                    break;
            }

            validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

            function checkFieldValueInObject(objectData, keyArray) {
                var strElem = "";
                for (var index = 0; index < keyArray.length; index++) {
                    var element = keyArray[index];
                    if (element == "DS_ACTIONDUEDATE") {
                        strElem = objectData.ActionDue_Group[element];
                    } else {
                        strElem = objectData[element];
                    }
                    if (!strElem) {
                        return false;
                    }
                }
                return true;
            }
            return validaFlag;
        }
        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        var DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        var DS_ASI_STD_ECC4_NEC_EMP_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_EMP_CONTRACT');
        var DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS');
        var DS_ASI_STD_ECC4_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_CONTRACT');
        var DS_ASI_STD_ECC4_SETUP_SECTIONS = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_SETUP_SECTIONS');
        var DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY');
        var DS_ASI_STD_ECC4_KEY_DATES_SUMMARY = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_KEY_DATES_SUMMARY');
        var DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.DS_ASI_STD_ECC4_IS_USER_CONTRACTOR = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_IS_USER_CONTRACTOR');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        $scope.sectionGroup = $scope.resMsgCustomFields.Cost_Changes;
        $scope.keyMilestones = $scope.resMsgCustomFields.Prog_Changes;
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;
        if (currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            if ($scope.strFormId && $scope.strIsDraft == "NO") {
                $scope.oriMsgFields.DS_AUTODISTRIBUTE = "";
            }
            $scope.resMsgCustomFields.All_Responses.Responses = [];
            addNewRow();
            setContractlist();
            buildRecipientlist();
            buildActionslist();
            setContractorlist();
            setSectionlist();
            buildSectionlist();
            buildKeydatelist();
            if ($scope.strIsDraft == "YES") {
                var chkPermission = strIsUserDraftOnly("draft only");
                if (chkPermission.toLowerCase() == "yes")
                    setSendPermission("Draft");
                else
                    setSendPermission("Send");

                resetAllDates();
            }
        }
        if(currentViewName == "RES_VIEW")
        {
            var chkPermission = strIsUserDraftOnly("draft only");
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
            
            addNewRow();
            $scope.canUserEdit = checkPmResponse() == 'Yes' || strIsUserDraftOnly("emp_others") == 'Yes';
            $scope.resMsgCustomFields.Responder_Name = $scope.dsWorkingUser;
            $scope.oriMsgCustomFields.DSI_Chk_Status = checkPmResponse();
            var strEwnClose = $scope.oriMsgCustomFields.isEWN_Close;
            if (strEwnClose.toLowerCase() == "no") {
                var strStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
                var strFormStatusId = getFormStatusId(strStatus);
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }
        }
        if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var urlObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_CONTRACT, function (val) {
                return val.Value.split('|')[0].trim() == strConAppid.trim();
            });
            if (urlObj.length) {
                $scope.oriMsgCustomFields.Contract_URL = urlObj[0].URL;
            }
        }

        $scope.update();

        function calculateDistDate(days, callback) {
            var strDueDate = "";
            $scope.getServerTime(function (serverDate) {
                if (days) {
                    var d = new Date(serverDate);
                    d.setDate(d.getDate() + parseInt(days));
                    var month = d.getMonth() + 1;
                    var day = d.getDate();
                    strDueDate = d.getFullYear() + '-' +
                        (month < 10 ? '0' : '') + month + '-' +
                        (day < 10 ? '0' : '') + day;
                }
                callback(strDueDate);
            });
        }

        $scope.calcFieldTotal = function (paramObject) {
            var repData = paramObject.repData;
            var calcKey = paramObject.calcKey;
            var parObject = paramObject.parObject;
            var totalKey = paramObject.totalKey;

            var tempTotal = 0;
            for (var index = 0; index < repData.length; index++) {
                var element = repData[index][calcKey];
                tempTotal += (parseFloat(element) || 0);
            }

            parObject[totalKey] = tempTotal.toFixed(2);
        }

        $scope.restrictCharOnlyNumber = function (event) {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190, 109 , 189 , 37 , 39];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(RESTRICT_CHAR_MSG);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }

        }

        $scope.restrictCharOnlyNumberPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                event.preventDefault();
                return false;
            }
        };

        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };

        function setContractlist() {
            if (DS_ASI_STD_ECC4_NEC_EMP_CONTRACT.length) {
                $scope.conData = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_NEC_EMP_CONTRACT.length; i++) {
                    $scope.conData.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_NEC_EMP_CONTRACT[i].Name,
                            modelValue: DS_ASI_STD_ECC4_NEC_EMP_CONTRACT[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.onContractchange = function (conVal) {
            if (conVal) {
                var strParam = conVal.split('|')[0].trim();
                var strAppcode = $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_ASI_STD_ECC4_NEC_CONTRACT_CONTRACTORS, DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS, DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY, DS_ASI_STD_ECC4_KEY_DATES_SUMMARY,DS_ASI_STD_ECC4_SETUP_SECTIONS, DS_ASI_STD_ECC4_NEC_ASITE_DM_USED, DS_ASI_STD_ECC4_NEC_BESPOKE, DS_ASI_STD_ECC4_NEC_REASONCODE, DS_ASI_STD_ECC4_NEC_FUNDINGTYPE,DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASI_STD_ECC4_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_KEY_DATES_SUMMARY",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_SETUP_SECTIONS",
                            "fieldValue": strParam+','+strAppcode
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_ASITE_DM_USED",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_BESPOKE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_REASONCODE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_FUNDINGTYPE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                            "fieldValue": strParam
                        }]
                    }
                };
                $scope.isDataLoaded = false;
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS = angular.fromJson(response.data['DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
                        setContractorlist();

                        DS_ASI_STD_ECC4_SETUP_SECTIONS = angular.fromJson(response.data['DS_ASI_STD_ECC4_SETUP_SECTIONS']).Items.Item;
                        setSectionlist();

                        DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY']).Items.Item;
                        buildSectionlist();

                        DS_ASI_STD_ECC4_KEY_DATES_SUMMARY = angular.fromJson(response.data['DS_ASI_STD_ECC4_KEY_DATES_SUMMARY']).Items.Item;
                        buildKeydatelist();

                        var DS_ASI_GET_CURRENCY_FROM_CONTRACT = angular.fromJson(response.data['DS_ASI_GET_CURRENCY_FROM_CONTRACT']).Items.Item;
                        if (DS_ASI_GET_CURRENCY_FROM_CONTRACT.length) {
                            $scope.formCustomFields.Currency = DS_ASI_GET_CURRENCY_FROM_CONTRACT[0].Value2.trim();
                        }

                        var DS_ASI_STD_ECC4_NEC_ASITE_DM_USED = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_ASITE_DM_USED']).Items.Item;
                        var DS_ASI_STD_ECC4_NEC_BESPOKE = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_BESPOKE']).Items.Item;

                        setAsiteDMUsedFlag(DS_ASI_STD_ECC4_NEC_ASITE_DM_USED);
                        setBespokeContractFlag(DS_ASI_STD_ECC4_NEC_BESPOKE);

                        var chkPermission = strIsUserDraftOnly("draft only");
                        if (chkPermission.toLowerCase() == "yes")
                            setSendPermission("Draft");
                        else
                            setSendPermission("Send");

                        $scope.isDataLoaded = true;
                    }
                });
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim();
                $scope.oriMsgCustomFields.DS_ASI_STD_ECC4_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_ASI_STD_ECC4_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();

                setFormContent();

                if (DS_ASI_STD_ECC4_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }               
            }
        }

        function setContractorlist() {
            if (DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var lstcontractor = commonApi._.filter(DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
                    return val.Value.split('|')[1].trim() == 'Consultant';
                });
                $scope.objContractor = [];
                for (var i = 0; i < lstcontractor.length; i++) {
                    $scope.objContractor.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function setSectionlist() {
            if (DS_ASI_STD_ECC4_SETUP_SECTIONS.length) {
                $scope.objSections = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_SETUP_SECTIONS.length; i++) {
                    $scope.objSections.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_SETUP_SECTIONS[i].Name,
                            modelValue: DS_ASI_STD_ECC4_SETUP_SECTIONS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var strConequences = $scope.oriMsgCustomFields.Consequences;
            var strProbability = $scope.oriMsgCustomFields.Probability;
            var strActionComments = $scope.resMsgCustomFields.Actions_and_Comments;
            var strRRMNotes = $scope.resMsgCustomFields.RRM_Notes;
            var strIncreasePrice = $scope.oriMsgCustomFields.Increase_Price;

            strFormContent = strConAppid + "|" + strConequences + "|" + strProbability + "|" + strActionComments + "|" + strRRMNotes + "|" + strIncreasePrice + "|";

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        $scope.setProbabpercent = function (strVal) {
            var strPercent = "";
            if (strVal) {
                switch (strVal) {
                    case 'Certain':
                        strPercent = "100";
                        break;
                    case 'Very Unlikely':
                        strPercent = "20";
                        break;
                    case 'Very Likely':
                        strPercent = "80";
                        break;
                    case 'Likely':
                        strPercent = "60";
                        break;
                    case 'Unlikely':
                        strPercent = "40";
                        break;
                }
            }
            $scope.oriMsgCustomFields.Probability_Percent = strPercent;
            setFormContent()
        }

        function buildSectionlist() {
            if (DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY.length) {
                $scope.objSectionCode = [];
                var unique = [],
                    strCode = "";
                for (var i = 0; i < DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY.length; i++) {
                    strCode = DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY[i].Value3;
                    if (unique.indexOf(strCode) > -1)
                        continue;
                    else
                        unique.push(strCode);
                    $scope.objSectionCode.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY[i].Value18,
                            modelValue: strCode,
                            checked: false
                        }]
                    });
                }
            }
        }
        $scope.setSectionName = function (currObj, strVal , strOpenfrom) {

            var strSecname = commonApi._.filter(DS_ASI_STD_ECC4_NEC_CONTRACT_ACTIVITY_SUMMARY, function (val) {
                return val.Value3 == strVal;
            });
            if (strSecname.length) {
                currObj.Section_Name = strSecname[0].Value4.trim();
            }
            if (!strOpenfrom) {
                currObj.Act_Sel = "";
            }
            buildActivitylist(strSecname);
        }

        function buildActivitylist(strSecname) {
            $scope.objActivity = [];
            for (var i = 0; i < strSecname.length; i++) {
                $scope.objActivity.push({
                    optlabel: "",
                    options: [{
                        displayValue: strSecname[i].Value14,
                        modelValue: strSecname[i].Value14,
                        checked: false
                    }]
                });
            }
        }

        function buildKeydatelist() {
            if (DS_ASI_STD_ECC4_KEY_DATES_SUMMARY.length) {
                $scope.objKeydate = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_KEY_DATES_SUMMARY.length; i++) {
                    $scope.objKeydate.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_KEY_DATES_SUMMARY[i].Name,
                            modelValue: DS_ASI_STD_ECC4_KEY_DATES_SUMMARY[i].Value2,
                            checked: false
                        }]
                    });
                }
            }
        }

        function buildRecipientlist() {
            if (DS_PROJDISTUSERS.length) {
                $scope.objRecipients = [];
                for (var i = 0; i < DS_PROJDISTUSERS.length; i++) {
                    $scope.objRecipients.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_PROJDISTUSERS[i].Name,
                            modelValue: DS_PROJDISTUSERS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function buildActionslist() {
            if (DS_FORMACTIONS.length) {
                $scope.objActions = [];
                for (var i = 0; i < DS_FORMACTIONS.length; i++) {
                    $scope.objActions.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_FORMACTIONS[i].Name,
                            modelValue: DS_FORMACTIONS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.setActivitydata = function (currObj, strVal) {
            currObj.Activity_Name = strVal.split('|')[1].trim();
            currObj.Activity_Code = strVal.split('|')[0].trim();
            var strseccode = currObj.Section_Code;
            currObj.Act_Dup_Verify = strseccode + '|' + currObj.Activity_Code;
        }

        $scope.setKeydatedata = function (currObj, strVal) {

            var objKeydata = commonApi._.filter(DS_ASI_STD_ECC4_KEY_DATES_SUMMARY, function (val) {
                return val.Value2 == strVal;
            });
            if (objKeydata.length) {
                currObj.Key_Date_Id = strVal;
                currObj.Date_Description = objKeydata[0].Value3;
                currObj.Date_Type = objKeydata[0].Value7;
                currObj.Date_Ref = objKeydata[0].Value8;
            } else {
                currObj.Date_Description = "";
            }
        }

        $scope.onSectionChange = function (strVal) {
            if (strVal) {
                $scope.oriMsgCustomFields.Distribution_Section.Dist_Section_Code = strVal.split('|')[0].trim();
            }
            var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": "DS_ASI_STD_ECC4_SECTION_USERS,DS_ASI_STD_ECC4_SEC_LCK",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_ASI_STD_ECC4_SECTION_USERS",
                        "fieldValue": strParam
                    }, {
                        "fieldName": "DS_ASI_STD_ECC4_SEC_LCK",
                        "fieldValue": strParam
                    }]
                }
            };
            $scope.isSectionLoaded = false;
            $scope.getCallbackData(form).then(function (response) {
                if (response.data) {
                    var DS_ASI_STD_ECC4_SECTION_USERS = angular.fromJson(response.data['DS_ASI_STD_ECC4_SECTION_USERS']).Items.Item;
                    var DS_ASI_STD_ECC4_SEC_LCK = angular.fromJson(response.data['DS_ASI_STD_ECC4_SEC_LCK']).Items.Item;
                    if (DS_ASI_STD_ECC4_SEC_LCK.length) {
                        $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = DS_ASI_STD_ECC4_SEC_LCK[0].Name.trim();
                    }
                    $scope.oriMsgFields.DS_AUTODISTRIBUTE = "3"
                    $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    var strTouser = $scope.oriMsgFields.DS_PROJUSERS_ROLE_TEMP;
                    var struser = strTouser.split('|')[2].trim();
                    var iAutodistId = 1;
                    setAutoDistribution(struser, "7#For Information", "", iAutodistId, "");
                    setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS, iAutodistId);
                }
            });
        }
        var iCount = 0;

        function setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS, iAutodistId) {
            if (DS_ASI_STD_ECC4_SECTION_USERS.length) {
                var strValue = "",
                    strAction = "",
                    strDueDays = "",
                    strDate = "";
                strValue = DS_ASI_STD_ECC4_SECTION_USERS[iCount].Value.split('|');
                strAction = strValue[2].trim() + "#" + strValue[3].trim();
                strDueDays = strValue[4].split('#')[0].trim();
                calculateDistDate(strDueDays, function (retdate) {
                    strDate = retdate
                    var strDistusersp = setRecipientUser(strValue[0].trim());
                    if (strCheckAction(strValue[2].trim()).trim() == "1") {
                        iAutodistId = parseInt(iAutodistId) + 1;
                        setAutoDistribution(strDistusersp, strAction, strDate, iAutodistId, strDueDays);
                    }
                    iCount++;
                    if (iCount < DS_ASI_STD_ECC4_SECTION_USERS.length)
                        setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS);
                    else
                        $scope.isSectionLoaded = true;
                });
            } else
                $scope.isSectionLoaded = true;
        }

        function setRecipientUser(strUserid) {
            var usersObj = commonApi._.filter(DS_PROJDISTUSERS, function (val) {
                return val.Value.trim().indexOf(strUserid) > -1;
            });
            if (usersObj.length) {
                return usersObj[0].Value.trim();
            }
            return "";
        }

        function strCheckAction(strActionId) {
            var strFound = "0";
            var actionsObj = commonApi._.filter(DS_FORMACTIONS, function (val) {
                return val.Value.trim().indexOf(strActionId) > -1;
            });
            if (actionsObj.length) {
                strFound = "1";
            }
            return strFound;
        }

        function setAutoDistribution(strUser, strAction, strDueDate, iAutodistId, strDueDays) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy($scope.STATIC_OBJ_DATA.Auto_Distribute_Users)
            structDistribution.AutoDist_Id = iAutodistId;
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.ActionDue_Group.DS_ACTIONDUEDATE = strDueDate;
            structDistribution.ActionDue_Group.DS_DUEDAYS = strDueDays;

            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
        }

        function strIsUserDraftOnly(strVal) {
            if (DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == strVal) {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }

        function setAsiteDMUsedFlag(DS_ASI_STD_ECC4_NEC_ASITE_DM_USED) {
            var strXmlIsDMUsed = "YES";
            if (DS_ASI_STD_ECC4_NEC_ASITE_DM_USED.length) {
                strXmlIsDMUsed = DS_ASI_STD_ECC4_NEC_ASITE_DM_USED[0].Name.trim();
            }
            $scope.oriMsgCustomFields.isAsiteDMUsed = strXmlIsDMUsed;
        }

        function setBespokeContractFlag(DS_ASI_STD_ECC4_NEC_BESPOKE) {
            var strXmlBContract = "NO"
            if (DS_ASI_STD_ECC4_NEC_BESPOKE.length) {
                strXmlBContract = DS_ASI_STD_ECC4_NEC_BESPOKE[0].Value1.trim();
            }
            $scope.formCustomFields.Bespoke_Contract.Access_Based = strXmlBContract;
        }

        function resetAllDates() {
            var distNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users;
            if (distNodes.length) {
                var strDays = "",
                    strDueDate = "";
                for (var i = 0; i < distNodes.length; i++) {
                    strDays = distNodes[i].ActionDue_Group.DS_DUEDAYS;
                    if (strDays) {
                        calculateDistDate(strDays, function (retdate) {
                            strDueDate = $scope.formatDate(new Date(retdate), 'yy-mm-dd');
                            distNodes[i].ActionDue_Group.DS_ACTIONDUEDATE = strDueDate;
                        });
                    }
                }
            }
        }

        $scope.onActionDueDateChange = function () {

            var strMsgFlag = "";
            var strDraftMsg = "";
            strMsgFlag = validatePastDate();
            if (strMsgFlag == "1") {
                strDraftMsg = "2|WARNING! You have assigned a past date to a review draft action.  Please click Cancel to select a date in the future or click OK and the action will be cleared when the draft version of the form is saved.";
            } else {
                strDraftMsg = "0"
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_DRAFT_MSG = strDraftMsg;
        }

        function validatePastDate() {
            var strMsgFlag = "0";
            var distNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users;
            var strDueDate = "",
                strFormActions = "",
                strDatediff = "";
            var strtodaydate = $scope.parseDate("yy-mm-dd", $scope.todayDateDbFormat);
            if (distNodes.length) {
                for (var i = 0; i < distNodes.length; i++) {
                    strFormActions = distNodes[i].DS_FORMACTIONS;
                    if (strFormActions && strFormActions.split('#')[1].trim().toLowerCase() == "review draft") {
                        strDueDate = distNodes[i].ActionDue_Group.DS_ACTIONDUEDATE;
                        if (strDueDate) {
                            strDueDate = $scope.parseDate("yy-mm-dd", strDueDate);
                            strDatediff = (strDueDate - strtodaydate) / 1000 / 60 / 60 / 24;
                            if (strDatediff < 0)
                                strMsgFlag = "1";
                        }
                    }

                }
            }
            return strMsgFlag;
        }

        function setFormContent2() {
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = $scope.resMsgCustomFields.Total_Cost_Change;
        }

        function setFormContent3() {
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = $scope.resMsgCustomFields.Total_Programme_Change;
        }

        $scope.onPriceincreaseChanged = function (strVal) {
            if (strVal == 'Yes') {
                $scope.oriMsgCustomFields.Increase_Price = "Yes";
            } else {
                $scope.oriMsgCustomFields.Increase_Price = "No";
            }
        }

        function validateNumber(modaldata) {
            var strVal = modaldata.KD_Current_Additions;
            if (strVal && isNaN(strVal)) {
                alert("Please Enter only numbers");
                strVal = "";
                return false;
            }
            return true;
        }

        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var statudObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        function addNewRow() {
            $scope.getServerTime(function (serverDate) {
                var insertPoint = $scope.resMsgCustomFields.All_Responses.Responses;
                for (var index = 0; index < insertPoint.length; index++) {
                    insertPoint[index].DSI_Is_Old = "Old";
                }
                var structResponses = angular.copy($scope.STATIC_OBJ_DATA.Responses);
                structResponses.Response_Creator = $scope.dsWorkingUser;
                structResponses.Response_Date = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
                insertPoint.push(structResponses);
            });
        }

        function checkPmResponse() {
            var strIsPm = "No";
            if ($scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId) {
                strIsPm = "Yes";

            } else {
                strIsPm = strIsUserDraftOnly("service manager");
            }

            return strIsPm;
        }

        function setFirstKeyDate() {
            var strFirstkey = "";
            var keysObj = commonApi._.filter($scope.keyMilestones['Impacted_Key_Dates'], function (val) {
                return val.Key_Date_Id.trim() == '1';
            });
            if (keysObj.length) {
                strFirstkey = keysObj[0].KD_Current_Additions;
            }
            $scope.resMsgCustomFields.Total_Programme_Change = strFirstkey;
        }

        $scope.setFinalStatus = function (strValue) {
            var strFormStatusId = "";
            var strstatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
            if (strValue == 'yes' && confirm("Please Click ok to close the form")) {
                if (strstatus.toLowerCase() == 'open') {
                    strFormStatusId = getFormStatusId("Closed");
                } else if (strstatus.toLowerCase() != 'open') {
                    strFormStatusId = getFormStatusId("Closed-CE-Referred");
                }
            } else {
                strFormStatusId = getFormStatusId(strstatus);
                $scope.oriMsgCustomFields.isEWN_Close = 'no';
            }
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }
        $window.ewnpFinalCallBack = function () {
          
            if (currentViewName == "ORI_VIEW") {

                if($scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE < $scope.todayDateDbFormat)
                {
                    alert("Close due Date cannot be less then today date");
                    return true;
                }
                if ($scope.oriMsgCustomFields.Price_Inc == "No" && $scope.oriMsgCustomFields.Delay_Completion == "No" && $scope.oriMsgCustomFields.Impair_Performance == "No" && $scope.oriMsgCustomFields.Delay_Meeting == "No" && $scope.oriMsgCustomFields.Work_employer == 'No' && $scope.oriMsgCustomFields.breach_consent == "No" && $scope.oriMsgCustomFields.party_costs == "No" && $scope.oriMsgCustomFields.defined_cost == "No") {
                    alert("Select Atleast one event");
                    return true;
                }

                var strFormStatusId = getFormStatusId("Open");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }
                setFormContent2();
            setFormContent3();
            setFormContent();
            return false;
        }
        $scope.isValidForm = true;
        $window.customHTMLMethodAfterValidationError = function(){
            $scope.isValidForm = false;
        }
    }
    return FormController;
});

function customHTMLMethodAfterValidationError(){}

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof ewnpFinalCallBack !== "undefined") {
        return ewnpFinalCallBack();
    }
}