/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', 'mainModule', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController, mainModule) {
    'use strict';
    mainModule.filter('startFrom', function () {
        return function (input, start) {
            if (!input || input.length === undefined)
                return [];

            start = +start;
            if (input.length < start) {
                return input.slice(input.length);
            } else {
                return input.slice(start);
            }
        }
    });
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), NEC4_CONSTANT.yymmdddateformate);
        });

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        $scope.isDataLoaded = true;
        $scope.currentPage = 0;
        $scope.currentPageLine = 0;
        $scope.currentPageWH = 0;
        $scope.currentPageLineWH = 0;
        $scope.pageSize = '20';
        $scope.isValidateDataLoaded = true;
        $scope.isSectionShow = true;
        $scope.isdateSectionShow = true;
        $scope.isdateSectionShowPM = true;
        $scope.isnoACtion = true;
        $scope.isNotDisplayInavlidUser = false;
        $scope.validateErrorArray;
        $scope.validateSourceErrorArray;
        $scope.validateObj = {
            validateError: '',
            validateSourceError: '',
            validateForecast: '',
        };
        $scope.isDataImportedSuccess = false;
        $scope.isSideBarOpen = true;
        $scope.currentOriTab = 'basic-detail.html';
        $scope.mappingList = [];
        $scope.mappingListWH = [];
        $scope.mappingListActivity = [];
        $scope.filterFieldObj = {
            fltWBSElement: '',
            fltCostCode: '',
            fltWBSElementAct: ''
        };
        $scope.objCostCodeOneDesc = [];
        $scope.objCostCodeTwoDesc = [];
        $scope.objReportCodeThreeDesc = [];
        $scope.objWBSElement = [];
        $scope.isPM = false;
        $scope.isQS = false;
        $scope.isDraftPM = false;

        var LineLevel_Group = {
            WBSElement: "",
            Period: "",
            SourceID: "",
            Costtype: "",
            Contractor_Cost_Code: "",
            Contractor_Cost_CodeDesc: "",
            Supplier: "",
            Description: "",
            PostedDate: "",
            Quantity: "",
            LineValue: "0",
            NotesOne: "",
            NotesTwo: "",
            NotesThree: "",
            Agreed_Cost: "0",
            Linewise_Status: "",
            PreviousAFP_Value: "",
            Comment: "",
            LineLevel_GUID: "",
            Ref_CCT_GUID: "",
            LineReportCodeThree: "",
            LineCostCodeTwo: "",
            LineCurrHighlight: "0",
            LineSPHighlight: "0",
            LineIsRemarks: "0"
        }
        var CostCodeTwo_Group = {
            CCWBSElement: "",
            CCReportCodeThree: "",
            CostCodeTwo: "",
            CostCodeTwoDesc: "",
            TotalCostCOdeTwo: "0",
            TotalCostCOdeTwoWithDis: "0",
            TotalDisCostCOdeTwo: "0",
            WitheldDisCostCOdeTwo: "0",
            CCT_GUID: "",
            Ref_RCD3_GUID: "",
            CCTShow: false,
            CCTCurrHighlight: "0",
            CCTSPHighlight: "0",
            CCTIsRemarks: "0",
            LineLevelAllGroup: {
                LineLevelGroup: [LineLevel_Group]
            }
        }
        var WH_LineLevel_Group = {
            WH_WBSElement: "",
            WH_Period: "",
            WH_SourceID: "",
            WH_Costtype: "",
            WH_Contractor_Cost_Code: "",
            WH_Contractor_Cost_CodeDesc: "",
            WH_Supplier: "",
            WH_Description: "",
            WH_PostedDate: "",
            WH_Quantity: "",
            WH_LineValue: "",
            WH_NotesOne: "",
            WH_NotesTwo: "",
            WH_NotesThree: "",
            WH_LineReportCodeThree: "",
            WH_LineCostCodeTwo: "",
            WH_submitted_Cost: "",
            WH_Pending_Cost: "",
            WH_Agreed_Cost: "0",
            WH_Linewise_Status: "",
            WH_PreviousAFP_Value: "",
            WH_LineComment: "",
            WH_LineLevel_GUID: "",
            WH_Ref_CCT_GUID: "",
            WH_SPHighlight: "0",
            WH_CurrHighlight: "0",
            WH_LineIsRemarks: "0"
        }
        var WH_CostCodeTwo_Group = {
            WH_CCWBSElement: "",
            WH_CCReportCodeThree: "",
            WH_CostCodeTwo: "",
            WH_CostCodeTwoDesc: "",
            WH_TotalCostCOdeTwo: "",
            WH_TotalCostCOdeTwoActual: "",
            WH_TotalCostCOdeTwoSubmit: "",
            WH_TotalCostCOdeTwoPending: "",
            WH_CCT_GUID: "",
            WH_Ref_RCD3_GUID: "",
            WH_CCTShow: false,
            WH_CCTSPHighlight: "0",
            WH_CCTCurrHighlight: "0",
            WH_CCTIsRemarks: "0",
            WH_LineLevelAllGroup: {
                WH_LineLevelGroup: [WH_LineLevel_Group]
            }

        }
        var OPTACONTRACT_ACTIVITIES = {
            OptA_RefWBSElement: "",
            OptA_RefWBSElement_Name: "",
            OptActivity_Code: "",
            OptActivity_Name: "",
            OptActivity_Value: "0",
            OptActivity_Status: "",
            OptActivity_Comment: "",
            Ref_OptAWBSElement_Guid: "",
            OptActivity_Guid: ""
        }

        var STATIC_OBJ_DATA = {
            WH_Pages: {
                WH_Page_Range: ""
            },
            WH_ReportCodeGroup:
            {
                WH_ReportWbsElement: "",
                WH_ReportWbsName: "",
                WH_ReportCodeThree: "",
                WH_ReportCodeThreeDesc: "",
                WH_TotalReportCodeThree: "",
                WH_TotalReportCodeThreeActual: "",
                WH_TotalReportCodeThreeSubmit: "",
                WH_TotalReportCodeThreePending: "",
                WH_RCD3_GUID: "",
                WH_RCTShow: false,
                WH_RPSPHighlight: "0",
                WH_RPCurrHighlight: "0",
                WH_RPIsRemarks: "0",
                WH_CostCodeTwoAllGroup: {
                    WH_CostCodeTwoGroup: [WH_CostCodeTwo_Group]
                }
            },
            WH_CostCodeTwoGroup: WH_CostCodeTwo_Group,
            WH_LineLevelGroup: WH_LineLevel_Group,
            Pages: {
                Page_Range: ""
            },
            ReportCodeGroup:
            {
                ReportWbsElement: "",
                ReportWbsName: "",
                ReportCodeThree: "",
                ReportCodeThreeDesc: "",
                TotalReportCodeThree: "0",
                TotalReportCodeThreeWithDis: "0",
                TotalDisReportCodeThree: "0",
                WitheldDisReportCodethree: "0",
                RCD3_GUID: "",
                RCTShow: false,
                RPCurrHighlight: "0",
                RPSPHighlight: "0",
                RPIsRemarks: "0",
                CostCodeTwoAllGroup: {
                    CostCodeTwoGroup: [CostCodeTwo_Group]
                }
            },
            CostCodeTwoGroup: CostCodeTwo_Group,
            LineLevelGroup: LineLevel_Group,
            IMP_Summary_Data: {
                IMP_Sum_WBSElement: "",
                IMP_Sum_WBSElement_Name: "",
                IMP_Summary_Value: "",
                Target_Price: "",
                Previous_AFP_Data: "",
                Disallowed_Data: "",
                PriceofWorkDonetoDate: "",
                Other_Amount_AssessedByPM: "",
                Comment_AssessedByPM: "",
                Prev_Other_Amount_AssessedByPM: "",
                Prev_Comment_AssessedByPM: "",
                finalPriceofWorkDonetoDate: "",
                Other_Amount_PaidByPM: "",
                Comment_PaidByPM: "",
                PWDDNoFirstProgramme: "",
                PWDDNoFirstProgramme_Amt: "",
                PWDDLastAcceptedProg: "",
                PWDDLastAcceptedProg_Amt: "",
                PWDDNoBaseForeActual: "",
                PWDDNoBaseForeActual_Amt: "",
                PWDDNoPreConstruction: "",
                PWDDNoPreConstruction_Amt: "",
                PWDDNoConstruction: "",
                PWDDNoConstruction_Amt: "",
                NoHealthandSafety: "",
                NoHealthandSafety_Amt: "",
                NoOandMFile: "",
                DelayDamages: "",
                OtherDeductions: "",
                OtherDeductionComment: "",
                TotalLessAmount: "",
                HistoricPaidtoDate:"",
                PaidtoDate: "",
                PaymentDue: "",
                PreviousAmountAdjusted: "",
                Certified: "",
                ExternallyReceived: "",
                PreviousExternallyReceived: "",
                CertifiedSubTotal: "",
                AmountAdjusted: "",
                UnrecoveredAmount: "",
                Receipted: "",
                Summary_GUID: "",
                QS_Draft_Comment: ""
            },
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_ACTIONDUEDATE: "",
                DS_FORMACTIONS: ""
            },
            Auto_Complete_msg_Action: {
                DS_MSG_AC_TYPE: "",
                DS_MSG_AC_FORM: "",
                DS_MSG_AC_MSG_TYPE: "",
                DS_MSG_AC_USERID: "",
                DS_MSG_AC_ACTION: "",
                DS_MSG_AC_ACTION_REMARKS: ""
            },
            IMP_AFP_Data: {
                IMP_WBSElement: "",
                IMP_Period: "",
                IMP_SourceID: "0",
                IMP_Costtype: "0",
                IMP_Contractor_Cost_Code: "0",
                IMP_Contractor_Cost_CodeDesc: "",
                IMP_Supplier: "",
                IMP_Description: "",
                IMP_PostedDate: "",
                IMP_Quantity: "",
                IMP_Value: "",
                IMP_NotesOne: "",
                IMP_NotesTwo: "",
                IMP_NotesThree: "",
                IMP_GUID: ""
            },
            OptionADetails: {
                OptAWBSElement_Code: "",
                OptAWBSElement_Name: "",
                OptAWBSElement_Total: "",
                OptAWBSElement_Guid: "",
                OptActivity_Group: {
                    OptAContract_Activities: [OPTACONTRACT_ACTIVITIES]
                }
            },
            OptAContract_Activities: OPTACONTRACT_ACTIVITIES
        };

        var NEC4_CONSTANT = {
            appforpayment: 'Application for Payment',
            finalappforpayment: 'Final Application for Payment',
            appforpaymentfurtherwork: 'Application of Payment for Further works',
            yymmdddateformate: 'yy-mm-dd',
            draftstring: 'Draft',
            sendstring: 'Send',
            qsRole: 'NEC-ECC-Quantity Surveyor',
            poDetail: 'po-detail',
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
        }

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.afpDetails = $scope.formCustomFields["AFP_Details"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.impAFPGroup = $scope.afpDetails['IMP_AFP_Group'];
        $scope.reportCodeAllGroup = $scope.afpDetails['ReportCodeAllGroup'];
        $scope.whreportCodeAllGroup = $scope.afpDetails['WH_ReportCodeAllGroup'];
        $scope.impsummaryGroup = $scope.afpDetails['IMP_Summary_Group'];
        $scope.impsummaryData = $scope.impsummaryGroup['IMP_Summary_Data']
        $scope.paymentcertificate = $scope.oriMsgCustomFields['Payment_Certificate'];
        $scope.totalofdamage;
        $scope.OptionAgroup = $scope.afpDetails['OptionA_Group'];

        var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var ds_incomplete_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var ds_Workinguser_All_Roles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var ds_Asi_stw_Ecc4_Stw_Linelevel_All_Data = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_LINELEVEL_ALL_DATA");
        var ds_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA");
        var ds_ASI_STD_ECC4_STW_ReportCodethree_Level_Data = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_REPORTCODETHREE_LEVEL_DATA");
        var ds_Asi_Std_Eec4_STW_WBSELEMENTWISE_SUMMARY_DATA = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_WBSELEMENTWISE_SUMMARY_DATA");
        var ds_ASI_STD_ECC4_STW_ReportCodethree_Withheld_Level_Data = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_REPORTCODETHREE_WITHHELD_LEVEL_DATA");
        var dS_ASI_STD_ECC4_STW_CostCodeTwo_Withheld_Level_Data = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_COSTCODETWO_WITHHELD_LEVEL_DATA");
        var dS_ASI_STD_ECC4_STW_Linelevel_Withheld_All_Data = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_LINELEVEL_WITHHELD_ALL_DATA");
        var ds_ASI_STD_ECC4_STW_DISPLAYORIGINALDATA = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_DISPLAYORIGINALDATA");
        var ds_ASI_STD_ECC4_STW_DISPLAYORIGINAL_ACTIVITYDATA = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_DISPLAYORIGINAL_ACTIVITYDATA");
        var ds_ASI_STD_ECC4_STW_VERIFY_DRAFT_RESPONCES_DATA = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_VERIFY_DRAFT_RESPONCES_DATA");
        var ds_ASI_STD_ECC4_STW_WBSELEMENTLISTACTIVITYWISE = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_WBSELEMENTLISTACTIVITYWISE");
        var ds_asi_std_ecc4_all_contract_team_members = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS");
        var ds_ASI_STD_ECC4_STW_ContractandAFP_Pview_Details = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_CONTRACTANDAFP_PVIEW_DETAILS");
        var dS_ASI_STD_ECC4_STW_Child_Form_Action_Details = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_CHILD_FORM_ACTION_DETAILS");

        var strisDraft_Res_msg = $scope.oriMsgFields['DS_ISDRAFT_RES_MSG'];
        var strMSGid, strMsgidWh;
        var strisDraft_Res = $scope.oriMsgFields['DS_ISDRAFT_RES'];
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW" || currentViewName == "ORI_PRINT_VIEW_HTML" || currentViewName == "RES_PRINT_VIEW_HTML") {
            angular.element('.export-btn').hide();
            if (currentViewName == "RES_PRINT_VIEW") {
                setprintviewcommoindata();
                setSPdataonRESonLoad();
                isPMworkinguser();
                $scope.mappingListActivity = $scope.OptionAgroup['OptionADetails'];
            }
            if (currentViewName == "ORI_PRINT_VIEW") {
                setprintviewcommoindata();
                if ($scope.oriMsgCustomFields['DSI_OptionType'].indexOf("Option A") > -1) {
                    mapCostCodes();
                    if ($scope.oriMsgCustomFields['Application_for_Payment_Type'] == NEC4_CONSTANT.finalappforpayment) {
                        fillOriginaldata();
                        filterOriginaldata(event, '', 'All');
                    }
                }
                else {
                    fillOriginaldata();
                    filterOriginaldata(event, '', 'All');
                }
                $scope.currentOriTab = $scope.oriMsgCustomFields['DSI_OptionType'].indexOf('Option A') > -1 ? 'activity-detail.html' : 'wbs-detail.html';
            }
        }
        if (currentViewName == "RES_VIEW") {
            //set stage
            $scope.oriMsgCustomFields['DSI_Currentstage'] = $scope.oriMsgCustomFields['DSI_Nextstage'];
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
            $scope.isnoACtion = true;

            //check action is pending or not
            var isrequired = checkPendingAction(dsWorkingUserId);
            if (!isrequired) {
                $scope.isnoACtion = false;
            }
            else {
                //call contrcat team sp
                onContractchange();
                if (ds_Workinguser_All_Roles) {
                    if (ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-quantity surveyor") != -1) {
                        $scope.isQS = true;
                    }
                }
                isPMworkinguser();

                isDraftValidationForPM_QS();
                setSPdataonRESonLoad();
                //set label for print view
                if ($scope.isQS) {
                    $scope.oriMsgCustomFields['formlabel'] = 'QS Payment Assessment';
                }
                else if ($scope.isPM) {
                    $scope.oriMsgCustomFields['formlabel'] = 'PM Payment Assessment';
                }
            }
        }
        //set ori print view common fields
        function setprintviewcommoindata() {
            if (ds_ASI_STD_ECC4_STW_ContractandAFP_Pview_Details.length) {
                var lst = ds_ASI_STD_ECC4_STW_ContractandAFP_Pview_Details;

                // COntractCOde#COntarctURL#AFPcode#AFPURL#COntractorlogo#CLientlogo#
                //DS_ASI_STD_ECC4_STW_ContractandAFP_Pview_Details
                $scope.oriMsgCustomFields.Contract_Code = lst[0].Value7.trim();
                $scope.oriMsgCustomFields.Contract_No = lst[0].Value1.trim();
                $scope.oriMsgCustomFields.AFP_Code = lst[0].Value3.trim();
                $scope.formCustomFields.Contractor_Logo = lst[0].Value5.trim();
                $scope.formCustomFields.Client_Logo = lst[0].Value6.trim();
                $scope.oriMsgCustomFields.Contract_URL = lst[0].URL2.trim();
                $scope.oriMsgCustomFields.AFP_URL = lst[0].URL4.trim();
            }
        }
        //set tabs
        $scope.setCurrentSection = setCurrentSection;

        function setCurrentSection(tabURL) {
            if ($scope.currentOriTab == tabURL) {
                return false;
            };
            $scope.currentOriTab = tabURL;
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 500);
        };

        //set side bar
        $scope.setSideBar = function () {
            $scope.isSideBarOpen = !$scope.isSideBarOpen;
        };

        //set res data on load
        function setSPdataonRESonLoad() {
            if (strisDraft_Res_msg == "NO") {
                setOnLoadDetaildata();
            }
            if (currentViewName == "RES_PRINT_VIEW") {
                setDraftTargetpriceResprint();
            }
            if (currentViewName == "RES_VIEW") {
                setOnloadSummarywithLess();
                mapCostCodes();
            }
            filterOriginaldata(event, '', 'All');
            if ($scope.oriMsgCustomFields['DSI_OptionType'].indexOf("Option A") == -1) {
                // withheld data
                if (strisDraft_Res_msg == "NO") {
                    setOnLoadwithhelddata();
                }
                filterWHdata(event, '', 'All');
            }
        }
        function onContractchange() {
            var strParam = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT'];
            if (strParam) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }]
                    }
                };
                $scope.isDataLoaded = false;
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        $scope.isDataLoaded = true;
                        ds_asi_std_ecc4_all_contract_team_members = angular.fromJson(response.data['DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
                        var is_Draftpm = strIsUserDraftOnly("Emp_Others");
                        if (is_Draftpm == 'Yes') {
                            $scope.isDraftPM = true;
                            $scope.oriMsgCustomFields['formlabel'] = 'Draft Payment Assessment';
                        }
                        else {
                            $scope.isDraftPM = false;
                        }
                       /* if draft only user tried to respond or create then its not allowed
                        var strchkPermission = strIsUserDraftOnly("draft only");
                        if (strchkPermission.toLowerCase() == "yes")
                            setSendPermission(NEC4_CONSTANT.draftstring);
                        else
                            setSendPermission(NEC4_CONSTANT.sendstring); */
                        validateDate();
                    }
                });
            }
        }
        function strIsUserDraftOnly(strVal) {
            if (ds_asi_std_ecc4_all_contract_team_members.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < ds_asi_std_ecc4_all_contract_team_members.length; i++) {
                    strValue = ds_asi_std_ecc4_all_contract_team_members[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == strVal.toLowerCase()) {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }
        function setSendPermission(strVal) {

            if (strVal.toLowerCase() == "draft") {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| You are Draft only user so you are not authorized to create or draft the form so please click on Cancel button to exit.";
            }
        }

        //#region Withheld Tab
        function setOnLoadwithhelddata() {
            var lst = ds_ASI_STD_ECC4_STW_ReportCodethree_Withheld_Level_Data;
            $scope.whreportCodeAllGroup['WH_ReportCodeGroup'] = [];
            if (lst && lst.length) {
                for (var i = 0; i < lst.length; i++) {
                    var guid = commonApi.guId();
                    var strctafpdata = angular.copy(STATIC_OBJ_DATA.WH_ReportCodeGroup)

                    strctafpdata.WH_ReportWbsElement = lst[i].Value1;
                    strctafpdata.WH_ReportWbsName = lst[i].Value2;
                    strctafpdata.WH_ReportCodeThree = lst[i].Value3;
                    strctafpdata.WH_ReportCodeThreeDesc = lst[i].Value4;
                    strctafpdata.WH_TotalReportCodeThreeActual = lst[i].Value5;
                    strctafpdata.WH_TotalReportCodeThreeSubmit = lst[i].Value6;
                    strctafpdata.WH_TotalReportCodeThreePending = lst[i].Value7;
                    strctafpdata.WH_RCD3_GUID = guid;
                    strctafpdata.WH_RPSPHighlight = lst[i].Value8; //highlight flag
                    strctafpdata.WH_TotalReportCodeThree = lst[i].Value9;
                    strMsgidWh = lst[i].Value10;
                    $scope.whreportCodeAllGroup['WH_ReportCodeGroup'].push(strctafpdata);
                }
            }
        }
        $scope.showHideCodeWH = showHideCodeWH;
        function showHideCodeWH(currObj, strType) {
            if (strType == 'ReportCodeWH') {
                //verify node  is already in main xml or not
                var straddednode = false;
                //hide all nodes and display only clicked one
                var strHidedata = $scope.mappingListWH;
                if (strHidedata.length > 0) {
                    for (var i = 0; i < strHidedata.length; i++) {
                        strHidedata[i].WH_RCTShow = false;
                    }
                }
                //show only current node
                currObj.WH_RCTShow = true;

                //verify current node is already exist or not in main node
                if (currentViewName == "RES_VIEW" || (currentViewName == "RES_PRINT_VIEW" && strisDraft_Res_msg == "YES")) {
                    var strverify = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                    var strcheckReportdata = mappingReportCode(strverify, currObj.WH_ReportWbsElement, currObj.WH_ReportCodeThree, 'WH');
                    if (strcheckReportdata.length > 0) {
                        var strcheckcostcode = strcheckReportdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                        if (strcheckcostcode.length > 0) {
                            var verifyval = strcheckcostcode[0].WH_CostCodeTwo;
                            if (verifyval != '' && verifyval != '0') {
                                straddednode = true;
                            }
                        }
                    }
                }
                //add node as per condition
                if (straddednode) {
                    //if node exist in main node then add node from main xml node
                    setCostCodeNodesWH(strcheckcostcode, currObj, 'xmlVal');
                    $scope.currentPageWH = 0;
                    $scope.paginationArrayWH = $scope.getPaginationArray(currObj['WH_CostCodeTwoAllGroup']['WH_CostCodeTwoGroup'].length, $scope.pageSize);

                }
                else {
                    //if not exist then its new node and add node from sp

                    var strparam = currObj.WH_ReportWbsElement + '$$' + currObj.WH_ReportCodeThree + '$$' + strMsgidWh;
                    var form = {
                        "projectId": projectId,
                        "formId": formId,
                        "fields": "DS_ASI_STD_ECC4_STW_COSTCODETWO_WITHHELD_LEVEL_DATA",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_ASI_STD_ECC4_STW_COSTCODETWO_WITHHELD_LEVEL_DATA",
                                "fieldValue": strparam
                            }]
                        }
                    };

                    $scope.getCallbackData(form).then(function (response) {
                        if (response.data) {
                            dS_ASI_STD_ECC4_STW_CostCodeTwo_Withheld_Level_Data = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_COSTCODETWO_WITHHELD_LEVEL_DATA']).Items.Item;
                            setCostCodeNodesWH(dS_ASI_STD_ECC4_STW_CostCodeTwo_Withheld_Level_Data, currObj, 'spVal');
                            $scope.currentPageWH = 0;
                            $scope.paginationArrayWH = $scope.getPaginationArray(currObj['WH_CostCodeTwoAllGroup']['WH_CostCodeTwoGroup'].length, $scope.pageSize);        
                        }
                    });
                }
            }
            if (strType == 'CostCodeWH') {
                var straddednode = false;
                //hide all nodes and display only clicked one
                var strHidedata = $scope.mappingListWH;
                if (strHidedata.length > 0) {
                    for (var i = 0; i < strHidedata.length; i++) {
                        var strHideline = strHidedata[i]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                        for (var j = 0; j < strHideline.length; j++) {
                            strHideline[j].WH_CCTShow = false;
                        }
                    }
                }
                //show only current node
                currObj.WH_CCTShow = true;
                if (currentViewName == "RES_VIEW" || (currentViewName == "RES_PRINT_VIEW" && strisDraft_Res_msg == "YES")) {
                    var strverify = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                    var strcheckReportdata = mappingReportCode(strverify, currObj.WH_CCWBSElement, currObj.WH_CCReportCodeThree, 'WH');
                    var strcheckcostcode, strcheckLinedata, strLinedata;
                    if (strcheckReportdata.length > 0) {
                        strcheckcostcode = strcheckReportdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                        if (strcheckcostcode.length > 0) {
                            strcheckLinedata = mappingCostCode(strcheckcostcode, currObj.WH_CCWBSElement, currObj.WH_CCReportCodeThree, currObj.WH_CostCodeTwo, 'WH');
                            strLinedata = strcheckLinedata[0]["WH_LineLevelAllGroup"]["WH_LineLevelGroup"];
                            if (strLinedata.length > 0) {
                                var verifyval = strLinedata[0].WH_LineLevel_GUID;
                                if (verifyval != '' && verifyval != '0') {
                                    straddednode = true;
                                }
                                else {
                                    strcheckLinedata[0]["WH_LineLevelAllGroup"]["WH_LineLevelGroup"] = [];
                                }
                            }
                        }
                    }
                }
                if (straddednode) {
                    setLineLevelNodesWH(strLinedata, currObj, 'xmlVal');
                    $scope.currentPageLineWH = 0;
                    $scope.paginationArraylineWH = $scope.getPaginationArray(currObj['WH_LineLevelAllGroup']['WH_LineLevelGroup'].length, $scope.pageSize);

                }
                else {
                    var strparam = currObj.WH_CCWBSElement + '$$' + currObj.WH_CCReportCodeThree + '$$' + currObj.WH_CostCodeTwo + '$$' + strMsgidWh;
                    var spParam = {
                        "projectId": projectId,
                        "formId": formId,
                        "fields": "DS_ASI_STD_ECC4_STW_LINELEVEL_WITHHELD_ALL_DATA",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_ASI_STD_ECC4_STW_LINELEVEL_WITHHELD_ALL_DATA",
                                "fieldValue": strparam
                            }]
                        }
                    };

                    $scope.getCallbackData(spParam).then(function (response) {
                        if (response.data) {
                            dS_ASI_STD_ECC4_STW_Linelevel_Withheld_All_Data = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_LINELEVEL_WITHHELD_ALL_DATA']).Items.Item;
                            setLineLevelNodesWH(dS_ASI_STD_ECC4_STW_Linelevel_Withheld_All_Data, currObj, 'spVal');
                            $scope.currentPageLineWH = 0;
                            $scope.paginationArraylineWH = $scope.getPaginationArray(currObj['WH_LineLevelAllGroup']['WH_LineLevelGroup'].length, $scope.pageSize);
        
                        }
                    });
                }
            }
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 500);
        }
        function setCostCodeNodesWH(lstval, currObj, valType) {
            if (lstval.length > 0) {
                var strwbs, strccreportcode, strcostcodetwo, strcostcodetwodesc, strcctguid, strrefRCD3GUID, strtotalccd;
                var strCostdata, strtotalsubmitted, strtotalpending, strSPflag, strCurrflag, stragredcost, strcctRemarks;
                currObj.WH_CostCodeTwoAllGroup.WH_CostCodeTwoGroup = [];
                if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                    //add in main nodes
                    var strverify = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                    var strcheckdata = mappingReportCode(strverify, currObj.WH_ReportWbsElement, currObj.WH_ReportCodeThree, 'WH');
                    strcheckdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"] = [];
                    strCostdata = strcheckdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                }
                for (var i = 0; i < lstval.length; i++) {
                    if (valType == 'spVal') {
                        strwbs = lstval[i].Value1;
                        strccreportcode = lstval[i].Value3;
                        strcostcodetwo = lstval[i].Value5;
                        strcostcodetwodesc = lstval[i].Value6;
                        strcctguid = commonApi.guId();
                        strrefRCD3GUID = currObj.WH_RCD3_GUID;
                        strtotalccd = lstval[i].Value7;
                        strtotalsubmitted = lstval[i].Value8;
                        strtotalpending = lstval[i].Value9;
                        strSPflag = lstval[i].Value10;//  highlight flag
                        strCurrflag = '0';
                        stragredcost = lstval[i].Value11;
                        strcctRemarks = '0';
                    }
                    else {
                        strwbs = lstval[i].WH_CCWBSElement;
                        strccreportcode = lstval[i].WH_CCReportCodeThree;
                        strcostcodetwo = lstval[i].WH_CostCodeTwo;
                        strcostcodetwodesc = lstval[i].WH_CostCodeTwoDesc;
                        strcctguid = lstval[i].WH_CCT_GUID;
                        strrefRCD3GUID = lstval[i].WH_Ref_RCD3_GUID;
                        strtotalccd = lstval[i].WH_TotalCostCOdeTwoActual;
                        strtotalsubmitted = lstval[i].WH_TotalCostCOdeTwoSubmit;
                        strtotalpending = lstval[i].WH_TotalCostCOdeTwoPending;
                        strSPflag = lstval[i].WH_CCTSPHighlight;//  highlight flag
                        strCurrflag = lstval[i].WH_CCTCurrHighlight;
                        stragredcost = lstval[i].WH_TotalCostCOdeTwo;
                        strcctRemarks = lstval[i].WH_CCTIsRemarks;
                    }

                    var strcostcodedata = angular.copy(STATIC_OBJ_DATA.WH_CostCodeTwoGroup);
                    strcostcodedata.WH_CCWBSElement = strwbs;
                    strcostcodedata.WH_CCReportCodeThree = strccreportcode;
                    strcostcodedata.WH_CostCodeTwo = strcostcodetwo;
                    strcostcodedata.WH_CostCodeTwoDesc = strcostcodetwodesc;
                    strcostcodedata.WH_CCT_GUID = strcctguid;
                    strcostcodedata.WH_Ref_RCD3_GUID = strrefRCD3GUID;
                    strcostcodedata.WH_TotalCostCOdeTwo = parseFloat(stragredcost || 0);
                    strcostcodedata.WH_TotalCostCOdeTwoActual = parseFloat(strtotalccd || 0);
                    strcostcodedata.WH_TotalCostCOdeTwoSubmit = parseFloat(strtotalsubmitted || 0);
                    strcostcodedata.WH_TotalCostCOdeTwoPending = parseFloat(strtotalpending || 0);
                    strcostcodedata.WH_CCTSPHighlight = strSPflag;
                    strcostcodedata.WH_CCTCurrHighlight = strCurrflag;
                    strcostcodedata.WH_CCTIsRemarks = strcctRemarks;
                    currObj.WH_CostCodeTwoAllGroup.WH_CostCodeTwoGroup.push(strcostcodedata);
                    if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                        strCostdata.push(strcostcodedata);
                    }
                }
            }
        }
        function setLineLevelNodesWH(lst, currObj, valType) {
            if (lst.length > 0) {
                var strWBSElement, strPeriod, strSourceID, strCosttype, strCostCodeTwo, strSupplier, strDescription, strPostedDate, strconCostCode;
                var strQuantity, strValue, strNotesOne, strNotesTwo, strNotesThree, strReportCodeThree, strconCostCodedesc, strRefGUID;
                var strpendingcost, strGUID, strsubmittedcost, strLinewise_Status, strLinedata, strComment, strSPdlag, strCurrflag;
                var stragreedCOst, strisRemarks,strAdd = 0;
                currObj.WH_LineLevelAllGroup.WH_LineLevelGroup = [];

                for (var i = 0; i < lst.length; i++) {
                    if (valType == 'spVal') {
                        strWBSElement = lst[i].Value1;
                        strPeriod = lst[i].Value3;
                        strSourceID = lst[i].Value4;
                        strCosttype = lst[i].Value5;
                        strconCostCode = lst[i].Value6;
                        strconCostCodedesc = lst[i].Value7;
                        strSupplier = lst[i].Value8;
                        strDescription = lst[i].Value9;
                        strPostedDate = lst[i].Value10;
                        strQuantity = lst[i].Value11;
                        strValue = lst[i].Value12;
                        strNotesOne = lst[i].Value13;
                        strNotesTwo = lst[i].Value14;
                        strNotesThree = lst[i].Value15;
                        strReportCodeThree = lst[i].Value18;
                        strCostCodeTwo = lst[i].Value16;
                        strsubmittedcost = lst[i].Value21;
                        strpendingcost = lst[i].Value22;
                        strLinewise_Status = 'Withheld';
                        strComment = lst[i].Value23;
                        strGUID = lst[i].Value20;
                        strRefGUID = currObj.WH_CCT_GUID;
                        strSPdlag = lst[i].Value24;
                        strCurrflag = '0';
                        stragreedCOst = lst[i].Value25;
                        strisRemarks = '0';
                    }
                    else {
                        strWBSElement = lst[i].WH_WBSElement;
                        strPeriod = lst[i].WH_Period;
                        strSourceID = lst[i].WH_SourceID;
                        strCosttype = lst[i].WH_Costtype;
                        strconCostCode = lst[i].WH_Contractor_Cost_Code;
                        strconCostCodedesc = lst[i].WH_Contractor_Cost_CodeDesc;
                        strSupplier = lst[i].WH_Supplier;
                        strDescription = lst[i].WH_Description;
                        strPostedDate = lst[i].WH_PostedDate;
                        strQuantity = lst[i].WH_Quantity;
                        strValue = lst[i].WH_LineValue;
                        strNotesOne = lst[i].WH_NotesOne;
                        strNotesTwo = lst[i].WH_NotesTwo;
                        strNotesThree = lst[i].WH_NotesThree;
                        strReportCodeThree = lst[i].WH_LineReportCodeThree;
                        strCostCodeTwo = lst[i].WH_LineCostCodeTwo;
                        strsubmittedcost = lst[i].WH_submitted_Cost;
                        strpendingcost = lst[i].WH_Pending_Cost;
                        strLinewise_Status = 'Withheld';
                        strComment = lst[i].WH_LineComment;
                        strGUID = lst[i].WH_LineLevel_GUID;
                        strRefGUID = lst[i].WH_Ref_CCT_GUID;
                        strSPdlag = lst[i].WH_SPHighlight;
                        strCurrflag = lst[i].WH_CurrHighlight;
                        stragreedCOst = lst[i].WH_Agreed_Cost;
                        strisRemarks = lst[i].WH_LineIsRemarks;
                    }

                    var strcostcodedata = angular.copy(STATIC_OBJ_DATA.WH_LineLevelGroup);
                    strcostcodedata.WH_WBSElement = strWBSElement,
                        strcostcodedata.WH_Period = strPeriod,
                        strcostcodedata.WH_SourceID = strSourceID;
                    strcostcodedata.WH_Costtype = strCosttype;
                    strcostcodedata.WH_Contractor_Cost_Code = strconCostCode;
                    strcostcodedata.WH_Contractor_Cost_CodeDesc = strconCostCodedesc;
                    strcostcodedata.WH_Supplier = strSupplier;
                    strcostcodedata.WH_Description = strDescription;
                    strcostcodedata.WH_PostedDate = strPostedDate;
                    strcostcodedata.WH_Quantity = strQuantity;
                    strcostcodedata.WH_LineValue = strValue;
                    strcostcodedata.WH_NotesOne = strNotesOne;
                    strcostcodedata.WH_NotesTwo = strNotesTwo;
                    strcostcodedata.WH_NotesThree = strNotesThree;
                    strcostcodedata.WH_NotesThree = strNotesThree;
                    strcostcodedata.WH_LineReportCodeThree = strReportCodeThree;
                    strcostcodedata.WH_LineCostCodeTwo = strCostCodeTwo;
                    strcostcodedata.WH_submitted_Cost = strsubmittedcost;
                    strcostcodedata.WH_Pending_Cost = strpendingcost;
                    strcostcodedata.WH_Agreed_Cost = stragreedCOst;
                    strcostcodedata.WH_Linewise_Status = strLinewise_Status;
                    strcostcodedata.WH_LineComment = strComment;
                    strcostcodedata.WH_LineLevel_GUID = strGUID;
                    strcostcodedata.WH_Ref_CCT_GUID = strRefGUID;
                    strcostcodedata.WH_SPHighlight = strSPdlag;
                    strcostcodedata.WH_CurrHighlight = strCurrflag;
                    strcostcodedata.WH_LineIsRemarks = strisRemarks;
                    currObj.WH_LineLevelAllGroup.WH_LineLevelGroup.push(strcostcodedata);

                    if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                        var strverify = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                        var strcheckReportdata = mappingReportCode(strverify, currObj.WH_CCWBSElement, currObj.WH_CCReportCodeThree, 'WH');
                        if (strcheckReportdata.length > 0) {
                            var strcheckcostcode = strcheckReportdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                            if (strcheckcostcode.length > 0) {
                                var strcheckLinedata = mappingCostCode(strcheckcostcode, currObj.WH_CCWBSElement, currObj.WH_CCReportCodeThree, currObj.WH_CostCodeTwo, 'WH');
                                strLinedata = strcheckLinedata[0]["WH_LineLevelAllGroup"]["WH_LineLevelGroup"];
                            }
                        }
                       if (strLinedata.length == 0 || strAdd == 1) {
                            strAdd = 1;
                            strLinedata.push(strcostcodedata);
                        }
                    }
                }
            }
        }
        $scope.filterWHdata = filterWHdata;
        //filter data
        function filterWHdata(event, strwbsisexist, strtype) {
            var stralldata = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];

            //filter by paging
            if (strtype != 'paging') {
                $scope.afpDetails.WH_Total_Pages = stralldata.length;
                (stralldata.length < 20) ? $scope.afpDetails.WH_Page_Sel = '1-' + stralldata.length : $scope.afpDetails.WH_Page_Sel = '1-20';
                setPagingData('WH');
            }
            setPagination($scope.afpDetails.WH_Page_Sel, stralldata, $scope.afpDetails.WH_Page_Slice, 'WH');
        }
        //#endregion Withheld Tab           
        //#region Transaction data tab
        //set on load detail data
        function setOnLoadDetaildata() {
            var lst = ds_ASI_STD_ECC4_STW_ReportCodethree_Level_Data;
            if (lst && lst.length) {
                $scope.reportCodeAllGroup['ReportCodeGroup'] = [];

                for (var i = 0; i < lst.length; i++) {
                    var guid = commonApi.guId();
                    var strctafpdata = angular.copy(STATIC_OBJ_DATA.ReportCodeGroup)

                    strctafpdata.ReportWbsElement = lst[i].Value1;
                    strctafpdata.ReportWbsName = lst[i].Value2;
                    strctafpdata.ReportCodeThree = lst[i].Value3;
                    strctafpdata.ReportCodeThreeDesc = lst[i].Value4;
                    strctafpdata.TotalReportCodeThree = parseFloat(lst[i].Value5 || 0) - parseFloat(lst[i].Value7 || 0);
                    strctafpdata.TotalReportCodeThreeWithDis = lst[i].Value5;
                    strctafpdata.TotalDisReportCodeThree = lst[i].Value7;
                    strctafpdata.RCD3_GUID = guid;
                    strctafpdata.RPSPHighlight = lst[i].Value8; //highlight flag
                    strMSGid = lst[i].Value9;
                    $scope.reportCodeAllGroup['ReportCodeGroup'].push(strctafpdata);
                }
            }
        }

        //set showHide data
        $scope.showHideCode = showHideCode;
        function showHideCode(currObj, strType) {
            if (strType == 'ReportCode') {
                //verify node  is already in main xml or not
                var straddednode = false;
                //hide all nodes and display only clicked one
                var strHidedata = $scope.mappingList;
                if (strHidedata.length > 0) {
                    for (var i = 0; i < strHidedata.length; i++) {
                        strHidedata[i].RCTShow = false;
                    }
                }
                //show only current node
                currObj.RCTShow = true;

                //verify current node is already exist or not in main node
                if (currentViewName == "RES_VIEW" || (currentViewName == "RES_PRINT_VIEW" && strisDraft_Res_msg == "YES")) {
                    var strverify = $scope.reportCodeAllGroup['ReportCodeGroup'];
                    var strcheckReportdata = mappingReportCode(strverify, currObj.ReportWbsElement, currObj.ReportCodeThree, 'TS');
                    if (strcheckReportdata.length > 0) {
                        var strcheckcostcode = strcheckReportdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                        if (strcheckcostcode.length > 0) {
                            var verifyval = strcheckcostcode[0].CostCodeTwo;
                            if (verifyval != '' && verifyval != '0') {
                                straddednode = true;
                            }
                        }
                    }
                }
                //add node as per condition
                if (straddednode) {
                    //if node exist in main node then add node from main xml node
                    setCostCodeNodes(strcheckcostcode, currObj, 'xmlVal');
                    $scope.currentPage = 0;
                    $scope.paginationArray = $scope.getPaginationArray(currObj['CostCodeTwoAllGroup']['CostCodeTwoGroup'].length, $scope.pageSize);

                }
                else {
                    //if not exist then its new node and add node from sp
                    var strparam = currObj.ReportWbsElement + '$$' + currObj.ReportCodeThree + '$$' + strMSGid;
                    var form = {
                        "projectId": projectId,
                        "formId": formId,
                        "fields": "DS_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA",
                                "fieldValue": strparam
                            }]
                        }
                    };

                    $scope.getCallbackData(form).then(function (response) {
                        if (response.data) {
                            ds_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA']).Items.Item;
                            setCostCodeNodes(ds_ASI_STD_ECC4_STW_COSTCODETWO_LEVEL_DATA, currObj, 'spVal');
                            $scope.currentPage = 0;
                            $scope.paginationArray = $scope.getPaginationArray(currObj['CostCodeTwoAllGroup']['CostCodeTwoGroup'].length, $scope.pageSize);

                        }
                    });
                }
            }
            if (strType == 'CostCode') {
                var straddednode = false;
                //hide all nodes and display only clicked one
                var strHidedata = $scope.mappingList;
                if (strHidedata.length > 0) {
                    for (var i = 0; i < strHidedata.length; i++) {
                        var strHideline = strHidedata[i]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                        for (var j = 0; j < strHideline.length; j++) {
                            strHideline[j].CCTShow = false;
                        }
                    }
                }
                //show only current node
                currObj.CCTShow = true;
                if (currentViewName == "RES_VIEW" || (currentViewName == "RES_PRINT_VIEW" && strisDraft_Res_msg == "YES")) {
                    var strverify = $scope.reportCodeAllGroup['ReportCodeGroup'];
                    var strcheckReportdata = mappingReportCode(strverify, currObj.CCWBSElement, currObj.CCReportCodeThree, 'TS');
                    if (strcheckReportdata.length > 0) {
                        var strcheckcostcode = strcheckReportdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                        if (strcheckcostcode.length > 0) {
                            var strcheckLinedata = mappingCostCode(strcheckcostcode, currObj.CCWBSElement, currObj.CCReportCodeThree, currObj.CostCodeTwo, 'TS');
                            var strLinedata = strcheckLinedata[0]["LineLevelAllGroup"]["LineLevelGroup"];
                            if (strLinedata.length > 0) {
                                var verifyval = strLinedata[0].LineLevel_GUID;
                                if (verifyval != '' && verifyval != '0') {
                                    straddednode = true;
                                }
                                else {
                                    strcheckLinedata[0]["LineLevelAllGroup"]["LineLevelGroup"] = [];
                                }
                            }
                        }
                    }
                }
                if (straddednode) {
                    setLineLevelNodes(strLinedata, currObj, 'xmlVal');
                    $scope.currentPageLine = 0;
                    $scope.paginationArrayline = $scope.getPaginationArray(currObj['LineLevelAllGroup']['LineLevelGroup'].length, $scope.pageSize);

                }
                else {
                    var strparam = currObj.CCWBSElement + '$$' + currObj.CCReportCodeThree + '$$' + currObj.CostCodeTwo + '$$' + strMSGid;
                    var spParam = {
                        "projectId": projectId,
                        "formId": formId,
                        "fields": "DS_ASI_STD_ECC4_STW_LINELEVEL_ALL_DATA",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_ASI_STD_ECC4_STW_LINELEVEL_ALL_DATA",
                                "fieldValue": strparam
                            }]
                        }
                    };

                    $scope.getCallbackData(spParam).then(function (response) {
                        if (response.data) {
                            ds_Asi_stw_Ecc4_Stw_Linelevel_All_Data = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_LINELEVEL_ALL_DATA']).Items.Item;
                            setLineLevelNodes(ds_Asi_stw_Ecc4_Stw_Linelevel_All_Data, currObj, 'spVal');
                            $scope.currentPageLine = 0;
                            $scope.paginationArrayline = $scope.getPaginationArray(currObj['LineLevelAllGroup']['LineLevelGroup'].length, $scope.pageSize);
                            $timeout(function () {
                                $scope.expandTextAreaOnLoad();
                            }, 500);
                        }
                    });
                }
            }
            $timeout(function () {
                var element = angular.element(document.querySelector('#trans_inner'));
                element[0].focus();
                $scope.expandTextAreaOnLoad();
            }, 500);
        }

        function setCostCodeNodes(lstval, currObj, valType) {
            if (lstval.length > 0) {
                var strwbs, strccreportcode, strcostcodetwo, strcostcodetwodesc, strcctguid, strrefRCD3GUID, strtotalccd;
                var strCostdata, strwithdistotalccd, strdisallowed, strSPflag, strCurrflag, strcctisRemarks;
                currObj.CostCodeTwoAllGroup.CostCodeTwoGroup = [];
                if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                    //add in main nodes
                    var strverify = $scope.reportCodeAllGroup['ReportCodeGroup'];
                    var strcheckdata = mappingReportCode(strverify, currObj.ReportWbsElement, currObj.ReportCodeThree, 'TS');
                    strcheckdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"] = [];
                    strCostdata = strcheckdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                }
                for (var i = 0; i < lstval.length; i++) {
                    if (valType == 'spVal') {
                        strwbs = lstval[i].Value1;
                        strccreportcode = lstval[i].Value3;
                        strcostcodetwo = lstval[i].Value5;
                        strcostcodetwodesc = lstval[i].Value6;
                        strcctguid = commonApi.guId();
                        strrefRCD3GUID = currObj.RCD3_GUID;
                        strtotalccd = parseFloat(lstval[i].Value7 || 0) - parseFloat(lstval[i].Value9 || 0);
                        strwithdistotalccd = lstval[i].Value7;
                        strdisallowed = lstval[i].Value9;
                        strSPflag = lstval[i].Value10;//  highlight flag
                        strCurrflag = '0';
                        strcctisRemarks = '0';
                    }
                    else {
                        strwbs = lstval[i].CCWBSElement;
                        strccreportcode = lstval[i].CCReportCodeThree;
                        strcostcodetwo = lstval[i].CostCodeTwo;
                        strcostcodetwodesc = lstval[i].CostCodeTwoDesc;
                        strcctguid = lstval[i].CCT_GUID;
                        strrefRCD3GUID = lstval[i].Ref_RCD3_GUID;
                        strtotalccd = lstval[i].TotalCostCOdeTwo;
                        strwithdistotalccd = lstval[i].TotalCostCOdeTwoWithDis;
                        strdisallowed = lstval[i].TotalDisCostCOdeTwo;
                        strSPflag = lstval[i].CCTSPHighlight;
                        strCurrflag = lstval[i].CCTCurrHighlight;
                        strcctisRemarks = lstval[i].CCTIsRemarks;
                    }

                    var strcostcodedata = angular.copy(STATIC_OBJ_DATA.CostCodeTwoGroup);
                    strcostcodedata.CCWBSElement = strwbs;
                    strcostcodedata.CCReportCodeThree = strccreportcode;
                    strcostcodedata.CostCodeTwo = strcostcodetwo;
                    strcostcodedata.CostCodeTwoDesc = strcostcodetwodesc;
                    strcostcodedata.CCT_GUID = strcctguid;
                    strcostcodedata.Ref_RCD3_GUID = strrefRCD3GUID;
                    strcostcodedata.TotalCostCOdeTwo = parseFloat(strtotalccd || 0);
                    strcostcodedata.TotalCostCOdeTwoWithDis = parseFloat(strwithdistotalccd || 0);
                    strcostcodedata.TotalDisCostCOdeTwo = parseFloat(strdisallowed || 0);
                    strcostcodedata.CCTCurrHighlight = strCurrflag;
                    strcostcodedata.CCTSPHighlight = strSPflag;
                    strcostcodedata.CCTIsRemarks = strcctisRemarks;
                    currObj.CostCodeTwoAllGroup.CostCodeTwoGroup.push(strcostcodedata);
                    if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                        strCostdata.push(strcostcodedata);
                    }
                }
            }
        }
        function setLineLevelNodes(lst, currObj, valType) {
            if (lst.length > 0) {
                var strWBSElement, strPeriod, strSourceID, strCosttype, strCostCodeTwo, strSupplier, strDescription, strPostedDate, strconCostCode, strSPdlag, strCurrflag;
                var strQuantity, strValue, strNotesOne, strNotesTwo, strNotesThree, strReportCodeThree, strconCostCodedesc, strRefGUID;
                var strAgreed_Cost, strGUID, strPreviousAFP_Value, strLinewise_Status, strLinedata, strComment, strLineremark;
                var strAdd = 0;
                currObj.LineLevelAllGroup.LineLevelGroup = [];
                for (var i = 0; i < lst.length; i++) {
                    if (valType == 'spVal') {
                        strWBSElement = lst[i].Value1;
                        strPeriod = lst[i].Value2;
                        strSourceID = lst[i].Value3;
                        strCosttype = lst[i].Value4;
                        strconCostCode = lst[i].Value5;
                        strconCostCodedesc = lst[i].Value6;
                        strSupplier = lst[i].Value7;
                        strDescription = lst[i].Value8;
                        strPostedDate = lst[i].Value9;
                        strQuantity = lst[i].Value10;
                        strValue = lst[i].Value11;
                        strNotesOne = lst[i].Value12;
                        strNotesTwo = lst[i].Value13;
                        strNotesThree = lst[i].Value14;
                        strAgreed_Cost = lst[i].Value22;
                        strGUID = lst[i].Value19;
                        strRefGUID = currObj.CCT_GUID;
                        strPreviousAFP_Value = lst[i].Value20;
                        strLinewise_Status = lst[i].Value21;
                        strCostCodeTwo = lst[i].Value15;
                        strReportCodeThree = lst[i].Value17;
                        strComment = lst[i].Value23;
                        strSPdlag = lst[i].Value24;
                        strCurrflag = '0';
                        strLineremark = '0';
                    }
                    else {
                        strWBSElement = lst[i].WBSElement;
                        strPeriod = lst[i].Period;
                        strSourceID = lst[i].SourceID;
                        strCosttype = lst[i].Costtype;
                        strconCostCode = lst[i].Contractor_Cost_Code;
                        strconCostCodedesc = lst[i].Contractor_Cost_CodeDesc;
                        strSupplier = lst[i].Supplier;
                        strDescription = lst[i].Description;
                        strPostedDate = lst[i].PostedDate;
                        strQuantity = lst[i].Quantity;
                        strValue = lst[i].LineValue;
                        strNotesOne = lst[i].NotesOne;
                        strNotesTwo = lst[i].NotesTwo;
                        strNotesThree = lst[i].NotesThree;
                        strAgreed_Cost = lst[i].Agreed_Cost;
                        strLinewise_Status = lst[i].Linewise_Status;
                        strPreviousAFP_Value = lst[i].PreviousAFP_Value;
                        strComment = lst[i].LineComment;
                        strGUID = lst[i].LineLevel_GUID;
                        strRefGUID = lst[i].Ref_CCT_GUID;
                        strCostCodeTwo = lst[i].LineCostCodeTwo;
                        strReportCodeThree = lst[i].LineReportCodeThree;
                        strSPdlag = lst[i].LineSPHighlight;
                        strCurrflag = lst[i].LineCurrHighlight;
                        strLineremark = lst[i].LineIsRemarks;
                    }

                    var strcostcodedata = angular.copy(STATIC_OBJ_DATA.LineLevelGroup);
                    strcostcodedata.WBSElement = strWBSElement,
                        strcostcodedata.Period = strPeriod,
                        strcostcodedata.SourceID = strSourceID;
                    strcostcodedata.Costtype = strCosttype;
                    strcostcodedata.Contractor_Cost_Code = strconCostCode;
                    strcostcodedata.Contractor_Cost_CodeDesc = strconCostCodedesc;
                    strcostcodedata.Supplier = strSupplier;
                    strcostcodedata.Description = strDescription;
                    strcostcodedata.PostedDate = strPostedDate;
                    strcostcodedata.Quantity = strQuantity;
                    strcostcodedata.LineValue = strValue;
                    strcostcodedata.NotesOne = strNotesOne;
                    strcostcodedata.NotesTwo = strNotesTwo;
                    strcostcodedata.NotesThree = strNotesThree;
                    strcostcodedata.NotesThree = strNotesThree;
                    strcostcodedata.PreviousAFP_Value = strPreviousAFP_Value;
                    strcostcodedata.LineLevel_GUID = strGUID;
                    strcostcodedata.Ref_CCT_GUID = strRefGUID;
                    strcostcodedata.LineCostCodeTwo = strCostCodeTwo;
                    strcostcodedata.LineReportCodeThree = strReportCodeThree;
                    strcostcodedata.Agreed_Cost = parseFloat(strAgreed_Cost || 0) == 0 ? '0.00' : parseFloat(strAgreed_Cost);
                    strcostcodedata.Linewise_Status = strLinewise_Status;
                    strcostcodedata.LineComment = strComment;
                    strcostcodedata.LineCurrHighlight = strCurrflag;
                    strcostcodedata.LineSPHighlight = strSPdlag;
                    strcostcodedata.LineIsRemarks = strLineremark;
                    currObj.LineLevelAllGroup.LineLevelGroup.push(strcostcodedata);

                    if (valType == 'spVal' && currentViewName == "RES_VIEW") {
                        var strverify = $scope.reportCodeAllGroup['ReportCodeGroup'];
                        var strcheckReportdata = mappingReportCode(strverify, currObj.CCWBSElement, currObj.CCReportCodeThree, 'TS');
                        if (strcheckReportdata.length > 0) {
                            var strcheckcostcode = strcheckReportdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                            if (strcheckcostcode.length > 0) {
                                var strcheckLinedata = mappingCostCode(strcheckcostcode, currObj.CCWBSElement, currObj.CCReportCodeThree, currObj.CostCodeTwo, 'TS');
                                strLinedata = strcheckLinedata[0]["LineLevelAllGroup"]["LineLevelGroup"];
                            }
                        }
                       if (strLinedata.length == 0 || strAdd == 1) {
                            strAdd = 1;
                            strLinedata.push(strcostcodedata);
                        }
                    }
                }
            }
        }

        //set paging
        function setPagingData(strtype) {
            var pageParamObj, strPage_Slice;
            if (strtype == 'TS') {
                $scope.afpDetails.Tabbed_Paging.Pages = [];
                pageParamObj = {
                    totalCount: $scope.afpDetails.Total_Pages,
                    nodeKey: 'Pages',
                    parentNode: 'Tabbed_Paging',
                    pageNode: 'Page_Range',
                    dropdownModal: 'Page_Sel'
                };
                strPage_Slice = $scope.afpDetails.Page_Slice;
                addNewPageNode(pageParamObj, strPage_Slice);
                setDefaultRange('TS');
            }
            else {
                $scope.afpDetails.WH_Tabbed_Paging.WH_Pages = [];
                pageParamObj = {
                    totalCount: $scope.afpDetails.WH_Total_Pages,
                    nodeKey: 'WH_Pages',
                    parentNode: 'WH_Tabbed_Paging',
                    pageNode: 'WH_Page_Range',
                    dropdownModal: 'WH_Page_Sel'
                };
                strPage_Slice = $scope.afpDetails.WH_Page_Slice;
                addNewPageNode(pageParamObj, strPage_Slice);
                setDefaultRange('WH');
            }
        };
        function addNewPageNode(pageParam, strPage_Slice) {
            var tmpTotalCount = pageParam.totalCount,
                nodeKey = pageParam.nodeKey,
                parentNode = pageParam.parentNode,
                pageNode = pageParam.pageNode,
                dropdownModal = pageParam.dropdownModal;

            var pageNumberArray = getPagingArray(tmpTotalCount, strPage_Slice);

            if (!$scope.afpDetails[dropdownModal]) {
                $scope.afpDetails[dropdownModal] = pageNumberArray[0];
            }

            for (var index = 0; index < pageNumberArray.length; index++) {
                var pageStr = pageNumberArray[index];
                var newPageNode = angular.copy(STATIC_OBJ_DATA[nodeKey]);
                newPageNode[pageNode] = pageStr;
                $scope.afpDetails[parentNode][nodeKey].push(newPageNode);
            }
        }

        function getPagingArray(totalRecords, strPage_Slice) {
            var pageSize = parseInt(strPage_Slice);
            var pageStart = 1;
            var totalItemCount = totalRecords;
            var pageArray = [];

            var currPageIndex = 1;
            var totalPage = Math.ceil(totalItemCount / pageSize);
            var tmpTotalCount = totalItemCount;
            while (currPageIndex <= totalPage) {
                var pageEnd = (pageSize > tmpTotalCount ? tmpTotalCount : pageSize) + pageStart - 1;
                pageArray.push(pageStart + '-' + pageEnd);
                tmpTotalCount = tmpTotalCount - pageSize;
                currPageIndex++;
                pageStart = pageEnd + 1;
            }
            return pageArray;
        }
        // set Default Range
        function setDefaultRange(strtype) {
            if (strtype == 'TS') {
                if (!$scope.afpDetails.Tabbed_Paging.Pages.length || !$scope.afpDetails.Tabbed_Paging.Pages[0].Page_Range) {
                    $scope.afpDetails.Page_Sel = '0-0';
                    $scope.afpDetails.Tabbed_Paging.Pages = [{
                        Page_Range: '0-0'
                    }];
                }
            }
            else if (strtype == 'WH') {
                if (!$scope.afpDetails.WH_Tabbed_Paging.WH_Pages.length || !$scope.afpDetails.WH_Tabbed_Paging.WH_Pages[0].WH_Page_Range) {
                    $scope.afpDetails.WH_Page_Sel = '0-0';
                    $scope.afpDetails.WH_Tabbed_Paging.WH_Pages = [{
                        WH_Page_Range: '0-0'
                    }];
                }
            }
        }

        //set data based on paging list
        $scope.setPagination = setPagination;
        function setPagination(pageIndex, strimportdata, strPage_Slice, strtype) {
            var temp = angular.copy(strimportdata);
            var splittedIndex = pageIndex.split('-'),
                pageSlice = parseInt(strPage_Slice) || 20,
                spliceCount = (parseInt(splittedIndex[0]) + pageSlice > strimportdata.length) && !(parseInt(splittedIndex[1] + pageSlice) > strimportdata.length) ? ((strimportdata.length - 1) - parseInt(splittedIndex[0])) : pageSlice,
                pageRangeList = temp.splice(splittedIndex[0] - 1, spliceCount);
            if (strtype == 'TS') { $scope.mappingList = pageRangeList; }
            else { $scope.mappingListWH = pageRangeList; }
            if (currentViewName == 'ORI_VIEW' || currentViewName == 'ORI_PRINT_VIEW') {
                contractTotalOfAppliedValue($scope.mappingList, 'IMP_Value', $scope.afpDetails, 'Pagewise_Total_Amount');
            }
        };

        //filter data for ORI view's original data
        $scope.applyFilterCall = function (event, strwbsisexist, strtype) {
            filterOriginaldata(event, strwbsisexist, strtype);
        };
        function contractTotalOfAppliedValue(stralldata, strcalckey, strparobj, strtotalkey) {
            calcFieldTotal({
                repData: stralldata,
                calcKey: strcalckey,
                parObject: strparobj,
                totalKey: strtotalkey
            });
        }
        $scope.calcFieldTotal = calcFieldTotal;
        function calcFieldTotal(paramObject) {
            var repData = paramObject.repData;
            var calcKey = paramObject.calcKey;
            var parObject = paramObject.parObject;
            var totalKey = paramObject.totalKey;

            var tempTotal = 0;
            var index = 0;
            for (; index < repData.length; index++) {
                var element = repData[index][calcKey];
                tempTotal += (parseFloat(element) || 0);
            }
            parObject[totalKey] = angular.copy(tempTotal.toFixed(2));
        }
        function fillOriginaldata() {
            $scope.impAFPGroup['IMP_AFP_Data'] = [];
            var lst = ds_ASI_STD_ECC4_STW_DISPLAYORIGINALDATA;
            if (lst && lst.length) {
                var i = 0;
                for (; i < lst.length; i++) {
                    var strctOridata = angular.copy(STATIC_OBJ_DATA.IMP_AFP_Data)
                    strctOridata.IMP_WBSElement = lst[i].Value1;
                    strctOridata.IMP_Period = lst[i].Value3;
                    strctOridata.IMP_SourceID = lst[i].Value4;
                    strctOridata.IMP_Costtype = lst[i].Value5;
                    strctOridata.IMP_Contractor_Cost_Code = lst[i].Value6;
                    strctOridata.IMP_Contractor_Cost_CodeDesc = lst[i].Value7;
                    strctOridata.IMP_Supplier = lst[i].Value8;
                    strctOridata.IMP_Description = lst[i].Value9;
                    strctOridata.IMP_PostedDate = lst[i].Value10;
                    strctOridata.IMP_Quantity = lst[i].Value11;
                    strctOridata.IMP_Value = lst[i].Value12;
                    strctOridata.IMP_NotesOne = lst[i].Value13;
                    strctOridata.IMP_NotesTwo = lst[i].Value14;
                    strctOridata.IMP_NotesThree = lst[i].Value15;

                    $scope.impAFPGroup['IMP_AFP_Data'].push(strctOridata);

                }
            }
        }
        $scope.filterOriginaldata = filterOriginaldata;

        //filter data
        function filterOriginaldata(event, strwbsisexist, strtype) {
            //fetch filter nodes value
            var strfltWBSElement;
            if (strtype == 'wbswise') {
                strfltWBSElement = strwbsisexist;
                $scope.filterFieldObj.fltWBSElement = strwbsisexist;
                setCurrentSection('wbs-detail.html');
            }
            else {
                strfltWBSElement = $scope.filterFieldObj.fltWBSElement;
            }

            //fetch all dump and filter data
            var stralldata;
            if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_PRINT_VIEW") {
                var strfltCostCode = $scope.filterFieldObj.fltCostCode;
                stralldata = $scope.impAFPGroup['IMP_AFP_Data'];

                contractTotalOfAppliedValue(stralldata, 'IMP_Value', $scope.afpDetails, 'Total_Amount');

                if (strfltCostCode != "") {
                    stralldata = commonApi._.filter(stralldata, function (obj) {
                        return obj.IMP_Contractor_Cost_Code.indexOf(strfltCostCode) > -1;
                    });
                }
            }
            else if (currentViewName == "RES_VIEW" || currentViewName == "RES_PRINT_VIEW") {
                stralldata = $scope.reportCodeAllGroup['ReportCodeGroup'];
                if (strfltWBSElement != "") {
                    stralldata = commonApi._.filter(stralldata, function (obj) {
                        return obj.ReportWbsElement.indexOf(strfltWBSElement) > -1;
                    });
                }
            }

            //filter by paging
            if (strtype != 'paging') {
                $scope.afpDetails.Total_Pages = stralldata.length;
                $scope.afpDetails.Page_Sel = stralldata.length < 20 ? '1-' + stralldata.length : '1-20';
                setPagingData('TS');
            }
            setPagination($scope.afpDetails.Page_Sel, stralldata, $scope.afpDetails.Page_Slice, 'TS');
        }

        //reset filter data
        $scope.resetTrackerFilter = function (event) {
            $scope.filterFieldObj = {
                fltWBSElement: '',
                fltCostCode: '',
            };
            filterOriginaldata(event, '', 'All');
        };
        //#endregion
        //#region Payment Assessment tab related calculation
        function setDraftTargetpriceResprint() {
            var lstsummary = ds_Asi_Std_Eec4_STW_WBSELEMENTWISE_SUMMARY_DATA;
            if (lstsummary && lstsummary.length && strisDraft_Res_msg == "YES") 
            {
                $scope.impsummaryData.Target_Price = lstsummary[0].Value5;
            }
        }
        //set on load summary data with total and less value set on load
        function setOnloadSummarywithLess() {
            var lstsummary = ds_Asi_Std_Eec4_STW_WBSELEMENTWISE_SUMMARY_DATA;
            if (lstsummary && lstsummary.length) 
            {
                $scope.afpDetails['DSI_flagHistoric'] = lstsummary[0].Value57;
                if (strisDraft_Res_msg == "NO") 
                {
                    var strAFPType = $scope.oriMsgCustomFields['Application_for_Payment_Type'];
                    $scope.impsummaryData.IMP_Sum_WBSElement = lstsummary[0].Value2;
                    $scope.impsummaryData.IMP_Sum_WBSElement_Name = lstsummary[0].Value3;
                    $scope.impsummaryData.Previous_AFP_Data = lstsummary[0].Value4;
                    $scope.impsummaryData.Target_Price = lstsummary[0].Value5;
                    $scope.impsummaryData.PaidtoDate = lstsummary[0].Value6;
                    $scope.impsummaryData.IMP_Summary_Value = lstsummary[0].Value7;
                    $scope.impsummaryData.PWDDNoFirstProgramme = lstsummary[0].Value8;
                    $scope.impsummaryData.DelayDamages = lstsummary[0].Value10;
                    $scope.impsummaryData.Disallowed_Data = lstsummary[0].Value12;
                    $scope.impsummaryData.Prev_Other_Amount_AssessedByPM = lstsummary[0].Value16;
                    $scope.impsummaryData.Prev_Comment_AssessedByPM = lstsummary[0].Value17;
                    $scope.impsummaryData.PriceofWorkDonetoDate = parseFloat($scope.impsummaryData.Previous_AFP_Data || 0) + parseFloat($scope.impsummaryData.IMP_Summary_Value || 0) - parseFloat($scope.impsummaryData.Disallowed_Data || 0);
                    $scope.impsummaryData.finalPriceofWorkDonetoDate = parseFloat($scope.impsummaryData.PriceofWorkDonetoDate || 0) + parseFloat($scope.impsummaryData.Other_Amount_AssessedByPM || 0);
                    var sumamntwbswise = $scope.impsummaryData.finalPriceofWorkDonetoDate;
                    $scope.impsummaryData.Total_finaldonetodate_othpaidbypm = parseFloat($scope.impsummaryData.Other_Amount_PaidByPM || 0) + parseFloat(sumamntwbswise || 0);
                    $scope.impsummaryData.PWDDNoFirstProgramme_Amt = '';
                    if ($scope.impsummaryData.PWDDNoFirstProgramme == 'No') {
                        $scope.impsummaryData.PWDDNoFirstProgramme_Amt = sumamntwbswise != 0 ? round(((parseFloat(sumamntwbswise || 0) * 25) / 100), 2) : 0;
                    }
                    $scope.impsummaryData.PWDDNoBaseForeActual = lstsummary[0].Value9;
                    $scope.impsummaryData.PWDDNoBaseForeActual_Amt = '';
                    if ($scope.impsummaryData.PWDDNoBaseForeActual == 'No') {
                        $scope.impsummaryData.PWDDNoBaseForeActual_Amt = sumamntwbswise != 0 ? round(((parseFloat(sumamntwbswise || 0) * 15) / 100), 2) : 0;
                    }
                    $scope.impsummaryData.PWDDNoActual = $scope.oriMsgCustomFields.IsActual;
                    $scope.impsummaryData.PWDDNoFore = $scope.oriMsgCustomFields.IsForecast;

                    if (strAFPType == NEC4_CONSTANT.appforpayment) {
                        $scope.impsummaryData.TotalLessAmount = parseFloat($scope.impsummaryData.PWDDNoFirstProgramme_Amt || 0) +
                            parseFloat($scope.impsummaryData.PWDDLastAcceptedProg_Amt || 0) + parseFloat($scope.impsummaryData.PWDDNoBaseForeActual_Amt || 0) +
                            parseFloat($scope.impsummaryData.PWDDNoFore_Amt || 0) + parseFloat($scope.impsummaryData.PWDDNoActual_Amt || 0) +
                            parseFloat($scope.impsummaryData.PWDDNoPreConstruction_Amt || 0) + parseFloat($scope.impsummaryData.PWDDNoConstruction_Amt || 0) +
                            parseFloat($scope.impsummaryData.OtherDeductions || 0);
                    }
                    else if (strAFPType == NEC4_CONSTANT.finalappforpayment) {
                        $scope.impsummaryData.TotalLessAmount = parseFloat($scope.impsummaryData.PWDDNoPreConstruction_Amt || 0) +
                            parseFloat($scope.impsummaryData.NoHealthandSafety_Amt || 0) +
                            parseFloat($scope.impsummaryData.OtherDeductions || 0);
                    }
                    var strpayval = (parseFloat($scope.impsummaryData.finalPriceofWorkDonetoDate || 0) +
                        parseFloat($scope.impsummaryData.Other_Amount_PaidByPM || 0)) - (parseFloat($scope.impsummaryData.TotalLessAmount || 0) +
                        parseFloat($scope.impsummaryData.PaidtoDate || 0) + parseFloat($scope.impsummaryData.HistoricPaidtoDate || 0)) ;
                    $scope.impsummaryData.PreviousAmountAdjusted = lstsummary[0].Value48;
                    $scope.impsummaryData.PaymentDue = round(strpayval, 2);
                    $scope.impsummaryData.Certified = (parseFloat($scope.impsummaryData.PaymentDue || 0) - parseFloat($scope.impsummaryData.DelayDamages || 0)).toFixed(2);
                    $scope.impsummaryData.ExternallyReceived = lstsummary[0].Value50;
                    $scope.impsummaryData.PreviousExternallyReceived = parseFloat(lstsummary[0].Value51 || 0);
                    $scope.impsummaryData.CertifiedSubTotal = (parseFloat($scope.impsummaryData.Certified || 0) + parseFloat($scope.impsummaryData.ExternallyReceived || 0)).toFixed(2);
                    $scope.impsummaryData.Receipted = parseFloat($scope.impsummaryData.CertifiedSubTotal || 0);
                }
                if (strisDraft_Res_msg == "YES") 
                {
                    //set target price in draft
                    $scope.impsummaryData.Target_Price = lstsummary[0].Value5;
                }
            }
        }

        //set calculated data
        $scope.setSummaryData = setSummaryData;
        function setSummaryData(currObj, strType, Iscomment, Isstatus, parObj) {
            if (currentViewName == "RES_VIEW") {
                if (strType == 'Detail') {

                    var strwbselement = currObj.WBSElement;
                    var strReportCodeThree = currObj.LineReportCodeThree;
                    var strCostCodeTwo = currObj.LineCostCodeTwo;
                    var strGUID = currObj.LineLevel_GUID;
                    //filter of withheld wbswise
                    var strwhmaindata = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                    var strwhwbswisedata;
                    if (strwhmaindata && strwhmaindata.length) {
                        strwhwbswisedata = mappingWBSWise(strwhmaindata, strwbselement, 'WH');
                    }

                    //filter of mappinglistdata
                    var strmapmaindata = $scope.mappingList;
                    var strmapreportdata, strmapcostcodedata, strmapccdata;
                    strmapreportdata = mappingReportCode(strmapmaindata, strwbselement, strReportCodeThree, 'TS');
                    strmapccdata = strmapreportdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                    strmapcostcodedata = mappingCostCode(strmapccdata, strwbselement, strReportCodeThree, strCostCodeTwo, 'TS');


                    //filter of main xml data
                    var strmaindata = $scope.reportCodeAllGroup['ReportCodeGroup'];
                    var strwbswisedata = mappingWBSWise(strmaindata, strwbselement, 'TS');
                    var strreportdata = mappingReportCode(strmaindata, strwbselement, strReportCodeThree, 'TS');
                    var strccdata = strreportdata[0]["CostCodeTwoAllGroup"]["CostCodeTwoGroup"];
                    var strcostcodedata = mappingCostCode(strccdata, strwbselement, strReportCodeThree, strCostCodeTwo, 'TS');

                    var strLinedata = strcostcodedata[0]["LineLevelAllGroup"]["LineLevelGroup"];
                    if (strGUID) {
                        var strGUIDData = commonApi._.filter(strLinedata, function (obj) {
                            return obj.LineLevel_GUID.indexOf(strGUID) > -1;
                        });

                        strGUIDData[0].Agreed_Cost = currObj.Agreed_Cost;
                        strGUIDData[0].Linewise_Status = currObj.Linewise_Status;
                        if (currObj.LineComment == null || currObj.LineComment == "") {
                            strGUIDData[0].LineComment = "";
                        }
                        else {
                            strGUIDData[0].LineComment = currObj.LineComment;
                        }
                        strGUIDData[0].LineCurrHighlight = '0'
                        strGUIDData[0].LineIsRemarks = '0'
                        currObj.LineCurrHighlight = '0';
                        currObj.LineIsRemarks = '0'

                        if (currObj.Linewise_Status == 'Disallowed' || currObj.Linewise_Status == 'Agreed') {
                            strGUIDData[0].Agreed_Cost = currObj.LineValue;
                            currObj.Agreed_Cost = currObj.LineValue;
                        }
                        else if (currObj.Linewise_Status == 'Withheld' && ((parseFloat(currObj.Agreed_Cost || 0) > parseFloat(currObj.LineValue)) || Isstatus == 'Yes' || parseFloat(currObj.Agreed_Cost || 0) < 0)) {
                            strGUIDData[0].Agreed_Cost = '0.00';
                            currObj.Agreed_Cost = '0.00';
                        }
                        if (currObj.Linewise_Status == 'Disallowed' || currObj.Linewise_Status == 'Withheld') {
                            currObj.LineCurrHighlight = '1';
                            strGUIDData[0].LineCurrHighlight = '1';
                            if (currObj.LineComment == null || currObj.LineComment == "") {
                                currObj.LineIsRemarks = '1';
                                strGUIDData[0].LineIsRemarks = '1';
                            }
                        }

                        if (strwbselement && strLinedata.length) {
                            var strLinewiseTotal, LinewiseDisallowedCost, LinewiseDisallowed, withhelddisallowedcost, strCOstCOdewiseTotal, strDisCOstCOdewiseTotal, strCOstCOdewiseTotalWithDis, withhelddisallowedcostReport;
                            var strverifyHighlight, strverifyHighlightCC, strRemarksLine, strremarksCC;
                            //linewise total set to costcodewisetotal
                            for (var i = 0; i < strLinedata.length; i++) {
                                strLinewiseTotal = parseFloat(strLinewiseTotal || 0) + parseFloat(strLinedata[i].LineValue || 0);
                                //highlight pending remarks
                                strRemarksLine = parseFloat(strRemarksLine || 0) + parseFloat(strLinedata[i].LineIsRemarks || 0);
                                //highlight current edited node
                                strverifyHighlight = parseFloat(strverifyHighlight || 0) + parseFloat(strLinedata[i].LineCurrHighlight || 0);

                                if (strLinedata[i].Linewise_Status == 'Disallowed') {
                                    LinewiseDisallowed = parseFloat(LinewiseDisallowed || 0) + parseFloat(strLinedata[i].LineValue || 0);
                                }
                                else if (strLinedata[i].Linewise_Status == 'Withheld') {
                                    //add pending withheld amount as disallowed cost and also display in assessment tab as disallowed cost;
                                    withhelddisallowedcost = parseFloat(withhelddisallowedcost || 0) + (parseFloat(strLinedata[i].LineValue || 0) - parseFloat(strLinedata[i].Agreed_Cost || 0));
                                }

                            }
                            LinewiseDisallowedCost = parseFloat(LinewiseDisallowed || 0) + parseFloat(withhelddisallowedcost || 0);
                            //set in costcodewise total
                            settotalcostcodewise(strcostcodedata[0], strLinewiseTotal, LinewiseDisallowedCost, withhelddisallowedcost, 'TS', strverifyHighlight, strRemarksLine);
                            settotalcostcodewise(strmapcostcodedata[0], strLinewiseTotal, LinewiseDisallowedCost, withhelddisallowedcost, 'TS', strverifyHighlight, strRemarksLine);

                            //costcodewise total set into reportcodewise
                            for (var i = 0; i < strccdata.length; i++) {
                                strCOstCOdewiseTotal = parseFloat(strCOstCOdewiseTotal || 0) + parseFloat(strccdata[i].TotalCostCOdeTwo || 0);
                                strDisCOstCOdewiseTotal = parseFloat(strDisCOstCOdewiseTotal || 0) + parseFloat(strccdata[i].TotalDisCostCOdeTwo || 0);
                                strCOstCOdewiseTotalWithDis = parseFloat(strCOstCOdewiseTotalWithDis || 0) + parseFloat(strccdata[i].TotalCostCOdeTwoWithDis || 0);
                                withhelddisallowedcostReport = parseFloat(withhelddisallowedcostReport || 0) + parseFloat(strccdata[i].WitheldDisCostCOdeTwo || 0);
                                strverifyHighlightCC = parseFloat(strverifyHighlightCC || 0) + parseFloat(strccdata[i].CCTCurrHighlight || 0);
                                strremarksCC = parseFloat(strremarksCC || 0) + parseFloat(strccdata[i].CCTIsRemarks || 0);
                            }

                            //set in reportcodewise total
                            settotalreportcodewise(strreportdata[0], strCOstCOdewiseTotal, strDisCOstCOdewiseTotal, strCOstCOdewiseTotalWithDis, withhelddisallowedcostReport, 'TS', strverifyHighlightCC, strremarksCC);
                            settotalreportcodewise(strmapreportdata[0], strCOstCOdewiseTotal, strDisCOstCOdewiseTotal, strCOstCOdewiseTotalWithDis, withhelddisallowedcostReport, 'TS', strverifyHighlightCC, strremarksCC);

                            //set data for summarywise tab
                            var strtotalwbswisedata, strtotaldisallowed, strwithdisallowed, strtotalwithheldagreed, strwithhelddisallowedfinal;
                            for (var i = 0; i < strwbswisedata.length; i++) {
                                strtotalwbswisedata = parseFloat(strtotalwbswisedata || 0) + parseFloat(strwbswisedata[i].TotalReportCodeThree || 0);
                                strtotaldisallowed = parseFloat(strtotaldisallowed || 0) + parseFloat(strwbswisedata[i].TotalDisReportCodeThree || 0);
                                strwithdisallowed = parseFloat(strwithdisallowed || 0) + parseFloat(strwbswisedata[i].TotalReportCodeThreeWithDis || 0);
                                //strwithhelddisallowedfinal = parseFloat(strwithhelddisallowedfinal || 0) + parseFloat(strwbswisedata[i].WitheldDisReportCodethree || 0);
                            }
                            if (strwhwbswisedata && strwhwbswisedata.length) {
                                for (var i = 0; i < strwhwbswisedata.length; i++) {
                                    strtotalwithheldagreed = parseFloat(strtotalwithheldagreed || 0) + parseFloat(strwhwbswisedata[i].WH_TotalReportCodeThree || 0);
                                }
                            }
                            $scope.impsummaryData.IMP_Summary_Value = round(parseFloat(strwithdisallowed || 0), 2);
                            var disallowedwithwithheld = round(parseFloat(strtotaldisallowed || 0) + (parseFloat(strtotalwithheldagreed || 0) * -1), 2);
                            $scope.impsummaryData.Disallowed_Data = round(parseFloat(disallowedwithwithheld || 0), 2);
                            var strworkdonetodate = parseFloat(strwithdisallowed || 0) + parseFloat($scope.impsummaryData.Previous_AFP_Data || 0) - parseFloat(disallowedwithwithheld || 0);
                            $scope.impsummaryData.PriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0), 2);
                            $scope.impsummaryData.finalPriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0) + parseFloat($scope.impsummaryData.Other_Amount_AssessedByPM || 0), 2);

                            setBasicViewCalculation($scope.impsummaryData.finalPriceofWorkDonetoDate, '');

                        }
                    }

                }
                if (strType == 'Basic') {
                    //Added Row 20 Amount (Other amounts assessed by PM to be included in PWDD)
                    var strfinalworkdonetodate = round(parseFloat($scope.impsummaryData.PriceofWorkDonetoDate || 0) + parseFloat($scope.impsummaryData.Other_Amount_AssessedByPM || 0), 2);
                    $scope.impsummaryData.finalPriceofWorkDonetoDate = strfinalworkdonetodate;
                    setBasicViewCalculation(strfinalworkdonetodate, '');
                }
                if (strType == 'DetailWithheld') {
                    var strwbselement = currObj.WH_WBSElement;
                    var strReportCodeThree = currObj.WH_LineReportCodeThree;
                    var strCostCodeTwo = currObj.WH_LineCostCodeTwo;
                    var strGUID = currObj.WH_LineLevel_GUID;
                    //filter of main transaction data wbswise
                    var strwhmaindata = $scope.reportCodeAllGroup['ReportCodeGroup'];
                    var strwhwbswisedata;
                    if (strwhmaindata && strwhmaindata.length) {
                        strwhwbswisedata = mappingWBSWise(strwhmaindata, strwbselement, 'TS');
                    }

                    //filter of mappinglistdata
                    var strmapmaindata = $scope.mappingListWH;
                    var strmapreportdata = mappingReportCode(strmapmaindata, strwbselement, strReportCodeThree, 'WH');
                    var strmapccdata = strmapreportdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                    var strmapcostcodedata = mappingCostCode(strmapccdata, strwbselement, strReportCodeThree, strCostCodeTwo, 'WH');

                    //filter of main withheld xml data
                    var strmaindata = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
                    var strwbswisedata = mappingWBSWise(strmaindata, strwbselement, 'WH');
                    var strreportdata = mappingReportCode(strmaindata, strwbselement, strReportCodeThree, 'WH');
                    var strccdata = strreportdata[0]["WH_CostCodeTwoAllGroup"]["WH_CostCodeTwoGroup"];
                    var strcostcodedata = mappingCostCode(strccdata, strwbselement, strReportCodeThree, strCostCodeTwo, 'WH');

                    var strLinedata = strcostcodedata[0]["WH_LineLevelAllGroup"]["WH_LineLevelGroup"];

                    if (strGUID) {
                        var strGUIDData = commonApi._.filter(strLinedata, function (obj) {
                            return obj.WH_LineLevel_GUID.indexOf(strGUID) > -1;
                        });

                        strGUIDData[0].WH_Agreed_Cost = currObj.WH_Agreed_Cost;
                        strGUIDData[0].WH_LineComment = currObj.WH_LineComment;
                        currObj.WH_CurrHighlight = '0';
                        strGUIDData[0].WH_CurrHighlight = '0';
                        currObj.WH_LineIsRemarks = '0';
                        strGUIDData[0].WH_LineIsRemarks = '0';

                        if (parseFloat(currObj.WH_Agreed_Cost || 0) > parseFloat(currObj.WH_Pending_Cost || 0)) {
                            currObj.WH_Agreed_Cost = 0;
                            strGUIDData[0].WH_Agreed_Cost = 0;
                        }
                        if (currObj.WH_LineComment == null || currObj.WH_LineComment == "") {
                            strGUIDData[0].WH_LineComment = "";
                        }
                        else {
                            strGUIDData[0].WH_LineComment = currObj.WH_LineComment;
                        }

                        if (currObj.WH_Agreed_Cost != '' && parseFloat(currObj.WH_Agreed_Cost || 0) != 0 && currObj.WH_Agreed_Cost != null) {
                            currObj.WH_CurrHighlight = '1';
                            strGUIDData[0].WH_CurrHighlight = '1';
                            if (currObj.WH_LineComment == null || currObj.WH_LineComment == "") {
                                currObj.WH_LineIsRemarks = '1';
                                strGUIDData[0].WH_LineIsRemarks = '1';
                            }
                        }
                        if (strwbselement && strLinedata.length) {
                            var strLinewiseTotal, strCOstCOdewiseTotal, strRemarksLine, strverifyHighlight, strverifyHighlightCC, strremarksCC;
                            //linewise total set to costcodewisetotal
                            for (var i = 0; i < strLinedata.length; i++) {
                                //highlight pending remarks
                                strRemarksLine = parseFloat(strRemarksLine || 0) + parseFloat(strLinedata[i].WH_LineIsRemarks || 0);
                                //highlight current edited node
                                strverifyHighlight = parseFloat(strverifyHighlight || 0) + parseFloat(strLinedata[i].WH_CurrHighlight || 0);

                                strLinewiseTotal = parseFloat(strLinewiseTotal || 0) + parseFloat(strLinedata[i].WH_Agreed_Cost || 0);
                            }
                            //set in costcodewise total
                            settotalcostcodewise(strcostcodedata[0], strLinewiseTotal, '', '', 'WH', strverifyHighlight, strRemarksLine);
                            settotalcostcodewise(strmapcostcodedata[0], strLinewiseTotal, '', '', 'WH', strverifyHighlight, strRemarksLine);
                            //costcodewise total set into reportcodewise
                            for (var i = 0; i < strccdata.length; i++) {
                                strCOstCOdewiseTotal = parseFloat(strCOstCOdewiseTotal || 0) + parseFloat(strccdata[i].WH_TotalCostCOdeTwo || 0);
                                strverifyHighlightCC = parseFloat(strverifyHighlightCC || 0) + parseFloat(strccdata[i].WH_CCTCurrHighlight || 0);
                                strremarksCC = parseFloat(strremarksCC || 0) + parseFloat(strccdata[i].WH_CCTIsRemarks || 0);
                            }

                            //set in reportcodewise total
                            settotalreportcodewise(strreportdata[0], strCOstCOdewiseTotal, '', '', '', 'WH', strverifyHighlightCC, strremarksCC);
                            settotalreportcodewise(strmapreportdata[0], strCOstCOdewiseTotal, '', '', '', 'WH', strverifyHighlightCC, strremarksCC);

                            //set data for summarywise tab
                            var strtotalwithheldagreed, strwithdisallowed, strtotaldisallowed;
                            for (var i = 0; i < strwbswisedata.length; i++) {
                                strtotalwithheldagreed = parseFloat(strtotalwithheldagreed || 0) + parseFloat(strwbswisedata[i].WH_TotalReportCodeThree || 0);
                            }
                            if (strwhwbswisedata.length > 0) {
                                for (var i = 0; i < strwhwbswisedata.length; i++) {
                                    strwithdisallowed = parseFloat(strwithdisallowed || 0) + parseFloat(strwhwbswisedata[i].TotalReportCodeThreeWithDis || 0);
                                    strtotaldisallowed = parseFloat(strtotaldisallowed || 0) + parseFloat(strwhwbswisedata[i].TotalDisReportCodeThree || 0);
                                }
                            }
                            $scope.impsummaryData.IMP_Summary_Value = round(parseFloat(strwithdisallowed || 0), 2);
                            var disallowedwithwithheld = round(parseFloat(strtotaldisallowed || 0) + (parseFloat(strtotalwithheldagreed || 0) * -1), 2);
                            $scope.impsummaryData.Disallowed_Data = parseFloat(disallowedwithwithheld || 0);
                            var strworkdonetodate = parseFloat(strwithdisallowed || 0) + parseFloat($scope.impsummaryData.Previous_AFP_Data || 0) - parseFloat(disallowedwithwithheld || 0)
                            $scope.impsummaryData.PriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0), 2);
                            $scope.impsummaryData.finalPriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0) + parseFloat($scope.impsummaryData.Other_Amount_AssessedByPM || 0), 2);

                            setBasicViewCalculation($scope.impsummaryData.finalPriceofWorkDonetoDate, '');
                        }
                    }

                }
                if (strType == 'ActivityDetail') {
                    var strChildactdata = $scope.OptionAgroup['OptionADetails'][0]['OptActivity_Group']['OptAContract_Activities'];
                    if (strChildactdata && strChildactdata.length) {
                        var i = 0, strwbswiseValue, strwbswiseDisallowed, tempagreedtotal;
                        for (; i < strChildactdata.length; i++) {
                            strChildactdata[i].OptActivity_Value;
                            strChildactdata[i].OptActivity_Status;
                            strwbswiseValue = parseFloat(strwbswiseValue || 0) + parseFloat(strChildactdata[i].OptActivity_Value || 0);
                            if (strChildactdata[i].OptActivity_Status == 'No') {
                                strwbswiseDisallowed = parseFloat(strwbswiseDisallowed || 0) + parseFloat(strChildactdata[i].OptActivity_Value || 0);
                            }
                            if (strChildactdata[i].OptActivity_Status == 'Yes') {
                                tempagreedtotal = parseFloat(tempagreedtotal || 0) + parseFloat(strChildactdata[i].OptActivity_Value || 0);
                            }
                        }
                        parObj['tempTotalAgreedActivityValue'] = parseFloat(tempagreedtotal || 0);
                        $scope.impsummaryData.IMP_Summary_Value = round(parseFloat(strwbswiseValue || 0), 2);
                        $scope.impsummaryData.Disallowed_Data = round(parseFloat(strwbswiseDisallowed || 0), 2);
                        var strworkdonetodate = (parseFloat($scope.impsummaryData.IMP_Summary_Value || 0) + parseFloat($scope.impsummaryData.Previous_AFP_Data || 0)) - parseFloat(strwbswiseDisallowed || 0);
                        $scope.impsummaryData.PriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0), 2);
                        $scope.impsummaryData.finalPriceofWorkDonetoDate = round(parseFloat(strworkdonetodate || 0) + parseFloat($scope.impsummaryData.Other_Amount_AssessedByPM || 0), 2);

                        setBasicViewCalculation($scope.impsummaryData.finalPriceofWorkDonetoDate, '');
                    }
                }
            }
        }
        //mapping of costcode two and reportcode
        function mappingReportCode(strmapmaindata, strwbselement, strReportCodeThree, strtype) {
            var strmapreportdata;
            if (strtype == 'TS') {
                strmapreportdata = commonApi._.filter(strmapmaindata, function (obj) {
                    return obj.ReportWbsElement.indexOf(strwbselement) > -1 && obj.ReportCodeThree.indexOf(strReportCodeThree) > -1;
                });
            }
            else if (strtype == 'WH') {
                strmapreportdata = commonApi._.filter(strmapmaindata, function (obj) {
                    return obj.WH_ReportWbsElement.indexOf(strwbselement) > -1 && obj.WH_ReportCodeThree.indexOf(strReportCodeThree) > -1;
                });
            }
            return strmapreportdata
        }

        function mappingCostCode(strmapccdata, strwbselement, strReportCodeThree, strCostCodeTwo, strtype) {
            var strmapcostcodedata;
            if (strtype == 'TS') {
                strmapcostcodedata = commonApi._.filter(strmapccdata, function (obj) {
                    return obj.CCWBSElement.indexOf(strwbselement) > -1 && obj.CCReportCodeThree.indexOf(strReportCodeThree) > -1 && obj.CostCodeTwo.indexOf(strCostCodeTwo) > -1;
                });
            }
            else if (strtype == 'WH') {
                strmapcostcodedata = commonApi._.filter(strmapccdata, function (obj) {
                    return obj.WH_CCWBSElement.indexOf(strwbselement) > -1 && obj.WH_CCReportCodeThree.indexOf(strReportCodeThree) > -1 && obj.WH_CostCodeTwo.indexOf(strCostCodeTwo) > -1;
                });
            }
            return strmapcostcodedata
        }
        function mappingWBSWise(strmaindata, strwbselement, strtype) {
            var strwbswisedata;
            if (strtype == 'TS') {
                strwbswisedata = commonApi._.filter(strmaindata, function (obj) {
                    return obj.ReportWbsElement.indexOf(strwbselement) > -1;
                });
            }
            else if (strtype == 'WH') {
                strwbswisedata = commonApi._.filter(strmaindata, function (obj) {
                    return obj.WH_ReportWbsElement.indexOf(strwbselement) > -1;
                });
            }
            return strwbswisedata;
        }
        function settotalcostcodewise(strcostcodedata, strLinewiseTotal, LinewiseDisallowedCost, linewisewithhelddisallowed, strtype, strverifyHighlight, strRemarksLine) {
            if (strtype == 'TS') {
                strcostcodedata.TotalCostCOdeTwo = parseFloat(strLinewiseTotal || 0) - parseFloat(LinewiseDisallowedCost || 0);
                strcostcodedata.TotalDisCostCOdeTwo = parseFloat(LinewiseDisallowedCost || 0);
                strcostcodedata.TotalCostCOdeTwoWithDis = parseFloat(strLinewiseTotal || 0);
                strcostcodedata.WitheldDisCostCOdeTwo = parseFloat(linewisewithhelddisallowed || 0);
                strcostcodedata.CCTCurrHighlight = '0';
                strcostcodedata.CCTIsRemarks = '0';
                if (parseFloat(strverifyHighlight || 0) > 0) {
                    strcostcodedata.CCTCurrHighlight = '1';
                }
                if (parseFloat(strRemarksLine || 0) > 0) {
                    strcostcodedata.CCTIsRemarks = '1';
                }
            }
            else if (strtype == 'WH') {
                strcostcodedata.WH_TotalCostCOdeTwo = parseFloat(strLinewiseTotal || 0);
                strcostcodedata.WH_CCTCurrHighlight = '0';
                strcostcodedata.WH_CCTIsRemarks = '0';
                if (parseFloat(strverifyHighlight || 0) > 0) {
                    strcostcodedata.WH_CCTCurrHighlight = '1';
                }
                if (parseFloat(strRemarksLine || 0) > 0) {
                    strcostcodedata.WH_CCTIsRemarks = '1';
                }
            }
        }
        function settotalreportcodewise(strreportdata, strCOstCOdewiseTotal, strDisCOstCOdewiseTotal, strCOstCOdewiseTotalWithDis, strwithhelddisallowedReport, strtype, strverifyHighlightCC, strremarksCC) {
            if (strtype == 'TS') {
                strreportdata.TotalReportCodeThree = parseFloat(strCOstCOdewiseTotal || 0);
                strreportdata.TotalDisReportCodeThree = parseFloat(strDisCOstCOdewiseTotal || 0);
                strreportdata.TotalReportCodeThreeWithDis = parseFloat(strCOstCOdewiseTotalWithDis || 0);
                strreportdata.WitheldDisReportCodethree = parseFloat(strwithhelddisallowedReport || 0);
                strreportdata.RPCurrHighlight = '0';
                strreportdata.RPIsRemarks = '0';
                if (parseFloat(strverifyHighlightCC || 0) > 0) {
                    strreportdata.RPCurrHighlight = '1';
                }
                if (parseFloat(strremarksCC || 0) > 0) {
                    strreportdata.RPIsRemarks = '1';
                }
            }
            else if (strtype == 'WH') {
                strreportdata.WH_TotalReportCodeThree = parseFloat(strCOstCOdewiseTotal || 0);
                strreportdata.WH_RPCurrHighlight = '0';
                strreportdata.WH_RPIsRemarks = '0';
                if (parseFloat(strverifyHighlightCC || 0) > 0) {
                    strreportdata.WH_RPCurrHighlight = '1';
                }
                if (parseFloat(strremarksCC || 0) > 0) {
                    strreportdata.WH_RPIsRemarks = '1';
                }
            }
        }
        //set basic's calculation based on detail and basic view's amount change

        function setBasicViewCalculation(strfinalPriceofWorkDonetoDate, currObj) {
            strfinalPriceofWorkDonetoDate = parseFloat(strfinalPriceofWorkDonetoDate || 0);

            //Row 26 amount other amount
            var strOther_Amount_PaidByPM = parseFloat($scope.impsummaryData.Other_Amount_PaidByPM || 0);
            //set subtotal
            $scope.impsummaryData.Total_finaldonetodate_othpaidbypm = round(parseFloat($scope.impsummaryData.Other_Amount_PaidByPM || 0) + parseFloat(strfinalPriceofWorkDonetoDate || 0), 2);
            //ROW 31 amount (25% of PWDD no first programme (Schedule 3 50.5))
            var strPWDDNoFirstProgramme = $scope.impsummaryData.PWDDNoFirstProgramme;
            var strPWDDNoFirstProgrammeamt;
            if (strPWDDNoFirstProgramme == 'No') {
                $scope.impsummaryData.PWDDNoFirstProgramme_Amt = strfinalPriceofWorkDonetoDate != 0 ? round(((strfinalPriceofWorkDonetoDate * 25) / 100), 2) : 0;
                strPWDDNoFirstProgrammeamt = parseFloat($scope.impsummaryData.PWDDNoFirstProgramme_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoFirstProgramme_Amt = '';
                strPWDDNoFirstProgrammeamt = 0;
            }
            //Row 32 amount (25% of PWDD since last accepted programme if no revised programme submitted (Schedule 3 32.3))
            var strPwddprogrammeLast = $scope.impsummaryData.PWDDLastAcceptedProg;
            var strPwddprogrammeLastamt;
            if (strPwddprogrammeLast == 'No') {
                strPwddprogrammeLastamt = parseFloat($scope.impsummaryData.PWDDLastAcceptedProg_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDLastAcceptedProg_Amt = '';
                strPwddprogrammeLastamt = 0;
            }

            // ROW 33 (15% of PWDD no Baseline, Forecast and Actual cost profile / data provided (Schedule 4 4.3.5.3))
            var strBaseline = $scope.impsummaryData.PWDDNoBaseForeActual;
            var strbaseamount;
            if (strBaseline == 'No') {
                $scope.impsummaryData.PWDDNoBaseForeActual_Amt = strfinalPriceofWorkDonetoDate != 0 ? round(((strfinalPriceofWorkDonetoDate * 15) / 100), 2) : 0;
                strbaseamount = parseFloat($scope.impsummaryData.PWDDNoBaseForeActual_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoBaseForeActual_Amt = '';
                strbaseamount = 0;
            }

            //ROW 33 part 2
            $scope.impsummaryData.PWDDNoFore = $scope.oriMsgCustomFields.IsForecast;
            var strfore = $scope.impsummaryData.PWDDNoFore;
            var strforeamount;
            if (strfore == 'No') {
                strforeamount = parseFloat($scope.impsummaryData.PWDDNoFore_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoFore_Amt = '';
                strforeamount = 0;
            }
            //ROW 33 Part 3
            $scope.impsummaryData.PWDDNoActual = $scope.oriMsgCustomFields.IsActual;
            var stractual = $scope.impsummaryData.PWDDNoActual;
            var stractualamount;
            if (stractual == 'No') {
                stractualamount = parseFloat($scope.impsummaryData.PWDDNoActual_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoActual_Amt = '';
                stractualamount = 0;
            }
            //ROw 34 15% of PWDD no pre-construction estimate provided within 28 days of commencement of construction (Schedule 4 4.3.5.3)
            var strPWDDNoPreConstruction = $scope.impsummaryData.PWDDNoPreConstruction;
            var strPWDDNoPreConstruction_Amt;
            if (strPWDDNoPreConstruction == 'No') {
                $scope.impsummaryData.PWDDNoPreConstruction_Amt = strfinalPriceofWorkDonetoDate != 0 ? round(((strfinalPriceofWorkDonetoDate * 15) / 100), 2) : 0;
                strPWDDNoPreConstruction_Amt = parseFloat($scope.impsummaryData.PWDDNoPreConstruction_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoPreConstruction_Amt = '';
                strPWDDNoPreConstruction_Amt = 0;
            }
            // ROW 35 15% of PWDD no construction phase plan provided 2 weeks prior to commencement of construction (Schedule 4 4.3.5.3)
            var strPWDDNoConstruction = $scope.impsummaryData.PWDDNoConstruction;
            var strPWDDNoConstruction_Amt;
            if (strPWDDNoConstruction == 'No') {
                $scope.impsummaryData.PWDDNoConstruction_Amt = strfinalPriceofWorkDonetoDate != 0 ? round(((strfinalPriceofWorkDonetoDate * 15) / 100), 2) : 0;
                strPWDDNoConstruction_Amt = parseFloat($scope.impsummaryData.PWDDNoConstruction_Amt || 0);
            }
            else {
                $scope.impsummaryData.PWDDNoConstruction_Amt = '';
                strPWDDNoConstruction_Amt = 0;
            }
            //ROW 36 100% of amount due since last payment no Health and Safety file at Completion
            //Row 37 100% of amount due since last payment no O&M file at Completion
            var strNoHealthandSafety = $scope.impsummaryData.NoHealthandSafety;
            var strNoOandMFile = $scope.impsummaryData.NoOandMFile;

            var strNoHealthandSafety_Amt;
            if (strNoHealthandSafety == 'No' || strNoOandMFile == 'No') {
                $scope.impsummaryData.NoHealthandSafety_Amt = strfinalPriceofWorkDonetoDate;
                strNoHealthandSafety_Amt = parseFloat($scope.impsummaryData.NoHealthandSafety_Amt || 0);
            }
            else {
                $scope.impsummaryData.NoHealthandSafety_Amt = '';
                strNoHealthandSafety_Amt = 0;
            }

            //ROW 38 Delay Damages
            var strDelay = parseFloat($scope.impsummaryData.DelayDamages || 0);

            //Row 39 Other Deduction
            var strotherdeduction = parseFloat($scope.impsummaryData.OtherDeductions || 0);

            //Total Less Amount
            var strafpType = $scope.oriMsgCustomFields['Application_for_Payment_Type'];
            var strTotalLessAmount;
            if (strafpType == NEC4_CONSTANT.appforpayment) {
                strTotalLessAmount = parseFloat(strPWDDNoFirstProgrammeamt || 0) + parseFloat(strPwddprogrammeLastamt || 0) +
                    parseFloat(strbaseamount || 0) + parseFloat(strforeamount || 0) + parseFloat(stractualamount || 0) +
                    parseFloat(strPWDDNoPreConstruction_Amt || 0) + parseFloat(strPWDDNoConstruction_Amt || 0) +
                    parseFloat(strotherdeduction || 0);
            }
            else if (strafpType == NEC4_CONSTANT.finalappforpayment) {
                strTotalLessAmount = parseFloat(strPWDDNoPreConstruction_Amt || 0) + parseFloat(strNoHealthandSafety_Amt || 0) +
                    parseFloat(strotherdeduction || 0);
            }

            $scope.impsummaryData.TotalLessAmount = round(parseFloat(strTotalLessAmount || 0), 2);
            $scope.impsummaryData.PaymentDue = round((parseFloat(strfinalPriceofWorkDonetoDate || 0) + parseFloat(strOther_Amount_PaidByPM || 0)) - (parseFloat($scope.impsummaryData.PaidtoDate || 0) + parseFloat($scope.impsummaryData.HistoricPaidtoDate || 0) + parseFloat(strTotalLessAmount || 0)), 2);
            //CR - set certified amount
            $scope.impsummaryData.Certified = parseFloat($scope.impsummaryData.PaymentDue || 0) - parseFloat(strDelay || 0);

            //CR - certified sub total 
            $scope.impsummaryData.CertifiedSubTotal = parseFloat($scope.impsummaryData.Certified || 0) + parseFloat($scope.impsummaryData.ExternallyReceived || 0);

            //CR - receipted value
            $scope.impsummaryData.Receipted = parseFloat($scope.impsummaryData.Certified || 0) + parseFloat($scope.impsummaryData.ExternallyReceived || 0);

        }


        //#endregion Payment Assessment tab related calculation
        //#region Option A Tab
        function mapCostCodes() {
            //FOrmid # OptA_RefWBSElement# OptA_RefWBSElement_Name#
            //OptActivity_Code# OptActivity_Name# OptActivity_Value# OptActivity_Status # OptActivity_Guid # DS_ASI_STD_ECC4_STW_WBSElementList
            if (strisDraft_Res_msg == "NO" || strisDraft_Res_msg == "") {
                $scope.OptionAgroup['OptionADetails'] = [];
                var tmpCostCodes;
                if (currentViewName == "ORI_PRINT_VIEW") {
                    tmpCostCodes = ds_ASI_STD_ECC4_STW_DISPLAYORIGINAL_ACTIVITYDATA;
                }
                else {
                    tmpCostCodes = ds_ASI_STD_ECC4_STW_WBSELEMENTLISTACTIVITYWISE;
                }

                var hstSection = {};
                var strXml = "";
                var blIsActivity = false;
                var i = 0, k = 0, tempSectionArray = [];
                var element, strSectionCode, strHstSecCode, strSecXml;

                if (tmpCostCodes && tmpCostCodes.length) {

                    for (; i < tmpCostCodes.length; i++) {
                        element = tmpCostCodes[i];
                        strSectionCode = element.Value2 || '';
                        strHstSecCode = strSectionCode.trim().toLowerCase();
                        strXml = "";
                        blIsActivity = false;
                        if (!hstSection.hasOwnProperty(strHstSecCode)) {
                            strXml = mapImportedSection(element, strSectionCode);//map Section
                        } else {
                            strXml = mapImportedActivity(element, strSectionCode); //map Cost Code
                            blIsActivity = true;
                        }

                        if (blIsActivity) {
                            strSecXml = hstSection[strHstSecCode];
                            strSecXml["OptActivity_Group"]["OptAContract_Activities"].push(strXml);
                            hstSection[strHstSecCode] = strSecXml;

                        } else {
                            hstSection[strHstSecCode] = strXml;
                        }
                    }

                    tempSectionArray = [];
                    for (var key in hstSection) {
                        if (hstSection.hasOwnProperty(key)) {
                            tempSectionArray.push(hstSection[key]);
                        }
                    }
                    $scope.OptionAgroup['OptionADetails'] = angular.copy(tempSectionArray);
                    var strParoptionA = $scope.OptionAgroup['OptionADetails'];
                    for (; k < strParoptionA.length; k++) {
                        element = strParoptionA[k]['OptActivity_Group']['OptAContract_Activities'];
                        var tempTotal = 0, tempagreedtotal = 0, index = 0;
                        for (; index < element.length; index++) {
                            var strstatus = element[index]['OptActivity_Status'];
                            if (strstatus.toLowerCase() == 'yes') {
                                tempagreedtotal += (parseFloat(element[index]['OptActivity_Value']) || 0);
                            }
                            tempTotal += (parseFloat(element[index]['OptActivity_Value']) || 0);
                        }
                        strParoptionA[k]['tempTotalAgreedActivityValue'] = angular.copy(tempagreedtotal.toFixed(2));
                        strParoptionA[k]['tempTotalActivityValue'] = angular.copy(tempTotal.toFixed(2));
                    }
                }
            }
            $scope.mappingListActivity = $scope.OptionAgroup['OptionADetails'];
        }

        function mapImportedSection(tmpLoop) {
            var sectionNode = angular.copy(STATIC_OBJ_DATA.OptionADetails);
            sectionNode.OptAWBSElement_Code = tmpLoop.Value2;
            sectionNode.OptAWBSElement_Name = tmpLoop.Value3;
            sectionNode["OptActivity_Group"]["OptAContract_Activities"] = [mapImportedActivity(tmpLoop)];

            return sectionNode;
        }

        function mapImportedActivity(tmpLoop) {
            var contractActivityNode = angular.copy(STATIC_OBJ_DATA.OptAContract_Activities);
            contractActivityNode["OptA_RefWBSElement"] = tmpLoop.Value2;
            contractActivityNode["OptActivity_Code"] = tmpLoop.Value4;
            contractActivityNode["OptActivity_Name"] = tmpLoop.Value5;
            contractActivityNode["OptActivity_Value"] = round(tmpLoop.Value6, 2);
            contractActivityNode["OptActivity_Status"] = tmpLoop.Value7;
            contractActivityNode["OptActivity_Guid"] = tmpLoop.Value8;
            contractActivityNode["OptActivity_Comment"] = tmpLoop.Value10;
            return contractActivityNode;
        }
        //filter data for ORI view's original data
        $scope.applyFilterCallForActivity = function (event, strwbsisexist, strtype) {
            filterActivitydata(event, strwbsisexist, strtype);
        };
        //filter data
        function filterActivitydata(event, strwbsisexist, strtype) {
            //fetch filter nodes value
            var strfltWBSElement;
            if (strtype == 'wbswise') {
                strfltWBSElement = strwbsisexist;
                $scope.filterFieldObj.fltWBSElementAct = strwbsisexist;
                setCurrentSection('activity-detail.html');
            }
            else {
                strfltWBSElement = $scope.filterFieldObj.fltWBSElementAct;
            }
            //filter wbselement in activity data
            var stralldata = $scope.OptionAgroup['OptionADetails'];
            if (strfltWBSElement != "") {
                stralldata = commonApi._.filter(stralldata, function (obj) {
                    return obj.OptAWBSElement_Code.indexOf(strfltWBSElement) > -1;
                });
            }
            $scope.mappingListActivity = stralldata;

        }

        //reset filter data
        $scope.resetActivitydata = function (event) {
            $scope.filterFieldObj = {
                fltWBSElement: '',
                fltCostCode: '',
                fltWBSElementAct: ''
            };
            filterActivitydata(event, '', 'All');
        };

        //#endregion Option A Tab
        //#region General
        $scope.getPaginationArray = function (totalRecords, batchSize) {
            if (totalRecords == 0) {
                return [{
                    name: '0-0',
                    value: 0,
                }];
            }
            if (totalRecords <= batchSize) {
                return [{
                    name: '1-' + totalRecords,
                    value: 0
                }];
            }

            var tempArr = [];
            var pageNumber = 1;
            var strremainder = parseFloat(totalRecords || 0) % 2;
            if(strremainder == 0)
            {
                while (totalRecords > (batchSize * pageNumber - batchSize)) {
                    tempArr.push({
                        name: ((pageNumber * batchSize - batchSize) + 1) + '-' + (totalRecords < batchSize * pageNumber ? totalRecords : batchSize * pageNumber),
                        value: pageNumber - 1,
                    });
                    pageNumber++;
                }
            }
            else if(strremainder == 1)
            {
                while (totalRecords >= (batchSize * pageNumber - batchSize)) {
                    tempArr.push({
                        name: ((pageNumber * batchSize - batchSize) + 1) + '-' + (totalRecords < batchSize * pageNumber ? totalRecords : batchSize * pageNumber),
                        value: pageNumber - 1,
                    });
                    pageNumber++;
                }
            }

            return tempArr;
        };
        function isDraftValidationForPM_QS() {
            showsavedraftbutton();
            ShowSendbutton();
            $scope.isNotDisplayInavlidUser = false;
            var lst = ds_ASI_STD_ECC4_STW_VERIFY_DRAFT_RESPONCES_DATA;
            var strflagQS, strflagPM;
            if (lst && lst.length) {
                for (var i = 0; i < lst.length; i++) {
                    strflagQS = lst[i].Value2;
                    strflagPM = lst[i].Value3;
                }
                if (strflagQS.toLowerCase() == 'yes' || strflagPM.toLowerCase() == 'yes') {
                    $scope.isNotDisplayInavlidUser = true;
                    hidesavedraftbutton();
                    hideSendbutton();
                }
            }
        }
        //setpm flag true if pm is working user
        function isPMworkinguser() {
            var strVal = $scope.oriMsgFields['DS_PROJUSERS_ROLE'];
            if (strVal != "") {
                var struser = strVal.split('|')[2].split('#')[0].trim();
                if (dsWorkingUserId == struser) {
                    $scope.isPM = true;
                }
            }
        }
        //check pending action
        function checkPendingAction(strUser) {
            //check user have any pending action or not
            ds_incomplete_ACTIONS_BYMSG = commonApi._.filter(ds_incomplete_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Respond";
            });
            if (ds_incomplete_ACTIONS_BYMSG && ds_incomplete_ACTIONS_BYMSG.length) {
                for (var i = 0; i < ds_incomplete_ACTIONS_BYMSG.length; i++) {
                    var strUserId = ds_incomplete_ACTIONS_BYMSG[i].Value1;
                    if (strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return false;
        }
        function validateDate() {
            var strIstransaction = $scope.oriMsgCustomFields['DSI_IsTransaction'];
            var strformatteddate, stronlydate, fltdate, verifydte,verifyrole,strOnlyMonth,strOnlyYear;
            var strTodayDate = $scope.setDbDateClientSide(0);
            strformatteddate = $scope.formatDate(new Date(strTodayDate), NEC4_CONSTANT.yymmdddateformate);
            showsavedraftbutton();
            ShowSendbutton();
            $scope.isdateSectionShow = true;
            $scope.isdateSectionShowPM = true;
            var verifyPMallowedforResponce = dS_ASI_STD_ECC4_STW_Child_Form_Action_Details[0].Value5;
            var strdate = $scope.afpDetails['DSI_Verifydate'];
            if ($scope.oriMsgCustomFields['Application_for_Payment_Type'] == NEC4_CONSTANT.appforpayment) {
                var strformcreation = '',verifymonth,verifyyear;
                if($scope.oriMsgCustomFields['DSI_Creationdate'])
                {
                    strformcreation = $scope.formatDate(new Date($scope.oriMsgCustomFields['DSI_Creationdate']), NEC4_CONSTANT.yymmdddateformate);
                    verifymonth = strformcreation.split('-')[1].trim();
                    verifyyear = strformcreation.split('-')[0].trim();
                }
                stronlydate = strformatteddate.split('-')[2].trim();
                strOnlyMonth = strformatteddate.split('-')[1].trim();
                strOnlyYear = strformatteddate.split('-')[0].trim();
                if(strOnlyMonth == verifymonth && strOnlyYear == verifyyear)
                {
                    fltdate = parseFloat(stronlydate || 0);
                    verifydte = parseFloat(strdate || 0);
                    var count;
                    if ($scope.oriMsgCustomFields['DSI_OptionType'].indexOf('Option A') > -1) {
                        if (verifyPMallowedforResponce == 'No') {
                            verifyrole = true; //$scope.isDraftPM - draft Pm contains Action;
                            count = parseFloat($scope.oriMsgFields['DS_RES_COUNT'] || 0);
                        }
                        else {
                            if (fltdate > verifydte && $scope.isDraftPM) {
                                verifyrole = true; //$scope.isDraftPM - draft Pm contains Action but date is passed for draft PM so Pm can directly reply;
                            }
                            else {
                                verifyrole = false; //$scope.isDraftPM - draft Pm not contains Action so Pm can directly reply;
                                count = -1;
                            }
                        }
                    }
                    else {
                        verifyrole = $scope.isQS;
                        count = parseFloat($scope.oriMsgFields['DS_RES_COUNT'] || 0);
                    }

                    if (strIstransaction == 'Yes') {
                        if (fltdate <= verifydte && $scope.isPM && count == 0) {
                            //if date is not passed and before that Pm is trying to reply but QS/Draftpm(action exist)do not reply then PM will get error message
                            $scope.isdateSectionShowPM = false;
                            hidesavedraftbutton();
                            hideSendbutton();
                        }
                        if (fltdate > verifydte && verifyrole) {
                            //if date is passed and responder is draft pm or qs then they will not able to reply
                            $scope.isdateSectionShow = false;
                            hidesavedraftbutton();
                            hideSendbutton();
                        }
                        if (fltdate <= verifydte && $scope.isPM && count == -1 && !verifyrole) {
                            //it will check when DraftPm doesnot contain any action then PM will able to reply
                            $scope.oriMsgCustomFields['DSI_Currentstage'] = '2';
                        }
                        if (fltdate > verifydte && !verifyrole) {
                            //if draftpm and qs contains action but date is passed then PM can able to reply
                            $scope.oriMsgCustomFields['DSI_Currentstage'] = '2';
                        }
                    }
                    else {
                        if ($scope.isPM) {
                            $scope.oriMsgCustomFields['DSI_Currentstage'] = '2';
                        }
                        else {
                            if (fltdate > verifydte && verifyrole) {
                                //if date is passed and responder is draft pm or qs then they will not able to reply
                                $scope.isdateSectionShow = false;
                                hidesavedraftbutton();
                                hideSendbutton();
                            }
                        }
                    }
                }
                else
                {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| You are not authorized to reply to the form as the AFP is of last month and PM can reply on the main AFP form.";
                    hidesavedraftbutton();
                    hideSendbutton();
                }
            }
            else {
                if ($scope.isPM && verifyPMallowedforResponce == 'No') {
                    $scope.isdateSectionShowPM = false;
                    hidesavedraftbutton();
                    hideSendbutton();
                }
                else if ($scope.isPM && verifyPMallowedforResponce != 'No' && $scope.oriMsgCustomFields['DSI_OptionType'].indexOf("Option A") > -1) {
                    $scope.oriMsgCustomFields['DSI_Currentstage'] = '3';
                }
            }
        }
        function validateCommentForOptionA() {
            var stralldata = $scope.OptionAgroup['OptionADetails'];
            if (stralldata && stralldata.length) {
                var strSubdata = stralldata[0]['OptActivity_Group']['OptAContract_Activities'];
                var k = 0;
                if (strSubdata.length) {
                    for (; k < strSubdata.length; k++) {
                        if ((strSubdata[k]['OptActivity_Comment'] == '' || strSubdata[k]['OptActivity_Comment'] == null) && strSubdata[k]['OptActivity_Status'].toLowerCase().trim() == 'no') {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        function hidesavedraftbutton() {
            var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
            $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        }
        function showsavedraftbutton() {
            var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
            $saveDraftBtn && ($saveDraftBtn.style.display = 'inline');
        }
        function hideSendbutton() {
            var $sendBtn = $window.document.getElementById('btnSaveForm');
            $sendBtn && ($sendBtn.style.display = 'none');
        }
        function ShowSendbutton() {
            var $sendBtn = $window.document.getElementById('btnSaveForm');
            $sendBtn && ($sendBtn.style.display = 'inline');
        }
        function clearAction() {

            if (ds_incomplete_ACTIONS_BYMSG && ds_incomplete_ACTIONS_BYMSG.length) {
                var actionData = commonApi._.filter(ds_incomplete_ACTIONS_BYMSG, function (val) {
                    return val.Value4 == 'Respond';
                });
                if (actionData && actionData.length) {
                    $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                    $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                    var insertpoint = $scope.asiteSystemDataReadwrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                    for (var i = 0; i < actionData.length; i++) {
                        var struserid = actionData[i].Value1;
                        if (struserid != dsWorkingUserId) {
                            var AutocompleteActionStructure = angular.copy(STATIC_OBJ_DATA.Auto_Complete_msg_Action);
                            AutocompleteActionStructure.DS_MSG_AC_TYPE = "clear";
                            AutocompleteActionStructure.DS_MSG_AC_FORM = AppId;
                            AutocompleteActionStructure.DS_MSG_AC_MSG_TYPE = actionData[i].Value3;
                            AutocompleteActionStructure.DS_MSG_AC_USERID = struserid;
                            AutocompleteActionStructure.DS_MSG_AC_ACTION = "3";
                            AutocompleteActionStructure.DS_MSG_AC_ACTION_REMARKS = "clear actions";
                            insertpoint.push(AutocompleteActionStructure);
                        }
                    }
                }
            }
        }
        function round(value, decimals) {
            return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
        }
        function setOverallformstatus(strstatus) {
            if (strstatus != "") {
                var strFormStatusId = getFormStatusId(strstatus);
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
                }
            }
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter          
            if (ds_all_Active_Form_Status && ds_all_Active_Form_Status.length) {
                var statudObj = commonApi._.filter(ds_all_Active_Form_Status, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        function validateremarks() {
            var verifyTransaction, verifyWithheld;
            var strlst = $scope.reportCodeAllGroup['ReportCodeGroup'];
            var strlstwh = $scope.whreportCodeAllGroup['WH_ReportCodeGroup'];
            if (strlst && strlst.length) {
                var strvaliddata = commonApi._.filter(strlst, function (obj) {
                    return obj.RPIsRemarks == '1';
                });
                verifyTransaction = 'No';
                if (strvaliddata.length > 0) {
                    verifyTransaction = 'Yes';
                }
            }
            if (strlstwh && strlstwh.length) {
                var strvaliddatawh = commonApi._.filter(strlstwh, function (obj) {
                    return obj.WH_RPIsRemarks == '1';
                });
                verifyWithheld = 'No';
                if (strvaliddatawh.length > 0) {
                    verifyWithheld = 'Yes';
                }
            }
            if (verifyWithheld == 'Yes' || verifyTransaction == 'Yes') {
                return true;
            }
            return false;
        }
        //#endregion General Tab
        //final callback
        $window.afpFinalCallBack = function () {
            return $scope.setFlow();
        }
        $scope.setFlow = function () {
            clearAction();
            if ($scope.oriMsgCustomFields['DSI_OptionType'].indexOf("Option A") > -1 && $scope.oriMsgCustomFields['Application_for_Payment_Type'] == NEC4_CONSTANT.finalappforpayment) {
                var strVal = $scope.oriMsgFields['DS_PROJUSERS_ROLE'];
                var struser = '';
                if (strVal != "") {
                    struser = strVal.split('|')[2].trim();
                }
                var currentstage = $scope.oriMsgCustomFields['DSI_Currentstage'];
                var strdate = $scope.setDbDateClientSide(5);
                $scope.asiteSystemDataReadwrite.REPEATING_VALUES.Auto_Distribute_Group.Auto_Distribute_Users = [];
                if (currentstage) {
                    switch (currentstage) {
                        case '1':
                            $scope.oriMsgFields.DS_AUTODISTRIBUTE = "13";
                            var lstdraftpm = commonApi._.filter(ds_asi_std_ecc4_all_contract_team_members, function (val) {
                                return val.Value.split('|')[1].trim() == "Emp_Others"; //'Draft Only';
                            });
                            if (lstdraftpm && lstdraftpm.length) {
                                var i = 0;
                                for (; i < lstdraftpm.length; i++) {
                                    var approverVal = lstdraftpm[i].Value.split('|')[2].trim();
                                    setAutoDistribution(approverVal, '3#Respond', strdate);
                                }
                            }
                            if (!$scope.isPM && struser != '') {
                                setAutoDistribution(struser, "3#", strdate);
                            }
                            $scope.oriMsgCustomFields['DSI_Nextstage'] = '2';
                            break;
                        case '2':
                            if (!$scope.isPM && struser != '') {
                                setAutoDistribution(struser, "3#", strdate);
                            }
                            $scope.oriMsgCustomFields['DSI_Nextstage'] = '3';
                            break;
                        case '3':
                            setOverallformstatus("Closed")
                            break;

                    }
                }
            }
            else {
                var currentstage = $scope.oriMsgCustomFields['DSI_Currentstage'];
                $scope.asiteSystemDataReadwrite.REPEATING_VALUES.Auto_Distribute_Group.Auto_Distribute_Users = [];
                if (currentstage) {
                    switch (currentstage) {
                        case '1':
                            var strVal = $scope.oriMsgFields['DS_PROJUSERS_ROLE'];
                            if (strVal != "") {
                                $scope.oriMsgFields.DS_AUTODISTRIBUTE = "13";
                                var struser = strVal.split('|')[2].trim();
                                var strdate = $scope.setDbDateClientSide(5);
                                if (!$scope.isPM) {
                                    setAutoDistribution(struser, "3#", strdate);
                                }
                            }
                            $scope.oriMsgCustomFields['DSI_Nextstage'] = '2';
                            break;
                        case '2':
                            setOverallformstatus("Closed")
                            break;
                    }
                }
            }
            if ($scope.oriMsgCustomFields['DSI_OptionType'].indexOf("Option A") > -1) {
                var isvalidateCommentOptionA = validateCommentForOptionA();
                if (!isvalidateCommentOptionA) {
                    $window.alert("Remarks/Comments are pending to enter in Activity data.");
                    return true;
                }
            }
            var isremarkspending = validateremarks();
            if (isremarkspending) {
                $window.alert("Remarks are pending to enter in transaction data/Withheld data.");
                return true;
            }
            if ($scope.currentOriTab != 'basic-detail.html') {
                $window.alert("Please Return to Payment Assessment Tab for form submission.");
                return true;
            }
            return false;
        }
        function setAutoDistribution(strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), NEC4_CONSTANT.yymmdddateformate);
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = strDueDate;

            $scope.asiteSystemDataReadwrite['REPEATING_VALUES']['Auto_Distribute_Group']['Auto_Distribute_Users'].push(structDistribution);
        }
        function hidesavedraftbutton() {
            var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
            $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        }

        $scope.update();

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 100);
    }
    return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {

    if (typeof afpFinalCallBack !== "undefined") {
        return afpFinalCallBack();
    }
}
function customHTMLMethodBeforeCreate_RES() {

    if (typeof afpFinalCallBack !== "undefined") {
        return afpFinalCallBack();
    }
}

