﻿/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId')
            .value || '';

        var currentViewName = window.currentViewName;

        var printedOn = "";

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });
        $scope.requests = {};

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["ASITE_SYSTEM_DATA_READ_WRITE"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_CUSTOM_FIELDS"];
        $scope.DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        $scope.DS_ALL_STATUS_WithCloseout = $scope.getValueOfOnLoadData('DS_ALL_STATUS_WithCloseout');
        $scope.DS_ASI_Get_All_Default_FormSettingDetails = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.meetingChairDropDown = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.representativeDropDown = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.Administrator = $scope.oriMsgCustomFields['Meeting_Fields']['Meeting_Administrator'];

        $scope.AddNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };
        $scope.DeleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };
        $scope.expandTextArea = function (event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = event.currentTarget.scrollHeight + 'px';
        }
        $scope.delayedResize = function (event) {
            $timeout(function () {
                $scope.expandTextArea(event);
            }, 1000);
        }
        $scope.expandTextAreaOnLoad = function () {
            var textAreaObj = document.getElementsByTagName('textarea');
            if (textAreaObj) {
                for (var i = 0; i < textAreaObj.length; i++) {
                    textAreaObj[i].style.height = 'auto';
                    textAreaObj[i].style.height = textAreaObj[i].scrollHeight + 'px';
                }
            }
        }
        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);
        $scope.StateChanged = function (args) {
            if (args.value) {
                var CurrentIndex = args.repeatObj.indexOf(args.curObj);
                $.each(args.repeatObj, function (index, item) {
                    if (CurrentIndex == index) {
                        if (args.value == "Closed") {
                            item.IsPreviousMeeting = true;
                        }
                        else {
                            item.IsPreviousMeeting = false;
                        }
                    }
                })
            }
        };

        $scope.restrictChar = function (event, inputValue) {
            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert("Restricted Characters specified!!! Restricted Characters | < > #");
                        event.preventDefault();
                    }
                    break;
                case 32:
                    if (inputValue == "") {
                        event.preventDefault();
                    }
                    break;
            }
        };

        $scope.restrictCharPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }

            if (inputValue.match(/[|<>#]/gi)) {
                alert("Restricted Characters specified!!! Restricted Characters | < > #");
                event.preventDefault();
                return false;
            }
        };
        function DeleteBlackRecrods() {
            var AgendaStructure = $scope.formCustomFields['REPEATING_VALUES']['Meeting_Actions_Group']['DSI_Action_Agenda_Sequence_Section'];
            if (AgendaStructure != null) {
                var WorkingUserID = $scope.WorkingUserID[0].Value;
                $.each(AgendaStructure, function (index, item) {
                    if (item.Meeting_Actions.length == 0) {
                        item.Meeting_Actions = [];
                    }
                });
            }
        };


        $scope.RemarksChildStructure = {
            Remarks_User: "",
            Remarks_Date: "",
            Remarks: "",
            DSI_IsNew: "New"
        };
        $scope.ClearAcionParentStructure = {
            DS_AUTOCOMPLETE_ACTION_APP_ID: "1",
            Auto_Complete_Action: []
        };
        $scope.ClearActionChildStructure = {
            DS_AC_TYPE: "",
            DS_AC_FORM: "",
            DS_AC_MSG_TYPE: "",
            DS_AC_USERID: "",
            DS_AC_ACTION: "",
            DS_AC_ACTION_REMARKS: ""
        };
        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        };
        $scope.FormSettingStructure = {
            Setting_name: "",
            Original_value: "",
            Expected_value: ""
        };
        function array(key, value) {
            return { key: key, value: value };
        }
        function CheckFormSetting() {
            var HTmain = [];
            HTmain.push(array("Form_Group_Code", "ASI"));
            HTmain.push(array("No_of_Form_Instances", "0"));
            HTmain.push(array("FormType", "Form Type"));
            HTmain.push(array("Form_Template_Type", "HTML AppBuilder"));
            HTmain.push(array("Response_Type", "Combined Response Will have Custom Print View"));
            HTmain.push(array("Appbuilder_Code", "ASI"));
            HTmain.push(array("Is_Import_Emailin", ""));
            HTmain.push(array("Is_Import_Emailin_Exchange", "Not Selected"));
            HTmain.push(array("Exchange_Type", ""));
            HTmain.push(array("E_catalogue", "Not Selected"));
            HTmain.push(array("Cross_Workspace", "No"));
            HTmain.push(array("Use_controller", "No"));
            HTmain.push(array("Controller_Change_status", "No"));
            HTmain.push(array("Response_allowed", "No"));
            HTmain.push(array("Responder_Collaborate", "No"));
            HTmain.push(array("Response_From", "Recipients Only"));
            HTmain.push(array("Continue_Discussion", "No"));
            HTmain.push(array("Enable_Draft_Responses", "No"));
            HTmain.push(array("Show_Responses", "Always"));
            HTmain.push(array("Allow_Editing_ORI", "No"));
            HTmain.push(array("Is_Import_Editing_ORI", "No"));
            HTmain.push(array("Action_Required", "For Information|0"));
            HTmain.push(array("default_Action_required", ""));
            HTmain.push(array("Distribution_ORI_creation", "Mandatory"));
            HTmain.push(array("Allow_Distribution_after_creation", "Yes"));
            HTmain.push(array("Allow_All", "No"));
            HTmain.push(array("Allow_Originator", "Yes"));
            HTmain.push(array("Allow_Receipients", "Yes"));
            HTmain.push(array("Allow_Roles", "No"));
            HTmain.push(array("Role_Name", ""));
            HTmain.push(array("Allow_Edit_and_Forward", "No"));
            HTmain.push(array("Allow_Attachments", "No"));
            HTmain.push(array("Automatic_publish_to_folder", "No"));
            HTmain.push(array("Allow_Form_Associations", "No"));
            HTmain.push(array("Associations_bypass_Form_security", "No"));
            HTmain.push(array("Allow_Doc_Association", "No"));
            HTmain.push(array("Default_Doc_Association", "Static"));
            HTmain.push(array("Associations_Extend_Document_Issue", "No"));
            HTmain.push(array("Allow_Comment_Associations", "No"));
            HTmain.push(array("Associations_bypass_folder_security", "No"));
            HTmain.push(array("Allow_Attribute_Associations", "No"));
            HTmain.push(array("Allow_View_Associations", "No"));
            HTmain.push(array("Overall_Form_Statuses", "No"));
            HTmain.push(array("status_list", ""));
            HTmain.push(array("Closed_out_status_list", ""));
            HTmain.push(array("Restrict_Status_Change_in_View_Form", "No"));
            HTmain.push(array("Allow_Reopening_Form", "Yes"));
            HTmain.push(array("Originator_can_Change_Status", "No"));
            HTmain.push(array("Is_public", "No"));
            HTmain.push(array("Use_Form_Distribution_Groups", "No"));
            HTmain.push(array("Allow_autocreation_on_status_change", "No"));
            HTmain.push(array("Enable_SpellCheck", "Not Selected"));
            HTmain.push(array("Allow_External_Access", "No"));
            HTmain.push(array("Embed_form_Content_emails", "No"));
            HTmain.push(array("Can_Reply_via_emails", "No"));
            HTmain.push(array("From_Actions_Notification_Email_Subject", ""));
            HTmain.push(array("Is_Offline", "No"));
            HTmain.push(array("Embed_form_Content_in_instant_emails_Type", "Setting Off"));
            HTmain.push(array("Allow_Import_in_Edit_ORIValue", "Overwrite"));
            HTmain.push(array("Allow_Import_in_Edit_ORI", "No"));

            var HTstatus = [];
            HTstatus.push(array("Deactivated", "Yes"));
            HTstatus.push(array("Closed", "Yes"));
            HTstatus.push(array("In Progress", "No"));
            HTstatus.push(array("Open", "No"));
            HTstatus.push(array("ReOpen", "No"));

            var strmain = "Form_Group_Code:MAC$" +
            "Response_Type:Combined Response Will have Custom Print View$" +
            "Appbuilder_Code:STD-ACT-V1$" +
            "Response_allowed:For Yes$" +
            "Responder_Collaborate:Yes$" +
            "Continue_Discussion:Yes$" +
            "Distribution_ORI_creation:Optional$" +
            "Allow_Attachments:Yes$" +
            "Allow_Form_Associations:Yes$" +
            "Allow_Doc_Association:Yes$" +
            "Overall_Form_Statuses:Yes$" +
            "status_list:$" +
            "Allow_Receipients:No$" +
            "Closed_out_status_list:$" +
            "Enable_SpellCheck:On Request$" +
            "Allow_External_Access:Yes$" +
            "Response_From:All$" +
            "Use_Form_Distribution_Groups:Yes$" +
            "Restrict_Status_Change_in_View_Form:Yes$" +
            "Embed_form_Content_in_instant_emails_Type:Setting Off";

            if (strmain != "") {
                if (strmain.indexOf('$') > -1) {
                    for (var i = 0; i < strmain.split('$').length; i++) {
                        var strkey = strmain.split('$')[i].split(':')[0].toString().trim();
                        var strval = strmain.split('$')[i].split(':')[1].toString().trim();
                        var index = _.findIndex(HTmain, { key: strkey });
                        if (index > -1) {
                            HTmain[index].value = strval;
                        }
                    }
                }
            }
            
            var strSettings = Checkstatusonload(HTmain);
            if (strSettings != "") {
                $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following settings not stated properly";
                $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";
                var Arrstr = [];
                if (strSettings.indexOf('&') > -1) {
                    Arrstr = strSettings.split('&');
                    for (var i = 0; i < Arrstr.length; i++) {
                        var item = Arrstr[i].split(':');
                        var mainstrcutr = angular.copy($scope.FormSettingStructure);
                        mainstrcutr.Setting_name = item[0];
                        mainstrcutr.Original_value = item[2];
                        mainstrcutr.Expected_value = item[1];
                        $scope.AddNewItem($scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'], mainstrcutr);
                    }
                }
                else if (strSettings.indexOf(':') > -1) {
                    Arrstr = strSettings.split(':');
                    var mainstrcutr = angular.copy($scope.FormSettingStructure);
                    mainstrcutr.Setting_name = Arrstr[0];
                    mainstrcutr.Original_value = Arrstr[2];
                    mainstrcutr.Expected_value = Arrstr[1];
                    $scope.AddNewItem($scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'], mainstrcutr);
                }
            }
        }

        function Checkstatusonload(HTmain) {
            var sb = "";
            if ($scope.DS_ASI_Get_All_Default_FormSettingDetails != null) {
                var temp = $scope.DS_ASI_Get_All_Default_FormSettingDetails[0];
                for (var i = 1; i < 60; i++) {
                    var splitValue = [];
                    splitValue = temp["Value" + i.toString()];
                    if (splitValue.indexOf(':') > -1) {
                        var key = splitValue.split(':')[0].trim();
                        //var value = splitValue.split(':')[1].trim().replace(new RegExp("\s+"), " ");
                        var value = splitValue.split(':')[1].trim();

                        var ind = _.findIndex(HTmain, { key: key });
                        if (ind > -1) {
                            if (HTmain[ind].value.trim().indexOf(value.trim()) == -1) {
                                if (sb == "") {
                                    var result = getDisplayName(splitValue.split(':')[0].trim()) + ":" + HTmain[ind].value + ":" + splitValue.split(':')[1];
                                    sb = result;
                                }
                                else {
                                    var result1 = getDisplayName(splitValue.split(':')[0].trim()) + ":" + HTmain[ind].value + ":" + splitValue.split(':')[1];
                                    sb = sb.concat("&" + result1);
                                }
                            }
                        }
                    }
                }
            }
            return sb;
        };
        function getDisplayName(keyparameter) {
            var Hashtable = [];
            Hashtable.push(array("Form_Group_Code", "Form_Group_Code"));
            Hashtable.push(array("No_of_Form_Instances", "No_of_Form_Instances"));
            Hashtable.push(array("FormType", "FormType"));
            Hashtable.push(array("Form_Template_Type", "Form_Template_Type"));
            Hashtable.push(array("Response_Type", "Response_Type"));
            Hashtable.push(array("Appbuilder_Code", "Appbuilder_Code"));
            Hashtable.push(array("Is_Import_Emailin", "Is_Import_Emailin"));
            Hashtable.push(array("Is_Import_Emailin_Exchange", "Is_Import_Emailin_Exchange"));
            Hashtable.push(array("Exchange_Type", "Exchange_Type"));
            Hashtable.push(array("E_catalogue", "E_catalogue"));
            Hashtable.push(array("Cross_Workspace", "Cross_Workspace"));
            Hashtable.push(array("Use_controller", "Use_controller"));
            Hashtable.push(array("Controller_Change_status", "Controller_Change_status"));
            Hashtable.push(array("Response_allowed", "Response_allowed"));
            Hashtable.push(array("Responder_Collaborate", "Responder_Collaborate"));
            Hashtable.push(array("Response_From", "Response_From"));
            Hashtable.push(array("Continue_Discussion", "Continue_Discussion"));
            Hashtable.push(array("Enable_Draft_Responses", "Enable_Draft_Responses"));
            Hashtable.push(array("Show_Responses", "Show_Responses"));
            Hashtable.push(array("Allow_Editing_ORI", "Allow_Editing_ORI"));
            Hashtable.push(array("Is_Import_Editing_ORI", "Is_Import_Editing_ORI"));
            Hashtable.push(array("Action_Required", "Action_Required"));
            Hashtable.push(array("default_Action_required", "Default_Action_required"));
            Hashtable.push(array("Distribution_ORI_creation", "Distribution_ORI_creation"));
            Hashtable.push(array("Allow_Distribution_after_creation", "Allow_Distribution_after_creation"));
            Hashtable.push(array("Allow_All", "Allow_Distribution_after_creation_BY_All"));
            Hashtable.push(array("Allow_Originator", "Allow_Distribution_after_creation_BY_Originator"));
            Hashtable.push(array("Allow_Receipients", "Allow_Distribution_after_creation_BY_Receipients"));
            Hashtable.push(array("Allow_Roles", "Allow_Distribution_after_creation_BY_Roles"));
            Hashtable.push(array("Role_Name", "Allow_Distribution_after_creation_BY_Role_Role_Name"));
            Hashtable.push(array("Allow_Edit_and_Forward", "Allow_Edit_and_Forward"));
            Hashtable.push(array("Allow_Attachments", "Allow_Attachments"));
            Hashtable.push(array("Automatic_publish_to_folder", "Automatic_publish_to_folder"));
            Hashtable.push(array("Allow_Form_Associations", "Allow_Form_Associations"));
            Hashtable.push(array("Associations_bypass_Form_security", "Associations_bypass_Form_security"));
            Hashtable.push(array("Allow_Doc_Association", "Allow_Doc_Association"));
            Hashtable.push(array("Default_Doc_Association", "Default_Doc_Association"));
            Hashtable.push(array("Associations_Extend_Document_Issue", "Associations_Extend_Document_Issue"));
            Hashtable.push(array("Allow_Comment_Associations", "Allow_Comment_Associations"));
            Hashtable.push(array("Associations_bypass_folder_security", "Associations_bypass_folder_security"));
            Hashtable.push(array("Allow_Attribute_Associations", "Allow_Attribute_Associations"));
            Hashtable.push(array("Allow_View_Associations", "Allow_View_Associations"));
            Hashtable.push(array("Overall_Form_Statuses", "Overall_Form_Statuses"));
            Hashtable.push(array("status_list", "status_list"));
            Hashtable.push(array("Closed_out_status_list", "Closed_out_status_list"));
            Hashtable.push(array("Restrict_Status_Change_in_View_Form", "Restrict_Status_Change_in_View_Form"));
            Hashtable.push(array("Allow_Reopening_Form", "Allow_Reopening_Form"));
            Hashtable.push(array("Originator_can_Change_Status", "Originator_can_Change_Status"));
            Hashtable.push(array("Is_public", "Form_Is_public"));
            Hashtable.push(array("Use_Form_Distribution_Groups", "Use_Form_Distribution_Groups"));
            Hashtable.push(array("Allow_autocreation_on_status_change", "Allow_autocreation_on_status_change"));
            Hashtable.push(array("Enable_SpellCheck", "Enable_SpellCheck"));
            Hashtable.push(array("Allow_External_Access", "Allow_External_Access"));
            Hashtable.push(array("Embed_form_Content_emails", "Embed_form_Content_emails"));
            Hashtable.push(array("Can_Reply_via_emails", "Can_Reply_via_emails"));
            Hashtable.push(array("From_Actions_Notification_Email_Subject", "From_Actions_Notification_Email_Subject"));
            Hashtable.push(array("Is_Offline", "Is_Form_available_Offline"));
            Hashtable.push(array("Embed_form_Content_in_instant_emails_Type", "Embed_form_Content_in_instant_emails_Type"));
            Hashtable.push(array("Allow_Import_in_Edit_ORIValue", "Allow_Import_in_Edit_ORIValue"));
            Hashtable.push(array("Allow_Import_in_Edit_ORI", "Allow_Import_in_Edit_ORI"));

            var ind = _.findIndex(Hashtable, { key: keyparameter });
            return Hashtable[ind].key;
        }
        if (currentViewName == "RES_VIEW") {
            CheckFormSetting();
            var strIsDraftRes = $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_ISDRAFT_RES_MSG"];
            if (strIsDraftRes == "NO") {
                $scope.formCustomFields['REPEATING_VALUES']['DistributionGroup']['DistributionUsers'] = [];

                var DSI_Remarks_Repeating = $scope.formCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
                var strWorkinguser = $scope.WorkingUserID[0].Value
                $scope.RepeatingStrcuture = $scope.formCustomFields['DSI_Remarks_Section'];
                if (DSI_Remarks_Repeating.length > 0) {
                    if (DSI_Remarks_Repeating.length == 1 && DSI_Remarks_Repeating[0].Remarks == "") {
                        $scope.formCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'] = [];
                    }

                    var RemarksChildStrcuture = angular.copy($scope.RemarksChildStructure);
                    RemarksChildStrcuture.Remarks_User = strWorkinguser.split('#')[1].trim();
                    RemarksChildStrcuture.Remarks_Date = $scope.formatDate(new Date, 'dd/M/yy', 'yy-mm-dd');
                    RemarksChildStrcuture.Remarks = "";
                    RemarksChildStrcuture.DSI_IsNew = "New";
                    $scope.Parent = $scope.formCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
                    $scope.AddNewItem($scope.Parent, RemarksChildStrcuture);
                }
                var AgendaStructure = $scope.formCustomFields['REPEATING_VALUES']['Meeting_Actions_Group']['DSI_Action_Agenda_Sequence_Section'];
                if (AgendaStructure != null) {
                    $.each(AgendaStructure, function (index, item) {
                        $.each(item.Meeting_Actions, function (index1, ActionItem) {
                            $.each(ActionItem.Meeting_Recipients, function (index2, RecipientItem) {
                                var strOwner = RecipientItem.Action_Owner.split('#')[0].trim();
                                var strAction = RecipientItem.Minutes_Action;
                                if ((strOwner == strWorkinguser.split('|')[0].trim() && strAction.indexOf('3#Respond') > -1) ||
                                    (strWorkinguser.split('|')[0].trim() == $scope.Administrator.split('#')[0].split('|')[2].trim())) {
                                    RecipientItem.Disable_Flag = "1";
                                }
                                else {
                                    RecipientItem.Disable_Flag = "0";
                                }
                            });
                        });
                    });
                }
            }
        }
        $scope.FinalStatusChanged = function () {
            //take final status value
            var strStatusResult = $scope.oriMsgCustomFields['FinalMeeting_Status'];
            //take agenda structure
            var AgendaStructure = $scope.formCustomFields['REPEATING_VALUES']['Meeting_Actions_Group']['DSI_Action_Agenda_Sequence_Section'];
            if (AgendaStructure != null) {
                var WorkingUserID = $scope.WorkingUserID[0].Value;
                $.each(AgendaStructure, function (index, item) {
                    $.each(item.Meeting_Actions, function (index1, ActionItem) {
                        $.each(ActionItem.Meeting_Recipients, function (index2, RecipientItem) {
                            var strOldStatus = RecipientItem.DSI_User_Old_Status;
                            var strNewStatus = RecipientItem.Meeting_Action_UserStatus;
                            if (strOldStatus == "") {
                                strOldStatus = strNewStatus;
                                RecipientItem.DSI_User_Old_Status = strNewStatus;
                            }
                            if (strStatusResult) {
                                RecipientItem.Meeting_Action_UserStatus = "Completed";
                            }
                            else {
                                RecipientItem.Meeting_Action_UserStatus = strOldStatus;
                            }
                        });
                    });
                });
            }
        };

        if (currentViewName == "ORI_VIEW") {
            $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | You are not authorised to Create this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
        }
        $scope.WorkingUserIsNotAdministrator = function () {
            var WorkingUserID = $scope.WorkingUserID[0].Value;
            if ($scope.Administrator.split('#')[0].split('|')[2].trim() != WorkingUserID.split('|')[0].trim()) {
                return false;
            }
            else {
                return true;
            }
        };

        function UpdateFormStatus(StrStatus) {
            if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null) {
                $scope.DS_ALL_ACTIVE_FORM_STATUS = _.filter($scope.DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name == StrStatus;
                });
                if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null) {
                    var strStatus = $scope.DS_ALL_ACTIVE_FORM_STATUS[0].Value;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatus;
                }
            }
        }
        $window.MOM_FinalCallBack = function () {
            return $scope.FinalCallBack();
        }
        function checkDuplicateValue(args) {
            var index = args.repeatObj.indexOf(args.curObj);
            $.each(args.repeatObj, function (idx, obj) {
                if (idx != index && args.value != "" && obj[args.objName] == args.value) {
                    ADODDLE.alert({ title: "Duplicate " + args.msg + " selected !!!", msg: "Select a different " + args.msg });
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }
        function CheckPendingAction(strUser) {
            var IsAction = false;
            $scope.DS_INCOMPLETE_ACTIONS = _.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == "Respond";
            });
            if ($scope.DS_INCOMPLETE_ACTIONS != null) {
                var strStatus = $scope.DS_INCOMPLETE_ACTIONS[0].Value;
                if (strStatus != null) {
                    var split = strStatus.split('#')[0].split('|');
                    for (var i = 0 ; i < split.length; i++) {
                        if (split[i] != "" && split[i] == strUser.trim()) {
                            return true;
                        }
                    }
                }
            }
            return IsAction;
        };
        $scope.FinalCallBack = function () {
            $scope.oriMsgCustomFields['Meeting_Fields']['DS_AU_OTH_FORM'] = "1";
            $scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
            $scope.formCustomFields['REPEATING_VALUES']['DistributionGroup']['DistributionUsers'] = [];
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];

            //var strStatusResult = $scope.oriMsgCustomFields['Meeting_Fields']['FinalMeeting_Status'];
            var StrFinalStatus = $scope.oriMsgCustomFields['FinalMeeting_Status'];
            //check administrator is working user or not
            var IsAdministratorWorkinguser = IsAdministratorWorking();
            var strWorkinguser = $scope.WorkingUserID[0].Value;
            if (IsAdministratorWorkinguser) {
                if (StrFinalStatus) {
                    UpdateFormStatus("Closed");
                }
                else {
                    UpdateFormStatus("Open");
                }
            }
            var isActionSendToAdministartor = false;
            var AgendaStructure = $scope.formCustomFields['REPEATING_VALUES']['Meeting_Actions_Group']['DSI_Action_Agenda_Sequence_Section'];
            if (AgendaStructure != null) {
                $.each(AgendaStructure, function (index, item) {
                    $.each(item.Meeting_Actions, function (index1, ActionItem) {
                        $.each(ActionItem.Meeting_Recipients, function (index2, RecipientItem) {
                            var strOwner = RecipientItem.Action_Owner.split('#')[0].trim();
                            var strNewStatus = RecipientItem.Meeting_Action_UserStatus;
                            var strIsActive = RecipientItem.Disable_Flag;
                            var DSI_User_Old_Status = RecipientItem.DSI_User_Old_Status;
                            if (IsAdministratorWorkinguser) {
                                if (!StrFinalStatus) {
                                    //check pending action
                                    var isrequired = CheckPendingAction(strOwner);
                                    if (strNewStatus == "Completed") {
                                        //clear action and send form info
                                        ClearAction(strOwner, strWorkinguser);
                                        Set_Auto_Distribution(strOwner, "7#");
                                    }
                                    else if (isrequired == false || strOwner.trim() == strWorkinguser.split('|')[0].trim()) {
                                        //send respond
                                        Set_Auto_Distribution(strOwner, "3#");
                                    }
                                    RecipientItem.DSI_User_Old_Status = strNewStatus;
                                }
                                else {
                                    //send for info
                                    Set_Auto_Distribution(strOwner, "7#");
                                }
                            }
                            else {
                                if (strIsActive == "1" && strNewStatus != "Completed") {
                                    var strOldStatus = "";
                                    if (DSI_User_Old_Status != "") {
                                        strOldStatus = DSI_User_Old_Status;
                                    }
                                    Set_Auto_Distribution(strOwner, "3#");
                                    RecipientItem.DSI_User_Old_Status = strNewStatus;
                                }
                                else if (strIsActive == "1" && strNewStatus == "Completed") {
                                    isActionSendToAdministartor = true;
                                    RecipientItem.DSI_User_Old_Status = "Completed";
                                }
                            }
                        });
                    });
                });
            }
            if (isActionSendToAdministartor && !IsAdministratorWorkinguser) {
                var isActionSend = CheckPendingAction($scope.Administrator.split('#')[0].split('|')[2].trim());
                if (!isActionSend) {
                    Set_Auto_Distribution($scope.Administrator.split('#')[0].split('|')[2].trim(), "3#");
                }
            }
            var originatorid = $scope.formCustomFields['ORI_MSG_CUSTOM_FIELDS']['Meeting_Fields']['DS_Originator_ID'];
            Set_Auto_Distribution(originatorid, "7#");
            var DSI_Remarks_Repeating = $scope.formCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
            if (DSI_Remarks_Repeating != null) {
                $.each(DSI_Remarks_Repeating, function (index, item) {
                    item.DSI_IsNew = "Old";
                });
            }
            return false;
        };
        function Check_User_Exists(strUser) {
            var IsExists = false;
            var Distribution = $scope.formCustomFields['REPEATING_VALUES']['DistributionGroup']['DistributionUsers'];
            if (Distribution != null) {
                $.each(Distribution, function (index, item) {
                    if (item.DS_PROJDISTUSERS != null && item.DS_PROJDISTUSERS.split('#')[0].trim() == strOwner) {
                        return IsExists = true;
                    }
                });
            }
            return IsExists;
        }
        function Set_Auto_Distribution(strUser, strAction) {
            var districution = angular.copy($scope.DistributionStructure)
            districution.DS_PROJDISTUSERS = strUser;
            var d = new Date();
            d.setDate(d.getDate() + 7);
            var month = d.getMonth() + 1;
            var day = d.getDate();
            var strDueDate = d.getFullYear() + '-' +
                (month < 10 ? '0' : '') + month + '-' +
                (day < 10 ? '0' : '') + day;

            districution.DS_PROJDISTUSERS = strUser;
            districution.DS_FORMACTIONS = strAction;
            districution.DS_ACTIONDUEDATE = strDueDate;
            $scope.DistributionStructure = $scope.formCustomFields['REPEATING_VALUES']['DistributionGroup']['DistributionUsers'];
            $scope.AddNewItem($scope.DistributionStructure, districution);
        };
        function ClearAction(strUser, strWorkingUser) {
            var AppId = $scope.DS_APPBUILDERID;
            var strIsDraftRes = $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_AppBuilderID"];

            var strUserId = strUser.split('#')[0].trim();
            var ClearActionChildStructure = angular.copy($scope.ClearActionChildStructure);
            ClearActionChildStructure.DS_AC_TYPE = "clear";
            ClearActionChildStructure.DS_AC_FORM = AppId;
            ClearActionChildStructure.DS_AC_MSG_TYPE = "RES";
            ClearActionChildStructure.DS_AC_USERID = strUserId;
            ClearActionChildStructure.DS_AC_ACTION = 3;
            ClearActionChildStructure.DS_AC_ACTION_REMARKS = strWorkinguser.trim();
            $scope.ClearActionStructure = $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'];
            $scope.AddNewItem($scope.ClearActionStructure, ClearActionChildStructure);
        };

        function IsAdministratorWorking() {
            var strWorkinguser = $scope.WorkingUserID[0].Value;
            if (strWorkinguser.split('|')[0].trim() == $scope.Administrator.split('#')[0].split('|')[2].trim()) {
                return true;
            }
            return false;
        };
        //// column to sort
        //$scope.column = "";
        //// sort ordering (Ascending or Descending). Set true for desending
        //$scope.reverse;
        //// called on header click
        //$scope.sortColumn = function (col) {
        //    $scope.column = col;
        //    if ($scope.reverse) {
        //        $scope.reverse = false;
        //        $scope.reverseclass = 'arrow-up';
        //    } else {
        //        $scope.reverse = true;
        //        $scope.reverseclass = 'arrow-down';
        //    }
        //};

    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {
    if (typeof MOM_FinalCallBack !== "undefined") {
        return MOM_FinalCallBack();
    }
}