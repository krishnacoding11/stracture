/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        }
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;
        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });
        $scope.stopAutoSaveDraftTimerFromClientSide();
        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        $scope.isRespond = false;
        var STATIC_OBJ_DATA = {
            ProcurementList: {
                ProcurementisSelected: false,
                Companyname: "",
                TenderStage: "",
                InitialQuote: "",
                Adjustment: "",
                FinalPrice: ""
            },
            ResponseList: {
                Role_Name: "",
                User_Name: "",
                PM_USer: "",
                Res_Date: "",
                User_Response: "",
                User_Comments: "",
                Response_By: "",
                Is_Old: "New"
            }
        };
       /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.clauseCommentGroup = $scope.oriMsgCustomFields["clauseCommentGroup"];
        $scope.triggerChangeGroup = $scope.oriMsgCustomFields["triggerChangeGroup"];
        $scope.approvalGroup = $scope.oriMsgCustomFields["approvalGroup"];
        $scope.alliancePrinciples = $scope.oriMsgCustomFields["alliancePrinciples"];
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var submitFlag=false;
        $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
        $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var allOrgList=$scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var dsAsiConfigSets = $scope.getValueOfOnLoadData("DS_GET_ATTRIBUTE_SET_DTLS");
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsProjDistuser =$scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        if (currentViewName == "ORI_VIEW") {
            var logo = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                return val.Value3.indexOf('Client_Logo') > -1;
            })[0] || {};
            $scope.oriMsgCustomFields.Client_Logo = logo.Value8 || '/images/asiteWhite60x200.png';
            $scope.cbsList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("CBS Code"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            }); 
            $scope.contractorList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Project Number"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8",
                allowBlankSelection: true
            });
            $scope.procurementUserList = structureItemList(commonApi.roleUsersListByRoleName('procurement lead', ds_Projusers_Role));
            $scope.BusinessUnitList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Business Unit"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
            $scope.OrderTypeReqList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Order Type Required"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
            $scope.SubScopeList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Subcontractors Scope"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
           
            $scope.supplierData = commonApi.getItemSelectionList({
                arrayObject: allOrgList,
                modelKey: "Value",
                displayKey: "Name",
                allowBlankSelection: true
            });
        }
        function structureItemList(availList) {
            var tempList = [];
            angular.forEach(availList, function (item) {
                tempList.push({
                    displayValue: item.split('#')[1].trim(),
                    modelValue: item
                });
            });
            return [{
                options: tempList
            }];
        }
        function getConfigurableAttriburteByType(type) {
            var AttributeByType = [];
            if (type) {
                AttributeByType = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return AttributeByType;
        }
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;
        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.strCanReply = "";
            var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
            $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
        }
        if (currentViewName == "ORI_VIEW" && workingUserAllRole && $scope.oriMsgCustomFields.DSI_CurrentStage == 1) {
            $scope.strCanReply = "yes";
            //commited the as per BLDBTR-3986(who has rights can create the form) 
            // if (workingUserAllRole[0].Value.toLowerCase().indexOf("commercial team") != -1) {
            //     $scope.strCanReply = "yes";
            // }
        }
        if ($scope.oriMsgCustomFields.DSI_CurrentStage > 1) {
            var actionData = commonApi._.filter(incompleteAction, function (val) {
                return val.Name.indexOf('Respond') > -1 && val.Value.indexOf(dsWorkingUserId) != -1
            });
            if (actionData && actionData.length) {
                $scope.strCanReply = "yes";
            }
        }
        if (currentViewName == "ORI_VIEW") {
            $scope.Msg = "You are not authorised to create the form currently. For more information, contact your Administrator."
        }
        if (currentViewName == "RES_VIEW") {
            $scope.SupplierStatusList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Supplier Status"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
            
            $scope.Msg = "You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form."
            var reqTotal = parseFloat($scope.oriMsgCustomFields.SubcontractTendererPrice || 0);
            $scope.cleraDataOnchange=function(currentObj){
                if(currentObj.User_Response=='Yes')
                {
                    currentObj.User_Name='';
                }
            }
            if (reqTotal > 1000000 ) {
                $scope.Reqamt = "uptoALT";
            } else if (reqTotal > 500000 && reqTotal <= 1000000) {
                $scope.Reqamt = "uptoAlianceManger";
            }  else if (reqTotal > 250000 && reqTotal <= 500000 ) {
                $scope.Reqamt = "uptoAMT";
            }
            else if (reqTotal > 50000 && reqTotal <= 250000 ) {
                $scope.Reqamt = "uptoLead";
            }else
                $scope.Reqamt = "uptoPM";

            $scope.procurementList = structureItemList(commonApi.roleUsersListByRoleName('procurement lead', ds_Projusers_Role));
            $scope.commercialList = structureItemList(commonApi.roleUsersListByRoleName('commercial lead', ds_Projusers_Role));
            if ($scope.oriMsgCustomFields.DSI_CurrentStage != 2 || $scope.resMsgCustomFields.isRES_Done == 'No') {
                //add new Row of Response
                $scope.resMsgCustomFields.ALL_Responses.ResponseList.push(angular.copy(STATIC_OBJ_DATA.ResponseList));
            }
            if ($scope.oriMsgCustomFields.DSI_CurrentStage == 2) {
                $scope.qsPMList =structureItemList(commonApi.roleUsersListByRoleName('quantity surveyor', ds_Projusers_Role));
                setRolename("Procurement Lead");
            } else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 3) {
                $scope.pmList =structureItemList(commonApi.roleUsersListByRoleName('project manager', ds_Projusers_Role));
                $scope.seniorList = structureItemList(commonApi.roleUsersListByRoleName('senior project lead', ds_Projusers_Role));    
                setRolename("Quantity Surveyor");
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 4) {
                $scope.seniorList = structureItemList(commonApi.roleUsersListByRoleName('senior project lead', ds_Projusers_Role));    
                setRolename("Project Manager");
            }
             else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 5) {
                setRolename("Senior Project Lead");
                $scope.AMTList = structureItemList(commonApi.roleUsersListByRoleName('alliance management team', ds_Projusers_Role));
                $scope.AMList = structureItemList(commonApi.roleUsersListByRoleName('alliance commercial manager', ds_Projusers_Role));
                
            } else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 6) {
                setRolename("Alliance Management Team");
                $scope.AMList = structureItemList(commonApi.roleUsersListByRoleName('alliance commercial manager', ds_Projusers_Role));
            } 
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 7) {
                setRolename("Alliance Commercial Manager");
                $scope.ALTList = structureItemList(commonApi.roleUsersListByRoleName('alliance leadership team', ds_Projusers_Role));
                $scope.AManagerList = structureItemList(commonApi.roleUsersListByRoleName('alliance manager', ds_Projusers_Role));
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 8) {
                setRolename("Alliance Leadership Team");
            }
            else if ($scope.oriMsgCustomFields.DSI_CurrentStage == 9) {
                setRolename("Alliance Manager");
            }
        }
        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
        }
       
        function setRolename(rolename) {
            var Rlist = $scope.resMsgCustomFields.ALL_Responses.ResponseList;
            for (var i = 0; i < Rlist.length; i++) {
                if (Rlist[i].Is_Old == 'New') {
                    Rlist[i].Role_Name = rolename;
                    break;
                }
            }
        }
        $scope.update();
        $scope.rowTotal = function (index) {
            var element,
                Quote = 0,
                Adj = 0;

            element = $scope.oriMsgCustomFields.ProcurementGroup.ProcurementList[index];
            if (element.InitialQuote) {
                Quote += (parseFloat(element.InitialQuote) || 0);
            }
            if (element.Adjustment) {
                Adj += (parseFloat(element.Adjustment) || 0);
            }
            element.FinalPrice = (Quote + Adj).toFixed(2);
          
        };
        $scope.calculateProfit = function () {
            var aBudget=$scope.oriMsgCustomFields.AllianceBudget;
            if(aBudget==''||aBudget==0 || aBudget==0.00 )
            {aBudget=1}
            $scope.oriMsgCustomFields.NettProfitLoss = (parseFloat($scope.oriMsgCustomFields.AllianceBudget || 0) - parseFloat($scope.oriMsgCustomFields.SubcontractTendererPrice || 0)).toFixed(2);
            $scope.oriMsgCustomFields.NettPercentageProfitLoss = (parseFloat($scope.oriMsgCustomFields.NettProfitLoss|| 0) / parseFloat(aBudget|| 0) * 100);
            if($scope.oriMsgCustomFields.NettPercentageProfitLoss)
            {$scope.oriMsgCustomFields.NettPercentageProfitLoss=$scope.oriMsgCustomFields.NettPercentageProfitLoss.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0];}
            
        };
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
        };
        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length == 1) {
                return;
            }
            repeatindData.splice(index, 1);
        };
        $scope.resetUserDetails=function(obj) {
            if(obj){
                obj.User_Name='';
            }
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (allformStatus && allformStatus.length > 0) {
                var statudObj = commonApi._.filter(allformStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        function setStatus(statusname) {
            var strFormStatusId = getFormStatusId(statusname);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }
        function formSubmit(issubmit)
        { 
            submitFlag=true;
            $window.submitForm(1);
        }
        // Set App Work Flow From here
        function setAppWorkflow() {
            var userTodistribute = '',
                userTodistributeoth = '',
                queUserForInfo = '',
                autoDistNode = currentViewName == "ORI_VIEW" ? '3' : '13';
            // Distribution Will be made from here
            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if (!$scope.strCanReply) {
                alert($scope.Msg);
                return true;
            }
            var cStage = $scope.oriMsgCustomFields.DSI_CurrentStage;
           // $scope.oriMsgCustomFields.ORI_FORMTITLE = "Procurement Approval";
            if (currentViewName == "RES_VIEW") {
                //Make filed balnak
                if ($scope.resMsgCustomFields.isRES_Done == 'No') {
                    $scope.resMsgCustomFields.isRES_Done = '';
                }
                //set old to all
                var resData = "";
                for (var i = 0; i < $scope.resMsgCustomFields.ALL_Responses.ResponseList.length; i++) {
                    if ($scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Is_Old == 'New') {
                        resData = $scope.resMsgCustomFields.ALL_Responses.ResponseList[i];
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Is_Old = 'Old';
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Res_Date = $scope.formatDate(new Date($scope.todayDate), 'dd/mm/yy');
                        $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].Response_By = $scope.dsWorkingUser;
                        if ($scope.resMsgCustomFields.ALL_Responses.ResponseList[i].User_Name == '') {
                            $scope.resMsgCustomFields.ALL_Responses.ResponseList[i].User_Name = $scope.resMsgCustomFields.Procurement_Lead;
                        }
                        break;
                    }
                }
            }
            if (cStage == "1") {
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                setStatus("Open");
            }
             else if (cStage == "2") {
                if ($scope.resMsgCustomFields.isRES_Done == '') {
                    userTodistribute = resData.User_Name;
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                    setStatus("Procurement Lead Approved");
                } else if ($scope.resMsgCustomFields.isRES_Done == 'Yes') {
                    setStatus("Closed");
                }
            }
             else if (cStage == "3") {
                if (resData.User_Response == 'Yes') {
                    userTodistribute = resData.User_Name;
                    if($scope.Reqamt == "uptoLead" || $scope.Reqamt == "uptoPM"){
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;}
                    else{
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2;}
                    setStatus("QS Approved");
                }
                else {
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                    setStatus("Revise Resubmit");
                }
            }
             else if (cStage == "4") {
                if (resData.User_Response == 'Yes' && $scope.Reqamt != "uptoPM") {
                    userTodistribute = resData.User_Name;
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                } else {
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response == 'Yes' ? setStatus("PM Approved") : setStatus("Revise Resubmit");
            }
             else if (cStage == "5") {
                if (resData.User_Response == 'Yes' && $scope.Reqamt != "uptoLead") {
                    userTodistribute = resData.User_Name;
                    if($scope.Reqamt == "uptoAMT")
                         $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                    else
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2
                } else {
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response == 'Yes' ? setStatus("Project Lead Approved") : setStatus("Revise Resubmit");
            } else if (cStage == "6") {
                if (resData.User_Response == 'Yes' && $scope.Reqamt != "uptoAMT") {
                    userTodistribute = resData.User_Name;
                    $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;
                } else {
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response == 'Yes' ? setStatus("AMT Approved") : setStatus("Revise Resubmit");
            }
            else if (cStage == "7") {
                if (resData.User_Response == 'Yes' ) {
                    userTodistribute = resData.User_Name;
                    if($scope.Reqamt == "uptoAlianceManger"){
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 2;
                    }
                    else if($scope.Reqamt == "uptoALT")
                        $scope.oriMsgCustomFields.DSI_NextStage = parseInt(cStage) + 1;

                } else {
                    userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                    $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                    $scope.oriMsgCustomFields.DSI_NextStage = 2;
                }
                resData.User_Response == 'Yes' ? setStatus("Commercial Manager Approved") : setStatus("Revise Resubmit");
            }
            else if (cStage == "8") {
                if (resData.User_Response == 'Yes') {
                    setStatus("ALT Approved");
                } else {
                    setStatus("Revise Resubmit");
                }
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                $scope.oriMsgCustomFields.DSI_NextStage = 2;
            }
            else if (cStage == "9") {
                if (resData.User_Response == 'Yes') {
                    setStatus("Alliance Manager Approved");
                } else {
                    setStatus("Revise Resubmit");
                }
                userTodistribute = $scope.resMsgCustomFields.Procurement_Lead;
                $scope.resMsgCustomFields.isRES_Done = resData.User_Response;
                $scope.oriMsgCustomFields.DSI_NextStage = 2;
            }
            if (queUserForInfo) {
                // Distribution Will be made from here for 
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: queUserForInfo.split('#')[0].trim(),
                        strAction: "7#For Information",
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }
            if (userTodistribute) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistribute.split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: commonApi.calculateDistDateFromDays({
                            baseDate: $scope.todayDate,
                            days: 7
                        })
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }
            if (userTodistributeoth) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistributeoth.split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: commonApi.calculateDistDateFromDays({
                            baseDate: $scope.todayDate,
                            days: 7
                        })
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }
            formSubmit("");
        }
        $window.svrFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                if (!$scope.strCanReply) {
                    alert($scope.Msg);
                    return true;
                }
                if (submitFlag) {
                    $element.removeClass('loaded');
                    return false;
                }
                setAppWorkflow();
                return true;
            }
        };
    }
    return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof svrFinalCallBack !== "undefined") {
        return svrFinalCallBack();
    }
} 