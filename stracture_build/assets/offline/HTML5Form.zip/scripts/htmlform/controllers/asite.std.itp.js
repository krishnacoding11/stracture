
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $filter, $timeout) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		if($scope.$parent.priv && $scope.$parent.priv.canPrint){
			$scope.$parent.priv.canPrint = false;
		}
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		$scope.activityTypeList = [{
			Value: "D - Document",
			Display_name: "D - Document"
		},{
			Value: "W - Witness Point",
			Display_name: "W - Witness Point"
		},{
			Value: "S - Surveillance",
			Display_name: "S - Surveillance"
		},{
			Value: "X - Self Inspection",
			Display_name: "X - Self Inspection"
		},{
			Value: "H - Hold Point",
			Display_name: "H - Hold Point"
		}];
		$scope.observationList = [{
			Value: "None",
			Display_name: "None"
		},{
			Value: "TextBox",
			Display_name: "TextBox"
		},{
			Value: "Date input",
			Display_name: "Date input"
		},{
			Value: "SelectBox",
			Display_name: "Dropdown"
		},{
			Value: "Checkbox",
			Display_name: "Checkbox"
		},{
			Value: "Radio button",
			Display_name: "Radio button"
		}];
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.Activities = $scope.oriMsgCustomFields.Activitiy_Group.Activities;
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.DS_ISDRAFT = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		$scope.resCurrStage = $scope.oriMsgCustomFields.CurrStage;
		$scope.prevStatus = $scope.resMsgCustomFields.Status || '';
		var modelRowIndex = -1;
		var modalOpened = "";
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			STATIC_OBJ = {
				activity: {
					"Activity_No": "",
					"Activity_GUID": "",
					"Activity_Name": "",
					"Spec_Standard_Ref": "",
					"Acceptance_Criteria": "",
					"Frequency": "",
					"Activity_Type": "",
					"Is_Signature_required": "No",
					"is_holdPoint": false,
					"Observation": {
						"control": "None",
						"is_number_control": false,
						"is_range_control": false,
						"is_required": false,
						"optionsGroup": {
							"options": [{
								"Label": "",
								"Value": ""
							}]
						},
						"radio_value": "",
						"field_label": "",
						"field_name": "",
						"value": "",
						"min_field_label": "",
						"max_field_label": "",
						"min_field_name": "",
						"max_field_name": "",
						"min_value": "",
						"max_value": "",
						"min_valid_value": "",
						"max_valid_value" : "",
						"Remarks": "Yes"
					},
					"sectionType": "Subsection"
				},
				"Observation" : {
					"control": "",
					"is_number_control": false,
					"is_range_control": false,
					"is_required": false,
					"optionsGroup": {
						"options": [{
							"Label": "",
							"Value": ""
						}]
					},
					"radio_value": "",
					"field_label": "",
					"field_name": "",
					"value": "",
					"min_field_label": "",
					"max_field_label": "",
					"min_field_name": "",
					"max_field_name": "",
					"min_value": "",
					"max_value": "",
					"min_valid_value": "",
					"max_valid_value" : "",
					"Remarks": "Yes"
				},
				"fieldOptions": {
					"Label": "",
					"Value": ""
				}
			},
			ITP_CONSTANT = {
				OBSERVATION: "observation",
				open_status: "Open",
            },
			WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID'),
			DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'),
			DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS'),
			DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');

		$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		if($scope.oriMsgCustomFields.OriginatorUser){
			$scope.isCurUserOriginator = ($scope.currentUserid == $scope.oriMsgCustomFields.OriginatorUser.split('|')[0].trim());
		}
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		
		$scope.tableUtilSettings = {
			activitiesDetails: {
				tooltip: "select to remove/remove all/Insert new Record data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRecordSelected",
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0
				},
				newStaticObject: angular.copy(STATIC_OBJ.activity),
				ADD_NEW_BEFORE_TIP: "Insert Activity before row",
				ADD_NEW_AFTER_TIP: "Insert Activity after row",
				deleteAllRowTooltip: "Remove all Activity Record Details",
				deleteCurrRowMsg: "Remove Activity Record Details",
				deleteSelectedMsg: "Remove selected Activity Record Details",
				addItemCallBack: function () {
					refreshActivityNO();
				},
				deleteItemCallBack: function () {
					refreshActivityNO();
				}
			}
		};

		$scope.onSectionTypeChange = function(){
			refreshActivityNO();
		};

		$scope.onActivityTypeCHange = function(recoredRow){
			if(recoredRow.Activity_Type && recoredRow.Activity_Type.toLowerCase().indexOf('hold point') != -1 ){
				recoredRow.is_holdPoint = true;
			}else{
				recoredRow.is_holdPoint = false;
			}
		};

		$scope.addNewItem = function (list, addItemFor) {
			$scope.addRepeatingRow(list, angular.copy(STATIC_OBJ[addItemFor]));
			if(addItemFor == 'activity'){
				refreshActivityNO();
			}
		};
		$scope.deleteItem = function (list, index, itemFor) {
			if(itemFor == 'option' && list.length == 1){
				alert('Atleast One option should be available');
				return;
			}
			list.splice(index, 1);
		};	
		$scope.allowEditAndDist = true;
		if($scope.isOriView){
			var formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
			formStatus = formStatus.toLowerCase();
			$scope.allowEditAndDist = $scope.isCurUserOriginator && (formStatus == 'approved' || formStatus == 'rejected');
			if($scope.dSFormId && $scope.DS_ISDRAFT.toLowerCase() == "no"){
				hideimportFromExcel();
				$timeout(function () {
					angular.element("#btnSaveDraft").hide();
				});
			}
			setBasicList();
			setClientlogo();
			onImportFromExcel();
		}
		if($scope.isRespView){
			setBasicList();
			hideimportFromExcel();
			$scope.isAuthorized = true;
			var actionAvailable = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
				return val.Name.indexOf('Respond') > -1 && val.Value.indexOf($scope.currentUserid) != -1;
			});
			if(!actionAvailable.length){
				$scope.isAuthorized = false;
			}else{
				$scope.resMsgCustomFields.Status = "";
				$scope.resMsgCustomFields.Comments = "";
			}
		}

		function hideimportFromExcel(){
			$timeout(function () {
				var objGetExcelComponent = document.getElementsByClassName('component-wrapper');
				if (objGetExcelComponent && objGetExcelComponent.length) {
					objGetExcelComponent[0].style.display = 'none';
				}
			});
		}

		function onImportFromExcel(){
			if($scope.oriMsgCustomFields.isImported == 'Yes'){
				$scope.oriMsgCustomFields.ORI_USERREF = "";
				angular.forEach($scope.Activities, function(item){
					item.Observation = angular.copy(STATIC_OBJ.Observation);
					item.Observation.control = 'None';
					if(item.Activity_Type && item.Activity_Type.toLowerCase().indexOf('hold point') != -1 ){
						item.is_holdPoint = true;
					}else{
						item.is_holdPoint = false;
					}
				});
				refreshActivityNO();	
				$scope.oriMsgCustomFields.isImported = 'completed';
			}
		}

		function refreshActivityNO(){
			$timeout(function () {
				var preSectionNo, prevSubSectionNo, hasSection;
				angular.forEach($scope.Activities, function(item, index){
					if(item.sectionType){
						if(index == 0){
							item.Activity_No = 1;
							preSectionNo = item.Activity_No;
							prevSubSectionNo = 1;
							if(item.sectionType.toLowerCase() == 'section'){
								hasSection = true;
							}
						}else{
							if(!hasSection){
								item.Activity_No = preSectionNo + 1;
								preSectionNo = item.Activity_No;
								prevSubSectionNo = 1;
								if(item.sectionType.toLowerCase() == 'section'){
									hasSection = true;
								}
							}else{
								if(item.sectionType.toLowerCase() == 'section'){
									item.Activity_No = preSectionNo + 1;
									preSectionNo = item.Activity_No;
									prevSubSectionNo = 1;
								}else{
									item.Activity_No = preSectionNo + '.' + prevSubSectionNo;
									prevSubSectionNo = prevSubSectionNo + 1;
								}
							}
						}
					}
				});
            }, 200);
		}

		function setBasicList(){
			var projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			$scope.ApproverUserList = commonApi.getItemSelectionList({
				arrayObject: projAllRolesList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
			$scope.DisciplineList = getConfigurableAttriburteByType('Discipline');
		}

		function AddGUIDtoActivities(){
			angular.forEach($scope.Activities, function(item){
				if(!item.Activity_GUID){
					item.Activity_GUID = commonApi.guId();
					item.Observation.Ref_Activity_GUID = item.Activity_GUID;
				}
			});
		}

		function setClientlogo() {
			var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
            if (WorkingUserID.length) {
                var strOrgName = WorkingUserID[0].Name.split(',')[1].trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
		}

		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		$scope.onObservationChange = function(recordItem, index, selectedItem){
			recordItem.Observation.is_range_control = false;
			recordItem.Observation.field_label = "";
			recordItem.Observation.max_field_label = "";
			recordItem.Observation.min_field_label = "";

			if(selectedItem != 'None'){
				$scope.showObservationModal(recordItem, index, selectedItem);
			}
		};

		$scope.showObservationModal = function(recordItem, index, selectedItem){
			if(!selectedItem){
				return;
			}
			$scope.openModal(ITP_CONSTANT.OBSERVATION, recordItem, index);
		};

		$scope.openModal = function (modalId, rowData, index) {
			modelRowIndex = index;
			modalOpened = modalId;
            if (rowData) {
                $scope.modelData = angular.copy(rowData);
            }
            showModal(modalId);
		};
		
		$scope._onIsNUmberControlChange = function(){
			if(!$scope.modelData.Observation.is_number_control){
				$scope.modelData.Observation.is_range_control = false;
			}
		};

		function closeModal(){
			if(modalOpened == ITP_CONSTANT.OBSERVATION && ($scope.isOriView || $scope.isRespView)){
				if(CheckActivityOBrValidity($scope.Activities[modelRowIndex])){
					$scope.Activities[modelRowIndex].Observation.control = "None";
				}
			}
			hideModal();
		}

		function hideModal() {
			ctrl.model.modelId = '';
			$scope.modelData = {};
			$timeout(function () {
                var scrollObj = document.body;
                if (scrollObj.scrollTop == 0) {
                    scrollObj = document.documentElement;
                }
                if($scope.isRespView && scrollObj.scrollTop == 0){
                    $window.parent.postMessage("scrollTo:"+ ctrl.model.scrollTop, '*');
                }else{
					scrollObj.scrollTop = ctrl.model.scrollTop;
				}
            }, 200);
		}

		ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: closeModal,
            showloader: false,
            readOnly: false
		};
		
		function showModal(id) {
			var body = document.body;
			var docElement = document.documentElement;
			ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            if($scope.isRespView){
				$window.parent.postMessage("scrollToTop", '*');
			}
			
            ctrl.model.modelId = id;
            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4');
                modalHeader.addClass('primary-header-bg white-font');
            }, 200);
		}

		function updateRecord(){
			if(modalOpened == ITP_CONSTANT.OBSERVATION){
				var OptGroup = $scope.modelData.Observation.optionsGroup;
				var LabelIsDuplicate,ValueIsDuplicate; 
				if($element.find('#modalForm').hasClass('ng-invalid')){
					alert('Fill required fields first');
					return;
				}
				if(OptGroup.options && OptGroup.options.length){
					LabelIsDuplicate = commonApi._.uniq(OptGroup.options, function(x){ return x.Label; }).length !== OptGroup.options.length;
					ValueIsDuplicate = commonApi._.uniq(OptGroup.options, function(x){ return x.Value; }).length !== OptGroup.options.length;
					if(LabelIsDuplicate || ValueIsDuplicate){
						alert('Value and Label should be unique');
						return;
					}
				}
				
				$scope.modelData.Observation.field_name = $scope.modelData.Observation.field_label ?  $scope.modelData.Observation.field_label.trim().split(' ').join('_') : "";
				$scope.modelData.Observation.min_field_name = $scope.modelData.Observation.min_field_label ? $scope.modelData.Observation.min_field_label.trim().split(' ').join('_') : "";
				$scope.modelData.Observation.max_field_name = $scope.modelData.Observation.max_field_label ? $scope.modelData.Observation.max_field_label.trim().split(' ').join('_') : "";
				$scope.Activities[modelRowIndex] = angular.copy($scope.modelData);
			}
			hideModal();
		}

		function validateObservationFields(){
			var invalidActivity = [];
			angular.forEach($scope.Activities, function(item, index){
				if(CheckActivityOBrValidity(item)){
					invalidActivity.push(index);
				}
			});
			return commonApi._.uniq(invalidActivity);
		}

		function CheckActivityOBrValidity(item){
			var isInvalid = false;
			switch (item.Observation.control.toLowerCase()) {
				case "textbox":
				case "date input":
					if(item.Observation.is_range_control && (!item.Observation.min_field_label || !item.Observation.max_field_label)){
						isInvalid = true;
					}
					if(!item.Observation.is_range_control && !item.Observation.field_label){
						isInvalid = true;
					}
				break;
				case "selectbox":
				case "checkbox":
				case "radio button":
					if(!item.Observation.field_label){
						isInvalid = true;
					}
					angular.forEach(item.Observation.optionsGroup.options, function(option){
						if(!option.Label || !option.Label){
							isInvalid = true;
						}
					});
				break;
			}
			return isInvalid;
		}

		function setFormWorkflow() {
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var distDate = commonApi.calculateDistDateFromDays({ baseDate: getDateFromZone() , days: 7 });
			var ApproverUser = $scope.oriMsgCustomFields.sendForApproval.split('|')[2].trim();
			if($scope.isOriView){
				if(!$scope.resMsgCustomFields.Status){
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = distDate;
				}
				updateFormStatus(ITP_CONSTANT.open_status);
				$scope.oriMsgCustomFields.CurrStage = 2;
				$scope.oriMsgCustomFields.OriginatorUser = WorkingUserID['0'].Value.trim();
				$scope.oriMsgCustomFields.LastResolver = WorkingUserID['0'].Value.trim();
				$scope.resMsgCustomFields.Status = "";
				$scope.resMsgCustomFields.Comments = "";
				setDistribution(ApproverUser, "3#Respond", "3", distDate);
			}else if($scope.isRespView){
				var lastResolver = $scope.oriMsgCustomFields.LastResolver ? $scope.oriMsgCustomFields.LastResolver.split('|')[0].trim() : "";
				if($scope.oriMsgCustomFields.CurrStage == 2){
					$scope.oriMsgCustomFields.CurrStage = 3;
				}else{
					$scope.oriMsgCustomFields.CurrStage = 2;
				}
				if($scope.resMsgCustomFields.Status.toLowerCase() == 'approved'){
					$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
					setDistribution(lastResolver, '7#For Information', "13", '');
					updateFormStatus('approved');
				}
				if($scope.resMsgCustomFields.Status.toLowerCase() == 'revise and resubmit'){
					$scope.oriMsgCustomFields.LastApprover = WorkingUserID['0'].Value.trim();
					setDistribution(lastResolver, '3#Respond', "13", distDate);
					updateFormStatus('revise and resubmit');
				}
				if($scope.resMsgCustomFields.Status.toLowerCase() == 'resubmited'){
					$scope.oriMsgCustomFields.lastResolver = WorkingUserID['0'].Value.trim();
					setDistribution(ApproverUser, '3#Respond', "13", distDate);
					updateFormStatus('open');
				}
				if($scope.resMsgCustomFields.Status.toLowerCase() == 'rejected'){
					$scope.oriMsgCustomFields.LastApprover = WorkingUserID['0'].Value.trim();
					setDistribution(lastResolver, '7#For Information', "13", '');
					updateFormStatus('rejected');
				}
				if($scope.resMsgCustomFields.Status.toLowerCase() == 'cancelled'){
					$scope.oriMsgCustomFields.LastApprover = WorkingUserID['0'].Value.trim();
					setDistribution(lastResolver, '7#For Information', "13", '');
					updateFormStatus('cancelled');
				}
			}
		}
		
		function setDistribution(UsertoDist, Action, DS_AUTODist, strDate){
			var tempList = [];
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

			tempList.push({
				strUser: UsertoDist,
				strAction: Action,
				strDate: strDate
			});

			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODist
			});
		}

		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}

		function getDateFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}
		
		$scope.update();

		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView){
				if($scope.dSFormId && $scope.DS_ISDRAFT.toLowerCase() == "no" && !$scope.allowEditAndDist){
					alert('You are not allowed to Edit this ITP as the approval is currently in progress');
					return true;
				}
				$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.oriMsgCustomFields.Title + ' (Rev: '+ $scope.oriMsgCustomFields.Rev + ')';
				AddGUIDtoActivities();
				var inValidOb = validateObservationFields();
				if(inValidOb.length){
					var alertMessage = "";
					var row;
					angular.forEach(inValidOb, function(item){
						row = item + 1;
						alertMessage = alertMessage + "Fill mandatory observation value Activity row " + row + '\n';
					});
					alert(alertMessage);
					return true;
				}
				setFormWorkflow();
				$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';
			}
			if($scope.isRespView){
				if( !$scope.isAuthorized){
					alert("You are not Authorized to Respond");
					return true;
				}
				AddGUIDtoActivities();
				if($scope.oriMsgCustomFields.CurrStage == '3' && $scope.prevStatus.toLowerCase() == 'revise and resubmit'){
					$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.oriMsgCustomFields.Title + ' (Rev: '+ $scope.oriMsgCustomFields.Rev + ')';
					$scope.resMsgCustomFields.Status = "Resubmited";
				}
				setFormWorkflow();
			}
			return false;
		};

		$window.draftSubmitCallBack = function () {
			if($scope.isOriView){
				if($scope.dSFormId && $scope.DS_ISDRAFT.toLowerCase() == "no" && !$scope.allowEditAndDist){
					alert('You are not allowed to Edit this ITP as the approval is currently in progress');
					return true;
				}
			}
			return false;
		};
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}