/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/signature', '../components/inlineattachment'], function(angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;

        // restrict autosave Draft and hide Save Draft button.
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        var currentViewName = window.currentViewName;
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 1500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        $scope.myFields = $scope.data['myFields'];
        $scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
        $scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
        $scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
        $scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
        $scope.isOriView = (currentViewName == 'ORI_VIEW');
        $scope.isRespView = (currentViewName == 'RES_VIEW');
        $scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
        $scope.isRespPrintView = (currentViewName == 'RES_PRINT_VIEW');
        $scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
        $scope.isContentFilledOut = !!($scope.oriMsgCustomFields['formCreatedServerDate']);
        var currentUserid = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        
       
        $scope.xhr = {
            guIdXhr: false,
            platformXhr: false
        };
        // item for the model popup
        $scope.item = {
            rowIndex: '',
            rowObj: {
                id: '',
                listKey: '',
                index: '',
                feedbackNode: {}
            }
        };
        $scope.allRowTaskNodesList = [];

        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
            userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
            customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
            _5_Form_Data = $scope.asiteSystemDataReadOnly['_5_Form_Data'],
            isDraft = (_5_Form_Data.DS_ISDRAFT.toLowerCase() == 'yes'),
            isEditOri = !!($scope.dSFormId && !isDraft),
            CONSTANTS_OBJ = {
                IMAGE_ASITE_DEFAULT_STR: '/images/asiteWhite60x200.png',
                IMAGE_DEFAULT_STR: '/images/htmlform/sfp/sfpjv-logo.png',
                PLANT_LIST_KEY_STR: 'plant-type-list',
                PLANT_LIST_LABEL_STR: "Plant Type's list",
                PLANT_TYPE_ATTR_NAME_SPACE: 'plant type',
                PLANT_TYPE_ATTR_NAME_WITHOUT_SPACE: 'planttype',
                DS_GET_GUID: 'DS_GET_GUID',
                DOC_ASSESSMENT_KEY: 'doc-assessment',
                CONTRACTORS_USERS_KEY: 'contractors-users-list',
                DIST_USERS_LABEL_STR: 'Contractors list',
                TASK_FORM_NODE_KEY: 'task-form-node',
                TASK_FORM_NODE_OBJECT_KEY: 'taskFormNodeObj',
                TASK_AUTO_NODE_LIST_KEY: 'task-auto-node-list',
                RESET_CONFIRM_TEXT: 'This will reset your task List for this particular row. Please confirm it',
                SATISFACTORY_STR: 'satisfactory',
                UNSATISFACTORY_STR: 'unsatisfactory',
                NA_STR: 'n/a'

            },
            STATIC_OBJ = {
                CONFIG_JSON: [],
                docAssAttachedDocs: {
                    attachedDoc: ""
                },
                taskFormNodeObj: {
                    formTitle: '',
                    taskDetails: '',
                    assignTo: '',
                    dueDays: '',
                    taskGuId: '',
                    isVerificationRequired: 'Yes',
                    TaskCreated:'0'
                },
                taskFormAutoCreateNode: {
                    form_GuID: '',
                    ACF_01_CREATED_BY: '',
                    ACF_01_Date_Created: '',
                    ACF_01_DS_CLOSE_DUE_DATE: '',
                    ACF_01_DS_AUTODISTRIBUTE: '',
                    ACF_01_DS_FORMCONTENT1: '<<DS_Form_ID>>',
                    ACF_01_DS_FORMCONTENT2: '',
                    ACF_01_DS_Logo_Link: '',
                    ACF_01_DS_FORMTITLE: '',
                    ACF_01_Task_Details: '',
                    ACF_01_Task_Reference: '<<DS_Form_ID>>',
                    ACF_01_Task_Type: '',
                    ACF_01_Task_Ref_Id: '',
                    ACF_01_Assigned_To: '',
                    ACF_01_DS_WF_Next_Step: '2',
                    ACF_01_DS_ORG_PREFIX: '',
                    ACF_01_DS_Logo: '',
                    ACF_01_DS_Ref_AppId: '',
                    ACF_01_Verification_Required: 'Yes',
                    ACF_01_DS_UniqueFormRef: '',
                    ACF_01_DS_Task_Due_Days: '',
                    ACF_01_isSelected: '',
                    ACF_01_isCreated: '',
                    ACF_01_REPEATING_VALUES: {
                        ACF_01_DS_AutoDistribute_User_Group: {
                            ACF_01_DS_AutoDistribute_Users: [{
                                ACF_01_DS_PROJDISTUSERS: '',
                                ACF_01_DS_FORMACTIONS: '',
                                ACF_01_DS_ACTIONDUEDATE: '',
                                ACF_01_DS_DUEDAYS: ''
                            }]
                        }
                    }
                },
                listKeyNodeNameMap: {
                    'doc-assessment': 'docAssfeedback',
                    'gen-requirement': 'genReqfeedback',
                    'plant-specific-requirement': 'psReqfeedback'
                },
                taskDetailsNodeNameMap: {
                    'doc-assessment': 'docAssItem',
                    'gen-requirement': 'genReqCheckPoint',
                    'plant-specific-requirement': 'psReqCheckPoint'
                }
            },
            submitFlag = false,
            workingUserId = $scope.getWorkingUserId(),
            projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
            msgIncompleteActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS'),
            incompleteActionsByMsgList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');

            $scope.getServerTime(function(serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
            $scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);

        });
        var strTodayDateTime = getDateTimeFromZone();
        $scope.Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
        $scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
        $scope.oriMsgCustomFields.isDefaultLogo = true;
        $scope.isPendingAction = false;

        /**All Common functions will be start from here */

        function getDateTimeFromZone() {
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            return  (new Date(parseInt(utcDate.getTime()) + (parseFloat($window.USP.localeVO._timezone.rawOffset) + parseFloat($window.USP.localeVO._timezone.dstSavings))));
        
		}

        var structureItemList = function(setFor, availList) {
            var tempList = [],
                optlabel = '';
            switch (setFor) {
                case CONSTANTS_OBJ.PLANT_LIST_KEY_STR:
                    angular.forEach(availList, function(item) {
                        tempList.push({
                            displayValue: item.Value8,
                            modelValue: item.Value7
                        });
                    });
                    optlabel = CONSTANTS_OBJ.PLANT_LIST_LABEL_STR;
                    break;
                case CONSTANTS_OBJ.CONTRACTORS_USERS_KEY:
                    angular.forEach(availList, function(item) {
                        tempList.push({
                            displayValue: item.Name,
                            modelValue: item.Value
                        });
                    });
                    optlabel = CONSTANTS_OBJ.DIST_USERS_LABEL_STR;
                    break;
            }
            return [{
                optlabel: optlabel,
                options: tempList
            }];
        };

        $scope.bulkapply = function(strVal, docAssDoc, item) {
            for (var i = 0; i < docAssDoc.length; i++) {
                docAssDoc[i][item] = strVal;
            }
        };


        var setPlantTypeList = function() {
            var attrName = '',
                plantTypeList = customAttr.filter(function(attrObj) {
                    attrName = attrObj.Value3.toLowerCase();
                    return (attrName == CONSTANTS_OBJ.PLANT_TYPE_ATTR_NAME_SPACE || attrName == CONSTANTS_OBJ.PLANT_TYPE_ATTR_NAME_WITHOUT_SPACE) && attrObj.Value11 == 'Active';
                });

            $scope.plantTypeList = structureItemList(CONSTANTS_OBJ.PLANT_LIST_KEY_STR, plantTypeList);
        };

        var setallLists = function() {
            $scope.cvmpChecklist = $scope.oriMsgCustomFields.cvmpChecklist;
            $scope.vehicleMobilePlantDetails = $scope.cvmpChecklist.vehicleMobilePlantDetails;
            $scope.docAssessmentDetails = $scope.cvmpChecklist.docAssessmentDetails;
            $scope.genRequirementsDetails = $scope.cvmpChecklist.genRequirementsDetails;
            $scope.plantSpecificRequirementsDetails = $scope.cvmpChecklist.plantSpecificRequirementsDetails;
            $scope.inspectionDetailsSection = $scope.cvmpChecklist.inspectionDetailsSection;
            $scope.approvalCorrectiveActionsDetails = $scope.cvmpChecklist.approvalCorrectiveActionsDetails;
            $scope.sfpInspectorDetails = $scope.cvmpChecklist.sfpInspectorDetails;
            $scope.contractorDetails = $scope.cvmpChecklist.contractorDetails;
            $scope.projDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
            setPlantTypeList();
        };

        /**
         * this function is to set only index to the list for preventing clash on html view.
         */
        var setIndexesToSections = function(plantSpecificRequirementsDetails) {
            for (var i = 0; i < plantSpecificRequirementsDetails.plantSpecificRequirementsList.length; i++) {
                plantSpecificRequirementsDetails.plantSpecificRequirementsList[i].psReqSeq = i;
                for (var j = 0; j < plantSpecificRequirementsDetails.plantSpecificRequirementsList[i].subSectionList.length; j++) {
                    plantSpecificRequirementsDetails.plantSpecificRequirementsList[i].subSectionList[j].psReqSeq = j;
                }
            }
            return plantSpecificRequirementsDetails;
        };

        var setUserSelectFirstMsg = function() {
            if (!$scope.cvmpChecklist.fillUpUserRole) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1|Form can not be submitted. Please select your option or click cancel.";
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
                $scope.isOriginatorUser = ($scope.cvmpChecklist.fillUpUserRole == 'originator');
                $scope.fillUpUserRole = $scope.cvmpChecklist.fillUpUserRole;
                // set contractorlist only when contractor is selected.
                $scope.contractorsList = structureItemList(CONSTANTS_OBJ.CONTRACTORS_USERS_KEY, projAllRolesList.filter(function(obj) {
                    return obj.Value.split('|')[0].toLowerCase().trim().indexOf('contractors') > -1
                }));
                if ($scope.isOriView && !$scope.cvmpChecklist.selectedOriginator) {
                    $scope.cvmpChecklist.selectedOriginator = commonApi._.find(projAllRolesList, function(roleObj) {
                        return roleObj.Value.indexOf(workingUserId) > -1;
                    }).Value;
                }
            }
        };

        /**
         * Set view data accordingly ori view.
         */
        var setOriViewBase = function () {
            // set by default originator as only originator only can create form.	
            setallLists();
            setUserSelectFirstMsg();

            $scope.sfpInspectorDetails.inspectorName = currentUserid['0'].Value.split('|')[1].split('#')[0].trim();

            if(strTodayDateTime) {
				// set InspectionDates Date prepopulated.
				 $scope.cvmpChecklist.sfpInspectorDetails.inspectionDate = $scope.formatDate(strTodayDateTime, 'yy-mm-dd');
			} 

        };

        /**
         * Set view data accordingly response view.
         */
        var setResViewBase = function() {
            $scope.isPendingAction = commonApi.checkPendingActionOnMsg({
                incompleteActionsByMsgList: incompleteActionsByMsgList,
                actionName: 'Respond',
                strUser: workingUserId,
                isCheckMsgId: false,
                strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
            });

            if ($scope.isPendingAction || !$scope.dsDbInserted) {
                setallLists();
                setUserSelectFirstMsg();
                if ($scope.cvmpChecklist.fillUpUserRole == 'contractor') {
                    $scope.contractorDetails.contractorName = currentUserid['0'].Value.split('|')[1].split('#')[0].trim();
                }
                if ($scope.cvmpChecklist.fillUpUserRole == 'originator') {
                    $scope.sfpInspectorDetails.inspectorName = currentUserid['0'].Value.split('|')[1].split('#')[0].trim();
                }

                if(strTodayDateTime) {
                    // set InspectionContractorDate Date prepopulated.
                     $scope.cvmpChecklist.contractorDetails.inspectionContractorDate = $scope.formatDate(strTodayDateTime, 'yy-mm-dd');
                } 

                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
            }
        };

        var loadConfig = function() {
            $scope.xhr.platformXhr = true;
            $scope.loadConfig(function() {
                // set default available config data to reset fields purpose.
                STATIC_OBJ.CONFIG_JSON = angular.copy($scope.data.config);
                $scope.oriMsgCustomFields.DSI_PreviousMsgId = msgIncompleteActionList.length ? msgIncompleteActionList[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId;
                if (!isEditOri && !isDraft) {
                    $scope.oriMsgCustomFields.cvmpChecklist.instructions = angular.copy(STATIC_OBJ.CONFIG_JSON['instructions']) || [];
                    $scope.oriMsgCustomFields.cvmpChecklist.docAssessmentDetails = angular.copy(STATIC_OBJ.CONFIG_JSON['docAssessmentDetails']) || {
                        docAssessmentList: [],
                        isQuaReqToOperate: ''
                    };
                    $scope.oriMsgCustomFields.cvmpChecklist.genRequirementsDetails = angular.copy(STATIC_OBJ.CONFIG_JSON['genRequirementsDetails']) || {
                        genRequirementsList: []
                    };
                    $scope.oriMsgCustomFields.cvmpChecklist.plantSpecificRequirementsDetails = setIndexesToSections(angular.copy(STATIC_OBJ.CONFIG_JSON['plantSpecificRequirementsDetails']) || {
                        plantSpecificRequirementsList: []
                    });
                    $scope.oriMsgCustomFields.cvmpChecklist.inspectionDetailsSection = angular.copy(STATIC_OBJ.CONFIG_JSON['inspectionDetailsSection']) || {
                        plantOrigin: '',
                        isPlantToPerformWork: '',
                        plantReasonFeedback: '',
                        inspectionTypeList: []
                    };
                }

                if ($scope.isOriView) {
                    setOriViewBase();
                } else if ($scope.isRespView) {
                    setResViewBase();
                }
                $scope.isConfigDataNotAvail = false;
                $scope.xhr.platformXhr = false;
            }, function(xhr) {
                $scope.isConfigDataNotAvail = true;
                $scope.xhr.platformXhr = false;
                Notification.error({
                    title: 'Server Error While Fetching Data',
                    message: 'Error while fetching config data!!'
                });
                // set Save and Save Draft button to hide if config data is not available.									
                angular.element('#btnSaveForm').hide();
                angular.element('#btnSaveDraft').hide();
            });
        };

        $scope.addNewItem = function(list, addItemFor) {
            var newObj = angular.copy(STATIC_OBJ[addItemFor]);
            list.push(newObj);
            // set Default Task Details for the task going to be created
            if (addItemFor == CONSTANTS_OBJ.TASK_FORM_NODE_OBJECT_KEY) {
                // This function will set by default Task details using that row's item name accordingly sections. while adding it
                $scope.item.rowObj.feedbackNode.taskFormNodeList[list.length - 1].taskDetails = 'Unsatisfactory-' + $scope.item.rowObj.feedbackNode[STATIC_OBJ.taskDetailsNodeNameMap[$scope.item.rowObj.listKey]].split('<i>')[0].trim();
                // set random generated guid.
                $scope.item.rowObj.feedbackNode.taskFormNodeList[list.length - 1].taskGuId = commonApi.guId();
            }
        };

        $scope.removeItem = function(index, list) {
            list.splice(index, 1);
        };

        /**
         * this function is seprate to remove inline attachment.
         */

        $scope.setFillupUser = function(fillupUserRole) {
            $scope.cvmpChecklist.fillUpUserRole = fillupUserRole;
            $scope.oriMsgCustomFields['ORI_FORMTITLE'] = fillupUserRole == 'originator' ? 'CVMP::SFP' : 'CVMP::Conc';
            setUserSelectFirstMsg();
        };

        $scope.deleteAttchmentItem = function(obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };

        $scope.setApprovalActionNode = function() {
            if ($scope.approvalCorrectiveActionsDetails.isPlantApprovedForUseOnSite == 'no') {
                $scope.approvalCorrectiveActionsDetails.plantInductionStickerNo = '';
            } else {
                $scope.approvalCorrectiveActionsDetails.isVehicleSafeToTravel = '';
            }
        };

        $scope.setOtherMethodIfSelected = function(methodObj, parentItem) {
            // return if other check box is not selected.
            if (methodObj.methodName.toLowerCase().indexOf('other') == -1) {
                return;
            }
            // set other field as other selected
            parentItem.isOtherCleaningMethod = methodObj.isMethodSelected;
            !parentItem.isOtherCleaningMethod && (parentItem.otherCleaningMethod = '');
        };

        $scope.setAtleastOneNodeSelectedFlag = function(item, listKey, propertyKey, selectedKey) {
            var isTrueFilterdArray = item[listKey].filter(function(obj) {
                return obj[selectedKey];
            });

            item[propertyKey] = !!(isTrueFilterdArray.length);
        };

        $scope.confirmToResetTaskList = function(nodeObj, listKey) {
            var taskObj = nodeObj.taskFormNodeList.filter(function(obj) {
                return obj.TaskCreated == '1';
            });
            // return is the value is blank so it will not been called for the first time.	
            // return if taskFormNodeList length is not available as well		
            if (!nodeObj.taskFormNodeList.length || !nodeObj[STATIC_OBJ.listKeyNodeNameMap[listKey]] || taskObj.length) {
                return false;
            }
            if ($window.confirm(CONSTANTS_OBJ.RESET_CONFIRM_TEXT)) {
                nodeObj.taskFormNodeList = [];
            } else {
                // putting it in timeout 
                $timeout(function() {
                    // if no is selected then back to selected Unsatisfactory option back.
                    nodeObj[STATIC_OBJ.listKeyNodeNameMap[listKey]] = CONSTANTS_OBJ.UNSATISFACTORY_STR;
                }, 12);
            }
        };

        $scope.dateChangeEvent = function(paramObj) {
            // date comparison with other date logic 
            if (paramObj.node[paramObj.compareDate1] && paramObj.node[paramObj.compareDate2]) {
                var date1 = new Date(paramObj.node[paramObj.compareDate1]),
                    date2 = new Date(paramObj.node[paramObj.compareDate2]);

                if (paramObj.comparionMethod == 'greater' && date1 >= date2) {
                    Notification.error({
                        title: 'Validation Error',
                        message: paramObj.fieldName2 + ' should be smaller than ' + paramObj.fieldName1
                    });
                    paramObj.node[paramObj.compareDate1] = '';
                } else if (paramObj.comparionMethod == 'less' && date1 <= date2) {
                    Notification.error({
                        title: 'Validation Error',
                        message: paramObj.fieldName2 + ' should be smaller than ' + paramObj.fieldName1
                    });
                    paramObj.node[paramObj.compareDate1] = '';
                }
            }
        };

        // common item selection modal Start
        $scope.showModalThyemeLeaf = function(id, listKey, index) {
            $scope.showModal({
                id: id,
                listKey: listKey,
                index: index,
                feedbackNode: $scope.docAssessmentDetails.docAssessmentList[index]
            });
        };
        var backUpObject="";
        $scope.showModal = function (paramObj) {
            // show model first so that user can view activity going on.
            var body = document.body,
                docElement = document.documentElement;
            ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            if (currentViewName == "RES_VIEW") {
                $window.parent.postMessage("scrollToTop", '*');
            }

            ctrl.model.readOnly = (!$scope.isOriView && !$scope.isRespView) || paramObj.feedbackNode.docAssfeedback != 'unsatisfactory' && paramObj.feedbackNode.genReqfeedback != 'unsatisfactory' && paramObj.feedbackNode.psReqfeedback != 'unsatisfactory';
            ctrl.model.modelId = paramObj.id;
            $scope.item.rowIndex = paramObj.index;
            $scope.item.rowObj = paramObj;
            backUpObject = angular.copy(paramObj.feedbackNode.taskFormNodeList);

            // add branding color class
            $element.find('modal header.m-header').addClass('primary-header-bg');
        };

        var isMendatoryFieldExist = function(taskFormNodeList) {
            var taskNodeObj = {},
                isloopBreak = false;
            for (var i = 0; i < taskFormNodeList.length && !isloopBreak; i++) {
                taskNodeObj = taskFormNodeList[i];
                for (var key in taskNodeObj) {
                    if (!taskNodeObj[key]) {
                        isloopBreak = true;
                        break;
                    }
                }
            }
            return isloopBreak;
        };

        $scope.hideModal = function (strVal) {
            if(strVal!="update"){
                $scope.item.rowObj.feedbackNode.taskFormNodeList=backUpObject;
            }
            ctrl.model.modelId = '';
            $timeout(function () {
                var scrollObj = document.body;
                if (scrollObj.scrollTop == 0) {
                    scrollObj = document.documentElement;
                }
                if (currentViewName == "RES_VIEW" && scrollObj.scrollTop == 0) {
                    $window.parent.postMessage("scrollTo:"+ ctrl.model.scrollTop, '*');
                }else{
                    scrollObj.scrollTop = ctrl.model.scrollTop;
                }
            }, 50);
        };

        $scope.updateModal = function () {
            if (isMendatoryFieldExist($scope.item.rowObj.feedbackNode.taskFormNodeList)) {
                Notification.warning({
                    title: "Validation",
                    message: 'Please fill mendatory fields.!!'
                });
                return;
            } else {
                $scope.backup.item = $scope.item;
                ctrl.model.modelId = '';
            }
            $timeout(function () {
                $scope.hideModal("update");
            })
        };

        ctrl.model = {
            modelId: "",
            showModal: $scope.showModal,
            update: $scope.updateModal,
            hideModal: $scope.hideModal,
            readOnly: false
        };

        $scope.backup = {
            item: {
                rowIndex: '',
                rowObj: {
                    id: '',
                    listKey: '',
                    index: '',
                    feedbackNode: {}
                }
            }
        };
        // common item selection modal End

        /**
         * Form's workflow logic
         */
        var setFormStatusAndFlow = function() {
            var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
                currFormStaus = 'open',
                dsAutoDistribute = $scope.isRespView ? '13' : '3',
                formSelectedStaus = $scope.approvalCorrectiveActionsDetails.isPlantApprovedForUseOnSite,
                userTodistribute = '';

            if ($scope.cvmpChecklist.fillUpUserRole == 'originator') {
                if (formSelectedStaus == 'yes') {
                    currFormStaus = 'approved';
                } else if (formSelectedStaus == 'yes, with conditions') {
                    currFormStaus = 'pending';
                    userTodistribute = $scope.cvmpChecklist.selectedOriginator;
                } else {
                    currFormStaus = 'rejected';
                }
            } else if ($scope.cvmpChecklist.fillUpUserRole == 'contractor') {
                if (!$scope.dsDbInserted && $scope.isOriView) {
                    currFormStaus = 'raised'
                    userTodistribute = $scope.cvmpChecklist.selectedContractorName;
                } else {
                    // change the user role after form filled by contractor.
                    $scope.cvmpChecklist.fillUpUserRole = 'originator';
                    userTodistribute = $scope.cvmpChecklist.selectedOriginator;
                }
            }

            if (userTodistribute) {
                // Distribution Will be made from here for 
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistribute.split('|')[2].trim(),
                        strAction: "3#Respond",
                        strDate: commonApi.calculateDistDateFromDays({
                            baseDate: $scope.serverDate,
                            days: 5
                        })
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: dsAutoDistribute
                });
            }

            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: availFormStatuses,
                strStatus: currFormStaus
            });
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }
        };
        var setOriginatorDistNodes = function () { 
            if ($scope.cvmpChecklist.selectedOriginator ) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: $scope.cvmpChecklist.selectedOriginator.split('|')[2].trim(),
                        strAction: "7#For Information",
                        strDate: ""
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: $scope.isRespView ? '13' : '3'
                });
            }
        }
        /**
         * below function will be called only when form gets filled.
         */
        var isCustomFormValidationSuccess = function() {
            if (($scope.isOriView && $scope.isOriginatorUser) || $scope.isRespView) {
                var inspectionTypeObj = {};
                for (var i = 0; i < $scope.inspectionDetailsSection.inspectionTypeList.length; i++) {
                    inspectionTypeObj = $scope.inspectionDetailsSection.inspectionTypeList[i];
                    if (!inspectionTypeObj.isAtleastOneItemSelected || !inspectionTypeObj.isAtleastOneMethodSelected) {
                        Notification.error({
                            delay: 8000,
                            title: 'One Check box must selected.',
                            message: 'Each row in Section 5 must have atleast one checkbox ticked under "Specific Item" and "How Cleaned".'
                        });
                        $window.parent.postMessage("scrollToTop", '*');
                        return false;
                    }
                }
            }
            return true;
        };

        var setAutocreateNodes = function(taskList) {
            if (taskList.length) {
                var newTaskNode = {},
                    userId = workingUserId,
                    strAction = '3#Respond',
                    strDuedays = '';
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
                for (var i = 0; i < taskList.length; i++) {
                    if(taskList[i].TaskCreated=='1')
                    continue;
                    newTaskNode = angular.copy(STATIC_OBJ['taskFormAutoCreateNode']);
                    strDuedays = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: !isNaN(taskList[i].dueDays) && parseInt(taskList[i].dueDays) || 3
                    });
                    taskList[i].TaskCreated ="1";
                    // set guid for further use.
                    newTaskNode.form_GuID = taskList[i].taskGuId;
                    newTaskNode.ACF_01_DS_FORMCONTENT2 = taskList[i].taskGuId;

                    // set node from the form to the auto create form.
                    newTaskNode.ACF_01_DS_FORMTITLE = taskList[i].formTitle;
                    newTaskNode.ACF_01_Task_Details = taskList[i].taskDetails,
                    newTaskNode.ACF_01_Assigned_To = taskList[i].assignTo;
                    newTaskNode.ACF_01_DS_Task_Due_Days = taskList[i].dueDays;
                    newTaskNode.ACF_01_Verification_Required = taskList[i].isVerificationRequired;
                    newTaskNode.ACF_01_CREATED_BY = userId;
                    newTaskNode.ACF_01_Date_Created = $scope.todayDateDbFormat;
                    newTaskNode.ACF_01_DS_CLOSE_DUE_DATE = strDuedays;
                    newTaskNode.ACF_01_DS_AUTODISTRIBUTE = "3";
                    newTaskNode.ACF_01_DS_Ref_AppId = $window.AppBuilderFormIDCode;
                    newTaskNode.ACF_01_Task_Type = "Incident";
                    newTaskNode.ACF_01_DS_FORMCONTENT1 = '<<DS_Form_ID>>';
                    newTaskNode.ACF_01_Task_Reference = '<<DS_Form_ID>>';
                    newTaskNode.ACF_01_isCreated = "1";
                    var childNodes = newTaskNode.ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users;
                    if (childNodes && childNodes.length) {
                        for (var j = 0; j < childNodes.length; j++) {
                            childNodes[j].ACF_01_DS_PROJDISTUSERS = taskList[i].assignTo;
                            childNodes[j].ACF_01_DS_FORMACTIONS = strAction;
                            childNodes[j].ACF_01_DS_ACTIONDUEDATE = strDuedays;
                        }
                    }

                    // final pushing node.
                    $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);
                }
            }
        };

        var updateAllRowTaskNodesList = function() {
            var primaryKey = ['docAssessmentDetails', 'genRequirementsDetails', 'plantSpecificRequirementsDetails'],
                subKey = ['docAssessmentList', 'genRequirementsList', 'plantSpecificRequirementsList'],
                currList = '',
                currTaskList = '';
            for (var i = 0; i < primaryKey.length; i++) {
                currList = $scope[primaryKey[i]][subKey[i]];
                for (var j = 0; j < currList.length; j++) {
                    if (primaryKey[i] == 'plantSpecificRequirementsDetails' && subKey[i] == 'plantSpecificRequirementsList') {
                        if (currList[j].isPsReqShow) {
                            for (var k = 0; k < currList[j].subSectionList.length; k++) {
                                currTaskList = currList[j].subSectionList[k].taskFormNodeList;
                                for (var l = 0; l < currTaskList.length; l++) {
                                    $scope[primaryKey[i]].isTaskCreated = true;
                                    $scope.allRowTaskNodesList.push(currTaskList[l]);
                                }
                            }
                        }
                    } else {
                        currTaskList = currList[j].taskFormNodeList;
                        for (var k = 0; k < currTaskList.length; k++) {
                            $scope[primaryKey[i]].isTaskCreated = true;
                            $scope.allRowTaskNodesList.push(currTaskList[k]);
                        }
                    }
                }
            }
        };

        /**
         * set submitflag true and manually submit the form.
         */
        var submitFormOnDone = function() {
            submitFlag = true;
            // remove loaded class to show loader
            $element.removeClass('loaded');
            $window.submitForm(1);
        };

        var setFormWorkflow = function() {

            // remove config data not needed.
            delete $scope.data.config;
            // Form Title Set from here
            if ($scope.isOriView) {
                $scope.oriMsgCustomFields['ORI_FORMTITLE'] = $scope.isOriginatorUser ? 'CVMP::SFP' : 'CVMP::Conc';
            }
            // reseting the auto dist node.
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            // flow for contractor or originator
            if ($scope.dsDbInserted || (!$scope.dsDbInserted && $scope.isOriginatorUser) || ($scope.isRespView && !$scope.isOriginatorUser)) {

                // set Date to Show on the Print Views.
                $scope.oriMsgCustomFields['formCreatedServerDate'] = $scope.serverDate;

                // set node to identify form on originator's view.
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';

                // reset task form node blank for ori view.
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
                $scope.allRowTaskNodesList = [];

                updateAllRowTaskNodesList();
                var formSelectedStaus = $scope.approvalCorrectiveActionsDetails.isPlantApprovedForUseOnSite;
                 if (formSelectedStaus == 'yes' || formSelectedStaus == 'no') {
                    setOriginatorDistNodes();
                }
                if ($scope.allRowTaskNodesList.length) {
                    // set auto node for task node to auto create it.
                    setAutocreateNodes($scope.allRowTaskNodesList);
                    setFormStatusAndFlow();
                    $scope.xhr.guIdXhr = false;
                    submitFormOnDone();
                } else {
                    setFormStatusAndFlow();
                    submitFormOnDone();
                }
            } else {
                setFormStatusAndFlow();
                submitFormOnDone();
            }
        };

        $scope.isDraft = isDraft;
        if ($scope.isOriView || $scope.isRespView) {
            loadConfig();
        } else if ($scope.isOriPrintView || $scope.isRespPrintView) {
            //  execute below code only form is created.
            if (!$scope.isDraft) {
                $scope.isPendingAction = commonApi.checkPendingActionOnMsg({
                    incompleteActionsByMsgList: incompleteActionsByMsgList,
                    actionName: 'Respond',
                    strUser: workingUserId,
                    isCheckMsgId: false,
                    strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
                });
            }

            setallLists();
            // set Task form tracker details
            $scope.taskTrackerDetailsList = commonApi._.filter($scope.getValueOfOnLoadData('DS_Check_FormContent_Data'), function(val) {
                return val.Value15 == 'ORI001';
            });

            // set originator and user role field.
            $scope.isOriginatorUser = ($scope.cvmpChecklist.fillUpUserRole == 'originator');
            $scope.fillUpUserRole = $scope.cvmpChecklist.fillUpUserRole;
        }

        $scope.isCallForDraft = false;
        var formSubmitCallBack = function() {
            !$scope.isCallForDraft && setFormWorkflow();
        };

        $scope.update();

        $window.oriformSubmitCallBack = function() {
            if (submitFlag) {
                return false;
            }

            if (isCustomFormValidationSuccess()) {
                formSubmitCallBack();
            }
            return true;
        };

        $window.draftSubmitCallBack = function() {
            $scope.isCallForDraft = true;
            // remove config data not needed.
            delete $scope.data.config;

            formSubmitCallBack();
        };
    }

    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}