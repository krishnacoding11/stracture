define(['angular', './base', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = $window.currentViewName;        
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.showTenderDataTable = false;
        $scope.isDataLoaded = true;
        $scope.isVenNoMandatory = false;
        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.vendorDetails = $scope.oriMsgCustomFields.vendorDetails;
        $scope.vendorStwCostCodeMapping = $scope.oriMsgCustomFields.vendorStwCostCodeMapping;
        $scope.updateStwCostCodeGroup = $scope.oriMsgCustomFields.updatedVendorStwCostCodeMapping;
        $scope.contractorCodePaging = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_STW_CONTRACTOR_CODE_PAGING');
        var ds_Asi_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var ds_Asi_Std_ecc4_STW_DUPLICATE_ORG_CHECK = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_DUPLICATE_ORG_CHECK");
        var ds_Asi_Std_ecc4_STW_GET_VENDORNOS = $scope.getValueOfOnLoadData("DS_ASI_STD_ECC4_STW_GET_VENDORNOS");
        $scope.oriMsgCustomFields.data_selections = $scope.oriMsgCustomFields.data_selections || 'Yes';
        $scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
        $scope.isEditori = false;        
        $scope.isXHRon = false;
        $scope.guidXhr = false;
        $scope.costCodeXhr = false;
        $scope.disableTenderName = false;
        // side bar default set open
        $scope.isSideBarOpen = false;
        $scope.isAnyLotSelected = false;
        $scope.isEccLotSelected = false;
        $scope.isPscLotSelected = false;
        $scope.isImportBasicValid = true;
        $scope.basicValidationMsg = '';
        $scope.isDupContInProgress = false;
        $scope.dupContCodeList = [];
        $scope.isStwMappInProgress = false;
        $scope.stwCodeUnMappedList = [];
        $scope.filterFieldObj = {
            contCostCode : '',
            contCostCodeDesc : '',
            stwCostCode : '',
            stwCostCodeDesc : '',
            stwCostCodeUom : '',
            historyLogString : ''
        };

        var modelRowIndex = -1, 
        STATIC_OBJ_DATA = {            
            Pages: {
                Page_Range: ""
            },
            mappingObj : {
                mappingGuid : '',
                isMappingSelected : '',
                isMappingShow : '',
                isMappingDisable : false,
                isFieldDisable :false,
                isNodeDbEntryDone : false,
                venodorCostCode : {
                    contCostCode : '',
                    contCostCodeDesc : ''
                },
                stwCostCodeObj : {
                    stwCostCode : '',
                    stwCostCodeDesc : '',
                    stwCostCodeUom : ''
                },
                importedContCostCode : '',
                importedContCostCodeDesc : '',
                importedStwCostCode : '',
                importedStwCostCodeDesc : '',
                importedStwCostCodeUom : '',
                historyLogString: ''
            },
            VendorNos: {
                ContractCompany: "",
                VendorNo: "",
                isSubmitted:"",
                isValidVendor: "Yes",
            }
        },
        onloadBackUp = {
            costCodeList: [],
            changingList : []
        },
        guidRowObj = {},
        classApp = angular.module('classApp', []),
        dataCached = {
            importedSheet : [],
            structuredImportedSheet : []
        },
        submitFlag = false,
        isOriView = (currentViewName == "ORI_VIEW"),
        isOriPrintView = (currentViewName == "ORI_PRINT_VIEW");
        
        $scope.isImported = (($scope.oriMsgCustomFields.isImported || '').trim().toLowerCase() == 'yes');        
        $scope.isEditOri = !!(isOriView && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT != 'YES' && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID);

        if(isOriView)
        {
            fillContractCompany();
        }
        classApp.controller('classCtrl', function ($scope) {
            $scope.isActive = false;
            $scope.activeButton = function () {
                $scope.isActive = !$scope.isActive;
            }
        });
        var validationString = "1| Imported Data is not proper. Please correct the Excel import sheet and try again.",
            getGUIdOnCallBack = function (guidLength, callBack) {
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": 'DS_GET_GUID',
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": 'DS_GET_GUID',
                        "fieldValue": guidLength
                    }]
                }
            };
            $scope.guidXhr = $scope.getCallbackData(form).then(function (response) {
                var strGetDetails = []
                if (response.data) {
                    strGetDetails = angular.fromJson(response.data['DS_GET_GUID']).Items.Item;
                }
                callBack(strGetDetails);
                $scope.guidXhr = false;
            }, function (error) {
                var errorMsg = 'Error retriving Guid <br/>' + error;
                Notification.error({
                    title: 'Server Error',
                    message: errorMsg
                });
                $scope.guidXhr = false;
            });
        },  updateRecord = function() {
            if ($scope.guidXhr || $scope.costCodeXhr) {
                return false;
            } else if (!($scope.modelData.venodorCostCode.contCostCode && $scope.modelData.venodorCostCode.contCostCodeDesc && $scope.modelData.stwCostCodeObj.stwCostCode && $scope.modelData.stwCostCodeObj.stwCostCodeDesc && $scope.modelData.stwCostCodeObj.stwCostCodeUom)) {
                Notification.warning({
                    title: "Validation",
                    message: 'Please fill mandatory fields.!!'
                });
                return false;
            }

            $timeout(function () {
                var rowIndex = modelRowIndex,
                    newNode = angular.copy($scope.modelData);
                if(ctrl.model.modelId == 'mapping-cost-code') {
                    if (rowIndex > -1) {
                        $scope.vendorStwCostCodeMapping.mappingList[rowIndex] = newNode;
                    } else {
                        $scope.vendorStwCostCodeMapping.mappingList.unshift(newNode);
                        onloadBackUp.changingList.unshift(newNode);
                        // update total page count on newly added one.
                        $scope.oriMsgCustomFields.Total_Pages = onloadBackUp.changingList.length;
                    }
                    guidRowObj[newNode.mappingGuid] = newNode;
                }

                hideModal();

            }, 200);
        },  hideModal = function() {
            ctrl.model.modelId = '';
        },  putRecordInUpdation = function(paramObj) {
            var rowObj = {};
            for (var i = 0; i < paramObj.multipleList.length; i++) {
                rowObj = paramObj.parent[paramObj.multipleList[i]];
                guidRowObj[rowObj.mappingGuid] = rowObj;
            }
        },  setBackUpAndPagination = function (isOriView) {
            onloadBackUp.costCodeList = angular.copy($scope.vendorStwCostCodeMapping.mappingList);
            onloadBackUp.changingList = angular.copy($scope.vendorStwCostCodeMapping.mappingList);
            $scope.oriMsgCustomFields.Total_Pages = $scope.vendorStwCostCodeMapping.mappingList.length;
            // set first 50 on load.
            $scope.setPagination($scope.oriMsgCustomFields.Page_Sel || '1-50');
        },  setImportedDataInCache = function(guidResp) {
            var stwMappingObj = {}, stwMapping = [], lastUsedGuidIndex = 0;
            
            for(var i=0; i< $scope.vendorStwCostCodeMapping.mappingList.length; i++) {
                stwMappingObj = $scope.vendorStwCostCodeMapping.mappingList[i];
                stwMapping.push({
                    mappingGuid :  stwMappingObj.mappingGuid,
                    isMappingSelected : stwMappingObj.isMappingSelected || false,
                    isMappingShow : stwMappingObj.isMappingShow || true,
                    isMappingDisable : stwMappingObj.isMappingDisable || false,
                    isFieldDisable : stwMappingObj.isFieldDisable || false,
                    isNodeDbEntryDone : stwMappingObj.mappingGuid ? true : false,
                    venodorCostCode : {
                        contCostCode : stwMappingObj.importedContCostCode || stwMappingObj.venodorCostCode.contCostCode,
                        contCostCodeDesc : stwMappingObj.importedContCostCodeDesc || stwMappingObj.venodorCostCode.contCostCode
                    },
                    stwCostCodeObj : {
                        stwCostCode : stwMappingObj.importedStwCostCode || stwMappingObj.stwCostCodeObj.stwCostCode,
                        stwCostCodeDesc : stwMappingObj.importedStwCostCodeDesc || stwMappingObj.stwCostCodeObj.stwCostCodeDesc,
                        stwCostCodeUom : stwMappingObj.importedStwCostCodeUom || stwMappingObj.stwCostCodeObj.stwCostCodeUom
                    },
                    historyLogString : stwMappingObj.historyLogString
                });
                if(!stwMappingObj.mappingGuid && guidResp[lastUsedGuidIndex]) {
                    stwMapping[i].mappingGuid = guidResp[lastUsedGuidIndex].Value2 || '';
                    guidRowObj[guidResp[lastUsedGuidIndex].Value2] = stwMapping[i];
                    lastUsedGuidIndex++;
                }
            }            
            // set imported strucutered data to the list.
            $scope.vendorStwCostCodeMapping.mappingList = angular.copy(stwMapping);
            dataCached.structuredImportedSheet = angular.copy(stwMapping);

            // reset page selection to set pagination.
            $scope.oriMsgCustomFields.Page_Sel = '';
            setBackUpAndPagination();
            setPagingData();
            $scope.setPagination($scope.oriMsgCustomFields.Page_Sel);
            // update the scope value
            $scope.update();
        },  returnDuplicateObj = function (paramObj){
            var dupArray = [], dupKeyMap = {},currObj;
            for(var i=0; i<paramObj.mainObj.length; i++) {
                currObj = paramObj.mainObj[i];    
                if(!currObj.mappingGuid && dupKeyMap.hasOwnProperty(currObj[paramObj.dupKeyToFind])) {
                    dupArray.push(currObj);                    
                } else {
                    dupKeyMap[currObj[paramObj.dupKeyToFind]] = currObj;
                }
            }
            return dupArray;
        },  validateContractorCode = function(impoData, callBackFun) {
            var dupContCostCodes = returnDuplicateObj({
                mainObj : impoData,
                dupKeyToFind : 'importedContCostCode'
            });

            if (dupContCostCodes.length) {
                callBackFun && callBackFun(dupContCostCodes);
            } else {
                var strUniqueContCostCode = commonApi._.uniq(impoData.filter(function(impoRecord){
                    return !impoRecord.mappingGuid;
                }), false, "importedContCostCode").map(function(recordObj) {
                    return recordObj.importedContCostCode
                }).join(",");

                if(strUniqueContCostCode) {
                    checkContCostCodeInDB(strUniqueContCostCode,function (contCostCodeDetails) {
                        // UNIQUE LIST OF VENDOR COST CODE.
                        var uniqueContList = commonApi._.uniq(contCostCodeDetails, false, 'Value2'),
                            dupContCostCodes = uniqueContList.filter(function (contCodeObj) {
                            return contCodeObj.Value1 && contCodeObj.Value2;
                        });
                        callBackFun && callBackFun(dupContCostCodes);
                    });
                } else {
                    callBackFun && callBackFun([]);
                }
            }
        },  validateStwCodeMapping = function(strUniqueStwCode, callBackFun) {                        
            $scope.getStwCostCodeMapping(strUniqueStwCode, function (costCodeDetails) {        
                callBackFun && callBackFun(costCodeDetails);    
            });
        },  validateImportedData = function (impoData, guidResp) {
            // to show the import validation process
            $scope.loaded = true;
            $element.addClass('loaded');

            $scope.isDupContInProgress = true;
            validateContractorCode(impoData, function(duplicateList) {
                if (duplicateList.length) {
                    $scope.dupContCodeList = duplicateList || []; 
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = validationString;
                } else {
                    $scope.isSideBarOpen = false;
                }
                $scope.isDupContInProgress = false;
            });

            var uniqueStwCodeList = commonApi._.uniq(impoData.filter(function(impoRecord){
                    return !impoRecord.mappingGuid;
                }), false, 'importedStwCostCode'),
                uniqueStwCodeMap =  commonApi._.indexBy(uniqueStwCodeList, 'importedStwCostCode'),
                strUniqueStwCode = uniqueStwCodeList.map(function(recordObj) {
                    return recordObj.importedStwCostCode;
                }).join(',');
            
            if(uniqueStwCodeList.length && strUniqueStwCode) {
                $scope.isStwMappInProgress = true;
                validateStwCodeMapping(strUniqueStwCode, function(stwCodeUnMappedList) {
                    if (stwCodeUnMappedList.length) {
                        // filtered Out the not available Codes.
                        var unmappedCodes = [], objRecord = {};
                        for (var i=0; i<stwCodeUnMappedList.length; i++) {
                            objRecord = stwCodeUnMappedList[i];
                            if(!objRecord.Value4) {                                
                                unmappedCodes.push(objRecord);
                            }
                        }
    
                        $scope.stwCodeUnMappedList = unmappedCodes;
                        unmappedCodes.length && ($scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = validationString);
                    } else {                    
                        $scope.isSideBarOpen = false;                    
                    }
                    $scope.isStwMappInProgress = false;
                }); 
            }
        },  basicValidationKeyMap = {
            '1' : 'Imported sheet is not from the same organisation. Please import sheet of same organisation.!',
            '2' : 'Imported sheet is not latest Exported. Please get the latest exported data.!'
        },  checkForLatestImportKey = function (guidResp) {
            if(!$scope.oriMsgCustomFields.DSI_UniqueKey) {
                Notification.error({
                    title: 'Import sheet validation',
                    message: 'Unique key is not available from your Exported Sheet. Please get the latest Excel'
                });
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = validationString;
                return false;
            }

            var uniqKeyCombo = $scope.oriMsgCustomFields.DSI_UniqueKey + '$$'+ $scope.vendorDetails.contractOrg.orgId +'$$STW-CCCD';
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = $scope.oriMsgCustomFields.DSI_UniqueKey;        
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": "DS_ASI_STD_ECC4_STW_VALIDATE_VENDORCOSTCODE",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_ASI_STD_ECC4_STW_VALIDATE_VENDORCOSTCODE",
                        "fieldValue": uniqKeyCombo
                    }]
                }
            };

            $scope.guidXhr = true;
            $scope.getCallbackData(form).then(function (response) {
                if (response.data) {
                    $scope.isImportBasicValid = false;                    
                    $scope.guidXhr = false;
                    var uniqKeyResp = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_VALIDATE_VENDORCOSTCODE']).Items.Item[0] || {};
                    if(['1','2'].indexOf(uniqKeyResp.Value2) > -1) {
                        $scope.basicValidationMsg = basicValidationKeyMap[uniqKeyResp.Value2];
                        Notification.error({
                            title: 'Import sheet validation',
                            message: $scope.basicValidationMsg
                        });
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = validationString;                        
                    } else {
                        $scope.isImportBasicValid = true;
                        validateImportedData($scope.vendorStwCostCodeMapping.mappingList, guidResp);
                        setImportedDataInCache(guidResp);
                    }
                }
            },  function (error) {    
                $scope.guidXhr = false;
                var errorMsg = 'Error retriving data<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });                
            });
        };

        $scope.tableUtilSettings = {
            mappingListObj: {
                tooltip: "Select to Edit",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0,
                    deleteSelected: 0,
                    editRow: 1,
                    deactivateRow: 1,
                    reactivateRow: 1
                },
                checkboxModelKey: "isMappingSelected",
                disableRowKey: "isMappingDisable",
                editRowCallBack: function(rowData) {
                    $scope.openModal('mapping-cost-code', rowData);
                },
                DEACTIVATE_MSG: "Deactivate selected row/rows",
                deactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },
                REACTIVATE_MSG: "Reactivate selected row/rows",
                reactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },                
                newStaticObject: angular.copy(STATIC_OBJ_DATA.mappingObj),
                deleteCurrRowMsg: "Remove Stw_Cost_Code Detail",
                deleteSelectedMsg: "Remove selected Stw_Cost_Code Detail"
            }
        };

        $scope.modelData = angular.copy(STATIC_OBJ_DATA.vendorStwCostCodeMapping);
        $scope.openModal = function (modalId, rowData) {
            if(!$scope.vendorDetails.vendorName){
                return false;
            }

            // show modal
            ctrl.model.modelId = modalId;
            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4');
                modalHeader.addClass('primary-header-bg white-font')
            }, 5);

            modelRowIndex = -1;
            if (rowData) {
                modelRowIndex = rowData.index;
                $scope.form.title = "Edit Vendor Cost Code Details";
                $scope.modelData = angular.copy(rowData.row);
                if (isOriPrintView) {
                    ctrl.model.readOnly = true;
                }
            } else {
                $scope.form.title = "Add Vendor Cost Code Details";
                // get single guid on add row
                getGUIdOnCallBack(1, function (guidResp) {
                    if (modalId == 'mapping-cost-code'){
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.mappingObj);
                        // set first record guid.
                        $scope.modelData.mappingGuid = guidResp[0].Value2;
                    }
                });
            }
        };

        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false,
            disableBtn: !$scope.guidXhr
        };

        var resetFilterFields = function () {
            $scope.filterFieldObj = {
                contCostCode : '',
                contCostCodeDesc : '',
                stwCostCode : '',
                stwCostCodeDesc : '',
                stwCostCodeUom : '',
                historyLogString : ''            
            };
            $scope.oriMsgCustomFields.data_selections = "Yes";
            $scope.oriMsgCustomFields.Page_Sel = "";
        };

        $scope.resetTrackerFilter = function (event) {
            resetFilterFields();
            $scope.filterTrackerLog(event, true, false);
        };

        var isRowBelongsToFilter = function(rowObj) {
            return ((($scope.oriMsgCustomFields.data_selections == 'Yes' && rowObj.isMappingDisable == false) 
            || ($scope.oriMsgCustomFields.data_selections == 'No' && rowObj.isMappingDisable == true)) 
            && rowObj.venodorCostCode.contCostCode.trim().toLowerCase().indexOf($scope.filterFieldObj.contCostCode.trim().toLowerCase()) > -1
            && rowObj.venodorCostCode.contCostCodeDesc.trim().toLowerCase().indexOf($scope.filterFieldObj.contCostCodeDesc.trim().toLowerCase()) > -1
            && rowObj.stwCostCodeObj.stwCostCode.trim().toLowerCase().indexOf($scope.filterFieldObj.stwCostCode.trim().toLowerCase()) > -1
            && rowObj.stwCostCodeObj.stwCostCodeDesc.trim().toLowerCase().indexOf($scope.filterFieldObj.stwCostCodeDesc.trim().toLowerCase()) > -1
            && rowObj.stwCostCodeObj.stwCostCodeUom.trim().toLowerCase().indexOf($scope.filterFieldObj.stwCostCodeUom.trim().toLowerCase()) > -1);
        },  getPagingArray = function (totalRecords) {
            var pageSize = parseInt($scope.oriMsgCustomFields.Page_Slice);
            var pageStart = 1;
            var totalItemCount = totalRecords;
            var pageArray = [];

            var currPageIndex = 1;
            var totalPage = Math.ceil(totalItemCount / pageSize);
            var tmpTotalCount = totalItemCount;
            while (currPageIndex <= totalPage) {
                var pageEnd = (pageSize > tmpTotalCount ? tmpTotalCount : pageSize) + pageStart - 1;
                pageArray.push(pageStart + '-' + pageEnd);
                tmpTotalCount = tmpTotalCount - pageSize;
                currPageIndex++;
                pageStart = pageEnd + 1;
            }
            return pageArray;
        },  addNewPageNode =function (pageParam) {
            var tmpTotalCount = pageParam.totalCount,
                nodeKey = pageParam.nodeKey,
                parentNode = pageParam.parentNode,
                pageNode = pageParam.pageNode,
                dropdownModal = pageParam.dropdownModal;

            var pageNumberArray = getPagingArray(tmpTotalCount);

            if (!$scope.oriMsgCustomFields[dropdownModal]) {
                $scope.oriMsgCustomFields[dropdownModal] = pageNumberArray[0];
            }

            for (var index = 0; index < pageNumberArray.length; index++) {
                var pageStr = pageNumberArray[index];
                var newPageNode = angular.copy(STATIC_OBJ_DATA[nodeKey]);
                newPageNode[pageNode] = pageStr;
                $scope.oriMsgCustomFields[parentNode][nodeKey].push(newPageNode);
            }
        },  setPagingData = function () {
            $scope.oriMsgCustomFields.Tabbed_Paging.Pages = [];
            var pageParamObj = {
                totalCount: $scope.oriMsgCustomFields.Total_Pages,
                nodeKey: 'Pages',
                parentNode: 'Tabbed_Paging',
                pageNode: 'Page_Range',
                dropdownModal: 'Page_Sel'
            };
            addNewPageNode(pageParamObj);
            setDefaultRange();
        };

        $scope.setPagination = function (pageIndex) {
            var temp = angular.copy(onloadBackUp.changingList);
            var splittedIndex = pageIndex.split('-'),
                pageSlice = parseInt($scope.oriMsgCustomFields["Page_Slice"]) || 50,
                spliceCount = (parseInt(splittedIndex[0]) + pageSlice > onloadBackUp.changingList.length) && !(parseInt(splittedIndex[1] + pageSlice) > onloadBackUp.changingList.length) ? ((onloadBackUp.changingList.length - 1) - parseInt(splittedIndex[0])) : pageSlice,
                pageRangeList = temp.splice(splittedIndex[0] - 1, spliceCount);
            $scope.vendorStwCostCodeMapping.mappingList = pageRangeList;
        };

        $scope.filterTrackerLog = function(event, isForReset, isOnload) {
            if(!$scope.vendorDetails.vendorName) {
                return false;
            };

            var dataSourceInc = "DS_ASI_STD_ECC4_STW_CONTRACTOR_CODE_PAGING",
            tmpTrackerParam = $scope.filterFieldObj.contCostCode + '|' + $scope.filterFieldObj.contCostCodeDesc + '|' + $scope.filterFieldObj.stwCostCode + '|' + $scope.filterFieldObj.stwCostCodeDesc + '|' + $scope.filterFieldObj.stwCostCodeUom + '|' + $scope.oriMsgCustomFields.data_selections + '|' + $scope.vendorDetails.vendorName.split('#')[0].trim();

            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": tmpTrackerParam
                    }]
                }
            };			

            $scope.isXHRon = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;
                if (resData) {
                    var lstvalue = angular.fromJson(response.data[dataSourceInc]).Items.Item,rowObj,foundedIndex,
                        isBlankFilter = !$scope.filterFieldObj.contCostCode && !$scope.filterFieldObj.contCostCodeDesc && !$scope.filterFieldObj.stwCostCode && !$scope.filterFieldObj.stwCostCodeDesc && !$scope.filterFieldObj.stwCostCodeUom;
                    $scope.vendorStwCostCodeMapping.mappingList = [];
                    
                    for (var i = 0; i < lstvalue.length; i++) {
                        $scope.vendorStwCostCodeMapping.mappingList.push({
                            mappingGuid :  lstvalue[i].Value6,
                            isMappingSelected : '',
                            isMappingShow : '',
                            isMappingDisable : (lstvalue[i].Value7 == 'true'),
                            isFieldDisable : true,
                            isNodeDbEntryDone : true,
                            venodorCostCode : {
                                contCostCode : lstvalue[i].Value1,
                                contCostCodeDesc : lstvalue[i].Value2
                            },
                            stwCostCodeObj : {
                                stwCostCode : lstvalue[i].Value3,
                                stwCostCodeDesc : lstvalue[i].Value4,
                                stwCostCodeUom : lstvalue[i].Value5
                            },
                            historyLogString : lstvalue[i].Value10
                        }); 
                    }

                    // Push updated nodes to the list if changed before filter.                        
                    for (var key in guidRowObj) {
                        // skip loop if the property is from prototype
                        if (!guidRowObj.hasOwnProperty(key)) continue;
                        rowObj = guidRowObj[key];
                        foundedIndex = commonApi._.findIndex($scope.vendorStwCostCodeMapping.mappingList, {
                            mappingGuid : rowObj.mappingGuid 
                        });
                        if(isRowBelongsToFilter(rowObj)) {
                            if(foundedIndex>-1){
                                $scope.vendorStwCostCodeMapping.mappingList[foundedIndex] = rowObj;
                            } else if (rowObj) {
                                $scope.vendorStwCostCodeMapping.mappingList.unshift(rowObj);
                            }
                        } else if($scope.oriMsgCustomFields.data_selections == 'All' && foundedIndex>-1){
                            // remove element if it doesn't suit in the filter from pagination array.
                            $scope.vendorStwCostCodeMapping.mappingList[foundedIndex] = rowObj;                        
                        } else if($scope.oriMsgCustomFields.data_selections == 'All' && foundedIndex == -1) {
                            // remove element if it doesn't suit in the filter from pagination array.
                            $scope.vendorStwCostCodeMapping.mappingList.unshift(rowObj);                        
                        } else if($scope.oriMsgCustomFields.data_selections != 'All' && foundedIndex>-1){
                            // remove element if it doesn't suit in the filter from pagination array.
                            $scope.vendorStwCostCodeMapping.mappingList.splice(foundedIndex, 1);                           
                        }
                    }
                    if(isOnload) {
                        onloadBackUp.costCodeList = angular.copy($scope.vendorStwCostCodeMapping.mappingList);
                    } 
                    // data back up with 'onChangingList' key changed while active inactive selection.
                    onloadBackUp.changingList = angular.copy($scope.vendorStwCostCodeMapping.mappingList);                    
                    $scope.oriMsgCustomFields.Total_Pages = $scope.vendorStwCostCodeMapping.mappingList.length;                        
                    ($scope.vendorStwCostCodeMapping.mappingList.length < 50) ? $scope.oriMsgCustomFields.Page_Sel = '1-'+$scope.vendorStwCostCodeMapping.mappingList.length : $scope.oriMsgCustomFields.Page_Sel = '1-50';
                    setPagingData(); 
                    if(isForReset || (!isForReset && $scope.vendorStwCostCodeMapping.mappingList.length > 50 && isBlankFilter)) {
                        $scope.setPagination($scope.oriMsgCustomFields.Page_Sel);
                    }                    
                }
            }, function (error) {
                $scope.isXHRon = false;                
                var errorMsg = 'Error retriving DocumentData<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
            });
        };

        $scope.getStwCostCodeMapping = function(stwCostCode, callBackFunc) {
            if(!stwCostCode || !$scope.vendorDetails.vendorName){
                return false;
            }
            
            var dataSourceInc = "DS_ASI_STD_ECC4_STW_GET_CONTRACTOR_CODE",
                tmpTrackerParam = stwCostCode + '|' + $scope.vendorDetails.vendorName.split('#')[0].trim();

            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": tmpTrackerParam
                    }]
                }
            };			

            $scope.costCodeXhr = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.costCodeXhr = false;
                if (resData) {
                    var costCodeDetails = angular.fromJson(response.data[dataSourceInc]).Items.Item || [{}];
                    if(callBackFunc) {
                        callBackFunc(costCodeDetails);
                    } else {
                        costCodeDetails = costCodeDetails[0];
                        // taking the only first one
                        $scope.modelData.stwCostCodeObj.stwCostCodeDesc = costCodeDetails.Value2 || '';
                        $scope.modelData.stwCostCodeObj.stwCostCodeUom = costCodeDetails.Value3 || '';
                    }
                }
            }, function (error) {
                $scope.costCodeXhr = false;                
                var errorMsg = 'Error retriving data<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
                callBackFunc && callBackFunc([]);
            });
        };

        var checkContCostCodeInDB = function(contCostCode, callBackFunc) {
            var dataSourceInc = 'DS_ASI_STD_ECC4_STW_CODE_CHECK_DUPLICATE';
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": 'STW-CCCD|'+contCostCode+ '|' + $scope.vendorDetails.vendorName.split('#')[0].trim()
                    }]
                }
            };			

            $scope.costCodeXhr = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.costCodeXhr = false;
                if (resData) {
                    // taking the only first one
                    var contCostCodeObj = angular.fromJson(response.data[dataSourceInc]).Items.Item || [{}];
                    if(callBackFunc) {
                        callBackFunc(contCostCodeObj);
                    } else {
                        contCostCodeObj = contCostCodeObj[0];
                        if(contCostCodeObj.Value2 && contCostCodeObj.Value1) {
                            Notification.error({
                                title: 'Duplicate Entry Found.',
                                message: 'Duplicate Vendor Cost Code found. Please enter different Vendor Cost Code..!'
                            });
                            $scope.modelData.venodorCostCode.contCostCode = '';
                        }
                    }
                }
            }, function (error) {
                $scope.costCodeXhr = false;
                var errorMsg = 'Error retriving data<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
                callBackFunc && callBackFunc([]);
            });
        };

        /**
         *   this function checks duplicate Contractor cost code whether created or not while adding new one.
         *   anf only make ajax call if not found it in locally all active data.
         **/
        $scope.validateForDuplicate = function (contCostCode) {
            if(!contCostCode) {
                return false;
            }

            var dupCostCode = onloadBackUp.costCodeList.filter(function(codeObj) {
                return codeObj.venodorCostCode.contCostCode == contCostCode;
            }) || [];

            if(!dupCostCode.length) {
                var rowObj;
                for (var key in guidRowObj) {
                    // skip loop if the property is from prototype
                    if (!guidRowObj.hasOwnProperty(key)) continue;
                    rowObj = guidRowObj[key] || {};
                    if (rowObj.venodorCostCode.contCostCode == contCostCode) {
                        dupCostCode.push(rowObj);
                        break;
                    }
                }
            }

            if(!dupCostCode.length) {
                checkContCostCodeInDB(contCostCode);
            }

            if(dupCostCode.length) {
                Notification.error({
                    title: 'Duplicate Entry Found.',
                    message: 'Duplicate Vendor Cost Code found. Please enter different Vendor Cost Code..!'
                });
                $scope.modelData.venodorCostCode.contCostCode = '';
            }
        };

        // set Default Range
        var setDefaultRange = function() {
            if(!$scope.oriMsgCustomFields.Tabbed_Paging.Pages.length || !$scope.oriMsgCustomFields.Tabbed_Paging.Pages[0].Page_Range) {
                $scope.oriMsgCustomFields.Page_Sel = '0-0';            
                $scope.oriMsgCustomFields.Tabbed_Paging.Pages = [{
                    Page_Range : '0-0'
                }];
            }
        };

		$scope.setCurrentSection = function (tabURL) {
            if($scope.currentOriTab == tabURL) {
                return false;
            };

            if($scope.isImported && isOriView && tabURL == 'vendor-cost-code.html') {
                return false
            }

			$scope.currentOriTab = tabURL;				
			$timeout(function () {
                $scope.expandTextAreaOnLoad();
                if(tabURL == 'vendor-cost-code.html' && !$scope.isXHRon) {
                    if(!$scope.isImported || isOriPrintView ) {
                        setDefaultRange();
                        $scope.vendorStwCostCodeMapping.mappingList = [];
                        // set Onload Data.
                        $scope.filterTrackerLog(event, false, true);
                    } 
                }
			}, 10);
		};

        $scope.applyFilterCall = function (event) {
            if(event.which != 13) {
                return false;
            }
            $scope.filterTrackerLog(event, false, false);
        };

        $scope.setEccPscSelectedFlag = function() {
            $scope.isEccLotSelected = $scope.vendorDetails.eccLotDetail.lot1 || $scope.vendorDetails.eccLotDetail.lot2 || $scope.vendorDetails.eccLotDetail.lot3 || $scope.vendorDetails.eccLotDetail.lot4 || $scope.vendorDetails.eccLotDetail.lot1ThirdParty || $scope.vendorDetails.eccLotDetail.lot2ThirdParty; 

            $scope.isPscLotSelected = $scope.vendorDetails.pscLotDetail.lot1PanProgramme || $scope.vendorDetails.pscLotDetail.lot2WaterTreatment ||$scope.vendorDetails.pscLotDetail.lot3WasteTreatment || $scope.vendorDetails.pscLotDetail.lot4WaterInfra || $scope.vendorDetails.pscLotDetail.lot5WasteInfra ||$scope.vendorDetails.pscLotDetail.lot6ICA;

            $scope.isAnyLotSelected = $scope.isEccLotSelected || $scope.isPscLotSelected;
        };

        $scope.setSideBar = function(){
            $scope.isSideBarOpen = !$scope.isSideBarOpen;
        };

        var validateSingleOrgForm = function(checkValue, isWhileSubmit, callBackFun) {              
            var dataSourceInc = "DS_ASI_STD_ECC4_STW_DUPLICATE_ORG_CHECK",
                form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": checkValue
                    }]
                }
            };

            $scope.isXHRon = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;
                if (resData) {
                    ds_Asi_Std_ecc4_STW_DUPLICATE_ORG_CHECK = angular.fromJson(response.data[dataSourceInc]).Items.Item;
                    var isvalidVendorname = ds_Asi_Std_ecc4_STW_DUPLICATE_ORG_CHECK[0].Value1.toLowerCase().trim();
                    var isvalidVendorno = ds_Asi_Std_ecc4_STW_DUPLICATE_ORG_CHECK[0].Value2.toLowerCase().trim();

                    if( isvalidVendorname == 'y') {
                        Notification.error({
                            title: 'Same Organisation.',
                            message: 'Form for the Same Organisation has already been created, please check it.!'
                        });
                        // reseting the org selection field.
                        $scope.vendorDetails.vendorName = '';
                        $scope.vendorsList = structureItemList('vendor-name', $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID')); 
                    } else if(isvalidVendorno == 'y') {
                        Notification.error({
                            title: 'Same Vendor No.',
                            message: 'Form for the Same Vendor No has already been created, please check it.!'
                        });
                    } else {
                        isWhileSubmit && callBackFun && callBackFun();
                    }
                    // highlight invaid vendornos.
                    highlightandSubmitVendorNos(ds_Asi_Std_ecc4_STW_DUPLICATE_ORG_CHECK[0].Value3,'ValidationCheck');                    
                }
            }, function (error) {
                $scope.isXHRon = false;                
                var errorMsg = 'Error retriving DocumentData<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
            });
        };
       
        
        /**
         *   this function checks duplicate validation for STW and HD code with Single Vendor ORG.
         *
         * */
        $scope.duplicateValidationChecks = function(value, validationFor, callBackFun,strindex,currObj) { 
            
            //first check duplicate within form or not
            if(strindex != '')
            {
            $timeout(function () {
                var rowIndex = strindex;
                var index = "";
                        if (rowIndex > -1)
                            index = rowIndex;
                        else
                            index = $scope.vendorDetails.VendorNoDetails.VendorNos.length - 1;
                        
                            var boolDuplicateFlag =  $scope.checkDuplicateValue({
                            key: 'VendorNo',
                            model: currObj,
                            index: index,
                            repetObj: $scope.vendorDetails.VendorNoDetails.VendorNos,
                            msg: 'Vendor Number'
                        });
                    })
                }
                //check that is it not duplicate accross all Vendor cost code forms
                var vendorId = (validationFor == 'vendor-name') ? (value.modelValue || '').split('#')[0] : ($scope.vendorDetails.vendorName || '').split('#')[0];
                var strVendorNos = $scope.vendorDetails['VendorNoDetails']['VendorNos'];
                var strVendorNoparam ='';
                if(strVendorNos && strVendorNos.length)
                {
                    for(var i=0;i<strVendorNos.length;i++)
                    {
                        var strconcate = strVendorNos[i]['ContractCompany'] + '$$' + strVendorNos[i]['VendorNo'];
                        strVendorNoparam = strconcate + '|' + strVendorNoparam;
                    }
                }
                var checkValue = vendorId + '@@' + strVendorNoparam;
                validateSingleOrgForm(checkValue, (validationFor == 'all'), callBackFun);
        };

        var structureItemList = function (setFor, availList) {
			var tempList = [],
				optlabel = '';
			if (setFor == 'vendor-name') {
                angular.forEach(availList, function (item) {
                    tempList.push({
                        displayValue: item.Name,							
                        modelValue: item.Value
                    });
                });
                optlabel = 'Vendor Organisations';
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
        };

        $scope.currentOriTab = 'vendor-details.html';
        if(!$scope.isImported) {
            $scope.vendorStwCostCodeMapping.mappingList = [];
        }

        resetFilterFields();
        if (isOriView) {
            $scope.getServerTime(function (serverDate) {
                $scope.strTime = new Date(serverDate).getTime();
                $scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
            });
            if($scope.isImported) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = '0';
                if (!$scope.vendorStwCostCodeMapping) {
                    Notification.error({
                        title: 'Import sheet validation',
                        message: 'May be you missed to prepare data before import. Please do proper procedure to prepare import data.!'
                    });
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    return false;
                }
                var newAddedRecords = $scope.vendorStwCostCodeMapping.mappingList.filter(function(stwObj) {
                    return !stwObj.mappingGuid;
                }) || [];
                dataCached.importedSheet = angular.copy($scope.vendorStwCostCodeMapping.mappingList);
                if(newAddedRecords.length) {
                    getGUIdOnCallBack(newAddedRecords.length, function (guidResp) {
                        // validation for the latest Expoert sheet imported or not.
                        checkForLatestImportKey(guidResp);
                    });
                } else {
                    // validation for the latest Expoert sheet imported or not.
                    checkForLatestImportKey([]);
                }
                fillContractCompany();
            }
            $scope.vendorsList = structureItemList('vendor-name', $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID')); 
            $scope.setEccPscSelectedFlag();                            
            $scope.vendorDetails.loggedInUser = $scope.getValueOfOnLoadData('DS_LOGGEDIN_USERID')[0].Value;
            $scope.vendorDetails.workingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value;
        } else if (isOriPrintView) {
            $scope.isSideBarOpen = false;
        }
        
        var lotStrNodeMap = {
            eccLotDetail : 'selectedEccLotStr',
            pscLotDetail : 'selectedPscLotStr'
        };

        var setEccPscNodeStringNode = function () {            
            var lotKey = ['eccLotDetail','pscLotDetail'],
                selctedNode = [];
            for (var i=0; i<lotKey.length; i++) {
                selctedNode = [];
                for (var key in $scope.vendorDetails[lotKey[i]]) {
                    if($scope.vendorDetails[lotKey[i]][key]){
                        selctedNode.push(key);
                    }
                } 
                // set string in node  
                $scope.vendorDetails[lotStrNodeMap[lotKey[i]]] = selctedNode.join();                
            }
        },  setUpdatedDataNodes = function () {
            var rowObj = {};
            // reset the update nodes first.
            $scope.updateStwCostCodeGroup.updatedMappingList = [];
            for (var key in guidRowObj) {
                // skip loop if the property is from prototype
                if (!guidRowObj.hasOwnProperty(key)) continue;
                rowObj = guidRowObj[key] || {};
                if (!angular.equals({}, rowObj)) {
                    $scope.updateStwCostCodeGroup.updatedMappingList.push({
                        updatedMappingGuid : rowObj.mappingGuid,
                        isUpdatedMappingSelected : rowObj.isMappingSelected,
                        isUpdatedMappingShow: rowObj.isMappingShow,
                        isUpdatedMappingDisable: rowObj.isMappingDisable,
                        updatedMappingDisable : rowObj.mappingDisable,
                        updatedVenodorCostCode : {
                            updatedContCostCode : rowObj.venodorCostCode.contCostCode,
                            updatedContCostCodeDesc: rowObj.venodorCostCode.contCostCodeDesc
                        },
                        updatedStwCostCodeObj : {
                            updatedStwCostCode : rowObj.stwCostCodeObj.stwCostCode,
                            updatedStwCostCodeDesc : rowObj.stwCostCodeObj.stwCostCodeDesc,
                            updatedStwCostCodeUom : rowObj.stwCostCodeObj.stwCostCodeUom
                        }
                    });
                }
            }
        },  setFinalData = function (isCallSubmitForm) {
            var splittedVendorDetails = $scope.vendorDetails.vendorName.split('#');
            // set Organization Id in Form Content 1.
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = splittedVendorDetails[0].trim();
            $scope.oriMsgCustomFields.ORI_FORMTITLE = splittedVendorDetails[1].trim();
            $scope.oriMsgCustomFields.ORI_USERREF = $scope.oriMsgCustomFields.ORI_USERREF || 'V0.0';
            setEccPscNodeStringNode();
            setUpdatedDataNodes();

            // set nodes to true for the 
            for(var i=0;i<$scope.vendorStwCostCodeMapping.mappingList.length; i++) {
                $scope.vendorStwCostCodeMapping.mappingList[i].isNodeDbEntryDone = true;
            }

            // To identify Import Process Done in Edit Ori.
            if($scope.isImported) {
                // set Completed Node value in isImported once Import is over.
                $scope.oriMsgCustomFields.isImported = 'Completed';
                $scope.isImported = false;
            }

            //set submitted flag true if Vendor No is already added so for next time it will display as read only
            highlightandSubmitVendorNos('setSubmitted','final');

            if(isCallSubmitForm) {
                submitFlag = true;
                $window.submitForm(1);
            }
        };
        function highlightandSubmitVendorNos(invalidlst,strcalltype)
        {
            $scope.isVenNoMandatory = false;
            //verify Vendor name , Vendor Nos and Lot Nos are inserted or not
            var strVendorNos = $scope.vendorDetails['VendorNoDetails']['VendorNos'];
            if(strVendorNos && strVendorNos.length)
            {
                for(var i=0;i<strVendorNos.length;i++)
                {
                    if(strcalltype == 'final' && strVendorNos[i]['VendorNo'] != '' && strVendorNos[i]['VendorNo'] != null)
                    {
                        strVendorNos[i]['isSubmitted'] = 'Yes';
                    }
                    else
                    {
                        var strconcate = strVendorNos[i]['ContractCompany'] + '$$' + strVendorNos[i]['VendorNo'];
                        strVendorNos[i]['isValidVendor'] = "Yes";
                        if(invalidlst.indexOf(strconcate) > -1)
                        {
                            strVendorNos[i]['isValidVendor'] = "No";
                            
                        }
                        if(strVendorNos[i]['VendorNo'])
                        {
                            $scope.isVenNoMandatory = true;
                        }
                    }
                }
            }
        }
        function fillContractCompany()
        {
            //add all contract company default on load and if already added then skip that node entry
            var strformid = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
            var strisdraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
            var strContractCompany = ds_Asi_Std_ecc4_STW_GET_VENDORNOS;
            $scope.vendorDetails.VendorNoDetails.VendorNos = [];
            if(strContractCompany && strContractCompany.length)
            {
                for(var i=0;i<strContractCompany.length;i++)
                {
                    var objvendor = angular.copy(STATIC_OBJ_DATA.VendorNos );
                   
                    objvendor.ContractCompany = strContractCompany[i].Value2.trim();
                    objvendor.VendorNo = strContractCompany[i].Value3.trim();
                    objvendor.isSubmitted = strContractCompany[i].Value4.trim();
                    objvendor.isValidVendor = "Yes";
                    if(strContractCompany[i].Value3.trim() != '')
                    {
                        $scope.isVenNoMandatory = true;
                    }
                   
                    $scope.vendorDetails.VendorNoDetails.VendorNos.push(objvendor);
                }
            }
        }
        function verifyVendorNos()
        {
            //verify Vendor Nos 
            var strvendordetails = $scope.vendorDetails['VendorNoDetails']['VendorNos'];
            if(strvendordetails && strvendordetails.length)
            {
                for(var i=0;i<strvendordetails.length;i++)
                {
                    if(strvendordetails[i]['VendorNo'] != '')
                    {
                        return true;
                    }
                }
            }
            return false;
        }

       
       
        $window.costCodeSubmit = function () {
            if (submitFlag) {
				return false;				
            }
            //verify Vendor name , Vendor Nos and Lot Nos are inserted or not
            var isVendorNovalid = verifyVendorNos();
            if(!$scope.vendorDetails.vendorName || !isVendorNovalid || !$scope.isAnyLotSelected) {
                Notification.error({
                    title: 'Validation Error',
                    message: 'Please Fill out Vendor Details to move further..!'
                });   
                return true;            
            }
            
            //validate duplicate Vendor nos or Vendor name with previous Vendor form
            $scope.duplicateValidationChecks({modelValue : $scope.vendorDetails.vendorName}, 'all', function() {
                setFinalData(true);
            },'','');

            

            // if (!$scope.isEditOri) {
            //     $scope.duplicateValidationChecks({modelValue : $scope.vendorDetails.vendorName}, 'all', function() {
            //         setFinalData(true);
            //     });
            // } else {
            //     setFinalData(false);
            //     return false;
            // }

            return true;
        };

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof costCodeSubmit !== "undefined") {
        return costCodeSubmit();
    }
}