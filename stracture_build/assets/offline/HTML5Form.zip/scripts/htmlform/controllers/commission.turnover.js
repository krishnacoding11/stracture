define(['angular', './base'], function (angular, baseController) {
    'use strict';

    /*
    * @constructor
    * @alias module:Form-Controller/FormController
    */
    function FormController($scope, $element,$filter, $document, commonApi, $controller, $window, $timeout,Notification) {
        
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var currentViewName = window.currentViewName;
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.commissioningGrp = $scope.formCustomFields["Commissioning_Details"];
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.workingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var projUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        $scope.checklistCount = $scope.getValueOfOnLoadData('DS_NNG_COMM_Get_CheckListCount');
        var incompleteActData=$scope.getValueOfOnLoadData('DS_CHILDFORMWITHINCOMPLETEACTION');
        var formStatus =$scope.asiteSystemDataReadOnly['_5_Form_Data']["Status_Data"]["DS_ALL_FORMSTATUS"];
        formStatus=formStatus&&formStatus.split('#')[1].trim();
        var pmCanreply=false;

        $scope.isEditORI = ($scope.strFormId != '' && $scope.strIsDraft == 'NO');
        $scope.cmtDisplay = false;
        $scope.allAprroved=false;
        $scope.objSelection=false;
        $scope.dispDiv = false;
        $scope.disablOP=false;
        $scope.disablCC=false; 
        $scope.disablDC=false;
        $scope.disablIns=false;
        $scope.disablPeng=false;
       

        $scope.toolTipmsg='Please select one of these options.'
        $scope.isEditORI = ($scope.strFormId != '' && $scope.strIsDraft == 'NO');
        $scope.ACF_02_FORM = {
            ACF_02_DSI_state: "",
            ACF_02_DSI_region: "",
            ACF_02_DSI_projectteam: "",
            ACF_02_ORI_FORMTITLE: "",
            ACF_02_DS_FORMTITLE: "",
            ACF_02_DSI_RFSDate: "",
            ACF_02_CREATED_BY: "",
            ACF_02_commissioningActivity: "",
            ACF_02_projectManager: "",
            ACF_02_operationsManager: "",
            ACF_02_constructionCoordinator: "",
            ACF_02_operationsTeam: "",
            ACF_02_leadInspector: "",
            ACF_02_projectEngineer: "",
            ACF_02_divisionEnvironmental: "",
            ACF_02_rightWayAgent: "",
            ACF_02_documentationSpecialist: "",
            ACF_02_DS_FORMCONTENT1: "<<DS_Form_ID>>",
            ACF_02_DS_Ref_AppId: "",
            ACF_02_REPEATING_VALUES: {
                ACF_02_DS_AutoDistribute_User_Group: {
                    ACF_02_DS_AutoDistribute_Users: [{
                        ACF_02_DS_PROJDISTUSERS: "",
                        ACF_02_DS_FORMACTIONS: "",
                        ACF_02_DS_ACTIONDUEDATE: ""

                    }]
                }
            }
        }
        $scope.ACF_01_FORM = {
            ACF_01_DSI_state: "",
            ACF_01_DSI_region: "",
            ACF_01_DSI_projectteam: "",
            ACF_01_ORI_FORMTITLE: "",
            ACF_01_DS_FORMTITLE: "",
            ACF_01_DSI_RFSDate: "",
            ACF_01_CREATED_BY: "",
            ACF_01_commissioningActivity: "",
            ACF_01_projectManager: "",
            ACF_01_operationsManager: "",
            ACF_01_constructionCoordinator: "",
            ACF_01_operationsTeam: "",
            ACF_01_leadInspector: "",
            ACF_01_projectEngineer: "",
            ACF_01_divisionEnvironmental: "",
            ACF_01_rightWayAgent: "",
            ACF_01_documentationSpecialist: "",
            ACF_01_DS_FORMCONTENT1: "<<DS_Form_ID>>",
            ACF_01_DS_Ref_AppId: "",
            ACF_01_REPEATING_VALUES: {
                ACF_01_DS_AutoDistribute_User_Group: {
                    ACF_01_DS_AutoDistribute_Users: [{
                        ACF_01_DS_PROJDISTUSERS: "",
                        ACF_01_DS_FORMACTIONS: "",
                        ACF_01_DS_ACTIONDUEDATE: ""

                    }]
                }
            }
        }

        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.operations_RES = {
            opUser:"",
            resDate:"",
            opComments: "",
            opAcceptObj: "",
            Is_Old: "New"
        }
        $scope.Inspector_RES={
            Inspector:"",
            Ins_resDate:"",
            InsComments:"",
            InsAcceptObj:"",
            Role:"",
            RES_User:"",
            InsIsOld:"New"
        }
        
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;

        });
        if (currentViewName == "ORI_VIEW") {
            $scope.strCanReply = "";

            $scope.projectManager = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Project Manager");
            });
            $scope.operationsManager = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Operations Manager");
            });
    
            $scope.constructionCoordinator = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Construction Coordinator");
            });
            $scope.operationsTeam = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Operations Team Contact");
            });
            $scope.leadInspector = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Inspector");
            });
            $scope.projectEngineer = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Project Engineer");
            });
            $scope.divisionEnvironmental = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Division Environmental Specialist");
            });
            $scope.rightwayAgent = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "ROW Agent");
            });
            $scope.documentationSpecialist = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Documentation Specialist");
            });
        }
        if(currentViewName == "ORI_PRINT_VIEW" ){
            angular.element('.export-btn').hide();
        }
        if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {

            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = commonApi.calculateDistDateFromDays({
                    baseDate: getDateTimeFromZone(),
                    days:7
                });
            if (workingUserAllRole) {
                if (workingUserAllRole[0].Value.toLowerCase().indexOf("project manager") != -1) {
                    $scope.strCanReply = "yes";
                }
                else {
                    $scope.strCanReply = "";
                }
            }

        }
        if (currentViewName == "ORI_VIEW" && $scope.strIsDraft == "NO") {
            if ($scope.oriMsgCustomFields.DSI_Next_Stage == "") {
                $scope.oriMsgCustomFields.DSI_Next_Stage = 1
            }
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == "") {
                $scope.oriMsgCustomFields.DSI_Current_Stage = 1
            }
            else {
                $scope.oriMsgCustomFields.DSI_Current_Stage = $scope.oriMsgCustomFields.DSI_Next_Stage
            }
        }
        function chkApproved() {
            var f1=false;
            var f2 = false;
            var formStatus="";
            for (var i = 0; i < $scope.checklistCount.length; i++) {
                formStatus=$scope.checklistCount[i].Value7.toLowerCase().trim();
                if ($scope.checklistCount[i].Value8.toLowerCase().trim() == 'commissioning checklists') {
                    if(formStatus== 'not required')
                    {f1=true; f2=true; break;}
                    if ($scope.checklistCount[i].Value4 != 0 && $scope.checklistCount[i].Value6 == 0 && (formStatus=='complete'|| formStatus=='closed') ) {
                        f1 = true;
                    }
                }
                if ($scope.checklistCount[i].Value8.toLowerCase().trim() == 'type 1 deficiencies') {
                    if ($scope.checklistCount[i].Value4 != 0 && $scope.checklistCount[i].Value6 == 0 ) {
                        f2 = true;
                    }
                    else if($scope.checklistCount[i].Value4 == 0 || $scope.checklistCount[i].Value4 =="None Found"){
                        f2 = true;
                    }
                }
            }
            if (f1 && f2 && workingUserAllRole[0].Value.toLowerCase().indexOf("project manager") !=-1) {
                $scope.allAprroved = true;
            }
            if($scope.oriMsgCustomFields.DSI_Current_Stage == 4){$scope.allAprroved = true;}
        }
        var disabledUserData = function () {
            if (incompleteActData && incompleteActData.length > 0) {
                for (var i = 0; i < incompleteActData.length; i++) {
                    if ($scope.commissioningGrp.operationsManager_old != "" && incompleteActData[i].Value4 == $scope.commissioningGrp.operationsManager_old.split("#")[0].split('|')[2].trim()) {
                        $scope.disablOP = true;
                    }
                    if ($scope.commissioningGrp.constructionCoordinator_old != "" && incompleteActData[i].Value4 == $scope.commissioningGrp.constructionCoordinator_old.split("#")[0].split('|')[2].trim()) {
                        $scope.disablCC = true;
                    }
                    if ($scope.commissioningGrp.documentationSpecialist_old != "" && incompleteActData[i].Value4 == $scope.commissioningGrp.documentationSpecialist_old.split("#")[0].split('|')[2].trim()) {
                        $scope.disablDC = true;
                    }
                     if ($scope.commissioningGrp.leadInspector_old != "" && incompleteActData[i].Value4 == $scope.commissioningGrp.leadInspector_old.split("#")[0].split('|')[2].trim()) {
                        $scope.disablIns = true;
                    }
                    if ($scope.commissioningGrp.projectEngineer_old != "" && incompleteActData[i].Value4 == $scope.commissioningGrp.projectEngineer_old.split("#")[0].split('|')[2].trim()) {
                        $scope.disablPeng = true;
                    }
                }
            }
        }
       //Adding Inspectore Workflow
       if($scope.isEditORI &&  currentViewName == "ORI_VIEW"  ) {
           $scope.oriMsgCustomFields.Todays_Date = $scope.formatDate(new Date(), 'mm/dd/yy');
           $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = '1';
         if(document.getElementById("DS_ISDRAFT_EDITORI").value == "NO"){
           $scope.commissioningGrp.operationsManager_old=$scope.commissioningGrp.operationsManager;
           $scope.commissioningGrp.constructionCoordinator_old=$scope.commissioningGrp.constructionCoordinator;
           $scope.commissioningGrp.documentationSpecialist_old=$scope.commissioningGrp.documentationSpecialist;
           $scope.commissioningGrp.leadInspector_old=$scope.commissioningGrp.leadInspector;
           $scope.commissioningGrp.projectEngineer_old=$scope.commissioningGrp.projectEngineer;
          }
           disabledUserData();
           chkApproved();
          
            if($scope.oriMsgCustomFields.DSI_Current_Stage >2 ){
            var strRes = commonApi._.filter($scope.commissioningGrp.Inspector_RES, function (val) {
                return  val.InsIsOld && val.InsIsOld.indexOf("New") != -1  
            });
            if(strRes.length==0)
                $scope.commissioningGrp.Inspector_RES.push(angular.copy($scope.Inspector_RES));
            }


            if($scope.oriMsgCustomFields.DSI_Current_Stage ==4 ){
                for (var i = 0; i < $scope.checklistCount.length; i++) {
                    if ($scope.checklistCount[i].Value8.toLowerCase().trim() == 'type 1 deficiencies') {
                        if ($scope.checklistCount[i].Value4 > 0 && $scope.checklistCount[i].Value6 != 0 ) {
                            $scope.objSelection=true;
                            $scope.toolTipmsg='There are pending Checklist/Type 1 Deficiencies items. XTF cannot be accepted for now.';
                            $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length-1].InsAcceptObj='Object';
                        }
                    }
                }
            }
        }
        if ($scope.isEditORI &&  currentViewName == "ORI_VIEW") {
          
            if($scope.oriMsgCustomFields.DSI_Current_Stage == 1 && (formStatus.toLowerCase() =='open' || formStatus.toLowerCase() =='')
             && workingUserAllRole[0].Value.toLowerCase().indexOf("project manager") != -1 && $scope.checklistCount.length>0 )
             {pmCanreply=true;}

            var userid = $scope.workingUserID['0'].Value.split('|')[0].trim();
            var actionData = commonApi._.filter(incompleteAction, function (val) {
                return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(userid) != -1
            });
            if ((actionData && actionData.length) || (pmCanreply)) {
                $scope.strCanReply = "yes";
            }
        }
        if ($scope.oriMsgCustomFields.DSI_Current_Stage == 2 && currentViewName == "ORI_VIEW") {
            var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                return val.Is_Old.indexOf("New") != -1
            });
            if (strRes.length == 0)
                $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));

        }
        if($scope.isEditORI && currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields.DSI_Current_Stage == 1){
            if(formStatus.toLowerCase()=="objection" && $scope.commissioningGrp.operations_RES.length>0 &&
             $scope.commissioningGrp.operations_RES[0].opAcceptObj=='Object'  ){
                $scope.cmtDisplay=true;
                var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                    return val.Is_Old.indexOf("New") != -1
                });
                if (strRes.length == 0)
                    $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));
            }
        }
     
        var projectMasterFormDetails = $scope.getValueOfOnLoadData("DS_NNG_PMF_GET_ProjectMasterForm_Details")[0] || {};
        $scope.commissioningGrp.DSI_workOrderNo = projectMasterFormDetails.Value1 || "";//Work_Order_Number
        $scope.commissioningGrp.DSI_projectName = projectMasterFormDetails.Value3 || "";//Project_Name
        $scope.commissioningGrp.DSI_state = projectMasterFormDetails.Value9 || "";//State
        $scope.commissioningGrp.DSI_region = projectMasterFormDetails.Value8 || "";//Region 
        $scope.commissioningGrp.DSI_projectteam = projectMasterFormDetails.Value52 || "";//Project Team
        $scope.commissioningGrp.DSI_RFSDate = $scope.formatDate(new Date(projectMasterFormDetails.Value24), 'mm/dd/yy') || "";//RFS Date

          function getDateTimeFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }
        function setDistribution(userTodistribute, Days, autoDistNode, actionName) {
            
            if (userTodistribute) {
                var structDistricution = angular.copy($scope.DistributionStructure)
                structDistricution.DS_PROJDISTUSERS = userTodistribute.indexOf('#') > -1 ? userTodistribute.split("#")[0].split("#")[0].split('|')[2].trim() : userTodistribute;
                structDistricution.DS_FORMACTIONS = actionName;
                structDistricution.DS_ACTIONDUEDATE = commonApi.calculateDistDateFromDays({
                    baseDate: getDateTimeFromZone(),
                    days: Days
                })
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistricution);
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = autoDistNode;
            }

        }
        function setAutocreateNodes() {
            var newTaskNode = {};
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
            newTaskNode = angular.copy($scope.ACF_01_FORM);
            newTaskNode.ACF_01_DSI_state = $scope.commissioningGrp.DSI_state;
            newTaskNode.ACF_01_DSI_region = $scope.commissioningGrp.DSI_region;
            newTaskNode.ACF_01_ORI_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_01_DS_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_01_DSI_projectteam = $scope.commissioningGrp.DSI_projectteam;
            newTaskNode.ACF_01_DSI_RFSDate = $scope.commissioningGrp.DSI_RFSDate;
            newTaskNode.ACF_01_CREATED_BY = $scope.workingUserID[0].Value.split('|')[0].trim();
            newTaskNode.ACF_01_commissioningActivity = $scope.commissioningGrp.commissioningActivity;
            newTaskNode.ACF_01_projectManager = $scope.commissioningGrp.projectManager;
            newTaskNode.ACF_01_operationsManager = $scope.commissioningGrp.operationsManager;
            newTaskNode.ACF_01_constructionCoordinator = $scope.commissioningGrp.constructionCoordinator;
            newTaskNode.ACF_01_operationsTeam = $scope.commissioningGrp.operationsTeam;
            newTaskNode.ACF_01_leadInspector = $scope.commissioningGrp.leadInspector;
            newTaskNode.ACF_01_projectEngineer = $scope.commissioningGrp.projectEngineer;
            newTaskNode.ACF_01_DS_FORMCONTENT1 = '<<DS_Form_ID>>';
            newTaskNode.ACF_01_DS_AUTODISTRIBUTE = '';
            newTaskNode.ACF_01_divisionEnvironmental = $scope.commissioningGrp.divisionEnvironmental;
            newTaskNode.ACF_01_rightWayAgent = $scope.commissioningGrp.rightWayAgent;
            newTaskNode.ACF_01_documentationSpecialist = $scope.commissioningGrp.documentationSpecialist;
            newTaskNode.ACF_01_DS_Ref_AppId = $window.AppBuilderFormIDCode;

            // final pushing node.

            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);
            // set Task For another ;
            newTaskNode = angular.copy($scope.ACF_02_FORM);
            newTaskNode.ACF_02_DSI_state = $scope.commissioningGrp.DSI_state;
            newTaskNode.ACF_02_DSI_region = $scope.commissioningGrp.DSI_region;
            newTaskNode.ACF_02_ORI_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_02_DS_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_02_DSI_projectteam = $scope.commissioningGrp.DSI_projectteam;
            newTaskNode.ACF_02_DSI_RFSDate = $scope.commissioningGrp.DSI_RFSDate;
            newTaskNode.ACF_02_CREATED_BY = $scope.workingUserID[0].Value.split('|')[0].trim();
            newTaskNode.ACF_02_commissioningActivity = $scope.commissioningGrp.commissioningActivity;
            newTaskNode.ACF_02_projectManager = $scope.commissioningGrp.projectManager;
            newTaskNode.ACF_02_operationsManager = $scope.commissioningGrp.operationsManager;
            newTaskNode.ACF_02_constructionCoordinator = $scope.commissioningGrp.constructionCoordinator;
            newTaskNode.ACF_02_operationsTeam = $scope.commissioningGrp.operationsTeam;
            newTaskNode.ACF_02_leadInspector = $scope.commissioningGrp.leadInspector;
            newTaskNode.ACF_02_projectEngineer = $scope.commissioningGrp.projectEngineer;
            newTaskNode.ACF_02_DS_FORMCONTENT1 = '<<DS_Form_ID>>';
            newTaskNode.ACF_02_DS_AUTODISTRIBUTE = '';
            newTaskNode.ACF_02_divisionEnvironmental = $scope.commissioningGrp.divisionEnvironmental;
            newTaskNode.ACF_02_rightWayAgent = $scope.commissioningGrp.rightWayAgent;
            newTaskNode.ACF_02_documentationSpecialist = $scope.commissioningGrp.documentationSpecialist;
            newTaskNode.ACF_02_DS_Ref_AppId = $window.AppBuilderFormIDCode;
           
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_02_FORM = [];
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_02_FORM.push(newTaskNode);

        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (allformStatus && allformStatus.length > 0) {
                var statudObj = commonApi._.filter(allformStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        $scope.clearData = function () {
            
            if($scope.commissioningGrp.isCommissionreq=='Yes'){
                if($scope.cmtDisplay==true)
                {
                    var operationsRES = $scope.commissioningGrp['operations_RES'];
                    operationsRES[operationsRES.length - 1].opComments='';
                }
                else
                    $scope.commissioningGrp.pmComments="";
            }
            
            
        }
        $scope.showDiv = function () {
            if($scope.dispDiv)
                $scope.dispDiv =false;
            else
                $scope.dispDiv=true;
        }
      
        function setStatus(statusname) {
            var strFormStatusId = getFormStatusId(statusname);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }
        $scope.update();
        $window.oriformSubmitCallBack = function () {
            var strMsg=""
            if (!$scope.strCanReply) {
                alert("You are not authorized to edit the form. Please contact your Administrator");
                return true;
            }
            if($scope.isEditORI){
                if($scope.commissioningGrp.operationsManager_old!="" &&$scope.commissioningGrp.operationsManager=="" ){
                    if(strMsg=='') {strMsg='Operations Manager'; } 
                }
                if($scope.commissioningGrp.constructionCoordinator_old!="" &&$scope.commissioningGrp.constructionCoordinator=="" ){
                    if(strMsg=='') {strMsg='Construction Coordinator'; }
                    else{ strMsg=strMsg + ', Construction Coordinator'}  
                }
                if($scope.commissioningGrp.documentationSpecialist_old!="" &&$scope.commissioningGrp.documentationSpecialist=="" ){
                    if(strMsg=='') {strMsg='Documentation Specialist' }
                    else{ strMsg=strMsg + ', Documentation Specialist'}
                }
            }
            if (strMsg !="") {
                Notification.error({ title: 'Alert', message: strMsg + ' must be assigned.' });
                return true;
            }
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";

            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 1 && $scope.allAprroved==false) {
                $scope.oriMsgCustomFields.DSI_orignatorID = $scope.workingUserID[0].Value.split('|')[0].trim();
                if ($scope.commissioningGrp.isCommissionreq == 'No') {
                    $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                    setDistribution($scope.commissioningGrp.operationsManager, 7, 3, "2#")
                    setStatus("Send For Approval");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = parseInt($scope.oriMsgCustomFields.DSI_Current_Stage) + 1;
                    if($scope.cmtDisplay==true){
                        var operationsRES = $scope.commissioningGrp['operations_RES'];
                        for (var i = 0; i < operationsRES.length; i++) {
                            if (operationsRES[operationsRES.length - 1].Is_Old == "New") {
                                operationsRES[operationsRES.length - 1].opUser = $scope.workingUserID[0].Value;
                                operationsRES[operationsRES.length - 1].resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                                operationsRES[operationsRES.length - 1].Is_Old = "Old";
                            }
                        }
                    }
                }
                else if(pmCanreply==false){
                    setAutocreateNodes();
                    setStatus("Open");
                }
            }
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 2) {
                var operationsRES = $scope.commissioningGrp['operations_RES'];
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
                for (var i = 0; i < operationsRES.length; i++) {
                    if (operationsRES[operationsRES.length - 1].Is_Old == "New") {
                        operationsRES[operationsRES.length - 1].opUser = $scope.workingUserID[0].Value;
                        operationsRES[operationsRES.length - 1].resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                        operationsRES[operationsRES.length - 1].Is_Old = "Old";
                    }
                }
                if ($scope.commissioningGrp.operations_RES[operationsRES.length - 1].opAcceptObj == 'Accept') {
                    setStatus("Not required")
                } else if ($scope.commissioningGrp.operations_RES[operationsRES.length - 1].opAcceptObj == 'Object') {
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                    setDistribution($scope.oriMsgCustomFields.DSI_orignatorID, 7, 3, "2#")
                    setStatus("Objection")
                }
            }

            var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
            if (($scope.oriMsgCustomFields.DSI_Current_Stage == 1 || $scope.oriMsgCustomFields.DSI_Current_Stage == 3) 
            && $scope.allAprroved==true && inspectorRES[inspectorRES.length-1].InsAcceptObj=='Submitted') {
                if ($scope.commissioningGrp.operationsManager=='') {
                    alert("This step cannot be completed if there is no user assigned as Operations Manager.");
                    return true;
                }
                
                  for (var i = 0; i < inspectorRES.length; i++) {
                    if (inspectorRES[i].InsIsOld == "New") {
                        inspectorRES[i].Inspector=$scope.workingUserID[0].Value;
                        inspectorRES[i].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
                        inspectorRES[i].InsIsOld = "Old";
                        inspectorRES[i].Role = "Project Manager";
                    }
                  }
                setDistribution($scope.commissioningGrp.operationsManager, 7, 3, "2#");
                setStatus("Submitted");
                $scope.oriMsgCustomFields.DSI_Next_Stage = 4;
            }
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 4)
            {
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
                inspectorRES[inspectorRES.length-1].RES_User=$scope.workingUserID[0].Value;
                inspectorRES[inspectorRES.length-1].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
                inspectorRES[inspectorRES.length-1].InsIsOld = "Old";
                inspectorRES[inspectorRES.length-1].Role = "Operations Manager";
                if (inspectorRES[inspectorRES.length-1].InsAcceptObj == 'Accept') {
                    setStatus("Complete");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = parseInt($scope.oriMsgCustomFields.DSI_Current_Stage) + 1;
                    setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "7#");
                    setDistribution($scope.commissioningGrp.leadInspector, 7, 3, "7#");
                    setDistribution($scope.commissioningGrp.projectEngineer, 7, 3, "7#");
                    setDistribution($scope.commissioningGrp.documentationSpecialist, 7, 3, "7#");
               } else{
                       setStatus("Objection");
                       setDistribution(inspectorRES[0].Inspector.split('|')[0].trim(), 7, 3, "2#");
                       $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
                 }
            }
            return false;
        };
    }

    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}