/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {	
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if(!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') && 
			!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if(!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') && 
			!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function(taRegisterTool, taOptions) {
			taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'clear','ul','ol'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull','indent', 'outdent'],
                []
            ];
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
					setTimeout(function() {
						me.action(color)
					}, 100)
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
			taRegisterTool("fontColor", {
				display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("foreColor", color)
					}
					setTimeout(function() {
						me.action(color)
					}, 100)
				},
				options: {
					replacerClassName: "fa fa-font",
					showButtons: !1,
                    showAlpha : !1
				},
				color: "#000"
			}),
			taRegisterTool('fontName', {
				display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>"+"</button>",
				action: function (event, font) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
					this.$element.toggleClass('open-fonts-list');
					return this.$editor().wrapSelection('fontName', font);
				},	
				disabled: function() {},			
				options: [
					{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
					{ name: 'Serif', css: "'times new roman', serif" },
					{ name: 'Wide', css: "'arial black', sans-serif" },
					{ name: 'Narrow', css: "'arial narrow', sans-serif" },
					{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
					{ name: 'Courier New', css: "'courier new', monospace" },
					{ name: 'Garamond', css: 'garamond, serif' },
					{ name: 'Georgia', css: 'georgia, serif' },
					{ name: 'Tahoma', css: 'tahoma, sans-serif' },
					{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
					{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
					{ name: 'Verdana', css: 'verdana, sans-serif' },
					{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
				]
			}),
			taRegisterTool('fontSize', {
				display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",				
				action: function (event, size) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-list').removeClass('open-fonts-list');
					this.$element.toggleClass('open-fonts-size-list');					
					return this.$editor().wrapSelection('fontSize', parseInt(size));					
				},			                
				disabled: function() {},
				options: [
					{ name: 'xx-small', css: 'xx-small', value: 1 },
					{ name: 'x-small', css: 'x-small', value: 2 },
					{ name: 'small', css: 'small', value: 3 },
					{ name: 'medium', css: 'medium', value: 4 },
					{ name: 'large', css: 'large', value: 5 },
					{ name: 'x-large', css: 'x-large', value: 6 },
					{ name: 'xx-large', css: 'xx-large', value: 7 }

				]
			}),
			taOptions.toolbar[1].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'),taOptions;
			
		}
		]);
		$provide.decorator("taToolFunctions", ["$delegate", function($delegate) {
				var imgOnSelectActionFn = $delegate.imgOnSelectAction;
				return $delegate.imgOnSelectAction = function(event, $element, editorScope) {
					imgOnSelectActionFn(event, $element, editorScope),
					editorScope.displayElements.popover.css("width", "auto"),
					editorScope.displayElements.popover.find(".btn-group").eq(1).remove()
				},$delegate;
			}
		])
		
	};
	toolbar:["formatStyle"];
	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
    });
	

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */

	function FormController($scope, $element, $document, commonApi,$filter, $controller, $window, $timeout, Notification) {
		var ctrl = this;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;
		// restrict autosave Draft and hide Save Draft button.
		var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
		$saveDraftBtn && ($saveDraftBtn.style.display = 'none');
		
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
			angular.element('.export-btn').hide();
		}
		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
		var dSDraftRESMsg = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.commUserRolesList = $scope.oriMsgCustomFields.commUserRolesList;
		$scope.commReferenceClauses = $scope.oriMsgCustomFields.commReferenceClauses;
		$scope.commExternalReference = $scope.oriMsgCustomFields.commExternalReference;
		$scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
		var mtaHeaderDetails = $scope.getValueOfOnLoadData('DS_MTA_PSR_Header_Details')[0];
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var dsWorkingUser = $scope.Asite_System_Data_Read_Only._1_User_Data.DS_WORKINGUSER;
		var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		var dsFilterUserDetails = $scope.getValueOfOnLoadData('DS_USERDETAILS_FILTERED');
		var currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		
		$scope.tempToRoleList = [];
		$scope.tempCopyToRoleList = [];
		$scope.tempToUsersList = [];
		$scope.tempCopyToUsersList = [];
		$scope.allRespMsgList = [];
		$scope.isOriView = (currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (currentViewName == 'RES_VIEW');
		$scope.isRespPrintView = (currentViewName == 'RES_PRINT_VIEW');
		$scope.xhr = {
			guIdXhr: false,
			platformXhr: false
		};
		var STATIC_OBJ_DATA = {
			All_Responses: {
				"DSI_ResID": "",
				"Response_Remarks": "",
				"Response_Creator": "",
				"Response_Date": "",
				"DSI_ResFlag": ""
			}
		}
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			selectedRoles = {
				toList: [],
				copyToList: []
			}, fieldNameKeyMap = {
				'to-role': 'toList',
				'copy-to-role': 'copyToList'
			}, listNameKeyMap = {
				'to-role': 'toRole',
				'copy-to-role': 'copyToRole',
			}, userListKeyMap = {
				'to-role': 'toUsersStr',
				'copy-to-role': 'copyToUsersStr',
			}, tempListKeyMap = {
				'to-role': 'tempToUsersList',
				'copy-to-role': 'tempCopyToUsersList'
			}, tempRolesListKeyMap = {
				'to-role': 'tempToRoleList',
				'copy-to-role': 'tempCopyToRoleList'
			}, strKeyRevMap = {
				'to-role-users': 'to-role',
				'copy-to-role-users': 'copy-to-role'
			};
			var setPsrProjectDetails = function () {
				$scope.projectDetails.Planning_Number = mtaHeaderDetails.Value2;
				$scope.projectDetails.ProgramManager = mtaHeaderDetails.Value3;
				$scope.projectDetails.ProjectPSE = mtaHeaderDetails.Value4;
				$scope.projectDetails.ProjectDescr = mtaHeaderDetails.Value5;
				$scope.projectDetails.KeyProject = mtaHeaderDetails.Value6;
				$scope.projectDetails.ConstructionMgr = mtaHeaderDetails.Value7;
				$scope.projectDetails.ProjectStatus = mtaHeaderDetails.Value8;
				$scope.projectDetails.ProjectPhase = mtaHeaderDetails.Value9;
				$scope.projectDetails.ProgramOfficer = mtaHeaderDetails.Value10;
			};

		$scope.serverDate = "";
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.userFormatedDate = "";
		$scope.userDateFormat = userDateFormat,
			$scope.getServerTime(function (serverDate) {
				$scope.serverDate = serverDate;
				$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
				$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
				$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), 'mm/dd/yy');
			});
		
		// to get Custom Attribute On Load.
	
		var	allRoleUsersList = [],
			allUsersList = [],
			allRolesList = [],
			formActionDays = {},
			strRespondDays = '';

		var modelRowIndex = -1;
		$scope.openModal = function (modalId, rowData) {
			modelRowIndex = -1;
			ctrl.model.readOnly = true;
            showModal(modalId);
		} 
		ctrl.model = {
            modelId: "",
            update: false,
            hideModal: hideModal,
            showloader: false,
            readOnly: false
        };
        function showModal(id) {
            // show modal
            ctrl.model.modelId = id;

            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4')
                modalHeader.addClass('primary-header-bg white-font')
            }, 200);
		};
		function hideModal() {
            ctrl.model.modelId = '';
        }

		if (currentViewName == "RES_VIEW") {
			
			if (dSDraftRESMsg == "NO") {
				var strResCount = $scope.resMsgCustomFields.DSI_Res_Counter,
					insertPoint = $scope.resMsgCustomFields.RESPONSES.All_Responses;

				if (insertPoint.length) {
					for (var i = 0; i < insertPoint.length; i++) {
						if (insertPoint[i].Response_Remarks) {
							insertPoint[i].DSI_ResFlag = "Old";
						}
					}
				}

				strResCount++;
				var resNodes = angular.copy(STATIC_OBJ_DATA.All_Responses);
				resNodes.DSI_ResID = strResCount;
				resNodes.Response_Creator = dsWorkingUser;
				resNodes.Response_Date = $scope.formatDate(new Date(getDateTimeFromZone()), 'yy-mm-dd');
				insertPoint.push(resNodes);
				
			} else {
				var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
					return val.DSI_ResFlag != "Old";
				});
				if (responseObj.length) {
					responseObj[0].Response_Creator = dsWorkingUser;
				}
			}

		}
		/**All Common functions will be start from here */
		// Value22 contains selected actions and it's days from the form Setting
		var setFormSettingActionDays = function (formsSettings) {
			var allActions = formsSettings.Value22.split(':')[1],
				actionsList = allActions.split(','),
				actionSplited = '';
			for (var i = 0; i < actionsList.length; i++) {
				actionSplited = actionsList[i].split('|');
				formActionDays[actionSplited[0]] = actionSplited[1];
			}
			// default value for Respond action set 3 as per decision.
			strRespondDays = formActionDays['Respond'] || 3;
		};
		function getDateTimeFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }
		
		 /**
         * Set ConfigurableAttriburte Type Value in Location dropdown.
         */
        function getConfigurableAttriburteByType(type) {
            var location = [];
            if (type) {
                location = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return location;
		}
		
		//N
		if (currentViewName == "ORI_VIEW") {
			$scope.oriMsgCustomFields.DSI_Sig_UserName = dsFilterUserDetails[0].Value2.split(',')[0]
			$scope.oriMsgCustomFields.DSI_Sig_Organisation = dsFilterUserDetails[0].Value3
			$scope.oriMsgCustomFields.DSI_Sig_Phone = dsFilterUserDetails[0].Value5
			$scope.oriMsgCustomFields.DSI_Sig_Email = dsFilterUserDetails[0].Value6
			$scope.oriMsgCustomFields.DSI_Sig_JobTitle = dsFilterUserDetails[0].Name

			var dicipline = [];
			var projectCode = commonApi._.findWhere(dsAsiConfigurableAttributes, {
				Value3: "Project Code",
				Value11: "Active"
			}) || {};
			projectCode = projectCode && projectCode.Value7;
			$scope.locationAttrList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Location Attribute"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
			var getAllOrgDetails = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
			var objCurrentOrg = commonApi._.findWhere(getAllOrgDetails, {
				Value3: $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Name.split(',')[1].trim()
			}) || {};
			if (objCurrentOrg.Value4) {
				$scope.oriMsgCustomFields.DS_Logo = objCurrentOrg.Value4;
			}
			for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
				var element = dsAsiConfigurableAttributes[index];

				if (element.Value3 === "FDiscipline" && element.Value11 === "Active") {
					dicipline.push(element);
				}
			}
			$scope.Dicipline = dicipline;
		}
		//End N
		
		var getSetSPValues = function () {
			allRoleUsersList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			allUsersList = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
			allRolesList = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES');
			setFormSettingActionDays($scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails')[0]);
		};

	    var structureItemList = function (setFor, availList) {
			var tempList = [],
				optlabel = '';
			switch (setFor) {
				case 'role-list':
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value
						});
					});
					optlabel = 'Roles list';
					break;
				case 'user-list':
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value
						});
					});
					optlabel = 'Users list';
					break;
			}

			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};

		var updateRolesList = function (forField, index) {
			// Prepare list and bind it for html template
			$scope[tempRolesListKeyMap[forField]][index] = structureItemList('role-list', allRolesList);
		};


		var setUsersOnRoleSelection = function (forField, index, roleName) {
			if (roleName) {
				roleName = roleName.split('#')[0].trim();
				$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allRoleUsersList.filter(function (userRoleObj) {
					return userRoleObj.Value.indexOf(roleName) > -1
				}));
			} else {
				if (forField == 'to-role') {
					$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allUsersList);
				}
				else {
					$scope[tempListKeyMap[forField]][index] = [];
				}
			}
			updateRolesList(forField, index);
		};

		var checkAndSetSelectedRoleExist = function (forField, index, roleName) {
			var currList = selectedRoles[fieldNameKeyMap[forField]],
				currIndex = currList.indexOf(roleName);
			if (roleName && currList.length && currIndex != index && currIndex > -1) {
				Notification.warning({
					title: "Role is already selected",
					message: "Please select different role."
				});
				roleName = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][userListKeyMap[forField]] = '';
				$scope[tempListKeyMap[forField]][index] = [];
			}
			selectedRoles[fieldNameKeyMap[forField]][index] = roleName;
			setUsersOnRoleSelection(forField, index, roleName);
		};

		/**
		 *  All Needed ORI functions will be initiated form here if user has action or user creating it for the first time.
		 * 	Else 'noAccessToPerform' flag will be set to true that will not allow any user perform action.
		 */

		var setRoleAndUsersListData = function () {
			var keyNames = ['to-role', 'copy-to-role'], currNodeNameStr = '', currList = [], currObj = {}, currRoleName = '';
			for (var i = 0; i < keyNames.length; i++) {
				currNodeNameStr = keyNames[i];
				currList = $scope.commUserRolesList[fieldNameKeyMap[currNodeNameStr]];
				for (var k = 0; k < currList.length; k++) {
					currObj = currList[k];
					// set already selected Roles in list to check duplication while response view					
					selectedRoles[fieldNameKeyMap[currNodeNameStr]][k] = currObj[listNameKeyMap[currNodeNameStr]];
					currRoleName = currObj[listNameKeyMap[currNodeNameStr]];
					currRoleName = currRoleName && currRoleName.split('#')[0].trim();
					setUsersOnRoleSelection(currNodeNameStr, k, currRoleName);
				}
			}
		};
		var setOriResViewBase = function () {
			setPsrProjectDetails();
			getSetSPValues();
			$scope.workingUserId = currentUserid;
			$scope.oriMsgCustomFields.commFormName = $scope.Asite_System_Data_Read_Only['_4_Form_Type_Data']['DS_FORMNAME'];
			$scope.oriMsgCustomFields.commWorkspaceName = $scope.Asite_System_Data_Read_Only['_3_Project_Data']['DS_PROJECTNAME'];
			$scope.Asite_System_Data_Read_Only['_5_Form_Data']["DS_SEND_MSG"] = "0";
			if ($scope.isRespView) {
				// As Per Discussion Flushing Out commResponse field for response
				$scope.oriMsgCustomFields.commResponse = '';
			}
			setRoleAndUsersListData();
			
		};
		var setPrintViewBase = function () {
			$scope.allRespMsgList = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
			$scope.allFormrecipient = commonApi._.filter($scope.getValueOfOnLoadData('DS_FORM_RECIPIENT_LIST'), function (val) {
				return val.Value.split('|')[2].trim() != "Info - Publisher";
			});
			for (var index = 0; index < $scope.allRespMsgList.length; index++) {
				$scope.allRespMsgList[index].Value4 = commonApi._.unescape($scope.allRespMsgList[index].Value4);
			}
			setPsrProjectDetails();
		};

		/**All Common functions will be End from here */
		$scope.insertNewItems = function (addToList, insertFor) {
			var newObj = {};
			switch (insertFor) {
				case 'to-role-users':
					newObj = {
						toRole: '',
						toUsersStr: []
					};
					break;
				case 'copy-to-role-users':
					newObj = {
						copyToRole: '',
						copyToUsersStr: []
					};
					break;
			}
			//Add item in items
			$scope.addRepeatingRow(addToList, newObj);
			setUsersOnRoleSelection(strKeyRevMap[insertFor], addToList.length - 1, '');
		};

		$scope.removeItem = function (index, list, forField) {
			if (forField) {
				// it will remove the temp users list.
				$scope[tempListKeyMap[forField]].splice(index, 1);
				// it will remove the temp roles list.
				$scope[tempRolesListKeyMap[forField]].splice(index, 1);
				// it will remove indexed role from the selected role's list
				// that manages the duplication check of selection role.
				selectedRoles[fieldNameKeyMap[forField]].splice(index, 1);
			}
			list.splice(index, 1);
		};

		$scope.resetRow = function (forField, index) {
			$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = "";
			$scope.changeItemSelectionEvent(forField, index)
		};
		$scope.editorNativePasteEvent = function ($html) {
			return $html;
		};
		// common item selection modal End
		$scope.changeItemSelectionEvent = function (forField, index) {
			switch (forField) {
				case 'to-role':
				case 'copy-to-role':
					var roleName = $scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]];
					checkAndSetSelectedRoleExist(forField, index, roleName);
					break;
				case 'to-users':
				case 'copy-to-users':
					break;
			}
		};

		/**
		* Form's workflow logic		
		*/
		var setWorkflow = function () {
			var allListName = ['toList', 'copyToList'],
				currNodeName = "",
				tempList = [],
				tempNodeObj = {},
				childNodeObj = {},
				strRespActionDate = commonApi.calculateDistDateFromDays({
					baseDate: $scope.serverDate,
					days: parseInt(strRespondDays)
				}),
				autoDistNodeVal = $scope.isRespView ? '13' : '3';
			for (var i = 0; i < allListName.length; i++) {
				currNodeName = allListName[i];
				tempNodeObj = $scope.commUserRolesList[currNodeName];
				for (var j = 0; j < tempNodeObj.length; j++) {
					childNodeObj = tempNodeObj[j];
					var ccList=[];
					if (currNodeName == 'toList') {
						tempList.push({
							strUser: childNodeObj.toUsersStr.indexOf('#') > -1 ? childNodeObj.toUsersStr.split('#')[0].trim() : childNodeObj.toUsersStr,
							strAction: $scope.oriMsgCustomFields.Action,
							strDate: strRespActionDate
						});
					} else {
						if (childNodeObj.copyToUsersStr.length == 0 && childNodeObj.copyToRole != '') {
							for (var i = 0; i < allRoleUsersList.length; i++) {
								if (allRoleUsersList[i].Value.indexOf(childNodeObj.copyToRole.split('#')[0].trim()) > -1) {
									ccList.push(allRoleUsersList[i].Value);
								}
							}
						}
						else {
							ccList= childNodeObj.copyToUsersStr.slice();
						}
						for (var k = 0; k < ccList.length; k++) {
							tempList.push({
								strUser: ccList[k].indexOf('|') > -1 ? ccList[k].split('|')[2].trim() : ccList[k],
								strAction: "7#For Information",
								strDate: ""
							});
						}
						
					}
				}
			}
			$scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];
			// Distribution Will be made from here
			if (tempList.length) {
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.Asite_System_Data_Read_Write,
					DS_AUTODISTRIBUTE: autoDistNodeVal
				});
			}
			// set Date to Show on the Print Views.
			$scope.oriMsgCustomFields['commServerDate'] = $scope.userFormatedDate;
			$scope.oriMsgCustomFields['commServerDateDBFormat'] = $scope.todayDateDbFormat;
			$scope.oriMsgCustomFields.Last_ResponderId = currentUserid;
		};

		if ($scope.isOriView || $scope.isRespView) {
			setOriResViewBase();
			if ($scope.isRespView) {
				setReplayUsers();
			}
		} else if ($scope.isOriPrintView || $scope.isRespPrintView) {
			setPrintViewBase();
		}

		function setReplayUsers() {
			var toUsers = $scope.commUserRolesList.toList,
				index = -1,
				lastResponder = allUsersList.filter(function (val) {
					return val.Value.indexOf($scope.oriMsgCustomFields.Last_ResponderId) > -1;
				});
			if (toUsers.length) {
				if (lastResponder.length) {
					toUsers[0].toUsersStr=lastResponder[0].Value;
				}
			}
		}

		$scope.isCallForDraft = false;
		var formSubmitCallBack = function () {
			!$scope.isCallForDraft && setWorkflow();
			return false;
		};

		$scope.update();

		$window.oriformSubmitCallBack = function () {
			if (confirm("Are you sure you want to send this form?")) {
				formSubmitCallBack();}
			else{
				return true;
			}
		};
		$window.respformSubmitCallBack = function () {
			if (confirm("Are you sure you want to send this form?")) {
				formSubmitCallBack();}
			else{
				return true;
			}
		};

	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeCreate_RES() {
	if (typeof respformSubmitCallBack !== "undefined") {
		return respformSubmitCallBack();
	}
}

