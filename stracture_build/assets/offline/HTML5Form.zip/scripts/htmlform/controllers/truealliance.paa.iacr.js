/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection', '../components/signature', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;
        var modelRowIndex = -1;
        $scope.modalData = {};
        var SECTION_ARRAY = [];
        var DS_PAA_MPC_KEY_DATES_SUMMARY = [];

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                $scope.data.myFields.FORM_CUSTOM_FIELDS.Todays_Date = $scope.todayDateDbFormat;
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        $scope.isRespond = false;
        var DS_GET_ALL_PREV_FORMS;
        var PAA_CONSTANT = {
            reponseNotice: "Reply Period for Internal Alliance Change Request",
            defaultCategory: "1) Beneficial Scope Transfer",
            restrictedCharMsg: "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #",
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
            respond: "Respond",
            forInformation: "For Information",
            Closed: 'Closed',
            Open: 'Open',
            Accepted: 'Accepted',
            ClosedWithdrawn: 'Closed-Withdrawn',
            ClosedDispute: 'Closed-Dispute',
            RejectedResubmit: 'Rejected-Resubmit',
            ReviseResubmit: 'Revise Resubmit',
            Rejected: 'Rejected',
            DisputeRejection: 'Dispute',

            oriDistNumb: "401",
            resDistNumb: "411",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
            RESPOND_ACTION: "3#Respond",
            INFO_ACTION: '7#For Information',
        }

        var STATIC_OBJ_DATA = {
            sections: {
                "sectionName": "",
                "activityCode": "",
                "nopDropdown": "",
                "originalPrice": "",
                "totalAddition": "0.00",
                "currentAddition": "",
                "fee": "",
                "revisedPrice": "",
                "impactStartDate": "",
                "impactEndDate": "",
                "isSelected": ""
            },
            Impacted_Key_Dates: {
                "Key_Date_Id": "",
                "Date_Description": "",
                "KD_Current_Additions": "",
                "Date_Type": "",
                "Date_Ref": "",
                "KD_Sel": "",
                "key_isSelected": ""
            }
        }

        $scope.tableUtilSettings = {
            sections: {
                tooltip: "select to remove/remove all/Insert new section",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sections)
            },
            Impacted_Key_Dates: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0
                },
                checkboxModelKey: "key_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Impacted_Key_Dates),
                ADD_NEW_BEFORE_TIP: "Insert before programme change estimate",
                ADD_NEW_AFTER_TIP: "Insert after programme change estimate",
                deleteAllRowTooltip: "Remove all programme change estimate",
                deleteCurrRowMsg: "Remove programme change estimate",
                deleteSelectedMsg: "Remove selected programme change estimate"
            }
        }

        $scope.categoryData = commonApi.getItemSelectionList({
            arrayObject: [{
                name: PAA_CONSTANT.defaultCategory
            },
            {
                name: "2) Risk/Contingency Mitigation"
            }
                //,
                // {
                //     name: "3. Occurrence of Adjustment Events"
                // },
                // {
                //     name: "4. Value Engineering/ Value Creation"
                // }
            ],
            modelKey: 'name',
            displayKey: 'name'
        })

        ctrl.model = {
            modelId: "",
            showloader: false,
            readOnly: false,
            scrollTop: 0
        };

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.clauseCommentGroup = $scope.oriMsgCustomFields["clauseCommentGroup"];
        $scope.triggerChangeGroup = $scope.oriMsgCustomFields["triggerChangeGroup"];
        $scope.approvalGroup = $scope.oriMsgCustomFields["approvalGroup"];
        $scope.SectionsGroup = $scope.oriMsgCustomFields["SectionsGroup"];
        $scope.Prog_Changes = $scope.oriMsgCustomFields["Prog_Changes"];
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
        $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        $scope.DS_PAA_MPC_IS_USER_CONTRACTOR = $scope.getValueOfOnLoadData('DS_PAA_MPC_IS_USER_CONTRACTOR');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getWorkingUserId();
        $scope.subProjectList = [];
        $scope.selectionlist = {
            contractNoList: [],
            UserlistData: []
        }

        $scope.sectionGroup = $scope.resMsgCustomFields.Cost_Changes;
        $scope.keyMilestones = $scope.resMsgCustomFields.Prog_Changes;
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;
        $scope.oriMsgFields.DS_DB_INSERT = false;
        if (currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.changeCategory = PAA_CONSTANT.defaultCategory;
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
            $scope.selectionlist.contractNoList = commonApi.getItemSelectionList({
                arrayObject: contractData,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        } else if (currentViewName == "RES_VIEW") {
            $scope.isRespond = true;
            $scope.resMsgCustomFields.Responder_Name = $scope.dsWorkingUser;
            $scope.oriMsgCustomFields.ResponderUserId = dsWorkingUserId;
            $scope.resMsgCustomFields['resComment'] = "";
            $scope.resMsgCustomFields.resAction = '';
        }

        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break;
                }
            }
        } else {
            onContractchange($scope.oriMsgCustomFields.Contract, true);
        }

        $scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;

        $scope.update();

        $scope.onContractchange = onContractchange;
        function onContractchange(conVal, isOnLoad) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var tempConAppCode = conVal.split('|')[0].trim();
                var tempCon = conVal.split('|');

                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.oriMsgCustomFields.Contractor_Logo = tempCon[2].trim();

                setFormContent();

                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_GET_ALL_PREV_FORMS,DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS,DS_PAA_Contract_Activity_Group_dtls,DS_PAA_MPC_KEY_DATES_SUMMARY,DS_ASI_GET_CURRENCY_FROM_CONTRACT,DS_PAA_MPC_NEC_KEY_CONTRACT_DATES,DS_PAA_MPC_CON_SUBPROJECTDETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_GET_ALL_PREV_FORMS",
                            "fieldValue": "PAA-MPC-DBO | Open | " + tempConAppCode + " | " + $window.AppBuilderFormIDCode + " $$ " + "PAA-MPC-DBO | Open | " + tempConAppCode + " | PAA-MPC-SVR $$ "
                        }, {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_Contract_Activity_Group_dtls",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_KEY_DATES_SUMMARY",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_CON_SUBPROJECTDETAILS",
                            "fieldValue": tempConAppCode
                        }],
                    }
                };

                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        $scope.isDataLoaded = true;
                        if (!isOnLoad) {
                            $scope.SectionsGroup.sections = [];
                            $scope.Prog_Changes.Impacted_Key_Dates = [];
                            setCurreny(response);
                            serReplyDays(response);
                        }
                        setUserList(response);
                        setSectionList(response);
                        setKeayDate(response);
                        setSubprojectList(response);
                        if ($scope.strFormId) {
                            checkUserCanRespond(response);
                        }
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
                        if ($scope.oriMsgCustomFields.Can_Forward) {
                            var chkPermission = strIsUserDraftOnly(response);
                            if (chkPermission.toLowerCase() == "yes") {
                                setSendPermission("Draft");
                            } else {
                                setSendPermission("Send");
                            }
                        }
                    }
                });

                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim()  + "|" + arrStr[11].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
            }
        }

        function setSubprojectList(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_CON_SUBPROJECTDETAILS)) {
                var resList = JSON.parse(response.data.DS_PAA_MPC_CON_SUBPROJECTDETAILS).Items.Item;
                if (resList[0] && resList[0].Value6 == 'Yes') {
                    var section = $scope.oriMsgCustomFields.Contract.split('|')[6].trim();
                    $scope.oriMsgCustomFields.projectName = section;
                    $scope.subProjectList = commonApi.getItemSelectionList({
                        arrayObject: [{ name: section }],
                        groupNameKey: "",
                        modelKey: "name",
                        displayKey: "name"
                    });
                } else {
                    $scope.subProjectList = commonApi.getItemSelectionList({
                        arrayObject: resList,
                        groupNameKey: "",
                        modelKey: "Value2",
                        displayKey: "Value2",
                        allowBlankSelection: true
                    });
                }
            }
        }

        function setSectionList(response) {
            if (JSON.parse(response.data.DS_PAA_Contract_Activity_Group_dtls)) {
                var resList = JSON.parse(response.data.DS_PAA_Contract_Activity_Group_dtls).Items.Item;
                for (var i = 0; i < resList.length; i++) {
                    var lvl68Custom = (resList[i].Value8 || resList[i].Value7);
                    SECTION_ARRAY.push({
                        sectionName: resList[i].Value15.trim() + " | " + lvl68Custom + " | " + resList[i].Value9,
                        activityCode: resList[i].Value5,
                        nopDropdown: resList[i].Value15.trim(),
                        originalPrice: resList[i].Value6.trim(),
                        totalAddition: resList[i].Value14.trim(),
                        lvl68Custom: lvl68Custom
                    });
                }

                SECTION_ARRAY = commonApi._.sortBy(SECTION_ARRAY, 'sectionName');

                $scope.sectionList = commonApi.getItemSelectionList({
                    arrayObject: SECTION_ARRAY,
                    groupNameKey: "",
                    modelKey: "sectionName",
                    displayKey: "sectionName",
                    allowBlankSelection: true
                });
            }
        }

        function setKeayDate(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_KEY_DATES_SUMMARY)) {
                DS_PAA_MPC_KEY_DATES_SUMMARY = JSON.parse(response.data.DS_PAA_MPC_KEY_DATES_SUMMARY).Items.Item;
                $scope.objKeydate = commonApi.getItemSelectionList({
                    arrayObject: DS_PAA_MPC_KEY_DATES_SUMMARY,
                    groupNameKey: "",
                    modelKey: "Value2",
                    displayKey: "Name",
                    allowBlankSelection: true
                });
            }
        }
        function checkUserCanRespond(response) {
            var isrequired = CheckPendingAction(dsWorkingUserId);
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft");
            $scope.oriMsgCustomFields.Can_Forward = "No";
            var userList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
            var objData = commonApi._.filter(userList, function (val) {
                return val.Value.split('|')[2].split('#')[0].trim() == dsWorkingUserId;
            });
            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1";
            }
            if($scope.strIsDraft == "YES"  && isrequired && !strReviewDraft && !$scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "No";
            } else if($scope.strIsDraft == "YES" && !strReviewDraft && $scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
        }
        function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + dsWorkingUserId + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
        }
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.editDraft = "";
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (strNodes) {
                var strUserId = "",
                    strCheckRespond = "";
                for (var i = 0; i < strNodes.length; i++) {
                    $scope.editDraft = "Yes";
                    strUserId = strNodes[i].Value1;
                    strCheckRespond = strNodes[i].Value4;
                    if (strCheckRespond == "Review Draft" && strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }
        function strIsUserDraftOnly(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS)) {
                var resList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < resList.length; i++) {
                    strValue = resList[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "alliance_technical_lead") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft" || !$scope.oriMsgCustomFields.Can_Reply) {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }
        function setUserList(response) {
            if (JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS)) {
                var resList = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
                var allianceUserList = commonApi._.filter(resList, function (obj) {
                    return obj.Value && obj.Value.toLowerCase().indexOf('alliance_leadership_team') > -1;
                });

                $scope.selectionlist.UserlistData = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(allianceUserList, function (obj) { return obj.Name }),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name",
                    allowBlankSelection: true
                });
            }
        }

        function setCurreny(response) {
            if (response.data.DS_ASI_GET_CURRENCY_FROM_CONTRACT) {
                var selectedRecord = angular.fromJson(response.data.DS_ASI_GET_CURRENCY_FROM_CONTRACT).Items.Item;
                $scope.oriMsgCustomFields.Currency = selectedRecord[0].Value2;
            }
        }

        function serReplyDays(response) {
            var contractDates = angular.fromJson(response.data['DS_PAA_MPC_NEC_KEY_CONTRACT_DATES']).Items.Item;
            if (contractDates && contractDates.length) {
                var selectedData = commonApi._.filter(contractDates, function (obj) {
                    return obj.Value3.toLowerCase() == PAA_CONSTANT.reponseNotice.toLowerCase();
                })[0];
                if (selectedData) {
                    $scope.oriMsgCustomFields['Reply_Days'] = selectedData.Value4;
                }
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var strConequences = $scope.oriMsgCustomFields.Consequences;
            var strProbability = $scope.oriMsgCustomFields.Probability;
            var strActionComments = $scope.resMsgCustomFields.Actions_and_Comments;
            var strRRMNotes = $scope.resMsgCustomFields.RRM_Notes;
            var strIncreasePrice = $scope.oriMsgCustomFields.Increase_Price;

            strFormContent = strConAppid + "|" + strConequences + "|" + strProbability + "|" + strActionComments + "|" + strRRMNotes + "|" + strIncreasePrice + "|";

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        $scope.setToActon = function () {
            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            var toUserId = $scope.approvalGroup[0].name;
            toUserId = toUserId && toUserId.split('#')[0].trim();
            toUserId = toUserId && toUserId.split('|')[2].trim();
            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: toUserId && toUserId.split('#')[0].trim(),
                    strAction: PAA_CONSTANT.respondNumber + PAA_CONSTANT.respond,
                    strDate: $scope.oriMsgCustomFields['Reply_Days'] || 2
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: $scope.isRespond ? PAA_CONSTANT.resDistNumb : PAA_CONSTANT.oriDistNumb,
            });
        }

        $scope.onSectionChange = function (currRow) {
            var selectedSection = commonApi._.filter(SECTION_ARRAY, function (obj) {
                return obj.sectionName == currRow.sectionName;
            })[0];
            if (selectedSection && selectedSection.sectionName) {
                currRow.activityCode = selectedSection.activityCode;
                currRow.nopDropdown = selectedSection.nopDropdown;
                currRow.originalPrice = selectedSection.originalPrice;
                //currRow.totalAddition = selectedSection.totalAddition;
            }

            $scope.sectionList = angular.copy($scope.sectionList);
        }

        $scope.onIMpectDateChange = function (curRow, chagedField) {
            if (curRow.impactStartDate && curRow.impactEndDate && curRow.impactStartDate > curRow.impactEndDate) {
                alert('Start date should not be greater than end date!!!');
                curRow[chagedField] = '';
            }
        };

        $scope.addNewItem = function (repeatingData, objKeyName, parentRow) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);
                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.setKeydatedata = function (currObj, strVal) {
            if (strVal) {
                var objKeydata = commonApi._.filter(DS_PAA_MPC_KEY_DATES_SUMMARY, function (val) {
                    return val.Value2 == strVal
                });
                if (objKeydata.length) {
                    currObj.Key_Date_Id = strVal;
                    currObj.Date_Description = objKeydata[0].Value3;
                    currObj.Date_Type = objKeydata[0].Value7;
                    currObj.Date_Ref = objKeydata[0].Value8
                } else {
                    currObj.Date_Description = ""
                }
            } else {
                $scope.objKeydate = angular.copy($scope.objKeydate);
            }
        }

        function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        function isEstimationCostValid() {
            var sum = 0;
            angular.forEach($scope.SectionsGroup.sections, function (item) {
                sum = sum + Number(item.totalAddition);
            });
            return sum != 0 ? false : true;
        }

        function setRespFlow() {
            var dist_days = $scope.oriMsgCustomFields['Reply_Days'] || 2;
            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            var actionType, userId;
            if ($scope.isOriginator) {
                setFormStatus(PAA_CONSTANT.ReviseResubmit);
                actionType = PAA_CONSTANT.RESPOND_ACTION;
                userId = $scope.approvalGroup[0].name;
                userId = userId && userId.split('#')[0].trim();
                userId = userId && userId.split('|')[2].trim();
            } else {
                var strFormStatus = PAA_CONSTANT.Rejected;
                if ($scope.resMsgCustomFields.resAction == 'Accept') {
                    strFormStatus = PAA_CONSTANT.Accepted;
                    dist_days = "";
                }
                setFormStatus(strFormStatus);
                actionType = $scope.resMsgCustomFields.resAction == 'Accept' ? PAA_CONSTANT.INFO_ACTION : PAA_CONSTANT.RESPOND_ACTION;
                userId = $scope.oriMsgCustomFields.Originator_Id;
            }
            if (userId && actionType) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userId,
                        strAction: actionType,
                        strDate: dist_days
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                    DS_AUTODISTRIBUTE: PAA_CONSTANT.resDistNumb
                });
            }
        }

        $window.svrFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not authorised to edit this Draft message. Please click on cancel button to exit.");
					return true;
				}
                if (!$scope.oriMsgCustomFields.Can_Reply) {
                    alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
                    return true;
                }
                if (!isEstimationCostValid()) {
                    alert("The change request results in increase in the contract value. Please amend the transfer values.");
                    return true;
                }
                $scope.setToActon();
                setFormStatus(PAA_CONSTANT.Open);
            } else if ($scope.isRespond) {
                if (!isEstimationCostValid()) {
                    alert("The change request results in increase in the contract value. Please amend the transfer values.");
                    return true;
                }
                setRespFlow();
            }

            setFormContent();
            $scope.oriMsgFields.DS_DB_INSERT = true;
            return false;
        }
        $scope.isValidForm = true;
        $window.customHTMLMethodAfterValidationError = function () {
            $scope.isValidForm = false;
        }
    }
    return FormController;
});

function customHTMLMethodAfterValidationError() { }

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof svrFinalCallBack !== "undefined") {
        return svrFinalCallBack();
    }
}