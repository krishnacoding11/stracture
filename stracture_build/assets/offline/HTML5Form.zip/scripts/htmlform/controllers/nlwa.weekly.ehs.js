/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base'], function (angular, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();

        /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');

        if(currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.Originator = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
            $scope.oriMsgCustomFields.CreationDate = $scope.formatDate(new Date(), 'dd/mm/yy');
        }

        $scope.addNewDrill = function(listToImport) {
            $scope.addRepeatingRow(listToImport, {
                Title: "",
                Desc: "",
                Report: ""
            });    
        }

        $window.oriSubmitCallBack = function () {
            $scope.asiteSystemDataReadWrite.DS_USER_ROLE_ASSIGNMENT_FLAG = true;

            if (currentViewName == "ORI_VIEW") {
                var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
                var members = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                    return  (val.Value.split('|')[0].trim() === 'NLHPP HS&E Lead');
                });
    
                if (members.length) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF = $scope.oriMsgCustomFields.CreationDate;
                    $scope.asiteSystemDataReadWrite.ORI_FORMTITLE = $scope.oriMsgCustomFields.WeeklyEHSStatistics.PrincipalContractor;

                    var teamList = [];
                    members.forEach(function(member) {
                        teamList.push({
                            strUser: member.Value.split('|')[2].trim(),
                            strAction: "7#For Information",
                            strDate : ""   
                        });
                    });

                    commonApi.setDistributionNode({
                        actionNodeList: teamList,
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: 3
                    });
                    return false;
                }else {
                    alert("There is no user exist in NLHPP HS&E Lead Role.");
                    return true;
                }
            }

            return false;
        };

        $window.draftSubmitCallBack = function () { 
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
            if(!$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF) {
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF = $scope.oriMsgCustomFields.CreationDate;
            }
            $scope.asiteSystemDataReadWrite.ORI_FORMTITLE = $scope.oriMsgCustomFields.WeeklyEHSStatistics.PrincipalContractor;
            return false;
        }

        $scope.update();
    }
    
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriSubmitCallBack !== "undefined") {
		return oriSubmitCallBack();
	}
}


function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}