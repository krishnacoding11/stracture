/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

		/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {	
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement && event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if(!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') && 
			!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if(!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') && 
			!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function(taRegisterTool, taOptions) {
			taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                []
            ];
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
			taRegisterTool("fontColor", {
				display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("foreColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-font",
					showButtons: !1,
                    showAlpha : !1
				},
				color: "#000"
			}),
			taRegisterTool('fontName', {
				display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>"+"</button>",
				action: function (event, font) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
					this.$element.toggleClass('open-fonts-list');
					return this.$editor().wrapSelection('fontName', font);
				},	
				disabled: function() {},			
				options: [
					{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
					{ name: 'Serif', css: "'times new roman', serif" },
					{ name: 'Wide', css: "'arial black', sans-serif" },
					{ name: 'Narrow', css: "'arial narrow', sans-serif" },
					{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
					{ name: 'Courier New', css: "'courier new', monospace" },
					{ name: 'Garamond', css: 'garamond, serif' },
					{ name: 'Georgia', css: 'georgia, serif' },
					{ name: 'Tahoma', css: 'tahoma, sans-serif' },
					{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
					{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
					{ name: 'Verdana', css: 'verdana, sans-serif' },
					{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
				]
			}),
			taRegisterTool('fontSize', {
				display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",				
				action: function (event, size) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-list').removeClass('open-fonts-list');
					this.$element.toggleClass('open-fonts-size-list');					
					return this.$editor().wrapSelection('fontSize', parseInt(size));					
				},			                
				disabled: function() {},
				options: [
					{ name: 'xx-small', css: 'xx-small', value: 1 },
					{ name: 'x-small', css: 'x-small', value: 2 },
					{ name: 'small', css: 'small', value: 3 },
					{ name: 'medium', css: 'medium', value: 4 },
					{ name: 'large', css: 'large', value: 5 },
					{ name: 'x-large', css: 'x-large', value: 6 },
					{ name: 'xx-large', css: 'xx-large', value: 7 }

				]
			}),
			taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'),taOptions;
		}
		]);
	};
	
	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
	});
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
		
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		$scope.getServerTime(function (serverDate) {
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
		});

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadwrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
		$scope.dSDraft = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'];
		var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
		var DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS');
		var DS_ASI_STD_FIDIC_NEC_COMM_TYPES = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_COMM_TYPES');
		var DS_ASI_STD_FIDIC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_CONTRACT');
		var DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES');
		$scope.DS_RES_COUNT = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_RES_COUNT'];
		var DS_ASI_STD_FIDIC_SETUP_SECTIONS = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_SETUP_SECTIONS');
		var DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		$scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
		$scope.isDataLoaded = true;
		$scope.dropdownObj = {
			contractNoList: [],
			distSectionsList: [],
			engineerlist: [],
			communicationList: [],
			clausesList: [],
			ewnList:[],
			employerlist: [],
			forInfoUserslist:[],
			valueEngList:[]
		};

		var STATIC_OBJ_DATA = {

			CEN_EVENT_CLAUSES: {
				"ClauseNo": "",
				"Clause_Text": "",
				"isClauseSelected": false
			}
		}

		var FIDIC_CONSTANT = {
			UNAUTHORIZED_MSG: "1|You are not authorised to respond this form. You therefore cannot respond, please click the cancel button at the bottom of the form.",
			RESPOND_ACTION: '3#Respond',
			INFO_ACTION: '7#For Information',
			ROLE_ALREADY_TITLE: 'Role is already selected',
			ROLE_ALREADY_MSG: 'Please select different role.',
			SERVER_ERROR_TITLE: 'Server Error',
			SECTION_SERVER_ERROR_MSG: 'Error while getting Section Data.',
			employer: 'Employer',
			engineer: 'Engineer',
			contractor: 'Contractor',
			referred:'Referred'
		};

		if (currentViewName == "ORI_VIEW") {

			if ($scope.dSFormId) {
				checkUserCanRespond();
			}


			if ($scope.dSFormId && $scope.dSDraft == "NO") {
				$scope.oriMsgCustomFields.Can_Forward = "";
				$scope.hideSaveDraftButton();
			}
			var contractData = $scope.getValueOfOnLoadData('DS_ASI_STD_FIDIC_NEC_ORG_CONTRACT');
			$scope.dropdownObj.contractNoList = commonApi.getItemSelectionList({
				arrayObject: contractData,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
				setSendPermission("Send");
				
			if ($scope.dSDraft == "YES") {
				fillDropwdowns();
			}
		}

		if (currentViewName == "ORI_PRINT_VIEW") {
			var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
			var urlObj = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_CONTRACT, function (val) {
				return val.Value.split('|')[0].trim() == strConAppid.trim();
			});
			if (urlObj.length) {
				$scope.oriMsgCustomFields.Contract_URL = urlObj[0].URL;
			}
			if(DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM.length){
				$scope.oriMsgCustomFields.valEng_URL = DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM[0].URL3;
			}

			angular.element('.export-btn').hide();
		}

		$scope.onContractchange = function (conVal) {
			if (conVal) {
				$scope.isDataLoaded = false;
				var tempConAppCode = conVal.split('|')[0].trim();
				var tempCon = conVal.split('|');
				$scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
				$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
				$scope.oriMsgCustomFields.Client_Logo = tempCon[5].trim();
				$scope.oriMsgCustomFields.Contractor_Logo = tempCon[4].trim();
				$scope.oriMsgCustomFields.Engineer_Logo = tempCon[6].trim();
				$scope.oriMsgCustomFields.Contract_Code = tempCon[2].trim();
				var spParam = {
					dataSourceArray: [{
						"fieldName": "DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_EWN",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_COMM_Details",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_COMM_TYPES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_KEY_CONTRACT_DATES",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_SETUP_SECTIONS",
						"fieldValue": tempConAppCode
					}, {
						"fieldName": "DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM",
						"fieldValue": tempConAppCode+"|"+$scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE
					}],
					successCallback: contractChangeCallback
				};

				$scope.getCallbackSPdata(spParam);
			}
		}

		function contractChangeCallback(responseList) {

			if (responseList["DS_ASI_STD_FIDIC_SETUP_SECTIONS"]) {
				DS_ASI_STD_FIDIC_SETUP_SECTIONS = responseList["DS_ASI_STD_FIDIC_SETUP_SECTIONS"];
			}

			if (responseList["DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS"]) {
				DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS = responseList["DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS"];
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_COMM_TYPES"]) {
				DS_ASI_STD_FIDIC_NEC_COMM_TYPES = responseList["DS_ASI_STD_FIDIC_NEC_COMM_TYPES"];
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES"]) {
				DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES = responseList["DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES"];
			}

			var keyDatesObj = responseList["DS_ASI_STD_FIDIC_NEC_KEY_CONTRACT_DATES"];
			if (keyDatesObj.length) {
				var appCode = $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
				var keyObj = commonApi._.filter(keyDatesObj, function (val) {
					return val.Value5 == appCode;
				});
				if (keyObj.length) {
					var days = keyObj[0].Value4.trim();
					$scope.oriMsgCustomFields.Reply_Due_Days = days;
					$scope.oriMsgCustomFields.Reply_Due_Date = commonApi.calculateDistDateFromDays({
						baseDate: $scope.todayDateDbFormat,
						days: days
					});
				}
			}

			if (responseList["DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM"]) {
				DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM = responseList["DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM"];
			}

			fillDropwdowns();

			var chkPermission = strIsUserDraftOnly();
			if (chkPermission.toLowerCase() == "yes")
				setSendPermission("Draft");
			else
				setSendPermission("Send");

			$scope.isDataLoaded = true;
		}

		function setWorkflow() {

			$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var tempList = [];
			var allUsers = $scope.oriMsgFields.DS_PROJUSERS_ALL_ROLES;
			if (allUsers) {
				var distDate = $scope.oriMsgCustomFields.Reply_Due_Date;

				tempList.push({
					strUser: allUsers.split('|')[2].trim(),
					strAction: FIDIC_CONSTANT.INFO_ACTION,
					strDate: distDate
				});

				var infoUsers = $scope.oriMsgCustomFields.Dist_Group_Users;
				if (infoUsers.length) {
					for (var j = 0; j < infoUsers.length; j++) {
						tempList.push({
							strUser: infoUsers[j].split('|')[2].trim(),
							strAction: FIDIC_CONSTANT.INFO_ACTION,
							strDate: ""
						});
					}
				}
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
					DS_AUTODISTRIBUTE: 3
				});
			}
		}

		function fillDropwdowns() {

			$scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_SETUP_SECTIONS,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var objdata = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return (val.Value.split('|')[1].trim() == FIDIC_CONSTANT.engineer) && val.Value.split('|')[2].split('#')[0].trim() != currentUserid;
			});
			$scope.dropdownObj.engineerlist = commonApi.getItemSelectionList({
				arrayObject: objdata,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			$scope.dropdownObj.forInfoUserslist = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
			
			$scope.dropdownObj.communicationList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_COMM_TYPES,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var currUserObj = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return val.Value.split('|')[2].split('#')[0].trim() == currentUserid;
			});

			if (currUserObj.length) {
				$scope.oriMsgCustomFields.Filter_Role = currUserObj[0].Value.split('|')[1].trim();
			}

			$scope.dropdownObj.clausesList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES,
				groupNameKey: "",
				modelKey: "Value3",
				displayKey: "Value5"
			});

			$scope.dropdownObj.valueEngList = commonApi.getItemSelectionList({
				arrayObject: DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM,
				groupNameKey: "",
				modelKey: "Value2",
				displayKey: "Value6"
			});
		}

		function strIsUserDraftOnly() {
            if (DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == currentUserid)
                            return "Yes";
                    }
                }
            }
            return "No";
		}
		
		function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.Asite_System_Data_Read_Only._5_Form_Data.DS_SEND_MSG = strMsg;
		}

		function checkUserCanRespond(){

			var strCanReplay = "YES",
            strCanReplayStatus = "0";
			var objData = commonApi._.filter(DS_ASI_STD_FIDIC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return val.Value.split('|')[2].split('#')[0].trim() == currentUserid;
			});

			if (!objData.length) {
				strCanReplay = "";
				strCanReplayStatus = "1"
			}				
			if(!strCanReplay){
				$scope.hideSaveDraftButton();
			}
			$scope.oriMsgCustomFields.Can_Reply = strCanReplay;
			$scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;	
	   }
		
	   $scope.setTitle = function(strVal){
		var objData = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_ALL_NOTICE_CLAIM, function (val) {
			return val.Value2.trim() == strVal;
		});
		if(objData.length){
			$scope.oriMsgCustomFields.ORI_FORMTITLE = objData[0].Value4.trim();
		}
	   }

		function setFormContent1() {
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = $scope.oriMsgCustomFields.valEngId;
		}


		$scope.setClauses = function () {
			$scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES = [];
			var selectedClauses = $scope.oriMsgCustomFields.clauses,
				insertPoint = $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES,
				structClauses = "";

			var tempClausesobj = commonApi._.filter(DS_ASI_STD_FIDIC_NEC_ALL_CLAUSES, function (itm) {
				for (var i = 0; i < selectedClauses.length; i++) {
					if (itm.Value3 == selectedClauses[i]) {
						return true;
					}
				}
			});

			if (tempClausesobj.length) {
				for (var i = 0; i < tempClausesobj.length; i++) {
					structClauses = angular.copy(STATIC_OBJ_DATA.CEN_EVENT_CLAUSES);
					structClauses.ClauseNo = tempClausesobj[i].Value3;
					structClauses.Clause_Text = tempClausesobj[i].Value4;
					insertPoint.push(structClauses);
				}
			}
		}

		$scope.update();
		$scope.isCallForDraft = false;
		function formSubmitCallBack() {

			if (currentViewName == "ORI_VIEW") {
				if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not permitted to edit this form, please cancel this process and use the Distribute option to forward to additional recipients.");
					return true;
				}
				
				if (!$scope.oriMsgCustomFields.Can_Reply) {
					alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
					return true;
				}
				
				setFormContent1();
				setWorkflow();
			}
			return false;
		};

		$window.oriformSubmitCallBack = function () {
			return formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			setFormContent1();
		}
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}