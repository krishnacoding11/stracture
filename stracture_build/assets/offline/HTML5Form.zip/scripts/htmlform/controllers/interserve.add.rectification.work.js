/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					freezedHeaderColScrollBind();
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');					
				}, 100);
			}
		});

		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');		
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');		
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');		
		$scope.isRespPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.isDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'YES');
		$scope.appMsgId = $scope.asiteSystemDataReadOnly['_6_Form_MSG_Data']['DS_MSGID'];
		$scope.formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
		$scope.isFormAccepted = $scope.formStatus === 'Accepted';

		// form's user interaction nodea starts here.
		$scope.rectificationWork = $scope.oriMsgCustomFields.rectificationWork;
		$scope.rectificationDetails = $scope.rectificationWork.rectificationDetails || [];
		$scope.calculatedTotalAmounts = $scope.rectificationWork.calculatedTotalAmounts || {
			activityTotal: '',
			variationTotal: '',
			prelimsTotal: '',
			designFeesTotal: '',
			contingencyTotal: '',
			inflationTotal: '',
			nec4FeeTotal: '',
			ohSumTotal: '',
			targetCostTotal: '',
			targetVariationCostTotal : ''
		};

		$scope.rectificationDetails = $scope.rectificationWork.rectificationDetails || {
			responseStatus : '',
			responseComment : ''
		};

		$scope.mapRoomsDetails = $scope.rectificationWork.mapRoomsDetails || [];
		$scope.roomListMap = [];

		$scope.isAllFieldsAvail = $scope.rectificationWork.isAllFieldsAvail || false;
		$scope.isShowTabled = $scope.rectificationWork.isShowTabled || false;
		$scope.xhr = {
			rectificationXhr : false
		};		

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			CONSTANTS_OBJ = {
				IMAGE_ASITE_DEFAULT_STR : '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR : 'images/htmlform/interserve/interserve-logo.png',
				ROOM_NO_LIST_KEY : 'room-no-list',
				ROOM_NO_LABEL : 'Room No\'s List',
				DIST_USER_LIST_KEY : 'dist-user-list',
				DIST_USER_LIST_LABEL : 'Role Users',
				BOQ_Details_by_QSref : 'DS_INS_BOQ_Details_by_QSref',
				PRICEDOCDETAIL_BY_QSREF : 'DS_INS_PRICEDOCDETAIL_BY_QSREF'
			},
			STATIC_OBJ = {
				rectDetails : {					
					rectGuid: '',
					isRectSelected : false,
					isRectShow : true,
					isRectDeleted : false,
					isRectHeader : false,
					rectificationCode: '',
					rectificationName: '',
					rectBoqQuantity : {
						boqQty: '',
						boqUom: '',
						boqRate: '',
						boqNetCost: '',
                        boqNetCostVariation : ''
					},
					calculationDetails : {
						prelims : '',
						designFees : '',
						contingency : '',
						inflation : '',
						nec4Fee : '',
						ohSum : '',
						targetCost : '',
						targetVariationCost : ''
					},
					customColumns : {
						
					}
				},
				roomDetails: {
					roomNo: "",
					'new': true
				}
			},
            FORMID = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] || '',			
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),			
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
			roomList = [];

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);

			$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
		});
		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		$scope.oriMsgCustomFields.isDefaultLogo = true;	
		
		$scope.tableUtilSettings = {
			rectDetails: {
				tooltip: "select to remove/remove all/Insert new BOQ data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRectSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore:0,
					deleteAllRow: 0,
                    deleteSelected: 0,
				},
				newStaticObject: angular.copy(STATIC_OBJ.rectDetails),
				ADD_NEW_BEFORE_TIP: "Insert before BOQ Details",
				ADD_NEW_AFTER_TIP: "Insert after BOQ Details",
				deleteAllRowTooltip: "Remove all BOQ Details",
				deleteCurrRowMsg: "Remove BOQ Details",
				deleteSelectedMsg: "Remove selected BOQ Details",
				addItemCallBack: function () {},
				editRowCallBack: function () {},
				deleteItemCallBack: function () {}
			}
		};	
		
		var freezedHeaderColScrollBind = function(){		
			$timeout(function () {
				var objTableWrapper = $element.find('.table-wrapper'),
					objHeaderTR = $element.find('.headerTR th');

				objTableWrapper.bind('scroll', function(event){
					var objFixTds = $element.find('.freezeTd');
					objFixTds.css('left', ( event.target.scrollLeft )+ "px" );
					objHeaderTR.css('top' , ( event.target.scrollTop )+ "px");
				});
			},200);
		},	totalAmontKey = [
			'prelimsTotal',
			'designFeesTotal',
			'contingencyTotal',
			'inflationTotal',
			'nec4FeeTotal',
			'ohSumTotal',
			'targetCostTotal'
		],	amontKeys = [
			'prelims',
			'designFees',
			'contingency',
			'inflation',
			'nec4Fee',
			'ohSum',
			'targetCost'
		],	calculationsKeyMap = {
			boqQty : {
				nodeParent : 'rectBoqQuantity',
				total : 'boqNetCost',
				calcNode : 'calculationDetails',
				totalCalcNode : 'calculatedTotalAmounts',
				preFix : ''
			}, measuredQty : {
				nodeParent : 'rectMeasuredQuantity',
				total : 'measuredTotalVariation',
				//	total : 'measuredTotal',
				calcNode : 'measCalculationDetails',
				totalCalcNode : 'measCalculatedTotalAmounts',
				preFix : 'meas'
			}
		},	calculateIndividualTotal = function (calcFor) {
			for(var k=0; k<amontKeys.length; k++) {				
				var currObjKey = calculationsKeyMap[calcFor]['totalCalcNode'],
					currRowPropKey = calculationsKeyMap[calcFor]['preFix'] + amontKeys[k],
					currTotalAmontKey = calcFor == 'measuredQty' ? totalAmontKey[k].charAt(0).toUpperCase() + totalAmontKey[k].slice(1) : totalAmontKey[k],
					currPropertyKey = calculationsKeyMap[calcFor]['preFix'] + currTotalAmontKey;
				
				//  reset key total first.
				$scope[currObjKey][currPropertyKey] = 0;
				for(var i=0; i< $scope.rectificationDetails.length; i++) {
					if(!$scope.rectificationDetails[i].isRectHeader) {					
						$scope[currObjKey][currPropertyKey] = (parseFloat($scope[currObjKey][currPropertyKey]) || 0) + (parseFloat($scope.rectificationDetails[i][calculationsKeyMap[calcFor]['calcNode']][currRowPropKey]) || 0) ;
						$scope[currObjKey][currPropertyKey] = $scope[currObjKey][currPropertyKey].toFixed(2);

					}
				}
			}
		}, 	calcPrelims = function (tempObj, calcFor, totalKey) {
			// =Y24*$AN$14
			var prelims = parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']])*parseFloat($scope.rectificationWork.activityOverHead.prelimnaries/100);			
			return prelims.toFixed(2);
		}, 	calcDesignFees = function (tempObj , calcFor, totalKey) {
			// =(AH24+Y24)*$AN$15
			var designFees = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]))*parseFloat($scope.rectificationWork.activityOverHead.profDesignFees/100);
			return designFees.toFixed(2);
		}, 	calcContingency = function (tempObj, calcFor, totalKey) {
			// =((AI24+AH24+Y24)*$AN$16)
			var contingency = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]))* parseFloat($scope.rectificationWork.activityOverHead.contingency/100);
			return contingency.toFixed(2);
		}, 	calcInflation = function (tempObj, calcFor, totalKey) {
			// =((AI24+AH24+Y24)*$AN$17)
			var inflation = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']])) * parseFloat($scope.rectificationWork.activityOverHead.inflation/100);
			return inflation.toFixed(2);
		}, 	calcNec4Fee = function (tempObj, calcFor, totalKey) {
			// =((AH24+AI24+Y24+AK24)*$AN$18)
			var nec4Fee = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'inflation'])) * parseFloat($scope.rectificationWork.activityOverHead.NEC4basedFee/100);
			return nec4Fee.toFixed(2);
		}, 	calcOhSum = function (tempObj, calcFor, totalKey) {
			// =SUM(AH24:AL24)
			var ohSum = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'contingency']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'inflation']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'nec4Fee']));
			return ohSum.toFixed(2);
		}, 	calcTargetCost = function (tempObj, calcFor, totalKey) {
			// =AM24+Y24
			var targetCost = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'ohSum']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]));
			return targetCost.toFixed(2);
		},	bgVariationCalculation = function (tempObj, calcFor) {			
			// Calculated Individual Nodes 
			tempObj.calculationDetails.prelims = calcPrelims(tempObj, calcFor, 'prelimsTotal');
			tempObj.calculationDetails.designFees = calcDesignFees(tempObj, calcFor, 'designFeesTotal');
			tempObj.calculationDetails.contingency = calcContingency(tempObj, calcFor, 'contingencyTotal');
			tempObj.calculationDetails.inflation =calcInflation(tempObj, calcFor, 'inflationTotal');
			tempObj.calculationDetails.nec4Fee = calcNec4Fee(tempObj, calcFor, 'nec4FeeTotal');
			tempObj.calculationDetails.ohSum = calcOhSum(tempObj, calcFor, 'ohSumTotal');
			tempObj.calculationDetails.targetCost = calcTargetCost(tempObj, calcFor, 'targetCostTotal');
			// function for the whole total calculations.
			calculateIndividualTotal(calcFor);
			//	calculateAllTotal();
		},	structureItemList = function(setFor, availList) {    			
			var tempList=[],
				optlabel = '';  				
			switch (setFor) {				
				case CONSTANTS_OBJ.DIST_USER_LIST_KEY:
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.split('#')[1].trim(),							
							modelValue:  item
						});	
					});
					optlabel = CONSTANTS_OBJ.DIST_USER_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.ROOM_NO_LIST_KEY:
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Value8,                         
							modelValue:  item.Value7 + '#' + item.Value8
						});	
					});
					optlabel = CONSTANTS_OBJ.ROOM_NO_LABEL;
					break;					
			}     
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};
		
		$scope.itemListOpen = function (index, currRoomNo) {			
			var selectedRoomNo = [],
				filteredList = roomList || [];

			$scope.mapRoomsDetails.forEach(function(roomObj) {
				if(roomObj.roomNo && roomObj.roomNo != currRoomNo) {
					selectedRoomNo.push(roomObj.roomNo);
				}	
			});

			if(selectedRoomNo.length) {
				filteredList = roomList.filter(function(item) {
					return selectedRoomNo.indexOf(item.Value7 + '#' + item.Value8) < 0;
				});
			} 

			$scope.roomListMap[index] = structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, filteredList);
		};

		$scope.setIsAllFieldsAvail = function () {
			$scope.isAllFieldsAvail = false;
			if($scope.rectificationWork.qsRef && $scope.rectificationWork.activityOverHead.prelimnaries && $scope.rectificationWork.activityOverHead.profDesignFees && $scope.rectificationWork.activityOverHead.contingency && $scope.rectificationWork.activityOverHead.inflation && $scope.rectificationWork.activityOverHead.NEC4basedFee) {
				$scope.isAllFieldsAvail = true;
			}
		};

		$scope.showTableFun = function () {
			$scope.isShowTabled = false;
			if($window.confirm("It will disable values you have entered, Do you want to procceed?")){
				$scope.isShowTabled = true;			
			}
		};

		$scope.insertNewItems = function (addToList, insertFor) {
			//Add item in items
			$scope.addRepeatingRow(addToList, angular.copy(STATIC_OBJ[insertFor]));
		};

		$scope.addNewRoom = function(list) {
			list.push(angular.copy(STATIC_OBJ.roomDetails));			
			$scope.roomListMap.push(structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, roomList));
		};

		$scope.removeRoomNo = function(index) {			
			$scope.mapRoomsDetails.splice(index, 1);
			$scope.roomListMap.splice(index, 1);
		};

		$scope.calculateBoqNetCost = function (paramObj) {
			paramObj.calcNode[paramObj.totalKey] = 0;
			paramObj.calcNode[paramObj.totalKey] = parseInt(paramObj.calcNode.boqQty || 0) * parseFloat(paramObj.calcNode.boqRate || 0);
			paramObj.calcNode[paramObj.totalKey] = paramObj.calcNode[paramObj.totalKey].toFixed(2);
			bgVariationCalculation(paramObj.item, paramObj.calcFor);
		};

		var workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0],
			workingUserId = $scope.getWorkingUserId(),
			trustRoleUserList = commonApi.roleUsersListByRoleName('trust', projAllRolesList),			
			isUserTrustRoleMember = !!(trustRoleUserList.filter(function(userObj){
				return (workingUserId == userObj.split('#')[0].trim());
			}).length),
			incompleteActionsList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS'),
			incompleteActionsByMsgList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG'),			
			isForCreate = !!($scope.isOriView && FORMID == '') || !!($scope.isOriView && FORMID != '' && $scope.isDraft),
			isEditAndFwd = ($scope.isOriView && !$scope.isDraft && $scope.appMsgId != '') || !!($scope.isOriView && !$scope.isDraft && FORMID);

		$scope.authorizedToWork = false;
		$scope.isOriginatorUser = ($scope.rectificationWork.distUserDetails.originatorUser && (workingUserId == $scope.rectificationWork.distUserDetails.originatorUser.split('#')[0].trim()));

		var checkWorkingAccess = function() {
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| You are not authorised to raise or edit this Form.";				
			return isForCreate || !isUserTrustRoleMember || isEditAndFwd;
		};

		var setOriViewBase = function () {
			// set Block Number Dynamically from the Custom attribute.
			$scope.trustRoleUsersList = structureItemList(CONSTANTS_OBJ.DIST_USER_LIST_KEY, trustRoleUserList);
			
			// set originator on load.
			if(isForCreate) {
				//	getPriceDetailOverHead();
				// to set block number dynamically
				if(!$scope.rectificationWork.block) {
					// default set 5.
					$scope.rectificationWork.block = (configAttributesList.filter(function(attrObj) {
						return (attrObj.Value3.toLowerCase() == 'block number' || attrObj.Value3.toLowerCase() == 'blocknumber') && attrObj.Value11 == 'Active';
					})[0] || {Value7 : '05'}).Value7;
				}

				roomList = configAttributesList.filter(function(attrObj) {
					return (attrObj.Value3.toLowerCase() == 'room no' || attrObj.Value3.toLowerCase() == 'roomno') && attrObj.Value11 == 'Active';
				});

				!$scope.rectificationWork.formTitle && ($scope.rectificationWork.formTitle = "Schedule 6/7. Rectification/Enhancement Work."); 
				!$scope.rectificationWork.formSubTitle && ($scope.rectificationWork.formSubTitle = $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME);		
				!$scope.rectificationWork.tableColumnHeader && ($scope.rectificationWork.tableColumnHeader = "Rectification/Enhancements (Contractor pricing detail)");

				var workingUser = workingUserObj.Value.split('#')[0];
				$scope.rectificationWork.distUserDetails.originatorUser = workingUser.replace('|','#').trim();
				!$scope.mapRoomsDetails.length && $scope.addNewRoom($scope.mapRoomsDetails);
			}
		};
		
		if ($scope.isOriView) {
			$scope.authorizedToWork = checkWorkingAccess();
			if($scope.authorizedToWork) {
				$scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
				setOriViewBase();
				// resetting auto distribution node.
				$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			}
		} else if ($scope.isRespView) {	
			// reset the Form Status and Comments respectivly as well.
			if($scope.isOriginatorUser){
				$scope.rectificationWork.responseDetails.originatorComments = '';		
			} else {
				$scope.rectificationWork.responseDetails.responseComment = '';
			}
			$scope.rectificationWork.responseDetails.responseStatus = '';
		} else if ($scope.isOriPrintView) {
			$scope.$parent.priv.canForward = $scope.isFormAccepted;
		} else if ($scope.isRespPrintView) {}
	
		var setFormWorkflow = function () {
			var userTodistribute = '',
				currFormStaus = '',
				autoDistNode = '3';

			// Distribution Will be made from here
			// resetting auto distribution node.
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if($scope.isOriView) {
				userTodistribute = $scope.rectificationWork.distUserDetails.distUser;
				currFormStaus = 'for approval';				
				if(isEditAndFwd) {
					$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
					$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
					commonApi.setClearCompletePendingActions({
						//	actionsList : incompleteActionsList,
						actionsList : incompleteActionsByMsgList,
						nodeToSet : $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action,
						appBuilderCode : $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID,
						//	actionSpNodeKey : 'Name',
						actionSpNodeKey : 'Value4',
						actionStr : 'Respond',
						acttionId : '3',
						type : 'clear',
						remarks : 'clear actions',
						isAllActionClear : true
					});
				}
			} else if($scope.isRespView) {
				currFormStaus = $scope.rectificationWork.responseDetails.responseStatus;
				autoDistNode = '13'
				if(currFormStaus == 'revised and resubmit' || currFormStaus == 'accepted') {
					userTodistribute = $scope.rectificationWork.distUserDetails.originatorUser; 
				} else if(currFormStaus == 'for approval') {
					userTodistribute = $scope.rectificationWork.distUserDetails.distUser;
				}
			} 

			if(userTodistribute) {
				commonApi.setDistributionNode({
					actionNodeList : [{
						strUser : userTodistribute,
						strAction : "3#Respond",
						strDate : commonApi.calculateDistDateFromDays({
							baseDate: $scope.serverDate,
							days : 7
						})                    
					}],
					autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE : autoDistNode
				});
			}

            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {             
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		};

		$scope.update();
		$window.oriformSubmitCallBack = function () {
			setFormWorkflow();
			$scope.rectificationWork.isShowTabled = $scope.isShowTabled;
			$scope.rectificationWork.isAllFieldsAvail = $scope.isAllFieldsAvail;

			$scope.mapRoomsDetails.forEach(function(roomDetail) {
				delete roomDetail['new'];
			});

			//	set form title.
			if(!$scope.oriMsgCustomFields.ORI_FORMTITLE) {
				$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.rectificationWork.formType + ' ' + $scope.oriMsgCustomFields.ORI_USERREF;
			}

			// DB entry check.
			$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = ($scope.isRespView && $scope.rectificationWork.responseDetails.responseStatus == 'accepted').toString();
			
			return false;
		};
		
		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			$scope.rectificationWork.isShowTabled = $scope.isShowTabled;
			$scope.rectificationWork.isAllFieldsAvail = $scope.isAllFieldsAvail;
		}
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}