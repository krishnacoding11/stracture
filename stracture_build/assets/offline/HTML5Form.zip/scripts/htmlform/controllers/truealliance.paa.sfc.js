/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/signature', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.oriMsgCustomFields.Todays_Date = $scope.todayDateDbFormat;
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();
        $scope.isDataLoaded = true;


        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadWrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
        $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        var DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var dsWorkingUserId = $scope.getWorkingUserId();
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';

        $scope.selectionlist = {
            contractNoList: [],
            objActionsList: [],
            projectManlist: [],
            maintManList: [],
            interfaceCoList: [],
            assetOwnerList: []
        }

        var PAA_CONSTANT = {
            //To fill dropdown rolewise
            ProjectMan: 'Project Manager',
            maintMan: 'Maintenance Manager',
            InterfaceCo: 'Interface Co-ordinator',
            assetOwner: '[Discipline] Asset Owner',

            // Form Statuses
            Closed: 'Closed',
            forReview: 'For Review',
            rejected: 'Rejected',
            revisedForReview: 'Revised - For Review',

            reponseNotice: 'Sectional Completion Certificate Reply Period',
            defaultReplyDays: 2,

            // Manage date as per Holiday Calender
            oriDistNumb: "401",
            resDistNumb: "411",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
        }
        if (currentViewName == 'ORI_VIEW' || currentViewName == 'RES_VIEW') {
            var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
            $scope.selectionlist.contractNoList = commonApi.getItemSelectionList({
                arrayObject: contractData,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
            $scope.selectionlist.objActionsList = commonApi.getItemSelectionList({
                arrayObject: DS_FORMACTIONS,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        $scope.update();

        function setOriView() {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
        }

        initFormsData();
        function initFormsData() {
            if ($scope.oriMsgCustomFields.Contract && currentViewName == "ORI_VIEW") {
                onContractchange($scope.oriMsgCustomFields.Contract, true);
            }

            if (currentViewName == "ORI_VIEW") {
                setOriView();
            }
            if (currentViewName == 'RES_VIEW') {
                $scope.oriMsgCustomFields["ResponderName"] = document.getElementById('DS_WORKINGUSER').value;
                $scope.oriMsgCustomFields["ResponderUserId"] = dsWorkingUserId;
                $scope.isRespond = true;
                $scope.canReply = checkHasRespondAction();
                $scope.oriMsgCustomFields.Res_Comment = '';
                $scope.oriMsgCustomFields.Approval_Grant = 'Accept';
                $scope.oriMsgCustomFields["ProManagersignature"] = ""
            }
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
                $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
                setRolewiseUser(PAA_CONSTANT.ProjectMan);
                setRolewiseUser(PAA_CONSTANT.maintMan);
                setRolewiseUser(PAA_CONSTANT.InterfaceCo);
                setRolewiseUser(PAA_CONSTANT.assetOwner);
                $scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;
            }
            if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
                $scope.hideExportBtn();
                for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                    if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                        $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                        break;
                    }
                }
            }
        }

        /**
         * Used to get userId from string given by sp
         * @param {String} userString 
         */
        function getUserId(userString) {
            if (userString) {
                return userString.split('|')[2].split('#')[0].trim();
            } else {
                return "";
            }
        }

        /**
         * To check if user has action or not
         */
        function checkHasRespondAction() {
            var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                Name: "Respond"
            });
            if (!spNode) {
                return false;
            }

            var incompleteUserActionIds = spNode.Value.trim();
            if (incompleteUserActionIds && dsWorkingUserId && incompleteUserActionIds.indexOf(dsWorkingUserId) > -1) {
                return true;
            }
            return false;
        };

        function clearUsersAction(userIdsArray) {
            if (userIdsArray && userIdsArray.length) {
                var dsAppBuilderID = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];
                $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
                for (var index = 0; index < userIdsArray.length; index++) {
                    var msgType = getMsgType( userIdsArray[index] );
                    $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                        DS_AC_TYPE: "clear",
                        DS_AC_FORM: dsAppBuilderID,
                        DS_AC_MSG_TYPE: (msgType && msgType.indexOf("RES") > -1) ? "RES" : "ORI",
                        DS_AC_USERID: userIdsArray[index],
                        DS_AC_ACTION: "3",
                        DS_AC_ACTION_REMARKS: "Action Cleared"
                    })
                }
            }
        }

        function getMsgType(userId){
            for (var index = 0; index < DS_INCOMPLETE_ACTIONS_BYMSG.length; index++) {
                var element = DS_INCOMPLETE_ACTIONS_BYMSG[index];
                if(element.Value1 == userId && element.Value4 == "Respond"){
                    return element.Value3
                }
            }
            return "";
        }

        function setAppWorkFlow() {
            var userTodistribute = [];
            var autoDistNumber = 0;
            var actionValue = "";
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "";
            if ($scope.isOriginator) {
                userTodistribute = [
                    getUserId($scope.oriMsgCustomFields.ProjectMan),
                    getUserId($scope.oriMsgCustomFields.InterfaceCo),
                    getUserId($scope.oriMsgCustomFields.MaintenanceManager),
                    getUserId($scope.oriMsgCustomFields.AssetName),
                ];

                setFormStatus($scope.isRespond ? PAA_CONSTANT.revisedForReview : PAA_CONSTANT.forReview);
                autoDistNumber = $scope.isRespond ? PAA_CONSTANT.resDistNumb : PAA_CONSTANT.oriDistNumb;
                actionValue = PAA_CONSTANT.respondNumber;
            } else {
                autoDistNumber = PAA_CONSTANT.resDistNumb;
                var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                    Name: "Respond"
                });
                var incompleteUserActionIds = spNode && spNode.Value.split('#')[0].split('|');
                incompleteUserActionIds = commonApi._.filter(incompleteUserActionIds, function (user) { return user.trim() != "" && user != dsWorkingUserId && user });
                if ($scope.oriMsgCustomFields.Approval_Grant == 'Reject') {
                    clearUsersAction(incompleteUserActionIds);
                    userTodistribute = [
                        $scope.oriMsgCustomFields.Originator_Id
                    ];
                    setFormStatus(PAA_CONSTANT.rejected);
                    actionValue = PAA_CONSTANT.respondNumber;
                } else if (!incompleteUserActionIds.length) {
                    var allAMTandALTusers = $scope.oriMsgCustomFields.amtUsers.concat($scope.oriMsgCustomFields.altUsers);
                    allAMTandALTusers = commonApi._.map(allAMTandALTusers, function (obj) {
                        return getUserId(obj);
                    })
                    userTodistribute = allAMTandALTusers.concat([
                        $scope.oriMsgCustomFields.Originator_Id
                    ]);
                    setFormStatus(PAA_CONSTANT.Closed);
                    actionValue = PAA_CONSTANT.forInfoNumber;
                }


            }

            if (userTodistribute.length) {
                var actionNodeList = [];
                for (var index = 0; index < userTodistribute.length; index++) {
                    actionNodeList.push({
                        strUser: userTodistribute[index],
                        strAction: actionValue,
                        strDate: $scope.oriMsgCustomFields.Reply_Days
                    });
                }
                commonApi.setDistributionNode({
                    actionNodeList: actionNodeList,
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: autoDistNumber
                });
            }
            // Form's Staus will be set from below code.
            function setFormStatus(currFormStaus) {
                var strFormStatusId = commonApi.getFormStatusId({
                    availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                    strStatus: currFormStaus
                });

                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }

            return false;
        }

        $scope.onContractchange = onContractchange;
        function onContractchange(conVal, onloadFlag) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var strParam = conVal.split('|')[0].trim();
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS, DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS,DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": strParam
                        }]
                    }
                };

                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        $scope.isDataLoaded = true;
                        if (!onloadFlag) {
                            setReplyDays(response);
                            setALTandAMTusers(response);
                        }
                        if ($scope.strFormId) {
                            checkUserCanupdateDraft(response);
                        }
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
                        if ($scope.oriMsgCustomFields.Can_Forward) {
                            var chkPermission = strIsUserDraftOnly(response);
                            if (chkPermission.toLowerCase() == "yes") {
                                setSendPermission("Draft");
                            } else {
                                setSendPermission("Send");
                            }
                        }
                    }
                });

                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[11].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
            }
        }

        function setReplyDays(response) {
            var contractDates = angular.fromJson(response.data['DS_PAA_MPC_NEC_KEY_CONTRACT_DATES']).Items.Item;
            if (contractDates && contractDates.length) {
                var selectedData = commonApi._.filter(contractDates, function (obj) {
                    return obj.Value3.toLowerCase() == PAA_CONSTANT.reponseNotice.toLowerCase();
                })[0];
                $scope.oriMsgCustomFields["Reply_Days"] = selectedData ? selectedData.Value4 : PAA_CONSTANT.defaultReplyDays;
            }
        }

        function strIsUserDraftOnly(response) {
            var contractUsersList = angular.fromJson(response.data['DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
            if (contractUsersList) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < contractUsersList.length; i++) {
                    strValue = contractUsersList[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "alliance_technical_lead") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft" || !$scope.oriMsgCustomFields.Can_Reply) {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }
        function checkUserCanupdateDraft(response){
            var isrequired = CheckPendingAction(dsWorkingUserId);
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft");
            $scope.oriMsgCustomFields.Can_Forward = "No";
            var contractUsersList = angular.fromJson(response.data['DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
            var objData = commonApi._.filter(contractUsersList, function(val) {
                return val.Value.split("|")[2].split("#")[0].trim() == dsWorkingUserId;
            });
            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1";
            }
            if($scope.strIsDraft == "YES"  && isrequired && !strReviewDraft && !$scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "No";
            } else if($scope.strIsDraft == "YES" && !strReviewDraft && $scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
		}
        function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + dsWorkingUserId + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
        }
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.editDraft = "";
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (strNodes) {
                var strUserId = "",
                    strCheckRespond = "";
                for (var i = 0; i < strNodes.length; i++) {
                    $scope.editDraft = "Yes";
                    strUserId = strNodes[i].Value1;
                    strCheckRespond = strNodes[i].Value4;
                    if (strCheckRespond == "Review Draft" && strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }
        function setALTandAMTusers(response) {
            var contractUsers = angular.fromJson(response.data['DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
            if (contractUsers && contractUsers.length) {
                var amtUsers = [];
                var altUsers = []
                for (var index = 0; index < contractUsers.length; index++) {
                    var element = contractUsers[index];
                    if (element.Value) {
                        if (element.Value.toLowerCase().indexOf('alliance_leadership_team') > -1) {
                            altUsers.push(element.Value)
                        } else if (element.Value.toLowerCase().indexOf('alliance_management_team') > -1) {
                            amtUsers.push(element.Value)
                        }
                    }
                }

                $scope.oriMsgCustomFields["altUsers"] = angular.copy(altUsers);
                $scope.oriMsgCustomFields["amtUsers"] = angular.copy(amtUsers);
            }
        }

        function setRolewiseUser(strRole) {
            if (DS_PROJUSERS_ROLE.length) {
                var isContractor = commonApi._.filter(DS_PROJUSERS_ROLE, function (val) {
                    if (val.Value.split('|')[0].trim() == strRole) {
                        return val.Value;
                    }
                });

                var objRecipients = [];
                for (var i = 0; i < isContractor.length; i++) {
                    objRecipients.push({
                        optlabel: "",
                        options: [{
                            displayValue: isContractor[i].Name,
                            modelValue: isContractor[i].Value,
                            checked: false
                        }]
                    });
                }
                if (strRole) {
                    switch (strRole) {
                        case PAA_CONSTANT.ProjectMan:
                            $scope.selectionlist.projectManlist = angular.copy(objRecipients);
                        case PAA_CONSTANT.maintMan:
                            $scope.selectionlist.maintManList = angular.copy(objRecipients);
                        case PAA_CONSTANT.InterfaceCo:
                            $scope.selectionlist.interfaceCoList = angular.copy(objRecipients);
                        case PAA_CONSTANT.assetOwner:
                            $scope.selectionlist.assetOwnerList = angular.copy(objRecipients);
                    }
                }
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            strFormContent = strConAppid + "|";

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        $window.sfcFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not authorised to edit this Draft message. Please click on cancel button to exit.");
					return true;
				}
                if (!$scope.oriMsgCustomFields.Can_Reply) {
                    alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
                    return true;
                }
            }
            setAppWorkFlow();
            setFormContent();
        };
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof sfcFinalCallBack !== "undefined") {
        return sfcFinalCallBack();
    }
}