define(['angular', "mainModule", './base', '../components/item.selection', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, $filter) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		angular.element(".export-btn").hide();
		$scope.isXHRon = false;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.Activities = $scope.oriMsgCustomFields.Activitiy_Group.Activities;
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		$scope.isDSFormId = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] != '');
		$scope.isEditORI = ($scope.isDSFormId && ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'NO'));
		$scope.ITPFormList = $scope.getValueOfOnLoadData('DS_MTA_CheckList_ITP_FormDetail');
		$scope.TaskFormList = $scope.getValueOfOnLoadData('DS_MTA_Task_FormDetail');
		
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			STATIC_OBJ = {
				activity: {
					"Activity_No": "",
					"Activity_GUID": "",
					"Activity_Name": "",
					"Acceptance_Criteria": "",
					"Activity_Type": "",
					"is_holdPoint": false,
					"Observation": {
						"control": "",
						"is_number_control": false,
						"is_range_control": false,
						"is_required": false,
						"optionsGroup": {
							"options": [{
								"Label": "",
								"Value": ""
							}]
						},
						"field_label": "",
						"field_name": "",
						"value": "",
						"min_field_label": "",
						"max_field_label": "",
						"min_field_name": "",
						"max_field_name": "",
						"min_value": "",
						"max_value": "",
						"min_valid_value": "",
						"max_valid_value" : ""
					},
					"sectionType": "",
					"comments": ""
				},
				activityPhotos: {
					attachedDocs: ''
				},
				taskFormAutoCreateNode: {
					ACF_01_DS_Logo: '',
					ACF_01_ActivityId: '',
					ACF_01_ORI_FORMTITLE: '',
					ACF_01_DS_FORMTITLE: '',
					ACF_01_Task_Type: 'ITC',
					ACF_01_CREATED_BY: '',
					ACF_01_Task_Detail: '',
					ACF_01_DS_CLOSE_DUE_DATE: '',
                    ACF_01_Task_Assigned_TO: '',
					ACF_01_Task_Verification_Required: '',
					ACF_01_Task_Reference: '<<DS_Form_ID>>',
					ACF_01_LastReviewer: '',
					ACF_01_CurrStage: '2', 
					ACF_01_DS_FORMCONTENT1: '<<DS_Form_ID>>',
                    ACF_01_DS_FORMCONTENT2: '',
					ACF_01_DS_AUTODISTRIBUTE: '3',
					ACF_01_AUTOCREATE_INDEX: '',
                    ACF_01_REPEATING_VALUES: {
                        ACF_01_DS_AutoDistribute_User_Group: {
                            ACF_01_DS_AutoDistribute_Users: [{
                                ACF_01_DS_PROJDISTUSERS: '',
                                ACF_01_DS_FORMACTIONS: '',
                                ACF_01_DS_ACTIONDUEDATE: '',
                                ACF_01_DS_DUEDAYS: ''
                            }]
                        }
                    }
				}
			},
			WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID'),
			DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'),
			DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_WS_STATUS'),
			mtaHeaderDetails = $scope.getValueOfOnLoadData("DS_MTA_PSR_Header_Details");
		
			var timeZoneMap = {
				"Africa/Bangui": "W. Central Africa Standard Time",
				"Africa/Cairo": "Egypt Standard Time",
				"Africa/Casablanca": "Morocco Standard Time",
				"Africa/Harare": "South Africa Standard Time",
				"Africa/Johannesburg": "South Africa Standard Time",
				"Africa/Lagos": "W. Central Africa Standard Time",
				"Africa/Monrovia": "Greenwich Standard Time",
				"Africa/Nairobi": "E. Africa Standard Time",
				"Africa/Windhoek": "Namibia Standard Time",
				"America/Anchorage": "Alaskan Standard Time",
				"America/Argentina/San_Juan": "Argentina Standard Time",
				"America/Asuncion": "Paraguay Standard Time",
				"America/Bahia": "Bahia Standard Time",
				"America/Bogota": "SA Pacific Standard Time",
				"America/Buenos_Aires": "Argentina Standard Time",
				"America/Caracas": "Venezuela Standard Time",
				"America/Cayenne": "SA Eastern Standard Time",
				"America/Chicago": "Central Standard Time",
				"America/Chihuahua": "Mountain Standard Time (Mexico)",
				"America/Cuiaba": "Central Brazilian Standard Time",
				"America/Denver": "Mountain Standard Time",
				"America/Fortaleza": "SA Eastern Standard Time",
				"America/Godthab": "Greenland Standard Time",
				"America/Guatemala": "Central America Standard Time",
				"America/Halifax": "Atlantic Standard Time",
				"America/Puerto_Rico": "Atlantic Standard Time",
				"America/Indianapolis": "US Eastern Standard Time",
				"America/Indiana/Indianapolis": "US Eastern Standard Time",
				"America/La_Paz": "SA Western Standard Time",
				"America/Los_Angeles": "Pacific Standard Time",
				"America/Mexico_City": "Mexico Standard Time",
				"America/Montevideo": "Montevideo Standard Time",
				"America/New_York": "Eastern Standard Time",
				"America/Noronha": "Fernando de Noronha Time",
				"America/Phoenix": "US Mountain Standard Time",
				"America/Regina": "Canada Central Standard Time",
				"America/Santa_Isabel": "Pacific Standard Time (Mexico)",
				"America/Santiago": "Pacific SA Standard Time",
				"America/Sao_Paulo": "Brazil Time",
				"America/St_Johns": "Newfoundland Standard Time",
				"America/Tijuana": "Pacific Standard Time",
				"Antarctica/McMurdo": "New Zealand Standard Time",
				"Atlantic/South_Georgia": "UTC-02",
				"Asia/Almaty": "Central Asia Standard Time",
				"Asia/Amman": "Jordan Standard Time",
				"Asia/Baghdad": "Arabia Standard Time",
				"Asia/Baku": "Azerbaijan Standard Time",
				"Asia/Bangkok": "SE Asia Standard Time",
				"Asia/Beirut": "Middle East Standard Time",
				"Asia/Calcutta": "India Standard Time",
				"Asia/Colombo": "Sri Lanka Standard Time",
				"Asia/Damascus": "Syria Standard Time",
				"Asia/Dhaka": "Bangladesh Standard Time",
				"Asia/Dubai": "Gulf Standard Time",
				"Asia/Irkutsk": "North Asia East Standard Time",
				"Asia/Jerusalem": "Israel Standard Time",
				"Asia/Kabul": "Afghanistan Standard Time",
				"Asia/Kamchatka": "Kamchatka Standard Time",
				"Asia/Karachi": "Pakistan Standard Time",
				"Asia/Katmandu": "Nepal Standard Time",
				"Asia/Kolkata": "India Standard Time",
				"Asia/Krasnoyarsk": "North Asia Standard Time",
				"Asia/Kuala_Lumpur": "Singapore Standard Time",
				"Asia/Kuwait": "Arab Standard Time",
				"Asia/Magadan": "Magadan Standard Time",
				"Asia/Muscat": "Arabian Standard Time",
				"Asia/Novosibirsk": "N. Central Asia Standard Time",
				"Asia/Oral": "West Asia Standard Time",
				"Asia/Rangoon": "Myanmar Standard Time",
				"Asia/Riyadh": "Arab Standard Time",
				"Asia/Seoul": "Korea Standard Time",
				"Asia/Shanghai": "China Standard Time",
				"Asia/Singapore": "Singapore Standard Time",
				"Asia/Saigon": "Indochina Time",
				"Asia/Taipei": "Taipei Standard Time",
				"Asia/Tashkent": "West Asia Standard Time",
				"Asia/Tbilisi": "Georgian Standard Time",
				"Asia/Tehran": "Iran Standard Time",
				"Asia/Tokyo": "Japan Standard Time",
				"Asia/Ulaanbaatar": "Ulaanbaatar Standard Time",
				"Asia/Vladivostok": "Vladivostok Standard Time",
				"Asia/Yakutsk": "Yakutsk Standard Time",
				"Asia/Yekaterinburg": "Ekaterinburg Standard Time",
				"Asia/Yerevan": "Armenian Standard Time",
				"Atlantic/Azores": "Azores Standard Time",
				"Atlantic/Cape_Verde": "Cape Verde Standard Time",
				"Atlantic/Reykjavik": "Greenwich Standard Time",
				"Australia/Adelaide": "Cen. Australia Standard Time",
				"Australia/Brisbane": "E. Australia Standard Time",
				"Australia/Darwin": "AUS Central Standard Time",
				"Australia/Hobart": "Eastern Standard Time (Tasmania)",
				"Australia/Perth": "W. Australia Standard Time",
				"Australia/Sydney": "Eastern Standard Time (New South Wales)",
				"Australia/Canberra": "Eastern Standard Time (New South Wales)",
				"Australia/Melbourne": "AUS Eastern Standard Time",
				"Etc/GMT": "UTC",
				"Etc/GMT+11": "UTC-11",
				"Etc/GMT+12": "Dateline Standard Time",
				"Etc/GMT+2": "UTC-02",
				"Etc/GMT-12": "UTC+12",
				"Europe/Amsterdam": "W. Europe Standard Time",
				"Europe/Athens": "GTB Standard Time",
				"Europe/Belgrade": "Central Europe Standard Time",
				"Europe/Berlin": "W. Europe Standard Time",
				"Europe/Brussels": "Central European Time",
				"Europe/Budapest": "Central Europe Standard Time",
				"Europe/Dublin": "GMT Standard Time",
				"Europe/Helsinki": "FLE Standard Time",
				"Europe/Istanbul": "Eastern European Time",
				"Europe/Kiev": "FLE Standard Time",
				"Europe/London": "GMT Standard Time",
				"Europe/Minsk": "E. Europe Standard Time",
				"Europe/Moscow": "Russian Standard Time",
				"Europe/Paris": "Central European Time",
				"Europe/Sarajevo": "Central European Standard Time",
				"Europe/Warsaw": "Central European Standard Time",
				"Europe/Lisbon": "Western European Time",
				"Indian/Mauritius": "Mauritius Standard Time",
				"Pacific/Apia": "West Samoa Time",
				"Pacific/Auckland": "New Zealand Standard Time",
				"Pacific/Fiji": "Fiji Standard Time",
				"Pacific/Guadalcanal": "Solomon Islands Time",
				"Pacific/Guam": "Chamorro Standard Time",
				"Pacific/Honolulu": "Hawaiian Standard Time",
				"Pacific/Pago_Pago": "Samoa Standard Time",
				"Pacific/Port_Moresby": "Papua New Guinea Time",
				"Pacific/Tongatapu": "Tonga Standard Time",
				"Pacific/Midway": "Samoa Standard Time",
				"Pacific/Enderbury": "Phoenix Is. Time",
				"Pacific/Kiritimati": "Line Islands Standard Time"
			};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		
		if($scope.isOriPrintView){
			// adding task url in Activity 
			if($scope.TaskFormList.length){
				angular.forEach($scope.Activities, function(item){
					if(item.sectionType != 'Section'){
						angular.forEach($scope.TaskFormList, function(taskItem){
							if(taskItem.Value22 && taskItem.Value22.split('---')[0] == item.Activity_GUID){
								item.TaskUrl = taskItem.URL3;
							}
						});
					}
				});

				$timeout(function () {
					angular.forEach($scope.Activities, function(item){
						if(item.TaskUrl && angular.element('#'+item.Activity_GUID)[0]){
							angular.element('#'+item.Activity_GUID)[0].href = item.TaskUrl;
						}
					});
				}, 500);
			}
		}
		$scope.onItpSlectionChange = function(){
			if(!$scope.oriMsgCustomFields.ITP_Id){
				$scope.Activities = [];
				$scope.oriMsgCustomFields.Activitiy_Group.Activities = $scope.Activities;
				return;
			}
			$scope.getActivityList($scope.oriMsgCustomFields.ITP_Id);
		};

		$scope.onITCStatusChange = function(){
			var hasAnyFailActivity;
			if($scope.oriMsgCustomFields.ITC_Status.toLowerCase() == 'completed'){
				$scope.Activities.forEach(function(item){
					if((item.sectionType.toLowerCase() != 'section') && (item.ActivityCompleted.toLowerCase() != 'pass' && item.ActivityCompleted.toLowerCase() != 'n/a' )){
						hasAnyFailActivity = true;
					}
				});
				if(hasAnyFailActivity){
					alert('All activities should be completed (Pass or N/A) in order to complete the inspection');
					$scope.oriMsgCustomFields.ITC_Status = "In Progress";
				}
			}
		};

		$scope._onObrRadioChange = function(rowObrItem, option){
			if(rowObrItem.value){
				rowObrItem.selectedRadioLabel = option.Label;
			}else{
				rowObrItem.selectedRadioLabel = "";
			}
		};

		/***
		 * Parmas: Stauts of activity, activity item, prev status
		 * Reset status of activity if is after hold point and till hold point some activity is false
		 */
		$scope.onActStatusChange = function(actStatus, recordItem, prevValue){
			var HoldPointGot, hasAnyFail, _isRadioSelectedAfterHold, confirmResult, HoldPointIndex=-1, hasAnyFailIndex=-1;
			if(!passActIfNotClosed(actStatus, recordItem, prevValue)){
				// when task of respected activity is not closed and selected status is pass
				return;
			}
			for(var i = 0; i < $scope.Activities.length; i++){
				if($scope.Activities[i].sectionType != 'Section'){
					if((hasAnyFailIndex <= HoldPointIndex)  && hasAnyFail && HoldPointGot && $scope.Activities[i].ActivityCompleted.toLowerCase()){
						_isRadioSelectedAfterHold = true;
					}
					if($scope.Activities[i].ActivityCompleted.toLowerCase() != 'pass' && $scope.Activities[i].ActivityCompleted.toLowerCase() != 'n/a'){
						hasAnyFail = true;
						if(hasAnyFailIndex == -1){
							hasAnyFailIndex = i;
						}
					}
					if($scope.Activities[i].is_holdPoint && $scope.Activities[i].is_holdPoint != 'false'){
						HoldPointGot = true;
						HoldPointIndex = i;
					}
				}
			}
			// to check if fail any activity before some activity completed then reset that activity
			if(_isRadioSelectedAfterHold){
				confirmResult = confirm("Your Result After Hold point Will be reset! \n Are You Sure?");
				if (confirmResult) {
					radioDisableAfterHold(true);
					setCheckboxValidation(actStatus, recordItem.Observation);
					recordItem.Date_Act_status_Change = $scope.getDateFromZone();
				} else {
					recordItem.ActivityCompleted = prevValue;
				}
			}else{
				radioDisableAfterHold();
				setCheckboxValidation(actStatus, recordItem.Observation);
				recordItem.Date_Act_status_Change = $scope.getDateFromZone();
			}
		};

		function passActIfNotClosed(actStatus, recordItem, prevValue){
			if((actStatus.toLowerCase() == 'pass' || actStatus.toLowerCase() == 'n/a') && (prevValue.toLowerCase() == 'fail' || prevValue.toLowerCase() == '')){
				if($scope.TaskFormList.length){
					var matchedTask = commonApi._.find($scope.TaskFormList, function (obj) {
						if(obj.Value22 && obj.Value22.split('---')[0].trim() === recordItem.Activity_GUID){
							return obj;
						}
					});
					if(matchedTask && matchedTask.Value11){
						if(matchedTask.Value11.split("|")[1] && matchedTask.Value11.split("|")[1].trim().toLowerCase() == "closed"){
							return true;
						}else{
							alert('In order to mark the activity as Passed / NA all associated Tasks need to be completed');
							recordItem.ActivityCompleted = prevValue;
							return false;
						}
					}
				}
			}
			return true;
		}

		/***
		 * Resets activity result after hold point if above activity is changed to fail
		 * disable radio button after hold point if hold point is not cleared 
		 * sets holdpointcleared hold point is cleared
		 */
		function radioDisableAfterHold(_resetActivityResult){
			var hasAnyFail, HoldPointGot, hasAnyFailIndex = -1, HoldPointIndex = -1, isHoldPoint;
			angular.forEach($scope.Activities, function(item, index){
				if(item.sectionType != 'Section'){
					isHoldPoint =  item.is_holdPoint && item.is_holdPoint != 'false';
					if(hasAnyFail && HoldPointGot && (hasAnyFailIndex <= HoldPointIndex) ){
						item.DisableRadio = true;
						if(_resetActivityResult){
							item.ActivityCompleted = '';
						}
					}else{
						item.DisableRadio = false;
					}
					if(item.ActivityCompleted.toLowerCase() != 'pass' && item.ActivityCompleted.toLowerCase() != 'n/a'){
						hasAnyFail = true;
						if(hasAnyFailIndex == -1){
							hasAnyFailIndex = index;
						}
					}
					if(isHoldPoint){
						HoldPointGot = true;
						HoldPointIndex = index;
					}
					//to set hold point isCleared if hold point above or hold activity is cleared
					if(isHoldPoint){
						if(hasAnyFail && HoldPointGot && (hasAnyFailIndex <= HoldPointIndex)){
							item.holdCleared = false;
						}else{
							item.holdCleared = true;
						}
					}
				}
			});
		}

		$scope.onObrCheckboxCHange = function(actStatus, observation){
			setCheckboxValidation(actStatus, observation);
		};

		var setCheckboxValidation = function(actStatus, observation){
			if(actStatus.toLowerCase() == 'pass'){
				var selectedOp = commonApi._.find(observation.optionsGroup.options, function(item){
						return item.Selected;
					});
				if(selectedOp){
					observation._checkboxReq = false;
				}else{
					observation._checkboxReq = true;
				}
			}else{
				observation._checkboxReq = false;
			}
		};

		$scope.getActivityList = function (ITP_Id) {
			if (!ITP_Id)
			  return;
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": "DS_MTA_CheckList_ITP_Activities",
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": "DS_MTA_CheckList_ITP_Activities",
						"fieldValue": ITP_Id.split('|')[0].trim()
					}]
				}
			};
			$scope.isXHRon = true;
			$scope.getCallbackData(form).then(function (response) {
				var activitesList = angular.fromJson(response.data['DS_MTA_CheckList_ITP_Activities']).Items.Item;

				if(activitesList){
					addActivitiesTOList(activitesList);
				}
				$scope.isXHRon = false;
			});
		};
		function addActivitiesTOList(activitesList){
			var Activities = [];
			var finalActivities = [];
			var HoldPointGot = false;
			angular.forEach(activitesList, function (item, index) {
				var number_control = item.Value14 && item.Value14 != 'false' ? true : false;
				var range_control = item.Value19 && item.Value19 != 'false' ? true : false;
				var isHoldPoint = item.Value8 && item.Value8 != 'false' ? true : false;
				var activity = {
					"Activity_No": item.Value26,
					"Activity_GUID": item.Value3,
					"Activity_Name": item.Value4,
					"Acceptance_Criteria": item.Value5,
					"Spec_Standard_Ref": item.Value6,
					"Frequency": item.Value25,
					"Activity_Type": item.Value7,
					"is_holdPoint": isHoldPoint,
					"Observation": {
						"control": item.Value13,
						"is_number_control": number_control,
						"is_range_control": range_control,
						"is_required": item.Value20,
						"optionsGroup": {
							"options": []
						},
						"checkbox_value": item.Value21,
						"field_label": item.Value11,
						"field_name": item.Value17,
						"value": item.Value23,
						"min_field_label": item.Value12,
						"max_field_label": item.Value9,
						"min_field_name": item.Value10,
						"max_field_name": item.Value22,
						"min_value": item.Value18,
						"max_value": item.Value24,
						"min_valid_value": item.Value15,
						"max_valid_value": item.Value16,
						"AddRemarks": item.Value30
					},
					"sectionType": item.Value29,
					"comments": "",
					"ActivityCompleted": "",
					"attachements": [{
						"attachedDocs" : ""
					}]
				};
				Activities.push(activity);
			});
			finalActivities = commonApi._.uniq(Activities, function(item){
				return item.Activity_GUID;
			});
			var Grouped = commonApi._.groupBy(activitesList, function(item){
				return item.Value3;
			});
			angular.forEach(finalActivities, function(finalItem){
				finalItem.DisableRadio = HoldPointGot;
				if(finalItem.is_holdPoint && finalItem.is_holdPoint != 'false'){
					HoldPointGot = true;
				}
				var groupedItem = Grouped[finalItem.Activity_GUID];
				if(groupedItem && groupedItem.length) {
					for(var i = 0; i < groupedItem.length; i++){
						finalItem.Observation.optionsGroup.options.push({
							"Label": groupedItem[i].Value27,
							"Value": groupedItem[i].Value28
						});
					}
				}
			});
			$scope.Activities = finalActivities;
			$scope.oriMsgCustomFields.Activitiy_Group.Activities = $scope.Activities;
			$scope.expandTextAreaOnLoad();
		}

		$scope.addNewItem = function (list, addItemFor) {
			$scope.addRepeatingRow(list, angular.copy(STATIC_OBJ[addItemFor]));
		};
		$scope.deleteItem = function (list, index) {
			list.splice(index, 1);
		};

		$scope.scrollTOListItem = function (eID) {
            if (eID !== '') {
                $timeout(function () {
                    var newId = "#ID_" + eID;
                    var offset = $(newId).offset();
                    if (offset) {
                        var scrollTotal = offset.top - 100;
                        $('html,body').animate({
                            scrollTop: scrollTotal
                        }, 500);
                    }
                }, 500);
            }
        };

		function structureItemList(availList, setFor){
			var tempList = [];
			var displayVal, modelVal;
			switch (setFor) {
				case "ITP-LIST":
					angular.forEach(availList, function (item) {
						displayVal = item.Value3 + ' (' + item.Value4 + ')';
						modelVal = item.Value1 + ' | ' + displayVal;
						tempList.push({
							displayValue: displayVal,
							modelValue: modelVal
						});
					});
				break;
			}
			return [{
				options: tempList
			}];
		}

		if($scope.isOriView){
			var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo'),
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			setBasicList();
			setClientlogo();
			if(!$scope.isEditORI){
				$scope.ITPList = structureItemList($scope.ITPFormList,  'ITP-LIST');
				setPsrProjectDetails();
			}
		}

		function setBasicList(){
			$scope.projUserList = commonApi.getItemSelectionList({
				arrayObject: projAllRolesList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
		}

		function setPsrProjectDetails() {
            if(!mtaHeaderDetails || !mtaHeaderDetails.length){
                return;
            }
            mtaHeaderDetails = mtaHeaderDetails[0];
            $scope.projectDetails.Planning_Number = mtaHeaderDetails.Value2;
            $scope.projectDetails.ProgramManager = mtaHeaderDetails.Value3;
            $scope.projectDetails.ProjectPSE = mtaHeaderDetails.Value4;
            $scope.projectDetails.ProjectDescr = mtaHeaderDetails.Value5;
            $scope.projectDetails.KeyProject = mtaHeaderDetails.Value6;
            $scope.projectDetails.ConstructionMgr = mtaHeaderDetails.Value7;
            $scope.projectDetails.ProjectStatus = mtaHeaderDetails.Value8;
            $scope.projectDetails.ProjectPhase = mtaHeaderDetails.Value9;
            $scope.projectDetails.ProgramOfficer = mtaHeaderDetails.Value10;
        }
		function setClientlogo() {
            if (WorkingUserID.length) {
				var strOrgName = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
		}
		
		function getDateTimeFromZone() {
			var userTimeZone = timeZoneMap[$window.USP.timezoneId];
			var serverDatemilisec = new Date($scope.serverDate).getTime();
			var utcActualTime = serverDatemilisec - 3600000;
            var offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            var nd = new Date(parseInt(utcActualTime) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
            return nd + " " + userTimeZone;
		}

		$scope.getDateFromZone = function(){
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}

		function setAutocreateNodes(activites){
			var autoCrtIndex = 0;
			var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : 'open'
			});
            if (activites.length) {
				var newTaskNode = {},
					Workinguser = WorkingUserID['0'].Value.trim(),
                    strAction = '3#',
                    strDuedays = '';
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
                for (var i = 0; i < activites.length; i++) {
                    if(activites[i].TaskCreated =='1' || activites[i].ActivityCompleted != 'Fail'){
						continue;
					}
					var TaskDays = !isNaN(activites[i].TaskDays) && parseInt(activites[i].TaskDays) || 3;
                    newTaskNode = angular.copy(STATIC_OBJ.taskFormAutoCreateNode);
                    strDuedays = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.getDateFromZone(),
                        days: TaskDays
					});
					activites[i].TaskCreated ="1";
					autoCrtIndex = autoCrtIndex + 1;
					newTaskNode.ACF_01_DS_Logo = $scope.oriMsgCustomFields.DS_Logo;
					newTaskNode.ACF_01_ActivityId = activites[i].Activity_GUID + '---' + activites[i].Activity_No;
					newTaskNode.ACF_01_ORI_FORMTITLE = activites[i].TaskName;
					newTaskNode.ACF_01_DS_FORMTITLE = activites[i].TaskName;
					newTaskNode.ACF_01_Task_Type = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMGROUPNAME;
					newTaskNode.ACF_01_Task_Detail = activites[i].TaskDetails;
					newTaskNode.ACF_01_DS_CLOSE_DUE_DATE = strDuedays;
					newTaskNode.ACF_01_Task_Assigned_TO = activites[i].TaskAssignedTO;
					newTaskNode.ACF_01_CREATED_BY = Workinguser.split('|')[0].trim();
					newTaskNode.ACF_01_Task_Verification_Required =  activites[i].TaskVerificationRequired || 'No';
					newTaskNode.ACF_01_Task_Reference =  '<<DS_Form_ID>>';
					newTaskNode.ACF_01_LastReviewer =  Workinguser;
					newTaskNode.ACF_01_CurrStage =  '2';
					newTaskNode.ACF_01_DS_FORMCONTENT1 =  '<<DS_Form_ID>>';
					newTaskNode.ACF_01_DS_AUTODISTRIBUTE =  '3';
					newTaskNode.ACF_01_DS_FORMCONTENT2 =  activites[i].Activity_GUID;
					newTaskNode.ACF_01_DS_ALL_FORMSTATUS = strFormStatusId.split('#')[0].trim();
					newTaskNode.ACF_01_DS_Ref_AppId = $window.AppBuilderFormIDCode;
					newTaskNode.ACF_01_AUTOCREATE_INDEX = autoCrtIndex;
					newTaskNode.ACF_01_RaisedOnDate = getDateTimeFromZone();
					newTaskNode.ACF_01_Planning_Number = $scope.projectDetails.Planning_Number;
					newTaskNode.ACF_01_ProgramManager = $scope.projectDetails.ProgramManager;
					newTaskNode.ACF_01_ProjectPSE = $scope.projectDetails.ProjectPSE;
					newTaskNode.ACF_01_ProjectDescr = $scope.projectDetails.ProjectDescr;
					newTaskNode.ACF_01_KeyProject = $scope.projectDetails.KeyProject;
					newTaskNode.ACF_01_ConstructionMgr = $scope.projectDetails.ConstructionMgr;
					newTaskNode.ACF_01_ProjectStatus = $scope.projectDetails.ProjectStatus;
					newTaskNode.ACF_01_ProjectPhase = $scope.projectDetails.ProjectPhase;
					newTaskNode.ACF_01_ProgramOfficer = $scope.projectDetails.ProgramOfficer;
                    var childNodes = newTaskNode.ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users;
                    if (childNodes && childNodes.length) {
                        for (var j = 0; j < childNodes.length; j++) {
                            childNodes[j].ACF_01_DS_PROJDISTUSERS = activites[i].TaskAssignedTO.split('|')[2].split('#')[0].trim();
                            childNodes[j].ACF_01_DS_FORMACTIONS = strAction;
							childNodes[j].ACF_01_DS_ACTIONDUEDATE = strDuedays;
							childNodes[j].ACF_01_DS_DUEDAYS = TaskDays;
                        }
                    }
                    $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);
                }
            }
        }

		function setFormWorkflow(){
			$scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
			setAutocreateNodes($scope.Activities);
		}

		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}


		$scope.update();

		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView){
				if(!$scope.submitFlag){
					$scope.getServerTime(function (serverDate) {// called here to set very lattest server time and date 
						$scope.serverDate = serverDate;
						$scope.submitFlag = true;
						$window.submitForm(1);
					});
					return true;
				}
				if($scope.oriMsgCustomFields.ITP_Id){
					$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.oriMsgCustomFields.ITP_Id.split("|")[1].trim() + " :: " + $scope.oriMsgCustomFields.Location;
				}
				setFormWorkflow();
				$scope.onITCStatusChange();
				if($scope.oriMsgCustomFields.ITC_Status.toLowerCase() == 'completed'){
					updateFormStatus('completed');
				}else{
					updateFormStatus('in Progress');
				}
			}
			return false;
		};

		$window.draftSubmitCallBack = function () {
			return false;
		};
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}