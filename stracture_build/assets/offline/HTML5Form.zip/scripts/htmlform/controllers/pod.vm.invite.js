define(['angular', './base', '../components/folder.selection', '../components/item.selection'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});

		var ctrl = this;
		var orgId = '';
		var email = '';
		var sendObj = {};
		$scope.invitationRoleName = '';
		$scope.companyName = undefined;
		$scope.clickSave = false;
		$scope.disableButton = false;
		$scope.subject = undefined;
		$scope.isAcceptReject = true;
		$scope.senderLogoURL = '';
		$scope.isStatus = false;
		$scope.isSenderLogoURL = true;
		$scope.statusValue = '';
		$scope.weightageId = '';
		$scope.weightageFormId = '';
		$scope.isSameOrg = false;
		$scope.dsMktWtgDetails = $scope.getValueOfOnLoadData('DS_MKT_WTG_DETAILS');
		ctrl.$onInit = function () {
			$scope.update();
			var iframeUrl = decodeURIComponent($window.location.href);
			var dataString = iframeUrl.split('?');
			var data = $scope.getFormData();
			$scope.senderLogoURL = data.senderLogoURL;
			if ($scope.senderLogoURL == "marketimages/no_company_logo.jpg") {
				$scope.isSenderLogoURL = false;
			}
			
			var isAcceptRejectValue = $scope.getValueOfOnLoadData('DS_CHECK_RECIPIENT_TO_APPROVE');
			if (isAcceptRejectValue.length && isAcceptRejectValue[0].Value == "True") {
				$scope.isAcceptReject = true;
			} else {
				$scope.isAcceptReject = false;
			}
			if (dataString[1]) {
				var dataArray = dataString[1].split('&');
				var tempCompanyName = (dataString[1].split('companyName=')[1] || '');
				$scope.companyName = tempCompanyName.split("&bfpc")[0];
				for (var i = 0; i < dataArray.length; i++) {
					if (dataArray[i].indexOf('orgId') > -1) {
						orgId = dataArray[i].split('=')[1];
					}
					if (dataArray[i].indexOf('email') > -1) {
						email = dataArray[i].split('=')[1];
					}
				}
			} else {
				$scope.weightageId = data.weightageId;
				$scope.weightageFormId = data.weightageFormId;
				$scope.companyName = data.companyName;
				$scope.subject = data.subject;
				$scope.descripation = data.message;
			}
			$scope.invitationRoleName = data.invitationRoleName;
			$scope.acceptStatusName = data.accept;
			$scope.rejectStatusName = data.reject;
			if ($window.currentViewName == "ORI_PRINT_VIEW") {
				if(USP.orgID == data.buyerOrgId){
					$scope.isSameOrg = true;
				}
				var dsMktWtgUrlDTLS = $scope.getValueOfOnLoadData('DS_MKT_WTG_URL_DTLS');
				$scope.weightageURL =  dsMktWtgUrlDTLS[0] && dsMktWtgUrlDTLS[0].URL2
				getStatus();
			}

		}
		var getStatus = function () {
			var hashedFormId = $("input[name ='formId']").val();
			var hashedProjectId = $("input[name ='projectId']").val();
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/getPrequalLinkDetails?project_id=" + hashedProjectId + "&form_id=" + hashedFormId,
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				if (response.data) {
					if (!response.data.validLink) {
						$scope.isAcceptReject = false;
						if (response.data.accept) {
							$scope.statusValue = 'ACCEPTED';
							$scope.isStatus = true;
						} else {
							$scope.statusValue = 'REJECTED';
							$scope.isStatus = true;
						}
					}

				}
			}, function () {

			});
		}

		$scope.setFormId = function(){
			for (var index = 0; index < $scope.dsMktWtgDetails.length; index++) {
				var element = $scope.dsMktWtgDetails[index];
				if(element.Value2 === $scope.weightageId){
					$scope.weightageFormId = element.Value4;
				}
			}
		}

		$scope.closePreQualificationFormModal = function (e) {
			var obj = { 'message': 'closeModal' };
			window.top.postMessage(JSON.stringify(obj), "*");
			window.close();
			if ($scope.companyName == '') {
				$window.top.postMessage("closeCreateFormIframe:-1",'*')
			}
		}
		$scope.sendData = function (e) {
			$scope.clickSave = true;
			sendObj.ORI_FORMTITLE = $scope.subject;
			sendObj.message = $scope.descripation;
			sendObj.companyName = $scope.companyName;
			sendObj.invitationRoleName = $scope.invitationRoleName;
			sendObj.acceptStatusName = $scope.acceptStatusName;
			sendObj.rejectStatusName = $scope.rejectStatusName;
			sendObj.weightageFormId = $scope.weightageFormId;
			sendObj.weightageId = $scope.weightageId;
			window.top.postMessage(JSON.stringify(sendObj), "*");
		}

		$scope.acceptReject = function (isAccept) {
			$scope.disableButton = true;
			if (isAccept) {
				$(".accept").text("Accept...");
			} else {
				$(".reject").text("Reject...")
			}
			var hashedFormId = $("input[name ='formId']").val();
			var hashedProjectId = $("input[name ='projectId']").val();
			var hformTypeId = $("input[name ='formTypeId']").val();
			hformTypeId = hformTypeId && hformTypeId.split('$$')[0];
			var statusName = $scope.acceptStatusName;
			if (!isAccept) {
				statusName = $scope.rejectStatusName;
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/processPrequalLink",
				method: 'post',
				withCredentials: true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
				data: {
					hashedFormId: hashedFormId,
					hashedProjectId: hashedProjectId,
					isAccept: isAccept,
					formTypeId: hformTypeId,
					settingTypeId: 1,
					statusName: statusName,
					weightageId: $scope.weightageFormId
				}
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					if (response.data.prequalLink) {
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.location = response.data.prequalLink;
					} else {
						alert(response.data.linkStatus);
						if (window.top && window.top.opener) {
							window.top.opener.postMessage(JSON.stringify(sendObj), "*");
							window.close();
						} else {
							window.location = top.marketPlaceServiceURL+"?origin=true";
						}
					}
				}
			}, function () {
				$scope.clickApprove = false;
				$scope.disableButton = false;
				//alert("Error In Evalution Submit");
			});
		}
	}
	return FormController;
});