/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, $filter, htmlformservice, myConfig) {
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});
		$window._isOffline = false;
		// restrict autosave Draft
		$scope.stopAutoSaveDraftTimerFromClientSide();
				
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		
		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.dSIsDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.isRespPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		var WorkPackageTypes = $scope.getValueOfOnLoadData('DS_getDefectTypesForProjects_pf');
		$scope.AllLocation = $scope.getValueOfOnLoadData('DS_getAllLocationByProject_PF');
		$scope.allActiveFormStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var recentDefectObj = $scope.getValueOfOnLoadData('DS_SNG_AUS_GET_RECENT_DEFECTS');
		var formPermissionObj = $scope.getValueOfOnLoadData('DS_CHECK_FORM_PERMISSION_USER');
		var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
		$scope.canCopyDefect = formPermissionObj && formPermissionObj.length && formPermissionObj[0].Value4 == 'Yes'; 
		$scope.recentDefectsList = [];
		$scope.recentdefectCaption = "Please Select...";
		var tempAssignedToRole = $scope.oriMsgCustomFields.AssignedToRole;
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			CONSTANTS_OBJ = {
				LOCATION_LABEL: "Location List",
				IMAGE_ASITE_DEFAULT_STR: '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR: 'images/asite.gif',
				LOCATION: "Location",
				ROLES_LIST: "Roles list",
				STATUS_LIST: "Status list",
				SUBCONTRACTOR: "subcontractor",
				ISSUE_Type: "issue type",
				ROOT_CAUSE: "root cause",
				WORKPACKAGE: "workpackage",
				FIELD_INSPECTOR: "Field Inspector",
				THUMBNAIL_VIEW_PATH: "/commonapi/thumbnail/viewThumb",
				RES_ACTION: "3#Respond",
				FOR_INFO: "7#",
				RES_ACTION_CODE: "411",
				ORI_ACTION_CODE: "401",
				StartWithRole: "Defect"
			},
			STATIC_OBJ = {
				autocompleteMsgStructure: {
					DS_MSG_AC_TYPE: "",
					DS_MSG_AC_FORM: "",
					DS_MSG_AC_MSG_TYPE: "",
					DS_MSG_AC_USERID: "",
					DS_MSG_AC_ACTION: "",
					DS_MSG_AC_ACTION_REMARKS: ""
				}
			};

		$scope.isOffline = $window._isOffline;
		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
		});
		// set default start date 
		if(!$window._isOffline && $scope.isOriView && !$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no"){
			$scope.oriMsgCustomFields.StartDate = getDateFromZone();
			$scope.oriMsgCustomFields.StartDateDisplay = $scope.formatDate(new Date(getDateFromZone()), 'dd-M-yy');
		}

		if ($window._isOffline && $scope.isOriView && !$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no") {
			if(objConfigData.todaysDate){
				// reversing date because getting in dd-mm-yyyy format
				var todaysDate = objConfigData.todaysDate.split("-").reverse().join("-");
				$scope.oriMsgCustomFields.StartDate =  $scope.formatDate(new Date(todaysDate), 'yy-mm-dd');
				$scope.oriMsgCustomFields.StartDateDisplay = $scope.formatDate(new Date(todaysDate), 'dd-M-yy');
			}
			if(objConfigData.formCreationDate){
				$scope.oriMsgCustomFields.FormCreationDate = objConfigData.formCreationDate;
			}
		}

		var showHideTooltipDueDate = function () {
			if($window.showHideTooltipDueDateCalled){
				return;
			}
			$window.showHideTooltipDueDateCalled = true;
			angular.element('body').on('click', function (event) {
				if(!angular.element('#expdueDateInfoIcon').length){
					return;
				}
				var $eventTarget = angular.element(event.target),
					targetId = event.target.id,
					targetParentId = event.target.parentElement.id,
					clickedOnIcon;
	
					if(targetId == 'expdueDateInfoIcon' || targetParentId == 'expdueDateInfoIcon'){
						clickedOnIcon = true;
						if(angular.element('.exp-due-date-wrapper').hasClass('showTooltip')){
							angular.element('.exp-due-date-wrapper').removeClass('showTooltip');
						}else{
							angular.element('.exp-due-date-wrapper').addClass('showTooltip');
						}
					}
					if(!clickedOnIcon && angular.element('.exp-due-date-wrapper').hasClass('showTooltip') && !$eventTarget.closest('#expdueDateInfo').length){
						angular.element('.exp-due-date-wrapper').removeClass('showTooltip');
					}
			});
		};
		showHideTooltipDueDate();
		$scope.onStartDateChange = function(){
			var StartDate = $scope.oriMsgCustomFields.StartDate;
			$scope.oriMsgCustomFields.StartDateDisplay = StartDate ? $scope.formatDate(new Date(StartDate), 'dd-M-yy') : "";
		};


		/***
		 * Validate expected finished day
		 */
		$scope.validateExpDueDays = function(){
			var expDays = $scope.oriMsgCustomFields.ExpectedFinishDays;
			if(expDays){
				if(isNaN(expDays)){
					$scope.oriMsgCustomFields.ExpectedFinishDays = "";
					alert("Expected Finish Day(s) Should be Number Only!!!");
					return;
				}else if(expDays < 0){
					$scope.oriMsgCustomFields.ExpectedFinishDays = "";
					alert("Expected Finish Day(s) should not be less than zero!!!");
					return;
				}
			}
		};

		/**
		 * inoked when location changed from pin icon and associated location
		 * used to set location detail on location change from pin
		 * @param {assocObj}: Array of associated location
		 */
		htmlformservice.associateLocationComplete = function (assocObj) {
			var tempList = assocObj.selectedLocation;
			if(tempList && tempList.length  && tempList[0].pfLocationTreeDetail){
				var locationId = tempList[0].pfLocationTreeDetail.locationId;
					if(locationId && $scope.AllLocation.length){
						var selectedLocation = $scope.AllLocation.filter(function(item){
							return item.Value3 == locationId;
					});
					setLocationsFieldsValue(selectedLocation[0]);
				}
			}
		};

		/***
		 * to clear action of current message 
		 * invoked on response view is user is Field inspector
		 */
		function clearActionByMsg() {
			var ActionData = DS_INCOMPLETE_ACTIONS_BYMSG;
			$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
			$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
			var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
			var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
            if (ActionData.length) {
                for (var i = 0; i < ActionData.length; i++) {
					if(ActionData[i].Value4 == 'Respond'){
						var AutocompleteMsg = angular.copy(STATIC_OBJ.autocompleteMsgStructure);
						AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
						AutocompleteMsg.DS_MSG_AC_FORM = AppId;
						AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
						AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
						AutocompleteMsg.DS_MSG_AC_ACTION = "3";
						AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";
						insertpoint.push(AutocompleteMsg);
					}
                }
            }
        }
		
		/**
		 * Commen function to assing action to user
		 * @param {*} userToDist: array or string users list or sing user 
		 * @param {string} action: action to assign
		 * @param {string} DS_AUTODISTRIBUTE
		 * @param {*} distDate: due date fo action
		 */
		function assignActionToUser(userToDist, action, DS_AUTODISTRIBUTE, distDate){
			var tempList = [];
			if(angular.isArray(userToDist) && userToDist.length){
				for (var j = 0; j < userToDist.length; j++) {
					tempList.push({
						strUser: userToDist[j],
						strAction: action,
						strDate: distDate
					});
				}
			}else{
				tempList.push({
					strUser: userToDist,
					strAction: action,
					strDate: distDate
				});
			}
			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODISTRIBUTE
			});
		}
		/**
		 * sets repsonse work flow, on close out status select forinfo action to inpsector, origiinator and last responder
		 * 
		 */
		function setWorkFlowResponse(){
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var selectedstatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS;
			var oriMsg = $scope.oriMsgCustomFields;
			var closedActionTOuser = [];
			var distributionDays;
			// when field inspector then he/she is assiging to non field inspector and so the distdays are taken from setting otherwise taken from added days from oriview
			if(!_isCurUserFI()){
				distributionDays = getRespondDays() ? getRespondDays() : '3' ;
			}else{
				distributionDays = $scope.oriMsgCustomFields.DistributionDays.trim();
			}

			oriMsg.ActualFinishDate = "";
			clearActionByMsg();

			if($scope.isCloseoutStatus(selectedstatus)){
				closedActionTOuser = [];
				angular.forEach(getArrayOfUserbyRole([CONSTANTS_OBJ.FIELD_INSPECTOR]), function(inspetorItem){
					closedActionTOuser.push(inspetorItem.split('#')[0].trim());
				});
				closedActionTOuser.push(oriMsg.LastResponder);
				closedActionTOuser.push(oriMsg.OriginatorId.split('|')[0].trim());
				assignActionToUser(commonApi._.uniq(closedActionTOuser), CONSTANTS_OBJ.FOR_INFO, CONSTANTS_OBJ.RES_ACTION_CODE);
				if(!$window._isOffline){
					oriMsg.ActualFinishDate = getDateFromZone(true);
				}else{
					$oriMsg.ActualFinishDate = $scope.serverDate;
				}
			}else{
				if(_isCurUserFI()){
					oriMsg.FieldInspector = currentUserValue().split('|')[0].trim();
					assignActionToUser(getArrayOfUserbyRole([$scope.oriMsgCustomFields.AssignedToRole]), CONSTANTS_OBJ.RES_ACTION, CONSTANTS_OBJ.RES_ACTION_CODE, distributionDays);
					$scope.oriMsgCustomFields.Assigned = $scope.oriMsgCustomFields.AssignedToRole;
				}else{
					assignActionToUser(getArrayOfUserbyRole([CONSTANTS_OBJ.FIELD_INSPECTOR]), CONSTANTS_OBJ.RES_ACTION, CONSTANTS_OBJ.RES_ACTION_CODE, distributionDays);
				}
			}
			oriMsg.LastResponder = currentUserValue().split('|')[0].trim();
		}

		/**
		 * return user with given roles
		 * @param {array} roles: array of role names 
		 */
		function getArrayOfUserbyRole(roles){
			var projUserWithRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			var userArray= [], added;
			for(var i=0; i<projUserWithRole.length; i++){
				var userRoles = projUserWithRole[i].Value.split('|')[0].split(',');
				added = false;
				for(var j=0; j<userRoles.length; j++){
					for(var k=0; k<roles.length; k++){
						if(!added && userRoles[j].toLowerCase().trim() == roles[k].toLowerCase()){
							userArray.push(projUserWithRole[i].Value.split('|')[2].trim());
							added = true;
						}
					}
				}
			}
			return userArray;
		}

		function setWorkFlowOri() {
			var distributionDays = $scope.oriMsgCustomFields.DistributionDays;
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if($scope.oriMsgCustomFields.originator_is_FI == 'Yes'){
				$scope.oriMsgCustomFields.FieldInspector = currentUserValue().split('|')[0].trim();
				assignActionToUser(getArrayOfUserbyRole([$scope.oriMsgCustomFields.AssignedToRole]), CONSTANTS_OBJ.RES_ACTION, CONSTANTS_OBJ.ORI_ACTION_CODE, distributionDays);
				$scope.oriMsgCustomFields.Assigned = $scope.oriMsgCustomFields.AssignedToRole;
			}else{
				// configured repsonse day from setting or 3 days if assigning action to Field inspector
				distributionDays = getRespondDays() ? getRespondDays() : '3';
				assignActionToUser(getArrayOfUserbyRole([CONSTANTS_OBJ.FIELD_INSPECTOR]), CONSTANTS_OBJ.RES_ACTION, CONSTANTS_OBJ.ORI_ACTION_CODE, distributionDays);
			}
			$scope.oriMsgCustomFields.LastResponder = currentUserValue().split('|')[0].trim();
		}

		function getRespondDays(){
			var strdays = "";
			var actionDetails = $scope.getValueOfOnLoadData('DS_GET_APP_ACTION_DETAILS').filter(function(action) {
				return action.Value2 == "Respond";
			});
			if(actionDetails.length){
				strdays = actionDetails[0].Value3.trim();
			}
			return strdays;
		}
		
		function structureItemList(availList, setFor){
			var tempList = [];
			switch (setFor) {
				case CONSTANTS_OBJ.ROLES_LIST:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Name
						});
					});
				break;
				case CONSTANTS_OBJ.STATUS_LIST:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value
						});
					});
				break;
				case CONSTANTS_OBJ.ISSUE_Type:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value8,
							modelValue: item.Value8
						});
					});
				break;
				case CONSTANTS_OBJ.ROOT_CAUSE:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value8,
							modelValue: item.Value8
						});
					});
				break;
				case CONSTANTS_OBJ.WORKPACKAGE:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value1,
							modelValue: item.Value1,
						});
					});
				break;
			}
			return [{
				options: tempList
			}];
		}

		function currentUserValue() {
			return $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.trim();
		}
		
		/**
		 * invoked on ori view form send and on responce view is  slected status is open allocated
		 * Ori-view: Set DueDate for distributed user, close due date, ExpectedFinishDate, DistributionDays
		 * Resp View: Set DueDate for distributed user to assigned to user
		 */
		function setDistributionDaysAndExpectedEndDate(){
			var startDate = $scope.oriMsgCustomFields.StartDate;
			if(!$scope.isOriView){
				startDate = getDateFromZone();
			}
			var finishDay = $scope.oriMsgCustomFields.ExpectedFinishDays;
			if(finishDay && startDate){
				var strParam = startDate + '|' + '' + '|' + finishDay;
				var spName = "DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY";
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": spName,
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": spName,
							"fieldValue": strParam
						}]
					}
				};
				$scope.getCallbackData(form).then(function (response) {
					if(response.data){
						var resData = angular.fromJson(response.data[spName]).Items.Item, 
							strCloseDate, 
							closeDateArr,
							distributionDays,
							resDataItem;

						if(resData.length){
							resDataItem = resData[0];
							distributionDays = parseInt(finishDay) + parseInt(resDataItem.Value1);
							closeDateArr = resDataItem.Value2.split('/');
							strCloseDate = closeDateArr[2]+"-"+closeDateArr[1]+"-"+closeDateArr[0];
							if($scope.isOriView){
								$scope.oriMsgCustomFields.DistributionDays = distributionDays.toString();
								$scope.oriMsgCustomFields.ExpectedFinishDate = resDataItem.Value2;
								$scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE = strCloseDate;
							}
							// assign duedays if action assigned to other then field inspector
							if(_isCurUserFI()){
								for(var i=0; i<$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.length; i++ ){
									$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users[i].DS_ACTIONDUEDATE = distributionDays.toString();
								}
							}
						}
						$scope.submitFlag = true;
						$window.submitForm(1);
					}
				});
			}
		}

		/**
		 * Set location values and isCalibrated value
		 * invoked on load of ori-view
		 * @param {object} item 
		 */
		function setLocationValue(){
			var locationId = commonApi.getParamObj().locationId;
			var isCalibrated = commonApi.getParamObj().isCalibrated;
			if($window._isOffline){
				locationId = objConfigData.locationId;
				isCalibrated = objConfigData.isCalibrated;
			}
			if(!locationId){
				return;
			}
			var locations = $scope.getValueOfOnLoadData('DS_getAllLocationByProject_PF');
			var selectedLocation;
			if(locationId && locations.length){
				selectedLocation = locations.filter(function(item){
					return item.Value3 == locationId;
				});
				setLocationsFieldsValue(selectedLocation[0]);
				if(isCalibrated == 'true' && $scope.oriMsgCustomFields.Location){
					$scope.oriMsgCustomFields.isCalibrated = true;
				}else{
					$scope.oriMsgCustomFields.isCalibrated = false;
				}
			}
		}

		/**
		 * Set location, locationName, PF_Location_Detail value from object 
		 * @param {object} item: matched item from location sp data
		 */
		function setLocationsFieldsValue(item){
			var strPF_Details = "";
			$scope.oriMsgCustomFields.LocationName = "";
			if(item && item.Value9){
				$scope.oriMsgCustomFields.Location = item.Value9 || '';
				strPF_Details = item.Value3.trim() + "|" +  item.Value5.trim() + "|" +  item.Value7.trim() + "|" +  item.Value11.trim();
				$scope.oriMsgCustomFields.PF_Location_Detail = strPF_Details;
				$scope.oriMsgCustomFields.LocationName = item.Value9.split('|')[2];
			}
		}

		/**
		 * return array custom attribute is matched with attribute name
		 * @param {string} type: confugured attrbite name
		 */
		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		/**
		 * here excluding root cause field as geougiou client dont want that field
		 */
		function excludeRootcauseFn(){
			var dsClient = $scope.asiteSystemDataReadOnly._3_Project_Data.DS_CLIENT;
			if(dsClient && dsClient.toLowerCase().indexOf('georgiou') != -1 ){
				$scope.oriMsgCustomFields.excludeRootCauseField = 'yes';
			}
		}

		function setOriViewBase() {
			$scope.workpackageList = structureItemList(WorkPackageTypes, CONSTANTS_OBJ.WORKPACKAGE);
			$scope.issueType =  structureItemList(getConfigurableAttriburteByType('Defect Type'), CONSTANTS_OBJ.ISSUE_Type);
			if($scope.oriMsgCustomFields.originator_is_FI == 'Yes'){
				setRolesList();
			}
			$scope.availableStatus = structureItemList($scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'), CONSTANTS_OBJ.STATUS_LIST);
		}

		function setRolesList(){
			var roles = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES').filter(function (role) {
				return role.Name.startsWith(CONSTANTS_OBJ.StartWithRole) || role.Name.startsWith(CONSTANTS_OBJ.StartWithRole.toLowerCase());
			});
			$scope.RolesList = structureItemList(roles, CONSTANTS_OBJ.ROLES_LIST);
		}
		/**
		 * Check for current user is it Field inspector
		 * return true if is field inspector otherwise false
		 */
		function _isCurUserFI(){
			var CurUserId = currentUserValue().split('|')[0].trim();
			var projUserWithRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			var isFI = false;
			for(var i=0; i<projUserWithRole.length; i++){
				if(projUserWithRole[i].Value && projUserWithRole[i].Value.split('|')[2].split('#')[0].trim() == CurUserId){
					var userRoles = projUserWithRole[i].Value.split('|')[0].split(',');
					for(var j=0; j<userRoles.length; j++){
						if(userRoles[j].toLowerCase().trim() == CONSTANTS_OBJ.FIELD_INSPECTOR.toLowerCase()){
							isFI = true;
						}
					}
					break;
				}
			}
			return isFI;
		}

		if ($scope.isOriView) {
			if(_isCurUserFI()){
				$scope.oriMsgCustomFields.originator_is_FI = 'Yes';
			}else{
				$scope.oriMsgCustomFields.originator_is_FI = 'No';
			}
			// to hide Root Cause field on Georgiou client
			excludeRootcauseFn();
			setOriViewBase();
			fillRecentDefects();
			if (!$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no") {
				setLocationValue();
			}
		}
		if ($scope.isRespView) {
			$scope.isUserFI = _isCurUserFI();
			var curUserId = currentUserValue().split('|')[0].trim();
			var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS').filter(function(item){
				return item.Name.toLowerCase() == 'respond' && item.Value.indexOf(curUserId) > -1;
			   });
			if(incompleteAction.length){
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
				if($scope.isUserFI){
					$scope.oriMsgCustomFields.AssignedToRole = "";
				}
				$scope.resMsgCustomFields.Comments = "";
				$scope.resMsgCustomFields.RootCause = "";
				$scope.resMsgCustomFields.SHResponse = "Yes";

				$scope.availableStatus = structureItemList($scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'), CONSTANTS_OBJ.STATUS_LIST);
				$scope.rootCauseList =  structureItemList(getConfigurableAttriburteByType('Root Cause'), CONSTANTS_OBJ.ROOT_CAUSE);
				setRolesList();
			}else{
				$scope.resMsgCustomFields.SHResponse = "";
			}
		}

		if($scope.isOriPrintView || $scope.isRespPrintView){
			$scope.allResData = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
			
			$scope.allAttchements = $scope.getValueOfOnLoadData('DS_DOC_ATTACHMENTS_ALL');
			if($scope.allAttchements && $scope.allAttchements.length){
				// make and add url of thumbnail
				var plainProjectId  =  $scope.projectId && $scope.projectId.split("$$")[0];
				angular.forEach($scope.allAttchements, function(item){
					if($window._isOffline) {
						item.thumbURL = item.OfflineAttachmentPath;
					} else {
						item.thumbURL = myConfig.baseUrl + CONSTANTS_OBJ.THUMBNAIL_VIEW_PATH +  "?projectId=" + plainProjectId + "&attachmentId=" + item.Value6;
					}
				});
			}
		}

		$scope.launchDefectForm = function () {
			$window.prePopulatemapping = new Object();
			$window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '7';
			$window.prePopulatemapping['SRC1'] = $scope.oriMsgCustomFields.ORI_FORMTITLE;
			$window.prePopulatemapping['TG1'] = 'ORI_FORMTITLE';
			$window.prePopulatemapping['SRC2'] = $scope.oriMsgCustomFields.DefectTyoe;
			$window.prePopulatemapping['TG2'] = 'DefectTyoe';
			$window.prePopulatemapping['SRC3'] = encodeURIComponent($scope.oriMsgCustomFields.Location);
			$window.prePopulatemapping['TG3'] = 'Location';
			$window.prePopulatemapping['SRC4'] = $scope.oriMsgCustomFields.LocationName;
			$window.prePopulatemapping['TG4'] = 'LocationName';
			$window.prePopulatemapping['SRC5'] = $scope.oriMsgCustomFields.ExpectedFinishDays;
			$window.prePopulatemapping['TG5'] = 'ExpectedFinishDays';
			$window.prePopulatemapping['SRC6'] = $scope.oriMsgCustomFields.Defect_Description;
			$window.prePopulatemapping['TG6'] = 'Defect_Description';
			$window.prePopulatemapping['SRC7'] = $scope.oriMsgCustomFields.TaskType;
			$window.prePopulatemapping['TG7'] = 'TaskType';
			launchCreateForm("SNG-AUS-DEF");
		};

		/**
		 * Return todays date from dayligh saving time zone
		 * @param {string} withTime: to pass true if want time also 
		 */
		function getDateFromZone(withTime){
			var offset = 0;
			Date.prototype.stdTimezoneOffset = function () {
				var jan = new Date(this.getFullYear(), 0, 1);
				var jul = new Date(this.getFullYear(), 6, 1);
				return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
			};
			Date.prototype.isDstObserved = function () {
				return this.getTimezoneOffset() < this.stdTimezoneOffset();
			};
			var today = new Date();
			if (today.isDstObserved()) { 
				offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
			} else {
				offset = $window.USP.localeVO._timezone.rawOffset;
			}

			var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
			var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
			if(withTime){
				nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
			}else{
				nd = $filter('date')(nd, 'yyyy-MM-dd');
			}
            return nd;
		}

		/**
		 * Fill recent defect list for recent defect selector
		 */
		function fillRecentDefects() {
			if (recentDefectObj.length) {
				var loopLength = recentDefectObj.length,
					numberOfRecentDefect = commonApi.getParamObj().numberOfRecentDefect;
				if (numberOfRecentDefect && numberOfRecentDefect < loopLength) {
					loopLength = numberOfRecentDefect;
				}
				for (var i = 0; i < loopLength; i++) {
					$scope.recentDefectsList.push({
						defectId: recentDefectObj[i].Value1,
						defectName: recentDefectObj[i].Value2,
						defectType: recentDefectObj[i].Value10,
						defectWorkpackage: recentDefectObj[i].Value3
					});
				}
			}
		}

		$scope.selectRecenteDefect = function(defectId, defTitle){
			angular.element('#selectedRecentDefect').val(defTitle);
			$scope.recentdefectCaption = defTitle;
			$scope.onRecentDefectChange(defectId);
			$scope.closeRecentDropdown();
		};

		$scope.OpenRecentDropdown = function(){
			angular.element('.recent-defdropdown-wrapper').addClass('dropdown-open');
		};
		$scope.closeRecentDropdown = function(){
			angular.element('.recent-defdropdown-wrapper').removeClass('dropdown-open');
		};

		$scope.onRecentDefectChange = function (strVal) {
			if (strVal) {
				var defectObj = commonApi._.filter(recentDefectObj, function (val) {
					return val.Value1 == strVal;
				});
				if (defectObj.length) {
					$scope.oriMsgCustomFields.ORI_FORMTITLE = defectObj[0].Value2;
					$scope.oriMsgCustomFields.TaskType = defectObj[0].Value10;
					$scope.oriMsgCustomFields.DefectTyoe = defectObj[0].Value3;
					$scope.workpackageList = structureItemList(WorkPackageTypes, CONSTANTS_OBJ.WORKPACKAGE);
					$scope.issueType = structureItemList(getConfigurableAttriburteByType('Defect Type'), CONSTANTS_OBJ.ISSUE_Type);
					$scope.oriMsgCustomFields.ExpectedFinishDays = defectObj[0].Value6;
					$scope.oriMsgCustomFields.Defect_Description = defectObj[0].Value7;
					//set role from recent defect if user is field inspector
					if(_isCurUserFI()){
						var assignedRole = defectObj[0].Value11.trim();
						var found = commonApi._.find($scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES'), function(role){
							return (role.Name.startsWith(CONSTANTS_OBJ.StartWithRole) || role.Name.startsWith(CONSTANTS_OBJ.StartWithRole.toLowerCase())) && role.Name.trim() == assignedRole;
						});
						if(found){
							$scope.oriMsgCustomFields.AssignedToRole = assignedRole;
						}else{
							$scope.oriMsgCustomFields.AssignedToRole = "";
						}
						setRolesList();
					}
				}
			}
		};

		/**
		 * Invoked on status selection change 
		 * reset root cause field value and set showrootcause yes if selected status is closeout status
		 */
		$scope.onStatusSelectionChange = function(){
			$scope.resMsgCustomFields.RootCause = '';
			var selectedStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS;
			if(selectedStatus && $scope.isCloseoutStatus(selectedStatus)){
				$scope.oriMsgCustomFields.showRootCause = 'yes';
			}else{
				$scope.oriMsgCustomFields.showRootCause = 'no';
			}
		};

		$scope.restrictCharPasteCustom = function (event, nodeKey, parentObj) {
			var inputValue;
			if ($window.clipboardData) {
				inputValue = $window.clipboardData.getData('Text');
			} else if (event.originalEvent) {
				inputValue = event.originalEvent.clipboardData.getData('text/plain');
			} else {
				inputValue = event.target.innerText;
			}

			if (inputValue.match(/[|<>%#]/gi)) {
				alert("Restricted Characters specified!!! Restricted Characters | < > # %");
				//	blank out richText box on paste if found any listed Special characters.	
				if (event.target.innerText) {
					angular.element(event.target).find('div[contenteditable="true"]').html('');
					parentObj[nodeKey] = '';
				} else {
					event.preventDefault();
				}
				return false;
			}
		};

		$scope.restrictCharCustom = function (event, charList) {
			switch (event.keyCode) {
				case 51:
				case 53:
				case 188:
				case 190:
				case 220:
					if (event.shiftKey) {
						alert("Restricted Characters specified!!! Restricted Characters | < > # %");
						event.preventDefault();
					}
					break;
			}
			if (charList && Array.isArray(charList) && charList.indexOf(event.keyCode) >= 0) {
				event.preventDefault();
			}
		};

		/**
		 * input status is closeout then return tru othewise false 
		 * @param {string} inputStatus: selected status as input to check is it close out or not
		 */
		$scope.isCloseoutStatus = function(inputStatus){
			var selectedclosestatus = $scope.getValueOfOnLoadData('DS_ALL_STATUS_WithCloseout').find(function (status) {
				if(inputStatus.indexOf('#') != -1){
					inputStatus = inputStatus.split('#')[1];
				}
				return (inputStatus.trim() ==  status.Value1.trim()) && (status.Value2.split('|')[2].trim() == 'Yes');
			});
			if(selectedclosestatus){
				return true;
			}
			return false;
		};

		$scope.update();
		
		$window.oriformSubmitCallBack = function () {
			if($scope.isRespView && $scope.resMsgCustomFields.SHResponse != "Yes"){
				alert('You are not authorized to response.');
				return true;
			}
			if ($scope.submitFlag) {
                return false;
            }
			if (angular.element('#btnSaveForm').scope().assoc.attachments.data.length > 10) {
				alert("only 10 documents are allowed to be attach");
				return true;
			}
			if ($window._isOffline && $scope.isOriView && objConfigData.todaysDate) {
				// reversing date because getting in dd-mm-yyyy format
				var todaysDate = objConfigData.todaysDate.split("-").reverse().join("-");
				if($scope.oriMsgCustomFields.StartDate < $scope.formatDate(new Date(todaysDate), 'yy-mm-dd')){
					alert("Start date can not be a past Date!!!");
					return true;
				}
			}
			if (!$window._isOffline && $scope.isOriView && $scope.oriMsgCustomFields.StartDate < getDateFromZone()) {
				alert("Start date can not be a past Date!!!");
				return true;
			}
			if($scope.isRespView){
				// on closeout select reseting assigned to role to prevoius
				if($scope.isCloseoutStatus($scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS)){
					$scope.oriMsgCustomFields.AssignedToRole = tempAssignedToRole;
				}
				setWorkFlowResponse();
				if(!$window._isOffline && _isCurUserFI()){
					setDistributionDaysAndExpectedEndDate();
					return true;
				}
			}
			if($scope.isOriView){
				$scope.oriMsgCustomFields.OriginatorId = currentUserValue();
				if(!$window._isOffline){
					$scope.oriMsgCustomFields.Todays_Date = getDateFromZone(true);
				}else{
					$scope.oriMsgCustomFields.Todays_Date = $scope.serverDate;
				}
				setWorkFlowOri();
				if(!$window._isOffline){
					setDistributionDaysAndExpectedEndDate();
					return true;
				}
			}
			return false;
		};
		$window.draftSubmitCallBack = function () {
			return false;
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}