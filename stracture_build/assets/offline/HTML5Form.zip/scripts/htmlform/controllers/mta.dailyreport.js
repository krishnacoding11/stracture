define(['angular', './base', '../components/inlineattachment', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                    isfunctionToCall && setInlineAttachmentNodes();
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.showTenderDataTable = false;
        $scope.isDataLoaded = true;

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.GenralGroup = $scope.oriMsgCustomFields["General_Group"];
        $scope.weatherGroup = $scope.oriMsgCustomFields["Weather_Group"];
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.equipmentGroup = $scope.oriMsgCustomFields["Equipment_Group"];
        $scope.companiesGroup = $scope.oriMsgCustomFields["Companies_Group"];
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
        $scope.DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
        $scope.DS_ORIGINATOR = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ORIGINATOR;
        $scope.DS_WORKINGUSER = $scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER;
        $scope.DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        var ds_Workinguser_All_Roles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        $scope.Contract = $scope.getValueOfOnLoadData('DS_MTA_PSR_LOCATION_DETAILS');
        $scope.materialsGroup = $scope.oriMsgCustomFields["Materials_Group"];
        $scope.visitorsGroup = $scope.oriMsgCustomFields["Visitors_Group"];
        $scope.safetyGroup = $scope.oriMsgCustomFields["Safety_Group"];
        $scope.qaqcGroup = $scope.oriMsgCustomFields["QA_QC_Group"];
        $scope.secCGroup = $scope.oriMsgCustomFields["SectionC_Group"];
        $scope.secDGroup = $scope.oriMsgCustomFields["SectionD_Group"];
        $scope.secEGroup = $scope.oriMsgCustomFields["SectionE_Group"];
        $scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
        var currentUserName = "";
        var mtaHeaderDetails = $scope.getValueOfOnLoadData('DS_MTA_PSR_Header_Details')[0],
            _5FormDataNode = $scope.asiteSystemDataReadOnly['_5_Form_Data'],
            strIsDraft = _5FormDataNode['DS_ISDRAFT'].toLowerCase(),
            setPsrProjectDetails = function () {

                $scope.projectDetails.Planning_Number = mtaHeaderDetails.Value2;
                $scope.projectDetails.ProgramManager = mtaHeaderDetails.Value3;
                $scope.projectDetails.ProjectPSE = mtaHeaderDetails.Value4;
                $scope.projectDetails.ProjectDescr = mtaHeaderDetails.Value5;
                $scope.projectDetails.KeyProject = mtaHeaderDetails.Value6;
                $scope.projectDetails.ConstructionMgr = mtaHeaderDetails.Value7;
                $scope.projectDetails.ProjectStatus = mtaHeaderDetails.Value8;
                $scope.projectDetails.ProjectPhase = mtaHeaderDetails.Value9;
                $scope.projectDetails.ProgramOfficer = mtaHeaderDetails.Value10;
            };
        $scope.DSFormId = _5FormDataNode['DS_FORMID'],
            $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsProjuser = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.isEditori = false;
        initFormsData();

        $scope.isXHRon = false;
        $scope.disableTenderName = false;
        var modelRowIndex = -1;
        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] ([AaPp][Mm]))";
        var STATIC_OBJ_DATA = {
            Weather: {
                Weather_isSelected: false,
                Item: "",
                TimeFrame: "",
                Low_Temp: "",
                Current_Temp: "",
                High_Temp: "",
                Conditions: "",
                Humidity: "",
                Visiblity: "",
                Pricip: "",
                Windspeed: "",
                WindDescription: "",
                Notes: ""
            },
            Companies: {
                Companies_isSelected: "",
                Company: "",
                Work_Location: "",
                Work_Activity: "",
                Expected_Workers: "",
                Units_Works: "",
                Personnel_Group: {
                    Personnel: [{
                        Personnel_isSelected: "",
                        Personnel_Type: "",
                        No_Workers: "",
                        Labor_Unit: "",
                        Labor_Typenit: ""
                    }]
                }
            },
            Personnel: {
                Personnel_isSelected: "",
                Personnel_Type: "",
                No_Workers: "",
                Labor_Unit: "",
                Labor_Typenit: ""
            },
            Equipment: {
                Equipment_isSelected: false,
                Item: "",
                Description: "",
                Item_Type: "",
                Source: "",
                Equipment_Company: "",
                Location_Used: "",
                Status: "",
                Reading: "",
                UOM: ""
            },
            Materials: {
                Materials_isSelected: false,
                Item: "",
                Materials_Description: "",
                Category: "",
                Qty_Recived: "",
                Qty_Rejected: "",
                Location: "",
                Materials_Date: "",
                Materials_Time: ""
            },
            Visitors: {
                Visitors_isSelected: false,
                Item: "",
                Visitor_Name: "",
                Visitor_Comapny: "",
                Visit_Date: "",
                Visit_Time: ""
            },
            Safety: {
                Safety_isSelected: false,
                Item: "",
                Date: "",
                Time: "",
                Contact: "",
                Company: "",
                Contact_Other: "",
                Notis_By: "",
                Work_Activity: "",
                Safty_Issue: "",
                Hours_Lost: "",
                Reference: "",
                Severity: "",
                Requirement: "",
                Require_By: "",
                Outcome: "",
                Completed: "",
                Checked_By: "",
                Work_Location: "",
                Brif_Work_Desc: "",
                Corrective_Measures: "",
                Non_Right: "",
                Track_Safety: "",
                Non_Right_Attachment: "",
                Track_Safety_Attachment: ""

            },
            QA_QC: {
                QA_QC_isSelected: false,
                Item: "",
                Csi_Code: "",
                Description: "",
                Company: "",
                Issued_By: "",
                Notes: "",
                QA_QC_Location: "",
                QA_QC_Drawing_No: "",
                QA_QC_Insp_Name: "",
                QA_QC_Activity: "",
                QA_QC_Contract: "",
                QA_QC_Material: "",
                QA_QC_Equipment: "",
                QA_QC_Procedure: ""
            },
            DiversionServices: {
                Diversion_isSelected: "",
                GO_No: "",
                GO_Owner: "",
                Support_Timecall: "",
                Support_Timecalloff: "",
                Support_Dept: "",
                Support_Dept_Cont: "",
                Track: "",
                Limits: ""
            },
            SignalEngineer: {
                SignalEngineerName: "",
                SignalMTA: "",
                SignalContractor: "",
                SignalScopeOfWork: "",
                SignalWeekday: "",
                SignalWeekend: "",
                SignalRoomLocation: "",
                SignalElevated: "",
                SignalWayside: "",
                SignalInStation: "",
                SignalEIC: "",
                SignalPassNo: "",
                CIR: "",
                CIRElevated: "",
                CIRWayside: "",
                CIRInStation: ""
            },
            GOPiggybacked: {
                Piggybacked_isSelected: "",
                GOPiggybacked_Contractor: "",
                GOPiggybacked_TA_Office: "",
                GOPiggybacked_EIC: "",
                GOPiggybacked_CM_Num: ""
            },
            GOPiggybackedwith: {
                GOPiggybackedwith_isSelected: "",
                GOPiggybackedwith_Contractor: "",
                GOPiggybackedwith_TA_Office: "",
                GOPiggybackedwith_EIC: "",
                GOPiggybackedwith_CM_Num: ""
            },
            Flagging_Personnel: {
                Flagging_isSelected: "",
                Flagging_Name: "",
                Flagging_Passno: "",
                Flagging_Time_in: "",
                Flagging_Time_out: "",
                Flagging_Lunch: ""
            },
            Inspection_Protection: {
                Inspection_isSelected: "",
                Inspection_Name: "",
                Inspection_Pass: "",
                Inspection_Time_in: "",
                Inspection_Time_out: ""
            },
            Work_Train: {
                WorkTrain_isSelected: "",
                SectionD_Consist: "",
                SectionD_Track: "",
                SectionD_Arrival: "",
                SectionD_Departure: ""
            },
            Bulletin_Section: {
                SignalBulletin_isSelected: "",
                Bulletin_Number: "",
                Bulletin_Date: "",
                Bulletin_Owner: "",
                Bulletin_Call_On: "",
                Bulletin_Supervisor_Name_On: "",
                Bulletin_Pass_No_On: "",
                Bulletin_Call_Off: "",
                Bulletin_Supervisor_Name_Off: "",
                Bulletin_Pass_No_Off: ""
            },
            Company_Data: {
                Company_Name: "",
                Company_Value: ""
            },
            PriviousFormsdata: {
                Date: "",
                formId: "",
                General: "Yes",
                Companies: "Yes",
                Equipment: "Yes",
                Materials: "Yes",
                Visitors: "Yes",
                Safety: "Yes",
                QA_QC: "Yes",
                Inspection_Hold_Point: "Yes",
                Support_Services: "Yes",
            },
            Signalman: {
                SignalmanName: "",
                SignalmanMTA: "",
                SignalmanMTAPassNo: "",
                SignalmanContractor: "",
                SignalmanScopeOfWork: "",
                SignalmanWeekday: "",
                SignalmanDayNight: "",
                SignalmanWeekend: "",
                SignalmanWeekendDayNight: "",
                SignalmanRoomLocation: "",
                SignalmanElevated: "",
                SignalmanWayside: "",
                SignalmanInStation: "",
                SignalmanEIC: "",
                SignalmanPassNo: "",
                SignalmanCIR: "",
                SignalmanCIRElevated: "",
                SignalmanCIRWayside: "",
                SignalmanCIRInStation: ""
            }
        },

            keyCodeData = [],
            weatherData = [];

        $scope.openModelForSafety = function (index) {
            var rowObj = $scope.safetyGroup.Safety[index];
            $scope.openModal('Safety', { row: rowObj });
        }

        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Weather);
        $scope.openModal = function (modalId, rowData) {
            modelRowIndex = -1;
            if (rowData) {
                modelRowIndex = rowData.index;
                $scope.modelData = angular.copy(rowData.row);
                if (currentViewName == "ORI_PRINT_VIEW") {
                    ctrl.model.readOnly = true;
                }
            }
            else {
                switch (modalId) {
                    case 'Weather':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Weather);
                        var firstSecrionRow = $scope.weatherGroup['Weather'][0];
                        if (firstSecrionRow && !firstSecrionRow['TimeFrame'] && !firstSecrionRow['Low_Temp'] && !firstSecrionRow['Current_Temp']
                            && !firstSecrionRow['High_Temp'] && !firstSecrionRow['Conditions'] && !firstSecrionRow['Humidity'] && !firstSecrionRow['Visiblity']
                            && !firstSecrionRow['Pricip'] && !firstSecrionRow['Windspeed'] && !firstSecrionRow['WindDescription']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Weather']);
                        }
                        break;
                    case 'Companies':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Companies);
                        var firstSecrionRow = $scope.companiesGroup['Companies'][0];
                        if (firstSecrionRow && !firstSecrionRow['Companies_Company'] && !firstSecrionRow['Work_Location'] && !firstSecrionRow['Work_Activity']
                            && !firstSecrionRow['Expected_Workers'] && !firstSecrionRow['Units_Works'] && !firstSecrionRow['Workers']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Companies']);
                        }
                        break;
                    case 'Equipment':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Equipment);
                        var firstSecrionRow = $scope.equipmentGroup['Equipment'][0];
                        if (firstSecrionRow && !firstSecrionRow['Equipment_Description'] && !firstSecrionRow['Item_Type'] && !firstSecrionRow['Source']
                            && !firstSecrionRow['Equipment_Company'] && !firstSecrionRow['Location_Used'] && !firstSecrionRow['Status']
                            && !firstSecrionRow['Reading'] && !firstSecrionRow['UOM']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Equipment']);
                        }
                        break;
                    case 'Materials':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Materials);
                        var firstSecrionRow = $scope.materialsGroup['Materials'][0];
                        if (firstSecrionRow && !firstSecrionRow['Materials_Description'] && !firstSecrionRow['Category'] && !firstSecrionRow['Qty_Recived']
                            && !firstSecrionRow['Qty_Recived'] && !firstSecrionRow['Location'] && !firstSecrionRow['Materials_Date']
                            && !firstSecrionRow['Materials_Time']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Materials']);
                        }
                        break;
                    case 'Visitors':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Visitors);
                        var firstSecrionRow = $scope.visitorsGroup['Visitors'][0];
                        if (firstSecrionRow && !firstSecrionRow['Visitor_Name'] && !firstSecrionRow['Visitor_Comapny'] && !firstSecrionRow['Visit_Date']
                            && !firstSecrionRow['Visit_Time']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Visitors']);
                        }
                        break;
                    case 'Safety':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Safety);
                        var firstSecrionRow = $scope.safetyGroup['Safety'][0];
                        if (firstSecrionRow && !firstSecrionRow['Safety_Date'] && !firstSecrionRow['Safety_Time'] && !firstSecrionRow['Contact']
                            && !firstSecrionRow['Safety_Company'] && !firstSecrionRow['Contact_Other'] && !firstSecrionRow['Notis_By'] && !firstSecrionRow['Work_Activity']
                            && !firstSecrionRow['Safty_Issue'] && !firstSecrionRow['Hours_Lost'] && !firstSecrionRow['Reference'] && !firstSecrionRow['Severity']
                            && !firstSecrionRow['Requirement'] && !firstSecrionRow['Require_By'] && !firstSecrionRow['Outcome'] && !firstSecrionRow['Completed'] && !firstSecrionRow[' Checked_By']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Safety']);
                        }
                        break;
                    case 'QA_QC':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.QA_QC);
                        var firstSecrionRow = $scope.qaqcGroup['QA_QC'][0];
                        if (firstSecrionRow && !firstSecrionRow['Csi_Code'] && !firstSecrionRow['QA_QC_Description'] && !firstSecrionRow['QA_QC_Company']
                            && !firstSecrionRow['Issued_By'] && !firstSecrionRow['QA_QC_Location'] &&
                            !firstSecrionRow['QA_QC_Drawing_No'] && !firstSecrionRow['QA_QC_Insp_Name'] && !firstSecrionRow['QA_QC_Activity']
                            && !firstSecrionRow['QA_QC_Contract'] && !firstSecrionRow['QA_QC_Material'] && !firstSecrionRow['QA_QC_Equipment'] && !firstSecrionRow['QA_QC_Procedure']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['QA_QC']);
                        }
                        break;
                    case 'DiversionServices':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.DiversionServices);
                        var firstSecrionRow = $scope.secCGroup['DiversionServices'][0];
                        if (firstSecrionRow && !firstSecrionRow['GO_No'] && !firstSecrionRow['Track'] && !firstSecrionRow['Limits']
                            && !firstSecrionRow['GO_Owner'] && !firstSecrionRow['Support_Timecall'] && !firstSecrionRow['Support_Timecalloff']
                            && !firstSecrionRow['Support_Dept'] && !firstSecrionRow['Support_Dept_Cont']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['DiversionServices']);
                        }
                        break;
                    case 'SignalEngineer':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.SignalEngineer);
                        var firstSecrionRow = $scope.secDGroup.SignalEngineer[0];
                        if (firstSecrionRow && !firstSecrionRow.SignalEngineerName && !firstSecrionRow.SignalMTA && !firstSecrionRow.MTAPassNo && !firstSecrionRow.SignalContractor && !firstSecrionRow.SignalScopeOfWork && !firstSecrionRow.SignalWeekday && !firstSecrionRow.SignalWeekend && !firstSecrionRow.SignalRoomLocation && !firstSecrionRow.SignalElevated && !firstSecrionRow.SignalWayside && !firstSecrionRow.SignalInStation && !firstSecrionRow.SignalEIC && !firstSecrionRow.SignalPassNo && !firstSecrionRow.CIR && !firstSecrionRow.CIRElevated && !firstSecrionRow.CIRWayside && !firstSecrionRow.CIRInStation) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['SignalEngineer']);
                        }
                        break;
                    case 'GOPiggybacked':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.GOPiggybacked);
                        var firstSecrionRow = $scope.secCGroup['GOPiggybacked'][0];
                        if (firstSecrionRow && !firstSecrionRow['GOPiggybacked_Contractor'] && !firstSecrionRow['GOPiggybacked_TA_Office'] && !firstSecrionRow['GOPiggybacked_EIC'] &&
                            !firstSecrionRow['GOPiggybacked_CM_Num']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['GOPiggybacked']);
                        }
                        break;
                    case 'GOPiggybackedwith':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.GOPiggybackedwith);
                        var firstSecrionRow = $scope.secCGroup['GOPiggybackedwith'][0];
                        if (firstSecrionRow && !firstSecrionRow['GOPiggybackedwith_Contractor'] && !firstSecrionRow['GOPiggybackedwith_TA_Office'] && !firstSecrionRow['GOPiggybackedwith_EIC'] &&
                            !firstSecrionRow['GOPiggybackedwith_CM_Num']) {
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['GOPiggybackedwith']);
                        }
                        break;
                    case 'PriviousFormsdata':
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.PriviousFormsdata);
                        $scope.filterDropdownList.formIdList = [];
                        break;
                }
            }
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            });
            showModal(modalId);
        }

        function updateRecord() {
            var modalId = ctrl.model.modelId;
            var backUpObject = "",
                index = "",
                isDuplicate = "";
            $timeout(function () {
                var rowIndex = modelRowIndex,
                    newNode = angular.copy($scope.modelData);
                switch (modalId) {
                    case 'Weather':
                        if (validateWeatherForm()) {
                            if (rowIndex > -1) {
                                $scope.weatherGroup['Weather'][rowIndex] = newNode;
                            }
                            else {
                                $scope.weatherGroup['Weather'].push(newNode);
                            }
                        }
                        else {
                            alert('Validation\n\nPlease fill mandatory fields.');
                            return;
                        }
                        break;
                    case 'Companies':
                        backUpObject = angular.copy($scope.companiesGroup['Companies']);
                        if (rowIndex > -1) {
                            $scope.companiesGroup['Companies'][rowIndex] = newNode;
                        }
                        else {
                            $scope.companiesGroup['Companies'].push(newNode);
                        }
                        if (rowIndex > -1)
                            index = rowIndex;
                        else
                            index = $scope.companiesGroup.Companies.length - 1;

                        isDuplicate = $scope.checkDuplicateValue({
                            key: 'Companies_Company',
                            model: $scope.modelData,
                            index: index,
                            repetObj: $scope.companiesGroup.Companies,
                            msg: 'Company'
                        });
                        if (!isDuplicate) {
                            $scope.companiesGroup['Companies'] = angular.copy(backUpObject);
                            return;
                        }
                        else {
                            setWorkersTotal();
                        }
                        break;

                    case 'Equipment':
                        if (rowIndex > -1) {
                            $scope.equipmentGroup['Equipment'][rowIndex] = newNode;
                        }
                        else {
                            $scope.equipmentGroup['Equipment'].push(newNode);
                        }
                        break;
                    case 'Materials':
                        if (rowIndex > -1) {
                            $scope.materialsGroup['Materials'][rowIndex] = newNode;
                        }
                        else {
                            $scope.materialsGroup['Materials'].push(newNode);
                        }
                        break;
                    case 'Visitors':
                        if (rowIndex > -1) {
                            $scope.visitorsGroup['Visitors'][rowIndex] = newNode;
                        }
                        else {
                            $scope.visitorsGroup['Visitors'].push(newNode);
                        }
                        break;
                    case 'Safety':
                        if (validateSafetyForm()) {
                            if ($scope.GenralGroup.Report_By == "Safety Contractor") {
                                $scope.oriMsgCustomFields.DSI_DisableType = 'Yes';
                            }
                            if (rowIndex > -1) {
                                $scope.safetyGroup['Safety'][rowIndex] = newNode;
                            }
                            else {
                                $scope.safetyGroup['Safety'].push(newNode);
                            }
                        } else {
                            alert('Validation\n\nPlease fill mandatory fields.');
                            return;
                        }
                        break;
                    case 'QA_QC':
                        if (validateQAQC()) {
                            if ($scope.GenralGroup.Report_By == "Quality Control Contractor") {
                                $scope.oriMsgCustomFields.DSI_DisableType = 'Yes';
                            }
                            if (rowIndex > -1) {
                                $scope.qaqcGroup['QA_QC'][rowIndex] = newNode;
                            }
                            else {
                                $scope.qaqcGroup['QA_QC'].push(newNode);
                            }
                        }
                        break;
                    case 'DiversionServices':
                        if (rowIndex > -1) {
                            $scope.secCGroup['DiversionServices'][rowIndex] = newNode;
                        }
                        else {
                            $scope.secCGroup['DiversionServices'].push(newNode);
                        }
                        break;
                    case 'GOPiggybacked':
                        if (rowIndex > -1) {
                            $scope.secCGroup['GOPiggybacked'][rowIndex] = newNode;
                        }
                        else {
                            $scope.secCGroup['GOPiggybacked'].push(newNode);
                        }
                        break;
                    case 'GOPiggybackedwith':
                        if (rowIndex > -1) {
                            $scope.secCGroup['GOPiggybackedwith'][rowIndex] = newNode;
                        }
                        else {
                            $scope.secCGroup['GOPiggybackedwith'].push(newNode);
                        }
                        break;
                    case 'SignalEngineer':
                        if (rowIndex > -1) {
                            $scope.secDGroup['SignalEngineer'][rowIndex] = newNode;
                        }
                        else {
                            $scope.secDGroup['SignalEngineer'].push(newNode);
                        }
                        break;
                    case 'PriviousFormsdata':
                        if (!validatePriviousFormData()) {
                            return;
                        }
                        var tickcheckbox = [];
                        var checkbox = $scope.modelData;

                        for (var key in checkbox) {
                            if (checkbox[key] == 'Yes') {
                                tickcheckbox.push(key);
                            }
                        }
                        var msgPrevData = $window.confirm('Are you sure you want to pull previous data from Daily Report (' + checkbox.formId + ') ?');

                        if (!msgPrevData) {
                            return;
                        }
                        iCount = 0;
                        getPreviousData(tickcheckbox);

                }

                hideModal();
            }, 200)

        }
        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false
        };
        function showModal(id) {
            // show modal
            ctrl.model.modelId = id;

            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4')
                modalHeader.addClass('primary-header-bg white-font')
            }, 200);
        };
        $scope.deleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };
        function validateWeatherForm() {
            var validaFlag = true;
            var mandatoryFields = ['TimeFrame', 'Current_Temp', 'Conditions'];

            for (var index = 0; index < mandatoryFields.length; index++) {
                var element = mandatoryFields[index];
                var strElem = $scope.modelData[element];
                if (!strElem) {
                    validaFlag = false;
                    break;
                }
            }
            return validaFlag;
        }

        function validateSafetyForm() {
            var validaFlag = true;
            var mandatoryFields = ['Brif_Work_Desc', 'Contact_Other', 'Work_Location', 'Work_Hours'];
            var roportBy = $scope.GenralGroup.Report_By;
            for (var index = 0; index < mandatoryFields.length; index++) {
                var element = mandatoryFields[index];
                var strElem = $scope.modelData[element];
                if (!strElem && roportBy == "Safety Contractor") {
                    validaFlag = false;
                    break;
                }
            }
            return validaFlag;
        }
        function validateQAQC() {
            var validaFlag = true;
            var mandatoryFields = ['QA_QC_Company', 'Issued_By', 'QA_QC_Location', 'QA_QC_Insp_Name', 'QA_QC_Activity', 'QA_QC_Contract', 'QA_QC_Material', 'QA_QC_Equipment', 'QA_QC_Procedure'];
            var roportBy = $scope.GenralGroup.Report_By;
            for (var index = 0; index < mandatoryFields.length; index++) {
                var element = mandatoryFields[index];
                var strElem = $scope.modelData[element];
                if (roportBy == "Quality Contractor") {
                    $scope.oriMsgCustomFields.DSI_DisableType = 'Yes';
                }
                if (!strElem && roportBy == "Quality Contractor") {
                    validaFlag = false;
                    break;
                }
            }
            return validaFlag;
        }

        function validatePriviousFormData() {
            var selectedData = $scope.modelData;
            if (selectedData.Date == '') {
                alert('Please select date');
                return false;
            }

            if (selectedData.formId == '') {
                alert('Please select formid');
                return false;
            }
            if (selectedData.General == 'No' && selectedData.Companies == 'No' && selectedData.Equipment == 'No' && selectedData.Materials == 'No' && selectedData.Visitors == 'No' && selectedData.Safety == 'No' && selectedData.QA_QC == 'No' && selectedData.Inspection_Hold_Point == 'No' && selectedData.Support_Services == 'No') {
                alert('At least one tab must be selected.');
                return false;
            }
            return true;
        }
        $scope.setCompany = function (strVal) {
            if (strVal) {
                $scope.modelData['Safety_Company'] = strVal.split(',')[1].trim();
            }
            else {
                $scope.modelData.Safety_Company = '';
            }
        };

        function setClientlogo() {
            if ($scope.WorkingUserID.length) {
                var strOrgName = $scope.WorkingUserID[0].Name.substr($scope.WorkingUserID[0].Name.indexOf(',') + 1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter($scope.DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter($scope.DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
        }

        function initFormsData() {

            if (currentViewName == "ORI_VIEW") {
                if ($scope.WorkingUserID && $scope.WorkingUserID.length > 0) {
                    currentUserName = $scope.WorkingUserID['0'].Name;
                }
                $scope.currentOriTab = 'General.html';
                var tmpCsi_Code = [];
                var tmpCsi_Description = [];
                var tmpShift = [];
                var tmplogo = [];
                var tmpStatus = [];
                var tmpReading = [];
                var tmpCause = [];
                var tmpitemType = [];
                var tmpSource = [];
                var tmpUOM = [];
                var tmpCategory = [];
                var tmpUnit = [];
                var tmpdocumentTemp = [];
                var tmpType = [];
                var tmplaborType = [];
                var tmppersonnelType = [];
                var tmpreportBy = [];

                var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
                for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                    var element = dsAsiConfigurableAttributes[index];

                    if (element.Value11.indexOf('Active') != -1) {
                        if (element.Value3 === "CSI Code") {
                            tmpCsi_Code.push(element);
                        } else if (element.Value3 === "CSI_Description") {
                            tmpCsi_Description.push(element);
                        } else if (element.Value3 === "Shift") {
                            tmpShift.push(element);
                        } else if (element.Value3 === "Client Logo") {
                            tmplogo.push(element);
                        } else if (element.Value3 === "Status") {
                            tmpStatus.push(element);
                        } else if (element.Value3 === "Reading") {
                            tmpReading.push(element);
                        } else if (element.Value3 === "Cause") {
                            tmpCause.push(element);
                        } else if (element.Value3 === "Item Type") {
                            tmpitemType.push(element);
                        } else if (element.Value3 === "Source") {
                            tmpSource.push(element);
                        } else if (element.Value3 === "UOM") {
                            tmpUOM.push(element);
                        } else if (element.Value3 === "Category") {
                            tmpCategory.push(element);
                        } else if (element.Value3 === "Unit") {
                            tmpUnit.push(element);
                        } else if (element.Value3 === "Document Template") {
                            tmpdocumentTemp.push(element);
                        }
                        else if (element.Value3 === "Type") {
                            tmpType.push(element);
                        }
                        else if (element.Value3 === "Labor Type") {
                            tmplaborType.push(element);
                        }
                        else if (element.Value3 === "Personnel Type") {
                            tmppersonnelType.push(element);
                        }
                        else if (element.Value3 === "Reported By") {
                            tmpreportBy.push(element);
                        }
                    }
                }
                $scope.Csi_Description = tmpCsi_Description;
                $scope.Csi_Code = tmpCsi_Code;
                $scope.Shift = tmpShift;
                $scope.Status = tmpStatus;
                $scope.Reading = tmpReading;
                $scope.Cause = tmpCause
                $scope.itemType = tmpitemType;
                $scope.Source = tmpSource;
                $scope.UOM = tmpUOM;
                $scope.Category = tmpCategory;
                $scope.Unit = tmpUnit;
                $scope.documentTemp = tmpdocumentTemp;
                $scope.Type = tmpType;
                $scope.laborType = tmplaborType;
                $scope.personnelType = tmppersonnelType;

                setClientlogo();

                if (!$scope.DSFormId || strIsDraft == 'yes') {
                    setPsrProjectDetails();
                }
                var isWorkingUserAdmin = ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("workspace - administrator") > -1;
                if ($scope.DSFormId != "" && strIsDraft == 'no' && $scope.DS_ORIGINATOR != $scope.DS_WORKINGUSER && !isWorkingUserAdmin) {
                    $scope.disabledDate = true;
                    $scope.isEditori = true;
                }

                if ($scope.DSFormId == "" && strIsDraft == 'no') {

                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["General_Group"]["Created_By"] = currentUserName;

                }

                var dsChkpermission = $scope.getValueOfOnLoadData('DS_CHECK_FORM_PERMISSION_USER');
                if (dsChkpermission.length > 0) {
                    var element = dsChkpermission[0];
                    var workingUser = $scope.WorkingUserID.length && $scope.WorkingUserID[0].Name
                    var workingUserOrg = workingUser && workingUser.split(',')[1].trim()
                    if (element.Value3 == 'All_Org') {
                        $scope.reportBy = dsProjuser
                    }
                    else if (element.Value3 == 'Own_Org') {
                        $scope.reportBy = commonApi._.filter(dsProjuser, function (val) {
                            return val.Value.indexOf(workingUserOrg) != -1
                        });
                    }
                    else {
                        $scope.reportBy = $scope.WorkingUserID;
                    }

                    var reportName = commonApi._.filter($scope.reportBy, function (val) {
                        return val.Name.indexOf($scope.GenralGroup.Report_By) != -1
                    });
                    if (reportName == "") { $scope.GenralGroup.Report_By = ""; }
                }

                var companyParam = {
                    arrayObject: $scope.DS_ASI_Configurable_Attributes.filter(function (custObj) {
                        return custObj.Value3.toLowerCase() == 'company';
                    }),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                }

                var contactParam = {
                    arrayObject: $scope.DS_PROJDISTUSERS,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                }
                var reportByParam = {
                    arrayObject: $scope.reportBy,
                    groupNameKey: "",
                    modelKey: "Name",
                    displayKey: "Name"
                }

                var tempCompanyList = commonApi.getItemSelectionList(companyParam);
                var tempContactist = commonApi.getItemSelectionList(contactParam);
                var tempreportByParam = commonApi.getItemSelectionList(reportByParam);
                $scope.updateLists = {
                    companyList: function () {
                        return commonApi.getItemSelectionList(companyParam)
                    },
                    equipmentCompanyList: function () {
                        return commonApi.getItemSelectionList(companyParam)
                    },
                    qaQCCompanyList: function () {
                        return commonApi.getItemSelectionList(companyParam)
                    },
                    saftyCompanyList: function () {
                        return commonApi.getItemSelectionList(companyParam)
                    },
                    contactList: function () {
                        return commonApi.getItemSelectionList(contactParam)
                    },
                    saftycontactList: function () {
                        return commonApi.getItemSelectionList(contactParam)
                    },
                    qaQCContactList: function () {
                        return commonApi.getItemSelectionList(contactParam)
                    },
                    reportByList: function () {
                        return commonApi.getItemSelectionList(reportByParam)
                    }
                };

                $scope.filterDropdownList = {
                    companyList: tempCompanyList,
                    equipmentCompanyList: tempCompanyList,
                    qaQCCompanyList: tempCompanyList,
                    contactList: tempContactist,
                    saftycontactList: tempContactist,
                    qaQCContactList: tempContactist,
                    reportByList: tempreportByParam
                };
            }
            if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_PRINT_VIEW") {
                $scope.Reference = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'Reference' && val.Value11.indexOf('Active') != -1
                });
                $scope.Severity = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'Severity' && val.Value11.indexOf('Active') != -1
                });
                if ($scope.strFormId != "") {
                    dateReportOnChange();
                }
            }

        }

        $scope.dateReportOnChange = dateReportOnChange;
        function dateReportOnChange() {
            var selectedDate = $scope.GenralGroup.General_Date;
            selectedDate = commonApi.parseDate('yy-mm-dd', selectedDate);
            var dayName = commonApi.formatDate('DD', selectedDate);
            $scope.GenralGroup.Dayofweek = dayName;
            if ($scope.GenralGroup.General_Date == "") {
                return
            }
        }

        $scope.calculateLaborUnits = function (args) {
            if (args) {
                var total = 0;

                var strUnit = $scope.modelData['Units_Works'];
                var strWorker = args.curObj.No_Workers;
                if (!strUnit) {
                    strUnit = 0;
                }
                if (!strWorker) {
                    strWorker = 0;
                }
                total = parseInt(strUnit) * parseInt(strWorker);
                args.curObj.Labor_Unit = total;
            }
        }
        $scope.calculateAllLaborUnits = function () {
            var strUnit = $scope.modelData['Units_Works'];
            var strWorker = 0;
            for (var i = 0; i < $scope.modelData['Personnel_Group']['Personnel'].length; i++) {
                strWorker = $scope.modelData['Personnel_Group']['Personnel'][i].No_Workers;
                if (!strUnit) {
                    strUnit = 0;
                }
                if (!strWorker) {
                    strWorker = 0;
                }
                strWorker = $scope.modelData['Personnel_Group']['Personnel'][i].Labor_Unit = parseInt(strUnit) * parseInt(strWorker);
            }
        }

        function hideModal() {
            ctrl.model.modelId = '';
        }
        $scope.tableUtilSettings = {
            Weather: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Weather_isSelected",
                editRowCallBack: editWeatherModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Weather),
                deleteAllRowTooltip: "Remove all Weather Detail",
                deleteCurrRowMsg: "Remove Weather Detail",
                deleteSelectedMsg: "Remove selected Weather Detail"
            },
            Companies: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Companies_isSelected",
                editRowCallBack: editCompaniesModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Companies),
                deleteAllRowTooltip: "Remove all Companies Detail",
                deleteCurrRowMsg: "Remove Companies Detail",
                deleteSelectedMsg: "Remove selected Companies Detail"
            },
            Personnel: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Personnel_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Personnel),
                deleteAllRowTooltip: "Remove all Personnel Detail",
                deleteCurrRowMsg: "Remove Personnel Detail",
                deleteSelectedMsg: "Remove selected Personnel Detail"
            },
            Equipment: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Equipment_isSelected",
                editRowCallBack: editEquipmentModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Equipment),
                deleteAllRowTooltip: "Remove all Equipment Detail",
                deleteCurrRowMsg: "Remove Equipment Detail",
                deleteSelectedMsg: "Remove selected Equipment Detail"
            },
            Materials: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Materials_isSelected",
                editRowCallBack: editMaterialsModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Materials),
                deleteAllRowTooltip: "Remove all Materials Detail",
                deleteCurrRowMsg: "Remove Materials Detail",
                deleteSelectedMsg: "Remove selected Materials Detail"
            },
            Visitors: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Visitors_isSelected",
                editRowCallBack: editVisitorsModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Visitors),
                deleteAllRowTooltip: "Remove all Visitors Detail",
                deleteCurrRowMsg: "Remove Visitors Detail",
                deleteSelectedMsg: "Remove selected Visitors Detail"
            },
            Safety: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Safety_isSelected",
                editRowCallBack: editSafetyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Safety),
                deleteAllRowTooltip: "Remove all Safety Detail",
                deleteCurrRowMsg: "Remove Safety Detail",
                deleteSelectedMsg: "Remove selected Safety Detail"
            },
            QA_QC: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "QA_QC_isSelected",
                editRowCallBack: editQAQCModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.QA_QC),
                deleteAllRowTooltip: "Remove all QA/QC Detail",
                deleteCurrRowMsg: "Remove QA/QC Detail",
                deleteSelectedMsg: "Remove selected QA/QC Detail"
            },
            DiversionServices: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "Diversion_isSelected",
                editRowCallBack: editServiceModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.DiversionServices),
                deleteAllRowTooltip: "Remove all Diversion Services Detail",
                deleteCurrRowMsg: "Remove Diversion Services Detail",
                deleteSelectedMsg: "Remove selected Diversion Services Detail"
            },
            SignalEngineer: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "SignalEngineer_isSelected",
                editRowCallBack: editSingnalModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.SignalEngineer),
                deleteAllRowTooltip: "Remove all Diversion Services Detail",
                deleteCurrRowMsg: "Remove Diversion Services Detail",
                deleteSelectedMsg: "Remove selected Diversion Services Detail"
            },
            GOPiggybacked: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "GOPiggybacked_isSelected",
                editRowCallBack: editPiggyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.GOPiggybacked),
                deleteAllRowTooltip: "Remove all Diversion Services Detail",
                deleteCurrRowMsg: "Remove Diversion Services Detail",
                deleteSelectedMsg: "Remove selected Diversion Services Detail"
            },
            GOPiggybackedwith: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "GOPiggybackedwith_isSelected",
                editRowCallBack: editPiggywithModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.GOPiggybackedwith),
                deleteAllRowTooltip: "Remove all Diversion Services Detail",
                deleteCurrRowMsg: "Remove Diversion Services Detail",
                deleteSelectedMsg: "Remove selected Diversion Services Detail"
            },
            Flagging_Personnel: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0
                },
                checkboxModelKey: "Flagging_isSelected",
                editRowCallBack: editPiggyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Flagging_Personnel),
                deleteAllRowTooltip: "Remove all Flagging Personnel Detail",
                deleteCurrRowMsg: "Remove Flagging Personnel  Detail",
                deleteSelectedMsg: "Remove selected Flagging Personnel Detail"
            },
            Inspection_Protection: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0
                },
                checkboxModelKey: "Inspection_isSelected",
                editRowCallBack: editPiggyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Inspection_Protection),
                deleteAllRowTooltip: "Remove all Flagging Personnel Detail",
                deleteCurrRowMsg: "Remove Flagging Personnel  Detail",
                deleteSelectedMsg: "Remove selected Flagging Personnel Detail"
            },
            Work_Train: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0
                },
                checkboxModelKey: "WorkTrain_isSelected",
                editRowCallBack: editPiggyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Work_Train),
                deleteAllRowTooltip: "Remove all Flagging Personnel Detail",
                deleteCurrRowMsg: "Remove Flagging Personnel  Detail",
                deleteSelectedMsg: "Remove selected Flagging Personnel Detail"
            },
            Bulletin_Section: {
                tooltip: "select to remove/remove all/Edit Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0
                },
                checkboxModelKey: "SignalBulletin_isSelected",
                editRowCallBack: editPiggyModal,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Bulletin_Section),
                deleteAllRowTooltip: "Remove all Flagging Personnel Detail",
                deleteCurrRowMsg: "Remove Flagging Personnel  Detail",
                deleteSelectedMsg: "Remove selected Flagging Personnel Detail"
            }
        }

        $scope.setDescription = function (strValue) {
            var Csi_Code = commonApi._.filter($scope.Csi_Code, function (val) {
                return val.Value7 == strValue;
            });
            $scope.modelData.QA_QC_Description = Csi_Code[0] ? Csi_Code[0].Value8 : '';
        }
        $scope.setCurrentSection = function (tabURL) {
            (tabURL == 'Weather.html') && getkeyCodeFromZipCode();
            $scope.currentOriTab = tabURL;
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            });
        };

        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

        };

        function editWeatherModal(rowData) {
            $scope.openModal('Weather', rowData);
        }
        function setWorkersTotal() {
            var repeatindgData = $scope.companiesGroup["Companies"];
            for (var i = 0; i < repeatindgData.length; i++) {
                var workerTotal = 0;
                var laborUnitsTotal = 0;
                var repeatindgDataM = repeatindgData[i];
                var repeatingPersonnel = repeatindgDataM['Personnel_Group']['Personnel'];
                for (var j = 0; j < repeatingPersonnel.length; j++) {
                    workerTotal += parseInt(repeatingPersonnel[j].No_Workers || 0);
                    laborUnitsTotal += parseInt(repeatingPersonnel[j].Labor_Unit || 0);
                }
                repeatindgData[i].Workers = workerTotal;
                repeatindgData[i].laborTotal = laborUnitsTotal;
            }
        };

        function editCompaniesModal(rowData) {
            $scope.openModal('Companies', rowData);
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            });
        }
        function editEquipmentModal(rowData) {
            $scope.openModal('Equipment', rowData);
        }
        function editMaterialsModal(rowData) {
            $scope.openModal('Materials', rowData);
        }

        function editVisitorsModal(rowData) {
            $scope.openModal('Visitors', rowData);
        }
        function editSafetyModal(rowData) {
            $scope.openModal('Safety', rowData);
        }
        function editQAQCModal(rowData) {
            var tempRowData = angular.copy(rowData);
            $scope.openModal('QA_QC', tempRowData);
        }
        function editServiceModal(rowData) {
            var tempRowData = angular.copy(rowData);
            $scope.openModal('DiversionServices', tempRowData);
        }
        function editSingnalModal(rowData) {
            var tempRowData = angular.copy(rowData);
            $scope.openModal('SignalEngineer', tempRowData);
        }
        function editPiggyModal(rowData) {
            var tempRowData = angular.copy(rowData);
            $scope.openModal('GOPiggybacked', tempRowData);
        }
        function editPiggywithModal(rowData) {
            var tempRowData = angular.copy(rowData);
            $scope.openModal('GOPiggybackedwith', tempRowData);
        }

        $scope.restrictCharOnlyNumberPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                event.preventDefault();
                return false;
            }
        }

        $scope.setPowerBlank = function () {
            var val = $scope.secCGroup.Power_Off;
            if (val == "Yes") {
                $scope.secCGroup['Power_on_date'] = '';
            }
            else {
                $scope.secCGroup['Power_off_date'] = '';
            }
        }
        $scope.setLocationDetail = function (strValue) {
            var strLocation = commonApi._.filter($scope.Contract, function (val) {
                return strValue && val.Value2.toLowerCase() == strValue.toLowerCase()
            });
            $scope.GenralGroup['General_Location'] = '';
            $scope.GenralGroup['General_Zip'] = '';

            if (strLocation && strLocation.length > 0) {
                for (var i = 0; i < strLocation.length; i++) {
                    $scope.GenralGroup['General_Location'] = strLocation[i].Value3;
                    $scope.GenralGroup['General_Zip'] = strLocation[i].Value4;
                }
            }
        }
        $scope.setSectionBlank = function () {
            var val = $scope.oriMsgCustomFields.Diversion_Service;
            if (val == "NO") {

                //Section C 
                $scope.secCGroup['DiversionServices'] = [];
                var newRowObject = angular.copy(STATIC_OBJ_DATA.DiversionServices || {});
                $scope.secCGroup['DiversionServices'].push(newRowObject);
                $scope.secCGroup['Command_Center'] = '';
                $scope.secCGroup['Command_Contact'] = '';
                $scope.secCGroup['Power_Off'] = '';
                $scope.secCGroup['Power_on_date'] = '';
                $scope.secCGroup['Power_off_date'] = '';
                $scope.secCGroup['Command_Center_Go'] = '';
                $scope.secCGroup['Command_Center_talked'] = '';
                $scope.secCGroup['Command_Tracked'] = '';
                $scope.secCGroup['Command_Area'] = '';
                $scope.secCGroup['GOPiggybacked'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.GOPiggybacked || {});
                $scope.secCGroup['GOPiggybacked'].push(newRowObject);
                $scope.secCGroup['Piggybacked_No'] = '';
                $scope.secCGroup['Piggybacked_Track'] = '';
                $scope.secCGroup['Piggybacked_Limit'] = '';

                //Section D 
                $scope.secDGroup['Flagging_Personnel'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.Flagging_Personnel || {});
                $scope.secDGroup['Flagging_Personnel'].push(newRowObject);

                $scope.secDGroup['Inspection_Protection'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.Inspection_Protection || {});
                $scope.secDGroup['Inspection_Protection'].push(newRowObject);

                $scope.secDGroup['Work_Train'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.Work_Train || {});
                $scope.secDGroup['Work_Train'].push(newRowObject);

                $scope.secDGroup['Bulletin_Section'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.Bulletin_Section || {});
                $scope.secDGroup['Bulletin_Section'].push(newRowObject);

                $scope.secDGroup['SignalEngineer'] = [];
                newRowObject = angular.copy(STATIC_OBJ_DATA.SignalEngineer || {});
                $scope.secDGroup['SignalEngineer'].push(newRowObject);

                $scope.secDGroup.SignalmanName = '';
                $scope.secDGroup.SignalmanMTA = '';
                $scope.secDGroup.SignalmanMTAPassNo = '';
                $scope.secDGroup.SignalmanContractor = '';
                $scope.secDGroup.SignalmanScopeOfWork = '';
                $scope.secDGroup.SignalmanWeekday = '';
                $scope.secDGroup.SignalmanDayNight = '';
                $scope.secDGroup.SignalmanWeekend = '';
                $scope.secDGroup.SignalmanWeekendDayNight = '';
                $scope.secDGroup.SignalmanRoomLocation = '';
                $scope.secDGroup.SignalmanElevated = '';
                $scope.secDGroup.SignalmanWayside = '';
                $scope.secDGroup.SignalmanInStation = '';
                $scope.secDGroup.SignalmanEIC = '';
                $scope.secDGroup.SignalmanPassNo = '';
                $scope.secDGroup.SignalmanCIR = '';
                $scope.secDGroup.SignalmanCIRElevated = '';
                $scope.secDGroup.SignalmanCIRWayside = '';
                $scope.secDGroup.SignalmanCIRInStation = '';
            }
        }


        $scope.restrictCharOnlyNumber = function (event, isfloat) {
            $scope.restrictChar(event);
            var validKeys = [];
            if (isfloat == true)
                validKeys = [46, 8, 9, 27, 13, 110, 190];
            else
                validKeys = [46, 8, 9, 27, 13];
            // Allow: backspace, delete, tab, escape, enter and .
            if (validKeys.indexOf(event.keyCode) !== -1 ||
                // Allow: Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X, Command+A
                ((event.keyCode == 65 || event.keyCode == 86 || event.keyCode == 88 || event.keyCode == 67) && (event.ctrlKey === true || event.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (event.keyCode >= 35 && event.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress

            if (((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) || (event.shiftKey && event.keyCode > 57)) {
                event.preventDefault();
            }
        }

        // Weather api related code.        
        $scope.apiKeyId = 'zvUADqfSbXSklYSVLwbGxvWMHgrALLBb';
        $scope.weatherXhrOn = false;
        $scope.keyCode = '';

        function getkeyCodeFromZipCode() {
            if (!$scope.GenralGroup.General_Zip) {
                $scope.keyCode = '';
                return false;
            }

            $scope.weatherXhrOn = true;
            commonApi.ajax({
                url: '//dataservice.accuweather.com/locations/v1/postalcodes/US/search?apikey=' + $scope.apiKeyId + '&details=true&q=' + $scope.GenralGroup.General_Zip,
                method: 'GET',
                cache: false,
                crossDomain: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                datatype: "json"
            }).then(function (response) {
                $scope.weatherXhrOn = false;
                keyCodeData = response.data;
                $scope.keyCode = '';
                if (keyCodeData.length) {
                    $scope.keyCode = keyCodeData[0].Key;
                }
            }, function (xhr) {
                $scope.weatherXhrOn = false;
                Notification.error({
                    title: 'Server Error',
                    message: 'Error while fetching folders list of current workspace'
                });
            });
        }

        var setTimeFrameData = function (timeFrameStr) {
            var dateTime = timeFrameStr,
                dateStr = '', timeStr = '',
                hours = '', minutes = '',
                dateObj = new Date(timeFrameStr);
            if (dateObj instanceof Date && !isNaN(dateObj)) {
                dateStr = $scope.formatDate(dateObj, 'mm-dd-yy');
                timeStr = dateObj.toLocaleTimeString({}, {
                    hour12: true,
                    hour: '2-digit',
                    minute: '2-digit'
                }).replace(/[^ -~]/g, '');
                dateTime = timeStr + ' ' + dateStr;
            }
            return dateTime;
        };

        var setWeatherData = function (weatherDataObj) {
            $scope.modelData.TimeFrame = setTimeFrameData(weatherDataObj.LocalObservationDateTime);
            // past 6 hrs
            $scope.modelData.Low_Temp = weatherDataObj.TemperatureSummary.Past6HourRange.Minimum.Imperial.Value;
            $scope.modelData.High_Temp = weatherDataObj.TemperatureSummary.Past6HourRange.Maximum.Imperial.Value;
            // current one
            $scope.modelData.Current_Temp = weatherDataObj.Temperature.Imperial.Value;
            $scope.modelData.Conditions = weatherDataObj.WeatherText;
            $scope.modelData.Humidity = weatherDataObj.RelativeHumidity;
            $scope.modelData.Visiblity = weatherDataObj.Visibility.Imperial.Value;
            $scope.modelData.Pricip = weatherDataObj.Precip1hr.Imperial.Value;
            $scope.modelData.Windspeed = weatherDataObj.Wind.Speed.Imperial.Value;
            $scope.modelData.WindDescription = weatherDataObj.Wind.Direction.Degrees + ' ' + weatherDataObj.Wind.Direction.English;
        };

        function getWeatherData() {
            $scope.weatherXhrOn = true;
            commonApi.ajax({
                url: '//dataservice.accuweather.com/currentconditions/v1/' + $scope.keyCode + '?apikey=' + $scope.apiKeyId + '&details=true',
                method: 'GET',
                cache: false,
                crossDomain: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                datatype: "json"
            }).then(function (response) {
                $scope.weatherXhrOn = false;
                weatherData = response.data;
                if (weatherData.length) {
                    setWeatherData(weatherData[0]);
                }
                $scope.update();
            }, function (xhr) {
                $scope.weatherXhrOn = false;
                Notification.error({
                    title: 'Server Error',
                    message: 'Error while fetching folders list of current workspace'
                });
            });
        };

        $scope.getWeatherData = function () {
            getWeatherData();
        }

        $scope.resetRow = function (node, nodeKey, listKey) {
            node[nodeKey] = '';
            $scope.filterDropdownList[listKey] = $scope.updateLists[listKey]();
            if (nodeKey == "Contact") { node['Safety_Company'] = ""; }
        }

        var iCount = 0;
        //Get priviousdata
        function getPreviousData(tickcheckbox) {
            var tabid = tickcheckbox[iCount];
            if (tabid) {
                var selectedFormId = $scope.modelData.formId;
                $scope.isDataLoaded = false;
                var strParam = selectedFormId + "|" + tabid.trim();
                var spName = 'DS_MTA_DREP_GET_PREVIOUS_DATA';
                var form = {
                    "projectId": projectId,
                    "fields": spName,
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": spName,
                            "fieldValue": strParam
                        }]
                    }
                };
                if (tabid == 'Support_Services') {
                    form.callbackParamVO.customFieldVOList[0].fieldValue = selectedFormId + "|" + "SectionC_Group"
                }
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var resData = angular.fromJson(response.data[spName]).Items.Item;
                        if (tabid == "General") {
                            setGeneralData(resData);
                        }
                        if (tabid == "QA_QC") {
                            setQAQCData(resData)
                        }
                        if (tabid == "Materials") {
                            setMaterialsData(resData)
                        }
                        if (tabid == "Equipment") {
                            setEquipmentData(resData)
                        }
                        if (tabid == "Companies") {
                            setCompaniesData(resData)
                        }
                        if (tabid == "Visitors") {
                            setVisitorsData(resData)
                        }
                        if (tabid == "Safety") {
                            setSafetyData(resData)
                        }
                        if (tabid == "Inspection_Hold_Point") {
                            setInspectionHoldPointData(resData)
                        }
                        if (tabid == "Support_Services") {
                            setSectionCData(resData); // TO Set Section C Data 
                            form.callbackParamVO.customFieldVOList[0].fieldValue = selectedFormId + "|" + "SectionD_Group"
                            $scope.getCallbackData(form).then(function (response) {
                                if (response.data) {
                                    var resData = angular.fromJson(response.data[spName]).Items.Item;
                                    setSectionDData(resData); // TO set section D Data

                                }
                            });
                        }
                        $timeout(function () {
                            $scope.expandTextAreaOnLoad();
                        }, 200);

                        iCount++;
                        if (iCount < tickcheckbox.length) {
                            getPreviousData(tickcheckbox);
                        } else {
                            $scope.isDataLoaded = true;
                        }
                    }
                });
            }
        }
        $scope.setLabourunit = function () {

        }

        function setVisitorsData(resData) {
            if (resData.length) {
                var i = 0;
                $scope.visitorsGroup.Visitors = [];
                for (; i < resData.length; i++) {
                    var tempData = angular.copy(STATIC_OBJ_DATA.Visitors)
                    tempData.Item = parseInt(i) + 1;
                    tempData.Visitor_Name = resData[i].Value2;
                    tempData.Visitor_Comapny = resData[i].Value5;
                    tempData.Visit_Date = resData[i].Value3;
                    tempData.Visit_Time = resData[i].Value4;
                    $scope.visitorsGroup.Visitors.push(tempData);
                }
                $scope.GenralGroup.General_Visitor = resData[0].Value6
            }
        }

        function setSafetyData(resData) {
            if (resData.length) {
                var i = 0;
                $scope.safetyGroup.Safety = [];
                for (; i < resData.length; i++) {

                    var tempData = angular.copy(STATIC_OBJ_DATA.Safety)
                    tempData.Item = parseInt(i) + 1;
                    tempData.Safety_Date = resData[i].Value7;
                    tempData.Safety_Time = resData[i].Value17;
                    tempData.Contact = resData[i].Value8.replace("||", "#");
                    tempData.Safety_Company = resData[i].Value2;
                    tempData.Contact_Other = resData[i].Value9;
                    tempData.Notis_By = resData[i].Value5.replace("||", "#");
                    tempData.Work_Activity = resData[i].Value18;
                    tempData.Safty_Issue = resData[i].Value15;
                    tempData.Hours_Lost = resData[i].Value11;
                    tempData.Work_Hours = resData[i].Value26;
                    tempData.Reference = resData[i].Value3;
                    tempData.Serverity = resData[i].Value4;
                    tempData.Requirement = resData[i].Value10;
                    tempData.Require_By = resData[i].Value14;
                    tempData.Outcome = resData[i].Value13;
                    tempData.Completed = resData[i].Value16;
                    tempData.Checked_By = resData[i].Value12;
                    tempData.Work_Location = resData[i].Value19;
                    tempData.Brif_Work_Desc = resData[i].Value20;
                    tempData.Corrective_Measures = resData[i].Value21;
                    tempData.Non_Right = resData[i].Value22;
                    tempData.Track_Safety = resData[i].Value23;
                    tempData.Severity = resData[i].Value30;
                    $scope.safetyGroup.Safety.push(tempData);
                }
                $scope.GenralGroup.General_Safety = resData[0].Value24
            }
        }

        function setInspectionHoldPointData(resData) {
            if (resData.length) {
                $scope.secEGroup.Inspected_Work = resData[0].Value7;
                $scope.secEGroup.Defects_Noted = resData[0].Value8;
                $scope.secEGroup.Hold_Points = resData[0].Value4;
                $scope.secEGroup.Instructions_Contractor = resData[0].Value5;
                $scope.secEGroup.Instructions_Performed = resData[0].Value9;
                $scope.secEGroup.Drawings_Section = resData[0].Value2;
                $scope.secEGroup.Inspections_Perform = resData[0].Value6;
                $scope.secEGroup.Nonconformance_Action = resData[0].Value3;
                $scope.secEGroup.Safety_Action = resData[0].Value10;
            }
        }

        function setSectionCData(resData) {
            var tempData;
            if (resData.length) {
                $scope.secCGroup.DiversionServices = [];
                $scope.secCGroup.GOPiggybacked = [];
                $scope.secCGroup.GOPiggybackedwith = [];
                for (var i = 0; i < resData.length; i++) {
                    // for GO
                    if (resData[i].Value36 == 'DiversionServices') {
                        tempData = angular.copy(STATIC_OBJ_DATA.DiversionServices);
                        tempData.GO_No = resData[i].Value22;
                        tempData.GO_Owner = resData[i].Value18;
                        tempData.Support_Timecall = resData[i].Value23;
                        tempData.Support_Timecalloff = resData[i].Value19;
                        tempData.Support_Dept = resData[i].Value20;
                        tempData.Support_Dept_Cont = resData[i].Value17;
                        tempData.Track = resData[i].Value25;
                        tempData.Limits = resData[i].Value21;
                        $scope.secCGroup.DiversionServices.push(tempData);
                    }
                    if (resData[i].Value36 == 'SectionC_Group') {
                        // for GO bottom portion
                        $scope.secCGroup.Command_Center = resData[i].Value16
                        $scope.secCGroup.Command_Contact = resData[i].Value14
                        $scope.secCGroup.Power_Off = resData[i].Value2
                        $scope.secCGroup.Power_off_date = resData[i].Value3
                        $scope.secCGroup.Power_on_date = resData[i].Value5
                        $scope.secCGroup.Command_Center_Go = resData[i].Value15
                        $scope.secCGroup.Command_Center_talked = resData[i].Value6
                        $scope.secCGroup.Command_Tracked = resData[i].Value7
                        $scope.secCGroup.Command_Area = resData[i].Value10
                        // for Piggyback  
                        $scope.secCGroup.Piggybacked_No = resData[i].Value13
                        $scope.secCGroup.Piggybacked_Track = resData[i].Value9
                        $scope.secCGroup.Piggybacked_Limit = resData[i].Value8
                        $scope.secCGroup.Piggybacked_Contractor = resData[i].Value11
                        $scope.secCGroup.Piggybacked_TA_Office = resData[i].Value4
                        $scope.secCGroup.Piggybacked_EIC = resData[i].Value12
                    }
                    //for GO section piggyback 
                    if (resData[i].Value36 == 'GOPiggybacked') {
                        tempData = angular.copy(STATIC_OBJ_DATA.GOPiggybacked);
                        tempData.GOPiggybacked_Contractor = resData[i].Value26;
                        tempData.GOPiggybacked_TA_Office = resData[i].Value27;
                        tempData.GOPiggybacked_EIC = resData[i].Value29;
                        tempData.GOPiggybacked_CM_Num = resData[i].Value28;
                        $scope.secCGroup.GOPiggybacked.push(tempData);
                    }
                    //for GO section piggyback with
                    if (resData[i].Value36 == 'GOPiggybackedwith') {
                        tempData = angular.copy(STATIC_OBJ_DATA.GOPiggybackedwith);
                        tempData.GOPiggybackedwith_Contractor = resData[i].Value32;
                        tempData.GOPiggybackedwith_TA_Office = resData[i].Value31;
                        tempData.GOPiggybackedwith_EIC = resData[i].Value34;
                        tempData.GOPiggybackedwith_CM_Num = resData[i].Value33;
                        $scope.secCGroup.GOPiggybackedwith.push(tempData);
                    }
                }
            }

        }

        function setSectionDData(resData) {
            var tempData;
            if (resData.length) {
                $scope.secDGroup.Flagging_Personnel = [];
                $scope.secDGroup.Inspection_Protection = [];
                $scope.secDGroup.Work_Train = [];
                $scope.secDGroup.Bulletin_Section = [];
                $scope.secDGroup.SignalEngineer = [];

                for (var i = 0; i < resData.length; i++) {
                    // Flagging Personnel
                    if (resData[i].Value18 == 'Flagging_Personnel') {
                        tempData = angular.copy(STATIC_OBJ_DATA.Flagging_Personnel);
                        tempData.Flagging_Name = resData[i].Value12;
                        tempData.Flagging_Passno = resData[i].Value10;
                        tempData.Flagging_Time_in = resData[i].Value9;
                        //tempData.TFlagging_ime_out = resData[i].Value7;
                        tempData.Flagging_Time_out = resData[i].Value8;
                        tempData.Flagging_Lunch = resData[i].Value6;
                        $scope.secDGroup.Flagging_Personnel.push(tempData);
                    }
                    // Inspection / Access & Protection
                    if (resData[i].Value18 == 'Inspection_Protection') {
                        tempData = angular.copy(STATIC_OBJ_DATA.Inspection_Protection);
                        tempData.Inspection_Name = resData[i].Value17;
                        tempData.Inspection_Pass = resData[i].Value13;
                        tempData.Inspection_Time_in = resData[i].Value16;
                        tempData.Inspection_Time_out = resData[i].Value14;
                        $scope.secDGroup.Inspection_Protection.push(tempData);
                    }
                    // Work Train
                    if (resData[i].Value18 == 'Work_Train') {
                        tempData = angular.copy(STATIC_OBJ_DATA.Work_Train);
                        tempData.SectionD_Consist = resData[i].Value4;
                        tempData.SectionD_Track = resData[i].Value3;
                        tempData.SectionD_Arrival = resData[i].Value5;
                        tempData.SectionD_Departure = resData[i].Value2;
                        $scope.secDGroup.Work_Train.push(tempData);
                    }

                    // Bulletin Section
                    if (resData[i].Value18 == 'Bulletin_Section') {
                        tempData = angular.copy(STATIC_OBJ_DATA.Bulletin_Section);
                        tempData.Bulletin_Number = resData[i].Value20;
                        tempData.Bulletin_Date = resData[i].Value21;
                        tempData.Bulletin_Owner = resData[i].Value22;
                        tempData.Bulletin_Call_On = resData[i].Value23;
                        tempData.Bulletin_Supervisor_Name_On = resData[i].Value24;
                        tempData.Bulletin_Pass_No_On = resData[i].Value25;
                        tempData.Bulletin_Call_Off = resData[i].Value26;
                        tempData.Bulletin_Supervisor_Name_Off = resData[i].Value27;
                        tempData.Bulletin_Pass_No_Off = resData[i].Value28;
                        $scope.secDGroup.Bulletin_Section.push(tempData);
                    }

                    // Signal Engineer
                    if (resData[i].Value18 == 'SignalEngineer') {
                        tempData = angular.copy(STATIC_OBJ_DATA.SignalEngineer);
                        tempData.SignalEngineerName = resData[i].Value29;
                        tempData.SignalMTA = resData[i].Value30;
                        tempData.MTAPassNo = resData[i].Value31;
                        tempData.SignalContractor = resData[i].Value32;
                        tempData.SignalScopeOfWork = resData[i].Value33;
                        tempData.SignalWeekday = resData[i].Value34;
                        tempData.SignalDayNight = resData[i].Value35;
                        tempData.SignalWeekend = resData[i].Value36;
                        tempData.SignalWeekendDayNight = resData[i].Value37;
                        tempData.SignalRoomLocation = resData[i].Value38;
                        tempData.SignalElevated = resData[i].Value39;
                        tempData.SignalWayside = resData[i].Value40;
                        tempData.SignalInStation = resData[i].Value41;
                        tempData.SignalEIC = resData[i].Value42;
                        tempData.SignalPassNo = resData[i].Value43;
                        tempData.CIR = resData[i].Value44;
                        tempData.CIRElevated = resData[i].Value45;
                        tempData.CIRWayside = resData[i].Value46;
                        tempData.CIRInStation = resData[i].Value47;
                        $scope.secDGroup.SignalEngineer.push(tempData);
                    }

                    // Signal man
                    if (resData[i].Value18 == 'SectionD_Group') {
                        $scope.secDGroup.SignalmanName = resData[i].Value48;
                        $scope.secDGroup.SignalmanMTA = resData[i].Value49;
                        $scope.secDGroup.SignalmanMTAPassNo = resData[i].Value50;
                        $scope.secDGroup.SignalmanContractor = resData[i].Value51;
                        $scope.secDGroup.SignalmanScopeOfWork = resData[i].Value52;
                        $scope.secDGroup.SignalmanWeekday = resData[i].Value53;
                        $scope.secDGroup.SignalmanDayNight = resData[i].Value54;
                        $scope.secDGroup.SignalmanWeekend = resData[i].Value55;
                        $scope.secDGroup.SignalmanWeekendDayNight = resData[i].Value56;
                        $scope.secDGroup.SignalmanRoomLocation = resData[i].Value57;
                        $scope.secDGroup.SignalmanElevated = resData[i].Value58;
                        $scope.secDGroup.SignalmanWayside = resData[i].Value59;
                        $scope.secDGroup.SignalmanInStation = resData[i].Value60;
                        $scope.secDGroup.SignalmanEIC = resData[i].Value61;
                        $scope.secDGroup.SignalmanPassNo = resData[i].Value62;
                        $scope.secDGroup.SignalmanCIR = resData[i].Value63;
                        $scope.secDGroup.SignalmanCIRElevated = resData[i].Value64;
                        $scope.secDGroup.SignalmanCIRWayside = resData[i].Value65;
                        $scope.secDGroup.SignalmanCIRInStation = resData[i].Value66;
                    }
                }
            }
        }

        function setGeneralData(resData) {
            if (resData.length) {
                $scope.GenralGroup.State = resData[0].Value13;
                $scope.GenralGroup.Author = resData[0].Value7;
                $scope.GenralGroup.Report_By = resData[0].Value16;
                $scope.GenralGroup.Shift = resData[0].Value2;
                $scope.GenralGroup.Type = resData[0].Value11;
                $scope.GenralGroup.Document_Template = resData[0].Value5;
                $scope.GenralGroup.Non_Work_Day = resData[0].Value10;
                $scope.GenralGroup.Cause = resData[0].Value15;
                $scope.GenralGroup.Refrence_No = resData[0].Value6;
                $scope.GenralGroup.General_Contract = resData[0].Value19;
                $scope.GenralGroup.Location = resData[0].Value20;
                $scope.GenralGroup.ZipCode = resData[0].Value21;
                $scope.GenralGroup.Quick_Report = resData[0].Value14;
                $scope.filterDropdownList.reportByList = commonApi.getItemSelectionList({
                    arrayObject: $scope.reportBy,
                    groupNameKey: "",
                    modelKey: "Name",
                    displayKey: "Name"
                });
                $scope.setLocationDetail(resData[0].Value19);
            }
        }
        function setQAQCData(resData) {
            if (resData.length) {
                var i = 0;
                $scope.qaqcGroup.QA_QC = [];
                for (; i < resData.length; i++) {
                    var tempQAData = angular.copy(STATIC_OBJ_DATA.QA_QC)
                    tempQAData.Item = parseInt(i) + 1;
                    tempQAData.Csi_Code = resData[i].Value2;
                    tempQAData.QA_QC_Description = resData[i].Value4;
                    tempQAData.QA_QC_Company = resData[i].Value3.indexOf('||') != '-1' ? resData[i].Value3.replace("||", "#") : resData[i].Value3;
                    tempQAData.Issued_By = resData[i].Value5;
                    tempQAData.QA_QC_Location = resData[i].Value6;
                    tempQAData.QA_QC_Drawing_No = resData[i].Value7;
                    tempQAData.QA_QC_Insp_Name = resData[i].Value8.indexOf('||') != '-1' ? resData[i].Value8.replace("||", "#") : resData[i].Value8;
                    tempQAData.QA_QC_Activity = resData[i].Value9;
                    tempQAData.QA_QC_Contract = resData[i].Value10;
                    tempQAData.QA_QC_Material = resData[i].Value11;
                    tempQAData.QA_QC_Equipment = resData[i].Value12;
                    tempQAData.QA_QC_Procedure = resData[i].Value13;
                    $scope.GenralGroup.General_QA_QC = resData[0].Value14
                    $scope.qaqcGroup.QA_QC.push(tempQAData);
                }

            }
        }
        function setMaterialsData(resData) {
            if (resData.length) {
                var i = 0;
                $scope.materialsGroup.Materials = [];
                for (; i < resData.length; i++) {
                    var tempData = angular.copy(STATIC_OBJ_DATA.Materials)
                    tempData.Item = parseInt(i) + 1;
                    tempData.Materials_Description = resData[i].Value3;
                    tempData.Category = resData[i].Value4;
                    tempData.Qty_Recived = resData[i].Value6;
                    tempData.Qty_Rejected = resData[i].Value2;
                    tempData.Location = resData[i].Value10;
                    tempData.Unit = resData[i].Value7
                    tempData.Materials_Date = resData[i].Value8;
                    tempData.Materials_Time = resData[i].Value5;
                    $scope.GenralGroup.General_Material = resData[i].Value9;
                    $scope.materialsGroup.Materials.push(tempData);
                }

            }
        }
        function setEquipmentData(resData) {
            if (resData.length) {
                var i = 0;
                $scope.equipmentGroup.Equipment = [];
                for (; i < resData.length; i++) {
                    var tempData = angular.copy(STATIC_OBJ_DATA.Equipment)
                    tempData.Item = parseInt(i) + 1;
                    tempData.Equipment_Description = resData[i].Value7;
                    tempData.Item_Type = resData[i].Value3;
                    tempData.Source = resData[i].Value9;
                    tempData.Equipment_Company = resData[i].Value4.indexOf('||') != '-1' ? resData[i].Value4.replace("||", "#") : resData[i].Value4;
                    tempData.Location_Used = resData[i].Value8;
                    tempData.Status = resData[i].Value2
                    tempData.Reading = resData[i].Value5;
                    tempData.UOM = resData[i].Value6;
                    $scope.GenralGroup.General_Equipment = resData[i].Value10;
                    $scope.equipmentGroup.Equipment.push(tempData);
                }

            }
        }

        function setCompaniesData(resData) {
            if (resData.length) {
                var i = 0, j = 0;
                $scope.companiesGroup.Companies = [];
                for (; i < resData.length; i++) {
                    var tempData = angular.copy(STATIC_OBJ_DATA.Companies)
                    tempData.Item = parseInt(i) + 1;
                    tempData.Companies_Company = resData[i].Value2.indexOf('||') != '-1' ? resData[i].Value2.replace("||", "#") : resData[i].Value2;
                    tempData.Work_Location = resData[i].Value4;
                    tempData.Work_Activity = resData[i].Value9;
                    tempData.Expected_Workers = resData[i].Value3;
                    tempData.Units_Works = resData[i].Value8;
                    var workerTotal = 0, laborUnitsTotal = 0;
                    var personnelData = "";
                    tempData.Personnel_Group.Personnel = [];
                    if (resData[i].Value10.indexOf("$!$") < 0) {
                        personnelData = resData[i].Value10.split("$@$");
                        var tempDataP = angular.copy(STATIC_OBJ_DATA.Personnel);
                        tempDataP.Personnel_Type = personnelData[1];
                        tempDataP.Labor_Type = personnelData[2];
                        tempDataP.No_Workers = personnelData[3];
                        tempDataP.Labor_Unit = personnelData[4];
                        tempData.Personnel_Group.Personnel.push(tempDataP);
                        workerTotal += parseInt(personnelData[3] || 0);
                        laborUnitsTotal += parseInt(personnelData[4] || 0);
                    }
                    else {
                        personnelData = resData[i].Value10.split("$!$");
                        j = 0;
                        for (; j < personnelData.length; j++) {
                            var tempDataP = angular.copy(STATIC_OBJ_DATA.Personnel);
                            var typeData = personnelData[j].split('$@$');
                            tempDataP.Personnel_Type = typeData[1];
                            tempDataP.Labor_Type = typeData[2];
                            tempDataP.No_Workers = typeData[3];
                            tempDataP.Labor_Unit = typeData[4];
                            tempData.Personnel_Group.Personnel.push(tempDataP);
                            workerTotal += parseInt(typeData[3] || 0);
                            laborUnitsTotal += parseInt(typeData[4] || 0);

                        }
                    }
                    tempData.Workers = workerTotal;
                    tempData.laborTotal = laborUnitsTotal;
                    $scope.GenralGroup.General_Company = resData[i].Value11;
                    $scope.companiesGroup.Companies.push(tempData);
                }
            }
        }
        function checkMandatoryFields() {
            var isRetuFlag = false;
            if (currentViewName == "ORI_VIEW") {
                $scope.GenralGroup.Modified_By = currentUserName;
                $scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.GenralGroup.Report_By;
                if (!$scope.GenralGroup.General_Date || !$scope.GenralGroup.Report_By || !$scope.GenralGroup.General_Contract) {
                    Notification.error({
                        title: 'Alert',
                        message: 'This form contains validation errors or mandatory fields are not specified. Errors are marked with either a red asterisk (required fields) or a red dashed border (invalid values). Please update and click on Create/Update button again.'
                    });

                    isRetuFlag = true;
                }

                if (($scope.DSFormId == "" && strIsDraft == 'no') || ($scope.DSFormId != "" && strIsDraft == 'yes')) {
                    $scope.oriMsgCustomFields.ORI_USERREF = $scope.GenralGroup.General_Date;
                }
            }
            return isRetuFlag;   
        }

        $scope.dateChangeEvent = function (modelObj) {
            $scope.filterDropdownList.formIdList = [];
            var selectedDate = modelObj.Date;
            if (selectedDate) {
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": "DS_MTA_DREP_All_Form_By_Date",
                        "fieldValue": selectedDate
                    }],
                    successCallback: function (responseList) {
                        var fillFormId = responseList["DS_MTA_DREP_All_Form_By_Date"];
                        if (fillFormId[0].Value1) {
                            $scope.filterDropdownList.formIdList = commonApi.getItemSelectionList({
                                arrayObject: fillFormId,
                                displayKey: "Value1",
                                modelKey: "Value1",
                            });

                        } else {
                            alert("No Daily Report for selected date.");
                        }
                    }
                };
                $scope.getCallbackSPdata(spParam);
            }
        }


        //TO solve error on edit ori when save action when attachment available
        //NOODLE-97315
        var isfunctionToCall = (currentViewName == "ORI_VIEW" && $scope.data.myFields.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMID);
        function getInlineAttachmentNodes() {
            var attachmentList = [];
            for (var key in $scope.oriMsgCustomFields.Safety_Group.Safety) {
                if ($scope.oriMsgCustomFields.Safety_Group.Safety[key]) {
                    attachmentList.push($scope.oriMsgCustomFields.Safety_Group.Safety[key].Non_Right_Attachment);
                    attachmentList.push($scope.oriMsgCustomFields.Safety_Group.Safety[key].Track_Safety_Attachment);
                }
            }
            return attachmentList;
        }
        function setInlineAttachmentNodes() {
            var inlineAttachmentList = getInlineAttachmentNodes(),
                attachMentObj = {};
            for (var i = 0; i < inlineAttachmentList.length; i++) {
                attachMentObj = inlineAttachmentList[i];

                if (typeof attachMentObj != 'object') {
                    continue
                }

                $scope.insertAttachmentField({
                    xdName: attachMentObj['@inline'],
                    xdocId: attachMentObj['@inline'].split(':')[0],
                    content: attachMentObj.content
                });
            }
        }

        $window.MTA_FinalCallBack = function () {
            if ($window.confirm("Are you sure you want to send this form?")) {
                return checkMandatoryFields();
            }
            else {
                return true;
            }
        }

        $scope.update();
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof MTA_FinalCallBack !== "undefined") {
        return MTA_FinalCallBack();
    }
}