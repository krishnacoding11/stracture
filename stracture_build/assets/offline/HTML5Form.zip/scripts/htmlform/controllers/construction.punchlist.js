define(['angular', './base', '../components/item.selection'], function (angular, baseController) {
    'use strict';

    /*
    * @constructor
    * @alias module:Form-Controller/FormController
    */
    function FormController($scope, $element, $document, $filter,commonApi, $controller, $window, $timeout,Notification) {
        var printedOn = "";
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        }; 
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        var currentViewName = window.currentViewName;
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.commissioningGrp = $scope.formCustomFields["Commissioning_Details"];
        var guID = $scope.getValueOfOnLoadData('DS_GET_GUID');
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var allformStatusWS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_WS_STATUS');
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.workingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.punchListTask = $scope.getValueOfOnLoadData('DS_NNG_COMM_XPTdetailsfromXPL');
        var projUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        $scope.cmtDisplay=false;
        var formStatus =$scope.asiteSystemDataReadOnly['_5_Form_Data']["Status_Data"]["DS_ALL_FORMSTATUS"];
        formStatus=formStatus&&formStatus.split('#')[1].trim();
        $scope.modifiedIndex=0;
        $scope.isEditORI = ($scope.strFormId != '' && $scope.strIsDraft == 'NO');
        $scope.allAprroved=false;
        $scope.editOriDisp=false;
        $scope.isConcUser = false;
        $scope.dispDiv =false;
        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.operations_RES={
            opComments:"",
            opAcceptObj:"",
            Is_Old:"New"
        }
        $scope.concStructure = {
            Contractor_Name: ""
        }
        $scope.Inspector_RES={
            Inspector:"",
            Ins_resDate:"",
            InsComments:"",
            InsAcceptObj:"",
            Role:"",
            RES_User:"",
            InsIsOld:"New"
        }
        $scope.taskNode={
            Task_AssignTo:"",
            Task_AssignDate:"",
            Task_Desc:"",
            Task_Type:"",
            Task_IsOld:"0",
            Task_Res_Created:"0",
            Task_GUID:""
        }
        $scope.taskFormAutoCreateNode = {
            ACF_01_CREATED_BY: "",
            ACF_01_DS_CLOSE_DUE_DATE: "",
            ACF_01_DS_AUTODISTRIBUTE: "3",
            ACF_01_DS_FORMCONTENT1: "<<DS_Form_ID>>",
            ACF_01_DS_FORMTITLE:  "",
            ACF_01_ORI_FORMTITLE:  "",
            ACF_01_Task_Details:  "",
            ACF_01_Task_Reference: "<<DS_Form_ID>>",
            ACF_01_Task_Type: "",
            ACF_01_Task_Ref_Id:"",
            ACF_01_Assigned_To:  "",
            ACF_01_DS_WF_Next_Step:"2",
            ACF_01_DS_Ref_AppId: "",
            ACF_01_Task_Verification_Required:  "Yes",
            ACF_01_DS_UniqueFormRef:"Yes",
            ACF_01_DS_ALL_FORMSTATUS: "",
            ACF_01_Originator_User:"",
            ACF_01_Assignee_User:"",
            ACF_01_Current_Stage:"0",
            ACF_01_Next_Stage:"1",
            ACF_01_DSI_Task_GUID:"",
            ACF_01_REPEATING_VALUES: {
                ACF_01_DS_AutoDistribute_User_Group: {
                    ACF_01_DS_AutoDistribute_Users: [{
                        ACF_01_DS_PROJDISTUSERS: '',
                        ACF_01_DS_FORMACTIONS: '',
                        ACF_01_DS_ACTIONDUEDATE: '',
                        ACF_01_DS_DUEDAYS: ''
                    }]
                }
            }
        }
    
        
        var projectMasterFormDetails = $scope.getValueOfOnLoadData("DS_NNG_PMF_GET_ProjectMasterForm_Details")[0] || {};
        $scope.commissioningGrp.DSI_workOrderNo = projectMasterFormDetails.Value1 || "";//Work_Order_Number
        $scope.commissioningGrp.DSI_projectName = projectMasterFormDetails.Value3 || "";//Project_Name
        $scope.commissioningGrp.DSI_state = projectMasterFormDetails.Value9 || "";//State
        $scope.commissioningGrp.DSI_region = projectMasterFormDetails.Value8 || "";//Region 
        $scope.commissioningGrp.DSI_projectteam = projectMasterFormDetails.Value52 || "";//Project Team
        $scope.commissioningGrp.DSI_RFSDate = $scope.formatDate(new Date(projectMasterFormDetails.Value24), 'mm/dd/yy') || "";
    
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;

        });
    if (currentViewName == "ORI_VIEW") {
        $scope.projectManager = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Project Manager");
        });
        $scope.operationsManager = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Operations Manager");
        });

        $scope.constructionCoordinator = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Construction Coordinator");
        });
        $scope.operationsTeam = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Operations Team Contact");
        });
        $scope.leadInspector = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Inspector");
        });
        $scope.projectEngineer = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Project Engineer");
        });
        $scope.divisionEnvironmental = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Division Environmental Specialist");
        });
        $scope.rightwayAgent = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "ROW Agent");
        });
        $scope.documentationSpecialist = commonApi._.filter(projUserRole, function (val) {
            return (val.Value.split('|')[0].trim() == "Documentation Specialist");
        });

    $scope.contractorList = commonApi._.filter(projUserRole, function (val) {
        return (val.Value.split('|')[0].trim() == "Primary Contractor" || val.Value.split('|')[0].trim() == "Additional Contractors")

    });
    if(!$scope.isEditORI && currentViewName == "ORI_VIEW"){
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        $scope.Msg="This form may not be created manually.  It is auto-created when the Commissioning Turnover Form (XTF) is launched by the Project Manager to begin the commissioning process.";
    }
    $scope.addNewItem = function (repeatingData, fromStructure) {
        getGUIdOnCallBack(1, function (guidResp) {
        var item = angular.copy(fromStructure);
        item.Task_GUID = guidResp[0];
        repeatingData.push(item);
        });
        if($scope.allAprroved==true)
        {$scope.allAprroved=false;}
        
    }
    $scope.deleteRow = function (index, repeatindData) {
        if (repeatindData.length == 1 && $scope.modifiedIndex == 0) {
            alert('Atleaset one row required');
            return false;
        }
        else if (repeatindData.length > index) {
            repeatindData.splice(index, 1);
         
            if ($scope.allAprroved == false ) {
                chkApproved();
                if($scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].Inspector == '' 
                && $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].RES_User == '' ){
                       $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsAcceptObj='';
                       $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsComments='';
                }
             }
        }
    }
    $scope.chkOriAssignTo=function (assignObj){
        if(assignObj.Task_AssignTo && assignObj.Task_AssignTo.split("#")[0].split('|')[2].trim() ==$scope.workingUserID[0].Value.split('|')[0].trim()){
            alert('Originator cannot be selected in Assigned To')
            assignObj.Task_AssignTo='';
        }
        if(!assignObj.Task_GUID)
            assignObj.Task_GUID = guID[0].Value2;
    }
    var getGUIdOnCallBack = function (totalNodes, callback) {
        var allNodes = [];
        var fieldValue = totalNodes;
        if (fieldValue) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_GET_GUID",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_GET_GUID",
                        "fieldValue": fieldValue
                    }]
                }
            };
            $scope.xhr.platformXhr = true;
            $scope.xhr.guIdXhr = $scope.getCallbackData(form).then(function (response) {
                if (response.data) {
                    var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
                    var strGetDetailsLength = strGetDetails.Items.Item.length;
                    for (var i = 0; i < strGetDetailsLength; i++) {
                        allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
                    }
                }
                $scope.xhr.platformXhr = false;
                $scope.xhr.guIdXhr = false;
                callback(allNodes);
            }, function (error) {
                $scope.xhr.platformXhr = false;
                $scope.xhr.guIdXhr = false;
                var errorMsg = 'Error retriving DocumentData<br/>' + error;
                Notification.error({
                    title: 'Server Error',
                    message: errorMsg
                });
            });
        }
    };
    $scope.clearData = function () {
        if($scope.commissioningGrp.punchListItems=='No'){
            for(var i=0;i<$scope.commissioningGrp.Task_Details.length;i++){
                if($scope.commissioningGrp.Task_Details[i].Task_IsOld==0)
                {
                   $scope.commissioningGrp.Task_Details[i].Task_AssignTo='';
                   $scope.commissioningGrp.Task_Details[i].Task_AssignDate='';
                   $scope.commissioningGrp.Task_Details[i].Task_Desc='';
                   $scope.commissioningGrp.Task_Details[i].Task_Type='';
                }
           }
            chkApproved();
        }
        else{
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 3) {
                $scope.allAprroved = false;
                //clear RES DATA
                if($scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].Inspector == '' 
                && $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].RES_User == '' ){
                       $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsAcceptObj='';
                       $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsComments='';
               }
            }
            else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 1){
                if($scope.cmtDisplay==true)
                {
                    var operationsRES = $scope.commissioningGrp['operations_RES'];
                    operationsRES[operationsRES.length - 1].opComments='';
                }
                else
                    $scope.commissioningGrp.suppComments="";
            }
        }
    }
    $scope.userList=commonApi._.filter(projUserRole, function (val) {
        return (val.Value.split('|')[0].trim() == "Additional Contractors" || val.Value.split('|')[0].trim() == "Construction Coordinator" ||
         val.Value.split('|')[0].trim() == "Electrical Engineer" || val.Value.split('|')[0].trim() == "Project Engineer" ||
         val.Value.split('|')[0].trim() == "Inspector" || val.Value.split('|')[0].trim() == "Primary Contractor" )

    });
    
    var outputArray = []; 
    var count = 0; 
    var start = false; 
    for (var j = 0; j < $scope.userList.length; j++) { 
        for (var k = 0; k < outputArray.length; k++) { 
            if ( $scope.userList[j].Name == outputArray[k].Name ) { 
                start = true; 
            } 
        } 
        count++; 
        if (count == 1 && start == false) { 
            outputArray.push($scope.userList[j]); 
        } 
        start = false; 
        count = 0; 
    } 
        $scope.userList =outputArray;

    }
    if(currentViewName == "ORI_PRINT_VIEW" ){
        angular.element('.export-btn').hide();
    }
    if (currentViewName == "ORI_VIEW" && $scope.strIsDraft == "NO") {
            
        if ($scope.oriMsgCustomFields.DSI_Next_Stage == "") {
            $scope.oriMsgCustomFields.DSI_Next_Stage = 1
        }
        if ($scope.oriMsgCustomFields.DSI_Current_Stage == "") {
            $scope.oriMsgCustomFields.DSI_Current_Stage = 1
        }
        else {
            $scope.oriMsgCustomFields.DSI_Current_Stage = $scope.oriMsgCustomFields.DSI_Next_Stage
        }
    }
    if ($scope.oriMsgCustomFields.DSI_Current_Stage == 2 && currentViewName == "ORI_VIEW") {
        var strRes = commonApi._.filter( $scope.commissioningGrp.operations_RES, function (val) {
            return val.Is_Old.indexOf("New") != -1  
        });
        if(strRes.length==0)
            $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));
        
     }
   
    function setBlankVal()
    {
            if($scope.commissioningGrp.constructionCoordinator=="-")
                $scope.commissioningGrp.constructionCoordinator="";
            if($scope.commissioningGrp.operationsManager=="-")
                $scope.commissioningGrp.operationsManager="";
  
    }
    if($scope.isEditORI && currentViewName == "ORI_VIEW" ){
        $scope.Msg="You are not authorised to edit the form currently. For more information, contact your Administrator."
        setBlankVal();
        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE=commonApi.calculateDistDateFromDays({
            baseDate: getDateTimeFromZone(),
            days: 7
        });
    }
    
    function getDateTimeFromZone() {
        var offset = 0;
        offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
        $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
        var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
        var now = new Date();
        var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
        var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
        nd = $filter('date')(nd, 'yyyy-MM-dd');
        return nd;
    }
    if(currentViewName=="ORI_VIEW"){
        $scope.strCanReply = ""; 
        if($scope.punchListTask.length > 0){
            for (var j = 0; j < $scope.punchListTask.length; j++) {
                if($scope.punchListTask[j].Value11=="1"){
                       setTaskRes($scope.punchListTask[j].Value12);
                }
                else{
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM="1";
                }
            }
        }
    }

   function chkApproved()
   {
            
            var strRes = commonApi._.filter( $scope.punchListTask, function (val) {
                    return val.Value2 =="Closed";
                });
            if($scope.oriMsgCustomFields.DSI_Current_Stage==1){
                var isInspector= commonApi._.filter($scope.leadInspector, function (val) {
                    return val.Value.indexOf($scope.workingUserID[0].Value.split('|')[0].trim()) != -1
                });
                    if($scope.punchListTask.length>0 && $scope.punchListTask.length== $scope.commissioningGrp.Task_Details.length && 
                    isInspector.length>0){
                            $scope.allAprroved=true;
                    }
            }
            else{
                if($scope.punchListTask.length>0 &&  $scope.punchListTask.length== $scope.commissioningGrp.Task_Details.length)
                    {
                        $scope.allAprroved=true;
                    }
            }
            if($scope.commissioningGrp.punchListItems=='No' && $scope.oriMsgCustomFields.DSI_Current_Stage>2 )
            {$scope.allAprroved=true;}


            var userid=getInspector()!=''?getInspector().split('|')[0].trim():$scope.oriMsgCustomFields.DSI_orignatorID;
            
            if($scope.oriMsgCustomFields.DSI_Current_Stage==3 && userid != $scope.workingUserID[0].Value.split('|')[0].trim())
            {$scope.oriMsgCustomFields.DSI_IsApproved=false
            $scope.allAprroved=false}

            if ($scope.commissioningGrp.punchListItems == 'No'&& $scope.oriMsgCustomFields.DSI_IsApproved==true &&
             ($scope.oriMsgCustomFields.DSI_Current_Stage==5||$scope.oriMsgCustomFields.DSI_Current_Stage==3))
            {$scope.allAprroved=true;}
    }
    function chkAutocreateEdit() {
        for (var i = 0; i < $scope.commissioningGrp.Task_Details; i++) {
            var allNodes = $scope.commissioningGrp.Task_Details;

            if (allNodes && allNodes.length) {
                for (var i = 0; i < allNodes.length; i++) {
                    var givenDate = allNodes[i].Task_AssignDate;
                    var currentDate = new Date();
                    givenDate = new Date(givenDate);
                    if (givenDate < currentDate) {
                        allNodes[i].Task_AssignDate = '';
                    }
                    if(allNodes[i].Task_AssignTo && allNodes[i].Task_AssignTo.split("#")[0].split('|')[2].trim() ==$scope.workingUserID[0].Value.split('|')[0].trim()){
                        allNodes[i].Task_AssignTo='';
                    }
                }
            }
        }
    }
    $scope.showDiv = function () {
        if($scope.dispDiv)
            $scope.dispDiv =false;
        else
            $scope.dispDiv=true;
    }
    function setWorkflowNotReq(){
        if(formStatus.toLowerCase()=='not required' && $scope.commissioningGrp.punchListItems == 'No'){
            $scope.strCanReply = "yes";
            $scope.oriMsgCustomFields.DSI_Current_Stage=1;
            $scope.oriMsgCustomFields.DSI_Next_Stage=1;
            $scope.oriMsgCustomFields.Hyperlink=1;
        }
    }
    if($scope.isEditORI && currentViewName == "ORI_VIEW" ) {
        //Edit Auto creat
         chkAutocreateEdit();
        //Clear Auto create
        $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
        //Check Action
        if((formStatus.toLowerCase()=='objection' || formStatus.toLowerCase()=='submitted' || formStatus.toLowerCase()=='not required' || formStatus.toLowerCase()=='complete')
         && ($scope.oriMsgCustomFields.DSI_Current_Stage != 3) && ($scope.oriMsgCustomFields.DSI_Current_Stage != 5) &&
         ($scope.oriMsgCustomFields.DSI_Current_Stage != 6) && ($scope.oriMsgCustomFields.Hyperlink=='') ){
            var userid = $scope.workingUserID['0'].Value.split('|')[0].trim();
            var actionData = commonApi._.filter(incompleteAction, function (val) {
                return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(userid) != -1
            });
            if (actionData && actionData.length) {
                $scope.strCanReply = "yes";
            }
            
         
        }
        else if($scope.oriMsgCustomFields.DSI_Current_Stage == 5){
            if($scope.commissioningGrp.operationsManager && 
                $scope.commissioningGrp.operationsManager.split('|')[2].split('#')[0].trim()==$scope.workingUserID[0].Value.split('|')[0].trim())
                {
                    $scope.strCanReply = "yes";
                }
                else 
                {   $scope.strCanReply = "";
                    setWorkflowNotReq();
                }
                    
        }
        else if($scope.oriMsgCustomFields.DSI_Current_Stage == 6){
            setWorkflowNotReq();
        }
        else{
            $scope.strCanReply = "yes";
            
        }
       // Check All Approved
       chkApproved();
        //Check Conc
       var isConc= $scope.projectManager = commonApi._.filter($scope.contractorList, function (val) {
            return val.Value.indexOf($scope.workingUserID[0].Value.split('|')[0].trim()) != -1
        });
        if(isConc.length>0)
        {$scope.isConcUser=true;}
        
        //Punclist length
        $scope.modifiedIndex=$scope.punchListTask.length;
        if($scope.oriMsgCustomFields.DSI_Current_Stage<4){$scope.roleName="Inspector"}
    }

    //CMT Display
    if($scope.isEditORI && currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields.DSI_Current_Stage == 1){
        if(formStatus.toLowerCase()=="objection" && $scope.commissioningGrp.operations_RES.length>0 &&
             $scope.commissioningGrp.operations_RES[$scope.commissioningGrp.operations_RES.length-1].opAcceptObj=='Reject'  ){
            $scope.cmtDisplay=true;
            var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                return val.Is_Old.indexOf("New") != -1
            });
            if (strRes.length == 0)
                $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));
        }
        else if($scope.oriMsgCustomFields.Hyperlink==1){
            $scope.cmtDisplay=true;
            var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                return val.Is_Old.indexOf("New") != -1
            });
            if (strRes.length == 0)
                $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));
        }
    }



    //Adding Inspectore Workflow
    if  (currentViewName == "ORI_VIEW" &&  $scope.allAprroved==true ) {
        if($scope.oriMsgCustomFields.DSI_Current_Stage==4 ){$scope.roleName="Construction Coordinator"}
        
        var strRes = commonApi._.filter($scope.commissioningGrp.Inspector_RES, function (val) {
            return  val.InsIsOld && val.InsIsOld.indexOf("New") != -1  
        });

        if(strRes.length==0)
            $scope.commissioningGrp.Inspector_RES.push(angular.copy($scope.Inspector_RES));

        if($scope.oriMsgCustomFields.DSI_Current_Stage==5 ){
            $scope.roleName="Operations Manager";
            $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length-1].InsAcceptObj='Accept';
        }
      
     }
     
    
    var reportByParam = commonApi.getItemSelectionList({ 
        arrayObject: dsAsiConfigurableAttributes.filter(function (custObj) {
            return custObj.Value3 == 'Task Title';
        }),
        groupNameKey: "",
        modelKey: "Value8",
        displayKey: "Value8"
    });
    $scope.filterDropdownList = {
        reportByList: reportByParam
    }
  
   
    function getFormStatusId(strStatus) {
        //get status according pass parameter
        if (allformStatus && allformStatus.length > 0) {
            var statudObj = commonApi._.filter(allformStatus, function (val) {
                return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
            });
            if (statudObj.length) {
                return statudObj[0].Value;
            }
        }
        return "";
    }
    function getFormStatusIdWS(strStatus) {
        //get status according pass parameter
        if (allformStatusWS && allformStatusWS.length > 0) {
            var statudObj = commonApi._.filter(allformStatusWS, function (val) {
                return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
            });
            if (statudObj.length) {
                return statudObj[0].Value;
            }
        }
        return "";
    }
    function setStatus(statusname) {
        var strFormStatusId = getFormStatusId(statusname);
        if (strFormStatusId) {
            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
        }
    }
  
    
    function setAutocreateNodes() {
        var allNodes = $scope.commissioningGrp.Task_Details;
        var userid = $scope.workingUserID[0].Value.split('|')[0].trim();
        $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
        $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
        if (allNodes && allNodes.length) {
            for (var i = 0; i < allNodes.length; i++) {
                if (allNodes[i].Task_IsOld == 0) {
                    var strUser = allNodes[i].Task_AssignTo.split("#")[0].split("#")[0].split('|')[2].trim(),
                                    strAction = "3#Respond";
                    var newTaskNode = {};
                    newTaskNode = angular.copy($scope.taskFormAutoCreateNode);
                    newTaskNode.ACF_01_CREATED_BY = $scope.workingUserID[0].Value.split('|')[0].trim();
                    newTaskNode.ACF_01_DS_CLOSE_DUE_DATE = allNodes[i].Task_AssignDate;
                    newTaskNode.ACF_01_DS_AUTODISTRIBUTE = "3";
                    newTaskNode.ACF_01_DS_FORMCONTENT1 = '<<DS_Form_ID>>';
                    newTaskNode.ACF_01_DS_FORMTITLE = allNodes[i].Task_Type.substring(0,100);
                    newTaskNode.ACF_01_ORI_FORMTITLE = allNodes[i].Task_Type.substring(0,100);
                    newTaskNode.ACF_01_Task_Details = allNodes[i].Task_Desc
                    newTaskNode.ACF_01_Task_Reference = '<<DS_Form_ID>>';
                    newTaskNode.ACF_01_Task_Type = allNodes[i].Task_Type.substring(0,100) ;
                    newTaskNode.ACF_01_Task_Ref_Id = "";
                    newTaskNode.ACF_01_Assigned_To = allNodes[i].Task_AssignTo;
                    newTaskNode.ACF_01_DS_WF_Next_Step = "2";
                    newTaskNode.ACF_01_DS_Ref_AppId = "";
                    newTaskNode.ACF_01_Task_Verification_Required = "Yes";
                    newTaskNode.ACF_01_Date_Of_Issue = $scope.formatDate(new Date(), 'mm/dd/yy');
                    newTaskNode.ACF_01_DS_UniqueFormRef = "Yes";
                    newTaskNode.ACF_01_DS_ALL_FORMSTATUS = getFormStatusIdWS("Pending").split('#')[0].trim();
                    newTaskNode.ACF_01_Originator_User =  $scope.workingUserID[0].Value.split('|')[0].trim();
                    newTaskNode.ACF_01_Assignee_User =strUser;
                    newTaskNode.ACF_01_Current_Stage = 0;
                    newTaskNode.ACF_01_Next_Stage = 1;
                    newTaskNode.ACF_01_AUTOCREATE_INDEX = i + 1;
                    newTaskNode.ACF_01_DSI_Task_GUID=allNodes[i].Task_GUID;
                    var childNodes = newTaskNode.ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users;
                    if (childNodes && childNodes.length) {
                        for (var j = 0; j < childNodes.length; j++) {
                            childNodes[j].ACF_01_DS_PROJDISTUSERS = strUser;
                            childNodes[j].ACF_01_DS_FORMACTIONS = strAction;
                            childNodes[j].ACF_01_DS_ACTIONDUEDATE = allNodes[i].Task_AssignDate;
                        }
                    }

                    // final pushing node.
                    $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);

                }
            }

        }
    }
    function clearUserActionById  (userPrevName) {
        if (!userPrevName) {
            return;
        }
        $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
        $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push({
            DS_AC_TYPE: "clear",
            DS_AC_FORM: $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'],
            DS_AC_MSG_TYPE: "ORI",
            DS_AC_USERID: userPrevName,
            DS_AC_ACTION: "2",
            DS_AC_ACTION_REMARKS: "Action Complete"
        });
        
    }
    function getInspector()
    {
            var statudObj = commonApi._.filter($scope.commissioningGrp['Inspector_RES'], function (val) {
                return val.Inspector != "";
            });
            if (statudObj.length) {
                return statudObj[0].Inspector;
            }
            return "";
        
    }
    function setTaskRes(taskGuid){
        if($scope.commissioningGrp.Task_Details.length>0){
            for (var i = 0; i < $scope.commissioningGrp.Task_Details.length; i++) {
                if($scope.commissioningGrp.Task_Details[i].Task_GUID==taskGuid){
                    $scope.commissioningGrp.Task_Details[i].Task_Res_Created="1";
                }
            }
        }
    }
    function setDistribution(userTodistribute, Days, autoDistNode, actionName) {
        if (userTodistribute) {
            var structDistricution = angular.copy($scope.DistributionStructure)
            structDistricution.DS_PROJDISTUSERS = userTodistribute.indexOf('#')>-1? userTodistribute.split("#")[0].split("#")[0].split('|')[2].trim():userTodistribute;
            structDistricution.DS_FORMACTIONS = actionName;
            structDistricution.DS_ACTIONDUEDATE = commonApi.calculateDistDateFromDays({
                baseDate: getDateTimeFromZone(),
                days: Days
            })
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistricution);
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = autoDistNode;
        }
    }
    $scope.update();
    $window.oriformSubmitCallBack = function () {
        $scope.oriMsgCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users=[];
        $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
        $scope.oriMsgCustomFields.Hyperlink='';
        //Clear action
        $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID']="0";

        if (!$scope.strCanReply) {
            alert($scope.Msg);
            return true;
        }
        var strMsg="";
        if($scope.commissioningGrp.operationsManager =='')
        {if(strMsg=='') {strMsg='Operations Manager'; } }
        if($scope.commissioningGrp.constructionCoordinator =='')
        {
            if(strMsg=='') {strMsg='Construction Coordinator'; }
            else{ strMsg=strMsg + ', Construction Coordinator'}
        }
      
        if (strMsg !='') {
            
            Notification.error({ title: 'Alert', message: strMsg + ' must be assigned. Contact that Project Manager to have the proper user assignment made on the XTF.' });
            return true;
        }
        if ($scope.commissioningGrp.punchListItems == 'Yes'  &&  $scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
            var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
            //condtion for chk if it submit or not first response
            if($scope.allAprroved ==true && inspectorRES[inspectorRES.length-1].InsAcceptObj=='Submitted'){
                setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "2#");
                setStatus("Submitted");
                $scope.oriMsgCustomFields.chkIns="true";
                for (var i = 0; i < inspectorRES.length; i++) {
                    if (inspectorRES[i].InsIsOld == "New") {
                        inspectorRES[i].Inspector=$scope.workingUserID[0].Value;
                        inspectorRES[i].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
                        inspectorRES[i].InsIsOld = "Old";
                        inspectorRES[i].Role = "Inspector";
                    }
                  }
                $scope.oriMsgCustomFields.DSI_Next_Stage = 4;
            }
            else{
                var autoCount = commonApi._.filter($scope.commissioningGrp.Task_Details, function (val) {
                    return (val.Task_IsOld == 0);
                });
                setStatus("Open");
                if(autoCount.length){
                    setAutocreateNodes();
                    //set All task old
                    commonApi._.filter($scope.commissioningGrp.Task_Details, function (val) {
                        return val.Task_IsOld =1 ;
                    });
                }
                else
                    $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
            }
        }
        else if($scope.commissioningGrp.punchListItems == 'No' &&  $scope.oriMsgCustomFields.DSI_Current_Stage == 1 ) {
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
            setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "2#");
            setStatus("Submitted");
            $scope.oriMsgCustomFields.DSI_Next_Stage = parseInt($scope.oriMsgCustomFields.DSI_Current_Stage) + 1;
            $scope.oriMsgCustomFields.DSI_orignatorID = $scope.workingUserID[0].Value.split('|')[0].trim();
            if($scope.cmtDisplay==true){
                var operationsRES = $scope.commissioningGrp['operations_RES'];
                for (var i = 0; i < operationsRES.length; i++) {
                    if (operationsRES[operationsRES.length - 1].Is_Old == "New") {
                        operationsRES[operationsRES.length - 1].opUser = $scope.workingUserID[0].Value;
                        operationsRES[operationsRES.length - 1].resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                        operationsRES[operationsRES.length - 1].Is_Old = "Old";
                    }
                }
            }
            else{
                $scope.oriMsgCustomFields.DSI_submittedUser=$scope.workingUserID[0].Name;
                
            }

        }
        else if ($scope.commissioningGrp.punchListItems == 'No' && $scope.oriMsgCustomFields.DSI_Current_Stage == 2) {
            var operationsRES = $scope.commissioningGrp['operations_RES'] ;
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if ($scope.commissioningGrp.operations_RES[operationsRES.length-1].opAcceptObj == 'Accept') {
                setStatus("Not required")
                $scope.oriMsgCustomFields.DSI_Next_Stage = 5;
                //setDistribution($scope.commissioningGrp.operationsManager, 7, 3, "2#");
                $scope.oriMsgCustomFields.DSI_IsApproved=true; 
            } 
            else if ($scope.commissioningGrp.operations_RES[operationsRES.length-1].opAcceptObj == 'Reject') {
                $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                setDistribution($scope.oriMsgCustomFields.DSI_orignatorID, 7, 3, "2#");
                setStatus("Objection")
            }
            for (var i = 0; i < operationsRES.length; i++) {
                if (operationsRES[i].Is_Old == "New") {
                   operationsRES[i].opUser=$scope.workingUserID[0].Value;
                   operationsRES[i].resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
                   operationsRES[i].Is_Old = "Old";
                }
              }
        }
        else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 3 ){
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
            var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
            //condtion for chk if it submit or not
            if($scope.allAprroved ==true && inspectorRES[inspectorRES.length-1].InsAcceptObj=='Submitted'){
                   $scope.oriMsgCustomFields.chkIns="true";
                    $scope.oriMsgCustomFields.DSI_orignatorID="";
                    $scope.oriMsgCustomFields.DSI_IsApproved=""; 
                    setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "2#");
                    setStatus("Submitted");
                    for (var i = 0; i < inspectorRES.length; i++) {
                        if (inspectorRES[i].InsIsOld == "New") {
                            inspectorRES[i].Inspector=$scope.workingUserID[0].Value;
                            inspectorRES[i].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
                            inspectorRES[i].InsIsOld = "Old";
                            inspectorRES[i].Role = "Inspector";
                        }
                    }
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 4;
            }
            else if($scope.commissioningGrp.punchListItems == 'Yes'){
                setStatus("Open");
                var autoCount = commonApi._.filter($scope.commissioningGrp.Task_Details, function (val) {
                    return (val.Task_IsOld == 0);
                });
                if(autoCount.length){
                    setAutocreateNodes();
                    //set All task old
                    commonApi._.filter($scope.commissioningGrp.Task_Details, function (val) {
                        return val.Task_IsOld =1 ;
                    });
                }
                else
                    $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
            }
        }
         //Constructor REs
         else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 4){
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
             var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
             inspectorRES[inspectorRES.length-1].RES_User=$scope.workingUserID[0].Value;
             inspectorRES[inspectorRES.length-1].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
             inspectorRES[inspectorRES.length-1].InsIsOld = "Old";
             inspectorRES[inspectorRES.length-1].Role = "Construction Coordinator";
             if (inspectorRES[inspectorRES.length-1].InsAcceptObj == 'Accept') {
                    if($scope.commissioningGrp.punchListItems == 'Yes')
                        setStatus("Complete");
                    else if($scope.commissioningGrp.punchListItems == 'No')
                        setStatus("Not required");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 5;
              } else{
                       setStatus("Objection");
                       setDistribution(getInspector().split('|')[0].trim(), 7, 3, "2#");
                       $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
                }
   
        }
         //Operation Manager  REs
         else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 5){
            var inspectorRES = $scope.commissioningGrp['Inspector_RES'] ;
            inspectorRES[inspectorRES.length-1].RES_User=$scope.workingUserID[0].Value;
            inspectorRES[inspectorRES.length-1].Ins_resDate=$scope.formatDate(new Date(), 'mm/dd/yy');
            inspectorRES[inspectorRES.length-1].InsIsOld = "Old";
            inspectorRES[inspectorRES.length-1].Role = "Operations Manager";
            $scope.oriMsgCustomFields.chkOperation="true";
            if (inspectorRES[inspectorRES.length-1].InsAcceptObj == 'Accept') {
                  clearUserActionById($scope.workingUserID[0].Value.split('|')[0].trim())
                  $scope.oriMsgCustomFields.DSI_Next_Stage = 6;
             } else{
                     setStatus("Objection");
                     setDistribution(getInspector()!=''?getInspector().split('|')[0].trim():$scope.oriMsgCustomFields.DSI_orignatorID, 7, 3, "2#");
                   //  setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "7#");
                     $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
               }

      }
     
        return false;
    
    };
}
     
    return FormController;
 });

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}