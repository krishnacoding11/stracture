/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
		
		

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

     

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;
		$scope.cdate = document.getElementById('DS_DATEOFISSUE') && document.getElementById('DS_DATEOFISSUE').value || '';
		$scope.cdate =new Date($scope.cdate.replace('-', "/"));
		$scope.updatedate = document.getElementById('DS_MSGDATE') && document.getElementById('DS_MSGDATE').value || '';
		$scope.updatedate =new Date($scope.updatedate);
		$scope.formstatus = document.getElementById('DS_FORMSTATUS') && document.getElementById('DS_FORMSTATUS').value || '';
		 
		$scope.isDataLoaded = true;
		var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
		
		$scope.STATIC_OBJ_DATA = {
			  Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: ""
            },
			 Responses: {
                Comments: "",
                Response_Creator: "",
                Response_Date: "",
                DSI_Is_Old: "New",
				Reason_for_call_to_be_open: "",
				Proposed_resolution: "",
				Root_Cause: "",
					
            }
		}
		
		/** Initialize db fields */
         
		$scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
		$scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
		$scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
		$scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
		
		$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
		$scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
		$scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
		$scope.DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES')
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		 var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		$scope.Client_Logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});
		$scope.Client_Logo =$scope.Client_Logo[0].Value8;
		$scope.formCustomFields.Client_Logo = $scope.Client_Logo;
		
		
		$scope.dsOriginator = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ORIGINATOR;
		$scope.dsWorkingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var dsWorkingUser=$scope.dsWorkingUser[0].Value;
		var WorkingUserID=dsWorkingUser.split('|')[0].trim();
		var date = new Date();
		var retdate = new Date(date.getTime() + (7 * 24 * 60 * 60 * 1000));

		var AsiteSupport = commonApi._.filter($scope.DS_PROJUSERS_ALL_ROLES, function (val) {
		return val.Value.indexOf("Asite Support") > -1 | val.Value.indexOf("support@asite.com") > -1;
		});
	    var AsiteSupportID=WorkingUserID;  
		$scope.supportflag='NO';
		if(AsiteSupport!=''){
			AsiteSupportID=AsiteSupport[0].Value.split('|')[2].split('#')[0].trim(); 
			if(AsiteSupportID==WorkingUserID){
				$scope.supportflag='Yes';
			}
		}
		
		
		$scope.update();
		
		 function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var statudObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
		
	function setAutoDistribution(strUser, strAction, strDueDate) {
		if (strDueDate) {
		strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
		}
		
		
		//get copy of distribution and set user ,date ,action to distribute
		$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users=[];
		var structDistribution = angular.copy($scope.STATIC_OBJ_DATA.Auto_Distribute_Users);
		structDistribution.DS_PROJDISTUSERS = strUser;
		structDistribution.DS_FORMACTIONS = strAction;
		structDistribution.DS_ACTIONDUEDATE = strDueDate;
		$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
	}
	if (currentViewName == "ORI_VIEW") {
		$scope.oriMsgCustomFields.ORIGINATOR_ID=WorkingUserID;
		console.log($scope.oriMsgCustomFields.ORIGINATOR_ID);
	}
	
	 $window.rhdhvFinalCallBack = function () {
		 if ($scope.submitFlag) {
                return false;
          }
		if (currentViewName == "ORI_VIEW") {
			oriview();
		}
		 
		  if(currentViewName == "RES_VIEW")
        {
			 addNewRow();
			 
		}
		return true;
	}
	function oriview()
	{
		$scope.getServerTime(function (serverDate) {
				$scope.oriMsgCustomFields.ORIGINATOR_ID=WorkingUserID;
				$scope.oriMsgCustomFields.CDATE=$filter('date')(serverDate, 'dd/MM/yyyy h:mm a');
				var struser = AsiteSupportID;
				$scope.oriMsgFields.DS_AUTODISTRIBUTE = "3"
				setAutoDistribution(struser, "3#Respond", retdate);
				$scope.submitFlag = true;
                $window.submitForm(1);
			});
	}
     function addNewRow() {
            $scope.getServerTime(function (serverDate) {
                var insertPoint = $scope.resMsgCustomFields.All_Responses.Responses;
                for (var index = 0; index < insertPoint.length; index++) {
                    insertPoint[index].DSI_Is_Old = "Old";
					if(index==insertPoint.length-1)
					{
						 
						insertPoint[index].Response_Creator = $scope.dsWorkingUser;
						//form_Status
						var strStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
						var strFormStatusId = getFormStatusId(strStatus);
						if (strFormStatusId) {
						$scope.asiteSystemDataReadOnly._5_Form_Data.DS_ALL_FORMSTATUS = strFormStatusId;
						}
						insertPoint[index].form_Status = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
						
						insertPoint[index].Response_Date = new Date(serverDate);
						insertPoint[index].Response_Date_Formate =$filter('date')(serverDate, 'dd/MM/yyyy h:mm a');
						if(WorkingUserID==AsiteSupportID){ //asite support
							insertPoint[index].IS_Support='YES';
						}else{
							insertPoint[index].IS_Support='NO';
						}
						
						
					}
                }
				       
               
				//response action
				if(WorkingUserID==AsiteSupportID){ //asite support
				  var struser = $scope.oriMsgCustomFields.ORIGINATOR_ID;
				   $scope.oriMsgFields.DS_AUTODISTRIBUTE = "13"
			      setAutoDistribution(struser, "13#Respond", retdate);
				}else{
				  var struser = AsiteSupportID;
				  $scope.oriMsgFields.DS_AUTODISTRIBUTE = "13"
				  setAutoDistribution(struser, "13#Respond", retdate);
				}
				
						$element.removeClass('loaded');
						var structResponses = angular.copy($scope.STATIC_OBJ_DATA.Responses);
						structResponses.DSI_Is_Old="New";
						insertPoint.push(structResponses);
						
				$scope.submitFlag = true;
                 $window.submitForm(1);
            });
        }
		


    }
    return FormController;
});

function customHTMLMethodAfterValidationError(){}

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof rhdhvFinalCallBack !== "undefined") {
        return rhdhvFinalCallBack();
    }
}