/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $controller, $window, $timeout) {

		// restrict autosave Draft and hide Save Draft button.
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 500);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.siteDiary = $scope.oriMsgCustomFields.siteDiary;
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy";

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		var STATIC_OBJ = {
			Dayworks: {
				Daysheet:'Daysheet #1 Reference:',
				isDayworks: false,
				reference: "",
				description:"",
				dayWorkActivity:"",
				attachedDocs: ""
			},
		};
		$scope.checkhours = function(){
			var dayWorkActivity = $scope.siteDiary.dayWorkActivity;
			if(dayWorkActivity){
				var Hours = parseFloat(dayWorkActivity);
				if(isNaN(dayWorkActivity)){
					$scope.siteDiary.dayWorkActivity = "";
					alert("Daywork Activities Should be Number Only!!!");
				}
				if(Hours <= 0 || Hours > 24){
					$scope.siteDiary.dayWorkActivity = "";
					alert("Daywork Activities Should be Less than 24 Hours!!!");
				}
			}
		};

		$scope.addNewItem = function (repeatingData, addItemFor) {
			var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
			if (addItemFor == "Dayworks") {
                var newOptionNumber = repeatingData.length + 1;
                newRowObject.Daysheet = "Daysheet #" + newOptionNumber + " Reference:";
            }
			repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad();
		};
		$scope.removeItem = function (nodeObj, list) {
			var index = list.indexOf(nodeObj);
			list.splice(index, 1);
		};
		 // To reset Daysheet Index while remove Dayworks
		 $scope.daysheetIndexReset = function() {
            $timeout(function () {
                var dayworks = $scope.oriMsgCustomFields.siteDiary['Dayworks'];
                for (var i = 0; i < dayworks.length; i++) {
                    dayworks[i].Daysheet = "Daysheet #" + (i + 1) + " Reference:";
                }
            }, 200);
        };
	
		$scope.update();
		function formSubmitCallBack()
		{
			$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.todayDateUKFormat + " " + $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME;
			return false;
		}
		$window.oriformSubmitCallBack = function () {
			formSubmitCallBack();
		};
		$window.draftSubmitCallBack = function () {
			formSubmitCallBack();
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}