/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, myConfig, htmlformservice) {
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});
		$window._isOffline = false;
		$scope.DESIGN_JSON  = angular.copy($window.DESIGN_JSON);
		var languageId = window.USP && window.USP.languageId || window.userLanguageId || "en_GB";
		$scope.languageId = languageId;
		
		// restrict autosave Draft
		$scope.stopAutoSaveDraftTimerFromClientSide();
				
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		
		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.dSIsDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.isRespPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		var DefectTypes = $scope.getValueOfOnLoadData('DS_ASI_SITE_getDefectTypesForProjects_pf');
		$scope.AllLocation = $scope.getValueOfOnLoadData('DS_ASI_SITE_getAllLocationByProject_PF');
		$scope.allActiveFormStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var recentDefectObj = $scope.getValueOfOnLoadData('DS_ALDR_SITE_GET_RECENT_DEFECTS');
		var formPermissionObj = $scope.getValueOfOnLoadData('DS_CHECK_FORM_PERMISSION_USER');
		var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		var dsAsiConfigSets = $scope.getValueOfOnLoadData('DS_GET_ATTRIBUTE_SET_DTLS');
		var dsAldSdSeDetails = $scope.getValueOfOnLoadData('DS_ALD_SNAG_DESNAG_DETAILS');
		$scope.canCopyDefect = formPermissionObj && formPermissionObj.length && formPermissionObj[0].Value4 == 'Yes'; 
		$scope.recentDefectsList = [];
		$scope.recentdefectCaption = "Please Select...";

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			CONSTANTS_OBJ = {
				LOCATION_LABEL: "Location List",
				IMAGE_ASITE_DEFAULT_STR: '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR: 'images/asite.gif',
				CONFIG_ISSUE_DESC_LIST_NAME: "Issue Description",
				CONFIG_ISSUE_SET: "Site Issues"
			};

		$scope.isOffline = $window._isOffline;
		
		$scope.attachements= {
            attachedDocs: ""
		};
		$scope.filterDropdownList = {
			reportByList: [],
			issueTypeList: [],
			IssueDescriptionList: []
		};
		
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);

			if($scope.isOriView && !$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no"){
				$scope.oriMsgCustomFields.StartDate = $scope.todayDateDbFormat;
				$scope.oriMsgCustomFields.StartDateDisplay = $scope.formatDate(new Date($scope.todayDateDbFormat), 'dd-M-yy');
			}
		});

		if ($window._isOffline && $scope.isOriView && !$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no") {
			if(objConfigData.todaysDate){
				// reversing date because getting in dd-mm-yyyy format
				var todaysDate = objConfigData.todaysDate.split("-").reverse().join("-");
				$scope.oriMsgCustomFields.StartDate =  $scope.formatDate(new Date(todaysDate), 'yy-mm-dd');
				$scope.oriMsgCustomFields.StartDateDisplay = $scope.formatDate(new Date(todaysDate), 'dd-M-yy');
			}
			if(objConfigData.formCreationDate){
				$scope.oriMsgCustomFields.FormCreationDate = objConfigData.formCreationDate;
			}
		}

		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		var showHideTooltipDueDate = function () {
			if($window.showHideTooltipDueDateCalled){
				return;
			}
			$window.showHideTooltipDueDateCalled = true;
			angular.element('body').on('click', function (event) {
				if(!angular.element('#expdueDateInfoIcon').length){
					return;
				}
				var $eventTarget = angular.element(event.target),
					targetId = event.target.id,
					targetParentId = event.target.parentElement.id,
					clickedOnIcon;
	
					if(targetId == 'expdueDateInfoIcon' || targetParentId == 'expdueDateInfoIcon'){
						clickedOnIcon = true;
						if(angular.element('.exp-due-date-wrapper').hasClass('showTooltip')){
							angular.element('.exp-due-date-wrapper').removeClass('showTooltip');
						}else{
							angular.element('.exp-due-date-wrapper').addClass('showTooltip');
						}
					}
					if(!clickedOnIcon && angular.element('.exp-due-date-wrapper').hasClass('showTooltip') && !$eventTarget.closest('#expdueDateInfo').length){
						angular.element('.exp-due-date-wrapper').removeClass('showTooltip');
					}
			});
		};
		showHideTooltipDueDate();
		$scope.onStartDateChange = function(){
			var StartDate = $scope.oriMsgCustomFields.StartDate;
			$scope.oriMsgCustomFields.StartDateDisplay = StartDate ? $scope.formatDate(new Date(StartDate), 'dd-M-yy') : "";
		};

		$scope.onDefectTypeChange = function (defectVal) {
			var defectTypeItem = DefectTypes.filter(function (defectType) {
				return defectType.Value1.trim() == defectVal;
			});
			$scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser = "";
			$scope.oriMsgCustomFields.Username = "";
			$scope.oriMsgCustomFields.Organization = "";
			if (defectTypeItem.length && defectTypeItem[0]) {
				$scope.oriMsgCustomFields.Username = defectTypeItem[0].Value4;
				$scope.oriMsgCustomFields.Organization = defectTypeItem[0].Value3;
			} 
			fillusersTODistList();
		};

		$scope.onLocationChange = function(item){
			var strPF_Details = "";
			$scope.oriMsgCustomFields.LocationName = "";
			if(item && item.modelValue){
				strPF_Details = item.Value3.trim() + "|" +  item.Value5.trim() + "|" +  item.Value7.trim() + "|" +  item.Value11.trim();
				$scope.oriMsgCustomFields.PF_Location_Detail = strPF_Details;
				$scope.oriMsgCustomFields.LocationName = item.modelValue.split('|')[2];
			}
		};

		$scope.validateExpDueDays = function(){
			var expDays = $scope.oriMsgCustomFields.ExpectedFinishDays;
			if(expDays){
				if(isNaN(expDays)){
					$scope.oriMsgCustomFields.ExpectedFinishDays = "";
					alert("Expected Finish Day(s) Should be Number Only!!!");
					return;
				}else if(expDays <= 0){
					$scope.oriMsgCustomFields.ExpectedFinishDays = "";
					alert("Expected Finish Day(s) should be greater than zero!!!");
					return;
				}
			}

		};
		
		function setWorkFlowResponse(){
			var status = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS;
			var formStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS.trim();
			var strStatus,strUserId;

			if(formStatus){
				var formStatusObj = $scope.allActiveFormStatus.filter(function(item){
					return item.Name.toLowerCase() == formStatus.toLowerCase();
				   });
				if(formStatusObj.length){
					strStatus = formStatusObj[0].Value;
				}
				var distributionDays = getRespondDays();
				if(!distributionDays){
					distributionDays = $scope.oriMsgCustomFields.DistributionDays.trim();
				}
				if(status.toLowerCase().indexOf('resolved') > -1 && strStatus.toLowerCase() != status.toLowerCase()){
					strUserId = $scope.oriMsgCustomFields.LastResponder_For_Originator;
					$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "411";
                    SetAutoDistribution(strUserId, "3#Respond", distributionDays, true);
				}
				if(status.toLowerCase().indexOf('open') > -1 && strStatus.toLowerCase() != status.toLowerCase()){
					strUserId = $scope.oriMsgCustomFields.LastResponder_For_AssignedTo;
					$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "411";
                    SetAutoDistribution(strUserId, "3#Respond", distributionDays);
				}
				if(status.toLowerCase().indexOf('verified') > -1){
					$scope.oriMsgCustomFields.ActualFinishDate = $scope.serverDate;
					strUserId = $scope.oriMsgCustomFields.LastResponder_For_AssignedTo;
                    SetAutoDistribution(strUserId, "7#", "");
				}else{
					$scope.oriMsgCustomFields.ActualFinishDate = "";
				}
			}
		}

		function setWorkFlowOri() {
			var assignedUser = $scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser;
			if(assignedUser){
				var struservalue = assignedUser.split('#')[0].trim();
				var strusername = assignedUser.split('#')[1].trim();
				var distributionDays = $scope.oriMsgCustomFields.DistributionDays;
				SetAutoDistribution(struservalue, "3#Respond", distributionDays);
				$scope.oriMsgCustomFields.LastResponder_For_AssignedTo = struservalue;
				$scope.oriMsgCustomFields.Assigned = strusername;
				$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "401";
			}
		}

		function getRespondDays(){
			var strdays = "";
			var actionDetails = $scope.getValueOfOnLoadData('DS_GET_APP_ACTION_DETAILS').filter(function(action) {
				return action.Value2 == "Respond";
			});
			if(actionDetails.length){
				strdays = actionDetails[0].Value3.trim();
			}
			return strdays;
		}
		
		function SetAutoDistribution(userId, action, dueDays){
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users[0].DS_PROJDISTUSERS = userId;
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users[0].DS_FORMACTIONS = action;
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users[0].DS_ACTIONDUEDATE = dueDays;
		}

		function structureItemList(availList, setFor){
			var tempList = [];
			switch (setFor) {
				case "Location":
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value10,
							modelValue: item.Value9,
							Value3: item.Value3,
							Value5: item.Value5,
							Value7: item.Value7,
							Value11: item.Value11
						});
					});
				break;
				case "DistUser":
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value,
						});
					});
				break;
				case "issueType":
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value1,
							modelValue: item.Value1,
						});
					});
				break;				
			}
			return [{
				options: tempList
			}];
			
		}

		function currentUserValue() {
			return $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.trim();
		}

		function fillusersTODistList() {
			var defectTypeUser = $scope.oriMsgCustomFields.Username,
				defectTypeOrg = $scope.oriMsgCustomFields.Organization,
				UserForList = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS').filter(function (userObj) {
					return userObj.Value.split('#')[0].trim() != currentUserValue().split('|')[0].trim();
				});
			if (defectTypeUser) {
				UserForList = UserForList.filter(function (userObj) {
					return userObj.Value.split('#')[0].trim() == defectTypeUser;
				});
			} else if (defectTypeOrg) {
				UserForList = UserForList.filter(function (userObj) {
					return userObj.Name.split(',')[1].trim() == defectTypeOrg;
				});
			}
			$scope.UsersTODistList = structureItemList(UserForList, 'DistUser');
		}

		function setDistributionDaysAndExpectedEndDate(){
			var startDate = $scope.oriMsgCustomFields.StartDate;
			var finishDay = $scope.oriMsgCustomFields.ExpectedFinishDays;
			if(finishDay && startDate){
				var strParam = startDate + '|' + '' + '|' + finishDay;
				var spName = "DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY";
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": spName,
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": spName,
							"fieldValue": strParam
						}]
					}
				};
				$scope.getCallbackData(form).then(function (response) {
					if(response.data){
						var resData = angular.fromJson(response.data[spName]).Items.Item, 
							strCloseDate, 
							closeDateArr,
							distributionDays,
							resDataItem;

						if(resData.length){
							resDataItem = resData[0];
							distributionDays = parseInt(finishDay) + parseInt(resDataItem.Value1);
							closeDateArr = resDataItem.Value2.split('/');
							strCloseDate = closeDateArr[2]+"-"+closeDateArr[1]+"-"+closeDateArr[0];
							$scope.oriMsgCustomFields.DistributionDays = distributionDays.toString();
							$scope.oriMsgCustomFields.ExpectedFinishDate = resDataItem.Value2;
							$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users[0].DS_ACTIONDUEDATE = distributionDays.toString();
							$scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE = strCloseDate;
						}
						$scope.submitFlag = true;
						$window.submitForm(1);
					}
				});
			}
		}

		function setLocationValue(){
			var locationId = commonApi.getParamObj().locationId;
			var isCalibrated = commonApi.getParamObj().isCalibrated;
			var aldSDS;
			if($window._isOffline){
				locationId = objConfigData.locationId;
				isCalibrated = objConfigData.isCalibrated;
			}
			if(!locationId){
				return;
			}
			$scope.strCanReply = '';
			if (locationId) {
				for (var m = 0; m < dsAldSdSeDetails.length; m++) {
					aldSDS = dsAldSdSeDetails[m];
					if(locationId == aldSDS.Value6.split('|')[0].trim()){
						$scope.strCanReply = 'yes';
					}
				}
			}
			var locations = $scope.LocationItems, selectedLocation;
			if(locationId && locations.length && locations[0].options && $scope.strCanReply == 'yes'){
				selectedLocation = locations[0].options.filter(function(item){
					return item.Value3 == locationId;
				});
				$scope.oriMsgCustomFields.Location = selectedLocation.length && selectedLocation[0].modelValue || '';
				$scope.LocationItems = structureItemList($scope.getValueOfOnLoadData('DS_ASI_SITE_getAllLocationByProject_PF'), 'Location');
				$scope.onLocationChange(selectedLocation[0]);
				if(isCalibrated == 'true' && $scope.oriMsgCustomFields.Location){
					$scope.oriMsgCustomFields.isCalibrated = true;
				}else{
					$scope.oriMsgCustomFields.isCalibrated = false;
				}
			}
		}

		/**
		 * Set location, locationName, PF_Location_Detail value from object 
		 * @param {object} item: matched item from location sp data
		 */
		function setLocationsFieldsValue(item){
			var strPF_Details = "";
			$scope.oriMsgCustomFields.LocationName = "";
			if(item && item.Value9){
				$scope.oriMsgCustomFields.Location = item.Value9 || '';
				strPF_Details = item.Value3.trim() + "|" +  item.Value5.trim() + "|" +  item.Value7.trim() + "|" +  item.Value11.trim();
				$scope.oriMsgCustomFields.PF_Location_Detail = strPF_Details;
				$scope.oriMsgCustomFields.LocationName = item.Value9.split('|')[2];
			}
		}
		
		$scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
		};
		$scope.deleteItem = function(obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
		};

		/**
		 * inoked when location changed from pin icon and associated location
		 * used to set location detail on location change from pin
		 * @param {assocObj}: Array of associated location
		 */
		htmlformservice.associateLocationComplete = function (assocObj) {
			var tempList = assocObj.selectedLocation;
			if (tempList && tempList.length && tempList[0].pfLocationTreeDetail) {
				var locationId = tempList[0].pfLocationTreeDetail.locationId;
				var aldSDS;
				$scope.strCanReply = '';
				if (locationId && $scope.AllLocation.length) {
					var selectedLocation = $scope.AllLocation.filter(function (item) {
						return item.Value3 == locationId;
					});

					for (var j = 0; j < dsAldSdSeDetails.length; j++) {
						aldSDS = dsAldSdSeDetails[j];
						if (locationId == aldSDS.Value6.split('|')[0].trim()) {
							$scope.strCanReply = 'yes';
						}
					}
					if ($scope.strCanReply) {
						setLocationsFieldsValue(selectedLocation[0]);
					}
				}
			}
		};
		
		/**
		 * This function invoked on issueType change 
		 * update issue description dropwdown
		 * resets issue description if is not avail in dropdownlist  list
		 * @param {string} issueType: selected issue type
		 * 
		 */
		$scope.onIssueTypeChange = function(issueType){
			var uniqList = [];
			var tempList = commonApi._.filter(dsAsiConfigSets, function (val) {
				if (uniqList.indexOf(val.Value9 + val.Value8 + val.Value6) === -1) {
					uniqList.push(val.Value9 + val.Value8 + val.Value6);
					return val.Value8.indexOf(CONSTANTS_OBJ.CONFIG_ISSUE_DESC_LIST_NAME) != -1 && val.Value6.indexOf(issueType) != -1;
				}
			});

			// do not reset IssueDescription if already has selected avail in list
			$scope.filterDropdownList.IssueDescriptionList = commonApi.getItemSelectionList({ arrayObject: tempList, modelKey: 'Value9', displayKey: 'Value9'});
			var foundObj = commonApi._.find(tempList, function(item){
				return item.Value9 == $scope.oriMsgCustomFields.IssueDescription;
			});
			if(!foundObj){
				$scope.oriMsgCustomFields.IssueDescription = '';
			}
		};
		
		function setOriViewBase() {
			$scope.LocationItems = structureItemList($scope.getValueOfOnLoadData('DS_ASI_SITE_getAllLocationByProject_PF'), 'Location');
			$scope.issueType = structureItemList(DefectTypes, 'issueType');			
			fillusersTODistList();
		}

		/**
		 * Set data in issue type list
		 */
		function setIssueTypesList(){
			var uniqChk = [];
			var issueTypeListData = [];
			for (var index = 0; index < dsAsiConfigSets.length; index++) {
				var element = dsAsiConfigSets[index];
				if (uniqChk.indexOf(element.Value6) === -1 && element.Value2.indexOf(CONSTANTS_OBJ.CONFIG_ISSUE_SET) != -1 && element.Value5.indexOf('Issue Types') != -1) {
					uniqChk.push(element.Value6);
					issueTypeListData.push(element);
				}
			}
			$scope.filterDropdownList.issueTypeList = commonApi.getItemSelectionList({ arrayObject: issueTypeListData, modelKey: 'Value6', displayKey: 'Value6' })
		}

		function setTaskTypeFromCustomAtt(){
			var taskTypeFromConfigAtt = commonApi.getItemSelectionList({
				arrayObject: dsAsiConfigurableAttributes.filter(function (custObj) {
					return custObj.Value3 == 'Task Type' && custObj.Value11==="Active";
				}),
				groupNameKey: '',
				modelKey: 'Value8',
				displayKey: 'Value8'
			});
			$scope.filterDropdownList.reportByList =  taskTypeFromConfigAtt;
		}
		if ($scope.isOriView) {
			setOriViewBase();
			fillRecentDefects();
			var userId = $scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser;
			if (userId && !isNaN(userId)) {
				var userObj = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS').filter(function (userObj) {
					return userObj.Value.split('#')[0].trim() == userId;
				});
				if (userObj.length) {
					$scope.onDefectTypeChange($scope.oriMsgCustomFields.DefectTyoe);
					$scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser = userObj[0].Value;
				}
				setLocationformSp($scope.oriMsgCustomFields.Location);
			}
			if (!$scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no") {
				setLocationValue();
				$scope.oriMsgCustomFields.CurrStage = "1";
			}
			else if ($scope.dSFormId && $scope.dSIsDraft.toLowerCase() == "no") {
				$scope.oriMsgCustomFields.CurrStage = "2";
			}
			setTaskTypeFromCustomAtt();
			// setting dropdown list
			setIssueTypesList();
			if ($scope.oriMsgCustomFields.IssueType) {
				$scope.onIssueTypeChange($scope.oriMsgCustomFields.IssueType);
			} else {
				$scope.oriMsgCustomFields.IssueDescription = "";
			}
		}
		if ($scope.isRespView) {
			$scope.resolverStatus = $scope.allActiveFormStatus.filter(function(item){
				return item.Name.toLowerCase() == 'resolved';
			   });
			$scope.verifierStatus = $scope.allActiveFormStatus.filter(function(item){
				return item.Name.toLowerCase() == 'open' || item.Name.toLowerCase() == 'verified';
			});

			var curUserId = currentUserValue().split('|')[0].trim();
			var formStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
			var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS').filter(function(item){
				return item.Name.toLowerCase() == 'respond' && item.Value.indexOf(curUserId) > -1;
			   });
			if(incompleteAction.length){
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
				$scope.resMsgCustomFields.Comments = "";
				$scope.resMsgCustomFields.SHResponse = "Yes";
				var lastOrigId = $scope.oriMsgCustomFields.LastResponder_For_Originator;
				var lastAssignedId = $scope.oriMsgCustomFields.LastResponder_For_AssignedTo;
				if (lastOrigId != curUserId && formStatus.toLowerCase() == "resolved")
				{
					$scope.oriMsgCustomFields.LastResponder_For_Originator = curUserId;
				}
				if (lastAssignedId != curUserId && formStatus.toLowerCase() == "open")
				{
					$scope.oriMsgCustomFields.LastResponder_For_AssignedTo = curUserId;
				}
			}else{
				$scope.resMsgCustomFields.SHResponse = "";
			}
		}

		if($scope.isOriPrintView || $scope.isRespPrintView){
			$scope.allResData = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
		}

		$scope.launchDefectForm = function () {
			$window.prePopulatemapping = new Object();
			$window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '10';
			$window.prePopulatemapping['SRC1'] = $scope.oriMsgCustomFields.ORI_FORMTITLE;
			$window.prePopulatemapping['TG1'] = 'ORI_FORMTITLE';
			$window.prePopulatemapping['SRC2'] = $scope.oriMsgCustomFields.DefectTyoe;
			$window.prePopulatemapping['TG2'] = 'DefectTyoe';
			$window.prePopulatemapping['SRC3'] = encodeURIComponent($scope.oriMsgCustomFields.Location);
			$window.prePopulatemapping['TG3'] = 'Location';
			$window.prePopulatemapping['SRC4'] = $scope.oriMsgCustomFields.LocationName;
			$window.prePopulatemapping['TG4'] = 'LocationName';
			$window.prePopulatemapping['SRC5'] = $scope.oriMsgCustomFields.ExpectedFinishDays;
			$window.prePopulatemapping['TG5'] = 'ExpectedFinishDays';
			$window.prePopulatemapping['SRC6'] = $scope.oriMsgCustomFields.Defect_Description;
			$window.prePopulatemapping['TG6'] = 'Defect_Description';
			$window.prePopulatemapping['SRC7'] = $scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser.split('#')[0].trim();
			$window.prePopulatemapping['TG7'] = 'AssignedToUser';
			$window.prePopulatemapping['SRC8'] = $scope.oriMsgCustomFields.TaskType;
			$window.prePopulatemapping['TG8'] = 'TaskType';
			$window.prePopulatemapping['SRC9'] = $scope.oriMsgCustomFields.IssueType;
			$window.prePopulatemapping['TG9'] = 'IssueType';	
			$window.prePopulatemapping['SRC10'] = $scope.oriMsgCustomFields.IssueDescription;
			$window.prePopulatemapping['TG10'] = 'IssueDescription';		
			launchCreateForm("ALD-SITE");
		}

		
		function fillRecentDefects() {
			if (recentDefectObj.length) {
				var loopLength = recentDefectObj.length,
					numberOfRecentDefect = commonApi.getParamObj().numberOfRecentDefect;
				if (numberOfRecentDefect && numberOfRecentDefect < loopLength) {
					loopLength = numberOfRecentDefect;
				}
				for (var i = 0; i < loopLength; i++) {
					$scope.recentDefectsList.push({
						defectId: recentDefectObj[i].Value1,
						defectName: recentDefectObj[i].Value2,
						defectType: recentDefectObj[i].Value3,
						defectLocation: recentDefectObj[i].Value4.split('|')[2]
					});
				}
			}
		}

		$scope.selectRecenteDefect = function(defectId, defTitle){
			angular.element('#selectedRecentDefect').val(defTitle);
			$scope.recentdefectCaption = defTitle;
			$scope.onRecentDefectChange(defectId);
			$scope.closeRecentDropdown();
		};

		$scope.OpenRecentDropdown = function(){
			angular.element('.recent-defdropdown-wrapper').addClass('dropdown-open');
		};
		$scope.closeRecentDropdown = function(){
			angular.element('.recent-defdropdown-wrapper').removeClass('dropdown-open');
		};

		$scope.onRecentDefectChange = function (strVal) {
			if (strVal) {
				var defectObj = commonApi._.filter(recentDefectObj, function (val) {
					return val.Value1 == strVal;
				});
				if (defectObj.length) {
					$scope.oriMsgCustomFields.ORI_FORMTITLE = defectObj[0].Value2;
					$scope.oriMsgCustomFields.DefectTyoe = defectObj[0].Value3;
					$scope.issueType = structureItemList(DefectTypes, 'issueType');
					$scope.oriMsgCustomFields.ExpectedFinishDays = defectObj[0].Value6;
					$scope.oriMsgCustomFields.Defect_Description = defectObj[0].Value7;
					$scope.onDefectTypeChange($scope.oriMsgCustomFields.DefectTyoe);
					$scope.oriMsgCustomFields.AssignedToUsersGroup.AssignedToUsers.AssignedToUser = defectObj[0].Value8 + "#" + defectObj[0].Value9;
					$scope.oriMsgCustomFields.TaskType = defectObj[0].Value10;	
					$scope.oriMsgCustomFields.IssueType = defectObj[0].Value11;
					$scope.oriMsgCustomFields.IssueDescription = defectObj[0].Value12;
					// to set value list of dropdown
					setIssueTypesList();
					$scope.onIssueTypeChange($scope.oriMsgCustomFields.IssueType);
					setTaskTypeFromCustomAtt();
				}
			}
		}

		function setLocationformSp(strLocation) {
			if (strLocation && $scope.AllLocation.length) {
				var locObj = $scope.AllLocation.filter(function (defectType) {
					return defectType.Value9.trim() == strLocation;
				});
				if (locObj.length) {
					$scope.oriMsgCustomFields.PF_Location_Detail = locObj[0].Value3.trim() + "|" + locObj[0].Value5.trim() + "|" + locObj[0].Value7.trim() + "|" + locObj[0].Value11.trim();;
				}
			}
		}

		$scope.restrictCharPasteCustom = function (event, nodeKey, parentObj) {
			var inputValue;
			if ($window.clipboardData) {
				inputValue = $window.clipboardData.getData('Text');
			} else if (event.originalEvent) {
				inputValue = event.originalEvent.clipboardData.getData('text/plain');
			} else {
				inputValue = event.target.innerText;
			}

			if (inputValue.match(/[|<>%#]/gi)) {
				alert("Restricted Characters specified!!! Restricted Characters | < > # %");
				//	blank out richText box on paste if found any listed Special characters.	
				if (event.target.innerText) {
					angular.element(event.target).find('div[contenteditable="true"]').html('');
					parentObj[nodeKey] = '';
				} else {
					event.preventDefault();
				}
				return false;
			}
		}

		$scope.restrictCharCustom = function (event, charList) {
			switch (event.keyCode) {
				case 51:
				case 53:
				case 188:
				case 190:
				case 220:
					if (event.shiftKey) {
						alert("Restricted Characters specified!!! Restricted Characters | < > # %");
						event.preventDefault();
					}
					break;
			}
			if (charList && Array.isArray(charList) && charList.indexOf(event.keyCode) >= 0) {
				event.preventDefault();
			}
		};
		function formpemission(){
			if ($scope.strCanReply == '') {
				alert("You are currently  not authorised to Create this form for this location, Please select Different Location");
				return true;
			}
			return false;
		}

		$scope.update();
		
		$window.oriformSubmitCallBack = function () {
			formpemission();
			if ($scope.submitFlag) {
                return false;
            }
			if (angular.element('#btnSaveForm').scope().assoc.attachments.data.length > 10) {
				alert("only 10 documents are allowed to be attach");
				return true;
			}
			if ($scope.isOriView && $scope.oriMsgCustomFields.StartDate < $scope.todayDateDbFormat) {
				alert("Start date can not be a past Date!!!");
				return true;
			}
			if($scope.isRespView){
				setWorkFlowResponse();
			}
			if($scope.isOriView){
				var openObj = $scope.allActiveFormStatus.filter(function(item){
						return item.Name.toLowerCase() == 'open';
					});
				if(openObj.length){
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = openObj[0].Value;
				}
				$scope.oriMsgCustomFields.OriginatorId = currentUserValue();
				$scope.oriMsgCustomFields.LastResponder_For_Originator = currentUserValue().split('|')[0].trim();
				$scope.oriMsgCustomFields.Todays_Date = $scope.serverDate;
				setWorkFlowOri();
				if(!myConfig.isOfflineMode){
					setDistributionDaysAndExpectedEndDate();
					return true;
				}
			}
			return false;
		};

		$window.draftSubmitCallBack = function () {
			return false;
		};
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}