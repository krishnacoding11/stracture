/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/inlineattachment', '../components/item.selection', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
        });

        var dateFormatMap = {
            "en_GB": "dd-M-yy",
            "fr_FR": "d M yy",
            "es_ES": "dd-M-yy",
            "ru_RU": "dd.mm.yy",
            "en_AU": "dd/mm/yy",
            "en_CA": "d-M-yy",
            "en_US": "M d, yy",
            "zh_CN": "yy-m-d",
            "de_DE": "dd.mm.yy",
            "ga_IE": "d M yy",
            "en_ZA": "dd M yy",
            "ja_JP": "yy/mm/dd",
            "ar_SA": "dd/mm/yy",
            "en_IE": "dd-M-yy",
            "nl_NL": "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
        $scope.dSDraft = $scope.asiteSystemDataReadOnly._5_Form_Data["DS_ISDRAFT"];
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsWorkingUserId = $scope.getWorkingUserId();
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');

        /***** Initialize db fields ******/
        $scope.selectionlist = {
            contractNoList: [],
            assetOwnerList: [],
            projectManlist: [],
            maintManList: [],
            interfaceCoList: []
        }

        $scope.isDataLoaded = true;
        if (currentViewName == "ORI_VIEW") {
            var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
            $scope.selectionlist.setContractlist = commonApi.getItemSelectionList({
                arrayObject: contractData,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        var currentViewName = window.currentViewName;

        var PAA_CONSTANT = {
            //To fill dropdown rolewise
            projectMan: 'Project Manager',
            maintMan: 'Maintenance Manager',
            interfaceCo: 'Interface Co-ordinator',
            assetOwner: '[Discipline] Asset Owner',

            // Form Statuses
            Closed: 'Closed',
            forReview: 'For Review',
            rejected: 'Rejected',
            revisedForReview: 'Revised - For Review',

            reponseNotice: 'Sectional Completion Certificate Reply Period',
            defaultReplyDays: 2,

            // Manage date as per Holiday Calender
            oriDistNumb: "401",
            resDistNumb: "411",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
        }

        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break;
                }
            }
        }


        /**
         * Change event of contract field, which used to fetch addition contract fields based on selection
         * @param {String} conVal 
         */
        $scope.onContractChange = function (conVal) {
            $scope.isDataLoaded = false;
            contractChangeCallback(conVal);
        }

        /**
         * Change event of contract field, which used to fetch addition contract fields based on selection
         * @param {*} conVal 
         * @param {*} onloadFlag : check function is called form on load or on change
         */
        function contractChangeCallback(conVal, onloadFlag) {

            if (conVal) {
                var strParam = conVal.split('|')[0].trim();
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[11].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                var spParam = {
                    dataSourceArray: [
                        {
                            "fieldName": "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": strParam
                        },
                        {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }
                    ],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if (!onloadFlag) {
                            setReplyDays(response);
                            setALTandAMTusers(response);
                        }
                        if ($scope.dSFormId) {
                            checkUserCanupdateDraft(response);
                        }
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
                        if ($scope.oriMsgCustomFields.Can_Forward) {
                            var chkPermission = strIsUserDraftOnly(response);
                            if (chkPermission.toLowerCase() == "yes") {
                                setSendPermission("Draft");
                            } else {
                                setSendPermission("Send");
                            }
                        }
                    }
                };

                $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                    return obj.fieldName;
                });

                $scope.getCallbackSPdata(spParam);

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
            }
        }

        /**
         * function called before submit form
         */
        $window.paaSCCFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not authorised to edit this Draft message. Please click on cancel button to exit.");
					return true;
				}
                if (!$scope.oriMsgCustomFields.Can_Reply) {
                    alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
                    return true;
                }
            }
            if ($scope.isRespond && !$scope.canReply) {
                $window.alert("Alert!\n\nYou do not have permission to reply on this message.")
                return true;
            }
            return setflow();
        };

        /**
         * Set Reply_Days value from contract form which return by SP
         * @param {Object} response 
         */
        function setReplyDays(response) {
            var contractDates = response.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES;
            if (contractDates && contractDates.length) {
                var selectedData = commonApi._.filter(contractDates, function (obj) {
                    return obj.Value3.toLowerCase() == PAA_CONSTANT.reponseNotice.toLowerCase();
                })[0];
                $scope.oriMsgCustomFields["Reply_Days"] = selectedData ? selectedData.Value4 : PAA_CONSTANT.defaultReplyDays;
            }
        }

        function strIsUserDraftOnly(response) {
            if (response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length && response) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "alliance_technical_lead") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft" || !$scope.oriMsgCustomFields.Can_Reply) {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }
        function checkUserCanupdateDraft(response){
            var isrequired = CheckPendingAction(dsWorkingUserId);
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft");
            $scope.oriMsgCustomFields.Can_Forward = "No";
            
            var objData = commonApi._.filter(response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function(val) {
                return val.Value.split("|")[2].split("#")[0].trim() == dsWorkingUserId;
            });
            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1";
            }
            if($scope.dSDraft == "YES"  && isrequired && !strReviewDraft && !$scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "No";
            } else if($scope.dSDraft == "YES" && !strReviewDraft && $scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
		}
        function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + dsWorkingUserId + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
        }
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.editDraft = "";
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (strNodes) {
                var strUserId = "",
                    strCheckRespond = "";
                for (var i = 0; i < strNodes.length; i++) {
                    $scope.editDraft = "Yes";
                    strUserId = strNodes[i].Value1;
                    strCheckRespond = strNodes[i].Value4;
                    if (strCheckRespond == "Review Draft" && strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }
        /**
         * set AMT and ALT users from contract form which return by SP
         * @param {Object} response 
         */
        function setALTandAMTusers(response) {
            var contractUsers = response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS;
            if (contractUsers && contractUsers.length) {
                var amtUsers = [];
                var altUsers = []
                for (var index = 0; index < response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length; index++) {
                    var element = response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS[index];
                    if (element.Value) {
                        if (element.Value.toLowerCase().indexOf('alliance_leadership_team') > -1) {
                            altUsers.push(element.Value)
                        } else if (element.Value.toLowerCase().indexOf('alliance_management_team') > -1) {
                            amtUsers.push(element.Value)
                        }
                    }
                }

                $scope.oriMsgCustomFields["altUsers"] = angular.copy(altUsers);
                $scope.oriMsgCustomFields["amtUsers"] = angular.copy(amtUsers);
            }
        }

        initFormsData();

        function initFormsData() {
            if ($scope.oriMsgCustomFields.Contract && currentViewName == "ORI_VIEW") {
                contractChangeCallback($scope.oriMsgCustomFields.Contract, true);
            }
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                if (currentViewName == "ORI_VIEW") {
                    $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
                } else {
                    $scope.oriMsgCustomFields["ResponderName"] = document.getElementById('DS_WORKINGUSER').value;
                    $scope.oriMsgCustomFields["ResponderUserId"] = dsWorkingUserId;
                    $scope.isRespond = true;
                    $scope.canReply = checkHasRespondAction();
                    $scope.oriMsgCustomFields.Res_Comment = "";
                    $scope.oriMsgCustomFields.Approval_Grant = "Accept";
                    $scope.oriMsgCustomFields.ProjectConSign = "";
                }
                var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
                $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
                setRolewiseUser(PAA_CONSTANT.projectMan);
                setRolewiseUser(PAA_CONSTANT.maintMan);
                setRolewiseUser(PAA_CONSTANT.interfaceCo);
                setRolewiseUser(PAA_CONSTANT.assetOwner);
            }

            $scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;
        }

        /**
         * Used to get userId from string given by sp
         * @param {String} userString 
         */
        function getUserId(userString) {
            if (userString) {
                return userString.split('|')[2].split('#')[0].trim();
            } else {
                return "";
            }
        }

        /**
         * To check if user has action or not
         */
        function checkHasRespondAction() {
            var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                Name: "Respond"
            });
            if (!spNode) {
                return false;
            }

            var incompleteUserActionIds = spNode.Value.trim();
            if (incompleteUserActionIds && dsWorkingUserId && incompleteUserActionIds.indexOf(dsWorkingUserId) > -1) {
                return true;
            }
            return false;
        };

        function clearUsersAction(userIdsArray) {
            if (userIdsArray && userIdsArray.length) {
                var dsAppBuilderID = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];
                $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
                for (var index = 0; index < userIdsArray.length; index++) {
                    var msgType = getMsgType( userIdsArray[index] );
                    $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                        DS_AC_TYPE: "clear",
                        DS_AC_FORM: dsAppBuilderID,
                        DS_AC_MSG_TYPE: (msgType && msgType.indexOf("RES") > -1) ? "RES" : "ORI",
                        DS_AC_USERID: userIdsArray[index],
                        DS_AC_ACTION: "3",
                        DS_AC_ACTION_REMARKS: "Action Cleared"
                    })
                }
            }
        }

        function getMsgType(userId){
            for (var index = 0; index < DS_INCOMPLETE_ACTIONS_BYMSG.length; index++) {
                var element = DS_INCOMPLETE_ACTIONS_BYMSG[index];
                if(element.Value1 == userId && element.Value4 == "Respond"){
                    return element.Value3
                }
            }
            return "";
        }

        function setflow() {
            var userTodistribute = [];
            var autoDistNumber = 0;
            var actionValue = "";
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "";
            if ($scope.isOriginator) {
                userTodistribute = [
                    getUserId($scope.oriMsgCustomFields.ProjectMan),
                    getUserId($scope.oriMsgCustomFields.InterfaceCo),
                    getUserId($scope.oriMsgCustomFields.MaintenanceManager),
                    getUserId($scope.oriMsgCustomFields.AssetName),
                ];

                setFormStatus($scope.isRespond ? PAA_CONSTANT.revisedForReview : PAA_CONSTANT.forReview);
                autoDistNumber = $scope.isRespond ? PAA_CONSTANT.resDistNumb : PAA_CONSTANT.oriDistNumb;
                actionValue = PAA_CONSTANT.respondNumber;
            } else {
                autoDistNumber = PAA_CONSTANT.resDistNumb;
                var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                    Name: "Respond"
                });
                var incompleteUserActionIds = spNode && spNode.Value.split('#')[0].split('|');
                incompleteUserActionIds = commonApi._.filter(incompleteUserActionIds, function (user) { return user.trim() != "" && user != dsWorkingUserId && user });
                if ($scope.oriMsgCustomFields.Approval_Grant == 'Reject') {
                    clearUsersAction(incompleteUserActionIds);
                    userTodistribute = [
                        $scope.oriMsgCustomFields.Originator_Id
                    ];
                    setFormStatus(PAA_CONSTANT.rejected);
                    actionValue = PAA_CONSTANT.respondNumber;
                } else if (!incompleteUserActionIds.length) {
                    var allAMTandALTusers = $scope.oriMsgCustomFields.amtUsers.concat($scope.oriMsgCustomFields.altUsers);
                    allAMTandALTusers = commonApi._.map(allAMTandALTusers, function (obj) {
                        return getUserId(obj);
                    })
                    userTodistribute = allAMTandALTusers.concat([
                        $scope.oriMsgCustomFields.Originator_Id
                    ]);
                    setFormStatus(PAA_CONSTANT.Closed);
                    actionValue = PAA_CONSTANT.forInfoNumber;
                }


            }

            if (userTodistribute.length) {
                var actionNodeList = [];
                for (var index = 0; index < userTodistribute.length; index++) {
                    actionNodeList.push({
                        strUser: userTodistribute[index],
                        strAction: actionValue,
                        strDate: $scope.oriMsgCustomFields.Reply_Days
                    });
                }
                commonApi.setDistributionNode({
                    actionNodeList: actionNodeList,
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: autoDistNumber
                });
            }
            // Form's Staus will be set from below code.
            function setFormStatus(currFormStaus) {
                var strFormStatusId = commonApi.getFormStatusId({
                    availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                    strStatus: currFormStaus
                });

                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }

            return false;
        }

        function setRolewiseUser(strRole) {
            //set role wise list dropdown
            if (ds_Projusers_Role.length) {
                var lstcontractor = commonApi._.filter(ds_Projusers_Role, function (val) {
                    if (val.Value.split('|')[0].trim() == strRole) {
                        return val.Value;
                    }
                });

                var objroleuser = [];
                for (var i = 0; i < lstcontractor.length; i++) {
                    objroleuser.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }

                if (strRole) {
                    switch (strRole) {
                        case PAA_CONSTANT.assetOwner:
                            $scope.selectionlist.assetOwnerList = angular.copy(objroleuser);
                            break;
                        case PAA_CONSTANT.projectMan:
                            $scope.selectionlist.projectManList = angular.copy(objroleuser);
                            break;
                        case PAA_CONSTANT.maintMan:
                            $scope.selectionlist.maintManList = angular.copy(objroleuser);
                            break;
                        case PAA_CONSTANT.interfaceCo:
                            $scope.selectionlist.interfaceCoList = angular.copy(objroleuser);
                            break;
                    }
                }
            }
        }
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof paaSCCFinalCallBack !== "undefined") {
        return paaSCCFinalCallBack();
    }
}