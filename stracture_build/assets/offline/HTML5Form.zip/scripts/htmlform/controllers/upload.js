/**
 * Upload Controller module.
 * This module will return Upload Controller.
 * @module Upload-Controller
 */

window.getJSONData = function() {};
window.getTemplateJSONData = function() {};
define(['angular', '../components/upload'], function(angular) {

	'use strict';

	/**
	 * @constructor
	 * @alias module:Upload-Controller/UploadController
	 */
	function UploadController($scope, commonApi, $document, $rootScope) {

		$scope.uploadHelper = {
			showLoader: false,
			showError: false
		};

		$scope.upload = function() {
			$scope.uploadHelper.showLoader = true;
			commonApi.uploadFile({
				params: {
					file: $scope.currentItem.file,
					name: $scope.currentItem.name
				},
				url: 'test'
			}).then(function(response) {
				$scope.hideModal();
			}, function(error) {
				$scope.uploadHelper.showError = true;
				$scope.uploadHelper.showLoader = false;
			});
		};

		var body = document.body;

		$scope.showUploadDialog = function(id, item) {
			$scope.hideUploadDialog();

			$scope.currentItem = item;

			$scope.uploadModel.modelId = id;

			var $body = $document.find('body');
			$body.addClass('mOpen');
			if (window.innerHeight < body.scrollHeight) {
				$body.addClass('hasScroll');
			}
		};

		$scope.hideUploadDialog = function() {
			$scope.uploadModel.modelId = "";
			$scope.uploadHelper.showError = false;
			$scope.uploadHelper.showLoader = false;

			if ($scope.currentItem && $scope.currentItem.fileElement)
				$scope.currentItem.fileElement.val(null);

			var $body = $document.find('body');
			$body.removeClass('mOpen');
			$body.removeClass('hasScroll');
		};

		$rootScope.disbaleUploadBtn = true;

		$scope.uploadModel = {
			modelId: "",
			update: $scope.upload,
			hideModal: $scope.hideUploadDialog
		};
	}

	return UploadController;
});