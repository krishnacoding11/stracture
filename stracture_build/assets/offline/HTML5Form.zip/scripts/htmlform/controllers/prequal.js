define(['angular', './base', '../components/folder.selection', '../components/inlineattachment', '../components/item.selection'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout, myConfig) {
		var ctrl = this;
		var projectId;
		var formTypeId;
		var userRef;
		var dcId;
		var isDraft = false;
		var sendObj = {};
		var actionDataByFormId = {};
		var weightageId = 0;
		var currentViewName = $window.currentViewName;
		if ($scope.msgThread) {
			isDraft = $scope.msgThread.isDraft;
		}
		$scope.currentTab = 1;
		$scope.jsonWeightage = {};
		$scope.clickApprove = false;
		$scope.clickReject = false;
		$scope.canEvalution = true;
		$scope.finalRatingCount = 0;
		$scope.isToggle = false
	
		$scope.companyName = '';
		$scope.zip = '';
		$scope.regionOfWork = [];
		$scope.selectedRegionOfWorkArray = [];
		$scope.regionOfWorkTitle = "";
		$scope.regionTitle = '';

		$scope.sectorExperience = []
		$scope.selectedSectorExperience = [];
		$scope.sectorExperienceTitle = "";
		$scope.sectorTitle = "";

		$scope.categoryCode = []
		$scope.selectedCatListIndex = [];
		$scope.currentCategoryCodeArray = [];
		$scope.selectedCategoryCodeArray = [];
		$scope.CategoryTitleArry = '';
		$scope.searchCategoryCodeTextAry = '';
		$scope.slicedCategoryCodesArry = [];
		$scope.industryCodeTypeListMapping = {};

		$scope.categoryList = [];
		$scope.currentCatlistArray = [];
		$scope.selectedCatListIndex = [];
		$scope.slicedCategoryListArry = [];
		$scope.selectedCatListArray = [];
		$scope.catListTitleArry = {};
		$scope.catListTitle = {};
		$scope.displayCatListTitle = [];
		$scope.searchCatListTextAry = [];

		$scope.states = [];
		$scope.selectedState = [];
		$scope.selectedCityIndex = [];
		$scope.cities = [];
		$scope.currentCitiesArray = [];
		$scope.cityIndex = [];
		$scope.slicedCitiesArry = [];
		$scope.currentStatesArray = [];
		$scope.slicedStatesArry = [];
		$scope.selectedState = [];
		$scope.selectedStateArray = [];
		$scope.stateTitleArry = [];
		$scope.CountryId = [];
		$scope.selectedCitiesArray = [];
		$scope.cityTitleArry = [];
		$scope.searchCityTextAry = [];
		$scope.searchStateTextAry = [];

		$scope.selCountryIds = [];

		$scope.typedtext = '';
		$scope.searchTextEnabled = false;
		$scope.customizeJson = {
			'col-md-12': [35, 82, 91, 47, 247, 248, 244, 73, 245, 253, 256, 90, 76, 131, 264, "230", 276, "276", 230],
			datasource: {},
			hierarchy: {
				'city': 'state',
				'state': 'country',
				'categoryofwork': 'subcategoryofwork',
				'safetyManagementSystem': 'healthSafetyCertificationDetails',
				'healthSafetyBySSIPMember': 'healthSafetyBySSIPMemberDetails',
				'OrgQualityPoilcy': 'qualityAssuranceCertifications',
				'orgAntiBriberyPolicy': 'orgAntiBriberyPolicyDetails',
				'CompliancemeasuresforAntiBribery': 'CompliancemeasuresforAntiBriberydetails',
				'orgSuspendedforFraudulentInvestigation': 'Provide_details Provide_Details_attachment_orgSuspendedforFraudulentInvestigation',
				'AnyClaimsforCurrentPastSuretyBonds': 'ClaimsforPastSuretyBondsDetails',
				'leedCertified': 'attachafile',
				'defaultedOnLoans': 'defaultedOnPriorLoansDetails',
				'OrgsustainabilityPolicy': 'OrgSustainabilityCertification',
				'OrgAnnualSustainabilityReport': 'orgAnnualSustainabilityReportAttachment',
				'OrgequalityDiversityPlan': 'equalityDiversityPlanAttachment',
				'AnySeniorEngagedAsGovtOfficials': 'Provide_Details Provide_Details_attachment_AnySeniorEngagedAsGovtOfficials',
			},
			dropdownObj: {
				categoryofwork: {
					id: 'category_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				subcategoryofwork: {
					id: 'subcategory_id',
					name: 'name',
					language_key: 'language_key',
					parent: 'category_id',
					regionCode: ''
				},
				businessType: {
					id: 'business_type_id',
					name: 'business_type_name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				companyIndustry: {
					id: 'company_industry_id',
					name: 'company_industry_name',
					language_key: 'company_industry_language_key',
					parent: '',
					regionCode: ''
				},
				country: {
					id: 'countryId',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					hasChild: true,
					isFilterDesc: true,
					regionCode: ''
				},
				state: {
					id: 'regionId',
					name: 'name',
					language_key: 'state_language_key',
					parent: 'countryId',
					hasChild: true,
					isFilterDesc: true,
					regionCode: "regionCode"
				},
				County: {
					id: 'county_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					hasChild: false,
					isFilterDesc: true,
					regionCode: ""
				},
				city: {
					id: 'city_id',
					name: 'city_name',
					language_key: 'city_language_key',
					parent: 'regionId',
					isFilterDesc: true,
					regionCode: ''
				},
				cityForState: {
					id: 'cityId',
					name: 'cityName',
					language_key: 'cityLanguageKey',
					parent: 'regionId',
					isFilterDesc: true,
					regionCode: ''
				},
				entityType: {
					id: 'entity_type_id',
					name: 'entity_type_name',
					language_key: 'entity_type_language_key',
					parent: '',
					regionCode: ''
				},
				regionName: {
					id: 'id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				sectorName: {
					id: 'sector_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: '',
					code: 'code'
				},
				ownerCategory: {
					id: 'ownerCategory_id',
					name: 'ownercategory_name',
					language_key: 'ownercategory_language_key',
					parent: '',
					regionCode: ''
				},
				professionalLicenceseName: {
					id: 'licencese_id',
					name: 'licencese_name',
					language_key: 'licencese_language_key',
					parent: '',
					regionCode: ''
				},
				companyContactsLevel: {
					id: 'level_id',
					name: 'level_name',
					language_key: 'level_language_key',
					parent: '',
					regionCode: ''
				},
				workExperienceArea: {
					id: 'experienceArea_id',
					name: 'experienceArea_name',
					language_key: 'experienceArea_language_key',
					parent: '',
					regionCode: ''
				},
				AccountingbasisOfStatement: {
					id: 'statement_id',
					name: 'statement_name',
					language_key: 'statement_langauge_key',
					parent: '',
					regionCode: ''
				},
				typeOfCover: {
					id: 'typeOfCover_id',
					name: 'typeOfCover_name',
					language_key: 'typeOfCover_language_key',
					parent: '',
					regionCode: ''
				},
				type_of_address: {
					id: 'id',
					name: 'name',
					language_key: '"language_key"',
					parent: '',
					regionCode: ''
				},
				nationallyRecognizedOrganizationCertifications: {
					id: 'org_certificate_id',
					name: 'org_certificate_name',
					language_key: 'org_certificate_language_key',
					parent: '',
					regionCode: ''
				},
				industrycodetype: {
					id: 'industry_code_id',
					name: 'name',
					language_key: '',
					parent: '',
					regionCode: ''
				},
				industrycategory: {
					id: 'industry_type_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				regionOfWork: {
					id: 'regionofwork_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				sectorExperience: {
					id: 'sector_Experience_id',
					name: 'name',
					language_key: 'language_key',
					parent: '',
					regionCode: ''
				},
				skills: [{
					id: 'unspc',
					name: 'UNSPC'
				}, {
					id: 'naics',
					name: 'NAICS'
				}, {
					id: 'nigp',
					name: 'NIGP'
				}, {
					id: 'csi',
					name: 'CSI'
				}, {
					id: 'other',
					name: 'OTHER'
				}
				]
			},
			uopBasicDetail: {
				legalCompanyName: '',
				duns: '',
				website: {},
				businessType: '',
				keyContactFirstName: {},
				keyContactLastName: {},
				keyContactEmail: {},
				keyContactNo: {},
				address: '',
				alertXhr: true,
				isUOPedit: false,
				companyOverview: '',
				Logo: '',
				city: '',
				country: '',
				entityType: '',
				categoryofwork: '',
				County: '',
				xhr: true
			}
		};
		$scope.formValid = true;
		$scope.currentCategoryItem = 1;
		$scope.isOverFlow = false;
		$scope.clickSave = false;
		$scope.clickSaveDraft = false;
		$scope.isForSaveDraft = false;
		$scope.hideNavBar = false;
		$scope.prequalJsonWeightage = {};
		$scope.uopAttachments = [];
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});
		ctrl.$onInit = function () {
			$scope.language = Language;
			$scope.data = $scope.getFormData();
			if (currentViewName == "PREQUAL_RES_VIEW") {
				$scope.companyName = $scope.data.ORI_FORMTITLE;
				if($scope.data.uopData && $scope.data.uopData.length > 0){
					$scope.currentCategoryItem = $scope.data.uopData[0].id;
				}
				weightageId =  $scope.data.referenceResourceId;
				getPrequalWeightages();
				actionDataByFormId = $scope.getValueOfOnLoadData('DS_GET_FORM_DATA_BY_DB_FORM_ID');
			} else if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_VIEW_PRINT") {
				var iframeUrl = decodeURIComponent($window.location.href);
				var dataString = iframeUrl && iframeUrl.split('?');
				var canEvalution = $scope.getValueOfOnLoadData('DS_IS_USER_ACTION_INCOMPLETE');
				if (canEvalution.length && canEvalution[0].Value == "Y") {
					$scope.canEvalution = true;
				} else {
					$scope.canEvalution = false;
				}
				var dataArray = dataString[1] && dataString[1].split('&');

				if (dataArray) {
					//	var projectInstanceID = dataArray[1].split('_');
					//	var buyerOrgId;
					//	dcId = projectInstanceID[0].split('=')[1];
					//	if (projectInstanceID.length > 0) {
					//		projectId = projectInstanceID[1] && projectInstanceID[1].split('$$')[0];
					//		formTypeId = projectInstanceID[2] && projectInstanceID[2].split('$$')[0];
					//	}
					for (var i = 0; i < dataArray.length; i++) {
						if (dataArray[i].indexOf('mailrecipient') > -1) {
							$scope.data.recipient = dataArray[i].split('=')[1];
						}
						if (dataArray[i].indexOf('formSelectRadiobutton') > -1) {
							var tempData = dataArray[i].split('=')[1];
							dcId = tempData.split('_')[0];
							projectId = (tempData.split('_')[1] || '').split('$$')[0];
							formTypeId = (tempData.split('_')[2] || '').split('$$')[0];
						}
						if (dataArray[i].indexOf('buyerOrgId') > -1) {
							var buyerOrgId = dataArray[i].split('=')[1];
							$scope.data.buyerOrgId = buyerOrgId.split('$$')[0];
							$scope.data.buyerOrgIdHashed = buyerOrgId;

							commonApi.ajax({
								url: top.marketPlaceServiceURL + "/marketplace/uop/getUOPByOrgId/" + $scope.data.buyerOrgId,
								method: 'GET',
								withCredentials: true,
								data: {},
								headers: {
									'Content-Type': 'application/json',
									'ApiKey': top.marketPlaceApiKey
								},
							}).then(function (response) {
								if (response.status === 200) {
									$scope.data.buyerOrgName = response.data.companyName;
									$scope.update();
									resizeTextarea()
								}
							}, function (error) {
								$window.alert("Error \n\n Probelm while fetching UOP by Org ID");
								console.log(error)
								$scope.update();
								resizeTextarea()
							});
						}
						if (dataArray[i].indexOf('weightage') > -1) {
							weightageId = dataArray[i].split('=')[1];
						}

						if (dataArray[i].indexOf('userRef') > -1) {
							userRef = dataArray[i].split('=')[1];
						}
						/* if (dataArray[i].indexOf('prequalReceiveUserId') > -1) {
							prequalReceiveUserId = dataArray[i].split('=')[1];
						} */
					}
				}
				top.$($window).resize(function () {
					$scope.isOverflow();
				});
				$scope.currentSubItem = $scope.data.uopData[0].data[0].id;
				$scope.currentSubItemData = $scope.data.uopData[0].data[0];
				if (currentViewName == "ORI_VIEW" && $("input[name ='editDraft']").val() != "true") {
					getUOPData();
				} else {
					$scope.onLoadDataSet($scope.data);
					$scope.update();
					$scope.uopJSON = $scope.data;
					if($scope.data.uopData && $scope.data.uopData.length > 0){
						$scope.currentCategoryItem = $scope.data.uopData[0].id;
					}
				}
			} else if (currentViewName == "PREQUAL_RES_VIEW_PRINT") {
				$scope.update();
				$scope.jsonWeightage = $scope.data;
				$scope.showCancelButton = angular.element("input[name =DS_FORMSTATUS]").val() != $scope.data.cancelStatus;
				//hide the cancel button for vendor after preqaulification
				if($scope.data.uopData && $scope.data.uopData.length > 0){
					$scope.currentCategoryItem = $scope.data.uopData[0].id;
				}
				if (angular.element("#DS_WORKINGUSERROLE").val() == "Vendor") {
					$scope.showCancelButton = false;
				}
			}
			$timeout(function () {
				if (isDraft) {
					$("#evalution").hide();
				} else {
					$("#evalution").show();
				}
			}, 50)
			$scope.approveStatus = $scope.data.approveStatus;
			$scope.rejectStatus = $scope.data.rejectStatus;
			
		}
		$scope.cancelInvitation = function () {
			var FormId = $("input[name ='formId']").val();
			var ProjectId = $("input[name ='projectId']").val();
			ProjectId = ProjectId.split("$$")[0];
			var formTypeId = $("input[name ='formTypeId']").val();
			if ($scope.showCancelButton) {
				$scope.clickCancel = true;
				commonApi.ajax({
					url: top.marketPlaceServiceURL + "/marketplace/prequal/resetPreqaulProcess",
					method: 'post',
					withCredentials: true,
					headers: {
						'ApiKey': top.marketPlaceApiKey,
						'Content-Type': 'application/json'
					},
					data: {
						formId: FormId,
						projectId: ProjectId,
						isApprove: true,
						formTypeId: formTypeId,
						prequalType: 1,
						evaluationStatus: $scope.data.cancelStatus || 'Cancelled',

					}
				}).then(function (response) {
					$scope.showCancelButton = false;
					if (response.data) {
						alert('Prequalification Cancelled Successfully')
						if (window.top && window.top.opener) {
							sendObj.refreshStatus = true;
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
							window.close();
							window.top.close();
							return;
						}
					} else {
						alert('The operation failed to excute')
					}
					window.location = top.marketPlaceServiceURL + "?origin=true";
				})
			}
		}

		var getUOPData = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/uop/orgregionuop?regionId=" + dcId + "&orgId=" + USP.orgID,
				method: 'get',
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				withCredentials: true
			}).then(function (response) {
				$scope.onLoadDataSet($scope.data);
				mergeUOPData(response.data);
				getPrequalWeightages();
				$scope.onLoadDataSet($scope.data);
			}, function () {

			});
		}
		var getPrequalWeightages = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages?boid=" + $scope.data.buyerOrgId + "&weightageId=" + weightageId,
				method: 'GET',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: {}
			}).then(function (response) {
				if (currentViewName == "PREQUAL_RES_VIEW") {
					if (response.data && response.data.myFields) {
						if (response.data.myFields.customsection && response.data.myFields.customsection.length > 0) {
							for (var i = 0; i < response.data.myFields.customsection.length; i++) {
								response.data.myFields.section.push(response.data.myFields.customsection[i]);
							}
						}
						$scope.jsonWeightage = response.data.myFields;
						$scope.update();
						if($scope.jsonWeightage.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.isEvalutionEnable == "No"){
							$scope.validateRating = false;
						}
					}
				} else {
					$scope.prequalJsonWeightage = response.data.myFields;
					showHidePrequalSection();
					$scope.currentSubItem = $scope.data.uopData[0].data[0].id;
					$scope.currentSubItemData = $scope.data.uopData[0].data[0];
					$scope.uopJSON = $scope.data;
					$scope.currentCategoryItem = $scope.data.uopData[0].id;
					$scope.update();
				}

			}, function () {
			});
		}
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ? $scope.currentTab = ' ' : $scope.currentTab = eID;
		};
		$scope.calculateRating = function (section, subsection) {
			var totalWeightageOfSubsection = 0;
			for (var i = 0; i < section.data.length; i++) {
				if (section.data[i].selected && section.data[i].evalutionWeightageValue) {
					totalWeightageOfSubsection += (parseInt(section.data[i].value) * parseInt(section.data[i].evalutionWeightageValue))
				}
			}
			var tempWeightage = (totalWeightageOfSubsection / 100);
			section.evalutionWeightageValue = tempWeightage;
			finalRatingCountCalculate();
			var ratingInput = document.getElementsByClassName("ratingInput");
			for (var i = 0; i < ratingInput.length; i++) {
				if (parseInt(ratingInput[i].value) >= 0 && parseInt(ratingInput[i].value) <= 100) {
					$scope.validateRating = false
				} else {
					$scope.validateRating = true;
					return
				}
			}
		}
		var finalRatingCountCalculate = function () {
			$scope.jsonWeightage.finalRatingCount = 0;
			for (var i = 0; i < $scope.jsonWeightage.section.length; i++) {
				if ($scope.jsonWeightage.section[i].evalutionWeightageValue) {
					var sectionPerValue = (parseInt($scope.jsonWeightage.section[i].value) * $scope.jsonWeightage.section[i].evalutionWeightageValue) / 100;
					$scope.jsonWeightage.finalRatingCount = $scope.jsonWeightage.finalRatingCount + sectionPerValue;
				}
			}
		}
		var showHidePrequalSection = function () {
			if ($scope.prequalJsonWeightage && $scope.prequalJsonWeightage.section) {
				for (var i = 0; i < $scope.prequalJsonWeightage.section.length; i++) {
					if (!$scope.prequalJsonWeightage.section[i].selected) {
						for (var j = $scope.data.uopData.length - 1; j >= 0; j--) {
							if ($scope.prequalJsonWeightage.section[i].sectionId == $scope.data.uopData[j].id) {
								$scope.data.uopData.splice(j, 1);
							}
						}
					} else {
						for (var j = 0; j < $scope.data.uopData.length; j++) {
							if ($scope.prequalJsonWeightage.section[i].sectionId == $scope.data.uopData[j].id) {
								for (var k = 0; k < $scope.prequalJsonWeightage.section[i].data.length; k++) {
									if (!$scope.prequalJsonWeightage.section[i].data[k].selected) {
										for (var l = $scope.data.uopData[j].data.length - 1; l >= 0; l--) {
											if ($scope.prequalJsonWeightage.section[i].data[k].sectionId == $scope.data.uopData[j].data[l].id) {
												$scope.data.uopData[j].data.splice(l, 1);
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if ($scope.prequalJsonWeightage && $scope.prequalJsonWeightage.customsection) {
				var subsectionData = [];
				for (var i = 0; i < $scope.prequalJsonWeightage.customsection.length; i++) {
					if ($scope.prequalJsonWeightage.customsection[i].selected) {
						for (var j = 0; j < $scope.prequalJsonWeightage.customsection[i].data.length; j++) {
							if ($scope.prequalJsonWeightage.customsection[i].data[j].selected) {
								subsectionData.push($scope.prequalJsonWeightage.customsection[i].data[j]);
							}
						}
						$scope.prequalJsonWeightage.customsection[i].data = subsectionData;
						subsectionData = [];
						$scope.data.uopData.push($scope.prequalJsonWeightage.customsection[i]);
					}
				}
			}
		}
		var getObjByFieldId = function (data) {
			var obj = {};
			if (data.length) {
				for (var i = 0; i < data.length; i++) {
					var subDataA = data[i];
					if (subDataA.data.length) {
						for (var j = 0; j < subDataA.data.length; j++) {
							var subDataB = subDataA.data[j];
							if (subDataB.data.length) {
								for (var k = 0; k < subDataB.data.length; k++) {
									var subDataC = subDataB.data[k];
									subDataC.fieldId && (obj[parseInt(subDataC.fieldId)] = subDataC);
								}
							}
						}
					}
				}
			}
			return obj;
		};
		var mergeUOPData = function (data) {
			$scope.companyName = data.companyName
			var responseObjByFieldId = getObjByFieldId(data.uopData);
			var scopeObjByFieldId = getObjByFieldId($scope.data.uopData);
			var uopItem;
			$scope.data.uopId = data.uopId;
			if (Object.keys(scopeObjByFieldId).length) {
				for (var key in scopeObjByFieldId) {
					if (scopeObjByFieldId[key].validationTypeId) {
						var validationTypeId = scopeObjByFieldId[key].validationTypeId.split(',');
						for (var i = 0; i < validationTypeId.length; i++) {
							if (validationTypeId[i] == "2") {
								scopeObjByFieldId[key].isMandatory = true;
							}
						}
					}
					if (scopeObjByFieldId[key].value && scopeObjByFieldId[key].value[0].length > 0) {
						for (var j = 0; j < scopeObjByFieldId[key].value[0].length; j++) {
							var validationTypeId = scopeObjByFieldId[key].value[0][j].validationTypeId.split(',');
							for (var i = 0; i < validationTypeId.length; i++) {
								if (validationTypeId[i] == "2") {
									scopeObjByFieldId[key].value[0][j].isMandatory = true;
								}
							}
						}
					}
					if (responseObjByFieldId[key]) {
						if (scopeObjByFieldId[key].fieldTypeId == 8) {
							if (responseObjByFieldId[key].value && responseObjByFieldId[key].value.length) {
								scopeObjByFieldId[key].value = [];
								for (var i = 0; i < responseObjByFieldId[key].value.length; i++) {
									for (var k = 0; k < responseObjByFieldId[key].value[i].length; k++) {
										if (responseObjByFieldId[key].value[i][k].fieldId == 232 || responseObjByFieldId[key].value[i][k].fieldId == 271) {
											responseObjByFieldId[key].value[i][k].value = responseObjByFieldId[key].value[i][k].value == "true" ? true : false
										}
										var validationTypeId = responseObjByFieldId[key].value[i][k].validationTypeId.split(',');
										for (var l = 0; l < validationTypeId.length; l++) {
											if (validationTypeId[l] == "2") {
												responseObjByFieldId[key].value[i][k].isMandatory = true;
											}
										}
									}
									scopeObjByFieldId[key].value.push(responseObjByFieldId[key].value[i]);
								}
								for (var i = 0; i < responseObjByFieldId[key].value.length; i++) {
									for (var j = 0; j < responseObjByFieldId[key].value[i].length; j++) {
										uopItem = responseObjByFieldId[key].value[i][j];
										if (scopeObjByFieldId[key].value[i]) {
											for (var k = 0; k < scopeObjByFieldId[key].value[i].length; k++) {
												if (responseObjByFieldId[key].value[i][j].fieldId == scopeObjByFieldId[key].value[i][k].fieldId) {
													if (responseObjByFieldId[key].value[i][j].fieldTypeId == 7) {
														if (responseObjByFieldId[key].value[i][j].value && responseObjByFieldId[key].value[i][j].value.id) {
															responseObjByFieldId[key].value[i][j].value.content = "my_" + responseObjByFieldId[key].value[i][j].value.name;
															$scope.uopAttachments.push(responseObjByFieldId[key].value[i][j].value)
														}
													}
													scopeObjByFieldId[key].value[i][k].value = responseObjByFieldId[key].value[i][j].value;
												}
											}
										}

									}
								}
							}
						} else {
							if (responseObjByFieldId[key].value == "true") {
								responseObjByFieldId[key].value = true;
								var fName = $scope.customizeJson.hierarchy[scopeObjByFieldId[key].fieldName];
								for (var i = 0; i < Object.keys(scopeObjByFieldId).length; i++) {
									if (fName == scopeObjByFieldId[Object.keys(scopeObjByFieldId)[i]].fieldName) {
										scopeObjByFieldId[Object.keys(scopeObjByFieldId)[i]].isShow = responseObjByFieldId[key].value;
									}
								}
							}
							scopeObjByFieldId[key].value = responseObjByFieldId[key].value;
						}

					}
				}
			}
		};
		$scope.returnStyle = function (style) {
			if ($scope.setStyle['col-md-6'].indexOf(style.fieldId) > -1 || $scope.setStyle['col-md-6'].indexOf(style.fieldTypeId) > -1) {
				return 'col-md-12';
			}
			else {
				return 'col-md-6';
			}
		}
		$scope.onLoadDataSet = function (paramObj,save) {
			var uopArray = paramObj.uopData;
			var section = [];
			for (var index = 0; index < uopArray.length; index++) {
				section = uopArray[index].data;
				for (var index1 = 0; index1 < section.length; index1++) {
					$scope.customizeSubsection(section[index1].data,save);
				}

			}
		}
		$scope.customizeSubsection = function (array,save) {
			var item;
			for (var index2 = 0; index2 < array.length; index2++) {
				item = array[index2];
				if (item.fieldTypeId == 8 && item.value) {
					item.value = $scope.dataManipulate(item);
				}
				$scope.updateItem(item, array);
				$scope.handleMultipleEntry(item,save);
				$scope.getAPIdata(item);
			}
		}
		$scope.setStyle = function (item) {
			item.width = 'col-md-6';
			if ($scope.customizeJson['col-md-12'].indexOf(item.fieldId) > -1) {
				item.width = 'col-md-12';
			}
		}
		$scope.dataManipulate = function (item) {
			var itemValue = [];
			var tempItemValue = [];
			if (item.value.length) {
				for (var i = 0; i < item.value.length; i++) {
					if (item.value[i]) {
						itemValue[i] = item.value[i].array ? item.value[i].array : item.value[i];
					}

				}
			} else {
				if (item.value) {
					if (item.value.array && item.value.array.length > 1) {
						for (var i = 0; i < item.value.array.length; i++) {
							tempItemValue.push(item.value.array[i]);
						}
						itemValue[0] = tempItemValue;
					} else {
						itemValue[0] = item.value.array ? [item.value.array] : item.value;
					}
				}

			}

			return itemValue;

		}
		$scope.handleMultipleEntry = function (item,save) {						
			var dataValue = item.value;
			item['header'] = [];
			if (item.fieldTypeId == 8 && item.value && item.value.length > 0) {
				for (var index = 0; index < item.value.length; index++) {
					for (var index1 = 0; index1 < dataValue[index].length; index1++) {
						$scope.getAPIdata(dataValue[index][index1]);
						$scope.updateItem(dataValue[index][index1], dataValue);
					}

				}
				item['header'] = angular.fromJson(angular.toJson(item.value[0]));
				if(save){
					for(var h=0;h<item.header.length;h++){
						if(item.header[h].label ==  "Attachment" || item.header[h].label == "Attach Documents"){
							item.header[h].value=null;
						}
					}
					for(var v=0;v<item.value.length;v++){						
						for(var i=0;i<item.value[v].length;i++){
							if((item.value[v][i].label ==  "Attachment" || item.value[v][i].label == "Attach Documents") && (item.value[v][i].value && !item.value[v][i].value.hasOwnProperty("content")))
							item.value[v][i].value = null;
						}
					}
				}
			}
		}
		$scope.updateItem = function (item, array) {
			if ($scope.customizeJson['col-md-12'].indexOf(item.fieldId) > -1) {
				item.width = 'col-md-12';
			}
			item.visibility = (item.visibility == 0 ? true : false);

			switch (parseInt(item.fieldTypeId)) {
				case 8:
					item.width = 'col-md-12';
					$scope.filterOptions(item, array);
					break;
				case 4:
					item.width = 'col-md-12';
					!item.value && (item.value = false);
					$scope.filterOptions(item, array);
					break;
				case 5:
					item.width = 'col-md-6';
					$scope.filterOptions(item, array);
					break;
				default:
					item.width = 'col-md-6';
					break;
			}
			if ($scope.customizeJson['col-md-12'].indexOf(item.fieldId) > -1) {
				item.width = 'col-md-12';
			}
		}
		$scope.getAPIdata = function (data) {
			if ((data.fieldTypeId == 5 || data.fieldTypeId == 6) && !$scope.customizeJson.datasource[data.fieldName]) {
				$scope.customizeJson.datasource[data.fieldName] = [];
				commonApi.ajax({
					url: top.marketPlaceServiceURL + '/marketplace/uop/fieldLookupData/' + data.fieldName,
					method: 'GET',
					headers: {
						'Content-Type': 'application/json',
						'ApiKey': top.marketPlaceApiKey
					},
					withCredentials: true
				}).then(function (response) {
					var array = [];
					var dropObj = $scope.customizeJson.dropdownObj[data.fieldName];
					if (response.data && dropObj) {
						for (var index = 0, item; index < response.data.length; index++) {
							item = response.data[index];
							array.push({
								value: String(item[dropObj.id]),
								name: item[dropObj.name],
								language_key: item[dropObj.language_key],
								parentId: item[dropObj.parent],
								regionCode: item[dropObj.regionCode]

							});
						}
						if (dropObj.id == 'regionofwork_id') {
							$scope.customizeJson.datasource[data.fieldName] = array;
							$scope.regionOfWork = $scope.customizeJson.datasource.regionOfWork;
							var tempValueRegionOfWorkArray = $scope.data.uopData[0].data[1].data.filter(function (com) {
								return com.fieldName == "regionOfWork"
							})[0];
							var valueRegionOfWorkArray = tempValueRegionOfWorkArray && tempValueRegionOfWorkArray.value && tempValueRegionOfWorkArray.value != "" ? tempValueRegionOfWorkArray.value.split(",") : [];
							if (valueRegionOfWorkArray != "" && $scope.regionOfWork != undefined) {
								$scope.regionOfWork.filter(function (cat) { return valueRegionOfWorkArray.indexOf(cat.value) != -1 })
									.forEach(function (cat) {
										cat.active = true;
										cat.hide = false;
										$scope.selectRegionOfWorkCompany(cat);
									})
							}
						}
						if (dropObj.id == 'entity_type_id') {
							$scope.customizeJson.datasource[data.fieldName] = array;
						}
						if (dropObj.id == 'company_industry_id') {
							$scope.customizeJson.datasource[data.fieldName] = array;
						}
						if (dropObj.id == 'sector_Experience_id') {
							$scope.customizeJson.datasource[data.fieldName] = array;
							$scope.sectorExperience = $scope.customizeJson.datasource.sectorExperience;
							var tempValueSectorExperience = $scope.data.uopData[0].data[1].data.filter(function (com) {
								return com.fieldName == "sectorExperience"
							})[0];
							var valueSectorExperience = tempValueSectorExperience && tempValueSectorExperience.value && tempValueSectorExperience.value != "" ? tempValueSectorExperience.value.split(",") : [];
							if (valueSectorExperience != "" && $scope.sectorExperience != undefined) {
								$scope.sectorExperience.filter(function (cat) { return valueSectorExperience.indexOf(cat.value) != -1 })
									.forEach(function (cat) {
										cat.active = true;
										cat.hide = false;
										$scope.selectSectorExperience(cat);
									})
							}
						}
						if (dropObj.id == 'industry_code_id') {
							var tempCatArray = [];
							var tempCatCode;
							var tempCatList;
							var selectedCatCode = '';
							var selectedCatList = '';
							var isCatCOdeNull = false;
							$scope.customizeJson.datasource[data.fieldName] = array;
							$scope.categoryCode = $scope.customizeJson.datasource.industrycodetype
							
							tempCatArray = $scope.data.uopData[0].data[2].data;
							
							if (tempCatArray.filter(function (add) { return add.fieldName == "industrycodetype"})[0]) {
								tempCatCode = tempCatArray.filter(function (add) { return add.fieldName == "industrycodetype"})[0];
									selectedCatCode = tempCatCode.value;
									if (!selectedCatCode && $scope.categoryCode && $scope.categoryCode.length) {
										isCatCOdeNull = true;
										selectedCatCode = $scope.categoryCode[0].value;
										tempCatCode.value = selectedCatCode;
									}
									tempCatList = tempCatArray.filter(function (catList) { return catList.fieldName == "industrycategory"})[0];
									
									selectedCatList = tempCatList.value;
									$scope.selectedCatListIndex = [selectedCatList];
									if (selectedCatCode != '' && $scope.categoryCode != undefined) {
										$scope.categoryCode.filter(function (catCode1) { return selectedCatCode == catCode1.value })
											.forEach(function (catCode1) {
												catCode1.active = false;
												catCode1.hide = false;
												if (isCatCOdeNull) {
													//setTimeout(() => {
													$scope.selectCategoryCode(catCode1, tempCatList, '', "industrycodetype");
													//}, 1000);
												}
												else {
													$scope.selectCategoryCode(catCode1, tempCatList, '', "industrycodetype");
												}

											})
									}

								}

							
							if (!$scope.slicedCategoryCodesArry.length && $scope.categoryCode && $scope.categoryCode.length) {
								$scope.slicedCategoryCodesArry = $scope.categoryCode.slice(0, 10)
							}
						}
						if (dropObj.id == 'regionId') {
							var tempAdressArray = [];
							var selectedState;
							var tempState;
							var selectedCity;
							var tempCity;
							var isStateNull = false;
							$scope.customizeJson.datasource[data.fieldName] = array;
							$scope.states = $scope.customizeJson.datasource[data.fieldName]
							if ($scope.data.uopData[0].data[3].data.filter(function (add) { return add.fieldName == "address" })[0]) {
								tempAdressArray = $scope.data.uopData[0].data[3].data.filter(function (add) { return add.fieldName == "address" })[0].value;
							}
							if (tempAdressArray && tempAdressArray.length) {
								for (var t = 0; t < tempAdressArray.length; t++) {
									var tempCountry = tempAdressArray[t].filter(function (country) { return country.fieldName == "country" })[0];
									if (tempCountry.value) {
										$scope.selCountryIds[t] = tempCountry.value;
										if (tempCountry.value == '18') {
											tempAdressArray[t][4].label = "County";
											$scope.setCitiesForSelectedState(tempCountry.value, t, '', tempAdressArray[t], '', false, 'country');
										} else {
											tempAdressArray[t][4].label = "State";
										}
										$scope.setStateForSelectedCountry(tempCountry.value, t, '', tempAdressArray[t], '', true, 'country');
									}
									tempState = tempAdressArray[t].filter(function (state) { return state.fieldName == 'state' })[0]
									$scope.selectedState[t] = selectedState = tempState.value;
									if (!selectedState && $scope.states && $scope.states.length) {
										isStateNull = true;
										selectedState = $scope.states[0].value
									}
									tempCity = tempAdressArray[t].filter(function (city) { return city.fieldName == "city" })[0]
									selectedCity = tempCity.value;
									$scope.selectedCityIndex[t] = selectedCity;


									if (selectedState != '' && $scope.states != undefined) {
										$scope.states.filter(function (state) { return selectedState == state.value })
											.forEach(function (state) {
												state.active = false;
												state.hide = false;
												if (isStateNull) {
													//setTimeout(() => {
													$scope.selectState(state, t, '', '', 'state');
													//}, 1000);
												}
												else {
													$scope.selectState(state, t, '', '', 'state');
												}

											})
									}
								}

							}
							if (!$scope.slicedStatesArry.length && $scope.states && $scope.states.length) {
								$scope.slicedStatesArry = $scope.states.slice(0, 10)
							}
						}
						if (dropObj.id == "countryId") {
							$scope.customizeJson.datasource[data.fieldName] = array;
						}
						if (data.fieldName == "type_of_address") {
							$scope.customizeJson.datasource[data.fieldName] = array;
						}
						if (data.id = "typeOfCover_id") {
							$scope.customizeJson.datasource[data.fieldName] = array;
						}
					}
				}, function () {

				});
			}
		}
		$scope.selectState = function (state, currentindex, subitems, uopItems, from, postcodeCity, fromOnchange, seTimeOut) {
			if (currentindex == undefined)
				return;
			$scope.clearStatesFilter(currentindex, subitems)
			if ($scope.searchTextEnabled) {
				$scope.currentStatesArray[currentindex].forEach(function (state) {
					state.hide = false;
				});
				$scope.searchTextEnabled = false;
			}

			if (!subitems && uopItems && uopItems.length) {
				for (var i = 0; i < uopItems.length; i++) {
					if (uopItems[i].fieldId == 8) {
						subitems = uopItems[i];
					}
				}
			}
			var stateTitle = [],
				arryCity = $scope.currentStatesArray[currentindex];

			if (state) {
				state.active = !state.active;
			}

			if (arryCity) {
				for (var index = 0; index < arryCity.length; index++) {
					if (arryCity[index].active) {
						$scope.selectedStateArray = [];
						$scope.selectedStateArray.push(arryCity[index]);
					}
				}
			}
			for (var i = 0; i < $scope.selectedStateArray.length; i++) {
				var element = $scope.selectedStateArray[i];
				if (!element.active) {
					$scope.currentStatesArray[currentindex].push(element);
					$scope.selectedStateArray.splice(i, 1);
				} else {

					stateTitle.push(element.name);
				}
			}
			if (state && !state.active) {
				$scope.currentStatesArray[currentindex] && $scope.currentStatesArray[currentindex].sort(function (a, b) {
					if (a.name < b.name) return -1;
					else if (a.name > b.name) return 1;
					return 0;
				});
			}
			if ($scope.selectedStateArray[0]) {
				$scope.stateTitleArry[currentindex] = $scope.selectedStateArray[0].name;
			}

			if ($scope.selectedStateArray[0] && $scope.selectedStateArray[0].value && ($scope.CountryId[currentindex] != '18')) {
				$scope.setCitiesForSelectedState($scope.selectedStateArray[0].value, currentindex, from, uopItems, postcodeCity, fromOnchange, 'region')
			} else {
				if (seTimeOut) {
					var cityAry;
					if (uopItems && uopItems.length) {
						for (var i = 0; i < uopItems.length; i++) {
							if (uopItems[i].fieldId == 7) {
								cityAry = uopItems[i];
							}
						}
					}
					if ($scope.selectedStateArray[0]) {
						if ($scope.customizeJson.datasource.city.length) {
							if ($scope.currentCitiesArray[currentindex]) {
								$scope.slicedCitiesArry = $scope.currentCitiesArray[currentindex].slice(0, 10);
								//   this.currentCitiesArray[currentindex] = Object.assign([], this.customizeJson.datasource.city);
								$scope.cityIndex[currentindex] = $scope.selectedCityIndex[currentindex] || 0;
								if ($scope.cityIndex[currentindex]) {
									$scope.currentCitiesArray[currentindex].filter(function (city) { return $scope.cityIndex[currentindex] == city.value })
										.forEach(function (city) {
											city.active = false;
											city.hide = false;
											$scope.selectCity(city, currentindex, cityAry);
										})
								}
							}
						}
					}
				} else {
					setTimeout(function () {
						var cityAry;
						if (uopItems && uopItems.length) {
							for (var i = 0; i < uopItems.length; i++) {
								if (uopItems[i].fieldId == 7) {
									cityAry = uopItems[i];
								}
							}
						}
						if ($scope.selectedStateArray[0]) {
							if ($scope.customizeJson.datasource.city.length) {
								if ($scope.currentCitiesArray[currentindex]) {
									$scope.slicedCitiesArry = $scope.currentCitiesArray[currentindex].slice(0, 10);
									//   this.currentCitiesArray[currentindex] = Object.assign([], this.customizeJson.datasource.city);
									$scope.cityIndex[currentindex] = $scope.selectedCityIndex[currentindex] || 0;
									if ($scope.cityIndex[currentindex]) {
										$scope.currentCitiesArray[currentindex].filter(function (city) { return $scope.cityIndex[currentindex] == city.value })
											.forEach(function (city) {
												city.active = false;
												city.hide = false;
												$scope.selectCity(city, currentindex, cityAry);
											})
									}
								}
							}
						}
					}, 500);
				}
			}

			if (subitems) {
				subitems.value = $scope.selectedStateArray[0] ? $scope.selectedStateArray[0].value : '';

				//this.onChangeDropdown(subitems, uopItems);
			}
		}
		$scope.clearStatesFilter = function (index, subitems) {
			if (subitems) {
				subitems.value = '';
			}

			for (var i = 0; i < $scope.selectedStateArray.length; i++) {
				var element = $scope.selectedStateArray[i];
				element.active = false;
			}

			$scope.currentStatesArray[index] && $scope.currentStatesArray[index].sort(function (a, b) {
				if (a.name < b.name) return -1;
				else if (a.name > b.name) return 1;
				return 0;
			});
			$scope.selectedStateArray = [];
			$scope.stateTitleArry[index] = "";
		}
		$scope.setCitiesForSelectedState = function (selectedState, currentindex, from, uopItems, postcodeCity, fromOnchange, fieldName) {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/uop/getCitiesByRegion' + "?id=" + selectedState + '&fieldName=' + fieldName,
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				withCredentials: true
			}).then(function (response) {
				if (response.data) {
					$scope.cities = response.data;
					var array = [], dropObj = $scope.customizeJson.dropdownObj['cityForState'];
					if (dropObj) {
						for (var index = 0, item, objOption; index < $scope.cities.length; index++) {
							item = $scope.cities[index];
							objOption = {
								value: String(item[dropObj.id]),
								name: item[dropObj.name],
								language_key: item[dropObj.language_key],
								parentId: item[dropObj.parent],
								hasChild: dropObj.hasChild || false,
								regionCode: item[dropObj.regionCode]
							}
							array.push(objOption);
						}
					}
					$scope.currentCitiesArray[currentindex] = Object.assign([], array);

					var cityAry;
					if (uopItems && uopItems.length) {
						for (var i = 0; i < uopItems.length; i++) {
							if (uopItems[i].fieldId == 7) {
								cityAry = uopItems[i];
							}
						}
					}
					if ($scope.cities.length) {
						$scope.cityIndex[currentindex] = $scope.selectedCityIndex[currentindex] || 0;
						if (fromOnchange)
							$scope.cityIndex[currentindex] = 0;

						if ($scope.cityIndex[currentindex]) {
							array.filter(function (city) { return $scope.cityIndex[currentindex] == city.value })
								.forEach(function (city) {
									city.active = false;
									city.hide = false;

									if (cityAry) {
										cityAry.displayValue = {};
										cityAry.displayValue.value = city.value;
										cityAry.displayValue.name = city.name;
										cityAry.displayValue.language_key = city.language_key;
									}

									$scope.selectCity(city, currentindex, cityAry);
								})
						} else {
							var city = array;
							if (cityAry) {
								if (postcodeCity) {
									city = array.filter(function (item) {
										return item.name === postcodeCity
									});
								}
								cityAry.displayValue = {
									value: city[0] ? city[0].value : '',
									name: city[0] ? city[0].name : '',
									language_key: city[0] ? city[0].language_key : ''
								}
							}
							$scope.selectCity(city[0], currentindex, cityAry);
						}

						if (!$scope.slicedCitiesArry.length && array && array.length) {
							$scope.slicedCitiesArry = array.slice(0, 10)
						}
					}
				}
			}, function () {

			});

		}
		$scope.selectCity = function (city, currentindex, subitems, uopItems) {
			$scope.clearCitiesFilter(currentindex, subitems)

			if ($scope.searchTextEnabled) {
				$scope.currentCitiesArray[currentindex].forEach(function (city) {
					city.hide = false;
				});
				$scope.searchTextEnabled = false;
			}
			var cityTitle = [],
				arryCity = $scope.currentCitiesArray[currentindex];
			if (city) {
				city.active = !city.active;
			}

			for (var index = 0; index < arryCity.length; index++) {
				if (arryCity[index].active) {
					$scope.selectedCitiesArray = [];
					$scope.selectedCitiesArray.push(arryCity[index]);

				}
			}
			for (var i = 0; i < $scope.selectedCitiesArray.length; i++) {
				var element = $scope.selectedCitiesArray[i];
				if (!element.active) {

					$scope.selectedCitiesArray.splice(i, 1);
				} else {
					cityTitle.push(element.name);
				}
			}


			var firstSelectedCity = $scope.selectedCitiesArray[0];
			if (firstSelectedCity) {
				$scope.cityTitleArry[currentindex] = firstSelectedCity.name;
				if (subitems) {
					subitems.value = firstSelectedCity.value;
				}
			}
		}
		$scope.resetCityAry = function (currentindex) {
			if ($scope.searchCityTextAry[currentindex] != "") {
				$scope.filterCitiesBySearchText($scope.searchCityTextAry[currentindex], currentindex)
			}
			else {
				$scope.slicedCitiesArry = $scope.currentCitiesArray[currentindex].splice(0, 10);
			}
		}
		$scope.resetStateAry = function (currentindex) {
			if ($scope.searchStateTextAry[currentindex] != "") {
				$scope.filterStateBySearchText($scope.searchStateTextAry[currentindex], currentindex)
			}
			else {
				$scope.slicedStatesArry = $scope.currentStatesArray[currentindex].splice(0, 10);
			}
		}
		$scope.filterStateBySearchText = function (searchtext, currentindex) {
			$scope.slicedStatesArry = [];
			$scope.currentStatesArray[currentindex].filter(function (state) {
				if (searchtext) {
					if (state.name.toLowerCase().indexOf(searchtext) == -1) {
						state.hide = true
					}
					else {
						if ($scope.slicedStatesArry.indexOf(state) == -1) {
							$scope.slicedStatesArry.push(state);
							state.hide = false;
						}
					}
				} else {
					if ($scope.slicedStatesArry.indexOf(state) == -1) {
						$scope.slicedStatesArry.push(state);
						state.hide = false;
					}
				}
			});
			$scope.slicedStatesArry = $scope.slicedStatesArry.slice(0, 10);
			var addIconArrayCheck = $scope.currentStatesArray[currentindex].filter(function (cat) { return !cat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}
		$scope.searchByCities = function (event, currentindex) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterCitiesBySearchText(searchtext, currentindex);
			$scope.searchCityTextAry[currentindex] = searchtext;
		}
		$scope.searchByState = function (event, currentindex) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterStateBySearchText(searchtext, currentindex);
			$scope.searchStateTextAry[currentindex] = searchtext;
		}
		$scope.toggleState = function (event, currentindex, subitems) {
			if (!event.checked)
				$scope.clearStatesFilter(currentindex, subitems)
		}
		$scope.toggleCity = function (event, currentindex, subitems) {
			if (!event.checked)
				$scope.clearCitiesFilter(currentindex, subitems)
		}
		$scope.filterCitiesBySearchText = function (searchtext, currentindex) {
			$scope.slicedCitiesArry = [];
			$scope.currentCitiesArray[currentindex].filter(function (city) {
				if (searchtext) {
					if (city.name && city.name.toLowerCase().indexOf(searchtext) == -1) {
						city.hide = true
					}
					else {
						if ($scope.slicedCitiesArry.indexOf(city) == -1) {
							$scope.slicedCitiesArry.push(city)
							city.hide = false;
						}
					}
				} else {
					if ($scope.slicedCitiesArry.indexOf(city) == -1) {
						$scope.slicedCitiesArry.push(city)
						city.hide = false;
					}
				}
			});
			$scope.slicedCitiesArry = $scope.slicedCitiesArry.slice(0, 10);
			var addIconArrayCheck = $scope.currentCitiesArray[currentindex].filter(function (cat) { return !cat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}
		$scope.clearCitiesFilter = function (index, subitems) {
			if (subitems) {
				subitems.value = '';
			}
			for (var i = 0; i < $scope.selectedCitiesArray.length; i++) {
				var element = $scope.selectedCitiesArray[i];
				element.active = false;
			}
			$scope.currentCitiesArray[index] && $scope.currentCitiesArray[index].sort(function (a, b) {
				if (a.cityName < b.cityName) return -1;
				else if (a.cityName > b.cityName) return 1;
				return 0;
			});
			$scope.selectedCitiesArray = [];
			$scope.cityTitleArry[index] = "";
		}
		$scope.setStateForSelectedCountry = function (selectedState, currentindex, from, uopItems, postcodeCity, fromOnchange, fieldName) {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/uop/getStateByCountry?id=' + selectedState,
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				withCredentials: true
			}).then(function (response) {
				var isStateNull = false;
				var selectedStateTemp = '';
				if (response.data) {
					var array = [], dropObj = $scope.customizeJson.dropdownObj['state'];
					if (dropObj) {
						for (var index = 0, item, objOption; index < response.data.length; index++) {
							item = response.data[index];
							objOption = {
								value: String(item[dropObj.id]),
								name: item[dropObj.name],
								language_key: item[dropObj.language_key],
								parentId: item[dropObj.parent],
								hasChild: dropObj.hasChild || false,
								regionCode: item[dropObj.regionCode]
							}
							array.push(objOption);
						}
					}
					$scope.currentStatesArray[currentindex] = Object.assign([], array);
					$scope.slicedStatesArry = array.slice(0, 10)
					var isStateNull = false;
					var isCallState = false;
					if (!$scope.selectedState[currentindex] && $scope.currentStatesArray[currentindex] && $scope.currentStatesArray[currentindex].length) {
						isStateNull = true;
						$scope.selectedState[currentindex] = $scope.currentStatesArray[currentindex][0];
					}
					if ($scope.selectedState[currentindex] != '' && $scope.currentStatesArray[currentindex] != undefined) {
						$scope.currentStatesArray[currentindex].filter(function (state) { return $scope.selectedState[currentindex] == state.value })
							.forEach(function (state) {
								state.active = false;
								state.hide = false;
								isCallState = true;
								if (isStateNull) {
									//setTimeout(() => {
									$scope.selectState(state, currentindex, '', uopItems, fieldName);
									//}, 1000);
								}
								else {
									$scope.selectState(state, currentindex, '', uopItems, fieldName);
								}

							})
						if (!isCallState) {
							$scope.selectState($scope.currentStatesArray[currentindex][0], currentindex, '', uopItems, fieldName, '', true);
						}
					}
				}
			}, function () {

			});
		}
		$scope.selectCategoryCode = function (code, subitems, uopItems, from) {			
			$scope.clearCategoryCodeFilter()
			if ($scope.searchTextEnabled) {
				$scope.currentCategoryCodeArray.forEach(function (code) {
					code.hide = false;
				});
				$scope.searchTextEnabled = false;
			}
			var codeTitle = [],
				arryCode = $scope.currentCategoryCodeArray;

			code.active = !code.active;

			for (var index = 0; index < arryCode.length; index++) {
				if (arryCode[index].active) {
					$scope.selectedCategoryCodeArray = [];
					$scope.selectedCategoryCodeArray.push(arryCode[index]);
				}
			}
			for (var i = 0; i < $scope.selectedCategoryCodeArray.length; i++) {
				var element = $scope.selectedCategoryCodeArray[i];
				if (!element.active) {
				} else {
					codeTitle.push(element.name);
				}
			}
			$scope.CategoryTitleArry = $scope.selectedCategoryCodeArray[0].name;

			if ($scope.selectedCategoryCodeArray[0].value) {
				$scope.setCategoryListForSelectedCatCode($scope.selectedCategoryCodeArray[0].value, subitems, from, uopItems)
			}

			if (subitems && from != 'industrycodetype') {
				subitems.value = $scope.selectedCategoryCodeArray[0].value;

				//this.onChangeDropdown(subitems, uopItems);
			}
		}
		$scope.setCategoryListForSelectedCatCode = function (selectedCatCode, subitems, from, uopItems) {
			if (!$scope.industryCodeTypeListMapping[selectedCatCode]) {
				$scope.industryCodeTypeListMapping[selectedCatCode] = {};
			}

			var cachedData = $scope.industryCodeTypeListMapping[selectedCatCode];
			if (cachedData.status == 'completed') {
				$scope.setSelectedListData(selectedCatCode, subitems, from, uopItems);
			} else if (cachedData.status == 'pending') {
				cachedData.arg.push({ executed: false, arg: [selectedCatCode, subitems, from, uopItems] });
			} else if (!cachedData.status) {
				if (!cachedData.arg) {
					cachedData.arg = [{ executed: false, arg: [selectedCatCode, subitems, from, uopItems] }];
				} else {
					cachedData.arg.push({ executed: false, arg: [selectedCatCode, subitems, from, uopItems] })
				}
				cachedData.status = 'pending';
				//this.totalLengthOfCategoryCode++;
				$scope.makeAjaxForList(selectedCatCode, subitems, from, uopItems)
			}
		}
		$scope.makeAjaxForList = function (selectedCatCode, subitems, from, uopItems) {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/uop/getIndustryCodeList?codeId=4',
				method: 'GET',
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				withCredentials: true
			}).then(function (response) {
				if (response.data) {
					var cachedData = $scope.industryCodeTypeListMapping[selectedCatCode];
					cachedData.status = 'completed';
					//this.totalLengthOfCategoryCode--;
					cachedData.list = response.data;
					for (var i = 0; i < cachedData.arg.length; i++) {
						var element = cachedData.arg[i];
						if (!element.executed) {
							element.executed = true;
							$scope.setSelectedListData.apply(this, cachedData.arg[i].arg);
						}
					}
				}
			}, function () {

			});
		}
		$scope.setSelectedListData = function (selectedCatCode, subitems, from, uopItems) {
			$scope.categoryList = JSON.parse(JSON.stringify($scope.industryCodeTypeListMapping[selectedCatCode].list));
			$scope.currentCatlistArray = Object.assign([], $scope.categoryList);

			var catListAry;
			if (uopItems && uopItems.length) {
				for (var i = 0; i < uopItems.length; i++) {
					if (uopItems[i].fieldId == 474) {
						catListAry = uopItems[i];
						subitems = catListAry;
					}
				}
			}
			if ($scope.categoryList.length) {
				var catListIndex = $scope.selectedCatListIndex[0] || 0;
				if (from == "onselect")
					catListIndex = 0;

				if (catListIndex) {
					$scope.categoryList.filter(function (catList) { return catListIndex.indexOf(catList.industryTypeId) != -1 })
						.forEach(function (catList) {
							catList.active = false;
							catList.hide = false;

							if (catListAry) {
								catListAry.displayValue.value = catList.industryTypeId;
								catListAry.displayValue.name = catList.name;
							}

							$scope.selectCategoryList(catList, subitems, catListAry);
						})
				}
				else {
					if (catListAry) {
						catListAry.displayValue = {
							value: $scope.categoryList[0].industryTypeId,
							name: $scope.categoryList[0].name
						}
					}
					$scope.selectCategoryList($scope.categoryList[0], subitems, catListAry);
				}

				if ($scope.categoryList && $scope.categoryList.length) {
					$scope.slicedCategoryListArry = $scope.categoryList.slice(0, 10)
				}
			}
		}
		$scope.selectCategoryList = function (listData, subitems, uopItems) {
			$scope.selectedCatListArray = [];
			$scope.catListTitleArry = [];
			$scope.catListTitle = [];
			$scope.displayCatListTitle = '';
			var selectedTitle = '';
			var industryTypeId = [];
			if ($scope.searchTextEnabled) {
				$scope.currentCatlistArray.forEach(function (list) {
					list.hide = false;
				});
				$scope.searchTextEnabled = false;
			}
			var listTitle = [],
				arryList = $scope.currentCatlistArray;

			listData.active = !listData.active;

			for (var index = 0; index < arryList.length; index++) {
				if (arryList[index].active) {
					//this.selectedCatListArray = [];
					$scope.selectedCatListArray.push(arryList[index]);

				}
			}
			for (var i = 0; i < $scope.selectedCatListArray.length; i++) {
				var element = $scope.selectedCatListArray[i];
				if (!element.active) {
					$scope.selectedCatListArray.splice(i, 1);
				} else {
					listTitle.push(element.name);
				}
				$scope.catListTitleArry.push(element);
				$scope.catListTitle.push(element.name);
				industryTypeId.push(element.industryTypeId);
			}
			$scope.displayCatListTitle = $scope.catListTitle.join(' | ')
			if (subitems) {
				subitems.value = industryTypeId.join(',');
			}
		}
		$scope.clearCategoryCodeFilter = function () {
			$scope.currentCategoryCodeArray = Object.assign([], $scope.categoryCode);

			for (var i = 0; i < $scope.selectedCategoryCodeArray.length; i++) {
				var element = $scope.selectedCategoryCodeArray[i];
				element.active = false;
				//this.currentCategoryCodeArray[index].push(element);
			}

			// this.currentCategoryCodeArray[index].sort((a, b) => {
			//   if (a.name < b.name) return -1;
			//   else if (a.name > b.name) return 1;
			//   return 0;
			// });
			$scope.selectedCategoryCodeArray = [];
			$scope.CategoryTitleArry = "";
		}
		$scope.toggleCategoryCode = function (event) {
			if (!event.checked)
				$scope.clearCategoryCodeFilter()
		}
		$scope.resetCategoryCodeAry = function () {
			if ($scope.searchCategoryCodeTextAry != "") {
				$scope.filterCategoryCodeBySearchText($scope.searchCategoryCodeTextAry)
			}
			else {
				$scope.slicedCategoryCodesArry = $scope.currentCategoryCodeArray.splice(0, 10);
			}
		}
		$scope.resetCatListAry = function () {
			if ($scope.searchCatListTextAry != "") {
				$scope.filterCategoryListBySearchText($scope.searchCatListTextAry)
			}
			else {
				$scope.slicedCategoryListArry = $scope.slicedCategoryListArry.splice(0, 10);
			}
		}
		$scope.searchByCategoryCode = function (event) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterCategoryCodeBySearchText(searchtext);
			$scope.searchCategoryCodeTextAry = searchtext;
		}
		$scope.searchByCategoryList = function (event) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterCategoryListBySearchText(searchtext);
			$scope.searchCatListTextAry = searchtext;
		}
		$scope.filterCategoryListBySearchText = function (searchtext) {
			$scope.slicedCategoryListArry = [];
			$scope.currentCatlistArray.filter(function (list) {
				if (searchtext) {
					$scope.enableShowMore = true;
					$scope.countOfShowMore = 10;
					var codeName = list.code.toLowerCase() + ' ' + list.name.toLowerCase();
					if (codeName.indexOf(searchtext) == -1) {
						list.hide = true
					}
					else {
						if ($scope.slicedCategoryListArry.indexOf(list) == -1) {
							$scope.slicedCategoryListArry.push(list)
							list.hide = false;
						}
					}
					if ($scope.slicedCategoryListArry.length <= 10) {
						this.enableShowMore = false;
					}
				} else {
					$scope.enableShowMore = false;
					$scope.countOfShowMore = 0;
					if ($scope.slicedCategoryListArry.indexOf(list) == -1) {
						$scope.slicedCategoryListArry.push(list)
						list.hide = false;
					}
				}
			});
			$scope.slicedCategoryListArryTemp = $scope.slicedCategoryListArry;
			$scope.slicedCategoryListArry = $scope.slicedCategoryListArry.slice(0, 10);
			var addIconArrayCheck = $scope.currentCatlistArray.filter(function (listCat) { return !listCat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}
		$scope.filterCategoryCodeBySearchText = function (searchtext) {
			$scope.slicedCategoryCodesArry = [];
			$scope.currentCategoryCodeArray.filter(function (state) {
				if (searchtext) {
					if (state.name.toLowerCase().indexOf(searchtext) == -1) {
						state.hide = true
					} else {
						if ($scope.slicedCategoryCodesArry.indexOf(state) == -1) {
							$scope.slicedCategoryCodesArry.push(state);
							state.hide = false;
						}
					}
				} else {
					if ($scope.slicedCategoryCodesArry.indexOf(state) == -1) {
						$scope.slicedCategoryCodesArry.push(state);
						state.hide = false;
					}
				}
			});
			$scope.slicedCategoryCodesArry = $scope.slicedCategoryCodesArry.slice(0, 10);
			var addIconArrayCheck = $scope.currentCategoryCodeArray.filter(function (cat) { return !cat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}
		$scope.clearCatListFilter = function (subitems) {
			if (subitems) {
				subitems.value = '';
			}
			for (var i = 0; i < $scope.selectedCatListArray.length; i++) {
				var element = $scope.selectedCatListArray[i];
				element.active = false;
			}
			// this.currentCatlistArray[index] && this.currentCatlistArray[index].sort((a, b) => {
			//   if (a.name < b.name) return -1;
			//   else if (a.name > b.name) return 1;
			//   return 0;
			// });
			$scope.selectedCatListArray = [];
			$scope.catListTitleArry = [];
			$scope.catListTitle = [];
			$scope.displayCatListTitle = '';
		}
		$scope.selectRegionOfWorkCompany = function (company, subitems, uopItems) {
			var title = [],
				arryCategory = $scope.regionOfWork;

			//company.active = !company.active;
			for (var index = 0; index < arryCategory.length; index++) {
				if (arryCategory[index].active) {
					$scope.selectedRegionOfWorkArray.push(arryCategory[index]);
					$scope.regionOfWork.splice(index, 1);
				}
			}
			for (var i = 0; i < $scope.selectedRegionOfWorkArray.length; i++) {
				var element = $scope.selectedRegionOfWorkArray[i];
				if (!element.active) {
					$scope.regionOfWork.push(element);
					$scope.selectedRegionOfWorkArray.splice(i, 1);
				} else {
					title.push(element.value);
				}
			}
			if (!company.active) {
				$scope.regionOfWork.sort(function (a, b) {
					if (a.name < b.name) return -1;
					else if (a.name > b.name) return 1;
					return 0;
				});
			}
			$scope.regionOfWorkTitle = $scope.selectedRegionOfWorkArray.map(function (category) { category.name }).join(',');
			$scope.regionTitle = title.join(',');
			if (subitems) {
				subitems.value = $scope.regionTitle;
			}

		}

		$scope.selectSectorExperience = function (company, subitems, uopItems) {
			var title = [],
				arryCategory = $scope.sectorExperience;

			//company.active = !company.active;
			for (var index = 0; index < arryCategory.length; index++) {
				if (arryCategory[index].active) {
					$scope.selectedSectorExperience.push(arryCategory[index]);
					$scope.sectorExperience.splice(index, 1);
				}
			}
			for (var i = 0; i < $scope.selectedSectorExperience.length; i++) {
				var element = $scope.selectedSectorExperience[i];
				if (!element.active) {
					$scope.sectorExperience.push(element);
					$scope.selectedSectorExperience.splice(i, 1);
				} else {
					title.push(element.value);
				}
			}
			if (!company.active) {
				$scope.sectorExperience.sort(function (a, b) {
					if (a.name < b.name) return -1;
					else if (a.name > b.name) return 1;
					return 0;
				});
			}
			$scope.sectorExperienceTitle = $scope.selectedSectorExperience.map(function (category) { category.name }).join(',');
			$scope.sectorTitle = title.join(',');
			if (subitems) {
				subitems.value = $scope.sectorTitle;
			}

		}
		$scope.searchByRegionOfWork = function (event) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterRegionOfWorkBySearchText(searchtext);
		}
		$scope.searchBySectorExperience = function (event) {
			var searchtext;
			if (event.keyCode == 40 || event.keyCode == 38) {
				return;
			}
			searchtext = event.target.value.trim().toLowerCase();
			$scope.filterSectorExperienceBySearchText(searchtext);
		}
		$scope.filterRegionOfWorkBySearchText = function (searchtext) {
			$scope.regionOfWork.filter(function (company) {
				if (searchtext) {
					(company.name.toLowerCase().indexOf(searchtext) == -1) && (company.hide = true);
					if (company.name.toLowerCase() == "other") company.hide = false;
				} else {
					company.hide = false;
				}
			});
			var addIconArrayCheck = $scope.regionOfWork.filter(function (cat) { return !cat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}

		$scope.filterSectorExperienceBySearchText = function (searchtext) {
			$scope.sectorExperience.filter(function (company) {
				if (searchtext) {
					(company.name.toLowerCase().indexOf(searchtext) == -1) && (company.hide = true);
					if (company.name.toLowerCase() == "other") company.hide = false;
				} else {
					company.hide = false;
				}
			});
			var addIconArrayCheck = $scope.sectorExperience.filter(function (cat) { return !cat.hide });
			if (addIconArrayCheck.length == 0) {

				$scope.typedtext = searchtext;
			} else {

			}
			$scope.searchTextEnabled = true;
		}
		$scope.clearRegionsofWorkFilter = function (subitems) {
			if (subitems) {
				subitems.value = '';
			}
			for (var i = 0; i < $scope.selectedRegionOfWorkArray.length; i++) {
				var element = $scope.selectedRegionOfWorkArray[i];
				element.active = false;
				$scope.regionOfWork.push(element);
			}
			$scope.regionOfWork.sort(function (a, b) {
				if (a.name < b.name) return -1;
				else if (a.name > b.name) return 1;
				return 0;
			});
			$scope.selectedRegionOfWorkArray = [];
			$scope.regionOfWorkTitle = '';
		}

		$scope.clearSectorExperience = function (subitems) {
			if (subitems) {
				subitems.value = '';
			}
			for (var i = 0; i < $scope.selectedSectorExperience.length; i++) {
				var element = $scope.selectedSectorExperience[i];
				element.active = false;
				$scope.sectorExperience.push(element);
			}
			$scope.sectorExperience.sort(function (a, b) {
				if (a.name < b.name) return -1;
				else if (a.name > b.name) return 1;
				return 0;
			});
			$scope.selectedSectorExperience = [];
			$scope.sectorExperienceTitle = '';
		}
		$scope.selectSection = function (section) {
			$scope.currentCategoryItem = section.id;
			if (section.data[0]) {
				$scope.currentSubItem = section.data[0].id;
				$scope.currentSubItemData = section.data[0];
			}
			$scope.toggle();
		}
		$scope.selectSubItem = function (subsections) {
			if (currentViewName == "ORI_VIEW") {
				setContentOfAttachment();
			}
			$scope.currentSubItem = subsections.id;
			$scope.currentSubItemData = subsections;
		}

		var setContentOfAttachment = function () {
			var inlineAttachment = $("input[name$='Asite']");
			if (inlineAttachment.length > 0) {
				for (var i = 0; i < $scope.currentSubItemData.data.length; i++) {
					if ($scope.currentSubItemData.data[i].fieldTypeId == "7") {
						for (var j = 0; j < inlineAttachment.length; j++) {
							if (inlineAttachment[j].id == $scope.currentSubItemData.data[i].value["@inline"]) {
								$scope.currentSubItemData.data[i].value.content = "12" + inlineAttachment[j].value.split(':/')[1];
							}
						}

					} else if ($scope.currentSubItemData.data[i].fieldTypeId == "8") {
						if ($scope.currentSubItemData.data[i].value) {
							for (var j = 0; j < $scope.currentSubItemData.data[i].value.length; j++) {
								for (var k = 0; k < $scope.currentSubItemData.data[i].value[j].length; k++) {
									if ($scope.currentSubItemData.data[i].value[j][k].fieldTypeId == "7") {
										for (var l = 0; l < inlineAttachment.length; l++) {
											if ($scope.currentSubItemData.data[i].value[j][k].value && inlineAttachment[l].id == $scope.currentSubItemData.data[i].value[j][k].value["@inline"]) {
												$scope.currentSubItemData.data[i].value[j][k].value.content = "12" + inlineAttachment[l].value.split(':/')[1];
											}
										}
									}
								}
							}
						}

					}
				}
			}
		}

		$scope.toggle = function () {
			$scope.isToggle = !$scope.isToggle;
		}
		$scope.nextSection = function (currentId) {
			$scope.currentSubItem = currentId.id + 1;
		}
		$scope.isOverflow = function () {
			var element = document.getElementById('subsection-nav');
			if (element) {
				$scope.hideNavBar = element.offsetHeight < element.scrollHeight || element.offsetWidth < element.scrollWidth;
			}
		}
		$scope.onChangeDropdown = function (param, uopArray, event, currentindex, onChange, onLoad) {
			if (param.fieldId == 221) {
				$scope.CountryId[currentindex] = param.value;
				if (param.value == '18') {
					uopArray[4].label = "County";
					$scope.setCitiesForSelectedState(param.value, currentindex, '', uopArray, '', onChange, 'country');
				} else {
					uopArray[4].label = "State";
				}
				$scope.setStateForSelectedCountry(param.value, currentindex, '', uopArray, '', true, 'country');
			}
		}
		$scope.rightnav = function (navid) {
			$(navid).animate({ scrollLeft: '+=80' }, 'fast');
		}

		$scope.leftnav = function (navid) {
			$(navid).animate({ scrollLeft: '-=80' }, 'fast');
		}
		$scope.repeatingItemsRemove = function (index, array) {
			if (array.fieldId == 222) {
				$scope.CategoryTitleArry = "";
				$scope.catListTitleArry = [];
				$scope.catListTitle = [];
				$scope.displayCatListTitle = "";
			}
			if (array.fieldId == 4) {
				$scope.cityTitleArry[index] = "";
				$scope.stateTitleArry[index] = "";
			}
			array.value.splice(index, 1);
			$scope.setDefaultPrimaryAddress(array);
			//array.splice(index, 1);
		}
		$scope.repeatingItemsAdd = function (array) {
			var addItem = angular.fromJson(angular.toJson(array.header));
			for (var key in addItem) {
				if (addItem.hasOwnProperty(key)) {
					if (addItem[key].fieldTypeId == 7) {
						addItem[key]['value'] = {};
					}
					else if (addItem[key].fieldId == 7 && addItem[key]['displayValue']) {
						addItem[key]['displayValue'] = {};
						addItem[key]['value'] = "";
					}
					else {
						addItem[key]['value'] = "";
					}
				}
			}
			array.value.push(addItem);
			if (array.value && array.value.length > 1) {
				for (var a = 0; a < array.value.length; a++) {
					if (a > 0) {
						for (var j = 0; j < array.value[a].length; j++) {
							if (array.value[a][j].fieldId == 473) {
								$scope.clearCategoryCodeFilter(array.value.length - 1)
							}
							if (array.value[a][j].fieldId == 7) {
								$scope.clearCitiesFilter(array.value.length - 1)
							}
							if (array.value[a][j].fieldId == 8) {
								$scope.clearStatesFilter(array.value.length - 1)
							}
							if (array.value[a][j].fieldId == 272) {
								$scope.clearStatesFilter(array.value.length - 1)
							}
							if (array.value[a][j].fieldId == 474) {
								$scope.clearCatListFilter(array.value.length - 1)
							}
						}
					}
				}
			}
		}
		$scope.setDefaultPrimaryAddress = function (data) {
			if (data.fieldId == 4) {
				var defaultAddressSet = false;
				for (var v = 0, array = data.value || []; v < array.length; v++) {
					for (var j = 0, array1 = array[v] || []; j < array1.length; j++) {
						if (array1[j].fieldId == 232 && array1[j].value) {
							array1[j].value === true && (defaultAddressSet = true);
						}
					}
				}
				if (!defaultAddressSet) {
					for (var v = 0, array = data.value || []; v < 1; v++) {
						for (var j = 0, array1 = array[v] || []; j < array1.length; j++) {
							if (array1[j].fieldId == 232) {
								array1[j].value = true;
							}
						}
					}
				}
			}
			if (data.fieldId == 477) {
				var defaultAddressSet = false;
				for (var v = 0, array = data.value || []; v < array.length; v++) {
					for (var j = 0, array1 = array[v] || []; j < array1.length; j++) {
						if (array1[j].fieldId == 271 && array1[j].value) {
							array1[j].value === true && (defaultAddressSet = true);
						}
					}
				}
				if (!defaultAddressSet) {
					for (var v = 0, array = data.value || []; v < 1; v++) {
						for (var j = 0, array1 = array[v] || []; j < array1.length; j++) {
							if (array1[j].fieldId == 271) {
								array1[j].value = true;
							}
						}
					}
				}
			}
		}
		$scope.activeSubSection = function (subsections) {
			$scope.currentSubItem = subsections.id;
		}
		$scope.onFileChange = function (event, item) {
			item.value = event.srcElement.files[0].name;
		}
		$scope.cancel = function () {
			$window.top.postMessage("closeCreateFormIframe:-1",'*');
		}
		$scope.onChangeEvent = function (event, param, array, allItems) {
			$scope.onBlurMethod(event,param);
			if (allItems && param.fieldId == 232) {
				$scope.setPrimaryAddress(event, param, allItems);
			}
			if (allItems && param.fieldId == 271) {
				$scope.setPrimaryContact(event, param, allItems);
			}
			$scope.filterOptions(param, array);
			if (param.fieldId == "222" && param.value.indexOf("67") != -1) {
				for (var o = 0; o < $scope.categoryofwork[0].options.length; o++) {
					if ($scope.categoryofwork[0].options[o].modelValue != "67")
						$scope.categoryofwork[0].options[o].checked = false;
				}

				this.subitems.value = ["67"];
				for (var a = 0; a < array.length; a++) {
					if (array[a].fieldId == "223") {
						array[a].hide = true;
					}
					else if (array[a].fieldId == "265") {
						array[a].hide = false;
					}
				}
				$scope.hideSubCategoryOfWork = true;
			}
		}
		$scope.setPrimaryAddress = function (event, param, allItems) {
			for (var index = 0, array = document.querySelectorAll("#primaryAddress"); index < array.length; index++) {
				array[index].getElementsByTagName('input')[0].checked = false;
			}
			for (var i = 0; i < allItems.length; i++) {
				for (var j = 0; j < allItems[i].length; j++) {
					if (allItems[i][j].fieldId == 232) {
						allItems[i][j].value = false;
					}
				}
			}
			event.target.checked = true;
			param.value = true;
		}

		$scope.setPrimaryContact = function (event, param, allItems) {
			for (var index = 0, array = document.querySelectorAll("#primaryAddress"); index < array.length; index++) {
				array[index].getElementsByTagName('input')[0].checked = false;
			}
			for (var i = 0; i < allItems.length; i++) {
				for (var j = 0; j < allItems[i].length; j++) {
					if (allItems[i][j].fieldId == 271) {
						allItems[i][j].value = false;
					}
				}
			}
			event.target.checked = true;
			param.value = true;
		}
		$scope.onBlurMethod = function (event, field, index) {
			var array = [], vilidateObj = {}; var selCountry = '';
			if (field.fieldId == 1) {
				$scope.companyName = field.value;
			}
			if (field.fieldId == 9) {
				$scope.zip = field.value;
				selCountry = $scope.selCountryIds[index];
			}
			if (field.validationTypeId) {
				array.push(returnValidationobj(field, 1));
				vilidateObj[field.fieldId + "" + 1] = field;
				var countryObj = angular.element('#country')[0];

				makeAjaxCallForValidation({
					validationArray: array,
					subsection: [field],
					vilidateObj: vilidateObj,
					submit: false,
					selCountry: selCountry,
					IsSetCityState: false,
					uopIndex: index
				});
			}
		}
		var makeAjaxCallForValidation = function (paramObj) {
			if (paramObj.validationArray) {
				for (var i = 0; i < paramObj.validationArray.length; i++) {
					if (paramObj.validationArray[i].fieldName === "abn") {
						paramObj.validationArray[i].value = paramObj.validationArray[i].value.replace(/ /g, '');
					}
					if (paramObj.validationArray[i].fieldName === "zip") {
						if(paramObj.selCountry){
							paramObj.validationArray[i].value = paramObj.validationArray[i].value + '#' + paramObj.selCountry;
						}else{
							var selCountry = paramObj.validationArray.filter(function (item) { 
								return item.rowId === paramObj.validationArray[i].rowId && (item.fieldId === 221 || item.fieldId === "221");
							})
							paramObj.validationArray[i].value = paramObj.validationArray[i].value + '#' + selCountry[0].value;
						}
						
					}
					if (paramObj.validationArray[i].fieldName === "keyContactEmail") {
						if(paramObj.validationArray[i].value == "")
						paramObj.validationArray[i].value = "#true"
					}
				}
			}
			var isValidform = true;
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/uop/validate",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(paramObj.validationArray)
			}).then(function (response) {
				if (response.data) {
					var param = response.data;
					var moveSection = true;
					for (var index = 0; index < param.length; index++) {
						var id = param[index].fieldId + "" + param[index].rowId;
						if (param[index].fieldName == "abn" && param[index].statusCode == "PARTIAL_MATCH") {
							var result = JSON.parse(param[index].result);
							var stateCode = $scope.customizeJson.datasource.state.filter(function (item) { return item.regionCode === result.AddressState });
							if (stateCode.length) {
								result.AddressStateOj = stateCode[0];
							}
							var EntityType = $scope.customizeJson.datasource.entityType.filter(function (item) { return item.name === result.EntityTypeName });
							if (EntityType.length) {
								result.EntityTypeObj = EntityType[0];
							}
							for (var i = 0; i < $scope.data.uopData.length; i++) {
								for (var j = 0; j < $scope.data.uopData[i].data.length; j++) {
									for (var k = 0; k < $scope.data.uopData[i].data[j].data.length; k++) {
										if ($scope.data.uopData[i].data[j].data[k].fieldId == "1") {
											$scope.data.uopData[i].data[j].data[k].value = result.EntityName;
										}
										if ($scope.data.uopData[i].data[j].data[k].fieldId == "17") {
											$scope.data.uopData[i].data[j].data[k].value = result.EntityTypeObj.value;
										}
										if ($scope.data.uopData[i].data[j].data[k].fieldId == "4") {
											for (var l = 0; l < $scope.data.uopData[i].data[j].data[k].value.length; l++) {
												for (var m = 0; m < $scope.data.uopData[i].data[j].data[k].value[l].length; m++) {
													if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == "9") {
														$scope.data.uopData[i].data[j].data[k].value[l][m].value = result.AddressPostcode;
														$scope.zip = result.AddressPostcode;
													}
													if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == "8") {
														$scope.data.uopData[i].data[j].data[k].value[l][m].value = result.AddressStateOj.value;
													}
												}
											}
										}
									}
								}
							}
							$scope.companyName = result.EntityName;
						}
						if (param[index].fieldName == "zip" && param[index].statusCode == "PARTIAL_MATCH") {
							var result = JSON.parse(param[index].result);
							for (var i = 0; i < $scope.data.uopData.length; i++) {
								for (var j = 0; j < $scope.data.uopData[i].data.length; j++) {
									for (var k = 0; k < $scope.data.uopData[i].data[j].data.length; k++) {
										if ($scope.data.uopData[i].data[j].data[k].fieldId == "4") {
											if (paramObj.uopIndex != undefined) {
												for (var m = 0; m < $scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex].length; m++) {
													if ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].fieldId == "9") {
														$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value = $scope.zip;
													}
													if ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].fieldId == "8") {
														var stateObj = $scope.getState(result[0].State, $scope.currentStatesArray[paramObj.uopIndex]);
														if (stateObj[0]) {
															stateObj[0].active = false;
														}
														if (paramObj.IsSetCityState) {
															var name = $scope.CountryId[paramObj.uopIndex] != '18' ? 'Zipcode and state are not match' : 'Postcode and county are not match';
															if (stateObj[0] && ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value != stateObj[0].value)) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = name;
															}
															if (!stateObj[0] && result[0].zip) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = name
															}
														} else {
															var fromName = $scope.customizeJson.datasource.state ? 'state' : 'onselect';
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value = stateObj[0] ? stateObj[0].value : '';
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].displayValue = stateObj[0];
															$scope.selectState(stateObj[0], paramObj.uopIndex, $scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m], $scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex], fromName, result[0].City, true, true);
														}
													}
													if ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].fieldId == 7 && ($scope.CountryId[paramObj.uopIndex] != '18')) {
														var cityObj = $scope.getCity(result[0].City, $scope.currentCitiesArray[paramObj.uopIndex]);
														if (cityObj[0]) {
															cityObj[0].active = false;
														}
														if (paramObj.IsSetCityState) {
															if (cityObj[0] && ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value != cityObj[0].value)) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = 'Zipcode do not match selected city.';
															}
															if (!cityObj[0] && result[0].zip) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = 'Zipcode do not match selected city.';
															}
														} else {
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value = cityObj[0] ? cityObj[0].value : '';
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].displayValue = cityObj[0];
															//this.selectCity(cityObj[0],0,uopData[currentI][j],paramObj.uopItems)
														}
													}
													if ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].fieldId == 7 && ($scope.CountryId[paramObj.uopIndex] == '18')) {
														var cityObj = $scope.getCity(result[0].City, $scope.currentCitiesArray[paramObj.uopIndex]);
														if (cityObj[0]) {
															cityObj[0].active = false;
														}
														if (paramObj.IsSetCityState) {
															if (cityObj[0] && ($scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value != cityObj[0].value)) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = 'Postcode do not match selected city.';
															}
															if (!cityObj[0] && result[0].zip) {
																$scope.clickSave = false;
																$scope.clickSaveDraft = false;
																isValidform = false;
																paramObj.vilidateObj[id].invalid = true;
																paramObj.vilidateObj[id].message = 'Postcode do not match selected city.';
															}
														} else {
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].value = cityObj[0] ? cityObj[0].value : '';
															$scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m].displayValue = cityObj[0];
															this.selectCity(cityObj[0], selectedCurrentIndex, $scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex][m], $scope.data.uopData[i].data[j].data[k].value[paramObj.uopIndex])
														}
													}
												}
											} else {
												for (var l = 0; l < $scope.data.uopData[i].data[j].data[k].value.length; l++) {
													for (var m = 0; m < $scope.data.uopData[i].data[j].data[k].value[l].length; m++) {
														if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == "9") {
															$scope.data.uopData[i].data[j].data[k].value[l][m].value = $scope.zip;
														}
														if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == "8") {
															var stateObj = $scope.getState(result[0].State, $scope.currentStatesArray[l]);
															if (stateObj[0]) {
																stateObj[0].active = false;
															}
															if (paramObj.IsSetCityState) {
																var name = $scope.CountryId[l] != '18' ? 'Zipcode and state are not match' : 'Postcode and county are not match';
																if (stateObj[0] && ($scope.data.uopData[i].data[j].data[k].value[l][m].value != stateObj[0].value)) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = name;
																}
																if (!stateObj[0] && result[0].zip) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = name
																}
															} else {
																var fromName = $scope.customizeJson.datasource.state ? 'state' : 'onselect';
																$scope.data.uopData[i].data[j].data[k].value[l][m].value = stateObj[0] ? stateObj[0].value : '';
																$scope.data.uopData[i].data[j].data[k].value[l][m].displayValue = stateObj[0];
																$scope.selectState(stateObj[0], l, $scope.data.uopData[i].data[j].data[k].value[l][m], $scope.data.uopData[i].data[j].data[k].value[l], fromName, result[0].City, true, true);
															}
														}
														if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == 7 && ($scope.CountryId[l] != '18')) {
															var cityObj = $scope.getCity(result[0].City, $scope.currentCitiesArray[l]);
															if (cityObj[0]) {
																cityObj[0].active = false;
															}
															if (paramObj.IsSetCityState) {
																if (cityObj[0] && ($scope.data.uopData[i].data[j].data[k].value[l][m].value != cityObj[0].value)) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = 'Zipcode do not match selected city.';
																}
																if (!cityObj[0] && result[0].zip) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = 'Zipcode do not match selected city.';
																}
															} else {
																$scope.data.uopData[i].data[j].data[k].value[l][m].value = cityObj[0] ? cityObj[0].value : '';
																$scope.data.uopData[i].data[j].data[k].value[l][m].displayValue = cityObj[0];
																//this.selectCity(cityObj[0],0,uopData[currentI][j],paramObj.uopItems)
															}
														}
														if ($scope.data.uopData[i].data[j].data[k].value[l][m].fieldId == 7 && ($scope.CountryId[l] == '18')) {
															var cityObj = $scope.getCity(result[0].City, $scope.currentCitiesArray[l]);
															if (cityObj[0]) {
																cityObj[0].active = false;
															}
															if (paramObj.IsSetCityState) {
																if (cityObj[0] && ($scope.data.uopData[i].data[j].data[k].value[l][m].value != cityObj[0].value)) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = 'Postcode do not match selected city.';
																}
																if (!cityObj[0] && result[0].zip) {
																	$scope.clickSave = false;
																	$scope.clickSaveDraft = false;
																	isValidform = false;
																	paramObj.vilidateObj[id].invalid = true;
																	paramObj.vilidateObj[id].message = 'Postcode do not match selected city.';
																}
															} else {
																$scope.data.uopData[i].data[j].data[k].value[l][m].value = cityObj[0] ? cityObj[0].value : '';
																$scope.data.uopData[i].data[j].data[k].value[l][m].displayValue = cityObj[0];
																this.selectCity(cityObj[0], selectedCurrentIndex, $scope.data.uopData[i].data[j].data[k].value[l][m], $scope.data.uopData[i].data[j].data[k].value[l])
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						if (param[index].statusCode == "FAIL") {
							$scope.clickSave = false;
							$scope.clickSaveDraft = false;
							isValidform = false;
							paramObj.vilidateObj[id].invalid = true;
							paramObj.vilidateObj[id].message = param[index].message;
							if (moveSection && param[index].sectionId && param[index].subSectionId) {
								$scope.currentCategoryItem = param[index].sectionId
								$scope.currentSubItem = param[index].subSectionId;
								var ErrorSection = $.grep($scope.data.uopData, function (n, i) {
									return n.id == param[index].sectionId
								});
								var ErrorSubSection = $.grep(ErrorSection[0].data, function (n, i) {
									return n.id == param[index].subSectionId
								});
								$scope.currentSubItemData = ErrorSubSection;
								if(document.getElementById(paramObj.vilidateObj[id].fieldName) && document.getElementById(paramObj.vilidateObj[id].fieldName).getElementsByClassName("input-element")){
									document.getElementById(paramObj.vilidateObj[id].fieldName).getElementsByClassName("input-element")[0].focus();
								}
								moveSection = false;
							}
						} else {
							paramObj.vilidateObj[id].message = '';
							paramObj.vilidateObj[id].invalid = false;
						}
					}
					if (isValidform && paramObj.submit) {
						$scope.savePrequalForm();
					}
				}
			}, function () {

			});
		}
		$scope.getState = function (state, stateData) {
			var returnData = [];
			var stateObj = stateData;

			returnData = stateObj.filter(function (item) {
				return item.name === state;
			});
			return returnData;
		}
		$scope.getCity = function (city, cityData) {
			var returnData = [];
			returnData = cityData.filter(function (item) {
				return item.name === city
			});
			return returnData;
		}
		var returnValidationobj = function (field, index, sectionId, subSectionId) {

			var fieldValue = field.value;
			if (typeof (fieldValue) && !fieldValue && field.fieldTypeId != 7 || field.fieldTypeId == 7) {
				fieldValue = "";
			}
			return {
				uopId: $scope.data.uopId,
				value: fieldValue,
				fieldId: field.fieldId,
				rowId: index,
				sectionId: sectionId,
				subSectionId: subSectionId,
				fieldName: field.fieldName
			};
		}
		$scope.filterOptions = function (param, arrayItem) {
			var fid = $scope.customizeJson['hierarchy'][param.fieldName];
			var fidArray = fid && fid.split(' ');
			if (fidArray && fidArray.length > 1) {
				for (var j = 0; j < fidArray.length; j++) {
					if (fidArray[j] && typeof (param.value) && arrayItem) {
						for (var index = 0; index < arrayItem.length; index++) {
							if (arrayItem[index].fieldName == fidArray[j]) {
								param.fieldTypeId == 5 ? arrayItem[index].parentid = param.value : arrayItem[index].isShow = param.value;
							}
						}
					}
				}
			} else {
				if (fid && typeof (param.value) && arrayItem) {
					for (var index = 0; index < arrayItem.length; index++) {
						if (arrayItem[index].fieldName == fid) {
							param.fieldTypeId == 5 ? arrayItem[index].parentid = param.value : arrayItem[index].isShow = param.value;
						}
					}
				}
			}
		}

		$scope.prequalValidateForm = function (isForSaveDraft) {
			$scope.isForSaveDraft = isForSaveDraft;
			var jsonObj = {
				submit: true,
				validationArray: [],
				vilidateObj: [],
				IsSetCityState: true
			}
			$scope.isForSaveDraft ? ($scope.clickSaveDraft = $scope.isForSaveDraft) : $scope.clickSave = true;
			for (var i = 0; i < $scope.data.uopData.length; i++) {
				for (var j = 0; j < $scope.data.uopData[i].data.length; j++) {
					for (var k = 0; k < $scope.data.uopData[i].data[j].data.length; k++) {
						if ($scope.data.uopData[i].data[j].data[k].fieldTypeId == "8") {
							var data = $scope.data.uopData[i].data[j].data[k].value || [];
							for (var l = 0; l < data.length; l++) {
								if (data[l]) {
									for (var m = 0; m < data[l].length; m++) {
										//if (data[l][m].validationTypeId) {
										jsonObj.vilidateObj[data[l][m].fieldId + "" + l] = data[l][m];
										jsonObj.validationArray.push(returnValidationobj(data[l][m], l, $scope.data.uopData[i].id, $scope.data.uopData[i].data[j].id));
										//}
										if (data[l][m].fieldTypeId == 7 && data[l][m].value && data[l][m].value.id) {
											//$scope.uopAttachments.push(data[l][m].value);
										}
									}
								}

							}

						} else {
							if ($scope.data.uopData[i].data[j].data[k].validationTypeId) {
								jsonObj.vilidateObj[$scope.data.uopData[i].data[j].data[k].fieldId + "" + 1] = $scope.data.uopData[i].data[j].data[k];
								jsonObj.validationArray.push(returnValidationobj($scope.data.uopData[i].data[j].data[k], 1, $scope.data.uopData[i].id, $scope.data.uopData[i].data[j].id));
							}
						}
					}
				}
			}
			if ($scope.isForSaveDraft == false) {
				$scope.selectSection($scope.data.uopData[0]);
				makeAjaxCallForValidation(jsonObj);
			}
			else {
				$scope.savePrequalForm();
			}
		}
		var weightageValidateForm = function () {
			var section = $scope.jsonWeightage.section,
				formWeightage = 0,
				sectionWeightage = 0,
				valid = true;
			for (var i = 0; i < section.length; i++) {
				sectionWeightage = 0;
				for (var j = 0; j < section[i].data.length; j++) {
					if (section[i].data[j].value) {
						if (section[i].data[j].value > 100) {
							alert('form contain error pls fix it');
							valid = false;
							break;
						} else {
							sectionWeightage += section[i].data[j].value;
						}
					}
				}
				if (section[i].value) {
					if (section[i].value > 100) {
						alert('form contain error pls fix it')
						valid = false;
						break;
					} else {
						formWeightage += section[i].value;
					}
				}
				if (sectionWeightage > 100) {
					alert('form contain error pls fix it')
					valid = false;
					break;
				}

			}
			if (formWeightage > 100) {
				alert('form contain error pls fix it')
				valid = false;
			}
			return valid;

		}

		$scope.savePrequalWeightage = function (approve) {
			$scope.clickApprove = true;
			if (approve) {
				$scope.clickApprove = false;
				$scope.clickReject = true;
			} else {
				var getJsonData = $window.getJSONData && JSON.parse($window.getJSONData());
				var refData = "";
				if (getJsonData && getJsonData.myFields) {
					$scope.jsonWeightage.prequalType = getJsonData.myFields.prequalType;
					refData = $scope.jsonWeightage.referenceResourceId = getJsonData.myFields.referenceResourceId;

				}
				var jsonReadWrite = {
					"Asite_System_Data_Read_Only": {
						"_5_Form_Data": {
							"DS_FORMCONTENT1": refData
						}
					},
					"Asite_System_Data_Read_Write": {
						"Auto_Distribution_Msg_Actions": {
							"DS_AUTODISTRIBUTE_OTHERS_MSG_APP_ID": 1,
							"Auto_Distribution_Msg_Action": [{
								"DS_MSG_ADO_TYPE": 2,
								"DS_MSG_ADO_FORM": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value2,
								"DS_MSG_ADO_MSG_TYPE": "ORI001",
								"DS_MSG_ADO_FORMACTIONS": "3#Respond",
								"DS_MSG_ADO_PROJDISTGROUPS": "",
								"DS_MSG_ADO_ACTIONDUEDATE": 7,
								"DS_MSG_ADO_PROJDISTUSERS": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value5
							}]
						}
					}
				}
				$scope.jsonWeightage && angular.extend($scope.jsonWeightage, jsonReadWrite);
			}
			$scope.jsonWeightage.ORI_FORMTITLE = $scope.companyName;
			var myFields = {
				myFields: $scope.jsonWeightage
			}
			
			var formJson = {
				jsonData: angular.toJson(myFields),
				projectId: $("input[name ='projectId']").val().split('$$')[0],
				formTypeId: top.$("input[name ='formTypeId']").val(),
				msgId: $("input[name ='msgId']").val(),
				formId: $("input[name ='formId']").val(),
				msgTypeId: 2,
				parentMsgId: $("input[name ='parent_msg_id']").val(),
				isApprove: $scope.clickApprove,
				vendorOrgId: $scope.data.vendorOrgId,
				evaluationStatus: $scope.clickApprove ? $scope.approveStatus : $scope.rejectStatus
			}

			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveeval",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					alert("Evaluation Submitted Successfully");
					if (window.top && window.top.opener) {
						window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						window.close();
						window.top.close();
					} else {
						window.location = top.marketPlaceServiceURL + "?origin=true";
					}
				}
			}, function () {
				alert("Error In Evaluation Submit.");
				$scope.clickApprove = false;
			});
		}

		var genXdocId = function () {
			var xId = "x_x_x_x".replace(/[x]/g, function (c) {
				var r = Math.random() * 9 | 0, v = c == "x" ? r : "0";
				return v
			}) + "_my"

			return 'xdoc_' + xId + ':Asite';
		}

		$scope.savePrequalForm = function () {
			$scope.isForSaveDraft ? ($scope.clickSaveDraft = $scope.isForSaveDraft) : $scope.clickSave = true;
			$scope.data.vendorOrgId = USP.orgID;
			$scope.data.ORI_FORMTITLE = $scope.companyName;
			$scope.data.vendorOrgName = USP.tpdOrgName;
			$scope.data.prequalType = myConfig.prequalType ? myConfig.prequalType : 1;
			$scope.data.referenceResourceId = weightageId
			/* prequalReceiveUserId = $("input[name ='prequalReceiveUserId']").val()
			$scope.data.Distribution.AutoDistribute_Users[0].DS_PROJDISTUSERS = prequalReceiveUserId;
			$scope.data.Distribution.AutoDistribute_Users[0].DS_ACTIONDUEDATE = calculateDistDate(7); */
			$scope.data.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = $scope.data.referenceResourceId;
			
			$scope.onLoadDataSet($scope.data,true);
			$scope.appendAttachmentHiddenFields && $scope.appendAttachmentHiddenFields(window.getJSONData());
			$scope.appendAttachHiddenFields();
			var formJson = {
				jsonData: {
					myFields: $scope.data
				},
				projectId: projectId,
				formTypeId: formTypeId,
				userRef: userRef,
				uopAttachments: []
			}
			formJson.inlineAttachments = [];
			var $attachInputs = $("input[name$='Asite']");
			for (var i = 0; i < $attachInputs.length; i++) {
				if ($attachInputs[i].id != "xdoc_attachment_fields") {
					formJson.inlineAttachments.push(
						{ "name": $attachInputs[i].name, "value": $attachInputs[i].value }
					)
				}
			}
			formJson.jsonData.myFields.attachments = [];

			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				formJson.jsonData.myFields[$fakepathids[i].name] = $fakepathids[i].value;
			}

			for (var i = 0, xsnId; i < $scope.uopAttachments.length; i++) {
				xsnId = genXdocId();
				formJson.uopAttachments.push({
					"name": $scope.uopAttachments[i].id + '',
					"value": xsnId.split(':')[0]
				});
				formJson.inlineAttachments.push({
					"name": xsnId,
					"value": 'xdInlineFile:/' + $scope.uopAttachments[i].name
				});
				formJson.jsonData.myFields[xsnId] = {
					'@inline': xsnId,
					'content': ''
				}
			}
			var attachdocs = angular.element("input[name=attachedDocs]");
			var attachdocs_ = angular.element("input[name=attachedDocs_]");
			if(attachdocs.length)
			formJson.attachedDocs = [];

			if(attachdocs_.length)
			formJson.attachedDocs_ = [];
			for(var i=0;i<attachdocs.length;i++){
				if(formJson.attachedDocs.indexOf(attachdocs[i].value == -1))
				formJson.attachedDocs.push(attachdocs[i].value);
			}
			for(var i=0;i<attachdocs_.length;i++){
				if(formJson.attachedDocs_.indexOf(attachdocs_[i].value == -1))
				formJson.attachedDocs_.push(attachdocs_[i].value);
			}

			var attachxdoc_ = angular.element("input[id^=attchment_xdoc_]");
			formJson.dataMap = {};
			for(var i=0;i<attachxdoc_.length;i++){
				var attachxdoc_Name = attachxdoc_[i].name;				
				formJson.dataMap[attachxdoc_Name]=attachxdoc_[i].value;
			}						
			formJson.eOriDraftMsgId = $("input[name ='msgId']").val();
			formJson.attachDocFolderID = $("input[name ='attachDocFolderID']").val();

			formJson.msgId = $("input[name ='msgId']").val();
			formJson.formId = $("input[name ='formId']").val();
			if ($scope.isForSaveDraft) {
				formJson.saveAsDraft = true;
			}
			formJson.editOri = false;
			if ($("input[name ='editDraft']").val() == "true") {
				formJson.formAction = 'edit';
			} else {
				formJson.formAction = 'create';
			}
			
			formJson.jsonData = angular.toJson(formJson.jsonData);
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/save",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					$scope.clickSaveDraft ? alert("Form Saved as Draft.") : alert("Prequalification Submitted Successfully.");
					if (window.top && window.top.opener) {
						if (ie_ver && ie_ver() > 0) {
							window.opener.reloadPublicURL && window.opener.reloadPublicURL();
						} else {
							window.top.opener.postMessage("PublicURLreload", "*");
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						}
						window.top.close();
					} else {
						window.location = top.marketPlaceServiceURL + "?origin=true";
					}
				}
			}, function () {
				alert("Error In Prequalification Submit.");
				$scope.clickSave = false;
				$scope.clickSaveDraft = false;
			});
		}
		function calculateDistDate(days) {
			var strDueDate = "";
			if (days) {
				var d = new Date();
				d.setDate(d.getDate() + days);
				var month = d.getMonth() + 1;
				var day = d.getDate();
				var strDueDate = d.getFullYear() + '-' +
					(month < 10 ? '0' : '') + month + '-' +
					(day < 10 ? '0' : '') + day;
			}
			return strDueDate;
		}
		angular.element($window).bind('resize', function () {
			$scope.isOverflow();
		});
	}
	return FormController;
});