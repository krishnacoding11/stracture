/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
 
 define(['angular', './base', '../components/number-format'], function(angular, baseController) {
    'use strict';

    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {

    	$scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null"){
            $scope.projectId = window.currProjId;
        }

        var printedOn = '';

        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function() {        
                    $scope.loaded = true;
                    $element.addClass('loaded');                
                }, 50);
            }
        });

        $element.addClass('loaded');     

        var currentViewName = window.currentViewName;
        var HMCR_Json = {};
    	var InsertMasterInitArray = {
    		"siteNum" : {
    			"siteNum" : []
    		},
    		"TechnicalInfo": {
	            "specReq": {
                    "value": "",
                    "isHighlighted": ""
                },
	            "dataSheet": {
                    "value": "",
                    "isHighlighted": ""
                },
	            "docTestCertiRef": {
                    "value": "",
                    "isHighlighted": ""
                },
	            "pageNo": {
                    "value": "",
                    "isHighlighted": ""
                },
	            "suppliedSample": {
                    "value": "",
                    "isHighlighted": ""
                }   ,
	            "compliance": {
                    "value": "",
                    "isHighlighted": ""
                }
            },
            "supplementaryInfo": {
                "item": {
                    "value": "",
                    "isHighlighted": ""
                },
                "isSupplementary": {
                    "value": "",
                    "isHighlighted": ""
                },
                "supPageNo": {
                    "value": "",
                    "isHighlighted": ""
                },
                "remarks": {
                    "value": "",
                    "isHighlighted": ""
                },
                "isDefault": false
            }
    	};

        var MCRNoIndexMap = {
            'MCR_Function'  : 0,
            'IssuingCompanyName' : 1,
            'SiteNo'  : 2,
            'WorkType'  : 3,
            'Content'   : 4,
            'DocType'   : 5
        };

        var reviewStageMap = {    
            "Yes"   : {
                "MCR Migration": "",
                "engineerName": "Sent to Contractor Designer",
                "designerName": "Sent to Contractor PM",
                "contractorPMName": "Sent to Document Controller",
                "tidewayDCName" : "QA Accepted"
            },
            "No"    : {
                "MCR Migration": "",
                "engineerName": "",
                "designerName": "Sent back to Contractor Engineer by Contractor Designer",
                "contractorPMName": "Sent back to Contractor Engineer by Contractor PM",
                "tidewayDCName" : "Sent back to Contractor Engineer by Document Controller" 
            }
        };

        var responseNoStageMap = {  
            "MCR Migration": 0,
            "engineerName": 1,
            "designerName": 2,
            "contractorPMName": 3,
            "tidewayDCName": 4                                       
        };

        var currRoleNameMap = {
            "Engineer" :"engineerName",
            "Designer" : "designerName",
            "Contractor PM" : "contractorPMName",
            "Document Controller" : "tidewayDCName"                                       
        };

        var approveKeyNameMap = {
            "engineerName" : "isEngineerApprove",
            "designerName" : "isDesignerApprove" ,
            "contractorPMName" : "isContractorPMApprove",
            "tidewayDCName": "isTidewayDCApprove" 
        }

        /* Auto expand text area */
        $scope.expandTextArea = function(event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = 2 + event.currentTarget.scrollHeight + 'px'; //Adding 2px more for hiding scroll NOODLE-56839
        }

        $scope.delayedResize = function(event) {
            //Bind all 4 events to textarea :
            //ng-keyup="delayedResize($event)" ng-cut="delayedResize($event)" ng-copy="delayedResize($event)" ng-paste="delayedResize($event);"
            $timeout(function() {
                $scope.expandTextArea(event);
            }, 500);
        }

        $scope.delayedExpandTextAreaOnLoad = function() {
            $timeout(function() {
                $scope.expandTextAreaOnLoad();
            }, 50);
        }

        $scope.expandTextAreaOnLoad = function() {
            var textAreaObj = document.getElementsByTagName('textarea');
            if (textAreaObj) {
                for (var i = 0; i < textAreaObj.length; i++) {
                    textAreaObj[i].style.height = 'auto';
                    textAreaObj[i].style.height = 2 + textAreaObj[i].scrollHeight + 'px'; //Adding 2px more for hiding scroll NOODLE-56839
                }
            }
        }

        /**
         * Handle on paste event for checking & restricting special char | # < &
         * @param {event} e - paste
         */
        $scope.restrictCharPaste = function(event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }

            if (inputValue.match(/[|<>#]/gi)) {
                // document.activeElement.blur();
                // ADODDLE.alert({
                //     title: "Restrict Character Entered!!!",
                //     msg: "Restricted Characters specified!!! Restricted Characters | < > #"
                // });
                alert("Restricted Characters specified!!! Restricted Characters | < > #");
                event.preventDefault();

                return false;
            }
        };

        /**
         * Handle key press for checking & restricting special char | # < &
         * @param {event} e - paste
         * @param {string} inputValue
         */
        $scope.restrictChar = function(event, inputValue) {
            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        // document.activeElement.blur();
                        // ADODDLE.alert({
                        //     title: "Restrict Character Entered!!!",
                        //     msg: "Restricted Characters specified!!! Restricted Characters | < > #"
                        // });
                        alert("Restricted Characters specified!!! Restricted Characters | < > #");
                        event.preventDefault();
                    }
                    break;
            }
        };

        $timeout(function() {
            $scope.expandTextAreaOnLoad();
        }, 1000);
        /* Auto expand text area */

    	$scope.insertNewItems = function(items, valueFor) {
            var item = angular.copy(InsertMasterInitArray[valueFor]);
            //Add item in items
            $scope.addRepeatingRow(items, item);
            return item;
        }

        $scope.deleteItems = function(array, index){
            array.splice(index, 1); 
        };
        
        $scope.getSelectedValue8 = function(selectedCustomAtr, selectedDrpDnValue, isBlank){         
            if(!isBlank){
                var DS_ASI_Configurable_AttributesArr = $scope.DS_ASI_Configurable_AttributesArr;
                var preSelectedVal = selectedDrpDnValue;
                if(selectedCustomAtr === "SiteNo" && typeof selectedDrpDnValue === "object"){
                    if(selectedDrpDnValue.length > 1){                       
                        return 'CONTR';
                    } else if(selectedDrpDnValue.length == 1){
                        // remove the white space from the Value8 of the selectedObj.
                        // return selectedDrpDnValue[0].Value8.replace(/\s/g, '');
                        return selectedDrpDnValue[0].Value8;
                    }
                }
                var selectedObj = commonApi._.where(DS_ASI_Configurable_AttributesArr, {Value3 : selectedCustomAtr, Value7 : preSelectedVal});

                return selectedObj[0].Value8;
            } else{
                var returnStr = "XX";
                if(selectedCustomAtr == 'Function'){
                    returnStr = "XXXX";
                } else if(selectedCustomAtr == 'SiteNo'){
                    returnStr = "XXXXX";
                } else if(selectedCustomAtr == 'IssuingCompanyName'){
                    returnStr = "XXXXX";
                } else if(selectedCustomAtr == 'WorkType'){
                    returnStr = "XXX";
                }
                return returnStr;
            }
        };  

        /**
         * fetch the date from server
         * @param {fn} callback
         */
        var getServerTime = function(callback) {
            commonApi.ajax({
                url: (window.adoddleBaseUrl || "") + "/commonapi/htmlForm/serverDateTime",
                method: 'POST',
                withCredentials: true,
                headers : {
                     'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformResponse : function(data, headersGetter, status) {
                    return "" + data;
                }
            }).then(function(response) {
                var data = response.data || {};
                printedOn = data || printedOn;
                // console.log(printedOn);
                callback(printedOn);
            }, function() {
                // $window.alert('error');
            });
        };

        var SetStatus = function(strStatus) {                                   
            var activeStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
            var selectedStatus = commonApi._.where(activeStatus, {Name : strStatus});
            //TEmperery status set into the both fields.

            var defaultStatusList =[{
              "Value": "1006 # Submitted",
              "Name": "Submitted"
            }];

            if(!selectedStatus.length){
                selectedStatus = defaultStatusList;
            }

            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = selectedStatus[0].Value;
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'] = selectedStatus[0].Value;
            
        };

        var updateRevisionNo = function(revisionNo, DS_FORMSTATUS){
            // udate revision only for below Status.
            // "Accepted"
            // "Accepted With Comments"
            // "Not Accepted"
            if(DS_FORMSTATUS === "Accepted" || DS_FORMSTATUS === "Accepted With Comments" || DS_FORMSTATUS === "Not Accepted"){
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["revisionNo"]++;            

                // To generate the Link FWD wise in child MCR form.
                $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT3'] = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["revisionNo"];
            }
        };

        var decideReview_Stage = function(calledBy, isApprove){                        
            var strRevStatus = "";
            isApprove = typeof isApprove != "undefined" ? isApprove : "Yes";            

            strRevStatus = reviewStageMap[isApprove][calledBy];
            SetReview_Stage(strRevStatus);
        };

        var SetReview_Stage = function(strRevStatus) {     
            console.log("SetReview_Stage() :: Review_Stage : "+strRevStatus);       
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'] = strRevStatus;
        };

        var SetCurrentStage = function(strCurrentStage){
            /*
            * CURRENT STAGE VALUES ARE SET ACCORDING TO THEIR ROLES AS FOLLOWS
            * "MCR Migration": 0
            * "Engineer": 1
            * "Designer": 2
            * "Contractor PM": 3
            * "Tideway DC": 4
            */
            console.log("SetCurrentStage() :: currentStage : "+strCurrentStage);
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"].currentStage = strCurrentStage;
        }

        $scope.setFormTitle = function(productName){
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["ORI_FORMTITLE"] = productName;
        };

        $scope.autoCalculateMCRNumber = function(selectedCustomAtr, selectedDrpDnValue){

            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var oldMCRNo = ORI_MSG_Custom_Fields.MCRNo;
            var oldMCRNoArry = oldMCRNo.split('-');

            if(selectedDrpDnValue){
                oldMCRNoArry[MCRNoIndexMap[selectedCustomAtr]] = $scope.getSelectedValue8(selectedCustomAtr, selectedDrpDnValue, false).split('-')[0].trim();                
            } else{
                oldMCRNoArry[MCRNoIndexMap[selectedCustomAtr]] = $scope.getSelectedValue8(selectedCustomAtr, selectedDrpDnValue, true).trim();
            }
            var updatedMCRno = oldMCRNoArry.join('-').toUpperCase();
            setMcrNo(updatedMCRno);
                     
        };

        var setMcrNo = function(updatedMCRno){
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCRNo"] = updatedMCRno;
            // to make easy for the SP side to read witouht opening XML.
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT2'] = updatedMCRno; 
        };

        /*
         *  Function to update value in the node for custom attribute to show on listing.
         *
         */
        $scope.updateListingNodeValue = function(key, item){            
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            $scope.ORI_MSG_Custom_Fields = ORI_MSG_Custom_Fields;

            // first blank out the change.
            $scope.ORI_MSG_Custom_Fields[key] = "";

            if(!item){
                return;
            } else{
                if( key === "MCR_SiteNumber"){
                    if(item && item.siteNum && item.siteNum.length){
                        for(var i = 0; i<item.siteNum.length; i++){
                            var siteNumObj = item.siteNum[i];
                            if(i === item.siteNum.length-1){
                                $scope.ORI_MSG_Custom_Fields[key] += siteNumObj.Value8;
                            } else{
                                $scope.ORI_MSG_Custom_Fields[key] += siteNumObj.Value8 + ',';
                            }

                        }                               
                    } else{
                        $scope.ORI_MSG_Custom_Fields[key] = "";
                    }
                } else{
                    $scope.ORI_MSG_Custom_Fields[key] = item.Value8;
                }
                if( key === "MCR_ContractNo" && ORI_MSG_Custom_Fields.currentUserRole === "MCR Migration" ){
                    setZoneNode(item.Value7)
                }
            }
        };

        $scope.setCustomAttrIsHighlighted = function(jsonDataKey){
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var customAttrIsHighlightedObj = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isHighlightedForCust"];
            var currentUserRole = ORI_MSG_Custom_Fields.currentUserRole;
            var isFromHMCR = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isFromHMCR"];
            var isFromCompletedMCR = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isFromCompletedMCR"];

            if(currentUserRole == 'Document Controller'){
                return
            }

            if((isFromHMCR == true || isFromCompletedMCR == true) && currentUserRole != "MCR Migration"){                
                customAttrIsHighlightedObj[jsonDataKey] = true;
            }
        };

        $scope.clearPageNumber = function(suppInfo){
            if(suppInfo.item.value != 'UKAS Certification'){
                suppInfo.supPageNo.value = "";
            }
        }

        $scope.setIsHighlighted = function(valObj,valKeyName,highlightedKeyName){
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var currentUserRole = ORI_MSG_Custom_Fields.currentUserRole;
            var isFromHMCR = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isFromHMCR"];
            var isFromCompletedMCR = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isFromCompletedMCR"];

            if(currentUserRole == 'Document Controller'){
                return
            }

            if((isFromHMCR == true || isFromCompletedMCR == true) && currentUserRole != "MCR Migration"){                
                if(valObj.value){
                    valObj.isHighlighted = true;
                }
            }
        };

        /*
         *  Get proper Id For the auto Distribution.
         */

        var prepareIdForAutoDist = function(userName){            
            var uNameId = userName;             
            var barCount = uNameId.split("|").length - 1;            
            var t_split = uNameId.split('|'); 
            if(uNameId.indexOf("|") > -1){                                
                uNameId = t_split[2];                        
            } else{
                uNameId = t_split[0];
            }          
            return uNameId;
        };

        /*
         *
         *  Function to decide which users will get the "For Info" Actions in Form cycle.
         *
         */

        var sendInfoToOthers = function(calledBy,isApprovedFromCalled){              

            var userList = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["userList"];
            var currentUserRole = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"];
            var currentUserkeyName = currRoleNameMap[currentUserRole];            
            var isApproved = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isApproved"];
            var responseNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["responseNo"];
            var currentUserApprove = isApproved[approveKeyNameMap[currentUserkeyName]];            

            if(currentUserkeyName == "designerName" && currentUserApprove == "Yes"){
                AutoDistUser(prepareIdForAutoDist(userList["engineerName"]),"7#For Information", 7);
            } else if(currentUserkeyName == "contractorPMName"){
                if(currentUserApprove == "Yes"){
                    AutoDistUser(prepareIdForAutoDist(userList["engineerName"]),"7#For Information", 7);
                    AutoDistUser(prepareIdForAutoDist(userList["designerName"]),"7#For Information", 7);
                } else if(currentUserApprove == "No"){
                    AutoDistUser(prepareIdForAutoDist(userList["designerName"]),"7#For Information", 7);                    
                }
            } else if(currentUserkeyName == "tidewayDCName"){
                if(currentUserApprove == "Yes"){
                    AutoDistUser(prepareIdForAutoDist(userList["engineerName"]),"7#For Information", 7);
                    AutoDistUser(prepareIdForAutoDist(userList["designerName"]),"7#For Information", 7);
                    AutoDistUser(prepareIdForAutoDist(userList["contractorPMName"]),"7#For Information", 7);
                } else if(currentUserApprove == "No"){
                    AutoDistUser(prepareIdForAutoDist(userList["designerName"]),"7#For Information", 7);
                    AutoDistUser(prepareIdForAutoDist(userList["contractorPMName"]),"7#For Information", 7);
                }
            } 

        };

        var AutoDistUser = function(strUserName, strAction, strDueDay, calledBy) {
            if (!strUserName){
                return;
            }
            getServerTime(function(serverDate) {
                var strDays = (new Date(serverDate)).getTime() + (86400000 * strDueDay);
                var strDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
                asiteSystemDataReadWrite['Auto_Distribute_Group'] = asiteSystemDataReadWrite['Auto_Distribute_Group'] || {};                
                //asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] || [];

                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push({
                    DS_PROJDISTUSERS: strUserName.trim(),
                    DS_FORMACTIONS: strAction,
                    DS_ACTIONDUEDATE: strDueDate,
                    DS_ACTIONDAYS: strDueDay
                });
            });
        };
       
        // auto complete action
        var AutoCompleteAction = function(userRole){   
            var node = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS") || [];
            node = commonApi._.findWhere(node, {
                Name: "For Action"
            });

            
            // to bind the responseNo with data to check Access for the user for.
            var reviewNo = responseNoStageMap[userRole] + "";
            console.log("responseNo :: "+reviewNo);
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["responseNo"] = parseInt(reviewNo);

            if (!node) {
                return;
            }

            var strincompleteactions = node.Value.trim();

            var strUserData = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
            strUserData = strUserData[0] || {};
            strUserData = strUserData.Value || "";

            var Workinguserid = strUserData.split('#')[0].split('|')[0].trim();

            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];            
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            if (strincompleteactions) {
                var DS_AC_MSG_TYPE = "FWD";
                var split = strincompleteactions.split('|');
                asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
                asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";                
                var AppId = asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'];
                var nodeDistribution = asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'];

                nodeDistribution.push({
                    DS_AC_TYPE: "complete",
                    DS_AC_FORM: AppId,
                    DS_AC_MSG_TYPE: "ORI",
                    DS_AC_USERID: split[1],
                    DS_AC_ACTION: "36",
                    DS_AC_ACTION_REMARKS: "Action Completed"
                });
                nodeDistribution.push({
                    DS_AC_TYPE: "complete",
                    DS_AC_FORM: AppId,
                    DS_AC_MSG_TYPE: DS_AC_MSG_TYPE,
                    DS_AC_USERID: split[1],
                    DS_AC_ACTION: "36",
                    DS_AC_ACTION_REMARKS: "Action Completed"
                });                
            } 
        };

        $scope.onUserApproveRadioChange = function(userRole, isApprove, userDisAgreeComment){            
            var currentUserRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES')[0]; //Current user role
            currentUserRole = currentUserRole.Value || "";

            if(isApprove == 'No'){
                $scope.OnUserNameChange('engineerName',isApprove); 
                if(userRole == 'contractorPMName' && currentUserRole.indexOf("Contractor PM") > -1){
                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["PM_ApproveDate"] = "";
                }
                else if(userRole == "tidewayDCName" && currentUserRole.indexOf("Document Controller") > -1) {
                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["QA_AcceptedDate"] = "";
                }
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isCycleRejected"] = true;
            } 
            else if(isApprove == 'Yes'){
                // Blank Disagree Comment on approve "YES" for the Respactive user.
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["disagreeComments"][userDisAgreeComment] = "";
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isCycleRejected"] = false;
                if(userRole == 'engineerName' && $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["userList"]["designerName"] !== ''){
                    $scope.OnUserNameChange('designerName',isApprove);
                } else if(userRole == 'designerName' && $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["userList"]["contractorPMName"] !== ''){
                    $scope.OnUserNameChange('contractorPMName',isApprove);
                } else if(userRole == 'contractorPMName' && currentUserRole.indexOf("Contractor PM") > -1){
                    if($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["userList"]["tidewayDCName"] !== ''){
                        $scope.OnUserNameChange('tidewayDCName',isApprove);                        
                    }
                    getServerTime(function(serverDate) {                
                        $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["PM_ApproveDate"] = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');
                    });
                }
                else if(userRole == "tidewayDCName" && currentUserRole.indexOf("Document Controller") > -1){                       
                    $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    // set the Users for the For Info Action.
                    sendInfoToOthers(userRole, isApprove);
                    // to complete self Action.
                    AutoCompleteAction("tidewayDCName");
                    //QA_AcceptedDate date set for Commenting Form reference.
                    getServerTime(function(serverDate) {                
                        $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["QA_AcceptedDate"] = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');
                    });
                }                
            }
            decideReview_Stage(userRole, isApprove);
        };

        $scope.OnUserNameChange = function(calledBy, isApprove){            
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];            
            var userName = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['userList'][calledBy];
            //asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            if (userName) {
                // send to Tech autho Respond action
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3";

                userName = prepareIdForAutoDist(userName);                           

                //blank out the "Auto_Distribute_Users" node for the distribution.
                $scope.data.myFields["Asite_System_Data_Read_Write"]["Auto_Distribute_Group"]["Auto_Distribute_Users"] = [];                
                // for Action to the next user.     
                AutoDistUser(userName, "36#For Action", 7, calledBy);
                // set the default "For Information" Action to the users.
                sendInfoToOthers(calledBy, isApprove);
                // set the default auto complete data for the user.
                AutoCompleteAction(calledBy);
            }          
        };

        // to launch another form from the MCR.
        $scope.launchCreateFormFromView = function(appBuilderFIDC) {
            // for mcr form --- appbuilder code ----- TTT-TIDP-MCR
            // for mcr commenting form --- appbuilder code ----- TTT-TIDP-MCMT
            var existingJSON = jQuery('.json_data').val();
            // fill direct into JSON. Both need to put into JSON            
            var isFromHMCR = ($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isHistoricMCR"] == true);            
            //var isFromCompletedMCR = (!($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isHistoricMCR"] == true) && $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'] != "Submitted" );
            var isFromCompletedMCR = !($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isHistoricMCR"] == true);

            var dbMSGID = "";

            // to reset the variable for the doc's association.
            window.DP_DOC_ASSOC = undefined;     
            window.DP_ORI_FWD_DOC_ASSOC= undefined;

            // to set the other associations.
            window.DS_ASSOCIATED_DOCS_UPDATES='';
            window.DP_FORM_ASSOC='';
            window.DP_FORM_ASSOC_CURRENT='';
            // remove old obj
            delete window.localStorage.HMCR_Json;

            if(appBuilderFIDC === "TTT-TIDP-MCR" && typeof window.localStorage !== "undefined"){
                // to carry forward the associated Docs to the another new form launched.                
                if(document.getElementById("DS_MSGID").value.indexOf("ORI") > -1){
                    window.DP_DOC_ASSOC = "";    
                } else if(document.getElementById("DS_MSGID").value.indexOf("FWD") > -1){
                    window.DP_ORI_FWD_DOC_ASSOC = "";
                }

                window.localStorage.setItem("HMCR_Json",existingJSON);
                window.localStorage.setItem("isFromHMCR",isFromHMCR);
                window.localStorage.setItem("isFromCompletedMCR",isFromCompletedMCR);

                typeof window.USP != 'undefined' ? dbMSGID = $('#msgId').attr('value') : dbMSGID = msg_id;                
                dbMSGID = dbMSGID.split('$$')[0];
                window.localStorage.setItem("dbMSGID", dbMSGID);                
            }

            // just for only work around in classic due to this flag it throws error in some functions in classic[ Collab ].
            if(typeof USP === 'undefined'){
                DP_FORM_ASSOC_CURRENT = undefined;
            }

            // below will launch a new form according to the appBuilderFIDC.
            launchCreateForm(appBuilderFIDC);

            // to Disable after clicked Once. need to un comment.
            jQuery('.launchNewMCRBtn, .launchCommentingBtn').unbind('click').addClass('btn-disabled').prop('disabled', true);
        };
        
        //returns true if has For Action for mentioned userId
        $scope.checkIncompleteForActionsForUserAccess = function(userId){
            var hasPendingForAction = false;
            var incompleteActionNodes = $scope.getValueOfOnLoadData("DS_GET_MSG_DISTRIBUTION_Action_LIST");  
            
            if(!incompleteActionNodes.length){
                //created first time.
                hasPendingForAction = true;
            } else {
                var hasIncompleteAction = commonApi._.filter(incompleteActionNodes, function(node) {
                    //Value4: action_name, Value5: action_complete, Value8: user_id, Value10 : distributor_user_id,
                    return node.Value4 == "For Action" && node.Value5 == "Incomplete" && node.Value8 == userId;
                });
                if(hasIncompleteAction.length){
                    hasPendingForAction = true;
                }
            }
            console.log("checkIncompleteForActionsForUserAccess():: hasPendingForAction:: "+ hasPendingForAction);
            return hasPendingForAction;

        }

        // to check the user access with role and if is valid user to edit and Forward.
        $scope.checkUserAccess = function(){
            $scope.isValidShow = false;  
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];            
            var currentUserRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES')[0]; 
            //Current user role
            currentUserRole = currentUserRole.Value || "";            
            var DS_FORMID = document.getElementById('DS_FORMID').value || "";
            
            var DS_ISDRAFT = document.getElementById('DS_ISDRAFT').value || "";
            var DS_ISDRAFT_FWD_MSG = document.getElementById('DS_ISDRAFT_FWD_MSG').value || "";
            var isFormDraft = (DS_ISDRAFT == "YES" || DS_ISDRAFT_FWD_MSG == "YES");
            
            var isCycleRejected = ORI_MSG_Custom_Fields["isCycleRejected"];
            
            var responseNo = ORI_MSG_Custom_Fields["responseNo"];
            console.log("checkUserAccess() :: responseNo ==============>>> " + responseNo);
            
            var prevCurrentStage = ORI_MSG_Custom_Fields["currentStage"] || '';
            console.log("checkUserAccess() :: currentStage ============>>> " + prevCurrentStage);

            var isMcrMigrationRoleUser = currentUserRole.indexOf('MCR Migration') > -1 ? true : false;
            var isContEnggRoleuser = currentUserRole.indexOf("Contractor Engineer") > -1 ? true : false;
            
            //var DS_MSGID = document.getElementById("DS_MSGID").value
            var DS_WORKINGUSER_ID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
            var userId =  DS_WORKINGUSER_ID.Value.split('|')[0].trim();

            var reviewStage =  $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'];
            
            /* DS_INCOMPLETE_MSG_ACTIONS Value -- "user_ids | # action_name | msg_id | current_msg_id" 
            Eg: "0| # |ORI001|3098909" */
            // var incompleteActionNodes = $scope.getValueOfOnLoadData("DS_INCOMPLETE_MSG_ACTIONS"); 
            // if(incompleteActionNodes.length == 0){
            //     $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['WarningMessage']['NoCreateAccess'] = "You do not have any active 'For Action' to edit or update this form at this time. Please contact workspace administrator"
            //     return;
            // } else {
            //     // if(DS_FORMID == "" || ((DS_FORMID!="" && isFormDraft)) )
            // }
            
            var hasNoCreateAccess = $scope.checkIncompleteForActionsForUserAccess(userId);
            if(!hasNoCreateAccess){
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['WarningMessage']['NoCreateAccess'] = "You do not have any active 'For Action' to edit or update this form at this time. Please contact workspace administrator"
                return;
            }
            
            //If draft, then minus one the prevCurrentStage
            //except for MCR user and
            //Engineer when cycle is rejected
            if(isFormDraft){
                if(!isMcrMigrationRoleUser && !(isContEnggRoleuser && isCycleRejected && responseNo!='1') ){ 
                    var draftedPrevCurrentStage = parseInt(prevCurrentStage);
                    prevCurrentStage = (draftedPrevCurrentStage - 1) + "";
                }
            }
            
           //Check if current user is MCR Migration or Engineer (new MCR Form) and set Current Stage accordingly
            if(isMcrMigrationRoleUser && DS_FORMID == "" ){
                prevCurrentStage = "0";
            } 
            else if(isContEnggRoleuser && ((DS_FORMID == "" && reviewStage=="") || 
                (DS_FORMID!="" && isFormDraft && reviewStage=="Sent to Contractor Designer") || 
                (DS_FORMID!="" && isCycleRejected && !isFormDraft) || 
                prevCurrentStage=="4")) {
                    prevCurrentStage = "0";
            }

            //Checking Role wise
            if((isMcrMigrationRoleUser && DS_FORMID == "" ) || (isMcrMigrationRoleUser && responseNo == "" && isFormDraft) ){
                $scope.isValidShow = true;
            } 
            else if(isContEnggRoleuser && prevCurrentStage=="0"){
                // set the status by default to the "Submitted". Check From the Onload SP.
                $scope.DS_FORMSTATUS = document.getElementById('DS_FORMSTATUS').value || "";
                if((responseNo == "1" && !isFormDraft) || ORI_MSG_Custom_Fields.isApproved.isEngineerApprove == "" || $scope.DS_FORMSTATUS === "Accepted" || $scope.DS_FORMSTATUS === "Not Accepted" || $scope.DS_FORMSTATUS === "Accepted With Comments") {
                    $scope.isValidShow = true;
                } 
                else if((responseNo == "" || responseNo == "1" || responseNo == "2") && isFormDraft){
                    $scope.isValidShow = true;
                }
            } 
            else if(currentUserRole.indexOf("Contractor Designer") > -1 && prevCurrentStage=="1"){
                if(responseNo == "2" && !isFormDraft){                    
                    $scope.isValidShow = true;
                } 
                else if((responseNo == "1" || responseNo == "2" || responseNo == "3") && isFormDraft){
                    $scope.isValidShow = true;
                }
            } 
            else if(currentUserRole.indexOf("Contractor PM") > -1  && prevCurrentStage=="2"){
                if(responseNo == "3" && !isFormDraft){                    
                    $scope.isValidShow = true;
                } 
                else if((responseNo == "1" || responseNo == "3" || responseNo == "4") && isFormDraft){
                    $scope.isValidShow = true;
                }
            } 
            else if(currentUserRole.indexOf("Document Controller") > -1  && prevCurrentStage=="3"){
                //ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove
                if(responseNo == "4" && !isFormDraft){                    
                    $scope.isValidShow = true;
                } 
                else if((responseNo == "1" || responseNo == "4") && isFormDraft){
                    $scope.isValidShow = true;
                }
            }
        };        

        $scope.checkOnLoadSetData = function(){
            if(window.currentViewName === "ORI_VIEW"){
                $scope.checkUserAccess();  
                $scope.getJSONFromHMCR();
            }
            $scope.setDefaultData();
        };

        // HMCR data we get from the local storage with key "HMCR_Json"
        $scope.getJSONFromHMCR = function(){                 
            // fill direct into JSON. need to put into JSON            
            if(window.localStorage.hasOwnProperty("HMCR_Json")){         
                HMCR_Json = JSON.parse(window.localStorage.getItem("HMCR_Json"));                   
                // removing the HMCR_Jsonkey from the local storage.
                delete window.localStorage.HMCR_Json;
                $scope.setPrePopulateDataINJson(HMCR_Json);
            }
        };

        // function to pre-populate data from the HMCR form to the new Launched MCR Form.
        $scope.setPrePopulateDataINJson = function(HMCR_Json){
            // Below Fields are mendetory pre populated for the openning Form as per Spec.           
            // o   Product Name
            // o   Generic Description
            // o   Supplier/Manufacturer
            // o   Address
            // o   Contact
            // o   Technical Information
            // o   CE Marking
            // o   Supplementary Information
            // o   Associated Documents     --------- ////  Done by 'DP_DOC_ASSOC' flag.
            // o   MCR Number (as per selected custom attributes)
            // o   Revision Number (Next auto Number)

            /// and below Filds will be disabled by "isFromHMCR" flag.

            // o   Product Name
            // o   Generic Description
            // o   Supplier/Manufacturer
            // o   Address
            // o   Contact

            // to use in link for the MCR to MCR need to put it with revisionNO the in DS_FORMCONTENT 
            $scope.dbMSGID = window.localStorage.dbMSGID;

            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.isFromHMCR = (window.localStorage.isFromHMCR == "true");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.isFromCompletedMCR = (window.localStorage.isFromCompletedMCR == "true");
            if($scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.isFromCompletedMCR){
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.isNewLaunchDisable = (window.localStorage.isFromCompletedMCR == "true");                
            }

            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["productName"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["productName"];
            
            // isuue not working TO DO
            $scope.setFormTitle(HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["productName"]["value"]);

            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["genericDesc"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["genericDesc"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplierName"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["supplierName"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["address"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["address"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["contact"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contact"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["TechnicalInfo"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["isCEmarkingReq"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["isCEmarkingReq"];
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"] = HMCR_Json["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["supplementaryInfo"];

        };

    	$scope.setDefaultData = function() {
    		var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            $scope.ORI_MSG_Custom_Fields = ORI_MSG_Custom_Fields;

            // set value for MCR no to Generate AutoNumber with out 
            $scope.MCRNo = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'];
            $scope.Review_Stage =  $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage']
            
            var DS_WORKINGUSER_ID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];

            ORI_MSG_Custom_Fields.isHistoricMCR = ORI_MSG_Custom_Fields.isHistoricMCR || false;

            // To generate the AutoNumber appended with MCRNo and stored in ORI_USERREF and DS_FORMCONTENT2.
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AU_OTH_FORM'] = "1";

            var currentUserRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES')[0]; //Current user role
            currentUserRole = currentUserRole.Value || "";
            var currUserId = DS_WORKINGUSER_ID.Value.split('|')[0].trim() 
            
            var currentUserNameObj = commonApi._.find($scope.getValueOfOnLoadData('DS_PROJDISTUSERS'), function(obj) {
                return obj.Value.indexOf(currUserId) > -1;
            });
            var currentUserName = currentUserNameObj.Value;

            if(!ORI_MSG_Custom_Fields.mcrWorkSpace){                
                ORI_MSG_Custom_Fields.mcrWorkSpace = document.getElementById('DS_PROJECTNAME').value || "";             
            }
            getServerTime(function(serverDate) {                
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"].mcrDate = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"].Todays_Date = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');
            });

            // close due date field data.         
            var closeDueDate = $scope.getValueOfOnLoadData("DS_CLOSE_DUE_DATE") || [];
            closeDueDate = (closeDueDate[0] || {}).Value || "";            
            if(closeDueDate == ""){
              closeDueDate = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] || "";
            }
            if (!closeDueDate) {
                getServerTime(function(serverDate) {
                    var strDays = (new Date(serverDate)).getTime() + (86400000 * 28);
                    var strDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                    $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strDueDate;
                });                
            }
            else {
                $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = closeDueDate;
            }

            var DS_FORMID = document.getElementById('DS_FORMID').value || "";
            var DS_ISDRAFT = document.getElementById('DS_ISDRAFT').value || "";
            var DS_ISDRAFT_FWD_MSG = document.getElementById('DS_ISDRAFT_FWD_MSG').value || "";
            var isFormDraft = (DS_ISDRAFT == "YES" || DS_ISDRAFT_FWD_MSG == "YES");
            $scope.isFormDraft = isFormDraft; 
            var responseNo = ORI_MSG_Custom_Fields["responseNo"];
            var prevCurrentStage = ORI_MSG_Custom_Fields["currentStage"] || '';
            var isCycleRejected = ORI_MSG_Custom_Fields["isCycleRejected"];

            var isMcrMigrationRoleUser = currentUserRole.indexOf('MCR Migration') > -1 ? true : false;
            var isContEnggRoleuser = currentUserRole.indexOf("Contractor Engineer") > -1 ? true : false;
            var reviewStage =  $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'];

            //If draft, then minus one the prevCurrentStage
            //except for MCR user and
            //Engineer when cycle is rejected
             if(isFormDraft){
                 if(!isMcrMigrationRoleUser && !(isContEnggRoleuser && isCycleRejected && responseNo!='1') ){ 
                    var draftedPrevCurrentStage = parseInt(prevCurrentStage);
                    prevCurrentStage = (draftedPrevCurrentStage - 1) + "";
                }
            }
            
            //Check if current user is Engineerand set Current Stage as 0
            //Check if current user is MCR Migration or Engineer (new MCR Form) and set Current Stage accordingly
            if(isMcrMigrationRoleUser && DS_FORMID == "" ){
                prevCurrentStage = "0";
            } 
            else if(isContEnggRoleuser && ((DS_FORMID == "" && reviewStage=="") || 
                (DS_FORMID!="" && isFormDraft && reviewStage=="Sent to Contractor Designer") || 
                (DS_FORMID!="" && isCycleRejected && !isFormDraft) || 
                prevCurrentStage=="4")) {
                    prevCurrentStage = "0";
            }

            /// set the Conditions role wise.
            $scope.setZone(currentUserRole);
            if((isMcrMigrationRoleUser && DS_FORMID == "" ) || (isMcrMigrationRoleUser && responseNo == "" && isFormDraft)) {
                ORI_MSG_Custom_Fields.isHistoricMCR = true;
                ORI_MSG_Custom_Fields.currentUserRole = 'MCR Migration';
                SetReview_Stage("Migration User");
                if(!isFormDraft){
                    SetCurrentStage("0");
                }
            }
            else if(isContEnggRoleuser && prevCurrentStage=="0"){
                ORI_MSG_Custom_Fields.isApproved.isEngineerApprove = 'Yes';
                ORI_MSG_Custom_Fields.currentUserRole = 'Engineer';
                if(window.currentViewName === "ORI_VIEW"){  
                    ORI_MSG_Custom_Fields.userList.engineerName = currentUserName; 
                    if(( ORI_MSG_Custom_Fields.isApproved.isDesignerApprove != "Yes" || ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove != "Yes" || ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove != "Yes")){
                        $scope.OnUserNameChange('designerName',"Yes");                    
                        if((ORI_MSG_Custom_Fields.isApproved.isDesignerApprove == "No" || ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove == "No" || ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove == "No") && ORI_MSG_Custom_Fields.isCycleRejected == true){
                            decideReview_Stage('engineerName',"Yes");                            
                        }
                    } 

                    // To set the review stage after Revision gets updated.
                    if($scope.DS_FORMSTATUS != "Submitted" && $scope.DS_FORMSTATUS != "Open"){
                        decideReview_Stage('engineerName',"Yes");
                    }         
                    
                    //reset isCycleRejected flag
                    ORI_MSG_Custom_Fields.isCycleRejected = false;

                    // to reset the disagree comment
                    $scope.resetDisagreeComment();
                    if(!isFormDraft){
                        SetCurrentStage("1");
                    }
                }
            }  
            else if(currentUserRole.indexOf('Contractor Designer') > -1 && prevCurrentStage=="1"){            
                ORI_MSG_Custom_Fields.isApproved.isEngineerApprove = 'Yes';
                ORI_MSG_Custom_Fields.currentUserRole = 'Designer';
                if(window.currentViewName === "ORI_VIEW"){  
                    //ORI_MSG_Custom_Fields.userList.designerName = currentUserName;
                    if(ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove != "Yes" || ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove != "Yes"){                    
                        if(ORI_MSG_Custom_Fields.isApproved.isDesignerApprove == "No"){
                            setEngineerAutoDistData();    
                            decideReview_Stage('designerName',"No");
                        } else{
                            $scope.OnUserNameChange('contractorPMName',"Yes");
                            if(ORI_MSG_Custom_Fields.isApproved.isDesignerApprove == "Yes" && (ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove == "No" || ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove == "No")){
                                decideReview_Stage('designerName',"Yes");
                            }
                        }
                    }
                    if(!isFormDraft){
                        SetCurrentStage("2");
                    }
                }
                

            } 
            else if(currentUserRole.indexOf('Contractor PM') > -1 && prevCurrentStage=="2"){                
                ORI_MSG_Custom_Fields.isApproved.isEngineerApprove = 'Yes';
                ORI_MSG_Custom_Fields.isApproved.isDesignerApprove = 'Yes';
                ORI_MSG_Custom_Fields.currentUserRole = 'Contractor PM';
                
                if(window.currentViewName === "ORI_VIEW"){
                    //ORI_MSG_Custom_Fields.userList.contractorPMName = currentUserName;
                    if(ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove != "Yes"){                
                        if(ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove == "No"){
                            setEngineerAutoDistData();   
                            decideReview_Stage('contractorPMName',"No");   
                        } else{              
                            $scope.OnUserNameChange('tidewayDCName',"Yes");
                            if(ORI_MSG_Custom_Fields.isApproved.isDesignerApprove == "Yes" && ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove == "Yes" && ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove == "No"){
                                decideReview_Stage('contractorPMName',"Yes");
                            }
                        }
                    }
                    if(!isFormDraft){
                        SetCurrentStage("3");
                    }
                }
            }              
            else if(currentUserRole.indexOf('Document Controller') > -1 && prevCurrentStage=="3"){                
                ORI_MSG_Custom_Fields.isApproved.isEngineerApprove = 'Yes';
                ORI_MSG_Custom_Fields.isApproved.isDesignerApprove = 'Yes';
                ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove = 'Yes';
                ORI_MSG_Custom_Fields.currentUserRole = 'Document Controller';

                if(window.currentViewName === "ORI_VIEW"){
                    //ORI_MSG_Custom_Fields.userList.tidewayDCName = currentUserName;                
                    if(ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove == "No"){
                        setEngineerAutoDistData();
                        decideReview_Stage('tidewayDCName',"No");
                    } else if (ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove == "Yes"){
                        decideReview_Stage('tidewayDCName',"Yes");
                    }
                    if(!isFormDraft){        
                        SetCurrentStage("4");
                    }
                }

            }
            else {
                if(currentUserRole.indexOf('Document Controller') > -1 && prevCurrentStage=="4"){
                    ORI_MSG_Custom_Fields.currentUserRole = 'Document Controller';                    
                } else{
                    ORI_MSG_Custom_Fields.currentUserRole = currentUserRole;
                }
            }

            // Interpretation For Only ORI_VIEW.
            if(window.currentViewName === "ORI_VIEW"){  
                // set data for distribution to engineer on load.
                // If any Role rejects and forward Further
                if(currentUserRole.indexOf('Contractor Engineer') > -1 && (ORI_MSG_Custom_Fields.isApproved.isDesignerApprove == "" )){
                    $scope.onUserApproveRadioChange('engineerName','Yes', 'engineerDisagreeComment');
                    // to set the Form Title from the Launch button Clicked.
                    //$scope.setFormTitle(ORI_MSG_Custom_Fields.productName.value);
                }

                $scope.updateStatusAndRevision();

                // To generate the Link FWD wise in child MCR form.
                if(typeof $scope.dbMSGID != 'undefined' && $scope.dbMSGID != ''){
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT'] = $scope.dbMSGID ;                    
                }
            }
          
            $scope.DS_FORMSTATUS = document.getElementById('DS_FORMSTATUS').value || "";           

            // // to get Custom Attribute On Load.
            var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes') ;
            $scope.DS_ASI_Configurable_AttributesArr = customAttr  || [];            

            $scope.DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES') || [];

            // To get MCR Refference ON Locd.
            var DS_TTT_GET_MCR_COMMENT_ASSOC_DTLS = $scope.getValueOfOnLoadData('DS_TTT_GET_MCR_COMMENT_ASSOC_DTLS') || [];
            // mcrLinked Form List
            $scope.mcrUrl = commonApi._.where(DS_TTT_GET_MCR_COMMENT_ASSOC_DTLS, {Value8 : "TTT-TIDP-MCR"}) || [];
            // McrCommenting Form List
            $scope.mcrCommentingUrl = commonApi._.where(DS_TTT_GET_MCR_COMMENT_ASSOC_DTLS, {Value8 : "TTT-TIDP-MCMT"}) || [];

            if(window.currentViewName == "ORI_PRINT_VIEW"){                
                var isDsDraftMsgLatest = $scope.getValueOfOnLoadData("DS_IS_DRAFT_MSG_LATEST")[0] || {};
                $scope.isDsDraftMsgLatest = isDsDraftMsgLatest.Value2 || "";
            }
    	}; 

        $scope.setZone = function(currentUserRole){                        
            var zone = "";
            if(currentUserRole.indexOf('East Contractor Engineer') > -1){
                zone = "East"
            }
            else if(currentUserRole.indexOf('West Contractor Engineer')  > -1){
                zone = "West"
            }
            else if(currentUserRole.indexOf('SI Contractor Engineer') > -1){
                zone = "SI";
            }
            else if(currentUserRole.indexOf('Central Contractor Engineer') > -1){
                zone = "Central"
            }
            
            setZoneNode(zone);
        };

        var setZoneNode = function(zone){
            // to set the MCR_Zone only once while creating from the Engineer and Migration User so that further it can not be changd.
            // will update as per migration user changes it's value
            if($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"] === "" || $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"] === "MCR Migration"){
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"] = zone;                
            }
        };

        var setEngineerAutoDistData = function(){
            if(window.currentViewName === "ORI_VIEW"){
                $scope.OnUserNameChange('engineerName',"Yes");
                decideReview_Stage('engineerName',"Yes");                
            }
        };
        
        /*
            Reset belowed Objects while new revision is created.
            // "isApprove"
            // "disagreeComments"
            // "userList"
        */
        $scope.resetObjForNewRevision = function(){
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            // isApprove Obj
            //ORI_MSG_Custom_Fields.isApproved.isEngineerApprove = "";
            ORI_MSG_Custom_Fields.isApproved.isDesignerApprove = "";
            ORI_MSG_Custom_Fields.isApproved.isContractorPMApprove = "";
            ORI_MSG_Custom_Fields.isApproved.isTidewayDCApprove = "";

            $scope.resetDisagreeComment();
            $scope.resetIsHighlighted();

            // userList Obj
            //ORI_MSG_Custom_Fields.userList.engineerName = "";
            ORI_MSG_Custom_Fields.userList.designerName = "";
            ORI_MSG_Custom_Fields.userList.contractorPMName = "";
            ORI_MSG_Custom_Fields.userList.tidewayDCName = "";
        }; 

        /*
         *  reset the all Disagree comment Object
         */
        $scope.resetDisagreeComment = function(){
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            // disagreeComments Obj
            ORI_MSG_Custom_Fields.disagreeComments.designerDisagreeComment = "";
            ORI_MSG_Custom_Fields.disagreeComments.contractorPMDisagreeComment = "";
            ORI_MSG_Custom_Fields.disagreeComments.tidewayDCDisagreeComment = "";
        };

        /*
         *  reset the Is Highlighted Flag for the all fields for the new revision at Engineer.
         */
        $scope.resetIsHighlighted = function(){   

            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["productName"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["tempOrPerm"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["genericDesc"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["location"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["specRef"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplierName"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["address"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["contact"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["incorporationDate"]["isHighlighted"] = "";            
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["thirdPartyCompliance"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["projDBRef"]["isHighlighted"] = "";
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["isCEmarkingReq"]["isHighlighted"] = "";            

            for(var i=0;i<$scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"].length;i++){
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["specReq"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["dataSheet"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["docTestCertiRef"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["pageNo"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["suppliedSample"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["TechnicalInfo"][i]["compliance"]["isHighlighted"] = "";
            }

            for(var i=0;i<$scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"].length;i++){
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"][i]["item"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"][i]["isSupplementary"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"][i]["supPageNo"]["isHighlighted"] = "";
                $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields["supplementaryInfo"][i]["remarks"]["isHighlighted"] = "";
            }

        };

        /*
            Reset belowed Objects while new revision is created.
        */

        $scope.updateStatusAndRevision = function(){

            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            // set the status by default to the "Submitted". Check From the Onload SP.
            $scope.DS_FORMSTATUS = document.getElementById('DS_FORMSTATUS').value || "";                                
            // Conditions to Set the Form Status for the Current view.
            if($scope.DS_FORMSTATUS == ""){
                if(ORI_MSG_Custom_Fields.currentUserRole == 'MCR Migration'){                    
                    SetStatus("Accepted");                        
                } else{
                    SetStatus("Submitted");                        
                    if(ORI_MSG_Custom_Fields.isFromHMCR == true){
                        ORI_MSG_Custom_Fields.isNewLaunchDisable = true;                                            
                    }
                }
            } else if($scope.DS_FORMSTATUS == "Open"){
                if(ORI_MSG_Custom_Fields.currentUserRole == 'MCR Migration'){                    
                    SetStatus("Accepted");                        
                }
            } else if($scope.DS_FORMSTATUS == "Submitted"){
                if(ORI_MSG_Custom_Fields.currentUserRole != 'MCR Migration' && ORI_MSG_Custom_Fields.currentUserRole != 'Engineer'){
                    // To Disable other Custom Attributes Disable flag for the other Users Then Engineer and Migration User.
                    ORI_MSG_Custom_Fields.isRoleWiseDisable = true;
                }
            } else if($scope.DS_FORMSTATUS != "Submitted" && $scope.DS_FORMSTATUS != "Open"){                    
                if(ORI_MSG_Custom_Fields.revisionNo == 1 && $scope.DS_FORMSTATUS === "Not Accepted"){
                    // to further use to disable Input For NEW REVISON DATA.                    
                } else if($scope.DS_FORMSTATUS === "Accepted With Comments" || $scope.DS_FORMSTATUS === "Accepted"){
                    //ORI_MSG_Custom_Fields.isDisableInput = true;                  
                    ORI_MSG_Custom_Fields.isRevisionDisable = true;                      
                }
                // to Update Rivision Number with Any Status Change From Commmenting Form Excepting "Submitted".
                // and set Status To Submitted again for new Cycle for New Revision.            
                // reset the flag while First time Status is "Not Accepted".

                ORI_MSG_Custom_Fields.isFromHMCR = false;
                ORI_MSG_Custom_Fields.isRoleWiseDisable = false;
                ORI_MSG_Custom_Fields.isNewLaunchDisable = false;
                // to set the highlighted background after revision get updated if user changes any details.
                ORI_MSG_Custom_Fields.isFromCompletedMCR = true;

                SetStatus("Submitted");
                updateRevisionNo(ORI_MSG_Custom_Fields.revisionNo, $scope.DS_FORMSTATUS);                                                                
                $scope.resetObjForNewRevision();
            }

            // logic for the disable inputs.
            //$scope.logicForDisableInputs();
        };

        // function to fill ng-options with Contract Number.
        $scope.filterDropDownContactNumber = function(item){            
            var currentUserRole = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"] ;
            var zone = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"];            
            if(currentUserRole == "MCR Migration"){
                return (item.Value3.indexOf("ContractNo") > -1 && item.Value11 == "Active");
            }
            return (item.Value3.indexOf("ContractNo") > -1 && item.Value7.indexOf(zone) > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with Company Name.
        $scope.filterDropDownCompanyName = function(item){            
            var currentUserRole = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"] ;
            var zone = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"];            
            if(currentUserRole == "MCR Migration"){
                if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){
                    var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                    return (item.Value3.indexOf("IssuingCompanyName") > -1 && item.Value7.indexOf(contractNo) > -1 && item.Value11 == "Active");
                }
            }
            return (item.Value3.indexOf("IssuingCompanyName") > -1 && item.Value7.indexOf(zone) > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with Site Number.
        $scope.filterDropDownSiteNumber = function(item){            
            var currentUserRole = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"] ;
            var zone = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"];            
            if(currentUserRole == "MCR Migration"){
                if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){
                    var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                    return (item.Value3.indexOf("SiteNo") > -1 && item.Value7.indexOf(contractNo) > -1 && item.Value11 == "Active");
                }
            }
            return (item.Value3.indexOf("SiteNo") > -1 && item.Value7.indexOf(zone) > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with MCR_Function.
        $scope.filterDropDownFunction = function(item){
            var currentUserRole = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["currentUserRole"] ;
            var zone = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["MCR_Zone"];            
            if(currentUserRole == "MCR Migration"){
                if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){
                    var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                    return (item.Value3.indexOf("MCR_Function") > -1 && item.Value7.indexOf(contractNo) > -1 && item.Value11 == "Active");
                }
            }
            return (item.Value3.indexOf("MCR_Function") > -1 && item.Value7.indexOf(zone) > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with WorkType.
        $scope.filterDropDownWorkType = function(item){
            return (item.Value3.indexOf("WorkType") > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with filterDropDownContent.
        $scope.filterDropDownContent = function(item){
            return (item.Value3.indexOf("Content") > -1 && item.Value11 == "Active");
        };

        // function to fill ng-options with filterDropDownDocType.
        $scope.filterDropDownDocType = function(item){
            return (item.Value3.indexOf("DocType") > -1 && item.Value11 == "Active");
        };

        $scope.filterDS_PROJUSERS_ALL_ROLES_DESIGNER_NAME = function(item){                
            if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){
                var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                if(contractNo){                
                    var userRole = item.Value.split('|')[0] || "";
                    var userRoleof = contractNo + " " + "Contractor Designer";
                    return (userRole.toLowerCase().indexOf(userRoleof.toLowerCase()) > -1);
                }
            }        
        }

        $scope.filterDS_PROJUSERS_ALL_ROLES_CONTRACTOR_PM_NAME = function(item){            
            if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){
                var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                if(contractNo){
                    var userRole = item.Value.split('|')[0] || "";
                    var userRoleof = contractNo + " " + "Contractor PM";
                    return (userRole.toLowerCase().indexOf(userRoleof.toLowerCase()) > -1);
                }
            }
        }

        $scope.filterDS_PROJUSERS_ALL_ROLES_DOCUMENT_CONTROLLER_NAME = function(item){   
            if(typeof $scope.data.myFields["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["contractNo"] != "undefined" && item){         
                var contractNo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['contractNo']['Value7'];
                if(contractNo){
                    var userRole = item.Value.split('|')[0] || "";
                    var userRoleof = contractNo + " " + "Document Controller";
                    return (userRole.toLowerCase().indexOf(userRoleof.toLowerCase()) > -1);
                }
            }
        };
        
        // init function on load will check the access as well set default data
        $scope.checkOnLoadSetData();        

    }
    return FormController;
});

var gIsActionIncomplete = false; //Global defined to check for incomplete action SP on send click.
var doNotSubmitResView = false;

/**
 ** To prevent the form submit on Draft when user is not have Authorization.
 ** for the HTML 5 forms only.
 **/

function validateForHTML5FormForSaveDraft(){
    var sendMsg = document.getElementById("DS_SEND_MSG");
    if(sendMsg && sendMsg.value){
      var pipeIndex = sendMsg.value.indexOf('|')
        if(pipeIndex > -1){
          var flag = '' + Trim(sendMsg.value.substring(0, pipeIndex));
          var message = Trim(sendMsg.value.substring(pipeIndex + 1));
          if(flag == '1'){
            ADODDLE.alert({ title: "Alert Message", msg: message});
            return false;
          }
          if(flag == '2'){
            if(!confirm(message))
              return false;
          }
        }
    }

    if(typeof customHTMLMethodBeforeCreate_ORI != "undefined" && customHTMLMethodBeforeCreate_ORI()){
      return false;
    }

    return true;
}
