/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

		// restrict autosave Draft and hide Save Draft button.
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});

		var currentViewName = window.currentViewName;
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",

			 STATIC_OBJ = {
				HandOverTransfer: {
					HO:"HO #1 MU:",
                    ho_mu: "",
                    Destination:"",
                    Destination_Road:"",
                    Destination_Other:"",
                    Notes:"",
                    MU:"",
					isHO:false,
					attachedDocs: ""
				},
				IFS_In: {
					LKSToMSDc:"LKS to MSDC #1 MU:",
                    LkstomsdcMu: "",
                    MA:"",
                    MB:"",
                    DmaTaTbDmb:"",
                    Destination:"",
					Destination_HRS:"",
					Destination_DS:"",
					isifsIN:false,
					attachedDocs: ""
				},
				IFS_Out: {
					MsdcToLks:"MSDC to LKS #1 MU:",
                    madsToLksMu: "",
                    MA:"",
                    MB:"",
                    DmaTaTbDmb:"",
                    Destination:"",
					Destination_Road2:"",
					Destination_Other:"",
					isifsOut:false,
					attachedDocs: ""
				},
				Authority: {
					ATT:"ATT #1 Reference:",
                    Reference: "",
					MU:"",
				    Destination:"",
					Note:"",
					isauthority:false,
					attachedDocs: ""
				},
				dynamic_running: {
					DR:"DR #1 MU:",
					MU:"",
					Destination:"",
					Completed:"",
					Requires_Retest:"",
					Note:"",
					isdynamicrunning:false,
					attachedDocs: ""
				},
				Hand_Back_Transfer_LKS: {
					HB:"HB #1 MU:",
					MU:"",
					Destination:"",
					Destination_Road3:"",
					Destination_Other:"",
					Note:"",
					isHandBackTransferLKS:false,
					attachedDocs: ""
				}
			};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		$scope.addNewItem = function (repeatingData, addItemFor) {
			var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
			if (addItemFor == "HandOverTransfer") {
                var newOptionNumber = repeatingData.length + 1;
                newRowObject.HO = "HO #" + newOptionNumber + " MU:";
			}
			if (addItemFor == "IFS_In") {
                var newMRFormsIN = repeatingData.length + 1;
                newRowObject.LKSToMSDc = "LKS to MSDC #" + newMRFormsIN + " MU:";
			}
			if (addItemFor == "IFS_Out") {
                var newFIMFloat = repeatingData.length + 1;
                newRowObject.MsdcToLks = "MSDC to LKS #" + newFIMFloat + " MU:";
			}
			if (addItemFor == "Authority") {
                var newATT = repeatingData.length + 1;
                newRowObject.ATT = "ATT #" + newATT + " Reference:";
			}
			if (addItemFor == "dynamic_running") {
                var newDR = repeatingData.length + 1;
                newRowObject.DR = "DR #" + newDR + " MU:";
			}
			if (addItemFor == "Hand_Back_Transfer_LKS") {
                var newHB = repeatingData.length + 1;
                newRowObject.HB = "HB #" + newHB + " MU:";
            }
			repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad();
		};

		$scope.removeItem = function (nodeObj, list) {
			var index = list.indexOf(nodeObj);
			list.splice(index, 1);
		};
		// To reset  Index while remove Row
		$scope.HandOverTransfer = function() {
            $timeout(function () {
                var HandOver = $scope.oriMsgCustomFields.HandOverTransfertoLKS['HandOverTransfer'];
                for (var i = 0; i < HandOver.length; i++) {
                    HandOver[i].HO = "HO #" + (i + 1) + " MU:";
                }
            }, 200);
		};
		$scope.IfsIn = function() {
            $timeout(function () {
                var ifsin = $scope.oriMsgCustomFields.Intra_Facility_Shunts['IFS_In'];
                for (var i = 0; i < ifsin.length; i++) {
                    ifsin[i].LKSToMSDc = "LKS to MSDC #" + (i + 1) + " MU:";
                }
            }, 200);
		};
		$scope.IfsOut = function() {
            $timeout(function () {
                var ifsout = $scope.oriMsgCustomFields.Intra_Facility_Shunts_Out['IFS_Out'];
                for (var i = 0; i < ifsout.length; i++) {
                    ifsout[i].MsdcToLks = "MSDC to LKS #" + (i + 1) + " MU:";
                }
            }, 200);
		};
		$scope.authority = function() {
            $timeout(function () {
                var authority = $scope.oriMsgCustomFields.Authority_To_Travel['Authority'];
                for (var i = 0; i < authority.length; i++) {
                    authority[i].ATT = "ATT #" + (i + 1) + " Reference:";
                }
            }, 200);
		};
		$scope.dynamicrunning = function() {
            $timeout(function () {
                var Dynamicrunning = $scope.oriMsgCustomFields.Dynamic_Running['dynamic_running'];
                for (var i = 0; i < Dynamicrunning.length; i++) {
                    Dynamicrunning[i].DR = "DR #" + (i + 1) + " MU:";
                }
            }, 200);
		};
		$scope.handBackTransferLks = function() {
            $timeout(function () {
                var handbackToLks = $scope.oriMsgCustomFields.Hand_Back['Hand_Back_Transfer_LKS'];
                for (var i = 0; i < handbackToLks.length; i++) {
					handbackToLks[i].HB = "HB #" + (i + 1) + " MU:";
                }
            }, 200);
		};

		if(currentViewName == "ORI_VIEW"){
			$scope.locationsList = commonApi.getItemSelectionList({
				arrayObject: getConfigurableAttriburteByType('Site Diary Locations'),
				groupNameKey: "",
				modelKey: "Value7",
				displayKey: "Value8"
			});
			$scope.TAKTList = commonApi.getItemSelectionList({
				arrayObject: getConfigurableAttriburteByType('Site Diary TAKT'),
				groupNameKey: "",
				modelKey: "Value7",
				displayKey: "Value8"
			});
		}

		$scope.onLocationChange = function(selectedItem, eventFrom){
			var trainMovements = $scope.opMovDiary.trainMovements;
			if(trainMovements.fromLocation.id == trainMovements.toLocation.id){
				if(eventFrom == 'from'){
					$scope.opMovDiary.trainMovements.fromLocation.id = "";
					$scope.opMovDiary.trainMovements.fromLocation.label = "";
				}else{
					$scope.opMovDiary.trainMovements.toLocation.id = "";
					$scope.opMovDiary.trainMovements.toLocation.label = "";
				}
				alert("From Location and To Location Should not be same !!!");
			}else{
				if(eventFrom == 'from'){
					$scope.opMovDiary.trainMovements.fromLocation.label = selectedItem.displayValue || "";
				}else{
					$scope.opMovDiary.trainMovements.toLocation.label = selectedItem.displayValue || "";
				}
			}
		};
		$scope.onTAKTChange = function(selectedItem){
			$scope.opMovDiary.trainMovements.TAKT.label =  selectedItem.displayValue || "";
		};

		$scope.onLocoChange = function(){
			if($scope.opMovDiary.shunting && !$scope.opMovDiary.shunting.loco){
				$scope.opMovDiary.shunting.locoId = "";
				$scope.opMovDiary.shunting.locoComments = "";
			}
		};
		$scope.onShunterChange = function(){
			if($scope.opMovDiary.shunting && !$scope.opMovDiary.shunting.shunter){
				$scope.opMovDiary.shunting.shunterId = "";
				$scope.opMovDiary.shunting.shunterComments = "";
			}
		};

		$scope.muNumValidate = function(){
			var muVal = $scope.opMovDiary.trainMovements.MU;
			if(muVal && isNaN(muVal)){
				$scope.opMovDiary.trainMovements.MU = "";
				alert("MU Should be Number Only!!!");
			}
		};
		
		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		$scope.update();

		function formSubmitCallBack()
		{
			$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.todayDateUKFormat + " " + $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME;
			return false;
		}
		$window.oriformSubmitCallBack = function () {
			formSubmitCallBack();
		};
		$window.draftSubmitCallBack = function () {
			formSubmitCallBack();
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}