define(['angular', './base', '../components/signature'], function(angular, baseController) {
     'use strict';
     
      /*
      * @constructor
      * @alias module:Form-Controller/FormController
      */
     function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout) {       
        var printedOn = "";
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        
        $scope.isFullLoaded({
            onComplete: function () {
            	$timeout(function() {
            		$scope.loaded = true;
            		$element.addClass('loaded');                
            	}, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        
        $scope.commentList = [];

        $scope.getCommentsListArray = function() {
            var retArray = [];
            for (var i = 0; i < $scope.data.myFields.NNG_Forms.Design_Checklist.length; i++) {
                var section = $scope.data.myFields.NNG_Forms.Design_Checklist[i];
                for (var j = 0; j < section.Sub_Section.length; j++) {
                    var sub_sec = section.Sub_Section[j];
                    if(sub_sec.Meets == 'Other' && sub_sec.Comment) {
                        retArray.push(sub_sec);
                    }
                }
            }            
            return retArray;
        };

        $scope.onChangeMeets = function(sub_sec, section){
            var value = sub_sec.Meets || '';
            if(value=="Yes" || value=="No"){
                sub_sec.Comment = "";
            }

            section.rowspan = section.Sub_Section.length;
            for (var j = 0; j < section.Sub_Section.length; j++) {
                var subsec = section.Sub_Section[j];
                subsec.rowspan = subsec.categoryCount;

                if(subsec.Meets == 'Other') {
                    section.rowspan++;
                    var firstSubSection = section.Sub_Section[j - (subsec.categoryIndex - 1)]
                    firstSubSection.rowspan++;
                }
            }
        };

        $scope.restrictChar = function(event, inputValue) {
            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert("Restricted Characters specified!!! Restricted Characters | < > #");
                        event.preventDefault();
                    }
                break;
            }
        };

        $scope.restrictCharPaste = function(event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (inputValue.match(/[|<>#]/gi)) {
                alert("Restricted Characters specified!!! Restricted Characters | < > #");
                event.preventDefault();
                return false;
            }
        };

        $scope.filterDsProjUserAllRoles = function(item){
            var userRole = item.Value.split('|')[0] || "";
            userRole = userRole.toLowerCase();
            if(userRole.indexOf("project engineer") > -1 || userRole.indexOf("electrical engineer") > -1){
                return true;
            }
        }

        $scope.OnPipelineFacilityChange = function(){
            var title = $scope.data.myFields['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['ORI_FORMTITLE'];
            if(title){                
                $scope.data.myFields['NNG_Forms']['Pipeline_Facility'] = title;
            }
        }

        var getServerTime = function(callback) {
            commonApi.ajax({
                url: (window.adoddleBaseUrl || "") + "/commonapi/htmlForm/serverDateTime",
                method: 'POST',
                withCredentials: true,
                headers : {
                     'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformResponse : function(data, headersGetter, status) {
                    return "" + data;
                }
            }).then(function(response) {
                var data = response.data || {};
                printedOn = data || printedOn;
                console.log(printedOn);
                callback(printedOn);
            }, function() {
                // $window.alert('error');
            });
        };        
        
        if(!$scope.data.myFields['group1']['Date']){
            getServerTime(function(serverDate) {
                $scope.data.myFields['group1']['Date']  = $scope.formatDate(new Date(serverDate), 'mm/dd/yy');                
            });    
        }
        

        // var DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
        // if (DS_WORKINGUSER_ALL_ROLES[0] && DS_WORKINGUSER_ALL_ROLES[0].Value) {
        //     $scope.data.myFields['group1']['Title'] = DS_WORKINGUSER_ALL_ROLES[0].Value;// $scope.DS_WORKINGUSER_ALL_ROLES = [{"Value":"Workspace - Administrator","Name":"Workspace - Administrator"}];
        // }

        $scope.DS_PROJUSERS_ALL_ROLES = [];
        console.log("DS_PROJUSERS_ALL_ROLES--->" + $scope.DS_PROJUSERS_ALL_ROLES);
        var DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES') || [];
         if(DS_PROJUSERS_ALL_ROLES[0] && DS_PROJUSERS_ALL_ROLES[0].Value){
            $scope.DS_PROJUSERS_ALL_ROLES = DS_PROJUSERS_ALL_ROLES;
         }
        
        

        var projectMasterFormDetails = $scope.getValueOfOnLoadData("DS_NNG_PMF_GET_ProjectMasterForm_Details")[0] || {}; 
        $scope.projectName = projectMasterFormDetails.Value3 || "";//Project_Name
        $scope.workOrderNo = projectMasterFormDetails.Value1 || "";//Work_Order_Number
        $scope.projectDescription = projectMasterFormDetails.Value17 || "";//LegalLandDescription
        
        $scope.update();
    }
     
    return FormController;
 });