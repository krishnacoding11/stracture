
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.stopAutoSaveDraftTimerFromClientSide();
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy", "nl_NL": "dd-M-yy" };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.SectionsGroup = $scope.oriMsgCustomFields["SectionsGroup"];
        $scope.DamageGroup = $scope.oriMsgCustomFields.Damages_Section_Group;
        var dsWorkingUserId = $scope.getWorkingUserId();
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PAA_Contract_Activity_Group_dtls = $scope.getValueOfOnLoadData('DS_PAA_Contract_Activity_Group_dtls');
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_PAA_MPC_NEC_GET_AFP_DETAIL = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_GET_AFP_DETAIL');
        var DS_PAA_MPC_NEC_Check_AFP = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_Check_AFP');
        var DS_PAA_MPC_Certificate_Key_Dates = $scope.getValueOfOnLoadData('DS_PAA_MPC_Certificate_Key_Dates');
        var DS_PAA_MPC_NEC_PMTASSESSMENTDATE = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_PMTASSESSMENTDATE');
        var SECTION_ARRAY = [];
        var AFP_CONSTANT = {
            //To fill dropdown rolewise
            ewnWorkspaceUsers: 'Workspace - Administrator',
            defaultReplyDays: '7',
            reponseNotice: 'Response period for Early Notices',
            Closed: 'Closed',
            Open: 'Open',
            respond: "3#Respond",
            forInformation: "7#For Information",
            oriDistNumb: 3,
            resDistNumb: 13,
            Accepted: "Accepted",
            appforpayment: 'Application for Payment',
            finalappforpayment: 'Final Application for Payment',
            appforpaymentfurtherwork: 'Application of Payment for Further works',
            yymmdddateformate: 'yy-mm-dd',
        }

        $scope.isDataLoaded = true;
        var currentViewName = window.currentViewName;
        $scope.selectionlist = {
            ewnWorkspaceUserslist: [],
            setContractlist: [],
            assesYearlist: [],
            assesPeriodlist: []
        }

        var STATIC_OBJ_DATA = {
            CommercialImpact: "0.00",
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            },
            sections: {
                "sectionName": "",
                "activityCode": "",
                "nopDropdown": "",
                "originalPrice": "",
                "totalAddition": "",
                "currentAddition": "",
                "revisedPrice": "",
                "isSelected": "",
                "Previous_Payments": "",
                "Approved_Amount": 0,
                "Linewise_Total_Amount": ""
            },
            Damages_Section: {
                Dam_Section_Detail: "",
                Dam_Section_Code: "",
                Dam_Section_Name: "",
                Dam_Activity_Code: "",
                Dam_Activity_Name: "",
                Damage_Amount: "",
                Damage_GUID: ""
            }
        }

        if ((currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") && $scope.oriMsgCustomFields.Contract) {
            onContractchange($scope.oriMsgCustomFields.Contract, true);
        }

        function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        $scope.tableUtilSettings = {
            Damages_Section: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                deleteItemCallBack: contractTotalOfdamageamount,
                checkboxModelKey: "damsec_isSelected",
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all sections?",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Damages_Section),
                deleteAllRowTooltip: "Remove all sections",
                deleteCurrRowMsg: "Remove section",
                deleteSelectedMsg: "Remove selected section"

            }
        }

        $scope.onContractchange = onContractchange;
        function onContractchange(conVal, onloadFlag) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var tempConAppCode = conVal.split('|')[0].trim();
                var strAppcode = $scope.asiteSystemDataReadWrite.DS_FORM_APPBUILDERCODE;
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim();
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();

                setFormContent();

                var spParam = {
                    dataSourceArray: [
                        {
                            "fieldName": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_SETUP_SECTIONS",
                            "fieldValue": tempConAppCode + ',' + strAppcode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_ASITE_DM_USED",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_BESPOKE",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_REASONCODE",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_FUNDINGTYPE",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_Contract_Activity_Group_dtls",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_GET_AFP_DETAIL",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_Check_AFP",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_Certificate_Key_Dates",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_PMTASSESSMENTDATE",
                            "fieldValue": tempConAppCode
                        }

                    ],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;

                        if (response["DS_PAA_MPC_NEC_GET_AFP_DETAIL"]) {
                            DS_PAA_MPC_NEC_GET_AFP_DETAIL = response["DS_PAA_MPC_NEC_GET_AFP_DETAIL"];
                        }
                        if (response["DS_PAA_MPC_NEC_Check_AFP"]) {
                            DS_PAA_MPC_NEC_Check_AFP = response["DS_PAA_MPC_NEC_Check_AFP"];
                        }
                        if (response["DS_PAA_Contract_Activity_Group_dtls"]) {
                            DS_PAA_Contract_Activity_Group_dtls = response["DS_PAA_Contract_Activity_Group_dtls"];
                        }
                        if (response["DS_PAA_MPC_Certificate_Key_Dates"]) {
                            DS_PAA_MPC_Certificate_Key_Dates = response["DS_PAA_MPC_Certificate_Key_Dates"];
                        }
                        if (response["DS_PAA_MPC_NEC_PMTASSESSMENTDATE"]) {
                            DS_PAA_MPC_NEC_PMTASSESSMENTDATE = response["DS_PAA_MPC_NEC_PMTASSESSMENTDATE"];
                        }
                        if (!onloadFlag) {
                            $scope.SectionsGroup.sections = [];
                            $scope.DamageGroup.Damages_Section = [];
                            if (response.DS_ASI_GET_CURRENCY_FROM_CONTRACT && response.DS_ASI_GET_CURRENCY_FROM_CONTRACT[0]) {
                                $scope.oriMsgCustomFields.Currency = response.DS_ASI_GET_CURRENCY_FROM_CONTRACT[0].Value2;
                            }
                            setReplyDays(response);
                            setSectionData();
                        }
                        setSectionList();
                        if (currentViewName == 'ORI_VIEW') {
                            $scope.oriMsgCustomFields.Monthly_Submission.App_Issue_Date = $scope.formatDate(new Date($scope.todayDateDbFormat), AFP_CONSTANT.yymmdddateformate);
                            $scope.oriMsgCustomFields['Monthly_Submission']['Certificate_of_Payment_Due_Date'] = $scope.formatDate(new Date(commonApi.calculateDistDateFromDays({ baseDate: $scope.todayDateDbFormat, days: '14' })), AFP_CONSTANT.yymmdddateformate);
                            setUserList(response);
                            validateAFP();
                            if (DS_PAA_MPC_NEC_PMTASSESSMENTDATE.length) {
                                $scope.selectionlist.assesYearlist = commonApi._.uniq(DS_PAA_MPC_NEC_PMTASSESSMENTDATE, 'Value1');
                                var strYear = $scope.oriMsgCustomFields.Final_Submission.Asses_Year;
                                if (strYear) {
                                    var strassessObj = commonApi._.filter(DS_PAA_MPC_NEC_PMTASSESSMENTDATE, function (val) {
                                        return val.Value1 == strYear;
                                    });
                                    $scope.selectionlist.assesPeriodlist = commonApi._.uniq(strassessObj, 'Value3');
                                }
                            }
                        }
                    }
                };
                $scope.getCallbackSPdata(spParam);
            }
        }

        $scope.addNewItem = function (repeatingData, objKeyName, parentRow) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);
                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        initFormsData();
        function initFormsData() {
            if (currentViewName == "ORI_VIEW") {
                var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
                $scope.selectionlist.setContractlist = commonApi.getItemSelectionList({
                    arrayObject: contractData,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;

            } else if (currentViewName == "RES_VIEW") {
                $scope.oriMsgCustomFields.ResponderName = document.getElementById('DS_WORKINGUSER').value;
                $scope.oriMsgCustomFields.ResponderUserId = dsWorkingUserId;
                $scope.oriMsgCustomFields.ResponderComment = "";
                updateApprovedPayment();

            }

            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
                $scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;
            } else {
                for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                    if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                        $scope.contractURL = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                        break;
                    }
                }
                $timeout(function () {
                    $scope.hideExportBtn()
                }, 100)
            }

            $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
            $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
            $scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;
        }

        function setSectionList() {
            if (DS_PAA_Contract_Activity_Group_dtls) {
                for (var i = 0; i < DS_PAA_Contract_Activity_Group_dtls.length; i++) {
                    var lvl68Custom = (DS_PAA_Contract_Activity_Group_dtls[i].Value8 || DS_PAA_Contract_Activity_Group_dtls[i].Value7);
                    SECTION_ARRAY.push({
                        sectionName: DS_PAA_Contract_Activity_Group_dtls[i].Value15.trim() + " | " + lvl68Custom + " | " + DS_PAA_Contract_Activity_Group_dtls[i].Value9,
                        activityCode: DS_PAA_Contract_Activity_Group_dtls[i].Value5,
                        nopDropdown: DS_PAA_Contract_Activity_Group_dtls[i].Value15.trim(),
                        originalPrice: DS_PAA_Contract_Activity_Group_dtls[i].Value6.trim(),
                        totalAddition: DS_PAA_Contract_Activity_Group_dtls[i].Value14.trim(),
                        lvl68Custom: lvl68Custom
                    });
                }

                SECTION_ARRAY = commonApi._.sortBy(SECTION_ARRAY, 'sectionName');

                $scope.sectionList = commonApi.getItemSelectionList({
                    arrayObject: SECTION_ARRAY,
                    groupNameKey: "",
                    modelKey: "sectionName",
                    displayKey: "sectionName"
                });
            }
        }

        $scope.onSectionChange = function (currRow) {
            var selectedSection = commonApi._.filter(SECTION_ARRAY, function (obj) {
                return obj.sectionName == currRow.Dam_Section_Detail;
            })[0];
            if (selectedSection && selectedSection.sectionName) {
                currRow.Dam_Activity_Code = selectedSection.activityCode;
            }
            $scope.sectionList = angular.copy($scope.sectionList);
        }

        /**
         * To fetch Level 7 code name from SP name DS_PAA_Contract_Activity_Group_dtls which match to SP name DS_PAA_MPC_NEC_GET_AFP_DETAIL
         * @param {Object} element : object of SP name DS_PAA_MPC_NEC_GET_AFP_DETAIL
         */
        function getSectionName(element) {
            var newSectioName = "";
            element.Value1 + " | " + element.Value2 + " | " + element.Value2;

            for (var i = 0; i < DS_PAA_Contract_Activity_Group_dtls.length; i++) {
                var lvl68Custom = (DS_PAA_Contract_Activity_Group_dtls[i].Value8 || DS_PAA_Contract_Activity_Group_dtls[i].Value7);
                if (element.Value1 == DS_PAA_Contract_Activity_Group_dtls[i].Value15 && element.Value2 == lvl68Custom) {
                    newSectioName = DS_PAA_Contract_Activity_Group_dtls[i].Value15.trim() + " | " + lvl68Custom + " | " + DS_PAA_Contract_Activity_Group_dtls[i].Value9;
                }
            }

            return newSectioName
        }

        function setSectionData() {
            if (DS_PAA_MPC_NEC_GET_AFP_DETAIL.length) {
                var insertPoint = $scope.SectionsGroup.sections,
                    objSection, element, prevTotal = 0, prevPay = 0, prevafpAmtdue = 0;
                for (var i = 0; i < DS_PAA_MPC_NEC_GET_AFP_DETAIL.length; i++) {
                    element = DS_PAA_MPC_NEC_GET_AFP_DETAIL[i];
                    prevPay = (parseFloat(element.Value5) || 0);
                    prevafpAmtdue = (parseFloat(element.Value7) || 0);
                    objSection = angular.copy(STATIC_OBJ_DATA.sections);
                    objSection.sectionName = getSectionName(element)
                    objSection.activityCode = element.Value8;
                    objSection.nopDropdown = element.Value1;
                    objSection.Previous_Payments = prevPay.toFixed(2);
                    objSection.Linewise_Total_Amount = prevPay.toFixed(2);
                    prevTotal += prevPay;
                    insertPoint.push(objSection);
                }
                $scope.oriMsgCustomFields.Cumulative_Total_Amount = prevTotal.toFixed(2);
                $scope.oriMsgCustomFields.Previous_Amount_Due = prevafpAmtdue.toFixed(2);
            }
        }
        function setUserList(response) {
            if (response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS) {
                var ownerUserList = commonApi._.filter(response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function (obj) {
                    return obj.Value && obj.Value.split('|')[1].toLowerCase().indexOf('director') > -1;
                });

                $scope.selectionlist.ewnWorkspaceUserslist = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(ownerUserList, function (obj) { return obj.Name }),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            strFormContent = strConAppid + "|";

            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        $scope.contractTotalOfdamageamount = contractTotalOfdamageamount;
        function contractTotalOfdamageamount() {
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.DamageGroup.Damages_Section,
                    calcKey: 'Damage_Amount',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'Dam_Total_Amount'
                });
                calculateData();
            }, 200)
        }

        $scope.calculateData = calculateData;
        function calculateData(currObj) {
            var lineTotal = 0,
                enterAmount = 0,
                damOtherAmount = 0,
                fltDamTotal = 0,
                uptoLessAmount = 0,
                pendingAmount = 0,
                strtilldateamount = 0,
                strotheramount = 0;
            if (currObj) {
                enterAmount = currentViewName == 'ORI_VIEW' ? (parseFloat(currObj.totalAddition) || 0) : (parseFloat(currObj.Approved_Amount) || 0);
                lineTotal = (parseFloat(currObj.Previous_Payments) || 0) + enterAmount;
                currObj.Linewise_Total_Amount = lineTotal.toFixed(2);
            }
            damOtherAmount = $scope.oriMsgCustomFields.Dam_Other_Amount;
            var strafptype = $scope.oriMsgCustomFields.Application_for_Payment_Type;
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.SectionsGroup.sections,
                    calcKey: 'Linewise_Total_Amount',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'Grand_Total_Amount'
                });
                if (strafptype == AFP_CONSTANT.finalappforpayment) {
                    strotheramount = $scope.oriMsgCustomFields.Other_Amount;
                }
                strtilldateamount = (parseFloat($scope.oriMsgCustomFields.Grand_Total_Amount) || 0) + (parseFloat(strotheramount) || 0);
                fltDamTotal = (parseFloat(damOtherAmount) || 0) + (parseFloat($scope.oriMsgCustomFields.Dam_Total_Amount) || 0);
                uptoLessAmount = strtilldateamount - fltDamTotal;
                pendingAmount = uptoLessAmount - (parseFloat($scope.oriMsgCustomFields.Previous_Amount_Due) || 0)
                $scope.oriMsgCustomFields.UptoDate_LessDamage_Amount = uptoLessAmount.toFixed(2);
                $scope.oriMsgCustomFields.Pending_Payment_Amount = pendingAmount.toFixed(2);
            }, 200);
        }
        function setUserAction() {

            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            var userId = $scope.oriMsgCustomFields.EWNIssutoName;
            if (userId) {
                userId = userId && userId.split(' | ')[2];
                userId = userId && userId.split('#')[0];
                var distDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.todayDateDbFormat,
                    days: $scope.oriMsgCustomFields['Reply_Days'] || 2
                });
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userId,
                        strAction: AFP_CONSTANT.respond,
                        strDate: distDate
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: currentViewName == "ORI_VIEW" ? AFP_CONSTANT.oriDistNumb : AFP_CONSTANT.resDistNumb,
                });
            }
        }


        function setReplyDays(response) {
            var contractDates = response.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES;
            if (contractDates && contractDates.length) {
                var selectedData = commonApi._.filter(contractDates, function (obj) {
                    return obj.Value3.toLowerCase() == AFP_CONSTANT.reponseNotice.toLowerCase();
                })[0];
                $scope.oriMsgCustomFields.Reply_Days = selectedData ? selectedData.Value4 : AFP_CONSTANT.defaultReplyDays;
            }
        }

        function updateApprovedPayment() {
            var sectionObj = $scope.SectionsGroup.sections;
            if (sectionObj.length) {
                for (var i = 0; i < sectionObj.length; i++) {
                    sectionObj[i].Approved_Amount = sectionObj[i].totalAddition;
                }
            }
            $scope.calcFieldTotal({
                repData: sectionObj,
                calcKey: 'Approved_Amount',
                parObject: $scope.oriMsgCustomFields,
                totalKey: 'Approved_Total_Amount'
            });
        }

        function validateAFP() {
            $scope.strafp = "";
            $scope.strfinalafp;
            if (DS_PAA_MPC_NEC_Check_AFP.length) {
                $scope.strafp = DS_PAA_MPC_NEC_Check_AFP[0].Value1;
                $scope.strfinalafp = DS_PAA_MPC_NEC_Check_AFP[0].Value2;
                if ($scope.strafp == "YES") {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| Previous AFP is not Accepted so You can not create new application for payment";
                    $scope.hideSaveDraftButton();
                }
                if ($scope.strfinalafp == "YES") {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| Final AFP is already created for this Contract so You can not create new application for payment";
                    $scope.hideSaveDraftButton();
                }
            }
        }

        $scope.setassessmentdate = function () {
            var strafptype = $scope.oriMsgCustomFields.Application_for_Payment_Type,
                stryear = $scope.oriMsgCustomFields.Final_Submission.Asses_Year,
                strPeriod = $scope.oriMsgCustomFields.Final_Submission.Asses_Period;
            $scope.oriMsgCustomFields.isFinal_AFPlate = false;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strafptype;
            var ccdate = "", strassessdate = "";
            if (DS_PAA_MPC_Certificate_Key_Dates.length) {
                ccdate = DS_PAA_MPC_Certificate_Key_Dates[0].Value1.trim();
            }
            if (stryear && strPeriod) {
                var strassessObj = commonApi._.filter(DS_PAA_MPC_NEC_PMTASSESSMENTDATE, function (val) {
                    return val.Value1 == stryear && val.Value3 == strPeriod;
                });
                if (strassessObj.length) {
                    strassessdate = strassessObj[0].Value5;
                    strassessdate = $scope.formatDate(new Date(strassessdate), AFP_CONSTANT.yymmdddateformate);
                    $scope.oriMsgCustomFields["Final_Submission"]["Assess_Date"] = strassessdate;
                }
            }
            if (strafptype == AFP_CONSTANT.appforpayment) {
                $scope.oriMsgCustomFields.Monthly_Submission.App_Issue_Date = $scope.formatDate(new Date($scope.todayDateDbFormat), AFP_CONSTANT.yymmdddateformate);
                $scope.oriMsgCustomFields['Monthly_Submission']['Certificate_of_Payment_Due_Date'] = $scope.formatDate(new Date(commonApi.calculateDistDateFromDays({ baseDate: $scope.todayDateDbFormat, days: '14' })), AFP_CONSTANT.yymmdddateformate);

            } else if (strafptype == AFP_CONSTANT.finalappforpayment) {
                $scope.oriMsgCustomFields["Final_Submission"]["Final_App_Issue_Due_Date"] = strassessdate && $scope.formatDate(new Date(commonApi.calculateDistDateFromDays({ baseDate: strassessdate, days: '21' })), AFP_CONSTANT.yymmdddateformate);
                $scope.oriMsgCustomFields['Final_Submission']['Completion_Issue'] = ccdate && $scope.formatDate(new Date(ccdate), AFP_CONSTANT.yymmdddateformate);
            }
        }

        $scope.setPeriod = function (strYear) {
            $scope.oriMsgCustomFields.Final_Submission.Asses_Period = "";
            $scope.oriMsgCustomFields.Final_Submission.Assess_Date = "";
            if (strYear) {
                var strassessObj = commonApi._.filter(DS_PAA_MPC_NEC_PMTASSESSMENTDATE, function (val) {
                    return val.Value1 == strYear;
                });
                $scope.selectionlist.assesPeriodlist = commonApi._.uniq(strassessObj, 'Value3');
            }
            else {
                $scope.selectionlist.assesPeriodlist = [];
            }
        }

        $window.paaAfpFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                setUserAction();
            }
            if (currentViewName == "RES_VIEW") {
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
                setFormStatus(AFP_CONSTANT.Accepted);
            }
            setFormContent();
            return false;
        }

        $scope.update();

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof paaAfpFinalCallBack !== "undefined") {
        return paaAfpFinalCallBack();
    }
}