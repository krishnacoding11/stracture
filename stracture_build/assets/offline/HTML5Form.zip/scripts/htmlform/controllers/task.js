/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base'], function (angular, baseController) {
    'use strict';
    /**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId')
            .value || '';

        var currentViewName = window.currentViewName;

        var printedOn = "";

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });

        $scope.requests = {};
        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.ORIMsgCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.packageCostCodes = $scope.getValueOfOnLoadData('DS_ASI_GET_PACKAGE_DETAILS');
        $scope.projectDetails = $scope.getValueOfOnLoadData('DS_ASI_GET_Project_List');
        $scope.projectUsers = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        $scope.DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');


        $scope.orginatorUserId = USP.userID && USP.userID.split('$$')[0];
        $scope.strWorkinguser = $scope.WorkingUserID[0].Value

        if (currentViewName == "ORI_VIEW") {
            //add user and date in repeating section
            var DSI_Remarks_Repeating = $scope.ORIMsgCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
            if (DSI_Remarks_Repeating != null) {
                $.each(DSI_Remarks_Repeating, function (index, item) {
                    if (item.Remarks == "") {
                        item.Remarks_User = $scope.strWorkinguser.split('#')[1].trim(),
                        item.Remarks_Date = $scope.formatDate(new Date, 'dd-M-yy', 'yy-mm-dd')
                    }
                });
            }
            //take working user
            var strWorkinguser = $scope.WorkingUserID[0].Value;
            //check imcomplete action
            $scope.Action_Result = CheckPendingAction(strWorkinguser.split('|')[0].trim());
        }
        else if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW") {
            //make blank remarks
            var DSI_Remarks_Repeating = $scope.ORIMsgCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
            if (DSI_Remarks_Repeating != null) {
                $.each(DSI_Remarks_Repeating, function (index, item) {
                    if (item.Remarks == "" && DSI_Remarks_Repeating.length == 1) {
                        $scope.ORIMsgCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'] = [];
                    }
                });
            }
        }
        function CheckPendingAction(strUser) {
            //check user pending action
            var IsAction = false;
            $scope.DS_INCOMPLETE_ACTIONS = _.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == "Assign Status";
            });
            if ($scope.DS_INCOMPLETE_ACTIONS != null) {
                var strStatus = $scope.DS_INCOMPLETE_ACTIONS[0].Value;
                if (strStatus != null) {
                    var split = strStatus.split('#')[0].split('|');
                    for (var i = 0 ; i < split.length; i++) {
                        if (split[i] != "" && split[i] == strUser.trim()) {
                            return true;
                        }
                    }
                }
            }
            return IsAction;
        };
        $scope.RemarksStructure = {
            Remarks_User: $scope.strWorkinguser.split('#')[1].trim(),
            Remarks_Date: $scope.formatDate(new Date, 'dd-M-yy', 'yy-mm-dd'),
            Remarks: "",
            DSI_IsNew: "New"
        };

        $scope.restrictCharPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }

            if (inputValue.match(/[|<>#]/gi)) {
                alert("Restricted Characters specified!!! Restricted Characters | < > #");
                event.preventDefault();
                return false;
            }
        };
        $scope.restrictChar = function (event, inputValue) {
            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert("Restricted Characters specified!!! Restricted Characters | < > #");
                        event.preventDefault();
                    }
                    break;
                case 32:
                    if (inputValue == "") {
                        event.preventDefault();
                    }
                    break;
            }
        };
        $scope.delayedResize = function (event) {
            $timeout(function () {
                $scope.expandTextArea(event);
            }, 1000);
        }
        $scope.expandTextArea = function (event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = event.currentTarget.scrollHeight + 'px';
        }
        $scope.AddNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);

        };
        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };
        $window.MOM_FinalCallBack = function () {
            return $scope.FinalCallBack();
        }
        $scope.FinalCallBack = function () {
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT2'] = $scope.ORIMsgCustomFields['Task_ID'];
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT3'] = $scope.ORIMsgCustomFields['Percentage_Complete'];
            var DSI_Remarks_Repeating = $scope.ORIMsgCustomFields['DSI_Remarks_Section']['DSI_Remarks_Repeating'];
            //make old all repeating remarks
            if (DSI_Remarks_Repeating != null) {
                $.each(DSI_Remarks_Repeating, function (index, item) {
                    item.DSI_IsNew = "Old";
                });
            }
            var percentage = $scope.ORIMsgCustomFields.Percentage_Complete;
            if (percentage == 100) {
                UpdateFormStatus("Closed");
            }
            else {
                UpdateFormStatus("Open");
            }
            return false;
        };
        $scope.PercentageValidation = function (inputvalue) {
            if (inputvalue > 100) {
                alert('Percentage must be between 0 to 100.');
                $scope.ORIMsgCustomFields.Percentage_Complete = "";
            }
        };
        function UpdateFormStatus(StrStatus) {
            if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null) {
                $scope.DS_ALL_ACTIVE_FORM_STATUS = _.filter($scope.DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name == StrStatus;
                });
                if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null) {
                    var strStatus = $scope.DS_ALL_ACTIVE_FORM_STATUS[0].Value;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatus;
                }
            }
        }
    }
    return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof MOM_FinalCallBack !== "undefined") {
        return MOM_FinalCallBack();
    }
}