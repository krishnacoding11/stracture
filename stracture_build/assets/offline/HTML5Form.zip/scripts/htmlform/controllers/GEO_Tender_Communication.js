/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $timeout) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.ORIMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];

		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.Responses = $scope.ORIMsgCustomFields.RES_MSG_Custom_Fields.RESPONSES.ALL_RES;

		var DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_GEO_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_GEO_STD_TNDR_GetITBs');

		$scope.update();

		$scope.reasonForCommunication = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Reason_for_Communication') != -1 && val.Value11.indexOf('Active') != -1;
		});

		$scope.logo = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});

		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
		var strResDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			var strDays = (new Date(serverDate)).getTime() + (86400000 * 3);
			var strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
			$scope.strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date($scope.strTime), 'dd-M-yy');
			$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = strCloseDueDate;
		});
		if (window.currentViewName == "ORI_VIEW") {
			var strPrefix = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMAUTONO_PREFIX'];

			if (strFormId == "" || strIsDraft == "YES") {
				$scope.ORIMsgCustomFields['ORI_USERREF'] = strPrefix + "<<NEXT_AUTONO>>";
				$scope.ORIMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
				$timeout(function () {
					if (localStorage) {
						var numVal = localStorage.getItem('formcode_num')
						if (numVal) {
							if (numVal) {
								$scope.setFormContentOnITBChange(numVal);
							}
							localStorage.removeItem('formcode_num');
						}
					}
				}, 1000);
			}
		}

		$scope.setFormContentOnITBChange = function (selectedITBValue) {
			var strSel_ITB = selectedITBValue.split('-')[0].trim();
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
						"fieldValue": strSel_ITB
					}]
				}
			}
			$scope.ORIMsgCustomFields.DSI_isLoading = true;
			$scope.getCallbackData(form).then(function (response) {
				if (response.data) {
					$scope.ORIMsgCustomFields.DSI_isLoading = false;
					var DS_GEO_STD_TNDR_GET_ITBSDETAILS = angular.fromJson(response.data['DS_GEO_STD_TNDR_GET_ITBSDETAILS']);
					if (DS_GEO_STD_TNDR_GET_ITBSDETAILS && DS_GEO_STD_TNDR_GET_ITBSDETAILS.Items.Item.length) {
						DS_GEO_STD_TNDR_GET_ITBSDETAILS = DS_GEO_STD_TNDR_GET_ITBSDETAILS.Items.Item;
						var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
							return val.Value1.indexOf(strSel_ITB) != -1;
						});
						$scope.ORIMsgCustomFields['Select_ITB'] = dropDownValueObj[0].Value1;
						if (DS_GEO_STD_TNDR_GET_ITBSDETAILS) {
							var strItbId = DS_GEO_STD_TNDR_GET_ITBSDETAILS[0].Value1;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = strItbId;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT2'] = strSel_ITB;
						}
					}
				}
			});
		}

		if (window.currentViewName == "ORI_PRINT_VIEW" || window.currentViewName == "FORM_PRINT_VIEW" || window.currentViewName == "RES_PRINT_VIEW") {
			var strSel_ITB = $scope.ORIMsgCustomFields['Select_ITB'];
			var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
				return val.Value3.indexOf(strSel_ITB) != -1;
			});
			$scope.ORIMsgCustomFields['ITB_URL'] = dropDownValueObj[0].URL6;
		}

		if (window.currentViewName == "RES_VIEW") {
			
			if (strResDraft == "YES") {
				expandTextArea();
				return;
			}
			var intResponseNodeLength = $scope.Responses.length;
			for (var i = 0; i < intResponseNodeLength; i++) {
				if ($scope.Responses[i].RFI_Response.length > 0) {
					$scope.Responses[i].DSI_ResFlag = "Old";
				}
			}
			
			var strResCount = $scope.ORIMsgCustomFields['RES_MSG_Custom_Fields']['DSI_Res_Counter'],
				strWorkingUser = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'],
				BlankResponseNode = {
					"DSI_ResID": "",
					"RFI_Response": "",
					"RFI_ResponseBy": "",
					"RFI_ResponseDate": "",
					"DSI_ResFlag": ""
				},
				strToday = $scope.setDbDateClientSide(0),
				intCount = strResCount;
				
			if (strFormId.trim().length > 0 && (strIsDraft == "NO" || strIsDraft == "")) {
				if (intCount == 1) {
					$scope.Responses[0]['RFI_ResponseBy'] = strWorkingUser;
					$scope.Responses[0]['RFI_ResponseDate'] = strToday;
					intCount++;
				} else {
					intCount++;
					var responseNode = angular.copy(BlankResponseNode);
					responseNode.DSI_ResID = intCount.toString();
					responseNode.RFI_ResponseBy = strWorkingUser;
					responseNode.RFI_ResponseDate = strToday;
					responseNode.DSI_ResFlag = "New";
					if (responseNode) {
						$scope.Responses.push(responseNode);
					}
				}
			}
			$scope.ORIMsgCustomFields['RES_MSG_Custom_Fields']['DSI_Res_Counter'] = intCount.toString();
		}
		expandTextArea();
		function expandTextArea()
		{
			$timeout(function () {
				$scope.expandTextAreaOnLoad();
			}, 500);
		}
				
		if (strFormId != "" && strIsDraft == "NO") {
			$scope.ORIMsgCustomFields.DSI_isLoading = false;
		}			
	}
	return FormController;
});