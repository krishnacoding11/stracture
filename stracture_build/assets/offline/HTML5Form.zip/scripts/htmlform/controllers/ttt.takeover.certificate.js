/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';

    /**
     * removeToobarOptions : @taOptions required,
     * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
     * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
     * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
     */
    var hideOnOutside = function () {
        angular.element('body').on('click', function (event) {
            var $eventTarget = angular.element(event.target),
                targetClassList = event.target.classList,
                targetParentClassList = event.target.parentElement.classList,
                $editorToolbar = angular.element('.artf-editor-toolbar');
            if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
                !$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
                $editorToolbar.find('.font-name').removeClass('open-fonts-list');
            }
            if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
                !$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
                $editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
            }
        });
    },
        addTextAngularOptions = function ($provide) {
            $provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
                taOptions.toolbar = [
                    ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                    ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                    []
                ];
                return taRegisterTool("backgroundColor", {
                    display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                    action: function (color) {
                        var me = this;
                        if (this.$editor().wrapSelection) {
                            return this.$editor().wrapSelection("backColor", color)
                        }
                    },
                    options: {
                        replacerClassName: "fa fa-paint-brush",
                        showButtons: !1
                    },
                    color: "#fff"
                }),
                    taRegisterTool("fontColor", {
                        display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                        action: function (color) {
                            var me = this;
                            if (this.$editor().wrapSelection) {
                                return this.$editor().wrapSelection("foreColor", color)
                            }
                        },
                        options: {
                            replacerClassName: "fa fa-font",
                            showButtons: !1,
                            showAlpha: !1
                        },
                        color: "#000"
                    }),
                    taRegisterTool('fontName', {
                        display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>" + "</button>",
                        action: function (event, font) {
                            //Ask if event is really an event.					
                            if (!!event.stopPropagation) {
                                //With this, you stop the event of textAngular.
                                event.stopPropagation();
                                //Then click in the body to close the dropdown.
                                angular.element("body").trigger("click");
                            }
                            angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
                            this.$element.toggleClass('open-fonts-list');
                            return this.$editor().wrapSelection('fontName', font);
                        },
                        disabled: function () { },
                        options: [{
                            name: 'Sans-Serif',
                            css: 'Arial, Helvetica, sans-serif'
                        },
                        {
                            name: 'Serif',
                            css: "'times new roman', serif"
                        },
                        {
                            name: 'Wide',
                            css: "'arial black', sans-serif"
                        },
                        {
                            name: 'Narrow',
                            css: "'arial narrow', sans-serif"
                        },
                        {
                            name: 'Comic Sans MS',
                            css: "'comic sans ms', sans-serif"
                        },
                        {
                            name: 'Courier New',
                            css: "'courier new', monospace"
                        },
                        {
                            name: 'Garamond',
                            css: 'garamond, serif'
                        },
                        {
                            name: 'Georgia',
                            css: 'georgia, serif'
                        },
                        {
                            name: 'Tahoma',
                            css: 'tahoma, sans-serif'
                        },
                        {
                            name: 'Trebuchet MS',
                            css: "'trebuchet ms', sans-serif"
                        },
                        {
                            name: "Helvetica",
                            css: "'Helvetica Neue', Helvetica, Arial, sans-serif"
                        },
                        {
                            name: 'Verdana',
                            css: 'verdana, sans-serif'
                        },
                        {
                            name: 'Proxima Nova',
                            css: 'proxima_nova_rgregular'
                        }
                        ]
                    }),
                    taRegisterTool('fontSize', {
                        display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",
                        action: function (event, size) {
                            //Ask if event is really an event.					
                            if (!!event.stopPropagation) {
                                //With this, you stop the event of textAngular.
                                event.stopPropagation();
                                //Then click in the body to close the dropdown.
                                angular.element("body").trigger("click");
                            }
                            angular.element('.open-fonts-list').removeClass('open-fonts-list');
                            this.$element.toggleClass('open-fonts-size-list');
                            return this.$editor().wrapSelection('fontSize', parseInt(size));
                        },
                        disabled: function () { },
                        options: [{
                            name: 'xx-small',
                            css: 'xx-small',
                            value: 1
                        },
                        {
                            name: 'x-small',
                            css: 'x-small',
                            value: 2
                        },
                        {
                            name: 'small',
                            css: 'small',
                            value: 3
                        },
                        {
                            name: 'medium',
                            css: 'medium',
                            value: 4
                        },
                        {
                            name: 'large',
                            css: 'large',
                            value: 5
                        },
                        {
                            name: 'x-large',
                            css: 'x-large',
                            value: 6
                        },
                        {
                            name: 'xx-large',
                            css: 'xx-large',
                            value: 7
                        }

                        ]
                    }),
                    taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'), taOptions;
            }]);
        };

    /**
     * configuring and Binding the created text-angular options to the MainModule.
     */
    mainModule.config(function ($translateProvider, $provide) {
        addTextAngularOptions($provide);
        hideOnOutside();
    });

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // restrict autosave Draft
        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        // restrict autosave Draft
        $scope.stopAutoSaveDraftTimerFromClientSide();

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var STATIC_OBJ_DATA = {
            Doc_Form_Details: {
                Doc_Form_SeqID: "",
                Doc_Form_SeqHeader: "",
                Document_Details_Grp: {
                    Document_Details: [{
                        Doc_Form_SubSeqId: "",
                        Doc_Rev_ID: "",
                        Doc_ID: "",
                        Form_ID: "",
                        Doc_User_Ref: "",
                        Doc_Form_Title: "",
                        Doc_Form_Status: "",
                        Doc_Form_Workspace: "",
                        Doc_Form_Type: "",
                        Doc_TWEXNET: "",
                        Doc_Dep_Guid: ""
                    }]
                }
            },
            Document_Details: {
                Doc_Form_SubSeqId: "",
                Doc_Rev_ID: "",
                Doc_ID: "",
                Form_ID: "",
                Doc_User_Ref: "",
                Doc_Form_Title: "",
                Doc_Form_Status: "",
                Doc_Form_Workspace: "",
                Doc_Form_Type: "",
                Doc_TWEXNET: "",
                Doc_Dep_Guid: ""
            },
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
        };

        var TTT_CONSTANT = {
            //define status
            Approved_status: "Approved",
            NotApproved_status: "Not Approved",
            overall_accept_status: "Accepted",
            overall_reject_status: "Rejected",
            issuedstatus: "Issued",
            reviewInProgress: "Review In Progress",
            tidewaydm: "Tideway Delivery Manager",

            // Static role used in Code
            contractor: "Contractor"
        }

        /** Initialize db fields */
        $scope.logo = "/images/htmlform/commenting/tideway.png";
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.ori_msg_Custom_Fields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.Cer_TidewayDM_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["certificate_TidewayDM_ApprovedBy"];
        $scope.Cer_SCM_ApprovedBy = $scope.ori_msg_Custom_Fields["TWUL_Statement"]["Cer_SCM_ApprovedBy"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Get_Dashboard_Formwise_Details');
        var DS_TTT_TIDP_Validate_and_Get_Document_Details = $scope.getValueOfOnLoadData('DS_TTT_TIDP_Validate_and_Get_Document_Details');
        var DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.dbFormId = $scope.formdata5['DS_FORMID'];
        $scope.isDraft = $scope.formdata5['DS_ISDRAFT'];
        $scope.contractorList = $scope.getValueOfOnLoadData('DS_TTT_ECC3_NEC_EMP_CONTRACT');
        $scope.dstttEcc3NecEmpContract = $scope.getValueOfOnLoadData('DS_TTT_ECC3_NEC_CONTRACT');
        $scope.ori_msg_Custom_Fields.MainTitle = "TAKE OVER CERTIFICATE";
        $scope.setTitle = "CERTIFICATE";
        $scope.setPartNo = "1";
        var contractTeamMemberList = $scope.getValueOfOnLoadData('DS_TTT_ECC3_ALL_CONTRACT_TEAM_MEMBERS');
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsWorkingUser = dsWorkingUserId;
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        var todayDate = '';
        var todayDateDbFormat = '';
        $scope.getServerTime(function (serverDate) {
            todayDate = serverDate;
            todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            initORIview();
        });


        function initORIview() {

            if (currentViewName == "ORI_VIEW") {

                var tmpcertificateContractorlist = [];

                for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                    var element = dsAsiConfigurableAttributes[index];

                    if (element.Value3 == "Certificate_Contractor") {
                        tmpcertificateContractorlist.push(element);
                    }
                }

                $scope.certificateContractorlist =  tmpcertificateContractorlist;

                //check and discard all draft forms before creating new form.
                if ($scope.dbFormId != "" && $scope.isDraft == "NO") {
                    $scope.xhr = false;
                    binddocumentList();
                }
                if ($scope.dbFormId == "" || $scope.isDraft == "YES") {
                    filluserreflist();
                    fillContractorList();
                    $scope.hideSaveDraftButton();
                    $scope.onContractChange($scope.ori_msg_Custom_Fields.Contractor_Ref);
                    $scope.setandvalidatedata($scope.ori_msg_Custom_Fields.Certi_Ref);
                }
                if ($scope.ori_msg_Custom_Fields.Certi_Ref == "") {
                    $scope.validatedocumentFlag = true;
                }

                //set precise and statements
                if ($scope.dbFormId == "" && $scope.isDraft == "NO") {
                    $scope.ori_msg_Custom_Fields.Precise_Limits =
                        "<center>This Take Over Certificate applies to:  <br>" +
                        "The <i>works</i> as described by the West / Central / East Main Works or the System Integrator Contract (C4xx) [edit]<br><br>" +

                        "OR<br><br>" +

                        "Part of the <i> works </i> : [enter details] <br></center>";

                    $scope.ori_msg_Custom_Fields.TO_Statement = "Under clause 35.3 the Project Manager certifies that the Employer has taken over [part of] the <i> works </i> pursuant to clause 35.1 on Day, Month, Year [enter the date]";

                    $scope.ori_msg_Custom_Fields.theEmployer = "Bazalgette Tunnel Limited Cottons Centre, Cottons Lane, London, England SE1 2QG";

                    $scope.ori_msg_Custom_Fields.PM_Statement = "CH2M Hill United Kingdom (a Jacobs company) Cottons Centre, Cottons Lane, London, United Kingdom SE1 2QG";
                    
                    $scope.ori_msg_Custom_Fields.selectedEmployer = "Bazalgette Tunnel Limited";
                }
            }


            if (currentViewName == "ORI_PRINT_VIEW") {
                angular.element('.export-btn').hide();
                binddocumentList();
            }

            settabs();
        }

        function settabs() {
            $scope.oriviewtabs = [{
                title: 'Certificate',
                url: 'Certificate.html'
            }, {
                title: 'Package Listing',
                url: 'packageListing.html'
            }]

            $scope.currentOriViewTab = 'Certificate.html';
            /****************************************/
            $scope.isActiveTab = function (tabUrl, calledform) {
                if (calledform == "ori_print_view_main") {
                    return tabUrl == $scope.currentOriPrintViewTab;
                } else if (calledform == "ori_view_main") {
                    return tabUrl == $scope.currentOriViewTab;
                }
            }
            /****************************************/

            $scope.setTitle = "CERTIFICATE";
            $scope.setPartNo = "1";
            $scope.onClickTab = function (tab, calledform) {
                var strFlag = "CERTIFICATE",
                    intPartNo = "1";
                if (calledform == "ori_view_main") {
                    $scope.currentOriViewTab = tab.url;
                }
                if (calledform == "ori_print_view_main") {
                    $scope.currentOriPrintViewTab = tab.url;
                }
                if (tab.title == "Package Listing") {
                    strFlag = "PACKAGE LISTING";
                    intPartNo = "2";
                }
                $scope.setTitle = strFlag;
                $scope.setPartNo = intPartNo;

                $timeout(function () {
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        }

        $window.TTT_AssociateDocsAndForms = function () {
            return $scope.setflow();
        }

        $scope.setflow = function () {
            
            if (contractTeamMemberList.length) {
                var roleArray = [];
                var roleName = "";
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    roleName = contractTeamMemberList[i].Value.split('|')[1].trim();
                    if (roleName == 'Emp_Others' || roleName == 'Project Manager') {
                        roleArray.push(contractTeamMemberList[i].Value.split('|')[2].split('#')[0].trim());
                    }
                }
                roleArray = commonApi._.uniq(roleArray);
                if (roleArray.indexOf($scope.getWorkingUserId()) < 0) {
                    alert("You are not authorised to create or edit this form. Please contact Administrator for more details, click the cancel button at the bottom of the form. ");
                    return true;
                }
            }

            if ($scope.ori_msg_Custom_Fields.errorMsg != '') {
                return true;
            }
            else {
                var currentstage = $scope.ori_msg_Custom_Fields["DSI_CurrentStage"];
                var workingUserName = dsWorkingUser && dsWorkingUser.split(',')[0].trim();
                var workingUserOrg = dsWorkingUser && dsWorkingUser.split(',')[1].trim();
                var strTodayDate = todayDateDbFormat;
                $scope.formdata5.DS_DB_INSERT = true;
                //validation mandatory fields if not filled on submit

                var intFlag = validationAcrossAllTabs();
                if (intFlag == 1) {
                    alert("Validation\n\n Please fill mandatory field(s)!");
                    return true;
                }

                if (currentstage) {
                    switch (currentstage) {
                        case '0':
                            $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

                            var selectedContractor = $scope.ori_msg_Custom_Fields.selectedContractor;
                            var contractorID = selectedContractor.split("|")[2].trim().split("#")[0].trim();

                            //set distribution
                            var strdate = commonApi.calculateDistDateFromDays({
                                baseDate: todayDate,
                                days: 2
                            });
                            setDistribution(contractorID, "7#For Information", "3", strdate);

                            //update status
                            updateFormStatus(TTT_CONSTANT.issuedstatus);
                            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = TTT_CONSTANT.overall_accept_status;
                            assocformsanddocs();

                            //tideway delivery manager details
                            $scope.Cer_TidewayDM_ApprovedBy.TidewayDM_ApprovedBy_Date = strTodayDate;
                            $scope.Cer_TidewayDM_ApprovedBy.TidewayDM_ApprovedBy_Name = workingUserName;
                            $scope.Cer_TidewayDM_ApprovedBy.TidewayDM_ApprovedBy_ID = dsWorkingUserId.split('|')[0];
                            $scope.Cer_TidewayDM_ApprovedBy.TidewayDM_ApprovedBy_Position = TTT_CONSTANT.tidewaydm;
                            $scope.Cer_TidewayDM_ApprovedBy.TidewayDM_ApprovedBy_onbehalfof = workingUserOrg;
                            break;
                    }
                }
                
            }
        }

        function assocformsanddocs() {
            var assoFormsStr = ':#';
            var assoDocsStr = "";
            var strdsvalidatedocumentdata = DS_TTT_TIDP_Validate_and_Get_Document_Details;
            for (var index = 0; index < strdsvalidatedocumentdata.length; index++) {
                var strvalidate = strdsvalidatedocumentdata[index].Value1.trim();
                if (strvalidate == "0") {
                    var assocflag = strdsvalidatedocumentdata[index].Value16;
                    if (assocflag == 'Yes') {
                        if (strdsvalidatedocumentdata[index].Value15 != "") {
                            if (assoFormsStr == ":#") {
                                assoFormsStr += ':' + strdsvalidatedocumentdata[index].Value15;
                            } else {
                                assoFormsStr += ',:' + strdsvalidatedocumentdata[index].Value15;
                            }
                        }
                        if (strdsvalidatedocumentdata[index].Value7 != "") {
                            assoDocsStr += strdsvalidatedocumentdata[index].Value7 + "#" + strdsvalidatedocumentdata[index].Value14 + "#" + strdsvalidatedocumentdata[index].Value13 + ",";
                        }
                    }
                }
            }
            if (assoFormsStr.length > 2) {
                $scope.formdata5['DS_AUTO_ASSOC_FORMS'] = assoFormsStr;
            }
            $scope.formdata5['DS_AUTO_ASSOC_DOCS'] = assoDocsStr;
        }

        function updateFormStatus(StrStatus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: StrStatus.toLowerCase()
            });
            $scope.formdata5['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
        }

       function setDistribution(UsertoDist, Action, DS_AUTODist, strDate){
            var tempList = [];

            tempList.push({
                strUser: UsertoDist,
                strAction: Action,
                strDate: strDate
            });

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: DS_AUTODist
            });
        }

        function filluserreflist() {
            $scope.objuserref = [];
            var element = $scope.DS_TTT_TIDP_Get_Dashboard_Formwise_Details;
            for (var index = 0; index < element.length; index++) {
                if (element[index].Value2 && element[index].Value3) {
                    var struserref = element[index].Value2.trim();
                    var strguid = element[index].Value3.trim();
                    var strconcate = struserref + "||" + strguid;
                    $scope.objuserref.push({
                        optlabel: "",
                        options: [{
                            displayValue: struserref,
                            modelValue: strconcate,
                            checked: false
                        }]
                    });
                }
            }
        }

        function fillContractorList() {
            $scope.objContractorList = commonApi.getItemSelectionList({
                arrayObject: $scope.contractorList,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })
        }

        $scope.setandvalidatedata = function (strcerti) {
            if (strcerti) {
                var strGUID = strcerti.split("||")[1].trim();
                $scope.ori_msg_Custom_Fields.ORI_USERREF = strcerti.split("||")[0].trim();
                $scope.ori_msg_Custom_Fields.Cer_GUID = strGUID;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = strcerti.split("||")[0].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strcerti.split("||")[1].trim();

                var spParam = {
                    dataSourceArray: [{
                        "fieldName": "DS_TTT_TIDP_Validate_and_Get_Document_Details",
                        "fieldValue": strGUID + "|TTT-ECC3-TOC"
                    }],
                    successCallback: getcallbackcertidata
                };
                $scope.xhr = true;
                $scope.getCallbackSPdata(spParam);
            }
        }

        function getcallbackcertidata(responseList) {
            $scope.xhr = false;
            if (responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"]) {
                DS_TTT_TIDP_Validate_and_Get_Document_Details = responseList["DS_TTT_TIDP_Validate_and_Get_Document_Details"];
                $scope.ori_msg_Custom_Fields.ORI_FORMTITLE = DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value20;
            }
            binddocumentList();
        }

        $scope.onContractChange = function (strcontract) {
            if (strcontract) {
                var strconparam = strcontract.split('|')[0].trim();
                $scope.ori_msg_Custom_Fields.CON_AppBuilderId = strconparam;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strconparam;
                $scope.ori_msg_Custom_Fields.DS_STT_NEC_CONTRACT = strcontract;

                var spcontractparam = {
                    dataSourceArray: [{
                        "fieldName": "DS_TTT_ECC3_ALL_CONTRACT_TEAM_MEMBERS",
                        "fieldValue": strconparam
                    }
                    ],
                    successCallback: getCallbackcontract
                };

                $scope.xhr = true;
                $scope.contractLoader = false;
                $scope.getCallbackSPdata(spcontractparam);

                var arrStr = strcontract.split('|');
                $scope.ori_msg_Custom_Fields.Contract_ID = arrStr[5].trim();
            }
        }

        function getCallbackcontract(responseList) {
            $scope.xhr = false;
            $scope.contractLoader = true;

            if (responseList["DS_TTT_ECC3_ALL_CONTRACT_TEAM_MEMBERS"]) {
                contractTeamMemberList = responseList["DS_TTT_ECC3_ALL_CONTRACT_TEAM_MEMBERS"];

                // Contractor Data list
                if (contractTeamMemberList.length) {
                    var matchRole = "Contractor"
                    var arrayContractorValue = [];
                    var arrayContractorNode = [];
                    for (var i = 0; i < contractTeamMemberList.length; i++) {
                        var element = contractTeamMemberList[i];
                        var roleName = element.Value.split('|')[1].trim();
                        if (arrayContractorValue.indexOf(element.Value) == -1 && roleName == matchRole) {
                            arrayContractorNode.push(element);
                            arrayContractorValue.push(element.Value);
                        }
                    }

                    $scope.contractorList1 = commonApi.getItemSelectionList({
                        arrayObject: arrayContractorNode,
                        groupNameKey: "",
                        modelKey: "Value",
                        displayKey: "Name"
                    })

                    var chkPermission = strIsUserDraftOnly("draft only");
                    if (chkPermission.toLowerCase() == "yes")
                        setSendPermission("Draft");
                    else
                        setSendPermission("Send");
                }
            }
        }


        // put functions suggested by pareshbhai..

        if (currentViewName == "ORI_PRINT_VIEW") {
            var strConAppid = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT;
            var urlObj = commonApi._.filter($scope.dstttEcc3NecEmpContract, function (obj) {
                return obj.Value && obj.Value.split('|')[0].trim() == strConAppid.trim();
            });
            if (urlObj.length) {
                $scope.Contract_URL = urlObj[0].URL;
            }
        }

        function strIsUserDraftOnly(strVal) {
            if (contractTeamMemberList.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    strValue = contractTeamMemberList[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == strVal) {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == $scope.getWorkingUserId())
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {

            var strMsg = "";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.ori_msg_Custom_Fields.errorMsg = strMsg;
        }

        function binddocumentList() {
            if (DS_TTT_TIDP_Validate_and_Get_Document_Details[0].Value1 == '1') {
                $scope.validatedocumentFlag = true;
                $scope.formdata5["DS_SEND_MSG"] = '1|You can not create/update the form.Please verify validation message.';
                $scope.hideSaveDraftButton();
            } else {
                var objSaveDraftBtn = document.getElementById('btnSaveDraft');
                $scope.validatedocumentFlag = false;
                $scope.formdata5["DS_SEND_MSG"] = '0|';
                setDocumentFormHeaders(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                setDocumentFormdetails(DS_TTT_TIDP_Validate_and_Get_Document_Details);
                objSaveDraftBtn && (objSaveDraftBtn.style.display = 'inline-block');
            }
        }

        //validation mandatory fields if not filled on submit
        function validationAcrossAllTabs() {
            var sendToContractor = $scope.ori_msg_Custom_Fields.selectedContractor;

            if (!sendToContractor || !$scope.ori_msg_Custom_Fields.Precise_Limits || !$scope.ori_msg_Custom_Fields.TO_Statement || !$scope.ori_msg_Custom_Fields.theContractor || !$scope.ori_msg_Custom_Fields.Certificate_Contractor) {
                return 1;
            }
        }

        function onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
        }

        function setDocumentFormHeaders(dsvalidatedocumentdata) {
            $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details = [];
            var insertPointparent = $scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details,
                strdocumentdet = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    var unique = [];
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();
                        if (strvalidate == "0") {
                            var strheader = dsvalidatedocumentdata[index].Value10.trim() + "|$|" + dsvalidatedocumentdata[index].Value11.trim();
                            unique.push(strheader);
                        }
                    }
                    if (unique.length) {
                        unique = unique.filter(onlyUnique);
                        for (var i = 0; i < unique.length; i++) {
                            var seqnum = unique[i].split('|$|')[0].trim();
                            var seqheader = unique[i].split('|$|')[1].trim();
                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Doc_Form_Details);
                            strdocumentdet.Doc_Form_SeqID = seqnum;
                            strdocumentdet.Doc_Form_SeqHeader = seqheader;
                            insertPointparent.push(strdocumentdet);
                        }
                    }
                }
            }
        }

        function setDocumentFormdetails(dsvalidatedocumentdata) {
            var strdocumentdet = "";
            var seqcount, headerseqold = "";

            if (dsvalidatedocumentdata.length) {
                if (dsvalidatedocumentdata[0].Value2 != "") {
                    for (var index = 0; index < dsvalidatedocumentdata.length; index++) {
                        var strvalidate = dsvalidatedocumentdata[index].Value1.trim();

                        if (strvalidate == "0") {
                            var strheaderseq = dsvalidatedocumentdata[index].Value10.trim()
                            var strheadertitle = dsvalidatedocumentdata[index].Value11.trim();

                            var insertPoint = commonApi._.filter($scope.ori_msg_Custom_Fields.Doc_Form_Grp.Doc_Form_Details, function (Obj) {
                                return Obj.Doc_Form_SeqID == strheaderseq && Obj.Doc_Form_SeqHeader == strheadertitle;
                            });

                            strdocumentdet = angular.copy(STATIC_OBJ_DATA.Document_Details);
                            if (strheaderseq == headerseqold) {
                                seqcount = seqcount + 1;
                            } else {
                                seqcount = 1;
                            }
                            var checksubseqid = insertPoint[0]['Document_Details_Grp']['Document_Details'][0]['Doc_Form_SubSeqId'];
                            if (checksubseqid == "") {
                                insertPoint[0]['Document_Details_Grp']['Document_Details'] = [];
                            }
                            strdocumentdet.Doc_Form_SubSeqId = strheaderseq + "." + seqcount;
                            strdocumentdet.Doc_Form_Title = dsvalidatedocumentdata[index].Value2;
                            strdocumentdet.Doc_Form_Status = dsvalidatedocumentdata[index].Value4;
                            strdocumentdet.Doc_User_Ref = dsvalidatedocumentdata[index].Value3;
                            strdocumentdet.Doc_Form_Type = dsvalidatedocumentdata[index].Value6;
                            strdocumentdet.Doc_Form_Workspace = dsvalidatedocumentdata[index].Value5;
                            strdocumentdet.Form_ID = dsvalidatedocumentdata[index].Value9;
                            strdocumentdet.Doc_Rev_Link = dsvalidatedocumentdata[index].URL17;
                            strdocumentdet.Doc_Rev_ID = dsvalidatedocumentdata[index].Value12;
                            strdocumentdet.Doc_ID = dsvalidatedocumentdata[index].Value8;
                            strdocumentdet.Doc_Dep_Guid = dsvalidatedocumentdata[index].Value18;

                            insertPoint[0]['Document_Details_Grp']['Document_Details'].push(strdocumentdet);

                            headerseqold = strheaderseq;
                        }
                    }
                }
            }
        }

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms();
    }
}