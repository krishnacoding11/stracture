/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;
        var modelRowIndex = -1;

        var CONTRACT_ACTIVITIES = {
            Con_isSelected: false,
            CSection_Code: "",
            Activity_Code: "",
            Activity_Name: "",
            Activity_Value: "0",
            Msg_Activity: "",
            Activity_Used_Flag: "NO",
            Total_Additions: "0",
            Unagreed_Additions: "0",
            PM_Estimated: "0",
            PM_Adjustment: "0",
            EWN_Additions: "0",
            Anticipated_Additions: "0",
            Payment_Received: "0",
            HTotal_Additions: "0",
            HAnticipated_Additions: "0",
            HPayment_Received: "0",
            EWN_PriceIncNo: "0",
            EWN_wo_Quotation: "0"
        };
        var STATIC_OBJ_DATA = {
            Sections: {
                Section_Code: "",
                sec_isSelected: false,
                Section_Name: "",
                Activity_Count: "1",
                Section_Used: "NO",
                Activity_Group: {
                    Contract_Activities: [CONTRACT_ACTIVITIES]
                }
            },
            Contract_Activities: CONTRACT_ACTIVITIES,
            Key_Milestone: {
                Key_Date_Id: "1",
                Date_Type: "",
                Date_Ref: "",
                Date_Description: "",
                Key_Date: "",
                Planned_Completion_Date: "",
                Anticipated_Delays: "0",
                Bonus: "",
                LAD: "",
                Completion_Date_Acc_Prog: "",
                Key_Date_Used_Flag: "NO",
                HKD_Additions: "",
                HKD_Anti_Additions: "",
                Bonus_LAD_Group: {
                    Bonus_LAD: [{
                        Range_From: "",
                        Range_To: "",
                        Range_Bonus: "",
                        Range_LAD: ""
                    }]
                },
                Del_Flag: "0"
            },
            Indexation: {
                INDX_ID: "1",
                PayAssess_No: "",
                PayAssess_Date: "",
                PriceAdj_Factor: "",
                PriceAdj_Value: "",
                PriceAdj_Cumulative: "",
                PMC_Ref: "",
                PriceAdj_ImpDate: ""
            },
            CE_Clause: {
                Clause_Id: "",
                Clause_No: "",
                Clause_Description: "",
                CE_isSelected: ""
            },
            Financial_AU: {
                Range_id: "",
                Start_Range: "",
                End_Range: "",
                ConRanges: {
                    RangeWise_AU: {
                        Range_RefID: "",
                        Fin_Au_Priority: "",
                        Fin_Au_Org: "",
                        Fin_Au_Org_Name: "",
                        Fin_AuthorityUser: "",
                        Fin_Au_Role: ""
                    }
                }
            },
            Communication_Type: {
                Communication_Name: "",
                canRemove: "Yes",
                Comm_Accpt_Only: "No"
            },
           
            HD_CE_ActivityCode: {
                HD_CE_Section_Code: "",
                HD_CE_Activity_Code: "",
                HD_CE_Activity_Value: "0",
                HD_CE_Anticipated_Variations: "0"
            },
            HD_CE_Key_Date: {
                HD_Key_Date_Id: "",
                HD_Key_Date_Ref: "",
                HD_Key_Date_Additions: ""
            },
            Project_Managers: {
                Project_Manager: "",
                PM_Name: ""
            },
            Supervisors: {
                Supervisor: "",
                Supervisor_Name: ""
            },
            TflAuthorisors: {
                TflAuthorisor: "",
                TflAuthorisor_Name: ""
            },            
            Emp_Others: {
                Emp_Other: "",
                Emp_Other_Name: ""
            },
            Assistant_Project_Manager: {
                Assistant_PM: "",
                APM_Name: ""
            },
            Con_Others: {
                Con_Other: "",
                Con_Other_Name: ""
            },
            Draft_Users: {
                Draft_User: "",
                Draft_User_Name: ""
            },
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: ""
            },
            Pages_Risks: {
                Page_Range_Risks: ""
            },
            Pages: {
                Page_Range: ""
            }
        };
        var STT_CONSTANT = {
            //All static value used in Code
            restrictedCharMsg: "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #",
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
            validanIncidentDateMsg : "Validation \n\n Date reported should be greater than Incident date.",
            validanProjManConMsg: 'Validation\n\n Please assign TfL or Project Co or TfL Authoriser!',
            validanReturnContractTabMsg: 'Validation\n\n Please Return to the Contract Details tab in order to Submit the Contract',
            validanOnlyNumericMsg: 'Validation\n\nOnly numeric value expected.',
            validanErrorConfigMsg: 'Error while loading Config!',
            validanDuplActCodeMsg: "Duplicate Activity Code selected!! \n\n Select a different Activity Code.",
            contractEccA: "NEC4 ECC Option A",
            datesAndDaysParamMsg: "date and days param required",
            infoActionCode: "7#For Information",

            // All report template name
            reportTemplCEPM: "Riverlinx_CE_Log_Project_Co_View_Report",
            reportTemplRiskReg : "Riverlinx_SCC_Risk_Register_Report",
            reportTemplCECON: "Riverlinx_CE_Log_Contractor_View_Report",
            
            //All popup Modal keys
            priceBreakDown: 'price-breakdown',
            keyContractDates: 'key-contract-dates',
            indexation: 'indexation',
            historicRiskInfo: 'historic-risk-info',
            historicCEInfo: 'historic-ce-info',
            managementTeam: 'management-team',
            
            // ALL template constants
            contractDetailsTab: 'contract-details.html',
            historicRiskInfoHtml:'historic-risk-info.html',
            compensationEventLogHtml:'compensation-event-log.html',
            contractInfoHtml:'contract-information.html',
            sectionalComplKeyDatesHtml:'sectional-completion-key-dates.html',
            priceBreakdownHtml:'price-breakdown.html',
            contractDetailsHtml:'contract-details.html',
            historicCeInfoHtml:'historic-ce-info.html',
            riskRegister: 'risk-register.html',

            // Static SP Used in Forms
            dsSttNecHdCeLogFiltered: "DS_RVL_NEC_HD_CE_LOG_FILTERED",
            dsSttNecContractRisksPaging: "DS_RVL_NEC_CONTRACT_RISKS_PAGING",
            dsSttNecContractActivitySummary:"DS_RVL_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttKeyDatesSummary:"DS_RVL_KEY_DATES_SUMMARY",
            dsSttIncSummaryStatusPaging: "DS_RVL_INC_SUMMARY_STATUS_PAGING",
            dsSttNecContractPrint: "DS_RVL_NEC_CONTRACT_PRINT",
            dsSttNecContractSummary: "DS_RVL_NEC_CONTRACT_SUMMARY"
        }

        var clauseFilterParam = {
            Clause_No: '',
            Clause_Description: ''
        }

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.requests = {};
        $scope.isXHRon = false;
        $scope.modalData = {};
        $scope.projUsersList = [];
        $scope.projUsersName = '';
        $scope.isSideBarOpen = true;

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";

        var ONLY_EDIT_OBJ = {
            insertBefore: 0,
            insertAfter: 0,
            deleteSelected: 0,
            deleteAllRow: 0
        }
        var ONLY_READ_ONLY_OBJ = angular.copy(ONLY_EDIT_OBJ);
        ONLY_READ_ONLY_OBJ.editRow = 0;

        $scope.tableUtilSettings = {
            Contract_ActivitiesNotDel : {
                tooltip: "select to remove/remove all/Insert new Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteSelected:0,
                    deleteAllRow:0
                },
                checkboxModelKey: "Con_isSelectedNotDel",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Contract_Activities)
            },
            Contract_Activities: {
                tooltip: "select to remove/remove all/Insert new Activity",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0
                },
                deleteItemCallBack: conActivityTotalInModal,
                checkboxModelKey: "Con_isSelected",
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Activity Details?",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Contract_Activities),
                ADD_NEW_BEFORE_TIP: "Insert before Activity Detail",
                ADD_NEW_AFTER_TIP: "Insert after Activity Detail",
                deleteAllRowTooltip: "Remove all Activity Detail",
                deleteCurrRowMsg: "Remove Activity Detail",
                deleteSelectedMsg: "Remove selected Activity Detail"
            },
            Sections: {
                tooltip: "select to remove/remove all/Insert new Section",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow:0
                },
                deleteItemCallBack: contractTotalOfPriceBreakDown,
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Sections?",
                editRowCallBack: editSectionModal,
                checkboxModelKey: "sec_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Sections),
                deleteAllRowTooltip: "Remove all Sections Detail",
                deleteCurrRowMsg: "Remove Sections Detail",
                deleteSelectedMsg: "Remove selected Sections Detail"
            },
            Key_Milestone: {
                tooltip: "select to remove/remove all/Insert new Key Contract Date",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow:0
                },
                editRowCallBack: editKeyContractModal,
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Key Contract Dates?",
                checkboxModelKey: "key_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Sections),
                deleteAllRowTooltip: "Remove all Key Contract Date",
                deleteCurrRowMsg: "Remove Key Contract Dates",
                deleteSelectedMsg: "Remove Selected Key Contract Dates"
            },
            Indexation: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Indexation Informations?",
                deleteItemCallBack: indexationCummuativeTotal,
                editRowCallBack: editIndexationModal,
                checkboxModelKey: "Ind_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Sections),
                deleteAllRowTooltip: "Remove all Indexation Informations",
                deleteCurrRowMsg: "Remove Indexation Informations",
                deleteSelectedMsg: "Remove Selected Indexation Informations"
            },
            CE_Clause: {
                tooltip: "select to remove/remove all/Insert new Clause",
                hasDefaultRecord: true,
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Clause?",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "CE_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.CE_Clause),
                deleteAllRowTooltip: "Remove all Clause",
                deleteCurrRowMsg: "Remove Clause",
                deleteSelectedMsg: "Remove Selected Clause"
            },
            Financial_AU: {
                tooltip: "select to remove/remove all/Insert new Range",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "Fin_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Financial_AU),
                deleteAllRowTooltip: "Remove all Range",
                deleteCurrRowMsg: "Remove Range",
                deleteSelectedMsg: "Remove Selected Range"
            },
            Communication_Type: {
                tooltip: "select to remove/remove all/Insert new Communication Type",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Communication Type?",
                checkboxModelKey: "COM_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Communication_Type),
                deleteAllRowTooltip: "Remove all Communication Type",
                deleteCurrRowMsg: "Remove Communication Type",
                deleteSelectedMsg: "Remove Selected Communication Type"
            },
            HD_CE_ActivityCode: {
                tooltip: "select to remove/remove all/Insert new Additional CBS Code",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Additional CBS Codes?",
                checkboxModelKey: "CEACT_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.HD_CE_ActivityCode),
                deleteAllRowTooltip: "Remove all Additional CBS Code",
                deleteCurrRowMsg: "Remove Additional CBS Code",
                deleteSelectedMsg: "Remove Selected Additional CBS Code"
            },
            HD_CE_Key_Date: {
                tooltip: "select to remove/remove all/Insert new Additional Key Date",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Additional Key Dates?",
                checkboxModelKey: "CEKey_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.HD_CE_Key_Date),
                deleteAllRowTooltip: "Remove all Additional Key Date",
                deleteCurrRowMsg: "Remove Additional Key Date",
                deleteSelectedMsg: "Remove Selected Additional Key Date"
            }
        }

        $scope.tableUtilSettings.SectionsNotDel = angular.copy( $scope.tableUtilSettings.Sections );
        $scope.tableUtilSettings.SectionsNotDel.checkboxModelKey = "sec_isSelectedNotDel",
        $scope.tableUtilSettings.SectionsNotDel.hideControlIcon = angular.copy(ONLY_EDIT_OBJ);

        $scope.tableUtilSettings.Key_MilestoneNotDel = angular.copy($scope.tableUtilSettings.Key_Milestone);
        $scope.tableUtilSettings.Key_MilestoneNotDel.checkboxModelKey = "key_isSelectedNotDel";
        $scope.tableUtilSettings.Key_MilestoneNotDel.hideControlIcon = angular.copy(ONLY_EDIT_OBJ);

        $scope.tableUtilSettings.Communication_TypeNotDel = angular.copy($scope.tableUtilSettings.Communication_Type);
        $scope.tableUtilSettings.Communication_TypeNotDel.checkboxModelKey = "COM_isSelectedNotDel";
        $scope.tableUtilSettings.Communication_TypeNotDel.hideControlIcon = angular.copy(ONLY_READ_ONLY_OBJ);



        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.sectionGroup = $scope.oriMsgCustomFields["AUTOCREATE_REPEATING_VALUES"]["Section_Group"];
        
        $scope.indexationInfo = $scope.formCustomFields["Indexation_Info"];
        $scope.finalAccount = $scope.formCustomFields["Final_Account"];
        $scope.paymentCosts = $scope.oriMsgCustomFields["Payments_Costs"];
        $scope.sectionsName = $scope.sectionGroup['Sections']['Section_Name'];
        $scope.Currency = $scope.formCustomFields['Currency'];

        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
        $scope.dsProjOrganisationsId = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');

        var dsWorkingUserField = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'];
        var dsWorkingUserOrg = dsWorkingUserField && dsWorkingUserField.trim();
        dsWorkingUserOrg = dsWorkingUserOrg ? dsWorkingUserOrg.split(',')[1].trim() : '';

        $scope.dsProjOrganisationsId = commonApi._.filter($scope.dsProjOrganisationsId,function(spdata){
            return spdata.Value.toLowerCase().indexOf(dsWorkingUserOrg.toLowerCase()) == -1;
        });

        $scope.dsAsiStdEcc4NecContractPrint = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttNecContractPrint );

        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        function contractTotalOfPriceBreakDown() {
            $timeout(function(){
                $scope.calcFieldTotal({ repData: $scope.sectionGroup['Sections'], calcKey: 'tempTotalActivityValue', parObject: $scope.sectionGroup, totalKey: 'tempGrandTotalActivityValue' });
                $scope.calcFieldTotal({ repData: $scope.sectionGroup['Sections'], calcKey: 'tempTotalAnticipatedAdd', parObject: $scope.sectionGroup, totalKey: 'tempGrandTotalAnticipatedAdd' });

                $scope.oriMsgCustomFields['CONTRACT_VALUE'] = $scope.sectionGroup['tempGrandTotalActivityValue'];
            });
        }

        function conActivityTotalInModal(){
            $timeout(function(){
                $scope.calcFieldTotal({ repData: $scope.modalData['Activity_Group']['Contract_Activities'], calcKey: 'Activity_Value', parObject: $scope.modalData, totalKey:'tempTotalActivityValue'});
                $scope.calcFieldTotal({ repData: $scope.modalData['Activity_Group']['Contract_Activities'], calcKey: 'Anticipated_Additions', parObject: $scope.modalData, totalKey:'tempTotalAnticipatedAdd'});
            },100);
        }

        function updateRecord() {
            var rowIndex = modelRowIndex,
                newNode = angular.copy($scope.modalData);

            if (!validateModalForm(ctrl.model.modelId)) {
                $window.alert(STT_CONSTANT.mandatoryValMsg);
                return;
            }

            switch (ctrl.model.modelId) {
                case STT_CONSTANT.priceBreakDown:
                    var tmpBackupObj = angular.copy( $scope.sectionGroup['Sections'] );
                    //Assign Parent Section_Code to child Activity's CSection_Code
                    for (var index = 0; index < newNode['Activity_Group']['Contract_Activities'].length; index++) {
                        var element = newNode['Activity_Group']['Contract_Activities'][index];
                        element['CSection_Code'] = newNode['Section_Code'];
                    }

                    if (rowIndex > -1) {
                        $scope.sectionGroup['Sections'][rowIndex] = newNode;
                    }
                    else {
                        $scope.sectionGroup['Sections'].push(newNode);
                        rowIndex = $scope.sectionGroup['Sections'].length-1;
                    }

                    var isVal = $scope.checkDuplicateValue({model:newNode, key:'Section_Code', repetObj: $scope.sectionGroup['Sections'], index:rowIndex, msg: 'Section Code'});
                    if(!isVal){
                        $scope.modalData = angular.copy( $scope.sectionGroup['Sections'][rowIndex] );
                        $scope.sectionGroup['Sections'] = angular.copy( tmpBackupObj );
                        return;
                    }

                    contractTotalOfPriceBreakDown();
                    break;
                case STT_CONSTANT.keyContractDates:
                    var tmpBackupObj = angular.copy( $scope.keyMilestones['Key_Milestone'] );
                    if (rowIndex > -1) {
                        $scope.keyMilestones['Key_Milestone'][rowIndex] = newNode;
                    }
                    else {
                        $scope.keyMilestones['Key_Milestone'].push(newNode);
                        rowIndex = $scope.keyMilestones['Key_Milestone'].length-1;
                    }

                    var isVal = $scope.checkDuplicateValue({model:newNode, key:'Date_Ref', repetObj:$scope.keyMilestones['Key_Milestone'], index:rowIndex, msg: 'Date Ref'});
                    if(!isVal){
                        $scope.modalData = angular.copy( $scope.keyMilestones['Key_Milestone'][rowIndex] );
                        $scope.keyMilestones['Key_Milestone'] = angular.copy( tmpBackupObj );
                        return;
                    }

                    $scope.keyMilestones['Key_Milestone'][ rowIndex ]['Key_Date_Id'] = rowIndex+1;

                    if(rowIndex == 0){
                        $scope.oriMsgCustomFields['COMPLETION_DATE'] = $scope.keyMilestones['Key_Milestone'][0]['Key_Date'];
                    }
                    break;
                case STT_CONSTANT.indexation:
                    if (rowIndex > -1) {
                        $scope.indexationInfo['Indexation'][rowIndex] = newNode;
                    }
                    else {
                        $scope.indexationInfo['Indexation'].push(newNode);
                    }
                    modelRowIndex = -1;
                    indexationCummuativeTotal();
                    break;
                case STT_CONSTANT.historicRiskInfo:
                    if (rowIndex > -1) {
                        $scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data'][rowIndex] = newNode;
                    }
                    else {
                        $scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data'].push(newNode);
                    }
                    break;
                case STT_CONSTANT.historicCEInfo:
                    if (rowIndex > -1) {
                        $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'][rowIndex] = newNode;
                    }
                    else {
                        $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'].push(newNode);
                    }

                    calculateCEInfoTotal();

                    break;
                case STT_CONSTANT.managementTeam:
                    
                    userListArray = {
                        projectManager : angular.copy($scope.modalData.projectManager),
                        superviser : angular.copy($scope.modalData.superviser),
                        tflAuthorisor : angular.copy($scope.modalData.tflAuthorisor),
                        employerTeam : angular.copy($scope.modalData.employerTeam),
                        contractor : angular.copy($scope.modalData.contractor),
                        contractorTeamOth : angular.copy($scope.modalData.contractorTeamOth),
                        draftOnly : angular.copy($scope.modalData.draftOnly)
                    }
                    setViewHTMLdata();
                    setDataInManagementTeam('projectManager');
                    setDataInManagementTeam('superviser');
                    setDataInManagementTeam('tflAuthorisor');
                    setDataInManagementTeam('employerTeam');
                    setDataInManagementTeam('contractor');
                    setDataInManagementTeam('contractorTeamOth');
                    setDataInManagementTeam('draftOnly');
                    
                    break;
            }

            $timeout(function () {
                hideModal();
            })

        }

        $scope.setCurrentSection = function (tabURL) {
            $scope.currentOriTab = tabURL;

            switch(tabURL){
                case STT_CONSTANT.riskRegister:
                    $scope.resetRiskRegFilter();
                    break;
                case STT_CONSTANT.compensationEventLogHtml:
                    $scope.resetTrackerFilter();
                    break;
            }

            bindTableScrollEvent(tabURL);
        };

        $scope.setHdKeyDateRef = function(currRowObj){
            var currHD_Date_id = commonApi._.filter( $scope.oriMsgCustomFields['Key_Milestones']['Key_Milestone'] , function(obj){
                return obj.Date_Ref == currRowObj['HD_Key_Date_Ref']
            }).map(function(obj){
                return obj.Key_Date_Id;
            })[0];

            currRowObj['HD_Key_Date_Id'] = currHD_Date_id || '';
        }

        $scope.intervalChange = function(onLoadFlg){
            if(!onLoadFlg){
                $scope.oriMsgCustomFields['group25']['Assessment_Interval'] = '';
            }
            if($scope.oriMsgCustomFields['group25']['Assessment_Type'] == 'On' || $scope.oriMsgCustomFields['group25']['Assessment_Type'] == 'Every'){
                $scope.intervalArray = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"];
                $scope.intervalText = "days of each month";

                if($scope.oriMsgCustomFields['group25']['Assessment_Type'] == 'Every'){
                    $scope.intervalText = "days";
                }
            }else{
                $scope.intervalArray = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
                $scope.intervalText = "of the month";
            }
        }

        $scope.downloadReport = function(reportId){
            var form_template_name = "";
            var Report_format = "XLS";
            switch(reportId){
                case 1:
                    form_template_name = STT_CONSTANT.reportTemplCEPM;
                    break;
                case 2:
                    form_template_name = STT_CONSTANT.reportTemplRiskReg;
                    break;
                case 3:
                    form_template_name = STT_CONSTANT.reportTemplCECON;
                    break;
            }
            if(form_template_name){
                $window.showSelectedReportfromApp(form_template_name,Report_format);
            }
        }

        function setPMandCONAutoDistributionNode(){
            $scope.data.myFields.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];

            var allPMusers = $scope.oriMsgCustomFields.All_Project_Managers.Project_Managers;
            var pmUser = null;
            var pmUserId = null;
            var distAction = STT_CONSTANT.infoActionCode;
            for (var index = 0; index < allPMusers.length; index++) {
                pmUser = allPMusers[index].Project_Manager;
                if(pmUser){
                    pmUserId = pmUser.split('#')[0].trim();
                    setAutoDistribution('PM', pmUserId , distAction, '');
                }
            }

            var allConUsers = $scope.oriMsgCustomFields.Assistant_Project_Managers.Assistant_Project_Manager;
            var conUser = null;
            var conUserId = null;
            for (var index = 0; index < allConUsers.length; index++) {
                conUser = allConUsers[index].Assistant_PM;
                if(conUser){
                    conUserId = conUser.split('#')[0].trim();
                    setAutoDistribution('PM', conUserId , distAction, '');
                }
            }

        }

        function validateModalForm(modalId) {
            var mandatorySingleFieldArray = [];
            var mandatoryRepeatFieldArray = [];
            var validaFlag = true;
            var repeatindData = null;
            switch (modalId) {
                case STT_CONSTANT.priceBreakDown:
                    mandatorySingleFieldArray = ['Section_Code', 'Section_Name'];
                    mandatoryRepeatFieldArray = ['Activity_Code', 'Activity_Name'];
                    repeatindData = $scope.modalData['Activity_Group']['Contract_Activities'];
                    break;
                case STT_CONSTANT.keyContractDates:
                    mandatorySingleFieldArray = ['Date_Type', 'Date_Ref', 'Date_Description', 'Key_Date', 'Planned_Completion_Date'];
                    break;
                case STT_CONSTANT.historicCEInfo:
                    mandatorySingleFieldArray = ["CE_Status"];
                    break;
            }

            validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

            if (repeatindData && validaFlag) {
                for (var k = 0; k < repeatindData.length; k++) {
                    if (validaFlag) {
                        validaFlag = checkFieldValueInObject(repeatindData[k], mandatoryRepeatFieldArray);
                    } else {
                        break;
                    }
                }
            }

            function checkFieldValueInObject(objectData, keyArray) {
                for (var index = 0; index < keyArray.length; index++) {
                    var element = keyArray[index];
                    var strElem = objectData[element];
                    if (!strElem) {
                        return false;
                    }
                }
                return true;
            }

            return validaFlag;
        }

        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false,
            scrollTop: 0
        };

        function showModal(id) {
            var body = document.body;
            var docElement = document.documentElement;
            ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            ctrl.model.modelId = id;

            $timeout(function(){
                var focusElem = $element.find('[autofocus]');
                focusElem[0] && focusElem[0].focus();
            })
        };

        function hideModal() {
            ctrl.model.modelId = '';

            $timeout(function(){
                var scrollObj = document.body
                if(scrollObj.scrollTop == 0){
                    scrollObj = document.documentElement;
                }

                scrollObj.scrollTop = ctrl.model.scrollTop;
            },200)
        }

        function editSectionModal(rowData) {
            $scope.openModal(STT_CONSTANT.priceBreakDown, rowData);
        }

        function editKeyContractModal(rowData) {
            $scope.openModal(STT_CONSTANT.keyContractDates, rowData);
        }

        function editIndexationModal(rowData) {
            $scope.openModal(STT_CONSTANT.indexation, rowData);
        }

        function editHistoricCEModal(rowData){
            $scope.openModal(STT_CONSTANT.historicCEInfo, rowData);
        }

        function editHistoricRiskInfoModal(rowData){
            $scope.openModal(STT_CONSTANT.historicRiskInfo, rowData);
        }

        var userListArray = {
            projectManager: [],
            superviser: [],
            tflAuthorisor: [],
            employerTeam: [],
            contractor: [],
            contractorTeamOth: [],
            draftOnly: []
        }
        initFormsData();

        $scope.updateCEpriceBasedOnStatus = function(){
            var ccDateRef = commonApi._.filter($scope.modalData['HD_CE_Key_Dates']['HD_CE_Key_Date'] , function(obj){
                return obj.HD_Key_Date_Ref == 'CC';
            });
            $scope.calcFieldTotal({ repData: $scope.modalData['HD_CE_ActivityCodes']['HD_CE_ActivityCode'], calcKey: 'HD_CE_Activity_Value', parObject: $scope.modalData, totalKey: 'tempHD_CE_Activity_Value' });
            $scope.calcFieldTotal({ repData: ccDateRef, calcKey: 'HD_Key_Date_Additions', parObject: $scope.modalData, totalKey: 'tempHD_Key_Date_Additions' });

            var tempStatus = $scope.modalData['CE_Status'];
            var tempAgreedFlg = $scope.modalData['CE_Agreed'];

            var unagreedVal = 0;
            var implementedVal = 0;
            var unagreedDays = 0;
            var implementedDays = 0;
            if(tempAgreedFlg == 'YES'){
                if(tempStatus == 'Open'){
                    unagreedVal = $scope.modalData['tempHD_CE_Activity_Value'];
                    unagreedDays = $scope.modalData['tempHD_Key_Date_Additions'];
                }else{
                    implementedVal = $scope.modalData['tempHD_CE_Activity_Value'];
                    implementedDays = $scope.modalData['tempHD_Key_Date_Additions'];
                }
            }

            $scope.modalData['CE_UA_Quot_Changes'] = unagreedVal;
            $scope.modalData['CE_IM_Cost_Changes'] = implementedVal;

            $scope.modalData['CE_Unagreed_Prog_Changes'] = unagreedDays;
            $scope.modalData['CE_IM_Prog_Changes'] = implementedDays;
        }

        $scope.agreedAsCEchanged = function(){
            var tempAgreedFlg = $scope.modalData['CE_Agreed'];
            if(tempAgreedFlg == 'NO'){
                $scope.modalData['CE_Status'] = 'Closed';
            }
            $scope.updateCEpriceBasedOnStatus();
        }

        $scope.contractChange = function(){
            $scope.oriMsgCustomFields['LINK_CONTRACT_NO'] = $scope.asiteSystemDataReadOnly['_4_Form_Type_Data']['DS_FORMGROUPCODE'] + $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_MAXORGFORMNO'] + '-' + $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields['ORI_USERREF'];
        }

        $scope.increasePriceChange = function(currRow){
            var isIncreasePrice = currRow['Increase_Price'];
            if(isIncreasePrice == 'No'){
                currRow['Projected_Price_Change'] = '';
            }
        }

        $scope.addActivtyIndex = function(currRow){
            
            for (var index = 0; index < $scope.sectionGroup['Sections'].length; index++) {
                var element = $scope.sectionGroup['Sections'][index];
                if(element.Section_Code == currRow.HD_CE_Section_Code){
                    currRow.ActIndex = index;
                    break;
                }
            }
        }

        $scope.setFormTitleAndSupplId = setFormTitleAndSupplId;

        function setFormTitleAndSupplId(){
            var tempContractorVal = $scope.oriMsgCustomFields['DS_PROJORGANISATIONS_ID'];
            var tempContractorName = tempContractorVal ? tempContractorVal.split('#')[1] : '';
            var tempContractorId = tempContractorVal ? tempContractorVal.split('#')[0] : '';
            $scope.data["myFields"]["Asite_System_Data_Read_Write"]["ORI_MSG_Fields"]["ORI_FORMTITLE"] = "Contract For - " + tempContractorName;
            $scope.oriMsgCustomFields['Supplier_Id'] = tempContractorId.trim();
        }

        $scope.resetSearchClause = function(){
            $scope.oriMsgCustomFields['Search_Criteria']['Clause_No_Filter'] = ''
            $scope.oriMsgCustomFields['Search_Criteria']['Clause_Desc_Filter'] = ''

            $scope.filterSearchClause();
        }

        $scope.filterSearchClause = function(){
            clauseFilterParam = {
                Clause_No: $scope.oriMsgCustomFields['Search_Criteria']['Clause_No_Filter'],
                Clause_Description: $scope.oriMsgCustomFields['Search_Criteria']['Clause_Desc_Filter']
            }

            $timeout(function(){
                $scope.expandTextAreaOnLoad();
            },100);
        }

        $scope.clauseFilter = function (strVal) {
            var strClauseNo = clauseFilterParam.Clause_No.toLowerCase();
            var strClauseDesc = clauseFilterParam.Clause_Description.toLowerCase();
            return (strVal.Clause_No.toLowerCase().indexOf(strClauseNo) > -1 && strVal.Clause_Description.toLowerCase().indexOf(strClauseDesc) > -1);
        }
        

        $scope.resetRiskRegFilter = function(){
            $scope.oriMsgCustomFields['Risk_Search_Criteria']['RDescription_Filter'] = "";
            $scope.oriMsgCustomFields['Risk_Search_Criteria']['RConsequences_Filter'] = "";
            $scope.oriMsgCustomFields['Risk_Search_Criteria']['RProbability_Filter'] = "";
            $scope.oriMsgCustomFields['Risk_Search_Criteria']['RStatus_Filter'] = "All";
            $scope.formCustomFields['Page_Sel_Risks'] = '';

            filterRikRegister();
        }
        $scope.filterRikRegister = filterRikRegister;
        function filterRikRegister(){
            var dataSourceName = STT_CONSTANT.dsSttNecContractRisksPaging;

            $scope.oriMsgCustomFields['TRisk_Search_Criteria']['TRDescription_Filter'] = $scope.oriMsgCustomFields['Risk_Search_Criteria']['RDescription_Filter'].toLowerCase();
            $scope.oriMsgCustomFields['TRisk_Search_Criteria']['TRConsequences_Filter'] = $scope.oriMsgCustomFields['Risk_Search_Criteria']['RConsequences_Filter'].toLowerCase();
            $scope.oriMsgCustomFields['TRisk_Search_Criteria']['TRProbability_Filter'] = $scope.oriMsgCustomFields['Risk_Search_Criteria']['RProbability_Filter'];
            $scope.oriMsgCustomFields['TRisk_Search_Criteria']['TRStatus_Filter'] = $scope.oriMsgCustomFields['Risk_Search_Criteria']['RStatus_Filter'] == 'All' ? '' : $scope.oriMsgCustomFields['Risk_Search_Criteria']['RStatus_Filter'];

            var riskPagingParam = $scope.oriMsgCustomFields['Risk_Search_Criteria']['RDescription_Filter'] + '|' +$scope.oriMsgCustomFields['Risk_Search_Criteria']['RConsequences_Filter'] + '|' +$scope.oriMsgCustomFields['Risk_Search_Criteria']['RProbability_Filter'] + '|' +$scope.oriMsgCustomFields['Risk_Search_Criteria']['RStatus_Filter'] + '|' + ($scope.formCustomFields['Page_Sel_Risks'] || '1-50');
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": riskPagingParam
                    }]
                }
            };

            if(document.URL.indexOf('adoddle') > 0){
                form["callerApp"] = 10;
            }

            $scope.requests[dataSourceName] = true;
            $scope.add({
                name: dataSourceName,
                status: "incomplete"
            });

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;

                $scope.requests[ dataSourceName ] = false;
                $scope.update({
                    name: dataSourceName,
                    status: "completed"
                });

                if(resData){
                    var spData = angular.fromJson(response.data[ dataSourceName ]);
                    spData = spData['Items']["Item"] || [];

                    $scope.dsAaiStdEcc4NecContractRisksPaging = spData;
                    countRiskRegisterDataTotal();
                }
            }, throwCallBackError);
        }

        $scope.resetTrackerFilter = function(){
            $scope.oriMsgCustomFields['TSearch_Criteria']['TSubject_Filter'] = "";
            $scope.oriMsgCustomFields['TSearch_Criteria']['TStatus_Filter'] = "All";
            $scope.oriMsgCustomFields['TSearch_Criteria']['TNotification_Type_Filter'] = "";
            $scope.oriMsgCustomFields['TSearch_Criteria']['TIs_CE_Filter'] = "";
            $scope.formCustomFields['Page_Sel'] = "";

            filterTrackerLog();
        }

        $scope.filterTrackerLog = filterTrackerLog;
        function filterTrackerLog(){
            var dataSourceInc = STT_CONSTANT.dsSttIncSummaryStatusPaging;
            var dataSourceNec = STT_CONSTANT.dsSttNecHdCeLogFiltered;
            var tmpFormField = dataSourceInc+','+dataSourceNec;

            var tmpTrackerParam = $scope.oriMsgCustomFields['TSearch_Criteria']['TSubject_Filter'] + '|' + $scope.oriMsgCustomFields['TSearch_Criteria']['TStatus_Filter'] + '|' + $scope.oriMsgCustomFields['TSearch_Criteria']['TNotification_Type_Filter'] + '|' + $scope.oriMsgCustomFields['TSearch_Criteria']['TIs_CE_Filter'] + '|' + ($scope.formCustomFields['Page_Sel'] || '1-50');
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": tmpFormField,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": tmpTrackerParam
                    },{
                        "fieldName": dataSourceNec,
                        "fieldValue": tmpTrackerParam
                    }]
                }
            };

            if(document.URL.indexOf('adoddle') > 0){
                form["callerApp"] = 10;
            }

            $scope.requests[ dataSourceInc ] = true;
            $scope.add({
                name: dataSourceInc,
                status: "incomplete"
            });

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;

                $scope.requests[ dataSourceInc ] = false;
                $scope.update({
                    name: dataSourceInc,
                    status: "completed"
                });

                if(resData){
                    var spDataSourceInc = angular.fromJson(response.data[ dataSourceInc ]);
                    spDataSourceInc = spDataSourceInc['Items']["Item"] || [];

                    var spDataSourceNec = angular.fromJson(response.data[ dataSourceNec ]);
                    spDataSourceNec = spDataSourceNec['Items']["Item"] || [];

                    $scope.dsAaiStdEcc4IncSymmaryStatusPaging = spDataSourceInc;
                    $scope.dsAsiStdEcc4NecHdCeLogFiltered = spDataSourceNec;

                    countTrackerDataTotal();
                }
            });
        }

        $scope.indexationCummuativeTotal = indexationCummuativeTotal;
        function indexationCummuativeTotal(tab) {
            var indexationArrayLength = $scope.indexationInfo['Indexation'].length;
            var tmpIndex = modelRowIndex > -1 ? modelRowIndex : indexationArrayLength;
            var objLength = tab == 'modal' ? tmpIndex+1 : tmpIndex;

            var tmpCummTotal = 0;
            for (var i = 0; i < objLength; i++) {
                if (tab != 'modal') {
                    tmpCummTotal += parseFloat($scope.indexationInfo['Indexation'][i]['PriceAdj_Value']) || 0;
                    $scope.indexationInfo['Indexation'][i]['PriceAdj_Cumulative'] = tmpCummTotal;
                } else if (i != tmpIndex ) {
                    tmpCummTotal += parseFloat($scope.indexationInfo['Indexation'][i]['PriceAdj_Value']) || 0;
                }
            }
            if (tab == 'modal') {
                tmpCummTotal += parseFloat($scope.modalData['PriceAdj_Value']) || 0;
                $scope.modalData['PriceAdj_Cumulative'] = tmpCummTotal;
            }
        }

        $scope.checkDuplicateActivityCode = function(currRow){
            var str = currRow.HD_CE_Section_Code + '|' + currRow.HD_CE_Activity_Code;

            for (var index = 0; index < $scope.modalData['HD_CE_ActivityCodes']['HD_CE_ActivityCode'].length; index++) {
                var element = $scope.modalData['HD_CE_ActivityCodes']['HD_CE_ActivityCode'][index];
                var tempStr = element.HD_CE_Section_Code + '|' + element.HD_CE_Activity_Code;
                if(currRow != element && str == tempStr){
                    currRow.HD_CE_Activity_Code = "";
                    $window.alert(STT_CONSTANT.validanDuplActCodeMsg);
                    break;
                }
            }
        }

        $scope.openLargeModal = function (viewId, rowData) {
            angular.element('.m-wrap .m-content').addClass('m-content--large');
            $scope.openModal(viewId, rowData, true)
        }

        $scope.openModal = function (viewId, rowData, isLargeModal) { // rowData used when user edit row , rowData come from table.util component as param
            if(!isLargeModal){
                angular.element('.m-wrap .m-content').removeClass('m-content--large');
            }
            modelRowIndex = -1;
            $scope.tempModalFlag = {};
            switch (viewId) {
                case STT_CONSTANT.priceBreakDown:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        var firstSecrionRow = $scope.sectionGroup['Sections'][0];
                        if(firstSecrionRow && (!firstSecrionRow['Section_Code'] || !firstSecrionRow['Section_Name']) ){
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstSecrionRow)
                        }else{
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Sections']);
                        }
                    }
                    break;
                case STT_CONSTANT.keyContractDates:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        var firstKeyMilestoneRow = $scope.keyMilestones['Key_Milestone'][0];
                        if(firstKeyMilestoneRow && !firstKeyMilestoneRow['Date_Type'] && !firstKeyMilestoneRow['Date_Ref']){
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstKeyMilestoneRow);
                        }else{
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Key_Milestone']);
                        }
                    }
                    $scope.tempModalFlag['index'] = modelRowIndex;
                    break;
                case STT_CONSTANT.indexation:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        var firstIndexationRow = $scope.indexationInfo['Indexation'][0] || STATIC_OBJ_DATA['Indexation'];
                        if(firstIndexationRow['PayAssess_No'] || firstIndexationRow['PayAssess_Date'] || firstIndexationRow['PriceAdj_Factor'] || firstIndexationRow['PriceAdj_Value'] || firstIndexationRow['PriceAdj_Cumulative']){
                            firstIndexationRow = angular.copy(STATIC_OBJ_DATA['Indexation']);
                        }else{
                            modelRowIndex = 0;
                        }
                        $scope.modalData = angular.copy(firstIndexationRow);
                    }
                    break;
                case STT_CONSTANT.historicRiskInfo:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        var firstHistoricRiskRow = $scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data'][0];
                        if(firstHistoricRiskRow && (!firstHistoricRiskRow['Risk_Id'] && !firstHistoricRiskRow['Risk_CreationDate'] && !firstHistoricRiskRow['Risk_User_Ref'] && !firstHistoricRiskRow['Risk_Description'] && !firstHistoricRiskRow['Risk_Consequences'] && !firstHistoricRiskRow['Risk_Section_Name'] && !firstHistoricRiskRow['Risk_Probability'] && !firstHistoricRiskRow['Risk_Actions'] && !firstHistoricRiskRow['Risk_Notes'] && !firstHistoricRiskRow['Projected_Price_Change'] && !firstHistoricRiskRow['Projected_Prog_Change'] && !firstHistoricRiskRow['Risk_Incident']) ){
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstHistoricRiskRow);
                        }else{
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Historic_Risk_Data']);
                        }

                        $scope.modalData['Risk_Status'] = 'Closed';
                    }
                    break;
                case STT_CONSTANT.historicCEInfo:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        var firstHistoricCERow = $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'][0];
                        if(firstHistoricCERow && !firstHistoricCERow['CE_Status']  ){
                            modelRowIndex = 0;
                            $scope.modalData = angular.copy(firstHistoricCERow);
                        }else{
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA['Historic_CE_Data']);
                        }
                    }
                    break;
                case STT_CONSTANT.managementTeam:
                    $scope.modalData = {
                        tempUserList : [],
                        projectManager : userListArray.projectManager,
                        superviser : userListArray.superviser,
                        tflAuthorisor : userListArray.tflAuthorisor,
                        employerTeam : userListArray.employerTeam,
                        contractor : userListArray.contractor,
                        contractorTeamOth : userListArray.contractorTeamOth,
                        draftOnly : userListArray.draftOnly
                    }
                    break;
            }


            showModal(viewId)
        }

        $scope.isItemModalOpen = false;
        $scope.openItemModal = function (event, userListId) {

            $scope.projUsersList = getItemSelectionList(dsProjDistUsers, '', 'Value', 'Name');

            $scope.projUsersName = angular.copy(userListArray[userListId]);

            $timeout(function () {
                $scope.isItemModalOpen = true;
                var currTD = event.target;
                var allOffset = currTD.getBoundingClientRect();
                var body = document.body;
                var docElement = document.documentElement;
                var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
                var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;

                var top = allOffset.top + vDiff;
                var left = allOffset.left + hDiff;

                $timeout(function () {
                    currentListFocus = userListId;

                    var itmModalObj = document.getElementById('nec4-item-modal');
                    itmModalObj.style.top = top + 'px';
                    itmModalObj.style.left = left + 'px';
                });
            });

        }

        function hideItemModal() {
            $scope.isItemModalOpen = false;
            currentListFocus = '';
        }

        $scope.addUserToRoleList = function(usrObj,listName){
            if (usrObj) {
                var userToAdd = angular.copy( usrObj );
                var newTempList= $scope.modalData[listName].concat(userToAdd);
                $scope.modalData[listName] = commonApi._.unique(newTempList);
            }    
        }

        $scope.removeUserFromRoleList = function(index,listObj, isTempUsers){
            listObj.splice(index, 1);

            if(isTempUsers){
                $scope.projUsersList = getItemSelectionList(dsProjDistUsers, '', 'Value', 'Name'); 
            }
        }

        $scope.resetUserList = function(listObj){
            
            for (var index = 0; index < listObj.length; index++) {
                $scope.removeUserFromRoleList(index,listObj, true);
            }
            
            if(listObj.length){
                $scope.resetUserList(listObj);
            }else{
                $scope.projUsersList = getItemSelectionList(dsProjDistUsers, '', 'Value', 'Name');
            }
        }

        $document.on('click', function (event) {
            var itmModalObj = document.getElementById('nec4-item-modal');
            var itemContainerObj = document.querySelectorAll('.item-selection.drop-show')[0];
            if (event && itmModalObj && !itmModalObj.contains(event.target) && !itemContainerObj.contains(event.target)) {
                hideItemModal();
            }
        });

        function setViewHTMLdata(isOnLoad){
            if(isOnLoad){

                var tempProjMangerArray = commonApi._.map($scope.oriMsgCustomFields.All_Project_Managers.Project_Managers, function(obj){
                    return obj.Project_Manager;
                }).filter(function(itm){
                    return itm != ''
                });
    
                var tempSuperviserArray = commonApi._.map($scope.oriMsgCustomFields.All_Supervisors.Supervisors, function(obj){
                    return obj.Supervisor;
                }).filter(function(itm){
                    return itm != ''
                });

                if ($scope.oriMsgCustomFields.All_TflAuthorisors) {
                    var tempTflAuthorisorArray = commonApi._.map($scope.oriMsgCustomFields.All_TflAuthorisors.TflAuthorisors, function(obj){
                        return obj.TflAuthorisor;
                    }).filter(function(itm){
                        return itm != ''
                    });
                }                    
    
                var tempAllEmpOthArray = commonApi._.map($scope.oriMsgCustomFields.All_Emp_Others.Emp_Others, function(obj){
                    return obj.Emp_Other;
                }).filter(function(itm){
                    return itm != ''
                });
    
                var tempContractorArray = commonApi._.map($scope.oriMsgCustomFields.Assistant_Project_Managers.Assistant_Project_Manager, function(obj){
                    return obj.Assistant_PM;
                }).filter(function(itm){
                    return itm != ''
                });
    
                var tempContractorTeamOthArray = commonApi._.map($scope.oriMsgCustomFields.All_Con_Others.Con_Others, function(obj){
                    return obj.Con_Other;
                }).filter(function(itm){
                    return itm != ''
                });
    
                var tempDraftOnlyArray = commonApi._.map($scope.oriMsgCustomFields.Drafts_Only.Draft_Users, function(obj){
                    return obj.Draft_User;
                }).filter(function(itm){
                    return itm != ''
                });
                userListArray ={
                    projectManager: tempProjMangerArray,
                    superviser: tempSuperviserArray,
                    tflAuthorisor: tempTflAuthorisorArray,
                    employerTeam: tempAllEmpOthArray,
                    contractor: tempContractorArray,
                    contractorTeamOth: tempContractorTeamOthArray,
                    draftOnly: tempDraftOnlyArray
                }
            }

            setDisplayUserHTMLData('projectManager');
            setDisplayUserHTMLData('superviser');
            if ($scope.oriMsgCustomFields.All_TflAuthorisors) {
                setDisplayUserHTMLData('tflAuthorisor');
            }    
            setDisplayUserHTMLData('employerTeam');
            setDisplayUserHTMLData('contractor');
            setDisplayUserHTMLData('contractorTeamOth');
            setDisplayUserHTMLData('draftOnly');

        }
        
        function setDisplayUserHTMLData(currentListFocus){
            var tempList = '';
            for (var index = 0; index < userListArray[currentListFocus].length; index++) {
                var element = userListArray[currentListFocus][index];
                tempList += (index + 1) + '. &nbsp;' + element.split('#')[1] + '<br/>';
            }
            $scope.displayUserListHTML[currentListFocus] = tempList;
        }

        function setDataInManagementTeam(teamName) {
            switch (teamName) {
                case 'projectManager':
                    var projectManager = userListArray.projectManager;
                    var tempProjMangerArray = [];
                    for (var i = 0; i < projectManager.length; i++) {
                        var element = projectManager[i];
                        var tempProjMangerNode = angular.copy(STATIC_OBJ_DATA.Project_Managers)
                        tempProjMangerNode.Project_Manager = element;
                        tempProjMangerNode.PM_Name = element.split('#')[1].trim();
                        tempProjMangerArray.push(tempProjMangerNode);
                    }
                    $scope.oriMsgCustomFields.All_Project_Managers.Project_Managers = angular.copy(tempProjMangerArray);
                    break;
                case 'superviser':
                    var superviser = userListArray.superviser;
                    var tempSuperviserArray = [];
                    for (var i = 0; i < superviser.length; i++) {
                        var element = superviser[i];
                        var tempSupervisorsNode = angular.copy(STATIC_OBJ_DATA.Supervisors)
                        tempSupervisorsNode.Supervisor = element;
                        tempSupervisorsNode.Supervisor_Name = element.split('#')[1].trim();
                        tempSuperviserArray.push(tempSupervisorsNode);
                    }
                    $scope.oriMsgCustomFields.All_Supervisors.Supervisors = angular.copy(tempSuperviserArray);
                    break;
                case 'tflAuthorisor':
                    var tflAuthorisor = userListArray.tflAuthorisor;
                    var temptflAuthorisorArray = [];
                    for (var i = 0; i < tflAuthorisor.length; i++) {
                        var element = tflAuthorisor[i];
                        var tempTflAuthorisorsNode = angular.copy(STATIC_OBJ_DATA.TflAuthorisors)
                        tempTflAuthorisorsNode.TflAuthorisor = element;
                        tempTflAuthorisorsNode.TflAuthorisor_Name = element.split('#')[1].trim();
                        temptflAuthorisorArray.push(tempTflAuthorisorsNode);
                    }
                    $scope.oriMsgCustomFields.All_TflAuthorisors.TflAuthorisors = angular.copy(temptflAuthorisorArray);
                    break;
                case 'employerTeam':
                    var employerTeam = userListArray.employerTeam;
                    var tempAllEmpOthArray = [];
                    for (var i = 0; i < employerTeam.length; i++) {
                        var element = employerTeam[i];
                        var tempAllEmpOthNode = angular.copy(STATIC_OBJ_DATA.Emp_Others)
                        tempAllEmpOthNode.Emp_Other = element;
                        tempAllEmpOthNode.Emp_Other_Name = element.split('#')[1].trim();
                        tempAllEmpOthArray.push(tempAllEmpOthNode);
                    }
                    $scope.oriMsgCustomFields.All_Emp_Others.Emp_Others = angular.copy(tempAllEmpOthArray);
                    break;
                case 'contractor':
                    var contractor = userListArray.contractor;
                    var tempContractorArray = [];
                    for (var i = 0; i < contractor.length; i++) {
                        var element = contractor[i];
                        var tempContractorNode = angular.copy(STATIC_OBJ_DATA.Assistant_Project_Manager)
                        tempContractorNode.Assistant_PM = element;
                        tempContractorNode.APM_Name = element.split('#')[1].trim();
                        tempContractorArray.push(tempContractorNode);
                    }
                    $scope.oriMsgCustomFields.Assistant_Project_Managers.Assistant_Project_Manager = angular.copy(tempContractorArray);
                    break;
                case 'contractorTeamOth':
                    var contractorTeamOth = userListArray.contractorTeamOth;
                    var tempContractorTeamOthArray = [];
                    for (var i = 0; i < contractorTeamOth.length; i++) {
                        var element = contractorTeamOth[i];
                        var tempContractorTeamOthNode = angular.copy(STATIC_OBJ_DATA.Assistant_Project_Manager)
                        tempContractorTeamOthNode.Con_Other = element;
                        tempContractorTeamOthNode.Con_Other_Name = element.split('#')[1].trim();
                        tempContractorTeamOthArray.push(tempContractorTeamOthNode);
                    }
                    $scope.oriMsgCustomFields.All_Con_Others.Con_Others = angular.copy(tempContractorTeamOthArray);
                    break;
                case 'draftOnly':
                    var draftOnly = userListArray.draftOnly;
                    var tempDraftOnlyArray = [];
                    for (var i = 0; i < draftOnly.length; i++) {
                        var element = draftOnly[i];
                        var tempDraftOnlyNode = angular.copy(STATIC_OBJ_DATA.Draft_Users)
                        tempDraftOnlyNode.Draft_User = element;
                        tempDraftOnlyNode.Draft_User_Name = element.split('#')[1].trim();
                        tempDraftOnlyArray.push(tempDraftOnlyNode);
                    }
                    $scope.oriMsgCustomFields.Drafts_Only.Draft_Users = angular.copy(tempDraftOnlyArray);
                    break;
            }
        }

        function calculateCEHDAdditions_KeyDates(){
            resetAllKeyDateTotals();

            var allHistoricCEData = $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'];

            for (var index = 0; index < $scope.keyMilestones['Key_Milestone'].length; index++) {
                var keyMilestoneObj = $scope.keyMilestones['Key_Milestone'][index];
                var strKey_Date_Id = keyMilestoneObj['Key_Date_Id'];

                var iHKD_Additions = 0;
                var iHKD_Anti_Additions = 0;

                for (var k = 0; k < allHistoricCEData.length; k++) {
                    var ceObj = allHistoricCEData[k];
                    var hdCeKeyDates = ceObj.HD_CE_Key_Dates.HD_CE_Key_Date;

                    var strTmpCEStatus = ceObj["CE_Status"];
                    var strTmpIsCE = ceObj["CE_Agreed"];

                    for (var i = 0; i < hdCeKeyDates.length; i++) {
                        var hdCeDateObj = hdCeKeyDates[i];
                        if( hdCeDateObj.HD_Key_Date_Id == strKey_Date_Id ){
                            var iTmpValue = hdCeDateObj.HD_Key_Date_Additions;
    
                            if (strTmpCEStatus.toLowerCase() == "closed" && strTmpIsCE.toLowerCase() == "yes")
                            {
                                iHKD_Additions += iTmpValue;
                                keyMilestoneObj["HKD_Additions"] = iHKD_Additions;
                            }
                            else if (strTmpCEStatus.toLowerCase() != "closed" && strTmpIsCE.toLowerCase() == "yes")
                            {
                                iHKD_Anti_Additions += iTmpValue;
                                keyMilestoneObj["HKD_Anti_Additions"] = iHKD_Anti_Additions;
                            }
                        }
                    }
                    
                }
                
            }
        }

        function calculateCEInfoTotal(){
            $timeout(function(){
                $scope.calcFieldTotal({ repData: $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], calcKey: 'CE_UA_Quot_Changes', parObject: $scope.oriMsgCustomFields['Historic_CE_Information'], totalKey: 'tempCE_UA_Quot_Changes' });
                $scope.calcFieldTotal({ repData: $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], calcKey: 'CE_Unagreed_Prog_Changes', parObject: $scope.oriMsgCustomFields['Historic_CE_Information'], totalKey: 'tempCE_Unagreed_Prog_Changes' });
                $scope.calcFieldTotal({ repData: $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], calcKey: 'CE_IM_Cost_Changes', parObject: $scope.oriMsgCustomFields['Historic_CE_Information'], totalKey: 'tempCE_IM_Cost_Changes' });
                $scope.calcFieldTotal({ repData: $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], calcKey: 'CE_IM_Prog_Changes', parObject: $scope.oriMsgCustomFields['Historic_CE_Information'], totalKey: 'tempCE_IM_Prog_Changes' });
    
                calculateCEHDAdditions(true);
                calculateCEHDAdditions_KeyDates();
            })

        }

        function calculateCEHDAdditions(reInitNodes){
            if(reInitNodes){
                resetAllActTotals("CE");
            }

            var allCEData = $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'];
            var allSectionsData = $scope.sectionGroup['Sections'];

            for (var i = 0; i < allCEData.length; i++) {
                var ceObj = allCEData[i];
                var strTmpCEStatus = ceObj.CE_Status;
                var strTmpIsCE = ceObj.CE_Agreed;
                var allCEActivityCode = ceObj.HD_CE_ActivityCodes.HD_CE_ActivityCode;
                
                for (var j = 0; j < allCEActivityCode.length; j++) {
                    var ceActObj = allCEActivityCode[j];
                    var strTmpSectionCode = ceActObj.HD_CE_Section_Code;
                    var strTmpCostCode = ceActObj.HD_CE_Activity_Code;
                    var dblTmpValue =  parseFloat( ceActObj.HD_CE_Activity_Value ) || 0;                    
                    

                    for (var index = 0; index < allSectionsData.length; index++) {
                        var allActivityNode = allSectionsData[index]['Activity_Group']['Contract_Activities'];
                        for (var k = 0; k < allActivityNode.length; k++) {
                            var tmpSectionCode = allActivityNode[k].CSection_Code;
                            var tmpActiviyCode = allActivityNode[k].Activity_Code;
                            if(tmpSectionCode == strTmpSectionCode && tmpActiviyCode == strTmpCostCode){
                                
                                allActivityNode[k].HTotal_Additions = parseFloat( allActivityNode[k].HTotal_Additions ) || 0;
                                allActivityNode[k].HAnticipated_Additions = parseFloat( allActivityNode[k].HAnticipated_Additions ) || 0;
        
                                if( strTmpCEStatus.toLowerCase() == 'closed' && strTmpIsCE.toLowerCase() == "yes"){
                                    allActivityNode[k].HTotal_Additions = allActivityNode[k].HTotal_Additions + dblTmpValue;
                                }else if( strTmpCEStatus.toLowerCase() != 'closed' && strTmpIsCE.toLowerCase() == "yes"){
                                    allActivityNode[k].HAnticipated_Additions = allActivityNode[k].HAnticipated_Additions + dblTmpValue;
                                }                            
                            }
                        }
                    }

                }
            }

        }

        function resetAllActTotals(strType){
            var allSectionsData = $scope.sectionGroup['Sections'];

            for (var i = 0; i < allSectionsData.length; i++) {
                var allActionNodes = allSectionsData[i]['Activity_Group']['Contract_Activities'];
                for (var k = 0; k < allActionNodes.length; k++) {
                    var tempContAct = allActionNodes[k];
                    if(strType == 'CFN'){
                        tempContAct['HFees_Received'] = '0';
                    }
                    else if( strType == 'CE'){
                        tempContAct['HTotal_Additions'] = '0';
                        tempContAct['HAnticipated_Additions'] = '0';
                    }
                    
                }
            }
        }

        function resetAllKeyDateTotals(){
            for (var index = 0; index < $scope.keyMilestones['Key_Milestone'].length; index++) {
                var element = $scope.keyMilestones['Key_Milestone'][index];
                element['HKD_Additions'] = 0;
                element['HKD_Anti_Additions'] = 0;                
            }
        }


        /***** Initialize db fields ******/

        function initFormsData() {
            $scope.setCurrentSection(STT_CONSTANT.contractDetailsTab);

            $scope.dbFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
            $scope.isDraftEditOri = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_EDITORI'] == 'NO' ? false : true;
            $scope.isDraft = $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.DS_ISDRAFT == 'NO' ? false : true;

            if(!$scope.dbFormId || $scope.isDraft){
                setImportNodes();
            }

            setUniqueStringPMs();

            $scope.projUsersList = getItemSelectionList(dsProjDistUsers, '', 'Value', 'Name');

            if($scope.dbFormId && !$scope.isDraft && !$scope.isDraftEditOri){
                $scope.dsAsiStdEcc4NecContractActivitySummary = $scope.getValueOfOnLoadData(STT_CONSTANT.dsSttNecContractActivitySummary);

                updateUsedFlag();
                calculateAllAdditions();
            }

            var ds_Asi_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            $scope.currencyArray = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val) {
                return val.Value3.indexOf('Currency') != -1 && val.Value11.indexOf('Active') != -1;
            });
            $scope.displayUserListHTML = {
                projectManager: '',
                superviser: '',
                TflAuthorisor: '',
                employerTeam: '',
                contractor: '',
                contractorTeamOth: '',
                draftOnly: ''
            }
            setViewHTMLdata(true);

            if (currentViewName == "ORI_PRINT_VIEW") {
                $scope.isUserPM = $scope.formCustomFields['All_PMs'] ? $scope.formCustomFields['All_PMs'].indexOf(dsWorkingUserId) : -1;
                var tempDsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
                if (tempDsWorkingUserId[0]) {
                    tempDsWorkingUserId = tempDsWorkingUserId[0].Value;
                    $scope.isDsClient = tempDsWorkingUserId ? tempDsWorkingUserId.indexOf( $scope.asiteSystemDataReadOnly._3_Project_Data.DS_CLIENT ) : -1
                }
                $scope.isContractA = $scope.oriMsgCustomFields['CONTRACT_FORM'] == STT_CONSTANT.contractEccA;


                var tempTotalAdditions = 0;
                var tempEWNPriceIncNo = 0;
                var tempAnticipatedAdditions = 0
                var tempRevisedTotalOfPrices = 0;
                var tempPriceAdjustmentForInflation = 0;
                var tempUnagreedAdditionsTotal = 0;
                var tempPMAdjustmentTotal = 0;
                var tempEWNAdditionsTotal = 0;
                var tempProjectedTotalOfPrices = 0;
                var tempProjectedTotalOfPricesIncInfation = 0;
                var tempEwnWoQuotation = 0;


                var allSectionsData = $scope.sectionGroup['Sections'];
                var allHistoricRiskData = angular.copy($scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data']);

                var grandSectionTotalObject = {
                    Activity_Value: 0,
                    Total_Additions: 0,
                    Unagreed_Additions: 0,
                    PM_Estimated: 0,
                    PM_Adjustment: 0,
                    EWN_Additions: 0,
                    Anticipated_Additions: 0,
                    EWN_wo_Quotation: 0
                }
                var tempGrandSectionTotalObject = angular.copy(grandSectionTotalObject);
                for (var index = 0; index < allSectionsData.length; index++) {
                    var contractActivities = allSectionsData[index]['Activity_Group']['Contract_Activities'];

                    var tempAllContractActivityTotal = angular.copy(grandSectionTotalObject);

                    for (var k = 0; k < contractActivities.length; k++) {

                        contractActivities[k]['Activity_Value'] = (parseFloat(contractActivities[k]['Activity_Value']) || 0);
                        contractActivities[k]['Total_Additions'] = (parseFloat(contractActivities[k]['Total_Additions']) || 0);
                        contractActivities[k]['Unagreed_Additions'] = (parseFloat(contractActivities[k]['Unagreed_Additions']) || 0);
                        contractActivities[k]['PM_Estimated'] = (parseFloat(contractActivities[k]['PM_Estimated']) || 0);
                        contractActivities[k]['PM_Adjustment'] = (parseFloat(contractActivities[k]['PM_Adjustment']) || 0);
                        contractActivities[k]['EWN_Additions'] = (parseFloat(contractActivities[k]['EWN_Additions']) || 0);
                        contractActivities[k]['Anticipated_Additions'] = (parseFloat(contractActivities[k]['Anticipated_Additions']) || 0);
                        contractActivities[k]['EWN_wo_Quotation'] = (parseFloat(contractActivities[k]['EWN_wo_Quotation']) || 0);
                        contractActivities[k]['EWN_PriceIncNo'] = (parseFloat(contractActivities[k]['EWN_PriceIncNo']) || 0);


                        tempAllContractActivityTotal['Activity_Value'] = tempAllContractActivityTotal['Activity_Value'] + contractActivities[k]['Activity_Value'];
                        tempAllContractActivityTotal['Total_Additions'] = tempAllContractActivityTotal['Total_Additions'] + contractActivities[k]['Total_Additions'];
                        tempAllContractActivityTotal['Unagreed_Additions'] = tempAllContractActivityTotal['Unagreed_Additions'] + contractActivities[k]['Unagreed_Additions'];
                        tempAllContractActivityTotal['PM_Estimated'] = tempAllContractActivityTotal['PM_Estimated'] + contractActivities[k]['PM_Estimated'];
                        tempAllContractActivityTotal['PM_Adjustment'] = tempAllContractActivityTotal['PM_Adjustment'] + contractActivities[k]['PM_Adjustment'];
                        tempAllContractActivityTotal['EWN_Additions'] = tempAllContractActivityTotal['EWN_Additions'] + contractActivities[k]['EWN_Additions'];
                        tempAllContractActivityTotal['Anticipated_Additions'] = tempAllContractActivityTotal['Anticipated_Additions'] + contractActivities[k]['Anticipated_Additions'];
                        tempAllContractActivityTotal['EWN_wo_Quotation'] = tempAllContractActivityTotal['EWN_wo_Quotation'] + contractActivities[k]['EWN_wo_Quotation'];

                        tempEwnWoQuotation = tempEwnWoQuotation + contractActivities[k]['EWN_wo_Quotation'];
                        tempAnticipatedAdditions = tempAnticipatedAdditions + contractActivities[k]['Anticipated_Additions'];

                        tempEWNPriceIncNo = tempEWNPriceIncNo + contractActivities[k]['EWN_PriceIncNo'];

                        tempTotalAdditions = tempTotalAdditions + contractActivities[k]['Total_Additions'];

                        tempRevisedTotalOfPrices = tempRevisedTotalOfPrices + contractActivities[k]['Activity_Value'] + contractActivities[k]['Total_Additions'];

                        tempUnagreedAdditionsTotal = tempUnagreedAdditionsTotal + contractActivities[k]['Unagreed_Additions'];
                        tempPMAdjustmentTotal = tempPMAdjustmentTotal + contractActivities[k]['PM_Adjustment'];
                        tempEWNAdditionsTotal = tempEWNAdditionsTotal + contractActivities[k]['EWN_Additions'];

                        tempProjectedTotalOfPrices = tempProjectedTotalOfPrices + contractActivities[k]['Activity_Value'] + contractActivities[k]['Total_Additions'] + contractActivities[k]['Unagreed_Additions'] + contractActivities[k]['PM_Adjustment'] + contractActivities[k]['EWN_Additions'];
                    }

                    allSectionsData[index]['sectionTotalObject'] = angular.copy(tempAllContractActivityTotal);

                    tempGrandSectionTotalObject['Activity_Value'] = tempGrandSectionTotalObject['Activity_Value'] + tempAllContractActivityTotal['Activity_Value'];
                    tempGrandSectionTotalObject['Total_Additions'] = tempGrandSectionTotalObject['Total_Additions'] + tempAllContractActivityTotal['Total_Additions'];
                    tempGrandSectionTotalObject['Unagreed_Additions'] = tempGrandSectionTotalObject['Unagreed_Additions'] + tempAllContractActivityTotal['Unagreed_Additions'];
                    tempGrandSectionTotalObject['PM_Estimated'] = tempGrandSectionTotalObject['PM_Estimated'] + tempAllContractActivityTotal['PM_Estimated'];
                    tempGrandSectionTotalObject['PM_Adjustment'] = tempGrandSectionTotalObject['PM_Adjustment'] + tempAllContractActivityTotal['PM_Adjustment'];
                    tempGrandSectionTotalObject['EWN_Additions'] = tempGrandSectionTotalObject['EWN_Additions'] + tempAllContractActivityTotal['EWN_Additions'];
                    tempGrandSectionTotalObject['Anticipated_Additions'] = tempGrandSectionTotalObject['Anticipated_Additions'] + tempAllContractActivityTotal['Anticipated_Additions'];
                    tempGrandSectionTotalObject['EWN_wo_Quotation'] = tempGrandSectionTotalObject['EWN_wo_Quotation'] + tempAllContractActivityTotal['EWN_wo_Quotation'];
                }

                $scope.sectionGroup['Sections'].grandSectionTotalObject = angular.copy(tempGrandSectionTotalObject);

                var tempProjectedPriceChange = 0;
                var tempProjectedPriceChangeWithNo = 0;
                for (var i = 0; i < allHistoricRiskData.length; i++) {
                    var riskObj = allHistoricRiskData[i];
                    if (riskObj['Risk_Status'] != 'Closed' && riskObj['Increase_Price'] == 'Yes') {
                        tempProjectedPriceChange = tempProjectedPriceChange + (parseFloat(riskObj['Projected_Price_Change']) || 0);
                    } else if (riskObj['Risk_Status'] != 'Closed' && riskObj['Increase_Price'] == 'No') {
                        tempProjectedPriceChangeWithNo = tempProjectedPriceChangeWithNo + (parseFloat(riskObj['Projected_Price_Change']) || 0);
                    }
                }

                tempEWNAdditionsTotal = tempEWNAdditionsTotal + tempProjectedPriceChange;
                tempProjectedTotalOfPrices = tempProjectedTotalOfPrices + tempProjectedPriceChange;


                for (var i = 0; i < $scope.indexationInfo['Indexation'].length; i++) {
                    var indObj = $scope.indexationInfo['Indexation'][i];
                    tempPriceAdjustmentForInflation = tempPriceAdjustmentForInflation + (parseFloat(indObj['PriceAdj_Value']) || 0);
                }

                $scope.indexationInfo['Proj_Adj_Inflation'] = (parseFloat($scope.indexationInfo['Proj_Adj_Inflation']) || 0)
                tempProjectedTotalOfPricesIncInfation = tempProjectedTotalOfPrices + tempPriceAdjustmentForInflation;
                tempProjectedTotalOfPricesIncInfation = tempProjectedTotalOfPricesIncInfation + $scope.indexationInfo['Proj_Adj_Inflation'] + tempEwnWoQuotation;


                $scope.totalAdditions = tempTotalAdditions;
                $scope.revisedTotalOfPrices = tempRevisedTotalOfPrices;
                $scope.priceAdjustmentForInflation = tempPriceAdjustmentForInflation;

                $scope.unagreedAdditionsTotal = tempUnagreedAdditionsTotal;
                $scope.ewnWoQuotation = tempEwnWoQuotation;
                $scope.pmAdjustmentTotal = tempPMAdjustmentTotal;
                $scope.ewnAdditionsTotal = tempEWNAdditionsTotal;
                $scope.projectedTotalOfPrices = tempProjectedTotalOfPrices;
                $scope.projectedTotalOfPricesIncInfation = tempProjectedTotalOfPricesIncInfation;

                $scope.anticipatedAdditions = tempAnticipatedAdditions;
                $scope.projectedPriceChange = tempProjectedPriceChange;
                $scope.projectedPriceChangeWithNo = tempProjectedPriceChangeWithNo;
                $scope.ewnPriceIncNo = tempEWNPriceIncNo;

                $scope.dsAsiStdECC4KeyDatesSummary = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttKeyDatesSummary );
                $scope.dsAaiStdEcc4NecContractSummary = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttNecContractSummary );
                $scope.dsAaiStdEcc4NecContractRisksPaging = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttNecContractRisksPaging );
                $scope.dsAaiStdEcc4IncSymmaryStatusPaging = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttIncSummaryStatusPaging );
                $scope.dsAsiStdEcc4NecHdCeLogFiltered = $scope.getValueOfOnLoadData( STT_CONSTANT.dsSttNecHdCeLogFiltered );

                countTrackerDataTotal();
                countRiskRegisterDataTotal();

                var contractSummaryVal38 = 0;
                var contractSummaryVal39 = 0;
                if($scope.dsAaiStdEcc4NecContractSummary[0]){
                    $scope.dsAaiStdEcc4NecContractSummary[0]['Value28'] = parseFloat( $scope.dsAaiStdEcc4NecContractSummary[0]['Value28'] ) || 0;
                    $scope.dsAaiStdEcc4NecContractSummary[0]['Value29'] = parseFloat( $scope.dsAaiStdEcc4NecContractSummary[0]['Value29'] ) || 0;
                    
                    contractSummaryVal38 = $scope.dsAaiStdEcc4NecContractSummary[0]['Value38'];
                    contractSummaryVal39 = $scope.dsAaiStdEcc4NecContractSummary[0]['Value39'];
                }

                $scope.nextProgramSubmissionClass = '';
                if (contractSummaryVal38 == 1 && contractSummaryVal39 == 0) {
                    $scope.nextProgramSubmissionClass = 'red-font';
                } else if (contractSummaryVal38 == 2 && contractSummaryVal39 == 0) {
                    $scope.nextProgramSubmissionClass = 'blue-bg white-font';
                } else if (contractSummaryVal38 == 3 && contractSummaryVal39 == 0) {
                    $scope.nextProgramSubmissionClass = 'green-bg white-font';
                } else if (contractSummaryVal38 == 0 && contractSummaryVal39 == 1) {
                    $scope.nextProgramSubmissionClass = 'light-blue-bg white-font';
                } else if (contractSummaryVal38 == 1 && contractSummaryVal39 == 1) {
                    $scope.nextProgramSubmissionClass = 'yellow-font';
                } else if (contractSummaryVal38 == 2 && contractSummaryVal39 == 1) {
                    $scope.nextProgramSubmissionClass = 'white-font light-red-bg';
                } else if (contractSummaryVal38 == 3 && contractSummaryVal39 == 1) {
                    $scope.nextProgramSubmissionClass = 'vialot-bg white-font';
                }

                var tempKPIPayments = 0;
                var tempPotentialLiqDamages = 0;
                $scope.keyDateValue5 = 0;
                var keyDateValue11 = 0;
                var keyDateValue12 = 0;

                var tempKeyDateSummaryTotal = {
                    Value5: 0,
                    Value5Val2EQ1: 0,
                    Value6: 0,
                    Value9: 0,
                    Value19: 0,
                    Value10: 0,
                    Value11: 0,
                    Value12: 0,
                    Value17: 0,
                    Value18: 0
                }
                for (var i = 0; i < $scope.dsAsiStdECC4KeyDatesSummary.length; i++) {
                    var keySummary = $scope.dsAsiStdECC4KeyDatesSummary[i];
                    keySummary['Value5'] = (parseFloat(keySummary['Value5']) || 0);
                    keySummary['Value6'] = (parseFloat(keySummary['Value6']) || 0);
                    keySummary['Value10'] = (parseFloat(keySummary['Value10']) || 0);
                    keySummary['Value11'] = (parseFloat(keySummary['Value11']) || 0);
                    keySummary['Value12'] = (parseFloat(keySummary['Value12']) || 0);
                    keySummary['Value17'] = (parseFloat(keySummary['Value17']) || 0);
                    keySummary['Value18'] = (parseFloat(keySummary['Value18']) || 0);
                    keySummary['Value14'] = (parseFloat(keySummary['Value14']) || 0);
                    keySummary['Value9'] = (parseFloat(keySummary['Value9']) || 0);
                    keySummary['Value19'] = (parseFloat(keySummary['Value19']) || 0);

                    tempKeyDateSummaryTotal['Value5'] = tempKeyDateSummaryTotal['Value5'] + keySummary['Value5'];
                    tempKeyDateSummaryTotal['Value6'] = tempKeyDateSummaryTotal['Value6'] + keySummary['Value6'];
                    tempKeyDateSummaryTotal['Value9'] = tempKeyDateSummaryTotal['Value9'] + keySummary['Value9'];
                    tempKeyDateSummaryTotal['Value19'] = tempKeyDateSummaryTotal['Value19'] + keySummary['Value19'];
                    tempKeyDateSummaryTotal['Value10'] = tempKeyDateSummaryTotal['Value10'] + keySummary['Value10'];
                    tempKeyDateSummaryTotal['Value11'] = tempKeyDateSummaryTotal['Value11'] + keySummary['Value11'];
                    tempKeyDateSummaryTotal['Value12'] = tempKeyDateSummaryTotal['Value12'] + keySummary['Value12'];
                    tempKeyDateSummaryTotal['Value17'] = tempKeyDateSummaryTotal['Value17'] + keySummary['Value17'];
                    tempKeyDateSummaryTotal['Value18'] = tempKeyDateSummaryTotal['Value18'] + keySummary['Value18'];


                    if (keySummary['Value2'] == '1') {
                        $scope.unagreedQuatationChange = keySummary['Value6'];
                        $scope.pmAdjusToProjProgChange = keySummary['Value10'];
                        $scope.anticipatedDelays = keySummary['Value12'];
                        $scope.variance = keySummary['Value14'];
                        $scope.incidentsAwaitingQuotation = keySummary['Value19'];

                        tempKPIPayments = tempKPIPayments + keySummary['Value17'];
                        tempPotentialLiqDamages = tempPotentialLiqDamages + keySummary['Value18'];

                        keyDateValue11 = keySummary['Value11'];
                        keyDateValue12 = keySummary['Value12'];
                        $scope.keyDateValue5 = keySummary['Value5'];

                        tempKeyDateSummaryTotal['Value5Val2EQ1'] = tempKeyDateSummaryTotal['Value5Val2EQ1'] + keySummary['Value5'];

                        if (keySummary['Name'].indexOf('Contract Completion') > -1) {
                            $scope.ewnChangesDays = keyDateValue11;
                        }
                    }

                    keySummary['revisedComplDate'] = addDaysInDate(keySummary['Value4'], keySummary['Value5']);
                    keySummary['projectedComplDate'] = addDaysInDate(keySummary['Value4'], keySummary['Value6'] + keySummary['Value10'] + keySummary['Value5'] + keySummary['Value11']);

                    keySummary['estimatedComplDate'] = addDaysInDate(keySummary['Value4'], keySummary['Value5'] + keySummary['Value6'] + keySummary['Value10'] + keySummary['Value11'] + keySummary['Value12']);
                }

                $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal'] = angular.copy(tempKeyDateSummaryTotal)

                if ($scope.oriMsgCustomFields['COMPLETION_DATE']) {
                    var tempProjCompDays = (parseFloat($scope.unagreedQuatationChange) || 0) + (parseFloat($scope.pmAdjusToProjProgChange) || 0) + keyDateValue11 + $scope.keyDateValue5;

                    $scope.projectedComplDate = addDaysInDate($scope.oriMsgCustomFields['COMPLETION_DATE'], tempProjCompDays);

                    var tempEstimatedComplDays = $scope.keyDateValue5 + $scope.unagreedQuatationChange + $scope.pmAdjusToProjProgChange + keyDateValue12;

                    $scope.estimatedComplDate = addDaysInDate($scope.oriMsgCustomFields['COMPLETION_DATE'], tempEstimatedComplDays);
                    $scope.revisedComplDate = addDaysInDate($scope.oriMsgCustomFields['COMPLETION_DATE'], $scope.keyDateValue5);
                }
                $scope.kpiPayments = tempKPIPayments;
                $scope.potentialLiqDamages = tempPotentialLiqDamages;

                $scope.oriMsgCustomFields['LINK_CON_ID1'] = $scope.oriMsgCustomFields['LINK_CON_ID'];
                $scope.linkConID1 = (parseFloat($scope.oriMsgCustomFields['LINK_CON_ID1']) || 0);

                $scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share'] ) || 0;
                $scope.oriMsgCustomFields['Payments_Costs']['Fee'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['Fee'] ) || 0;
                $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] ) || 0;
                $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] ) || 0;
                $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] ) || 0;
                $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge'] = parseFloat( $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge'] ) || 0;

                var tempPainAndGainShare = (
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] +
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['PM_Adjustment'] + 
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['EWN_Additions'] + 
                    $scope.projectedPriceChange + 
                    $scope.sectionGroup['Sections'].grandSectionTotalObject['Anticipated_Additions'] + 
                    $scope.indexationInfo['Proj_Adj_Inflation'] + 
                    $scope.priceAdjustmentForInflation - 
                    (
                        $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                        $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                        $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] + 
                        $scope.ewnPriceIncNo + 
                        $scope.projectedPriceChangeWithNo
                    )
                    ) * ($scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share'] / 100);

                if( $scope.isUserPM == -1 && !$scope.isContractA ){
                    tempPainAndGainShare = (
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] +
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['EWN_Additions'] + 
                        $scope.projectedPriceChange + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['EWN_wo_Quotation'] + 
                        $scope.indexationInfo['Proj_Adj_Inflation'] + 
                        $scope.priceAdjustmentForInflation - 
                        (
                            $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                            $scope.ewnPriceIncNo + 
                            $scope.projectedPriceChangeWithNo
                        )
                        ) * ($scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share'] / 100);
                }

                $scope.painAndGainShare = tempPainAndGainShare;

                var tempEstimatedTotalOfPriceWithAncticipated = 
                    $scope.linkConID1 > 0 ? ( 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['PM_Adjustment'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['EWN_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Anticipated_Additions'] + 
                        $scope.projectedPriceChange + 
                        $scope.oriMsgCustomFields['Payments_Costs']['Fee'] + 
                        $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value17'] + 
                        $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge'] + 
                        $scope.indexationInfo['Proj_Adj_Inflation'] + 
                        $scope.priceAdjustmentForInflation 
                    ) / $scope.linkConID1 * 100 : 0;

                var tempEstimatedTotalOfPriceWithFinalCost = 
                    $scope.linkConID1 > 0 ? ( 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['PM_Adjustment'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['EWN_Additions'] + 
                        $scope.sectionGroup['Sections'].grandSectionTotalObject['Anticipated_Additions'] + 
                        $scope.projectedPriceChange + 
                        $scope.oriMsgCustomFields['Payments_Costs']['Fee'] + 
                        $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value17'] + 
                        $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge'] + 
                        $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value18'] + 
                        $scope.indexationInfo['Proj_Adj_Inflation'] + 
                        $scope.priceAdjustmentForInflation 
                    ) / $scope.linkConID1 * 100 : 0;

                if( $scope.isUserPM != -1 && !$scope.isContractA ){
                    tempEstimatedTotalOfPriceWithFinalCost = 
                        $scope.linkConID1 > 0 ? 
                        ( 
                            $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] + 
                            $scope.ewnPriceIncNo + 
                            $scope.projectedPriceChangeWithNo + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Fee'] + 
                            ( 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['PM_Adjustment'] + $scope.ewnPriceIncNo + $scope.projectedPriceChange +
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Anticipated_Additions'] +
                                $scope.indexationInfo['Proj_Adj_Inflation'] + 
                                $scope.priceAdjustmentForInflation -
                                (
                                    $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                                    $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                                    $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] + 
                                    $scope.ewnPriceIncNo + 
                                    $scope.projectedPriceChangeWithNo
                                )
                            ) * 
                            ( 
                                $scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share']/100 
                            ) + 
                            $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value17'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge'] + 
                            $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value18'] 
                        ) / $scope.linkConID1 * 100 : 0


                    tempEstimatedTotalOfPriceWithAncticipated = 
                        $scope.linkConID1 > 0 ? 
                        ( 
                            $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] + 
                            $scope.ewnPriceIncNo + 
                            $scope.projectedPriceChangeWithNo + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Fee'] + 
                            ( 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Activity_Value'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Total_Additions'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Unagreed_Additions'] + 
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['PM_Adjustment'] + $scope.ewnPriceIncNo + $scope.projectedPriceChange +
                                $scope.sectionGroup['Sections'].grandSectionTotalObject['Anticipated_Additions'] +
                                $scope.indexationInfo['Proj_Adj_Inflation'] + 
                                $scope.priceAdjustmentForInflation -
                                (
                                    $scope.oriMsgCustomFields['Payments_Costs']['Defined_Cost'] + 
                                    $scope.oriMsgCustomFields['Payments_Costs']['Forecast_DCost_Go'] + 
                                    $scope.oriMsgCustomFields['Payments_Costs']['PM_Delta_FDCTG'] + 
                                    $scope.ewnPriceIncNo + 
                                    $scope.projectedPriceChangeWithNo
                                )
                            ) * 
                            ( 
                                $scope.oriMsgCustomFields['Payments_Costs']['Pain_Gain_Share']/100 
                            ) + 
                            $scope.dsAsiStdECC4KeyDatesSummary['keyDateSummaryTotal']['Value17'] + 
                            $scope.oriMsgCustomFields['Payments_Costs']['Financing_Charge']
                        ) / $scope.linkConID1 * 100 : 0
                }

                $scope.percetageOfApprovalBudget = {
                    projectedTotalOfPrices: ( $scope.linkConID1 > 0 ? $scope.projectedTotalOfPricesIncInfation / $scope.linkConID1 * 100 : 0),

                    estimatedTotalOfPrice: ( $scope.linkConID1 > 0 ? ($scope.anticipatedAdditions + $scope.projectedTotalOfPricesIncInfation) / $scope.linkConID1 * 100 : 0),

                    estimatedTotalOfPriceWithAncticipated: tempEstimatedTotalOfPriceWithAncticipated,

                    estimatedTotalOfPriceWithFinalCost: tempEstimatedTotalOfPriceWithFinalCost
                }


                $scope.update();
            } else if (currentViewName == "ORI_VIEW") {

                $scope.intervalChange(true);

                if (!$scope.isDraft && $scope.dbFormId == '') {
                    var tmpImported = $scope.formCustomFields['is_Imported'].trim();
                    tmpImported = tmpImported.toLowerCase() == 'no' ? false : true;
                    if(!tmpImported){
                        var tempKeyMileStone = angular.copy(STATIC_OBJ_DATA.Key_Milestone);
                        tempKeyMileStone.Date_Type = "Contract Completion";
                        tempKeyMileStone.Date_Ref = "CC";
                        tempKeyMileStone.Date_Description = "Overall Contract Completion Date";
    
                        $scope.oriMsgCustomFields["Key_Milestones"]["Key_Milestone"] = [ tempKeyMileStone ];
    
                        var tempSections = angular.copy(STATIC_OBJ_DATA.Sections);
                        tempSections.Section_Code = "CONTR";
                        tempSections.isDefault = 1;
                        tempSections.Section_Name = "Contract Wide";
                        tempSections['Activity_Group']['Contract_Activities'][0]['Activity_Code'] = "CONTR";
                        tempSections['Activity_Group']['Contract_Activities'][0]['isDefaultAct'] = 1;
    
                        $scope.sectionGroup['Sections'] = [ tempSections ];
    
                        //Onload all row show default balnk
                        $scope.indexationInfo['Indexation'] = [];
                        $scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data'] = [];
                        $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'] = [];
                    }
                    
                    loadConfig(function () {
                        $scope.update();
                    });
                } else {
                    $scope.update();
                }

                $scope.keyMilestones = $scope.oriMsgCustomFields["Key_Milestones"];
            }
        }

        /**
         * Function used when user imports data using import sheet
         */
        function setImportNodes(){
            var tmpImported = $scope.formCustomFields['is_Imported'].trim();
            var imSectionCode = $scope.oriMsgCustomFields['Imported_Activity_Codes']['Imported_Activity_Code'];
            var imSectionCodeLen = imSectionCode && imSectionCode.length;
            
            if(tmpImported == "YES" && imSectionCodeLen){
                autoSelectSupplier();
                mapCostCodes();
                
                $scope.oriMsgCustomFields["COMPLETION_DATE"] = $scope.oriMsgCustomFields["Key_Milestones"]["Key_Milestone"][0]["Key_Date"];

                updateUsedFlag();
                mapKeyDates();

                var chkFirstKeyDate = isFirstDateValid();
                if (chkFirstKeyDate == "TBS"){
                    setFirstKeyDateValue();
                }
                else if (chkFirstKeyDate == "No"){
                    setFirstKeyDate();
                }
                setKeyDateIds();
                updateCeLogMap();
                setUniqueStringCostCodes();

                //set Budget values;
                $scope.oriMsgCustomFields['LINK_CON_ID1'] = $scope.oriMsgCustomFields['LINK_CON_ID'].trim();
                $scope.oriMsgCustomFields['ID_Flag'] = 1;
                
                // Garbage Imported Activities Nodes
                $scope.oriMsgCustomFields['Imported_Activity_Codes']['Imported_Activity_Code'] = [];
                $scope.oriMsgCustomFields['IMP_HD_CE_Log']['IMP_Historic_CE_Data'] = [];

                setUniqueStringKeyDates();
                $scope.formCustomFields["is_Imported"] = "Complete";

                // Set form Title based on Added Supplier
                setFormTitleAndSupplId();

                // Set Contrator Value
                setContractorOnImport();
                // Count Total of imported nodes
                contractTotalOfPriceBreakDown();
                indexationCummuativeTotal();
                calculateCEInfoTotal();
            }
        }

        function setContractorOnImport() {
            var setValue = $scope.oriMsgCustomFields['DS_PROJORGANISATIONS_ID'];
            $scope.oriMsgCustomFields['DS_PROJORGANISATIONS_ID'] = commonApi._.filter($scope.dsProjOrganisationsId , function(conObj){
                return conObj.Value.indexOf(setValue) > -1
            }).map(function(mapObj){
                return mapObj.Value;
            })[0];
        }

        function setUniqueStringKeyDates(){
            var tmpAllUnique_Values = "";
            var nodeKeyDates = $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'];
            if (nodeKeyDates && nodeKeyDates.length )
            {
                for (var i = 0; i < nodeKeyDates.length; i++) {
                    var loopNode = nodeKeyDates[i];
                    
                    if (loopNode["Date_Ref"])
                        return;
                    var strDateRef = loopNode["Date_Ref"];
                    tmpAllUnique_Values = tmpAllUnique_Values + '|' + strDateRef.trim();
                }
            }
            
            $scope.oriMsgCustomFields['All_KeyDates'] = tmpAllUnique_Values + "|";
        }


        function setUniqueStringCostCodes(){
            var tmpAllUnique_Values = '',
                loopCostCodes, 
                nodeCostCodes, 
                loopNode, i, k;
            var nodeContractSections = $scope.sectionGroup['Sections'];

            if (nodeContractSections && nodeContractSections.length )
            {
                for (i = 0; i < nodeContractSections.length; i++) {
                    loopCostCodes = nodeContractSections[i];
                    
                    nodeCostCodes = loopCostCodes["Activity_Group"]["Contract_Activities"];
                    if (nodeCostCodes && nodeCostCodes.length)
                    {
                        for ( k = 0; k < nodeCostCodes.length; k++) {
                            loopNode = nodeCostCodes[k];
                        
                            if (loopNode["CSection_Code"] || loopNode["Activity_Code"])
                                return;

                            tmpAllUnique_Values = tmpAllUnique_Values + '|' + loopNode["CSection_Code"] + "#" + loopNode["Activity_Code"];
                        }
                        
                    }
                }
                
            }
            
            $scope.oriMsgCustomFields['All_ActivityCodes'] = tmpAllUnique_Values + "|";
        }

        function autoSelectSupplier(){
            var strSupplierId = $scope.oriMsgCustomFields['Supplier_Id'].trim();
            var xmlAllSuppliers = null;
            if(strSupplierId){
                xmlAllSuppliers = $scope.dsProjOrganisationsId;
                for (var i = 0; i < xmlAllSuppliers.length; i++) {
                    var loopNode = xmlAllSuppliers[i].Value;
                    var splitSupplier = loopNode && loopNode.split('#')[0];
                    splitSupplier = splitSupplier && splitSupplier.trim();

                    if(splitSupplier == strSupplierId){
                        $scope.oriMsgCustomFields['DS_PROJORGANISATIONS_ID'] = loopNode;
                        break;
                    }
                }
            }
        }

        function mapCostCodes(){
            $scope.sectionGroup['Sections'] = [];

            var tmpCostCodes = $scope.oriMsgCustomFields['Imported_Activity_Codes']['Imported_Activity_Code'];
            
            var hstSection = {};
            var strXml = "";
            var blIsActivity = false;

            if(tmpCostCodes && tmpCostCodes.length){

                for (var i = 0; i < tmpCostCodes.length; i++) {
                    var element = tmpCostCodes[i];

                    var strSectionCode = element["IM_Section_Code"] || '';
                    var strHstSecCode = strSectionCode.trim().toLowerCase();

                    strXml = "";
                    blIsActivity = false;

                    if( !hstSection.hasOwnProperty(key) ){
                        strXml = mapImportedSection(element, strSectionCode);//map Section
                    }else{
                        strXml = mapImportedActivity(element, strSectionCode); //map Cost Code
                        blIsActivity = true;
                    }

                    if(blIsActivity){
                        var strSecXml = hstSection[strHstSecCode];
                        strSecXml["Activity_Group"]["Contract_Activities"] = strXml;
                        hstSection[strHstSecCode] = strSecXml;
                        
                    }else{
                        hstSection[strHstSecCode] = strXml;
                    }   
                }

                var tempSectionArray = [];
                for (var key in hstSection) {
                    if (hstSection.hasOwnProperty(key)) {
                        tempSectionArray.push(hstSection[key]);
                    }
                }
                
                $scope.sectionGroup['Sections'] = angular.copy(tempSectionArray);
                
                for (var k = 0; k < $scope.sectionGroup['Sections'].length; k++) {
                    var element = $scope.sectionGroup['Sections'][k];
                    calcFieldTotal({ repData: element['Activity_Group']['Contract_Activities'], calcKey: 'Activity_Value', parObject: element, totalKey:'tempTotalActivityValue'});      

                    calcFieldTotal({ repData: element['Activity_Group']['Contract_Activities'], calcKey: 'Anticipated_Additions', parObject: element, totalKey:'tempTotalAnticipatedAdd'});
                }
            }
        }

        function mapImportedSection(tmpLoop, tmpSectionCode)
        {
            var sectionNode = angular.copy( STATIC_OBJ_DATA.Sections );
            sectionNode["Section_Code"] = tmpSectionCode;
            sectionNode["Section_Name"] = tmpLoop["IM_Section_Name"];

            sectionNode["Activity_Group"]["Contract_Activities"] = [ mapImportedActivity(tmpLoop, tmpSectionCode) ];
            
            return sectionNode;
        }

        function mapImportedActivity(tmpLoop, tmpSectionCode){
            var contractActivityNode = angular.copy( STATIC_OBJ_DATA.Contract_Activities );
            contractActivityNode["CSection_Code"] = tmpSectionCode;
            contractActivityNode["Activity_Code"] = tmpLoop["IM_Activity_Code"];
            contractActivityNode["Activity_Name"] = tmpLoop["IM_Activity_Name"];
            contractActivityNode["Activity_Value"] = tmpLoop["IM_Activity_Price"];
            contractActivityNode["Anticipated_Additions"] = tmpLoop["IM_Anticipated_Additions"];

            return contractActivityNode;
        }

        function mapKeyDates(){
            $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'] = [];
            
            var nodeAllKeyDates = $scope.oriMsgCustomFields['IMP_Key_Milestones']['IMP_Key_Milestone'];

            if(nodeAllKeyDates && nodeAllKeyDates.length){

                for (var i = 0; i < nodeAllKeyDates.length; i++) {
                    var loopNode = nodeAllKeyDates[i];

                    var objKeyMileStone = angular.copy( STATIC_OBJ_DATA.Key_Milestone );
                    objKeyMileStone['Date_Type'] = loopNode['IMP_Date_Type'].trim();
                    objKeyMileStone['Date_Ref'] = loopNode['IMP_Date_Reference'].trim();
                    objKeyMileStone['Date_Description'] = loopNode['IMP_Date_Description'].trim();
                    objKeyMileStone['Key_Date'] = loopNode['IMP_Key_Date'].trim();
                    objKeyMileStone['Planned_Completion_Date'] = loopNode['IMP_Planned_Completion_Date'].trim();

                    var strAnticipated_Delays = loopNode['IMP_Anticipated_Delays'] || '0';
                    objKeyMileStone['Anticipated_Delays'] = strAnticipated_Delays;
                    objKeyMileStone['Bonus'] = loopNode['IMP_Range_Bonus'].trim() || '';
                    objKeyMileStone['LAD'] = loopNode['IMP_Range_LAD'].trim() || '';

                    objKeyMileStone['Bonus_LAD_Group']['Bonus_LAD'][0]['Range_Bonus'] = loopNode['IMP_Range_Bonus'].trim();
                    objKeyMileStone['Bonus_LAD_Group']['Bonus_LAD'][0]['Range_LAD'] = loopNode['IMP_Range_LAD'].trim();

                    if(loopNode['IMP_Date_Type'] == "Contract Completion"){
                        $scope.oriMsgCustomFields['COMPLETION_DATE'] = loopNode['IMP_Key_Date'];
                    }

                    $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'].push(objKeyMileStone);
                }
            }
        }

        function isFirstDateValid(){
            var firstKeyDate = $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'][0]['Date_Type'].trim();
            
            if (firstKeyDate == "Contract Completion")
            {
                return "Yes";
            }
            else
            {
                return firstKeyDate != "" ? "No" : "TBS";
            }
        }

        function checkCeCostCodeMapping(checkCE, checkSection, checkCostCode)
        {
            var isHdCeMatched = false;
            return !!(commonApi._.filter( $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], function(ceObj){
                isHdCeMatched = commonApi._.filter(ceObj['HD_CE_ActivityCodes']['HD_CE_ActivityCode'] , function(hdCeObj){
                    return hdCeObj.HD_CE_Section_Code == checkSection && hdCeObj.HD_CE_Activity_Code == checkCostCode;
                });

                isHdCeMatched = !!isHdCeMatched.length;
                return ceObj.CE_Incident_No == checkCE && isHdCeMatched;
            }).length);
        }

        function updateCeLogMap(){
            var tmpActions = $scope.oriMsgCustomFields['IMP_HD_CE_Log']['IMP_Historic_CE_Data'];
            
            if(tmpActions && tmpActions.length ){
                $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'] = [];

                for (var i = 0; i < tmpActions.length; i++) {
                    var tmpLoop = tmpActions[i];
                    var checkCE = tmpLoop['IMP_Incident_No'];
                    var checkCostCode = tmpLoop['IMP_Activity_Code'];
                    var checkDateRef = tmpLoop['IMP_Date_Ref'];
                    var checkSection = tmpLoop['IMP_Section_Code'];
                    if (!checkCeMapping( checkCE))  // if Group not already mapped map Group and the activity
                    {
                        mapHistoricCE( tmpLoop); //map group		
                    }
                    else
                    {
                        if (checkSection != "")
                        {
                            if (!checkCeCostCodeMapping(checkCE, checkSection, checkCostCode) && checkSection != "" && checkCostCode != "") // if Group already mapped check if activity if mapped, map if not.                     
                                mapCECostCodes( tmpLoop); //map activity                       
                        }
                        if (checkCE != "")
                        {
                            if (!checkCeKeyDateMapping( checkCE, checkDateRef) && checkDateRef != "" )
                                mapCEKeyDates( tmpLoop ); // map Key Date
                        }
                    }
                }
                updateCeTotals();
            }
        }

        function updateCeTotals()
        {
            // This function updates the totals of the CE Historic Data

            var nodeAllCENodes = $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'];
            var i = 0, tmpActValue , tmpActValue,
                loopNode, nodeAllActivities, k, nodeActValue,
                tmpStatus, tmpIsCE

            if (nodeAllCENodes && nodeAllCENodes.length )
            {
                for (; i < nodeAllCENodes.length; i++) {
                    loopNode = nodeAllCENodes[i];
                 
                    tmpActValue = 0;
                    nodeAllActivities = loopNode["HD_CE_ActivityCodes"]["HD_CE_ActivityCode"];
                    if (nodeAllActivities && nodeAllActivities.length )
                    {
                        for (k = 0; k < nodeAllActivities.length; k++) {                        
                            nodeActValue = nodeAllActivities[k]["HD_CE_Activity_Value"];
                            if (nodeActValue == ""){
                                nodeActValue = "0";
                            }
                            tmpActValue = parseFloat(tmpActValue) + parseFloat(nodeActValue);
                        }
                    }
    
                    tmpStatus = loopNode["CE_Status"];
                    tmpIsCE = loopNode["CE_Agreed"]; // Added for Is CE flag while importing and calculating totals
                    if (tmpStatus == "Closed" && tmpIsCE == "YES"){
                        loopNode["CE_IM_Cost_Changes"] = tmpActValue.toString();
                    }    
                    else if (tmpStatus == "Closed" && tmpIsCE == "NO"){ // Added for Is CE flag while importing and calculating totals
                        loopNode["CE_IM_Cost_Changes"] = "0";
                    }
                    else if (tmpStatus != "Closed" && tmpIsCE == "NO"){ // Added for Is CE flag while importing and calculating totals
                        loopNode["CE_UA_Quot_Changes"] = "0";
                    }
                    else if (tmpStatus != "Closed" && tmpIsCE == "YES"){ // Added for Is CE flag while importing and calculating totals
                        loopNode["CE_UA_Quot_Changes"] = tmpActValue.toString();
                    }    
                }
            }

        }

        function mapCEKeyDates(tmpLoop)
        {
            var strKeyDateRef = tmpLoop["IMP_Date_Ref"].trim();
            var strKeyDateId = "-1";
            if (strKeyDateRef != ""){
                strKeyDateId = getDateRefId(tmpLoop["IMP_Date_Ref"]);
            }

            if (strKeyDateId == "-1"){
                strKeyDateId = "";
                strKeyDateRef = "";
            }

            var AcheckCE = tmpLoop["IMP_Incident_No"].trim();
            var CE_insert_point = commonApi._.filter($scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'] , function( ceObj ){
                return ceObj.CE_Incident_No == AcheckCE;
            });

            var strKeyDateValue = tmpLoop["IMP_Date_Delays"];
            if (strKeyDateValue.trim() == ""){
                strKeyDateValue = "0";
            }

            var KeyDate_Xml = angular.copy( STATIC_OBJ_DATA.HD_CE_Key_Date );
            KeyDate_Xml['HD_Key_Date_Id'] = strKeyDateId;
            KeyDate_Xml['HD_Key_Date_Ref'] = strKeyDateRef;
            KeyDate_Xml['HD_Key_Date_Additions'] = strKeyDateValue;
            
            CE_insert_point[0]['HD_CE_Key_Dates']['HD_CE_Key_Date'].push(KeyDate_Xml);
        }

        function checkCeKeyDateMapping(checkCE, chkDateRef)
        {
            // function checks if an Activity is already mapped and returns 1 if mapped else returns 0
            var chkDateId = getDateRefId(chkDateRef);

            var isHdKeyMatched = false;
            return !!(commonApi._.filter( $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], function(ceObj){
                isHdKeyMatched = commonApi._.filter(ceObj['HD_CE_Key_Dates']['HD_CE_Key_Date'] , function(hdCeObj){
                    return hdCeObj.HD_Key_Date_Id == chkDateId;
                });

                isHdKeyMatched = isHdKeyMatched.length ? true : false;
                return ceObj.CE_Incident_No == checkCE && isHdKeyMatched;
            })[0].Value);
        }

        function mapCECostCodes(tmpLoop)
        {
            var AcheckCE = tmpLoop["IMP_Incident_No"];

            var strCostValue = tmpLoop["IMP_Activity_Value"];
            if (strCostValue.trim() == ""){
                strCostValue = "0";
            }
            var strAntiVariations = tmpLoop["IMP_Anticipated_Value"];
            if (strAntiVariations.trim() == ""){
                strAntiVariations = "0";
            }

            var CE_insert_point = commonApi._.filter( $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'], function(ceObj){
                return ceObj.CE_Incident_No == AcheckCE;
            });

            var CostCode_Xml = angular.copy( STATIC_OBJ_DATA.HD_CE_ActivityCode );
            CostCode_Xml["HD_CE_Section_Code"] = tmpLoop["IMP_Section_Code"];
            CostCode_Xml["HD_CE_Activity_Code"] = tmpLoop["IMP_Activity_Code"];
            CostCode_Xml["HD_CE_Activity_Value"] = strCostValue;
            CostCode_Xml["HD_CE_Anticipated_Variations"] = strAntiVariations;
            
            CE_insert_point[0]['HD_CE_ActivityCodes']['HD_CE_ActivityCode'].push(CostCode_Xml.toString());
        }

        function checkCeMapping(checkCE){

            var tempHistoricCEData = $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'];
            for (var i = 0; i < tempHistoricCEData.length; i++) {
                var element = tempHistoricCEData[i];
                if(element['CE_Incident_No'] == checkCE){
                    return !!element['CE_Incident_No'];
                }   
            }
        }

        function mapHistoricCE(tmpLoop){
            var strKeyDateRef = tmpLoop["IMP_Date_Ref"];
            var strKeyDateId = "-1";

            if (strKeyDateRef != ""){
                strKeyDateId = getDateRefId( tmpLoop["IMP_Date_Ref"] );
            }

            if (strKeyDateId == "-1"){
                strKeyDateId = "";
                strKeyDateRef = "";
            }

            var strCostValue = tmpLoop["IMP_Activity_Value"];
            if (strCostValue.trim() == ""){
                strCostValue = "0";
            }

            var strKeyDateValue = tmpLoop["IMP_Date_Delays"];
            if (strKeyDateValue.trim() == ""){
                strKeyDateValue = "0";
            }

            var strAntiVariations = tmpLoop["IMP_Anticipated_Value"];
            if (strAntiVariations.trim() == ""){
                strAntiVariations = "0";
            }

            var strAcceptedValue = 0;
            var strUnagreedValue = 0;
            var strAcceptedKDValue = 0;
            var strUnagreedKDValue = 0;

            var strTotActValue = 0;

            if (tmpLoop["IMP_Status"] == "Closed" && tmpLoop["IMP_Agreed"] == "YES")
            {
                strAcceptedValue = parseFloat( strTotActValue ) + parseFloat( strCostValue );
                if (tmpLoop["IMP_Date_Ref"] == "CC"){
                    strAcceptedKDValue = parseFloat(strKeyDateValue);
                }
            }
            else if ( tmpLoop["IMP_Status"] == "Closed" && tmpLoop["IMP_Agreed"] == "NO")
            {
                strAcceptedValue = parseFloat( strTotActValue );	// + parseFloat(strCostValue);
                if (tmpLoop["IMP_Date_Ref"] == "CC"){
                    strAcceptedKDValue = 0;	//parseFloat(strKeyDateValue);
                }
            }
            else if (tmpLoop["IMP_Status"] != "Closed" && tmpLoop["IMP_Agreed"] == "NO")
            {
                strUnagreedValue = parseFloat( strTotActValue );	// + parseFloat(strCostValue);
                if (tmpLoop["IMP_Date_Ref"] == "CC"){
                    strUnagreedKDValue = 0;	//parseFloat(strKeyDateValue);
                }
            }
            else if ( tmpLoop["IMP_Status"] != "Closed" && tmpLoop["IMP_Agreed"] == "YES")
            {
                strUnagreedValue = parseFloat(strTotActValue) + parseFloat(strCostValue);
                if (tmpLoop["IMP_Date_Ref"] == "CC"){
                    strUnagreedKDValue = parseFloat(strKeyDateValue);
                }
            }

            var tempHistoricCEDataObj = angular.copy( STATIC_OBJ_DATA.Historic_CE_Data );
            tempHistoricCEDataObj['CE_Incident_No'] = tmpLoop['IMP_Incident_No']
            tempHistoricCEDataObj['CE_Subject'] = tmpLoop['IMP_Subject']
            tempHistoricCEDataObj['CE_Status'] = tmpLoop['IMP_Status']
            tempHistoricCEDataObj['CE_EWN_No'] = tmpLoop['IMP_EWN_No']
            tempHistoricCEDataObj['CE_Notification_No'] = tmpLoop['IMP_Notification_No']
            tempHistoricCEDataObj['CE_Notification_Date'] = tmpLoop['IMP_Notification_Date']
            tempHistoricCEDataObj['CE_NCE_Reply_Due'] = tmpLoop['IMP_NIMP_Reply_Due']

            tempHistoricCEDataObj['CE_NCE_Reply_Date'] = tmpLoop['IMP_NIMP_Reply_Date']
            tempHistoricCEDataObj['CE_Agreed'] = tmpLoop['IMP_Agreed']
            tempHistoricCEDataObj['CE_Quot_EMA_No'] = tmpLoop['IMP_Quot_EMA_No']
            tempHistoricCEDataObj['CE_Quot_EMA_Due'] = tmpLoop['IMP_Quot_EMA_Due']
            tempHistoricCEDataObj['CE_Quot_EMA_Submitted'] = tmpLoop['IMP_Quot_EMA_Submitted']
            tempHistoricCEDataObj['CE_Quot_Reply_Due'] = tmpLoop['IMP_Quot_Reply_Due']
            tempHistoricCEDataObj['CE_Quot_Reply_Date'] = tmpLoop['IMP_Quot_Reply_Date']
            tempHistoricCEDataObj['CE_UA_Quot_Changes'] = strUnagreedValue
            tempHistoricCEDataObj['CE_Unagreed_Prog_Changes'] = strUnagreedKDValue
            tempHistoricCEDataObj['CE_IM_Cost_Changes'] = strAcceptedValue
            tempHistoricCEDataObj['CE_IM_Prog_Changes'] = strAcceptedKDValue
            tempHistoricCEDataObj['CE_EMP_Cost_Change'] = tmpLoop['IMP_EMP_Cost_Change']
            tempHistoricCEDataObj['CE_EMP_Prog_Change'] = tmpLoop['IMP_EMP_Prog_Change']

            tempHistoricCEDataObj['HD_CE_ActivityCodes']['HD_CE_ActivityCode'][0]['HD_CE_Section_Code'] = tmpLoop['IMP_EMP_Prog_Change'];
            tempHistoricCEDataObj['HD_CE_ActivityCodes']['HD_CE_ActivityCode'][0]['HD_CE_Activity_Code'] = tmpLoop['IMP_Activity_Code'];
            tempHistoricCEDataObj['HD_CE_ActivityCodes']['HD_CE_ActivityCode'][0]['HD_CE_Activity_Value'] = strCostValue;
            tempHistoricCEDataObj['HD_CE_ActivityCodes']['HD_CE_ActivityCode'][0]['HD_CE_Anticipated_Variations'] = strAntiVariations;

            tempHistoricCEDataObj['HD_CE_Key_Dates']['HD_CE_Key_Date'][0]['HD_Key_Date_Id'] = strKeyDateId;
            tempHistoricCEDataObj['HD_CE_Key_Dates']['HD_CE_Key_Date'][0]['HD_Key_Date_Ref'] = strKeyDateRef;
            tempHistoricCEDataObj['HD_CE_Key_Dates']['HD_CE_Key_Date'][0]['HD_Key_Date_Additions'] = tmpLoop['IMP_Date_Delays'];

            $scope.oriMsgCustomFields['Historic_CE_Information']['Historic_CE_Data'].push(tempHistoricCEDataObj);
        }

        function getDateRefId(strDateRef)
        {
            // This function returns the Date Ref

            var tmpKeyDates = $scope.oriMsgCustomFields['Key_Milestones']['Key_Milestone'];
            var loopNode,nodeDateRef,nodeDateId,i;

            //var tmpLoopKeyDateNode;
            if (tmpKeyDates && tmpKeyDates.length )
            {
                for (i = 0; i < tmpKeyDates.length; i++)
                {
                    loopNode = tmpKeyDates[i];
                    nodeDateRef = loopNode["Date_Ref"].trim();
                    nodeDateId = loopNode["Key_Date_Id"].trim();
                    if (nodeDateRef == strDateRef)
                    {
                        return nodeDateId;
                    }
                }
            }
            return "-1";
        }

        function setFirstKeyDateValue(){
            $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'][0]['Date_Type'] = "Contract Completion"
            $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'][0]['Date_Ref'] = "CC";
            $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'][0]['Date_Description'] = "Overall Contract Completion Date";
        }

        function setFirstKeyDate() {
            setFirstKeyDateValue();
            setKeyDateIds();
        }

        function setKeyDateIds(){
            var xpniNodeAllKeyDates = $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'];
            if(xpniNodeAllKeyDates && xpniNodeAllKeyDates.length ){
                var strKeyDateId = "1";
                for (var i = 0; i < xpniNodeAllKeyDates.length; i++) {
                    var xpnloopNode = xpniNodeAllKeyDates[i];
                    xpnloopNode["Key_Date_Id"] = strKeyDateId;
                    strKeyDateId = ( parseInt(strKeyDateId) + 1).toString();
                }
                $scope.oriMsgCustomFields['Key_Date_Counter'] = ( parseInt(strKeyDateId) - 1).toString();
            }
        }

        function setUniqueStringPMs(){
            var meargeString = '|';
            var tempProjMangerArray = commonApi._.filter($scope.oriMsgCustomFields.All_Project_Managers.Project_Managers, function(itm){
                return itm.Project_Manager != ''
            }).map(function(obj){
                return obj.Project_Manager.split('#')[0].trim();
            });

            if(tempProjMangerArray.length ){
                tempProjMangerArray = meargeString + tempProjMangerArray.join( meargeString ) + meargeString
            }else{
                tempProjMangerArray = '';
            }
            $scope.formCustomFields.All_PMs = tempProjMangerArray
        }

        function updateUsedFlag(){

            // For Price Breakdown Structure [ Sections ]
            for (var k = 0; k < $scope.sectionGroup['Sections'].length; k++) {
                var tmpSection = $scope.sectionGroup['Sections'][k];
                var conActivity = tmpSection['Activity_Group']['Contract_Activities'];

                tmpSection['Section_Used'] = 'YES';
                for (var i = 0; i < conActivity.length; i++) {
                    var tmpConAct = conActivity[i];
                    tmpConAct['Activity_Used_Flag'] = "YES";
                }
            }

            // For Key Contract Dates [ Key_Milestone ]
            var keyMilestonesArray = $scope.oriMsgCustomFields["Key_Milestones"]['Key_Milestone'];
            for (var k = 0; k < keyMilestonesArray.length; k++) {
                var tmpKeyMilestone = keyMilestonesArray[k];
                tmpKeyMilestone['Key_Date_Used_Flag'] = 'YES';               
            }
        }

        function calculateAllAdditions(){
            for (var index = 0; index < $scope.dsAsiStdEcc4NecContractActivitySummary.length; index++) {
                var element = $scope.dsAsiStdEcc4NecContractActivitySummary[index];
                var splitSectionNo = element['Name'].split('|');
                var xmlSectionCode = splitSectionNo[0].trim();
                var xmlActivityCode = element["Value5"].trim();

                var xmlTotalAdditions = element["Value8"].trim();
                var xmlTotalUnagreedAdditions = element["Value9"].trim();
                var xmlPMEstimatedAdditions = element["Value10"].trim();
                var xmlPMAdjustments = element["Value11"].trim();
                var xmlEWNAdditions = element["Value12"].trim();
                var xmlTotalAntAdd = element["Value13"].trim();
                var xmlFeesReceived = element["Value15"].trim();

                var xmlEWNPriceIncNo = element["Value16"].trim();
                var xmlEWN_wo_Quotation = element["Value17"].trim();

                for (var k = 0; k < $scope.sectionGroup['Sections'].length; k++) {
                    var tmpSection = $scope.sectionGroup['Sections'][k];
                    var conActivity = tmpSection['Activity_Group']['Contract_Activities'];

                    if(tmpSection['Section_Code'].trim().toLowerCase() != xmlSectionCode.toLowerCase()){
                        continue;
                    }

                    for (var i = 0; i < conActivity.length; i++) {
                        var tmpConAct = conActivity[i];
                        if(tmpConAct['Activity_Code'] == xmlActivityCode){
                            tmpConAct['Total_Additions'] = xmlTotalAdditions;
                            tmpConAct['Unagreed_Additions'] = xmlTotalUnagreedAdditions;
                            tmpConAct['PM_Estimated'] = xmlPMEstimatedAdditions;
                            tmpConAct['PM_Adjustment'] = xmlPMAdjustments;
                            tmpConAct['EWN_Additions'] = xmlEWNAdditions;
                            tmpConAct['Anticipated_Additions'] = xmlTotalAntAdd;
                            tmpConAct['Payment_Received'] = xmlFeesReceived;
                            tmpConAct['EWN_PriceIncNo'] = xmlEWNPriceIncNo;
                            tmpConAct['EWN_wo_Quotation'] = xmlEWN_wo_Quotation;

                        }
                    }
                }
            }
        }

        function throwCallBackError(error){
            console.log(error)
            $window.alert("Error\n\nDatasource callback failed!")
        }

        function countRiskRegisterDataTotal(){
            var tempValue14 = 0;
            var tempValue15 = 0;
            $scope.formCustomFields.Total_Pages_Risks = 0;// Set Default Value 0

            for (var index = 0; index < $scope.dsAaiStdEcc4NecContractRisksPaging.length; index++) {
                var element = $scope.dsAaiStdEcc4NecContractRisksPaging[index];
                if(index == 0){
                  $scope.formCustomFields.Total_Pages_Risks = (parseFloat( element.Value16 ) || 0);
                }
                if(element.Value11 != 'Closed' && element.Value13 == 'Yes' && !element.Value10 ){
                    tempValue14 = tempValue14 + (parseFloat( element.Value14 ) || 0);
                    tempValue15 = tempValue15 + (parseFloat( element.Value15 ) || 0);
                }
            }

            var tempHistoricRiskData = $scope.oriMsgCustomFields['Historic_Risk_Register']['Historic_Risk_Data'];
            var tempProjectedPriceChange = 0;
            var tempProjectedProgChange = 0;
            for (var index = 0; index < tempHistoricRiskData.length; index++) {
                var element = tempHistoricRiskData[index];

                if(element.Risk_Status != 'Closed' && element.Increase_Price == 'Yes'){
                    tempProjectedPriceChange = tempProjectedPriceChange + ( parseFloat( element['Projected_Price_Change'] ) || 0);
                    tempProjectedProgChange = tempProjectedProgChange + ( parseFloat( element['Projected_Prog_Change'] ) || 0);
                }                
            }

            $scope.dsAaiStdEcc4NecContractRisksPaging['riskPagingTotal'] = {
                ProjPriceChange : tempValue14 + tempProjectedPriceChange,
                ProjProgChange : tempValue15 + tempProjectedProgChange,
                onlyHistonricProgChange: tempProjectedProgChange
            }

            setPagingData('Risks');
        }

        function setPagingData(pageName){
            var pageParamObj = {};
            
            switch(pageName){
                case 'Risks':
                    $scope.formCustomFields['Tabbed_Paging_Risks']['Pages_Risks'] = [];
                    pageParamObj = {
                        totalCount: $scope.formCustomFields['Total_Pages_Risks'],
                        nodeKey: 'Pages_Risks',
                        parentNode: 'Tabbed_Paging_Risks',
                        pageNode: 'Page_Range_Risks',
                        dropdownModal: 'Page_Sel_Risks'
                    };
                    break;
                case 'Tracker':
                    $scope.formCustomFields['Tabbed_Paging']['Pages'] = [];
                    pageParamObj = {
                        totalCount: $scope.formCustomFields['Total_Pages'],
                        nodeKey: 'Pages',
                        parentNode: 'Tabbed_Paging',
                        pageNode: 'Page_Range',
                        dropdownModal: 'Page_Sel'
                    };
                    break;
            }
            addNewPageNode( pageParamObj );
        }

        function getPagingArray(totalRecords){
            var pageSize = parseInt( $scope.formCustomFields["Page_Slice"] );;
            var pageStart = 1;
            var totalItemCount = totalRecords;
            var pageArray = [];

            var currPageIndex = 1;
            var totalPage = Math.ceil( totalItemCount / pageSize );
            var tmpTotalCount = totalItemCount;
            while (currPageIndex <= totalPage) {
                var pageEnd = (pageSize > tmpTotalCount ? tmpTotalCount : pageSize )+pageStart-1;
                pageArray.push(pageStart+'-'+pageEnd);
                tmpTotalCount = tmpTotalCount - pageSize;
                currPageIndex++;
                pageStart = pageEnd+1; 
            }
            
            return pageArray;
        }

        function addNewPageNode(pageParam){
            var tmpTotalCount = pageParam.totalCount,
            nodeKey  = pageParam.nodeKey,
            parentNode = pageParam.parentNode, 
            pageNode = pageParam.pageNode,
            dropdownModal = pageParam.dropdownModal;
            
            var pageNumberArray = getPagingArray( tmpTotalCount );

            if( !$scope.formCustomFields[ dropdownModal ] ){
                $scope.formCustomFields[ dropdownModal ] = pageNumberArray[0];
            }

            for (var index = 0; index < pageNumberArray.length; index++) {
                var pageStr = pageNumberArray[index];
                var newPageNode = angular.copy( STATIC_OBJ_DATA[ nodeKey ] );
                newPageNode[ pageNode ] = pageStr;
                $scope.formCustomFields[ parentNode ][ nodeKey ].push(newPageNode);
            }
        }

        function countTrackerDataTotal(){

            var tempUnagreedQuotationTotalSummPage = 0;
            var tempUnagreedQuotationDaysTotalSummPage = 0;
            var tempImplePriceSummPage = 0;
            var tempImplePriceDaysSummPage = 0;
            var tempPMAdjustmentProgDaysTotal = 0;
            var tempPMAdjustmentPriceTotal = 0;
            var tempPMEstimatedProgDaysTotal = 0;
            var tempPMEstimatedPriceTotal = 0;

            $scope.formCustomFields['Total_Pages'] = 0;// Set default value 0;
            for (var index = 0; index < $scope.dsAaiStdEcc4IncSymmaryStatusPaging.length; index++) {
                var element = $scope.dsAaiStdEcc4IncSymmaryStatusPaging[index];
                element['Value16'] = ( parseFloat(element['Value16']) || 0);
                element['Value17'] = ( parseFloat(element['Value17']) || 0);
                element['Value18'] = ( parseFloat(element['Value18']) || 0);
                element['Value19'] = ( parseFloat(element['Value19']) || 0);

                element['Value34'] = ( parseFloat(element['Value34']) || 0);
                element['Value22'] = ( parseFloat(element['Value22']) || 0);
                element['Value33'] = ( parseFloat(element['Value33']) || 0);
                element['Value27'] = ( parseFloat(element['Value27']) || 0);
                element['Value23'] = ( parseFloat(element['Value23']) || 0);

                tempUnagreedQuotationTotalSummPage = tempUnagreedQuotationTotalSummPage + element['Value16'];
                tempUnagreedQuotationDaysTotalSummPage = tempUnagreedQuotationDaysTotalSummPage + element['Value17'];
                tempImplePriceSummPage = tempImplePriceSummPage + element['Value18'];
                tempImplePriceDaysSummPage = tempImplePriceDaysSummPage + element['Value19'];

                tempPMAdjustmentProgDaysTotal = tempPMAdjustmentProgDaysTotal + element['Value34'];
                tempPMAdjustmentPriceTotal = tempPMAdjustmentPriceTotal + element['Value33'];
                tempPMEstimatedProgDaysTotal = tempPMEstimatedProgDaysTotal + element['Value27'];
                tempPMEstimatedPriceTotal = tempPMEstimatedPriceTotal + element['Value23'];

                // Dynamic Class Added Based on Condition;
                element['Value38'] = ( parseFloat(element['Value38']) || 0);

                element['PMsNCEdue'] = getDateClassForLegend(element['Value9'], element['Value38']);

                element['Value24'] = ( parseFloat(element['Value24']) || 0);
                element['Value37'] = ( parseFloat(element['Value37']) || 0);

                element['QuoPMAdue'] = getDateClassForLegend(element['Value24'], element['Value37'], element['Value11']);

                element['Value32'] = ( parseFloat(element['Value32']) || 0);
                element['Value39'] = ( parseFloat(element['Value39']) || 0);

                element['QuoPMAdue1'] = getDateClassForLegend(element['Value32'], element['Value39'], element['Value31']);

                element['Value16'] = ( parseFloat(element['Value16']) || 0);
                element['Value40'] = ( parseFloat(element['Value40']) || 0);

                element['PMaQuoDue'] = getDateClassForLegend(element['Value16'], element['Value40']);

                if(index == 0){
                    $scope.formCustomFields['Total_Pages'] = element['Value22'];
                }
            }

            var tempUnagreedQuotationTotalCELog = 0;
            var tempUnagreedQuotationDaysTotalCELog = 0;
            var tempImplePriceTotalCELog = 0;
            var tempImplePriceDaysTotalCELog = 0;
            for (var index = 0; index < $scope.dsAsiStdEcc4NecHdCeLogFiltered.length; index++) {
                var element = $scope.dsAsiStdEcc4NecHdCeLogFiltered[index];
                element['Value16'] = ( parseFloat(element['Value16']) || 0);
                element['Value17'] = ( parseFloat(element['Value17']) || 0);
                element['Value18'] = ( parseFloat(element['Value18']) || 0);
                element['Value19'] = ( parseFloat(element['Value19']) || 0);

                tempUnagreedQuotationTotalCELog = tempUnagreedQuotationTotalCELog + element['Value16'];
                tempUnagreedQuotationDaysTotalCELog = tempUnagreedQuotationDaysTotalCELog + element['Value17'];
                tempImplePriceTotalCELog = tempImplePriceTotalCELog + element['Value18'];
                tempImplePriceDaysTotalCELog = tempImplePriceDaysTotalCELog + element['Value19'];
            }

            $scope.tackerTotal = {
                unagreedQuatation: tempUnagreedQuotationTotalSummPage + tempUnagreedQuotationTotalCELog,
                unagreedQuatationDays: tempUnagreedQuotationDaysTotalSummPage + tempUnagreedQuotationDaysTotalCELog,
                implePriceSummPage : tempImplePriceSummPage + tempImplePriceTotalCELog,
                implePriceSummPageDays : tempImplePriceDaysSummPage + tempImplePriceDaysTotalCELog,
                pmAdjustmentProgDaysTotal : tempPMAdjustmentProgDaysTotal,
                pmAdjustmentPriceTotal : tempPMAdjustmentPriceTotal,
                pmEstimatedProgDaysTotal : tempPMEstimatedProgDaysTotal,
                pmEstimatedPriceTotal : tempPMEstimatedPriceTotal
            }

            setPagingData('Tracker');
        }

        function getDateClassForLegend(firstVal, secondVal, thirdVal){
            var retClassName = '';
            var chkFlag = thirdVal ? thirdVal != '' : true;
            if( firstVal == 2 && secondVal == 0){
                retClassName = 'span-date-btn open-date';
            }else if( firstVal == 2 && secondVal > 0 && chkFlag){
                retClassName = 'span-date-btn open-date extension-served';
            }else if( firstVal == 5 && secondVal == 0 ){
                retClassName = 'span-date-btn open-date-week';
            }else if( firstVal == 5 && secondVal > 0 && chkFlag){
                retClassName = 'span-date-btn open-date-week extension-served';
            }else if( firstVal == 3 && secondVal == 0 ){
                retClassName = 'span-date-btn open-date-overdue';
            }else if( firstVal == 3 && secondVal > 0 && chkFlag){
                retClassName = 'span-date-btn open-date-overdue extension-served';
            }else if( firstVal == 4 && secondVal == 0 ){
                retClassName = 'span-date-btn late-notice';
            }else if( firstVal == 4 && secondVal > 0 ){
                retClassName = 'span-date-btn extension-late-notice';
            }else if( firstVal == 1 && secondVal > 0 && chkFlag){
                retClassName = 'span-date-btn extension-served';
            }

            return retClassName;
        }

        function bindTableScrollEvent(tabName) {
            $timeout(function () {
                switch(tabName){
                    case STT_CONSTANT.historicRiskInfoHtml:
                        tableScrollEvent('tbl_Historic_Risk_Data', 'tbl_Historic_Risk_Data_header');
                        break;
                    case STT_CONSTANT.riskRegister:
                        tableScrollEvent('tbl_Risk_Register', 'tbl_Historic_Risk_Data_header');
                        break;
                    case STT_CONSTANT.compensationEventLogHtml:
                        tableScrollEvent('tbl_compensationEventLogHtml', 'tbl_Historic_Risk_Data_header');
                        break;
                    case STT_CONSTANT.historicCeInfoHtml:
                        tableScrollEvent('tbl_Historic_CE_Data', 'tbl_Historic_CE_Info_header');
                        break;
                    case STT_CONSTANT.sectionalComplKeyDatesHtml:
                        tableScrollEvent('tbl_Sectional_Key_Data', 'tbl_Sectional_Key_Data_header');
                        break;
                    case STT_CONSTANT.priceBreakdownHtml:
                        tableScrollEvent('tbl_Price_Breakdown_Data', 'tbl_Price_Breakdown_Data_header');
                        break;
                }

                $scope.expandTextAreaOnLoad();

            }, 200);
        }

        function tableScrollEvent(tableId, headerClass){
            var objTableWrapper = document.getElementById(tableId);
            var objHeaderTR = $element.find('.'+ headerClass).parent();

            angular.element(objTableWrapper).bind('scroll', function (event) {
                objHeaderTR.scrollLeft( event.target.scrollLeft );
            });
        }

        function getItemSelectionList(arrayObject, groupName, modalKey, displayKey) {
            var tmpArray = [];
            var $groupName = groupName || "";
            for (var i = 0; i < arrayObject.length; i++) {
                tmpArray.push({
                    displayValue: arrayObject[i][displayKey],
                    modelValue: arrayObject[i][modalKey],
                    checked: false
                });
            }

            if (!tmpArray.length) {
                tmpArray.push({
                    displayValue: '',
                    modelValue: '',
                    checked: false
                })
            }

            return [
                {
                    optlabel: $groupName,
                    options: tmpArray
                }
            ];
        }


        /* This function load data of config.json file, 
        *  which added in .zip file,
        *  @param:callback which occures after load config file
        **/
        function loadConfig(callback) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getConfigJson",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&appBuilderId=" + $window.AppBuilderFormIDCode
            }).then(function (response) {

                var tempCommTypeArray = []
                var configCommunication_Types = response.data['Communication_Types'] || [];
                for(var i = 0 ; i < configCommunication_Types.length; i ++){
                    var tempCommType = angular.copy( STATIC_OBJ_DATA.Communication_Type);
                    tempCommType.Communication_Name = configCommunication_Types[i]['Value'];
                    tempCommType.canRemove = "No";
                    if(configCommunication_Types[i]['Accpt_Only_Flag']){
                        tempCommType.Comm_Accpt_Only = configCommunication_Types[i]['Accpt_Only_Flag'];
                    }
                    tempCommTypeArray.push(tempCommType);
                }
                $scope.formCustomFields['Communication_Types']['Communication_Type'] = tempCommTypeArray;
                callback && callback();
            }, function (xhr) {
                $window.alert(STT_CONSTANT.validanErrorConfigMsg);
            });
        };

        /* This function accepts date and days[Number], 
        *  which return new date with add days in passed date
        *  @param:date[string]
        *  @param:days[number]
        *  @return:newDate[string] with standard db formar yyyy-MM-dd
        **/
        function addDaysInDate(date, days) {
            var newDate = "";

            if (date) {
                var tmpDays = parseInt(days) || 0;
                var d = new Date(date);
                d.setDate(d.getDate() + tmpDays);
                var month = d.getMonth() + 1;
                var day = d.getDate();
                newDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;

            }
                
            return newDate;
        }

        function setAutoDistribution(userRole, strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            
            var newDistNode = angular.copy( STATIC_OBJ_DATA.Auto_Distribute_Users );
            var strCheckUser = 'NO';
            var allDistributedNodes = $scope.data.myFields.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users;

            for (var index = 0; index < allDistributedNodes.length; index++) {
                allDistributedNodes[index];
                if( allDistributedNodes[index]['DS_PROJDISTUSERS'] == strUser){
                    strCheckUser = "YES";
                    break;
                }                
            }

            $scope.data.myFields.Asite_System_Data_Read_Write.DS_AUTODISTRIBUTE = '3';
            if( ( userRole == 'PM' || userRole == 'CON' ) && strCheckUser == 'NO'){
                newDistNode.DS_PROJDISTUSERS = strUser;
                newDistNode.DS_FORMACTIONS = strAction;
                newDistNode.DS_ACTIONDUEDATE = strDueDate;

                $scope.data.myFields.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users.push(newDistNode);
            }
        }

        /*
        * This function is used calculate total on repeatindData and store it on other field
        * @param paramObject.repData< Array >: current Array from repeating data(Array)
        * @param paramObject.calcKey< string >: consider as input field to calculate total
        * @param paramObject.parObject< Object >: parent object where set calculated value 
        * @param paramObject.totalKey< string >: use this key from paramObject.parObject to set calculated value in this field
        */
        $scope.calcFieldTotal = calcFieldTotal;
        function calcFieldTotal(paramObject) {
            var repData = paramObject.repData;
            var calcKey = paramObject.calcKey;
            var parObject = paramObject.parObject;
            var totalKey = paramObject.totalKey;

            var tempTotal = 0;
            for (var index = 0; index < repData.length; index++) {
                var element = repData[index][calcKey];
                tempTotal += (parseFloat(element) || 0);
            }

            parObject[totalKey] = tempTotal;
        }

        $scope.restrictCharOnlyNumber = function () {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(STT_CONSTANT.restrictedCharMsg);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }

        }

        //if item is deleted than make one entry mandatory
        $scope.deleteItem = function (obj, repeatingData) {

            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);

        };

        $scope.restrictCharOnlyNumberPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            }
            else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue)) {
                alert(STT_CONSTANT.validanOnlyNumericMsg);
                event.preventDefault();
                return false;
            }
        };


        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.deleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };

        $window.asiNec4FinalCallBack = function () {

            if( !$scope.sectionGroup['Sections'][0]['Activity_Group']['Contract_Activities'][0]['Activity_Name']){
                $window.alert('Validation\n\nPlease add description in Price breakdown structure');
                return true;
            }

            var isKeyContractValid = true;
            var blankFieldName = "";
            for (var i = 0; i < $scope.keyMilestones['Key_Milestone'].length; i++) {
                var element = $scope.keyMilestones['Key_Milestone'][i];
                if(!element.Key_Date || !element.Planned_Completion_Date){
                    isKeyContractValid = false;
                    blankFieldName = "Original Completion Date or Planned Completion Date"
                    break;
                }
                
            }

            if(!isKeyContractValid){
                $window.alert('Validation\n\nPlease fill below mandatory field in Key Contract Dates\n\n'+blankFieldName);
                return true;
            }

            var tempProjMangerArray = commonApi._.map($scope.oriMsgCustomFields.All_Project_Managers.Project_Managers, function(obj){
                return obj.Project_Manager;
            }).filter(function(itm){
                return itm != ''
            });

            var tempContractorArray = commonApi._.map($scope.oriMsgCustomFields.Assistant_Project_Managers.Assistant_Project_Manager, function(obj){
                return obj.Assistant_PM;
            }).filter(function(itm){
                return itm != ''
            });

            var tempTflAuthorisorArray = commonApi._.map($scope.oriMsgCustomFields.All_TflAuthorisors.TflAuthorisors, function(obj){
                return obj.TflAuthorisor;
            }).filter(function(itm){
                return itm != ''
            });

            if(tempProjMangerArray.length == 0 || tempContractorArray.length == 0 || tempTflAuthorisorArray.length == 0){
                $window.alert(STT_CONSTANT.validanProjManConMsg);
                return true;
            }

            if($scope.currentOriTab != STT_CONSTANT.contractDetailsHtml){
                $window.alert(STT_CONSTANT.validanReturnContractTabMsg);
                return true;
            }

            setPMandCONAutoDistributionNode();

            return false;
        }

        $scope.isValidForm = true;
        $window.customHTMLMethodAfterValidationError = function(){
            $scope.isValidForm = false;
        }

    }
    return FormController;
});

function customHTMLMethodAfterValidationError(){}

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof asiNec4FinalCallBack !== "undefined") {
        return asiNec4FinalCallBack();
    }
}