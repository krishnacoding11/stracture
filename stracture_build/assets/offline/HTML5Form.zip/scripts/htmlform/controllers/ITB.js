/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $filter, commonApi, $controller, $window, $timeout, myConfig, api, apiConfig, download, Notification) {
        var ctrl = this;
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId')
            .value || '';

        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        var timeZoneMap = {
            "Africa/Bangui": "W. Central Africa Standard Time",
            "Africa/Cairo": "Egypt Standard Time",
            "Africa/Casablanca": "Morocco Standard Time",
            "Africa/Harare": "South Africa Standard Time",
            "Africa/Johannesburg": "South Africa Standard Time",
            "Africa/Lagos": "W. Central Africa Standard Time",
            "Africa/Monrovia": "Greenwich Standard Time",
            "Africa/Nairobi": "E. Africa Standard Time",
            "Africa/Windhoek": "Namibia Standard Time",
            "America/Anchorage": "Alaskan Standard Time",
            "America/Argentina/San_Juan": "Argentina Standard Time",
            "America/Asuncion": "Paraguay Standard Time",
            "America/Bahia": "Bahia Standard Time",
            "America/Bogota": "SA Pacific Standard Time",
            "America/Buenos_Aires": "Argentina Standard Time",
            "America/Caracas": "Venezuela Standard Time",
            "America/Cayenne": "SA Eastern Standard Time",
            "America/Chicago": "Central Standard Time",
            "America/Chihuahua": "Mountain Standard Time (Mexico)",
            "America/Cuiaba": "Central Brazilian Standard Time",
            "America/Denver": "Mountain Standard Time",
            "America/Fortaleza": "SA Eastern Standard Time",
            "America/Godthab": "Greenland Standard Time",
            "America/Guatemala": "Central America Standard Time",
            "America/Halifax": "Atlantic Standard Time",
            "America/Puerto_Rico": "Atlantic Standard Time",
            "America/Indianapolis": "US Eastern Standard Time",
            "America/Indiana/Indianapolis": "US Eastern Standard Time",
            "America/La_Paz": "SA Western Standard Time",
            "America/Los_Angeles": "Pacific Standard Time",
            "America/Mexico_City": "Mexico Standard Time",
            "America/Montevideo": "Montevideo Standard Time",
            "America/New_York": "Eastern Standard Time",
            "America/Noronha": "Fernando de Noronha Time",
            "America/Phoenix": "US Mountain Standard Time",
            "America/Regina": "Canada Central Standard Time",
            "America/Santa_Isabel": "Pacific Standard Time (Mexico)",
            "America/Santiago": "Pacific SA Standard Time",
            "America/Sao_Paulo": "Brazil Time",
            "America/St_Johns": "Newfoundland Standard Time",
            "America/Tijuana": "Pacific Standard Time",
            "Antarctica/McMurdo": "New Zealand Standard Time",
            "Atlantic/South_Georgia": "UTC-02",
            "Asia/Almaty": "Central Asia Standard Time",
            "Asia/Amman": "Jordan Standard Time",
            "Asia/Baghdad": "Arabia Standard Time",
            "Asia/Baku": "Azerbaijan Standard Time",
            "Asia/Bangkok": "SE Asia Standard Time",
            "Asia/Beirut": "Middle East Standard Time",
            "Asia/Calcutta": "India Standard Time",
            "Asia/Colombo": "Sri Lanka Standard Time",
            "Asia/Damascus": "Syria Standard Time",
            "Asia/Dhaka": "Bangladesh Standard Time",
            "Asia/Dubai": "Gulf Standard Time",
            "Asia/Irkutsk": "North Asia East Standard Time",
            "Asia/Jerusalem": "Israel Standard Time",
            "Asia/Kabul": "Afghanistan Standard Time",
            "Asia/Kamchatka": "Kamchatka Standard Time",
            "Asia/Karachi": "Pakistan Standard Time",
            "Asia/Katmandu": "Nepal Standard Time",
            "Asia/Kolkata": "India Standard Time",
            "Asia/Krasnoyarsk": "North Asia Standard Time",
            "Asia/Kuala_Lumpur": "Singapore Standard Time",
            "Asia/Kuwait": "Arab Standard Time",
            "Asia/Magadan": "Magadan Standard Time",
            "Asia/Muscat": "Arabian Standard Time",
            "Asia/Novosibirsk": "N. Central Asia Standard Time",
            "Asia/Oral": "West Asia Standard Time",
            "Asia/Rangoon": "Myanmar Standard Time",
            "Asia/Riyadh": "Arab Standard Time",
            "Asia/Seoul": "Korea Standard Time",
            "Asia/Shanghai": "China Standard Time",
            "Asia/Singapore": "Singapore Standard Time",
            "Asia/Saigon": "Indochina Time",
            "Asia/Taipei": "Taipei Standard Time",
            "Asia/Tashkent": "West Asia Standard Time",
            "Asia/Tbilisi": "Georgian Standard Time",
            "Asia/Tehran": "Iran Standard Time",
            "Asia/Tokyo": "Japan Standard Time",
            "Asia/Ulaanbaatar": "Ulaanbaatar Standard Time",
            "Asia/Vladivostok": "Vladivostok Standard Time",
            "Asia/Yakutsk": "Yakutsk Standard Time",
            "Asia/Yekaterinburg": "Ekaterinburg Standard Time",
            "Asia/Yerevan": "Armenian Standard Time",
            "Atlantic/Azores": "Azores Standard Time",
            "Atlantic/Cape_Verde": "Cape Verde Standard Time",
            "Atlantic/Reykjavik": "Greenwich Standard Time",
            "Australia/Adelaide": "Cen. Australia Standard Time",
            "Australia/Brisbane": "E. Australia Standard Time",
            "Australia/Darwin": "AUS Central Standard Time",
            "Australia/Hobart": "Eastern Standard Time (Tasmania)",
            "Australia/Perth": "W. Australia Standard Time",
            "Australia/Sydney": "Eastern Standard Time (New South Wales)",
            "Australia/Canberra": "Eastern Standard Time (New South Wales)",
            "Australia/Melbourne": "AUS Eastern Standard Time",
            "Etc/GMT": "UTC",
            "Etc/GMT+11": "UTC-11",
            "Etc/GMT+12": "Dateline Standard Time",
            "Etc/GMT+2": "UTC-02",
            "Etc/GMT-12": "UTC+12",
            "Europe/Amsterdam": "W. Europe Standard Time",
            "Europe/Athens": "GTB Standard Time",
            "Europe/Belgrade": "Central Europe Standard Time",
            "Europe/Berlin": "W. Europe Standard Time",
            "Europe/Brussels": "Central European Time",
            "Europe/Budapest": "Central Europe Standard Time",
            "Europe/Dublin": "GMT Standard Time",
            "Europe/Helsinki": "FLE Standard Time",
            "Europe/Istanbul": "Eastern European Time",
            "Europe/Kiev": "FLE Standard Time",
            "Europe/London": "GMT Standard Time",
            "Europe/Minsk": "E. Europe Standard Time",
            "Europe/Moscow": "Russian Standard Time",
            "Europe/Paris": "Central European Time",
            "Europe/Sarajevo": "Central European Standard Time",
            "Europe/Warsaw": "Central European Standard Time",
            "Europe/Lisbon": "Western European Time",
            "Indian/Mauritius": "Mauritius Standard Time",
            "Pacific/Apia": "West Samoa Time",
            "Pacific/Auckland": "New Zealand Standard Time",
            "Pacific/Fiji": "Fiji Standard Time",
            "Pacific/Guadalcanal": "Solomon Islands Time",
            "Pacific/Guam": "Chamorro Standard Time",
            "Pacific/Honolulu": "Hawaiian Standard Time",
            "Pacific/Pago_Pago": "Samoa Standard Time",
            "Pacific/Port_Moresby": "Papua New Guinea Time",
            "Pacific/Tongatapu": "Tonga Standard Time",
            "Pacific/Midway": "Samoa Standard Time",
            "Pacific/Enderbury": "Phoenix Is. Time",
            "Pacific/Kiritimati": "Line Islands Standard Time"
        };
        var STATIC_OBJ_DATA = {
            Doc_Checklist: {
                Doc_isSelected: "",
                Cheklist_Name: "",
                Doc_Is_Checked: ""

            },
            Question_CheckList: {
                Question_isSelected: "",
                Question_Name: "",
                Question_CheckList_Type: "",
                Question_Checkbox_Details: "",
                Question_Textbox_Details: ""

            },
            sectionsSetup: {
                autoId: "",
                sequenceId: "",
                sectionId: "",
                sectionDescription: "",
                UOM: "",
                Quantity: "",
                Rate: "",
                Price: "",
                Total: "",
                sectionParentId: "",
                hierarchySequenceId: "",
                Guid: "",
                EditFlag: "",
                immediate_parentId: "",
                immediate_parentGUId: "",
                immediate_childId: "",
                immediate_childGUId: "",
                isMultipleRemove: false,
                isLastflag: false,
                isDeleteSection: false,
                Tax: ""
            },
            DSI_Formsetting:{
                DSI_Setting_name: "",
                DSI_Original_value: "",
                DSI_Expected_value: ""
            }
        }

        var currentViewName = window.currentViewName,
            InsertMasterInitArray = {
                'sectionsSetup': {
                    autoId: "",
                    sequenceId: "",
                    sectionId: "",
                    sectionDescription: "",
                    UOM: "",
                    Quantity: "",
                    Rate: "",
                    Price: "",
                    Total: "",
                    sectionParentId: "",
                    hierarchySequenceId: "",
                    Guid: "",
                    EditFlag: "",
                    immediate_parentId: "",
                    immediate_parentGUId: "",
                    immediate_childId: "",
                    immediate_childGUId: "",
                    isMultipleRemove: false,
                    isLastflag: false,
                    isDeleteSection: false,
                    Tax: ""
                }
            },
            deleteFlagJsonKeyMap = {
                'sectionsSetup': 'isDeleteSection'
            };


        $scope.editORIMsg = false;
        $scope.readOnly = false;
        $scope.fieldName = '';
        $scope.fieldValue = '';
        $scope.deletedSectionSequenceId = [];
        $scope.isSameOrg = false;
        $scope.isFromMarketPlace = false;

        angular.element($window).bind("resize", function () {
            $scope.expandTextAreaOnLoad();
        });

        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];

        $scope.dsMktWtgDetails = $scope.getValueOfOnLoadData('DS_MKT_WTG_DETAILS');
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.actionsDropDown = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        $scope.DS_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.strIsDraft = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT;
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        $scope.DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        $scope.DS_ASI_STD_ADD_BM_Bid_Recipients = $scope.getValueOfOnLoadData('DS_ASI_STD_ADD_BM_Bid_Recipients');
        $scope.DS_INCOMPLETE_MSG_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
        $scope.DS_ASI_STD_TNDR_Schedule_Workdetail = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_Schedule_Workdetail');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails = $scope.getValueOfOnLoadData('DS_ASI_STD_ADD_BM_Bid_CloseDetails');
        $scope.DS_ISDRAFT_RES_MSG = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
        $scope.DS_ASI_STD_ADD_BM_Bid_Addenda = $scope.getValueOfOnLoadData('DS_ASI_STD_ADD_BM_Bid_Addenda');
        $scope.DS_ASI_STD_TNDR_GET_COUNTRY_LIST = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GET_COUNTRY_LIST');
        $scope.DS_ASI_STD_TNDR_GET_STATE_LIST = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GET_STATE_LIST');
        $scope.DS_ASI_STD_TNDR_GET_UOP_ORG_DETAILS = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GET_UOP_ORG_DETAILS');
        $scope.DS_ASI_STD_ITB_PKG_REQUIREMENT = $scope.getValueOfOnLoadData('DS_ASI_STD_ITB_PKG_REQUIREMENT');
        $scope.DS_ASI_STD_ITB_DOC_CHECKLIST = $scope.getValueOfOnLoadData('DS_ASI_STD_ITB_DOC_CHECKLIST');
        $scope.DS_ASI_STD_ITB_QUESTION_CHECKLIST = $scope.getValueOfOnLoadData('DS_ASI_STD_ITB_QUESTION_CHECKLIST');
        $scope.DS_ORIGINATOR = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ORIGINATOR;
        $scope.DS_ISDRAFT_FWD_MSG = document.getElementById("DS_ISDRAFT_FWD_MSG").value;
        $scope.ds_Asi_Get_All_Default_FormSettingDetails = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_LOGGEDIN_USERID = $scope.getValueOfOnLoadData('DS_LOGGEDIN_USERID');
        var DS_ASI_GET_LATEST_ORI_FWD_MSG_ID = $scope.getValueOfOnLoadData('DS_ASI_GET_LATEST_ORI_FWD_MSG_ID');
        var fetchUserDetails = $scope.getValueOfOnLoadData('DS_FETCH_USER_DETAILS');
        var userSystemPrivilege = $scope.getValueOfOnLoadData('DS_USER_SYSTEM_PRIVILEGE');
        var lastIndex = 0;
        $scope.isDSFormId = ($scope.strFormId != '');
        $scope.isEditORI = ($scope.isDSFormId && ($scope.strIsDraft == 'YES'));
        $scope.loggedInUserRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_WITHOUT_ROLE');
        if ($scope.loggedInUserRole.length) {
            loggedInUserId = $scope.loggedInUserRole[0].Value1.split('|')[0].trim();
        }
        if(myConfig.aSessionID && myConfig.aSessionID != 'null'){
            $scope.getServerTime(function (serverDate) {
                $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
                $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
            });
        }

        $scope.strTodayDateTime = getDateTimeFromZone();
        $scope.oriMsgCustomFields.DSI_Converted_Date = $scope.strTodayDateTime;

        var bfpc = '';
        $scope.ishideEOIButton = true;
        $scope.ishideQueryButton = false;
        $scope.ishideCommButton = false;
        $scope.ishideSubmitButton = false;
        $scope.ishidePrequalButton = false;
        $scope.ishideViewPrequalButton = false;
        $scope.ishideAddendumButton = false;
        $scope.ishideResBidderview = false;
        $scope.ishideDeclineButton = false;
        $scope.ishideParticipateButton = false;
        $scope.ishideResBiddAdminview = false;
        $scope.isTenderEndDatePassed = false;
        $scope.isSealedPkgReviewDateChk = false;
        $scope.ishideResBidderResPrintview = false;
        $scope.ishideResBiddAdminPrintview = false;
        $scope.ishideDeclineMsg = false;
        $scope.isSealedPkgMsg = false;
        $scope.ishidePFCButton = false;
        $scope.ishideBidder = false;
        $scope.ishideRegisterButton = false;
        $scope.canUserEdit = true;
        $scope.canUserRespond = true;
        $scope.RecipientStructure = {
            Tenderer_Organisation: "",
            Tenderer_Recipient: "",
            isMarketplaceUser:""
        };
        var strWorkingUserOrg = "",
            CurrentUserID = "",
            CurrentUserName = "",
            loggedInUserId = '',
            loggedInUserName = '',
            loggedInUserNameOrg = '';
        if ($scope.WorkingUserID && $scope.WorkingUserID.length > 0) {
            $scope.formCustomFields.Bid_Opportunity.ResWorkinguserId = $scope.WorkingUserID[0].Value.split('|')[0].trim();
            CurrentUserID = $scope.WorkingUserID[0].Value.split('|')[0].trim();
            CurrentUserName = $scope.WorkingUserID['0'].Name;
            strWorkingUserOrg = CurrentUserName.split(',')[1].trim();
        }
        var loggedinUserOrg = "";
        var orgOrganization = "";

        if ($scope.DS_ORIGINATOR && $scope.DS_ORIGINATOR.length) {
            orgOrganization = $scope.DS_ORIGINATOR.split(',')[1].trim();
        }
        if (DS_LOGGEDIN_USERID && DS_LOGGEDIN_USERID.length) {
            loggedinUserOrg = DS_LOGGEDIN_USERID[0].Name.split(',')[1].trim();
        }
        if (orgOrganization && loggedinUserOrg) {
            if ((loggedinUserOrg.toLowerCase().trim() == orgOrganization.toLowerCase().trim()) && (strWorkingUserOrg && strWorkingUserOrg.toLowerCase().trim() == orgOrganization.toLowerCase().trim())) {
                $scope.ishideBidder = true;
            }

        }

        $scope.PackageStructure = {
            ID: "",
            Work_Description: "",
            UOM: "",
            Quantity: "",
            Value: "",
            Rate: "",
            EditFlag: "",
            UOM_Other: ""
        }
        $scope.AddPackageStructure = {
            Additional_ID: "",
            AddPackageReq_Desc: "",
            AddPackageReq_Quantity: "",
            AddPackageReq_Unit: "",
            AddPackageReq_Rate: "",
            AddPackageReq_Price: "",
            AddPackageReq_UnitOther: ""
        }

        $scope.AutocompleteMsgStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }

        $scope.AutoDistActionStructure = {
            DS_ADO_TYPE: "",
            DS_ADO_FORM: "",
            DS_ADO_MSG_TYPE: "",
            DS_ADO_FORMACTIONS: "",
            DS_ADO_PROJDISTGROUPS: "",
            DS_ADO_ACTIONDUEDATE: "",
            DS_ADO_PROJDISTUSERS: ""
        }

        $scope.AutocompleteActionStructure = {
            DS_AC_TYPE: "",
            DS_AC_FORM: "",
            DS_AC_MSG_TYPE: "",
            DS_AC_USERID: "",
            DS_AC_ACTION: "",
            DS_AC_ACTION_REMARKS: ""

        }

        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }

        var logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1
        });

        $scope.Bidtype = commonApi._.filter($scope.DS_WORKSPACE_ROLES_with_ID, function (val) {
            return val.Name.toLowerCase().indexOf('wp') > -1
        });

        

        $scope.Currency = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Currency' && val.Value11.indexOf('Active') != -1
        });

        $scope.UOM = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Unit' && val.Value11.indexOf('Active') != -1
        });

        $scope.Docchecklist = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Document List' && val.Value11.indexOf('Active') != -1
        });
        $scope.Questionchecklist = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Question List' && val.Value11.indexOf('Active') != -1
        });
        $scope.ContactPerson = commonApi._.filter($scope.DS_PROJUSERS_ROLE, function (val) {
            return val.Value.indexOf('Tender Team') != -1
        });
        $scope.TaxName = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Tax Name' && val.Value11.indexOf('Active') != -1
        });

        $scope.DownloadType = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3 == 'Download_Document' && val.Value7 == 'ASI-STD-ITB' && val.Value11.indexOf('Active') != -1
        });

        $scope.canAccessOJUE = commonApi._.filter(userSystemPrivilege, function (val) {
            return val.Value3 == 'VM - Can accept public bids without subscription'
        });

        if (userSystemPrivilege.length) {
            var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value40 == 'Reject' && val.Value38.indexOf(strWorkingUser) > -1;
            });
        }

        if ($scope.strFormId) {
            $scope.formCustomFields.Bid_Opportunity.Can_Reply = "";
            var strCanReply = "";
            var userid = "";
            if ($scope.WorkingUserID && $scope.WorkingUserID.length) {
                userid = $scope.WorkingUserID['0'].Value.split('|')[0].trim();
            }
            $scope.ActionData = commonApi._.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Value.indexOf('Respond') > -1 && val.Value.indexOf(userid) != -1
            });
            if ($scope.ActionData && $scope.ActionData.length) {
                strCanReply = "YES";
            }
            $scope.formCustomFields.Bid_Opportunity.Can_Reply = strCanReply;
        }

        /**
         * for 'DS_ASI_STD_CHECK_EOI_USER_VALIDATE' SP returning Values 
         * Value2 indicates weather User is Qualified or Not with response value "Q" or "NQ".
         * Value3 indicates weather EOI form is created against the current ITB form with response value "Yes" or "No".
         * Value4 indicates buyerOrgId
         * Value5 indicates vendorOrgId
         */

        var isHideEOIButtonForUser = function () {
            var bidRicUserId = '';
            if (CurrentUserID || loggedInUserId) {
                for (var i = 0; i < $scope.DS_ASI_STD_ADD_BM_Bid_Recipients.length; i++) {
                    bidRicUserId = $scope.DS_ASI_STD_ADD_BM_Bid_Recipients[i].Value5.trim();
                    if (bidRicUserId == CurrentUserID || bidRicUserId == loggedInUserId) {
                        return true;
                    }
                }
            }
            return false;
        },
            getHideExpressInterestOnBidData = function () {
                if ($scope.formCustomFields.Bid_Opportunity.Is_Tender_Public == 'no' || $scope.strIsDraft == 'YES') {
                    return;
                }
                var DS_ASI_STD_CHECK_EOI_USER_VALIDATE = $scope.getValueOfOnLoadData('DS_ASI_STD_CHECK_EOI_USER_VALIDATE')[0],
                    buyerOrgId = '',
                    vendorOrgId = '';

                if (!DS_ASI_STD_CHECK_EOI_USER_VALIDATE) {
                    return;
                }

                buyerOrgId = DS_ASI_STD_CHECK_EOI_USER_VALIDATE.Value4;
                vendorOrgId = DS_ASI_STD_CHECK_EOI_USER_VALIDATE.Value5;
                var reqParamObj = [{
                    "buyerOrgId": buyerOrgId,
                    "vendorOrgId": vendorOrgId,
                    "bidCloseDate": $scope.formCustomFields.Bid_Opportunity.Tender_End_Date,
                    "allowExternalVendor": ($scope.formCustomFields.Bid_Opportunity.allowExternalVendor == "Yes" ? true : false)
                }];
                commonApi.ajax({
                    url: $window.marketPlaceServiceURL + '/marketplace/opportunities/canExpressInterestOnBid',
                    method: 'POST',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8',
                        'ApiKey': $window.marketPlaceApiKey
                    },
                    data: JSON.stringify(reqParamObj)
                }).then(function (response) {
                    if (response.data) {
                        var canExpressInterest = (response.data[0].canExpressInterest == 'true');
                        $scope.ishideEOIButton = !canExpressInterest || (canExpressInterest && isHideEOIButtonForUser()) || $scope.oriMsgCustomFields.Enable_form_public_link == 'Yes';
                        bfpc = response.data[0].bfpc;
                    }
                },function () {
                    ////Not getting data QA2
                    Notification.error({ title: 'Server Error', message: 'Server Error.' });
                });
            },
            createFormWithMarketPlaceFunction = function (respData) {
                var options = {
                    target: "blank",
                    url: myConfig.baseUrl + "/adoddle/apps?action_id=903&formSelectRadiobutton=" + respData.dcId + '_' + respData.formTypeVO.projectId + '_' + respData.formTypeVO.formTypeID + '_' + $scope.strFormId + '_ASI-STD-EOI&bfpc=' + bfpc,
                    method: "POST"
                };
                // This function submit form from common service.
                commonApi.submitForm(options);
            },
            getFormSetting = function () {
                commonApi.ajax({
                    url: (myConfig.baseUrl || "") + "/commonapi/form/getLatestFormType?appBuilderCode=ASI-STD-EOI&projectId=" + myConfig.projectId,
                    method: 'POST',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(function (response) {
                    if (response.data) {
                        createFormWithMarketPlaceFunction(response.data);
                    }
                }, function () {
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while receiving Latest Form type!!'
                    });
                });
            },
            createEOIForm = function () {
                getFormSetting();
            },
            createPrequalForm = function () {
                var aSessionID = "";
                if (typeof (USP) != "undefined") { aSessionID = USP.aSessionId; } else { aSessionID = myConfig.aSessionID; }
                commonApi.ajax({
                    url: $window.marketPlaceServiceURL + '/marketplace/prequal/launchPrequalFromTender',
                    method: 'POST',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8',
                        'ApiKey': $window.marketPlaceApiKey,
                        "ASessionID": aSessionID
                    },
                    data: {
                        formId: myConfig.formId,
                        projectId: myConfig.projectId,
                        userRef: $scope.strFormId,
                        weightageId: $scope.oriMsgCustomFields.weightageDBId
                    }
                }).then(function (response) {
                    if (response.data) {
                        var options = {
                            target: "blank",
                            url: response.data.prequalLink,
                            method: "POST"
                        };
                        commonApi.submitForm(options);
                        $scope.disablePrequal = true;
                    }
                }, function () {
                    ////Prequal
                    Notification.error({ title: 'Server Error', message: 'Server Error.' });
                });
            };

        var checkForMarketPlaceCustomAttr = function () {
            var isMarketPlaceFound = false,
                cutomAttrList = $scope.DS_ASI_Configurable_Attributes;
            for (var i = 0; i < cutomAttrList.length; i++) {
                var attrObj = cutomAttrList[i],
                    attrName = attrObj.Value3.toLowerCase().trim(),
                    attrCode = attrObj.Value7,
                    attrValue = attrObj.Value8.toLowerCase().trim();

                if (attrName == 'marketplace' && attrCode == '001' && attrValue == 'yes') {
                    isMarketPlaceFound = true;
                    break;
                }
            }
            $scope.isMarketPlaceFound = isMarketPlaceFound;
            return isMarketPlaceFound;
        },
            setMarketPlaceContent = function () {
                if (!checkForMarketPlaceCustomAttr()) {
                    $scope.formCustomFields.Bid_Opportunity.Is_Tender_Public = 'no';
                }
            };

        $scope.SetDistribution = function () {
            $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
            var Recipients = $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode;
            if (Recipients.length) {
                var strUserOrgs = "";
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                var closeduedate = $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE;
                for (var i = 0; i < Recipients.length; i++) {
                    var user = Recipients[i].Tenderer_Recipient.trim();
                    var strUserOrg = Recipients[i].Tenderer_Organisation.split('#')[0].trim();
                    if (strUserOrgs) {
                        strUserOrgs += ",";
                    }
                    strUserOrgs += strUserOrg;
                    if (user) {
                        setAutoDistribution(user, "3#Respond", closeduedate);
                    }
                }
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = strUserOrgs;
            }
        }
        //#region formsettings
        //form setting code
        function checkFormSetting() {
            /*====================================================================================================
                        //set and check other formsettings proper match or not
            ======================================================================================================*/
            var htMain = [
                { key:"No_of_Form_Instances", value:"0"},
                { key:"FormType", value:"Form Type"},
                { key:"Form_Template_Type", value:"HTML AppBuilder"},
                { key:"Response_Type", value:"Combined Response Will have Custom Print View"},
                { key:"Appbuilder_Code", value:"ASI"},
                { key:"Is_Import_Emailin", value:""},
                { key:"Is_Import_Emailin_Exchange", value:"Not Selected"},
                { key:"Exchange_Type", value:""},
                { key:"E_catalogue", value:"Not Selected"},
                { key:"Cross_Workspace", value:"No"},
                { key:"Use_controller", value:"No"},
                { key:"Form_Group_Code", value:"ASI"},
                { key:"Controller_Change_status", value:"No"},
                { key:"Response_allowed", value:"No"},
                { key:"Responder_Collaborate", value:"No"},
                { key:"Response_From", value:"Recipients Only"},
                { key:"Continue_Discussion", value:"No"},
                { key:"Enable_Draft_Responses", value:"No"},
                { key:"Show_Responses", value:"Always"},
                { key:"Allow_Editing_ORI", value:"No"},
                { key:"Is_Import_Editing_ORI", value:"No"},
                { key:"Action_Required", value:"For Information|0"},
                { key:"default_Action_required", value:""},
                { key:"Distribution_ORI_creation", value:"Mandatory"},
                { key:"Allow_Distribution_after_creation", value:"Yes"},
                { key:"Allow_All", value:"No"},
                { key:"Allow_Originator", value:"Yes"},
                { key:"Allow_Receipients", value:"Yes"},
                { key:"Allow_Roles", value:"No"},
                { key:"Role_Name", value:""},
                { key:"Allow_Edit_and_Forward", value:"No"},
                { key:"Automatic_publish_to_folder", value:"No"},
                { key:"Allow_Form_Associations", value:"No"},
                { key:"Associations_bypass_Form_security", value:"No"},
                { key:"Allow_Doc_Association", value:"No"},
                { key:"Default_Doc_Association", value:"Static"},
                { key:"Associations_Extend_Document_Issue", value:"No"},
                { key:"Allow_Comment_Associations", value:"No"},
                { key:"Associations_bypass_folder_security", value:"No"},
                { key:"Allow_Attribute_Associations", value:"No"},
                { key:"Allow_View_Associations", value:"No"},
                { key:"Overall_Form_Statuses", value:"No"},
                { key:"status_list", value:""},
                { key:"Closed_out_status_list", value:""},
                { key:"Restrict_Status_Change_in_View_Form", value:"No"},
                { key:"Allow_Reopening_Form", value:"Yes"},
                { key:"Originator_can_Change_Status", value:"No"},
                { key:"Is_public", value:"No"},
                { key:"Use_Form_Distribution_Groups", value:"No"},
                { key:"Allow_autocreation_on_status_change", value:"No"},
                { key:"Enable_SpellCheck", value:"Not Selected"},
                { key:"Allow_External_Access", value:"No"},
                { key:"Embed_form_Content_emails", value:"No"},
                { key:"Can_Reply_via_emails", value:"No"},
                { key:"From_Actions_Notification_Email_Subject", value:""},
                { key:"Is_Offline", value:"No"},
                { key:"Allow_Import_in_Edit_ORIValue", value:"Overwrite"},
                { key:"Allow_Import_in_Edit_ORI", value:"No"},
            ];
            //main string 
            var strmain = "Appbuilder_Code:ASI-STD-ITB$"+
            "Response_Type:	Multiple Responses Will have Custom Print View$"+
            "Response_allowed:Yes$"+
            "Responder_Collaborate:No$"+
            "Use_controller:$"+
            "Response_From:Recipients Only$"+
            "Continue_Discussion:Yes$"+
            "Show_Responses:Always$"+
            "Form_Group_Code:ITB$"+
            "Distribution_ORI_creation:$"+
            "Allow_Receipients:$"+
            "Allow_Edit_and_Forward:$"+
            "Allow_Attribute_Associations:$"+
            "Allow_Reopening_Form:$"+
            "Use_Form_Distribution_Groups:$"+
            "Action_Required:$"+
            "Overall_Form_Statuses:$"+
            "Allow_External_Access:$"+
            "Originator_can_Change_Status:$"+
            "Embed_form_Content_emails:$"+
            "Automatic_publish_to_folder:$"+
            "Allow_Form_Associations:$"+
            "Associations_bypass_Form_security:$"+
            "Allow_Doc_Association:$"+
            "Default_Doc_Association:$"+
            "Associations_Extend_Document_Issue:$"+
            "Allow_Distribution_after_creation:$"+
            "Associations_bypass_folder_security:$"+
            "Enable_SpellCheck:$"+
            "Allow_Originator:$"+
            "Is_Offline:$"+
            "Is_public:$"+
            "Allow_autocreation_on_status_change:$"+
            "Allow_View_Associations:$"+
            "Restrict_Status_Change_in_View_Form:$"+
            "Is_Import_Editing_ORI:";
            
            

            if (strmain != "") {
                if (strmain.indexOf('$') > -1) {
                    for (var i = 0; i < strmain.split('$').length; i++) {
                        var strkey = strmain.split('$')[i].split(':')[0].toString().trim();
                        var strval = strmain.split('$')[i].split(':')[1].toString().trim();
                        var index = commonApi._.findIndex(htMain, { key: strkey });
                        if (index > -1) {
                            htMain[index].value = strval;
                        }
                    }
                }
            }
            var strSettings = checkmainstringonload(htMain);
            if (strSettings != "") {
                $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following form settings not stated properly";
                $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting']=[];
               // $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";
                var arrStr = [];
                if (strSettings.indexOf('&') > -1) {
                    arrStr = strSettings.split('&');
                    for (var i = 0; i < arrStr.length; i++) {
                        var item = arrStr[i].split(':');
                        var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                        mainstrcutr.DSI_Setting_name = item[0];
                        mainstrcutr.DSI_Original_value = item[2];
                        mainstrcutr.DSI_Expected_value = item[1];
                        $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                    }
                }
                else if (strSettings.indexOf(':') > -1) {
                    arrStr = strSettings.split(':');
                    var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                    mainstrcutr.DSI_Setting_name = arrStr[0];
                    mainstrcutr.DSI_Original_value = arrStr[2];
                    mainstrcutr.DSI_Expected_value = arrStr[1];
                    $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                }
                //if formsettings are not matched
                $scope.flagIsformsetting = true;
                var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                $saveDraftBtn && ($saveDraftBtn.style.display = 'none'); 
                $scope.update();
                return;
            }
            else
            {
                $scope.flagIsformsetting = false;
            }
        }
        function checkmainstringonload(htMain) {
            var sb = "";
            if ($scope.ds_Asi_Get_All_Default_FormSettingDetails != null) {
                var temp = $scope.ds_Asi_Get_All_Default_FormSettingDetails[0];
                for (var i = 1; i < 60; i++) {
                    var splitValue = [];
                    splitValue = temp["Value" + i.toString()];
                    if (splitValue.indexOf(':') > -1) {
                        var key = splitValue.split(':')[0].trim();
                        var value = splitValue.split(':')[1].trim();
                         var ind = commonApi._.findIndex(htMain, { key: key });
                        if (ind > -1) {
                            if(htMain[ind].value.trim() != "")
                            { 
                                if (htMain[ind].value.trim().indexOf(value.trim()) == -1) {
                                    if (sb == "") {
                                        var result = getDisplayName(splitValue.split(':')[0].trim()) + ":" + htMain[ind].value + ":" + splitValue.split(':')[1];
                                        sb = result;
                                    }
                                    else {
                                        var result1 = getDisplayName(splitValue.split(':')[0].trim()) + ":" + htMain[ind].value + ":" + splitValue.split(':')[1];
                                        sb = sb.concat("&" + result1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return sb;
        }
       
        function getDisplayName(keyparameter) {
            var Hashtable = [
            { key:"Form_Group_Code",value:"Form_Group_Code"},
            { key:"No_of_Form_Instances",value:"No_of_Form_Instances"},
            { key:"FormType",value:"FormType"},
            { key:"Form_Template_Type",value:"Form_Template_Type"},
            { key:"Response_Type",value:"Response_Type"},
            { key:"Appbuilder_Code",value:"Appbuilder_Code"},
            { key:"Is_Import_Emailin",value:"Is_Import_Emailin"},
            { key:"Is_Import_Emailin_Exchange",value:"Is_Import_Emailin_Exchange"},
            { key:"Exchange_Type",value:"Exchange_Type"},
            { key:"E_catalogue",value:"E_catalogue"},
            { key:"Cross_Workspace",value:"Cross_Workspace"},
            { key:"Use_controller",value:"Use_controller"},
            { key:"Controller_Change_status",value:"Controller_Change_status"},
            { key:"Response_allowed",value:"Response_allowed"},
            { key:"Responder_Collaborate",value:"Responder_Collaborate"},
            { key:"Response_From",value:"Response_From"},
            { key:"Continue_Discussion",value:"Continue_Discussion"},
            { key:"Enable_Draft_Responses",value:"Enable_Draft_Responses"},
            { key:"Show_Responses",value:"Show_Responses"},
            { key:"Allow_Editing_ORI",value:"Allow_Editing_ORI"},
            { key:"Is_Import_Editing_ORI",value:"Is_Import_Editing_ORI"},
            { key:"Action_Required",value:"Action_Required"},
            { key:"default_Action_required",value:"Default_Action_required"},
            { key:"Distribution_ORI_creation",value:"Distribution_ORI_creation"},
            { key:"Allow_Distribution_after_creation",value:"Allow_Distribution_after_creation"},
            { key:"Allow_All",value:"Allow_Distribution_after_creation_BY_All"},
            { key:"Allow_Originator",value:"Allow_Distribution_after_creation_BY_Originator"},
            { key:"Allow_Receipients",value:"Allow_Distribution_after_creation_BY_Receipients"},
            { key:"Allow_Roles",value:"Allow_Distribution_after_creation_BY_Roles"},
            { key:"Role_Name",value:"Allow_Distribution_after_creation_BY_Role_Role_Name"},
            { key:"Allow_Edit_and_Forward",value:"Allow_Edit_and_Forward"},
            { key:"Allow_Attachments",value:"Allow_Attachments"},
            { key:"Automatic_publish_to_folder",value:"Automatic_publish_to_folder"},
            { key:"Allow_Form_Associations",value:"Allow_Form_Associations"},
            { key:"Associations_bypass_Form_security",value:"Associations_bypass_Form_security"},
            { key:"Allow_Doc_Association",value:"Allow_Doc_Association"},
            { key:"Default_Doc_Association",value:"Default_Doc_Association"},
            { key:"Associations_Extend_Document_Issue",value:"Associations_Extend_Document_Issue"},
            { key:"Allow_Comment_Associations",value:"Allow_Comment_Associations"},
            { key:"Associations_bypass_folder_security",value:"Associations_bypass_folder_security"},
            { key:"Allow_Attribute_Associations",value:"Allow_Attribute_Associations"},
            { key:"Allow_View_Associations",value:"Allow_View_Associations"},
            { key:"Overall_Form_Statuses",value:"Overall_Form_Statuses"},
            { key:"status_list",value:"status_list"},
            { key:"Closed_out_status_list",value:"Closed_out_status_list"},
            { key:"Restrict_Status_Change_in_View_Form",value:"Restrict_Status_Change_in_View_Form"},
            { key:"Allow_Reopening_Form",value:"Allow_Reopening_Form"},
            { key:"Originator_can_Change_Status",value:"Originator_can_Change_Status"},
            { key:"Is_public",value:"Form_Is_public"},
            { key:"Use_Form_Distribution_Groups",value:"Use_Form_Distribution_Groups"},
            { key:"Allow_autocreation_on_status_change",value:"Allow_autocreation_on_status_change"},
            { key:"Enable_SpellCheck",value:"Enable_SpellCheck"},
            { key:"Allow_External_Access",value:"Allow_External_Access"},
            { key:"Embed_form_Content_emails",value:"Embed_form_Content_emails"},
            { key:"Can_Reply_via_emails",value:"Can_Reply_via_emails"},
            { key:"From_Actions_Notification_Email_Subject",value:"From_Actions_Notification_Email_Subject"},
            { key:"Is_Offline",value:"Is_Form_available_Offline"},
            { key:"Embed_form_Content_in_instant_emails_Type",value:"Embed_form_Content_in_instant_emails_Type"},
            { key:"Allow_Import_in_Edit_ORIValue",value:"Allow_Import_in_Edit_ORIValue"},
            { key:"Allow_Import_in_Edit_ORI",value:"Allow_Import_in_Edit_ORI"},
            ];
            var ind = commonApi._.findIndex(Hashtable, { key: keyparameter });
            return Hashtable[ind].key;
        }
        $scope.setEndDate = function () {
            $scope.strdate = $scope.formCustomFields.Bid_Opportunity.Tender_End_Date;
            $scope.strTime = $scope.formCustomFields.Bid_Opportunity.Tender_End_Time;
            var strStartdate = $scope.formCustomFields.Bid_Opportunity.Start_Date;

            if (!$scope.strdate) {
                return true;
            }
            if ($scope.strdate && $scope.strTime) {
                var dt = new Date($scope.strdate);
                var time = convertTimeformat($scope.strTime);
                if (time) {
                    var arrtime = time.split(':');
                    dt.setHours(arrtime[0]);
                    dt.setMinutes(arrtime[1]);
                }
                $scope.formCustomFields.Bid_Opportunity.AvailabilityDate = $filter('date')(dt, 'yyyy-MM-ddTHH:mm:ss');
                $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE = $filter('date')(dt, 'yyyy-MM-ddTHH:mm:ss');
                setDistribution_Dates();
                var dtObj = new Date(strStartdate);
                if (dt.getTime() <= dtObj.getTime()) {
                    $scope.formCustomFields.Bid_Opportunity.Tender_End_Time = "";
                    alert("Invalid date and time specified !!! \n\n End date and time should be greater than release date and time");
                    return true;
                }
            }
            return false;
        }

        $scope.FillUserDetails = function (StrVal) {
            var strRole = "";
            $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode = [];
            $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
            if (StrVal) {
                strRole = StrVal.split('#')[1].trim()
                $scope.formCustomFields.Bid_Opportunity.ORI_FORMTITLE = strRole;

                $scope.Recipients = commonApi._.filter($scope.DS_PROJUSERS_ROLE, function (val) {
                    return val.Value.indexOf(strRole) != -1 && val.Name.split(',')[1].trim().indexOf(strWorkingUserOrg) < 0;
                });

                var closeduedate = $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE;
                var tempDistNode = [];
                if ($scope.Recipients && $scope.Recipients.length) {
                    for (var i = 0; i < $scope.Recipients.length; i++) {
                        var Value = $scope.Recipients[i].Value.trim();
                        var strusername = Value.split('|');
                        var strid = strusername[2].split('#')[0].trim();
                        var userwithid = "";
                        var strdistUser = commonApi._.filter($scope.DS_PROJDISTUSERS, function (val) {
                            return val.Value.split('#')[0] == strid;
                        });
                        if (strdistUser.length) {
                            userwithid = strdistUser[0].Value;
                        }
                        var strorgname = strusername[1].split(',')[1].trim();

                        $scope.Org = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                            return val.Name.indexOf(strorgname) != -1
                        });
                        var arrReceipien = angular.copy($scope.RecipientStructure);
                        arrReceipien.Tenderer_Organisation = $scope.Org[0].Value;
                        arrReceipien.Tenderer_Recipient = userwithid;
                        arrReceipien.isMarketplaceUser = $scope.isFromMarketPlace ? 'Yes' : "";
                        tempDistNode.push(arrReceipien);
                        $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                        setAutoDistribution(userwithid, "3#Respond", closeduedate);
                    }
                    $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode = _.sortBy(tempDistNode, function (num) {
                        return (num.Tenderer_Organisation).split('#')[1];
                    });
                }
                $timeout(function () {
                    $scope.OrgDuplicateCheck();
                });
            }
        };

        if (currentViewName == "ORI_VIEW") {
            setMarketPlaceContent();
            $scope.isFromMarketPlace = commonApi.getParamObj().fromMarketplace;
            if ($scope.isFromMarketPlace) {
                var bidTypeId = commonApi.getParamObj().bidTypeId,
                    bidListformId = commonApi.getParamObj().bidListformId,
                    bidType = commonApi._.filter($scope.DS_WORKSPACE_ROLES_with_ID, function (val) {
                        return val.Value.split('|')[0].trim() == bidTypeId.trim();
                    });
                if (bidType.length) {
                    $scope.formCustomFields.Bid_Opportunity.Bid_Type = bidType[0].Value;
                    $scope.FillUserDetails(bidType[0].Value);
                    if (bidListformId) {
                        $scope.oriMsgCustomFields.bidListFormId = bidListformId.split('$$')[0];
                        $scope.oriMsgCustomFields.DS_AU_OTH_FORM = "1";
                    }
                }
            }

            $scope.orgFilter = DS_PROJORGANISATIONS_ID;
            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                setClientLogo();
                checkFormSetting();
                $scope.formCustomFields.Bid_Opportunity.Start_Date = getDateTimeFromZone();
                $scope.setEndDate();
                $scope.packageFilter = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'Tender Packages' && val.Value11.indexOf('Active') != -1
                });
            }
            if ($scope.strIsDraft == "YES") {
                $timeout(function () {
                    $scope.OrgDuplicateCheck();
                });
            }
            if ($scope.strFormId == "") {
                $scope.oriMsgCustomFields.DSI_SourceTimeZone = timeZoneMap[$window.USP.timezoneId];
                $scope.oriMsgCustomFields.DateOfIssue = $scope.formatDate(new Date(), 'yy-mm-dd');
                var invitationMsg = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'InvitationMsg' && val.Value11.indexOf('Active') != -1
                });
                if (invitationMsg.length) {
                    var msg = ''
                    for (var index = 0; index < invitationMsg.length; index++) {
                        msg += invitationMsg[index].Value8;
                    }
                    $scope.formCustomFields.Bid_Opportunity.Invitation_Message = msg;
                }
                var strwkg_uset = $scope.WorkingUserID[0].Value;
                var ContactPersonFilter = commonApi._.filter($scope.DS_PROJUSERS_ROLE, function (val) {
                    return val.Value.indexOf(strwkg_uset.split('|')[0].trim()) != -1 && val.Value.indexOf('Tender Team') != -1
                });
                if (ContactPersonFilter.length) {
                    var strVal = ContactPersonFilter[0].Value.split("|")[2].split("#")[0].trim();
                    $scope.formCustomFields.Bid_Opportunity.Contact_Person_With_Id = ContactPersonFilter[0].Value;
                    $scope.formCustomFields.Bid_Opportunity.Contact_Person = ContactPersonFilter[0].Name;
                    setEmailPhoneOfContactPerson(strVal);
                    setBidAminValue(strVal);
                }

            }
            if (!$scope.strFormId) {
                fillCheckListData();
            }
            $scope.isEditOri = false;
            if ($scope.strIsDraft == "NO" && $scope.strFormId) {
                $scope.isEditOri = true;
                if ($scope.DS_ISDRAFT_FWD_MSG == "NO")
                    setDistnode();
                clearActionEditForward();
                restrictOtherUsersEditForward();
                angular.element("custom-common-dropdown[dd-name='import-excel']").hide();
                checkUserCanRespond();
                clearActionifTenderEndDatePassed();
            }
        }

        if (currentViewName != "ORI_VIEW" && $scope.strFormId && $scope.strIsDraft != "YES") {
            setUpdatedAddendumDates();
        }
        if (currentViewName == "ORI_PRINT_VIEW") {
            $scope.DS_ASI_STD_PACKAGE_DOCS = $scope.getValueOfOnLoadData('DS_ASI_STD_PACKAGE_DOCS');
            $scope.DS_ASI_STD_ASSOCIATED_DOCS_UPDATES = $scope.getValueOfOnLoadData('DS_ASI_STD_ASSOCIATED_DOCS_UPDATES');
            $scope.loggedInUserRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_WITHOUT_ROLE');
            if ($scope.loggedInUserRole.length) {
                loggedInUserId = $scope.loggedInUserRole[0].Value1.split('|')[0].trim();
                loggedInUserName = $scope.loggedInUserRole[0].Value2;
                loggedInUserNameOrg = loggedInUserName.split(',')[1].trim();

                if (loggedInUserNameOrg === orgOrganization) {
                    $scope.isSameOrg = true;
                }
            }

            var dsMktWtgUrlDTLS = $scope.getValueOfOnLoadData('DS_MKT_WTG_URL_DTLS');
            $scope.weightageURL = dsMktWtgUrlDTLS[0] && dsMktWtgUrlDTLS[0].URL2;

            clearActionifTenderEndDatePassed();
            if(myConfig.aSessionID && myConfig.aSessionID != 'null'){
                getHideExpressInterestOnBidData();
            }
            hideSubmitButton();
            hidePrequalButton();
            hideQueryButton({
                originatorOrg: orgOrganization,
                loggedInUserOrg: loggedinUserOrg,
                strWorkingUserOrg: strWorkingUserOrg
            });
            hideCommButton();
            hideAddendumButton();
            hidePfcButton();
            hideRegisterButton();
            $scope.oriMsgCustomFields.RejectByAdminFlag = "";
            var strWorkingUser = $scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER.split(',')[0];

            var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value40 == 'Reject' && val.Value38.indexOf(strWorkingUser) > -1;
            });
            if (AllResData && AllResData.length) {
                $scope.oriMsgCustomFields.RejectByAdminFlag = "yes";
            }

            var strReviewDate = $scope.formCustomFields.Bid_Opportunity.Review_Date;
            if (strReviewDate) {
                if ($scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && strReviewDate > $scope.strTodayDateTime) {
                    $scope.oriMsgCustomFields.DSI_Reviewdate_flag = "Yes";
                } else {
                    $scope.oriMsgCustomFields.DSI_Reviewdate_flag = "No";
                }
            }
            setPackageDataPrintView();

            $scope.bidRecpUserObj = commonApi._.filter($scope.DS_ASI_STD_ADD_BM_Bid_Recipients, function (val) {
                return val.Value5.trim() == CurrentUserID;
            });


        }
        if (currentViewName == "RES_VIEW") {
            angular.element("custom-common-dropdown[dd-name='import-excel']").hide();
            clearActionifTenderEndDatePassed();
            checkForMultiResponse();
            setClientLogo();
            $scope.formCustomFields.Bid_Response.Response_Date = $scope.formatDate(new Date(), 'yy-mm-dd');
            $scope.formCustomFields.Bid_Opportunity.ResUserId = $scope.WorkingUserID['0'].Value;
            if ($scope.DS_ISDRAFT_RES_MSG == "YES") {
                if ($scope.formCustomFields.Bid_Response.Comments) {
                    $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "13";
                }
                $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users.DS_ACTIONDUEDATE = calculateDistDate(5);

                var taxname = $scope.oriMsgCustomFields.Tax_Name + " Tax";
                if ($scope.oriMsgCustomFields.DSI_Tax_Req == "YES") {
                    $scope.TAX = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                        return val.Value3 == taxname && val.Value11.indexOf('Active') != -1
                    });
                }
            } else {
                var strMessageId = "";

                if ($scope.DS_INCOMPLETE_MSG_ACTIONS[0]) {
                    strMessageId = $scope.DS_INCOMPLETE_MSG_ACTIONS[0].Name.split("|")[2].trim();
                }
                var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                    return val.Value29 == strMessageId;
                });

                setResponseData(AllResData, strMessageId);
                if ($scope.oriMsgCustomFields.DSI_Table_Type == "YES")
                    setPackageDataMLDL(strMessageId);
                else
                    setPackageData(AllResData);

                var taxname = $scope.oriMsgCustomFields.Tax_Name + " Tax";
                if ($scope.oriMsgCustomFields.DSI_Tax_Req == "YES") {
                    $scope.TAX = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                        return val.Value3 == taxname && val.Value11.indexOf('Active') != -1
                    });
                }


                if ($scope.oriMsgCustomFields.DSI_Doc_Checklist == "YES") {
                    setDocChecklistData();
                }
                if ($scope.oriMsgCustomFields.DSI_Question_CheckList == "YES") {
                    setQuestionChecklistData();
                }
                $scope.formCustomFields.Bid_Opportunity.ResponseFlag = "Accepted";

            }
            hideBidderView();
            hideParticipateButton();
            hideDeclineButton();
            hideResBiddAdminView();
            checkTenderEndDatePassedMsg();
            hideSealedPkgReviewDateChk();
        }
        if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW") {
            checkForMultiResponse();
            finalMessages();
            bidChk();
            checkUserCanRespond();
            $scope.oriMsgCustomFields.CurentViewCheckforRes = "no";
        }
        if (currentViewName == "RES_PRINT_VIEW") {
            finalMessages();
            hideResBiddAdminPrintview();
            hideResBidderResPrintview();
            hideDeclineMsg();

        }
        if (currentViewName == "RES_PRINT_VIEW" || currentViewName == "ORI_PRINT_VIEW") {
            hideSealedPkgMsg();
        }
        if (currentViewName == "FORM_PRINT_VIEW") {
            if ($scope.DS_FORMSTATUS == "Open") {
                setFinalMessageForReject();
            }
        }
        $scope.update();
        //declare structure for repeating

        $scope.PFCStructure = {
            PFCID: "",
            PFCPackage: "",
            PFCTitle: "",
            PFCDescription: "",
            PFC_URL: ""
        }
        $scope.QueryStructure = {
            BIDQueryID: "",
            BIDQueryPackage: "",
            BIDQueryTitle: "",
            BIDQueryDescription: "",
            BIDQueryID_URL: "",
            BIDQueryStatus: ""
        }
        $scope.CommStructure = {
            CommunicationID: "",
            CommunicationPackage: "",
            CommunicationTitle: "",
            CommunicationUserref: "",
            CommunicationIDURL: "",
            CommunicationReason: ""
        }

        $timeout(function () {
            $scope.expandTextAreaOnLoad();

        }, 1000);

        $scope.AddNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
        $scope.addNewCheckItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };
        $scope.DeleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };
        $scope.DeleteItem = function (obj, repeatingData) {
            //delete data by index
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };

        $window.addEventListener('message', function (e) {
            if (typeof e.data !== 'string') { return; }
            if (e.data == 'PublicURLreload') {
                $window.reloadPublicURL();
            }
        }, false);

        $window.reloadPublicURL = function () {
            if ($scope.oriMsgCustomFields && $scope.oriMsgCustomFields.DS_FORM_PUBLIC_URL) {
                $window.location = $scope.oriMsgCustomFields.DS_FORM_PUBLIC_URL;
            } else {
                $window.location.reload();
            }
        };

        $window.ITB_FinalCallBack = function () {
            return $scope.checkMandatoryFields();
        }
        $window.ITB_FinalCallBackDraft = function () {

            if (currentViewName == "ORI_VIEW") {
                if (!$scope.canUserEdit) {
                    alert("You are not authorised to edit the form. Please contact your Administrator.");
                    return true;
                }

                if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == 'yes') {
                    alert($scope.formCustomFields.Bid_Opportunity.TenderEndDateMessage);
                    return true;
                }

            }
            if (currentViewName == "RES_VIEW") {
                if (!$scope.isTenderEndDatePassed && $scope.formCustomFields.Bid_Opportunity.ResWorkinguserId != $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                    alert($scope.formCustomFields.Bid_Opportunity.TenderEndDateMessage);
                    return true
                }
                if ($scope.ishideResBiddAdminview && $scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                    alert("It is a sealed package. You can view it after review date has passed.");
                    return true;
                }
            }
            if (!$scope.canUserRespond) {
                alert("You are Replaying on old message. Please select latest message.");
                return true;
            }

            $scope.oriMsgCustomFields['lastIndex'] = parseInt(lastIndex);
            if ($scope.deletedSectionSequenceId)
                $scope.oriMsgCustomFields['deletedSectionSequenceId'] = $scope.deletedSectionSequenceId || [];
            return false;
        };

        $scope.checkMandatoryFields = function () {
            if ($scope.submitFlag) {
                return false;
            }
            clearActionifTenderEndDatePassed();
            if (currentViewName == "ORI_VIEW") {
                if ($scope.flagIsformsetting) {
                    Notification.error({
                        title: 'Form Setting',
                        message: "Form setting not statted properly."
                    });
                    return true;
                }
                $scope.oriMsgCustomFields['lastIndex'] = parseInt(lastIndex);
                if (!$scope.formCustomFields.Bid_Opportunity.Is_Tender_Public) {
                    alert("Please select BID type first.");
                    return true;
                }

                if (!$scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode.length && $scope.formCustomFields.Bid_Opportunity.Is_Tender_Public != 'yes') {
                    alert("You can not create the form because you have missed to add recipients.");
                    return true;
                }

                if (!$scope.canUserEdit) {
                    alert("You are not authorised to edit the form. Please contact your Administrator.");
                    return true;
                }

                if (!$scope.canUserRespond) {
                    alert("You are Replaying on old message. Please select latest message.");
                    return true;
                }

                if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == 'yes') {
                    alert($scope.formCustomFields.Bid_Opportunity.TenderEndDateMessage);
                    return true;
                }

                if ($scope.strIsDraft == "NO" && $scope.strFormId) {
                    distributeEditFroward()
                    $scope.oriMsgCustomFields['lastIndex'] = parseInt(lastIndex);
                    if ($scope.deletedSectionSequenceId)
                        $scope.oriMsgCustomFields['deletedSectionSequenceId'] = $scope.deletedSectionSequenceId || [];
                }

                if($scope.isFromMarketPlace){
                    var obj = { 'message': 'closeModal' };			
			        window.top.opener.postMessage(JSON.stringify(obj), "*");
                }
                $scope.oriMsgCustomFields.DSI_orignatorID = $scope.WorkingUserID[0].Value.split('|')[0].trim();
                $scope.oriMsgCustomFields.DSI_orignatorEmail = fetchUserDetails[0].Value1.trim();

            }
            var strResWorkinguserId = $scope.formCustomFields.Bid_Opportunity.ResWorkinguserId;
            var strResBidAdmin = $scope.formCustomFields.Bid_Opportunity.ResBidAdmin;
            if (currentViewName == "RES_VIEW") {
                if (!$scope.canUserRespond) {
                    alert("You are Replaying on old message. Please select latest message.");
                    return true;
                }
                if (!$scope.isTenderEndDatePassed && strResWorkinguserId != strResBidAdmin) {
                    alert($scope.formCustomFields.Bid_Opportunity.TenderEndDateMessage);
                    return true;
                }
                if ($scope.ishideResBiddAdminview && strResWorkinguserId == strResBidAdmin) {
                    alert("It is a sealed package. You can view it after review date has passed.");
                    return true;
                }
                if (!$scope.oriMsgCustomFields.Flag && strResWorkinguserId == strResBidAdmin) {
                    alert("Bid / Tender has already been awarded to Your Organization");
                    return true;
                }
                if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == 'yes' && $scope.formCustomFields.Bid_Information.Bid_Evaluation_Status=='') {
                    alert($scope.formCustomFields.Bid_Opportunity.TenderEndDateMessage);
                    return true;
                }
                if ($scope.formCustomFields.MessageForMultiResponse && strResWorkinguserId != strResBidAdmin) {
                    alert($scope.formCustomFields.MessageForMultiResponse);
                    return true;
                }
            }

            return false;
        };


        function setAutoDistribution(strUser, strAction, strDueDate) {
            //copy structure of distribution nodes

            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistricution = angular.copy($scope.DistributionStructure)
            structDistricution.DS_PROJDISTUSERS = strUser;
            structDistricution.DS_FORMACTIONS = strAction;
            structDistricution.DS_ACTIONDUEDATE = strDueDate

            $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users.push(structDistricution);
        };

        $scope.SetPackageType = function (str) {
            if (str == "Sealed") {
                $scope.formCustomFields.Bid_Opportunity.FL_DISABLE_ASSOC = "1";
            } else {
                $scope.formCustomFields.Bid_Opportunity.FL_DISABLE_ASSOC = "";
            }
        }

       

        function setDistnode() {
            $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode = [];
            var recipients = $scope.DS_ASI_STD_ADD_BM_Bid_Recipients;
            if (recipients.length) {
                for (var i = 0; i < recipients.length; i++) {
                    var arrReceipien = angular.copy($scope.RecipientStructure);
                    arrReceipien.Tenderer_Organisation = recipients[i].Value3.trim() + '#' + recipients[i].Value4.trim();
                    arrReceipien.Tenderer_Recipient = recipients[i].Value5.trim() + '#' + recipients[i].Value6.trim().replace(' (' + recipients[i].Value3.trim() + ')', '').trim();
                    $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode.push(arrReceipien);
                }
            }

        }
        $scope.SetContactInformation = function (strVal) {
            var strUserId = "";
            if (strVal) {
                strUserId = strVal.split("|")[2].split("#")[0].trim();
                $scope.formCustomFields.Bid_Opportunity.Contact_Person = strVal.split('#')[1].trim();
            }
            setEmailPhoneOfContactPerson(strUserId);
            setBidAminValue(strUserId);
        };

        function setBidAminValue(strVal) {
            var bidAdmin = commonApi._.filter($scope.DS_PROJUSERS_ROLE, function (val) {
                return val.Value.split('|')[2].split("#")[0].trim() == strVal;
            });

            if (bidAdmin.length) {
                $scope.formCustomFields.Bid_Opportunity.Bid_Administrator = bidAdmin[0].Value.split('|')[2].trim();
            }
        }

        function setEmailPhoneOfContactPerson(strVal) {
            if (strVal) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_PROJUSER_DETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_PROJUSER_DETAILS",
                            "fieldValue": strVal
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var datauser = angular.fromJson(response.data['DS_PROJUSER_DETAILS']);
                        if (datauser && datauser.Items.Item.length) {
                            var strValue = datauser.Items.Item[0].Value.trim();
                            $scope.formCustomFields.Bid_Opportunity.Contact_No = strValue.split('|')[2].trim();
                            $scope.formCustomFields.Bid_Opportunity.Email_Address = strValue.split('|')[3].trim();
                        }
                    }
                });

            } else {
                $scope.formCustomFields.Bid_Opportunity.Contact_No = "";
                $scope.formCustomFields.Bid_Opportunity.Email_Address = "";
            }
        }
        $scope.CheckDuplicate = function (args) {
            checkDuplicateValue(args);
        };

        function checkDuplicateValue(args) {
            var currentIndex = args.repeatObj.indexOf(args.curObj);
            angular.forEach(args.repeatObj, function (item, index) {
                if (currentIndex != index && args.value != "" && item[args.objName] == args.value) {
                    alert("Duplicate " + args.msg + " selected !!!\n\nSelect a different " + args.msg);
                    args.curObj[args.objName] = "";
                    return true;
                }
            });
            return false;
        }



        $scope.CalculateCost = function (args) {
            if (args) {
                var total = 0;
                var strQty = args.curObj.Quantity;
                var strRate = args.curObj.Rate;
                if (!strQty) {
                    strQty = 0;
                }
                if (!strRate) {
                    strRate = 0;
                }
                total = parseFloat(strQty) * parseFloat(strRate);
                args.curObj.Value = total.toFixed(2);
            }
            setNetSum();
        }
        $scope.OnUomChange = function (args) {
            var strVal = args.curObj.UOM;
            if (strVal && strVal.indexOf('QRO') > -1) {
                args.curObj.Quantity = '0.00';
                if (currentViewName == "RES_VIEW") {
                    args.curObj.EditFlag = "|1";
                    $scope.CalculateTotal(args);
                }
            } else { if (currentViewName == "RES_VIEW") { args.curObj.EditFlag = ""; } }
        }
        $scope.OnTaxChange = function (args) {
            $scope.CalculateTotal(args);
        }


        $scope.CalculateTotal = function (args) {
            var currObj = args.curObj;
            var parentGUId = currObj.immediate_parentGUId;
            if (args.value != "") {
                var total = 0;
                var strQty = currObj.Quantity;
                var strRate = currObj.Rate;
                var strTax = currObj.Tax;
                if (!strQty) {
                    strQty = 0;
                }
                if (!strRate) {
                    strRate = 0;
                }
                if (!strTax) {
                    strTax = 0;
                }
                if (isNaN(Number(strQty))) {
                    strQty = 0;
                }
                total = Number(strQty) * Number(strRate);
                if (strTax != 0 && total != 0) {
                    total = total + (total * (strTax / 100))
                }
                currObj.Total = total.toFixed(2);
            }
            var parentObj = commonApi._.filter($scope.oriMsgCustomFields.Section_Details.sectionsSetup, function (elem) {
                return elem.Guid == parentGUId;
            })[0];

            if (parentObj && parentObj.immediate_parentGUId) {
                dochildTotal(parentObj);
                var tmpArgs = {
                    curObj: parentObj,
                    value: ""
                }

                $scope.CalculateTotal(tmpArgs);
            } else {
                setMainTotal(currObj);
                setNetSum();
            }


        }

        function dochildTotal(args) {
            var arrCurr = args;
            var Guid = arrCurr.Guid
            var rate = 0.00;

            arrCurr = commonApi._.filter($scope.oriMsgCustomFields.Section_Details.sectionsSetup, function (elem) {
                return elem.immediate_parentGUId == Guid;

            });
            for (var i = 0; i < arrCurr.length; i++) {
                if (arrCurr[i].Total) {
                    rate = parseFloat(rate) + parseFloat(arrCurr[i].Total);
                }
            }
            if (arrCurr.length > 0) {
                args.Total = rate.toFixed(2);
            }
        }


        function setMainTotal(args) {
            var parentGUId = args.parentGUId;
            var arrMain;
            var mainObj = commonApi._.filter($scope.oriMsgCustomFields.Section_Details.sectionsSetup, function (elem) {
                return elem.Guid == parentGUId;
            })[0];

            var immediate_childGUId = mainObj.immediate_childGUId;
            var rate = 0.00;
            arrMain = commonApi._.filter($scope.oriMsgCustomFields.Section_Details.sectionsSetup, function (elem) {
                return immediate_childGUId.indexOf(elem.Guid) > -1;
            });
            for (var i = 0; i < arrMain.length; i++) {
                if (arrMain[i].Total) {
                    rate = parseFloat(rate) + parseFloat(arrMain[i].Total);
                }
            }
            if (arrMain.length > 0) {
                mainObj.Total = rate.toFixed(2);
            }

        }
        $scope.ResetCounter = function () {
            var repeating = $scope.oriMsgCustomFields.Bid_Schedule.Bid_Detailed_Schedule;
            var iCnt = 1;
            if (repeating) {
                for (var i = 0; i < repeating.length; i++) {
                    repeating[i].ID = iCnt;
                    iCnt++;
                }
            }
        }


        function convertTimeformat(str) {
            var hours = Number(str.match(/^(\d+)/)[1]);
            var minutes = Number(str.match(/:(\d+)/)[1]);
            var AMPM = str.match(/\s(.*)$/)[1];
            if (AMPM == "PM" && hours < 12) hours = hours + 12;
            if (AMPM == "AM" && hours == 12) hours = hours - 12;
            var sHours = hours.toString();
            var sMinutes = minutes.toString();
            if (hours < 10) sHours = "0" + sHours;
            if (minutes < 10) sMinutes = "0" + sMinutes;
            return sHours + ":" + sMinutes
        }

        $scope.SetReviewDate = function () {
            $scope.strdate = $scope.formCustomFields.Bid_Opportunity.Tender_Review_Date;
            $scope.strTime = $scope.formCustomFields.Bid_Opportunity.Tender_Review_Time;
            var strPkgType = $scope.formCustomFields.Bid_Opportunity.Pkg_Type;
            var straEndDate = $scope.formCustomFields.Bid_Opportunity.AvailabilityDate;
            var strEnddate = $scope.formCustomFields.Bid_Opportunity.Tender_End_Date;
            if (!$scope.strdate && strPkgType == 'Sealed') {
                return true;
            }
            if ($scope.strdate && strEnddate) {
                var reviewDtobj = new Date($scope.strdate);
                var endDtobj = new Date(strEnddate);

                if (reviewDtobj < endDtobj) {
                    $scope.formCustomFields.Bid_Opportunity.Tender_Review_Date = "";
                    alert("Invalid date specified !!! \n\n Tender Review date should be greater than or equal to Tender End date");
                    return true;
                }
            }
            if ($scope.strdate && $scope.strTime) {
                var dt = new Date($scope.strdate);
                var time = convertTimeformat($scope.strTime);
                if (time) {
                    var arrtime = time.split(':');
                    dt.setHours(arrtime[0]);
                    dt.setMinutes(arrtime[1]);
                }
                $scope.formCustomFields.Bid_Opportunity.Review_Date = $filter('date')(dt, 'yyyy-MM-ddTHH:mm:ss');
                var dtobj = new Date(straEndDate);
                if (dt.getTime() <= dtobj.getTime()) {
                    $scope.formCustomFields.Bid_Opportunity.Tender_Review_Date = "";
                    $scope.formCustomFields.Bid_Opportunity.Tender_Review_Time = "";
                    alert("Invalid date and time specified !!! \n\n Tender Review date and time should be greater than Tender End date and time");
                    return true;
                }
            }

            return false;
        }

        $scope.SetReviewTime = function () {
            $scope.strTime = $scope.formCustomFields.Bid_Opportunity.Tender_Review_Time;
            var strPkgType = $scope.formCustomFields.Bid_Opportunity.Pkg_Type;
            if (!$scope.strTime && strPkgType == 'Sealed') {
                return true;
            }
            return false;
        }

        function setDistribution_Dates() {
            var distnodes = $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users;
            $scope.closeduedate = $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE;
            if (distnodes && distnodes.length) {
                for (var i = 0; i < distnodes.length; i++) {
                    distnodes[i].DS_ACTIONDUEDATE = $scope.formatDate(new Date($scope.closeduedate), 'yy-mm-dd');
                }
            }
        }

        $scope.OrgDuplicateCheck = function () {
            var repNodes = $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode;
            if (repNodes && repNodes.length) {
                for (var i = 0; i < repNodes.length; i++) {
                    $scope.ddChange({
                        repeatObj: $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode,
                        objName: 'Tenderer_Organisation'
                    });
                }
            }
        }

        $scope.ddChange = function (args) {
            $scope.arrMain = [];
            var isValidFlag = false,
                formNode = this.myform;

            for (var index = 0; index < args.repeatObj.length; index++) {
                var element = args.repeatObj[index];
                if (element.isMarketplaceUser == 'Yes') {
                    $scope.arrMain.push(element[args.objName]);
                    continue;
                }
                if ($scope.arrMain.indexOf(element[args.objName]) > -1) {
                    isValidFlag = true;
                    formNode[args.objName + index].$setValidity('duplicate', !isValidFlag)
                } else {
                    $scope.arrMain.push(element[args.objName]);
                    isValidFlag = false;
                    formNode[args.objName + index].$setValidity('duplicate', !isValidFlag)
                }
            }
        }
        $scope.downloadReport = function (form_template_name, Report_format) {
            $window.showSelectedReportfromApp(form_template_name, Report_format);
        }

        $scope.launchCommmunicationForm = function () {
            if (localStorage) {
                localStorage.setItem("formcode_num", $scope.strFormId);
            }
            launchCreateForm("ASI-STD-COMM");
        }

        $scope.launchPFCForm = function () {
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '1';
            $window.prePopulatemapping['SRC1'] = $scope.strFormId;
            $window.prePopulatemapping['TG1'] = 'Select_ITB';
            if (localStorage) {
                localStorage.setItem("formcode_num", $scope.strFormId);
            }
            launchCreateForm("ASI-STD-PCL");
        }
        //Sign up click event to redirect in the marketplace page.
        $scope.callMarketSignup = function (){
            window.open(window.marketPlaceServiceURL + "?origin=true&signup=true","_blank");
        };

        $scope.launchSuppForm = function () {
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '1';
            $window.prePopulatemapping['SRC1'] = $scope.strFormId;
            $window.prePopulatemapping['TG1'] = 'Select_ITB';
            if (localStorage) {
                localStorage.setItem("formcode_num", $scope.strFormId);
            }
            launchCreateForm("ASI-STD-SUP");
        };

        $scope.launchAddendumForm = function () {
            $window.DP_DOC_ASSOC = 'DS_ASI_STD_ASSOCIATED_DOCS_UPDATES';
            $window.DP_FORM_ASSOC = '';
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['TOTALMAPPING'] = '1';
            $window.prePopulatemapping['SRC1'] = '/my:myFields/my:FORM_CUSTOM_FIELDS/my:Bid_Opportunity/my:ORI_FORMTITLE';
            $window.prePopulatemapping['TG1'] = 'ORI_FORMTITLE';
            if (localStorage) {
                localStorage.setItem("formcode_num", $scope.strFormId);
            }
            launchCreateForm("ASI-STD-ADD");
        }

        $scope.launchQueryForm = function () {
            $window.prePopulatemapping = new Object();
            $window.prePopulatemapping['TOTALMAPPING'] = '4';
            $window.prePopulatemapping['SRC1'] = '/my:myFields/my:FORM_CUSTOM_FIELDS/my:Bid_Opportunity/my:ORI_FORMTITLE';
            $window.prePopulatemapping['TG1'] = 'ORI_FORMTITLE';
            $window.prePopulatemapping['SRC2'] = '/my:myFields/my:FORM_CUSTOM_FIELDS/my:Bid_Opportunity/my:ORI_USERREF';
            $window.prePopulatemapping['TG2'] = 'ORI_USERREF';
            $window.prePopulatemapping['SRC3'] = '/my:myFields/my:FORM_CUSTOM_FIELDS/my:Bid_Opportunity/my:Contact_Person';
            $window.prePopulatemapping['TG3'] = 'TenderContactPerson';
            $window.prePopulatemapping['SRC4'] = '/my:myFields/my:FORM_CUSTOM_FIELDS/my:Bid_Opportunity/my:Contact_No';
            $window.prePopulatemapping['TG4'] = 'TenderContactNumber';
            if (localStorage) {
                localStorage.setItem("formcode_num", $scope.strFormId);
            }
            launchCreateForm("ASI-STD-TND");
        }

        $scope.copyPublicLink = function () {
            $timeout(function () {
                $element.find('#publicLink').select();
                $element.find('#publicLinkBtn').click();
            });
        }

        $scope.isCopiedClass = false;
        $scope.onCopySuccess = function (e) {
            $scope.isCopiedClass = true;
            $timeout(function () {
                $scope.isCopiedClass = false;
                $scope.isCopyOpen = false;
            }, 1000);
        };

        $scope.onCopyError = function (e) {
            if (myConfig.applicationId === 2)
                return;

            api.copyToClipboard(e, e.text);
            $scope.isCopyOpen = false;
        };

        $scope.launchExpressinterestForm = function () {
            if ((myConfig.aSessionID && myConfig.aSessionID != 'null') || (typeof $window.USP != 'undefined' && $window.USP && $window.USP.aSessionId && $window.USP.aSessionId != 'null')) {
                // work this logic only for the publicView forms.
                createEOIForm();
            } else {
                var relocationConfirm = confirm("To Express Interest, You need to Login first. Click on 'OK' to Login.");
                if (relocationConfirm) {
                    $window.location = $window.marketPlaceServiceURL+"?origin=true";
                }
            }
        }
        $scope.launchPrequaForm = function () {
            if (myConfig.aSessionID == 'null') {
                if ($scope.$parent && $scope.$parent.$parent && $scope.$parent.$parent.loginMarketplace) {
                    $scope.$parent.$parent.loginMarketplace()
                } else {
                    $window.alert("You need to login first to submit prequal");
                }
                return;
            }
            if ((myConfig.aSessionID && myConfig.aSessionID != 'null') || (typeof $window.USP != 'undefined' && $window.USP && $window.USP.aSessionId && $window.USP.aSessionId != 'null')) {
                // work this logic only for the publicView forms.
                createPrequalForm();
            } else {
                var relocationConfirm = confirm("To Prequal Form, You need to Login first. Click on 'OK' to Login.");
                if (relocationConfirm) {
                    $window.location = $window.marketPlaceServiceURL+"?origin=true";
                }
            }
        }
        $scope.viewPrequalForm = function () {
            if ($scope.oriMsgCustomFields.DSI_Prequal_URL) {
                var options = {
                    target: "blank",
                    url: $scope.oriMsgCustomFields.DSI_Prequal_URL,
                    method: "POST"
                };
                // This function submit form from common service.
                commonApi.submitForm(options);
            }
        }

        function hideQueryButton(paramObj) {
            if ($scope.WorkingUserID.length) {
                var ContactPerson = commonApi._.filter($scope.DS_ASI_STD_ADD_BM_Bid_Recipients, function (val) {
                    return val.Value5.trim() == CurrentUserID;
                }),
                    splittedloggedInUserRoles = $scope.DS_WORKINGUSER_ALL_ROLES.length && $scope.DS_WORKINGUSER_ALL_ROLES[0].Value.split(','),
                    isUserTenderTeamMember = false;

                for (var i = 0; i < splittedloggedInUserRoles.length; i++) {
                    isUserTenderTeamMember = (splittedloggedInUserRoles[i].trim().toLowerCase() == 'tender team');
                    if (isUserTenderTeamMember) {
                        break;
                    }
                }

                if (($scope.strIsDraft == "YES") || ($scope.DS_FORMSTATUS == "Closed" || $scope.DS_FORMSTATUS.indexOf("Award") > -1) || (paramObj.originatorOrg === paramObj.strWorkingUserOrg) || isUserTenderTeamMember || (!ContactPerson.length) || ($scope.formCustomFields.Bid_Opportunity.ResponseFlag.indexOf("Reject") > -1) || ($scope.oriMsgCustomFields.RejectByAdminFlag.toLowerCase() == "yes")) {
                    $scope.ishideQueryButton = true;
                }
            } else {
                $scope.ishideQueryButton = true;
            }
        }

        function hideCommButton() {
            if ($scope.WorkingUserID.length) {
                var ContactPerson = commonApi._.filter($scope.DS_WORKINGUSER_ALL_ROLES, function (val) {
                    return val.Value.indexOf('Tender Team') != -1
                });
                if ($scope.strIsDraft == "YES") {
                    $scope.ishideCommButton = true;
                } else if (!ContactPerson.length) {
                    $scope.ishideCommButton = true;
                }
            } else {
                $scope.ishideCommButton = true;
            }
        }

        function hideSubmitButton() {
            if ($scope.WorkingUserID.length) {
                var ContactPerson = commonApi._.filter($scope.DS_ASI_STD_ADD_BM_Bid_Recipients, function (val) {
                    return val.Value5 == CurrentUserID;
                });

                if ($scope.strIsDraft == "YES") {
                    $scope.ishideSubmitButton = true;
                } else if ($scope.DS_FORMSTATUS == "Closed" || $scope.DS_FORMSTATUS.indexOf("Award") > -1) {
                    $scope.ishideSubmitButton = true;
                } else if ($scope.formCustomFields.MessageForMultiResponse) {
                    $scope.ishideSubmitButton = true;
                } else if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag.indexOf("Reject") > -1) {
                    $scope.ishideSubmitButton = true;
                } else if ($scope.DS_ORIGINATOR.indexOf($scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER) > -1) {
                    $scope.ishideSubmitButton = true;
                } else if (!ContactPerson.length) {
                    $scope.ishideSubmitButton = true;
                } else if ($scope.oriMsgCustomFields.RejectByAdminFlag.toLowerCase() == "yes") {
                    $scope.ishideSubmitButton = true;
                }
            } else {
                $scope.ishideSubmitButton = true;
            }
        }

        function hidePrequalButton() {
            var DS_ASI_STD_CHECK_EOI_USER_VALIDATE = $scope.getValueOfOnLoadData('DS_ASI_STD_CHECK_EOI_USER_VALIDATE')[0],
                buyerOrgId = '',
                vendorOrgId = '';
            buyerOrgId = DS_ASI_STD_CHECK_EOI_USER_VALIDATE.Value4;
            vendorOrgId = DS_ASI_STD_CHECK_EOI_USER_VALIDATE.Value5;
            if ($scope.strIsDraft == "YES" || $scope.oriMsgCustomFields.Enable_form_public_link == 'No' || buyerOrgId == vendorOrgId) {
                $scope.ishidePrequalButton = true;
                $scope.ishideViewPrequalButton = true;
            } else {
                var asiValidateprequal = $scope.getValueOfOnLoadData('DS_ASI_STD_VALIDATE_PREQUAL');
                if (asiValidateprequal.length > 0 && asiValidateprequal[0].Value7 != '4' && asiValidateprequal[0].Value7 != "") {
                    $scope.ishidePrequalButton = true;
                    $scope.oriMsgCustomFields.DSI_Prequal_URL = myConfig.baseUrl + asiValidateprequal[0].URL6;
                } else {
                    $scope.ishideViewPrequalButton = true;
                }
            }
        }

        function hideAddendumButton() {
            if ($scope.WorkingUserID.length) {
                var contactPerson = commonApi._.filter($scope.DS_WORKINGUSER_ALL_ROLES, function (val) {
                    return val.Value.indexOf('Tender Team') != -1
                });
                if ($scope.strIsDraft == "YES") {
                    $scope.ishideAddendumButton = true;
                } else if ($scope.DS_FORMSTATUS == "Closed" || $scope.DS_FORMSTATUS.indexOf("Award") > -1) {
                    $scope.ishideAddendumButton = true;
                } else if (!contactPerson.length && $scope.DS_ORIGINATOR.indexOf($scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER) < 0 && CurrentUserID != $scope.formCustomFields.Bid_Opportunity.Bid_Administrator.split('#')[0].trim()) {
                    $scope.ishideAddendumButton = true;
                } else if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag.indexOf("Reject") > -1) {
                    $scope.ishideAddendumButton = true;
                } else if ($scope.oriMsgCustomFields.RejectByAdminFlag.toLowerCase() == "yes") {
                    $scope.ishideAddendumButton = true;
                }
            } else {
                $scope.ishideAddendumButton = true;
            }
        }

        function hidePfcButton() {
            if ($scope.WorkingUserID.length) {
                if ($scope.strIsDraft == "YES") {
                    $scope.ishidePFCButton = true;
                } else if ($scope.DS_ORIGINATOR.indexOf($scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER) < 0 && CurrentUserID != $scope.formCustomFields.Bid_Opportunity.Bid_Administrator.split('#')[0].trim()) {
                    $scope.ishidePFCButton = true;
                } else if ($scope.DS_FORMSTATUS == "Closed" || $scope.DS_FORMSTATUS.indexOf("Award") > -1) {
                    $scope.ishidePFCButton = true;
                }
            } else {
                $scope.ishidePFCButton = true;
            }
        }
        function hideRegisterButton() {
            var aSessionID = "";
            if (typeof (USP) != "undefined") { aSessionID = USP.aSessionId; } else { aSessionID = myConfig.aSessionID; }
            if (aSessionID && aSessionID !='null')  {
                $scope.ishideRegisterButton = true;
            } else {
                if ($scope.strIsDraft == "YES") {
                    $scope.ishideRegisterButton = true;
                }  else if ($scope.DS_FORMSTATUS == "Closed" || $scope.DS_FORMSTATUS.indexOf("Award") > -1) {
                    $scope.ishideRegisterButton = true;
                }
            }
        }

        function getDateTimeFromZone() {
            var offset = 0;
            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                Date.prototype.stdTimezoneOffset = function () {
                    var jan = new Date(this.getFullYear(), 0, 1);
                    var jul = new Date(this.getFullYear(), 6, 1);
                    return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
                }
                
                Date.prototype.isDstObserved = function () {
                    return this.getTimezoneOffset() < this.stdTimezoneOffset();
                }
                
                var today = new Date();
                if (today.isDstObserved()) { 
                    offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
                } else {
                    offset = $window.USP.localeVO._timezone.rawOffset;
                }
                $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;

            } else {
                if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails && $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails.length) {
                    offset = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value11;
                }
            }

            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
            return nd;
        }

        $scope.oriprintviewtabs = [{
            title: 'Information',
            url: 'Information.html',
            isVisible: true
        }, {
            title: 'Tracker',
            url: 'Tracker.html',
            isVisible: true
        }, {
            title: 'Addendum Information',
            url: 'Addendum_Information.html',
            isVisible: true
        }, {
            title: 'Queries',
            url: 'Other_Information.html',
            isVisible: true
        }, {
            title: 'Point for Clarification',
            url: 'pfc.html',
            isVisible: true
        }, {
            title: 'Communications',
            url: 'communication.html',
            isVisible: true
        }];
        $scope.currentOriPrintViewTab = 'Information.html';

        $scope.strRole = commonApi._.filter($scope.DS_WORKINGUSER_ALL_ROLES, function (val) {
            return val.Value.indexOf('Tender Team') != -1
        });

        if ($scope.strRole && !$scope.strRole.length) {
            $scope.oriprintviewtabs[1].isVisible = false;
        }

        /****************************************/
        $scope.isActiveTab = function (tabUrl, calledform) {
            if (calledform == "ori_print_view_main") {
                return tabUrl == $scope.currentOriPrintViewTab;
            }
        }

        $scope.onClickTab = function (tab, calledform) {

            if (calledform == "ori_print_view_main") {
                $scope.currentOriPrintViewTab = tab.url;
            }
            if (tab.url == "Tracker.html") {
                $scope.fillTrackerData();
            } else if (tab.url == "Addendum_Information.html") {
                $scope.fillAddendaData();
            } else if (tab.url == "Other_Information.html" || tab.url == "pfc.html" || tab.url == "communication.html") {
                $scope.fillOtherData();
            }
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 500);
        }

        /****************************************/

        $scope.fillTrackerData = function () {
            if ($scope.strFormId) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_ASI_STD_ADD_BM_Bid_Responses",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASI_STD_ADD_BM_Bid_Responses",
                            "fieldValue": $scope.strFormId
                        }]
                    }
                };

                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var DS_ASI_STD_ADD_BM_Bid_Responses = angular.fromJson(response.data['DS_ASI_STD_ADD_BM_Bid_Responses']);
                        if (DS_ASI_STD_ADD_BM_Bid_Responses.Items && DS_ASI_STD_ADD_BM_Bid_Responses.Items.Item) {
                            for (var index = 0; index < DS_ASI_STD_ADD_BM_Bid_Responses.Items.Item.length; index++) {
                                var element = DS_ASI_STD_ADD_BM_Bid_Responses.Items.Item[index];
                                if (element.Value19) {
                                    element.Value19 = $scope.formatDate(new Date(element.Value19), 'dd-M-yy', 'M dd,yy');
                                }
                                if (element.Value15) {
                                    element.Value15 = $scope.formatDate(new Date(element.Value15), 'dd-M-yy', 'M dd,yy');
                                }
                                if (element.Value17) {
                                    element.Value17 = $scope.formatDate(new Date(element.Value17), 'dd-M-yy', 'M dd,yy');
                                }
                            }
                            $scope.strTrackerData = DS_ASI_STD_ADD_BM_Bid_Responses.Items.Item;
                        }
                    }
                });
            }
        }

        $scope.fillAddendaData = function () {

            if ($scope.DS_ASI_STD_ADD_BM_Bid_Addenda) {
                $scope.strAddendaData = $scope.DS_ASI_STD_ADD_BM_Bid_Addenda;
            }
        }

        $scope.setWeighatagFormId = function () {
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = $scope.oriMsgCustomFields.weightageId;
            for (var index = 0; index < $scope.dsMktWtgDetails.length; index++) {
                var element = $scope.dsMktWtgDetails[index];
                if (element.Value2 === $scope.oriMsgCustomFields.weightageId) {
                    $scope.oriMsgCustomFields.weightageDBId = element.Value4;
                }
            }
        }

        $scope.fillOtherData = function () {
            var PFCData = $scope.getValueOfOnLoadData('DS_ASI_STD_NLS_RFC_PointForClarification');
            if (PFCData && PFCData.length) {
                $scope.formCustomFields.OtherDetailsGroup.Package = [];
                $scope.formCustomFields.OtherDetailsGroup.BIDQueryDetails = [];
                $scope.formCustomFields.OtherDetailsGroup.CommunicationDetails = [];
                $scope.strPFCinsertPoint = $scope.formCustomFields.OtherDetailsGroup.Package;
                $scope.strQRYinsertPoint = $scope.formCustomFields.OtherDetailsGroup.BIDQueryDetails;
                $scope.strComminsertPoint = $scope.formCustomFields.OtherDetailsGroup.CommunicationDetails;
                for (var i = 0; i < PFCData.length; i++) {
                    var strCode = PFCData[i]["Value1"] || "";
                    var strPackage = PFCData[i]["Value3"] || "";
                    var strTitle = PFCData[i]["Value2"] || "";
                    var strDesc = PFCData[i]["Value4"] || "";
                    var strUrl = PFCData[i]["URL1"] || "";
                    var strStatus = PFCData[i]["Value5"] || "";
                    var strReasonComm = PFCData[i]["Value7"] || "";

                    if (strCode.indexOf("PFC") > -1) {
                        var PFCStructure = angular.copy($scope.PFCStructure);
                        PFCStructure.PFCID = strCode;
                        PFCStructure.PFCPackage = strPackage;
                        PFCStructure.PFCTitle = strTitle;
                        PFCStructure.PFCDescription = strDesc;
                        PFCStructure.PFC_URL = strUrl;

                        $scope.strPFCinsertPoint.push(PFCStructure);

                    } else if (strCode.indexOf("TNQ") > -1) {
                        var QueryStructure = angular.copy($scope.QueryStructure);
                        QueryStructure.BIDQueryID = strCode;
                        QueryStructure.BIDQueryPackage = strPackage;
                        QueryStructure.BIDQueryTitle = strTitle;
                        QueryStructure.BIDQueryDescription = strDesc;
                        QueryStructure.BIDQueryID_URL = strUrl;
                        QueryStructure.BIDQueryStatus = strStatus;

                        $scope.strQRYinsertPoint.push(QueryStructure);

                    } else if (strCode.indexOf("COMM") > -1) {
                        var CommStructure = angular.copy($scope.CommStructure);
                        CommStructure.CommunicationID = strCode;
                        CommStructure.CommunicationPackage = strPackage;
                        CommStructure.CommunicationTitle = strTitle;
                        CommStructure.CommunicationUserref = strDesc;
                        CommStructure.CommunicationIDURL = strUrl;
                        CommStructure.CommunicationReason = strReasonComm;

                        $scope.strComminsertPoint.push(CommStructure);

                    }
                }
            }
        }

        function setClientLogo() {
            if (logo && logo.length) {
                $scope.oriMsgCustomFields.DS_Logo = logo[0].Value8;
            }
        }

        function setPackageData(AllResData) {
            $scope.oriMsgCustomFields.Bid_Schedule.Bid_Detailed_Schedule = [];
            if (AllResData && AllResData.length) {
                var insertpoint = $scope.oriMsgCustomFields.Bid_Schedule.Bid_Detailed_Schedule;
                var iCnt = 0;
                var BidItemTotal = 0;
                for (var i = 0; i < AllResData.length; i++) {
                    var strFlag = "",
                    strValue23 = AllResData[i]["Value23"] || "",
                    strValue22 = AllResData[i]["Value22"] || "",
                    strValue25 = AllResData[i]["Value25"] || "",
                    strValue30 = AllResData[i]["Value30"] || "",
                    strValue21 = AllResData[i]["Value21"] || "";
                    if (strValue23) {
                        strFlag = strFlag + "|1";
                    }
                    if (strValue22) {
                        strFlag = strFlag + "|2";
                    }
                    if (strValue25) {
                        strFlag = strFlag + "|3";
                    }
                    if (strValue30 == "A" || !strValue21)
                        continue;
                    var PackageStructure = angular.copy($scope.PackageStructure);
                    iCnt++;
                    PackageStructure.ID = iCnt;
                    PackageStructure.Work_Description = strValue21;
                    PackageStructure.UOM = strValue22;
                    PackageStructure.Quantity = strValue23;
                    var strVal24 = AllResData[i]["Value24"] || "0";
                    BidItemTotal = parseFloat(BidItemTotal) + parseFloat(strVal24);
                    PackageStructure.Value = strVal24;
                    PackageStructure.Rate = strValue25;
                    PackageStructure.EditFlag = strFlag;
                    insertpoint.push(PackageStructure);
                }

                $scope.oriMsgCustomFields.Bid_Schedule.Bid_Item_Total = parseFloat(BidItemTotal).toFixed(2);
                $scope.formCustomFields.Bid_Response.Nett_Summ = parseFloat(BidItemTotal).toFixed(2);
            }
        }

        function setPackageDataMLDL(strMessageId) {
            var PackageData = commonApi._.filter($scope.DS_ASI_STD_ITB_PKG_REQUIREMENT, function (val) {
                return val.Value19 == strMessageId;
            });
            $scope.oriMsgCustomFields.Section_Details.sectionsSetup = [];
            if (PackageData && PackageData.length) {
                var insertpoint = $scope.oriMsgCustomFields.Section_Details.sectionsSetup;
                var BidItemTotal = 0,
                    strRate = 0.00;
                for (var i = 0; i < PackageData.length; i++) {
                    var strFlag = "",
                        UOM = PackageData[i]["Value8"] || "",
                        Quantity = PackageData[i]["Value9"] || "",
                        Pid = PackageData[i]["Value14"] || "",
                        setTotal = 0.00;

                    if (UOM == "null") { UOM = ""; }
                    if ((Quantity && Quantity>0) || Pid != "1") {
                        strFlag = strFlag + "|1";
                    }
                    if (UOM || Pid != "1") {
                        strFlag = strFlag + "|2";
                    }
                    if (Pid != "1" && UOM == "") { UOM = "N/A" }
                    strRate = '';
                    if (PackageData[i]["Value17"] == "RES") {
                        strRate = PackageData[i]["Value15"];
                    }
                    if (PackageData[i]["Value10"] == "0") { setTotal = PackageData[i]["Value21"] || "0.00" }
                    var PackageStructure = angular.copy(STATIC_OBJ_DATA.sectionsSetup);
                    PackageStructure.autoId = PackageData[i]["Value3"] || "";
                    PackageStructure.sectionDescription = PackageData[i]["Value5"] || "";
                    PackageStructure.UOM = UOM;
                    PackageStructure.Quantity = Quantity || "0";
                    PackageStructure.Rate = strRate;
                    PackageStructure.isLastflag = PackageData[i]["Value14"] || "";
                    PackageStructure.Guid = PackageData[i]["Value6"] || "";
                    PackageStructure.immediate_parentId = PackageData[i]["Value10"] || "";
                    PackageStructure.immediate_parentGUId = PackageData[i]["Value11"] || "";
                    PackageStructure.immediate_childId = PackageData[i]["Value12"] || "";
                    PackageStructure.immediate_childGUId = PackageData[i]["Value13"] || "";
                    PackageStructure.EditFlag = strFlag;
                    PackageStructure.parentGUId = PackageData[i]["Value16"] || "";
                    PackageStructure.sectionParentId = PackageData[i]["Value7"] || "";
                    PackageStructure.sectionId = PackageData[i]["Value4"] || "";
                    PackageStructure.sequenceId = PackageData[i]["Value2"] || "";
                    PackageStructure.Total = PackageData[i]["Value21"] || "0.00";
                    PackageStructure.Tax = PackageData[i]["Value20"] || "";
                    BidItemTotal = parseFloat(BidItemTotal) + parseFloat(setTotal);
                    insertpoint.push(PackageStructure);
                }
                sectionTotal();
                $scope.oriMsgCustomFields.Bid_Schedule.Bid_Item_Total = parseFloat(BidItemTotal).toFixed(2);
                $scope.formCustomFields.Bid_Response.Nett_Summ = parseFloat(BidItemTotal).toFixed(2);
            }
        }

        function setDocChecklistData() {
            var DocData = $scope.DS_ASI_STD_ITB_DOC_CHECKLIST;
            if (DocData && DocData.length) {
                $scope.oriMsgCustomFields.Doc_Checklists.Doc_Checklist = [];
                var insertpoint = $scope.oriMsgCustomFields.Doc_Checklists.Doc_Checklist;
                for (var i = 0; i < DocData.length; i++) {
                    var Cheklist_Name = DocData[i]["Value5"] || "";
                    var DocStructure = angular.copy(STATIC_OBJ_DATA.Doc_Checklist);
                    DocStructure.Cheklist_Name = Cheklist_Name;
                    DocStructure.Doc_Is_Checked = "NO";
                    insertpoint.push(DocStructure);
                }

            }
        }

        function setQuestionChecklistData() {
            var QuestionData = $scope.DS_ASI_STD_ITB_QUESTION_CHECKLIST;
            if (QuestionData && QuestionData.length) {
                $scope.oriMsgCustomFields.Question_CheckLists.Question_CheckList = [];
                var insertpoint = $scope.oriMsgCustomFields.Question_CheckLists.Question_CheckList;
                for (var i = 0; i < QuestionData.length; i++) {
                    var QuestionStructure = angular.copy(STATIC_OBJ_DATA.Question_CheckList);
                    QuestionStructure.Question_Name = QuestionData[i]["Value5"] || "";
                    QuestionStructure.Question_CheckList_Type = QuestionData[i]["Value6"] || "";
                    QuestionStructure.Question_Checkbox_Details = "";
                    QuestionStructure.Question_Textbox_Details = "";
                    insertpoint.push(QuestionStructure);
                }

            }
        }

        function setPackageDataPrintView() {
            var strMsgId = $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_MSGID.trim();
            var PackageData = commonApi._.filter($scope.DS_ASI_STD_ITB_PKG_REQUIREMENT, function (val) {
                return val.Value18.trim() == strMsgId;
            });

            if (PackageData && PackageData.length) {
                $scope.oriMsgCustomFields.Section_Details.sectionsSetup = [];
                var insertpoint = $scope.oriMsgCustomFields.Section_Details.sectionsSetup;
                for (var i = 0; i < PackageData.length; i++) {
                    var autoId = PackageData[i]["Value3"] || "";
                    var sectionDescription = PackageData[i]["Value5"] || "";
                    var UOM = PackageData[i]["Value8"] || "";
                    var Quantity = PackageData[i]["Value9"] || "";
                    var Rate = PackageData[i]["Value15"] || "";
                    var PackageStructure = angular.copy($scope.PackageStructure);
                    PackageStructure.autoId = autoId;
                    PackageStructure.sectionDescription = sectionDescription;
                    PackageStructure.UOM = UOM;
                    PackageStructure.Quantity = Quantity;
                    PackageStructure.Rate = Rate;
                    insertpoint.push(PackageStructure);
                }
            }
        }

        function fillCheckListData() {
            var checklist = $scope.Docchecklist;
            if (checklist && checklist.length) {
                $scope.oriMsgCustomFields.Doc_Checklists.Doc_Checklist = [];
                var insertpoint = $scope.oriMsgCustomFields.Doc_Checklists.Doc_Checklist;
                for (var i = 0; i < checklist.length; i++) {
                    var checklistStructure = angular.copy(STATIC_OBJ_DATA.Doc_Checklist);
                    checklistStructure.Cheklist_Name = checklist[i].Value8;
                    checklistStructure.Doc_Is_Checked = "NO";
                    insertpoint.push(checklistStructure);
                }
            }
            checklist = $scope.Questionchecklist;

            if (checklist && checklist.length) {
                $scope.oriMsgCustomFields.Question_CheckLists.Question_CheckList = [];
                var insertpoint = $scope.oriMsgCustomFields.Question_CheckLists.Question_CheckList;
                for (var i = 0; i < checklist.length; i++) {
                    var checklistStructure = angular.copy(STATIC_OBJ_DATA.Question_CheckList);
                    checklistStructure.Question_Name = checklist[i].Value8;
                    checklistStructure.Question_CheckList_Type = "";
                    checklistStructure.Question_Checkbox_Details = "";
                    checklistStructure.Question_Textbox_Details = "";
                    insertpoint.push(checklistStructure);
                }
            }
        }
        ///model data
        $scope.tableUtilSettings = {
            Doc_Checklist: {
                tooltip: "select to remove/remove all/Edit Checklist",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Doc_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Doc_Checklist),
                deleteAllRowTooltip: "Remove all Checklists Detail",
                deleteCurrRowMsg: "Remove Checklist Detail",
                deleteSelectedMsg: "Remove selected Checklist Detail"
            },
            Question_CheckList: {
                tooltip: "select to remove/remove all/Edit Questions",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Question_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Question_CheckList),
                deleteAllRowTooltip: "Remove all Questions Detail",
                deleteCurrRowMsg: "Remove Question Detail",
                deleteSelectedMsg: "Remove selected Question Detail"
            }
        }
        $scope.deleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };
        $scope.ResetAdditionalCounter = function () {
            var repeating = $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Table;
            var iCnt = 1;
            if (repeating) {
                for (var i = 0; i < repeating.length; i++) {
                    repeating[i].Additional_ID = iCnt;
                    iCnt++;
                }
            }
        }

        $scope.CalculateAdditionalCost = function (args) {
            if (args) {
                var total = 0;
                var strQty = args.curObj.AddPackageReq_Quantity;
                var strRate = args.curObj.AddPackageReq_Rate;
                if (!strQty) {
                    strQty = 0;
                }
                if (!strRate) {
                    strRate = 0;
                }
                total = parseFloat(strQty) * parseFloat(strRate);
                args.curObj.AddPackageReq_Price = total.toFixed(2);
            }
            setNetSum();
        }

        function sectionTotal() {
            var strSecNodes = $scope.oriMsgCustomFields.Section_Details.sectionsSetup;
            var secTotal = 0,
                taxTotal = 0,
                priceTotal = 0,
                strValue = "",
                strTax = "",
                strQty = "",
                strRate = "",
                strPrice = "";
            if (strSecNodes.length) {
                for (var i = 0; i < strSecNodes.length; i++) {
                    if (strSecNodes[i].immediate_parentGUId == "") {
                        strValue = strSecNodes[i]["Total"] || "0";
                        if (strValue) {
                            secTotal = parseFloat(secTotal) + parseFloat(strValue);
                        }
                    }
                    strTax = strSecNodes[i]["Tax"] || "0";
                    strQty = strSecNodes[i]["Quantity"] || "0";
                    strRate = strSecNodes[i]["Rate"] || "0";
                    strPrice = parseFloat(strQty) * parseFloat(strRate);
                    priceTotal = parseFloat(priceTotal) + parseFloat(strPrice);
                    taxTotal = parseFloat(taxTotal) + parseFloat(strPrice) * (strTax / 100);
                }
            }
            $scope.oriMsgCustomFields.Bid_Schedule.Bid_Item_Total = parseFloat(secTotal).toFixed(2);
            $scope.oriMsgCustomFields.Bid_Schedule.Tax_Total = parseFloat(taxTotal).toFixed(2);
            $scope.oriMsgCustomFields.Bid_Schedule.Price_Total = parseFloat(priceTotal).toFixed(2);
        }

        function packageTotal() {
            var strPkgNodes = $scope.oriMsgCustomFields.Bid_Schedule.Bid_Detailed_Schedule;
            var pkgTotal = 0;
            if (strPkgNodes) {
                for (var i = 0; i < strPkgNodes.length; i++) {
                    var strValue = strPkgNodes[i]["Value"] || "0";
                    if (strValue) {
                        pkgTotal = parseFloat(pkgTotal) + parseFloat(strValue);
                    }
                }
            }
            $scope.oriMsgCustomFields.Bid_Schedule.Bid_Item_Total = parseFloat(pkgTotal).toFixed(2);
        }

        function setNetSum() {
            if ($scope.oriMsgCustomFields.DSI_Table_Type == "YES")
                sectionTotal();
            else
                packageTotal();
            var pkgTotal = $scope.oriMsgCustomFields.Bid_Schedule.Bid_Item_Total;
            var strAddPkgNodes = $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Table;
            var AddpkgTotal = 0;
            if (strAddPkgNodes) {
                for (var i = 0; i < strAddPkgNodes.length; i++) {
                    var strValue = strAddPkgNodes[i]["AddPackageReq_Price"] || "0";
                    if (strValue) {
                        AddpkgTotal = parseFloat(AddpkgTotal) + parseFloat(strValue);
                    }
                }
            }
            $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Total = parseFloat(AddpkgTotal).toFixed(2);
            var total = 0;
            total = parseFloat(pkgTotal) + parseFloat(AddpkgTotal);
            $scope.formCustomFields.Bid_Response.Nett_Summ = parseFloat(total).toFixed(2);

        }

        function setResponseData(AllResData, strMessageId) {
            if (AllResData && AllResData.length) {
                for (var i = 0; i < AllResData.length; i++) {
                    $scope.oriMsgCustomFields.Type_of_Contract = AllResData[i]["Value10"] || "";
                    $scope.oriMsgCustomFields.Type_of_Procedure = AllResData[i]["Value11"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Package_Description = AllResData[i]["Value12"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Addl_Info = AllResData[i]["Value13"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Contact_Person = AllResData[i]["Value14"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Email_Address = AllResData[i]["Value15"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Contact_No = AllResData[i]["Value50"] || "";
                    $scope.oriMsgCustomFields.DateOfIssue = AllResData[i]["Value9"] || "";
                    $scope.formCustomFields.Bid_Opportunity.ORI_FORMTITLE = AllResData[i]["Value2"] || "";
                    $scope.formCustomFields.Bid_Opportunity.ORI_USERREF = AllResData[i]["Value3"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Bid_Administrator = AllResData[i]["Value28"] + "#" + AllResData[i]["Value8"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Pkg_Type = AllResData[i]["Value7"] || "";
                    $scope.formCustomFields.Bid_Opportunity.Responder_Detail = AllResData[i]["Value37"] + "#" + AllResData[i]["Value33"] || "";
                    $scope.formCustomFields.Bid_Opportunity.ResBidAdmin = AllResData[i]["Value28"] || "";
                    $scope.oriMsgCustomFields.Currency_Sign = AllResData[i]["Value41"] || "";
                    $scope.oriMsgCustomFields.DSI_Table_Type = AllResData[i]["Value44"] || "";
                    $scope.oriMsgCustomFields.DSI_Doc_Checklist = AllResData[i]["Value45"] || "";
                    $scope.oriMsgCustomFields.DSI_Question_CheckList = AllResData[i]["Value46"] || "";
                    $scope.oriMsgCustomFields.DSI_Pkg_Req = AllResData[i]["Value47"] || "";
                    $scope.oriMsgCustomFields.DSI_Tax_Req = AllResData[i]["Value48"] || "";
                    $scope.oriMsgCustomFields.Tax_Name = AllResData[i]["Value49"] || "";


                }
            }
            var strResWorkinguserId = $scope.formCustomFields.Bid_Opportunity.ResWorkinguserId;
            var strResBidAdmin = $scope.formCustomFields.Bid_Opportunity.ResBidAdmin;

            if (strResWorkinguserId == strResBidAdmin) {
                setAdditionalPackageData(strMessageId);
                checkSameOrgMultipleAward(strMessageId);
                setNetSum();
                $scope.formCustomFields.Bid_Opportunity.ResponseFlag = "Accepted";
                $scope.formCustomFields.Bid_Response.ResponseStage = "2";
                updateAssocFalg();
            } else {
                checkUserCanRespond();
                clearMultipleActionTendrer();
                if ($scope.WorkingUserID[0].Value.indexOf(strResWorkinguserId) > 0) {
                    $scope.oriMsgCustomFields.Flg_HideResMsgForBidder = "True";
                }
                $scope.formCustomFields.Bid_Response.ResponseStage = "1";
            }
        }

        function setAdditionalPackageData(strMessageId) {
            var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value29 == strMessageId && val.Value30 == 'A';
            });

            if (AllResData && AllResData.length) {
                $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Table = [];
                var insertpoint = $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Table;
                var iCnt = 0;
                var BidItemTotal = 0;
                for (var i = 0; i < AllResData.length; i++) {

                    var AddPackageStructure = angular.copy($scope.AddPackageStructure);
                    iCnt++;
                    AddPackageStructure.ID = iCnt;
                    AddPackageStructure.AddPackageReq_Desc = AllResData[i]["Value21"] || "";
                    AddPackageStructure.AddPackageReq_Unit = AllResData[i]["Value22"] || "";
                    AddPackageStructure.AddPackageReq_Quantity = AllResData[i]["Value23"] || "";
                    var strValue25 = AllResData[i]["Value25"] || "0";
                    BidItemTotal = parseFloat(BidItemTotal) + parseFloat(strValue25);
                    AddPackageStructure.AddPackageReq_Rate = AllResData[i]["Value24"] || "";;
                    AddPackageStructure.AddPackageReq_Price = strValue25;
                    insertpoint.push(AddPackageStructure);

                    $scope.formCustomFields.Bid_Response.Nett_Sum_Words = AllResData[i]["Value31"] || "";
                    $scope.formCustomFields.Bid_Response.Comments = AllResData[i]["Value32"] || "";
                    var Responder_Name = "";
                    if (AllResData[i]["Value37"] && AllResData[i]["Value38"]) {
                        Responder_Name = AllResData[i]["Value37"] + "#" + AllResData[i]["Value38"];
                        $scope.formCustomFields.Bid_Response.Responder_Name = Responder_Name;
                    }

                    $scope.formCustomFields.Bid_Response.Position = AllResData[i]["Value34"] || "";
                    $scope.formCustomFields.Bid_Response.Response_Date = AllResData[i]["Value35"] || "";
                    $scope.formCustomFields.Bid_Response.Quality = AllResData[i]["Value42"] || "";
                    $scope.formCustomFields.Bid_Response.Commercial = AllResData[i]["Value43"] || "";
                }
                $scope.oriMsgCustomFields.AdditionalPackageReq.AddPackageReq_Total = parseFloat(BidItemTotal).toFixed(2);
            }

        }

        function calculateDistDate(days) {
            var strDueDate = "";
            if (days) {
                var d = new Date();
                d.setDate(d.getDate() + days);
                var month = d.getMonth() + 1;
                var day = d.getDate();
                var strDueDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;
            }
            return strDueDate;
        }
        $scope.ParticipateClick = function () {
            $scope.formCustomFields.Bid_Opportunity.ResponseFlag = "Accepted";
            $scope.oriMsgCustomFields.DeclineUserName = "";
            $scope.ishideDeclineButton = false;
            setActionOriginator();
            hideBidderView();
        }

        $scope.DeclineClick = function () {
            $scope.formCustomFields.Bid_Opportunity.ResponseFlag = "Rejected";
            $scope.oriMsgCustomFields.DeclineUserName = $scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER;
            $scope.ishideParticipateButton = false;
            setActionOriginator();
            hideBidderView();
        }

        $scope.OnCommentChange = function () {
            $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE = "";
            $scope.formCustomFields.Bid_Opportunity.ResponseFlag = "Accepted";
            $scope.formCustomFields.Bid_Response.Responder_Name = CurrentUserID + "#" + $scope.WorkingUserID[0].Name;

            setActionOriginator();
        }

        function setActionOriginator() {
            $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "13";
            if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag == "Rejected") {
                setAutoDistribution($scope.formCustomFields.Bid_Opportunity.Bid_Administrator, "7#For Information", "");
            } else {
                setAutoDistribution($scope.formCustomFields.Bid_Opportunity.Bid_Administrator, "3#Respond", calculateDistDate(5));
            }
        }

        function hideBidderView() {

            $scope.ishideResBidderview = false;
            if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                $scope.ishideResBidderview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ReleaseDate_Validation == "yes") {
                $scope.ishideResBidderview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag == "Rejected") {
                $scope.ishideResBidderview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == "yes") {
                $scope.ishideResBidderview = true;
            } else if ($scope.formCustomFields.MessageForMultiResponse) {
                $scope.ishideResBidderview = true;
            }
        }

        function hideDeclineButton() {
            if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag == "Rejected") {
                $scope.ishideDeclineButton = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ReleaseDate_Validation == "yes") {
                $scope.ishideDeclineButton = true;
            } else if ($scope.oriMsgCustomFields.TenderEvalutiaonMsg.indexOf('"Reject"') > -1) {
                $scope.ishideDeclineButton = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                $scope.ishideDeclineButton = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == "yes") {
                $scope.ishideDeclineButton = true;
            } else if ($scope.formCustomFields.MessageForMultiResponse) {
                $scope.ishideDeclineButton = true;
            }
        }

        function hideParticipateButton() {
            if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag != "Rejected") {
                $scope.ishideParticipateButton = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed == "yes") {
                $scope.ishideParticipateButton = true;
            } else if ($scope.oriMsgCustomFields.TenderEvalutiaonMsg.indexOf('"Reject"') > -1) {
                $scope.ishideParticipateButton = true;
            } else if ($scope.formCustomFields.MessageForMultiResponse) {
                $scope.ishideParticipateButton = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ReleaseDate_Validation == "yes") {
                $scope.ishideParticipateButton = true;
            }
        }

        function hideResBiddAdminView() {
            if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId != $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                $scope.ishideResBiddAdminview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin && $scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date >= $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.ishideResBiddAdminview = true;
            } else if (!$scope.oriMsgCustomFields.Flag) {
                $scope.ishideResBiddAdminview = true;
            }
        }
        $scope.HideShowNotice = function (strVal) {
            if (strVal && strVal.indexOf('Awarded') > -1) {
                $scope.isStatusAwarded = true;
            } else {
                $scope.isStatusAwarded = false;
            }
        }

        $scope.SetAwardDetails = function (strVal) {

            $scope.oriMsgCustomFields.RejectMsg = "";
            $scope.formCustomFields.Bid_Information.AwardedUserName = "";
            $scope.formCustomFields.Bid_Information.AwardedOrgId = "";
            $scope.asiteSystemDataReadWrite.Auto_Complete_Actions.DS_AUTOCOMPLETE_ACTION_APP_ID = "0";
            if (strVal && strVal.indexOf('Awarded') > -1) {
                $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "";
                setAwardedStatus();
                setconditiondistribute("7#For Information");
                var strname = $scope.formCustomFields.Bid_Response.Responder_Name.split('#')[1];
                if (strname) {
                    $scope.formCustomFields.Bid_Information.AwardedUserName = strname.split(',')[0];
                    var AwardedOrg = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strname.split(',')[1].trim();
                    });
                    if (AwardedOrg && AwardedOrg.length) {
                        $scope.formCustomFields.Bid_Information.AwardedOrgId = AwardedOrg[0].Value.split('#')[0];
                    }
                }
                finalMessages();
                $scope.formCustomFields.Bid_Information.AwaredDate = $scope.formatDate(new Date(), 'yy-mm-dd');;

            } else if (strVal && strVal.indexOf('Reject') > -1) {
                setconditiondistribute("7#For Information");
                $scope.formCustomFields.Bid_Information.Evalution_Complete = "no";
                $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "1";
                $scope.oriMsgCustomFields.RejectMsg = "Thank you for showing your interest for this bid. The tender has already been awarded. For any further information you may contact us following the 'Contact Information' above.";
                $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = "Open";

            } else if (strVal && strVal.indexOf('Closed') > -1) {
                var strFormStatusId = getFormStatusId("Closed");
                $scope.formCustomFields.Bid_Information.Evalution_Complete = "no";
                $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "1";
                if (strFormStatusId) {
                    $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = strFormStatusId;
                }
                setconditiondistribute("7#For Information");
                sendForInfoToallOthrs();
                clearAction();
                finalMessages();
            }
        }

        function clearActionifTenderEndDatePassed() {
            $scope.strTodayDateTime = getDateTimeFromZone();
            $scope.oriMsgCustomFields.DSI_Converted_Date = $scope.strTodayDateTime;
            if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails && $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails.length) {
                var strEndDate = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value5;

                if ($scope.oriMsgCustomFields.DSI_Converted_Date > strEndDate) {
                    $scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed = "yes";
                } else {
                    $scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed = "";
                }
            }
        }

        function checkTenderEndDatePassedMsg() {
            if ($scope.formCustomFields.Bid_Opportunity.TenderEndDatePassed != "yes") {
                $scope.isTenderEndDatePassed = true;
            } else if ($scope.formCustomFields.MessageForMultiResponse) {
                $scope.isTenderEndDatePassed = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                $scope.isTenderEndDatePassed = true;
            }
        }

        function hideSealedPkgReviewDateChk() {
            if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId == $scope.formCustomFields.Bid_Opportunity.ResBidAdmin && $scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date < $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.isSealedPkgReviewDateChk = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResWorkinguserId != $scope.formCustomFields.Bid_Opportunity.ResBidAdmin) {
                $scope.isSealedPkgReviewDateChk = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Unsealed") {
                $scope.isSealedPkgReviewDateChk = true;
            } else if ($scope.oriMsgCustomFields.Flg_HideResMsgForBidder == "True") {
                $scope.isSealedPkgReviewDateChk = true;
            }
        }

        function checkForMultiResponse() {
            var strCanReply = "";
            var ActionData = commonApi._.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Value.indexOf('Respond') > -1 && val.Value.indexOf(CurrentUserID) != -1
            });

            if (ActionData && ActionData.length) {
                strCanReply = "YES";
            }
            if (!strCanReply) {
                $scope.formCustomFields.MessageForMultiResponse = "";
                var Attribute = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == 'AllowMultipleResponseInTender' && val.Value11.indexOf('Active') != -1
                });

                if (Attribute && Attribute.length) {
                    var strAttrval = Attribute[0].Value8.toLowerCase();
                    var rejectData = commonApi._.filter($scope.DS_ASI_STD_ADD_BM_Bid_Recipients, function (val) {
                        return val.Value7 == "Rejected" && val.Value5 == CurrentUserID;
                    });
                    if (strAttrval == "no") {
                        $scope.formCustomFields.MessageForMultiResponse = "You have already responded to the Invitation.";
                    } else if (strAttrval == "yes" && rejectData.length) {
                        $scope.formCustomFields.MessageForMultiResponse = "You have chosen to decline the Invitation please contact your bid admin.";
                    }
                }
            }
        }

        function checkSameOrgMultipleAward(strMessageId) {
            var AwardCount = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value40 == 'Awarded';
            });

            if (AwardCount && AwardCount.length) {
                var strArr = [];
                for (var i = 0; i < AwardCount.length; i++) {
                    var strValue38 = AwardCount[i]["Value38"] || "";
                    if (strValue38) {
                        var strorg = strValue38.split(',')[1];
                        if (strArr.indexOf(strorg) < 0)
                            strArr.push(strorg);
                    }
                }


                var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                    return val.Value29 == strMessageId;
                });

                if (AllResData && AllResData.length) {
                    var strValue38 = AllResData[0]["Value38"] || "";
                    if (strValue38) {
                        var strorg = strValue38.split(',')[1];
                        if (strArr.indexOf(strorg) > -1) {
                            $scope.oriMsgCustomFields.Flag = "";
                        } else {
                            $scope.oriMsgCustomFields.Flag = "1";
                        }
                    }
                }
            }
        }

        function clearMultipleActionTendrer() {
            var Attribute = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                return val.Value3 == 'AllowMultipleResponseInTender' && val.Value11.indexOf('Active') != -1
            });

            if (Attribute && Attribute.length) {
                if (Attribute[0].Value8 && Attribute[0].Value8.toLowerCase() == "yes") {
                    var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                        return val.Value37 == CurrentUserID && val.Value18 == 'RES';
                    });

                    if (AllResData && AllResData.length) {
                        var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                        var strResBidAdmin = $scope.formCustomFields.Bid_Opportunity.ResBidAdmin;
                        $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                        $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                        var nodeDistribution = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                        for (var i = 0; i < AllResData.length; i++) {

                            var strResid = AllResData[i].Value17 || "";
                            var AutocompleteMsgRes = angular.copy($scope.AutocompleteMsgStructure);
                            var AutocompleteMsgForInfo = angular.copy($scope.AutocompleteMsgStructure);

                            AutocompleteMsgRes.DS_MSG_AC_TYPE = "clear";
                            AutocompleteMsgRes.DS_MSG_AC_FORM = AppId;
                            AutocompleteMsgRes.DS_MSG_AC_MSG_TYPE = strResid;
                            AutocompleteMsgRes.DS_MSG_AC_USERID = strResBidAdmin;
                            AutocompleteMsgRes.DS_MSG_AC_ACTION = "3";
                            AutocompleteMsgRes.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                            AutocompleteMsgForInfo.DS_MSG_AC_TYPE = "clear";
                            AutocompleteMsgForInfo.DS_MSG_AC_FORM = AppId;
                            AutocompleteMsgForInfo.DS_MSG_AC_MSG_TYPE = strResid;
                            AutocompleteMsgForInfo.DS_MSG_AC_USERID = strResBidAdmin;
                            AutocompleteMsgForInfo.DS_MSG_AC_ACTION = "7";
                            AutocompleteMsgForInfo.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                            nodeDistribution.push(AutocompleteMsgRes);
                            nodeDistribution.push(AutocompleteMsgForInfo);
                        }

                    } else {
                        $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "0";
                    }
                }
            }
        }

        function getFormStatusId(StrStatus) {
            //get status according pass parameter
            if ($scope.DS_ALL_ACTIVE_FORM_STATUS != null && $scope.DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var DS_ALL_ACTIVE_FORM_STATUS = _.filter($scope.DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == StrStatus.toLowerCase().trim();
                });

                return DS_ALL_ACTIVE_FORM_STATUS[0].Value;
            }
            return "";
        }

        function setAwardedStatus() {
            var strFormStatusId = getFormStatusId("Awarded");
            var strevalution = $scope.formCustomFields.Bid_Information.Evalution_Complete;
            var strstatus = $scope.formCustomFields.Bid_Information.Bid_Evaluation_Status;

            var SetAwardStatus = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                return val.Value3 == 'SetAwardStatus' && val.Value11.indexOf('Active') != -1
            });

            if (SetAwardStatus && SetAwardStatus.length) {
                var strCount = SetAwardStatus[0].Value7;

                var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                    return val.Value40 == 'Awarded';
                });
                var i = AllResData.length + 1;
                if (i == strCount && strstatus.toLowerCase().indexOf('awarded') > -1) {
                    $scope.formCustomFields.Bid_Information.Evalution_Complete = "yes";
                    $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "1";
                    if (strFormStatusId) {
                        $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = strFormStatusId;
                    }
                    sendForInfoToallOthrs();
                } else if (strevalution == "yes" && strstatus.toLowerCase().indexOf('awarded') > -1) {
                    $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "";
                    if (strFormStatusId) {
                        $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = strFormStatusId;
                        sendForInfoToallOthrs();
                    }
                } else if (strevalution == "no" && strstatus.toLowerCase().indexOf('awarded') > -1) {
                    $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "";
                    $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = "Open";
                } else if (strstatus.toLowerCase().indexOf('closed') > -1 || strstatus.toLowerCase().indexOf('rejected') > -1) {
                    $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "1";
                    $scope.formCustomFields.Bid_Information.Evalution_Complete = "no";
                }
            } else {
                if (strstatus.toLowerCase().indexOf('awarded') > -1 && strFormStatusId) {
                    $scope.formCustomFields.Bid_Information.Evalution_Complete = "yes";
                    $scope.formCustomFields.Bid_Information.Bid_Evalution_Flag = "1";
                    $scope.formCustomFields.Bid_Information.DS_ALL_FORMSTATUS = strFormStatusId;
                    sendForInfoToallOthrs();
                }
            }
        }

        function sendForInfoToallOthrs() {

            var Allaction = $scope.DS_ASI_STD_TNDR_Schedule_Workdetail;
            if (Allaction && Allaction.length) {
                $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;
                var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var strResMainUser = $scope.formCustomFields.Bid_Opportunity.Responder_Detail.split('#')[0];
                var strarr = [];
                for (var i = 0; i < Allaction.length; i++) {
                    var strMsgType = Allaction[i].Value18 || "";
                    if (strMsgType == "RES") {
                        var strBid_adminID = Allaction[i].Value37 || "";
                        if (strBid_adminID && strarr.indexOf(strBid_adminID) < 0) {
                            strarr.push(strBid_adminID);
                        } else {
                            continue;
                        }

                        if (strResMainUser.trim() == strBid_adminID.trim())
                            continue;

                        var strBid_admin = strBid_adminID + "#";
                        var AutoDistActionStructure = angular.copy($scope.AutoDistActionStructure);

                        AutoDistActionStructure.DS_ADO_TYPE = "3";
                        AutoDistActionStructure.DS_ADO_FORM = strFormId;
                        AutoDistActionStructure.DS_ADO_MSG_TYPE = "ORI";
                        AutoDistActionStructure.DS_ADO_FORMACTIONS = "7";
                        AutoDistActionStructure.DS_ADO_ACTIONDUEDATE = calculateDistDate(5);
                        AutoDistActionStructure.DS_ADO_PROJDISTUSERS = strBid_admin;

                        insertpoint.push(AutoDistActionStructure);
                    }
                }
                if (insertpoint.length) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS_APP_ID = "1";
                }
            }
        }

        function setconditiondistribute(straction) {
            var strresdet = $scope.formCustomFields.Bid_Opportunity.Responder_Detail;
            if (strresdet) {
                $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "13";
                var strUser = strresdet.split('#')[0].trim();
                setAutoDistribution(strUser, straction, calculateDistDate(5))
            }
        }

        function finalMessages() {
            $scope.formCustomFields.Bid_Information.TenderFinalMessage = "";
            var workingUser = $scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER.split(',')[0].trim();
            var formStatus = $scope.DS_FORMSTATUS;
            var awaredUserName = getAwardedUserNameFromDBData();
            var strConfigAttriubte = "";
            if (formStatus.indexOf("Closed") > -1) {
                strConfigAttriubte = "SuspendedMsg";
            } else if (formStatus.indexOf("Awarded") > -1) {
                if (awaredUserName.indexOf(workingUser) > -1)
                    strConfigAttriubte = "AwardedMsg";
                else
                    strConfigAttriubte = "NotAwardedMsg";
            } else if (formStatus.indexOf("Reject") > -1) {
                strConfigAttriubte = "RejectedMsg";
            }
            $scope.oriMsgCustomFields.TenderEvalutiaonMsg = strConfigAttriubte;

            var AttrData = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                return val.Value3 == strConfigAttriubte && val.Value11.indexOf('Active') != -1
            });

            if (AttrData && AttrData.length) {
                var strVal = AttrData[0].Value8;
                var tenderFinalMsg = workingUser + "," + strVal;
                $scope.formCustomFields.Bid_Information.TenderFinalMessage = tenderFinalMsg;
            }

            if ($scope.DS_ORIGINATOR.indexOf(workingUser) > -1 || CurrentUserID == $scope.formCustomFields.Bid_Opportunity.Bid_Administrator.split('#')[0].trim()) {
                $scope.formCustomFields.Bid_Information.TenderFinalMessage = "";
            }
        }

        function getAwardedUserNameFromDBData() {
            var AwardedUserName = "";
            var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value40 == 'Awarded' && val.Value37 == CurrentUserID && val.Value36 != "";
            });

            if (AllResData && AllResData.length) {
                AwardedUserName = AllResData[0].Value36;
            }

            return AwardedUserName;
        }

        function clearAction() {
            var ActionData = commonApi._.filter($scope.DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == 'Respond';
            });

            if (ActionData && ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_Actions.Auto_Complete_Action = [];
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                $scope.asiteSystemDataReadWrite.Auto_Complete_Actions.DS_AUTOCOMPLETE_ACTION_APP_ID = "1";
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_Actions.Auto_Complete_Action;
                var arrsplit = ActionData[0].Value.split('|');
                if (arrsplit.length > 2) {
                    for (var i = 1; i < arrsplit.length - 1; i++) {
                        if (arrsplit[i]) {
                            var AutocompleteActionStructure = angular.copy($scope.AutocompleteActionStructure);
                            AutocompleteActionStructure.DS_AC_TYPE = "clear";
                            AutocompleteActionStructure.DS_AC_FORM = AppId;
                            AutocompleteActionStructure.DS_AC_MSG_TYPE = "RES";
                            AutocompleteActionStructure.DS_AC_USERID = arrsplit[i];
                            AutocompleteActionStructure.DS_AC_ACTION = "3";
                            AutocompleteActionStructure.DS_AC_ACTION_REMARKS = "clear actions";
                            insertpoint.push(AutocompleteActionStructure);
                        }
                    }
                }
            }
        }

        function setUpdatedAddendumDates() {
            if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails && $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails.length) {
                if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value5) {
                    $scope.formCustomFields.Bid_Opportunity.AvailabilityDate = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value5;
                }
                if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value7) {
                    $scope.formCustomFields.Bid_Opportunity.Review_Date = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value7;
                }
                if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value8) {
                    $scope.formCustomFields.Bid_Opportunity.Start_Date = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value8;
                }
                if ($scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value10) {
                    $scope.oriMsgCustomFields.DSI_SourceTimeZone = $scope.DS_ASI_STD_ADD_BM_Bid_CloseDetails[0].Value10;
                }
            }
        }

        function setFinalMessageForReject() {
            var AllResData = commonApi._.filter($scope.DS_ASI_STD_TNDR_Schedule_Workdetail, function (val) {
                return val.Value40 == 'Rejected' && Value37 == CurrentUserID;
            });
            var workingUser = "",
                strConfigAttriubte = "";
            if (AllResData && AllResData.length) {
                strConfigAttriubte = "RejectedMsg";
                workingUser = AllResData[0].Value38;
            }

            if (strConfigAttriubte) {
                var Attribute = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == strConfigAttriubte && val.Value11.indexOf('Active') != -1
                });
                if (Attribute && Attribute.length) {
                    var message = workingUser.split(',')[0] + "," + Attribute[0].Value8;
                    $scope.formCustomFields.Bid_Information.TenderFinalMessage = message;
                }
            }

        }

        function bidChk() {
            var strPkgType = $scope.formCustomFields.Bid_Opportunity.Pkg_Type;
            if (strPkgType == "Unsealed") {
                $scope.oriMsgCustomFields.DSI_Bidchk = "Yes";
            } else {
                var strReviewDate = $scope.formCustomFields.Bid_Opportunity.Review_Date;
                if (strPkgType == "Sealed" && strReviewDate > $scope.strTodayDateTime) {
                    $scope.oriMsgCustomFields.DSI_Bidchk = "No";
                } else {
                    $scope.oriMsgCustomFields.DSI_Bidchk = "Yes";
                }
            }
        }

        function hideResBidderResPrintview() {
            var strStage = $scope.formCustomFields.Bid_Response.ResponseStage;
            if (strStage != "1" && strStage != "2") {
                $scope.ishideResBidderResPrintview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag != "Accepted") {
                $scope.ishideResBidderResPrintview = true;
            } else if (loggedinUserOrg != $scope.formCustomFields.Bid_Opportunity.ResUserId.split('#')[1].split(',')[1].trim() && $scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date > $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.ishideResBidderResPrintview = true;
            } else if (strStage == "2" && $scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date > $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.ishideResBidderResPrintview = true;
            }
        }

        function hideResBiddAdminPrintview() {
            var strStage = $scope.formCustomFields.Bid_Response.ResponseStage;
            if (strStage != "2") {
                $scope.ishideResBiddAdminPrintview = true;
            } else if (CurrentUserID != $scope.formCustomFields.Bid_Opportunity.Bid_Administrator.split('#')[0].trim()) {
                $scope.ishideResBiddAdminPrintview = true;
            } else if ($scope.formCustomFields.Bid_Information.TenderFinalMessage) {
                $scope.ishideResBiddAdminPrintview = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date > $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.ishideResBiddAdminPrintview = true;
            }
        }

        function hideDeclineMsg() {
            if ($scope.formCustomFields.Bid_Opportunity.ResponseFlag != "Rejected" && $scope.formCustomFields.Bid_Opportunity.ResponseFlag != "Reset") {
                $scope.ishideDeclineMsg = true;
            } else if ($scope.formCustomFields.Bid_Information.TenderFinalMessage) {
                $scope.ishideDeclineMsg = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date > $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.ishideDeclineMsg = true;
            } else if ($scope.oriMsgCustomFields.DeclineUserName == $scope.asiteSystemDataReadOnly._1_User_Data.DS_WORKINGUSER) {
                $scope.ishideDeclineMsg = true;
            }
        }

        function hideSealedPkgMsg() {

            var strResuser = $scope.formCustomFields.Bid_Opportunity.ResUserId;
            if ($scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Unsealed") {
                $scope.isSealedPkgMsg = true;
            } else if (strResuser && loggedinUserOrg == strResuser.split('#')[1].split(',')[1].trim() && $scope.formCustomFields.Bid_Opportunity.Pkg_Type == "Sealed" && $scope.formCustomFields.Bid_Opportunity.Review_Date > $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.isSealedPkgMsg = true;
            } else if ($scope.formCustomFields.Bid_Opportunity.Review_Date < $scope.oriMsgCustomFields.DSI_Converted_Date) {
                $scope.isSealedPkgMsg = true;
            }

            if (!$scope.isSealedPkgMsg) {
                var attachmentIcon = document.querySelectorAll('custom-common-dropdown[dd-name="assoc-attach"]')[0]
                if (attachmentIcon) {
                    attachmentIcon.style.display = 'none';
                }
                angular.element('.assoc-attach-files').hide();
                angular.element('.assoc-attach-attachments').hide();
                angular.element('.assoc-link').hide();
            }
        }

        $scope.restrictCharOnlyNumber = function (event, existVal) {
            var validKeys = [37, 38, 39, 40, 27, 8, 9, 13, 46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 110, 190, 127];
            var inputVal = (event.which) ? event.which : event.keyCode;
            $scope.restrictChar(event, inputVal);
            if (validKeys.indexOf(inputVal) == -1 || (existVal && ([9, 8, 127, 37, 38, 39, 40].indexOf(inputVal) == -1 || event.shiftKey && [98, 100, 102, 104].indexOf(inputVal) == -1) && existVal.length + 1 > 13)) {
                event.preventDefault();
            }
        };

        $scope.customDecimalValidation = function (inputVal) {
            if (!inputVal) {
                return;
            }
            var tempInVal = inputVal + ''.replace(/,/g, ''),
                validVal = '',
                fractionSplitedVal = tempInVal.split('.');
            $scope.isValidAmount = true;
            $scope.validationMsg = '';

            if (fractionSplitedVal.length > 2) {
                $scope.formCustomFields.Bid_Opportunity.Budget = '';
                $scope.isValidAmount = false;
                $scope.validationMsg = 'More than one decimal points are not allowed. Please enter valid amount.';
                return
            }

            if (fractionSplitedVal[0] && fractionSplitedVal[0].length > 10) {
                $scope.formCustomFields.Bid_Opportunity.Budget = '';
                $scope.isValidAmount = false;
                $scope.validationMsg = 'Maximum 10 Degits allowed before decimal point. Please enter valid amount.';
                return;
            }

            if (fractionSplitedVal[1] && fractionSplitedVal[1].length > 2) {
                $scope.formCustomFields.Bid_Opportunity.Budget = '';
                $scope.isValidAmount = false;
                $scope.validationMsg = 'Maximum 2 Degits allowed after decimal point. Please enter valid amount.';
                return;
            }


            validVal = fractionSplitedVal[1] && fractionSplitedVal[1].length ? parseFloat(fractionSplitedVal.join('.')).toFixed(fractionSplitedVal[1].length): parseFloat(fractionSplitedVal.join('.'));
            $scope.formCustomFields.Bid_Opportunity.Budget = validVal != 'NaN' ? validVal : '';
        };

        $scope.SetCountryId = function (onLoad) {
            if(!onLoad){
                $scope.formCustomFields.Bid_Opportunity.State = '';
            }
            var strCountry = $scope.formCustomFields.Bid_Opportunity.Country;
            var strCountryFilter = commonApi._.filter($scope.DS_ASI_STD_TNDR_GET_COUNTRY_LIST, function (val) {
                return val.Value2 == strCountry;
            });

            var strCountryId = "";
            if (strCountryFilter && strCountryFilter.length) {
                strCountryId = strCountryFilter[0].Value1;
            }
            $scope.formCustomFields.Bid_Opportunity.Country_Id = strCountryId;
            $scope.getStateList = commonApi._.filter($scope.DS_ASI_STD_TNDR_GET_STATE_LIST, function (val) {
                return val.Value3 == strCountryId;
            });
        }

        $scope.SetStateId = function () {
            var strState = $scope.formCustomFields.Bid_Opportunity.State;
            var strstrStateFilter = commonApi._.filter($scope.DS_ASI_STD_TNDR_GET_STATE_LIST, function (val) {
                return val.Value2 == strState;
            });

            var strStateId = "";
            if (strstrStateFilter && strstrStateFilter.length) {
                strStateId = strstrStateFilter[0].Value1;
            }
            $scope.formCustomFields.Bid_Opportunity.State_Id = strStateId;
        }

        $scope.setTenderType = function (IsTenderPublic) {
            $scope.formCustomFields.Bid_Opportunity.Is_Tender_Public = IsTenderPublic;
            if (IsTenderPublic == 'no') {
                $scope.formCustomFields.Bid_Opportunity.allowExternalVendor = "No";
            } else if (IsTenderPublic == 'yes') {
                $scope.formCustomFields.Bid_Opportunity.allowExternalVendor = "Yes";
            }
            $scope.SetUserOrgDetail();
        };

        $scope.SetUserOrgDetail = function () {

            var strIsPublic = $scope.formCustomFields.Bid_Opportunity.Is_Tender_Public;
            var strCountry = "";
            var strCountry_Id = "";
            var strState = "";
            var strState_Id = "";
            var strCity = "";
            var strZip = "";
            if (strIsPublic == "yes" && $scope.DS_ASI_STD_TNDR_GET_UOP_ORG_DETAILS && $scope.DS_ASI_STD_TNDR_GET_UOP_ORG_DETAILS.length) {
                var strOrg = $scope.DS_ASI_STD_TNDR_GET_UOP_ORG_DETAILS[0];
                strCountry = strOrg.Value2;
                strCountry_Id = strOrg.Value3;
                strState = strOrg.Value4;
                strState_Id = strOrg.Value5;
                strCity = strOrg.Value6;
                strZip = strOrg.Value7;

            }
            $scope.formCustomFields.Bid_Opportunity.Country = strCountry;
            $scope.formCustomFields.Bid_Opportunity.Country_Id = strCountry_Id;
            $scope.formCustomFields.Bid_Opportunity.State = strState;
            $scope.formCustomFields.Bid_Opportunity.State_Id = strState_Id;
            $scope.formCustomFields.Bid_Opportunity.City = strCity;
            $scope.formCustomFields.Bid_Opportunity.Zip = strZip;

            $scope.SetCountryId(true);
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 200);
        }

        function updateAssocFalg() {
            var strPkgType = $scope.formCustomFields.Bid_Opportunity.Pkg_Type;
            var strPattern = "";
            if (strPkgType == "Sealed") {
                strPattern = $scope.strFormId + "@ORI@" + "FL_DISABLE_ASSOC@0@ASI-STD-ITB";
                $scope.oriMsgCustomFields.DS_Update_Appbuilder = strPattern;
                $scope.oriMsgCustomFields.DS_AU_OTH_FORM = "1";
            }
        }

        //structured download documents call
        $scope.calldownloadAllAttachAssocLatestRevZip = function () {
            window.downloadAllAttachAndAssocLatestRevZip();
        }

        //set configurable attributes value in download flags
        function downloadtypebuttonflagset() {
            if ($scope.DownloadType.length) {
                var strdownload = $scope.DownloadType[0].Value8;
                if (strdownload != "") {
                    var strsecondary = strdownload ? strdownload.split('$$')[0].split('::')[1].trim() : 'No';
                    var strmarkup = strdownload ? strdownload.split('$$')[1].split('::')[1].trim() : 'No';
                    var strsimplepath = strdownload ? strdownload.split('$$')[2].split('::')[1].trim() : 'No';
                    $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.ORI_MSG_Data.DOWNLOAD_SECONDARY_FILE = strsecondary == 'Yes' ? true : false;
                    $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.ORI_MSG_Data.DS_ASSOCIATIONS_SIMPLE_PATH = strmarkup == 'Yes' ? true : false;
                    $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.ORI_MSG_Data.DOWNLOAD_FILE_WITH_MARKUP = strsimplepath == 'Yes' ? true : false;
                }
            }
        }

        // on printview decide which button will display 
        //if associated documents are multi dc then disploay structured else simple path(secondary,markup,simplepath)

        function downloadtypebuttonshowhide() {
            $scope.isshowStructure = false;
            $scope.isshowsecondary = false;
            var DS_ASI_Document_Is_Multi_DC = "";
            if (DS_ASI_Document_Is_Multi_DC.length) {
                var strflag = "";
                for (var i = 0; i < DS_ASI_Document_Is_Multi_DC.length; i++) {
                    strflag = DS_ASI_Document_Is_Multi_DC[i].Value1;
                }
                if (strflag == "Yes") {
                    isshowStructure = true;
                    //set show flag for structure download button 
                } else {
                    if ($scope.DownloadType.length > 0) {
                        isshowsecondary = true;
                        //set show flag for secondary,markup,simplepath flag 
                    } else {
                        isshowStructure = true;
                        //set show flag for structure download button 
                    }

                }
            }
        }

        //simple path download documents call
        $scope.calldownloadAllAttachAssocSecondaryMarkup = function () {

            //listing revision ids
            var DS_ASI_STD_PACKAGE_DOCS_test = $scope.DS_ASI_STD_PACKAGE_DOCS;
            if (DS_ASI_STD_PACKAGE_DOCS_test != null && DS_ASI_STD_PACKAGE_DOCS_test.length) {
                var strRevId = "",
                    strRevisionIds = "";
                for (var i = 0; i < DS_ASI_STD_PACKAGE_DOCS_test.length; i++) {
                    strRevId = DS_ASI_STD_PACKAGE_DOCS_test[i].Value1;
                    if (DS_ASI_STD_PACKAGE_DOCS_test.length > 1) {
                        strRevisionIds = strRevId + "," + strRevisionIds;
                    }
                }
                if (strRevisionIds != "") {
                    strRevisionIds = strRevisionIds.replace(/,\s*$/, "");
                }
                $scope.formCustomFields.Bid_Opportunity.DSI_RevisionIds = angular.copy(strRevisionIds);
            }

            var strrevision = "";
            strrevision = $scope.formCustomFields.Bid_Opportunity.DSI_RevisionIds;

            //flag settings from configurable attributes
            var strsecondary, strmarkup, strsimplepath;
            var strdownload = $scope.DownloadType[0].Value8.trim();
            if (strdownload != "") {
                strsecondary = strdownload.split('$$')[0].split('::')[1].trim();
                strmarkup = strdownload.split('$$')[1].split('::')[1].trim();
                strsimplepath = strdownload.split('$$')[2].split('::')[1].trim();
            }

            strsecondary = strsecondary == "Yes" ? true : false;
            strmarkup = false;
            strsimplepath = strsimplepath == "Yes" ? false : true;

            //download document
            var downloadAllAttachAssocXhr = false;
            if (downloadAllAttachAssocXhr) {
                return;
            }

            var extraParam = {
                "isIncludeMarkup": false,
                "isParentDoc": true,
                "isXREF": false,
                "isRenameWithDocRef": false,
                "isAppenedRevNo": false,
                "isAppendDocTitle": false,
                "isAppenedIssNo": false,
                "fromSaveAsPDF": false,
                "isFolderStructure": strsimplepath,
                "isAssocFiles": strsecondary,
                "revIds": [strrevision]
            };

            downloadAllAttachAssocXhr = api.ajax({
                url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
                data: {
                    extra: JSON.stringify(extraParam),
                    projectIds: myConfig.projectId + ",",
                    projectID: myConfig.projectId,
                    isMultiProject: false
                },
                _cdnUrl: myConfig.downloadServiceURL
            });
            downloadAllAttachAssocXhr.then(function (data) {
                data.projectId = myConfig.projectId;
                download.createZipFile(data);
            }, function (xhr) {
                downloadAllAttachAssocXhr = false;
                xhr.errorTitle = lang.get("server-error");
                api.showServerErrMsg(xhr);
            });
        }


        ///////// Custome Table 

        var PARENT_NO_MSG = '"Parent Id" should be less than Current "Id"',
            DELETE_NODE_REFERENCE_AFFECT_MSG = "Deleting this row may affect it's all references",
            Limit_Msg = "Hierarchy limited exceeded.",
            DUPLICATE_VALUE_FIELDS_MSG = "Duplicate value 'fieldValue' entered in 'fieldName'.\nIt is available in any other Row.";


        $scope.onLoadActivities = function () {

            if ($scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length && $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][0].sequenceId === '') {
                lastIndex = 1;
                $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][0].sequenceId = lastIndex;
            }
            if ($scope.oriMsgCustomFields.isImported == "yes" && $scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length) {
                var length = parseInt($scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length) - 1;
                lastIndex = $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][length].sequenceId;
                if ($scope.oriMsgCustomFields.DSI_DeletedSection) {
                    $scope.deletedSectionSequenceId = $scope.oriMsgCustomFields.DSI_DeletedSection.split(',').map(Number);
                }
            }

            $scope.readOnly = (currentViewName === 'ORI_PRINT_VIEW');


            (($scope.isDSFormId && $scope.strIsDraft == 'YES') || ($scope.isDSFormId && $scope.strIsDraft == 'NO' && currentViewName == "ORI_VIEW")) && flushOutJsonDataForEditORI();
            // set Data from the Db

            $timeout(function () {
                $scope.expandTextAreaOnLoad();
                $scope.setFocusToLastAddedElement('level-setup-table');
            }, 100);
        };

        ctrl.$onInit = function () {
            $scope.onLoadActivities();
        };
        var flushOutJsonDataForEditORI = function () {
            if ($scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length) {
                lastIndex = $scope.oriMsgCustomFields.lastIndex;
                $scope.deletedSectionSequenceId = $scope.oriMsgCustomFields.deletedSectionSequenceId.map(function (x) {
                    return parseInt(x, 10);
                });
                $scope.editORIMsg = true;
            }
        },
        char_count= function (str, letter) 
        {
         var letter_Count = 0;
         for (var position = 0; position < str.length; position++) 
         {
            if (str.charAt(position) == letter) 
              {
              letter_Count += 1;
              }
          }
          return letter_Count;
        };

        $scope.setFocusToLastAddedElement = function (tableId) {
            $timeout(function () {
                angular.element('#' + tableId + '>tbody>tr:last input').length && angular.element('#' + tableId + '>tbody>tr:last input').last().focus();
            }, 50);
        };

        $scope.insertNewItems = function (valueFor, isMaintainIndex) {
            var setUpObj = $scope.oriMsgCustomFields.Section_Details[valueFor];
            var item = angular.copy(InsertMasterInitArray[valueFor]);
            autoSequenceId(valueFor, item);
            $scope.addRepeatingRow(setUpObj, item);
            return item;
        };
        /**
         * function to create Auto Sequence Id and maintaining last available Index.
         */

        var autoSequenceId = function (valueFor, item) {
            if (valueFor == 'sectionsSetup') {
                lastIndex = parseInt(lastIndex) + 1;
                item.sequenceId = lastIndex;
            }
        };

        ///Delete Sequence
        $scope.deleteItems = function (valueFor, index, isMaintainIndex, currentObj) {
            var isConfirm = true;

            if (valueFor == 'sectionsSetup') {
                isConfirm = confirm(DELETE_NODE_REFERENCE_AFFECT_MSG);
            }

            if (isConfirm) {
                var isForEdit = false;
                if ($scope.isEditORI) {
                    isForEdit = (isMaintainIndex && currentObj.isDbSearchResult);
                    if (isForEdit) {
                        editOriDeleteItems(valueFor, currentObj, isForEdit);
                    } else {
                        normalDeleteItems(valueFor, index, isMaintainIndex, currentObj, isForEdit);
                    }
                } else {
                    normalDeleteItems(valueFor, index, isMaintainIndex, currentObj, isForEdit);
                }

            }
        };

        $scope.checkDuplicateRecord = function (valueFor, rowObj) {
            var isDuplicateRecord = false;


            isDuplicateRecord = $scope.oriMsgCustomFields.Section_Details.sectionsSetup.length > 1 && $scope.oriMsgCustomFields.Section_Details.sectionsSetup.some(function (sectionObj) {
                return setupDuplicateCheck(sectionObj, rowObj, valueFor);
            });

            if (isDuplicateRecord) {
                alert(DUPLICATE_VALUE_FIELDS_MSG.replace("'fieldName'", '"' + $scope.fieldName + '"').replace("'fieldValue'", '"' + $scope.fieldValue + '"'));
            }
        };

        var normalDeleteItems = function (valueFor, index, isMaintainIndex, currentObj, isForEdit) {
            if (isMaintainIndex) {
                findDelHierarchy(valueFor, currentObj, isForEdit);
            } else {
                $scope.oriMsgCustomFields[valueFor].splice(index, 1);
                for (var b = 0; b < $scope.oriMsgCustomFields.Section_Details.sectionsSetup.length; b++) {
                    $scope.oriMsgCustomFields.Section_Details.sectionsSetup[b].additionalMetaDataValue.length && $scope.oriMsgCustomFields.Section_Details.sectionsSetup[b].additionalMetaDataValue.splice(index, 1);
                }
            }
        };
        var setupDuplicateCheck = function (sectionObj, rowObj, valueFor) {
            var isSameSequence = (rowObj.sequenceId + '' != '' && sectionObj.sequenceId != '' && parseInt(rowObj.sequenceId) != parseInt(sectionObj.sequenceId)),
                isSameSectionId = (rowObj.sectionId + '' != '' && parseInt(sectionObj.sectionId) == parseInt(rowObj.sectionId)),
                isSameSectionParentId = (rowObj.sectionParentId + '' != '' && parseInt(sectionObj.sectionParentId) == parseInt(rowObj.sectionParentId)),
                isSameAutoId = (rowObj.autoId + '' != '' && parseInt(sectionObj.autoId) == parseInt(rowObj.autoId)),
                isDuplicate = (isSameSequence && (isSameSectionId && isSameSectionParentId && isSameAutoId && !sectionObj[deleteFlagJsonKeyMap[valueFor]]));

            if (isDuplicate) {
                $scope.fieldName = 'Section-Order Id and Parent Id';
                $scope.fieldValue = rowObj.sectionId + ' and ' + rowObj.sectionParentId;
                rowObj.sectionId = '';
                rowObj.sectionParentId = '';
                rowObj.autoId = '';
            }

            return isDuplicate;
        };



        /**
         * Find all the Hierarchy nodes.
         */
        var getHierarchyList = function (valueFor, currentObj, isCurrObjInclude) {
            var tempObj = currentObj,
                heirarchyList = [],
                allSequences = [],
                directNodes = [],
                sequenceHie = {};

            if (isCurrObjInclude) {
                heirarchyList.push(tempObj),
                    allSequences.push(tempObj.sequenceId + '');
            }

            for (var i = 0; i < allSequences.length; i++) {
                directNodes = $scope.oriMsgCustomFields.Section_Details[valueFor].filter(function (obj) {
                    return obj.sectionParentId == allSequences[i];
                });
                for (var j = 0; j < directNodes.length; j++) {
                    if (allSequences.indexOf(directNodes[j].sequenceId + '') < 0) {
                        allSequences.push(directNodes[j].sequenceId + '');
                        heirarchyList.push(directNodes[j]);
                    } else {
                        break;
                    }
                }
                sequenceHie[allSequences[i]] = directNodes;
            }
            return heirarchyList;
        }
        /**
         * Delete Founded Hierarchy List from main JSON.
         */

        var findDelHierarchy = function (valueFor, currentObj, isForEdit) {
            var heirarchyList = getHierarchyList(valueFor, currentObj, true);
            // removing for the main Oject or set relevant delete flag for db.
            for (var k = 0; k < heirarchyList.length; k++) {
                for (var j = 0; j < $scope.oriMsgCustomFields.Section_Details[valueFor].length; j++) {
                    if ((typeof $scope.oriMsgCustomFields.Section_Details[valueFor][j] != 'undefined' || typeof $scope.oriMsgCustomFields.Section_Details[valueFor][j] != undefined) && ($scope.oriMsgCustomFields.Section_Details[valueFor][j].sequenceId == heirarchyList[k].sequenceId) && ($scope.oriMsgCustomFields.Section_Details[valueFor][j].autoId == heirarchyList[k].autoId)) {
                        if (isForEdit && $scope.oriMsgCustomFields.Section_Details[valueFor][j].isDbSearchResult) {
                            $scope.oriMsgCustomFields.Section_Details[valueFor][j][deleteFlagJsonKeyMap[valueFor]] = $scope.oriMsgCustomFields.Section_Details[valueFor][j].isDbSearchResult;
                            $scope.deletedSectionSequenceId.push(parseInt($scope.oriMsgCustomFields.Section_Details[valueFor][j].sequenceId));
                        } else {
                            $scope.deletedSectionSequenceId.push(parseInt($scope.oriMsgCustomFields.Section_Details[valueFor][j].sequenceId));
                            $scope.oriMsgCustomFields.Section_Details[valueFor].splice(j, 1);
                        }
                    }
                }
            }
        };

        /*
         *   function is to validate Parent Id not greater than or equal with sequence(Index Id).
         */

        $scope.validateCurrentIndex = function (event, sectionsSetup, whichField) {
            // truncating Leading Zeros from input.
            sectionsSetup.sectionId && (sectionsSetup.sectionId = parseInt(sectionsSetup.sectionId) || "");
            sectionsSetup.sectionParentId && (sectionsSetup.sectionParentId = parseInt(sectionsSetup.sectionParentId));
            (whichField === 'sectionParentId') && (sectionsSetup.sectionParentId == 0) && (sectionsSetup.isChildFormHide = false);

            if (whichField === 'sectionParentId' && (sectionsSetup.sectionParentId >= sectionsSetup.sequenceId)) {
                alert(PARENT_NO_MSG);
                // blank out section parent Id on blur.
                sectionsSetup.sectionParentId = '';
                sectionsSetup.isChildFormHide = false;
                sectionsSetup.autoId = sectionsSetup.sectionId;
                event.preventDefault();
            } else if (sectionsSetup.sectionParentId < sectionsSetup.sequenceId && $scope.deletedSectionSequenceId.indexOf(sectionsSetup.sectionParentId) > -1) {
                sectionsSetup.sectionParentId = '';
                sectionsSetup.isChildFormHide = false;
                sectionsSetup.autoId = '';
                alert('Parent Node you have entered is not available. Please fill this field from available nodes.');
                event.preventDefault();
            }

            $scope.updateAutoIds(sectionsSetup);
        };

        /*
         * below group of functions are for the 'Auto Id' field.
         */
        var autoidFlag;
        $scope.updateAutoIds = function (sectionsSetup) {
            autoidFlag="";
            updateAutoIds(sectionsSetup);
            updateAutoIdsHie(sectionsSetup);
        };

        var updateAutoIds = function (sectionsSetup) {
            if (sectionsSetup.sectionParentId == 0) {
                sectionsSetup.autoId = sectionsSetup.sectionId;
            } else {
                var rootParentId = $scope.findRootParent(sectionsSetup);
                var count=rootParentId && char_count(rootParentId.toString(),'.')
                if(count>8){
                        if(autoidFlag==""){
                            alert(Limit_Msg);
                            autoidFlag="1";}

                        // blank out section parent Id on blur.
                        sectionsSetup.sectionParentId = '';
                        sectionsSetup.isChildFormHide = false;
                        sectionsSetup.autoId = sectionsSetup.sectionId;
                        event.preventDefault();
                        return false;
                }
                if (rootParentId && sectionsSetup.sectionId) {
                    sectionsSetup.autoId = rootParentId + '.' + sectionsSetup.sectionId;
                } else {
                    sectionsSetup.autoId = sectionsSetup.sectionId;
                }
            }
        };

        var updateAutoIdsHie = function (sectionsSetup) {
            var heirarchyList = getHierarchyList('sectionsSetup', sectionsSetup, true);
            for (var k = 0; k < heirarchyList.length; k++) {
                for (var j = 0; j < $scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length; j++) {
                    if (sectionsSetup.sequenceId != $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][j].sequenceId && $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][j].sequenceId == heirarchyList[k].sequenceId) {
                        updateAutoIds($scope.oriMsgCustomFields.Section_Details['sectionsSetup'][j]);
                    }
                }
            }
        };

        $scope.findRootParent = function (sectionsSetup) {
            // truncating Leading Zeros
            var autoHId = parseInt(sectionsSetup.sectionParentId);
            sectionsSetup.sectionParentId=parseInt(sectionsSetup.sectionParentId);
            for (var t = 0; t < $scope.oriMsgCustomFields.Section_Details['sectionsSetup'].length; t++) {
                var item = $scope.oriMsgCustomFields.Section_Details['sectionsSetup'][t];
                if (sectionsSetup.sectionId && sectionsSetup.sectionParentId && (sectionsSetup.sectionParentId == item.sequenceId)) {
                    autoHId = item.autoId;
                }
            }

            return autoHId;
        };

        function clearActionEditForward() {
            var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == 'Respond';
            });
            if (ActionData && ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                for (var i = 0; i < ActionData.length; i++) {
                    var AutocompleteMsg = angular.copy($scope.AutocompleteMsgStructure);

                    AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
                    AutocompleteMsg.DS_MSG_AC_FORM = AppId;
                    AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
                    AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
                    AutocompleteMsg.DS_MSG_AC_ACTION = "3";
                    AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                    insertpoint.push(AutocompleteMsg);
                }
            }
        }

        function distributeEditFroward() {
            $scope.formCustomFields.REPEATING_VALUES.Distribution.AutoDistribute_Users = [];
            var recipients = $scope.formCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode;
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
            if (recipients.length) {
                var closeduedate = $scope.formCustomFields.Bid_Opportunity.DS_CLOSE_DUE_DATE;
                for (var i = 0; i < recipients.length; i++) {
                    var user = recipients[i].Tenderer_Recipient.trim();
                    if (user) {
                        setAutoDistribution(user, "3#Respond", closeduedate);
                    }
                }
            }

        }

        $scope.setFormTitle = function (bidType) {
            $scope.formCustomFields.Bid_Opportunity.ORI_FORMTITLE = bidType;
        }

        function restrictOtherUsersEditForward() {
            if ($scope.DS_ORIGINATOR != CurrentUserName && CurrentUserID != $scope.formCustomFields.Bid_Opportunity.Bid_Administrator.split('#')[0].trim()) {
                $scope.canUserEdit = false;
            }
        }

        function checkUserCanRespond() {
            var psrentMsgId = "";
            if (currentViewName == "RES_VIEW" || currentViewName == "ORI_VIEW") {
                if ($scope.DS_ISDRAFT_RES_MSG == "YES" || $scope.DS_ISDRAFT_FWD_MSG == "YES") {
                    psrentMsgId = $scope.oriMsgCustomFields.DSI_ParentMsgId;
                } else {
                    var commonParmObj = commonApi.getParamObj(),
                        psrentMsgId = commonParmObj.parent_msg_id && commonParmObj.parent_msg_id.split('$$')[0].trim() || "";
                    $scope.oriMsgCustomFields.DSI_ParentMsgId = psrentMsgId;
                }
                if (DS_ASI_GET_LATEST_ORI_FWD_MSG_ID.length && psrentMsgId != DS_ASI_GET_LATEST_ORI_FWD_MSG_ID[0].Value1.trim() && $scope.DS_ISDRAFT_FWD_MSG == 'NO') {
                    $scope.canUserRespond = false;
                }
            } else if (currentViewName == "ORI_PRINT_VIEW") {
                psrentMsgId = $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_MSGID.trim();
                if (DS_ASI_GET_LATEST_ORI_FWD_MSG_ID.length && psrentMsgId != DS_ASI_GET_LATEST_ORI_FWD_MSG_ID[0].Value2.trim() && $scope.DS_ISDRAFT_FWD_MSG == 'NO') {
                    $scope.canUserRespond = false;
                }
            }
        }

       

        $scope.onBoqChange = function (strVal) {
            if (strVal == "YES") {
                $scope.oriMsgCustomFields.DSI_Pkg_Req = "NO";
            }
        }

        $scope.restrictDashPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) {
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (parseFloat(inputValue) < 0) {
                event.preventDefault();
                return false;
            }
        }

        $scope.restrictQuantity = function (event, sectionsSetup) {
            var quantityVal = sectionsSetup.Quantity;
            if (quantityVal.toLocaleLowerCase() != "qro" && isNaN(quantityVal)) {
                sectionsSetup.Quantity = '';
                alert('Enter Proper number value');
            }
        }		        
    };
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof ITB_FinalCallBack !== "undefined") {
        return ITB_FinalCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof ITB_FinalCallBack !== "undefined") {
        return ITB_FinalCallBackDraft();
    }
}