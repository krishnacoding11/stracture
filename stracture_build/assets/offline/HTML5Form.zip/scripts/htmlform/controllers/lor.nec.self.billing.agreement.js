/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/signature'], function (angular, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd/M/yy');
            $scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
        });

        $scope.Logo = '/images/htmlform/LOR/lor-logo.jpg';
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        $window.addEventListener('scroll', function () {
            if ($window.scrollY || document.documentElement.scrollTop) {
                $element.addClass('scroll-top');
                return;
            }
            $element.removeClass('scroll-top');
        });

        /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.selectedTab = "Signature";
        var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData("DS_ASI_GET_Organization_Logo");
        $scope.DS_PROJUSERS = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.dsWorkingUserId = $scope.getWorkingUserId();
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        $scope.oriSignatoriesContractor = $scope.formCustomFields["REPEATING_VALUES"]["Signatories_Contractor_Group"]["Signatories_Contractor_USERS"][0];
        $scope.oriSignatoriesSubContractor = $scope.formCustomFields["REPEATING_VALUES"]["Signatories_SubContractor_Group"]["Signatories_SubContractor_USERS"][0];  

        var logoURLFromServer = '/images/htmlform/LOR/lor-logo.jpg';
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        // to get Custom Attribute On Load.
        var logo = commonApi._.findWhere(dsAsiConfigurableAttributes, {
            Value3: "SSC Logo",
            Value7: "SSC Logo"
        }) || {};
        $scope.oriMsgCustomFields.DS_Logo = logo.Value8 ? logo.Value8 : logoURLFromServer;

        // set contractor registration number baased on contractor company...
        $scope.setContractorRegNo = function(contractCompany){
            if(contractCompany == 'Laing O’Rourke Construction Limited'){
                $scope.oriMsgCustomFields.ContractorRegistrationNo = '4309402';
                $scope.oriMsgCustomFields.LOR_CompanyNumber = '549 3477 06';
            } else if(contractCompany == 'Laing O’Rourke Infrastructure Limited'){
                $scope.oriMsgCustomFields.ContractorRegistrationNo = '4309441';
                $scope.oriMsgCustomFields.LOR_CompanyNumber = '549 3477 06';
            } else if(contractCompany == 'Select Plant Hire Limited'){
                $scope.oriMsgCustomFields.ContractorRegistrationNo = '1973463';
                $scope.oriMsgCustomFields.LOR_CompanyNumber = '549 3477 06';
            } else if(contractCompany == 'Expanded Limited'){
                $scope.oriMsgCustomFields.ContractorRegistrationNo = '5117890';
                $scope.oriMsgCustomFields.LOR_CompanyNumber = '549 3477 06';
            }
        }

        if (currentViewName == "RES_VIEW") {
            if ($scope.strFormId != "") {
                var strMsg = "";
                if ($scope.oriSignatoriesContractor.dbUserId == $scope.getWorkingUserId() || $scope.oriSignatoriesSubContractor.dbUserId == $scope.getWorkingUserId()) {
                    strMsg = "0|";
                    $scope.contractorShow = false;
                    $scope.subContractorShow = false;
                    if ($scope.oriSignatoriesContractor.dbUserId == $scope.getWorkingUserId()) {
                        $scope.oriMsgCustomFields.boolContractorFlag = true;
                        $scope.contractorShow = true;
                    }
                    if ($scope.oriSignatoriesSubContractor.dbUserId == $scope.getWorkingUserId()) {
                        $scope.oriMsgCustomFields.boolSubcontractorFlag = true;
                        $scope.subContractorShow = true;
                    }

                } else {
                    strMsg = "1| You are not authorised to create or edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                }
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;

                for (var i = 0; i < DS_ASI_GET_Organization_Logo.length; i++) {
                    if ($scope.getWorkingUserId() == DS_ASI_GET_Organization_Logo[i].Value2.split("|")[2].trim()) {
                        if ($scope.contractorShow) {
                            $scope.contractorAutomatedSign = DS_ASI_GET_Organization_Logo[i].Value4;
                            break;
                        }
                        if ($scope.subContractorShow) {
                            $scope.subContractorAutomatedSign = DS_ASI_GET_Organization_Logo[i].Value4;
                            break;
                        }
                    }
                }
            }
        }

        $scope.scrollToTop = function () {
            window.scrollTo(0, 0);
        };

        // Form's workflow logic
        function setFormStatus(status) {
            var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
            var currFormStaus = status || 'Open';
            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: availFormStatuses,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }
        };

        $window.subcontractAgreementFinalCallBack = function () {
            if (currentViewName == "RES_VIEW") {

                // setting self billing agreement date signed by first response user...
                if (!$scope.oriMsgCustomFields.SelfBillingAgreementDate) {
                    $scope.oriMsgCustomFields.SelfBillingAgreementDate = $scope.todayDateUKFormat;
                }

                // set signature for manual contractor...
                if($scope.contractorShow){
                    if ($scope.oriMsgCustomFields.boolContractorFlag && $scope.oriMsgCustomFields.contractorAutomatedOrManual == 'Automated') {
                        $scope.oriSignatoriesContractor.sign = $scope.contractorAutomatedSign;
                    }
                }

                // set signature for manual subContractor....
                if($scope.subContractorShow){
                    if ($scope.oriMsgCustomFields.boolSubcontractorFlag && $scope.oriMsgCustomFields.subcontractorAutomatedOrManual == 'Automated') {
                        $scope.oriSignatoriesSubContractor.sign = $scope.subContractorAutomatedSign
                    }
                }
                

                // setting status as Signed as form is closeout...
                if ($scope.oriMsgCustomFields.boolContractorFlag && $scope.oriMsgCustomFields.boolSubcontractorFlag) {
                    setFormStatus('Signed');
                }
            }
            return false;
        };

        $window.draftSubmitCallBack = function () {
            //To Do
            return false;
        }

        $scope.update();
    }

    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {
    if (typeof subcontractAgreementFinalCallBack !== "undefined") {
        return subcontractAgreementFinalCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}