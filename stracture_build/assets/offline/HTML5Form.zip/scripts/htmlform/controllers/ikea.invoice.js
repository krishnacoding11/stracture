define(['angular', "mainModule", './base', '../components/item.selection', '../components/number-format', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $filter, $window, $timeout) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		
		$scope.stopAutoSaveDraftTimerFromClientSide();
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.Invoice_Item_Group = $scope.oriMsgCustomFields.Invoice_Item_Group;
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.editForward = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT != 'YES';
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isResPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.CurrformStatus  = angular.element('#DS_FORMSTATUS').val() || "";
		$scope.duplicateInvoice = false;
		$scope.xhr = {
			InvoiceItemsXhr: false,
			finalInvoceCreatedXhr: false
		}
		var STATIC_OBJ = {
			CODE_GROUP: {
				Group_Code: "",
				Group_Name: "",
				Group_Code_GUID: "",
				Invoice_Code_group: {
					Invoice_Code_list: []
				},
			},
			COST_CODE: {
				Code: "",
				Cost_Name: "",
				Code_GUID: "",
				Code_Parent_GUID: "",
				Contract_Amount: "",
				Current_Certified: "",
				Cumulative_upto_last_bill: "",
				Is_itemIncluded: 'yes'
			}
		},
		CONSTANTS_OBJ = {
			IMAGE_DEFAULT_STR: 'images/asite.gif',
			OPEN: "Open",
			CONTRACT_LIST:'contract-list',
			APPROVED_FINAL:"approved - final",
			APPROVED:"approved",
			REVISE_RESUBMIT: "revise and resubmit",
			COST_ORIGINATOR: "Invoice Originator",
			FOR_INFO: "7#For Information",
			ORI_ACTION_CODE: "3",
		},
		dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'],
		DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var isDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT == 'NO' ? false : true;
		var contractFormsList = $scope.getValueOfOnLoadData('DS_IKEA_Approved_Contract_List');
		
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			if (!dSFormId || isDraft) {
				var serverDateObj = new Date(serverDate);
				serverDateObj.setDate(serverDateObj.getDate() + 7);
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
			}
		});

		$scope.selectionlist = {
			ContractList: [],
			typesList: []
        }

		if($scope.isOriView){
			var curStatus = $scope.CurrformStatus.toLowerCase();
			$scope.isCostOriginator = hasCostOriginatorinROle();
			$scope.hideSaveDraftButton();
			if(!$scope.editForward){
				var logos = getLefRightLogo();
				$scope.oriMsgCustomFields.leftLogo =  logos[0];
				$scope.oriMsgCustomFields.rightLogo =  logos[1];
				$scope.selectionlist.ContractList = commonApi.getItemSelectionList({ arrayObject: contractFormsList, modelKey: 'Value4', displayKey: 'Value4' });
				$scope.selectionlist.typesList = commonApi.getItemSelectionList({
					arrayObject: getConfigurableAttriburteByType('Invoice Values'),
					groupNameKey: "",
					modelKey: "Value8",
					displayKey: "Value8",
					allowBlankSelection: true
				});
				setSupplyerBillingDetails();
			}
			if(!isDraft && !$scope.editForward && $scope.oriMsgCustomFields.Contract_No){
				$scope.oriMsgCustomFields.isFromLauch = true;
				onContractSelection();
			}

			// to edit and forward availabel for given status
			$scope.isAvailforEditAndForward = (curStatus == CONSTANTS_OBJ.REVISE_RESUBMIT)

			// to re get the contract details and cumulative certfied amount on adit and forward
			if((isDraft && $scope.oriMsgCustomFields.Contract_No) || ($scope.editForward && $scope.isAvailforEditAndForward)){
				$scope.requestLatestData = true;
				if(isDraft){
					CheckInvoiceCreateable($scope.oriMsgCustomFields.ContractFormID);
				}else{
					setInvoiceItemsDetails($scope.oriMsgCustomFields.ContractFormID)
				}
			}
		}
		if($scope.isRespView){
			var curUserId = $scope.getWorkingUserId();
			var currUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
			$scope.hasResponseAction = false;
			var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS').filter(function(item){
				return item.Name.toLowerCase() == 'respond'  && item.Value.indexOf(curUserId) > -1;
				});
			if(incompleteAction.length){
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
				$scope.resMsgCustomFields.Comments = "";
				if(currUser && currUser.length){
					$scope.resMsgCustomFields.responseBy = currUser[0].Name;
				}

				$scope.availableStatus = commonApi.getItemSelectionList({
					arrayObject: $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
					groupNameKey: "",
					modelKey: "Value",
					displayKey: "Name"
				});
				$scope.hasResponseAction = true;
			}
		}

		if($scope.isOriPrintView || $scope.isResPrintView){
			$scope.hideExportBtn();
			$scope.contractFOrmDetails = $scope.getValueOfOnLoadData('DS_GET_Form_All_Data_By_FormContent');
		}

		function getLefRightLogo(){
			var logos = getConfigurableAttriburteByType('Logo');
			var logoLeft = CONSTANTS_OBJ.IMAGE_DEFAULT_STR, logoRight = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
			angular.forEach(logos, function(item){
				if(item.Value7 && item.Value7.toLowerCase() == 'left logo'){
					logoLeft = item.Value8;
				}
				if(item.Value7 && item.Value7.toLowerCase() == 'right logo'){
					logoRight = item.Value8;
				}
			})
			return [logoLeft, logoRight];
		}
		
		/**
		 * return array custom attribute is matched with attribute name
		 * @param {string} type: confugured attrbite name
		 */
		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		function setSupplyerBillingDetails(){
			var supplier = $scope.oriMsgCustomFields.Supplier;
			var billing = $scope.oriMsgCustomFields.Billing
			var prevInvoice = $scope.getValueOfOnLoadData('DS_IKEA_Previous_INV_Dtls');
			if(isDraft || !prevInvoice || !prevInvoice.length){
				return;
			}
			supplier.Supplier_Name =  prevInvoice[0].Value4;
			supplier.Supplier_Contact =  prevInvoice[0].Value5;
			supplier.Supplier_Street =  prevInvoice[0].Value6;
			supplier.Supplier_Street1 =  prevInvoice[0].Value7;
			supplier.Supplier_City_State =  prevInvoice[0].Value8;
			supplier.Supplier_Zip =  prevInvoice[0].Value9;
			supplier.Supplier_Country =  prevInvoice[0].Value10;
			supplier.Supplier_Tel =  prevInvoice[0].Value11;
			supplier.Supplier_Email =  prevInvoice[0].Value12;
			supplier.Supplier_Fax =  prevInvoice[0].Value13;
			supplier.Supplier_GST =  prevInvoice[0].Value15;
			supplier.Supplier_PAN =  prevInvoice[0].Value14;
			supplier.Supplier_Vendor_Code =  prevInvoice[0].Value16;
			billing.Billing_Name = prevInvoice[0].Value17;
			billing.Billing_Contact = prevInvoice[0].Value18;
			billing.Billing_Street = prevInvoice[0].Value19;
			billing.Billing_Street1 = prevInvoice[0].Value20;
			billing.Billing_City_State = prevInvoice[0].Value21;
			billing.Billing_Zip = prevInvoice[0].Value22;
			billing.Billing_Country = prevInvoice[0].Value23;
			billing.Billing_Tel = prevInvoice[0].Value24;
			billing.Billing_Email = prevInvoice[0].Value25;
			billing.Billing_Fax = prevInvoice[0].Value26;
			billing.Billing_GST = prevInvoice[0].Value28;
			billing.Billing_PAN = prevInvoice[0].Value27
			billing.Billing_State_Code = prevInvoice[0].Value29;
		}

		/**
		 * Return true if working yuser has cost originator role
		 */
		function hasCostOriginatorinROle(){
			var aUserRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
			if(aUserRoles && aUserRoles.length && aUserRoles[0].Value){
				var found = commonApi._.find(aUserRoles[0].Value.split(','), function(item){
					return item.trim().toLowerCase() == CONSTANTS_OBJ.COST_ORIGINATOR.toLowerCase();
				})
				return !!found;
			}else{
				return false;
			}
		}

		/**
		 * return user with given role
		 * @param {array} role: array of role names 
		 */
		function getArrayOfUserbyRole(role){
			var projUserWithRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			var userArray= [], added;
			for(var i=0; i<projUserWithRole.length; i++){
				var userRoles = projUserWithRole[i].Value.split('|')[0].split(',');
				added = false;
				for(var j=0; j<userRoles.length; j++){
					if(!added && userRoles[j].toLowerCase().trim() == role.toLowerCase()){
						userArray.push(projUserWithRole[i].Value.split('|')[2].trim());
						added = true;
					}
				}
			}
			return userArray;
		}

		/**
		 * set form status
		 * @param {string} StrStatus: status to set
		 */
		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}

		/**
		 * Commen function to assing action to user
		 * @param {*} userToDist: array or string users list or sing user 
		 * @param {string} action: action to assign
		 * @param {string} DS_AUTODISTRIBUTE
		 * @param {*} distDate: due date fo action
		 */
		function assignActionToUser(userToDist, action, DS_AUTODISTRIBUTE, distDate){
			var tempList = [];
			if(angular.isArray(userToDist) && userToDist.length){
				for (var j = 0; j < userToDist.length; j++) {
					tempList.push({
						strUser: userToDist[j],
						strAction: action,
						strDate: distDate
					});
				}
			}else{
				tempList.push({
					strUser: userToDist,
					strAction: action,
					strDate: distDate
				});
			}
			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODISTRIBUTE
			});
		}

		function isNOtAllowed(){
			if($scope.editForward && !$scope.isCostOriginator){
				alert('You are not allowed to edit and forward')
				return true;
			}
			if($scope.editForward && $scope.isCostOriginator && !$scope.isAvailforEditAndForward){
				alert('Approval in progress');
				return true;
			}
			return false;
		}

		/**
		 * 
		 * @param {object} curItem: current item of invoice
		 */
		$scope.onCertifiedAmountChange = function(curItem){
			var totalCurcertifed = 0;
			angular.forEach($scope.Invoice_Item_Group.Invoice_Items, function(item){
				angular.forEach(item.Invoice_Code_group.Invoice_Code_list, function(subitem){
					if(subitem.Is_itemIncluded == 'yes'){
						totalCurcertifed = totalCurcertifed + Number(subitem.Current_Certified);
					}
				});
			});
			$scope.oriMsgCustomFields.Total_Current_Certified = totalCurcertifed;
			setAllTotals();
		};

		$scope.onDeductionChange = function(){
			var orimsg = $scope.oriMsgCustomFields;
			if(orimsg.Deductions && Number(orimsg.Deductions) < 0){
				alert('should not be nagative');
				orimsg.Deductions = 0;
			}
			orimsg.Total_Deductions = Number(orimsg.Cumulative_Deductions_upto_last_bill) + Number(orimsg.Deductions);
			setAllTotals();
		}

		$scope.onRetentionChange = function(){
			var orimsg = $scope.oriMsgCustomFields;
			if(orimsg.Retention && Number(orimsg.Retention) < 0){
				alert('should not be nagative');
				orimsg.Retention = 0;
			}
			orimsg.Total_Retentions = Number(orimsg.Cumulative_Retention_upto_last_bill) + Number(orimsg.Retention);
			setAllTotals();
		}

		$scope.onMobilzationChange = function(){
			var orimsg = $scope.oriMsgCustomFields;
			orimsg.Total_Mob_Adj = Number(orimsg.Cumulative_Mob_adj_upto_last_bill) + Number(orimsg.Moblization_Adjustment);
			setAllTotals();
		}

		function setAllTotals(){
			var orimsg = $scope.oriMsgCustomFields;
			orimsg.Total_Certified_After_deduction = orimsg.Total_Current_Certified - Number(orimsg.Deductions) - Number(orimsg.Retention) - Number(orimsg.Moblization_Adjustment)
			orimsg.Payable_invoice = orimsg.Total_Certified_After_deduction;
			orimsg.Total_Cumulative_And_Certified_After_deduction = orimsg.Total_Certified_After_deduction + orimsg.Total_Cumulative_After_deduction;
		}

		$scope.onContractSelection = onContractSelection;
		function onContractSelection(){
			var selectedContractNO = $scope.oriMsgCustomFields.Contract_No;
			if(selectedContractNO){
				var foundbud = commonApi._.find(contractFormsList, function(item){
					return item.Value4 == selectedContractNO;
				});
				if(foundbud){
					$scope.oriMsgCustomFields.Contact_Title = foundbud.Value5;
					$scope.oriMsgCustomFields.Contact_For = foundbud.Value6;
					$scope.oriMsgCustomFields.Role = foundbud.Value7;
					$scope.oriMsgCustomFields.Tax = foundbud.Value10;
					$scope.oriMsgCustomFields.Currency = foundbud.Value11;
					$scope.oriMsgCustomFields.ContractFormID = foundbud.Value2;
					$scope.oriMsgCustomFields.Project_Name = foundbud.Value12;
					$scope.oriMsgCustomFields.Start_Date = foundbud.Value8;
					$scope.oriMsgCustomFields.End_Date = foundbud.Value9;
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3  = foundbud.Value2;
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1  = foundbud.Value2;
					CheckInvoiceCreateable($scope.oriMsgCustomFields.ContractFormID);	
				}
			}else{
				resetContractDetails();
			}
		};

		/**
		 * retrun formdata form ajax request
		 * @param {string} sp: string if multiple then string with comma seperated
		 * @param {any} fieldName: string of field name or array of object with sp and field name 
		 */
		function getFormDataForAjax(sp, fieldName){
			var tempList = [];
			if(angular.isArray(fieldName) && fieldName.length){
				for (var j = 0; j < fieldName.length; j++) {
					tempList.push({
						fieldName: fieldName[j].sp,
						fieldValue: fieldName[j].fieldValue
					});
				}
			}else{
				tempList.push({
					fieldName: sp,
					fieldValue: fieldName
				});
			}
			return {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": sp,
				"callbackParamVO": {
					"customFieldVOList": tempList
				}
			};
		}

		function CheckInvoiceCreateable(contractForm){
			$scope.xhr.finalInvoceCreatedXhr = true;
			var listDataReviseDate = [], invoiceTypes = [], foundFulAndFinal;
			var sp = "DS_IKEA_Form_CAM_Dtls,DS_IKEA_Invoice_Type";
			var fieldValue = [{sp:"DS_IKEA_Form_CAM_Dtls",fieldValue: contractForm},
							{sp:"DS_IKEA_Invoice_Type",fieldValue: contractForm}]
			var form = getFormDataForAjax(sp,fieldValue);
			$scope.getCallbackData(form).then(function (response) {
				$scope.xhr.finalInvoceCreatedXhr = false;
				listDataReviseDate = angular.fromJson(response.data['DS_IKEA_Form_CAM_Dtls']).Items.Item;
				invoiceTypes = angular.fromJson(response.data['DS_IKEA_Invoice_Type']).Items.Item;
				var endDate = listDataReviseDate && listDataReviseDate.length && listDataReviseDate[0].Value6 || $scope.oriMsgCustomFields.End_Date;
				$scope.isFullAndFInalCreated = false;
				if(invoiceTypes && invoiceTypes.length){
					foundFulAndFinal = commonApi._.find(invoiceTypes, function(item){
						return item.Value6.toLowerCase() == "full and final settlement";
					});
					if(foundFulAndFinal){
						alert('Full and final invoice created for this contract.');
						$scope.isFullAndFInalCreated = true;
						resetContractDetails();
						$scope.Invoice_Item_Group.Invoice_Items = [];
						$scope.oriMsgCustomFields.Contract_No = "";
						return;
					}
				}
				if(endDate >= getDateFromZone()){
					//set invoice item details it contract end date is not over
					setInvoiceItemsDetails(contractForm);
				}else{
					// reset details if contract end date is over
					alert('Contract End date is over, You can not create invoice of selected contract');
					resetContractDetails();
					$scope.Invoice_Item_Group.Invoice_Items = [];
					$scope.oriMsgCustomFields.Contract_No = "";
					$scope.isEndDateOver = true;
				}
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Fetching Data.'
				});
				$scope.xhr.finalInvoceCreatedXhr = false;
			});
		}

		/**
		 * called on contract selection or onload for edit ori or draft ori, 
		 * need to add backuplist when calling from edit and forward or draft
		 * @param {string} contractForm: contract form no 
		 */
		function setInvoiceItemsDetails(contractForm){
			var sp = "DS_IKEA_Form_BSF_CON_CAM_Dtls,DS_IKEA_Invoice_Dtls";
			var fieldValue = [{sp:"DS_IKEA_Form_BSF_CON_CAM_Dtls",fieldValue: contractForm},
							{sp:"DS_IKEA_Invoice_Dtls",fieldValue: contractForm}]
			$scope.Backup_Invoice_Items = $scope.Invoice_Item_Group.Invoice_Items;
			$scope.Invoice_Item_Group.Invoice_Items = [];
			var form = getFormDataForAjax(sp,fieldValue);
			$scope.getCallbackData(form).then(function (response) {
				var listDataCont = angular.fromJson(response.data['DS_IKEA_Form_BSF_CON_CAM_Dtls']).Items.Item;
				var listDataIvoice = angular.fromJson(response.data['DS_IKEA_Invoice_Dtls']).Items.Item;
				fillInvoiceItemsDetails(listDataCont);
				getAllcummulativeUptoLastInvoice(listDataIvoice);
				$scope.xhr.InvoiceItemsXhr = false;
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Fetching Data.'
				});
				$scope.xhr.InvoiceItemsXhr = false;
			});
		}

		/**
		 * setting data in contact items list
		 * @param {array} list: list of budget sumamry cost code got by sp
		 */
		function fillInvoiceItemsDetails(list){
			var parentObj = {}, childObj = {}, groupTrack = {};
			var TotalconAmt = 0;
			$scope.oriMsgCustomFields.Total_Final_Contract_Amount = 0
			angular.forEach(list, function(item){
				if(!groupTrack.hasOwnProperty(item.Value9)){
					groupTrack[item.Value9] = 'no';
				}
				if(groupTrack.hasOwnProperty(item.Value9) && groupTrack[item.Value9] == 'no'){
					parentObj = angular.copy(STATIC_OBJ.CODE_GROUP);
					parentObj.Group_Code_GUID = item.Value9;
					parentObj.Group_Code = item.Value7;
					parentObj.Group_Name = item.Value8;
					parentObj.hasAnyWithChecked = 'no';
				}
				angular.forEach(list, function(subitem){
					if(item.Value9 == subitem.Value9 && groupTrack[item.Value9] == 'no' && subitem.Value17 == 'yes'){
						childObj = angular.copy(STATIC_OBJ.COST_CODE);
						childObj.Code_GUID = subitem.Value12;
						childObj.Code = subitem.Value10;
						childObj.Cost_Name = subitem.Value11;
						childObj.Code_Parent_GUID = subitem.Value9;
						childObj.Contract_Amount =  Number(subitem.Value4) + Number(subitem.Value16);
						TotalconAmt = TotalconAmt + childObj.Contract_Amount;
						childObj.Current_Certified =  "";
						childObj.Is_itemIncluded = subitem.Value17;
						if(childObj.Is_itemIncluded == 'yes'){
							parentObj.hasAnyWithChecked = 'yes';
						}
						parentObj.Invoice_Code_group.Invoice_Code_list.push(childObj);
					}
				});
				if(groupTrack.hasOwnProperty(item.Value9) && groupTrack[item.Value9] == 'no'){
					groupTrack[item.Value9] = 'yes';
					//here only pushing that which group has atlease one row is selected in it
					if(parentObj.hasAnyWithChecked == 'yes'){
						$scope.Invoice_Item_Group.Invoice_Items.push(parentObj);
					}
				}
			});
			$scope.oriMsgCustomFields.Total_Final_Contract_Amount = TotalconAmt;
		}

		/**
		 * called on load for update and set updated date edit and distribte and draft case
		 * @param {array} backup_List: list of backed up contract item of chenged
		 */
		function updateInvoiceItemList(backup_List){
			var backupGroup, backupcode;
			if(!backup_List){
				return;
			}
			angular.forEach($scope.Invoice_Item_Group.Invoice_Items, function(item){
				backupGroup = commonApi._.find(backup_List, function(backupgroupItem){
					return backupgroupItem.Group_Code_GUID == item.Group_Code_GUID;
				})
				if(backupGroup){
					angular.forEach(item.Invoice_Code_group.Invoice_Code_list, function(subitem){
						backupcode = commonApi._.find(backupGroup.Contract_Code_group.Contract_Code_list, function(backupCodeItem){
							return backupCodeItem.Code_GUID == subitem.Code_GUID;
						})
						if(backupcode && (backupcode.Is_itemIncluded == 'yes' || subitem.Is_itemIncluded == 'yes') ){
							subitem.Is_itemIncluded = 'yes'
							subitem.Current_Certified = backupcode.Current_Amendment;
						}
					});
				}
			})
		}

		/**
		 * 
		 * @param {Array} listData array of invoice data of cummulative details
		 */
		function getAllcummulativeUptoLastInvoice(listData){
			var orimsg = $scope.oriMsgCustomFields, totalCumlitive = 0;
			if(listData && listData.length){
				angular.forEach(listData, function(spListItem){
					angular.forEach($scope.Invoice_Item_Group.Invoice_Items, function(item){
						angular.forEach(item.Invoice_Code_group.Invoice_Code_list, function(subitem, index){
							if((spListItem.Value9 == subitem.Code_GUID) && subitem.Is_itemIncluded == 'yes'){
								// dummy entry of cummulative till sp ready
								subitem.Cumulative_upto_last_bill = spListItem.Value4;
								totalCumlitive = totalCumlitive + Number(subitem.Cumulative_upto_last_bill);
							}
						});
					});
				});
				orimsg.Cumulative_Deductions_upto_last_bill = listData[0].Value6;
				orimsg.Cumulative_Retention_upto_last_bill = listData[0].Value5;
				orimsg.Cumulative_Mob_adj_upto_last_bill = listData[0].Value7;
				orimsg.Total_Cumulative_upto_last_bill = totalCumlitive;
				orimsg.Total_Cumulative_After_deduction = orimsg.Total_Cumulative_upto_last_bill - 
				Number(orimsg.Cumulative_Deductions_upto_last_bill) - 
				Number(orimsg.Cumulative_Retention_upto_last_bill) - 
				Number(orimsg.Cumulative_Mob_adj_upto_last_bill);
			}else{
				orimsg.Cumulative_Deductions_upto_last_bill = 0;
				orimsg.Cumulative_Retention_upto_last_bill = 0;
				orimsg.Cumulative_Mob_adj_upto_last_bill = 0;
				orimsg.Total_Cumulative_upto_last_bill = 0;
				orimsg.Total_Cumulative_After_deduction = 0;
			}
			orimsg.Total_Deductions = Number(orimsg.Cumulative_Deductions_upto_last_bill) + Number(orimsg.Deductions);
			orimsg.Total_Retentions = Number(orimsg.Cumulative_Retention_upto_last_bill) + Number(orimsg.Retention);
			orimsg.Total_Mob_Adj = Number(orimsg.Cumulative_Mob_adj_upto_last_bill) + Number(orimsg.Moblization_Adjustment);
		
			if($scope.requestLatestData){
				updateInvoiceItemList($scope.Backup_Invoice_Items);
				$scope.requestLatestData = false;
			}
			setAllTotals();
		}
		
		function resetContractDetails(){
			$scope.oriMsgCustomFields.Contact_Title = "";
			$scope.oriMsgCustomFields.Contact_For = "";
			$scope.oriMsgCustomFields.Role = "";
			$scope.oriMsgCustomFields.Tax = "";
			$scope.oriMsgCustomFields.Currency = "";
			$scope.oriMsgCustomFields.ContractFormID = "";
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = "";
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = "";
		}

		/**
		 * get today's date from zone
		 */
		function getDateFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}

		$scope.checkDuplicate = function (invNumber, submitType){
			if(!invNumber){
				$scope.duplicateInvoice = false;
				return;
			}
			$scope.uniqueNameValidationXHR = true;
			var spName = "DS_IKEA_validate_Invoice_No_INV";
			var form =  {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": spName,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": spName,
						"fieldValue": invNumber.trim()
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				var respItems = angular.fromJson(response.data[spName]).Items.Item;
				$scope.uniqueNameValidationXHR = false;
				if(respItems[0].Value2 && respItems[0].Value2.toLowerCase() == 'yes'){
					$scope.duplicateInvoice = true;
					$scope.submitFlag = false;
					if(submitType){
						alert('Duplicate Invoice Number');
					}
				}else{
					$scope.duplicateInvoice = false;
					if(submitType && (submitType == 'send' || submitType == 'draft')){
						$scope.submitFlag = true;
						if(submitType == 'send'){
							$window.submitForm(1);
						}else{
							$window.submitForm(0);
						}
					}
				}
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Validation Check.'
				});
				$scope.duplicateInvoice = false;
				$scope.uniqueNameValidationXHR = false;
			});
		};
		
		$scope.update();

		$window.oriformSubmitCallBack = function () {
			var oriMsg = $scope.oriMsgCustomFields;
			if($scope.isOriView){
				if($scope.isEndDateOver){
					alert('Contract End date is over, You can not create invoice of selected contract');
					return true;
				}
				if($scope.isFullAndFInalCreated){
					alert('Full and final invoice created for this contract.');
					return true;
				}
				if(isNOtAllowed()){
					return true;
				}
				if(!$scope.editForward){
					if($scope.uniqueNameValidationXHR){
						alert('Wait, Invoice Number validation check request running');
						return true;
					}
					if(!$scope.submitFlag && oriMsg.Invoice_Number){
						$scope.checkDuplicate(oriMsg.Invoice_Number, 'send');
						return true;
					}
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = oriMsg.Invoice_Number;
				}
				if($scope.oriMsgCustomFields.Contract_No){
					$scope.oriMsgCustomFields.ORI_FORMTITLE =  "Invoice for " +   $scope.oriMsgCustomFields.Contract_No;
				}
				assignActionToUser(getArrayOfUserbyRole(CONSTANTS_OBJ.COST_ORIGINATOR), CONSTANTS_OBJ.FOR_INFO, CONSTANTS_OBJ.ORI_ACTION_CODE, '');
				updateFormStatus(CONSTANTS_OBJ.OPEN);
				oriMsg.isRespView = 'no';
			}
			if($scope.isRespView){
				if(!$scope.hasResponseAction){
					alert('You are not authorized to response.');
					return true;
				}
				oriMsg.isRespView = 'yes';
			}
			return false;
		};
		$window.draftSubmitCallBack = function () {
			var oriMsg = $scope.oriMsgCustomFields;
			if($scope.isOriView){
				if($scope.isEndDateOver){
					alert('Contract End date is over, You can not create invoice of selected contract');
					return true;
				}
				if($scope.isFullAndFInalCreated){
					alert('Full and final invoice created for this contract.');
					return true;
				}
				if(isNOtAllowed()){
					return true;
				}
				if(!$scope.editForward){
					if($scope.uniqueNameValidationXHR){
						alert('Wait, Invoice Number validation check request running');
						return true;
					}
					if(!$scope.submitFlag && oriMsg.Invoice_Number){
						$scope.checkDuplicate(oriMsg.Invoice_Number, 'draft');
						return true;
					}
					if($scope.oriMsgCustomFields.Contract_No){
						$scope.oriMsgCustomFields.ORI_FORMTITLE =  "Invoice for " +   $scope.oriMsgCustomFields.Contract_No;
					}
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = oriMsg.Invoice_Number;
				}
				oriMsg.isRespView = 'no';
			}
			return false;
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}