/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', "mainModule", './base'], function (angular, mainModule, baseController) {
	'use strict';
	 
    /**
         * removeToobarOptions : @taOptions required,
         * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
         * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
         * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
         */
        var hideOnOutside = function () {
            angular.element('body').on('click', function (event) {
                var $eventTarget = angular.element(event.target),
                    targetClassList = event.target.classList,
                    targetParentClassList = event.target.parentElement.classList,
                    $editorToolbar = angular.element('.artf-editor-toolbar');
                if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
                    !$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
                    $editorToolbar.find('.font-name').removeClass('open-fonts-list');
                }
                if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
                    !$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
                    $editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
                }
            });
        }, addTextAngularOptions = function ($provide) {
            $provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
                taOptions.toolbar = [
                    ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                    ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                    []
                ];
                return taRegisterTool("backgroundColor", {
                    display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                    action: function (color) {
                        var me = this;
                        if (this.$editor().wrapSelection) {
                            return this.$editor().wrapSelection("backColor", color)
                        }
                    },
                    options: {
                        replacerClassName: "fa fa-paint-brush",
                        showButtons: !1
                    },
                    color: "#fff"
                }),
                    taRegisterTool("fontColor", {
                        display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
                        action: function (color) {
                            var me = this;
                            if (this.$editor().wrapSelection) {
                                return this.$editor().wrapSelection("foreColor", color)
                            }
                        },
                        options: {
                            replacerClassName: "fa fa-font",
                            showButtons: !1,
                            showAlpha: !1
                        },
                        color: "#000"
                    }),
                    taRegisterTool('fontName', {
                        display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>" + "</button>",
                        action: function (event, font) {
                            //Ask if event is really an event.					
                            if (!!event.stopPropagation) {
                                //With this, you stop the event of textAngular.
                                event.stopPropagation();
                                //Then click in the body to close the dropdown.
                                angular.element("body").trigger("click");
                            }
                            angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
                            this.$element.toggleClass('open-fonts-list');
                            return this.$editor().wrapSelection('fontName', font);
                        },
                        disabled: function () { },
                        options: [
                            { name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
                            { name: 'Serif', css: "'times new roman', serif" },
                            { name: 'Wide', css: "'arial black', sans-serif" },
                            { name: 'Narrow', css: "'arial narrow', sans-serif" },
                            { name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
                            { name: 'Courier New', css: "'courier new', monospace" },
                            { name: 'Garamond', css: 'garamond, serif' },
                            { name: 'Georgia', css: 'georgia, serif' },
                            { name: 'Tahoma', css: 'tahoma, sans-serif' },
                            { name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
                            { name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
                            { name: 'Verdana', css: 'verdana, sans-serif' },
                            { name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
                        ]
                    }),
                    taRegisterTool('fontSize', {
                        display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",
                        action: function (event, size) {
                            //Ask if event is really an event.					
                            if (!!event.stopPropagation) {
                                //With this, you stop the event of textAngular.
                                event.stopPropagation();
                                //Then click in the body to close the dropdown.
                                angular.element("body").trigger("click");
                            }
                            angular.element('.open-fonts-list').removeClass('open-fonts-list');
                            this.$element.toggleClass('open-fonts-size-list');
                            return this.$editor().wrapSelection('fontSize', parseInt(size));
                        },
                        disabled: function () { },
                        options: [
                            { name: 'xx-small', css: 'xx-small', value: 1 },
                            { name: 'x-small', css: 'x-small', value: 2 },
                            { name: 'small', css: 'small', value: 3 },
                            { name: 'medium', css: 'medium', value: 4 },
                            { name: 'large', css: 'large', value: 5 },
                            { name: 'x-large', css: 'x-large', value: 6 },
                            { name: 'xx-large', css: 'xx-large', value: 7 }
    
                        ]
                    }),
                    taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'), taOptions;
            }
            ]);
        };
    
        /**
         * configuring and Binding the created text-angular options to the MainModule.
         */
        mainModule.config(function ($translateProvider, $provide) {
            addTextAngularOptions($provide);
            hideOnOutside();
        });
        
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		$scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];

		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_GEO_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_GEO_STD_TNDR_GetITBs');
		$scope.DS_PROJORGANISATIONS = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
		$scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		$scope.DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');

		$scope.update();
		$scope.DSI_isLoaded = true;
		$scope.DistributionStructure = {
			DS_PROJDISTUSERS: "",
			DS_FORMACTIONS: "",
			DS_ACTIONDUEDATE: "",
			Dist_Organisation: ""
		}

		$scope.logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});

		function setClientLogo() {
			if ($scope.logo && $scope.logo[0].Value8) {
				$scope.oriMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
			}
		}
		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			var strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date(strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(strTime), 'dd-M-yy');
		});
		if (currentViewName == "ORI_VIEW") {
			if (strFormId == "" || strIsDraft == "YES") {
				setClientLogo();
				$timeout(function () {
					if (localStorage) {
						var numVal = localStorage.getItem('formcode_num');
						if (numVal) {
							$scope.oriMsgCustomFields.ITB_Info.Select_ITB = numVal;
							$scope.setITTDetails(numVal);
							localStorage.removeItem('formcode_num');
						}
					}
				}, 1000);
			}
		}
		if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW") {
			var itbURL = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
				return val.Value1 == $scope.oriMsgCustomFields.ITB_Info.Select_ITB;
			});

			if (itbURL && itbURL.length) {
				$scope.oriMsgCustomFields.ITB_Info.ITB_URL = itbURL[0].URL6;
			}
		}

		$timeout(function () {
			$scope.expandTextAreaOnLoad();
		}, 1000);

		$scope.AddNewItem = function (repeatingData, fromStructure) {
			var item = angular.copy(fromStructure);
			repeatingData.push(item);
		};
		$scope.DeleteRow = function (index, repeatindData) {
			if (repeatindData.length > index) {
				repeatindData.splice(index, 1);
			}
		};
		$scope.DeleteItem = function (obj, repeatingData) {
			//delete data by index
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
		};


		$scope.setITTDetails = function (str) {
			if (str) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_GEO_STD_ADD_BM_Bid_CloseDetails,DS_GEO_STD_TNDR_GET_ITBSDETAILS,DS_GEO_STD_ADD_BM_Bid_Recipients",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_GEO_STD_ADD_BM_Bid_CloseDetails",
							"fieldValue": str
						}, {
							"fieldName": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
							"fieldValue": str
						}, {
							"fieldName": "DS_GEO_STD_ADD_BM_Bid_Recipients",
							"fieldValue": str
						}]
					}
				};
				$scope.DSI_isLoaded = false;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var ITBData = angular.fromJson(response.data['DS_GEO_STD_TNDR_GET_ITBSDETAILS']).Items.Item;
						var AllCloseDate = angular.fromJson(response.data['DS_GEO_STD_ADD_BM_Bid_CloseDetails']).Items.Item;
						var DS_GEO_STD_ADD_BM_Bid_Recipients = angular.fromJson(response.data['DS_GEO_STD_ADD_BM_Bid_Recipients']).Items.Item;
						if (ITBData && ITBData.length) {
							var strBidAdmin = ITBData[0].Value5;
							var strOrgTitle = ITBData[0].Value3;
							var strItbId = ITBData[0].Value1;

							$scope.oriMsgCustomFields.ITB_Info.ORI_FORMTITLE = strOrgTitle;
							$scope.oriMsgCustomFields.ITB_Info.Bid_Administrator = strBidAdmin;
							$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strItbId;

						}
						setDistNodes(DS_GEO_STD_ADD_BM_Bid_Recipients);
						if (AllCloseDate && AllCloseDate.length) {
							if (AllCloseDate[0].Value5) {
								$scope.oriMsgCustomFields.Addenda_Prev_Date = AllCloseDate[0].Value5;
							}
							if (AllCloseDate[0].Value6) {
								$scope.oriMsgCustomFields.ITB_Review_Date = AllCloseDate[0].Value6;
							}
							if (AllCloseDate[0].Value7) {
								$scope.oriMsgCustomFields.ITB_Review_Date = AllCloseDate[0].Value7;
							}
							if (AllCloseDate[0].Value8) {
								$scope.oriMsgCustomFields.ITB_Prev_Release_Date = AllCloseDate[0].Value8;
							}
							if (AllCloseDate[0].Value10) {
								$scope.oriMsgCustomFields.DSI_SourceTimeZone = AllCloseDate[0].Value10;
							}
							if (AllCloseDate[0].Value11) {
								$scope.oriMsgCustomFields.DSI_TimeZone_Offset = AllCloseDate[0].Value11;
								$scope.oriMsgCustomFields.DSI_Converted_Date = getDateTimeFromZone();

							}
						}
						$scope.DSI_isLoaded = true;
					}
				});
			}
		}

		function setDistNodes(DS_GEO_STD_ADD_BM_Bid_Recipients) {
			$scope.asiteSystemDataReadWrite.Distribution.AutoDirstribute_Users = [];
			var strrecepients = commonApi._.filter(DS_GEO_STD_ADD_BM_Bid_Recipients, function (val) {
				return val.Value7 != 'Rejected'
			});
			$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "3";
			for (var i = 0; i < strrecepients.length; i++) {
				var strUserId = strrecepients[i].Value5.trim();

				var strUserDetails = getUserName(strUserId);
				var strOrgDetails = strrecepients[i].Value4.trim();
				if(strUserDetails!="" && strOrgDetails !="")
					setAutoDistribution(strUserDetails, "7#For Information", "", strOrgDetails);
			}
		}

		function getUserName(strUserId) {
			var Allusers = $scope.DS_PROJDISTUSERS;
			if (Allusers && Allusers.length) {
				for (var i = 0; i < Allusers.length; i++) {
					var strValue = Allusers[i].Value.trim();
					if (strValue && strValue.split('#')[0] == strUserId) {
						return strValue;
					}
				}
			}
			return "";
		}

		function setAutoDistribution(strUser, strAction, strDueDate, strOrg) {

			if (strDueDate) {
				strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
			}
			//get copy of distribution and set user ,date ,action to distribute
			var structDistricution = angular.copy($scope.DistributionStructure)
			structDistricution.DS_PROJDISTUSERS = strUser;
			structDistricution.DS_FORMACTIONS = strAction;
			structDistricution.DS_ACTIONDUEDATE = strDueDate;
			structDistricution.Dist_Organisation = strOrg;
			$scope.asiteSystemDataReadWrite.Distribution.AutoDirstribute_Users.push(structDistricution);
		}

		$window.ASI_FinalCallBack = function () {
			return $scope.FinalCallBack();
		}

		$scope.FinalCallBack = function () {
			$scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_SEND_MSG = "0";
			var strITTId = $scope.oriMsgCustomFields.ITB_Info.Select_ITB;
			if (strITTId) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
							"fieldValue": strITTId
						}]
					}
				};
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var ITBData = angular.fromJson(response.data['DS_GEO_STD_TNDR_GET_ITBSDETAILS']).Items.Item;
						if (ITBData && ITBData.length) {
							var val12 = ITBData[0].Value12;
							if (val12 && val12 == "1") {
								$scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_SEND_MSG = "1| Supplementary can not be created subsequent to the release of responses.";
								return true;
							}
						}

					}
				});
			}

			return false;
		}

		$scope.SetEndDate = function () {
			$scope.strdate = $scope.oriMsgCustomFields.Tender_New_End_Date;
			$scope.strTime = $scope.oriMsgCustomFields.Tender_New_End_Time;
			var strAddendaPrevDate = $scope.oriMsgCustomFields.Addenda_Prev_Date;
			var strchangedate = $scope.oriMsgCustomFields.Change_Date;
			$scope.endDatemsg = "";
			if (!$scope.strdate && strchangedate.toLowerCase() == "yes") {
				$scope.endDatemsg = "Mandatory values not selected !!! \n\n Select New End date for the Tender";
				return true;
			}
			if (!$scope.strTime && strchangedate.toLowerCase() == "yes") {
				return true;
			}
			if($scope.strdate)
			{
				var newEnddtobj = new Date($scope.strdate);
				newEnddtobj.setHours(0);
				newEnddtobj.setMinutes(0);
				newEnddtobj.setSeconds(0);
				var prevEnddtObj = new Date(strAddendaPrevDate);
				prevEnddtObj.setHours(0);
				prevEnddtObj.setMinutes(0);
				prevEnddtObj.setSeconds(0);
				if(newEnddtobj < prevEnddtObj)
				{
					$scope.oriMsgCustomFields.Tender_New_End_Date = "";
					alert("Invalid Date selected! \n\n Specify End date greater than or equal to Previous end date");
					return true;
				}
			}
			if ($scope.strdate && $scope.strTime) {
				var dt = new Date($scope.strdate);
				var strtime = convertTimeformat($scope.strTime);
				if (strtime) {
					var arrtime = strtime.split(':');
					dt.setHours(arrtime[0]);
					dt.setMinutes(arrtime[1]);
				}
				$scope.oriMsgCustomFields.Addenda_End_Date = $filter('date')(dt, 'yyyy-MM-ddTHH:mm:ss');
				var strConvertedDate = $scope.oriMsgCustomFields.DSI_Converted_Date;
				var dtConverted = new Date(strConvertedDate);
				if (dt.getTime() < dtConverted.getTime()) {
					alert("Invalid Date selected! \n\n Specify Tender End date greater than or equal to today's date");
					$scope.oriMsgCustomFields.Tender_New_End_Time = "";
					return true;
				}
				var dt1 = new Date(strAddendaPrevDate);
				if (dt.getTime() < dt1.getTime()) {
					alert("Invalid Date selected! \n\n Specify End date greater than or equal to Previous end date");
					$scope.oriMsgCustomFields.Tender_New_End_Date = "";
					$scope.oriMsgCustomFields.Tender_New_End_Time = "";
					return true;
				}
			}
			return false;
		}

		$scope.SetEndTimeMandatory = function () {
			$scope.strTime = $scope.oriMsgCustomFields.Tender_New_End_Time;
			var strchangedate = $scope.oriMsgCustomFields.Change_Date;
			if (!$scope.strTime && strchangedate.toLowerCase() == "yes") {
				return true;
			}
			return false;
		}
		$scope.SetReviewDate = function () {
			$scope.strdate = $scope.oriMsgCustomFields.Tender_New_Review_Date;
			$scope.strTime = $scope.oriMsgCustomFields.Tender_New_Review_Time;

			var strReviewDae = $scope.oriMsgCustomFields.ITB_Review_Date;
			var strNewEndDate = $scope.oriMsgCustomFields.Addenda_End_Date;
			var strEndDate = $scope.oriMsgCustomFields.Tender_New_End_Date;
			$scope.reviewDatemsg = "";
			if (!$scope.strdate && strReviewDae) {
				$scope.reviewDatemsg = "Mandatory values not selected !!! \n\n Please Specify New Addenda Review Date";
				return true;
			}
			if ($scope.strdate && strEndDate) {
				var endDateobj = new Date(strEndDate);
				var reviewDateobj = new Date($scope.strdate);

				if (reviewDateobj < endDateobj) {
					$scope.oriMsgCustomFields.Tender_New_Review_Date = "";
					alert("Invalid Date selected! \n\n Specify review date greater than New End date");
					return true;
				}
			}
			if ($scope.strdate && $scope.strTime) {
				var dt = new Date($scope.strdate);
				var strtime = convertTimeformat($scope.strTime);
				if (strtime) {
					var arrtime = strtime.split(':');
					dt.setHours(arrtime[0]);
					dt.setMinutes(arrtime[1]);
				}
				$scope.oriMsgCustomFields.Addenda_Review_Date = $filter('date')(dt, 'yyyy-MM-ddTHH:mm:ss');

				var prevDtobj = new Date(strReviewDae);
				if (dt.getTime() < prevDtobj.getTime()) {
					alert("Invalid Date selected! \n\n Specify review date greater than Previous review date");
					$scope.oriMsgCustomFields.Tender_New_Review_Date = "";
					$scope.oriMsgCustomFields.Tender_New_Review_Time = "";
					return true;
				}
				var strED = new Date(strNewEndDate);
				if (dt.getTime() <= strED.getTime()) {
					alert("Invalid Date selected! \n\n Specify review date greater than New End date");
					$scope.oriMsgCustomFields.Tender_New_Review_Time = "";
					return true;
				}
			}
			return false;
		}
		$scope.SetReviewTimeMandatory = function () {
			$scope.strTime = $scope.oriMsgCustomFields.Tender_New_Review_Time;
			var strReviewedate = $scope.oriMsgCustomFields.ITB_Review_Date;

			if (!$scope.strTime && strReviewedate) {
				return true;
			}
			return false;
		}

		function convertTimeformat(str) {
			var hours = Number(str.match(/^(\d+)/)[1]);
			var minutes = Number(str.match(/:(\d+)/)[1]);
			var AMPM = str.match(/\s(.*)$/)[1];
			if (AMPM == "PM" && hours < 12) hours = hours + 12;
			if (AMPM == "AM" && hours == 12) hours = hours - 12;
			var sHours = hours.toString();
			var sMinutes = minutes.toString();
			if (hours < 10) sHours = "0" + sHours;
			if (minutes < 10) sMinutes = "0" + sMinutes;
			return sHours + ":" + sMinutes
		}

		function getDateTimeFromZone() {
			$scope.offset = 0;
			$scope.offset = $scope.oriMsgCustomFields.DSI_TimeZone_Offset;
			var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
			var now = new Date();
			var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
			utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
			var nd = new Date(parseInt(utcDate.getTime()) + parseInt($scope.offset));
			nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
			return nd;
		}

	}

	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof ASI_FinalCallBack !== "undefined") {
		return ASI_FinalCallBack();
	}
}