/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
window.updateFormXsnTitle = function() {};
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function(angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }        
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId')
            .value || '';

        var currentViewName = window.currentViewName;        

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                   
                }, 500);
            }
        });

        var STATIC_OBJ_DATA = {
            Reviewers_distg: {
                "Reviewers_Distributiongroup": "",
                "Reviewers_Distributiongroup_isSelected": ""
            },
            MultiComment_info: {
                "UID": "",
                "Ref_Res_Id": "",
                "Idx": "",
                "Id": "",
                "Severity": "",
                "ReviewerName": "",
                "IsOpenClose": "Open",
                "MultiComment_Info_isSelected": ""
            },
            Comment_Info: {
                "Ref_Res_Id": "",
                "Idx": "",
                "Comment_Level": "",
                "Comment_Level_Prev_Value": "",
                "Doc_Rev": "",
                "Comment_Info_IsSelected": ""
            },
            reviewersDistributionGroup: {
                "Reviewers_Distributiongroup": ""
            },
            Res_Info: {
                "UID": "",
                "Response_id": "",
                "ResponseBy": "",
                "Res_Date": "",
                "Response_comments": "",
                "Response_Accepted": "",
                "UserAllRoles": "",
                "visible": "",
                "CycleNo": "",
                "CommentBY": "",
                "RCRES_Reviewer_id": "",
                "TARES_RC_id": "",
                "PMRES_RC_id": "",
                "CONRES_PM_id": "",
                "display_to_tig": "",
                "GroupForRC": "",
                "GroupForRiviewer": "",
                "All_Comments": {
                    "Comments_Info": [{
                        "UID": "",
                        "Ref_Res_Id": "",
                        "Idx": "",
                        "Comment_Level": "",
                        "Comment_Level_Prev_Value": "",
                        "Doc_Rev": "",
                        "DSI_Chk_Done":"0",
                        "Doc_ID": "",
                        "PMComment": "",
                        "field5": "",
                        "field6": "",
                        "Doc_Title": "",
                        "Doc_status": "",
                        "DocFolder_Name": "",
                        "Doc_FolderId": "",
                        "Doc_ref": "",
                        "Multicomment": {
                            "MultiComment_info": [{
                                "UID": "",
                                "Ref_Res_Id": "",
                                "Idx": "",
                                "Id": "",
                                "Severity": "",
                                "ReviewerName": "",
                                "IsOpenClose": "Open",
                                "Pkg_Level_Status": "",
                                "Doc_Level_Status": "",
                                "CommentGroup": {
                                    "RepeatCommentGroup": [{
                                        "UID": "",
                                        "Ref_Res_Id": "",
                                        "Idx": "",
                                        "Id": "",
                                        "RepeatComment_Id": "",
                                        "Comment": "",
                                        "Label": "",
                                        "PM_Name":"",
                                        "Con_Name":"",
                                        "comment_against": "",
                                        "CommentBy": "",
                                        "Reason": "",
                                        "IsDeleted": "",
                                        "seqNo": ""
                                    }]
                                }
                            }]
                        },
                        "Recommend": {
                            "Recommend_Doc_Level": ""
                        },
                        "group25": ""
                    }]
                }
            },
            Comments_Info: {
                "UID": "",
                "Ref_Res_Id": "",
                "Idx": "",
                "Comment_Level": "",
                "Comment_Level_Prev_Value": "",
                "Doc_Rev": "",
                "DSI_Chk_Done":"0",
                "Doc_ID": "",
                "PMComment": "",
                "field5": "",
                "field6": "",
                "Doc_Title": "",
                "Doc_status": "",
                "DocFolder_Name": "",
                "Doc_FolderId": "",
                "Doc_ref": "",
                "Multicomment": {
                    "MultiComment_info": [{
                        "UID": "",
                        "Ref_Res_Id": "",
                        "Idx": "",
                        "Id": "",
                        "Severity": "",
                        "ReviewerName": "",
                        "IsOpenClose": "Open",
                        "Pkg_Level_Status": "",
                        "Doc_Level_Status": "",
                        "CommentGroup": {
                            "RepeatCommentGroup": [{
                                "UID": "",
                                "Ref_Res_Id": "",
                                "Idx": "",
                                "Id": "",
                                "RepeatComment_Id": "",
                                "Comment": "",
                                "Label": "",
                                "PM_Name":"",
                                "Con_Name":"",
                                "comment_against": "",
                                "CommentBy": "",
                                "Reason": "",
                                "IsDeleted": "",
                                "seqNo": ""
                            }]
                        }
                    }]
                },
                "Recommend": {
                    "Recommend_Doc_Level": ""
                },
                "group25": ""
            },
            multiCommentInfo: {
                "UID": "",
                "Ref_Res_Id": "",
                "Idx": "",
                "Id": "",
                "Severity": "",
                "ReviewerName": "",
                "IsOpenClose": "Open",
                "Pkg_Level_Status": "",
                "Doc_Level_Status": "",
                "CommentGroup": {
                    "RepeatCommentGroup": [{
                        "UID": "",
                        "Ref_Res_Id": "",
                        "Idx": "",
                        "Id": "",
                        "RepeatComment_Id": "",
                        "Comment": "",
                        "Label": "",
                        "PM_Name":"",
                        "Con_Name":"",
                        "comment_against": "",
                        "CommentBy": "",
                        "Reason": "",
                        "IsDeleted": "",
                        "seqNo": ""
                    }]
                }
            },
            repeatCommentGroup: {
                "UID": "",
                "Ref_Res_Id": "",
                "Idx": "",
                "Id": "",
                "RepeatComment_Id": "",
                "Comment": "",
                "Label": "",
                "PM_Name":"",
                "Con_Name":"",
                "comment_against": "",
                "CommentBy": "",
                "Reason": "",
                "IsDeleted": "",
                "seqNo": "",
                "addedNewValue": "YES"
            },
            Prev_Comments_Info:{
                "Prev_Doc_Ref":"",
                "Prev_Reason":"",
                "Prev_Doc_Folder_Name":"",
                "Prev_Comment_Level":"",
                "Prev_Response_Id":"",
                "Prev_Comments_Info_Idx":"",
                "Prev_Doc_Title":"",
                "Prev_Con_Name": "",
                "Prev_Comment_By": "",
                "project_id": "",
                "Prev_seqNo": "",
                "Prev_Doc_Level_Status": "",
                "Prev_doc_rev": "",
                "Prev_IsOpenClose": "",
                "Prev_Doc_Folder_Id": "",
                "Prev_Pkg_Level_Status": "",
                "msg_id": "",
                "Prev_Comment": "",
                "Prev_RepeatComment_Id": "",
                "Prev_Doc_Id_rev_id": "",
                "Prev_Comment_Level_Prev_Value": "",
                "Form_Id": "",
                "Prev_Reviewer_Name": "",
                "Prev_MultiComment_info_Id": "",
                "Prev_PM_Name": "",
                "Prev_Doc_Status": "",
                "Prev_UID": "",
                "PackageNumber": "",
                "Prev_Label": "",
                "Prev_IsDeleted": "",
                "Prev_comment_against": "",
                "Prev_Severity": "",
                "Package_Revision_No": ""
            }            
        };
        $scope.tableUtilSettings = {
            Reviewers_Dist_Group: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Reviewer Groups?",

                checkboxModelKey: "Reviewers_Distributiongroup_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Reviewers_distg),
                deleteAllRowTooltip: "Remove all Reviewer Groups",
                deleteCurrRowMsg: "Remove Reviewer Group",
                deleteSelectedMsg: "Remove Selected Reviewer Group"
            },
            MultiComment_info_Group: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Gate Details?",

                checkboxModelKey: "MultiComment_Info_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.MultiComment_info),
                deleteAllRowTooltip: "Remove all Gate Details",
                deleteCurrRowMsg: "Remove Gate Detail",
                deleteSelectedMsg: "Remove Selected Gate Detail"
            },
        }
        $scope.requests = {};
        $scope.groupUsersList = [];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
        $scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
        $scope.GetSetupFormDetail = $scope.getValueOfOnLoadData('DS_ASI_TIDP_GET_FLOW_DETAILS');
        var GetPOIDetails = $scope.getValueOfOnLoadData('DS_ASI_TIDP_GET_POI_SECTION_DETAILS') || [];
        var gateDaysdetails = $scope.getValueOfOnLoadData('DS_ASI_TIDP_GET_GATE_DETAILS');
        $scope.allPoiDetails = commonApi._.filter(GetPOIDetails, function(obj) {
            return obj.Value1 == "Yes"
        });      
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.workingUserDetails = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var msgContent = $scope.getValueOfOnLoadData('DS_GETFORMCONTENT_MSG');
        var incompleteActionsByMsg = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS_BYMSG") || [];

        var BAM_COMMENTING_CONSTANT = {

            // Static Status 
            Further_Review_in_Progress: "Further Review in Progress",   
            Review_in_Progress :"Review in Progress",                        
            Package :"Package",
            Document :"Document",
            For_Acceptance:"For Acceptance",
            QA_Accepted:"QA Accepted",
            For_Information:"For Information",
            For_Construction:"For Construction",
            No_Comment:"No Comment",
            Not_Accepted:"Not Accepted",
            Accepted:"Accepted",          
            Sent_to_PM:"Sent to PM",
            Sent_to_PM_via_TA:"Sent to PM via TA",            
            Sent_to_Contractor:"Sent to Contractor",
            Sent_back_to_RC_by_TA:"Sent back to RC by TA",
            
            // Static Roles
            Technical_Authoriser : "Technical Authoriser",
            Project_Manager:"Project Manager",
            contractorRole : "Contractor_Role",              
            Contractor_PM:"Contractor PM",

            // Static Week 
            Four_Weeks:"4 Weeks",
            Three_Weeks:"3 Weeks",

            dasyInMiliseconds: 86400000,

            // Tab names
            commentingDetails : "CommentingDetails",
            CommentingForm:"CommentingForm",

            // Data Source used
            dsAsiCheckPackageFormStatusSP : "DS_ASI_CHECK_PACKAGE_FORM_STATUS",
            dsAsiGetPkgRevSP : "DS_ASI_GET_PKG_REV",
            dsAsiTidpGetCmntPreviousRevDtlsPS : "DS_ASI_TIDP_GET_CMNT_PREVIOUS_REV_DTLS",
            dsAsiTidpMsgDocAssociationsForAllRevSP: "DS_ASI_TIDP_MSG_DOC_ASSOCIATIONS_FOR_All_Rev",
            dsAssocFormAssocDocsMetadataSP :"DS_ASSOC_FORM_ASSOCDOCS_METADATA",

            // Alert/Warning messages
            strYouAreNotAutorised : "0#You are not authorized to respond to this form",
            strYouAreNotAutorisedAtThisStage : "0#You are not authorized to respond to this form at this stage",
            strRoleChangeMsg : "0#Your role has been changed from Reviewer to Review Cordinator by the Document Controller. Please discard this draft and create a new response.",
            strPendingAction : "0#There is no pending action, please contact the Administrator for further queries."
        }

        /**
         * associate the submission package in commenting form
         */
        $window.updateFormXsnTitle = function(digest, isOnClick, callback) {
            if (window.currentViewName !== "ORI_VIEW") {
                return;
            }
            $scope.oriMsgCustomFields["activeTab"] = BAM_COMMENTING_CONSTANT.commentingDetails; //PackageRevisionHistoryDetails or CommentingDetails
            var associateFormData = $window.getAssociatedFormDetail();
            if (!associateFormData) {
                $scope.oriMsgCustomFields['ReviewCoordinator_DistGrp'] = "";
                $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"] = "";
                $scope.isFormAssociated = false;
                !digest && $scope.$digest();
                return;
            }
            associateFormData = associateFormData.formData || associateFormData;
            var pkgFormID = associateFormData.formId.split('$$')[0];
            
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": BAM_COMMENTING_CONSTANT.dsAsiCheckPackageFormStatusSP,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": BAM_COMMENTING_CONSTANT.dsAsiCheckPackageFormStatusSP,
                        "fieldValue": pkgFormID
                    }]
                }
            };
            $scope.requests['chkpkgformstatus'] = true;
            $scope.add({
                name: "chkpkgformstatus",
                status: "incomplete"
            });

            $scope.getCallbackData(form)
                .then(function(response) {
                    $scope.requests['chkpkgformstatus'] = false;
                    $scope.update({
                        name: "chkpkgformstatus",
                        status: "completed"
                    });

                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["CDE_Phase"] = "CDE-5";
                    if (isOnClick) {
                        onClickCallBackCheckPkgFormStatus(response, callback);
                    } else {
                        onLoadCallBackUpdateFormTitle(response, associateFormData);
                    }
                }, throwCallBackError);
        };

        /**
         * This function used to manage callback Error in Ajax call
         * @param { Object } error : Error Object from server side
         */
        function throwCallBackError(error){
            $window.alert("Error\n\nDatasource callback failed!")
        }

        window.clearRCSubmitClearORIAction = function(data) {
            var resData = $(data).find("Value").text();
            if (resData == "Y") {
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
                var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
                var asiteSystemDataReadWrite = $scope.data["myFields"]['Asite_System_Data_Read_Write'];
                var strDSFormStatus = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
                var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
                var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";
                setRCNameInFormContent2();
                //Check if RC
                if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Review_in_Progress && (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1)) {
                    completeReviewCoordinatorAction();                    
                }
            }
        };
        //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
        window.checkUserReviewDraft = function() {                
                var strWorkingUserId = getWorkingUserId();
                var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                var Draft = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                var strCurrentStage = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['CurrentStage'];
                if (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES" && strCurrentStage == "5") {
                    return true;
                } else {
                    return false;
                }
            }
            //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends	

            /**
             * fuction used to get working user ID              
            */
            function getWorkingUserId()
            {                
                var strWorkingUserId = $scope.workingUserDetails[0].Value.split('|')[0].trim() || "";
                return strWorkingUserId;
            }
        var checkRCNameInFormContent2 = function() {
            var isRCNameInFormContent = false;
            var strDsFormContent2 = msgContent[0].Value7 || "";
            strDsFormContent2 = strDsFormContent2.replace("$$$", "#");
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
            if (strReviewCoordinatorUser == strDsFormContent2) {
                isRCNameInFormContent = true
            }
            return isRCNameInFormContent
        }

        var setRCNameInFormContent2 = function(strReviewCoordinatorUser) {
            if (strReviewCoordinatorUser) {
                $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_FORMCONTENT2'] = "";
                $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_FORMCONTENT2'] = strReviewCoordinatorUser;
            } else {
                //Check if User is DC, then update DS_FORMCONTENT2
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                if (isDCChangeUser) {
                    var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                        return obj["isUserActive"] == true
                    });
                    var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
                    if (strReviewCoordinatorUser) {
                        $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_FORMCONTENT2'] = "";
                        $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_FORMCONTENT2'] = strReviewCoordinatorUser;
                    }
                }
            }
        }
        var onLoadCallBackUpdateFormTitle = function(response, associateFormData) {
            var isShow = "";
            var pkGMsgId = "";

            if (response.data) {
                var formStatus = JSON.parse(response.data[ BAM_COMMENTING_CONSTANT.dsAsiCheckPackageFormStatusSP ]);
                formStatus = formStatus['Items']["Item"] || [];
                if (!formStatus.length) {
                    return;
                }
                var resValue = formStatus[0];
                if (resValue.Name) {
                    pkGMsgId = resValue.Name;
                }
                if (resValue.Value2) {
                    isShow = resValue.Value2.trim();
                }
                if (isShow.toLowerCase() == "true") {
                    $scope.oriMsgCustomFields["ORI_FORMTITLE"] = associateFormData.title;
                    $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"] = associateFormData.formId.split('$$')[0];
                    $scope.isFormAssociated = true;
                    $scope.oriMsgCustomFields.DS_AUTOASSOCIATE_DOC_FROM_ASSOC_FORMS = true;
                    $scope.oriMsgCustomFields.DS_ASSOCIATED_FORM_MSG_ID = pkGMsgId                    
                    GetPkgFormData(false);
                    GetDocumentHistory(); 
                    GetPreviousCommentingData();
                } else {
                    //A commenting form has already been created or is in progress for this revision. Cannot create a new form.
                    $scope.oriMsgCustomFields['Warning']['NoCreateAccess'] = "#" + isShow;
                }
            }
        };
        var onClickCallBackCheckPkgFormStatus = function(response, callback) {
            if (response.data) {
                var isShow = "";
                var formStatus = JSON.parse(response.data[ BAM_COMMENTING_CONSTANT.dsAsiCheckPackageFormStatusSP ]);
                formStatus = formStatus['Items']["Item"] || [];
                if (!formStatus.length) {
                    return false;
                }
                var resValue = formStatus[0];
                if (resValue.Value2) {
                    isShow = resValue.Value2.trim();
                }
                if (isShow.toLowerCase() != "true") {
                    
                    $window.alert(isShow);
                    
                    disableButtons(1);
                    $("body > .loading").remove();
                    return;
                }
                callback && callback();
            }
        };

        var GetPkgFormData = function(isOnReviewCoordinatorChange) {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": BAM_COMMENTING_CONSTANT.dsAsiGetPkgRevSP,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": BAM_COMMENTING_CONSTANT.dsAsiGetPkgRevSP,
                        "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                    }]
                }
            };
            $scope.requests['pkgrev'] = true;
            $scope.add({
                name: BAM_COMMENTING_CONSTANT.dsAsiGetPkgRevSP,
                status: "incomplete"
            });
            $scope.getCallbackData(form)
                .then(function(response) {
                    $scope.requests['pkgrev'] = false;
                    $scope.update({
                        name: BAM_COMMENTING_CONSTANT.dsAsiGetPkgRevSP,
                        status: "completed"
                    });

                    if (!response.data) {
                        return;
                    }
                    var AllNodesMainDS = JSON.parse(response.data[ BAM_COMMENTING_CONSTANT.dsAsiGetPkgRevSP ]);
                    AllNodesMainDS = AllNodesMainDS['Items']["Item"] || [];

                    if (!AllNodesMainDS.length) {
                        return;
                    }
                    AllNodesMainDS = commonApi._.filter(AllNodesMainDS, function(o) {
                        return !!(o.Name);
                    });
                    if (!AllNodesMainDS.length) {
                        return;
                    }
                    var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                    var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
                    var asiteSystemDataReadWrite = $scope.data["myFields"]['Asite_System_Data_Read_Write'];
                    var xpnloopnode = AllNodesMainDS[0];
                    var strRevisionNo = xpnloopnode.Value2.trim();
                    var strFwdNo = xpnloopnode.Value3.trim();                    
                    var strPackageNumber = xpnloopnode.Value6.trim();
                    var strPeriodOfReply = xpnloopnode.Value7.trim();
                    var strPackageSubmissionPurpose=xpnloopnode.Value8.trim();                    
                    var strOriginator = xpnloopnode.Value9.trim();
                    var strPkgIssueDate = "";
                    var strTaskPkgRCGroup=xpnloopnode.Value13.trim().replace("@@","#");
                    var strTaskPkgReviewerGroups=xpnloopnode.Value14.trim();
                    setReviewerOnLoad(strTaskPkgReviewerGroups);
                    CommonGetCallback(strTaskPkgRCGroup,FillRCUserstoTable);  
                    oriMsgCustomFields['ReviewCoordinator_DistGrp'] = strTaskPkgRCGroup;

                    var obj = {
                        DS_ADO_TYPE: "",
                        DS_ADO_FORM: strPackageNumber,
                        DS_ADO_MSG_TYPE: "",
                        DS_ADO_FORMACTIONS: "2#AssignStatus",
                        DS_ADO_PROJDISTGROUPS: "",
                        DS_ADO_ACTIONDUEDATE: "",
                        DS_ADO_PROJDISTUSERS: ""
                    };
                    oriMsgCustomFields['Package_Revision_No'] = strRevisionNo;
                    oriMsgCustomFields['Package_Submission_Purpose'] = strPackageSubmissionPurpose;
                    oriMsgCustomFields['Pkg_Fwd_No'] = strFwdNo;
                    oriMsgCustomFields['PeriodForReply'] = strPeriodOfReply;
                    oriMsgCustomFields['Task_Review_Coordinator_PKG'] = strTaskPkgRCGroup;
                    oriMsgCustomFields['Task_Reviewer_Groups_PKG'] = strTaskPkgReviewerGroups;
                    if (xpnloopnode.Value10) {
                        oriMsgCustomFields['Pkg_QA_check_Date'] = xpnloopnode.Value10;
                    }

                    if (xpnloopnode.Value11) {
                        oriMsgCustomFields['Pkg_Issued_Date'] = xpnloopnode.Value11;
                        strPkgIssueDate = xpnloopnode.Value11;
                    }
                    if (xpnloopnode.Value12) {
                        oriMsgCustomFields['Pkg_Gate'] = xpnloopnode.Value12;
                    }
                    if (xpnloopnode.Value4) {
                        oriMsgCustomFields['Pkg_DC_RES_Status'] = xpnloopnode.Value4.trim(); //NOODLE-47680 
                    }
                    //NOODLE-41336 change for Due date
                    var strDays = 0;
                    if (strPeriodOfReply.indexOf(BAM_COMMENTING_CONSTANT.Four_Weeks) > -1) {
                        strDays = 28;
                    } else if (strPeriodOfReply.indexOf(BAM_COMMENTING_CONSTANT.Three_Weeks) > -1) {
                        strDays = 21;
                    }

                    //Change as per mailed requirement  //change PackageDeliveryDate date as per new PHASE (Actual submission date + Period of reply)
                    if (strPkgIssueDate) {
                        strDays = $scope.parseDate('dd/mm/yy', strPkgIssueDate).getTime() + ( BAM_COMMENTING_CONSTANT.dasyInMiliseconds * strDays);
                        oriMsgCustomFields['PackageDeliveryDate'] = $scope.formatDate(new Date(strDays), 'dd/mm/yy'); ////NOODLE-49128
                    } else {
                        strDays = serverDate.getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * strDays);
                        oriMsgCustomFields['PackageDeliveryDate'] = $scope.formatDate(new Date(strDays), 'dd/mm/yy');
                    }
                    if (strPeriodOfReply.indexOf('N/A') > -1) {
                        strDays = $scope.parseDate('dd/mm/yy', strPkgIssueDate).getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * 27);
                    }
                    if (!isOnReviewCoordinatorChange) {
                        //Onload set PM Response Due Date
                        $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(new Date(strDays), 'yy-mm-dd');

                        if (currentViewName == "ORI_VIEW") {
                            $scope.getCalculatedActionDueDate();
                        }

                    } else if (isOnReviewCoordinatorChange && !$scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE']) {
                        // On RCGroup change but date set as blank, only then  update date.
                        $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                    }
                    // NOODLE-43023 set PackageNumber
                    oriMsgCustomFields['PackageNumber'] = strPackageNumber;

                    //NOODLE-41017 set Fomcontent1="PKGxxx#FWDxxx" Set Pkg_Contractor (get contractor from Package form)
                    oriMsgCustomFields['Pkg_Contractor'] = "";

                    asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = oriMsgCustomFields['PackageNumber'] + "#" + oriMsgCustomFields['Pkg_Fwd_No'];
                    if (strOriginator) {
                        var strArr = strOriginator.split('@');
                        if (strArr.length) {
                            var arrStr1 = strArr[0].trim() || "";
                            var arrStr2 = strArr[1].trim() || "";
                            oriMsgCustomFields['Pkg_Contractor'] = arrStr1 + " # " + arrStr2;
                            obj.DS_ADO_PROJDISTUSERS = oriMsgCustomFields['Pkg_Contractor'];
                        }
                    }
                    asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push(obj);                 
                });
        };
        /**
		* This function is used to set reviewer user as per Task selected in Package Form. We have defined reviewer users in WBS form (Task section) and we select any task in Package Form. 
		* @param { string } strTaskPkgReviewerGroups : We get single/multiple Reviewer user in string and we split users through below function.
		*/
        function setReviewerOnLoad(strTaskPkgReviewerGroups) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            if (strTaskPkgReviewerGroups) {

                var commaSeperated = strTaskPkgReviewerGroups.split(',');
                var strExculsionWithGUID = [];
                for (var i = 0; i < commaSeperated.length; i++){
                    strExculsionWithGUID.push(commaSeperated[i].split('$$')[0]);
                }
                strExculsionWithGUID =strExculsionWithGUID && strExculsionWithGUID.join();
                var strReviewerGroups = strExculsionWithGUID && strExculsionWithGUID.split("@@"),
                strReviewerGroups = strReviewerGroups && strReviewerGroups.join('#'),
                strReviewerGroups = strReviewerGroups && strReviewerGroups.split(',');

                oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'] = [];
                
                for (var i = 0; i < strReviewerGroups.length; i++) {
                    var item = angular.copy(STATIC_OBJ_DATA.reviewersDistributionGroup);
                    item.Reviewers_Distributiongroup = strReviewerGroups[i] && strReviewerGroups[i].trim();
                    $scope.addRepeatingRow(oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'], item);
                    FillRCUserstoTable_ReviewerGroup(strReviewerGroups[i] && strReviewerGroups[i].trim(), i);
                }
            }
        }
        var GetPreviousCommentingData = function () {
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": BAM_COMMENTING_CONSTANT.dsAsiTidpGetCmntPreviousRevDtlsPS,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": BAM_COMMENTING_CONSTANT.dsAsiTidpGetCmntPreviousRevDtlsPS,
                        "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                    }]
                }
            };
            $scope.requests['PrevComm'] = true;
            $scope.add({
                name: BAM_COMMENTING_CONSTANT.dsAsiTidpGetCmntPreviousRevDtlsPS,
                status: "incomplete"
            });
            $scope.getCallbackData(form)
                .then(function (response) {
                    $scope.requests['PrevComm'] = false;
                    $scope.update({
                        name: BAM_COMMENTING_CONSTANT.dsAsiTidpGetCmntPreviousRevDtlsPS,
                        status: "completed"
                    });
                    if (!response.data) {
                        return;
                    }
                    if (response.data) {
                        var AllNodesMainDS = JSON.parse(response.data[BAM_COMMENTING_CONSTANT.dsAsiTidpGetCmntPreviousRevDtlsPS]);
                        AllNodesMainDS = AllNodesMainDS['Items']["Item"] || [];

                        if (!AllNodesMainDS.length) {
                            return;
                        }
                        $scope.resMsgCustomFields["Previous_Comments"]["Prev_Comments_Info"]=[];
                        if (AllNodesMainDS && AllNodesMainDS.length) {
                            $scope.PreviousCommentsAvailable="";
                            
                            for (var i = 0; i < AllNodesMainDS.length; i++) {
                                if(AllNodesMainDS[i].Value8 &&(AllNodesMainDS[i].Value25==="open" || AllNodesMainDS[i].Value25==="point of attention"))
                                {
                                $scope.PreviousCommentsAvailable="YES";
                                var PrevCommentGroup = angular.copy(STATIC_OBJ_DATA['Prev_Comments_Info']);
                                PrevCommentGroup.project_id = AllNodesMainDS[i].Value1;
                                PrevCommentGroup.Form_Id = AllNodesMainDS[i].Value2;
                                PrevCommentGroup.msg_id = AllNodesMainDS[i].Value5;
                                PrevCommentGroup.PackageNumber = AllNodesMainDS[i].Value6;
                                PrevCommentGroup.Package_Revision_No = AllNodesMainDS[i].Value7;
                                PrevCommentGroup.Prev_UID = AllNodesMainDS[i].Value8;
                                PrevCommentGroup.Prev_Response_Id = AllNodesMainDS[i].Value9;
                                PrevCommentGroup.Prev_Comments_Info_Idx = AllNodesMainDS[i].Value10;
                                PrevCommentGroup.Prev_MultiComment_info_Id = AllNodesMainDS[i].Value11;
                                PrevCommentGroup.Prev_RepeatComment_Id = AllNodesMainDS[i].Value12;
                                PrevCommentGroup.Prev_seqNo = AllNodesMainDS[i].Value13;
                                PrevCommentGroup.Prev_Doc_Folder_Id = AllNodesMainDS[i].Value14;
                                PrevCommentGroup.Prev_Doc_Folder_Name = AllNodesMainDS[i].Value15;
                                PrevCommentGroup.Prev_Doc_Id_rev_id = AllNodesMainDS[i].Value16;
                                PrevCommentGroup.Prev_doc_rev = AllNodesMainDS[i].Value17;
                                PrevCommentGroup.Prev_Doc_Title = AllNodesMainDS[i].Value18;
                                PrevCommentGroup.Prev_Doc_Ref = AllNodesMainDS[i].Value19;
                                PrevCommentGroup.Prev_Doc_Status = AllNodesMainDS[i].Value20;
                                PrevCommentGroup.Prev_Comment_Level = AllNodesMainDS[i].Value21;
                                PrevCommentGroup.Prev_Comment_Level_Prev_Value = AllNodesMainDS[i].Value22;
                                PrevCommentGroup.Prev_Reviewer_Name = AllNodesMainDS[i].Value23;
                                PrevCommentGroup.Prev_IsOpenClose = AllNodesMainDS[i].Value24;
                                PrevCommentGroup.Prev_Severity = AllNodesMainDS[i].Value25;
                                PrevCommentGroup.Prev_Pkg_Level_Status = AllNodesMainDS[i].Value26;
                                PrevCommentGroup.Prev_Doc_Level_Status = AllNodesMainDS[i].Value27;
                                PrevCommentGroup.Prev_Comment = AllNodesMainDS[i].Value28;
                                PrevCommentGroup.Prev_Label = AllNodesMainDS[i].Value29;
                                PrevCommentGroup.Prev_IsDeleted = AllNodesMainDS[i].Value30;
                                PrevCommentGroup.Prev_Comment_By = AllNodesMainDS[i].Value31;
                                PrevCommentGroup.Prev_comment_against = AllNodesMainDS[i].Value32;
                                PrevCommentGroup.Prev_Reason = AllNodesMainDS[i].Value33;
                                PrevCommentGroup.Prev_PM_Name = AllNodesMainDS[i].Value34;
                                PrevCommentGroup.Prev_Con_Name = AllNodesMainDS[i].Value35;
                                $scope.resMsgCustomFields["Previous_Comments"]["Prev_Comments_Info"].push(PrevCommentGroup);
                                }
                            }
                        }
                    }
                });
        };
        var AssociateDocsForAllRev = function(AllRevDocDetails) {
            var totalPkgRevisions = commonApi._.uniq(AllRevDocDetails, function(item) {
                return item.Value16;
            });
            var AllRevDocDetailsArr = [];
            var Package_Revision_No = $scope.oriMsgCustomFields['Package_Revision_No'];
            var historicRevisionsCnt = 0;

            if (totalPkgRevisions.length) {
                //Create Obj for looping 
                for (var i = 0; i <= totalPkgRevisions.length - 1; i++) {
                    var pkgRevision = totalPkgRevisions[i].Value16;
                    var cmntId = totalPkgRevisions[i].Value15 || "";
                    var cmntIdUrl = totalPkgRevisions[i].URL15 || "";
                    var packageFormStatus = totalPkgRevisions[i].Value17 || "";
                    var showCurrentVersion = parseInt(Package_Revision_No) > parseInt(pkgRevision) ? true : false;
                    if (showCurrentVersion) {
                        historicRevisionsCnt++;
                    }

                    var revDocsArr = commonApi._.where(AllRevDocDetails, {
                        Value16: pkgRevision
                    });

                    var RevdetailsObj = {
                        "PackageRevision": pkgRevision,
                        "PackageStatus": packageFormStatus,
                        "CMNT_ID": cmntId,
                        "CMNT_ID_URL": cmntIdUrl,
                        "showCurrentVersion": showCurrentVersion,
                        "RevDocs": revDocsArr
                    }
                    AllRevDocDetailsArr.push(RevdetailsObj);
                }
            }
            
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associated_Doc_History"] = {};
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associated_Doc_History"]['Associate_Doc_All_Rev'] = AllRevDocDetailsArr;
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associated_Doc_History"]['HistoricRevisionCount'] = historicRevisionsCnt;
        }

        var GetDocumentHistory = function() {
            //Set default active tab as Commenting tab
            $scope.oriMsgCustomFields["activeTab"] = BAM_COMMENTING_CONSTANT.commentingDetails; //PackageRevisionHistoryDetails or CommentingDetails
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": BAM_COMMENTING_CONSTANT.dsAsiTidpMsgDocAssociationsForAllRevSP,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": BAM_COMMENTING_CONSTANT.dsAsiTidpMsgDocAssociationsForAllRevSP,
                        "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                    }]
                }
            };

            $scope.requests['pkgrev'] = true;
            $scope.add({
                name: BAM_COMMENTING_CONSTANT.dsAsiTidpMsgDocAssociationsForAllRevSP,
                status: "incomplete"
            });

            $scope.getCallbackData(form).then(function(response) {
                $scope.requests['pkgrev'] = false;
                $scope.update({
                    name: BAM_COMMENTING_CONSTANT.dsAsiTidpMsgDocAssociationsForAllRevSP,
                    status: "completed"
                });
                if (!response.data) {
                    return;
                }
                var AllRevDocDetails = JSON.parse(response.data[ BAM_COMMENTING_CONSTANT.dsAsiTidpMsgDocAssociationsForAllRevSP ]);
                AllRevDocDetails = AllRevDocDetails['Items']["Item"] || [];
                AssociateDocsForAllRev(AllRevDocDetails, "callback");
            });
        };
        var serverDate;
        $scope.getServerTime(function(serverDateArgs) {
            serverDate = new Date(serverDateArgs);
            $scope.todayDateDbFormat = $scope.formatDate( serverDate, 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate( serverDate, 'dd-M-yy');

            On_FormEvents_Loading();
            On_FormEvents_ViewSwitched();
            $scope.setDefaultData();
            $scope.update();
        });

        // trigger association initially
        var ISDRAFT = document.getElementById("DS_ISDRAFT");
        ISDRAFT = ISDRAFT ? ISDRAFT.value : "";

        if (ISDRAFT.toLowerCase() != "yes" && currentViewName == "ORI_VIEW") {
            $window.updateFormXsnTitle(true, false);
        }

        //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
        function getAllIncompleteActionReviewDraftUserIds() {
            var allIncompleteActUsersIds = [];
            
            var incompleteReviewDraftActions = commonApi._.filter(incompleteActionsByMsg, function(obj) {
                return obj.Value4 == "Review Draft"
            });
            for (var i = 0; i < incompleteReviewDraftActions.length; i++) {
                allIncompleteActUsersIds.push(incompleteReviewDraftActions[i].Value1);
            }
            return allIncompleteActUsersIds;
        }
        //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends        
        
        var On_FormEvents_Loading = function() {
            var Xpnnode = $scope.getValueOfOnLoadData("DS_ASI_TIDP_FETCH_PKG_QA_DATE_DTL")[0];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            if (!oriMsgCustomFields['Pkg_QA_check_Date'] && Xpnnode && Xpnnode.Value3) {
                var strdate = Xpnnode.Value3.trim();
                if (strdate) {
                    oriMsgCustomFields['Pkg_QA_check_Date'] = strdate;
                }
            }

            if (Xpnnode && Xpnnode.Value4) {
                var strpkgdate = Xpnnode.Value4.trim();
                if (strpkgdate) {
                    oriMsgCustomFields['Pkg_Issued_Date'] = strpkgdate;

                    var strPeriodOfReply = oriMsgCustomFields['PeriodForReply'];
                    var strDays = 0;
                    var pmDueDateDays = 0;
                    if (strPeriodOfReply.indexOf(BAM_COMMENTING_CONSTANT.Four_Weeks) > -1) {
                        strDays = 28;
                        pmDueDateDays = 28;
                    } else if (strPeriodOfReply.indexOf(BAM_COMMENTING_CONSTANT.Three_Weeks) > -1) {
                        strDays = 21;
                        pmDueDateDays = 21;
                    } else if (strPeriodOfReply.indexOf('N/A') > -1) {
                        strDays = 27;
                        pmDueDateDays = 0;
                    }
                    strDays = $scope.parseDate('dd/mm/yy', strpkgdate)
                        .getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * strDays);
                    pmDueDateDays = $scope.parseDate('dd/mm/yy', strpkgdate)
                        .getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * pmDueDateDays);
                    oriMsgCustomFields['PackageDeliveryDate'] = $scope.formatDate(new Date(pmDueDateDays), 'dd/mm/yy');
                    $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                }
            }
        };

        $scope.resetNewUserName = function(userRole, userNodeName, currUserNodeName, isCheckboxChecked) {
            if (!isCheckboxChecked) {
                var userRoleDetails = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['DC_Users_List'][userRole]
                var newUserNodeName = userRoleDetails[userNodeName];

                if (newUserNodeName != "") {
                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['DC_Users_List'][userRole][userNodeName] = "";

                    var autoDistUsers = $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'];
                    if (autoDistUsers.length) {
                        var respondActionUser = newUserNodeName.split("|");
                        respondActionUser = respondActionUser[2] || "";
                        respondActionUser = respondActionUser.trim();
                        $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = commonApi._.reject(autoDistUsers, function(obj) {
                            return (obj["DS_FORMACTIONS"] == "3#Respond" && obj["DS_PROJDISTUSERS"] == respondActionUser)
                        });
                    }

                    var cmntStatus = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];
                    cmntStatus = cmntStatus.split("#")[1].trim();
                    var prevUser = "";
                    var match = "";
                    if (userRole == "RC_Role") {
                        removePrevRCNameNodesFromArray();
                        prevUser = userRoleDetails.RC_Prev_Name;
                        prevUser = prevUser.split("|")[2] || prevUser;
                        prevUser = prevUser.trim();
                        match = commonApi._.find($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(item) {
                            return item.ReviewCoordinatorName.indexOf(prevUser) > -1
                        });
                    } else if (userRole == "TA_Role") {
                        prevUser = userRoleDetails.TA_Prev_Name;
                        prevUser = prevUser.split("|")[2] || prevUser;
                        removePrevTANameNodesFromArray();
                        prevUser = prevUser.trim();
                        match = commonApi._.find($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(item) {
                            return item.TAName.indexOf(prevUser) > -1
                        });

                    } else if (userRole == "PM_Role") {
                        prevUser = userRoleDetails.PM_Prev_Name;
                        prevUser = prevUser.split("|")[2] || prevUser;
                        prevUser = prevUser.trim();
                        if (!(cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA || cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM)) {
                            //If status is "Not Accepted" or "Accepted with Comments"
                            var selectedProjManagerArr = commonApi._.filter($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                                return obj["isUserActive"] == true
                            });
                            var selectedProjManager = selectedProjManagerArr[0] && selectedProjManagerArr[0]['PMName'] || "";

                            if (selectedProjManager != "") {
                                cmntStatus = BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA;
                            } else {
                                cmntStatus = BAM_COMMENTING_CONSTANT.Sent_to_PM;
                            }
                        }
                        if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) {
                            removePrevTechPMNameNodesFromArray();
                            match = commonApi._.find($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(item) {
                                return item.PMName.indexOf(prevUser) > -1
                            });
                        } else if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM) {
                            removePrevPMNameNodesFromArray();
                            match = commonApi._.find($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(item) {
                                return item.PMName.indexOf(prevUser) > -1
                            });
                        }

                    } else if (userRole == BAM_COMMENTING_CONSTANT.contractorRole) {
                        prevUser = userRoleDetails.Contractor_Prev_Name;
                        prevUser = prevUser.split("|")[2] || prevUser;
                        prevUser = prevUser.trim();
                        removePrevContractorNameNodesFromArray();
                        match = commonApi._.find($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['PM_Response']['Contractors']["Contractor"], function(item) {
                            return item.ContractorName.indexOf(prevUser) > -1
                        });
                    }
                    if (match) {
                        match.isUserActive = true;
                        var currUserName = match[currUserNodeName];
                        currUserName = currUserName.split("|")[2].trim() || "";

                        var autoCompleteAction = $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Complete_Actions']['Auto_Complete_Action'];
                        if (autoCompleteAction.length) {
                            $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Complete_Actions']['Auto_Complete_Action'] = commonApi._.reject(autoCompleteAction, function(obj) {
                                return (obj["DS_AC_USERID"] == currUserName)
                            });

                        }

                    }
                }
            }
        }

        var On_FormEvents_ViewSwitched = function() {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
            var isDCUser = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["DC_User_Change"];;
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            if (Draft != "YES") {
                $scope.removeAddedNewValueKey();
            } else {
                //NOODLE-85405 two restriction added, 2. Only RC And PM can respond to contractor response - draft scenerio. ptahiliani 25-01-2019 - code starts
                checkUserIsPMorRCAfterContractorResponse();
                //NOODLE-85405 two restriction added, 2. Only RC And PM can respond to contractor response - draft scenerio. ptahiliani 25-01-2019 - code ends
            }
            if ((currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW")) {
                $scope.checkDueDateForDraft();
                var isSubCon=ORI_MSG_Custom_Fields['is_Sub_Contractor_Required'];
                if(!isSubCon)
                {
                ORI_MSG_Custom_Fields['is_Sub_Contractor_Required'] = 'No';
                }
                var SubContractorGroup = $scope.getValueOfOnLoadData("DS_PROJDISTGROUPS");
                $scope.filterSubContractorGroup = commonApi._.filter(SubContractorGroup, function(item) {
                    return item.Name == "Sub-Contractor";
                });
            }
            //Added by Nihil to add new row when subcontractor responds
            if (currentViewName == "RES_VIEW") {
                createResForSubContractor();                
            }
            //End nihil
            /* Below Flag will Clear the User Pending Actions on Save Draft. 
             * This flag should be set default as False. Its gets set to True when Review Cordinator is creating his form
             * Ref: NOODLE-56703*/
            asiteSystemDataReadWrite['DS_AUTOCOMPLETE_ACTION_SAVE_DRAFT'] = "False";

            if (currentViewName == "RES_VIEW") {
                //Check User have Respond Action   to reply
                //  NOODLE-40995    
                check_HasRespondAction();
                asiteSystemDataReadWrite['Flags']['DS_CALL_METHOD'] = "1"; //NOODLE-49020
                $scope.oriMsgCustomFields.DS_AUTOASSOCIATE_DOC_FROM_ASSOC_FORMS = false;
            } else {
                asiteSystemDataReadWrite['Flags']['DS_CALL_METHOD'] = "0";
            }
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var Can_Reply = oriMsgCustomFields['Warning']['Can_Reply'];
            //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
            
            var strWorkingUserId = getWorkingUserId();
            var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
            var strCurrentStage = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['CurrentStage'];
            if (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES" && strCurrentStage == "5") {
                Can_Reply = "YES";
            }
            //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
            if (Can_Reply == "YES") {
                asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = "0";
                oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
            } else if (Can_Reply == "NO") {
                if (Draft == "YES") {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strPendingAction;
                } else {
                    asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = "1| You do not have a permission to create Response. Save your Response as Draft.";
                }
            }

            if (currentViewName == "RES_VIEW" && Draft != "YES") {
                //NOODLE-45716
                oriMsgCustomFields['LastStage'] = oriMsgCustomFields['CurrentStage'];

                if (oriMsgCustomFields['CurrentStage'] == "4" || oriMsgCustomFields['CurrentStage'] == "5") {
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = "";
                }

                //NOODLE-47514 Clear DS_ASSOC_STATUS_UPDATE
                asiteSystemDataReadOnly['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "";

                /*-----------------------------------------------*/
                removeIsAddedNewByDCFlag();
                checkDCUserChange(Draft);
                /*-----------------------------------------------*/
            }

            if (currentViewName == "RES_VIEW" && Draft == "YES" && Can_Reply == "YES") {
                var strLastStage = oriMsgCustomFields['LastStage'];
                var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                var ireturn = 1;
                if (strCurrentStage != "0")
                    ireturn = CheckLatestUID();

                if (ireturn == 1) {
                    CheckDraftSection();
                    var strDS_SEND_MSG = asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'];
                    if (strDS_SEND_MSG == "0") {
                        // Update draft as current user's response.
                        if (strCurrentStage == "0" || strCurrentStage == "2" || strCurrentStage == "3" || strCurrentStage == "4") {
                            ReplaceUserifIsdraft();
                        }

                        if (strCurrentStage == "2" || strCurrentStage == "3" || strCurrentStage == "4" || strCurrentStage == "5") {
                            ClearAction(); // clear action on ORI and RES 
                        }
                    } else {
                        oriMsgCustomFields['Warning']['Can_Reply'] = "NO"; // Invalid draft for this stage
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strPendingAction;
                    }
                } else {
                    var strMsg = BAM_COMMENTING_CONSTANT.strPendingAction;
                    if (asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'].toLowerCase() == "review in progress") {
                        strMsg = "1#" + BAM_COMMENTING_CONSTANT.strPendingAction.replace("0#", "");
                    }
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts                    
                    var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                    var strWorkingUserId = getWorkingUserId();
                    var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                    var allPendingRespondUsersIds = [];
                    
                    var allPendingRespondNodes = commonApi._.filter(incompleteActionsByMsg, function(obj) {
                        return obj.Value4 == "Respond"
                    });
                    for (var i = 0; i < allPendingRespondNodes.length; i++) {
                        allPendingRespondUsersIds.push(allPendingRespondNodes[i].Value1);
                    }
                    if ((allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 || allPendingRespondUsersIds.indexOf(strWorkingUserId) > -1) && Draft == "YES") {
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                    } else {
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = strMsg;
                    }
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
                }
            } else if (currentViewName == "RES_VIEW" && Draft == "YES" && Can_Reply == "NO") {
                var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                var ireturn = 1;
                if (strCurrentStage != "0" || isDCUser)
                    ireturn = CheckLatestUID();
                if (ireturn == 0) {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strPendingAction;
                }
            }
            if ((currentViewName == "RES_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW") && Draft != "YES") {
                SetFlag();
            }
            if (currentViewName != "ORI_VIEW") {
                var xpniSpNodes = oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'];
                if (xpniSpNodes.length > 0) {
                    oriMsgCustomFields['Show_hide_Reviewers'] = "YES";
                } else {
                    oriMsgCustomFields['Show_hide_Reviewers'] = "NO";
                }
            }
            if (currentViewName == "RES_VIEW" && Draft == "YES") {
                ResetDataInDraftForSpclCharc();
                if (oriMsgCustomFields["DC_User_Change"]) {
                    checkDCUserChange(Draft);
                }
            }
            var strDSFormStatus = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            if (currentViewName == "RES_PRINT_VIEW" && Draft == "YES") {
                if (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM) > -1) {
                    resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_PMRES'] = "YES";
                }
            }
            // update the distribution action date if draft is open from current date. NOODLE-59231
            var distUsers = $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'];
            if (distUsers && distUsers.length) {
                for (var d = 0; d < distUsers.length; d++) {
                    var distUser = distUsers[d];
                    if (distUser.DS_ACTIONDAYS) {
                        $scope.distUser = distUser;
                        
                        var strDays = serverDate.getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * $scope.distUser.DS_ACTIONDAYS);
                        if (strDays) {
                            $scope.distUser.DS_ACTIONDUEDATE = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                        }                        
                    }
                }
            }
            if (currentViewName == "RES_VIEW") {
                if (!checkRCNameInFormContent2()) {
                    if (oriMsgCustomFields["DC_User_Change"] && Draft == "YES") {
                        var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                            return obj["isUserActive"] == true
                        });
                        var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
                        if (strReviewCoordinatorUser) {
                            setRCNameInFormContent2(strReviewCoordinatorUser);
                        }
                    } else {
                        var newRCuser = msgContent[0].Value7 || "";
                        newRCuser = newRCuser.replace("$$$", "#");
                        // update active RC name and set new name in dsformcontent2
                        setRCNameInFormContent2(newRCuser);
                        //Reset all RC name nodes as inactive
                        resetAllRCNameNodesAsInactive();
                        resetNodeAsInactive($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['ReviewCoordinatorUsers']["ReviewCoordinatorUser"]);
                        //Add new active RC name
                        oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].push({
                            "ReviewCoordinatorName": newRCuser,
                            "isUserActive": true
                        });
                    }
                }
            }
        };
        
        /* Auto expand text area */
        $scope.expandTextArea = function(event) {
            event.currentTarget.style.height = 'auto';
            event.currentTarget.style.height = 2 + event.currentTarget.scrollHeight + 'px'; //Adding 2px more for hiding scroll NOODLE-56839
        }

        $scope.delayedExpandTextAreaOnLoad = function() {
            $timeout(function() {
                $scope.expandTextAreaOnLoad();
            }, 50);
        }

        $scope.expandTextAreaOnLoad = function() {
            var textAreaObj = document.getElementsByTagName('textarea');
            if (textAreaObj) {
                for (var i = 0; i < textAreaObj.length; i++) {
                    textAreaObj[i].style.height = 'auto';
                    textAreaObj[i].style.height = 2 + textAreaObj[i].scrollHeight + 'px'; //Adding 2px more for hiding scroll NOODLE-56839
                }
            }
        }

        /*
         * This function removes "addedNewValue" key for insert 
         */
        $scope.removeAddedNewValueKey = function() {
            var Res_Info = $scope.resMsgCustomFields['All_Response']['Res_Info'];
            if (Res_Info.length) {
                for (var i = 0; i < Res_Info.length; i++) {
                    var resInfo = Res_Info[i];

                    for (var j = 0; j < resInfo['All_Comments']['Comments_Info'].length; j++) {
                        var commentInfo = resInfo['All_Comments']['Comments_Info'][j];

                        for (var k = 0; k < commentInfo['Multicomment']['MultiComment_info'].length; k++) {
                            var multiInfo = commentInfo['Multicomment']['MultiComment_info'][k];

                            for (var l = 0; l < multiInfo['CommentGroup']['RepeatCommentGroup'].length; l++) {
                                var repeatInfo = multiInfo['CommentGroup']['RepeatCommentGroup'][l];

                                if (repeatInfo.addedNewValue) {
                                    delete repeatInfo.addedNewValue;
                                }
                            }
                        }
                    }
                }
            }
        }

        $scope.checkDueDateForDraft = function() {
            var autoDistUsers = $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'];
            if (autoDistUsers.length) {
                var todaysDate = $scope.formatDate( serverDate, 'yy-mm-dd');
                for (var i = 0; i < $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'].length; i++) {
                    var assignedDate = $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'][i]['DS_ACTIONDUEDATE'];
                    if (assignedDate != "") {
                        if (parseInt((new Date(assignedDate) - new Date(todaysDate)) / (1000 * 60 * 60 * 24)) < 0) {
                            $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'][i]['DS_ACTIONDUEDATE'] = todaysDate;
                        }
                    }
                }
            }
        }

        $scope.setDefaultData = function() {
            var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var Asite_System_Data_Read_Only = $scope.data["myFields"]["Asite_System_Data_Read_Only"];

            //FOR ORI VIEW
            $scope.showOriRCErrorMsg = false;
            $scope.isFormAssociated = false; //Change to false on QA2
            // close due date            
            var closeDueDate = $scope.getValueOfOnLoadData("DS_CLOSE_DUE_DATE") || [];
            closeDueDate = (closeDueDate[0] || {}).Value || "";

            if (closeDueDate == "") {
                closeDueDate = Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] || "";
            }
            if (!closeDueDate) {
                
                var addDays = 27; //Set to 21 days for N/A and 3 weeks -- NOODLE-60091
                if (ORI_MSG_Custom_Fields['PeriodForReply'] === BAM_COMMENTING_CONSTANT.Four_Weeks) {
                    addDays = 28;
                } else if (ORI_MSG_Custom_Fields['PeriodForReply'] === BAM_COMMENTING_CONSTANT.Three_Weeks) {
                    addDays = 21;
                }

                var strDays = serverDate.getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * addDays);
                var strDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
                Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strDueDate;
                
            } else {
                Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = closeDueDate;
            }

            if (currentViewName == "ORI_VIEW") {
                if (!$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS']) {
                    SetStatus(BAM_COMMENTING_CONSTANT.Review_in_Progress);
                    SetReview_Stage(BAM_COMMENTING_CONSTANT.Review_in_Progress);
                    $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['status'] = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS']
                }                
               var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";

                // Get RC role from Stored value
                var strUser = (strWORKINGUSER.split('#')[1] || "")
                    .trim();
                var strUserId = strWORKINGUSER.split('|')[0].trim() + " # " + strUser;
                ORI_MSG_Custom_Fields['Originator'] = strUser;
                ORI_MSG_Custom_Fields['Originator_Id'] = strUserId;
                ORI_MSG_Custom_Fields['Status'] = 'Not Submitted';
                var isSubCon=ORI_MSG_Custom_Fields['is_Sub_Contractor_Required'];
                if(!isSubCon)
                {
                ORI_MSG_Custom_Fields['is_Sub_Contractor_Required'] = 'No';
                }                
            }
            $scope.reviewCoordinatorDistGrp = ORI_MSG_Custom_Fields["ReviewCoordinator_DistGrp"];
            $scope.reviewCoordinatorGroup = $scope.getValueOfOnLoadData("DS_PROJDISTGROUPS");

            var contractDetails = ($scope.getValueOfOnLoadData("DS_ASI_TIDP_GET_CONTRACT_DETAILS") || [])[0] || {};
            if (!ORI_MSG_Custom_Fields['Contract'])
                ORI_MSG_Custom_Fields['Contract'] = contractDetails.Value3 || "";
            if (!ORI_MSG_Custom_Fields['Project_No'])
                ORI_MSG_Custom_Fields['Project_No'] = contractDetails.Value4 || "";
            
            ORI_MSG_Custom_Fields['Todays_Date'] = $scope.formatDate(serverDate, 'yy-mm-dd');           

            //PRINT ORI VIEW
            var AllNodesMainDS = $scope.getValueOfOnLoadData( BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ) || [];
            $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA = AllNodesMainDS;
            if (!AllNodesMainDS.length) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP,
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP,
                            "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                        }]
                    }
                };
                $scope.requests[ BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ] = true;
                $scope.add({
                    name: BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP,
                    status: "incomplete"
                });

                $scope.getCallbackData(form)
                    .then(function(response) {
                        $scope.requests[ BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ] = false;
                        $scope.update({
                            name: BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ,
                            status: "completed"
                        });
                        if (response.data) {
                            if (response.data[ BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ]) {
                                var dSAssocFormAssocDocsMetaData = JSON.parse(response.data[ BAM_COMMENTING_CONSTANT.dsAssocFormAssocDocsMetadataSP ]);
                                $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA = dSAssocFormAssocDocsMetaData['Items']["Item"];
                            } else {
                                $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA = [];
                            }
                        }
                    });
            }
            // RES VIEW
            $scope.dummyModel = '';
            $scope.DisplayGroup = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["DisplayGroup"];
            $scope.RC_Send_To = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]["Selected_Tech_Autho"]["RC_Send_To"];
            $scope.Selected_Technical_Authoriser = commonApi._.where($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                return obj["isUserActive"] == true
            });
            $scope.CurrentStage = ORI_MSG_Custom_Fields["CurrentStage"];
            $scope.LastStage = ORI_MSG_Custom_Fields["LastStage"];

            // RES VIEW - REVIEWER
            $scope.showReadOnlyComments = false;
            $scope.Res_Info = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]["Res_Info"];

            $scope.DS_WORKINGUSER_ALL_ROLES = [];
            var DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
            if (DS_WORKINGUSER_ALL_ROLES[0] && DS_WORKINGUSER_ALL_ROLES[0].Value) {
                $scope.DS_WORKINGUSER_ALL_ROLES = DS_WORKINGUSER_ALL_ROLES[0].Value;
            }
            $scope.ReviewersGroupUsers = ORI_MSG_Custom_Fields["ReviewersGroupUsers"]["ReviewersInfo"];
            if ($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]["RES_ReviewCoordinator"] == "") {
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]["RES_ReviewCoordinator"] = {
                    "PM_Draft_Response": ""
                };
            }
            $scope.RES_ReviewCoordinator = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]["RES_ReviewCoordinator"];
            $scope.TechnicalAutho = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['TechnicalAutho']
            $scope.PM_Response = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['PM_Response'];
            $scope.Selected_Tech_Autho = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['Selected_Tech_Autho'];
            $scope.Associate_Docs = ORI_MSG_Custom_Fields["Associate_Doc"]["Associate_Docs"];
            $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData("DS_ALL_FORMSTATUS");

            $scope.DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
            $scope.PM_Contractor_Comm = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['PM_Contractor_Comm'];

            //Get Document details on load for views other than ORI_VIEW and RES_VIEW
            if (!(window.currentViewName == "ORI_VIEW" || window.currentViewName == "RES_VIEW")) {
                var AllRevDocDetails = $scope.getValueOfOnLoadData('DS_ASI_TIDP_MSG_DOC_ASSOCIATIONS_FOR_All_Rev') || [];
                if (AllRevDocDetails.length) {
                    AssociateDocsForAllRev(AllRevDocDetails, "onload");
                }
                if (!$scope.oriMsgCustomFields["activeTab"]) {
                    $scope.oriMsgCustomFields["activeTab"] = BAM_COMMENTING_CONSTANT.commentingDetails; //PackageRevisionHistoryDetails or CommentingDetails
                }               
            }

            if(window.currentViewName=="RES_VIEW" || window.currentViewName=="RES_PRINT_VIEW" || window.currentViewName=="FORM_PRINT_VIEW")
            {
                if ($scope.oriMsgCustomFields["activeTab_Res_View"]) {
                    $scope.oriMsgCustomFields["activeTab_Res_View"] = BAM_COMMENTING_CONSTANT.CommentingForm; //PackageRevisionHistoryDetails or CommentingDetails
                    $scope.delayedExpandTextAreaOnLoad();
                }    
            }
            //show hide scope vars
            $scope.showReviewer = false;
            $scope.showDraftProjMngrRes = false;
            $scope.showTechnicalAuthoriserRes = false;
            $scope.showProjMngrRes = false;
            $scope.showContrResp = false;
            $scope.showProjMngrCntrctrRes = false;

            var hasContractorReviewComment = commonApi._.some($scope.PM_Contractor_Comm['PM_CON_Com_details'], function(obj) {
                return (obj.Contractor_Review_comments);
            });

            // to get Custom Attribute On Load.
            var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            $scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
            var ISDRAFT = document.getElementById("DS_ISDRAFT");
            ISDRAFT = ISDRAFT ? ISDRAFT.value : "";
            if (currentViewName == "ORI_VIEW") {
                var logo = commonApi._.filter(customAttr, function(val) {
                    return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1
                });
                if (logo && logo.length) {
                    $scope.oriMsgCustomFields.DS_Logo = logo[0].Value8;
                }
            }
            if (currentViewName == "ORI_VIEW" && ISDRAFT == "YES") {
                $scope.getCalculatedActionDueDate();
            }
            // Show Reviewer
            if ($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["DisplayGroup"]['Dis_flag_RC_section'] == "YES") {
                $scope.showReviewer = true;
            }
            // SHOW Draft Project Manager Response
            else if ($scope.RC_Send_To == BAM_COMMENTING_CONSTANT.Technical_Authoriser) {
                
                $scope.showDraftProjMngrRes = true;
            }
            // SHOW Technical Authoriser Response
            else if ($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["DisplayGroup"]['Dis_flag_TA_Section'] == "YES") {
                $scope.showTechnicalAuthoriserRes = true;
            }
            // SHOW Project Manager Response
            else if ($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["DisplayGroup"]['Dis_Flag_PM_section'] == "YES") {
                $scope.showProjMngrRes = true;
            }
            // SHOW Contractor Response
            else if ($scope.currentStage == "5") {
                $scope.showContrResp = true;
            }
            // SHOW Project Manager Contractor Response
            else if (hasContractorReviewComment && $scope.lastStage == "5") {
                $scope.showProjMngrCntrctrRes = true;
            }

            $scope.checkForContactorReviewComments = function() {
                var hasContractorReviewComment = commonApi._.some($scope.PM_Contractor_Comm['PM_CON_Com_details'], function(obj) {
                    return (obj.Contractor_Review_comments);
                });

                return hasContractorReviewComment;
            }

            $scope.$watch(function($scope) {
                return $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['Reviewers_DistGrps']['Reviewers_distg'];
            }, function(newValue, oldValue) {
                if (newValue != oldValue) {
                    $scope.On_Reviewers_distg_Changed();
                }
            }, true);

            $scope.$watch(function($scope) {
                return $scope.resMsgCustomFields["All_Response"]["PM_Response"]["PM_Res_Status"];
            }, function(newValue, oldValue) {
                if (newValue != oldValue) {
                    $scope.On_PM_Res_Status_Changed();
                }
            }, true);

            applyAllCommentInfoWatch();

        };

        var applyAllCommentInfoWatch = function() {
            commonApi._.each($scope.resMsgCustomFields["All_Response"]["Res_Info"], function(o) {
                applyCommentInfoWatch(o);
            });
        };

        var applyCommentInfoWatch = function(o) {
            var timeout = undefined;
            if (typeof o == "undefined") {
                return;
            }

            if (o.visible != 'YES') {
                return;
            }

            $scope.$watch(function($scope) {
                return o['All_Comments']['Comments_Info'];
            }, function(newValue, oldValue) {
                if (!timeout) {
                    $scope.ON_Comments_Info(o);
                    timeout = $window.setTimeout(function() {
                        timeout = undefined;
                    }, 50);
                }
            }, true);
        };

        $scope.firstResCommentBy = function() {
            return (commonApi._.findWhere($scope.resMsgCustomFields["All_Response"]["Res_Info"], {
                visible: 'YES'
            }) || {});
        };

        $scope.filterReviewCoordinatorGroup = function(item) {
            return (item.Value.indexOf("RC") > -1 || item.Value.indexOf("Coordinator") > -1);
        }

        $scope.filterReviewGroup = function(item) {
            return !(item.Value.indexOf("RC") > -1 || item.Value.indexOf("Coordinator") > -1);
        }

        $scope.filterDS_PROJUSERS_ALL_ROLES_TA = function(item) {
            var roleNameLowerCase = item.Value.toLowerCase().trim(),
            roleNamePipe = roleNameLowerCase.split('|')[0].trim(),
            roleNamePipeSplit = roleNamePipe.split(','),
            roleName = null;
            for (var i = 0; i < roleNamePipeSplit.length; i++) {
                roleName = roleNamePipeSplit[i].trim();                
                if (roleName == 'technical authoriser') {
                    return true;
                }
            }
        }
        $scope.filterDS_PROJUSERS_ALL_ROLES_PM = function(item) {           
            var roleNameLowerCase = item.Value.toLowerCase().trim(),
            roleNamePipe = roleNameLowerCase.split('|')[0].trim(),
            roleNamePipeSplit = roleNamePipe.split(','),
            roleName = null;
            for (var i = 0; i < roleNamePipeSplit.length; i++) {
                roleName = roleNamePipeSplit[i].trim();                
                if (roleName == 'project manager') {
                    return true;
                }
            }
        }
        $scope.filterContractor = function(item) {
            var userRole = item.Value.split('|')[0] || "";
            return (userRole.indexOf("Contractor PM") > -1); 
        }

        $scope.filterDS_ALL_FORMSTATUS = function(item) {
                return (item.Value.indexOf(BAM_COMMENTING_CONSTANT.Accepted) > -1 || item.Value.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1);
            }
          
        $scope.filterDsAssocFormAssocdocsMetadata = function(item) {

            for (var i = 0; i < $scope.allPoiDetails.length; i++) {
                if ($scope.allPoiDetails[i].Value2 == item.Value11) {                    
                    return (item.Value12 == BAM_COMMENTING_CONSTANT.QA_Accepted);                    
                }                
            }
        }

        $scope.filterFormProgressClose = function(item) {
            return (item.Name == "Closed");
        }
        $scope.filterReviewCoordinatorUserNames = function(item) {
            return (item.Value.indexOf('Review Coordinator') > -1);
        }
        $scope.onDCNewUserDropDownChange = function(userRole, userNodeName, userPrevName, userNewName, isCheckboxChecked) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            var cmntStatus = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];
            if (cmntStatus)
                cmntStatus = cmntStatus.split("#")[1].trim();

            if (!userNewName) {
                //Reset all RC name nodes as inactive
                if (userRole == "RC_Role") {
                    removePrevRCNameNodesFromArray();
                } else if (userRole == "TA_Role") {
                    removePrevTANameNodesFromArray();
                } else if (userRole == "PM_Role") {
                    if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) {
                        removePrevTechPMNameNodesFromArray();
                    } else if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM) {
                        removePrevPMNameNodesFromArray();
                    }
                } else if (userRole == BAM_COMMENTING_CONSTANT.contractorRole) {
                    removePrevContractorNameNodesFromArray();
                }
                return;
            }

            var currentUser = userPrevName.split("|")[2].trim();
            var currentUserId = currentUser.split("#")[0].trim();
            var newUser = userNewName.split('|')[2].trim();
            var reviewStage = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'];

            if (userNewName.indexOf(currentUserId) > -1) {
                alert("New user cannot be the same as current user. Please select another user.");
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['DC_Users_List'][userRole][userNodeName] = ""
                return;
            }
            if (userRole == "RC_Role") {
                //remove previous values if any.
                removePrevRCNameNodesFromArray();
                //Reset all RC name nodes as inactive
                resetNodeAsInactive($scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['ReviewCoordinatorUsers']["ReviewCoordinatorUser"]);
                //Add new active RC name
                oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].push({
                    "ReviewCoordinatorName": newUser,
                    "isUserActive": true,
                    "isAddedNewByDc": true
                });
                if (cmntStatus == BAM_COMMENTING_CONSTANT.Review_in_Progress || cmntStatus == BAM_COMMENTING_CONSTANT.Further_Review_in_Progress) {
                    $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    //Since RC does not have any dropdown selection, send action to new RC and clear action of prev RC manually instead of triggring on-change function
                    sendActionToRC("ActionByDC");
                    clearUserActionById(userPrevName);
                } else if (cmntStatus == "" || cmntStatus == BAM_COMMENTING_CONSTANT.Not_Accepted ) {
                    if (reviewStage == "Response from Contractor") {
                        $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                        sendActionToRC("ActionByDC");
                        clearUserActionById(userPrevName);
                    }
                }
                setRCNameInFormContent2();
            } else if (userRole == "TA_Role") {
                //remove previous values if any.
                removePrevTANameNodesFromArray();
                //Reset all RC name nodes as inactive
                
                resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"]);
                //Add new active TA
                allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"].push({
                    "TAName": newUser,
                    "isUserActive": true,
                    "isAddedNewByDc": true
                });
                if (cmntStatus == "Sent to TA") {
                    $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    $scope.On_Technical_Authoriser_Changed("ActionByDC", userPrevName);
                }
            } else if (userRole == "PM_Role") {
                if (!(cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA || cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM)) {
                    //If status is "Not Accepted" or "Accepted with Comments"
                    var selectedProjManagerArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                        return obj["isUserActive"] == true
                    });
                    var selectedProjManager = selectedProjManagerArr[0] && selectedProjManagerArr[0]['PMName'] || "";

                    if (selectedProjManager != "") {
                        cmntStatus = BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA;
                    } else {
                        cmntStatus = BAM_COMMENTING_CONSTANT.Sent_to_PM;
                    }
                }
                //Check and assign action according to existing action of ball in court.
                if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) {
                    //remove previous values if any.
                    removePrevTechPMNameNodesFromArray();
                    //Reset all PM name nodes as inactive
                    
                    resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"]);
                    //Add new active PM
                    allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].push({
                        "PMName": newUser,
                        "isUserActive": true,
                        "isAddedNewByDc": true
                    });
                    if (reviewStage == "Response from Contractor" || reviewStage == "Sent to PM by RC" || reviewStage == "Sent to PM by TA") {
                        $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                        $scope.On_SelectedProjectManager_Changed("ActionByDC", userPrevName);
                    }
                } else if (cmntStatus == BAM_COMMENTING_CONSTANT.Sent_to_PM) {
                    //remove previous values if any.
                    removePrevPMNameNodesFromArray();
                    //Reset all PM name nodes as inactive
                    resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"]);
                    //Add new active PM
                    allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"].push({
                        "PMName": newUser,
                        "isUserActive": true,
                        "isAddedNewByDc": true
                    });
                    if (reviewStage == "Response from Contractor" || reviewStage == "Sent to PM by RC" || reviewStage == "Sent to PM by TA") {
                        $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                        $scope.On_Selected_Project_Manager_Changed("ActionByDC", userPrevName);
                    }
                }
            } else if (userRole == BAM_COMMENTING_CONSTANT.contractorRole) {
                //remove previous values if any.
                removePrevContractorNameNodesFromArray();
                //Reset all PM name nodes as inactive
                resetAllContractorNameNodesAsInactive();
                //Add new active PM
                allRes['PM_Response']['Contractors']["Contractor"].push({
                    "ContractorName": newUser,
                    "isUserActive": true,
                    "isAddedNewByDc": true
                });
                if (reviewStage == BAM_COMMENTING_CONSTANT.Sent_to_Contractor) {
                    $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    $scope.On_Contractor_changed("ActionByDC", userPrevName);
                }
            }
        }

        var removeIsAddedNewByDCFlag = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            
            //RC
            removeNodeFromArray(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"],"isAddedNewByDc");
           
            //TA
            removeNodeFromArray(allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"],"isAddedNewByDc");
            
            //PM

            removeNodeFromArray(allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"],"isAddedNewByDc");
            
            //Tech PM

            removeNodeFromArray(allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"],"isAddedNewByDc");

            //Contractor
            removeNodeFromArray(allRes['PM_Response']['Contractors']["Contractor"],"isAddedNewByDc");            
        }
        
		/**
		* This function is used delete particular node from array.
		* @param { Array } nodeArray : pass array from which you want to remove node
		* @param { string } nodeName : Key name which you want to remove.		
		*/
        function  removeNodeFromArray (nodeArray,nodeName)
        {
            for (var i = 0; i < nodeArray.length; i++) {
                if (nodeArray[i][nodeName]) {
                    delete nodeArray[i][nodeName];
                }
            }
        }
        var checkDCUserChange = function(isDraft) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];

            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_ASI_CHECK_DC_USER_CHANGE",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_ASI_CHECK_DC_USER_CHANGE",
                        "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                    }]
                }
            };
            $scope.requests['pkgrev'] = true;
            $scope.add({
                name: "DS_ASI_CHECK_DC_USER_CHANGE",
                status: "incomplete"
            });

            $scope.getCallbackData(form).then(function(response) {
                $scope.requests['pkgrev'] = false;
                $scope.update({
                    name: "DS_ASI_CHECK_DC_USER_CHANGE",
                    status: "completed"
                });


                if (!response.data) {
                    return;
                }

                var AllUserListForDcChange = JSON.parse(response.data['DS_ASI_CHECK_DC_USER_CHANGE']);
                var AllUserListForDcChangeList = AllUserListForDcChange.Items.Item || [];

                //Reset flags
                if (isDraft != 'YES') {
                    oriMsgCustomFields["DC_Users_List"] = {
                        "RC_Role": {
                            "Can_DC_Change_RC": false,
                            "RC_Checked": false,
                            "RC_Prev_Name": "",
                            "RC_New_User": ""
                        },
                        "TA_Role": {
                            "Can_DC_Change_TA": false,
                            "TA_Checked": false,
                            "TA_Prev_Name": "",
                            "TA_New_User": ""
                        },
                        "PM_Role": {
                            "Can_DC_Change_PM": false,
                            "PM_Checked": false,
                            "PM_Prev_Name": "",
                            "PM_New_User": ""
                        },
                        "Contractor_Role": {
                            "Can_DC_Change_Contractor": false,
                            "Contractor_Checked": false,
                            "Contractor_Prev_Name": "",
                            "Contractor_New_User": ""
                        }
                    };
                }

                if (AllUserListForDcChangeList[0].Value && AllUserListForDcChangeList[0].Value.indexOf("Not DC") == -1) {
                    //DC can change users
                    oriMsgCustomFields["DC_User_Change"] = true;
                    isDCChangeUser = true;
                    oriMsgCustomFields['Warning']['Can_Reply'] = "YES";
                    asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = "0";
                    //Reset only once before distribution.
                    var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                    if (Draft != "YES") {
                        asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    }
                    var objSaveDraft = document.getElementById('btnSaveDraft');
                    if (objSaveDraft) {
                        objSaveDraft.style.display = 'none'
                    }
                    AddOldValuesForDCUserModification(AllUserListForDcChangeList);
                } else {
                    //Not DC. Regular flow of other roles
                    //Set DC_User_Change as false
                    oriMsgCustomFields["DC_User_Change"] = false;
                    isDCChangeUser = false;

                    // This is the main Function to Show / Hide Section stage wise(RV section/RC section->TA section->PMsection->Contractor Section).
                    AddBlankResponseNode();

                    //Set UID to block old draft creation NOODLE-52896
                    oriMsgCustomFields['LastUID'] = oriMsgCustomFields['CurrentUID'];
                    
                    oriMsgCustomFields['CurrentUID'] = serverDate.getTime();
                    
                }
            });
        }
        var removePrevRCNameNodesFromArray = function() {
            //Remove value from array if DC has added any new values
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            for (var i = 0; i < oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].length; i++) {
                if (oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"][i]["isAddedNewByDc"]) {
                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].splice(i, 1);
                    i--;
                }
            }
        }
        var removePrevTANameNodesFromArray = function() {
            //Remove value from array if DC has added any new values
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            for (var i = 0; i < allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"].length; i++) {
                if (allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"][i]["isAddedNewByDc"]) {
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"].splice(i, 1);
                    i--;
                }
            }
        }
        var removePrevPMNameNodesFromArray = function() {
            //Remove value from array if DC has added any new values
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            for (var i = 0; i < allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"].length; i++) {
                if (allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"][i]["isAddedNewByDc"]) {
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"].splice(i, 1);
                    i--;
                }
            }
        }
        var removePrevTechPMNameNodesFromArray = function() {
            //Remove value from array if DC has added any new values
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            for (var i = 0; i < allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].length; i++) {
                if (allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"][i]["isAddedNewByDc"]) {
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].splice(i, 1);
                    i--;
                }
            }
        }
        var removePrevContractorNameNodesFromArray = function() {
            //Remove value from array if DC has added any new values
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            for (var i = 0; i < allRes['PM_Response']['Contractors']["Contractor"].length; i++) {
                if (allRes['PM_Response']['Contractors']["Contractor"][i]["isAddedNewByDc"]) {
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['PM_Response']['Contractors']["Contractor"].splice(i, 1);
                    i--;
                }
            }
        }
        var resetAllContractorNameNodesAsInactive = function() {
            $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['PM_Response']['Contractors']["Contractor"].map(function(obj) {
                obj.isUserActive = false;
                return obj;
            });
        }

        /**
		* This function is used to  set isUserActive as false to passed array.
		* @param { Array } nodeArray : pass array from which you want set isUserActive as false
        */
        function resetNodeAsInactive(nodeArray)
        {
            nodeArray.map(function(obj) {
                obj.isUserActive = false;
                return obj;
            });
        }
        var updateIfHasValueInNode = function(checkForName, CheckForArr, CheckForNodeKey) {
            //Checks and returns false if name doesnt already exist in 'CheckFor'(Selected_Technical_Authorisers/Selected_Project_Managers) Array
            var usersArr = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Selected_Tech_Autho'][CheckForArr][CheckForNodeKey];

            if (CheckForNodeKey == "Selected_Technical_Authoriser") {
                return !(commonApi._.each(usersArr, function(obj) {
                    if (obj["TAName"] == checkForName) {
                        obj["isUserActive"] = true;
                        return obj;
                    }
                }).length);
                
            } else if (CheckForNodeKey == "Selected_Project_Manager") {
                return !(commonApi._.each(usersArr, function(obj) {
                    if (obj["PMName"] == checkForName) {
                        obj["isUserActive"] = true;
                        return obj;
                    }
                }).length);
            }
        }

        $scope.getCalculatedActionDueDate = function(calculateFor) {
            //This function returns the no of days due for response action. if calculateFor is blank, it is called for ORI view
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var strPeriodOfReply = oriMsgCustomFields['PeriodForReply'];            
            var customAttrArr = $scope.DS_ASI_Configurable_AttributesArr;
            if (!customAttrArr) {
                customAttrArr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            }
            var todaysDate = oriMsgCustomFields['Todays_Date'];
            var pkgIssueDate = oriMsgCustomFields['Pkg_Issued_Date'];
            var pkgIssueDateArr = pkgIssueDate.split('/');
            var formattedPkgIssueDate = "";

            if (pkgIssueDateArr.length > 1) {
                formattedPkgIssueDate = pkgIssueDateArr[2] + "-" + pkgIssueDateArr[1] + "-" + pkgIssueDateArr[0];
            } else {
                formattedPkgIssueDate = pkgIssueDate;
            }
            var diffDays = parseInt((new Date(todaysDate) - new Date(formattedPkgIssueDate)) / (1000 * 60 * 60 * 24));
            var revActionDueDays = 0,
                rcActionDueDays = 0,
                taActionDueDays = 0,
                pmActionDueDays = 0,
                contActionDueDays = 0; //From Custom Attributes
            
            var revActionDueDaysFinal = 0,
                rcActionDueDaysFinal = 0,
                taActionDueDaysFinal = 0,
                pmActionDueDaysFinal = 0,
                contActionDueDaysFinal = 0;
            var weekCustAttrArr = [];

            if (!oriMsgCustomFields.Action_Due_Days) {
                oriMsgCustomFields.Action_Due_Days = {
                    "Reviewer_Action_Due_Days": "",
                    "RC_Action_Due_Days": "",
                    "TA_Action_Due_Days": "",
                    "PM_Action_Due_Days": "",
                    "Contractor_Action_Due_Days": ""
                }
            }
            if (strPeriodOfReply == BAM_COMMENTING_CONSTANT.Three_Weeks) {
                weekCustAttrArr = commonApi._.where(customAttrArr, {
                    Value3: "WEEK3",
                    Value11: "Active"
                });
            } else if (strPeriodOfReply == BAM_COMMENTING_CONSTANT.Four_Weeks) {
                weekCustAttrArr = commonApi._.where(customAttrArr, {
                    Value3: "WEEK4"
                });
            } else if (strPeriodOfReply == "N/A") {
                weekCustAttrArr = commonApi._.where(customAttrArr, {
                    Value3: "N/A"
                });
            }
            var revActionDueDaysObj = commonApi._.where(weekCustAttrArr, {
                Value7: "Reviewer"
            });
            revActionDueDays = parseInt(revActionDueDaysObj[0].Value8);

            var rcActionDueDaysObj = commonApi._.where(weekCustAttrArr, {
                Value7: "RC"
            });
            rcActionDueDays = parseInt(rcActionDueDaysObj[0].Value8);

            var taActionDueDaysObj = commonApi._.where(weekCustAttrArr, {
                Value7: "TA"
            });
            taActionDueDays = parseInt(taActionDueDaysObj[0].Value8);

            var pmActionDueDaysObj = commonApi._.where(weekCustAttrArr, {
                Value7: "PM"
            });
            pmActionDueDays = parseInt(pmActionDueDaysObj[0].Value8);

            var contActionDueDaysObj = commonApi._.where(weekCustAttrArr, {
                Value7: "Contractor"
            });
            contActionDueDays = parseInt(contActionDueDaysObj[0].Value8);
            
            if (diffDays == 0) {
                revActionDueDaysFinal = revActionDueDays || 0;
                rcActionDueDaysFinal = rcActionDueDays || 0;
                taActionDueDaysFinal = taActionDueDays || 0;
                pmActionDueDaysFinal = pmActionDueDays || 0;
            } else {
                //Check For Reviewers & RC difference
                if (diffDays <= rcActionDueDays) {
                    revActionDueDaysFinal = 0;
                    if ((revActionDueDays - diffDays) > 0) {
                        revActionDueDaysFinal = (revActionDueDays - diffDays);
                    }
                    rcActionDueDaysFinal = 0;
                    if ((rcActionDueDays - diffDays) > 0) {
                        rcActionDueDaysFinal = (rcActionDueDays - diffDays);
                    }
                    taActionDueDaysFinal = taActionDueDays || 0;
                    pmActionDueDaysFinal = pmActionDueDays || 0;
                }
                //Check For RC+TA difference
                else if (diffDays <= (rcActionDueDays + taActionDueDays)) {
                    revActionDueDaysFinal = 0;
                    rcActionDueDaysFinal = 0;
                    taActionDueDaysFinal = 0;
                    if ((rcActionDueDays + taActionDueDays) - diffDays > 0) {
                        taActionDueDaysFinal = (rcActionDueDays + taActionDueDays) - diffDays;
                    }
                    pmActionDueDaysFinal = pmActionDueDays || 0;
                }
                //Check For RC+TA+PM difference
                else if (diffDays <= (rcActionDueDays + taActionDueDays + pmActionDueDays)) {
                    revActionDueDaysFinal = 0;
                    rcActionDueDaysFinal = 0;
                    taActionDueDaysFinal = 0;
                    taActionDueDaysFinal = 0;
                    pmActionDueDaysFinal = 0;
                    if ((rcActionDueDays + taActionDueDays + pmActionDueDays) - diffDays > 0) {
                        pmActionDueDaysFinal = (rcActionDueDays + taActionDueDays + pmActionDueDays) - diffDays;
                    }
                }
            }


            if (gateDaysdetails[0] && gateDaysdetails[0].Value1) {
                revActionDueDaysFinal=gateDaysdetails[0].Value4;
                rcActionDueDaysFinal = gateDaysdetails[0].Value5;
                pmActionDueDaysFinal=gateDaysdetails[0].Value6;
  
            }
            contActionDueDaysFinal = contActionDueDays || 0;
            oriMsgCustomFields.Action_Due_Days.Reviewer_Action_Due_Days = revActionDueDaysFinal;
            oriMsgCustomFields.Action_Due_Days.RC_Action_Due_Days = rcActionDueDaysFinal;
            oriMsgCustomFields.Action_Due_Days.TA_Action_Due_Days = taActionDueDaysFinal;
            oriMsgCustomFields.Action_Due_Days.PM_Action_Due_Days = pmActionDueDaysFinal;
            oriMsgCustomFields.Action_Due_Days.Contractor_Action_Due_Days = contActionDueDaysFinal;
            
            if (calculateFor) {
                if (calculateFor == "REVIEWER_DUE_DATE") {
                    return  revActionDueDaysFinal;
                } else if (calculateFor == "RC_DUE_DATE") {
                    return rcActionDueDaysFinal;
                } else if (calculateFor == "TA_DUE_DATE") {
                    return taActionDueDaysFinal;
                } else if (calculateFor == "PM_DUE_DATE") {
                    return pmActionDueDaysFinal;
                } else if (calculateFor == "CONTRACTOR_DUE_DATE") {
                    return contActionDueDaysFinal;
                } else if (calculateFor == "RC_REJECT_DUE_DATE") {
                    return 1;
                } else if (calculateFor == "PM_CLOSE_DUE_DATE") {
                    return 21;
                }                
            }
        }
        $scope.isCommentsInfoHasDocumentOrPackage = function(resInfo) {
            if (!resInfo) {
                return
            }
            var isDocOrPkg = false;
            var commentsInfo = resInfo['All_Comments']['Comments_Info'];
            commonApi._.each(commentsInfo, function(o) {
                if (o['Comment_Level'] == BAM_COMMENTING_CONSTANT.Package || o['Comment_Level'] == BAM_COMMENTING_CONSTANT.Document) {
                    isDocOrPkg = true;
                }
            });
            return isDocOrPkg;
        }
        $scope.isCommentsInfoHasNoComments = function(resInfo) {
            if (!resInfo) {
                return
            }

            var isNoComments = false;
            var commentsInfo = resInfo['All_Comments']['Comments_Info'];
            commonApi._.each(commentsInfo, function(o) {
                if (o['Comment_Level'] == 'No Comment') {
                    isNoComments = true;
                }
            });
            return isNoComments;
        }
        $scope.getLatestSeqId = function(items) {
            var lastSeqNo = parseInt(items[items.length - 1].seqNo) || 0;
            return lastSeqNo;
        }
        $scope.insertNewItems = function(items, valueFor, uid) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];                        
            var item = angular.copy(STATIC_OBJ_DATA[valueFor]);
            var strWorkingUserName = $scope.workingUserDetails[0].Name || "";
            if (uid && item.hasOwnProperty && item.hasOwnProperty('UID')) {
                item.UID = uid;
            }

            if (valueFor == 'multiCommentInfo') {
                
                item.ReviewerName = $scope.workingUserDetails[0].Name || "";;
                //Only for PM view
                var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                var strDis_Flag_PM_section = resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'];
                if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4") {

                    item.CommentGroup.RepeatCommentGroup[0].seqNo = 1;
                }
            } else if (valueFor == 'repeatCommentGroup') {
                var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                var strDis_Flag_PM_section = resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'];
                if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4") {
                    item.Label = "PM";   
                    item.PM_Name= strWorkingUserName;                
                } else if (strCurrentStage == "5") {
                    item.Label = strWorkingUserName;
                }

                item.seqNo = $scope.getLatestSeqId(items) + 1;
            }
            //Add item in items
            $scope.addRepeatingRow(items, item);

            if (valueFor == 'Comments_Info') {
                CheckCommentAvailabel(item);
            }
            return item;
        }

        $scope.duplicateDocValidation = function(array, myform, showAlert, strDocId) {
            var tested = [];
            for (var i = 0; i < array.length; i++) {
                var comInfo = array[i];
                var comDocId = comInfo.Doc_ID;
                if (tested.indexOf(comDocId) > -1)
                    continue;
                tested.push(comDocId);
                var duplicateDocsArr = commonApi._.where(array, {
                    Doc_ID: comDocId
                });

                if (duplicateDocsArr.length > 1) {
                    if (showAlert && comDocId == strDocId) {
                        alert("Duplicate document selected. Please select a different document."); 
                    }

                    for (var j = 0; j < array.length; j++) {
                        if (array[j]["Comment_Level"] === BAM_COMMENTING_CONSTANT.Document && comDocId == array[j]["Doc_ID"]) {
                            if (myform['DS_ASSOC_FORM_ASSOCDOCS_METADATA' + (array.length-1).toString()]) {
                                myform['DS_ASSOC_FORM_ASSOCDOCS_METADATA' + (array.length-1).toString()].$setValidity("duplicateVal", false);
                            }
                        }
                    }
                } else {
                    if (array[i]["Comment_Level"] === BAM_COMMENTING_CONSTANT.Document) {
                        if (myform['DS_ASSOC_FORM_ASSOCDOCS_METADATA' + i]) {
                            myform['DS_ASSOC_FORM_ASSOCDOCS_METADATA' + i].$setValidity("duplicateVal", true);
                        }
                    }
                }
            }
        }

        $scope.validateDocumentsStatusOnRadioChange = function(commentInfo) {
            var newCommentLevel = commentInfo.Comment_Level;
            var prevCommentlevel = commentInfo.Comment_Level_Prev_Value;

            var resInfo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'];
            var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];

            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var packageArr = commonApi._.filter(associateDocs, {
                IsDocument_Package: BAM_COMMENTING_CONSTANT.Package
            });
            var currentPackageStatus = packageArr[0] && packageArr[0].DocStatus || "";
            var validAcceptanceDocsArr = commonApi._.where(associateDocs, {
                IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,                
                PurposeOfIssue: oriMsgCustomFields['Package_Submission_Purpose'],
                MainDocStatus: BAM_COMMENTING_CONSTANT.QA_Accepted                
            });
            var commentedDocsArr = [];
            if (!validAcceptanceDocsArr.length) {
                return;
            }                   
            var isPackageCommentCnt = 0;
            var isOnlyPackageComment = false;

            for (var i = 0; i < resInfo.length; i++) {
                var visibleResInfo = resInfo[i];
                if (visibleResInfo.visible == "YES") {
                    var commentInfoArr = visibleResInfo['All_Comments']['Comments_Info'];

                    for (var j = 0; j < commentInfoArr.length; j++) {
                        var commentInfo = commentInfoArr[j];
                        if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.No_Comment) {
                            isPackageCommentCnt++;
                        } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Document) {
                            commentedDocsArr.push(commentInfo.Doc_ID);
                            isPackageCommentCnt++;
                        }
                    }
                }
            }
            if (!isPackageCommentCnt) {
                isOnlyPackageComment = true;
            }
            if (newCommentLevel == BAM_COMMENTING_CONSTANT.No_Comment) {
                //Reset all docs whos status is "Accepted With Comments"/"Not Accepted". Do nothing for ""/"Accepted"
                if (currentPackageStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                    if (validAcceptanceDocsArr.length) {
                        for (var i = 0; i < validAcceptanceDocsArr.length; i++) {
                            var thisDocStatus = validAcceptanceDocsArr[i].DocStatus;
                            if (thisDocStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                                resetDocStatus(validAcceptanceDocsArr[i].DocumentRevisionId, true); 
                            }
                        }
                    }
                }
            } else if (newCommentLevel == BAM_COMMENTING_CONSTANT.Document) {
                //Check if radio button is being clicked from Package radio button
                if (prevCommentlevel == BAM_COMMENTING_CONSTANT.Package) {
                    if (currentPackageStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                        if (validAcceptanceDocsArr.length) {
                            for (var i = 0; i < validAcceptanceDocsArr.length; i++) {
                                var thisDocStatus = validAcceptanceDocsArr[i].DocStatus;
                                if ( thisDocStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                                    var isDocCommented = commonApi._.contains(commentedDocsArr, validAcceptanceDocsArr[i].Doc_Id);
                                    if (!isDocCommented) {
                                        resetDocStatus(validAcceptanceDocsArr[i].DocumentRevisionId, true); 
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (newCommentLevel == BAM_COMMENTING_CONSTANT.Package) {
                if (prevCommentlevel == "") {
                    if (currentPackageStatus == BAM_COMMENTING_CONSTANT.Accepted) {
                        resetDocStatus();
                    }
                    if (commentedDocsArr.length > 0) {
                        var docListWithAcceptedStatus = commonApi._.filter(validAcceptanceDocsArr, function(obj) {
                            return (obj.DocStatus == BAM_COMMENTING_CONSTANT.Accepted)
                        });
                        for (var i = 0; i < docListWithAcceptedStatus.length; i++) {
                            resetDocStatus(docListWithAcceptedStatus[i].DocumentRevisionId, true); 
                        }
                    }
                } else {
                    if (prevCommentlevel == BAM_COMMENTING_CONSTANT.No_Comment) {
                        resetDocStatus();
                    }
                    if (prevCommentlevel == BAM_COMMENTING_CONSTANT.Document) {
                        if (currentPackageStatus == BAM_COMMENTING_CONSTANT.Accepted || isOnlyPackageComment) {
                            resetDocStatus();
                        } else if (currentPackageStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                            //Get all documents with Statues "Accepted With Comments"/"Not Accepted" and get doc list where comments are added.
                            //Reset status where comments are not made.
                            var docListWithoutAcceptedStatus = commonApi._.filter(validAcceptanceDocsArr, function(obj) {
                                return (obj.DocStatus == BAM_COMMENTING_CONSTANT.Not_Accepted)
                            });
                            var docIdsArr = _.map(docListWithoutAcceptedStatus, function(obj) {
                                return obj.DocStatus ? obj.DocumentRevisionId : ""
                            });
                            var resetDocArray = docIdsArr.filter(function(val) {
                                return commentedDocsArr.indexOf(val) == -1;
                            });
                            if (resetDocArray.length) {
                                for (var i = 0; i < resetDocArray.length; i++) {
                                    if (resetDocArray[i]) {
                                        resetDocStatus(resetDocArray[i], true);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        $scope.deleteItems = function(index, array, atleastOne, commentInfo, myform) {
            if (atleastOne && array.length == 1) {
                alert("Single entry cannot be deleted. You cannot delete all comments of a section.");
                return;
            }
            var deletedItem = array[index];
            $scope.removeRepeatingRow(array, index);
            // remove the users list index for group as well.
            $scope.groupUsersList.splice(index, 1);
            $scope.delayedExpandTextAreaOnLoad(); 
            commentInfo && CheckCommentAvailabel(commentInfo);

            //Check if Duplicates deleted and update accordingly
            if (deletedItem["Comment_Level"] && deletedItem["Comment_Level"] === BAM_COMMENTING_CONSTANT.Document) {
                $scope.duplicateDocValidation(array, myform, false, deletedItem.Doc_ID);
            }

            var commentLevel = deletedItem.Comment_Level;
            if (myform && commentLevel == BAM_COMMENTING_CONSTANT.Package) {
                var isPkgCommentAdded = false;
                var isPackageCommentCnt = 0;
                var commentedDocsArr = [];
                var resInfo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'];
                var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];                
                var statusEditableDocsArr = commonApi._.where(associateDocs, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,                    
                    PurposeOfIssue: oriMsgCustomFields['Package_Submission_Purpose'], 
                    MainDocStatus: BAM_COMMENTING_CONSTANT.QA_Accepted
                });
                             
                for (var i = 0; i < resInfo.length; i++) {
                    var visibleResInfo = resInfo[i];
                    if (visibleResInfo.visible == "YES") {
                        var commentInfoArr = visibleResInfo['All_Comments']['Comments_Info'];

                        for (var j = 0; j < commentInfoArr.length; j++) {
                            var commentInfo = commentInfoArr[j];
                            if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.No_Comment) {
                                isPackageCommentCnt++;
                            } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Package) {
                                isPkgCommentAdded = true;
                            } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Document) {
                                commentedDocsArr.push(commentInfo.Doc_ID);
                                isPackageCommentCnt++;
                            }
                        }
                    }
                }

                if (!isPackageCommentCnt) {
                    resetDocStatus();
                } else {
                    //RESET where document comments NOT ADDED and STATUS is to ‘Accepted with Comments’ and ‘Not Accepted’.
                    var docListWithoutAcceptedStatus = commonApi._.filter(statusEditableDocsArr, function(obj) {
                        return (obj.DocStatus ==BAM_COMMENTING_CONSTANT.Not_Accepted)
                    });

                    var docIdsArr = _.map(docListWithoutAcceptedStatus, function(obj) {
                        return obj.DocStatus ? obj.DocumentRevisionId : ""
                    });

                    var resetDocArray = docIdsArr.filter(function(val) {
                        return commentedDocsArr.indexOf(val) == -1;
                    });
                    if (resetDocArray.length) {
                        for (var i = 0; i < resetDocArray.length; i++) {
                            if (resetDocArray[i]) {
                                resetDocStatus(resetDocArray[i], true);
                            }
                        }
                    }
                }
            } else if (myform && commentLevel == BAM_COMMENTING_CONSTANT.Document) {
                if (deletedItem.Doc_ID) {
                    resetDocStatus(deletedItem.Doc_ID, true);
                }
            }
        }

        // Check if user hase Respond action or not
        var check_HasRespondAction = function() {
            var Xpnnode = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS");
            Xpnnode = commonApi._.findWhere(Xpnnode, {
                Name: "Respond"
            });
            if (!Xpnnode) {
                return;
            }

            var strincompleteactions_Old = Xpnnode.Value.trim();
            var Workinguserid = getWorkingUserId();
            if (strincompleteactions_Old) {                
                if (Workinguserid) {                    
                    var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                    if (Workinguserid && strincompleteactions_Old.indexOf(Workinguserid) > -1) {
                        oriMsgCustomFields['Warning']['Can_Reply'] = "YES";
                    } else {
                        oriMsgCustomFields['Warning']['Can_Reply'] = "NO";
                    }
                }
            }
        };

        //Update all previous responses as visible=NO 
        var setVisiblefield = function(i) {
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var nodes = resMsgCustomFields['All_Response']['Res_Info'];
            nodes = commonApi._.each(nodes, function(o) {
                if (o.Response_id <= i) {
                    o.visible = "NO";
                }
            });
        };

        var AddGeneral = function() {       

            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var Res_counter_LastValue = resMsgCustomFields['Counters']['Res_counter'];
            var i = 0;
            var lastCycleNo = resMsgCustomFields['Counters']['LastCycleNo'];          
            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";

            var strUserid = "";
            if (strWORKINGUSER.length > 1)
                strUserid = strWORKINGUSER.split('#')[1];

            var strRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
            strRoles = strRoles[0] || {};
            strRoles = strRoles.Value || "";

            var strUser = strWORKINGUSER.split('|')[0].trim() + " # " + strUserid.trim();

            //NOODLE-48494 Removed workspace role and used stored roles in repeating tables at form creation time.
            var xpniRoleNode = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] || [];
            xpniRoleNode = commonApi._.filter(xpniRoleNode, function(o) {
                return (strUser && o.User.indexOf(strUser) > -1);
            })[0];

            if (xpniRoleNode) {
                strRoles = xpniRoleNode.Role;
            }

            var xpnRoleNode = oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'];
            xpnRoleNode = commonApi._.filter(xpnRoleNode, function(o) {
                return (strUser && o.UserId.indexOf(strUser) > -1);
            })[0];

            if (xpnRoleNode) {
                strRoles = xpnRoleNode.UserRole;
            }

            setVisiblefield(Res_counter_LastValue);
            var nodeDistribution = resMsgCustomFields['All_Response']['Res_Info'];
            var Res_counter = resMsgCustomFields['Counters']['Res_counter'];
            var i = parseInt(Res_counter);

            var strGid = serverDate.getTime();
            i++;

            var resInfoObj = angular.copy(STATIC_OBJ_DATA['Res_Info']);
            $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['LastUID'] = strGid;
            resInfoObj.UID = strGid;
            resInfoObj.Response_id = i;
            resInfoObj.ResponseBy = strWORKINGUSER;
            resInfoObj.Res_Date = $scope.formatDate(serverDate, 'dd/mm/yy');
            resInfoObj.UserAllRoles = strRoles;
            resInfoObj.visible = "YES";
            resInfoObj.CycleNo = lastCycleNo;

            if (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1) {
                resInfoObj.RCRES_Reviewer_id = strWORKINGUSER;
                resInfoObj.CommentBY = "Review Coordinator :" + strUserid;
            } else {
                if (strRoles.indexOf("TIG") > -1) {
                    resInfoObj.CommentBY = "TIG :" + strUserid;
                } else {
                    resInfoObj.CommentBY = "Reviewer :" + strUserid;
                }
            }
            resInfoObj.All_Comments.Comments_Info[0].UID = strGid;
            resInfoObj.All_Comments.Comments_Info[0].Ref_Res_Id = i;
            resInfoObj.All_Comments.Comments_Info[0].Idx = 1;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].UID = strGid;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].Ref_Res_Id = i;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].Idx = 1;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].Id = 1;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].IsOpenClose = "Open";
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].CommentGroup.RepeatCommentGroup[0].UID = strGid;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].CommentGroup.RepeatCommentGroup[0].Ref_Res_Id = i;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].CommentGroup.RepeatCommentGroup[0].Idx = 1;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].CommentGroup.RepeatCommentGroup[0].Id = 1;
            resInfoObj.All_Comments.Comments_Info[0].Multicomment.MultiComment_info[0].CommentGroup.RepeatCommentGroup[0].RepeatComment_Id = 1;

            nodeDistribution.push(resInfoObj);
            applyCommentInfoWatch(resInfoObj);

            resMsgCustomFields['Counters']['comment_ctr'] = "1";
            resMsgCustomFields['Counters']['Res_counter'] = i + "";
            resMsgCustomFields['Counters']['Id_ctr'] = "1";

            SetRepeatComment_Counter(1, 1, true);
        };

        // Fill all document in repeating table from SP
        var fillNode = function(loopNode, type) {
            // insert
            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['Associate_Doc']['Associate_Docs'].push({
                WorkSpace_Id: loopNode.Value1 || "",
                WorkSpaceName: loopNode.Value2 || "",
                Form_ID: loopNode.Value3 || "",
                DocFolderID: loopNode.Value4 || "",
                DocFolderName: loopNode.Value5 || "",
                Doc_Id: loopNode.Value6 || "",
                FileName: loopNode.Value7 || "",                
                DocRef: loopNode.Value8 || type,
                Rev: loopNode.Value9 || "",
                DocTitle: loopNode.Value10 || "",
                DocStatus: "",
                IsDocument_Package: type,
                PurposeOfIssue: loopNode.Value11 || "",                
                MainDocStatus: loopNode.Value12 || "",
                URL: loopNode.Value21 || "",
                RevisionCounter: loopNode.Value23 || "",
                DocumentRevisionId: loopNode.Value24 || "",
                CommentingRaisedOn:loopNode.Value25 || ""
            });
        };

        // Fill all document in repeating table from SP &  one node for Package
        var FillDocData = function(assocData) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            if (!(oriMsgCustomFields['Associate_Doc']['Associate_Docs'][0] || {})
                .DocRef) {
                oriMsgCustomFields['Associate_Doc']['Associate_Docs'] = commonApi._.rest(oriMsgCustomFields['Associate_Doc']['Associate_Docs']);
            }
            var AllNodesMainDS = $scope.getValueOfOnLoadData("DS_ASSOC_FORM_ASSOCDOCS_METADATA") || [];
            if (!assocData && !AllNodesMainDS.length) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_ASSOC_FORM_ASSOCDOCS_METADATA",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASSOC_FORM_ASSOCDOCS_METADATA",
                            "fieldValue": $scope.oriMsgCustomFields["DS_GET_ASSOC_FIELD"]
                        }]
                    }
                };

                $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA = $scope.getValueOfOnLoadData("DS_ASSOC_FORM_ASSOCDOCS_METADATA");
                $scope.requests['DS_ASSOC_FORM_ASSOCDOCS_METADATA'] = true;
                $scope.add({
                    name: "DS_ASSOC_FORM_ASSOCDOCS_METADATA",
                    status: "incomplete"
                });

                $scope.getCallbackData(form)
                    .then(function(response) {
                        $scope.requests['DS_ASSOC_FORM_ASSOCDOCS_METADATA'] = false;
                        $scope.update({
                            name: "DS_ASSOC_FORM_ASSOCDOCS_METADATA",
                            status: "completed"
                        });

                        if (response.data) {
                            var dSAssocFormAssocDocsMetaData = JSON.parse(response.data['DS_ASSOC_FORM_ASSOCDOCS_METADATA']);
                            $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA = dSAssocFormAssocDocsMetaData['Items']["Item"];
                            FillDocData($scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA);
                        }
                        AutoSetPackageStatus();
                    });
                return;
            }
            if (assocData)
                AllNodesMainDS = assocData;
            var AllNodesAssoDocs = oriMsgCustomFields['Associate_Doc']['Associate_Docs'];
            if (AllNodesAssoDocs.length) {
                for (var i = 0; i < AllNodesMainDS.length; i++) {
                    var loopNode = AllNodesMainDS[i];
                    if (loopNode.Name) {
                        if (!commonApi._.some(AllNodesAssoDocs, function(o) {
                                return (o.Doc_Id == loopNode.Value6);
                            })) {
                            fillNode(loopNode, BAM_COMMENTING_CONSTANT.Document);
                        }
                    }
                }
            } else {
                for (var i = 0; i < AllNodesMainDS.length; i++) {
                    var loopNode = AllNodesMainDS[i];
                    if (loopNode.Name) {
                        fillNode(loopNode, BAM_COMMENTING_CONSTANT.Document);
                    }
                }

                // Add one node for package....
                fillNode({
                    Value1: "",
                    Value2: "",
                    Value3: "",
                    Value4: "",
                    Value5: "",
                    Value6: "",
                    Value7: "",
                    Value8: BAM_COMMENTING_CONSTANT.Package,
                    Value9: oriMsgCustomFields['Package_Revision_No'],
                    Value10: oriMsgCustomFields['PackageNumber'],
                    DocStatus: "",
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Package,
                    Value11: oriMsgCustomFields['Package_Submission_Purpose'],
                    Value12: "",
                    Value21: "",
                    Value23: "-"
                }, BAM_COMMENTING_CONSTANT.Package);

                AutoSetPackageStatus();
            }
        };

        var AddOldValuesForDCUserModification = function(AllUserListForDcChangeList) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            if (AllUserListForDcChangeList[0].Value == "Not Allowed") {
                oriMsgCustomFields['Warning']['NoCreateAccess'] = " 0 # You cannot replace any existing user at this stage for this commenting form.";
                return;
            }

            for (var i = 0; i < AllUserListForDcChangeList.length; i++) {
                var validUser = AllUserListForDcChangeList[i].Value;
                var userRole = validUser.split('|')[1].trim();
                var userName = validUser; 

                if (userRole == "RC") {
                    oriMsgCustomFields["DC_Users_List"]["RC_Role"]["Can_DC_Change_RC"] = true;
                    oriMsgCustomFields["DC_Users_List"]["RC_Role"]["RC_Prev_Name"] = userName;
                } else if (userRole == "TA") {
                    oriMsgCustomFields["DC_Users_List"]["TA_Role"]["Can_DC_Change_TA"] = true;
                    oriMsgCustomFields["DC_Users_List"]["TA_Role"]["TA_Prev_Name"] = userName;
                } else if (userRole == "PM" || userRole == "PMTA") {
                    oriMsgCustomFields["DC_Users_List"]["PM_Role"]["Can_DC_Change_PM"] = true;
                    oriMsgCustomFields["DC_Users_List"]["PM_Role"]["PM_Prev_Name"] = userName;
                } else if (userRole == "CONT") {
                    oriMsgCustomFields["DC_Users_List"]["Contractor_Role"]["Can_DC_Change_Contractor"] = true;
                    oriMsgCustomFields["DC_Users_List"]["Contractor_Role"]["Contractor_Prev_Name"] = userName;
                }
            }
        }

        //NOODLE-85405 two restriction added, 2. Only RC And PM can respond to contractor response - draft scenerio. ptahiliani 25-01-2019 - code starts
        function checkUserIsPMorRCAfterContractorResponse() {
            var allRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
            var allPMRoleUsers=[];
            if (allRoles.length) {
                for (var i = 0; i < allRoles.length; i++) {
                    var loop = allRoles[i];
                    if (loop.Value.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1) {
                    allPMRoleUsers.push(loop);
                    }
                }
            }     
            var allRCRoleUsers=[];
            if (allRoles.length) {
                for (var i = 0; i < allRoles.length; i++) {
                    var loop = allRoles[i];
                    if (loop.Value.indexOf("Review Coordinator") > -1) {
                        allRCRoleUsers.push(loop);
                    }
                }
            }          
            var strCurrentStage = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['CurrentStage'];
            if (strCurrentStage == "4") {                
                var strWorkingId = getWorkingUserId();
                var PMFlag = false;
                var RCFlag = false;
                if (allPMRoleUsers && allPMRoleUsers.length) {
                    for (var i = 0; i < allPMRoleUsers.length; i++) {
                        var id = allPMRoleUsers[i].Value && allPMRoleUsers[i].Value.split("|")[2].split("#")[0].trim();
                        if (id == strWorkingId) {
                            PMFlag = true;
                        }
                    }
                }
                if (allRCRoleUsers && allRCRoleUsers.length) {
                    for (var i = 0; i < allRCRoleUsers.length; i++) {
                        var id = allRCRoleUsers[i].Value && allRCRoleUsers[i].Value.split("|")[2].split("#")[0].trim();
                        if (id == strWorkingId) {
                            RCFlag = true;
                        }
                    }
                }
                if (PMFlag == true || RCFlag == true) {
                    $scope.RestrictOtherUserExceptPMandRcFlag = false;
                } else {
                    $scope.RestrictOtherUserExceptPMandRcFlag = true;
                }
            }
        }
        //NOODLE-85405 two restriction added, 2. Only RC And PM can respond to contractor response - draft scenerio. ptahiliani 25-01-2019 - code ends

        // Add blank nodes or copies all nodes Stage Wise ( DC(Stage-0)--->
        var AddBlankResponseNode = function() {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var PM_Contractor_Comm = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['PM_Contractor_Comm']['PM_CON_Com_details'];
            if (PM_Contractor_Comm.length) {
                for (var i = 0; i < PM_Contractor_Comm.length; i++) {
                    var ContractorComment = PM_Contractor_Comm[0].Sub_Con_Res_comments;
                }
            }
            asiteSystemDataReadWrite['Auto_Distribution_Actions']['Auto_Distribute_Action'] = [];
            asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];

            var strLastStage = oriMsgCustomFields['LastStage'];
            var SubConGroupSelected = oriMsgCustomFields['Sub_ContractorDistGroupInfo'];
            // remove all object from Res_Info except first object.
            resMsgCustomFields['All_Response']['Res_Info'] = resMsgCustomFields['All_Response']['Res_Info'] || [];

            if (!(resMsgCustomFields['All_Response']['Res_Info'][0] || {}).Response_id) {
                resMsgCustomFields['All_Response']['Res_Info'] = commonApi._.rest(resMsgCustomFields['All_Response']['Res_Info']);
            }

            var PM_APPROVE_COMMENTS = resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'];
            var TA_RES = resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_Status'];
            var allRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
            allRoles = allRoles[0] || {};
            allRoles = allRoles.Value || "";

            var SendToSubContractorValidation = oriMsgCustomFields['is_Sub_Contractor_Required'];            
            var strRC_Send_To = resMsgCustomFields['All_Response']['Selected_Tech_Autho']['RC_Send_To'].trim();
            var disGroup = resMsgCustomFields['DisplayGroup'];
            $scope.isRCforHideReviewer = true; // FOR NOODLE-60083
            disGroup['Dis_flag_RC_section'] = "NO";
            disGroup['Dis_flag_TA_Section'] = "NO";
            disGroup['Dis_Flag_PM_section'] = "NO";
            disGroup['Flag_ToDisplay_PMRES'] = "NO";
            disGroup['Flag_ToDisplay_CONTRES'] = "NO";
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";

            // Get RC role from Stored value
            var strUser = strWORKINGUSER.split('|')[0].trim() + " # " + (strWORKINGUSER.split('#')[1] || "").trim();
            var userInfo = oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'] || [];
            var xpnRoleNode = commonApi._.filter(userInfo, function(o) {
                return (strUser && o.UserId.indexOf(strUser) > -1);
            })[0];
            var strRCRole = "";
            if (xpnRoleNode) {
                strRCRole = xpnRoleNode.UserRole;
            }

            var strPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strPM = strPMArr[0] && strPMArr[0]['PMName'] || "";

            if (!strPM) {
                var selectedPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                strPM = selectedPMArr[0] && selectedPMArr[0]['PMName'] || "";
            }

            // RC View First Time
            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";

            var strDSFormStatus = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];

            var strTAArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strTA = strTAArr[0] && strTAArr[0]['TAName'] || "";

            // var strContractor = resMsgCustomFields['All_Response']['PM_Response']['Contractor'];
            var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strContractor = strContractorArr[0] && strContractorArr[0]['ContractorName'] || "";
            //Added by Nihil to check working user is sub contractor user or not            
            $scope.isSubContractor = getIsSubContractorUser();
            //End Nihil
            //NOODLE-85405 two restriction added, if unAuthorise user have full view load restrict. ptahiliani 17-01-2019 - code starts

            var checkUserHaveRespondOrNot = $scope.getValueOfOnLoadData("DS_IS_USER_ACTION_INCOMPLETE") || [];

            if (checkUserHaveRespondOrNot && checkUserHaveRespondOrNot.length && checkUserHaveRespondOrNot[0].Value == "N") {
                $scope.oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strPendingAction;
            } else {
                $scope.oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
            }

            if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Review_in_Progress && (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1)) {
                $scope.add({
                    name: "getJsonFromXmlLoaderTask",
                    status: "incomplete"
                });
                GetdataFromSP(function() {
                    AddEditNodeForRC1(strRCRole);

                    FillDocData();
                    setCommentLevelPreviousValue(); 
                    oriMsgCustomFields['CurrentStage'] = "2";
                    resMsgCustomFields['DisplayGroup']['Dis_flag_RC_section'] = "YES";
                    
                    //For readonly section of RC Response-view
                    $scope.Res_Info_Copy = resMsgCustomFields['All_Response']['Res_Info']
                    asiteSystemDataReadWrite['DS_AUTOCOMPLETE_ACTION_SAVE_DRAFT'] = "True";

                    asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    ClearActionbyMsg(); //ClearAction("CLEAR_FOR_RC");
                    $timeout(function() {
                        $scope.expandTextAreaOnLoad();
                    }, 10);
                    $scope.update({
                        name: "getJsonFromXmlLoaderTask",
                        status: "completed"
                    });
                });
            }
            //ReviewCoordinator View ( PM send back to RC)
            else if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Further_Review_in_Progress && (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1) && strLastStage == "4") {
                resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_comments'] = "";
                if (!$scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TIG_Response']) {
                    $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TIG_Response'] = {};
                }
                resMsgCustomFields['All_Response']['TIG_Response']['TIG_Remarks'] = "";
                AddEditNodeForRC_RecycleFromTA();

                FillDocData();
                setCommentLevelPreviousValue();

                oriMsgCustomFields['CurrentStage'] = "2";
                resMsgCustomFields['DisplayGroup']['Dis_flag_RC_section'] = "YES";
                
            }
            //ReviewCoordinator View ( TA send back to RC)
            else if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Further_Review_in_Progress && (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1) && strLastStage == "3") {
                AddEditNodeForRC_RecycleFromTA();

                FillDocData();
                setCommentLevelPreviousValue();

                oriMsgCustomFields['CurrentStage'] = "2";
                resMsgCustomFields['DisplayGroup']['Dis_flag_RC_section'] = "YES";
                
            }
            //Technical Authoriser(TA) View (RC send to  TA )
            else if (strDSFormStatus.indexOf("Sent to TA") > -1 && strTA) {
                var strTATemp = "";
                if (strTA.split('|')[2]) {
                    strTATemp = strTA.split('|')[2].split('#')[0].trim()
                } else {
                    strTATemp = strTA.split('#')[0].trim();
                }

                if ((strTATemp && strWORKINGUSER.indexOf(strTATemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Technical_Authoriser) > -1) {
                    AddEditNodeForTA();

                    FillDocData();
                    setCommentLevelPreviousValue();

                    oriMsgCustomFields['CurrentStage'] = "3";
                    resMsgCustomFields['DisplayGroup']['Dis_flag_TA_Section'] = "YES";
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }
            //Project Manager(PM) View (RC send to  PM || TA send to PM )
            else if ($scope.isSubContractor == "No" && strPM && (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM) > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1)) {
                var strPMTemp = "";
                if (strPM.split('|')[2]) {
                    strPMTemp = strPM.split('|')[2].split('#')[0].trim();
                } else {
                    strPMTemp = strPM.split('#')[0].trim();
                }

                if ((strPMTemp && strWORKINGUSER.indexOf(strPMTemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1) {
                    var iPMCnt = 0,
                        iContCnt = 0;
                    SetRepeatComment_Counter(iPMCnt, iContCnt, true);

                    if (!resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'].length) {
                        resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'].push({
                            PM_Res_comments: "",
                            Contractor_Review_comments: ""
                        });
                    }

                    oriMsgCustomFields['CurrentStage'] = "4";
                    resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'] = "YES";
                    resMsgCustomFields['All_Response']['PM_Response']['PM_Res_by'] = strWORKINGUSER;

                    checkUserIsPMorRCAfterContractorResponse();
                    FillDocData();
                    setCommentLevelPreviousValue();
                    AddEditNodeForPM();
                    SendActionInPkgForm();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }
            //Project Manager(PM) View (RC send to  PM || TA send to PM || contractor send to RC ) -- SETUP FORM (SEND TO REVIEW COORDINATOR LOGIC)
            else if ($scope.isSubContractor == "No" && SendToSubContractorValidation == "Yes" && ContractorComment != "" && strPM && (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM) > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1 || strLastStage == "5")) {
                var strPMTemp = "";
                if (strPM.split('|')[2]) {
                    strPMTemp = strPM.split('|')[2].split('#')[0].trim();
                } else {
                    strPMTemp = strPM.split('#')[0].trim();
                }

                if (((strPMTemp && strWORKINGUSER.indexOf(strPMTemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1) || (strLastStage == "5" && (strDSFormStatus.indexOf("Accepted With Comments") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1))) {
                    // NOODLE42232 --Add PM and contractor Communication blank node
                    if (!PM_APPROVE_COMMENTS) {
                        resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'] = commonApi._.rest(resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details']);
                    }

                    resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'].push({
                        PM_Res_comments: "",
                        Contractor_Review_comments: ""
                    });

                    if (strLastStage == "5") {
                        resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_PMRES'] = "YES";
                        if ($scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] == "" && (strDSFormStatus.indexOf("Accepted With Comments") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1)) {
                            SetStatus(strDSFormStatus);
                            $scope.On_DS_ALL_FORMSTATUS_changed();
                        }
                    }

                    oriMsgCustomFields['CurrentStage'] = "4";
                    resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'] = "YES";
                    checkUserIsPMorRCAfterContractorResponse();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }

            //Project Manager(PM) View (RC send to  PM || TA send to PM || contractor send to RC )
            else if (strPM && SendToSubContractorValidation == "No" && (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM) > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1 || strLastStage == "5")) {
                var strPMTemp = "";
                if (strPM.split('|')[2]) {
                    strPMTemp = strPM.split('|')[2].split('#')[0].trim();
                } else {
                    strPMTemp = strPM.split('#')[0].trim();
                }

                if (((strPMTemp && strWORKINGUSER.indexOf(strPMTemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1) || (strLastStage == "5" && (strDSFormStatus.indexOf("Accepted With Comments") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1))) {
                    // NOODLE42232 --Add PM and contractor Communication blank node
                    if (!PM_APPROVE_COMMENTS) {
                        resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'] = commonApi._.rest(resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details']);
                    }

                    resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'].push({
                        PM_Res_comments: "",
                        Contractor_Review_comments: ""
                    });

                    if (strLastStage == "5") {
                        resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_PMRES'] = "YES";
                        if ($scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] == "" && (strDSFormStatus.indexOf("Accepted With Comments") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1)) {
                            SetStatus(strDSFormStatus);
                            $scope.On_DS_ALL_FORMSTATUS_changed();
                        }
                    }

                    oriMsgCustomFields['CurrentStage'] = "4";
                    resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'] = "YES";
                    checkUserIsPMorRCAfterContractorResponse();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }
            //Contractor View  -- SETUP FORM (SEND TO REVIEW COORDINATOR LOGIC)
            else if (SendToSubContractorValidation == "No" && strContractor != "" && (strLastStage == "4") && (PM_APPROVE_COMMENTS == "YES")) {
                var strContractorTemp = "";
                if (strContractor.split('|')[2]) {
                    strContractorTemp = strContractor.split('|')[2].split('#')[0].trim();
                } else {
                    strContractorTemp = strContractor.split('#')[0].trim();
                }
                //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
                var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                var strWorkingUserId = strWORKINGUSER.split('|')[0].trim() || "";
                var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                if ((strContractorTemp && strWORKINGUSER.indexOf(strContractorTemp) > -1) || allRoles.indexOf("Contractor") > -1 || (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES")) {
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
                    oriMsgCustomFields['CurrentStage'] = "5";
                    resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_CONTRES'] = "YES";
                    $scope.On_Contractor_Review_comments_Changed();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }
            //Contractor View 
            else if ($scope.isSubContractor == "No" && SendToSubContractorValidation == "Yes" && strContractor != "" && (strLastStage == "4" || strLastStage == "5" || strLastStage == "6") && (PM_APPROVE_COMMENTS == "YES")) {
                var strContractorTemp = "";
                var ConResCount= $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['Contractor_Res_Count'];    
                var intcount=ConResCount;           ;
                if (strContractor.split('|')[2]) {
                    strContractorTemp = strContractor.split('|')[2].split('#')[0].trim();
                } else {
                    strContractorTemp = strContractor.split('#')[0].trim();
                }
                //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
                var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                var strWorkingUserId = strWORKINGUSER.split('|')[0].trim() || "";
                var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                if ((strContractorTemp && strWORKINGUSER.indexOf(strContractorTemp) > -1) || allRoles.indexOf("Contractor") > -1 || (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES")) {
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
                    oriMsgCustomFields['CurrentStage'] = "5";
                    intcount++;
                    resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_CONTRES'] = "YES";
                    $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['Contractor_Res_Count'] = intcount.toString();
                    $scope.On_Contractor_Review_comments_Changed();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            }
            //Added by Nihil to show sub contractor section when sub contractor respond
            else if ($scope.isSubContractor == "Yes" && (SendToSubContractorValidation == "Yes")) {
                var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                var strWorkingUserId = strWORKINGUSER.split('|')[0].trim() || "";
                var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                if ($scope.isSubContractor == "Yes" || allRoles.indexOf("Sub") > -1 || (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES")) {
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
                    oriMsgCustomFields['CurrentStage'] = "6";
                    resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_CONTRES'] = "YES";
                    AddNodesToDistibuteSubCon();
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                }
            } else {
                if (strReviewCoordinatorUser != "") {
                    if (strLastStage == "0" && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) == -1) {
                        AddGeneral();

                        oriMsgCustomFields['CurrentStage'] = "0";
                        resMsgCustomFields['DisplayGroup']['Flag_NoComment_Level'] = "";
                        resMsgCustomFields['DisplayGroup']['Flag_Pkg_Doc_Comment_Level'] = "";
                        
                    } else {
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorised;
                    }
                }
            }

            $scope.isRCforHideReviewer = false;
        };

        // This function gets all Response using sp=DS_ASI_CMB_RESPONSE_DATA and find all the response which are unique (using "my:UID")
        var GetdataFromSP = function(callback) {
            var AllNodes = $scope.getValueOfOnLoadData('DS_ASI_CMB_RESPONSE_DATA') || [];
            if (!AllNodes.length) {
                callback && callback();
                return;
            }

            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var paramStr = "";
            var isDCUserChangeArr = [];
            for (var i = 0; i < AllNodes.length; i++) {
                paramStr += AllNodes[i].Value3;
                if (AllNodes[i].Value4) {
                    isDCUserChangeArr.push(AllNodes[i].Value4);
                }
            }
            commonApi.ajax({
                    url: (window.adoddleBaseUrl || "") + "/commonapi/htmlForm/getJsonFromXml",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "xmlData=" + encodeURIComponent(paramStr)
                })
                .then(function(response) {
                    var strData = response.data;
                    strData = JSON.stringify(strData);
                    strData = strData.replace(/{"@xsi:nil":true}/g, '""');
                    strData = JSON.parse(strData);
                    if (strData.All_Response) {
                        resMsgCustomFields['All_Response']['Res_Info'] = [];

                        if (angular.isArray(strData.All_Response)) {
                            for (var i = 0; i < strData.All_Response.length; i++) {
                                var resObj = strData.All_Response[i];
                                var currVisibleResInfo = commonApi._.find(resObj['Res_Info'], function(resInfo) {
                                    return (resInfo.visible == "YES");
                                });
                                if (!currVisibleResInfo) {
                                    continue;
                                }
                                if (isDCUserChangeArr[i] == "false") { //Add only if not DC
                                    resMsgCustomFields['All_Response']['Res_Info'].push(currVisibleResInfo);
                                }
                            }
                            applyAllCommentInfoWatch();
                        } else {
                            resMsgCustomFields['All_Response']['Res_Info'] = commonApi._.union(resMsgCustomFields['All_Response']['Res_Info'], strData['All_Response']['Res_Info']);
                            applyAllCommentInfoWatch();
                        }
                    }
                    //CG : MULTIPLE NO COMMENT & MORE THAN ONE Res_Info VISIBLE = "YES" ISSUE 
                    for (var oldResCnt = 0; oldResCnt <= resMsgCustomFields['All_Response']['Res_Info'].length - 1; oldResCnt++) {
                        resMsgCustomFields['All_Response']['Res_Info'][oldResCnt].visible = "NO";
                    }
                    callback && callback();

                }, function() {
                    // error
                });
        };

        //This function copies all reponse of Lead Reviewers and TIG and create Nodes for RC 
        var AddEditNodeForRC1 = function(roles) {
            SetRepeatComment_Counter(0, 0, true);
            FillAllRESXML("Review Coordinator :", "Condition1", roles);
        };

        var SetRepeatComment_Counter = function(iPMCnt, iContCount, isSetCounter) {
            var strData = iPMCnt + "#" + iContCount;
            if (isSetCounter) {
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['Counters']['RepeatComment_Counter'] = strData;
            }
            strData = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['Counters']['RepeatComment_Counter'];
            var strCnt = strData.split('#');
            iPMCnt = parseInt(strCnt[0]);
            if (strCnt.length > 0) {
                iContCount = parseInt(strCnt[1]);
            }

            return [iPMCnt, iContCount];
        };

        //This function used to create XML of my:All_Comments
        var FillAllCommentsXML = function(NewResponseId, GUID, Roles, Condition, resInfo, hstNew) {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var strResponseby = resInfo.ResponseBy.replace("$$$", "#")
                .split('#')[1].trim();
            var strCurrentStage = oriMsgCustomFields['CurrentStage'];
            var strLastStage = oriMsgCustomFields['LastStage'];
            var strDis_Flag_PM_section = resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'];
            var allRoles = Roles;

            var AllcommentNodes = resInfo['All_Comments']['Comments_Info'];
            var iPMCnt = 0,
                iContCount = 0;
            var cntArray = SetRepeatComment_Counter(iPMCnt, iContCount, false);
            iPMCnt = cntArray[0];
            iContCount = cntArray[1];            
            var strWorkingUserName = $scope.workingUserDetails[0].Name || "";
            
            if (AllcommentNodes.length) {
                var j = 0;
                var k = 0;

                resMsgCustomFields['Counters']['comment_ctr'] = j + "";
                for (var l = 0; l < AllcommentNodes.length; l++) {
                    var loopNodeComment = AllcommentNodes[l];

                    if (loopNodeComment.Ref_Res_Id) {
                        var comment_ctr = resMsgCustomFields['Counters']['comment_ctr'];
                        j = comment_ctr;
                        j++;
                        var AllMulticomments = loopNodeComment['Multicomment']['MultiComment_info'];
                        var strDocId = loopNodeComment['Doc_ID'];
                        var strComment_Level = loopNodeComment['Comment_Level'];
                        var strGUID = loopNodeComment.UID;

                        if ((hstNew.hasOwnProperty(strDocId) && strComment_Level.toLowerCase() == "document") || (!strDocId && hstNew.hasOwnProperty(strComment_Level))) {
                            // childcomment If Document is available
                            if (AllMulticomments.length) {
                                for (var m = 0; m < AllMulticomments.length; m++) {
                                    var loopNodeMultiComment = AllMulticomments[m];
                                    var Id_ctr = resMsgCustomFields['Counters']['Id_ctr'];
                                    k = parseInt(Id_ctr) || k;
                                    k++;

                                    var multiCommentInfoObj = angular.copy(STATIC_OBJ_DATA['multiCommentInfo']);

                                    multiCommentInfoObj.UID = GUID;
                                    multiCommentInfoObj.Ref_Res_Id = NewResponseId;
                                    multiCommentInfoObj.Idx = j;
                                    multiCommentInfoObj.Id = k;
                                    multiCommentInfoObj.Severity = loopNodeMultiComment.Severity;

                                    if (Condition == "Condition1")
                                        multiCommentInfoObj.ReviewerName = strResponseby;
                                    else
                                        multiCommentInfoObj.ReviewerName = loopNodeMultiComment.ReviewerName;

                                    multiCommentInfoObj.IsOpenClose = "Open";
                                    multiCommentInfoObj.Ref_Responseby = strResponseby;

                                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup = [];

                                    var AllRepeatCommentGroup = loopNodeMultiComment['CommentGroup']['RepeatCommentGroup'];
                                    if (AllRepeatCommentGroup.length) {
                                        for (var n = 0; n < AllRepeatCommentGroup.length; n++) {
                                            var loopNodeRepeatGroup = AllRepeatCommentGroup[n];
                                            if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4") {
                                                iPMCnt++;
                                            }

                                            var repeatCommentGroup = angular.copy(STATIC_OBJ_DATA['repeatCommentGroup']);
                                            repeatCommentGroup.UID = GUID;
                                            repeatCommentGroup.Ref_Res_Id = NewResponseId;
                                            repeatCommentGroup.Idx = j;
                                            repeatCommentGroup.Id = k;

                                            if (strCurrentStage == "5") {
                                                iContCount++;
                                                repeatCommentGroup.RepeatComment_Id = "C" + iContCount;
                                            } else {
                                                repeatCommentGroup.RepeatComment_Id = iPMCnt;
                                            }

                                            var strCommentData = loopNodeRepeatGroup.Comment;
                                            if (strCommentData.trim()
                                                .indexOf("amp;") > -1) {
                                                strCommentData = strCommentData.Replace("amp;", "");
                                                repeatCommentGroup.Comment = strCommentData;
                                            } else {
                                                repeatCommentGroup.Comment = strCommentData;
                                            }

                                            repeatCommentGroup.comment_against = loopNodeRepeatGroup.comment_against;
                                            repeatCommentGroup.CommentBy = allRoles;

                                            if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4")
                                            {
                                                repeatCommentGroup.Label = "PM";
                                                repeatCommentGroup.PM_Name=strWorkingUserName;
                                            }
                                                
                                            else if (strCurrentStage == "5")
                                            {
                                                repeatCommentGroup.Label =strWorkingUserName;
                                            }
                                                

                                            multiCommentInfoObj.CommentGroup.RepeatCommentGroup.push(repeatCommentGroup);
                                        }
                                    }

                                    resMsgCustomFields['Counters']['Id_ctr'] = k + "";
                                    if (!strDocId) {
                                        hstNew[strComment_Level][0].Multicomment.MultiComment_info.push(multiCommentInfoObj);
                                    } else {
                                        hstNew[strDocId][0].Multicomment.MultiComment_info.push(multiCommentInfoObj);
                                    }
                                }
                            }
                        } else {
                            //If Document is New (Create node for New Doc/Package)
                            var Comments_Info = angular.copy(STATIC_OBJ_DATA['Comments_Info']);

                            Comments_Info.UID = GUID;
                            Comments_Info.Ref_Res_Id = NewResponseId;
                            Comments_Info.Idx = j;
                            Comments_Info.Doc_ID = loopNodeComment.Doc_ID;
                            Comments_Info.Doc_Title = loopNodeComment.Doc_Title;
                            Comments_Info.Doc_status = loopNodeComment.Doc_status;
                            Comments_Info.DocFolder_Name = loopNodeComment.DocFolder_Name;
                            Comments_Info.Doc_FolderId = loopNodeComment.Doc_FolderId;
                            Comments_Info.Doc_Rev = loopNodeComment.Doc_Rev;
                            Comments_Info.DSI_Chk_Done = loopNodeComment.DSI_Chk_Done;
                            Comments_Info.Comment_Level = loopNodeComment.Comment_Level;
                            Comments_Info.Comment_Level_Prev_Value = loopNodeComment.Comment_Level;
                            Comments_Info.Doc_ref = loopNodeComment.Doc_ref;
                            Comments_Info.Multicomment.MultiComment_info = [];

                            var AllMulticomments = loopNodeComment['Multicomment']['MultiComment_info'];
                            if (AllMulticomments.length) {
                                for (var m = 0; m < AllMulticomments.length; m++) {
                                    var loopNodeMultiComment = AllMulticomments[m];
                                    var Id_ctr = resMsgCustomFields['Counters']['Id_ctr'];
                                    k = Id_ctr;
                                    k++;

                                    var multiCommentInfoObj = angular.copy(STATIC_OBJ_DATA['multiCommentInfo']);

                                    multiCommentInfoObj.UID = GUID;
                                    multiCommentInfoObj.Ref_Res_Id = NewResponseId;
                                    multiCommentInfoObj.Idx = j;
                                    multiCommentInfoObj.Id = k;
                                    multiCommentInfoObj.Severity = loopNodeMultiComment.Severity;

                                    if (Condition == "Condition1")
                                        multiCommentInfoObj.ReviewerName = strResponseby;
                                    else
                                        multiCommentInfoObj.ReviewerName = loopNodeMultiComment.ReviewerName;

                                    multiCommentInfoObj.IsOpenClose = "Open";
                                    multiCommentInfoObj.Ref_Responseby = strResponseby;

                                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup = [];

                                    var AllRepeatCommentGroup = loopNodeMultiComment['CommentGroup']['RepeatCommentGroup'];
                                    if (AllRepeatCommentGroup.length > 0) {
                                        for (var n = 0; n < AllRepeatCommentGroup.length; n++) {
                                            var loopNodeRepeatGroup = AllRepeatCommentGroup[n];
                                            var repeatCommentGroup = angular.copy(STATIC_OBJ_DATA['repeatCommentGroup']);

                                            repeatCommentGroup.UID = GUID;
                                            repeatCommentGroup.Ref_Res_Id = NewResponseId;
                                            repeatCommentGroup.Idx = j;
                                            repeatCommentGroup.Id = k;

                                            if (strCurrentStage == "5") {
                                                iContCount++;
                                                repeatCommentGroup.RepeatComment_Id = "C" + iContCount;
                                            } else {
                                                repeatCommentGroup.RepeatComment_Id = iPMCnt;
                                            }

                                            var strCommentData = loopNodeRepeatGroup.Comment;
                                            if (strCommentData.trim()
                                                .indexOf("amp;") > -1) {
                                                strCommentData = strCommentData.Replace("amp;", "");
                                                repeatCommentGroup.Comment = strCommentData;
                                            } else {
                                                repeatCommentGroup.Comment = strCommentData;
                                            }

                                            repeatCommentGroup.comment_against = loopNodeRepeatGroup.comment_against;
                                            repeatCommentGroup.CommentBy = allRoles;

                                            if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4")
                                            {
                                                repeatCommentGroup.Label = "PM";
                                                repeatCommentGroup.PM_Name = strWorkingUserName;
                                            }
                                            else if (strCurrentStage == "5")
                                            {
                                                repeatCommentGroup.Label = strWorkingUserName;
                                                
                                            }                                              
                                            multiCommentInfoObj.CommentGroup.RepeatCommentGroup.push(repeatCommentGroup);
                                        }
                                    }
                                    resMsgCustomFields['Counters']['Id_ctr'] = k + "";
                                    Comments_Info.Multicomment.MultiComment_info.push(multiCommentInfoObj);
                                }
                            }
                            Comments_Info.Recommend.Recommend_Doc_Level = loopNodeComment.Recommend.Recommend_Doc_Level;
                            resMsgCustomFields['Counters']['comment_ctr'] = j + "";
                            if (!strDocId) {
                                strDocId = strComment_Level;
                            }
                            if (!hstNew[strDocId])
                                hstNew[strDocId] = [];

                            hstNew[strDocId].push(Comments_Info);
                        }
                    }
                }
            }

            SetRepeatComment_Counter(iPMCnt, iContCount, true);
            return hstNew;
        };

        //General Function for RES_INFO XML 
        var FillAllRESXML = function(Commentby, Condition, Roles) {

            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var iResCnt = 0;

            //NOODLE-48494 Removed workspace role and used stored roles in repeating tables at form creation time.
            var strRoles = Roles;            
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";
            var Res_counter_LastValue = resMsgCustomFields['Counters']['Res_counter'];
            var PM_APPROVE_COMMENTS = resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'];
            var TA_RES = resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_Status'];

            var AllnodesOfReviewers = null;
            if (Condition == "Condition1") {
                AllnodesOfReviewers = resMsgCustomFields['All_Response']['Res_Info'];
                AllnodesOfReviewers = commonApi._.filter(AllnodesOfReviewers, function(o) {
                    return (!o.RCRES_Reviewer_id && !o.TARES_RC_id && !o.PMRES_RC_id && !o.CONRES_PM_id);
                });
            } else {
                AllnodesOfReviewers = resMsgCustomFields['All_Response']['Res_Info'];
                AllnodesOfReviewers = commonApi._.filter(AllnodesOfReviewers, function(o) {
                    return (o.visible == "YES");
                });
            }
            AllnodesOfReviewers = commonApi._.uniq(AllnodesOfReviewers, function(o) {
                return o.UID;
            });
            //Remove if blank UID
            for (var j = 0; j < AllnodesOfReviewers.length; j++) {
                if (AllnodesOfReviewers[j].UID == "") {
                    AllnodesOfReviewers.splice(j, 1);
                }
            }

            if (AllnodesOfReviewers.length) {
            
                var blIsParentAdded = false;
                var strGid = serverDate.getTime();
                var commentInfo = {};
                var resInfoObj = angular.copy(STATIC_OBJ_DATA['Res_Info']);
                resInfoObj.All_Comments.Comments_Info = [];
                $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['LastUID'] = strGid;

                var strChild = [];
                var strNoComment = [];
                var strPackage = [];
                var blFoundOther = false;

                var Res_counter = resMsgCustomFields['Counters']['Res_counter'];
                iResCnt = parseInt(Res_counter);
                iResCnt++;

                for (var j = 0; j < AllnodesOfReviewers.length; j++) {
                    var loopNode = AllnodesOfReviewers[j];
                    var tmp_Response_id = loopNode.Response_id;
                    var old_GUID = loopNode.UID;

                    if (loopNode.Response_id && loopNode.ResponseBy) {
                        // find all comments and insert in to nodes
                        FillAllCommentsXML(iResCnt, strGid, strRoles, Condition, loopNode, commentInfo);

                        if (j == (AllnodesOfReviewers.length - 1)) {
                            for (var objKey in commentInfo) {

                                if (objKey.toLowerCase() == "no comment") {
                                    strNoComment = commonApi._.union(strNoComment, commentInfo[objKey]);
                                } else if (objKey.toLowerCase() == "package") {
                                    strPackage = commonApi._.union(strPackage, commentInfo[objKey]);
                                    blFoundOther = true;
                                } else {
                                    strChild = commonApi._.union(strChild, commentInfo[objKey]);
                                    blFoundOther = true;
                                }
                            }
                            if (!blFoundOther && strNoComment.length) {
                                strChild = strNoComment;
                            }

                            resInfoObj.All_Comments.Comments_Info = commonApi._.union(resInfoObj.All_Comments.Comments_Info, strChild, strPackage);
                            applyCommentInfoWatch(resInfoObj);
                        }

                        if (blIsParentAdded) {
                            continue;
                        }

                        resInfoObj.UID = strGid;
                        resInfoObj.Response_id = iResCnt;
                        resInfoObj.ResponseBy = strWORKINGUSER;
                        resInfoObj.Res_Date = $scope.formatDate(serverDate, 'dd/mm/yy');
                        resInfoObj.Response_Accepted = loopNode.Response_Accepted;
                        resInfoObj.UserAllRoles = strRoles;
                        resInfoObj.visible = "YES";

                        if (Condition == "Condition1") {
                            resInfoObj.RCRES_Reviewer_id = loopNode.ResponseBy.replace("$$$", "#");
                        } else {
                            resInfoObj.RCRES_Reviewer_id = loopNode.RCRES_Reviewer_id;
                        }

                        resInfoObj.CommentBY = Commentby + strWORKINGUSER.split('#')[1];

                        resMsgCustomFields['All_Response']['Res_Info'].push(resInfoObj);

                        blIsParentAdded = true;
                    }
                }

                setVisiblefield(Res_counter_LastValue);
            } else {
                AddGeneral();
            }
        };

        //This function is used to clear ORI/RES action of
        //NOODLE-89875 this function is editing if user change by DC and if RC and PM is same user and action should distribute ptahiliani 26-03-19 code starts
        var completeReviewCoordinatorAction = function() {
                $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
                var AppId = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];                
                var Workinguserid = getWorkingUserId();
                var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

                
                var rcActionNode = commonApi._.filter(incompleteActionsByMsg, function(obj) {
                    return obj.Value1 == Workinguserid && obj.Value4 == "Respond"
                });

                var strPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var Selected_Project_Manager = strPMArr[0] && strPMArr[0]['PMName'] || "";
                if (Selected_Project_Manager) {
                    var t_split = Selected_Project_Manager.split('|');
                    var autoDistUserID = "";
                    if (t_split[2]) {
                        autoDistUserID = t_split[2];
                    } else {
                        autoDistUserID = Selected_Project_Manager;
                    }
                    autoDistUserID = autoDistUserID.split('#')[0].trim();
                }

                var strTAArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var Technical_Authoriser = strTAArr[0] && strTAArr[0]['TAName'] || "";
                if (Technical_Authoriser) {
                    var t_split = Technical_Authoriser.split('|');
                    var autoDistUserID = "";
                    if (t_split[2]) {
                        autoDistUserID = t_split[2];
                    } else {
                        autoDistUserID = Technical_Authoriser;
                    }
                    autoDistUserID = autoDistUserID.split('#')[0].trim();
                }

                var allNodes = rcActionNode;
                rcActionNode = commonApi._.reject(allNodes, function(obj) {
                    return obj.Value1 == autoDistUserID
                });

                if (rcActionNode.length) {
                    for (var i = 0; i < rcActionNode.length; i++) {
                        var actionNode = rcActionNode[i];
                        var actionId = actionNode.Value3;
                        var clearORIorRES = "";
                        if (actionId.indexOf('ORI') > -1) {
                            clearORIorRES = "RC_CLEAR_ORI_ACTION";
                        } else {
                            clearORIorRES = "RC_CLEAR_RES_ACTION";
                        }

                        if (clearORIorRES == "RC_CLEAR_ORI_ACTION") {
                            $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                                DS_AC_TYPE: "complete",
                                DS_AC_FORM: AppId,
                                DS_AC_MSG_TYPE: "ORI",
                                DS_AC_USERID: Workinguserid,
                                DS_AC_ACTION: "3",
                                DS_AC_ACTION_REMARKS: "Action Completed"
                            });
                        } else if (clearORIorRES == "RC_CLEAR_RES_ACTION") {
                            $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                                DS_AC_TYPE: "complete",
                                DS_AC_FORM: AppId,
                                DS_AC_MSG_TYPE: "RES",
                                DS_AC_USERID: Workinguserid,
                                DS_AC_ACTION: "3",
                                DS_AC_ACTION_REMARKS: "Action Completed"
                            });
                        }
                    }
                }

            }
            //NOODLE-89875 this function is editing if user change by DC and if RC and PM is same user and action should distribute ptahiliani 26-03-19 code ends

        var setCommentLevelPreviousValue = function(resInfoArr) {
                //This function sets "Comment_Level_Prev_Value" from the same node value of "Comment_Level"

                var resInfo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'];
                for (var i = 0; i < resInfo.length; i++) {
                    var visibleResInfo = resInfo[i];
                    if (visibleResInfo.visible == "YES") {
                        var commentInfoArr = visibleResInfo['All_Comments']['Comments_Info'];
                        for (var j = 0; j < commentInfoArr.length; j++) {
                            var commentInfo = commentInfoArr[j];
                            resInfo[i]['All_Comments']['Comments_Info'][j].Comment_Level_Prev_Value = commentInfo.Comment_Level
                        }
                    }
                }
            }
            //
        var ClearActionbyMsg = function() {                
                var Workinguserid = getWorkingUserId();
                var allNodes = commonApi._.filter(incompleteActionsByMsg, {
                    Value4: "Respond"
                });

                var clearActionNodes = commonApi._.reject(allNodes, function(obj) {
                    return (obj.Value1 == Workinguserid)
                });

                
                var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
                var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

                if (clearActionNodes.length) {
                    if (!asiteSystemDataReadWrite['Auto_Complete_msg_Actions']) {
                        asiteSystemDataReadWrite['Auto_Complete_msg_Actions'] = {};
                    }
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'] = [];
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['DS_AUTOCOMPLETE_ACTION_MSG_APP_ID'] = "1";

                    var AppId = asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'];
                    for (var i = 0; i < clearActionNodes.length; i++) {
                        var nodeObj = clearActionNodes[i];
                        asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'].push({
                            DS_MSG_AC_TYPE: "clear",
                            DS_MSG_AC_FORM: AppId,
                            DS_MSG_AC_MSG_TYPE: nodeObj.Value3,
                            DS_MSG_AC_USERID: nodeObj.Value1,
                            DS_MSG_AC_ACTION: "3",
                            DS_MSG_AC_ACTION_REMARKS: "Action Cleared"
                        });
                    }
                    
                }
            }
            // Used to clear Action
        var ClearAction = function() {
            var node = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS") || [];
            node = commonApi._.findWhere(node, {
                Name: "Respond"
            });

            if (!node) {
                return;
            }
            var strincompleteactions = node.Value.trim();          
            var Workinguserid = getWorkingUserId();
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            //1538057 | Covanta TQ User, Covanta Demo Org # Covanta TQ User, Covanta Demo Org
            if (strincompleteactions) {
                var split = strincompleteactions.split('|');
                asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
                asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
                var AppId = asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'];
                if (split.length > 2) {
                    for (var i = 1; i < split.length - 1; i++) {
                        if (split[i] && split[i].indexOf("Respond") == -1 && (Workinguserid && split[i].indexOf(Workinguserid) == -1)) {

                            var xpniFindNode = asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'];
                            xpniFindNode = commonApi._.filter(xpniFindNode, function(o) {
                                return (o.DS_PROJDISTUSERS.indexOf(split[i].trim()) > -1 && o.DS_FORMACTIONS.indexOf('3#Respond') > -1);
                            });

                            if (!xpniFindNode.length) {
                                var nodeDistribution = asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'];
                                nodeDistribution.push({
                                    DS_AC_TYPE: "clear",
                                    DS_AC_FORM: AppId,
                                    DS_AC_MSG_TYPE: "ORI",
                                    DS_AC_USERID: split[i],
                                    DS_AC_ACTION: "3",
                                    DS_AC_ACTION_REMARKS: "Action Cleared"
                                });
                                nodeDistribution.push({
                                    DS_AC_TYPE: "clear",
                                    DS_AC_FORM: AppId,
                                    DS_AC_MSG_TYPE: "RES",
                                    DS_AC_USERID: split[i],
                                    DS_AC_ACTION: "3",
                                    DS_AC_ACTION_REMARKS: "Action Cleared",
                                });
                            }
                        }
                    }
                }
            }
        };

        var clearUserActionById = function(userPrevName) {
            var prevRCArr = userPrevName.split("|") || "";
            var prevRc = prevRCArr[2].trim() || "";
            if (!prevRc) {
                return;
            }

            var AppId = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
            asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
            var nodeDistribution = asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'];
            nodeDistribution.push({
                DS_AC_TYPE: "clear",
                DS_AC_FORM: AppId,
                DS_AC_MSG_TYPE: "ORI",
                DS_AC_USERID: prevRc,
                DS_AC_ACTION: "3",
                DS_AC_ACTION_REMARKS: "Action Cleared"
            });
            nodeDistribution.push({
                DS_AC_TYPE: "clear",
                DS_AC_FORM: AppId,
                DS_AC_MSG_TYPE: "RES",
                DS_AC_USERID: prevRc,
                DS_AC_ACTION: "3",
                DS_AC_ACTION_REMARKS: "Action Cleared",
            });
        }

        // (This function is Used when RC send to PM  or TA send PM )
        var AddEditNodeForPM = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var strCurrentStage = oriMsgCustomFields['CurrentStage'];
            var iPMCnt = 0,
                iContCnt = 0;
            SetRepeatComment_Counter(iPMCnt, iContCnt, true);

            // var Contractor_Review_comments = resMsgCustomFields['All_Response']['PM_Response']['Contractor']; // change for NOODLE42232
            var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                return obj["isUserActive"] == true
            });
            var Contractor_Review_comments = strContractorArr[0] && strContractorArr[0]['ContractorName'] || "";

            var Res_counter_LastValue = parseInt(resMsgCustomFields['Counters']['Res_counter']);

            if (!Contractor_Review_comments) {
                resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'] = "";

                if (resMsgCustomFields['All_Response']['PM_Response']['Contractors'] && resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"] && resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"].length) {
                    var selectedContractor = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                        return obj["isUserActive"] == true
                    });
                    if (selectedContractor[0]) {
                        selectedContractor[0]['ContractorName'] = "";
                    }
                } else {
                    resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"] = [{
                        "ContractorName": "",
                        "isUserActive": true
                    }];
                }

                var xpninodeofRC = resMsgCustomFields['All_Response']['Res_Info'];
                xpninodeofRC = commonApi._.filter(xpninodeofRC, function(o) {
                    return (o.visible == 'YES');
                });

                if (xpninodeofRC.length) {
                    for (var i = 0; i < xpninodeofRC.length; i++) {
                        var loopNode = xpninodeofRC[i];
                        var AllcommentNodes = loopNode['All_Comments']['Comments_Info'];

                        for (var j = 0; j < AllcommentNodes.length; j++) {
                            var comment_info = AllcommentNodes[j];
                            var multiComment = comment_info['Multicomment']['MultiComment_info'];

                            for (var k = 0; k < multiComment.length; k++) {
                                var multiCommentInfo = multiComment[k];
                                var commentGroup = multiCommentInfo['CommentGroup']['RepeatCommentGroup'];

                                commentGroup = commonApi._.each(commentGroup, function(o) {
                                    if (o.UID == loopNode.UID && o.IsDeleted != "YES") {
                                        iPMCnt++;
                                        o['RepeatComment_Id'] = (iPMCnt + "");
                                        o['Label'] = "PM";
                                        o['seqNo'] = 1;
                                    }
                                });
                            }
                        }
                    }
                }

                SetRepeatComment_Counter(iPMCnt, iContCnt, true);
            }
        };
      
        var AutoSetPackageStatus = function (isReturnPkgValue) {

            var setPkgStatus = "";
            var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
            var DS_FORMSTATUS = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];            
            if (!associateDocs.length) {
                return;
            }

            
            var docsArr = commonApi._.filter(associateDocs, {
                IsDocument_Package: BAM_COMMENTING_CONSTANT.Document
            });
            if (docsArr.length) {
                setPkgStatus = BAM_COMMENTING_CONSTANT.Accepted;
                for (var i = 0; i < docsArr.length; i++) {
                    if (docsArr[i].DocStatus == "Not Accepted") {
                        setPkgStatus = BAM_COMMENTING_CONSTANT.Not_Accepted;
                        break;
                    }
                }
            } else {
                //Case : No Documents found
                setPkgStatus = BAM_COMMENTING_CONSTANT.Not_Accepted;
            }
            
            for (var i = 0; i < associateDocs.length; i++) {
                if (associateDocs[i].IsDocument_Package == BAM_COMMENTING_CONSTANT.Package) {
                    associateDocs[i].DocStatus = setPkgStatus
                }
            }
            var currentRevision = $scope.oriMsgCustomFields['Package_Revision_No'];
            
            if ((DS_FORMSTATUS == BAM_COMMENTING_CONSTANT.Sent_to_PM || DS_FORMSTATUS == BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) && $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]["All_Response"]['PM_Response']['PM_Approve_Comments'] == "YES") {
                SetStatus(setPkgStatus);
                if (setPkgStatus == BAM_COMMENTING_CONSTANT.Accepted) {
                    SetReview_Stage("Closed");
                } else if (setPkgStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                    SetReview_Stage(BAM_COMMENTING_CONSTANT.Sent_to_Contractor);
                }
                //When PM responds, update pkg status in History 
                updatePackgeStatusForHistory(setPkgStatus, currentRevision);
            }
            updateDocStatusForHistory(currentRevision);

            if (isReturnPkgValue) {
                return setPkgStatus; 
            }

        };
        var SendActionInPkgForm = function() {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            // NOODLE-41017 NOODLE-47514 set Nodes to send action to contractor.
            asiteSystemDataReadWrite['Auto_Distribution_Actions']['Auto_Distribute_Action'] = [];

            var strDSFormStatus = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            var strPMApproval = resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'];

            //NOODLE-48020   PM can update DS_ASSOC_STATUS_UPDATE            
            if ((strDSFormStatus.indexOf("Sent to PM") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1) && strPMApproval == "YES") {
                asiteSystemDataReadOnly['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "21";
            } else {
                asiteSystemDataReadWrite['Auto_Distribution_Actions']['DS_AUTODISTRIBUTE_OTHERS_APP_ID'] = "0";
                asiteSystemDataReadWrite['Auto_Distribution_Actions']['Auto_Distribute_Action'] = [];
                asiteSystemDataReadOnly['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "0";
            }
        };
        var updatePackgeStatusForHistory = function(pkgStatusForHistory, currentRevision) {
            var revisionDetailsDocData = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associated_Doc_History"]['Associate_Doc_All_Rev'] || [];
            //Upadate all PackageStatus in Doc array
            if (revisionDetailsDocData.length) {
                revisionDetailsDocData.map(function(obj) {
                    if (obj.PackageRevision == currentRevision) {
                        obj.PackageStatus = pkgStatusForHistory;
                    }
                    return obj;
                });
            }
        }
        var updateDocStatusForHistory = function(currentRevision) {
            var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            var validAcceptanceDocsArr = commonApi._.where(associateDocs, {
                IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,                
                PurposeOfIssue: oriMsgCustomFields['Package_Submission_Purpose'],                
                MainDocStatus: BAM_COMMENTING_CONSTANT.QA_Accepted
            });

            var revisionDetailsDocData = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associated_Doc_History"]['Associate_Doc_All_Rev'] || [];
            var currentVersionHistoryArr = commonApi._.where(revisionDetailsDocData, {
                PackageRevision: currentRevision
            });
            var currentVersionHistoryDocsArray = currentVersionHistoryArr[0]["RevDocs"];

            for (var i = 0; i <= validAcceptanceDocsArr.length - 1; i++) {
                var docObj = validAcceptanceDocsArr[i];
                var DocRef = docObj.DocRef;
                var DocStatus = docObj.DocStatus
                for (var j = 0; j <= currentVersionHistoryDocsArray.length - 1; j++) {
                    var currentVersionHistoryDocsArrayObj = currentVersionHistoryDocsArray[j];
                    if (currentVersionHistoryDocsArrayObj.Value2 == DocRef) {
                        currentVersionHistoryDocsArray[j].Value9 = DocStatus;
                    }
                }
            }
        }
        var resetAllDocStatus = function() {
            var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var validAcceptanceDocsArr = commonApi._.where(associateDocs, {
                IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,                
                PurposeOfIssue: oriMsgCustomFields['Package_Submission_Purpose'],
                MainDocStatus: BAM_COMMENTING_CONSTANT.QA_Accepted
            });

            //Reset all DocStatus in Doc array
            validAcceptanceDocsArr.map(function(obj) {
                obj.DocStatus = "";
                return obj;
            });
        }

        var resetDocIdStatus = function(docId, isDocumentRevision) {
            var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
            var selectedDocIdArr = "";

            if (!isDocumentRevision && docId.split('-').length > 1) {
                isDocumentRevision = true
            }

            if (isDocumentRevision) {
                selectedDocIdArr = commonApi._.where(associateDocs, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,
                    DocumentRevisionId: docId
                });
            } else {
                selectedDocIdArr = commonApi._.where(associateDocs, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,
                    Doc_Id: docId
                });
            }

            selectedDocIdArr.map(function(obj) {
                obj.DocStatus = "";
                return obj;
            });
        }

        /**
        If docId is found, reset Status for that particular Doc, else resets doc status for all documents
        */
        var resetDocStatus = function(docId, isDocumentRevision) {
            if (docId) {
                resetDocIdStatus(docId, isDocumentRevision);
            } else {
                resetAllDocStatus();
            }
            AutoSetPackageStatus();
        }

        var validateDocStatusChange = function(associatedDoc) {
            if (associatedDoc.DocStatus) {
                var newSetStatus = associatedDoc.DocStatus;
                var isNoComment = false;
                var isPkgCommentAdded = false;
                var isPackageCommentCnt = 0;
                var isOnlyPackageComment = false;
                var isCurrDocCommentAdded = false;
                var commentedDocsArr = [];
                var resInfo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'];
                var associateDocs = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["Associate_Doc"]["Associate_Docs"] || [];
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
                var packageArr = commonApi._.filter(associateDocs, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Package
                });
                var currentPackageStatus = packageArr[0].DocStatus || "";
                var docsArr = commonApi._.filter(associateDocs, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.document
                });
                var validAcceptanceDocsArr = commonApi._.where(docsArr, {
                    IsDocument_Package: BAM_COMMENTING_CONSTANT.Document,                    
                    PurposeOfIssue: oriMsgCustomFields['Package_Submission_Purpose'],  
                    MainDocStatus: BAM_COMMENTING_CONSTANT.QA_Accepted,
                    DocStatus: ""
                });
                var pendingDocsWithBlankStatusCount = validAcceptanceDocsArr.length;
                for (var i = 0; i < resInfo.length; i++) {
                    var visibleResInfo = resInfo[i];
                    if (visibleResInfo.visible == "YES") {
                        var commentInfoArr = visibleResInfo['All_Comments']['Comments_Info'];
                        for (var j = 0; j < commentInfoArr.length; j++) {
                            var commentInfo = commentInfoArr[j];
                            if (commentInfo.Comment_Level ==BAM_COMMENTING_CONSTANT.No_Comment) {
                                isNoComment = true;
                                isPackageCommentCnt++;
                            } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Package) {
                                isPkgCommentAdded = true;
                            } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.document) {
                                commentedDocsArr.push(commentInfo.Doc_ID);
                                isPackageCommentCnt++;
                                if (commentInfo.Doc_ID == associatedDoc.DocumentRevisionId) { 
                                    isCurrDocCommentAdded = true;
                                }
                            }
                        }
                    }
                }

                if (!isPackageCommentCnt) {
                    isOnlyPackageComment = true;
                }              

                //Check if No-Comments is selected
                if (isNoComment && (newSetStatus == BAM_COMMENTING_CONSTANT.Not_Accepted)) {
                    alert("Cannot select '" + newSetStatus + "' status. No Comment has been added for this document. Cannot select 'Not Accepted' status");
                    resetDocStatus(associatedDoc.DocumentRevisionId, true);
                    return;
                }
                //Check if Package Comments are added
                if (isCurrDocCommentAdded) {
                    if (newSetStatus == BAM_COMMENTING_CONSTANT.Accepted) {
                        alert("Cannot select 'Accepted' status. Comment(s) have already been added for this document");
                        resetDocStatus(associatedDoc.DocumentRevisionId, true);
                        return;
                    }
                } else {
                    if (isPkgCommentAdded) {
                        var tempPkgStatus = AutoSetPackageStatus(true);
                        if ((!currentPackageStatus && !pendingDocsWithBlankStatusCount && newSetStatus == BAM_COMMENTING_CONSTANT.Accepted) ||
                            (isOnlyPackageComment && !pendingDocsWithBlankStatusCount && newSetStatus == BAM_COMMENTING_CONSTANT.Accepted && tempPkgStatus == BAM_COMMENTING_CONSTANT.Accepted)) {
                            alert("Cannot select 'Accepted' status. There are Comment(s) on the Package. Therefore at least one document must have a ‘Not Accepted’ status.");
                            resetDocStatus(associatedDoc.DocumentRevisionId, true);
                            return;
                        }
                    } else {
                        if (newSetStatus == BAM_COMMENTING_CONSTANT.Not_Accepted) {
                            alert("Cannot select '" + newSetStatus + "' status. No Comment has been added for this document. Cannot select 'Not Accepted' status");
                            resetDocStatus(associatedDoc.DocumentRevisionId, true);
                            return;
                        }
                    }
                }
            }
        }

        //First check If this draft is latest or not (this SP returns latest Uid from created response)
        var CheckLatestUID = function() {
            var iReturn = 0;
            var strLatestUid = "";

            var canReply = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]['Warning']['Can_Reply'];
            var isDCUser = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["DC_User_Change"];

            var xpnLatestUid = $scope.getValueOfOnLoadData("DS_ASI_TIDP_DRAFT_CHECK_NEW_P3") || [];
            if (xpnLatestUid[0]) {
                strLatestUid = xpnLatestUid[0].Value1;
            }

            if (strLatestUid == $scope.data['myFields']['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['LastUID']) {
                iReturn = 1;
            } else {
                iReturn = 0;
            }
            if (isDCUser && canReply == "NO" && $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_ISDRAFT_RES_MSG'] == 'YES') {
                iReturn = 0;
            }
            return iReturn;
        };

        //(This function is Used when TA send back to RC )
        var AddEditNodeForRC_RecycleFromTA = function() {
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response'];
            allRes['PM_Response']['PM_Approve_Comments'] = "";
            allRes['TechnicalAutho']['Tech_Res_Status'] = "";
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            if (allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"].length) {
                var selectedTA = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                    return obj["isUserActive"] == true
                });
                if (selectedTA[0]) {
                    selectedTA[0]['TAName'] = "";
                }
            } else {
                allRes['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"] = [{
                    "TAName": "",
                    "isUserActive": true
                }];
            }

            if (allRes['Selected_Tech_Autho']['Selected_Project_Managers'] && allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"] && allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"].length) {
                var selectedPM = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                if (selectedPM[0]) {
                    selectedPM[0]['PMName'] = "";
                }
            } else {
                allRes['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"] = [{
                    "PMName": "",
                    "isUserActive": true
                }];
            }

            allRes['Selected_Tech_Autho']['Selected_TIG'] = "";
            if (!allRes['TIG_Response']) {
                allRes['TIG_Response'] = {};
            }
            allRes['TIG_Response']['TIG_Approval'] = "";
            if (allRes['TechnicalAutho']['SelectedProjectManagers'] && allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].length) {
                var selectedPM = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                if (selectedPM[0]) {
                    selectedPM[0]['PMName'] = "";
                }
            } else {
                allRes['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"] = [{
                    "PMName": "",
                    "isUserActive": true
                }];
            }

        };

        //(This function is Used when RC send to TA )
        var AddEditNodeForTA = function() {
            var allRes = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho'];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            if (allRes['SelectedProjectManagers'] && allRes['SelectedProjectManagers']["SelectedProjectManager"] && allRes['SelectedProjectManagers']["SelectedProjectManager"].length) {
                var selectedPM = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                if (selectedPM[0]) {
                    selectedPM[0]['PMName'] = "";
                }
            } else {
                allRes['SelectedProjectManagers']["SelectedProjectManager"] = [{
                    "PMName": "",
                    "isUserActive": true
                }];
            }

            allRes['Tech_Res_Status'] = "";
        };

        //Check draft is match with current stage or not // So, user will not able to create older draft which is not match with current stage 
        var CheckDraftSection = function() {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var strLastStage = oriMsgCustomFields['LastStage'];
            var PM_APPROVE_COMMENTS = resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'];
            var TA_RES = resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_Status'];

            var allRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
            allRoles = allRoles[0] || {};
            allRoles = allRoles.Value || "";           
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";
            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";

            
            var strDsFormContent2 = msgContent[0].Value7 || "";
            strDsFormContent2 = strDsFormContent2.replace("$$$", "#");

            var strDSFormStatus = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];

            var strTAArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strTA = strTAArr[0] && strTAArr[0]['TAName'] || "";

            var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strContractor = strContractorArr[0] && strContractorArr[0]['ContractorName'] || "";

            var strRCSection = resMsgCustomFields['DisplayGroup']['Dis_flag_RC_section'];
            var strTASection = resMsgCustomFields['DisplayGroup']['Dis_flag_TA_Section'];
            var strPMSection = resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'];
            var strPMRESSection = resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_PMRES'];
            var strCONRESSection = resMsgCustomFields['DisplayGroup']['Flag_ToDisplay_CONTRES'];

            oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strPendingAction;

            var strPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strPM = strPMArr[0] && strPMArr[0]['PMName'] || "";

            if (!strPM) {
                var selectedPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                strPM = selectedPMArr[0] && selectedPMArr[0]['PMName'] || "";
            }

            if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Review_in_Progress && strRCSection == "YES") {
                if (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1)
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //ReviewCoordinator View ( PM send back to RC)
            else if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Further_Review_in_Progress && strRCSection == "YES" && strLastStage == "4") {
                if (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1)
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //ReviewCoordinator View ( TA send back to RC)
            else if (strDSFormStatus == BAM_COMMENTING_CONSTANT.Further_Review_in_Progress && strRCSection == "YES" && strLastStage == "3") {
                if (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) > -1)
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //Technical Authoriser(TA) View (RC send to  TA )
            else if (strDSFormStatus.indexOf("Sent to TA") > -1 && strTA != "" && strTASection == "YES") {
                var strTATemp = "";
                if (strTA.split('|')[2]) {
                    strTATemp = strTA.split('|')[2].split('#')[0].trim()
                } else {
                    strTATemp = strTA.split('#')[0].trim();
                }
                if ((strTATemp && strWORKINGUSER.indexOf(strTATemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Technical_Authoriser) > -1)
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //Project Manager(PM) View (RC send to  PM || TA send to PM )
            else if (strPM != "" && (strDSFormStatus.indexOf("Sent to PM") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1) && strPMSection == "YES") {
                var strPMTemp = "";
                if (strPM.split('|')[2]) {
                    strPMTemp = strPM.split('|')[2].split('#')[0].trim();
                } else {
                    strPMTemp = strPM.split('#')[0].trim();
                }

                if ((strPMTemp && strWORKINGUSER.indexOf(strPMTemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1)
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //Project Manager(PM) View (RC send to  PM || TA send to PM || contractor send to PM )
            else if (strPM != "" && (strDSFormStatus.indexOf("Sent to PM") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA) > -1 || strLastStage == "5") && strPMRESSection == "YES") {
                var strPMTemp = "";
                if (strPM.split('|')[2]) {
                    strPMTemp = strPM.split('|')[2].split('#')[0].trim();
                } else {
                    strPMTemp = strPM.split('#')[0].trim();
                }

                if (((strPMTemp && strWORKINGUSER.indexOf(strPMTemp) > -1) || allRoles.indexOf(BAM_COMMENTING_CONSTANT.Project_Manager) > -1) || (strLastStage == "5" && (strDSFormStatus.indexOf("Accepted With Comments") > -1 || strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1)))
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                else
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
            }
            //Contractor View 
            else if (strContractor != "" && (strLastStage == "4") && (PM_APPROVE_COMMENTS == "YES") && strCONRESSection == "YES") {
                var strContractorTemp = "";
                if (strContractorTemp.split('|')[2]) {
                    strContractorTemp = strContractor.split('|')[2].split('#')[0].trim();
                } else {
                    strContractorTemp = strContractor.split('#')[0].trim();
                }
                //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts
                var allPendingReviewDraftUsersIds = getAllIncompleteActionReviewDraftUserIds();
                var strWorkingUserId = strWORKINGUSER.split('|')[0].trim() || "";
                var Draft = asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
                if ((strContractorTemp && strWORKINGUSER.indexOf(strContractorTemp) > -1) || allRoles.indexOf("Contractor") > -1 || (allPendingReviewDraftUsersIds.indexOf(strWorkingUserId) > -1 && Draft == "YES")) {
                    //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends                    
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                } else {
                    oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strYouAreNotAutorisedAtThisStage;
                }
            } else {
                if (strReviewCoordinatorUser != "") {
                    if ((strLastStage == "0") && strDSFormStatus == BAM_COMMENTING_CONSTANT.Review_in_Progress && strRCSection != "YES" && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) == -1) {
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = "";
                    }

                    //Check if user in msgContent2 is RC 
                    if ((strDsFormContent2 != strReviewCoordinatorUser) && (strWORKINGUSER.indexOf(strDsFormContent2.split('#')[0].trim()) != -1)) {
                        oriMsgCustomFields['Warning']['NoCreateAccess'] = BAM_COMMENTING_CONSTANT.strRoleChangeMsg;
                    }
                }
            }
        };

        // Replace Action Performer in table as per LastGuid // Replace users name in RES info 
        var ReplaceUserifIsdraft = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var strLastStage = oriMsgCustomFields['LastStage'];
            var strCurrentStage = oriMsgCustomFields['CurrentStage'];

            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";


            var strRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
            strRoles = strRoles[0] || {};
            strRoles = strRoles.Value || "";            
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";

            var xpniRoleNode = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] || [];
            xpniRoleNode = commonApi._.filter(xpniRoleNode, function(o) {
                return (strWORKINGUSER && o.User.indexOf(strWORKINGUSER.split('|')[0]) > -1);
            })[0];

            if (xpniRoleNode) {
                strRoles = xpniRoleNode.Role;
            }

            var AllnodesOfReviewers = resMsgCustomFields['All_Response']['Res_Info'] || [];
            AllnodesOfReviewers = commonApi._.filter(AllnodesOfReviewers, function(o) {
                return (o.visible == "YES");
            });

            if (AllnodesOfReviewers.length) {
                for (var i = 0; i < AllnodesOfReviewers.length; i++) {
                    var loopNode = AllnodesOfReviewers[i];
                    if (strCurrentStage == "0" || strCurrentStage == "2" || strCurrentStage == "3" || strCurrentStage == "4") {
                        loopNode['ResponseBy'] = strWORKINGUSER;
                        loopNode['UserAllRoles'] = strRoles;
                    }

                    if (strCurrentStage == "0") {
                        if (strRoles.indexOf("TIG") > -1)
                            loopNode['CommentBY'] = "TIG :" + strWORKINGUSER.split('#')[1];
                        else
                            loopNode['CommentBY'] = "Reviewer :" + strWORKINGUSER.split('#')[1];
                    } else if (strCurrentStage == "2") {
                        loopNode['CommentBY'] = "Review Coordinator :" + strWORKINGUSER.split('#')[1];
                    } else if (strCurrentStage == "3") {
                        loopNode['CommentBY'] = "Technical Authoriser :" + strWORKINGUSER.split('#')[1];
                    } else if (strCurrentStage == "4") {
                        loopNode['CommentBY'] = "Project Manager :" + strWORKINGUSER.split('#')[1];
                    }
                }
            }
        };

        // This function is used to set flags and used in Form PRINT view and in RES Print View to display section according to falg.
        var SetFlag = function() {
            var resMsgCustomFields = $scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields'];
            var Recommendnodes = resMsgCustomFields['All_Response']['Res_Info'] || [];
            Recommendnodes = commonApi._.filter(Recommendnodes, function(o) {
                return (!o.RCRES_Reviewer_id && !o.TARES_RC_id && !o.PMRES_RC_id && !o.CONRES_PM_id && o.visible == "YES");
            });

            if (Recommendnodes.length > 0) {
                resMsgCustomFields['DisplayGroup']['DS_Flag_Recommend_section'] = "YES";
            } else {
                resMsgCustomFields['DisplayGroup']['DS_Flag_Recommend_section'] = "NO";
            }
        };

        var ResetDataInDraftForSpclCharc = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var strRCSendToForStage2 = resMsgCustomFields['All_Response']['Selected_Tech_Autho']['RC_Send_To'];
            var strCurrentStage = oriMsgCustomFields['CurrentStage'];
            var allRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');

            if (strRCSendToForStage2.trim().toLowerCase() == "technical authoriser" && strCurrentStage == "2") {
                var strTAArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strTA = strTAArr[0] && strTAArr[0]['TAName'].trim() || "";

                if (strTA.length > 0 && strTA.indexOf("&") > -1) {
                    var straTA = strTA.split('#')[0].split('|');
                    var strFilter = straTA[straTA.length - 1].trim();
                    var xpnPath = commonApi._.filter(allRoles, function(o) {
                        return (o.Value.indexOf(strFilter) > -1);
                    })[0] || {};

                    if (updateIfHasValueInNode(xpnPath.Value, "Selected_Technical_Authorisers", "Selected_Technical_Authoriser")) {
                        resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"]);
                        resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"].push({
                            "TAName": xpnPath.Value,
                            "isUserActive": true
                        });
                    }

                }
            }

            if (strRCSendToForStage2.trim()
                .toLowerCase() == "project manager" && strCurrentStage == "2") {

                var strPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strPM = strPMArr[0] && strPMArr[0]['PMName'].trim() || "";

                if (strPM.length > 0 && strPM.indexOf("&") > -1) {
                    var straPM = strPM.split('#')[0].split('|');
                    var strFilter = straPM[straPM.length - 1].trim();
                    var xpnPath = commonApi._.filter(allRoles, function(o) {
                        return (o.Value.indexOf(strFilter) > -1);
                    })[0] || {};

                    if (updateIfHasValueInNode(xpnPath.Value, "Selected_Project_Managers", "Selected_Project_Manager")) {
                        resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"]);
                        resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"].push({
                            "PMName": xpnPath.Value,
                            "isUserActive": true
                        });
                    }
                }
            }

            if (strCurrentStage == "3") {
                var selectedPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strPM = selectedPMArr[0] && selectedPMArr[0]['PMName'].trim() || "";

                if (strPM.length > 0 && strPM.indexOf("&") > -1) {
                    var straPM = strPM.split('#')[0].split('|');
                    var strFilter = straPM[straPM.length - 1].trim();
                    var xpnPath = commonApi._.filter(allRoles, function(o) {
                        return (o.Value.indexOf(strFilter) > -1);
                    })[0] || {};

                    resetNodeAsInactive($scope.data['myFields']['FORM_CUSTOM_FIELDS']['RES_MSG_Custom_Fields']['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"]);
                    resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].push({
                        "PMName": xpnPath.Value,
                        "isUserActive": true
                    });
                }
            }
            if (strCurrentStage == "4") {
                var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strCont = strContractorArr[0] && strContractorArr[0]['ContractorName'].trim() || "";

                if (strCont.length > 0 && strCont.indexOf("&") > -1) {
                    var straCont = strCont.split('#')[0].split('|');
                    var strFilter = straCont[straCont.length - 1].trim();
                    var xpnPath = commonApi._.filter(allRoles, function(o) {
                        return (o.Value.indexOf(strFilter) > -1);
                    })[0] || {};

                    resetAllContractorNameNodesAsInactive();
                    resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"].push({
                        "ContractorName": xpnPath.Value,
                        "isUserActive": true
                    });
                }
            }
        };

        $scope.On_Technical_Authoriser_Changed = function(sendActionBy, userPrevName) {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];

            // Step-5 Send to Techautho
            var strTAArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Technical_Authorisers']["Selected_Technical_Authoriser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var Technical_Authoriser = strTAArr[0] && strTAArr[0]['TAName'] || "";
            if (Technical_Authoriser) {
                // send to Tech autho Respond action
                if (sendActionBy != "ActionByDC") { 
                    asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                }
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";

                var t_split = Technical_Authoriser.split('|');
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = Technical_Authoriser;
                }

                var responseTime = $scope.getCalculatedActionDueDate("TA_DUE_DATE");
                AutoDistUser(autoDistUserName.trim(), "3#Respond", responseTime);

                if (sendActionBy == "ActionByDC") {
                    clearUserActionById(userPrevName);
                } else {
                    ClearActionbyMsg(); 
                }
            
            }
        };

        var AutoDistUser = function(strUserName, strAction, strDueDay) {
            
            if (!strUserName) {
                return;
            }
        
            var strDays = serverDate.getTime() + (BAM_COMMENTING_CONSTANT.dasyInMiliseconds * strDueDay);
            var strDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];

            asiteSystemDataReadWrite['Auto_Distribute_Group'] = asiteSystemDataReadWrite['Auto_Distribute_Group'] || {};
            asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] || [];

            if (strAction == "7#For Information") {
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push({
                    DS_PROJDISTUSERS: strUserName,
                    DS_FORMACTIONS: strAction,
                    DS_ACTIONDUEDATE: ""
                });
            } else {
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push({
                    DS_PROJDISTUSERS: strUserName,
                    DS_FORMACTIONS: strAction,
                    DS_ACTIONDUEDATE: strDueDate,
                    DS_ACTIONDAYS: strDueDay
                });
            }

            //get unique users and insert it them again
            var allActionsDistribution = asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'];
            var respondNodes = commonApi._.filter(allActionsDistribution, function(obj) {
                return obj["DS_FORMACTIONS"] == "3#Respond"
            });
            respondNodes = commonApi._.uniq(respondNodes, 'DS_PROJDISTUSERS');
            var forInfoNodes = commonApi._.filter(allActionsDistribution, function(obj) {
                return obj["DS_FORMACTIONS"] == "7#For Information"
            });
            forInfoNodes = commonApi._.uniq(forInfoNodes, 'DS_PROJDISTUSERS');
            asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = commonApi._.union(respondNodes, forInfoNodes);
          
        };

        // Step 6  send to PM   (If Tech_Res_Status=YES)   or  
        // send to Review Coordinator Respond Step=7  (If Tech_Res_Status=NO)
        $scope.On_Tech_Res_Status_Changed = function(status) {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];

            // Step 6  send to PM   (If Tech_Res_Status=YES)
            var selectedPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                return obj["isUserActive"] == true
            });
            var Project_Manager = selectedPMArr[0] && selectedPMArr[0]['PMName'] || "";
            if (status == "YES") {
                SetStatus(BAM_COMMENTING_CONSTANT.Sent_to_PM_via_TA);
                SetReview_Stage("Sent to PM by TA");
            }
            if (status == "YES" && Project_Manager) {
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = Project_Manager;
                }
                var responseTime = $scope.getCalculatedActionDueDate("PM_DUE_DATE");
                AutoDistUser(autoDistUserName, "3#Respond", responseTime);
            } else if (status == "NO") {
                // send to Review Coordinator Respond Step=7  (If Tech_Res_Status=NO)
                if (resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_Status']) {
                    resMsgCustomFields['All_Response']['TechnicalAutho']['Tech_Res_comments'] = "";
                }

                if (resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers'] && resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"] && resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"].length) {
                    var selectedPM = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                        return obj["isUserActive"] == true
                    });
                    if (selectedPM[0]) {
                        selectedPM[0]['PMName'] = "";
                    }
                } else {
                    resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"] = [{
                        "PMName": "",
                        "isUserActive": true
                    }];
                }
                SetStatus(BAM_COMMENTING_CONSTANT.Further_Review_in_Progress);
                SetReview_Stage(BAM_COMMENTING_CONSTANT.Sent_back_to_RC_by_TA);
                sendActionToRC();
                ClearAction();
            }
        };

        var SetStatus = function(strStatus) {
            var xpniDS_Status = $scope.getValueOfOnLoadData("DS_ALL_FORMSTATUS");
            var strStatusValue = "";
            if (xpniDS_Status.length) {
                for (var i = 0; i < xpniDS_Status.length; i++) {
                    var xpnLoop = xpniDS_Status[i];
                    if (xpnLoop.Name.toLowerCase() == strStatus.toLowerCase()) {
                        strStatusValue = xpnLoop.Value;
                        break;
                    }
                }
            }
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatusValue;
        };

        var SetReview_Stage = function(strStatus) {
            if (!$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage']) {
                $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'] = "";
            }
            $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['Status_Data']['Review_Stage'] = strStatus;
        }
        // send to Review Coordinator Respond Step=7   
        var sendActionToRC = function(sendActionBy) {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];
            if (sendActionBy != "ActionByDC") { 
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            }
            asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";

            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']['ReviewCoordinatorUser'], function(obj) {
                return obj["isUserActive"] == true
            });
            var strRC = strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'];
            if (strRC) {
                var responseTime
                if (sendActionBy == "ActionByDC") {
                    responseTime = $scope.getCalculatedActionDueDate("RC_DUE_DATE");
                } else {
                    responseTime = $scope.getCalculatedActionDueDate("RC_REJECT_DUE_DATE");
                }
                AutoDistUser(strRC, "3#Respond", responseTime);
            }
        };

        //send to PM
        $scope.On_SelectedProjectManager_Changed = function(sendActionBy, userPrevName) {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var selectedPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['TechnicalAutho']['SelectedProjectManagers']["SelectedProjectManager"], function(obj) {
                return obj["isUserActive"] == true
            });
            var Project_Manager = selectedPMArr[0] && selectedPMArr[0]['PMName'] || "";

            if (Project_Manager) {
                if (sendActionBy != "ActionByDC") { 
                    asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                }
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";

                var t_split = Project_Manager.split('|');
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = Project_Manager;
                }
                var responseTime = $scope.getCalculatedActionDueDate("PM_DUE_DATE");
                AutoDistUser(autoDistUserName, "3#Respond", responseTime);
                if (sendActionBy == "ActionByDC") {
                    clearUserActionById(userPrevName);
                } else {
                    ClearAction();
                }
            }
        };

        $scope.On_DS_ALL_FORMSTATUS_changed = function() {
            SetNodes();
        };

        var SetNodes = function(sendActionBy, userPrevName) {
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']["Contractor"], function(obj) {
                return obj["isUserActive"] == true
            });
            var contractor = strContractorArr[0] && strContractorArr[0]['ContractorName'] || "";

            var Approval_comments = resMsgCustomFields['All_Response']['PM_Response']['PM_Approve_Comments'];
            var status1 = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];

            if (!status1 && sendActionBy == "ActionByDC") {
                status1 = "#" + asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            }

            if (Approval_comments == "YES" && status1 && contractor) {
                var status = (status1.split('#')[1] || "")
                    .trim();
                var t_split = contractor.split('|');
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = contractor;
                }

                if (status == BAM_COMMENTING_CONSTANT.Not_Accepted ) {
                    // send to contractor respond action
                    if (sendActionBy != "ActionByDC") { 
                        asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    }
                    asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                    var responseTime = $scope.getCalculatedActionDueDate("CONTRACTOR_DUE_DATE");
                    AutoDistUser(autoDistUserName, "3#Respond", responseTime);


                    if (sendActionBy == "ActionByDC") {
                        clearUserActionById(userPrevName);
                    } else {
                        ClearAction();
                    }
                } else if (status == BAM_COMMENTING_CONSTANT.Accepted || status.indexOf("Closed") > -1) {
                    // send to contractor respond action
                    if (sendActionBy != "ActionByDC") {
                        asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                    }
                    asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                    AutoDistUser(autoDistUserName, "7#For Information", "");
                }

                //send forinfo 
                SendForInfoActionToAll();
            } else {
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            }
            
        };

        // Send Forinfo Action to All Reviewers and Review Coordinators.
        var SendForInfoActionToAll = function() {
            // NOODLE-42232 -- Send for info action on PM and CONTRACTOR's Response
            //Reviewers  
            sendActionToReviewers();
            SendForinforActionToRCgroupusers();
        };

        $scope.On_Contractor_changed = function(sendActionBy, userPrevName) {
            SetNodes(sendActionBy, userPrevName);
        };
        $scope.On_PM_Approve_Comments_Changed = function() {

            var isPmApproveComments = $scope.PM_Response['PM_Approve_Comments'];
            if (isPmApproveComments == "YES") {
                $scope.PM_Response['PM_Reason_ForNoApproval'] = "";
                
            }
            if (isPmApproveComments != "YES") {
                $scope.resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'][$scope.resMsgCustomFields['All_Response']['PM_Contractor_Comm']['PM_CON_Com_details'].length - 1]['PM_Res_comments'] = "";
                if ($scope.PM_Response['Contractors'] && $scope.PM_Response['Contractors']['Contractor'] && $scope.PM_Response['Contractors']['Contractor'].length) {
                    var selectedContractor = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']['Contractor'], function(obj) {
                        return obj["isUserActive"] == true
                    });
                    if (selectedContractor[0]) {
                        selectedContractor[0]['ContractorName'] = "";
                    }
                } else {
                    $scope.PM_Response['Contractors']['Contractor'] = [{
                        "ContractorName": "",
                        "isUserActive": true
                    }];
                }
            }
            if (isPmApproveComments != "") {
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['DisplayGroup']['Flag_ToDisplay_PMRES'] = "YES";
                $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['DisplayGroup']['Flag_ToDisplay_CONTRES'] = "NO";
            }

            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            
            var strContractorArr = commonApi._.filter($scope.resMsgCustomFields['All_Response']['PM_Response']['Contractors']['Contractor'], function(obj) {
                return obj["isUserActive"] == true
            });
            var contractor = strContractorArr[0] && strContractorArr[0]['ContractorName'] || "";

            var status = asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];

            asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];

            if (isPmApproveComments == "YES") {
                //Check pkg status and set DS_ALL_FORMSTATUS accordingly.
                var pkgStatus = AutoSetPackageStatus(true);
                SetStatus(pkgStatus);

                SetReview_Stage(BAM_COMMENTING_CONSTANT.Sent_to_Contractor);
                if (pkgStatus == BAM_COMMENTING_CONSTANT.Accepted) {
                    SetReview_Stage("Closed");
                }
            }

            if (isPmApproveComments == "YES" && status && contractor) {
                // send to contractor for info Step 8a and 8b
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = contractor;
                }
                AutoDistUser(autoDistUserName, "7#For Information", "");
                resMsgCustomFields['Counters']['LastCycleNo'] = resMsgCustomFields['Counters']['OldCycle'];
                ClearAction();
            } else if (isPmApproveComments == "NO") {
                SetStatus(BAM_COMMENTING_CONSTANT.Further_Review_in_Progress);
                SetReview_Stage('Sent back to RC by PM');
                sendActionToRC(); // NOODLE-47317
                // NOODLE-42232 -- Send for info action on PM or CONTRACTOR's Response
                sendActionToReviewers();
                ClearAction();
            } else {
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                resMsgCustomFields['Counters']['LastCycleNo'] = resMsgCustomFields['Counters']['OldCycle'];
            }

            SendActionInPkgForm(); //NOODLE-49564 Package status update only when send action to contractor

        };

        var sendActionToReviewers = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];

            var xRCAllnodes = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'];
            if (xRCAllnodes.length) {
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                for (var i = 0; i < xRCAllnodes.length; i++) {
                    var loopNode = xRCAllnodes[i];
                    AutoDistUser(loopNode.User, "7#For Information", "");
                }
            }
        };

        //send For Info action to RC
        $scope.On_Response_Accepted_Changed = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];

            //NOODLE-48494 Removed workspace role and used stored roles in repeating tables at form creation time.
            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
            var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";
            var strCurrentStage = oriMsgCustomFields['CurrentStage'];

            if (strReviewCoordinatorUser && strWORKINGUSER.indexOf(strReviewCoordinatorUser.split('#')[0].trim()) == -1 && strCurrentStage == "0") {
                asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                SendForinforActionToRCgroupusers();
            }            
        }

        var SendForinforActionToRCgroupusers = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var xRCAllnodes = oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'];

            if (xRCAllnodes.length > 0) {
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                for (var i = 0; i < xRCAllnodes.length; i++) {
                    var loopNode = xRCAllnodes[i];
                    AutoDistUser(loopNode.UserId, "7#For Information", "");
                }
            }
        };

        // Send respond action to all group users and RC 
        $scope.On_Reviewers_distg_Changed = function() {
            if (window.currentViewName == "ORI_VIEW") {
                var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
                var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
                var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

                asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];
                //reset all data and call all SPs again.
                asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] = [];
                oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'] = [];

                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3";

                var xpniSpNodes = oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'];

                if (xpniSpNodes.length) {
                    for (var i = 0; i < xpniSpNodes.length; i++) {
                        var loopNode = xpniSpNodes[i];
                        if (loopNode && loopNode.Reviewers_Distributiongroup) {
                        }
                    }
                    asiteSystemDataReadOnly["_5_Form_Data"]["DS_SEND_MSG"] = "0";
                } else {
                    asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = "0";
                }

                // Add Review Cooordinator
                var RC = oriMsgCustomFields['ReviewCoordinator_DistGrp'];
                if (RC) {
                    CommonGetCallback(RC,FillRCUserstoTable);                        
                }

                //send for Info to DC
                var DC = oriMsgCustomFields['Originator_Id'];
                if (DC) {
                    AutoDistUser(DC, "7#For Information", "");
                }
            }
        };

        function CommonGetCallback(value,callBack) {
            var spParam = {
                dataSourceArray : [{
                    "fieldName": 'DS_GET_DIST_GROUP_USERS_ROLES',
                    "fieldValue": value
                }],
                successCallback : function (responseList) {                                     
                  callBack(responseList, value);
                 
                },
                failureCallback : function(error) {
                    Notification.error({
                        title: "Server Error",
                        message: "Server error while retrieving data. "
                    });
                }
            };
            $scope.getCallbackSPdata(spParam);
        }
        
        // Step-5 Send to PM directly Respond action to change status and clear other reviewers respond action before sending to PM 
        $scope.On_Selected_Project_Manager_Changed = function(sendActionBy, userPrevName) {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];

            var strPMArr = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                return obj["isUserActive"] == true
            });

            var Selected_Project_Manager = strPMArr[0] && strPMArr[0]['PMName'] || "";
            if (Selected_Project_Manager) {
                if (sendActionBy != "ActionByDC") { 
                    asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                }
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";

                var t_split = Selected_Project_Manager.split('|');
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = Selected_Project_Manager;
                }

                var responseTime = $scope.getCalculatedActionDueDate("PM_DUE_DATE");
                AutoDistUser(autoDistUserName, "3#Respond", responseTime);

                if (sendActionBy == "ActionByDC") {
                    clearUserActionById(userPrevName);
                } else {
                    ClearActionbyMsg(); 
                }                
            }
        };

        // send Respond action to RC 
        $scope.Get_Reviewers_From_Selected_Group=function(value, obj)
        {
            var index = obj.index;            
            if (!value)
            return;
            FillRCUserstoTable_ReviewerGroup(value,index);           
        }
        $scope.On_Reviewers_Distributiongroup_Changed = function(value, validationObj) {
            if (!value || !validationObj)
                return;

            var isUnique = $scope.checkDuplicateValue(validationObj);
            if (!isUnique)
                return;

            AddNodesToDistibute();

            if (!value) {
                return;
            }
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            //NOODLE-48494 Insert all users into Table
            var xpniGroupNode = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'];
            xpniGroupNode = commonApi._.filter(xpniGroupNode, function(o) {
                return (o.GroupDetail == value);
            });            
            // Remove duplicate users
            var GroupIds = "";
            var xpnRevInfonodes = oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'];
            if (xpnRevInfonodes.length) {
                for (var i = 0; i < xpnRevInfonodes.length; i++) {
                    var loopNode = xpnRevInfonodes[i]['Reviewers_Distributiongroup'].trim();
                    GroupIds = GroupIds + " | " + loopNode.split('#')[0];
                }
            }
            var xpniNode = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'];
            if (xpniNode.length) {
                for (var i = 0; i < xpniNode.length; i++) {
                    var loopNode = xpniNode[i];
                    var strCurrentGroupid = loopNode.GroupDetail.trim().split('#')[0];
                    var strCurrentGroupDetail = loopNode.GroupDetail.trim();

                    if (strCurrentGroupid && GroupIds.indexOf(strCurrentGroupid) == -1) {
                        oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] = commonApi._.reject(oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'], function(o) {
                            return (o.GroupDetail == strCurrentGroupDetail);
                        });
                    }
                }
            }
        };

        var AddNodesToDistibute = function() {
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];
            asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3"; 
        };

        var AddNodesToDistibuteSubCon = function() {
            $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            $scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
        };

        // copy Secondary Data source to primary source //NOODLE-48494
        var FillUserstoTable = function (responseList, value) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            $scope.DS_GET_DIST_GROUP_USERS_ROLES = responseList['DS_GET_DIST_GROUP_USERS_ROLES'];

            if ($scope.DS_GET_DIST_GROUP_USERS_ROLES && $scope.DS_GET_DIST_GROUP_USERS_ROLES.length) {
                var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function (obj) {
                    return obj["isUserActive"] == true
                });
                var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";
                var responseTime = $scope.getCalculatedActionDueDate("REVIEWER_DUE_DATE");

                for (var i = 0; i < $scope.DS_GET_DIST_GROUP_USERS_ROLES.length; i++) {
                    var loopNode = $scope.DS_GET_DIST_GROUP_USERS_ROLES[i];
                    if (loopNode.Name) {
                        var strUserId = loopNode.Value1.trim();
                        var strUserName = loopNode.Value2.trim();
                        var strAction = loopNode.Value4.trim();
                        var strUserRoles = loopNode.Value7.trim();
                        var autoDistUserName = strUserId + " # " + strUserName;
                        var infoResponseTime = loopNode.Value5.trim();

                        oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'].push({
                            User: autoDistUserName,
                            Role: strUserRoles,
                            Action: strAction,
                            GroupDetail: value
                        });
                        oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] = commonApi._.uniq(oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'], 'User');

                        if (autoDistUserName != strReviewCoordinatorUser) {
                            if (loopNode.Value4 == "Respond") {
                                AutoDistUser(autoDistUserName, "3#Respond", responseTime);
                            } else if (loopNode.Value4 == "For Information") {
                                AutoDistUser(autoDistUserName, "7#For Information", "");
                            }
                        }
                    }
                }
            }
        };
        $scope.On_ReviewCoordinator_DistGrp_Changed = function() {
            var value = $scope.oriMsgCustomFields['ReviewCoordinator_DistGrp'];

            AddNodesToDistibute();
            // copy Secondary Data source to primary source            
            CommonGetCallback(value,FillRCUserstoTable);            
            //NOODLE-49128 Set Pkg form data from SP
            
        };
        //Added by Nihil
        $scope.On_SubContractor_DistGroup_Changed = function() {
            var value = $scope.oriMsgCustomFields['Sub_ContractorDistGroupInfo'];
            if (value) {
                value = value.split('#')[0].trim();
                AddNodesToDistibuteSubCon();
                CommonGetCallback(value,FillSubConUserstoTable);                
            }
        }
        var getIsSubContractorUser = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];            
           var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";
            var strSubContractorUserArr = commonApi._.filter(oriMsgCustomFields['SubContractorUsers']["SubContractorUser"], function(obj) {
                return obj["isSubConUserActive"] == true
            });
            var isSubContractor = "";
            var SubConinLoopNode = "";
            var SubConuserCode = strWORKINGUSER.split('|')[0].trim();
            for (var i = 0; i < strSubContractorUserArr.length; i++) {
                var loopNode = strSubContractorUserArr[i];
                if (loopNode) {
                    SubConinLoopNode = loopNode.SubContractorName.split('#')[0];
                    if (SubConinLoopNode.indexOf(SubConuserCode) != -1) {
                        isSubContractor = "Yes";
                        break;
                    } else {
                        isSubContractor = "No";
                    }
                }
            }
            return isSubContractor;
        }
        var createResForSubContractor = function() {
                var SubContractorUser = getIsSubContractorUser();
                if (SubContractorUser == "Yes") {
                    if (currentViewName == "RES_VIEW") {
                        var strFormId = $scope.Form_Data['DS_FORMID'].trim();
                        var strIsDraft = $scope.Form_Data['DS_ISDRAFT'].trim();
                        var strResDraft = $scope.Form_Data['DS_ISDRAFT_RES_MSG'].trim();

                        if (strResDraft == "YES") {
                            expandTextArea();
                            return;
                        }
                        var intResponseNodeLength = $scope.Responses_SubContractor.length;
                        for (var i = 0; i < intResponseNodeLength; i++) {
                            if ($scope.Responses_SubContractor[i].RFI_Response.length > 0) {
                                $scope.Responses_SubContractor[i].DSI_ResFlag = "Old";
                            }
                        }
                        var  strWorkingUser="";
                        var strResCount = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['DSI_Res_Counter'],
                            strWorkingUser = $scope.workingUserDetails[0].Name || "",
                            BlankResponseNode = {
                                "DSI_ResID": "",
                                "RFI_Response": "",
                                "RFI_ResponseBy": "",
                                "RFI_ResponseDate": "",
                                "DSI_ResFlag": ""
                            },
                            strToday = $scope.todayDateDbFormat,
                            intCount = strResCount;

                        if (strFormId && (strIsDraft == "NO" || strIsDraft == "")) {                            
                            if (intCount == 1) {
                                $scope.resMsgCustomFields.Sub_Contractor_Responces.All_Sub_Con_Res[0]['RFI_ResponseBy'] = strWorkingUser;
                                $scope.resMsgCustomFields.Sub_Contractor_Responces.All_Sub_Con_Res[0]['RFI_ResponseDate'] = strToday;                                
                                intCount++;
                            } else {       
                                intCount++;                         
                                var responseNode = angular.copy(BlankResponseNode);
                                responseNode.DSI_ResID = intCount.toString();
                                responseNode.RFI_ResponseBy = strWorkingUser;
                                responseNode.RFI_ResponseDate = strToday;
                                responseNode.DSI_ResFlag = "New";
                                if (responseNode) {
                                    $scope.Responses_SubContractor.push(responseNode);
                                }
                            }
                        }
                        $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['DSI_Res_Counter'] = intCount.toString();
                    }
                }
                //End Nihil
            }
            //Added by Nihil to send actions to sub contractor user
        var FillSubConUserstoTable = function (responseList, value) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            $scope.DS_GET_DIST_GROUP_USERS_ROLES = responseList['DS_GET_DIST_GROUP_USERS_ROLES'];
            if ($scope.DS_GET_DIST_GROUP_USERS_ROLES && $scope.DS_GET_DIST_GROUP_USERS_ROLES.length) {
                oriMsgCustomFields['Sub_ContractorDistGroup']['Sub_Con_User_info'] = [];

                oriMsgCustomFields['SubContractorUsers']['SubContractorUser'] = [];
                var activeUserAdded = true;

                for (var i = 0; i < $scope.DS_GET_DIST_GROUP_USERS_ROLES.length; i++) {
                    var loopNode = $scope.DS_GET_DIST_GROUP_USERS_ROLES[i];
                    if (loopNode.Name) {
                        var strUserId = loopNode.Value1.trim();
                        var strUserName = loopNode.Value2.trim();
                        var strAction = loopNode.Value4.trim();
                        var strUserRoles = loopNode.Value7.trim();

                        strUserId = strUserId + " # " + strUserName;
                        oriMsgCustomFields['Sub_ContractorDistGroup']['Sub_Con_User_info'].push({
                            UserId: strUserId,
                            action: strAction,
                            UserRole: strUserRoles,
                            GroupDt: value
                        });
                        oriMsgCustomFields['Sub_ContractorDistGroup']['Sub_Con_User_info'] = commonApi._.uniq(oriMsgCustomFields['Sub_ContractorDistGroup']['Sub_Con_User_info'], 'UserId');
                        if (strAction == "Respond" || strAction == BAM_COMMENTING_CONSTANT.For_Information) {
                            oriMsgCustomFields['SubContractorUsers']["SubContractorUser"].push({
                                "SubContractorName": strUserId,
                                "isSubConUserActive": activeUserAdded
                            });
                            var responseTime = $scope.getCalculatedActionDueDate("RC_DUE_DATE");
                            AutoDistUser(strUserId, "3#Respond", responseTime);
                        }
                    }
                }
                var strWorkingUserId = getWorkingUserId();
                AutoDistUser(strWorkingUserId, "3#Respond", responseTime);
                if (oriMsgCustomFields['SubContractorUsers']["SubContractorUser"].length) {
                    $scope.showOriRCErrorMsg = false;
                } else {
                    $scope.showOriRCErrorMsg = true;
                }
            }
        };
        var FillRCUserstoTable = function (responseList,value) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            $scope.DS_GET_DIST_GROUP_USERS_ROLES = responseList['DS_GET_DIST_GROUP_USERS_ROLES'];
            var ResCnt = 0;
            if ($scope.DS_GET_DIST_GROUP_USERS_ROLES && $scope.DS_GET_DIST_GROUP_USERS_ROLES.length) {
                oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'] = [];
                oriMsgCustomFields['ReviewCoordinatorUsers']['ReviewCoordinatorUser'] = [];
                var activeUserAdded = true;
                for (var i = 0; i < $scope.DS_GET_DIST_GROUP_USERS_ROLES.length; i++) {
                    var loopNode = $scope.DS_GET_DIST_GROUP_USERS_ROLES[i];
                    if (loopNode.Name) {
                        var strAction = loopNode.Value4.trim();
                        if (strAction && strAction == "Respond") {
                            ResCnt++;
                        }
                    }
                }
                if (ResCnt > 1) {
                    $scope.showOriRCErrorMsg = true;
                    return;
                }
                for (var i = 0; i < $scope.DS_GET_DIST_GROUP_USERS_ROLES.length; i++) {
                    var loopNode = $scope.DS_GET_DIST_GROUP_USERS_ROLES[i];
                    if (loopNode.Name) {
                        var strUserId = loopNode.Value1.trim();
                        var strUserName = loopNode.Value2.trim();
                        var strAction = loopNode.Value4.trim();
                        var strUserRoles = loopNode.Value7.trim();

                        strUserId = strUserId + " # " + strUserName;
                        oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'].push({
                            UserId: strUserId,
                            action: strAction,
                            UserRole: strUserRoles,
                            GroupDt: value
                        });

                        oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'] = commonApi._.uniq(oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'], 'UserId');
                        //NOODLE-48494
                        if (strAction == "Respond") {
                            oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].push({
                                "ReviewCoordinatorName": strUserId,
                                "isUserActive": activeUserAdded
                            });
                            if (strAction == "Respond") {
                                setRCNameInFormContent2(strUserId);
                            }

                            if (activeUserAdded) {
                                //reset All distribution 
                                $scope.data["myFields"]["Asite_System_Data_Read_Write"]['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

                                //Send action to RC
                                var responseTime = $scope.getCalculatedActionDueDate("RC_DUE_DATE");
                                AutoDistUser(strUserId, "3#Respond", responseTime);

                                //send for Info to DC
                                var DC = oriMsgCustomFields['Originator_Id'];
                                if (DC) {
                                    AutoDistUser(DC, "7#For Information", "");
                                }
                            }
                            activeUserAdded = false;
                        }
                    }
                }
                if (oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"].length) {
                    $scope.showOriRCErrorMsg = false;
                } else {
                    $scope.showOriRCErrorMsg = true;
                }
            }
        };

        var FillRCUserstoTable_ReviewerGroup = function (value, index) {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_GET_DIST_GROUP_USERS_ROLES",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_GET_DIST_GROUP_USERS_ROLES",
                        "fieldValue": value
                    }]
                }
            };
            $scope.requests['rcusers'] = true;
            $scope.add({
                name: "DS_GET_DIST_GROUP_USERS_ROLES",
                status: "incomplete"
            });
            $scope.getCallbackData(form).then(function (response) {
                $scope.requests['rcusers'] = false;
                $scope.update({
                    name: "DS_GET_DIST_GROUP_USERS_ROLES",
                    status: "completed"
                });
                if (response.data) {
                    var DS_GET_DIST_GROUP_USERS_ROLES = JSON.parse(response.data['DS_GET_DIST_GROUP_USERS_ROLES']);
                    $scope.DS_GET_DIST_GROUP_USERS_ROLES = DS_GET_DIST_GROUP_USERS_ROLES['Items']["Item"];

                    if ($scope.DS_GET_DIST_GROUP_USERS_ROLES && $scope.DS_GET_DIST_GROUP_USERS_ROLES.length) {
                        oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'] = [];
                        for (var i = 0; i < $scope.DS_GET_DIST_GROUP_USERS_ROLES.length; i++) {
                            var loopNode = $scope.DS_GET_DIST_GROUP_USERS_ROLES[i];
                            if (loopNode.Name) {
                                var strUserId = loopNode.Value1.trim();
                                var strUserName = loopNode.Value2.trim();
                                var strAction = loopNode.Value4.indexOf('Respond') > -1 ? '3#' + loopNode.Value4.trim() : '7#' + loopNode.Value4.trim();
                                var strUserRoles = loopNode.Value7.trim();

                                strUserId = strUserId + " # " + strUserName;
                                oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'].push({
                                    UserId: strUserId,
                                    action: strAction,
                                    UserRole: strUserRoles,
                                    modelValue: strUserId + '|' + strAction,
                                    GroupDt: value,
                                    userName: strUserId.split('#')[1].trim()
                                });
                            }
                        }
                        $scope.groupUsersList[index] = commonApi.getItemSelectionList({
                            arrayObject: oriMsgCustomFields.ReviewersGroupUsers.ReviewersInfo,
                            groupNameKey: "",
                            modelKey: "modelValue",
                            displayKey: "userName"
                        });
                    }
                }
            });
        };
        
        $scope.changeItemSelectionEvent = function(selectedVal) {
        }
        // send Respond action to RC
        $scope.On_Contractor_Review_comments_Changed = function() {
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];

            asiteSystemDataReadWrite['Distribution_Groups']['Distribution_Group'] = [];
            asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];

            var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                return obj["isUserActive"] == true
            });
            var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";

            if (strReviewCoordinatorUser) {
                asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "13";
                var t_split = strReviewCoordinatorUser.split('|');
                var autoDistUserName = "";
                if (t_split[2]) {
                    autoDistUserName = t_split[2];
                } else {
                    autoDistUserName = strReviewCoordinatorUser;
                }
                AutoDistUser(autoDistUserName, "3#Respond", 21);
                SendForInfoActionToAll();
                ClearAction();
            }
            SetReview_Stage("Response from Contractor");
        };

        // on DOC_ID change update other values.
        $scope.On_DOC_ID_Changed = function(strDocId, commentInfo, myform, name, commentInfoArray) {
            if (!strDocId) {
                return;
            }

            var strDocIdNew = strDocId.split('-')[0] || strDocId;
            var xpnDocument = $scope.DS_ASSOC_FORM_ASSOCDOCS_METADATA || [];
          
            xpnDocument = commonApi._.findWhere(xpnDocument, {
                Value24: strDocId
            });

            if (xpnDocument) {
                commentInfo.Doc_Title = xpnDocument.Value10;
                commentInfo.Doc_status = xpnDocument.Value12;
                commentInfo.DocFolder_Name = xpnDocument.Value5;
                commentInfo.Doc_FolderId = xpnDocument.Value4;
                commentInfo.Doc_Rev = xpnDocument.Value9;
                commentInfo.Doc_ref = xpnDocument.Value8;
            }
            resetDocStatus(strDocId, true);
            $scope.duplicateDocValidation(commentInfoArray, myform, true, strDocId);
        };

        $scope.On_DOC_ID_Click = function(strDocId, commentInfo, myform, name, commentInfoArray) {
            if (!strDocId) {
                return;
            }
        
            resetDocStatus(strDocId, true);
        };

        $scope.On_PM_Res_comments_Changed = function() {
            SetNodes();
            if ($scope.resMsgCustomFields["All_Response"]["PM_Response"]["PM_Res_Status"] == "") {
                var pkgStatus = AutoSetPackageStatus(true);

                SetReview_Stage(BAM_COMMENTING_CONSTANT.Sent_to_Contractor);
                if (pkgStatus == BAM_COMMENTING_CONSTANT.Accepted) {
                    SetReview_Stage("Closed");
                }
            } else {


            }
        };

        $scope.PmResStatusChangeSetStatusOkCallBack = function(status) {
         $scope.PmResStatusChangeSetDsFormStatus(status);
        }

        $scope.PmResStatusChangeSetStatusCancelCallBack = function(status) {
            $scope.PM_Response['PM_Res_Status'] = "";
            
            $scope.PmResStatusChangeSetDsFormStatus(status);
        }

        $scope.PmResStatusChangeSetDsFormStatus = function(status) {
            if (status) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = "0";
            } else {
                var strDSFormStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
                if (strDSFormStatus.indexOf("Closed") > -1) {
                    if (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1) {
                        SetStatus("Closed-Not Accepted");
                    } else if (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Accepted) > -1) {
                        SetStatus("Closed-Accepted");
                    }
                } else {
                    if (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Not_Accepted) > -1) {
                        SetStatus(BAM_COMMENTING_CONSTANT.Not_Accepted);
                    } else if (strDSFormStatus.indexOf(BAM_COMMENTING_CONSTANT.Accepted) > -1) {
                        SetStatus(BAM_COMMENTING_CONSTANT.Accepted);
                    }
                }
            }
            SetNodes();
        }

        $scope.On_PM_Res_Status_Changed = function() {
            var status = $scope.resMsgCustomFields["All_Response"]["PM_Response"]["PM_Res_Status"];
            if (status && status.indexOf("Closed") > -1) {
                var setStatus = "Closed - " + $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_FORMSTATUS']
                SetStatus(setStatus);
                SetReview_Stage(setStatus);
                $scope.PmResStatusChangeSetStatusOkCallBack(status);                
            } else {
                //Sent to contractor
                $scope.PmResStatusChangeSetDsFormStatus(false);
                SetReview_Stage(BAM_COMMENTING_CONSTANT.Sent_to_Contractor);
            }
        };

        $scope.setAllOpenCommentsClosed = function() {
            
            var resInfo = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'];
            for (var i = 0; i < resInfo.length; i++) {
                var visibleResInfo = resInfo[i];

                if (visibleResInfo.visible == "YES") {
                    var commentInfo = visibleResInfo['All_Comments']['Comments_Info'];

                    for (var j = 0; j < commentInfo.length; j++) {
                        var multiInfo = commentInfo[j]['Multicomment']['MultiComment_info'];

                        for (var k = 0; k < multiInfo.length; k++) {                            
                            $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"]['All_Response']['Res_Info'][i]['All_Comments']['Comments_Info'][j]['Multicomment']['MultiComment_info'][k].Severity = "close";                            
                        }
                    }
                }
            }
        }

        $scope.ON_Comments_Info = function(resInfo) {
            if (!resInfo)
                return;

            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            //Comment counter
            resMsgCustomFields['Counters']['comment_ctr'] = "1";

            //Id counter
            resMsgCustomFields['Counters']['Id_ctr'] = "1";

            var iPMCnt = 0,
                iContCnt = 0;
            SetRepeatComment_Counter(iPMCnt, iContCnt, true);

            var strParentResponse_id = resInfo.Response_id;
            var strParentUId = resInfo.UID;

            for (var j = 0; j < resInfo['All_Comments']['Comments_Info'].length; j++) {
                var commentInfo = resInfo['All_Comments']['Comments_Info'][j];

                commentInfo.UID = strParentUId;
                commentInfo.Ref_Res_Id = strParentResponse_id;
                commentInfo.Idx = j + 1;

                for (var k = 0; k < commentInfo['Multicomment']['MultiComment_info'].length; k++) {
                    var multiInfo = commentInfo['Multicomment']['MultiComment_info'][k];

                    multiInfo.UID = strParentUId;
                    multiInfo.Ref_Res_Id = strParentResponse_id;
                    multiInfo.Idx = j + 1;
                    multiInfo.Id = k + 1;

                    for (var l = 0; l < multiInfo['CommentGroup']['RepeatCommentGroup'].length; l++) {
                        var repeatInfo = multiInfo['CommentGroup']['RepeatCommentGroup'][l];

                        repeatInfo.UID = strParentUId;
                        repeatInfo.Ref_Res_Id = strParentResponse_id;
                        repeatInfo.Idx = j + 1;
                        repeatInfo.Id = k + 1;

                        if (!repeatInfo.RepeatComment_Id) {
                            var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                            if (strCurrentStage == "5") {
                                iContCnt++;
                                repeatInfo.RepeatComment_Id = "C" + iContCnt;
                            } else {
                                iPMCnt++;
                                repeatInfo.RepeatComment_Id = "" + iPMCnt;
                            }
                        }

                        if (l == 0 && repeatInfo.IsDeleted != "YES" && (repeatInfo.CommentBy != "Contractor" && repeatInfo.Label != "Contractor")) {
                            repeatInfo.Label = "PM";
                        }
                    }

                    resMsgCustomFields['Counters']['Id_ctr'] = (k + 1) + "";
                }

                resMsgCustomFields['Counters']['comment_ctr'] = (j + 1) + "";
                CheckCommentAvailabel(commentInfo);
            }
            ResetPMCommentNumbers();
        };

        //Set Flag for NOODLE-52087
        var CheckCommentAvailabel = function(commentInfo) {
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];

            // Check Comment Level   
            var strUId = commentInfo.UID;
            var resInfo = commonApi._.findWhere(resMsgCustomFields['All_Response']['Res_Info'], {
                UID: strUId,
                visible: "YES"
            });
            if (!resInfo) {
                return
            }
            var xpniTotalNodes = commonApi._.filter(resInfo.All_Comments.Comments_Info, function(o) {
                return (o.UID == strUId);
            });
            var xpniNodes = commonApi._.filter(xpniTotalNodes, function(o) {
                return (o.Comment_Level == BAM_COMMENTING_CONSTANT.Package || o.Comment_Level == BAM_COMMENTING_CONSTANT.Document);
            });

            /*
             * xpniTotalNodes This total count added to cross check, a particular rolewise user's first comment will not gets enabled and disabled.
             * Ref NOODLE-55598 hjadeja 25/Apr/2016
             */
            var strPostFix = "ShowAcceptedComment";
            if (xpniTotalNodes.length > 1 && xpniNodes.length) {
                resMsgCustomFields['DisplayGroup']['Flag_NoComment_Level'] = "NO#" + strPostFix;
            } else {
                if (xpniNodes.length) {
                    strPostFix = "HideAcceptedComment";
                }
                resMsgCustomFields['DisplayGroup']['Flag_NoComment_Level'] = "YES#" + strPostFix;
            }

            var xpniNoNodes = commonApi._.filter(xpniTotalNodes, function(o) {
                return (o.Comment_Level == 'No Comment');
            });
            if (xpniTotalNodes.length > 1 && xpniNoNodes.length) {
                resMsgCustomFields['DisplayGroup']['Flag_Pkg_Doc_Comment_Level'] = "NO";
            } else {
                resMsgCustomFields['DisplayGroup']['Flag_Pkg_Doc_Comment_Level'] = "YES";
            }
        };

        var ResetPMCommentNumbers = function() {            
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];

            var iPMCnt = 0,
                iContCnt = 0;
            SetRepeatComment_Counter(iPMCnt, iContCnt, true);

            var strCurrentStage = oriMsgCustomFields['CurrentStage'];
            var xpninodeofRC = resMsgCustomFields['All_Response']['Res_Info'];
            xpninodeofRC = commonApi._.where(xpninodeofRC, {
                visible: 'YES'
            });

            if (xpninodeofRC.length) {
                for (var i = 0; i < xpninodeofRC.length; i++) {
                    var resInfo = xpninodeofRC[i];

                    for (var j = 0; j < resInfo['All_Comments']['Comments_Info'].length; j++) {
                        var commentInfo = resInfo['All_Comments']['Comments_Info'][j];

                        for (var k = 0; k < commentInfo['Multicomment']['MultiComment_info'].length; k++) {
                            var multiInfo = commentInfo['Multicomment']['MultiComment_info'][k];

                            var hasFirstPM = false;
                            for (var l = 0; l < multiInfo['CommentGroup']['RepeatCommentGroup'].length; l++) {
                                var repeatInfo = multiInfo['CommentGroup']['RepeatCommentGroup'][l];
                                if (l == 0 && repeatInfo.UID == resInfo.UID && repeatInfo.IsDeleted != "YES" && repeatInfo.CommentBy != "Contractor" && repeatInfo.Label != "Contractor") {
                                    iPMCnt++;
                                    repeatInfo.RepeatComment_Id = iPMCnt + "";
                                    repeatInfo.Label = "PM";
                                    hasFirstPM = true;
                                } else if (strCurrentStage == "5" && repeatInfo.Label == "Contractor") {
                                    iContCnt++;
                                    repeatInfo.RepeatComment_Id = "";

                                    if (hasFirstPM) {
                                        repeatInfo.comment_against = iPMCnt + "";
                                    } else {
                                        repeatInfo.comment_against = "";
                                    }
                                } else {
                                    repeatInfo.RepeatComment_Id = "";
                                }
                            }
                        }
                    }
                }
            }

            SetRepeatComment_Counter(iPMCnt, iContCnt, true);
        };
        $scope.On_DocStatus_changed = function (associatedDoc) {
            var DS_ALL_FORMSTATUS = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];
            var DS_FORMSTATUS = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
            SendActionInPkgForm();
            AutoSetPackageStatus();               
        };
        $scope.On_RC_Send_To_Changed = function(value) {

            if (!value) {
                return;
            }
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            if ($scope.Selected_Tech_Autho['Selected_Project_Managers'] && $scope.Selected_Tech_Autho['Selected_Project_Managers']["Selected_Project_Manager"] && $scope.Selected_Tech_Autho['Selected_Project_Managers']["Selected_Project_Manager"].length) {
                var selectedPM = commonApi._.filter(resMsgCustomFields['All_Response']['Selected_Tech_Autho']['Selected_Project_Managers']["Selected_Project_Manager"], function(obj) {
                    return obj["isUserActive"] == true
                });
           
            } else {
                $scope.Selected_Tech_Autho['Selected_Project_Managers']["Selected_Project_Manager"] = [{
                    "PMName": "",
                    "isUserActive": true
                }];
            }
            $scope.Selected_Tech_Autho['Selected_TIG'] = '';
            if (value == BAM_COMMENTING_CONSTANT.Project_Manager) {
                SetStatus("Sent to PM");
                SetReview_Stage("Sent to PM by RC");
            } 
        };
        $scope.Change_Status_On_TA_Selection = function() {

            SetStatus("Sent to TA");
            SetReview_Stage("Sent to TA");
        };
        $scope.checkDuplicateValue = function(args) {
            //Added for NOODLE-59180 (Need normal alert)        
            var currentTargetName = args.model[args.key],
                allTagretData = args.repetObj,
                isValidFlag = true;

            for (var i = 0; i < allTagretData.length; i++) {
                var ele = allTagretData[i];
                if (i != args.index && currentTargetName == ele[args.key]) {
                    alert("Duplicate " + args.msg + " selected. Select a different " + args.msg);
                    args.model[args.key] = "";
                    isValidFlag = false;
                    break;
                }
            };
            return isValidFlag;
        };

        $scope.TTT_ExportToExcel = function() {
            var form_template_name = "BAM_CommentingFormExport",
                Report_format = "XLSM",
                reportName = "BAM_CommentingFormExport",
                reportType = "Ext",
                valueArray = "";
            showSelectedReportfromApp(form_template_name, Report_format, reportType, valueArray, reportName);
        }

        $scope.switchCommentingTab = function(evt, tabName) {
            
            $scope.oriMsgCustomFields["activeTab"] = tabName;
            $scope.delayedExpandTextAreaOnLoad();
        }

        $scope.switchCommentingTab_Res_View = function(evt, tabName) {
            
            $scope.oriMsgCustomFields["activeTab_Res_View"] = tabName;
            $scope.delayedExpandTextAreaOnLoad();
        }
        $scope.On_Comment_Level_Clicked = function(commentInfo) {
            var commentLevel = commentInfo.Comment_Level;
            commentInfo.Comment_Level_Prev_Value = commentLevel;
        }
        function clerDocDetail(commentInfo) {
        commentInfo.Doc_Title = "";
            commentInfo.Doc_status = "";
            commentInfo.DocFolder_Name = "";
            commentInfo.Doc_FolderId = "";
            commentInfo.Doc_Rev = "";
            commentInfo.Doc_ID = "";
            commentInfo.Doc_ref = "";
        }

        $scope.On_Comment_Level_Changed = function(commentInfo, $index, resInfo, myform) {
            var resMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["RES_MSG_Custom_Fields"];
            var oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];            
            var strWorkingUserName = $scope.workingUserDetails[0].Name || "";
            
            if (commentInfo.Comment_Level) {
                var repeatCommentArray = resInfo['All_Comments']['Comments_Info'] || [];
                if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Package || commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.No_Comment) {
                    var isUnique = $scope.checkDuplicateValue({
                        model: commentInfo,
                        key: 'Comment_Level',
                        index: $index,
                        repetObj: repeatCommentArray,
                        msg: 'Comment Level'
                    });
                    clerDocDetail(commentInfo);
                    if (!isUnique) {
                        commentInfo.Comment_Level = "";
                        return;
                    }
                    if (commentInfo.Comment_Level ==BAM_COMMENTING_CONSTANT.No_Comment) {
                        commentInfo.Recommend.Recommend_Doc_Level = "";
                        //TODO :As mentioned action in infopath
                        commentInfo.Recommend.Recommend_Doc_Level = "";

                        commonApi._.each(commentInfo.Multicomment.MultiComment_info, function(o) {
                            o.Severity = "";
                            commonApi._.each(o.CommentGroup.RepeatCommentGroup, function(obj) {
                                obj.Comment = "";
                            });
                        });
                    }
                } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Document) {
                    commentInfo.Recommend.Recommend_Doc_Level = "";
                }

                //NOODLE-60482
                if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Package || commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.Document) {
                    if (resInfo['Response_Accepted'] === BAM_COMMENTING_CONSTANT.Accepted || resInfo['Response_Accepted'] === "N/A") {
                        resInfo['Response_Accepted'] = "";
                    }
                    //NOODLE-63206
                    var deletedItemDocID = repeatCommentArray[$index].Doc_ID || "";
                    $scope.duplicateDocValidation(repeatCommentArray, myform, false, deletedItemDocID);
                } else if (commentInfo.Comment_Level == BAM_COMMENTING_CONSTANT.No_Comment) {
                    resInfo['Response_Accepted'] = "";
                }


                // delete self if comment level change
                var Ref_Res_Id = commentInfo.Ref_Res_Id;
                var Idx = commentInfo.Idx;
                var UID = commentInfo.UID;

                commentInfo.Multicomment.MultiComment_info = [];

                // Add Blank Node    after deletion             
                var strCurrentStage = oriMsgCustomFields['CurrentStage'];
                var strDis_Flag_PM_section = resMsgCustomFields['DisplayGroup']['Dis_Flag_PM_section'];

                //NOODLE-48494 Removed workspace role and used stored roles in repeating tables at form creation time.
                var strReviewCoordinatorUserArr = commonApi._.filter(oriMsgCustomFields['ReviewCoordinatorUsers']["ReviewCoordinatorUser"], function(obj) {
                    return obj["isUserActive"] == true
                });
                var strReviewCoordinatorUser = strReviewCoordinatorUserArr[0] && strReviewCoordinatorUserArr[0]['ReviewCoordinatorName'] || "";                
               var strWORKINGUSER = $scope.workingUserDetails[0].Value || "";

                var strUser = strWORKINGUSER.split('|')[0].trim() + " # " + strWORKINGUSER.split('#')[1].trim();
                var xpniRoleNode = oriMsgCustomFields['ReviewersGroupUsers']['ReviewersInfo'];
                xpniRoleNode = commonApi._.filter(xpniRoleNode, function(o) {
                    return (strUser && o.User.indexOf(strUser) > -1);
                })[0];

                var strRoles = "";
                if (xpniRoleNode) {
                    strRoles = xpniRoleNode.Role;
                }

                var xpnRoleNode = oriMsgCustomFields['ReviewCoordinatorGroupUsers']['User_info'];
                xpnRoleNode = commonApi._.filter(xpnRoleNode, function(o) {
                    return (strUser && o.UserId.indexOf(strUser) > -1);
                })[0];

                if (xpnRoleNode) {
                    strRoles = xpnRoleNode.UserRole;
                }

                var k = 0;
                var iPMCnt = 0,
                    iContCnt = 0;
                var Id_ctr = resMsgCustomFields['Counters']['Id_ctr'];
                k = parseInt(Id_ctr);
                k++;

                var cntArray = SetRepeatComment_Counter(iPMCnt, iContCnt, false);
                iPMCnt = cntArray[0];
                iContCnt = cntArray[1];

                var multiCommentInfoObj = angular.copy(STATIC_OBJ_DATA['multiCommentInfo']);

                multiCommentInfoObj.UID = UID;
                multiCommentInfoObj.Ref_Res_Id = Ref_Res_Id;
                multiCommentInfoObj.Idx = Idx;
                multiCommentInfoObj.Id = k;
                multiCommentInfoObj.ReviewerName = strWorkingUserName;
                multiCommentInfoObj.IsOpenClose = "Open";

                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].UID = UID;
                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].Ref_Res_Id = Ref_Res_Id;
                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].Idx = Idx;
                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].Id = k;
                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].RepeatComment_Id = 1;
                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].seqNo = 1;


                if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4") {
                    iPMCnt++;
                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].RepeatComment_Id = iPMCnt;
                } else if (strCurrentStage == "5") {
                    iContCnt++;
                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].RepeatComment_Id = iContCnt;
                } else {
                    iPMCnt++;
                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].RepeatComment_Id = iPMCnt;
                }

                multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].CommentBy = strRoles;

                if (strDis_Flag_PM_section == "YES" && strCurrentStage == "4")
                {
                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].Label = "PM";
                    multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].PM_Name = strWorkingUserName;
                }
                    
                else if (strCurrentStage == "5")
                {
                     multiCommentInfoObj.CommentGroup.RepeatCommentGroup[0].Label = strWorkingUserName;
                }                 
                commentInfo.Multicomment.MultiComment_info.push(multiCommentInfoObj);
                SetRepeatComment_Counter(iPMCnt, iContCnt, true);
                resMsgCustomFields['Counters']['Id_ctr'] = k + "";
            } else {
                // Set Reviewer Name if RC directly create Response 
                var xpnNode = commentInfo.Multicomment.MultiComment_info;
                if (xpnNode && xpnNode[0] && xpnNode[0].ReviewerName) {
                    xpnNode[0].ReviewerName = strWorkingUserName;
                }
            }

            CheckCommentAvailabel(commentInfo);
            ResetPMCommentNumbers();

            if (!commentInfo.Comment_Level_Prev_Value) {
                commentInfo.Comment_Level_Prev_Value = "";
            }
            $scope.validateDocumentsStatusOnRadioChange(commentInfo);            
        };
        var setWorkflow = function() {            
            var tempList = [],
                tempObj = {},
                tempChildObj = {},
                tempTaskUser={},
                splitedChild = [],
                userId = "",
                actionName = "",
                dateFromDays = commonApi.calculateDistDateFromDays({
                    baseDate: serverDate,
                    days : $scope.getCalculatedActionDueDate("REVIEWER_DUE_DATE")
                });
            
            for(var i=0; i<$scope.oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'].length; i++) {
                tempObj = $scope.oriMsgCustomFields['Reviewers_DistGrps']['Reviewers_distg'][i];
                for(var j=0; j<tempObj.Reviewer_UserName.length; j++) {
                    tempChildObj = tempObj.Reviewer_UserName[j];
                    splitedChild = tempChildObj.split('|');
                    userId = splitedChild[0];
                    actionName = '3#Respond';
                    tempList.push({
                        strUser : userId,
                        strAction : actionName,
                        strDate : actionName.indexOf('Respond') > -1 ? dateFromDays : ""
                    });
                    if(!tempTaskUser.hasOwnProperty(userId)) {
                        tempTaskUser[userId] = tempChildObj;
                    }   
                }
                $scope.oriMsgCustomFields['Task_Reviewer_Groups_Contacts'] = Object.keys(tempTaskUser);
            }

			// Distribution Will be made from here
			commonApi.setDistributionNode({
				actionNodeList : tempList,
				autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE : '3'
            });
        };

        $window.formSubmitCallBack = function () {
			!$scope.isCallForDraft && setWorkflow();
			return false;
		};
        $window.customHTMLMethodBeforeCreate_ORI = function() {
            if (currentViewName == "ORI_VIEW") {
                var cldate = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'];
                $scope.oriMsgCustomFields['PackageDeliveryDate'] = $scope.formatDate(new Date(cldate), 'dd/mm/yy');
                setWorkflow();
            }
            if (currentViewName == "RES_VIEW") {
                if (doNotSubmitResView) {
                    return true;
                } else if (gIsActionIncomplete) {
                    return false;
                }
                if( currentViewName == 'RES_VIEW')
                {
                    var Res_Info = $scope.resMsgCustomFields['All_Response']['Res_Info'];
                    if (Res_Info.length) {
                        for (var i = 0; i < Res_Info.length; i++) {
                            var resInfo = Res_Info[i];
        
                            for (var j = 0; j < resInfo['All_Comments']['Comments_Info'].length; j++) {
                                var commentInfo = resInfo['All_Comments']['Comments_Info'][j];
                                if(commentInfo.Comment_Level!="")
                                {
                                    commentInfo.DSI_Chk_Done="1";
                                }
                               
                            }
                        }
                    }
                }
                customHTMLMethodBeforeCreate_For_RES_VIEW();
                return true;
            } else if (currentViewName == "ORI_VIEW" && !gIsActionIncomplete && $('#save_draft').val() != "0") {
                customHTMLMethodBeforeCreate_For_ORI_VIEW();

            } else {
                return false;
            }
        }
    }
    return FormController;
});
var gIsActionIncomplete = false; //Global defined to check for incomplete action SP on send click.
var doNotSubmitResView = false;
var isDCChangeUser = false;
function customHTMLMethodBeforeCreate_For_ORI_VIEW() {
    window.updateFormXsnTitle(true, true);
}

var ViewFormDWR = {};
ViewFormDWR.getCallbackData = function(field, param, formId, projectId, userID, proxyUserID, callback) {
    var callBac = callback;
    var paramsObj = {
        field: field,
        param: param,
        formId: formId,
        projectId: projectId,
        action_id: 173
    };
    $.ajax({
        data: paramsObj,
        dataType: 'text',
        url: '/adoddle/apps',
        type: 'POST',
        cache: false,
        crossDomain: true,
        xhrFields: {
            withCredentials: true
        },
        success: function(data) {
            callBac(data);
        },
        error: function(xhr, textStatus, errorThrown) {
            errorCallbak & errorCallbak(xhr);
        }
    });
}
function customHTMLMethodBeforeCreate_For_RES_VIEW() {
    var projID = null;
    var spName = 'DS_IS_USER_ACTION_INCOMPLETE';
    var flg = document.URL.indexOf('adoddle') > 0;
    var prxyUsrID = null;

    if (!flg && currentViewName == 'ORI_PRINT_VIEW') {
        prxyUsrID = getValue(ISC_HASHED_USER_ID)
            .split('$$')[0];
        hashedprojectid = currProjId;
    } else {
        prxyUsrID = flg ? USP.proxyUserID : proxyuserid;
    }
    
    if (!document.getElementById("formParentDiv") && flg) { 
        projID = hashprojectId; //For adoddle
    } else {
        projID = flg ? hashprojectId : hashedprojectid.split('$$')[0]; //For classic
    }
    var usrID = flg ? USP.userID : userId;
    var frmID = flg ? document.getElementById('formId').value : document.getElementById('formId').value.split('$$')[0];
    ViewFormDWR.getCallbackData(spName, '', frmID, projID, usrID, prxyUsrID, function(data) {
        window.clearRCSubmitClearORIAction(data);
        //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code starts        
        var flag = window.checkUserReviewDraft();
        if (!flag) {
            checkResponseData(data, flg);
        } else {
            gIsActionIncomplete = true;
            submitForm(1);
        }
        //NOODLE-90135 review draft development ptahiliani 03-04-2019 - code ends
    });
}
function checkResponseData(data, flg) {
    var alertMsg = 'You have no pending Action.!!';
    var str = $(data).find("Value").text();

    if (isDCChangeUser) {
        str = 'Y'; //DC is changing Users
    }
    if (str == 'N') {
        if (flg) {
            ADODDLE.alert({
                title: 'Alert',
                msg: alertMsg
            })
        } else {
            alert(alertMsg)
        }
        doNotSubmitResView = true;
        submitForm(1);
    } else {
        gIsActionIncomplete = true;
        submitForm(1);
    }
}
