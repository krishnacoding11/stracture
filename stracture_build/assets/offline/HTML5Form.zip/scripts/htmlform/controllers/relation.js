define(['angular', './base', '../components/folder.selection', '../components/item.selection'], function(angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout) {
		
		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
            onComplete: function () {
            	$timeout(function() {
            		$scope.loaded = true;
            		$element.addClass('loaded');                
            	}, 50);
            }
        });
		
		var ctrl = this;
		var sendObj={};
		var count = 0;
		$scope.clickSave = false;
		$scope.statuses = undefined;
		$scope.data = '';
		$scope.Mainstatuses =  [
            {"name":"No relation","value":"1"},
            {"name":"Invited/Requested","value":"2"},
            {"name":"Pending","value":"3"},
            {"name":"Connected","value":"4"},
            {"name":"Qualified","value":"5"},
            {"name":"Under Review","value":"6"}
        ];
		$scope.disabled ={allSelected : false};
		$scope.stageDetails = [];
		$scope.formFields = [
			{"formFieldName":"Norelation","value":""},
			{"formFieldName":"RelationshipInProgress","value":""},
			{"formFieldName":"RelationshipApproved","value":""},
			{"formFieldName":"RelationshipRejected","value":""}
		]
		 ctrl.$onInit = function() {
			 $scope.update();
			 $scope.data = $scope.getFormData();
			 var xmlAllFormStatus = $scope.getValueOfOnLoadData('DS_BUYER_VENDOR_RELATIONSHIP_STATUS');
			 $scope.statuses = xmlAllFormStatus;
			 setData();
		}
		$scope.radioSelected = function(e){
			$scope.data.stageDetails=[];
			if($('.statusRadio:checked').length >= $scope.statuses.length){
				for(var i=0; i<$scope.Mainstatuses.length;i++){
				 for(var j=0; j<$scope.statuses .length;j++){
					if($scope.Mainstatuses[i].value == $scope.statuses[j].selectedStatus){
						//$scope.formFields[i].value += $scope.statuses[j].Value.split(" #")[0] +"#"
						$scope.data.stageDetails.push({
							"stage": {
								"stageId": $scope.Mainstatuses[i].value,
								"statusId": $scope.statuses[j].Value1
							}
						})
					}
				 }
				 
			 }
				$scope.disabled.allSelected = true;
			}
		}
		$scope.cancel= function(){
			$window.top.postMessage("closeCreateFormIframe:-1",'*')
		}
		var setData = function(){
			for(var i=0;i<$scope.statuses.length;i++){
				for(var j=0;j<$scope.Mainstatuses.length;j++){
					for(var k=0;k<$scope.data.stageDetails.length;k++){
						if($scope.data.stageDetails[k].stage.stageId == $scope.Mainstatuses[j].value && $scope.data.stageDetails[k].stage.statusId == $scope.statuses[i].Value1){
							$scope.statuses[i].selectedStatus = $scope.Mainstatuses[j].value;
						}
					}
				}
			}
		}
		
	}
	return FormController;
});