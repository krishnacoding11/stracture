/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/table.util', '../components/item.selection', '../components/inlineattachment', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout, $filter) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.CC_Name_Group_Table = {
            isSelected: '',
            CC_Name: '',
            CC_Group: '',
        }
        $scope.GeoTechnical_Group_Table = {
            isSelectedGeoTeam: '',
            Geo_Team_Group_Name: '',
            Geo_Team_Act_Req: '',
            Geo_Team_Name: '',
            Geo_Team_Comment: '',
            Geo_Team_Date: ''
        }
        $scope.Consultant_Group_Table = {

            DSI_ResID: '',
            Con_Team_Group_Name: '',
            Con_Team_Act_Req: '',
            Con_Team_Name: '',
            Con_Team_Comment: '',
            Con_Signature: '',
            Con_Team_Res_Date: ''
        }
        $scope.CCUser_Info = {
            Tenderer_Organisation_Info: "",
            Tenderer_Recipient_Info: ""
        };

        $scope.Inspection_Survey_Table = {
            isSelectedInspection: '',
            Inspection_Survey_Name: '',
            Inspection_Survey_Group: ''
        }
        $scope.PartE_MTR_User_Group_Table = {
            isSelectedMTR: '',
            MTR_User_Name: '',
            MTR_User_Position: '',
            MTR_User_Date: ''
        }
        $scope.ConActionuserstruct = {
            Con_Dist_User: "",
            Con_Proj_Roles: "",
            Con_Actions: "",
            Con_isSelected: false
        }
        $scope.Item_No_Group_Table = {
            isSelectedItem: '',
            Item_No: ''
        }
        $scope.Drawing_Submission_Ref_Table = {
            isSelectedDrawingRef: '',
            Drawing_Submission_Ref_No: '',
            Drawing_Sub_Ref_Other: ''
        }
        $scope.Work_Proposed_After_Approval_Table = {
            isSelectedWorkProposed: '',
            Work_Proposed_After_Approval: '',
            Work_After_Approval_Other: ''
        }
        $scope.PartB_Attachments = {
            General_Attachment: ""
        }
        $scope.PartC_Attachments = {
            PartC_Attachment: ""
        }
        $scope.PartD_Attachments = {
            PartD_Attachment: ""
        }
        $scope.PartE_Attachments = {
            PartE_Attachment: ""
        }
        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.completeActionStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }
        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.tableUtilSettings = {

            CC_Name_Group_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy($scope.CC_Name_Group_Table),
                hideControlIcon: {
                    insertBefore: 0,
                    editRow: 0
                },
                deleteAllRowTooltip: "Remove Cc Group",
                deleteCurrRowMsg: "Remove Cc Group",
                deleteSelectedMsg: "Remove Cc Group"
            },
            GeoTechnical_Group_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedGeoTeam",
                newStaticObject: angular.copy($scope.GeoTechnical_Group_Table),
                ADD_NEW_BEFORE_TIP: "Insert before CC Detail",
                ADD_NEW_AFTER_TIP: "Insert after CC Detail",
                deleteAllRowTooltip: "Remove all CC Detail",
                deleteCurrRowMsg: "Remove CC Detail",
                deleteSelectedMsg: "Remove selected CC Detail"
            },
            Inspection_Survey_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedInspection",
                newStaticObject: angular.copy($scope.Inspection_Survey_Table),
                ADD_NEW_BEFORE_TIP: "Insert before CC Detail",
                ADD_NEW_AFTER_TIP: "Insert after CC Detail",
                deleteAllRowTooltip: "Remove all CC Detail",
                deleteCurrRowMsg: "Remove CC Detail",
                deleteSelectedMsg: "Remove selected CC Detail"
            },
            PartE_MTR_User_Group_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedMTR",
                newStaticObject: angular.copy($scope.PartE_MTR_User_Group_Table),
                ADD_NEW_BEFORE_TIP: "Insert before CC Detail",
                ADD_NEW_AFTER_TIP: "Insert after CC Detail",
                deleteAllRowTooltip: "Remove all CC Detail",
                deleteCurrRowMsg: "Remove CC Detail",
                deleteSelectedMsg: "Remove selected CC Detail"
            },
            Item_No_Group_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedItem",
                newStaticObject: angular.copy($scope.Item_No_Group_Table),
                ADD_NEW_BEFORE_TIP: "Insert before Item Detail",
                ADD_NEW_AFTER_TIP: "Insert after Item Detail",
                deleteAllRowTooltip: "Remove all Item Detail",
                deleteCurrRowMsg: "Remove Item Detail",
                deleteSelectedMsg: "Remove selected Item Detail"
            },            
            Consultant_Distribution: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "Con_isSelected",
                newStaticObject: angular.copy($scope.ConActionuserstruct),                
                deleteAllRowTooltip: "Remove Consultant",
                deleteCurrRowMsg: "Remove Consultant",
                deleteSelectedMsg: "Remove selected Consultant"
            },
            Drawing_Submission_Ref_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedDrawingRef",
                newStaticObject: angular.copy($scope.Drawing_Submission_Ref_Table),
                ADD_NEW_BEFORE_TIP: "Insert before Drawing Submission",
                ADD_NEW_AFTER_TIP: "Insert after Drawing Submission",
                deleteAllRowTooltip: "Remove all Drawing Submission",
                deleteCurrRowMsg: "Remove Drawing Submission",
                deleteSelectedMsg: "Remove selected Drawing Submission"
            },
            Work_Proposed_After_Approval_Table: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                hasDefaultRecord: true,
                checkboxModelKey: "isSelectedWorkProposed",
                newStaticObject: angular.copy($scope.Work_Proposed_After_Approval_Table),
                ADD_NEW_BEFORE_TIP: "Insert before Work Proposed",
                ADD_NEW_AFTER_TIP: "Insert after Work Proposed",
                deleteAllRowTooltip: "Remove all Work Proposed",
                deleteCurrRowMsg: "Remove Work Proposed",
                deleteSelectedMsg: "Remove selected Work Proposed"
            },
        }

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.ORI_MSG_Fields = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields;
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];


        $scope.dsPartAFields = $scope.formCustomFields["PartA"];
        $scope.dsPartBFields = $scope.formCustomFields["PartB"];
        $scope.dsPartCFields = $scope.formCustomFields["PartC"];
        $scope.dsPartDFields = $scope.formCustomFields["PartD"];
        $scope.dsPartEFields = $scope.formCustomFields["PartE"];

        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.strIsDraft_Res = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES;
        $scope.strIsDraft_Res_Msg = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var WorkingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var dsProjUsersAllRoles = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']["Status_Data"]["DS_ALL_FORMSTATUS"];
        var incompleteActionsByMsg = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS_BYMSG") || [];
        var incompleteMessageAction = $scope.getValueOfOnLoadData("DS_INCOMPLETE_MSG_ACTIONS") || [];
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var dsUserdetailsFiltered = $scope.getValueOfOnLoadData('DS_USERDETAILS_FILTERED');
        var DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        var DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
        formStatus = formStatus && formStatus.split('#')[1].trim();
        $scope.strFormStatus = formStatus;

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateDbFormatForTitle = $scope.formatDate(new Date(serverDate), 'dd/mm/yy');
        });

        if (currentViewName == "ORI_VIEW") {

            $scope.strCanReply = "";
            setLocation();
            setCategory();
            setDrawingSubmissionRef();
            setWorkPruposedFromCustomAttribute();
            setITPSQPRef();
            setContractTitle();
            setContractNo();

            setDrawingSubFromCustomAtt();
            setWorkProposedFromCustomAtt();
            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {

                $scope.orgFilter = DS_PROJORGANISATIONS_ID;
                $scope.oriMsgCustomFields.DSI_Current_Stage = '0';
                $scope.oriMsgCustomFields.DSI_Next_Stage = '1';
                $scope.oriMsgCustomFields.DSI_Revision = '0';
                $scope.dsPartAFields.contractTitle = '';

                var strWorkingUserId = getWorkingUserId();
                $scope.dsPartAFields.Originator_Id = strWorkingUserId;
                $scope.dsPartAFields.Originator_Name = strWorkingUserId + "#" + $scope.WorkingUserID[0].Name;

                var strRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES') || [];
                strRoles = strRoles[0] || {};
                strRoles = strRoles.Value || "";

                if (strRoles.indexOf('Contractor') != -1) {
                    $scope.strCanReply = 'yes';
                    $scope.dsPartAFields.Checked_By = dsUserdetailsFiltered[0].Value2;
                    $scope.dsPartAFields.Checked_By_Position = dsUserdetailsFiltered[0].Name;                    
                    var formatteddate = $filter('date')(getDateTimeFromZone(), 'dd/MM/yyyyTHH:mm a');                                        
                    $scope.dsPartAFields.Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();

                } else {
                    $scope.Msg = 'You are not authorized to create this form. Please contact Workspace Administrator';
                    $scope.strCanReply = '';
                }
            }
        }
        if (currentViewName == "RES_VIEW") {

            if ($scope.strIsDraft_Res_Msg == 'NO') {
                $scope.oriMsgCustomFields.DSI_MSGID = getMsgId();
            }
            $scope.strCanReply = '';
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
            var formatteddate = $filter('date')(getDateTimeFromZone(), 'dd/MM/yyyyTHH:mm a');
            if ($scope.strFormId != '' || $scope.strIsDraft_Res == 'YES') {

                $scope.orgFilter = DS_PROJORGANISATIONS_ID;
                var nextStage = $scope.oriMsgCustomFields.DSI_Next_Stage;
                $scope.oriMsgCustomFields.DSI_Current_Stage = nextStage;
                var workinguserRole = WorkingUserAllRole['0'].Value;
                var strFormType = $scope.oriMsgCustomFields.Form_Type;

                if(strFormType && strFormType=='Inspection'){
                    
                    if (workinguserRole && (workinguserRole.indexOf('IGroup') > -1)) {

                        $scope.consultantuser = true;
                    } else {
                        $scope.consultantuser = false;
                    }
                }
                if(strFormType && strFormType=='Survey'){
                    
                    if (workinguserRole && (workinguserRole.indexOf('SGroup') > -1)) {

                        $scope.consultantuser = true;
                    } else {
                        $scope.consultantuser = false;
                    }
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '0' && $scope.DS_FORMSTATUS == 'Failed') {

                    setSendPermission(checkUserIncompleteActions());
                    setLocation();
                    setCategory();
                    setDrawingSubmissionRef();
                    setWorkPruposedFromCustomAttribute();
                    setITPSQPRef();
                    setContractTitle();
                    setContractNo();
                    setDrawingSubFromCustomAtt();
                    setWorkProposedFromCustomAtt();
                    if($scope.strIsDraft_Res == 'NO'){
                        
                        $scope.dsPartAFields.Check_On_Time='';
                        $scope.dsPartAFields.Check_On_Date='';
                        $scope.dsPartAFields.Checked_By_Signature = '';
                        $scope.dsPartAFields.Checked_By = dsUserdetailsFiltered[0].Value2;
                        $scope.dsPartAFields.Checked_By_Position = dsUserdetailsFiltered[0].Name;                    
                        $scope.dsPartAFields.Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();;                    
                        $scope.dsPartBFields.Consultant_Group_Details.Consultant_Group_Table = [];
                    }
                    
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '1' && $scope.DS_FORMSTATUS == 'Open') {

                    setSendPermission(checkUserIncompleteActions());
                    if(strFormType && strFormType=='Inspection'){
                        $scope.conRoles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                            return val.Name.toLowerCase().indexOf('igroup') >= 0;
                        });
                    }
                    if(strFormType && strFormType=='Survey'){
                        $scope.conRoles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                            return val.Name.toLowerCase().indexOf('sgroup') >= 0;
                        });
                    }

                    // $scope.conRoles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                    //     return val.Name.toLowerCase().indexOf('group') >= 0;
                    // });
                    //clear values

                    if($scope.strIsDraft_Res == 'NO'){
                        
                        $scope.dsPartBFields.PartB_Received_By_Signature = '';
                        $scope.dsPartBFields.Inspection_Assigned_Group = '';
                        $scope.dsPartBFields.SendTo_Consultant = '';
                        $scope.dsPartBFields.Part_B_Checked_By_Signature = '';
                    }
                        $scope.dsPartBFields.PartB_Received_By_Name = dsUserdetailsFiltered[0].Value2;
                        $scope.dsPartBFields.PartB_Received_By_Position = dsUserdetailsFiltered[0].Name;                                                           
                        $scope.dsPartBFields.PartB_Received_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                    //end
                }
                if ($scope.consultantuser && $scope.DS_FORMSTATUS == 'Delegated for Inspection') {

                    setSendPermission(checkUserIncompleteActions());
                    if ($scope.strIsDraft_Res != 'YES') {
                        var strResCount = $scope.dsPartBFields.DSI_Res_Counter,
                            insertPoint = $scope.dsPartBFields.Consultant_Group_Details.Consultant_Group_Table;
                        strResCount++;
                        $scope.dsPartBFields.DSI_Res_Counter = strResCount;
                        if (insertPoint.length) {
                            for (var i = 0; i < insertPoint.length; i++) {
                                if (insertPoint[i].Con_Team_Comment) {
                                    insertPoint[i].DSI_ResFlag = "Old";
                                }
                            }
                        }
                        var resNodes = angular.copy($scope.Consultant_Group_Table);
                        var workinguserId = $scope.WorkingUserID['0'].Value.split('|')[0].trim();
                        var groupname = GetConsultantUserGroup(workinguserId);
                        var actionRequired = GetConsultantActionRequired(workinguserId);                                                              
                        resNodes.DSI_ResID = "RES00" + strResCount;
                        resNodes.Con_Team_Name = $scope.WorkingUserID['0'].Value.split('#')[1].trim();
                        resNodes.Con_Team_Group_Name = groupname;
                        resNodes.Con_Team_Act_Req = actionRequired;                        
                        resNodes.Con_Team_Res_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();;                                        
                        insertPoint.push(resNodes);

                    } else {
                        var responseObj = commonApi._.filter($scope.dsPartBFields.Consultant_Group_Details.Consultant_Group_Table, function (val) {
                            return val.DSI_ResFlag != "Old";
                        });
                        if (responseObj.length) {
                            responseObj[0].Con_Team_Name = $scope.WorkingUserID['0'].Value.split('#')[1].trim();;
                        }
                    }
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '2' && !$scope.consultantuser && $scope.DS_FORMSTATUS == 'Delegated for Inspection') {

                    setSendPermission(checkUserIncompleteActions());

                    //clear values

                    if($scope.strIsDraft_Res == 'NO'){

                        $scope.dsPartBFields.PartA_Checked = '';
                        $scope.dsPartBFields.Part2_Notes_Comments = '';
                        $scope.dsPartBFields.Inspection_Carried_Date = '';
                        $scope.dsPartBFields.Inspection_Carried_Time = '';
                        $scope.dsPartCFields.PartA_Incomplete = '';
                        $scope.dsPartCFields.Not_Ready_To_Be_Inspected = '';
                        $scope.dsPartCFields.Others_Option = '';
                        $scope.dsPartCFields.Others_Comment = '';
                        $scope.dsPartCFields.RICS_Cancelled = '';
                        $scope.dsPartCFields.RICS_Cancelled_Comment = '';
                        $scope.dsPartCFields.Permission_Is_Given = '';
                        $scope.dsPartCFields.Permission_Is_Not_Given = '';
                        $scope.dsPartCFields.Outstanding_Completed = '';
                        $scope.dsPartCFields.Outstanding_Not_Completed = '';
                        $scope.dsPartBFields.PartB_Attachments = [];
                        $scope.dsPartBFields.Part2_Photo_Comments = '';                        
                    }
                        $scope.dsPartBFields.Part_B_Checked_By_Name = dsUserdetailsFiltered[0].Value2;
                        $scope.dsPartBFields.Part_B_Checked_By_Position = dsUserdetailsFiltered[0].Name;                                                           
                        $scope.dsPartBFields.Part_B_Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                
                    //end
                                                                                
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '3' &&
                    ($scope.DS_FORMSTATUS == 'Failed (Pending Endorsement)' ||
                        $scope.DS_FORMSTATUS == 'Cancelled (Pending Endorsement)' ||
                        $scope.DS_FORMSTATUS == 'Passed (Pending Endorsement)')) {

                    setSendPermission(checkUserIncompleteActions());
                    //Clear values
                    if($scope.strIsDraft_Res == 'NO'){
                        
                        $scope.dsPartCFields.Endorsement_Signature = '';
                        $scope.dsPartCFields.Endorsement_Comment = '';
                        $scope.dsPartCFields.PartC_Attachments = [];
                        $scope.dsPartCFields.PartC_Comments = '';
                    }
                    //end
                    $scope.dsPartCFields.Endorsement_Name = dsUserdetailsFiltered[0].Value2;
                    $scope.dsPartCFields.Endorsement_Position = dsUserdetailsFiltered[0].Name;                    
                    $scope.dsPartCFields.Endorsement_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '4' &&
                    ($scope.DS_FORMSTATUS == 'Failed (Pending Acknowledgement)' ||
                        $scope.DS_FORMSTATUS == 'Passed (Pending Acknowledgement)' ||
                        $scope.DS_FORMSTATUS == 'Cancelled (Pending Acknowledgement)')) {

                    if (workinguserRole && (workinguserRole.indexOf('Contractor') > -1)) {

                        setSendPermission(checkUserIncompleteActions());
                        setWorkPruposedFromCustomAttribute();
                        //clear values
                        if($scope.strIsDraft_Res == 'NO'){
                            
                            $scope.dsPartDFields.RISC_Approced = '';
                            $scope.dsPartDFields.RISC_Rejected = '';
                            $scope.dsPartDFields.RISC_Cancelled = '';
                            $scope.dsPartDFields.RISC_Approved_Signature = '';
                            $scope.dsPartDFields.PartD_Attachments = [];
                            $scope.dsPartDFields.PartD_Comments = '';
                        }
                        //end

                        $scope.dsPartDFields.RISC_Approver_Name = dsUserdetailsFiltered[0].Value2;
                        $scope.dsPartDFields.RISC_Approver_Position = dsUserdetailsFiltered[0].Name;                        
                        $scope.dsPartDFields.RISC_Approver_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();

                    } else {
                        $scope.strCanReply = '';
                    }

                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == '5' && $scope.DS_FORMSTATUS == 'Passed') {

                    if (workinguserRole && (workinguserRole.indexOf('ConE') > -1 ||
                            workinguserRole.indexOf('LS') > -1 ||
                            workinguserRole.indexOf('SconE') > -1 ||
                            workinguserRole.indexOf('Inspection') > -1 ||
                            workinguserRole.indexOf('Survey') > -1)) {

                        $scope.strCanReply = 'yes';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                        if($scope.strIsDraft_Res == 'NO'){

                            $scope.dsPartEFields.PartE_Attachments = [];
                            $scope.dsPartEFields.PartE_Attachment_Comments = '';
                            $scope.dsPartEFields.PartE_Comments = '';
                            $scope.dsPartEFields.Part_E_User_Name = '';
                            $scope.dsPartEFields.Part_E_User_Position = '';
                            $scope.dsPartEFields.Part_E_User_Date = '';
                            $scope.dsPartEFields.Part_E_User_Signature = '';
                        }
                        $scope.dsPartEFields.Part_E_User_Name = dsUserdetailsFiltered[0].Value2;
                        $scope.dsPartEFields.Part_E_User_Position = dsUserdetailsFiltered[0].Name;                                                               
                        $scope.dsPartEFields.Part_E_User_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                    }
                }
            }
        }
        $scope.onSendToDesignchange = function (sendTo) {

            if (sendTo == 'Yes') {
                $scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users = [];
                $scope.addNewItem($scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users, $scope.ConActionuserstruct);
            } else if (sendTo == 'No') {
                $scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users = [];
            }
        }
        function GetConsultantUserGroup(strworkinguser) {

            var users = $scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users;
            var idFromGroup = '';
            if (users && users.length) {
                for (var i = 0; i < users.length; i++) {

                    if(users[i].Con_Dist_User.length){
                        
                        idFromGroup = users[i].Con_Dist_User.split('|')[2].split('#')[0].trim();
                    }
                    if (strworkinguser && idFromGroup && strworkinguser == idFromGroup) {

                        return users[i].Con_Proj_Roles.split('#')[1].trim();
                    }
                }
            }
        }
        function GetConsultantActionRequired(strworkinguser) {

            var users = $scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users;
            var idFromGroup = '';
            var actionRequired='';
            if (users && users.length) {
                for (var i = 0; i < users.length; i++) {

                    if(users[i].Con_Dist_User.length){
                        
                        idFromGroup = users[i].Con_Dist_User.split('|')[2].split('#')[0].trim();
                    }
                    if (strworkinguser && idFromGroup && strworkinguser == idFromGroup) {

                        return users[i].Con_Actions.trim();
                    }
                }
            }
        }
        $scope.createContractorItemSelectionArray = function (currObj, strVal) {
            if (strVal != '1') {
                currObj.Con_Dist_User = "";
            }
            var strRole = currObj.Con_Proj_Roles,
                users = "";
            if (strRole) {
                var roleName = strRole.split('#')[1].trim();

                users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                    return val.Value.split('|')[0].indexOf(roleName) > -1
                });
            }

            var lineData = [];
            for (var i = 0; i < users.length; i++) {
                lineData.push({
                    optlabel: "",
                    options: [{
                        displayValue: users[i].Name,
                        modelValue: users[i].Value,
                        checked: false
                    }]
                });
            }
            currObj.lineData = angular.copy(lineData);
        }
        $scope.chekDuplicateConUsers = function (args) {
            var isDuplicate = $scope.checkDuplicateValue(args);
            if (!isDuplicate)
                $scope.createCCUsersItemSelectionArray(args.model);
        }

        $scope.createCCUsersItemSelectionArray = function (currObj, strVal) {
            if (strVal != '1') {
                currObj.CC_Name = "";
            }
            var strRole = currObj.CC_Group,
                users = "";
            if (strRole) {
                var roleName = strRole.split('#')[1].trim();

                users = commonApi._.filter(dsProjDistUsers, function (val) {
                    return val.Value.split('#')[1].indexOf(roleName) > -1
                });
            }

            var ccUsers = [];
            for (var i = 0; i < users.length; i++) {
                ccUsers.push({
                    optlabel: "",
                    options: [{
                        displayValue: users[i].Name,
                        modelValue: users[i].Value,
                        checked: false
                    }]
                });
            }
            currObj.ccUsers = angular.copy(ccUsers);
        }
        $scope.chekDuplicateCCUsers = function (args) {
            var isDuplicate = $scope.checkDuplicateValue(args);
            if (!isDuplicate)
                $scope.createCCUsersItemSelectionArray(args.model);
        }

        function setWorkPruposedFromCustomAttribute() {

            var work_Proposed_After_Approval = [];

            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Work proposed after approval" && element.Value11 === "Active") {
                    work_Proposed_After_Approval.push(element);
                }
            }
            $scope.Work_Proposed_After_Approval = work_Proposed_After_Approval;
        }

        function setWorkProposedFromCustomAtt() {
            var workProposedFromConfigAtt = commonApi.getItemSelectionList({
                arrayObject: dsAsiConfigurableAttributes.filter(function (custObj) {
                    return custObj.Value3 == 'Work proposed after approval' && custObj.Value11 === "Active";
                }),
                groupNameKey: '',
                modelKey: 'Value8',
                displayKey: 'Value8'
            });
            $scope.filterDropdownWorkProposed = {
                reportByList: workProposedFromConfigAtt
            }
        }
        $scope.chekDuplicateWorkProposed = function (args) {
            if (args.model.Work_Proposed_After_Approval != 'Other') {
                var isDuplicate = $scope.checkDuplicateValue(args);
            }
            if (!isDuplicate)
                setWorkProposedFromCustomAtt();
        }

        function setDrawingSubmissionRef() {

            var drwaing_Submission_Ref = [];
            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Drawing submission reference" && element.Value11 === "Active") {
                    drwaing_Submission_Ref.push(element);
                }
            }
            $scope.Drawing_Submission_Ref = drwaing_Submission_Ref;
        }

        function setDrawingSubFromCustomAtt() {
            var drawingSubFromConfigAtt = commonApi.getItemSelectionList({
                arrayObject: dsAsiConfigurableAttributes.filter(function (custObj) {
                    return custObj.Value3 == 'Drawing submission reference' && custObj.Value11 === "Active";
                }),
                groupNameKey: '',
                modelKey: 'Value8',
                displayKey: 'Value8'
            });
            $scope.filterDropdownDrawingSub = {
                reportByList: drawingSubFromConfigAtt
            }
        }
        $scope.chekDuplicateDrawingSub = function (args) {
            if (args.model.Drawing_Submission_Ref_No != 'Other') {
                var isDuplicate = $scope.checkDuplicateValue(args);
            }
            if (!isDuplicate)
                setDrawingSubFromCustomAtt();
        }

        function setCategory() {

            var category = [];
            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Category" && element.Value11 === "Active") {
                    category.push(element);
                }
            }
            $scope.Category = category;
        }

        function setLocation() {

            var location = [];
            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Location" && element.Value11 === "Active") {
                    location.push(element);
                }
            }
            $scope.Location = location;
        }

        function setContractTitle() {
            var contractTitle = [];
            var workingUserOrg = $scope.WorkingUserID['0'].Name.split(',')[1].trim();

            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Contract_Title" && element.Value11 === "Active") {
                    contractTitle.push(element);
                }
            }
            $scope.contractTitle = contractTitle;
            for (var i = 0; i < contractTitle.length; i++) {

                var org = contractTitle[i].Value7.trim();
                if (workingUserOrg && workingUserOrg == org) {
                    $scope.dsPartAFields.contractTitle = contractTitle[i].Value8.trim();
                }
            }
        }

        function setContractNo() {
            var contractNo = [];
            var workingUserOrg = $scope.WorkingUserID['0'].Name.split(',')[1].trim();

            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Contract_No" && element.Value11 === "Active") {
                    contractNo.push(element);
                }
            }
            $scope.contractNo = contractNo;
            for (var i = 0; i < contractNo.length; i++) {

                var org = contractNo[i].Value8.trim();
                if (workingUserOrg && workingUserOrg == org) {
                    $scope.dsPartAFields.Contract_No = contractNo[i].Value7.trim();
                }
            }
        }

        function getCompanyCode(strorg) {
            var companyCode = [];

            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Company Code" && element.Value11 === "Active") {
                    companyCode.push(element);
                }
            }
            for (var i = 0; i < companyCode.length; i++) {

                var org = companyCode[i].Value8.trim();
                if (strorg && strorg == org) {
                    return $scope.orgCode = companyCode[i].Value7.trim();
                }
            }
        }

        function setITPSQPRef() {

            var itpSqpRefNo = [];
            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "ITP_SQP_REF_No" && element.Value11 === "Active") {
                    itpSqpRefNo.push(element);
                }
            }
            $scope.ITPSQPRefNo = itpSqpRefNo;

        }

        if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
            // angular.element('.export-btn').hide();
        }
        $scope.update();

        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
        $scope.deleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);            
            repeatingData.splice(index, 1);
        };
        $scope.removePhotoComment = function (obj, repeatingData, section) {
            var index = repeatingData.indexOf(obj);
            if (repeatingData.length == 1 && section == 'PARTB') {
                $scope.dsPartBFields.Part2_Photo_Comments = '';
            } else if (repeatingData.length == 1 && section == 'PARTC') {
                $scope.dsPartCFields.PartC_Comments = '';
            } else if (repeatingData.length == 1 && section == 'PARTD') {
                $scope.dsPartDFields.PartD_Comments = '';
            } else if (repeatingData.length == 1 && section == 'PARTE') {
                $scope.dsPartEFields.PartE_Attachment_Comments = '';
            }
            repeatingData.splice(index, 1);
        };
        $scope.isDisabled = function (strVal) {
            return strVal === $scope.DS_FORMSTATUS
        };

        function setRolewiseDistribution(strRole, dsAutoDistribute) {

            var strusers = commonApi._.filter(dsProjUsersAllRoles, function (val) {
                return val.Value.toLowerCase().indexOf(strRole.toLowerCase()) != -1
            });
            var strcaldate = calculateDistDate(3);

            if (strusers && strusers.length) {
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter(dsProjDistUsers, function (val) {
                        return val.Value.indexOf(strUserId) != -1
                    })[0];

                    if (strdisuser && strdisuser.Value) {

                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = dsAutoDistribute;
                        setAutoDistribution(strdisuser.Value, "3#", strcaldate);
                    }
                }
            }
        }
        function setRolewiseDistributionForInfo(strRole, dsAutoDistribute) {

            var strusers = commonApi._.filter(dsProjUsersAllRoles, function (val) {
                return val.Value.toLowerCase().indexOf(strRole.toLowerCase()) != -1
            });
            var strcaldate = calculateDistDate(3);

            if (strusers && strusers.length) {
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter(dsProjDistUsers, function (val) {
                        return val.Value.indexOf(strUserId) != -1
                    })[0];

                    if (strdisuser && strdisuser.Value) {

                        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = dsAutoDistribute;
                        setAutoDistribution(strdisuser.Value, "7#", strcaldate);
                    }
                }
            }
        }
        function sendActionToConsultantUsers(dsAutoDistribute) {

            var strConUsersFromRoles = $scope.formCustomFields.PartB.Consultant_Distribution.Consultant_Distribution_Users;
            var strcaldate = calculateDistDate(3);
            var strResponder = "",
                strid = "";
            if (strConUsersFromRoles.length) {
                for (var i = 0; i < strConUsersFromRoles.length; i++) {
                    strResponder = strConUsersFromRoles[i].Con_Dist_User;
                    $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = dsAutoDistribute;
                    if (strResponder) {
                        strid = strResponder.split('|')[2].split('#')[0].trim();
                        setAutoDistribution(strid, "3#", strcaldate);
                    }
                }
            }
        }

        function sendActionToCCUsers(dsAutoDistribute) {

            var strCCUsers = $scope.formCustomFields.PartA.CC_Name_Group_Details.CC_Name_Group_Table;
            var strcaldate = calculateDistDate(3);
            var strResponder = "",
                strid = "";
            if (strCCUsers.length) {
                for (var i = 0; i < strCCUsers.length; i++) {
                    strResponder = strCCUsers[i].CC_Name;
                    $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = dsAutoDistribute;
                    if (strResponder) {
                        strid = strResponder.split('#')[0].trim();
                        setAutoDistribution(strid, "7#", strcaldate);
                    }
                }
            }
        }

        function sendActionToContractor(autoDistNode) {
            var contractor = $scope.dsPartAFields.Originator_Id;
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = autoDistNode;
            var strcaldate = calculateDistDate(3);
            if (contractor) {
                setAutoDistribution(contractor, '3#', strcaldate);
            }
        }

        function setAutoDistribution(strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistricution = angular.copy($scope.DistributionStructure)
            structDistricution.DS_PROJDISTUSERS = strUser;
            structDistricution.DS_FORMACTIONS = strAction;
            structDistricution.DS_ACTIONDUEDATE = strDueDate;
            $scope.asiteSystemDataReadWrite["Auto_Distribute_Group"]["Auto_Distribute_Users"].push(structDistricution);
        }

        function calculateDistDate(days) {

            var strDueDate = "";
            if (days) {
                var d = new Date($scope.todayDateDbFormat);
                d.setDate(d.getDate() + parseInt(days));
                var month = d.getMonth() + 1;
                var day = d.getDate();
                var strDueDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;
            }
            return strDueDate;
        }
        $scope.restrictCharOnlyNumber = function () {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(RESTRICT_CHAR_MSG);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }
        }

        function getWorkingUserId() {
            var strWorkingUserId = $scope.WorkingUserID[0].Value.split('|')[0].trim() || "";
            return strWorkingUserId;
        }

        function getDateTimeFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-ddTHH:mm:ss');
            return nd;
        }

        function setStatus(statusname) {
            var strFormStatusId = getFormStatusId(statusname);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (allformStatus && allformStatus.length > 0) {
                var statudObj = commonApi._.filter(allformStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        function setStageLogic() {
            var currentStage = $scope.oriMsgCustomFields.DSI_Current_Stage;
            var i = 0;
            i = parseInt(currentStage) + 1;
            $scope.oriMsgCustomFields.DSI_Next_Stage = i;
        }

        function setRivision() {
            var currentRevision = $scope.oriMsgCustomFields.DSI_Revision;
            var i = 0;
            i = parseInt(currentRevision) + 1;
            $scope.oriMsgCustomFields.DSI_Revision = i;
            var userRef = $scope.oriMsgCustomFields.ORI_USERREF;
            if ($scope.oriMsgCustomFields.DSI_Revision == "1") {
                userRef = userRef + "-" + "A";
                $scope.oriMsgCustomFields.ORI_USERREF = userRef;
            }
            if ($scope.oriMsgCustomFields.DSI_Revision != "1") {
                var revFromUserRef = userRef.split('-')[5].trim();
                var nextRev = nextChar(revFromUserRef);
                userRef = userRef.substring(0, 23);
                userRef = userRef + "-" + nextRev;
                $scope.oriMsgCustomFields.ORI_USERREF = userRef;
            }
        }

        function nextChar(c) {
            var u = c.toUpperCase();
            if (same(u, 'Z')) {
                var txt = '';
                var i = u.length;
                while (i--) {
                    txt += 'A';
                }
                return (txt + 'A');
            } else {
                var p = "";
                var q = "";
                if (u.length > 1) {
                    p = u.substring(0, u.length - 1);
                    q = String.fromCharCode(p.slice(-1).charCodeAt(0));
                }
                var l = u.slice(-1).charCodeAt(0);
                var z = nextLetter(l);
                if (z === 'A') {
                    return p.slice(0, -1) + nextLetter(q.slice(-1).charCodeAt(0)) + z;
                } else {
                    return p + z;
                }
            }
        }

        function nextLetter(l) {
            if (l < 90) {
                return String.fromCharCode(l + 1);
            } else {
                return 'A';
            }
        }

        function same(str, str1) {
            var i = str.length;
            while (i--) {
                if (str[i] !== str1) {
                    return false;
                }
            }
            return true;
        }

        function setSendPermission(strpermission) {

            if (strpermission && strpermission == 'YES') {

                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                $scope.strCanReply = 'yes';

            } else if (strpermission && strpermission == 'NO') {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                $scope.oriMsgCustomFields.DSI_Errormsg = 'You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                $scope.strCanReply = '';
            } else {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                $scope.oriMsgCustomFields.DSI_Errormsg = 'You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                $scope.strCanReply = '';
            }
        }

        function getMsgIdOfIncompleteAction() {
            var workingUserId = getWorkingUserId();
            var allPendingRespondNodes = commonApi._.filter(incompleteActionsByMsg, function (obj) {
                return obj.Value4 == "Respond"
            });
            for (var i = 0; i < allPendingRespondNodes.length; i++) {
                var strUserId = allPendingRespondNodes[i].Value1;
                var strMsgId = allPendingRespondNodes[i].Value3;

                if (workingUserId == strUserId) {
                    return strMsgId;
                }
            }
            return '';
        }

        function getMsgId() {

            var strMessageId = "";
            if (incompleteMessageAction && incompleteMessageAction[0]) {
                strMessageId = incompleteMessageAction[0].Value.split("|")[2].trim();
                return strMessageId;
            }
        }

        function checkUserIncompleteActions() {

            var CurrentUserID = getWorkingUserId();
            var ActionData = commonApi._.filter(incompleteAction, function (val) {
                return val.Value.indexOf('Respond') > -1 && val.Value.indexOf(CurrentUserID) != -1
            });
            if (ActionData && ActionData.length) {
                return "YES";
            } else {
                return "NO";
            }
        }

        function ClearActionbyMsg() {
            var Workinguserid = getWorkingUserId();
            var allNodes = commonApi._.filter(incompleteActionsByMsg, {
                Value4: "Respond"
            });

            var clearActionNodes = commonApi._.reject(allNodes, function (obj) {
                return (obj.Value1 == Workinguserid)
            });

            var asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            var asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            var AppId = asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'];
            if (clearActionNodes.length) {
                if (!asiteSystemDataReadWrite['Auto_Complete_msg_Actions']) {
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions'] = {};
                }
                asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'] = [];
                asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['DS_AUTOCOMPLETE_ACTION_MSG_APP_ID'] = "1";

                for (var i = 0; i < clearActionNodes.length; i++) {
                    var nodeObj = clearActionNodes[i];
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'].push({
                        DS_MSG_AC_TYPE: "clear",
                        DS_MSG_AC_FORM: AppId,
                        DS_MSG_AC_MSG_TYPE: nodeObj.Value3,
                        DS_MSG_AC_USERID: nodeObj.Value1,
                        DS_MSG_AC_ACTION: "3",
                        DS_MSG_AC_ACTION_REMARKS: "Action Cleared"
                    });
                }
            }
        }
        $window.riscfFinalCallBack = function () {

            return $scope.checkMandatoryFields();
        }
        $scope.checkMandatoryFields = function () {

            var consultantDistribution=$scope.dsPartBFields.Consultant_Distribution.Consultant_Distribution_Users;
            if (!$scope.strCanReply) {
                alert($scope.Msg);
                return true;
            }
            if ($scope.dsPartBFields.SendTo_Consultant == 'Yes' && $scope.DS_FORMSTATUS == 'Open') {

                if (consultantDistribution.length == 0) {

                    alert('Please select the users to whom you would like to notify');
                    return true;
                }
                if (consultantDistribution.length >= 1) {

                    for (var i = 0; i < consultantDistribution.length; i++) {

                        if (consultantDistribution[i].Con_Dist_User.length == 0 || consultantDistribution[i].Con_Proj_Roles.length == 0) {

                            alert('Please select the users to whom you would like to notify');
                            return true;
                        }
                    }
                }
            }
            var ricsType = '';
            var strFormType = $scope.oriMsgCustomFields.Form_Type;
            var workingUserOrg = $scope.WorkingUserID['0'].Name.split(',')[1].trim();
            var orgCode = getCompanyCode(workingUserOrg);
            workingUserOrg = workingUserOrg.substring(0, 3).toUpperCase();
            var contractNo = $scope.dsPartAFields.Contract_No;
            var location = $scope.dsPartAFields.Location.substring(0, 87);
            if (strFormType == 'Inspection') {
                ricsType = 'GEO'
            } else if (strFormType == 'Survey') {
                ricsType = 'SUR'
            }
            if ($window.currentViewName == "ORI_VIEW" && (($scope.strFormId == "" || $scope.strIsDraft == "YES"))) {
                $scope.oriMsgCustomFields.ORI_FORMTITLE = strFormType + " - " + location;
                var strPrefix = contractNo + "-" + 'RISC' + "-" + orgCode + "-" + ricsType;
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMAUTONO_PREFIX'] = strPrefix;
                $scope.oriMsgCustomFields['ORI_USERREF'] = strPrefix + "-" + "<<NEXT_AUTONO>>";
            }
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            var formatteddate = $filter('date')(getDateTimeFromZone(), 'dd/MM/yyyyTHH:mm a');                                        
            var strFormStatus = '';
            if ($window.currentViewName == 'ORI_VIEW' && (($scope.strFormId == '' || $scope.strIsDraft == 'YES'))) {


                if (strFormType == 'Inspection') {
                    setRolewiseDistribution('Inspection', '3');
                } else if (strFormType == 'Survey') {
                    setRolewiseDistribution('Survey', '3');
                }
                setStageLogic();
                sendActionToCCUsers('3');                
                $scope.dsPartAFields.Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                 
            } else if ($window.currentViewName == 'RES_VIEW' && $scope.strFormId != '') {

                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = '0';
                if ($scope.DS_FORMSTATUS == 'Open') {

                    var inspectionAssignedTo = $scope.dsPartBFields.Inspection_Assigned_Group;
                    var sendToConsultant = $scope.dsPartBFields.SendTo_Consultant;

                    if (sendToConsultant == 'Yes') {
                        sendActionToConsultantUsers('13');
                    }
                    if (strFormType == 'Inspection') {
                        setRolewiseDistribution('Inspection', '13');
                        setStatus('Delegated for Inspection');
                    } else if (strFormType == 'Survey') {
                        setRolewiseDistribution('Survey', '13');
                        setStatus('Delegated for Inspection');
                    }
                    ClearActionbyMsg();
                    setStageLogic();                    
                    $scope.dsPartBFields.PartB_Received_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                }
                if ($scope.DS_FORMSTATUS == 'Delegated for Inspection' && !$scope.consultantuser) {

                    var partAIncomplete = $scope.dsPartCFields.PartA_Incomplete;
                    var notReadyToBeInspected = $scope.dsPartCFields.Not_Ready_To_Be_Inspected;
                    var others = $scope.dsPartCFields.Others_Option;
                    var riscCancelled = $scope.dsPartCFields.RICS_Cancelled;
                    var permissionGiven = $scope.dsPartCFields.Permission_Is_Given;
                    var permissionNotGiven = $scope.dsPartCFields.Permission_Is_Not_Given;
                    var outstandingCompleted = $scope.dsPartCFields.Outstanding_Completed;
                    var outstandingNotCompleted = $scope.dsPartCFields.Outstanding_Not_Completed;

                    if (partAIncomplete == 'Incomplete' || notReadyToBeInspected == 'Not_Ready_To_Be_Inspected' || others == 'Other') {

                        strFormStatus = 'Failed (Pending Endorsement)'
                    } else if (riscCancelled == 'Cancelled') {

                        strFormStatus = 'Cancelled (Pending Endorsement)';
                    } else if (permissionGiven == 'Permission_Given' || outstandingCompleted == 'Outstanding_Completed') {

                        strFormStatus = 'Passed (Pending Endorsement)';
                    } else if (permissionNotGiven == 'Permission_Not_Given' || outstandingNotCompleted == 'Outstanding_Not_Completed') {

                        strFormStatus = 'Failed (Pending Endorsement)';
                    }

                    if (strFormType == 'Inspection') {
                        setRolewiseDistribution('Inspection', '13');
                    } else if (strFormType == 'Survey') {
                        setRolewiseDistribution('Survey', '13');
                    }
                    ClearActionbyMsg();
                    setStatus(strFormStatus);
                    setStageLogic();                    
                    $scope.dsPartBFields.Part_B_Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();                     
                }
                if ($scope.DS_FORMSTATUS == 'Delegated for Inspection' && $scope.consultantuser) {

                    if (strFormType == 'Inspection') {
                        setRolewiseDistributionForInfo('Inspection', '13');
                    } else if (strFormType == 'Survey') {
                        setRolewiseDistributionForInfo('Survey', '13');
                    }
                }
                if ($scope.DS_FORMSTATUS == 'Passed (Pending Endorsement)' ||
                    $scope.DS_FORMSTATUS == 'Failed (Pending Endorsement)' ||
                    $scope.DS_FORMSTATUS == 'Cancelled (Pending Endorsement)' &&
                    !$scope.consultantuser) {

                    sendActionToContractor('13');

                    if ($scope.DS_FORMSTATUS == 'Passed (Pending Endorsement)') {

                        strFormStatus = 'Passed (Pending Acknowledgement)';
                    } else if ($scope.DS_FORMSTATUS == 'Failed (Pending Endorsement)') {

                        strFormStatus = 'Failed (Pending Acknowledgement)';
                    } else if ($scope.DS_FORMSTATUS == 'Cancelled (Pending Endorsement)') {

                        strFormStatus = 'Cancelled (Pending Acknowledgement)';
                    }
                    ClearActionbyMsg();
                    setStatus(strFormStatus);
                    setStageLogic();                    
                    $scope.dsPartCFields.Endorsement_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();                    
                }
                if ($scope.DS_FORMSTATUS == 'Passed (Pending Acknowledgement)' ||
                    $scope.DS_FORMSTATUS == 'Failed (Pending Acknowledgement)' ||
                    $scope.DS_FORMSTATUS == 'Cancelled (Pending Acknowledgement)' &&
                    !$scope.consultantuser) {

                    if ($scope.DS_FORMSTATUS == 'Passed (Pending Acknowledgement)') {

                        strFormStatus = 'Passed';
                        setStageLogic();
                    } else if ($scope.DS_FORMSTATUS == 'Failed (Pending Acknowledgement)') {

                        strFormStatus = 'Failed';
                        sendActionToContractor('13');
                        $scope.oriMsgCustomFields.DSI_Current_Stage = '0';
                        $scope.oriMsgCustomFields.DSI_Next_Stage = '0';
                    } else if ($scope.DS_FORMSTATUS == 'Cancelled (Pending Acknowledgement)') {

                        strFormStatus = 'Cancelled';
                    }
                    ClearActionbyMsg();
                    setStatus(strFormStatus);                    
                    $scope.dsPartDFields.RISC_Approver_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();                    
                }
                if ($scope.DS_FORMSTATUS == 'Failed') {

                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AU_OTH_FORM = '1';
                    if (strFormType == 'Inspection') {
                        setRolewiseDistribution('Inspection', '13');
                    } else if (strFormType == 'Survey') {
                        setRolewiseDistribution('Survey', '13');
                    }
                    setRivision();
                    setStageLogic();
                    setStatus('Open');
                    sendActionToCCUsers('13');
                    $scope.oriMsgCustomFields.ORI_FORMTITLE = strFormType + " - " + location;                   
                    $scope.dsPartAFields.Checked_By_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();
                    
                }
                if ($scope.DS_FORMSTATUS == 'Passed') {
                    
                    $scope.dsPartEFields.Part_E_User_Date = formatteddate.split('T')[0].trim() + ' ' + formatteddate.split('T')[1].trim();                    
                }
            }
            $element.removeClass('loaded');
            return false;
        }
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof riscfFinalCallBack !== "undefined") {
        return riscfFinalCallBack();
    }
}