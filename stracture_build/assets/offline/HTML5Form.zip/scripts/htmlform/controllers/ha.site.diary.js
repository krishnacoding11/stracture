/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/number-format', '../components/table.util', '../components/signature', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout, myConfig) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });
        $scope.stopAutoSaveDraftTimerFromClientSide();
        var currServerDate = '';
        $scope.getServerTime(function (serverDate) {
            currServerDate = serverDate;
        });
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var isOriView = (currentViewName == "ORI_VIEW"),
            isOriPrintView = (currentViewName == "ORI_PRINT_VIEW");
        var STATIC_OBJ_DATA = {
            Cont_Work_Comp_Group: {
                CWCT_isSelected: false,
                CWCT_Item_No: "1.01",
                CWCT_Description: "",
                CWCT_attachements: [{
                    CWCT_Photo: ""
                }],
                CWCT_Photo_Location: "",
                CWCT_Guid: "",
                Contract_Labor_Details: {
                    Contract_Labor_List: [{
                        Labour_isSelected: "",
                        CWCT_Labour: "",
                        CWCT_Labour_No: "",
                        CWCT_Conc_Type: "",
                        CWCT_Parent_Labor_Guid: "",
                        CWCT_Labor_Guid: ""
                    }]
                },
                Contract_BIS_Labor_Details: {
                    Contract_BIS_Labor_List: [{
                        BIS_Labour_isSelected: "",
                        CWCT_BIS_Labour: "",
                        CWCT_BIS_Labour_No: "",
                        CWCT_BIS_Conc_Type: "",
                        CWCT_Parent_BIS_Labor_Guid: "",
                        CWCT_BIS_Labor_Guid: ""
                    }]
                }
            },
            Contract_Labor_List: {
                Labour_isSelected: "",
                CWCT_Labour: "",
                CWCT_Labour_No: "",
                CWCT_Conc_Type: "",
                CWCT_Parent_Labor_Guid: "",
                CWCT_Labor_Guid: ""
            },
            cwctPhoto: {
                CWCT_Photo: ""
            },
            miscePhoto: {
                Misce_Photo: ""
            },
            Contract_BIS_Labor_List: {
                BIS_Labour_isSelected: "",
                CWCT_BIS_Labour: "",
                CWCT_BIS_Labour_No: "",
                CWCT_BIS_Conc_Type: "",
                CWCT_Parent_BIS_Labor_Guid: "",
                CWCT_BIS_Labor_Guid: ""
            },
            Miscellaneous_Group: {
                Misce_isSelected: false,
                Misce_Item_No: "2.1",
                Misce_Description: "",
                Misce_attachements: [{
                    Misce_Photo: ""
                }],
                Misce_Photo_Location: "",
                Misce_Guid: "",
                Misce_Labor_Details: {
                    Misce_Labor_List: [{
                        Misce_Labour_isSelected: "",
                        Misce_Labour: "",
                        Misce_Labour_No: "",
                        Misce_Conc_Type: "",
                        Misce_Parent_Labor_Guid: "",
                        Misce_Labor_Guid: ""
                    }]
                },
                Misce_BIS_Labor_Details: {
                    Misce_BIS_Labor_List: [{
                        Misce_BIS_Labour_isSelected: "",
                        Misce_BSI_Labour: "",
                        Misce_BIS_Labour_No: "",
                        Misce_BIS_Conc_Type: "",
                        Misce_Parent_BIS_Labor_Guid: "",
                        Misce_BIS_Labor_Guid: ""
                    }]
                }
            },
            Misc_Labor_List: {
                Misce_Labour_isSelected: "",
                Misce_Labour: "",
                Misce_Labour_No: "",
                Misce_Conc_Type: "",
                Misce_Parent_Labor_Guid: "",
                Misce_Labor_Guid: ""
            },
            Misce_BIS_Labor_List: {
                Misce_BIS_Labour_isSelected: "",
                Misce_BSI_Labour: "",
                Misce_BIS_Labour_No: "",
                Misce_BIS_Conc_Type: "",
                Misce_Parent_BIS_Labor_Guid: "",
                Misce_BIS_Labor_Guid: ""
            },
            Contractor_Site_Staff_details: {
                CS_isSelected: false,
                Cont_Site_Staff_Name: "",
                Cont_Site_Staff_Input: "",
                DSI_isNew: "Yes"
            },
            Machine_Plant_Details: {
                Mac_Plant_isSelect: false,
                Plant_on_Site: "",
                refGuid: "",
                Owned: "",
                Hired: "",
                OwnedGuid: "",
                HiredGuid: "",
                Plant_No: "",
                hired_No: "",
                DSI_isPlantNew: "Yes",
                Owned_Worked: "",
                Owned_used: "",
                Owned_idle: "",
                Owned_brokenDowm: "",
                Hired_used: "",
                Hired_idle: "",
                Hired_brokenDowm: "",
                Hired_Worked: "",
                Owned_total: "0.0",
                Hired_Total: "0.0",
                Owned_or_Hired_Total: "0.0"
            },
            Safety_Issues_Group: {
                SI_isSelected: false,
                SI_Item: "1",
                SI_Description: ""
            },
            Progress_Update_Details: {
                PU_isSelected: false,
                Work_Activities: "",
                Actual_Progress: ""
            },
            Material_Delivered_Details: {
                MD_isSelected: false,
                MD_Item: "1",
                Des_of_Material: ""
            },
            Work_Delay_Today_Details: {
                WDT_isSelected: false,
                WDT_Item: "1",
                Description: ""
            },
            General_Attachments: {
                General_Attachment: ""
            },
            DSI_CONC_LabourHeaderList: {
                CONC_Seq: "",
                CONC_HeaderName: ""
            },
            DSI_BIS_LabourHeaderList: {
                CONC_BIS_Seq: "",
                CONC_BIS_HeaderName: ""
            },
            DSI_CONC_Labor_List: {
                CONC_GUID: "",
                CONC_ITEMNO: "",
                CONC_Labor_Name: "",
                CONC_Labour_No: "",
                CONC_Conc_Type: "",
                CONC_Labour_Type: ""
            },
            AutoDistActionStructure :{
                DS_ADO_TYPE: "",
                DS_ADO_FORM: "",
                DS_ADO_MSG_TYPE: "",
                DS_ADO_FORMACTIONS: "",
                DS_ADO_PROJDISTGROUPS: "",
                DS_ADO_ACTIONDUEDATE: "",
                DS_ADO_PROJDISTUSERS: ""
            },
            DistributionStructure: 
                {
                   DS_PROJDISTUSERS: "",
                   DS_FORMACTIONS: "",
                   DS_ACTIONDUEDATE: "",
                   DS_DUEDAYS: ""
                },
            
        },
            CONSTANTS_OBJ = {
                COW_SCOW_USER_LIST_KEY: 'cow-scow-user-list',
                COW_SCOW_USER_LIST_KEY_LABEL: 'COW SCOW Users',
                BSI_USER_LIST_KEY: 'BSI-user-list',
                BSI_USER_LIST_LABEL: 'BSI Users',
                COMM_TEAM_USER_LIST_KEY: 'PM-user-list',

            };
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.disabledDate = false;
        $scope.requests = {};

        var structureItemList = function (setFor, availList) {
            var tempList = [],
                optlabel = '';

            switch (setFor) {
                case CONSTANTS_OBJ.COW_SCOW_USER_LIST_KEY:
                    angular.forEach(availList, function (item) {
                        tempList.push({
                            displayValue: item.split('#')[1].trim(),
                            modelValue: item
                        });
                    });
                    optlabel = CONSTANTS_OBJ.COW_SCOW_USER_LIST_KEY_LABEL;
                    break;
                case CONSTANTS_OBJ.COMM_TEAM_USER_LIST_KEY:
                    angular.forEach(availList, function (item) {
                        tempList.push({
                            displayValue: item.Name,
                            modelValue: item.Value.split('|')[2].trim()
                        });
                    });
                    break;
                case CONSTANTS_OBJ.BSI_USER_LIST_KEY:
                    angular.forEach(availList, function (item) {
                        tempList.push({
                            displayValue: item.split('#')[1].trim(),
                            modelValue: item
                        });
                    });
                    optlabel = CONSTANTS_OBJ.BSI_USER_LIST_LABEL;
                    break;
            }
            return [{
                optlabel: optlabel,
                options: tempList
            }];
        };
        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.tableUtilSettings = {
            Contractor_Site_Staff_details: {
                tooltip: "select to remove/remove all data",
                hasDefaultRecord: true,
                checkboxModelKey: "CS_isSelected",
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Contractor_Site_Staff_details),
                addItemCallBack: contractorSiteStaff,
                deleteItemCallBack: contractorSiteStaff

            },
            Machine_Plant_Details: {
                tooltip: "select to remove/remove all data",
                hasDefaultRecord: true,
                checkboxModelKey: "Mac_Plant_isSelect",
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Machine_Plant_Details),

            },
            Safety_Issues_Group: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "SI_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Safety_Issues_Group)
            },
            Progress_Update_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "PU_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Progress_Update_Details),
            },
            Material_Delivered_Details: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "MD_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Material_Delivered_Details)
            },
            Work_Delay_Today_Details: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0
                },
                checkboxModelKey: "WDT_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Work_Delay_Today_Details)
            },
            Cont_Work_Comp_Group: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "CWCT_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Cont_Work_Comp_Group)
            },
            Contract_Labour_List: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "Labour_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Cont_Work_Comp_Group)
            },
            Contract_BIS_Labour_List: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "BIS_Labour_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Cont_Work_Comp_Group)
            },
            Miscellaneous_Group: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "Misce_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Miscellaneous_Group)
            },

            Misce_Labour_List: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "Misce_Labour_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Miscellaneous_Group)
            },
            Misce_BIS_Labour_List: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0
                },
                checkboxModelKey: "Misce_BIS_Labour_isSelected",
                deleteItemCallBack: optionIndexReset,
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Miscellaneous_Group)
            }
        };

        $scope.structDistribution = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        };
        function contractorSiteStaff() {
            $timeout(function () {
                $scope.countWorkDetailNo();
            });
        }
        function optionIndexReset() {
            $timeout(function () {
                $scope.safetyIssuesResetIndex();
                $scope.materialDelResetIndex();
                $scope.WorkDelayToday();
                $scope.ContractWorkComp();
                $scope.Miscellaneous();
                $scope.cwctsubTotal("All");
            }, 200);
        }
        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.RES_MSG_Custom_Fields;
        var asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.dsAllStepFields = $scope.formCustomFields["DS_ALL_STEP_FIELDS"];
        $scope.dsStep1Fields = $scope.formCustomFields["DS_STEP1_FIELDS"];
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT;
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        $scope.DS_HA_SD_Contract_Work_Completed = $scope.getValueOfOnLoadData('DS_HA_SD_Contract_Work_Completed');
        $scope.DS_HA_SD_Contract_Work_Completed_Labour_Service = $scope.getValueOfOnLoadData('DS_HA_SD_Contract_Work_Completed_Labour_Service');
        $scope.DS_HA_SD_Miscellaneous_Details = $scope.getValueOfOnLoadData('DS_HA_SD_Miscellaneous_Details');
        $scope.DS_HA_SD_Miscellaneous_Details_Labour_Service = $scope.getValueOfOnLoadData('DS_HA_SD_Miscellaneous_Details_Labour_Service');
        $scope.DS_HA_SD_Misce_CWCT_Labour_Total = $scope.getValueOfOnLoadData('DS_HA_SD_Misce_CWCT_Labour_Total');
        $scope.DS_HA_SD_Misce_CWCT_Labour_BSI_Total = $scope.getValueOfOnLoadData('DS_HA_SD_Misce_CWCT_Labour_BSI_Total');
        $scope.DS_HA_SD_Form_Details_Site_Memo = $scope.getValueOfOnLoadData('DS_HA_SD_Form_Details_Site_Memo');
        $scope.DS_HA_SD_Form_Details_Inspection_Date = $scope.getValueOfOnLoadData('DS_HA_SD_Form_Details_Inspection_Date');
        var dsAllFormStatus = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var incompleteActionsByMsg = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS_BYMSG") || [];
        $scope.arrLabourHeaderData = [];
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        $scope.ContractWorkComp = function () {
            var cwctdata = $scope.dsStep1Fields.Contract_Work_Completed.Cont_Work_Comp_Group;
            for (var i = 0; i < cwctdata.length; i++) {
                var num =  (i + 1); // any number between 0 & 99
                var result = ( '0' + num ).substr( -2 );
                cwctdata[i].CWCT_Item_No = "1." + result;
            }
        };
        $scope.Miscellaneous = function () {
            var Miscedata = $scope.dsStep1Fields.Miscellaneous_Details.Miscellaneous_Group;
            for (var i = 0; i < Miscedata.length; i++) {
                var num = (i + 1);  // any number between 0 & 99
                var result = ( '0' + num ).substr( -2 );
                Miscedata[i].Misce_Item_No = "2." + result;
            }
        };
        $scope.safetyIssuesResetIndex = function () {
            var safety = $scope.dsStep1Fields['Safety_Issues_Data']['Safety_Issues_Group'];
            for (var i = 0; i < safety.length; i++) {
                safety[i].SI_Item = + (i + 1);
            }
        };
        $scope.WorkDelayToday = function () {
            var material = $scope.dsStep1Fields['Material_Delivered']['Material_Delivered_Details'];
            for (var i = 0; i < material.length; i++) {
                material[i].MD_Item = + (i + 1);
            }
        };
        $scope.materialDelResetIndex = function () {
            var material = $scope.dsStep1Fields['Work_Delay_Today']['Work_Delay_Today_Details'];
            for (var i = 0; i < material.length; i++) {
                material[i].WDT_Item = + (i + 1);
            }
        };
        function getandSetGUID() {
            var tempCwct = $scope.dsStep1Fields.Contract_Work_Completed.Cont_Work_Comp_Group[0],
                tempMisce = $scope.dsStep1Fields.Miscellaneous_Details.Miscellaneous_Group[0];

            getGUIdOnCallBack(2, function (guidResp) {
                tempCwct.CWCT_Guid = guidResp[0];
                tempCwct.Contract_Labor_Details.Contract_Labor_List[0].CWCT_Parent_Labor_Guid = guidResp[0];
                tempCwct.Contract_BIS_Labor_Details.Contract_BIS_Labor_List[0].CWCT_Parent_BIS_Labor_Guid = guidResp[0];;
                tempMisce.Misce_Guid = guidResp[1];
                tempMisce.Misce_Labor_Details.Misce_Labor_List[0].Misce_Parent_Labor_Guid = guidResp[1];
                tempMisce.Misce_BIS_Labor_Details.Misce_BIS_Labor_List[0].Misce_Parent_BIS_Labor_Guid = guidResp[1];
            });
        }

        $scope.addNewWithGUID = function (repeatingData, objKeyName, parentGUID) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            if (objKeyName == "Misce_BIS_Labor_List") {
                newRowObject.Misce_Parent_BIS_Labor_Guid = parentGUID;
                repeatingData.push(newRowObject);
            }
            else if (objKeyName == "Misc_Labor_List") {
                newRowObject.Misce_Parent_Labor_Guid = parentGUID;
                repeatingData.push(newRowObject);
            }
            else if (objKeyName == "Contract_Labor_List") {
                newRowObject.CWCT_Parent_Labor_Guid = parentGUID;
                repeatingData.push(newRowObject);
            }
            else if (objKeyName == "Contract_BIS_Labor_List") {
                newRowObject.CWCT_Parent_BIS_Labor_Guid = parentGUID;
                repeatingData.push(newRowObject);
            }
            else {
                getGUIdOnCallBack(1, function (guidResp) {
                    if (objKeyName == "Cont_Work_Comp_Group") {
                        var num = repeatingData.length + 1; 
                        var result = ( '0' + num ).substr( -2 );
                        newRowObject.CWCT_Item_No = "1." + result;
                        newRowObject.CWCT_Guid = guidResp[0];
                        newRowObject.Contract_Labor_Details.Contract_Labor_List[0].CWCT_Parent_Labor_Guid = guidResp[0];
                        newRowObject.Contract_BIS_Labor_Details.Contract_BIS_Labor_List[0].CWCT_Parent_BIS_Labor_Guid = guidResp[0];
                    }
                    if (objKeyName == "Miscellaneous_Group") {
                        var num = repeatingData.length + 1; // any number between 0 & 99
                        var result = ( '0' + num ).substr( -2 );
                        newRowObject.Misce_Item_No = "2." + result;
                        newRowObject.Misce_Guid = guidResp[0];
                        newRowObject.Misce_Labor_Details.Misce_Labor_List[0].Misce_Parent_Labor_Guid = guidResp[0];
                        newRowObject.Misce_BIS_Labor_Details.Misce_BIS_Labor_List[0].Misce_Parent_BIS_Labor_Guid = guidResp[0];
                    }
                    repeatingData.push(newRowObject);
                });
            }

        };

        var getGUIdOnCallBack = function (totalNodes, callback) {
            var allNodes = [];
            var fieldValue = totalNodes;
            if (fieldValue) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_GET_GUID",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_GET_GUID",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.xhr.platformXhr = true;
                $scope.xhr.guIdXhr = $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
                        var strGetDetailsLength = strGetDetails.Items.Item.length;
                        for (var i = 0; i < strGetDetailsLength; i++) {
                            allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
                        }
                    }
                    $scope.xhr.platformXhr = false;
                    $scope.xhr.guIdXhr = false;
                    callback(allNodes);
                }, function (error) {
                    $scope.xhr.platformXhr = false;
                    $scope.xhr.guIdXhr = false;
                    var errorMsg = 'Error retriving DocumentData<br/>' + error;
                    Notification.error({
                        title: 'Server Error',
                        message: errorMsg
                    });
                });
            }
        };
        // to get Custom Attribute On Load.
        var logo = commonApi._.findWhere(dsAsiConfigurableAttributes, {
            Value3: "Logo",
            Value7: "Logo"
        }) || {};
        if (isOriView) {
            $scope.Msg = "You are not authorised to create/edit the form currently. For more information, contact your Administrator."
            $scope.strCanReply = "";
            $scope.oriMsgCustomFields.Comp_Logo = logo.Value8 || '/images/asiteWhite60x200.png';
            $timeout(function () {
                clearLabour();
                clearBis();
                $scope.$apply();
            });
            if ($scope.strIsDraft == "NO" && document.getElementById("DS_ISDRAFT_EDITORI").value == "NO") {
                if ($scope.oriMsgCustomFields.DSI_Next_Stage == "") {
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == "") {
                    $scope.oriMsgCustomFields.DSI_Current_Stage = 1;
                }
                else {
                    $scope.oriMsgCustomFields.DSI_Current_Stage = $scope.oriMsgCustomFields.DSI_Next_Stage;
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == "1") {
                    setLabourHeaderData();
                }
            }
            if (workingUserAllRole && $scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
                if (workingUserAllRole[0].Value.toLowerCase().indexOf("rss") != -1) {
                    $scope.strCanReply = "yes";
                }
                $scope.dsStep1Fields.RssDetails.rssName = $scope.dsWorkingUser;
                setOffset();
            }
            else if($scope.oriMsgCustomFields.DSI_Current_Stage == 2)
            {
                $scope.dsStep1Fields.BsiDetails.bsiName = $scope.dsWorkingUser;
            }
            else if($scope.oriMsgCustomFields.DSI_Current_Stage == 3){
                $scope.dsStep1Fields.cwoDetails.cwoName =  $scope.dsWorkingUser;
            }
            if (strFormId == '') {
                getandSetGUID();
            }
            if($scope.dsStep1Fields['Date_Created'] != "" && $scope.strIsDraft == 'YES') {
                dateCreatedOnChange();
            }
            if ($scope.oriMsgCustomFields.DSI_Current_Stage > 1) {
                var actionData = commonApi._.filter(incompleteAction, function (val) {
                    return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(dsWorkingUserId) != -1
                });
                if (actionData && actionData.length) {
                    $scope.strCanReply = "yes";
                }
              
            }

        }
        if (isOriPrintView) {
            $scope.hideExportBtn();
             //To get thumbnail
            // $scope.allAttchements = $scope.getValueOfOnLoadData("DS_DOC_ATTACHMENTS_ALL");
            // if ($scope.allAttchements && $scope.allAttchements.length) {
            //     var plainProjectId = projectId && projectId.split("$$")[0];
            //     angular.forEach($scope.allAttchements, function (item) {
            //         item.thumbURL = myConfig.baseUrl + "/commonapi/thumbnail/viewThumb?projectId=" + plainProjectId + "&attachmentId=" + item.Value6
            //         item.thumbType = chkFilename(item.Value2);
            //     })
            // }

        }
        //for thumbnail
        // function chkFilename(fileName) {
        //     var stringR = "",
        //         cwct = "",
        //         tempMisce = $scope.dsStep1Fields.Miscellaneous_Details.Miscellaneous_Group,
        //         tempCwct = $scope.dsStep1Fields.Contract_Work_Completed.Cont_Work_Comp_Group;
        //     for (var index = 0; index < tempCwct.length; index++) {
        //         for (var j = 0; j < tempCwct[index].CWCT_attachements.length; j++) {
        //             cwct = tempCwct[index].CWCT_attachements[j].CWCT_Photo;
        //             if (cwct) {
        //                 if (cwct.content.split('#')[4].replace(cwct.content.split('#')[3] + '_', '') == fileName) {
        //                     return 'C';
        //                 }
        //             }
        //         }
        //     }
        //     for (var index = 0; index < tempMisce.length; index++) {
        //         for (var j = 0; j < tempMisce[index].Misce_attachements.length; j++) {
        //             cwct = tempMisce[index].Misce_attachements[j].Misce_Photo;
        //             if (cwct) {
        //                 if (cwct.content.split('#')[4].replace(cwct.content.split('#')[3] + '_', '') == fileName) {
        //                     return 'M';
        //                 }
        //             }
        //         }
        //     }
        //     return stringR
        // }
        function getConfigurableAttriburteByType(type) {
            var AttributeByType = [];
            if (type) {
                AttributeByType = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return AttributeByType;
        }
        if (isOriView) {
            $scope.WeatherList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Inclement Weather Signal"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
            $scope.LabourList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Labour"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
    
        
        $scope.BsiLabourList = commonApi.getItemSelectionList({
            arrayObject: getConfigurableAttriburteByType("BSI Labour"),
            groupNameKey: "",
            modelKey: "Value8",
            displayKey: "Value8"
        });
        $scope.LocationList = commonApi.getItemSelectionList({
            arrayObject: getConfigurableAttriburteByType("Location"),
            groupNameKey: "",
            modelKey: "Value8",
            displayKey: "Value8"
        });
        $scope.ContractorList = commonApi.getItemSelectionList({
            arrayObject: getConfigurableAttriburteByType("Contractor"),
            groupNameKey: "",
            modelKey: "Value8",
            displayKey: "Value8"
        });
    }
        $scope.validateDate = function(callType) {
            var startDate = $scope.dsStep1Fields.Contract_Completion_Date;
            var endDate = $scope.dsStep1Fields.Ext_Con_Completion_Date;
            if ((Date.parse(startDate) > Date.parse(endDate))) {
                if (callType == "To") {
                    alert("Contract completion date should be less than extended contract completion date");
                    $scope.dsStep1Fields.Contract_Completion_Date = ""
                }
                if (callType == "From") {
                    alert("Extended contract completion date should be greater than contract completion date");
                    $scope.dsStep1Fields.Ext_Con_Completion_Date = ""
                }
            }
        }
        ;
        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] == '') {
            showAllPlants();
            showAllWorkerDetails();
        }

        $scope.dsPydDsdChkData = [];
        if ($scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] && currentViewName == 'ORI_PRINT_VIEW') {
            $scope.dsPydDsdChkData = $scope.getValueOfOnLoadData('DS_PYD_DSD_CHK_GET_ALL_REGSTR_DTL');
        }

        // Load Worker Details data from Custom Attributes
        function showAllWorkerDetails() {
            $scope.formCustomFields['Contractor_Site_Staff']['Contractor_Site_Staff_details'] = [];
            var strPlantNameCategory = $scope.dsStep1Fields['DS_Contractor_Staff'];
            strPlantNameCategory = strPlantNameCategory && strPlantNameCategory.trim();

            var dataPlantDetails = commonApi._.filter(dsAsiConfigurableAttributes, function (element) {
                return element.Value3 === strPlantNameCategory
            });

            for (var index = 0; index < dataPlantDetails.length; index++) {
                var element = dataPlantDetails[index];
                var tmpNomde = angular.copy(STATIC_OBJ_DATA.Contractor_Site_Staff_details);
                tmpNomde.Cont_Site_Staff_Name = element.Value8;
                tmpNomde.DSI_isNew = 'No';
                $scope.formCustomFields['Contractor_Site_Staff']['Contractor_Site_Staff_details'].push(tmpNomde);
            }
        }
        // Load Plant Details data from Custom Attributes
        function showAllPlants() {
            $scope.dsStep1Fields['Plant_Group']['Machine_Plant_Details'] = [];
            var strPlantNameCategory = $scope.dsStep1Fields['DS_Plant_Attribute_Name'];
            strPlantNameCategory = strPlantNameCategory && strPlantNameCategory.trim();

            var dataPlantDetails = commonApi._.filter(dsAsiConfigurableAttributes, function (element) {
                return element.Value3 === strPlantNameCategory
            });
            for (var index = 0; index < dataPlantDetails.length; index++) {
                var element = dataPlantDetails[index];
                var tmpNomde = angular.copy(STATIC_OBJ_DATA.Machine_Plant_Details);
                tmpNomde.Plant_on_Site = element.Value8;
                tmpNomde.refGuid = commonApi.guId();
                tmpNomde.DSI_isPlantNew = 'No';
                $scope.dsStep1Fields['Plant_Group']['Machine_Plant_Details'].push(tmpNomde);
            }
        }
        function setOffset() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
        }

        $scope.bsiChangeEvt = function (bsiImplication) {
          if (bsiImplication.toLowerCase() == 'no') {
                $scope.dsStep1Fields.bsiuser = '';
            }
        };
        $scope.cwctsubTotal = function (type) {
            var tempCwct = $scope.dsStep1Fields.Contract_Work_Completed.Cont_Work_Comp_Group,
                tempMisce = $scope.dsStep1Fields.Miscellaneous_Details.Miscellaneous_Group;
            var cwctCount = 0,
                misceCount = 0,
                misce = 0,
                cwct = 0;
            if (type == "CWC" || type == "All") {
                for (var index = 0; index < tempCwct.length; index++) {
                    for (var j = 0; j < tempCwct[index].Contract_Labor_Details.Contract_Labor_List.length; j++) {
                        cwct = tempCwct[index].Contract_Labor_Details.Contract_Labor_List[j].CWCT_Labour_No;
                        if (cwct)
                            cwctCount += (parseFloat(cwct) || 0);
                    }
                    for (var k = 0; k < tempCwct[index].Contract_BIS_Labor_Details.Contract_BIS_Labor_List.length; k++) {
                        cwct = tempCwct[index].Contract_BIS_Labor_Details.Contract_BIS_Labor_List[k].CWCT_BIS_Labour_No;
                        if (cwct)
                            cwctCount += (parseFloat(cwct) || 0);
                    }
                }
                $scope.dsStep1Fields.Contract_Work_Completed.CWC_Sub_Total = cwctCount.toFixed(1);
            }
            if (type == "Misc" || type == "All") {
                for (var index = 0; index < tempMisce.length; index++) {
                    for (var j = 0; j < tempMisce[index].Misce_Labor_Details.Misce_Labor_List.length; j++) {
                        misce = tempMisce[index].Misce_Labor_Details.Misce_Labor_List[j].Misce_Labour_No;
                        if (misce)
                            misceCount += (parseFloat(misce) || 0);
                    }
                    for (var k = 0; k < tempMisce[index].Misce_BIS_Labor_Details.Misce_BIS_Labor_List.length; k++) {
                        misce = tempMisce[index].Misce_BIS_Labor_Details.Misce_BIS_Labor_List[k].Misce_BIS_Labour_No;
                        if (misce)
                            misceCount += (parseFloat(misce) || 0);
                    }
                }
                $scope.dsStep1Fields.Miscellaneous_Details.Misce_Sub_Total = misceCount.toFixed(1);
            }
            if ($scope.dsStep1Fields.Miscellaneous_Details.Misce_Sub_Total || $scope.dsStep1Fields.Contract_Work_Completed.CWC_Sub_Total) {
                $scope.dsStep1Fields.cwct_misce_Total = (parseInt($scope.dsStep1Fields.Contract_Work_Completed.CWC_Sub_Total || 0) + parseInt($scope.dsStep1Fields.Miscellaneous_Details.Misce_Sub_Total) || 0).toFixed(1);
            }

        };
        $scope.countWorkDetailNo = function () {
            var tempEmployeeDetail = $scope.formCustomFields['Contractor_Site_Staff']['Contractor_Site_Staff_details'];
            var icount = 0;
            for (var index = 0; index < tempEmployeeDetail.length; index++) {
                var element = tempEmployeeDetail[index];
                if (element.Cont_Site_Staff_Input) {
                    icount += (parseFloat(element.Cont_Site_Staff_Input) || 0);
                }
            }

            $scope.dsStep1Fields['Sum_Contractor_Staff_No'] = icount.toFixed(1);
        };
        $scope.ownedHiredsetGuid = function () {
            var unikId = $scope.dsStep1Fields.Plant_Group.Machine_Plant_Details;
            for (var i = 0; i < unikId.length; i++) {
                if (unikId[i].Owned == 'Yes') {
                    unikId[i].OwnedGuid = commonApi.guId();
                    unikId[i].Plant_No = unikId[i].OwnedGuid;
                }
                if (unikId[i].Hired == 'Yes') {
                    unikId[i].HiredGuid = commonApi.guId();
                    unikId[i].hired_No = unikId[i].HiredGuid;
                }
            }
        };
        $scope.countOwned = function () {
            var tempPlantDetail = $scope.dsStep1Fields.Plant_Group.Machine_Plant_Details;
            for (var index = 0; index < tempPlantDetail.length; index++) {
                var element = tempPlantDetail[index],
                    oUsed = 0,
                    oidle = 0,
                    obrokenDowm = 0,
                    hused = 0,
                    hidle = 0,
                    oworked = 0,
                    hWorked = 0,
                    hbrokenDowm = 0;
                if (element.Owned_Worked && element.OwnedGuid == element.Plant_No) {
                    oworked += (parseFloat(element.Owned_Worked) || 0);
                }

                if (element.Owned_used && element.OwnedGuid == element.Plant_No) {
                    oUsed += (parseFloat(element.Owned_used) || 0);
                }
                if (element.Owned_idle && element.OwnedGuid == element.Plant_No) {
                    oidle += (parseFloat(element.Owned_idle) || 0);
                }
                if (element.Owned_brokenDowm && element.OwnedGuid == element.Plant_No) {
                    obrokenDowm += (parseFloat(element.Owned_brokenDowm) || 0);
                }
                if (element.Hired_Worked && element.OwnedGuid == element.Plant_No) {
                    hWorked += (parseFloat(element.Hired_Worked) || 0);
                }
                if (element.Hired_used && element.HiredGuid == element.hired_No) {
                    hused += (parseFloat(element.Hired_used) || 0);
                }
                if (element.Hired_idle && element.HiredGuid == element.hired_No) {
                    hidle += (parseFloat(element.Hired_idle) || 0);
                }
                if (element.Hired_brokenDowm && element.HiredGuid == element.hired_No) {
                    hbrokenDowm += (parseFloat(element.Hired_brokenDowm) || 0);
                }
                if (element.OwnedGuid == element.Plant_No) {
                    element.Owned_total = (oUsed + oidle + obrokenDowm + oworked).toFixed(1);
                }
                if (element.HiredGuid == element.hired_No) {
                    element.Hired_Total = (hused + hidle + hbrokenDowm + hWorked).toFixed(1);
                }
                if ((element.HiredGuid == element.hired_No) && (element.OwnedGuid == element.Plant_No)) {
                    element.Owned_or_Hired_Total = (parseInt(element.Owned_total) + parseInt(element.Hired_Total)).toFixed(1);
                } else if (element.OwnedGuid == element.Plant_No) {
                    element.Owned_or_Hired_Total = parseInt(element.Owned_total).toFixed(1);
                } else if (element.HiredGuid == element.hired_No) {
                    element.Owned_or_Hired_Total = parseInt(element.Hired_Total).toFixed(1);
                }
            }
        };
        $scope.checkandEmpty = function (index, Val, typeVal, objLabour) {
            if (typeVal == "Labour") {
                for (var i = 0; i < objLabour.Contract_Labor_Details.Contract_Labor_List.length; i++) {
                    if (objLabour.Contract_Labor_Details.Contract_Labor_List[i].CWCT_Labour == Val && i != index) {
                        objLabour.Contract_Labor_Details.Contract_Labor_List[index].CWCT_Labour = "";
                        alert("You can not select same Labour");
                        clearLabour();
                        break;
                    }
                }
            }
            if (typeVal == "BsiLabour") {
                for (var i = 0; i < objLabour.Contract_BIS_Labor_Details.Contract_BIS_Labor_List.length; i++) {
                    if (objLabour.Contract_BIS_Labor_Details.Contract_BIS_Labor_List[i].CWCT_BIS_Labour == Val && i != index) {
                        objLabour.Contract_BIS_Labor_Details.Contract_BIS_Labor_List[index].CWCT_BIS_Labour = "";
                        alert("You can not select same Labour");
                        clearBis();
                        break;
                    }
                }
            }
            if (typeVal == "misLabour") {
                for (var i = 0; i < objLabour.Misce_Labor_Details.Misce_Labor_List.length; i++) {
                    if (objLabour.Misce_Labor_Details.Misce_Labor_List[i].Misce_Labour == Val && i != index) {
                        objLabour.Misce_Labor_Details.Misce_Labor_List[index].Misce_Labour = "";
                        alert("You can not select same Labour");
                        clearLabour();
                        break;
                    }
                }
            }
            if (typeVal == "misBsiLabour") {
                for (var i = 0; i < objLabour.Misce_BIS_Labor_Details.Misce_BIS_Labor_List.length; i++) {
                    if (objLabour.Misce_BIS_Labor_Details.Misce_BIS_Labor_List[i].Misce_BSI_Labour == Val && i != index) {
                        objLabour.Misce_BIS_Labor_Details.Misce_BIS_Labor_List[index].Misce_BSI_Labour = "";
                        alert("You can not select same Labour");
                        clearBis();
                        break;
                    }
                }
            }
        };
        function clearBis() {
            $scope.BsiLabourList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("BSI Labour"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });

        }
        function clearLabour() {
            $scope.LabourList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Labour"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
        }
        $scope.scrollTOListItem = function (eID, type) {
            if (eID !== '') {
                $timeout(function () {
                    var newId = type == 'D' ? "#ID_" + eID : "#UP_" + eID;
                    var offset = $(newId).offset();
                    if (offset) {
                        var scrollTotal = offset.top - 120;
                        $('html,body').animate({
                            scrollTop: scrollTotal
                        }, 500);
                    }
                }, 500);
            }
        };

        $scope.update();

        $scope.inValidDate = false;
        $scope.isXHRon = false;
        $scope.dateCreatedOnChange = dateCreatedOnChange;

        function dateCreatedOnChange() {
            $scope.inValidDate = false;
            $scope.isXHRon = false;
            $scope.disabledDate = false;

            var selectedDate = $scope.dsStep1Fields['Date_Created'];
            selectedDate = new Date(selectedDate);
            var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var dayName = days[selectedDate.getDay()];

            $scope.dsStep1Fields['Site_Diary_Day'] = dayName;

            if ($scope.dsStep1Fields['Date_Created'] == '') {
                return;
            }
            var formatedDate = $scope.formatDate(selectedDate, 'dd/mm/yy');
            $scope.data.myFields.Asite_System_Data_Read_Write.ORI_MSG_Fields.ORI_FORMTITLE = $scope.data.myFields.Asite_System_Data_Read_Only['_3_Project_Data']["DS_PROJECTNAME"] + " :: " + formatedDate;
            var dataSourceName = "DS_HA_SD_CHK_GET_ALL_REGSTR_DTL";
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": $scope.dsStep1Fields['Date_Created']
                    }]
                }
            };

            $scope.requests['chkDateFetchRegstrData'] = true;
            $scope.add({
                name: "chkDateFetchRegstrData",
                status: "incomplete"
            });

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;

                $scope.requests['chkDateFetchRegstrData'] = false;
                $scope.update({
                    name: "chkDateFetchRegstrData",
                    status: "completed"
                });

                if (resData) {
                    var spData = angular.fromJson(response.data[dataSourceName]);
                    spData = spData['Items']["Item"] || [];

                    if (!spData.length) {
                        return;
                    }

                    if (spData[0] && spData[0].Value2 === 'Yes') {
                        $scope.inValidDate = true;
                    }

                }
            });

        }

        /***
                 * This function to auto fill the specific data from the previous active form section wise as well all sections data.
                 * set Previous form's historic data section wise code : START
                 */

        $scope.spXhr = {
            'DS_HA_SD_GET_previous_form_Contract_Work_Completed_Labour_Service': false,
            'DS_HA_SD_GET_previous_form_Miscellaneous_Details_Labour_Service': false,
            'DS_HA_SD_GET_previous_form_Contractor_Site_Staff_details': false,
            'DS_HA_SD_GET_previous_form_Machine_Plant_Details': false,
            'DS_HA_SD_GET_previous_form_Progress_Update_Details': false,
            'DS_HA_SD_GET_previous_form_Material_Delivered': false,

        };

        var setContractorCompleteDetail = function (labour, bisLabour, guidData) {
            var prevContractorCompleteObj = {},
                tempList = [],
                tempBisListlabour = [],
                tempListlabour = [],
                labourR = commonApi._.uniq(labour, 'Value7');
            for (var i = 0; i < labourR.length; i++) {
                tempBisListlabour = [],
                    tempListlabour = [];
                var contractorCompleteObj = angular.copy(STATIC_OBJ_DATA.Cont_Work_Comp_Group);
                prevContractorCompleteObj = labourR[i];
                contractorCompleteObj.CWCT_isSelected = false;
                contractorCompleteObj.CWCT_Item_No = prevContractorCompleteObj.Value3;
                contractorCompleteObj.CWCT_Description = prevContractorCompleteObj.Value4;
                contractorCompleteObj.CWCT_Photo = prevContractorCompleteObj.Value5;
                contractorCompleteObj.CWCT_Photo_Location = prevContractorCompleteObj.Value6;
                contractorCompleteObj.CWCT_Guid = guidData[0].Name.indexOf(',') > -1 ? guidData[0].Name.split(',')[i] : guidData[0].Name;
                for (var j = 0; j < labour.length; j++) {
                    if (labour[j].Value7 == prevContractorCompleteObj.Value7) {
                        var contractLaborListObj = angular.copy(STATIC_OBJ_DATA.Contract_Labor_List);
                        contractLaborListObj.Labour_isSelected = false;
                        contractLaborListObj.CWCT_Labour = labour[j].Value8;
                        contractLaborListObj.CWCT_Labour_No = labour[j].Value11;
                        contractLaborListObj.CWCT_Conc_Type = labour[j].Value12;
                        contractLaborListObj.CWCT_Parent_Labor_Guid = guidData[0].Name.indexOf(',') > -1 ? guidData[0].Name.split(',')[i] : guidData[0].Name;
                        contractLaborListObj.CWCT_Labor_Guid = "";
                        tempListlabour.push(contractLaborListObj);
                    }

                }
                contractorCompleteObj['Contract_Labor_Details']['Contract_Labor_List'] = tempListlabour;
                for (var k = 0; k < bisLabour.length; k++) {
                    if (bisLabour[k].Value7 == prevContractorCompleteObj.Value7) {
                        var contractLaborListObj = angular.copy(STATIC_OBJ_DATA.Contract_BIS_Labor_List);
                        contractLaborListObj.BIS_Labour_isSelected = false;
                        contractLaborListObj.CWCT_BIS_Labour = bisLabour[k].Value8;
                        contractLaborListObj.CWCT_BIS_Labour_No = bisLabour[k].Value11;
                        contractLaborListObj.CWCT_BIS_Conc_Type = bisLabour[k].Value12;
                        contractLaborListObj.CWCT_Parent_BIS_Labor_Guid = guidData[0].Name.indexOf(',') > -1 ? guidData[0].Name.split(',')[i] : guidData[0].Name;
                        contractLaborListObj.CWCT_BIS_Labor_Guid = "";
                        tempBisListlabour.push(contractLaborListObj);
                    }

                }
                contractorCompleteObj['Contract_BIS_Labor_Details']['Contract_BIS_Labor_List'] = tempBisListlabour;
                tempList.push(contractorCompleteObj);
            }
            if(tempList.length){
                    $scope.dsStep1Fields['Contract_Work_Completed']['Cont_Work_Comp_Group'] = tempList;
                    $scope.dsStep1Fields.Contract_Work_Completed.CWC_Sub_Total = labourR[0].Value13;
                    $scope.dsStep1Fields.cwct_misce_Total = guidData[0].Value3;
            }
            $timeout(function () {
                clearLabour();
                clearBis();
                $scope.$apply();
            });
        },
            setMiscellaneousDetails = function (labour, bisLabour, guidData) {
                var prevMiscellaneousCompleteObj = {},
                    tempList = [],
                    tempBisListlabour = [],
                    tempListlabour = [],
                    labourR = commonApi._.uniq(labour, 'Value7');
                for (var i = 0; i < labourR.length; i++) {
                    tempBisListlabour = [];
                    tempListlabour = [];
                    var miscellaneousCompleteObj = angular.copy(STATIC_OBJ_DATA.Miscellaneous_Group);
                    prevMiscellaneousCompleteObj = labourR[i];
                    miscellaneousCompleteObj.Misce_isSelected = false;
                    miscellaneousCompleteObj.Misce_Item_No = prevMiscellaneousCompleteObj.Value3;
                    miscellaneousCompleteObj.Misce_Description = prevMiscellaneousCompleteObj.Value4;
                    miscellaneousCompleteObj.Misce_Photo = prevMiscellaneousCompleteObj.Value5;
                    miscellaneousCompleteObj.Misce_Photo_Location = prevMiscellaneousCompleteObj.Value6;
                    miscellaneousCompleteObj.Misce_Guid = guidData[0].Value4.indexOf(',') > -1 ? guidData[0].Value4.split(',')[i] : guidData[0].Value4;
                    for (var j = 0; j < labour.length; j++) {
                        if (labour[j].Value7 == prevMiscellaneousCompleteObj.Value7) {
                            var contractLaborListObj = angular.copy(STATIC_OBJ_DATA.Misc_Labor_List);
                            contractLaborListObj.Misce_Labour_isSelected = false;
                            contractLaborListObj.Misce_Labour = labour[j].Value8;
                            contractLaborListObj.Misce_Labour_No = labour[j].Value11;
                            contractLaborListObj.Misce_Conc_Type = labour[j].Value12;
                            contractLaborListObj.Misce_Parent_Labor_Guid = guidData[0].Value4.indexOf(',') > -1 ? guidData[0].Value4.split(',')[i] : guidData[0].Value4;
                            contractLaborListObj.Misce_Labor_Guid = "";
                            tempListlabour.push(contractLaborListObj);
                        }
                    }
                    miscellaneousCompleteObj['Misce_Labor_Details']['Misce_Labor_List'] = tempListlabour;
                    for (var k = 0; k < bisLabour.length; k++) {
                        if (bisLabour[k].Value7 == prevMiscellaneousCompleteObj.Value7) {
                            var contractLaborListObj = angular.copy(STATIC_OBJ_DATA.Misce_BIS_Labor_List);
                            contractLaborListObj.Misce_BIS_Labour_isSelected = false;
                            contractLaborListObj.Misce_BSI_Labour = bisLabour[k].Value8;
                            contractLaborListObj.Misce_BIS_Labour_No = bisLabour[k].Value11;
                            contractLaborListObj.Misce_BIS_Conc_Type = bisLabour[k].Value12;
                            contractLaborListObj.Misce_Parent_BIS_Labor_Guid = guidData[0].Value4.indexOf(',') > -1 ? guidData[0].Value4.split(',')[i] : guidData[0].Value4;
                            contractLaborListObj.Misce_BIS_Labor_Guid = "";
                            tempBisListlabour.push(contractLaborListObj);
                        }
                    }
                    miscellaneousCompleteObj['Misce_BIS_Labor_Details']['Misce_BIS_Labor_List'] = tempBisListlabour;
                    tempList.push(miscellaneousCompleteObj);
                }
                if(tempList.length){
                $scope.dsStep1Fields['Miscellaneous_Details']['Miscellaneous_Group'] = tempList;
                $scope.dsStep1Fields.Miscellaneous_Details.Misce_Sub_Total = labourR[0].Name;
                $scope.dsStep1Fields.cwct_misce_Total = guidData[0].Value3;
                $timeout(function () {
                    clearLabour();
                    clearBis();
                    $scope.$apply();
                });
                }
            },
            setContractorSiteStaffData = function (prevsitestaffDetails) {
                var prevsitestaffObj = {},
                    tempList = [];
                for (var i = 0; i < prevsitestaffDetails.length; i++) {
                    var siteObj = angular.copy(STATIC_OBJ_DATA.Contractor_Site_Staff_details);
                    prevsitestaffObj = prevsitestaffDetails[i];
                    siteObj.Cont_Site_Staff_Name = prevsitestaffObj.Value3;
                    siteObj.Cont_Site_Staff_Input = prevsitestaffObj.Name;
                    $scope.dsStep1Fields.Sum_Contractor_Staff_No= prevsitestaffObj.Value4;
                    tempList.push(siteObj);
                }
                if(tempList.length){
                $scope.formCustomFields['Contractor_Site_Staff']['Contractor_Site_Staff_details'] = tempList;}
            },
            setMachineplantDetailsData = function (prevMachineplantDetails) {
                var prevMachineplantDetailsObj = {},
                    tempList = [];
                for (var i = 0; i < prevMachineplantDetails.length; i++) {
                    var plantObj = angular.copy(STATIC_OBJ_DATA.Machine_Plant_Details);
                    prevMachineplantDetailsObj = prevMachineplantDetails[i];
                    plantObj.Plant_on_Site = prevMachineplantDetailsObj.Value3;
                    plantObj.Owned_Worked = prevMachineplantDetailsObj.Value13;
                    plantObj.Owned_used = prevMachineplantDetailsObj.Value7;
                    plantObj.Owned_idle = prevMachineplantDetailsObj.Value8;
                    plantObj.Owned_brokenDowm = prevMachineplantDetailsObj.Value9;
                    plantObj.Owned_total = prevMachineplantDetailsObj.Value11;
                    plantObj.Owned_or_Hired_Total = prevMachineplantDetailsObj.Value12 || 0.0;
                    plantObj.Hired_used = prevMachineplantDetailsObj.Value4;
                    plantObj.Hired_idle = prevMachineplantDetailsObj.Value5;
                    plantObj.Hired_brokenDowm = prevMachineplantDetailsObj.Value6;
                    plantObj.Hired_Worked = prevMachineplantDetailsObj.Value14;
                    plantObj.Hired_Total = prevMachineplantDetailsObj.Value10 || 0.0;
                    tempList.push(plantObj);
                }
                if(tempList.length){
                $scope.dsStep1Fields['Plant_Group']['Machine_Plant_Details'] = tempList;}

            },
            setProgressDetailsData = function (prevprogressDetail) {
                var prevprogressObj = {},
                    tempList = [];
                for (var i = 0; i < prevprogressDetail.length; i++) {
                    var pObj = angular.copy(STATIC_OBJ_DATA.Progress_Update_Details);
                    prevprogressObj = prevprogressDetail[i];
                    pObj.Work_Activities = prevprogressObj.Value3;
                    pObj.Actual_Progress = prevprogressObj.Name;
                    tempList.push(pObj);
                }
                if(tempList.length){
                $scope.dsStep1Fields['Progress_Update']['Progress_Update_Details'] = tempList;
                }
            },
            setMaterialDetailsData = function (prevMaterialDetail) {
                var prevtMaterialObj = {},
                    tempList = [];
                for (var i = 0; i < prevMaterialDetail.length; i++) {
                    var mObj = angular.copy(STATIC_OBJ_DATA.Material_Delivered_Details);
                    prevtMaterialObj = prevMaterialDetail[i];
                    mObj.MD_Item = prevtMaterialObj.Name;
                    mObj.Des_of_Material = prevtMaterialObj.Value4;
                    tempList.push(mObj);
                }
                if(tempList.length){
                $scope.dsStep1Fields['Material_Delivered']['Material_Delivered_Details'] = tempList;
                }
            }

        var setPreviousFormsDetails = function (spStr, response) {
            switch (spStr) {

                case 'DS_HA_SD_GET_previous_form_Contractor_Site_Staff_details':
                    setContractorSiteStaffData(response);
                    break;
                case 'DS_HA_SD_GET_previous_form_Machine_Plant_Details':
                    setMachineplantDetailsData(response);
                    break;
                case 'DS_HA_SD_GET_previous_form_Progress_Update_Details':
                    setProgressDetailsData(response);
                    break;
                case 'DS_HA_SD_GET_previous_form_Material_Delivered':
                    setMaterialDetailsData(response);
                    break;
                default:
                    // set all data.
                    setContractorSiteStaffData(response);
                    setMachineplantDetailsData(response);
                    setProgressDetailsData(response);
                    setMaterialDetailsData(response);
            }
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 100);
        };
        var prepareSPParamContent = function (spStr) {
            var splitedSPName = spStr.split(','),
                appBldrCode = $document.find('#DS_FORM_APP_BLDR_CODE').val() || 'HA-SD',
                appBldrCode=appBldrCode+','+ $scope.dsStep1Fields.Contractor,
                spsObjList = [];

            for (var i = 0; i < splitedSPName.length; i++) {
                spsObjList.push({
                    fieldName: splitedSPName[i],
                    fieldValue: appBldrCode
                });
            }

            return {
                spStr: spStr,
                spsObjList: spsObjList
            }
        };
        var getPreviousFormsDetails = function (spParamObj) {
            var form = {
                projectId: projectId,
                formId: formId,
                fields: spParamObj.spStr,
                callbackParamVO: {
                    customFieldVOList: spParamObj.spsObjList
                }
            };

            $scope.spXhr[spParamObj.spStr] = true;
            $scope.getCallbackData(form).then(function (response) {
                if (!response.data) {
                    return;
                }
                setPreviousFormsDetails(spParamObj.spStr, angular.fromJson(response.data[spParamObj.spStr]).Items.Item);
                $scope.spXhr[spParamObj.spStr] = false;
            });
        };
        $scope.fillOutPrevFormDetails = function (spName) {
            getPreviousFormsDetails(prepareSPParamContent(spName));
        };
        $scope.fillOutPrevFormDetailsMISc = function (spName) {
            var spList = spName.split(',');
            $scope.spXhr[spList[0]] = true
            var appBldrCode = $document.find('#DS_FORM_APP_BLDR_CODE').val() || 'HA-SD',
               appBldrCode=appBldrCode+','+ $scope.dsStep1Fields.Contractor,
                spParam = {
                    dataSourceArray: [{
                        "fieldName": spList[0],
                        "fieldValue": appBldrCode
                    },
                    {
                        "fieldName": spList[1],
                        "fieldValue": appBldrCode
                    },
                    {
                        "fieldName": spList[2],
                        "fieldValue": appBldrCode
                    }],
                    successCallback: miscCallback
                };
            $scope.getCallbackSPdata(spParam);
        }
        function miscCallback(responseList) {
            var labour, bislabour, guidData;
            if (responseList["DS_HA_SD_GET_previous_form_Miscellaneous_Details"]) {
                labour = responseList["DS_HA_SD_GET_previous_form_Miscellaneous_Details"];
            }
            if (responseList["DS_HA_SD_GET_previous_form_Miscellaneous_Details_Labour_Service"]) {
                bislabour = responseList["DS_HA_SD_GET_previous_form_Miscellaneous_Details_Labour_Service"];
            }
            if (responseList["DS_HA_SD_GET_previous_form_Guid_List"]) {
                guidData = responseList["DS_HA_SD_GET_previous_form_Guid_List"];
            }

            setMiscellaneousDetails(labour, bislabour, guidData);
            $scope.spXhr.DS_HA_SD_GET_previous_form_Miscellaneous_Details_Labour_Service = false
        }
        $scope.fillOutPrevFormDetailsConc = function (spName) {
            var spList = spName.split(',');
            $scope.spXhr[spList[0]] = true
            var appBldrCode = $document.find('#DS_FORM_APP_BLDR_CODE').val() || 'HA-SD',
                appBldrCode=appBldrCode+','+ $scope.dsStep1Fields.Contractor,
                spParam = {
                    dataSourceArray: [{
                        "fieldName": spList[0],
                        "fieldValue": appBldrCode
                    },
                    {
                        "fieldName": spList[1],
                        "fieldValue": appBldrCode
                    },
                    {
                        "fieldName": spList[2],
                        "fieldValue": appBldrCode
                    },
                    ],
                    successCallback: concCallback
                };
            $scope.getCallbackSPdata(spParam);
        }
        function concCallback(responseList) {
            var labour,
                bislabour,
                guidData;
            if (responseList["DS_HA_SD_GET_previous_form_Contract_Work_Completed"]) {
                labour = responseList["DS_HA_SD_GET_previous_form_Contract_Work_Completed"];
            }
            if (responseList["DS_HA_SD_GET_previous_form_Contract_Work_Completed_Labour_Service"]) {
                bislabour = responseList["DS_HA_SD_GET_previous_form_Contract_Work_Completed_Labour_Service"];
            }
            if (responseList["DS_HA_SD_GET_previous_form_Guid_List"]) {
                guidData = responseList["DS_HA_SD_GET_previous_form_Guid_List"];
            }
            setContractorCompleteDetail(labour, bislabour, guidData);
            $scope.spXhr.DS_HA_SD_GET_previous_form_Contract_Work_Completed_Labour_Service = false
        }

        //if item is deleted than make one entry mandatory
        $scope.deleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);

        };
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            if (objKeyName == "Safety_Issues_Group") {
                var newSiNo = repeatingData.length + 1;
                newRowObject.SI_Item = + newSiNo;
            }
            if (objKeyName == "Material_Delivered_Details") {
                var newMdNo = repeatingData.length + 1;
                newRowObject.MD_Item = + newMdNo;
            }
            if (objKeyName == "Work_Delay_Today_Details") {
                var newWDT = repeatingData.length + 1;
                newRowObject.WDT_Item = + newWDT;
            }

            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
                $scope.expandTextAreaOnLoad();
            });


        };

        $scope.deleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };
        $scope.bsiUsersList = structureItemList(CONSTANTS_OBJ.BSI_USER_LIST_KEY, commonApi.roleUsersListByRoleName('sd-bsi', ds_Projusers_Role));
        $scope.cowUserslist = structureItemList(CONSTANTS_OBJ.COW_SCOW_USER_LIST_KEY,commonApi.roleUsersListByRoleName('sd-scow-cow', ds_Projusers_Role));
        $scope.pmUserslist = structureItemList(CONSTANTS_OBJ.COMM_TEAM_USER_LIST_KEY,
            commonApi._.filter(ds_Projusers_Role, function (val) {
                return (val.Value.split('|')[0].trim() == "SD-Contractor");
            }));
        var ClearActionbyMsg = function () {
            var Workinguserid = dsWorkingUserId;
            var clearActionNodes="";
            var cStage = $scope.oriMsgCustomFields.DSI_Current_Stage;
            var allNodes = commonApi._.filter(incompleteActionsByMsg, {
                Value4: "Assign Status"
            });
            if(cStage!=2){
                clearActionNodes = commonApi._.reject(allNodes, function(obj) {
                    return (obj.Value1 == Workinguserid)
                });
            }
            else {
                clearActionNodes =allNodes;
            }
            if (clearActionNodes.length) {
                if (!asiteSystemDataReadWrite['Auto_Complete_msg_Actions']) {
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions'] = {};
                }
                asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'] = [];
                asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['DS_AUTOCOMPLETE_ACTION_MSG_APP_ID'] = "1";

                var AppId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'];
                for (var i = 0; i < clearActionNodes.length; i++) {
                    var nodeObj = clearActionNodes[i];
                    asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'].push({
                        DS_MSG_AC_TYPE: "clear",
                        DS_MSG_AC_FORM: AppId,
                        DS_MSG_AC_MSG_TYPE: nodeObj.Value3,
                        DS_MSG_AC_USERID: nodeObj.Value1,
                        DS_MSG_AC_ACTION: "2",
                        DS_MSG_AC_ACTION_REMARKS: "Action Cleared"
                    });
                }

            }
        }
        function  sendAssignOthrs(userList) {
            var insertpoint = asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;
            var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
        //    asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
            for(var i=0;i<userList.length;i++){
                  var AutoDistActionStructure = angular.copy(STATIC_OBJ_DATA.AutoDistActionStructure);
                    AutoDistActionStructure.DS_ADO_TYPE = "3";
                    AutoDistActionStructure.DS_ADO_FORM = strFormId;
                    AutoDistActionStructure.DS_ADO_MSG_TYPE = "ORI";
                    AutoDistActionStructure.DS_ADO_FORMACTIONS = "2";
                    AutoDistActionStructure.DS_ADO_ACTIONDUEDATE =  commonApi.calculateDistDateFromDays({
                        baseDate: currServerDate,
                        days: 5
                    });
                    AutoDistActionStructure.DS_ADO_PROJDISTUSERS = userList[i].split('#')[0].trim();
                    insertpoint.push(AutoDistActionStructure);
                
            }
            if (insertpoint.length) {
                asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS_APP_ID = "1";
            }
        }
        /* Set app work Flow */
        function setAppWorkflow() {
            var userTodistribute = '',
                currFormStaus = '',
                internalStage = '',
                autoDistNode = '3';
            // Distribution Will be made from here
            asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            asiteSystemDataReadWrite['Auto_Complete_msg_Actions']['Auto_Complete_msg_Action'] = [];
            asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
            asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS_APP_ID = "0";

            var cStage = $scope.oriMsgCustomFields.DSI_Current_Stage;
            clearConcattachdata();
            clearMiscattachdata();
            if (cStage == "1" && $scope.dsStep1Fields.BSI_Input_Required == 'Yes') {
                setAutoDistributionAll($scope.dsStep1Fields.bsiuser);
                $scope.dsStep1Fields.RssDetails.rssResDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                $scope.oriMsgCustomFields.DSI_Next_Stage = 2;
                currFormStaus = 'Open';
            }
            else if (($scope.dsStep1Fields.BSI_Input_Required == 'No' && cStage == "1") || cStage == "2") {
                if (cStage == "1"){
                    $scope.dsStep1Fields.RssDetails.rssResDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                    setAutoDistributionAll($scope.dsStep1Fields.cwouser);
                }
                else {
                    sendAssignOthrs($scope.dsStep1Fields.cwouser);
                    $scope.dsStep1Fields.BsiDetails.bsiName = $scope.dsWorkingUser;
                    $scope.dsStep1Fields.BsiDetails.bsiResDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                    ClearActionbyMsg();
                }
                $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
                currFormStaus = 'Open';
            }
            else if (cStage == "3") {
                sendAssignOthrs($scope.dsStep1Fields.pmUser);
                ClearActionbyMsg();
                $scope.dsStep1Fields.cwoDetails.cwoName =  $scope.dsWorkingUser;
                $scope.dsStep1Fields.cwoDetails.cwoResDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                $scope.oriMsgCustomFields.DSI_Next_Stage = 4;
                currFormStaus = 'Completed';
            }
            else if (cStage == "4") {
                ClearActionbyMsg();
                $scope.dsStep1Fields.pm_ResDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                internalStage = 'Close form';
                $scope.oriMsgCustomFields.DSI_Next_Stage = 5;
                currFormStaus = 'Completed (Closed)';
            }
         
            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: dsAllFormStatus,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                $scope.dsStep1Fields.currStage = internalStage;
            }
        }
      
        function setAutoDistributionAll(userList) {
            var insertpoint = asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users;
            for(var i=0;i<userList.length;i++){
                var structDistricution = angular.copy($scope.structDistribution)            
                structDistricution.DS_PROJDISTUSERS = userList[i].split('#')[0].trim();
                structDistricution.DS_FORMACTIONS = "2#Assign Status";
                structDistricution.DS_ACTIONDUEDATE =  commonApi.calculateDistDateFromDays({
                    baseDate: currServerDate,
                    days: 5
                });
                insertpoint.push(structDistricution);
            }
            if (insertpoint.length) {
                asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE='3';
            }
            
        }
        $scope.checkandDel = function (){
            setAutoDistributionAll($scope.dsStep1Fields.bsiuser);
            ClearActionbyMsg();
        }
        $scope.setInsAppbuilder = function (siteType) {
            if (siteType == "ARUPHK-SMA") {
                $scope.dsStep1Fields.Ins_AppID = 'ARUPHK-IRFA';
            }
            else if (siteType == "ARUPHK-SME") {
                $scope.dsStep1Fields.Ins_AppID = 'ARUPHK-IRF';
            }
            else if (siteType == "ARUPHK-SMB") {
                $scope.dsStep1Fields.Ins_AppID = 'ARUPHK-IRFB';
            }
        }
        function clearConcattachdata() {
            var attachData = '', actionData;
            for (var i = 0; i < $scope.dsStep1Fields['Contract_Work_Completed']['Cont_Work_Comp_Group'].length; i++) {
                attachData = $scope.dsStep1Fields['Contract_Work_Completed']['Cont_Work_Comp_Group'][i].CWCT_attachements;
                actionData = commonApi._.filter(attachData, function (val) {
                    return val.CWCT_Photo != "";
                });
                $scope.dsStep1Fields['Contract_Work_Completed']['Cont_Work_Comp_Group'][i].CWCT_attachements = actionData;

            }
        }
        function clearMiscattachdata() {
            var attachData = '', actionData;
            for (var i = 0; i < $scope.dsStep1Fields['Miscellaneous_Details']['Miscellaneous_Group'].length; i++) {
                attachData = $scope.dsStep1Fields['Miscellaneous_Details']['Miscellaneous_Group'][i].Misce_attachements;
                actionData = commonApi._.filter(attachData, function (val) {
                    return val.Misce_Photo != "";
                });
                $scope.dsStep1Fields['Miscellaneous_Details']['Miscellaneous_Group'][i].Misce_attachements = actionData;
            }
        }
        function setLabourHeaderData() {
            var lab = getConfigurableAttriburteByType("Labour"),
                tempList = [],
                lHeader = "";
            for (var i = 0; i < lab.length; i++) {
                lHeader = angular.copy(STATIC_OBJ_DATA.DSI_CONC_LabourHeaderList);
                lHeader.CONC_Seq = i
                lHeader.CONC_HeaderName = lab[i].Value8;
                tempList.push(lHeader);
            }
            $scope.oriMsgCustomFields.DSI_CONC_LabourHeaderList = tempList;

            lab = getConfigurableAttriburteByType("BSI Labour")
            tempList = [];
            for (var i = 0; i < lab.length; i++) {
                lHeader = angular.copy(STATIC_OBJ_DATA.DSI_BIS_LabourHeaderList);
                lHeader.CONC_BIS_Seq = i
                lHeader.CONC_BIS_HeaderName = lab[i].Value8;
                tempList.push(lHeader);
            }
            $scope.oriMsgCustomFields.DSI_BIS_LabourHeaderList = tempList;
        }
        $window.HASiteDiaryFinalCallBack = function () {
            if ($scope.inValidDate) {
                $window.alert('Validation\n\nForm already created agaist selected date!');
                return true;
            }

            if (!$scope.strCanReply) {
                alert($scope.Msg);
                return true;
            }
            setAppWorkflow();
            return false;
        };

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof HASiteDiaryFinalCallBack !== "undefined") {
        return HASiteDiaryFinalCallBack();
    }
}