
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        // restrict autosave Draft

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {


                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });

        var STATIC_OBJ_DATA = {
                // Packagewise_Name: {
                //     PACKAGE_NAME_CODE:'',
                //     Expense_Type_List_Group:
                //     {    
                //     Expense_Type_List:[{
                //         EXPENSE_TYPE:'',
                //         CONTINGENCY_DETAILS:'',
                //         CONTINGENCY_VALUE:'',
                //         EXPECTED_VALUE:'',
                //         ACTUAL_DATE:'',
                //         ACTUAL_VALUE:''
                //     }]}
                //     },
                // Expense_Type_List:{
                //     EXPENSE_TYPE:'',
                //     CONTINGENCY_DETAILS:'',
                //     CONTINGENCY_VALUE:'',
                //     EXPECTED_VALUE:'',
                //     ACTUAL_DATE:'',
                //     ACTUAL_VALUE:''
                // },
                // Auto_Distribute_Users: {
                //     AutoDist_Id: "",
                //     DS_PROJDISTUSERS: "",
                //     DS_FORMACTIONS: "",
                //     isEditable: "1",
                //     dist_isSelected: false,
                //     DS_ACTIONDUEDATE: "",
                // },
            }

            // $scope.tableUtilSettings = {
            //     Packagewise_Name: {
            //         tooltip: "select to remove/remove all/Insert new data",
            //         hasDefaultRecord: true,
            //         hideControlIcon: {
            //             editRow : 0,
            //         },
            //         checkboxModelKey: "Certi_isSelected",
            //         newStaticObject : angular.copy(STATIC_OBJ_DATA.Packagewise_Name),
            //         ADD_NEW_BEFORE_TIP : "Insert before document",
            //         ADD_NEW_AFTER_TIP : "Insert after document",
            //         deleteAllRowTooltip: "Remove all documents",
            //         deleteCurrRowMsg : "Remove document",
            //         deleteSelectedMsg : "Remove selected document"
            //     },   
            //     Expense_Type_List: {
            //         tooltip: "select to remove/remove all/Insert new data",
            //         hasDefaultRecord: true,
            //         hideControlIcon: {
            //             editRow : 0,
            //         },
            //         checkboxModelKey: "Dep_isSelected",
            //         newStaticObject : angular.copy(STATIC_OBJ_DATA.Expense_Type_List),
            //         ADD_NEW_BEFORE_TIP : "Insert before document",
            //         ADD_NEW_AFTER_TIP : "Insert after document",
            //         deleteAllRowTooltip: "Remove all documents",
            //         deleteCurrRowMsg : "Remove document",
            //         deleteSelectedMsg : "Remove selected document"
            //     }
            // }
            
        var TTT_CONSTANT = {
            //define status
            notification_status: "SC Completion N issued",
            notification_Accepted: "Accepted",
            ttt_notification_group: "TTT_Notification_Group",
            ttt_notification_CC_group: "TTT_Notification_CC_Group",
            scm: "SCM"
        }

        /** Initialize db fields */
        $scope.logo = "/images/htmlform/commenting/tideway.png";

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.ori_msg_Custom_Fields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
       // $scope.contingencyexpenseforcaste = $scope.ori_msg_Custom_Fields["CONTINGENCY_EXPENSE_FORCASTE"];
        // $scope.packagewise_name_group = $scope.contingencyexpenseforcaste["Packagewise_Name_Group"];
        // $scope.packagewise_name = $scope.packagewise_name_group["Packagewise_Name"];
        
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var ds_asi_get_project_details = $scope.getValueOfOnLoadData('DS_ASI_GET_PROJECT_DETAILS');
      
        var dsWorkingUser = dsWorkingUserId;
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_PRINT_VIEW") {
            var closeBtn = angular.element('.docked .ibox .btn-xs.close-link:visible');
            closeBtn.trigger('click');
            $timeout(function () {
                showDate();
                dropFields();

                $scope.update();
            }, 200);
        } else {
            $scope.update();
        }

        function showDate() {
            var today = new Date();

            today = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear();
            document.getElementById("id1").innerHTML = today;
        }


        // $scope.addNewItem = function (repeatingData, objKeyName ) {
        //     var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName] );
        //     repeatingData.push(newRowObject);

        //     $timeout(function(){
        //         var bodypartObj = document.getElementById('tbl_'+objKeyName);

        //         if(bodypartObj){
        //             var scrollStr = bodypartObj.scrollHeight;
        //             bodypartObj.scrollTop = scrollStr;
        //         }
        //     });
        //     $scope.expandTextAreaOnLoad();
        // };

        function dropFields() {
            if (ds_asi_get_project_details.length) {
                $scope.projectname = [];

                for (var i = 0; i < ds_asi_get_project_details.length; i++) {
                    $scope.projectname.push({
                        optlabel: "",
                        options: [{
                            displayValue: ds_asi_get_project_details[i].Value3,
                            modelValue: ds_asi_get_project_details[i].Value2,
                            checked: false
                        }]
                    });
                }

            }

        }

        //send distribution
        // function setAutoDistribution(strUser, strAction, strDueDate, iAutodistId) {
        //     if (strDueDate) {
        //         strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
        //     }
            
        //     //get copy of distribution and set user ,date ,action to distribute
        //     var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
        //     structDistribution.AutoDist_Id = iAutodistId;
        //     structDistribution.DS_PROJDISTUSERS = strUser;
        //     structDistribution.DS_FORMACTIONS = strAction;
        //     structDistribution.DS_ACTIONDUEDATE = strDueDate;

        //     $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push(structDistribution);
        // }

        // function setAutoCreateNodesValues(){
		// 	$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;
		// 	$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
        //     $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = "ACT-Test",
        //     $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "1";

		// 	$scope.ACF_01_FORM.ACF_01_CREATED_BY = dsWorkingUserId;
		// 	$scope.ACF_01_FORM.ACF_01_ORI_USERREF = $scope.ori_msg_Custom_Fields['ORI_USERREF'];
        //     $scope.ACF_01_FORM.ACF_01_ORI_FORMTITLE = $scope.ori_msg_Custom_Fields['ORI_FORMTITLE'];
        //     $scope.ACF_01_FORM.ACF_01_PROJECT_NAME_CODE = $scope.ori_msg_Custom_Fields['PROJECT_NAME_CODE'];
        //     $scope.ACF_01_FORM.ACF_01_FORCASTED_MONTH = $scope.ori_msg_Custom_Fields['FORCASTED_MONTH'];
        //     $scope.ACF_01_FORM.ACF_01_DS_CLOSE_DUE_DATE=  $scope.setDbDateClientSide(5);
        //     $scope.ACF_01_FORM.ACF_01_DS_FORMTITLE = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
            
        // }

        $window.expFinalCallBack = function (){
            return setFlow();
        }

        function setFlow(){
            
            // $scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
            // if(currentViewName == "ORI_VIEW")
            // {
            
            //     $scope.ori_msg_Custom_Fields.DS_AUTODISTRIBUTE = "3";
            //         var struser = dsWorkingUserId;
            //         var iAutodistId = 1;
            //         var strduedate = $scope.setDbDateClientSide(5);
            //         var straction ="3#Respond";

            //         setAutoDistribution(struser, straction, strduedate, iAutodistId);
            // }
            //setAutoCreateNodesValues();
        }

        $scope.update();
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof expFinalCallBack !== "undefined") {
        return expFinalCallBack();
    }
}

function customHTMLMethodBeforeCreate_RES() {

    if (typeof expFinalCallBack !== "undefined") {
        return expFinalCallBack();
    }
}
