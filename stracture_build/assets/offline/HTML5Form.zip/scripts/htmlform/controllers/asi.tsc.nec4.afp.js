    /**
     * Form Controller module.
     * This module will return Form Controller.
     * @module Form-Controller
     */
    define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
        'use strict';
        /**
         * @constructor
         * @alias module:Form-Controller/FormController
         */
        function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

            $controller(baseController, {
                $scope: $scope,
                $element: $element
            });

            $scope.isFullLoaded({
                onComplete: function () {
                    $timeout(function () {
                        $scope.loaded = true;
                        $element.addClass('loaded');
                    }, 50);
                }
            });

            var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
            if (projectId == "null")
                projectId = window.currProjId;
            var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
            var currentViewName = window.currentViewName;
            var ctrl = this;
            var modelRowIndex = -1;
            $scope.modalData = {};

            var tempData = $scope.getFormData();
            $scope.data = {
                myFields: tempData
            };

            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 1000);

            $scope.getServerTime(function (serverDate) {
                $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), NEC4_CONSTANT.yymmdddateformate);
            });

            if ($window.stopAutoSaveTimer) {
                $window.stopAutoSaveTimer();
            } else if ($window.oAutoSaveTimer) {
                $window.clearTimeout($window.oAutoSaveTimer);
                $window.oAutoSaveTimer = null;
            }
            
            $scope.isDataLoaded = true;

            var STATIC_OBJ_DATA = {
                Distribution_Section: {
                    Dist_Section_Code: "",
                    Dist_Section_Name: "",
                    Activity_Code: "",
                    Activity_Name: "",
                    isDS_Locked:"No",
                    Applied_Amount: "",
                    Approved_Amount: "",
                    Cumulative_Amount: "0.00",
                    Linewise_Total_Amount: "0.00",
                    Section_GUID: "",
                    sec_isSelected: false,
                },
                Auto_Distribute_Users: {
                    AutoDist_Id: "",
                    DS_PROJDISTUSERS: "",
                    DS_FORMACTIONS: "",
                    isEditable: "1",
                    dist_isSelected: false,
                    ActionDue_Group: {
                        DS_ACTIONDUEDATE: "",
                        DS_DUEDAYS: ""
                    }
                },
                Damages_Section :{
                    Dam_Section_Detail: "",
                    Dam_Section_Code: "",
                    Dam_Section_Name: "",
                    Dam_Activity_Code:"",
                    Dam_Activity_Name:"",
                    Damage_Amount: "",
                    Damage_GUID: ""
                        },
                DSI_Formsetting:{
                    DSI_Setting_name: "",
                    DSI_Original_value: "",
                    DSI_Expected_value: ""
                }
            };
            $scope.tableUtilSettings = {
                Distribution_Section: {
                    tooltip: "Select to Edit data",
                    hasDefaultRecord: false,
                    editRowCallBack: editworkDonetoDate,
                    hideControlIcon: {
                        insertBefore : 0,
                        deleteSelected: 0,
                        deleteAllRow: 0,
                        insertAfter : 0,
                    },
                    
                    deleteItemCallBack: deleteRowCallbackAppliedvalue,
                    checkboxModelKey: "sec_isSelected",
                    DELETE_ALL_CONFIRM_MSG: "Do you want to remove all sections?",
                    newStaticObject: angular.copy(STATIC_OBJ_DATA.Distribution_Section),
                    ADD_NEW_BEFORE_TIP: "Insert before section",
                    ADD_NEW_AFTER_TIP: "Insert after section",
                    deleteAllRowTooltip: "Remove all sections",
                    deleteCurrRowMsg: "Remove section",
                    deleteSelectedMsg: "Remove selected section"
                    
                },
                Damages_Section: {
                    tooltip: "Select to Edit/Remove/Remove all data",
                    hasDefaultRecord: false,
                    editRowCallBack: editDamageModal,
                    hideControlIcon: {
                        insertBefore: 0,
                        insertAfter: 0,
                        editRow : 0,
                    },
                    deleteItemCallBack: contractTotalOfdamageamount,
                    checkboxModelKey: "damsec_isSelected",
                    DELETE_ALL_CONFIRM_MSG: "Do you want to remove all sections?",
                    newStaticObject: angular.copy(STATIC_OBJ_DATA.Damages_Section),
                    ADD_NEW_BEFORE_TIP: "Insert before section",
                    ADD_NEW_AFTER_TIP: "Insert after section",
                    deleteAllRowTooltip: "Remove all sections",
                    deleteCurrRowMsg: "Remove section",
                    deleteSelectedMsg: "Remove selected section"
                    
                }
            };

            var NEC4_CONSTANT = {
                restrictedCharMsg: "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #",
                mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
                workDonetoDate : 'workDonetoDate',
                damagesection: 'damagesection',
                appforpayment:'Application for Payment (Monthly Submission)',
                finalappforpayment:'Final Application for Payment',
                appforpaymentfurtherwork:'Application of Payment for Further works',
                yymmdddateformate:'yy-mm-dd',
                draftstring:'Draft',
                sendstring:'Send'
            }
            $scope.openModal = function (viewId, rowData) { // rowData used when user edit row , rowData come from table.util component as param
                modelRowIndex = -1;

                switch (viewId) {
                    case NEC4_CONSTANT.damagesection:
                        if (rowData) {
                            modelRowIndex = rowData.index;
                            $scope.modalData = angular.copy(rowData.row);
                            $scope.setSectionName($scope.modalData, $scope.modalData['Dam_Section_Code'],"edit");
                        } else {
                            $scope.modalData = angular.copy(STATIC_OBJ_DATA.Damages_Section);
                        }
                        break;
                    }

                showModal(viewId)
            }
            ctrl.model = {
                modelId: "",
                update: updateRecord,
                hideModal: hideModal,
                showloader: false,
                readOnly: false,
                scrollTop: 0
            };

            function showModal(id) {
                var body = document.body;
                var docElement = document.documentElement;
                ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
                // show modal
                ctrl.model.modelId = id;

                $timeout(function(){
                    var focusElem = $element.find('[autofocus]');
                    focusElem[0] && focusElem[0].focus();
                })
            };
            function hideModal() {
                ctrl.model.modelId = '';

                $timeout(function(){
                    var scrollObj = document.body
                    if(scrollObj.scrollTop == 0){
                        scrollObj = document.documentElement;
                    } 
                    scrollObj.scrollTop = ctrl.model.scrollTop;
                },200)
            }
            function editworkDonetoDate(rowData) {
                $scope.openModal(NEC4_CONSTANT.workDonetoDate, rowData);
            }
            function editDamageModal(rowData) {
                $scope.openModal(NEC4_CONSTANT.damagesection, rowData);
            }
            function updateRecord() {
                var rowIndex = modelRowIndex,
                    newNode = angular.copy($scope.modalData);

                if (!validateModalForm(ctrl.model.modelId)) {
                    $window.alert(NEC4_CONSTANT.mandatoryValMsg);
                    return;
                }
                var backUpObject = "",
                    index = "",
                    isDuplicate = "";
                switch (ctrl.model.modelId) {
                    case NEC4_CONSTANT.damagesection:
                        backUpObject = angular.copy($scope.damagesectionGroup['Damages_Section']);
                        if (rowIndex > -1) {
                            $scope.damagesectionGroup['Damages_Section'][rowIndex] = newNode;
                        } else {
                            $scope.damagesectionGroup['Damages_Section'].push(newNode);
                        }
                        if (rowIndex > -1)
                            index = rowIndex;
                        else
                            index = $scope.damagesectionGroup.Damages_Section.length - 1;
                        isDuplicate = $scope.checkDuplicateValue({
                            key: 'Dam_Section_Code',
                            model: $scope.modalData,
                            index: index,
                            repetObj: $scope.damagesectionGroup.Damages_Section,
                            msg: 'Section Code'
                        });
                        if (!isDuplicate) {
                            $scope.damagesectionGroup['Damages_Section'] = angular.copy(backUpObject);
                            $scope.setSectionName($scope.modalData, $scope.modalData['Dam_Section_Code']);
                            return;
                        }
                        break;
                }
                $timeout(function () {
                    hideModal();
                })

            }
            function validateModalForm(modalId) {
                var mandatorySingleFieldArray = [];
                var validaFlag = true;
                switch (modalId) {
                    case NEC4_CONSTANT.workDonetoDate:
                        mandatorySingleFieldArray = ['Damage_Amount'];
                        break;
                    }

                validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

                function checkFieldValueInObject(objectData, keyArray) {
                    var strElem = "";
                    for (var index = 0; index < keyArray.length; index++) {
                        var element = keyArray[index];
                            strElem = objectData[element];
                        if (!strElem) {
                            return false;
                        }
                    }
                    return true;
                }
                return validaFlag;
            }

            /** Initialize db fields */

            $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
            $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
            $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
            $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
            $scope.afpDetails = $scope.formCustomFields["AFP_Details"];
            $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
            $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
            $scope.sectionGroup = $scope.afpDetails["Distribution_Section_Group"];
            $scope.damagesectionGroup = $scope.afpDetails["Damages_Section_Group"];
            $scope.paymentcertificate = $scope.oriMsgCustomFields['Payment_Certificate'];
            $scope.totalofdamage;
            
            var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
            var ds_asi_std_ecc4_nec_org_contract = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_ORG_CONTRACT');
            var ds_asi_std_ecc4_nec_emp_contract = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_EMP_CONTRACT');
            var ds_asi_std_ecc4_all_contract_team_members = $scope.getValueOfOnLoadData('DS_ASL_TSC4_ALL_CONTRACT_TEAM_MEMBERS');
            var ds_asi_std_ecc4_nec_get_afp_detail = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_GET_AFP_DETAIL');
            var ds_asi_get_currency_from_contract = $scope.getValueOfOnLoadData('DS_ASI_GET_CURRENCY_FROM_CONTRACT');
            var ds_asi_std_ecc4_nec_Pmtassessmentdate = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_PMTASSESSMENTDATE');
            var ds_asi_std_ecc4_Certificate_Key_Dates = $scope.getValueOfOnLoadData('DS_ASL_TSC4_Certificate_Key_Dates');
            var ds_asi_std_ecc4_nec_Check_afp = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_Check_AFP');
            var ds_incomplete_actions = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
            var ds_asi_std_ecc4_nec_contract = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_CONTRACT');
            $scope.ds_all_Status_Withcloseout = $scope.getValueOfOnLoadData('DS_ALL_STATUS_WithCloseout');
            var ds_asi_std_ecc4_nec_contract_activity_summary = $scope.getValueOfOnLoadData('DS_ASL_TSC4_NEC_CONTRACT_ACTIVITY_SUMMARY');
            $scope.ds_Asi_Get_All_Default_FormSettingDetails = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
            var ds_Asi_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            var ds_Workinguser_All_Roles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
            
            var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
            var strIsDraft = $scope.oriMsgFields.DS_ISDRAFT;
            var strisDraft_Res = $scope.oriMsgFields['DS_ISDRAFT_RES'];
            var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
            if (dsWorkingUserId[0]) {
                dsWorkingUserId = dsWorkingUserId[0].Value;
                dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
                dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
            }
            if(currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW" || currentViewName == "ORI_PRINT_VIEW_HTML" || currentViewName == "RES_PRINT_VIEW_HTML")
            {
                $scope.IsshowPM_title = false; 
                if (ds_Workinguser_All_Roles) {
                    if (ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-client draft for pm") != -1 || ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-project manager") != -1) {
                        $scope.IsshowPM_title = true;
                    }
                }
            }
            
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
                
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
                    if (currentViewName == "ORI_VIEW") 
                    {
                        if(strFormId == "" && strIsDraft == "NO")
                        {
                            $scope.damagesectionGroup['Damages_Section'] = [];
                        }
                        
                        //set flag true if workinguser is belongs to NEC-ECC-Client or NEC-ECC-Project Manager
                        if (ds_Workinguser_All_Roles) {
                            if (ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-client draft for pm") != -1 || ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-project manager") != -1) {
                                $scope.afpDetails.isPM = true;
                                
                            }
                        }
                        $scope.getServerTime(function (serverDate) {
                            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), NEC4_CONSTANT.yymmdddateformate);
                            $scope.afpDetails['Con_Comment_Date'] = $scope.formatDate(new Date($scope.todayDateDbFormat), NEC4_CONSTANT.yymmdddateformate);
                        });

                        
                        setContractlist();
                        buildSectionlist();
                        buildCertificatelist();
                        validateAFP();

                        if(strIsDraft == "YES")
                        {
                            $scope.paymentcertificate['Application_for_Payment_Type'] = "";
                            setblankandcleardata();
                        }
                        if($scope.afpDetails.isPM)
                        {
                            setOverallformstatus("Accepted # Accepted");
                            setPM_Contractorlist("Contractor");
                        }
                        else
                        {
                            setOverallformstatus("Open # Open");
                            setPM_Contractorlist("Project Manager");
                        }
                    }
                    if(currentViewName == "RES_VIEW")
                    {
                        $scope.getServerTime(function (serverDate) {
                            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), NEC4_CONSTANT.yymmdddateformate);
                            $scope.afpDetails['PM_Comment_Date'] = $scope.formatDate(new Date($scope.todayDateDbFormat), NEC4_CONSTANT.yymmdddateformate);
                        });
                        var dsprojuserrole = $scope.asiteSystemDataReadwrite['DS_PROJUSERS_ROLE'];
                        var dsoriginator = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ORIGINATOR'] == "" ? "" : $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ORIGINATOR'].split(',')[1].trim();
                        var dsworkinguser = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'] == "" ? "" : $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'].split(',')[1].trim();
                        
                        $scope.formCustomFields['Can_Reply'] = "YES";
                        $scope.formCustomFields['Can_Reply_Status'] = "0";

                        var isrequired = checkPendingAction(dsWorkingUserId);
                        if(strFormId != "" && strIsDraft != "YES" && dsprojuserrole !="")
                        {
                            if(isrequired == false || (dsoriginator == dsworkinguser))
                            {
                            $scope.formCustomFields['Can_Reply'] = "";
                            $scope.formCustomFields['Can_Reply_Status'] = "2";
                            }
                        }
                        setOverallformstatus("Accepted # Accepted");

                    }
                    if(strIsDraft == "YES" || strisDraft_Res == "YES")
                    {
                        var strchkPermission = strIsUserDraftOnly();

                        if (strchkPermission.toLowerCase() == "yes")
                        setSendPermission(NEC4_CONSTANT.draftstring);
                        else
                        setSendPermission(NEC4_CONSTANT.sendstring);

                    }
                    if(strIsDraft == "NO" && strisDraft_Res == "NO")
                    {
                        //update data
                        var strtot = $scope.afpDetails['Total_Amount'];
                        var struptodate = $scope.afpDetails['UptoDate_LessDamage_Amount'];
                        var strpending = $scope.afpDetails['Pending_Payment_Amount'];
                        
                        var fltuptodate = (parseFloat(struptodate) || 0) - (parseFloat(strtot) || 0);
                        var fltpending = (parseFloat(strpending) || 0) - (parseFloat(strtot) || 0);
                        $scope.afpDetails['UptoDate_LessDamage_Amount'] = fltuptodate.toFixed(2);
                        $scope.afpDetails['Pending_Payment_Amount'] = fltpending.toFixed(2);
                        calculateTax();
                    }
                    buildDamageSectionlist();
                }
                
                if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW") {
                    
                    var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
                    var urlObj = commonApi._.filter(ds_asi_std_ecc4_nec_contract, function (val) {
                        return val.Value.split('|')[0].trim() == strConAppid.trim();
                    });
                    if (urlObj.length) {
                        $scope.oriMsgCustomFields.Contract_URL = urlObj[0].URL;
                    }
                }

            //on load set dropdowns
            function setContractlist() {
                if($scope.afpDetails.isPM)
                {
                    if (ds_asi_std_ecc4_nec_emp_contract.length) {
                        var poiParam = {
                            arrayObject : ds_asi_std_ecc4_nec_emp_contract,
                            groupNameKey: "",
                            modelKey : "Value",
                            displayKey : "Name"
                        }
                        $scope.conData = commonApi.getItemSelectionList(poiParam);
                    }
                }
                else
                {
                    if (ds_asi_std_ecc4_nec_org_contract.length) {

                        var poiParam = {
                            arrayObject : ds_asi_std_ecc4_nec_org_contract,
                            groupNameKey: "",
                            modelKey : "Value",
                            displayKey : "Name"
                        }
                        $scope.conData = commonApi.getItemSelectionList(poiParam);
                    }
                }
            }
            //call sps on contract dropdown selection
            $scope.onContractchange = function (conVal,strafptype) {
                if (conVal) {
                    var strParam = conVal.split('|')[0].trim();
                    var form = {
                        "projectId": projectId,
                        "formId": formId,
                        "fields": "DS_ASL_TSC4_ALL_CONTRACT_TEAM_MEMBERS,DS_ASL_TSC4_NEC_GET_AFP_DETAIL,DS_ASI_GET_CURRENCY_FROM_CONTRACT,DS_ASL_TSC4_NEC_PMTASSESSMENTDATE,DS_ASL_TSC4_NEC_Check_AFP,DS_ASL_TSC4_NEC_CONTRACT_ACTIVITY_SUMMARY,DS_ASL_TSC4_Certificate_Key_Dates",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_ASL_TSC4_ALL_CONTRACT_TEAM_MEMBERS",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASL_TSC4_NEC_GET_AFP_DETAIL",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASL_TSC4_NEC_PMTASSESSMENTDATE",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASL_TSC4_NEC_Check_AFP",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASL_TSC4_NEC_CONTRACT_ACTIVITY_SUMMARY",
                                "fieldValue": strParam
                            },{
                                "fieldName": "DS_ASL_TSC4_Certificate_Key_Dates",
                                "fieldValue": strParam
                            }]
                        }
                    };
                    $scope.isDataLoaded = false;
                    $scope.getCallbackData(form).then(function (response) {
                        if (response.data) {
                            ds_asi_std_ecc4_all_contract_team_members = angular.fromJson(response.data['DS_ASL_TSC4_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
                            if($scope.afpDetails.isPM)
                            {setPM_Contractorlist("Contractor");}
                            else
                            {setPM_Contractorlist("Project Manager");}
                            
                            ds_asi_std_ecc4_nec_contract_activity_summary = angular.fromJson(response.data['DS_ASL_TSC4_NEC_CONTRACT_ACTIVITY_SUMMARY']).Items.Item;

                            ds_asi_std_ecc4_nec_get_afp_detail = angular.fromJson(response.data['DS_ASL_TSC4_NEC_GET_AFP_DETAIL']).Items.Item;
                            buildSectionlist();
                            buildDamageSectionlist();

                            ds_asi_get_currency_from_contract = angular.fromJson(response.data['DS_ASI_GET_CURRENCY_FROM_CONTRACT']).Items.Item;
                            if (ds_asi_get_currency_from_contract.length) {
                                $scope.afpDetails.Currency = ds_asi_get_currency_from_contract[0].Value2.trim();
                            }

                            ds_asi_std_ecc4_nec_Pmtassessmentdate = angular.fromJson(response.data['DS_ASL_TSC4_NEC_PMTASSESSMENTDATE']).Items.Item;
                            buildCertificatelist();
                            
                            ds_asi_std_ecc4_Certificate_Key_Dates = angular.fromJson(response.data['DS_ASL_TSC4_Certificate_Key_Dates']).Items.Item;
                            setassessmentdate(strafptype);

                            ds_asi_std_ecc4_nec_Check_afp = angular.fromJson(response.data['DS_ASL_TSC4_NEC_Check_AFP']).Items.Item;
                            validateAFP();

                            var chkPermission = strIsUserDraftOnly();
                            if (chkPermission.toLowerCase() == "yes")
                                setSendPermission(NEC4_CONSTANT.draftstring);
                            else
                                setSendPermission(NEC4_CONSTANT.sendstring);

                            $scope.isDataLoaded = true;
                        }
                    });

                    //set logo and link
                    var arrStr = conVal.split('|');
                    $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                    if($scope.afpDetails.isPM)
                    {
                        $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                        $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                        $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();
                    }
                    else
                    {
                        $scope.oriMsgCustomFields.Contract_Code = arrStr[3].trim();
                        $scope.formCustomFields.Client_Logo = arrStr[5].trim();
                        $scope.formCustomFields.Contractor_Logo = arrStr[4].trim();
                    }

                    //set ContractAppbuilder ID in formcontent data
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT'] = angular.copy(strParam);

                    //set distnodes
                    
                    if (ds_asi_std_ecc4_nec_contract.length) {
                        var notesObj = commonApi._.filter(ds_asi_std_ecc4_nec_contract, function (val) {
                            return val.Value.split('|')[0].trim() == arrStr[0].trim();
                        });
                        if (notesObj.length) {
                            var strValue = notesObj[0].Name,
                                strNotes = strValue.split('|')[3].trim()
                            if (strNotes)
                                $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                        }
                    }
                }
            }

            //set project manager list dropdown
            function setPM_Contractorlist(strrole) {
                if (ds_asi_std_ecc4_all_contract_team_members.length) {
                    var lstpm = commonApi._.filter(ds_asi_std_ecc4_all_contract_team_members, function (val) {
                        return val.Value.split('|')[1].trim() == strrole; //'Project Manager';
                    });
                    $scope.objPM = [];
                    for (var i = 0; i < lstpm.length; i++) {
                        $scope.objPM.push({
                            optlabel: "",
                            options: [{
                                displayValue: lstpm[i].Name,
                                modelValue: lstpm[i].Value,
                                checked: false
                            }]
                        });
                    }
                }
            }

            //calculation of damage amount
            $scope.contractTotalOfdamageamount = contractTotalOfdamageamount;
            function contractTotalOfdamageamount() {
                $timeout(function () {
                    $scope.calcFieldTotal({
                        repData: $scope.damagesectionGroup['Damages_Section'],
                        calcKey: 'Damage_Amount',
                        parObject: $scope.afpDetails,
                        totalKey: 'Dam_Total_Amount'
                    });
                    calculateData("Damage");
                }, 200)
            }

            //calculation of Applied value
            function contractTotalOfAppliedValue(strcalckey,strtotalkey) {
                $scope.calcFieldTotal({
                    repData: $scope.sectionGroup['Distribution_Section'],
                    calcKey: strcalckey, 
                    parObject: $scope.afpDetails,
                    totalKey: strtotalkey 
                });
            }
            
            //calculation of Applied value
            function deleteRowCallbackAppliedvalue (strcalckey,strtotalkey) {
                $timeout(function () {
                    contractTotalOfAppliedValue(strcalckey,strtotalkey)
                }, 200)
            }

            $scope.calcFieldTotal = function (paramObject) {
                var repData = paramObject.repData;
                var calcKey = paramObject.calcKey;
                var parObject = paramObject.parObject;
                var totalKey = paramObject.totalKey;

                var tempTotal = 0;
                for (var index = 0; index < repData.length; index++) {
                    var element = repData[index][calcKey];
                    tempTotal += (parseFloat(element) || 0);
                }
                parObject[totalKey] = angular.copy(tempTotal.toFixed(2));
                $scope.totalofdamage = tempTotal; 
            }

            // set assessment date
            $scope.setassessmentdate = setassessmentdate
            function setassessmentdate (strafptype){
                $scope.afpDetails['isFinal_AFPlate'] = false;
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = strafptype;
                var ccdate = "";
                if (ds_asi_std_ecc4_Certificate_Key_Dates && ds_asi_std_ecc4_Certificate_Key_Dates.length) {
                        ccdate = ds_asi_std_ecc4_Certificate_Key_Dates[0].Value1.trim();
                    }
                if (ds_asi_std_ecc4_nec_Pmtassessmentdate.length) {
                    var strvalue2 = "",strvalue3 = "",strvalue6 = "",strvalue10="",strvalue7="";
                    for (var i = 0; i < ds_asi_std_ecc4_nec_Pmtassessmentdate.length; i++) {
                        strvalue2 = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value2;
                        strvalue3 = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value3;
                        strvalue6 = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value6;
                        strvalue10 = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value10;
                        strvalue7 = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value7;
                        }
                    }

                    if(strafptype == NEC4_CONSTANT.appforpayment)
                    {
                        var strassessdate = "";
                        if(strvalue3 == "")
                        {
                            $scope.paymentcertificate["Final_Submission"]["Assess_Date"] = strvalue2 && $scope.formatDate(new Date(strvalue2), NEC4_CONSTANT.yymmdddateformate);
                            strassessdate = strvalue2;
                        }
                        else
                        {
                            $scope.paymentcertificate["Final_Submission"]["Assess_Date"] = strvalue6 && $scope.formatDate(new Date(strvalue6), NEC4_CONSTANT.yymmdddateformate);
                            strassessdate = strvalue6;
                        }

                        $scope.paymentcertificate['Monthly_Submission']['App_Issue_Date'] = $scope.formatDate(new Date($scope.todayDateDbFormat),NEC4_CONSTANT.yymmdddateformate);
                        $scope.paymentcertificate['Monthly_Submission']['Certificate_of_Payment_Due_Date'] = strassessdate && $scope.formatDate(new Date(addDaysInDate(strassessdate,'14')),NEC4_CONSTANT.yymmdddateformate);
                    }
                    else if(strafptype == NEC4_CONSTANT.finalappforpayment)
                    {
                        
                    $scope.paymentcertificate["Final_Submission"]["Assess_Date"] = ccdate && $scope.formatDate(new Date(addDaysInDate(ccdate,'84')), NEC4_CONSTANT.yymmdddateformate);
                    $scope.paymentcertificate["Final_Submission"]["Final_App_Issue_Due_Date"] = ccdate && $scope.formatDate(new Date(addDaysInDate(ccdate,'84')), NEC4_CONSTANT.yymmdddateformate);
                    $scope.paymentcertificate['Final_Submission']['Completion_Issue'] = ccdate && $scope.formatDate(new Date(ccdate),NEC4_CONSTANT.yymmdddateformate);
                        if(ccdate != "")
                        {
                            var strDatediff = "",strdays="";
                            var strtodaydate = $scope.parseDate("yy-mm-dd", $scope.todayDateDbFormat);
                            ccdate = $scope.parseDate("yy-mm-dd", ccdate);
                            strDatediff = strtodaydate - ccdate;
                            strdays =  Math.ceil(strDatediff /(1000 * 60 * 60 * 24));
                            if(strdays > 28)
                            {
                                alert("Final Application for payment was submitted late");
                                $scope.afpDetails['isFinal_AFPlate'] = true;
                            }
                        }
                    }
                    else if(strafptype == NEC4_CONSTANT.appforpaymentfurtherwork)
                    {
                        $scope.paymentcertificate["Monthly_Submission"]["Certificate_of_Payment_Due_Date"] = $scope.formatDate(new Date(addDaysInDate($scope.todayDateDbFormat,'28')), NEC4_CONSTANT.yymmdddateformate);
                    }
                }

            //verify CONTR Value
            function verifyCONTR()
            {
                //if CONT does not contain cost then remove it from list
                var fltactivityvalue=0,fltimplementedcost=0,fltfinalcontrcost=0;
                if (ds_asi_std_ecc4_nec_contract_activity_summary && ds_asi_std_ecc4_nec_contract_activity_summary.length) {
                    var lstvalue = commonApi._.filter(ds_asi_std_ecc4_nec_contract_activity_summary, function (val) {
                            return val.Value3 == "CONTR";
                    });
                    for (var i = 0; i < lstvalue.length; i++) {
                        if (lstvalue[i].Value3 == "CONTR")
                        {
                            fltactivityvalue = fltactivityvalue +  (parseFloat(lstvalue[i].Value7.trim()) || 0);
                            fltimplementedcost = fltimplementedcost + (parseFloat(lstvalue[i].Value8.trim()) || 0);
                        }
                    }
                    fltfinalcontrcost = fltactivityvalue + fltimplementedcost;
                }
                return fltfinalcontrcost;
            }
            //set section name and activity descriptionand guid in pop up
            function buildSectionlist() {
                var isCONTval = verifyCONTR();
                //set default section
                $scope.sectionGroup["Distribution_Section"] = [];
                var objsection ;
                var guid = "",tempTotal = 0;
                var lstvalue;
                if(isCONTval == 0)
                {
                    if (ds_asi_std_ecc4_nec_get_afp_detail.length) {
                        lstvalue = commonApi._.filter(ds_asi_std_ecc4_nec_get_afp_detail, function (val) {
                                return val.Value1 != "CONTR";
                        });}
                }
                else
                {
                    if (ds_asi_std_ecc4_nec_get_afp_detail.length) 
                    {lstvalue = ds_asi_std_ecc4_nec_get_afp_detail;}
                }
            
                if (lstvalue != null && lstvalue.length) {
                    var strCode = "",strname = "",strCumulative = "",previousafpAmountdue;
                    for (var i = 0; i < lstvalue.length; i++) {
                        objsection = angular.copy(STATIC_OBJ_DATA.Distribution_Section );
                        strCode = lstvalue[i].Value1;
                        strname = lstvalue[i].Value2;
                        strCumulative = lstvalue[i].Value5;
                        if(strCode != "")
                        {
                            guid = commonApi.guId();
                            objsection.Dist_Section_Code = strCode; 
                            objsection.Dist_Section_Name = strname;
                            objsection.Cumulative_Amount = strCumulative;
                            objsection.Linewise_Total_Amount = strCumulative;
                            objsection.Section_GUID = guid;
                            tempTotal += (parseFloat(strCumulative) || 0);

                            $scope.sectionGroup["Distribution_Section"].push(objsection);
                        }
                        previousafpAmountdue = parseFloat(lstvalue[i].Value7 || 0);
                        $scope.afpDetails['Previous_Amount_Due'] = previousafpAmountdue.toFixed(2).toString();
                    }
                    $scope.afpDetails['Cumulative_Total_Amount'] = angular.copy(tempTotal.toFixed(2).toString());
                    $scope.afpDetails['Grand_Total_Amount'] = angular.copy(tempTotal.toFixed(2).toString());
                   
                }
            }
            function buildDamageSectionlist() {
                var isCONTval = verifyCONTR();
                var lstvalue;
                if(isCONTval == 0)
                {
                    if (ds_asi_std_ecc4_nec_get_afp_detail.length) {
                        lstvalue = commonApi._.filter(ds_asi_std_ecc4_nec_get_afp_detail, function (val) {
                                return val.Value1 != "CONTR";
                        });}
                }
                else
                {
                    if (ds_asi_std_ecc4_nec_get_afp_detail.length) 
                    {lstvalue = ds_asi_std_ecc4_nec_get_afp_detail;}
                }

                if (lstvalue != null && lstvalue.length) {
                    $scope.objSectionCode = [];
                    var unique = [],
                        strCode = "",strname="";
                    for (var i = 0; i < lstvalue.length; i++) {
                        strCode = lstvalue[i].Value1;
                        strname = lstvalue[i].Value2;
                        if (unique.indexOf(strCode) > -1)
                            continue;
                        else
                            unique.push(strCode);
                        $scope.objSectionCode.push({
                            optlabel: "",
                            options: [{
                                displayValue: strCode + "|" + strname,
                                modelValue: strCode + "|" + strname,
                                checked: false
                            }]
                        });
                    }
                }
            }
        

            $scope.setSectionName = function (currObj, strindex) {
                var strVal = currObj.Dam_Section_Detail;
                if(strVal != "")
                {
                    $timeout(function () {
                    var rowIndex = strindex;
                    var index = "";
                            if (rowIndex > -1)
                                index = rowIndex;
                            else
                                index = $scope.damagesectionGroup.Damages_Section.length - 1;
                            
                                var boolDuplicateFlag =  $scope.checkDuplicateValue({
                                key: 'Dam_Section_Detail',
                                model: currObj,
                                index: index,
                                repetObj: $scope.damagesectionGroup.Damages_Section,
                                msg: 'Section Code'
                            });
                            if (!boolDuplicateFlag) {
                                buildDamageSectionlist();
                            }
                            var strSecname = commonApi._.filter(ds_asi_std_ecc4_nec_get_afp_detail, function (val) {
                                return val.Value1 == strVal.split('|')[0].trim()
                            });
                            if (strSecname.length) {
                                currObj.Dam_Section_Code = strSecname[0].Value1.trim();
                                currObj.Dam_Section_Name = strSecname[0].Value2.trim();
                            }
                            var guid = "",sectionGUID="";
                            sectionGUID = currObj.Damage_GUID;
                            if(sectionGUID == "")
                            {
                                guid = commonApi.guId();
                                currObj.Damage_GUID = angular.copy(guid);
                            }
                    })
                }
            }

            function setblankandcleardata()
            {
                //set 0 to total
                $scope.afpDetails["Approved_Total_Amount"] = "0.00"
                $scope.afpDetails["Total_Amount"] = "0.00";
                var strTotcum = $scope.afpDetails["Cumulative_Total_Amount"];
                $scope.afpDetails["Grand_Total_Amount"] = strTotcum;
                
                //damage deduction
                calculateData("Yes");
            }
            $scope.setApproveddata = function (currObj) {
                if (currentViewName == "ORI_VIEW") 
                {
                    if(currObj != null)
                    {
                        var strAppliedVal = "",strprevious="",strTotApplied="",strTotcum="",fltLinewise="0.00",fltTotLinewise="0.00",fltFinalvalue;

                        //get applied and cumulative value and sum of both value
                        if($scope.afpDetails.isPM)
                        {strAppliedVal = currObj.Approved_Amount;}
                        else
                        {strAppliedVal = 0;}
                        strprevious = currObj.Cumulative_Amount;
                        fltLinewise = (parseFloat(strAppliedVal) || 0) + (parseFloat(strprevious) || 0);
                        currObj.Linewise_Total_Amount = fltLinewise.toFixed(2).toString();

                        //sum of total applied/approved value and total cumulative value set in grand total value
                        if($scope.afpDetails.isPM)
                        {
                            contractTotalOfAppliedValue('Approved_Amount','Approved_Total_Amount');
                            strTotApplied = $scope.afpDetails["Approved_Total_Amount"];
                        }
                        else 
                        {
                            contractTotalOfAppliedValue('Applied_Amount','Total_Amount');
                            strTotApplied = 0;
                        }
                        
                        strTotcum = $scope.afpDetails["Cumulative_Total_Amount"];
                        fltTotLinewise = (parseFloat(strTotApplied) || 0) + (parseFloat(strTotcum) || 0);
                        $scope.afpDetails["Grand_Total_Amount"] = angular.copy(fltTotLinewise.toFixed(2).toString());

                        //damage deduction
                        calculateData("Yes");

                        //set default close out status "accepted" if PM is working user
                        if($scope.afpDetails.isPM)
                        {
                            setOverallformstatus("Accepted # Accepted");
                        }
                        else
                        {
                            setOverallformstatus("Open # Open");
                        }
                    }
                }
                else if(currentViewName == "RES_VIEW")
                {
                    var strApprovedVal = "",strprevious="",strTotApproved="",strTotcum="",fltLinewise="0.00",fltTotLinewise="0.00";

                    //sum of Approved total value and cumulative value stored in linewise and also update grand total value
                    contractTotalOfAppliedValue('Approved_Amount','Approved_Total_Amount');
                    strApprovedVal = currObj.Approved_Amount;
                    strprevious = currObj.Cumulative_Amount;
                    fltLinewise = (parseFloat(strApprovedVal) || 0) + (parseFloat(strprevious) || 0);
                    currObj.Linewise_Total_Amount = fltLinewise.toFixed(2).toString();

                    strTotApproved = $scope.afpDetails["Approved_Total_Amount"];
                    strTotcum = $scope.afpDetails["Cumulative_Total_Amount"];
                    fltTotLinewise = (parseFloat(strTotApproved) || 0) + (parseFloat(strTotcum) || 0);
                    $scope.afpDetails["Grand_Total_Amount"] = angular.copy(fltTotLinewise.toFixed(2).toString());

                    //damage deduction
                    calculateData("Yes");

                    //set status always accepted
                    setOverallformstatus("Accepted # Accepted");
                }
            }
            
            //final calculation
            $scope.calculateData = function (strval)
            {
                calculateData(strval);
            }

            function calculateData(strval) {
                if(strval != "")
                {
                    var strdamtotamount="",strnoaccepted="",strRequire="",strdamOther="",
                    strtilldateamount="",flttotaldeductdamage,fltDamTotal,strprevious="",fltsubtotal,strTax,fltFinalamount,strAFP_type="",strotheramount = "";
                    
                    //check for other amount
                    strAFP_type = $scope.paymentcertificate['Application_for_Payment_Type'];
                    if(strAFP_type == NEC4_CONSTANT.finalappforpayment)
                    {
                        strotheramount = $scope.afpDetails['Other_Amount'];
                    }
                    //calculate amount due
                    if(currentViewName == "RES_VIEW")
                    {
                    strtilldateamount = $scope.afpDetails['Grand_Total_Amount'];
                    strtilldateamount =  (parseFloat(strtilldateamount) || 0) + (parseFloat(strotheramount) || 0);
                    strtilldateamount = strtilldateamount.toFixed(2);
                    }
                    else if((currentViewName == "ORI_VIEW"))
                    {
                        if($scope.afpDetails.isPM)
                        {
                            strtilldateamount = $scope.afpDetails['Grand_Total_Amount'];
                            strtilldateamount =  (parseFloat(strtilldateamount) || 0) + (parseFloat(strotheramount) || 0);
                            strtilldateamount = strtilldateamount.toFixed(2);
                        }
                        else
                        {
                            var strcum , strtot;
                            strtot = $scope.afpDetails['Total_Amount'];
                            strcum = $scope.afpDetails['Cumulative_Total_Amount'];
                            strtilldateamount =  (parseFloat(strtot) || 0) + (parseFloat(strcum) || 0) +(parseFloat(strotheramount) || 0);
                            strtilldateamount = strtilldateamount.toFixed(2);
                        }

                    }

                    if(strval == "Damage")
                    {
                        strdamtotamount = $scope.totalofdamage;    
                    }
                    else
                    {
                        strdamtotamount = $scope.afpDetails['Dam_Total_Amount'];
                    }
                    strnoaccepted = $scope.afpDetails['No_Accepted_Prog_Amount'];
                    strRequire = $scope.afpDetails['No_Req_Data_Provide_Amount'];
                    strdamOther = $scope.afpDetails['Dam_Other_Amount'];
                    fltDamTotal = (parseFloat(strdamtotamount) || 0)+ (parseFloat(strnoaccepted) || 0) + (parseFloat(strRequire) || 0) + (parseFloat(strdamOther) || 0);
                    flttotaldeductdamage = (parseFloat(strtilldateamount) || 0) - fltDamTotal;
                    $scope.afpDetails['UptoDate_LessDamage_Amount'] = angular.copy(flttotaldeductdamage.toFixed(2).toString());

                    //calculate sub total amount
                    strprevious = $scope.afpDetails['Previous_Amount_Due'];
                    fltsubtotal = flttotaldeductdamage - (parseFloat(strprevious) || 0);
                    $scope.afpDetails['Pending_Payment_Amount'] = angular.copy(fltsubtotal.toFixed(2).toString());

                    //Tax amount
                    calculateTax();
                }
            }

            function calculateTax () {
                    var strtxt = commonApi._.filter(ds_Asi_Configurable_Attributes, function (val) {
                        return val.Value3.indexOf('Tax') != -1 && val.Value11.indexOf('Active') != -1 && val.Value7.indexOf('Tax') != -1;
                    });
                    var strsubtotal="",fltFinalTotal,flttax = 0,fltpendingamount,flttaxamount;
                    if(strtxt.length)
                    {
                        flttax = (parseFloat(strtxt[0].Value8.trim()) || 0)
                    }
                    if(flttax > 0)
                    {
                        strsubtotal = $scope.afpDetails['Pending_Payment_Amount'];
                        fltpendingamount = (parseFloat(strsubtotal) || 0);
                        flttaxamount = (fltpendingamount * flttax)/100;
                        fltFinalTotal = fltpendingamount + flttaxamount;
                        $scope.afpDetails['Tax_Amount'] = angular.copy(flttaxamount.toFixed(2).toString());
                        $scope.afpDetails['Change_Amount_Due'] = angular.copy(fltFinalTotal.toFixed(2).toString());
                    }
                    else
                    {
                        strsubtotal = $scope.afpDetails['Pending_Payment_Amount'];
                        $scope.afpDetails['Tax_Amount'] = "0";
                        $scope.afpDetails['Change_Amount_Due'] = strsubtotal.toFixed(2);
                    }
            }
            function setAutoDistribution(strUser, strAction, strDueDate, iAutodistId,strDueDays) {
                if (strDueDate) {
                    strDueDate = $scope.formatDate(new Date(strDueDate), NEC4_CONSTANT.yymmdddateformate);
                }
                
                //get copy of distribution and set user ,date ,action to distribute
                var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
                structDistribution.AutoDist_Id = iAutodistId;
                structDistribution.DS_PROJDISTUSERS = strUser;
                structDistribution.DS_FORMACTIONS = strAction;
                structDistribution.ActionDue_Group['DS_ACTIONDUEDATE'] = strDueDate;
                structDistribution.ActionDue_Group['DS_DUEDAYS'] = strDueDays;

                $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push(structDistribution);
            }
           

            function setOverallformstatus(strVal){
                var strstatus = "";
                if(strVal != "")
                {
                    strstatus = strVal.split("#")[0].trim();
                    var strFormStatusId = getFormStatusId(strstatus);
                        if (strFormStatusId) {
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
                        
                    }
                }          
            }
            function getFormStatusId(strStatus) {
                //get status according pass parameter          
                if (ds_all_Active_Form_Status && ds_all_Active_Form_Status.length) {
                    var statudObj = commonApi._.filter(ds_all_Active_Form_Status, function (val) {
                        return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                    });
                    if (statudObj.length) {
                        return statudObj[0].Value;
                    }
                }
                return "";
            }
            
            /* This function accepts date and days[Number], 
            *  which return new date with add days in passed date
            *  @param:date[string]
            *  @param:days[number]
            *  @return:newDate[string] with standard db formar yyyy-MM-dd
            **/
        function addDaysInDate(date, days) {
            var newDate = "";

            if (date) {
                var tmpDays = parseInt(days) || 0;
                var d = new Date(date);
                d.setDate(d.getDate() + tmpDays);
                var month = d.getMonth() + 1;
                var day = d.getDate();
                newDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;

            }
                
            return newDate;
        }
        
        $scope.addNewItem = function (repeatingData, objKeyName ) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName] );
            repeatingData.push(newRowObject);

            $timeout(function(){
                var bodypartObj = document.getElementById('tbl_'+objKeyName);

                if(bodypartObj){
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });
            $scope.expandTextAreaOnLoad();
        };

        //check pending action
        function checkPendingAction(strUser) {
                //check user have any pending action or not
                var IsAction = false;
                ds_incomplete_actions = commonApi._.filter(ds_incomplete_actions, function (val) {
                    return val.Value4 == "Assign Status" || val.Value4 == "For Action" || val.Value4 == "Respond" || val.Value4 == "Review Draft";
                });
                if (ds_incomplete_actions) {
                    var strUserId = ds_incomplete_actions[0] && ds_incomplete_actions[0].Value1;
                    if (strUserId) {
                        if (strUserId && strUserId == strUser.trim()) {
                            return true;
                        }
                    }
                }
                return IsAction;
            }
            function strIsUserDraftOnly() {
                if (ds_asi_std_ecc4_all_contract_team_members.length) {
                    var strValue = "",
                        strRole = "",
                        strTmpEmpId = "";
                    for (var i = 0; i < ds_asi_std_ecc4_all_contract_team_members.length; i++) {
                        strValue = ds_asi_std_ecc4_all_contract_team_members[i].Value.split('|');
                        strRole = strValue[1].trim();
                        if (strRole.toLowerCase() == "draft only") {
                            strTmpEmpId = strValue[2].split('#')[0].trim();
                            if (strTmpEmpId == dsWorkingUserId)
                                return "Yes";
                        }
                    }
                }
                return "No";
            }
            function setSendPermission(strVal) {
                
                if (strVal.toLowerCase() == "draft") {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG  = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
                }
            }
                function buildCertificatelist() {
                    
                    if (ds_asi_std_ecc4_nec_Pmtassessmentdate.length) {
                        $scope.objCertificate = [];
                        var strCertificate = "";
                        for (var i = 0; i < ds_asi_std_ecc4_nec_Pmtassessmentdate.length; i++) {
                            strCertificate = ds_asi_std_ecc4_nec_Pmtassessmentdate[i].Value8;
                            $scope.objCertificate.push({
                                optlabel: "",
                                options: [{
                                    displayValue: strCertificate,
                                    modelValue: strCertificate,
                                    checked: false
                                }]
                            });
                        }
                    }
                }
                
                function validateAFP()
                {
                    $scope.strfinalafp;
                    $scope.strafp;
                    if (ds_asi_std_ecc4_nec_Check_afp.length) {
                        for (var i = 0; i < ds_asi_std_ecc4_nec_Check_afp.length; i++) {
                            $scope.strafp = ds_asi_std_ecc4_nec_Check_afp[i].Value1;
                            $scope.strfinalafp = ds_asi_std_ecc4_nec_Check_afp[i].Value2;
                        }
                        if($scope.strafp == "YES")
                        {
                            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| Previous AFP is not Accepted so You can not create new application for payment";

                            hidesavedraftbutton();
                        }
                    }
                }
                
                function validateAFPCalculation()
                {
                    var stractivity_value,strTotal_Additions,fltactivity_value = 0 ,fltTotal_additions = 0,fltTotalContractPrice = 0;
                    var strchangeamount = $scope.afpDetails["Approved_Total_Amount"];
                    var strrevisedamount = $scope.afpDetails["Cumulative_Total_Amount"];
                    if(strchangeamount <= 0)
                    {
                        return false;
                    }
                    else
                    {
                        $scope.validateafpfinalamount;
                        if (ds_asi_std_ecc4_nec_contract_activity_summary.length) {
                            for (var i = 0; i < ds_asi_std_ecc4_nec_contract_activity_summary.length; i++) {
                                stractivity_value = ds_asi_std_ecc4_nec_contract_activity_summary[i].Value7;
                                strTotal_Additions = ds_asi_std_ecc4_nec_contract_activity_summary[i].Value8;
                                fltactivity_value = fltactivity_value + (parseFloat(stractivity_value) || 0);
                                fltTotal_additions = fltTotal_additions + (parseFloat(strTotal_Additions) || 0);
                            }
                            fltTotalContractPrice = fltTotal_additions + fltactivity_value;
                        }
                        if(((parseFloat(strchangeamount) || 0)+(parseFloat(strrevisedamount) || 0)) > fltTotalContractPrice)
                        {
                            alert("Application for Payment amount should not be more than Contract's Target Price.");
                            return true;
                        }
                        else
                        {return false;}
                    }
                }

                //final callback
                $window.afpFinalCallBack = function () {
                    return $scope.validateBeforeFinalSubmission();
                }
                $scope.validateBeforeFinalSubmission = function () {

                    $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    if(currentViewName == "ORI_VIEW")
                    {
                        var strVal = $scope.oriMsgFields['DS_PROJUSERS_ROLE'];
                        if(strVal != "")
                        {
                            $scope.oriMsgFields.DS_AUTODISTRIBUTE = "3";
                            var struser = strVal.split('|')[2].trim();
                            var redays = $scope.oriMsgCustomFields.Reply_Due_Days;
                            var strdate = addDaysInDate($scope.todayDateDbFormat,redays);
                            var straction ="";
                            if($scope.afpDetails.isPM)
                            {straction = "7#";}
                            else
                            {straction = "3#Respond";}
                            setAutoDistribution(struser, straction, strdate, 1, "",redays); 
                        }
                    }

                    if (ds_Workinguser_All_Roles) {
                        if (ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-client draft for pm") != -1 || ds_Workinguser_All_Roles[0].Value.toLowerCase().indexOf("nec-ecc-project manager") != -1) {
                            var isvalidate = validateAFPCalculation();
                            if(isvalidate)
                            {return true;}
                            else
                            {return false;}
                        }
                    }
                    
                }
                function hidesavedraftbutton()
                {
                    var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                    $saveDraftBtn && ($saveDraftBtn.style.display = 'none'); 
                }
            //#region formsettings
            //form setting code
            function checkFormSetting() {
                /*====================================================================================================
                // check status is proper set or not
                ======================================================================================================*/
                var htStatus = [];
                htStatus.push(array("Deactivated", "Yes"));

                var strstatus = "Accepted:Yes";

                //update status string if it is passed in function as param (param name : strstatus)
            
                if (strstatus != "")
                {
                    if (strstatus.indexOf("$") > -1)
                    {
                        for (var i = 0; i < strstatus.split('$').length; i++)
                        {
                            var strkey = strstatus.split('$')[i].split(':')[0].toString().trim();
                            var strval = strstatus.split('$')[i].split(':')[1].toString().trim();
                            var index = commonApi._.findIndex(htStatus, { key: strkey });
                            if (index > -1) {
                                htStatus[strkey] = strval;
                            }
                            else
                            {
                                htStatus.push(array(strkey, strval));
                            }
                        }
                    }
                    else if (strstatus.indexOf(":") > -1)
                    {
                        var strkey = strstatus.split(':')[0].toString().trim();
                        var strval = strstatus.split(':')[1].toString().trim();
                        var index = commonApi._.findIndex(htStatus, { key: strkey });
                        if (index > -1) {
                            htStatus[strkey] = strval;
                        }
                        else
                        {
                            htStatus.push(array(strkey, strval));
                        }
                    }
                }
                var strstatusSettings = checkstatusonload(htStatus,strstatus);
                if (strstatusSettings != "") {
                    var strvalsetting ="";
                    for (var i = 0; i < $scope.ds_all_Status_Withcloseout.length; i++) {
                        var splitValue = $scope.ds_all_Status_Withcloseout[i].Value2;
                        if(splitValue != "")
                        {
                            if(splitValue.indexOf("|") > -1)
                            {
                                var strval1 = splitValue.split("|")[1].trim();
                                var strval2 = splitValue.split("|")[2].trim();
                            }
                            var strvalfinal = strval1 +":"+ strval2
                            strvalsetting = strvalsetting.concat(strvalfinal + ",");
                        }
                    }

                        $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following settings not stated properly";
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";
                        var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                        mainstrcutr.DSI_Setting_name = "Form status";
                        mainstrcutr.DSI_Original_value = strvalsetting;
                        mainstrcutr.DSI_Expected_value = strstatusSettings.replace("$",",");
                        $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                        
                        //if formsettings are not matched
                        $scope.flagIsformsetting = true;
                        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                        $saveDraftBtn && ($saveDraftBtn.style.display = 'none'); 
                }
                else
                {
                    $scope.flagIsformsetting = false;
                }
                /*====================================================================================================
                            //set and check other formsettings proper match or not
                ======================================================================================================*/

                var htMain = [
                    { key:"No_of_Form_Instances", value:"0"},
                    { key:"FormType", value:"Form Type"},
                    { key:"Form_Template_Type", value:"HTML AppBuilder"},
                    { key:"Response_Type", value:"Combined Response Will have Custom Print View"},
                    { key:"Appbuilder_Code", value:"ASI"},
                    { key:"Is_Import_Emailin", value:""},
                    { key:"Is_Import_Emailin_Exchange", value:"Not Selected"},
                    { key:"Exchange_Type", value:""},
                    { key:"E_catalogue", value:"Not Selected"},
                    { key:"Cross_Workspace", value:"No"},
                    { key:"Use_controller", value:"No"},
                    { key:"Controller_Change_status", value:"No"},
                    { key:"Response_allowed", value:"No"},
                    { key:"Responder_Collaborate", value:"No"},
                    { key:"Response_From", value:"Recipients Only"},
                    { key:"Continue_Discussion", value:"No"},
                    { key:"Enable_Draft_Responses", value:"No"},
                    { key:"Show_Responses", value:"Always"},
                    { key:"Allow_Editing_ORI", value:"No"},
                    { key:"Is_Import_Editing_ORI", value:"No"},
                    { key:"Action_Required", value:"For Information|0"},
                    { key:"default_Action_required", value:""},
                    { key:"Distribution_ORI_creation", value:"Mandatory"},
                    { key:"Allow_Distribution_after_creation", value:"Yes"},
                    { key:"Allow_All", value:"No"},
                    { key:"Allow_Originator", value:"Yes"},
                    { key:"Allow_Receipients", value:"Yes"},
                    { key:"Allow_Roles", value:"No"},
                    { key:"Role_Name", value:""},
                    { key:"Allow_Edit_and_Forward", value:"No"},
                    { key:"Allow_Attachments", value:"No"},
                    { key:"Automatic_publish_to_folder", value:"No"},
                    { key:"Allow_Form_Associations", value:"No"},
                    { key:"Associations_bypass_Form_security", value:"No"},
                    { key:"Allow_Doc_Association", value:"No"},
                    { key:"Default_Doc_Association", value:"Static"},
                    { key:"Associations_Extend_Document_Issue", value:"No"},
                    { key:"Allow_Comment_Associations", value:"No"},
                    { key:"Associations_bypass_folder_security", value:"No"},
                    { key:"Allow_Attribute_Associations", value:"No"},
                    { key:"Allow_View_Associations", value:"No"},
                    { key:"Overall_Form_Statuses", value:"No"},
                    { key:"status_list", value:""},
                    { key:"Closed_out_status_list", value:""},
                    { key:"Restrict_Status_Change_in_View_Form", value:"No"},
                    { key:"Allow_Reopening_Form", value:"Yes"},
                    { key:"Originator_can_Change_Status", value:"No"},
                    { key:"Is_public", value:"No"},
                    { key:"Use_Form_Distribution_Groups", value:"No"},
                    { key:"Allow_autocreation_on_status_change", value:"No"},
                    { key:"Enable_SpellCheck", value:"Not Selected"},
                    { key:"Allow_External_Access", value:"No"},
                    { key:"Embed_form_Content_emails", value:"No"},
                    { key:"Can_Reply_via_emails", value:"No"},
                    { key:"From_Actions_Notification_Email_Subject", value:""},
                    { key:"Is_Offline", value:"No"},
                    { key:"Embed_form_Content_in_instant_emails_Type", value:"Setting Off"},
                    { key:"Allow_Import_in_Edit_ORIValue", value:"Overwrite"},
                    { key:"Allow_Import_in_Edit_ORI", value:"No"},
                ];

                //main string 
                var strmain = "Appbuilder_Code:ASI-ECCIV-AFP$"+
                "Distribution_ORI_creation:Optional$"+
                "Response_allowed:Yes$"+
                "Responder_Collaborate:Yes$"+
                "Form_Group_Code:AFP$"+
                "Action_Required:For Action|3,For Information|0,Review Draft|3$"+
                "Overall_Form_Statuses:Yes$"+
                "Allow_External_Access:Yes$"+
                "Originator_can_Change_Status:Yes$"+
                "Embed_form_Content_emails:Yes$"+
                "Allow_Attachments:$"+
                "Automatic_publish_to_folder:$"+
                "Allow_Form_Associations:$"+
                "Associations_bypass_Form_security:$"+
                "Allow_Doc_Association:$"+
                "Default_Doc_Association:$"+
                "Associations_Extend_Document_Issue:$"+
                "Allow_Comment_Associations:$"+
                "Associations_bypass_folder_security:$"+
                "Enable_Draft_Responses:Yes$"+        
                "Embed_form_Content_in_instant_emails_Type:External User Only$"+
                "Use_Form_Distribution_Groups:Yes";

                if (strmain != "") {
                    if (strmain.indexOf('$') > -1) {
                        for (var i = 0; i < strmain.split('$').length; i++) {
                            var strkey = strmain.split('$')[i].split(':')[0].toString().trim();
                            var strval = strmain.split('$')[i].split(':')[1].toString().trim();
                            var index = commonApi._.findIndex(htMain, { key: strkey });
                            if (index > -1) {
                                htMain[index].value = strval;
                            }
                        }
                    }
                }
                var strSettings = checkmainstringonload(htMain);
                if (strSettings != "") {
                
                    $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following settings not stated properly";
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";
                    var arrStr = [];
                    if (strSettings.indexOf('&') > -1) {
                        arrStr = strSettings.split('&');
                        for (var i = 0; i < arrStr.length; i++) {
                            var item = arrStr[i].split(':');
                            var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                            mainstrcutr.DSI_Setting_name = item[0];
                            mainstrcutr.DSI_Original_value = item[2];
                            mainstrcutr.DSI_Expected_value = item[1];
                            $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                        }
                    }
                    else if (strSettings.indexOf(':') > -1) {
                        arrStr = strSettings.split(':');
                        var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                        mainstrcutr.DSI_Setting_name = arrStr[0];
                        mainstrcutr.DSI_Original_value = arrStr[2];
                        mainstrcutr.DSI_Expected_value = arrStr[1];
                        $scope.formCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                    }
                    //if formsettings are not matched
                    $scope.flagIsformsetting = true;
                    var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                    $saveDraftBtn && ($saveDraftBtn.style.display = 'none'); 
                    $scope.update();
                    return;
                }
                else
                {
                    $scope.flagIsformsetting = false;
                }
            }
            function array(key, value) {
                return { key: key, value: value };
            }
            function checkmainstringonload(htMain) {
                var sb = "";
                if ($scope.ds_Asi_Get_All_Default_FormSettingDetails != null) {
                    var temp = $scope.ds_Asi_Get_All_Default_FormSettingDetails[0];
                    for (var i = 1; i < 60; i++) {
                        var splitValue = [];
                        splitValue = temp["Value" + i.toString()];
                        if (splitValue.indexOf(':') > -1) {
                            var key = splitValue.split(':')[0].trim();
                            //var value = splitValue.split(':')[1].trim().replace(new RegExp("\s+"), " ");
                            var value = splitValue.split(':')[1].trim();

                            var ind = commonApi._.findIndex(htMain, { key: key });
                            if (ind > -1) {
                                if(htMain[ind].value.trim() != "")
                                { 
                                    if (htMain[ind].value.trim().indexOf(value.trim()) == -1) {
                                        if (sb == "") {
                                            var result = getDisplayName(splitValue.split(':')[0].trim()) + ":" + htMain[ind].value + ":" + splitValue.split(':')[1];
                                            sb = result;
                                        }
                                        else {
                                            var result1 = getDisplayName(splitValue.split(':')[0].trim()) + ":" + htMain[ind].value + ":" + splitValue.split(':')[1];
                                            sb = sb.concat("&" + result1);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return sb;
            };
            function  checkstatusonload(htStatus,strstatus) {
                var sb = "";
                var htStatusSp = [];

                //Check status of Form settings
                if ($scope.ds_all_Status_Withcloseout != null) {

                if (strstatus.trim() != "")
                {
                    for (var i = 0; i < $scope.ds_all_Status_Withcloseout.length; i++) {
                        var splitValue = $scope.ds_all_Status_Withcloseout[i].Value2;
                        if(splitValue.indexOf("|") > -1)
                        {
                            var key = splitValue.split('|')[1].trim();
                            var strrepstatus = splitValue.split('|')[2].trim();
                            var value = strrepstatus.replace(/\s\s+/g, ' ')//Regex.Replace(splitValue.split('|')[2].trim(), @"\s+", " ");

                            htStatusSp.push(array(key, value));
                        }
                    }
                    if (htStatus.length > 0)
                    {
                        for (var i = 0; i < htStatus.length; i++)
                        {
                            var key = htStatus[i].key.trim();   
                            var value = htStatus[i].value.trim();  
                            var ind = commonApi._.findIndex(htStatusSp, { key: key });
                            if(ind > -1)
                            {
                                if (htStatusSp[ind].value.trim().indexOf(value.trim()) == -1) 
                                {
                                    sb = strstatus;
                                }
                            }
                            else
                            {
                                sb = strstatus;
                            }
                        }
                    }
                }
            }   
                return sb;
            };
            function getDisplayName(keyparameter) {
                var Hashtable = [
                { key:"Form_Group_Code",value:"Form_Group_Code"},
                { key:"No_of_Form_Instances",value:"No_of_Form_Instances"},
                { key:"FormType",value:"FormType"},
                { key:"Form_Template_Type",value:"Form_Template_Type"},
                { key:"Response_Type",value:"Response_Type"},
                { key:"Appbuilder_Code",value:"Appbuilder_Code"},
                { key:"Is_Import_Emailin",value:"Is_Import_Emailin"},
                { key:"Is_Import_Emailin_Exchange",value:"Is_Import_Emailin_Exchange"},
                { key:"Exchange_Type",value:"Exchange_Type"},
                { key:"E_catalogue",value:"E_catalogue"},
                { key:"Cross_Workspace",value:"Cross_Workspace"},
                { key:"Use_controller",value:"Use_controller"},
                { key:"Controller_Change_status",value:"Controller_Change_status"},
                { key:"Response_allowed",value:"Response_allowed"},
                { key:"Responder_Collaborate",value:"Responder_Collaborate"},
                { key:"Response_From",value:"Response_From"},
                { key:"Continue_Discussion",value:"Continue_Discussion"},
                { key:"Enable_Draft_Responses",value:"Enable_Draft_Responses"},
                { key:"Show_Responses",value:"Show_Responses"},
                { key:"Allow_Editing_ORI",value:"Allow_Editing_ORI"},
                { key:"Is_Import_Editing_ORI",value:"Is_Import_Editing_ORI"},
                { key:"Action_Required",value:"Action_Required"},
                { key:"default_Action_required",value:"Default_Action_required"},
                { key:"Distribution_ORI_creation",value:"Distribution_ORI_creation"},
                { key:"Allow_Distribution_after_creation",value:"Allow_Distribution_after_creation"},
                { key:"Allow_All",value:"Allow_Distribution_after_creation_BY_All"},
                { key:"Allow_Originator",value:"Allow_Distribution_after_creation_BY_Originator"},
                { key:"Allow_Receipients",value:"Allow_Distribution_after_creation_BY_Receipients"},
                { key:"Allow_Roles",value:"Allow_Distribution_after_creation_BY_Roles"},
                { key:"Role_Name",value:"Allow_Distribution_after_creation_BY_Role_Role_Name"},
                { key:"Allow_Edit_and_Forward",value:"Allow_Edit_and_Forward"},
                { key:"Allow_Attachments",value:"Allow_Attachments"},
                { key:"Automatic_publish_to_folder",value:"Automatic_publish_to_folder"},
                { key:"Allow_Form_Associations",value:"Allow_Form_Associations"},
                { key:"Associations_bypass_Form_security",value:"Associations_bypass_Form_security"},
                { key:"Allow_Doc_Association",value:"Allow_Doc_Association"},
                { key:"Default_Doc_Association",value:"Default_Doc_Association"},
                { key:"Associations_Extend_Document_Issue",value:"Associations_Extend_Document_Issue"},
                { key:"Allow_Comment_Associations",value:"Allow_Comment_Associations"},
                { key:"Associations_bypass_folder_security",value:"Associations_bypass_folder_security"},
                { key:"Allow_Attribute_Associations",value:"Allow_Attribute_Associations"},
                { key:"Allow_View_Associations",value:"Allow_View_Associations"},
                { key:"Overall_Form_Statuses",value:"Overall_Form_Statuses"},
                { key:"status_list",value:"status_list"},
                { key:"Closed_out_status_list",value:"Closed_out_status_list"},
                { key:"Restrict_Status_Change_in_View_Form",value:"Restrict_Status_Change_in_View_Form"},
                { key:"Allow_Reopening_Form",value:"Allow_Reopening_Form"},
                { key:"Originator_can_Change_Status",value:"Originator_can_Change_Status"},
                { key:"Is_public",value:"Form_Is_public"},
                { key:"Use_Form_Distribution_Groups",value:"Use_Form_Distribution_Groups"},
                { key:"Allow_autocreation_on_status_change",value:"Allow_autocreation_on_status_change"},
                { key:"Enable_SpellCheck",value:"Enable_SpellCheck"},
                { key:"Allow_External_Access",value:"Allow_External_Access"},
                { key:"Embed_form_Content_emails",value:"Embed_form_Content_emails"},
                { key:"Can_Reply_via_emails",value:"Can_Reply_via_emails"},
                { key:"From_Actions_Notification_Email_Subject",value:"From_Actions_Notification_Email_Subject"},
                { key:"Is_Offline",value:"Is_Form_available_Offline"},
                { key:"Embed_form_Content_in_instant_emails_Type",value:"Embed_form_Content_in_instant_emails_Type"},
                { key:"Allow_Import_in_Edit_ORIValue",value:"Allow_Import_in_Edit_ORIValue"},
                { key:"Allow_Import_in_Edit_ORI",value:"Allow_Import_in_Edit_ORI"},
                ];
                var ind = commonApi._.findIndex(Hashtable, { key: keyparameter });
                return Hashtable[ind].key;
            }
            //#endregion
            $scope.update();

            $timeout(function(){
                $scope.expandTextAreaOnLoad();
            },100);
        }
        return FormController;
    });

    function customHTMLMethodBeforeCreate_ORI() {

        if (typeof afpFinalCallBack !== "undefined") {
            return afpFinalCallBack();
        }
    }

    function customHTMLMethodBeforeCreate_RES() {

        if (typeof afpFinalCallBack !== "undefined") {
            return afpFinalCallBack();
        }
    }