
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.stopAutoSaveDraftTimerFromClientSide();
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

       
        
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy", "nl_NL": "dd-M-yy" };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.strFormId = $scope.formdata5.DS_FORMID;
        $scope.strIsDraft = $scope.formdata5.DS_ISDRAFT;
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.SectionsGroup = $scope.oriMsgCustomFields["SectionsGroup"];
        $scope.DamageGroup = $scope.oriMsgCustomFields.Damages_Section_Group;
        var dsWorkingUserId = $scope.getWorkingUserId();
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_PAA_MPC_NEC_CPAF = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CPAF');
        var DS_PAA_MPC_NEC_AFP_Details = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_AFP_Details');
        var AFP_CONSTANT = {
            //To fill dropdown rolewise
            ewnWorkspaceUsers: 'Workspace - Administrator',
            Closed: 'Closed',
            Open: 'Open',
            forInformation: "7#For Information",
            oriDistNumb: 3,
        }

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            if($scope.strFormId == "" || $scope.strIsDraft == 'YES'){
                $scope.oriMsgCustomFields.Date_Of_Payment_Cert = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            }
        });

        $scope.isDataLoaded = true;
        var currentViewName = window.currentViewName;
        $scope.selectionlist = {
            ewnWorkspaceUserslist: [],
            setContractlist: [],
            afpList:[]
        }

        function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        $scope.onContractchange = onContractchange;
        function onContractchange(conVal, onloadFlag) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var tempConAppCode = conVal.split('|')[0].trim();
                var strAppcode = $scope.asiteSystemDataReadWrite.DS_FORM_APPBUILDERCODE;
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim();
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();

                setFormContent();

                var spParam = {
                    dataSourceArray: [
                        {
                            "fieldName": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_SETUP_SECTIONS",
                            "fieldValue": tempConAppCode + ',' + strAppcode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_ASITE_DM_USED",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_REASONCODE",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_Contract_Activity_Group_dtls",
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": "DS_PAA_MPC_NEC_CPAF",
                            "fieldValue": tempConAppCode
                        }
                    ],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if (!onloadFlag) {
                            if (response.DS_ASI_GET_CURRENCY_FROM_CONTRACT && response.DS_ASI_GET_CURRENCY_FROM_CONTRACT[0]) {
                                $scope.oriMsgCustomFields.Currency = response.DS_ASI_GET_CURRENCY_FROM_CONTRACT[0].Value2;
                            }
                        }
                        if (response["DS_PAA_MPC_NEC_CPAF"]) {
                            DS_PAA_MPC_NEC_CPAF = response["DS_PAA_MPC_NEC_CPAF"];
                            $scope.selectionlist.afpList = commonApi.getItemSelectionList({
                                arrayObject: DS_PAA_MPC_NEC_CPAF,
                                groupNameKey: "",
                                modelKey: "Value",
                                displayKey: "Name"
                            });
                        }
                        setUserList(response);
                       
                    }
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        if (currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields.Contract) {
            onContractchange($scope.oriMsgCustomFields.Contract, true);
        }

        initFormsData();
        function initFormsData() {
            if (currentViewName == "ORI_VIEW") {
                var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
                $scope.selectionlist.setContractlist = commonApi.getItemSelectionList({
                    arrayObject: contractData,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            }
            else {
                for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                    if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                        $scope.contractURL = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                        break;
                    }
                }
                $timeout(function() {
                    $scope.hideExportBtn()
                }, 100)
            }

           
            $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
            $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
            $scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;
        }

        function setUserList(response) {
            if (response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS) {
                var ownerUserList = commonApi._.filter(response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function (obj) {
                    return obj.Value && obj.Value.split('|')[1].toLowerCase().indexOf('alliance_management_team') > -1;
                });

                $scope.selectionlist.ewnWorkspaceUserslist = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(ownerUserList,function(obj){return obj.Name}),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            strFormContent = strConAppid +"|";
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }
        
        function setUserAction() {

            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            var userId = $scope.oriMsgCustomFields.EWNIssutoName;
            if (userId) {
                userId = userId && userId.split(' | ')[2];
                userId = userId && userId.split('#')[0];
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userId,
                        strAction: AFP_CONSTANT.forInformation,
                        strDate: "",
                        strDays: ""
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE:AFP_CONSTANT.oriDistNumb,
                });
            }
        }

        $scope.onAfpChange = function (strVal) {
            if (strVal) {
                var afpID = strVal.split('|')[2].trim() || "";
                $scope.formdata5.DS_FORMCONTENT1 = afpID;
                $scope.oriMsgCustomFields.AFP_Id = strVal.split('|')[3].trim() || ""
                var spParam = {
                    dataSourceArray: [
                        {
                            "fieldName": "DS_PAA_MPC_NEC_AFP_Details",
                            "fieldValue": afpID
                        }
                    ],
                    successCallback: function (response) {
                        if (response["DS_PAA_MPC_NEC_AFP_Details"]) {
                            var struptodate = 0, strOther = 0, dctotal = 0;
                            DS_PAA_MPC_NEC_AFP_Details = response["DS_PAA_MPC_NEC_AFP_Details"];
                            if (DS_PAA_MPC_NEC_AFP_Details.length) {
                                var element = DS_PAA_MPC_NEC_AFP_Details[0],
                                    struptodate = parseFloat(element.Value1) || 0,
                                    strOther = parseFloat(element.Value2) || 0;
                                dctotal = struptodate + strOther;
                                $scope.oriMsgCustomFields.UptoDate_Total_Amount = struptodate.toFixed(2);
                                $scope.oriMsgCustomFields.Other_Amount = strOther.toFixed(2);
                                $scope.oriMsgCustomFields.Uptodate_PlusOther_amount = dctotal.toFixed(2);
                                $scope.oriMsgCustomFields.AllDamages_Total_Amount = parseFloat(element.Value3).toFixed(2);
                                $scope.oriMsgCustomFields.UptoDate_LessDamage_Amount = parseFloat(element.Value4).toFixed(2);
                                $scope.oriMsgCustomFields.PreviousAfps_Total_Amount = parseFloat(element.Value5).toFixed(2);
                                $scope.oriMsgCustomFields.Pending_Payment_Amount = parseFloat(element.Value6).toFixed(2);
                                $scope.oriMsgCustomFields.Change_Amount_Due = parseFloat(element.Value7).toFixed(2);
                                $scope.oriMsgCustomFields.AFP_Details.Assess_date = $scope.formatDate(new Date(element.Value8), 'yy-mm-dd');

                            }
                        }
                    }
                };
                $scope.getCallbackSPdata(spParam);
            }
        }

        $window.paaAlcFinalCallBack = function () {
            if (currentViewName == "ORI_VIEW") {
                setUserAction();
                setFormStatus(AFP_CONSTANT.Closed);
                $scope.formdata5.Status_Data.DS_CLOSE_DUE_DATE = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.todayDateDbFormat,
                    days: 7
                });
            }
            setFormContent();
            return false;
        }

        $scope.update();

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof paaAlcFinalCallBack !== "undefined") {
        return paaAlcFinalCallBack();
    }
}