/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/inlineattachment'], function (angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $controller, $window, $timeout, commonApi, $filter) {

        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.resMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.RES_MSG_Custom_Fields;
        $scope.isRFQProcessCompleted = $scope.oriMsgCustomFields.isRFQProcessCompleted;
        $scope.isAuthToEnterFinalCost = $scope.oriMsgCustomFields.isAuthToEnterFinalCost;
        $scope.rfqDetails = $scope.oriMsgCustomFields.rfqDetails;
        $scope.CurrStage = $scope.oriMsgCustomFields.CurrStage;
        $scope.rfqSubmissionDetails = $scope.oriMsgCustomFields.rfqSubmissionDetails;
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.strIsDraft_Res = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES;
        $scope.strIsDraft_Res_Msg = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
        $scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
        $scope.isShowOtherFields = false;
        $scope.disableCostValue = false;
        $scope.TimeExtensioshow = false;
        $scope.hideCostValue = true;
        $scope.approveReject = $scope.resMsgCustomFields.appCurrentStatus || '';
        $scope.RecipientStructure = {
            Users_Organisation: "",
            Users_Recipient: ""
        };
        var isOriView = (currentViewName == "ORI_VIEW"),
            isOriPrintView = (currentViewName == "ORI_PRINT_VIEW"),
            isRespView = (currentViewName == 'RES_VIEW'),
            isRespPrintView = (currentViewName == 'RES_PRINT_VIEW'),

            STATIC_OBJ = {
                autocompleteMsgStructure: {
                    DS_MSG_AC_TYPE: "",
                    DS_MSG_AC_FORM: "",
                    DS_MSG_AC_MSG_TYPE: "",
                    DS_MSG_AC_USERID: "",
                    DS_MSG_AC_ACTION: "",
                    DS_MSG_AC_ACTION_REMARKS: ""
                },
                Attachfinaldocuments: {
                    attachedDocs: ""
                },
            },
            CONSTANTS_OBJ = {
                CLAIM_APP_LIST_KEY: 'claim-list',
                CLAIM_APP_LIST_LABEL: 'Raised Claim Reference list',
                MANAGER_DIRECTOR_USER_LIST_KEY: 'man-dir-list',
                MANAGER_DIRECTOR_USER_LIST_LABEL: 'Manager and Director Users list',
                COMM_TEAM_USER_LIST_KEY: 'comm-team-user-list',
                COMM_TEAM_USER_LIST_LABEL: 'Commercial Team Users list',
                SUPPLY_CHAIN_USER_LIST_KEY: 'supply-chain-user-list',
                SUPPLY_CHAIN_USER_LIST_LABEL: 'Supply Chain Users',
                SupplyChain: 'supply chain',
                CLIENT_LIST_KEY: 'client-list',
                CLIENT_LIST_LABEL: 'Client List',
                On_Hold: 'On Hold',
                Closed: 'closed',
                Submit_Cost: 'Submit Cost',
                Payment_Authorised: 'Payment Authorised',
                For_Governance: 'for governance',
                In_Pricing: 'In Pricing',
                In_Review: 'In Review',
                Approved: 'Approved',
                Rejected: 'Rejected',
                Revise_and_Resubmit: 'Revise and Resubmit',
                Moreinfo_Reqired: 'More Information Required',
                Sent_For_Approval: 'Sent For Approval',
                For_Client_Approval: 'For Client Approval',
                Client_Rejected: 'Client Rejected',
                Client_Approved: 'Client Approved',
                Works_Instructed: 'Works Instructed',
                Payment_Rejected: 'Payment Rejected',
                Works_Completed: 'Works Completed',
                Works_Rejected: 'Works Rejected',
                Works_Approved: 'Works Approved',
                Time_Extension: 'Time Extension',
                previousMsgId: 'ORI001'

            },
            projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
            claimFormsList = $scope.getValueOfOnLoadData('DS_MUJV_CLAM_List'),
            availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
            DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG'),
            structureItemList = function (setFor, availList) {
                var tempList = [],
                    optlabel = '';

                switch (setFor) {
                    case CONSTANTS_OBJ.MANAGER_DIRECTOR_USER_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.split('#')[1].trim(),
                                modelValue: item
                            });
                        });
                        optlabel = CONSTANTS_OBJ.MANAGER_DIRECTOR_USER_LIST_LABEL;
                        break;
                    case CONSTANTS_OBJ.COMM_TEAM_USER_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.split('#')[1].trim(),
                                modelValue: item
                            });
                        });
                        optlabel = CONSTANTS_OBJ.COMM_TEAM_USER_LIST_LABEL;
                        break;
                    case CONSTANTS_OBJ.CLAIM_APP_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.Value1,
                                modelValue: item.Value1,
                                Garrision: item.Value7
                            });
                        });
                        optlabel = CONSTANTS_OBJ.CLAIM_APP_LIST_LABEL;
                        break;
                    case CONSTANTS_OBJ.SUPPLY_CHAIN_USER_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.split('#')[1].trim(),
                                modelValue: item
                            });
                        });
                        optlabel = CONSTANTS_OBJ.SUPPLY_CHAIN_USER_LIST_LABEL;
                        break;
                    case CONSTANTS_OBJ.CLIENT_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.split('#')[1].trim(),
                                modelValue: item
                            });
                        });
                        optlabel = CONSTANTS_OBJ.CLIENT_LIST_LABEL;
                        break;
                }
                return [{
                    optlabel: optlabel,
                    options: tempList
                }];
            },

            workingUserRolesList = [];

        $scope.setDateDisplayFormat = function (propertyKey, obj) {
            obj['display' + propertyKey] = $scope.formatDate(obj[propertyKey], 'dd M yy', 'yy-mm-dd');
        };
        $scope.dateChangeEvent = function (paramObj) {
            // date comparison with other date logic 
            var workendDate = $scope.resMsgCustomFields.timeExtensionDate,
                workstrDate = $scope.rfqDetails.date;

            if (workstrDate) {
                var workstrdt = new Date(workstrDate);
                var workenddt = new Date(workendDate);
            }
            if (workstrdt && workenddt && (workstrdt >= workenddt)) {
                $scope.resMsgCustomFields.timeExtensionDate = "";
                alert("Invalid date  !!! \n\n Please Select After Close Due Date");
                return true;
            }
        };

        var resetClaimRelatedData = function () {
            $scope.rfqDetails.rfqTo = '';
            $scope.rfqDetails.clientRef = '';
            $scope.rfqDetails.garrision = '';
            $scope.rfqDetails.mujvRef = '';
            $scope.rfqDetails.costImplication = '';
            $scope.costImpChangeEvt($scope.rfqDetails.costImplication);
            $scope.rfqDetails.rfqDiscription = '';
        };

        $scope.itemChangeEvt = function (selectedItem, itemListKey) {
            switch (itemListKey) {
                case CONSTANTS_OBJ.CLAIM_APP_LIST_KEY:
                    resetClaimRelatedData();
                    var selectedCLaimObj = commonApi._.filter(claimFormsList, function (claimObj) {
                        return selectedItem.modelValue == claimObj.Value1;
                    })[0] || {};
                    $scope.rfqDetails.rfqTo = selectedCLaimObj.Value4 + '#' + selectedCLaimObj.Value5;
                    $scope.rfqDetails.supplyChainUser = $scope.rfqDetails.rfqTo;
                    break;
            }
            if (itemListKey == 'claim-list') {
                if (selectedItem) {
                    $scope.rfqDetails.garrision = selectedItem.Garrision;
                }
            }
        };

        $scope.costImpChangeEvt = function (costImplication) {
            if (costImplication == 'no') {
                $scope.rfqDetails.claimRegisterUser = $scope.rfqDetails.rfqTo;
            } else if (costImplication == 'yes') {
                $scope.rfqDetails.manDirUser = '';
                setManDirUsersList();
            }
        };

        //Flush value of Approve Description
        $scope.approveChangeEvt = function (descNodeKey, mainNode) {
            mainNode[descNodeKey] = '';
            $scope.rejectChangeEvt('Approved');
        };
        //Set flag value of Reject.
        $scope.rejectChangeEvt = function (nodeValue) {
            $scope.isShowDescNode = (nodeValue == 'Rejected' || nodeValue == 'Revise and Resubmit');
        };

        //Flush value of Reject Description
        $scope.rejectEvt = function (descNodeKey, mainNode) {
            mainNode[descNodeKey] = '';
        };

        $scope.checkOnlyOneCheckbox = function () {
            if ($scope.resMsgCustomFields.time_extension_button == 'Yes' || $scope.resMsgCustomFields.moreInfo_button == 'Yes') {
                $scope.hideCostValue = false;
                $scope.disableCostValue = true;
                $scope.resMsgCustomFields.capexCostValue = '';
                $scope.resMsgCustomFields.opexCostValue = '';
                $scope.resMsgCustomFields.opexAttachDoc = '';
                $scope.resMsgCustomFields.capexAttachDoc = '';
            } else {
                $scope.hideCostValue = true;
                $scope.disableCostValue = false;
                $scope.resMsgCustomFields.capexCostValue = '';
                $scope.resMsgCustomFields.opexCostValue = '';
            }
        };
        /**
         * Return todays date from time zone
         */
        function getDateFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }

        $scope.getDateFromZone = function () {
            return getDateFromZone();
        };
        // Total of Capex Cost and Opex Cost
        $scope.totalCost = function () {
            var capexCost = '',
                opexCost = '';
            $scope.resMsgCustomFields.finalCost = 0;
            capexCost = parseFloat($scope.resMsgCustomFields.capexCostValue);
            opexCost = parseFloat($scope.resMsgCustomFields.opexCostValue);
            if (capexCost != '' && isNaN(opexCost)) {
                $scope.resMsgCustomFields.finalCost = parseFloat(capexCost);
            } else if (opexCost != '' && isNaN(capexCost)) {
                $scope.resMsgCustomFields.finalCost = parseFloat(opexCost);
            } else if (capexCost != '' && opexCost != '' && (!isNaN(opexCost) || !isNaN(capexCost))) {
                $scope.resMsgCustomFields.finalCost = parseFloat(capexCost) + parseFloat(opexCost);
            }
        };
        $scope.resetUsersList = function (listKey, userNodeKey, mainNode) {
            mainNode[userNodeKey] = '';
            if (listKey == 'manDirList') {
                setManDirUsersList();
            } else if (listKey == 'commTeamUserList') {
                $scope.commTeamUserList = structureItemList(CONSTANTS_OBJ.COMM_TEAM_USER_LIST_KEY, commonApi.roleUsersListByRoleName('commercial team(mujv)', projAllRolesList));
            }
        };
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
            $scope.rfqDetails.rfqDateRequested = $scope.todayDateDbFormat;
            $scope.setDateDisplayFormat('rfqDateRequested', $scope.rfqDetails);
        });

        function setManDirUsersList() {
            var manList = commonApi.roleUsersListByRoleName('manager', projAllRolesList),
                dirList = commonApi.roleUsersListByRoleName('director', projAllRolesList);
            // Concating the manager and director roles users.
            $scope.manDirList = structureItemList(CONSTANTS_OBJ.MANAGER_DIRECTOR_USER_LIST_KEY, commonApi._.union(manList, dirList));
        }
        function setOriView() {
            var workingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.split('#')[0].replace('|', '#').replace(',', ' ,').trim();
            $scope.rfqDetails.Originator = workingUser.replace('|', '#').trim();
            $scope.claimAppList = structureItemList(CONSTANTS_OBJ.CLAIM_APP_LIST_KEY, claimFormsList);
            setManDirUsersList();
            // set values if it's loaded from claim form            
            if ($scope.rfqDetails.claimRef.claimFormNo) {
                var selectedCLaimObj = commonApi._.filter(claimFormsList, function (claimObj) {
                    return $scope.rfqDetails.claimRef.claimFormNo == claimObj.Value1;
                })[0] || {};

                if (angular.equals({}, selectedCLaimObj)) {
                    $scope.rfqDetails.claimRef.claimFormNo = '';
                    return false;
                }

                $scope.rfqDetails.rfqTo = selectedCLaimObj.Value4 + '#' + selectedCLaimObj.Value5;
                $scope.rfqDetails.supplyChainUser = $scope.rfqDetails.rfqTo;
                $scope.rfqDetails.claimRef.wasClaimedFromLaunch = true;
            }
        }
        if (isOriView || isRespView) {
            workingUserRolesList = String($scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES')[0].Value).toLowerCase().split(', ');
            $scope.supplyChainUsers = structureItemList(CONSTANTS_OBJ.SUPPLY_CHAIN_USER_LIST_KEY, commonApi.roleUsersListByRoleName('supply chain', projAllRolesList));
            $scope.clientList = structureItemList(CONSTANTS_OBJ.CLIENT_LIST_KEY, commonApi.roleUsersListByRoleName('client', projAllRolesList));
            $scope.garrisonManagerList = commonApi.roleUsersListByRoleName('07 garrison utility manager', projAllRolesList);
            $scope.commTeamUserList = commonApi.roleUsersListByRoleName('04 commercial coordinator mujv', projAllRolesList);
            $scope.supplyChainUsersList = commonApi.getItemSelectionList({
                arrayObject: setAllSupplyRole(CONSTANTS_OBJ.SupplyChain),
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        if (isOriView) {
            if ($scope.strFormId == "") {
                $scope.isAuthorized = true;
            }
            setOriView();
            if (!$scope.isRFQProcessCompleted) {
                $scope.isAuthToEnterFinalCost = ($scope.oriMsgCustomFields.rfqCurrStage == 'sent request for submit final cost');
            }
        } else if (isRespView) {
            $scope.sendToSupplyUser = '';
            $scope.reviseCost = '';
            var parentFormData = $scope.getValueOfOnLoadData('DS_MUJV_RFQS_PARENT_CHECK_FORMCONTENT_DATA');
            if (parentFormData.length && (parentFormData[0].Value2 == CONSTANTS_OBJ.In_Pricing || parentFormData[0].Value2 == CONSTANTS_OBJ.Works_Instructed)) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = '0';
                $scope.strCanReply = 'yes';
                if (parentFormData[0].Value2 == CONSTANTS_OBJ.In_Pricing) {
                    $scope.reviseCost = 'yes';
                } else if (parentFormData[0].Value2 == CONSTANTS_OBJ.Works_Instructed) {
                    $scope.sendToSupplyUser = 'yes';
                }
            } else {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = '1 | You are currently not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                $scope.oriMsgCustomFields.DSI_Errormsg = 'You are currently not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.';
                $scope.strCanReply = '';
            }
            if ($scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 == "ORI001") {
                $scope.rfqDetails.supplyChainUser = $scope.rfqDetails.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users[0].DS_PROJDISTUSERS.split("#")[0].trim();
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.On_Hold) {
                $scope.rfqDetails.ManagerRejectText = '';
                $scope.rfqDetails.manDirApproval = '';
                $scope.rfqDetails.CurrStage = 2;
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.In_Pricing || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Moreinfo_Reqired) {
                $scope.resMsgCustomFields.capexCostValue = '';
                $scope.resMsgCustomFields.opexCostValue = '';
                $scope.resMsgCustomFields.capexAttachDoc = "";
                $scope.resMsgCustomFields.opexAttachDoc = "";
                $scope.resMsgCustomFields.subCommTeamUser = '';
                $scope.resMsgCustomFields.finalCostDesc = '';
                $scope.resMsgCustomFields.commTeamApproval = '';
                $scope.resMsgCustomFields.manDirApproval = '';
                $scope.resMsgCustomFields.moreInformationRequired = "";
                $scope.resMsgCustomFields.time_extension_button = "";
                $scope.resMsgCustomFields.moreInfo_button = "";
                $scope.resMsgCustomFields.commTeamTimeApproval = "";
                $scope.resMsgCustomFields.commTeamTimeApprovedDesc = "";
                $scope.resMsgCustomFields.commTeamTimeRejectDesc = "";
                $scope.resMsgCustomFields.commTeamMorInfoDesc = "";
                $scope.rfqDetails.CurrStage = 2;
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Submit_Cost && $scope.rfqDetails.costImplication == 'no') {
                $scope.resMsgCustomFields.subManDirUser = '';
                $scope.resMsgCustomFields.commTeamApprovedDesc = '';
                $scope.isRFQProcessCompleted = true;
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Submit_Cost) {
                $scope.resMsgCustomFields.subManDirUser = '';
                $scope.resMsgCustomFields.commTeamApprovedDesc = '';
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Payment_Rejected || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Rejected) {
                $scope.resMsgCustomFields.supplyWorkType = '';
                $scope.resMsgCustomFields.supplyCommentBox = '';
                $scope.resMsgCustomFields.supplyWorkAttachDoc = '';
            }
            if ($scope.resMsgCustomFields.lastApproveReject == CONSTANTS_OBJ.Payment_Rejected) {
                $scope.resMsgCustomFields.paymentStatus = '';
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Completed) {
                $scope.resMsgCustomFields.isGarrisionApproved = false;
                $scope.resMsgCustomFields.garrisionRejectDesc = '';
                $scope.resMsgCustomFields.garrisionApproval = '';
                $scope.resMsgCustomFields.garrisionApprovedDesc = '';
            }
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Payment_Rejected) {
                $scope.resMsgCustomFields.paymentStatus = '';
                $scope.resMsgCustomFields.paymentAttachDoc= '';
            }
            $scope.isReqForManDirApprove = ($scope.oriMsgCustomFields.rfqCurrStage == 'sent request for manager/director approval');
            $scope.isSubCommTeamApprove = ($scope.oriMsgCustomFields.rfqCurrStage == 'sent submission for comm team approval');
            $scope.isSubManDirApprove = ($scope.oriMsgCustomFields.rfqCurrStage == 'sent submission for manager/director approval');

            setManDirUsersList();
            if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Rejected || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.In_Pricing) {
                $scope.isAuthToEnterFinalCost = true;
            }
        } else if (isOriPrintView) {
        } else if (isRespPrintView) {
            $scope.isShowOtherFields = true;
            $scope.resMsgCustomFields.isShowOtherFields = $scope.isShowOtherFields;
        }

        function formpemission() {
            if (currentViewName == "RES_VIEW") {
                if ($scope.strCanReply == '') {
                    alert("You are currently not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.");
                    return true;
                }
            }
            return false;
        }
        /**
         * Set 'Supply Chain' prefix user onload in ori-view ,res-view.
         * @param {String} obj : String of Supply Chain Role.
        */
        function setAllSupplyRole(obj) {
            var setAllRolebycontent = [];
            if (obj) {
                setAllRolebycontent = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                    return val.Name.toLowerCase().indexOf(obj) > -1;
                });
            }
            return setAllRolebycontent;
        }
        /**
        * Clear Action in Res-view.
        */
        function clearActionByMsg() {
            var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == 'Respond';
            });

            if (ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                for (var i = 0; i < ActionData.length; i++) {
                    var AutocompleteMsg = angular.copy(STATIC_OBJ.autocompleteMsgStructure);
                    AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
                    AutocompleteMsg.DS_MSG_AC_FORM = AppId;
                    AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
                    AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
                    AutocompleteMsg.DS_MSG_AC_ACTION = "3";
                    AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";
                    insertpoint.push(AutocompleteMsg);
                }
            }
        }

        /**
         * set response action to 04 Commercial Coordinator MUJV Role & 07 Garrison Utility Manager & Client (Commercial Team (Role)) .
         * * @param {Array} distNodes : Array of Commercial & Garrison user &  Client Role.
        */
        function assignCommToRespond(distNodes) {
            var tempList = [];
            if ($scope.resMsgCustomFields.TimeExtensioshow) {
                $scope.closeDueDate = $scope.resMsgCustomFields.timeExtensionDate;
                $scope.resMsgCustomFields.dateofTargetCostSubmission = $scope.resMsgCustomFields.timeExtensionDate;
            } else {
                $scope.closeDueDate = $scope.rfqDetails.date;
                $scope.resMsgCustomFields.dateofTargetCostSubmission = $scope.rfqDetails.date;
            }
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if (distNodes.length) {
                for (var i = 0; i < distNodes.length; i++) {
                    tempList.push({
                        strUser: distNodes[i].split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: $scope.closeDueDate
                    });
                }
            }
            if (tempList.length) {
                commonApi.setDistributionNode({
                    actionNodeList: tempList,
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: isRespView ? '13' : '3',
                });
            }
        }

        function setFormCommonNodes() {
            $scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            $scope.resMsgCustomFields.isShowOtherFields = $scope.isShowOtherFields;
            $scope.resMsgCustomFields.isAuthToEnterFinalCost = $scope.isAuthToEnterFinalCost;
            $scope.oriMsgCustomFields.isRFQProcessCompleted = $scope.isRFQProcessCompleted;
        }
        function setAppWorkflow() {
            var userTodistribute = '',
                currFormStaus = '',
                internalStage = '',
                distNodes = [],
                autoDistNode = isRespView ? '13' : '3';
            delete ($scope.rfqDetails.REPEATING_VALUES.DS_AutoDistribute_User_Group);
            // Distribution Will be made from here
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if (isOriView) {
                if ($scope.rfqDetails.costImplication == 'no') {
                    userTodistribute = $scope.rfqDetails.commercialTeamUser;
                    internalStage = 'sent request for submit final cost';
                }
                currFormStaus = CONSTANTS_OBJ.On_Hold;
            } else if (isRespView) {
                if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Approved && $scope.resMsgCustomFields.paymentStatus == CONSTANTS_OBJ.Payment_Authorised) {
                    currFormStaus = CONSTANTS_OBJ.Payment_Authorised;
                    internalStage = 'closed the form';
                    var supplyChainAllUsers = commonApi.roleUsersListByRoleName('supply chain', projAllRolesList),
                        supplyUserDistList = [];
                    for (var i = 0; i < supplyChainAllUsers.length; i++) {
                        supplyUserDistList.push({
                            strUser: supplyChainAllUsers[i],
                            strAction: "7#For Information"
                        });
                    }
                    if (supplyUserDistList.length) {
                        commonApi.setDistributionNode({
                            actionNodeList: supplyUserDistList,
                            autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                            asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                            DS_AUTODISTRIBUTE: autoDistNode
                        });
                    }
                } else if ($scope.isRFQProcessCompleted) {
                    if (!$scope.resMsgCustomFields.isCommTeamApproved && $scope.resMsgCustomFields.commTeamApproval == 'Approved') {
                        $scope.resMsgCustomFields.isCommTeamApproved = true;
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        currFormStaus = CONSTANTS_OBJ.Approved;
                        internalStage = 'sent submission for manager/director approval';
                    } else if (!$scope.resMsgCustomFields.isCommTeamApproved && ($scope.resMsgCustomFields.commTeamTimeApproval == 'Approved' || $scope.resMsgCustomFields.commTeamTimeApproval == 'Rejected' || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Moreinfo_Reqired)) {
                        if ($scope.resMsgCustomFields.commTeamTimeApproval == 'Approved') {
                            $scope.resMsgCustomFields.TimeExtensioshow = true;
                            $scope.resMsgCustomFields.dateofTargetCostSubmission = $scope.resMsgCustomFields.timeExtensionDate;
                        } else {
                            $scope.resMsgCustomFields.dateofTargetCostSubmission = $scope.rfqDetails.date;
                            $scope.resMsgCustomFields.TimeExtensioshow = false;
                        }
                        $scope.resMsgCustomFields.isCommTeamApproved = false;
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.In_Pricing;
                        internalStage = 'sent back to rewise final cost from comm team';
                    } else if (!$scope.resMsgCustomFields.isCommTeamApproved && $scope.resMsgCustomFields.commTeamApproval == 'Revise and Resubmit') {
                        $scope.resMsgCustomFields.isCommTeamApproved = false;
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.In_Pricing;
                        internalStage = 'sent back to rewise final cost from comm team';
                    } else if ($scope.resMsgCustomFields.isCommTeamApproved && !$scope.resMsgCustomFields.isManDirApproved && $scope.resMsgCustomFields.manDirApproval == 'Rejected') {
                        $scope.resMsgCustomFields.isCommTeamApproved = false;
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.In_Pricing;
                        internalStage = 'sent back to rewise final cost from manager/director';
                    } else if ($scope.resMsgCustomFields.isCommTeamApproved && !$scope.resMsgCustomFields.isManDirApproved && $scope.resMsgCustomFields.manDirApproval == 'Approved') {
                        $scope.resMsgCustomFields.isCommTeamApproved = false;
                        $scope.resMsgCustomFields.commTeamApproval = "";
                        distNodes = $scope.commTeamUserList;
                        assignCommToRespond(distNodes);
                        $scope.isAuthToEnterFinalCost = true;
                        $scope.rfqDetails.CurrStage = 3;
                        currFormStaus = CONSTANTS_OBJ.Sent_For_Approval;
                    } else if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.In_Review) {
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.Works_Instructed;
                        internalStage = "sent work to supply chain user";
                    } else if ($scope.resMsgCustomFields.supplyWorkType && ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Rejected || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Instructed || $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Payment_Rejected)) {
                        distNodes = $scope.garrisonManagerList;
                        assignCommToRespond(distNodes);
                        currFormStaus = CONSTANTS_OBJ.Works_Completed;
                        $scope.resMsgCustomFields.dateofWorksCompletion = getDateFromZone();
                        internalStage = "work sent to the garrison utility manager";
                    } else if (!$scope.resMsgCustomFields.isGarrisionApproved && $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Completed && $scope.resMsgCustomFields.garrisionApproval == CONSTANTS_OBJ.Works_Rejected) {
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.Works_Rejected;
                        internalStage = "works rejected by the garrison utility manager";
                    } else if (!$scope.resMsgCustomFields.isGarrisionApproved && $scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Completed && $scope.resMsgCustomFields.garrisionApproval == CONSTANTS_OBJ.Works_Approved) {
                        $scope.resMsgCustomFields.isGarrisionApproved = true;
                        distNodes = $scope.commTeamUserList;
                        assignCommToRespond(distNodes);
                        currFormStaus = CONSTANTS_OBJ.Works_Approved;
                        internalStage = "works approved by the garrison utility manager";
                    } else if ($scope.resMsgCustomFields.DS_Individual_Status == CONSTANTS_OBJ.Works_Approved && $scope.resMsgCustomFields.paymentStatus == CONSTANTS_OBJ.Payment_Rejected) {
                        userTodistribute = $scope.rfqDetails.supplyChainUser;
                        currFormStaus = CONSTANTS_OBJ.Payment_Rejected;
                        internalStage = "payment rejected by the commercial Team User";
                    } else if ($scope.rfqDetails.CurrStage == 2) {
                        distNodes = $scope.commTeamUserList;
                        assignCommToRespond(distNodes);
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        internalStage = 'sent submission for comm team approval';
                        $scope.resMsgCustomFields.date_Cost_Submission = getDateFromZone();
                        if ($scope.resMsgCustomFields.time_extension_button == 'Yes') {
                            currFormStaus = CONSTANTS_OBJ.Time_Extension;
                        } else if ($scope.resMsgCustomFields.moreInfo_button == 'Yes' && !$scope.resMsgCustomFields.time_extension_button) {
                            currFormStaus = CONSTANTS_OBJ.Moreinfo_Reqired;
                            $scope.isShowOnlyComment = true;
                        } else {
                            currFormStaus = CONSTANTS_OBJ.In_Review;
                            $scope.resMsgCustomFields.res_Available = 'Yes';
                        }
                    }
                } else {
                    if ($scope.rfqDetails.CurrStage == 2) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = "RES001";
                        $scope.isRFQProcessCompleted = true;
                        $scope.isAuthToEnterFinalCost = false;
                        $scope.isShowOtherFields = false;
                        distNodes = $scope.commTeamUserList;
                        assignCommToRespond(distNodes);
                        internalStage = 'sent submission for comm team approval';
                        $scope.resMsgCustomFields.date_Cost_Submission = getDateFromZone();
                        if ($scope.resMsgCustomFields.time_extension_button == 'Yes') {
                            currFormStaus = CONSTANTS_OBJ.Time_Extension;
                        } else if ($scope.resMsgCustomFields.moreInfo_button == 'Yes' && !$scope.resMsgCustomFields.time_extension_button) {
                            currFormStaus = CONSTANTS_OBJ.Moreinfo_Reqired;
                            $scope.isShowOnlyComment = true;
                        } else {
                            currFormStaus = CONSTANTS_OBJ.In_Review;
                            $scope.resMsgCustomFields.res_Available = 'Yes';
                        }
                    }
                }
            }
            if ($scope.resMsgCustomFields.TimeExtensioshow) {
                $scope.dueDate = $scope.resMsgCustomFields.timeExtensionDate;
            } else {
                $scope.dueDate = $scope.rfqDetails.date;
            }

            if (userTodistribute) {
                commonApi.setDistributionNode({
                    actionNodeList: [{
                        strUser: userTodistribute.split('#')[0].trim(),
                        strAction: "3#Respond",
                        strDate: $scope.dueDate
                    }],
                    autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE: autoDistNode
                });
            }

            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: availFormStatuses,
                strStatus: currFormStaus
            });
            $scope.resMsgCustomFields.DS_Individual_Status = currFormStaus;
            if (strFormStatusId) {
                $scope.resMsgCustomFields.appCurrentStatus = currFormStaus;
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                $scope.oriMsgCustomFields.rfqCurrStage = internalStage;
                $scope.resMsgCustomFields.lastApproveReject = $scope.approveReject;
            }
            $element.removeClass('loaded');
        }

        $scope.addNewItem = function (repeatingData, addItemFor) {
            var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
            repeatingData.push(newRowObject);
        };

        $scope.deleteAttchmentItem = function (index, repeatingData) {
            if (repeatingData.length == 1) {
                return;
            }
            repeatingData.splice(index, 1);
        };


        //to Hide Export Button in print view
        angular.element(".export-btn").hide();

        $scope.update();
        $window.oriformSubmitCallBack = function () {
            if (isOriView) {
                if ($scope.strFormId == "") {
                    alert("You are not permitted create this form, please cancel this process.");
                    return true;
                }
            } else {
                formpemission();
                if (isRespView) {
                    clearActionByMsg();
                }
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';
                setAppWorkflow();
                setFormCommonNodes();
                return false;
            }
        };
    }
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}