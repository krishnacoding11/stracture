/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base', '../components/folder.selection', '../components/item.selection'], function(angular, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout) {
        var ctrl = this;

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var customDropdownAttrType = 26;
        var projectInpt = document.getElementById('DS_PROJECTNAME');
        var idpDateFormat = "dd-M-yy";
        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null") {
            projectId = $window.currProjId;
        }

        if (!$window.USP || !$window.USP.email) {
            $window.alert('Fetal Error > User detail not found');
        }

        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" };
        var userDateFormat = dateFormatMap[$window.USP.languageId] || idpDateFormat;

        var printedBy = $window.USP ? $window.USP.email : "";
        var printedOn = "";

        $scope.project = projectInpt ? projectInpt.value : "";
        $scope.ptemplate = "";

        $scope.data = {};
        //		$scope.data.pref = "";

        // filter scope variables		
        $scope.showSections = []
        $scope.sectionListData = [];

        $scope.showDeliverables = [];
        $scope.deliverableListData = [];

        $scope.showComment = [];
        $scope.commentsListData = [];

        $scope.showItem = [];
        $scope.itemListData = [];

        $scope.showBlank = true;
        $scope.onlyThreeD = false;
        $scope.onlyMPDT = false;

        $scope.filterRole = [];
        $scope.filterRoleListData = [];

        $scope.filterStage = [];
        $scope.filterStageListData = [];

        $scope.filterLOD = [];
        $scope.filterLODListData = [];

        var staticValMap = "IDP_Plan_Status,IDP_RAG";
        var staticValues = {};
        $scope.staticValues = {};
        var setStaticListObj = function() {
            var staticValMapArray = staticValMap.split(',');
            for (var i = 0; i < staticValMapArray.length; i++) {
                var type = staticValMapArray[i];
                staticValues[type] = {};
                var el = document.getElementById('select' + type);
                if (!el) {
                    continue;
                }

                for (var j = 0; j < el.options.length; j++) {
                    var option = el.options[j];
                    var dataText = angular.element(option).text().split(':');
                    var code = dataText[0] || 'firstValue';
                    staticValues[type][code] = dataText[1];
                }
            }

            $scope.staticValues = staticValues;
        };

        setStaticListObj();

        var getStaticValue = function(type, code) {
            var staticObj = $scope.staticValues[type];
            return staticObj[(code || 'firstValue')];
        };

        var getDynamicValue = function(array, code) {
            for (var i = 0; i < array.length; i++) {
                var item = array[i];
                if (item.code == code) {
                    var name = item.displayValue || '';
                    return name.replace(code + ':', '');
                }
            }

            return "";
        };

        var getRoleMap = function() {
            return $scope.data.config.roles;
        };

        $scope.user = {
            roles: [],
            org: "",
            usp: {
                email: $window.USP.email,
                orgID: $window.USP.orgID,
                orgCode: "",
                tpdOrgName: $window.USP.tpdOrgName,
                tpdUserName: $window.USP.tpdUserName,
                userID: ($window.USP.userID || "").split('$$')[0]
            }
        };

        var sections = $scope.getValueOfOnLoadData('DS_IDP_SECTIONS'),
            deliverables = $scope.getValueOfOnLoadData('DS_IDP_DELIVERABLES'),
            deliverableStages = $scope.getValueOfOnLoadData('DS_IDP_DELIVERABLESTAGES'),
            deliverableComments = $scope.getValueOfOnLoadData('DS_IDP_DELIVERABLECOMMENTS'),
            stageComments = $scope.getValueOfOnLoadData('DS_IDP_DELIVERABLESTAGECOMMENTS'),
            deliverableItems = $scope.getValueOfOnLoadData('DS_IDP_DELIVERABLEITEMS'),
            stageItems = $scope.getValueOfOnLoadData('DS_IDP_STAGEITEM'),
            programme = $scope.getValueOfOnLoadData('DS_IDP_PROGRAMME')[0] || {},
            plqStages = $scope.getValueOfOnLoadData('DS_IDP_PLQSTAGES'),
            stageQuestions = $scope.getValueOfOnLoadData('DS_IDP_STAGEQUESTIONS');

        var mapMyFields = function() {
            // pstage
            var pstages = {};
            for (var i = 0; i < stageQuestions.length; i++) {
                var sq = stageQuestions[i];
                if (!pstages[sq.Value2]) {
                    pstages[sq.Value2] = [];
                }

                pstages[sq.Value2].push({
                    StageQuestions_ID: sq.Value1,
                    PLQStage_ID: sq.Value2,
                    note: sq.Value3,
                    qno: sq.Value4,
                    question: sq.Value5,
                    _name: sq.Value6,
                    answered: sq.Value7,
                    _stage: sq.Value8,
                    deliverables: sq.Value9 ? sq.Value9.split(',') : []
                });
            }

            // programme
            $scope.data.programme = {
                powTitle: programme.Value4,
                pstage: []
            };

            for (var i = 0; i < plqStages.length; i++) {
                var ps = plqStages[i];
                var obj = {
                    PLQStage_ID: ps.Value1,
                    Programme_ID: ps.Value2,
                    lod: ps.Value3,
                    stageTitle: ps.Value4,
                    stageEnd: ps.Value5,
                    stageStatName: ps.Value6,
                    stageStat: ps.Value7,
                    stageRef: ps.Value8,
                    stageName: ps.Value9,
                    projInfoMan: ps.Value10,
                    rag: ps.Value11,
                    id: ps.Value12,
                    projInfoManName: ps.Value13,
                    questions: pstages[ps.Value1]
                };
                if (ps.Value14) {
                    obj.lastModifier = {
                        orgCode: ps.Value15,
                        userID: ps.Value17,
                        orgID: ps.Value19,
                        tpdOrgName: ps.Value14,
                        tpdUserName: ps.Value16,
                        email: ps.Value18
                    };
                }
                $scope.data.programme.pstage.push(obj);
                $scope.data.programme.pstage = commonApi._.sortBy($scope.data.programme.pstage, function(p) {
                    return parseInt(p.id);
                });
            }

            // stage items
            var dItems = {};
            for (var i = 0; i < stageItems.length; i++) {
                var si = stageItems[i];
                if (!dItems[si.Value2]) {
                    dItems[si.Value2] = [];
                }

                var obj = {
                    StageItem_id: si.Value1,
                    DeliverableItem_ID: si.Value2,
                    lod: si.Value3,
                    role: si.Value4,
                    siid: si.Value5,
                    dueDate: si.Value6,
                    file_mask: si.Value7,
                    createdOn: si.Value11,
                    modifiedOn: si.Value12,
                    freeze: si.Value13 == "1",
                    uploaded: si.Value14 == "1",
                    rag: si.Value15 || 'AOK',
                    lodName: si.Value16,
                    file_link: si.Value17,
                    stgno: si.Value25,
                    stageRef: si.Value26,
                    revisionId: si.Value29,
                    isPlaceholder: si.Value30 == "1",
                    createdBy: si.Value31,
                    documentId: si.Value32,
                    folderId: si.Value37,
                    folderTitle: si.Value38,
                    locked: si.Value42 == "1"
                };
                if (si.Value27) {
                    obj.attrs = {
                        DocRef: si.Value27,
                        MaskKey: si.Value28
                    };
                }
                if (si.Value39) {
                    obj.lastModifier = {
                        orgCode: si.Value8,
                        userID: si.Value9,
                        orgID: si.Value10,
                        tpdOrgName: si.Value39,
                        tpdUserName: si.Value40,
                        email: si.Value41
                    };
                }
                if (si.Value24) {
                    obj.author = {
                        folderAccess: si.Value18,
                        orgID: si.Value19,
                        userImageName: si.Value20,
                        hashedOrgID: si.Value21,
                        user_type: si.Value22,
                        hUserID: si.Value23,
                        orgCode: si.Value24,
                        fname: si.Value33,
                        lname: si.Value34,
                        username: (si.Value33 || '') + (si.Value34 ? (' ' + si.Value34) : ''),
                        orgName: si.Value35,
                        email: si.Value36
                    };
                }
                dItems[si.Value2].push(obj);
            }

            // stage comments
            var dComments = {};
            for (var i = 0; i < stageComments.length; i++) {
                var sc = stageComments[i];
                if (!dComments[sc.Value3]) {
                    dComments[sc.Value3] = [];
                }
                var obj = {
                    DeliverableStageComment_ID: sc.Value1,
                    Deliverable_ID: sc.Value2,
                    DeliverableComment_ID: sc.Value3,
                    modifiedOn: sc.Value4,
                    createdBy: sc.Value5,
                    comment: sc.Value9,
                    stgno: sc.Value10,
                    createdOn: sc.Value11,
                    cid: sc.Value15
                };
                if (sc.Value12) {
                    obj.lastModifier = {
                        orgCode: sc.Value6,
                        userID: sc.Value7,
                        orgID: sc.Value8,
                        tpdOrgName: sc.Value12,
                        tpdUserName: sc.Value13,
                        email: sc.Value14
                    };
                }
                dComments[sc.Value3].push(obj);
            }

            // del items
            var dels = { items: {}, comments: {}, stages: {} };
            for (var i = 0; i < deliverableItems.length; i++) {
                var di = deliverableItems[i];
                if (!dels.items[di.Value2]) {
                    dels.items[di.Value2] = [];
                }
                var obj = {
                    DeliverableItem_ID: di.Value1,
                    Deliverable_ID: di.Value2,
                    dref: di.Value3,
                    role: di.Value4,
                    dtitle: di.Value5,
                    createdOn: di.Value6,
                    number: di.Value7,
                    DataProtectionLevel: di.Value8,
                    file_type: di.Value9,
                    Licence: di.Value10,
                    uploaded: di.Value11 == "1",
                    fileTypeName: di.Value12,
                    id: di.Value13,
                    locationName: di.Value14,
                    CopyrightHolder: di.Value15,
                    OriginalAuthor: di.Value16,
                    volume: di.Value17,
                    createdBy: di.Value18,
                    OutputData: di.Value19,
                    volumeName: di.Value20,
                    roleName: di.Value21,
                    location: di.Value22,
                    siref: di.Value23,
                    ProductionDate: di.Value24,
                    SharedInBusiness: di.Value25,
                    stage: commonApi._.sortBy(dItems[di.Value1], function(s) {
                        return parseInt(s.stgno);
                    })
                };
                if (di.Value29) {
                    obj.folder = {
                        folderId: di.Value29,
                        folderTitle: di.Value33
                    };
                }
                if (di.Value30) {
                    obj.originator = {
                        orgCode: di.Value26,
                        userID: di.Value27,
                        orgID: di.Value28,
                        tpdOrgName: di.Value30,
                        tpdUserName: di.Value31,
                        email: di.Value32
                    };
                }
                dels.items[di.Value2].push(obj);
            }

            // del comments
            for (var i = 0; i < deliverableComments.length; i++) {
                var dc = deliverableComments[i];
                if (!dels.comments[dc.Value2]) {
                    dels.comments[dc.Value2] = [];
                }
                var obj = {
                    DeliverableComment_ID: dc.Value1,
                    Deliverable_ID: dc.Value2,
                    dref: dc.Value3,
                    supplierName: dc.Value4,
                    createdBy: dc.Value5,
                    supplier: dc.Value6,
                    comment: dc.Value7,
                    id: dc.Value8,
                    createdOn: dc.Value12,
                    stage: commonApi._.sortBy(dComments[dc.Value1], function(s) {
                        return parseInt(s.stgno);
                    })
                };
                if (dc.Value13) {
                    obj.originator = {
                        orgCode: dc.Value9,
                        userID: dc.Value10,
                        orgID: dc.Value11,
                        tpdOrgName: dc.Value13,
                        tpdUserName: dc.Value14,
                        email: dc.Value15
                    };
                }
                dels.comments[dc.Value2].push(obj);
            }

            // del stages
            for (var i = 0; i < deliverableStages.length; i++) {
                var ds = deliverableStages[i];
                if (!dels.stages[ds.Value2]) {
                    dels.stages[ds.Value2] = [];
                }
                var obj = {
                    DeliverableStage_ID: ds.Value1,
                    Deliverable_ID: ds.Value2,
                    dref: ds.Value3,
                    lod: ds.Value4,
                    dnote: ds.Value5,
                    role: ds.Value6,
                    pdref: ds.Value7,
                    file_mask: ds.Value8,
                    stgno: ds.Value12,
                    createdOn: ds.Value13,
                    modifiedOn: ds.Value14,
                    freeze: ds.Value15 == "1",
                    isPlaceholder: ds.Value16 == "1",
                    createdBy: ds.Value17,
                    uploaded: ds.Value18 == "1",
                    roleName: ds.Value19,
                    rag: ds.Value20 || 'AOK',
                    lodName: ds.Value21,
                    ragName: ds.Value22,
                    Originator_OrgCode: ds.Value23,
                    Originator_UserID: ds.Value24,
                    Originator_OrgID: ds.Value25
                };
                if (ds.Value29) {
                    obj.lastModifier = {
                        orgCode: ds.Value9,
                        userID: ds.Value10,
                        orgID: ds.Value11,
                        tpdOrgName: ds.Value29,
                        tpdUserName: ds.Value30,
                        email: ds.Value31
                    };
                }
                dels.stages[ds.Value2].push(obj);
            }

            // deliverables
            var sctions = {};
            for (var i = 0; i < deliverables.length; i++) {
                var d = deliverables[i];
                if (!sctions[d.Value2]) {
                    sctions[d.Value2] = [];
                }
                var obj = {
                    Deliverable_ID: d.Value1,
                    Section_ID: d.Value2,
                    dref: d.Value3,
                    dtitle: d.Value4,
                    createdOn: d.Value5,
                    open_format: d.Value6,
                    native_format: d.Value7,
                    DataProtectionLevel: d.Value8,
                    capability: d.Value9,
                    file_type: d.Value10,
                    dscope: d.Value11,
                    Licence: d.Value12,
                    fileTypeName: d.Value13,
                    spref: d.Value14,
                    capabilityName: d.Value15,
                    CopyrightHolder: d.Value16,
                    OriginalAuthor: d.Value17,
                    assurance: d.Value18,
                    createdBy: d.Value19,
                    OutputData: d.Value20,
                    openFormatName: d.Value21,
                    ProductionDate: d.Value22,
                    SharedInBusiness: d.Value23,
                    stage: commonApi._.sortBy(dels.stages[d.Value1], function(s) {
                        return parseInt(s.stgno);
                    }),
                    sub_items: commonApi._.sortBy(dels.items[d.Value1], function(s) {
                        return parseInt(s.id);
                    }),
                    comments: commonApi._.sortBy(dels.comments[d.Value1], function(s) {
                        return parseInt(s.id);
                    })
                };
                if (d.Value24) {
                    obj.originator = {
                        tpdOrgName: d.Value24,
                        orgCode: d.Value25,
                        tpdUserName: d.Value26,
                        userID: d.Value27,
                        email: d.Value28,
                        orgID: d.Value29
                    };
                }
                sctions[d.Value2].push(obj);
            }

            $scope.data.section = [];
            for (var i = 0; i < sections.length; i++) {
                var s = sections[i];
                $scope.data.section.push({
                    Section_ID: s.Value1,
                    maxChar: s.Value2,
                    seref: s.Value3,
                    prefix: s.Value4,
                    startSequence: s.Value5,
                    increment: s.Value6,
                    setitle: s.Value7,
                    deliverable: sctions[s.Value1] || []
                });
            }
        }

        var linkedWorkspaceProjectId = null;
        var checkCrossWorkspaceData = function() {
            var formTypeId = window.formTypeId;
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getFormTypeDetailsByFormTypeId",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&userId=" + $window.USP.userID + "&formTypeId=" + formTypeId
            }).then(function(response) {
                var data = response.data || {};
                if (data.errorMsg) {
                    $window.alert('Error: ' + data.errorMsg);
                    return;
                }

                var formTypeVO = data.formTypeVO;
                var isTemplate = null;
                if (formTypeVO && formTypeVO.allowWorkspaceLink) {
                    var projId = formTypeVO.linkedWorkspaceProjectId || ""
                    linkedWorkspaceProjectId = projId;
                    isTemplate = ["", projId];
                }
                loadConfig(function() {
                    call_load_template(isTemplate);
                });
            }, function() {
                console.log("ERROR");
            });
        };

        var call_load_template = function(template) {
            var isTemplate = !!template;
            loadTemplate(template, function() {
                defineRole();

                fetchDynamicLists(isTemplate);

                fetchTemplateAttrList();

                // fetch EPM user list
                !$scope.readOnly && loadEpmList();

                // load with Template Manager role
                !$scope.readOnly && loadTMList();

                fetchUserListForStageItem();
            }, isTemplate);
        };

        var defineRole = function() {
            var userRoles = $scope.getWorkspaceRole() || [];
            var roleMap = getRoleMap();
            var roleArray = [];

            for (var key in roleMap) {
                if (typeof roleMap[key] == "string" && roleMap.hasOwnProperty(key)) {
                    var role = roleMap[key].split(",");
                    for (var i = 0; i < role.length; i++) {
                        var r = role[i];
                        if (userRoles.indexOf(r || key) > -1) {
                            roleArray.push(key);
                        }
                    }
                }
            }
            $scope.user.roles = roleArray;
            $scope.getCommentsListData(true);
        };

        var addKeysForSingleItemSelectionComponent = function(list, CheckedCode, selectList) {
            //Add and set checked/modelValue flag value for multiselect checkbox
            for (var i = 0; i < list.length; i++) {
                var listObj = list[i];
                if (!listObj.checked)
                    listObj.checked = false;
                if (!listObj.modelValue)
                    listObj.modelValue = listObj[CheckedCode];

                for (var j = 0; j < selectList.length; j++) {
                    if (selectList[j] == listObj[CheckedCode])
                        listObj.checked = true;
                }
            }
            return list;
        };

        $scope.orgList = [];
        $scope.regionList = [];
        $scope.regionListData = [];
        $scope.volumeList = [];
        $scope.volumeListData = [];
        $scope.locationList = [];
        $scope.locationListData = [];
        $scope.referenceList = [];
        $scope.pCodeList = [];
        $scope.stageStatList = [];
        $scope.defaultCOBieStage = "";
        $scope.COBieStageList = [];
        $scope.capabilityList = [];
        $scope.openFormatList = [];
        $scope.lodList = [];
        $scope.fileTypeList = [];
        $scope.itemRoleList = [];

        function fetchDynamicLists(isTemplate) {
            var typeNames = [];
            var configAttrs = $scope.data.config.attributes;
            for (var key in configAttrs) {
                if (configAttrs.hasOwnProperty(key) && key != 'generateURI') {
                    typeNames.push(configAttrs[key]);
                }
            }

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/dynamicContent",
                method: "post",
                withCredentials: true,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                data: "projectId=" + projectId + "&typeNames=" + encodeURIComponent(typeNames.join(','))
            }).then(function(response) {
                var list = response.data || {};

                checkForAvailAttr(list);

                $scope.orgList = list[configAttrs['Organization']] || [];
                var orgListArr = $scope.getItemSelectionArray($scope.orgList, true);
                $scope.orgListData = [{
                    optlabel: '',
                    options: orgListArr
                }];
                $scope.getItemListData(true);

                // set the user role based on organization
                var userOrg = $window.USP ? $window.USP.tpdOrgName : "";
                var orgObj = commonApi._.findWhere($scope.orgList, { name: userOrg }) || {};

                $scope.user.org = orgObj.code;
                $scope.user.usp.orgCode = orgObj.code;
                $scope.regionList = list[configAttrs['Region']] || [];
                $scope.regionList = commonApi._.sortBy($scope.regionList, function(o) { return o.code; });
                $scope.regionListData = [{
                    optlabel: "",
                    options: $scope.getItemSelectionArray($scope.regionList)
                }];

                $scope.stageStatList = list[configAttrs['StageStatus']] || [];

                var COBieStageListArr = list[configAttrs['StageStatus']] || [];
                $scope.COBieStageList = $scope.COBieStageList.concat(COBieStageListArr);
                var configCOBieStage = $scope.data.config.defaultStageStatues || "";
                $scope.defaultCOBieStage = configCOBieStage.split(",");

                var COBieStageListArr = addKeysForSingleItemSelectionComponent($scope.COBieStageList, "code", $scope.defaultCOBieStage);
                var cobieStages = [];
                if ($scope.data.programme && $scope.data.programme.pstage) {
                    for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                        var stage = $scope.data.programme.pstage[k];
                        cobieStages.push({
                            id: parseInt(stage.id),
                            name: stage.stageTitle,
                            displayValue: 'Stage ' + stage.id + ':' + stage.stageTitle,
                            code: 'Stage ' + stage.id
                        });
                    }
                }
                cobieStages = addKeysForSingleItemSelectionComponent(cobieStages, 'code', []);
                $scope.COBieStageListData = [{
                    optlabel: 'Statuses',
                    options: COBieStageListArr
                },{
                    optlabel: 'Stages',
                    options: cobieStages
                }];

                $scope.capabilityList = list[configAttrs['Capability']] || [];
                $scope.openFormatList = list[configAttrs['OutputFormat']] || [];
                $scope.lodList = list[configAttrs['LOD']] || [];

                $scope.getFilterLODListData(true);
                $scope.getCommentsListData(true);

                $scope.fileTypeList = list[configAttrs['FileType']] || [];
                var fileTypeListArr = $scope.getItemSelectionArray($scope.fileTypeList);
                $scope.fileTypeListData = [{
                    optlabel: "",
                    options: fileTypeListArr
                }];

                $scope.itemRoleList = list[configAttrs['Role']] || [];
                var itemRoleListArr = $scope.getItemSelectionArray($scope.itemRoleList);
                $scope.itemRoleListData = [{
                    optlabel: "",
                    options: itemRoleListArr
                }];

                $scope.pCodeList = list[configAttrs['ProjectCode']] || [];
                var pCodeListArr = $scope.getItemSelectionArray($scope.pCodeList);
                $scope.pCodeListData = [{
                    optlabel: "",
                    options: pCodeListArr
                }];

                $scope.volumeList = list[configAttrs['Volume']] || [];
                var volumeListArr = $scope.getItemSelectionArray($scope.volumeList);
                $scope.volumeListData = [{
                    optlabel: "",
                    options: volumeListArr
                }];

                $scope.locationList = list[configAttrs['Location']] || [];
                var locationListArr = $scope.getItemSelectionArray($scope.locationList);
                $scope.locationListData = [{
                    optlabel: "",
                    options: locationListArr
                }];
                $scope.VolumeCustAttrName = configAttrs['Volume'];
                $scope.LocationCustAttrName = configAttrs['Location'];

                $scope.referenceList = list[configAttrs['DeliverableReference']] || [];

                onUserAndOrgLoad();

                if (isTemplate) {
                    checkTemplateData(true);
                }
            }, function() {
                //				$window.alert('error');
            });
        };

        var volumeStandardList = undefined;
        var locationStandardList = undefined;
        var fetchTemplateAttrList = function() {
            var configAttrs = $scope.data.config.attributes;
            var typeNames = $scope.data.config.standardAttrs;
            if (window.currentViewName != 'ORI_VIEW' || !typeNames) {
                volumeStandardList = [];
                locationStandardList = [];
                return;
            }

            $scope.xhr.standardAttr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/workspace/getWorkspaceDetails",
                method: "post",
                withCredentials: true,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                data: "projectId=" + projectId + "&userId=" + $scope.user.usp.userID
            }).then(function(response) {
                $scope.xhr.standardAttr = false;

                var data = response.data || {};
                if (!data.templateProjectId || data.templateProjectId === "0" || data.templateProjectId === "null" ||
                    data.templateProjectId.indexOf('0$$') === 0 || data.templateProjectId.indexOf('-1$$') === 0) {
                    volumeStandardList = [];
                    locationStandardList = [];
                    ctrl.model.modelId == 'manageAttributes' && populateEntity(prevModalCurrentData.type);
                    return;
                }

                $scope.xhr.standardAttr = commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/dynamicContent",
                    method: "post",
                    withCredentials: true,
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    data: "projectId=" + data.templateProjectId + "&typeNames=" + encodeURIComponent(typeNames)
                }).then(function(response) {
                    $scope.xhr.standardAttr = false;
                    var list = response.data || {};

                    volumeStandardList = list[configAttrs['Volume']] || [];
                    locationStandardList = list[configAttrs['Location']] || [];

                    ctrl.model.modelId == 'manageAttributes' && populateEntity(prevModalCurrentData.type);
                }, function() {
                    $scope.xhr.standardAttr = false;
                    $window.alert('error');
                });
            }, function() {
                $scope.xhr.standardAttr = false;
                $window.alert('error');
            });
        };

        var resetDRefList = function(callback) {
            // disable submit buttons
            angular.element('#btnSaveForm').attr('disabled', 'disabled');
            angular.element('#btnSaveDraft').attr('disabled', 'disabled');

            var deleteReferenceList = [];
            var firstExcludeCustAttr = $scope.referenceList[0];
            var updateOnLoad = true;

            for (var i = 1; i < $scope.referenceList.length; i++) {
                deleteReferenceList.push({
                    value: $scope.referenceList[i].code,
                    defaultName: $scope.referenceList[i].name
                });
            }

            //Check if there are more than 1 values in custom attributes to delete
            if (deleteReferenceList.length) {
                manageAttributes('REMOVE', [{
                    attributeName: $scope.data.config.attributes["DeliverableReference"],
                    inputTypeId: customDropdownAttrType,
                    inputValueList: deleteReferenceList
                }], function(data) {
                    addMultipleDelRefOnSubmit(callback, firstExcludeCustAttr, updateOnLoad);
                }, updateOnLoad);
            } else {
                addMultipleDelRefOnSubmit(callback, firstExcludeCustAttr, updateOnLoad);
            }
        };

        var addMultipleDelRefOnSubmit = function(callback, firstExcludeCustAttr, updateOnLoad) {
            var addReferenceList = [];
            var operation = "REMOVE";
            var finalCallCustAttr = [{
                value: firstExcludeCustAttr.code,
                defaultName: firstExcludeCustAttr.name
            }];
            var drefAttrName = $scope.data.config.attributes["DeliverableReference"];

            for (var i = 0; i < $scope.data.section.length; i++) {
                var deliverables = $scope.data.section[i].deliverable || [];
                for (var j = 0; j < deliverables.length; j++) {
                    if (firstExcludeCustAttr.code != deliverables[j].dref && firstExcludeCustAttr.name != deliverables[j].dtitle) {
                        addReferenceList.push({
                            value: deliverables[j].dref,
                            defaultName: deliverables[j].dtitle
                        });
                    } else {
                        operation = "EDIT";
                        finalCallCustAttr = [{
                            value: deliverables[j].dref,
                            defaultName: deliverables[j].dtitle,
                            oldValue: firstExcludeCustAttr.code,
                            oldDefaultName: firstExcludeCustAttr.name
                        }];
                    }
                }
            }

            var firstDrefManaged = false;
            if (operation == "EDIT" && (finalCallCustAttr[0].value == finalCallCustAttr[0].oldValue && finalCallCustAttr[0].defaultName == finalCallCustAttr[0].oldDefaultName)) {
                firstDrefManaged = true;
            }

            var operationFn = function() {
                if (!firstDrefManaged) {
                    //Make the Final Call for the  first cust attr value
                    manageAttributes(operation, [{
                        attributeName: drefAttrName,
                        inputTypeId: customDropdownAttrType,
                        inputValueList: finalCallCustAttr
                    }], function() {
                        callback && callback();
                    }, updateOnLoad);
                } else {
                    callback && callback();
                }
            }

            if (addReferenceList.length) {
                manageAttributes('ADD', [{
                    attributeName: drefAttrName,
                    inputTypeId: customDropdownAttrType,
                    inputValueList: addReferenceList
                }], function() {
                    operationFn();
                }, updateOnLoad);
            } else {
                if (operation == "EDIT") {
                    operationFn();
                }
            }
        };

        var checkForAvailAttr = function(list) {
            if (window.currentViewName != 'ORI_VIEW') {
                return;
            }

            var missingAttr = [];
            var configAttrs = $scope.data.config.attributes;
            for (var key in configAttrs) {
                if (configAttrs.hasOwnProperty(key) && key != 'generateURI' && !list[configAttrs[key]]) {
                    missingAttr.push((missingAttr.length + 1) + '. ' + configAttrs[key]);
                }
            }

            if (missingAttr.length) {
                window.alert("Can't create form as required attributes are not available.\n" + missingAttr.join('\n'));
                window.cancelForm && window.cancelForm();
            }
        };

        /**
         * identify that row has atleast one stage filled or not
         * @param {object} deliverable
         * @returns {boolean} isBlank
         */
        $scope.isBlankRow = function(deliverable) {
            if (!deliverable)
                return;

            var isBlank = true;
            if (deliverable.stage) {
                for (var k = 0; k < deliverable.stage.length; k++) {
                    var stage = deliverable.stage[k];
                    if (stage.role || stage.load) {
                        isBlank = false;
                        break;
                    }
                }
            }

            return isBlank;
        };

        var getfilterStageIndexArr = function() {
            if (!$scope.filterStage)
                return;
            var indexArr = [];
            if ($scope.data.programme && $scope.data.programme.pstage) {
                for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                    var stage = $scope.data.programme.pstage[k];
                    if ($scope.filterStage.indexOf(stage.stageRef) > -1) {
                        indexArr.push(k);
                    }
                }
            }

            return indexArr;
        };

        /**
         * check that row has at list one column with file link
         * @param {object} item
         * @returns {boolean} hasFileLink
         */
        $scope.hasFileLink = function(item) {
            if (!item)
                return;

            var hasFileLink = false;
            if (item.stage) {
                for (var k = 0; k < item.stage.length; k++) {
                    var stage = item.stage[k];
                    if (stage.file_link) {
                        hasFileLink = true;
                        break;
                    }
                }
            }

            return hasFileLink;
        };

        /**
         * highlight cell according to filter
         * @param {object} stage
         * @returns {boolean} highlight
         */
        $scope.isMatch = function(stage) {
            if (!stage)
                return;

            var highlight = false;
            var indexArr = getfilterStageIndexArr();

            if ((isFilterStageCheckAll() || (indexArr && indexArr.indexOf(parseInt(stage.stgno)) > -1)) &&
                (stage.role && ($scope.filterRole.indexOf(stage.role) > -1)) &&
                (isFilterLODCheckAll() || (stage.lod && $scope.filterLOD.indexOf(stage.lod) > -1))) {
                highlight = true;
            }

            return highlight;
        };

        var isFilterStageCheckAll = function() {
            var retVal = false;
            var options = $scope.filterStageListData && $scope.filterStageListData[0] && $scope.filterStageListData[0].options || [];
            if ($scope.filterStage.length == options.length) {
                retVal = true
            }
            return retVal;
        };

        var isFilterLODCheckAll = function() {
            var retVal = false;
            var options = $scope.filterLODListData && $scope.filterLODListData[0] && $scope.filterLODListData[0].options || [];
            if ($scope.filterLOD.length == options.length) {
                retVal = true
            }
            return retVal;
        }

        // parse Questions' deliverables.
        var parseQuestionDeliverables = function(data) {
            var i, j, stage, q;
            if (data.programme && data.programme.pstage) {
                for (i = 0; i < data.programme.pstage.length; i++) {
                    stage = data.programme.pstage[i];
                    if (stage.stageName) {
                        stage.stageName = stage.stageName.replace(/&amp;/g, '&');
                    }
                    if (stage.questions) {
                        for (j = 0; j < stage.questions.length; j++) {
                            q = stage.questions[j];
                            if (typeof q.deliverables == "string") {
                                if (q.deliverables) {
                                    q.deliverables = q.deliverables.split(',');
                                } else {
                                    q.deliverables = [];
                                }
                            }

                            if (q.deliverables && q.deliverables.length == 1) {
                                var d = q.deliverables[0];
                                if (angular.isObject(d)) {
                                    if (d.content) {
                                        q.deliverables[0] = d.content;
                                    } else {
                                        q.deliverables = [];
                                    }
                                } else if (d && typeof d == "string" && d.indexOf(',') > -1) {
                                    q.deliverables = d.split(',');
                                }
                            }

                            if (!q.answered) {
                                q.answered = "";
                            }
                        }
                    }
                }
            }
        };

        var parseAllSections = function(data, isTemplate) {
            if (data.section && data.section.length) {
                data.section = commonApi._.reject(data.section, function(o) {
                    return !o.setitle;
                });

                data.section = commonApi._.sortBy(data.section, function(o) {
                    setPattern(o);
                    parseAllDeliverables(o, isTemplate);
                    return o.seref;
                });
            }
        };

        var setPattern = function(section) {
            section.maxChar = section.seref.length + "";
            section.prefix = section.seref.replace(/0/g, "");
            section.startSequence = section.startSequence || "100";
            section.increment = section.increment || "100";
        };

        var parseAllDeliverables = function(section, isTemplate) {
            if (section.deliverable && section.deliverable.length) {
                section.deliverable = commonApi._.sortBy(section.deliverable, function(o) {
                    var count = parseInt(o.dref.substr(section.prefix.length));
                    if (count == section.startSequence || (count - section.startSequence) % section.increment == 0) {
                        o.isMain = true;
                    }

                    o.seref = section.seref;

                    if (isTemplate || !o.createdBy) {
                        o.createdBy = printedBy;
                    }

                    if (isTemplate || !o.originator) {
                        o.originator = $scope.user.usp;
                    }

                    o.native_format = o.native_format || 'Y';

                    if (isTemplate) {
                        if (o.stage && o.stage.length) {
                            commonApi._.each(o.stage, function(ds) {
                                ds.pdref = o.dref;
                                ds.dref = o.dref;
                            });
                        }

                        if (o.sub_items && o.sub_items.length) {
                            commonApi._.each(o.sub_items, function(si) {
                                si.dref = o.dref;
                                si.createdBy = printedBy;
                                si.originator = $scope.user.usp;

                                commonApi._.each(si.stage, function(ss) {
                                    ss.siid = si.dref + ':' + si.id;
                                    $scope.updateSubMask(o.stage[ss.stgno], si, ss, $scope.data.programme.pstage[ss.stgno]);
                                });
                            });
                        }

                        if (o.comments && o.comments.length) {
                            commonApi._.each(o.comments, function(c) {
                                c.dref = o.dref;
                                c.createdBy = printedBy;
                                c.originator = $scope.user.usp;
                            });
                        }
                    }

                    return parseInt(o.dref.replace(section.prefix, ''));
                });
            }
        };

        var updateCreationDate = function(data, isTemplate) {
            if (!data.section || !data.section.length) {
                return;
            }

            getServerTime(function(date) {
                // set the form creation time
                if (isTemplate || !data.createdOn) {
                    data.createdOn = date;
                }

                for (var j = 0; j < data.section.length; j++) {
                    var s = data.section[j];
                    if (s.deliverable && s.deliverable.length) {
                        for (var i = 0; i < s.deliverable.length; i++) {
                            var o = s.deliverable[i];
                            if (isTemplate || !o.createdOn) {
                                o.createdOn = date;
                            }

                            if (isTemplate) {
                                if (o.sub_items && o.sub_items.length) {
                                    commonApi._.each(o.sub_items, function(si) {
                                        si.createdOn = date;
                                    });
                                }

                                if (o.comments && o.comments.length) {
                                    commonApi._.each(o.comments, function(c) {
                                        c.createdOn = date;
                                    });
                                }
                            }
                        }
                    }
                }
            });
        };

        var disableSaveActions = function() {
            var saveEle = document.getElementById('btnSaveForm');
            if (saveEle) {
                saveEle.disabled = true;
                saveEle.className += " btn-disabled";
            }
            var draftEle = document.getElementById('btnSaveDraft');
            if (draftEle) {
                draftEle.disabled = true;
                draftEle.className += " btn-disabled";
            }

            if ($window.stopAutoSaveTimer) {
                $window.stopAutoSaveTimer();
            } else if ($window.oAutoSaveTimer) {
                $window.clearTimeout($window.oAutoSaveTimer);
                $window.oAutoSaveTimer = null;
            }
        };

        /**
         * fetch the date from server
         * @param {fn} callback
         */
        var getServerTime = function(callback) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/serverDateTime",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformResponse: function(data, headersGetter, status) {
                    return "" + data;
                }
            }).then(function(response) {
                var data = response.data || {};
                printedOn = data || printedOn;
                callback(printedOn);
            }, function() {
                // $window.alert('error');
            });
        };

        var loadConfig = function(callback) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getConfigJson",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&appBuilderId=" + $window.AppBuilderFormIDCode
            }).then(function(response) {
                $scope.data.config = response.data || {};
                callback && callback();
            }, function(xhr) {
                $window.alert('Error while loading Config!');
            });
        };

        var setConfig = function() {
            if (typeof $scope.data.config == 'string') {
                $scope.data.config = angular.fromJson($scope.data.config);
            }

            $scope.data.config.placeholder = ($scope.data.config.placeholder === true || $scope.data.config.placeholder === "true");
            $scope.data.config.isParent = ($scope.data.config.isParent === true || $scope.data.config.isParent === "true");
            $scope.data.config.dueDateValidation = ($scope.data.config.dueDateValidation === true || $scope.data.config.dueDateValidation === "true");
            $scope.data.config.freeStageItem = ($scope.data.config.freeStageItem === true || $scope.data.config.freeStageItem === "true");
            $scope.data.config.actionNotification = ($scope.data.config.actionNotification === true || $scope.data.config.actionNotification === "true");
            $scope.data.config.disableDeliverableTitle = ($scope.data.config.disableDeliverableTitle === true || $scope.data.config.disableDeliverableTitle === "true");

            $scope.data.settings = $scope.data.settings || {};
            $scope.data.settings.capability = ($scope.data.settings.capability === true || $scope.data.settings.capability === "true");
            $scope.data.settings.openFormat = ($scope.data.settings.openFormat === true || $scope.data.settings.openFormat === "true");
            $scope.data.settings.nativeFormat = ($scope.data.settings.nativeFormat === true || $scope.data.settings.nativeFormat === "true");
            $scope.data.settings.editDelScope = ($scope.data.settings.editDelScope === true || $scope.data.settings.editDelScope === "true");
        };

        var setDefLODInStgManagement = function() {
            if (!$scope.data.config.defaultLOD) {
                return;
            }

            var split = $scope.data.config.defaultLOD.split(',');
            var defLodObj = {};
            for (var i = 0; i < split.length; i++) {
                var dlod = split[i].trim();
                if (dlod) {
                    dlod = dlod.split('=');
                    defLodObj[dlod[0]] = dlod[1];
                }
            }

            if ($scope.data.programme && $scope.data.programme.pstage) {
                for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                    var stage = $scope.data.programme.pstage[k];
                    if (!stage.lod && defLodObj[stage.id]) {
                        stage.lod = defLodObj[stage.id];
                    }
                }
            }
        };

        /**
         * invoke on project detail save
         */
        var loadTemplate = function(tpl, callback, silent) {
            if (tpl) {
                callformXmlData(tpl, callback, silent);
                return;
            }
            load_template_Continue(tpl, callback, silent, false);
        };

        var checkTemplateData = function(resetUnmatchData) {
            var volumeList = $scope.volumeList;
            var locationList = $scope.locationList;
            var fileTypeList = $scope.fileTypeList;
            var itemRoleList = $scope.itemRoleList;
            var isValid = true;
            if (!$scope.data.section)
                return isValid;

            for (var i = 0; i < $scope.data.section.length; i++) {
                var section = $scope.data.section[i];
                if (!section.deliverable || !section.deliverable.length) {
                    continue;
                }
                for (var j = 0; j < section.deliverable.length; j++) {
                    var d = section.deliverable[j];
                    if (!d.sub_items || !d.sub_items.length) {
                        continue;
                    }
                    for (var k = 0; k < d.sub_items.length; k++) {
                        var si = d.sub_items[k];

                        if (!si.dtitle) {
                            isValid = false;
                        }
                        if (!si.volume || !commonApi._.findWhere(volumeList, { code: si.volume })) {
                            if (resetUnmatchData) {
                                si.volume = "";
                            }
                            isValid = false;
                        }
                        if (!si.location || !commonApi._.findWhere(locationList, { code: si.location })) {
                            if (resetUnmatchData) {
                                si.location = "";
                            }
                            isValid = false;
                        }
                        if (!si.file_type || !commonApi._.findWhere(fileTypeList, { code: si.file_type })) {
                            if (resetUnmatchData) {
                                si.file_type = "";
                            }
                            isValid = false;
                        }
                        if (!si.role || !commonApi._.findWhere(itemRoleList, { code: si.role })) {
                            if (resetUnmatchData) {
                                si.role = "";
                            }
                            isValid = false;
                        }
                        if (!si.number) {
                            isValid = false;
                        }
                    }
                }
            }
            return isValid;
        };
        var callformXmlData = function(tpl, callback, silent) {
            var frmTitle = tpl[0] || "";
            var projId = tpl[1] || projectId;
            tpl = tpl[0] || tpl;
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/formXmlData",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "appBuilderCode=IDP" +
                    "&formTitle=" + frmTitle +
                    "&projectId=" + projId
            }).then(function(response) {
                var responseData = response.data || {};
                if (responseData.isSuccess) {
                    var data = angular.fromJson(responseData.response);
                    data = data.myFields || data;
                    data.config = $scope.data.config;

                    // preserve the ori form title specified in excel in child form
                    var oldTitle = data.ORI_FORMTITLE || "";
                    oldTitle = oldTitle.replace(data.pref + ' - ', '');
                    data.ORI_FORMTITLE = oldTitle;

                    angular.merge($scope.data, data);

                    // don't import from parent workspace
                    $scope.data.pref = "";
                    $scope.data.ptitle = "";
                    $scope.data.pmanager = "";
                    $scope.data.pfacility = "";
                    $scope.data.region = "";
                    $scope.data.status = "";

                    getServerTime(function(date) {
                        $scope.data.createdOn = date;
                    });

                    load_template_Continue(tpl, callback, silent, true);
                } else {
                    $window.alert(responseData.msg);
                    load_template_Continue(null, callback, silent, false)
                }
            }, function(error) {
                // $window.alert(error.msg);
                console.log("Error in formXmlData");
            });
        }

        var isChildForm = false;
        var load_template_Continue = function(tpl, callback, silent, isTemplate) {
            var tempData = $scope.getFormData();
            if (tempData.ptemplate || isTemplate) {
                if (!silent) {
                    $scope.data = tempData;
                }

                // prepare config
                if ($scope.data.config) {
                    setConfig();
                } else {
                    loadConfig(function() {
                        loadTemplate(tpl, callback, true);
                    });
                    return;
                }

                if (!$scope.data.section || !$scope.data.section.length) {
                    mapMyFields();
                }

                if ($scope.data.config.folderPath) {
                    getFolderDetailsByPath(isTemplate);
                } else {
                    getAllFoldersForProject(isTemplate);
                }

                parseAllSections($scope.data, isTemplate);
                updateCreationDate($scope.data, isTemplate);
                parseQuestionDeliverables($scope.data);

                if ($scope.data.isValid != 'Yes') {
                    disableSaveActions();
                }

                $scope.data.ORI_FORMTITLE = $scope.data.ORI_FORMTITLE || "Information Delivery Plan";

                if (isTemplate && linkedWorkspaceProjectId) {
                    $scope.data.model = linkedWorkspaceProjectId;
                }

                isChildForm = !$scope.data.config.isParent || !!$scope.data.model;

                // remove if edit ori, this flag is only
                if (isChildForm && window.currentViewName == 'ORI_VIEW') {
                    if (angular.element('#editORI').val() == "true") {
                        delete $scope.data.DS_DB_INSERT;
                    } else {
                        $scope.data.DS_DB_INSERT = "true";
                    }
                }

                // NOODLE-89976 - only one option required and it should be selected
                $scope.data.status = "Employers Information Delivery Plan";

                $scope.ptemplate = $scope.data.ptemplate;

                if (isTemplate || !$scope.data.createdBy) {
                    $scope.data.createdBy = printedBy;
                }

                if (isTemplate || !$scope.data.originator) {
                    $scope.data.originator = $scope.user.usp;
                }

                delete $scope.data.uploadedOn;

                // prepare lists
                if (!$scope.data.lists) {
                    $scope.data.lists = {
                        volumes: [],
                        locations: []
                    };
                } else {
                    if (typeof $scope.data.lists.volumes == 'string' && $scope.data.lists.volumes) {
                        $scope.data.lists.volumes = angular.fromJson($scope.data.lists.volumes);
                    }
                    $scope.data.lists.volumes = $scope.data.lists.volumes || [];

                    if (typeof $scope.data.lists.locations == 'string' && $scope.data.lists.locations) {
                        $scope.data.lists.locations = angular.fromJson($scope.data.lists.locations);
                    }
                    $scope.data.lists.locations = $scope.data.lists.locations || [];
                }

                setDefLODInStgManagement();

                $scope.updateCount();

                $scope.getSectionListData(true);
                $scope.getdeliverableListData(true);
                $scope.getCommentsListData(true); // Also called after getting user.roles & user.org
                $scope.getFilterRoleListData(true);
                $scope.getFilterStageListData(true);

                callback && callback();
            } else {
                $scope.update();
            }

            $timeout(function() {
                onResize();
                onScroll();
            }, 1000);
        }

        $scope.onRegionChange = function(item) {
            var name = getDynamicValue($scope.regionList, item.region);
            item.regionName = name;
        };

        $scope.onPlanChange = function(item) {
            var name = getStaticValue('IDP_Plan_Status', item.status);
            item.statusName = name;
        };

        $scope.onCapabilityChange = function(item) {
            var name = getDynamicValue($scope.capabilityList, item.capability);
            item.capabilityName = name;
        };

        $scope.onFormatChange = function(item) {
            var name = getDynamicValue($scope.openFormatList, item.open_format);
            item.openFormatName = name;
        };

        $scope.onSupplierRoleChange = function(item) {
            var name = getDynamicValue($scope.orgList, item.role);
            item.roleName = name;
        };

        $scope.onLODChange = function(item) {
            var name = getDynamicValue($scope.lodList, item.lod);
            item.lodName = name;
        };

        $scope.onRagChange = function(item) {
            var name = getStaticValue('IDP_RAG', item.rag);
            item.ragName = name;
        };

        $scope.onProjInfoChange = function(item) {
            var name = getDynamicValue($scope.orgList, item.projInfoMan);
            item.projInfoManName = name;
        };

        $scope.onStageStatChange = function(item) {
            var name = getDynamicValue($scope.stageStatList, item.stageStat);
            item.stageStatName = name;
        };

        $scope.onVolumeChange = function(item) {
            var name = getDynamicValue($scope.volumeList, item.volume);
            item.volumeName = name;
        };

        $scope.onLocationChange = function(item) {
            var name = getDynamicValue($scope.locationList, item.location);
            item.locationName = name;
        };

        $scope.onFileTypeChange = function(item) {
            var name = getDynamicValue($scope.fileTypeList, item.file_type);
            item.fileTypeName = name;
        };

        $scope.onItemRoleChange = function(item) {
            var name = getDynamicValue($scope.itemRoleList, item.role);
            item.roleName = name;
        };

        $scope.onAuthorChange = function(item) {
            if (!$scope.stageItemUsers || !$scope.stageItemUsers.length) {
                return;
            }

            item.roleName = "";
            item.author = null;
            if (!item.role) {
                return;
            }

            for (var i = 0; i < $scope.stageItemUsers.length; i++) {
                var u = $scope.stageItemUsers[i];
                if (u.hUserID == item.role) {
                    item.roleName = u.username + ', ' + u.orgName;
                    item.author = angular.copy(u);
                }
            }
        };

        $scope.onSubStgLODChange = function(item) {
            var name = getDynamicValue($scope.lodList, item.lod);
            item.lodName = name;
        };

        $scope.onSectionFilterChange = function(item) {
            $scope.getdeliverableListData(true);
        };

        $scope.getPreviousRevisionDetails = function(fn) {
            var revisionId = $scope.substg.revisionId;
            if (!revisionId) {
                return;
            }
            var item = $scope.subitem;
            var documentDetails = {
                "revisionId": revisionId,
                "maskKey": $scope.data.pref + '-' + ($scope.stg.role || '?') + '-' + (item.volume || '?') + '-' + (item.location || '?') + '-' +
                    (item.file_type || '?') + '-' + (item.role || '?') + '-' + (item.number || '?') + '-' + item.dref + '-' + $scope.pstg.stageRef + '-' + ($scope.backup.substg.lod || '?'),
                "customAttributeName": $scope.data.config.attributes["MaskKey"]
            };

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getPreviousRevisionDetails",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&documentDetails=" + angular.toJson(documentDetails)
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || {}
                if (data && data.documentDetails) {
                    var documentDetails = angular.fromJson(data.documentDetails);
                    $scope.substg.poiStatus = (documentDetails.poiStatus != "---") ? documentDetails.poiStatus : '';
                    $scope.substg.rev_num = (documentDetails.rev_num != "---") ? documentDetails.rev_num : '';

                    fn && fn();
                } else {
                    console.log("Error - no documentDetails");
                }
            }, function() {
                $scope.xhr.multiPH.pop();
                //				$window.alert('error');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        $scope.getSectionListData = function(onload) {
            $scope.sectionListData = [];
            var sectionListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            var optionsArr = [];

            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var check = "";
                if (onload) {
                    check = true;
                    $scope.showSections.push(section.seref);
                } else {
                    check = ($scope.showSections.indexOf(section.seref) > -1);
                }
                optionsArr.push({
                    displayValue: section.seref + " : " + section.setitle,
                    modelValue: section.seref,
                    checked: check
                });
            }
            sectionListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.sectionListData = sectionListDataArr;
        };

        $scope.getdeliverableListData = function(onload) {
            $scope.deliverableListData = [];
            var deliverableListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                if ($scope.showSections.indexOf(section.seref) > -1) {
                    var deliverables = section.deliverable || [];
                    var optionsArr = [];
                    for (var j = 0; j < deliverables.length; j++) {
                        var check = false;
                        var deliverable = deliverables[j];
                        if (onload) {
                            check = true;
                            $scope.showDeliverables.push(deliverable.dref);
                        } else {
                            check = ($scope.showDeliverables.indexOf(deliverable.dref)) ? true : false;
                        }
                        optionsArr.push({
                            displayValue: deliverable.dref + " : " + deliverable.dtitle,
                            modelValue: deliverable.dref,
                            checked: check
                        });
                    }
                    deliverableListDataArr.push({
                        optlabel: section.seref + " : " + section.setitle,
                        options: optionsArr
                    });
                }
            }
            $scope.deliverableListData = deliverableListDataArr;
        };

        $scope.getCommentsListData = function(onload) {
            $scope.commentsListData = [];
            var commentListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            var optionsArr = [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];
                for (var j = 0; j < deliverables.length; j++) {
                    var check = false;
                    var deliverable = deliverables[j];
                    if (deliverable.comments) {
                        for (var k = 0; k < deliverable.comments.length; k++) {
                            var comment = deliverable.comments[k];
                            if (onload) {
                                check = true;
                                $scope.showComment.push(comment.supplier);
                                $scope.showComment = commonApi._.uniq($scope.showComment);
                            } else {
                                check = ($scope.showComment.indexOf(comment.supplier) > -1);
                            }
                            //Check of user role is EPM or CanViewAllComments or is originator
                            if (CanViewAllComments() || ($scope.user.org == comment.originator.orgCode)) {
                                optionsArr.push({
                                    displayValue: comment.supplier + " : " + comment.supplierName,
                                    modelValue: comment.supplier,
                                    checked: check
                                });
                            }
                        }
                    }
                }
            }
            optionsArr = commonApi._.uniq(optionsArr, function(o) { return o.modelValue; });
            optionsArr = commonApi._.sortBy(optionsArr, function(o) { return o.modelValue; });
            commentListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.commentsListData = commentListDataArr;
        };

        $scope.getItemListData = function(onload) {
            $scope.itemListData = [];
            var itemListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            var orgArr = [];
            var optionsArr = [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];
                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var sub_items = deliverable.sub_items || [];
                    for (var k = 0; k < sub_items.length; k++) {
                        var subItem = sub_items[k];
                        var stages = subItem.stage;
                        for (var l = 0; l < stages.length; l++) {
                            var stage = stages[l];
                            stage.author && orgArr.push(stage.author.orgCode);
                        }

                    }
                }
            }
            orgArr = commonApi._.uniq(orgArr);
            if (orgArr.length && $scope.orgList.length) {
                for (var i = 0; i < orgArr.length; i++) {
                    var check = false;
                    var itemOrg = orgArr[i];
                    var orgData = commonApi._.findWhere($scope.orgList, { code: itemOrg });
                    if (onload) {
                        check = true;
                        $scope.showItem.push(itemOrg);
                        $scope.showItem = commonApi._.uniq($scope.showItem);
                    } else {
                        check = ($scope.showItem.indexOf(itemOrg) > -1);
                    }
                    optionsArr.push({
                        displayValue: orgData.displayValue,
                        modelValue: orgData.code,
                        checked: check
                    });
                }
            }
            optionsArr = commonApi._.sortBy(optionsArr, function(o) { return o.modelValue; });
            itemListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.itemListData = itemListDataArr;
        };

        $scope.getFilterRoleListData = function(onload) {
            $scope.filterRoleListData = [];
            var filterRoleListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            var orgArr = [];
            var optionsArr = [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];
                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var stages = deliverable.stage;
                    for (var k = 0; k < stages.length; k++) {
                        var stage = stages[k];
                        if (stage.role) {
                            var check = false;
                            if (onload) {
                                check = true;
                                $scope.filterRole.push(stage.role);
                                $scope.filterRole = commonApi._.uniq($scope.filterRole);
                            } else {
                                check = ($scope.filterRole.indexOf(stage.role) > -1);
                            }
                            optionsArr.push({
                                displayValue: stage.role + " : " + stage.roleName,
                                modelValue: stage.role,
                                checked: check
                            });
                        }
                    }
                }
            }
            optionsArr = commonApi._.uniq(optionsArr, function(o) { return o.modelValue; });
            optionsArr = commonApi._.sortBy(optionsArr, function(o) { return o.modelValue; });
            filterRoleListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.filterRoleListData = filterRoleListDataArr;
        };

        $scope.getFilterStageListData = function(onload) {
            $scope.filterStageListData = [];
            var filterStageListDataArr = [];
            var pstageArr = $scope.data.programme && $scope.data.programme.pstage || [];
            var optionsArr = [];
            if (pstageArr) {
                for (var i = 0; i < pstageArr.length; i++) {
                    var stage = $scope.data.programme.pstage[i];
                    var check = false;
                    if (onload) {
                        check = true;
                        $scope.filterStage.push(stage.stageRef);
                        $scope.filterStage = commonApi._.uniq($scope.filterStage);
                    } else {
                        check = ($scope.filterStage.indexOf(stage.stageRef) > -1);
                    }
                    optionsArr.push({
                        displayValue: stage.stageTitle,
                        modelValue: stage.stageRef,
                        checked: check
                    });
                }
            }
            filterStageListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.filterStageListData = filterStageListDataArr;
        };

        $scope.getFilterLODListData = function(onload) {
            $scope.filterLODListData = [];
            var filterLODListDataArr = [];
            var sectionsArray = $scope.data.section || [];
            var orgArr = [];
            var optionsArr = [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];
                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var stages = deliverable.stage;
                    for (var k = 0; k < stages.length; k++) {
                        var stage = stages[k];
                        if (stage.lod) {
                            var check = false;
                            if (onload) {
                                check = true;
                                $scope.filterLOD.push(stage.lod);
                                $scope.filterLOD = commonApi._.uniq($scope.filterLOD);
                            } else {
                                check = ($scope.filterLOD.indexOf(stage.lod) > -1);
                            }
                            optionsArr.push({
                                displayValue: stage.lod + " : " + stage.lodName,
                                modelValue: stage.lod,
                                checked: check
                            });
                        }
                    }
                }
            }
            optionsArr = commonApi._.uniq(optionsArr, function(o) { return o.modelValue; });
            optionsArr = commonApi._.sortBy(optionsArr, function(o) { return o.modelValue; });

            filterLODListDataArr.push({
                optlabel: "",
                options: optionsArr
            });
            $scope.filterLODListData = filterLODListDataArr
        };

        $scope.isShowComments = function(isDataRow, comment) {
            if (isDataRow) {
                if ($scope.showComment && $scope.showComment.indexOf(comment.supplier) > -1)
                    return true;
            } else {
                for (var i = 0; i < comment.length; i++) {
                    if ($scope.showComment && $scope.showComment.indexOf(comment[i].supplier) > -1)
                        return true;
                }
            }
            return false;
        };

        $scope.isShowItems = function(isDataRow, sub_items) {
            if (!$scope.data.config) {
                return false;
            }

            if ($scope.itemListData && $scope.itemListData.length && $scope.itemListData[0].options) {
                if ($scope.showItem.length == $scope.itemListData[0].options.length)
                    return true;
            }

            if (isDataRow) {
                var stages = sub_items.stage;
                for (var j = 0; j < stages.length; j++) {
                    var stage = stages[j];
                    var org = stage.author && stage.author.orgCode;
                    if (org && $scope.showItem && $scope.showItem.indexOf(org) > -1)
                        return true;
                }
            } else {
                for (var i = 0; i < sub_items.length; i++) {
                    var subitem = sub_items[i];
                    var stages = subitem.stage;
                    for (var j = 0; j < stages.length; j++) {
                        var stage = stages[j];
                        var org = stage.author && stage.author.orgCode;
                        if (org && $scope.showItem && $scope.showItem.indexOf(org) > -1)
                            return true;
                    }
                }
            }
            return false;
        }

        $scope.isHighlightItems = function(subitem_stg) {
            if ($scope.itemListData && $scope.itemListData.length && $scope.itemListData[0].options) {
                if ($scope.showItem.length == $scope.itemListData[0].options.length)
                    return false;
                var org = subitem_stg.author && subitem_stg.author.orgCode;
                if (org && $scope.showItem && $scope.showItem.indexOf(org) > -1)
                    return true;
            }
            return false;
        }

        $scope.checkModalPopupForSingeValueDropdown = function(id) {
            if (window.currentViewName != 'ORI_VIEW')
                return;
            switch (id) {
                case "projectdetails":
                    if ($scope.pCodeList.length === 1) {
                        $scope.item.pref = $scope.pCodeList[0].code;
                        $scope.pCodeListData[0].options[0].checked = true;
                        $scope.setPtitle();
                    }
                    if ($scope.regionList.length === 1) {
                        $scope.regionListData[0].options[0].checked = true;
                        $scope.item.region = $scope.regionList[0].code;
                        $scope.onRegionChange($scope.item);
                    }
                    break;
                case "stagemanagement":
                    break;
                case "itemdeliverables":
                    if ($scope.capabilityList.length === 1)
                        $scope.item.capability = $scope.capabilityList[0].code;
                    if ($scope.openFormatList.length === 1)
                        $scope.item.open_format = $scope.openFormatList[0].code;
                    break;
                case "subitemdeliverables":
                    if ($scope.volumeList.length === 1)
                        $scope.subitem.volume = $scope.volumeList[0].code;
                    if ($scope.locationList.length === 1)
                        $scope.subitem.location = $scope.locationList[0].code;
                    if ($scope.fileTypeList.length === 1)
                        $scope.subitem.file_type = $scope.fileTypeList[0].code;
                    if ($scope.itemRoleList.length === 1)
                        $scope.subitem.role = $scope.itemRoleList[0].code;
                    break;
                case "stagedeliverables":
                    if ($scope.lodList.length === 1)
                        $scope.stg.lod = $scope.lodList[0].code;
                    break;
                case "stagecomment":
                    break;
                case "deliverablecomment":
                    break;
                case "stage":
                    break;
                case "subitemstage":
                    break;
                case "uploaddocument":
                    break;
                case "folderselection":
                    break;
                case "findReplace":
                    break;
                case "mapCDE":
                    break;
                default:
                    break;
            }
        };

        $scope.findReplaceOnFilterChange = function(stage) {
            stage.existingFilterRoleOptions = [];
            stage.showValidation = false;
            stage.uniqueCounts = {};
            stage.existingRole = "";
            $scope.existingFilterRoleOptionsData = [];
            $scope.isSupplierFilterStage = (stage.supplierFilterStage) ? true : false;
            if (!stage.supplierFilterStage) {
                stage.existingRoleCount = 0;
                stage.newRole = "";
                return;
            }

            var existingOptions = [];
            var uniqueCounts = {};
            var selectedStageIndex = parseInt(stage.supplierFilterStage);

            var sectionsArray = $scope.data.section || [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];

                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var thisStageObj = deliverable.stage[selectedStageIndex];
                    if (!thisStageObj.role) {
                        continue;
                    }
                    var subItems = deliverable.sub_items || [];
                    if (!subItems.length) {
                        existingOptions.push(thisStageObj.role);
                    } else {
                        var isValid = true;
                        for (var k = 0; k < subItems.length; k++) {
                            var subItem = subItems[k];
                            var orgCode = (subItem.originator || {}).orgCode;
                            var substage = subItem.stage[selectedStageIndex];
                            if (thisStageObj.role == orgCode || substage.role) {
                                isValid = false;
                                break;
                            }
                        }
                        if (isValid) {
                            existingOptions.push(thisStageObj.role);
                        }
                    }
                }
            }

            if (!existingOptions.length) {
                stage.showValidation = true;
            } else {
                existingOptions.forEach(function(x) {
                    uniqueCounts[x] = (uniqueCounts[x] || 0) + 1;
                });
                stage.uniqueCounts = uniqueCounts;

                existingOptions = commonApi._.uniq(existingOptions);


                for (var i = 0; i < existingOptions.length; i++) {
                    var selectedCode = existingOptions[i];
                    var displayName = commonApi._.findWhere($scope.orgList, { code: selectedCode })
                    stage.existingFilterRoleOptions.push({
                        // code: selectedCode,
                        displayValue: displayName.displayValue,
                        modelValue: selectedCode,
                        checked: false
                    });
                }

                $scope.existingFilterRoleOptionsData = [{
                    optlabel: '',
                    options: stage.existingFilterRoleOptions
                }];
            }
        }

        $scope.findReplaceOnExistingRoleChange = function(stage) {
            if (stage.existingRole) {
                stage.existingRoleCount = stage.uniqueCounts[stage.existingRole];
            } else {
                stage.existingRoleCount = 0;
            }
        }

        $scope.onSupplierChange = function(item) {
            var name = getDynamicValue($scope.orgList, item.supplier);
            item.supplierName = name;
        };

        // refresh the total deliverable count at the bottom of the form
        $scope.updateCount = function() {
            if (!$scope.data) {
                $scope.data = {};
            }

            var sectionsCount = 0;
            var deliverablesCount = 0;
            var commentsCount = 0;
            var visibleComments = 0;
            var itemsCount = 0;
            if ($scope.data.section && $scope.data.section.length) {
                sectionsCount = $scope.data.section.length;
                for (var i = 0; i < $scope.data.section.length; i++) {
                    var section = $scope.data.section[i];
                    if (section.deliverable) {
                        deliverablesCount += section.deliverable.length;

                        for (var j = 0; j < section.deliverable.length; j++) {
                            var d = section.deliverable[j];
                            if (d.comments) {
                                commentsCount += d.comments.length;
                                if (CanViewAllComments()) {
                                    visibleComments += d.comments.length;
                                } else {
                                    for (var k = 0; k < d.comments.length; k++) {
                                        var c = d.comments[k];
                                        if ($scope.user.org && $scope.user.org == c.originator.orgCode) {
                                            visibleComments++;
                                        }
                                    }
                                }
                            }

                            if (d.sub_items) {
                                itemsCount += d.sub_items.length;
                            }
                        }
                    }
                }
            }

            $scope.data.counts = {
                sections: sectionsCount,
                deliverables: deliverablesCount,
                comments: commentsCount,
                visibleComments: visibleComments,
                items: itemsCount
            };

            return (sectionsCount + ' Sections, ' + deliverablesCount + ' Deliverables, ' + visibleComments + ' Comments, ' + itemsCount + ' Items');
        };

        /**
         * generate the mask based on mask key
         * mask key : [ProjRef]-[Author]-[Volume]-[Location]-[Type]-[Role]-[FileNum]-[Status]-[Rev]-[DelRef]-[Stage]-[LOD]-[Title].ext
         * @param {object} item
         * @param {object} stage
         * @param {object} pstage
         */
        $scope.updateMask = function(item, stage, pstage) {
            if (!stage.role)
                return;

            var pref = $scope.data.pref;
            stage.file_mask = pref + '-' + stage.role + '-?-?-?-?-?-?-?-' + item.dref + '-' + pstage.stageRef + '-' + (stage.lod || '?') + '-' + (item.dtitle || '?');
            return stage.file_mask;
        };

        /**
         * generate the mask based on mask key
         * mask key : [ProjRef]-[Author]-[Volume]-[Location]-[Type]-[Role]-[FileNum]-[Status]-[Rev]-[DelRef]-[Stage]-[LOD]-[Title].ext
         * @param {object} item
         * @param {object} stage
         * @param {object} pstage
         */
        $scope.updateSubMask = function(dStage, item, stage, pstage) {
            if (!$scope.data.config || !stage.role)
                return;

            var pref = $scope.data.pref;
            var role = dStage.role;

            var docRef = pref + '-' + (role || '?') + '-' + (item.volume || '?') + '-' + (item.location || '?') + '-' +
                (item.file_type || '?') + '-' + (item.role || '?') + '-' + (item.number || '?');

            var lastStrWHTitle = item.dref + '-' + pstage.stageRef + '-' + (stage.lod || '?');
            var lastStr = lastStrWHTitle + '-' + (item.dtitle || '?');

            stage.file_mask = docRef + '-Status-Rev-' + lastStr;

            if (!stage.attrs || !stage.attrs.DocRef) {
                stage.attrs = stage.attrs || {};
                stage.attrs.DocRef = docRef;
                stage.attrs.MaskKey = docRef + '-' + lastStrWHTitle;
            }

            stage.stageRef = pstage.stageRef;

            if (stage.poiStatus) {
                stage.file_mask = stage.file_mask.replace('-Status-', '-' + stage.poiStatus + '-');
            }
            if (stage.rev_num) {
                stage.file_mask = stage.file_mask.replace('-Rev-', '-' + stage.rev_num + '-');
            }

            return stage.file_mask;
        };

        var addZeroPad = function(number, minChar) {
            number = number + "";
            while (number.length < minChar) {
                number = "0" + number;
            }

            return number;
        };

        var CanViewAllComments = function() {
            return ($scope.user.roles.indexOf('CanViewAllComments') > -1);
        };

        $scope.canCreateComment = function(item) {
            if ($scope.user.roles.indexOf('EPM') > -1) {
                return true;
            }

            if ($scope.user.roles.indexOf('SIM') > -1 && $scope.data.programme && $scope.data.programme.pstage) {
                for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                    var stage = $scope.data.programme.pstage[k];
                    if ($scope.user.org && stage.projInfoMan == $scope.user.org) {
                        return true;
                    }
                }
            }

            for (var i = 0; i < item.stage.length; i++) {
                if ($scope.data.config.freeStageItem || ($scope.user.org && item.stage[i].role == $scope.user.org)) {
                    return true;
                }
            }

            return false;
        };

        $scope.canCreateItem = function(item) {
            if ($scope.user.roles.indexOf('TM') > -1 || $scope.data.config.freeStageItem) {
                return true;
            }

            for (var i = 0; i < item.stage.length; i++) {
                if ($scope.user.org && item.stage[i].role == $scope.user.org) {
                    return true;
                }
            }

            return false;
        };

        $scope.canRemoveItem = function(subitem) {
            if(subitem.uploaded) {
                if($scope.user.roles.indexOf('TM') > -1) {
                    for (var i = 0; i < subitem.stage.length; i++) {
                        if (subitem.stage[i].isPlaceholder) {
                            return false;
                        }
                    }
                    return true;
                }
            } else if($scope.user.usp.orgID == subitem.originator.orgID) {
                return true;
            }

            return false;
        };

        $scope.hasVisibleComments = function(comments) {
            if (CanViewAllComments()) {
                return true;
            }

            for (var i = 0; i < comments.length; i++) {
                if ($scope.user.org && comments[i].originator.orgCode == $scope.user.org) {
                    return true;
                }
            }

            return false;
        };

        $scope.isFolderReadOnly = function() {
            if (!$scope.subitem || !$scope.subitem.stage) {
                return true;
            }

            for (var i = 0; i < $scope.subitem.stage.length; i++) {
                var s = $scope.subitem.stage[i];
                if (s.revisionId) {
                    return true;
                }
            }

            return false;
        };

        var hasDocInDel = function(item, stg) {
            if (item.sub_items && item.sub_items.length) {
                for (var i = 0; i < item.sub_items.length; i++) {
                    var subItm = item.sub_items[i];
                    if(stg) {
                        if (subItm.stage[stg.stgno].uploaded) {
                            return true;
                        }
                    } else if (subItm.uploaded) {
                        return true;
                    }
                }
            }

            return false;
        };

        $scope.canChangeRole = function(stg, item) {
            if ($scope.data.config.freeStageItem) {
                return !hasDocInDel(item, stg);
            }

            if (((!item.sub_items || !item.sub_items.length) && (!item.comments || !item.comments.length)) ||
                ($scope.backup.stg && !$scope.backup.stg.role)) {
                return true;
            }

            if (item.sub_items && item.sub_items.length) {
                for (var i = 0; i < item.sub_items.length; i++) {
                    var subItm = item.sub_items[i];
                    if (subItm.originator.orgCode == stg.role) {
                        return false;
                    }
                }
            }

            return true;
        };

        $scope.isModalReadOnly = function(name) {
            var readOnly = '';
            if (!$scope.user.org && (!$scope.data.config.freeStageItem ||
                    (name !== 'uploaddocument' && name !== 'subitemstage' && name != 'subitemdeliverables'))) {
                return 'readOnly';
            }
            switch (name) {
                case 'mapCDE':
                case 'manageAttributes':
                    readOnly = 'readOnly';
                    break;
                case 'projectdetails':
                case 'itemdeliverables':
                    if ($scope.user.roles.indexOf('EPM') == -1 && $scope.user.roles.indexOf('TM') == -1) {
                        readOnly = 'readOnly';
                    }
                    break
                case 'findReplace':
                case 'stagedeliverables':
                case 'stagemanagement':
                    if ($scope.user.roles.indexOf('EPM') == -1) {
                        readOnly = 'readOnly';
                    }
                    break;
                case 'deliverablecomment':
                case 'stagecomment':
                    if ($scope.subitem && $scope.user.usp.userID != $scope.subitem.originator.userID) {
                        readOnly = 'readOnly';
                    }
                    break;
                case 'subitemdeliverables':
                    if ($scope.subitem && ($scope.user.usp.orgID != $scope.subitem.originator.orgID) || $scope.subitem.uploaded) {
                        readOnly = 'readOnly';
                    }
                    break;
                case 'subitemstage':
                    if ($scope.subitem && $scope.stg && (!$scope.stg.role || $scope.substg.freeze || $scope.substg.uploaded ||
                            ($scope.user.usp.orgID != $scope.subitem.originator.orgID ||
                                (!$scope.data.config.freeStageItem && $scope.user.org != $scope.stg.role)))) {
                        readOnly = 'readOnly';
                    }
                    break;
                case 'stage':
                    break;
            }

            return readOnly;
        };

        var getMaxRef = function(sections, deliverables, item, idx, isForParent) {
            var prefixLen = sections.prefix.length;
            var step = parseInt(sections.increment);
            var start = parseInt(sections.startSequence);
            var maxDref;
            if(item) {
                maxDref = parseInt(item.dref.substr(prefixLen))
            } else {
                maxDref = start;
            }
            var index = idx;
            if(!isForParent) {
                var floorNumber = Math.floor((maxDref - start) / step);
    
                var dref, number;
                for (var i = idx; i < deliverables.length; i++) {
                    dref = deliverables[i]['dref'];
                    number = parseInt(dref.substr(prefixLen));
    
                    if (Math.floor((number - start) / step) > floorNumber) {
                        break;
                    }
    
                    index = i;
                    maxDref = Math.max(maxDref, number);
                }
                maxDref = maxDref + 1;
                index = index + 1;
            } else {
                maxDref = item ? maxDref + step : maxDref;
            }

            maxDref = addZeroPad(maxDref, sections.maxChar - prefixLen);
            return { dref: sections.prefix + maxDref, index: index };
        };

        /**
         * insert new row below the targe row
         * @param {number} ixd
         * @param {object} item
         * @param {object} deliverable
         */
        $scope.addRow = function(item, deliverables, sections, isForParent) {
            var ref = {}, steDref;
            
            if (!sections && $scope.data.section && $scope.data.section.length) {
                var sectionArray = $scope.data.section;
                for (var i = 0; i < sectionArray.length; i++) {
                    sections = sectionArray[i];
                    deliverables = sections.deliverable || [];
                    if (deliverables.indexOf(item) > -1) {
                        break;
                    }
                }
            }
            
            var prefixLen = sections.prefix.length;
            var step = parseInt(sections.increment);
            
            if(item) {
                var ixd = deliverables.indexOf(item);
                ixd = Math.max(0, ixd);
    
                var limit = "";
                for (var i = 0; i < (sections.maxChar - prefixLen); i++) {
                    limit += "9";
                }
    
                steDref = parseInt(item.dref.substr(prefixLen));
                limit = Math.min(steDref + step - 1, limit);
    
                ref = getMaxRef(sections, deliverables, item, ixd);
                var newRef = ref.dref;
                if (parseInt(newRef.substr(prefixLen)) > limit) {
                    $window.alert('Exceeded limit to create Sub-Deliverables for current Deliverable.');
                    return;
                }
            }

            if(isForParent) {
                var maxDref;
                var start = parseInt(sections.startSequence);
                if(deliverables && deliverables.length) {
                    item = deliverables[deliverables.length - 1];
                    var number = parseInt(item.dref.substr(prefixLen));
                    maxDref = Math.floor((number - start) / step) * step + start + step;
                } else {
                    maxDref = start;
                }
                maxDref = addZeroPad(maxDref, sections.maxChar - prefixLen);
                ref = { dref: sections.prefix + maxDref };
            }

            var ragName = getStaticValue('IDP_RAG', "AOK") || '';

            var newStages = [];
            for (var i = 0; i < $scope.data.programme.pstage.length; i++) {
                newStages.push({
                    "stgno": (i + ""),
                    "pdref": ref.dref,
                    "role": "",
                    "roleName": "",
                    "lod": "",
                    "lodName": "",
                    "file_mask": "",
                    "rag": "AOK",
                    "ragName": ragName,
                    "dnote": "",
                    "createdBy": "",
                    "createdOn": ""
                });
            }

            var dtitleText = ref.dref + " ???";
            var newDeliverable = {
                dref: ref.dref,
                seref: sections.seref,
                spref: item ? item.dref : sections.seref,
                dtitle: dtitleText,
                native_format: 'Y',
                assurance: "",
                capability: "",
                capabilityName: "",
                open_format: "",
                openFormatName: "",
                file_type: "",
                fileTypeName: "",
                ProductionDate: "LOD",
                OriginalAuthor: "LOD",
                CopyrightHolder: "LOD",
                SharedInBusiness: "LOD",
                DataProtectionLevel: "LOD",
                Licence: "LOD",
                OutputData: "LOD",
                createdBy: printedBy,
                createdOn: printedOn,
                originator: $scope.user.usp,
                stage: newStages
            };

            if(isForParent) {
                newDeliverable.isMain = true;
            }

            getServerTime(function(date) {
                newDeliverable.createdOn = date;
                updateInDB(newDeliverable, dbMap.itemdeliverables, 'Insert');
            });

            if (!ref.index) {
                deliverables.push(newDeliverable); // append object in array
            } else {
                deliverables.splice(ref.index, 0, newDeliverable); // insert object in array
            }

            $scope.getdeliverableListData(true);
            $scope.hideModal();

            // TODO: if want to edit directly the new comment then uncomment below line
            //			$scope.showModal('itemdeliverables', newDeliverable, currentIndex, deliverables);

            manageAttributes('ADD', [{
                attributeName: $scope.data.config.attributes["DeliverableReference"],
                inputTypeId: customDropdownAttrType,
                inputValueList: [{
                    value: ref.dref,
                    defaultName: dtitleText
                }]
            }]);
        };

        /**
         * add new item under deliverable row in item table
         * @param {object} item
         */
        $scope.addItem = function(item, subItem) {
            if (!item.sub_items) {
                item.sub_items = [];
            }

            var lastSubItem = item.sub_items[item.sub_items.length - 1];
            var index = "1",
                newItem;

            if (lastSubItem) {
                index = parseInt(lastSubItem.id) + 1;
            }

            var newStages = [];
            var siref = item.dref + ':' + index;
            for (var i = 0; i < $scope.data.programme.pstage.length; i++) {
                newStages.push({ "siid": siref, "stgno": (i + ""), "role": "", "rag": "AOK", "roleName": "", "lodName": "", "lod": "", "file_link": "", "createdBy": "", "createdOn": "" });
            }

            if (subItem) {
                newItem = angular.copy(subItem);
                delete newItem.uploaded;
                newItem.stage = newStages;
            } else {
                newItem = {
                    dref: item.dref,
                    dtitle: "",
                    volume: "",
                    volumeName: "",
                    location: "",
                    locationName: "",
                    role: "",
                    roleName: "",
                    file_type: "",
                    fileTypeName: "",
                    ProductionDate: "LOD",
                    OriginalAuthor: "LOD",
                    CopyrightHolder: "LOD",
                    SharedInBusiness: "LOD",
                    DataProtectionLevel: "LOD",
                    Licence: "LOD",
                    OutputData: "LOD",
                    createdOn: printedOn,
                    stage: newStages,
                    folder: angular.copy($scope.data.folder),
                    isNewAddItem: true
                };
            }

            newItem.id = index;
            newItem.siref = siref;
            newItem.number = item.dref + '_' + index;
            newItem.createdBy = printedBy;
            newItem.originator = $scope.user.usp;
            if (subItem && isDuplicateNumber(newItem)) {
                $window.alert('Same Deliverable Item already exist');
                return;
            }
            $scope.xhr.multiPH.push(true);
            getServerTime(function(date) {
                newItem.createdOn = date;
                if (subItem) {
                    item.sub_items.push(newItem);
                    updateInDB(newItem, dbMap.subitemdeliverables, 'Insert', function() {
                        $scope.xhr.multiPH.pop();
                    });
                } else {
                    $scope.xhr.multiPH.pop();
                }
            });

            $scope.showModal('subitemdeliverables', item, newItem, (item.sub_items.length - 1));

            if (subItem) {
                ctrl.readOnly = $scope.isModalReadOnly('subitemdeliverables');
            }
        };

        /**
         * add new comment under deliverable row in item table
         * @param {object} item
         */
        $scope.addComment = function(item) {
            if (!item.comments)
                item.comments = [];

            var lastComment = item.comments[item.comments.length - 1];
            var index = "1";
            if (lastComment)
                index = parseInt(lastComment.id) + 1;

            var newStages = [];
            for (var i = 0; i < $scope.data.programme.pstage.length; i++) {
                newStages.push({ "stgno": (i + ""), "comment": "", "cid": item.dref + ':' + index });
            }

            var newComment = {
                id: index,
                dref: item.dref,
                supplier: "",
                supplierName: "",
                comment: "",
                author: printedBy,
                createdBy: printedBy,
                createdOn: printedOn,
                originator: $scope.user.usp,
                stage: newStages,
                isNewAddItem: true
            };

            getServerTime(function(date) {
                newComment.createdOn = date;
            });

            // item.comments.push(newComment);
            $scope.showModal('deliverablecomment', item, newComment, (item.comments.length - 1));
        };

        /**
         * remove deliverable row
         * @param {number} index
         * @param {object} deliverables
         */
        $scope.removeRow = function(index, deliverables) {
            if(!window.confirm('Deleting current Deliverable will remove all Deliverable Items, Stage Items, Deliverable comments, Stage Comments created under this Deliverable')) {
                return;
            }

            var item = deliverables[index];
            manageAttributes('REMOVE', [{
                attributeName: $scope.data.config.attributes["DeliverableReference"],
                inputTypeId: customDropdownAttrType,
                inputValueList: [{
                    value: item.dref,
                    defaultName: item.dtitle
                }]
            }]);

            // remove object from array 
            deliverables.splice(index, 1);

            // update bottom count
            $scope.hideModal();

            updateInDB({ dref: item.dref }, dbMap.itemdeliverables, 'Delete');
        };

        /**
         * remove deliverable items of deliverable
         * @param {number} index
         * @param {object} deliverable
         */
        $scope.removeItem = function(index, deliverable) {
            if (!deliverable.sub_items.length)
                return;

            var item = deliverable.sub_items[index];
            if(item.uploaded && $scope.user.roles.indexOf('TM') > -1) {
                if(!confirm('You have requested to remove Deliverable Item.\nAll files uploaded within this Deliverable Item will be orphaned in CDE')) {
                    return;
                }
            }
            
            if ($scope.data.config.placeholder) {
                removeMultiPH(item.stage, function() {
                    // remove object from array 
                    deliverable.sub_items.splice(index, 1);
                    $scope.hideModal();
                    updateInDB({ dref: item.dref, id: item.id }, dbMap.subitemdeliverables, 'Delete');
                });
            } else {
                // remove object from array 
                deliverable.sub_items.splice(index, 1);
                $scope.hideModal();
                updateInDB({ dref: item.dref, id: item.id }, dbMap.subitemdeliverables, 'Delete');
            }
        };

        $scope.removeStageItem = function(substg) {
            var stgno = substg.stgno;
            var siid = substg.siid;
            var obj = { "siid": siid, "stgno": stgno, "role": "", "roleName": "", "lodName": "", "lod": "", "file_link": "", "createdBy": "", "createdOn": "" };
            for (var key in substg) {
                if (substg.hasOwnProperty(key)) {
                    delete substg[key];
                }
            }
            angular.merge(substg, obj);
            updateInDB(substg, dbMap.subitemstage, 'Update');
            $scope.hideModal();
        }

        /**
         * remove deliverable row
         * @param {number} index
         * @param {object} deliverable
         */
        $scope.removeComment = function(index, deliverable) {
            if (!deliverable.comments.length)
                return;

            // remove object from array 
            var comment = deliverable.comments[index];
            deliverable.comments.splice(index, 1);
            $scope.hideModal();

            updateInDB({ dref: comment.dref, id: comment.id }, dbMap.deliverablecomment, 'Delete');
        };

        /**
         * Update the data on server 
         * @private
         */
        var saveFormData = function(callback) {
            var isTemplateDataValid = checkTemplateData();
            if (!isTemplateDataValid) {
                $window.alert('All "Deliverable Item" fields are mandatory. Please enter all pending Item values marked in red.');
                return;
            }

            if (angular.element('#editORI').val() != "true") {
                $scope.data.ORI_FORMTITLE = $scope.data.pref + ' - ' + $scope.data.ORI_FORMTITLE;
                isTemplateDataValid && resetDRefList(function() {
                    $window.submitForm && $window.submitForm(1); // create the form on first time modal update click for create form page only
                });
                return;
            }

            var jsonData = $window.getJSONData && $window.getJSONData();
            if (!jsonData) {
                $window.alert('No form data found');
                return;
            }

            var inpt = document.getElementById('html_json_data');
            if (!inpt) {
                inpt = document.createElement('input');
                inpt.id = "html_json_data";
                inpt.name = "jsonData";
                inpt.type = "hidden";
                document.myform.appendChild(inpt);
            }

            inpt.value = jsonData;

            var $form = angular.element('#myform');
            commonApi.ajax({
                url: $form.attr("action"),
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: $form.serialize() + '&isAjaxCall=true'
            }).then(function(response) {
                var data = response.data || {};
                callback && callback(data);
            }, function() {
                //				$window.alert('error');
            });
        };

        /**
         * update subitem stage rag on parent stage rag change
         */
        var updateSubRag = function() {
            if (!$scope.backup.item || !$scope.backup.item.sub_items || !$scope.backup.item.sub_items.length) {
                return;
            }

            for (var i = 0; i < $scope.backup.item.sub_items.length; i++) {
                var subItem = $scope.backup.item.sub_items[i];
                var subStage = subItem.stage[$scope.backup.stg.stgno];
                subStage.rag = $scope.backup.stg.rag || 'AOK';
                $scope.onRagChange(subStage);
            }
        };

        var isModified = function(oldObj, newObj) {
            if (!angular.isObject(oldObj) || !angular.isObject(newObj)) {
                return false;
            }

            for (var key in newObj) {
                if (newObj.hasOwnProperty(key) && key != 'generateURI' && newObj[key] !== oldObj[key]) {
                    return true;
                }
            }

            return false;
        };

        var setStageHistory = function(callback) {
            switch (ctrl.model.modelId) {
                case 'stagemanagement':
                case 'stagedeliverables':
                    if (isModified($scope.backup.stg, $scope.stg)) {
                        $scope.stg.lastModifier = $scope.user.usp;

                        if (!$scope.stg.createdBy && $scope.stg.role) {
                            $scope.stg.createdBy = printedBy;
                        }

                        $scope.xhr.multiPH.push(true);
                        getServerTime(function(date) {
                            $scope.stg.modifiedOn = date;

                            if (!$scope.stg.createdOn && $scope.stg.role) {
                                $scope.stg.createdOn = date;
                            }

                            callback && callback();
                            $scope.xhr.multiPH.pop();
                        });
                    } else {
                        callback && callback();
                    }
                    break;
                case 'subitemstage':
                case 'stagecomment':
                    if (isModified($scope.backup.substg, $scope.substg)) {
                        $scope.substg.lastModifier = $scope.user.usp;

                        var isCreated = ((ctrl.model.modelId == "subitemstage" && $scope.substg.role) || (ctrl.model.modelId == "stagecomment" && $scope.substg.comment));

                        if (!$scope.substg.createdBy && isCreated) {
                            $scope.substg.createdBy = printedBy;
                        }

                        $scope.xhr.multiPH.push(true);
                        getServerTime(function(date) {
                            $scope.substg.modifiedOn = date;

                            if (!$scope.substg.createdOn && isCreated) {
                                $scope.substg.createdOn = date;
                            }

                            callback && callback();
                            $scope.xhr.multiPH.pop();
                        });
                    } else {
                        callback && callback();
                    }
                    break;
                default:
                    callback && callback();
                    break;
            }
        };

        var freezePrevStages = function(item, substg) {
            if (!$scope.data.config.placeholder) {
                return;
            }

            var stgno = substg.stgno - 1;
            var updatedStages = [];
            if (stgno >= 0) {
                for (var i = stgno; i >= 0; i--) {
                    var prevStg = item.stage[i];
                    if (!prevStg.role) {
                        prevStg.freeze = true;
                        updatedStages.push(prevStg);
                    }
                }
            }

            updatedStages.length && updateInDB(updatedStages, dbMap.subitemstage, 'Update');
        }

        var placeholderSuccess = function(data) {
            if (ctrl.model.modelId == 'subitemstage') {
                freezePrevStages($scope.subitem, $scope.substg);
            }

            var isCallDelegateAction = data && data.documentDelegateActionDetails;
            $scope.updateRecord(true, $scope.substg && isCallDelegateAction);

            if ($scope.substg && isCallDelegateAction) {
                $scope.submitDelegateAction(data);
            }
        };

        var getCombinationKey = function(subItemRow) {
            var obj = {
                "Item": subItemRow.dtitle,
                "FileNumber": subItemRow.number,
                "Location": subItemRow.location,
                "Volume": subItemRow.volume,
                "FileType": subItemRow.file_type,
                "Role": subItemRow.role
            };
            var outputKey = '';
            var keyCombo = $scope.data.config.delItemUniqueCombination || 'FileNumber';
            var requiredKeys = keyCombo.split(",");
            for (var i = 0; i < requiredKeys.length; i++) {
                var attr = requiredKeys[i].trim();
                outputKey += obj[attr];
                if (i !== requiredKeys.length - 1) {
                    outputKey += "-";
                }
            }
            return outputKey;
        }

        var isDuplicateNumber = function(subItemRow) {
            var singleUnqiueKey = getCombinationKey(subItemRow);

            var sections = $scope.data.section;
            if (!sections || !sections.length) {
                return false;
            }

            for (var i = 0; i < sections.length; i++) {
                var section = sections[i];
                var deliverables = section.deliverable;
                if (!deliverables || !deliverables.length)
                    continue;

                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var subItems = deliverable.sub_items;

                    if (!subItems || !subItems.length) {
                        continue;
                    }

                    for (var k = 0; k < subItems.length; k++) {
                        var subItem = subItems[k];
                        if ((subItem.dref != subItemRow.dref || subItem.id != subItemRow.id) && getCombinationKey(subItem) === singleUnqiueKey) {
                            return true;
                        }
                    }
                }
            }

            return false;
        };

        // hold the data edited by user in modal 
        $scope.backup = {
            item: {},
            stg: {}
        };

        $scope.validateFindReplace = function() {
            var findReplace = $scope.findReplace;
            if (!findReplace.supplierFilterStage) {
                alert("Please select a Stage");
                return false;
            }

            if (!findReplace.existingRole) {
                alert("Please select a Existing Role");
                return false;
            }

            if (!findReplace.newRole) {
                alert("Please select a New Role");
                return false;
            }

            if (findReplace.existingRole == findReplace.newRole) {
                alert("Please select a different New Role. New Role cannot be the same as Existing Role");
                return false;
            }

            return true;
        };

        var updateFindReplace = function(date) {
            var findReplace = $scope.findReplace;
            var newRole = findReplace.newRole;
            var existingRole = findReplace.existingRole;
            var selectedStageIndex = parseInt(findReplace.supplierFilterStage);
            var sectionsArray = $scope.data.section || [];
            var dbArray = [];
            for (var i = 0; i < sectionsArray.length; i++) {
                var section = sectionsArray[i];
                var deliverables = section.deliverable || [];

                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];
                    var thisStageObj = deliverable.stage[selectedStageIndex];
                    var subItems = deliverable.sub_items || [];

                    if (!subItems.length && thisStageObj.role == existingRole) {
                        thisStageObj.role = newRole;
                        thisStageObj.lastModifier = $scope.user.usp;
                        thisStageObj.modifiedOn = date;
                        dbArray.push(thisStageObj);
                    } else {
                        var isValid = true;
                        for (var k = 0; k < subItems.length; k++) {
                            var subItem = subItems[k];
                            var orgCode = (subItem.originator || {}).orgCode;
                            var substage = subItem.stage[selectedStageIndex];
                            if (thisStageObj.role == orgCode || substage.role) {
                                isValid = false;
                                break;
                            }
                        }
                        if (isValid && thisStageObj.role == existingRole) {
                            thisStageObj.role = newRole;
                            thisStageObj.lastModifier = $scope.user.usp;
                            thisStageObj.modifiedOn = date;
                            dbArray.push(thisStageObj);
                        }
                    }
                }
            }

            if (dbArray.length) {
                updateInDB(dbArray, dbMap.stagedeliverables, 'Update');
            }
        }

        $scope.setPtitle = function() {
            $scope.item.ptitle = "";
            var pref = $scope.item.pref || "";
            for (var i = 0; i < $scope.pCodeListData.length; i++) {
                var pCodeList = $scope.pCodeListData[0];
                var options = pCodeList.options || [];
                for (var j = 0; j < options.length; j++) {
                    if (options[j].modelValue == pref) {
                        $scope.item.ptitle = options[j].displayName || "";
                        break;
                    }
                }
            }
        }

        $scope.submitDelegateAction = function(data) {
            var actionVO = angular.fromJson(data.documentDelegateActionDetails);
            if (!actionVO.length) {
                return
            }

            var strDrId = "";
            var strDrReportId = "";
            var hashedFolderId = $scope.subitem.folder.folderId;
            var f = findFolder($scope.folder.list, hashedFolderId);
            if (f) {
                hashedFolderId = f.folderId;
            }

            var strRepeatVO = "";
            for (var i = 0; i < actionVO.length; i++) {
                strRepeatVO += "&revision-id" + (i + 1) + "=" + actionVO[i].revisionId +
                    "&folder-id" + (i + 1) + "=" + hashedFolderId +
                    "&recipient-user-id" + (i + 1) + "=" + actionVO[i].recipient_user_id +
                    "&revision-dist-list-id" + (i + 1) + "=" + actionVO[i].dist_list_id +
                    "&delegated" + (i + 1) + "=false" +
                    "&action-name" + (i + 1) + "=" + actionVO[i].action_name +
                    "&action-id" + (i + 1) + "=" + actionVO[i].action_id +
                    "&NewActionDueDate" + (i + 1) + "=" + $scope.substg.dueDate // if actionDueDateType = 2

                strDrId += (actionVO[i].dist_list_id || "").split('$$')[0] + "|" + (actionVO[i].recipient_user_id || "").split('$$')[0] + "|" + actionVO[i].action_id;
                strDrReportId += (actionVO[i].dist_list_id || "").split('$$')[0] + "|" + actionVO[i].action_id + "|" + (actionVO[i].recipient_user_id || "").split('$$')[0] + "|" + actionVO[i].revisionId;
                if (actionVO.length > 1 && i != actionVO.length - 1) {
                    strDrId += ",";
                    strDrReportId += ",";
                }
            }

            commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/document/submitDelegateAction",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "distlistcount=" + actionVO.length +
                        "&drId=" + strDrId +
                        "&drReportId=" + strDrReportId +
                        "&project_id=" + projectId +
                        "&isFromRemoveUser=null" +
                        "&actionDueDateType=2" // 0 = Existing Due Date and 2 = User Definition
                        +
                        "&selected_user_type=1" +
                        "&selected_username=" + encodeURIComponent($scope.substg.author.username) +
                        "&userId=" + $scope.substg.author.userID +
                        "&selected_orgname=" + encodeURIComponent($scope.substg.author.orgName) +
                        "&orgId=" + $scope.substg.author.hashedOrgID +
                        strRepeatVO
                }).then(function(response) {
                    var data = response.data || {};
                    if (data.isSuccess)
                        $scope.hideModal();
                }),
                function() {
                    //				$window.alert('error');			
                    $window.alert('Error while Submit Delegate Action!');
                };
        }

        /**
         * check the Doc Title validation as platform
         */

        //docref validation keys
        var drtValidationKeys = ["ptitle", "pfacility", "dtitle", "dscope", "dnote", "number", "rev", "comment"];

        var customValidations = function() {
            var isValid = true;
            for (var v = 0; v < drtValidationKeys.length; v++) {
                var key = drtValidationKeys[v];
                if ($scope.item && typeof $scope.item === "object" && $scope.item[key]) {
                    var customRegx = "";
                    if (key === 'dtitle') {
                        customRegx = /"|&|#|;|\x7C|<|>|%|\\|\||\^|\/|~|\*|—/; // allow question mark
                    }
                    isValid = drtValidationKeysMethod($scope.item[key], customRegx);
                }

                if ($scope.subitem && typeof $scope.subitem === "object" && $scope.subitem[key] && isValid) {
                    isValid = drtValidationKeysMethod($scope.subitem[key]);
                }

                if ($scope.stg && typeof $scope.stg === "object" && $scope.stg[key] && isValid) {
                    isValid = drtValidationKeysMethod($scope.stg[key]);
                }

                if ($scope.substg && typeof $scope.substg === "object" && $scope.substg[key] && isValid) {
                    isValid = drtValidationKeysMethod($scope.substg[key]);
                }

                if ($scope.upload && typeof $scope.upload === "object" && $scope.upload[key] && isValid) {
                    isValid = drtValidationKeysMethod($scope.upload[key]);
                }

                if (!isValid)
                    break;
            }

            return isValid;
        };

        var drtValidationKeysMethod = function(value, regx) {
            var regx = regx || /"|&|#|;|\x3F|\x7C|<|>|%|\\|\||\^|\/|~|\*|—/; // :| : removed.
            value = value.trim().replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();

            if (regx.test(value)) {
                $window.alert('Invalid characters entered. Characters(#), HTML Tags or any character with ASCII value less than 32 are not allowed.');
                return false;
            }

            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32) {
                    $window.alert('Invalid characters entered. Characters(#), HTML Tags or any character with ASCII value less than 32 are not allowed.');
                    return false;
                }
            }

            var invalidStringArray = ['#', 'onmouseover=', 'javas&#99;ript', 'javascript:', '<script', '</script>', 'vbscript:', 'livescript:', '<s&#99;ript>', '<img', 'onload=',
                '<input', '<select', '<textarea', '<form', '<head', '<body', '<html', 'datasrc=', '<iframe', 'text/javascript', 'eval(', 'expression(',
                'url(', '&{[', 'alert(', '\x3cscript', 'javascript#', '<meta', '%3cscript', 'document.cookie', 'window.location', '<EMBED', '</EMBED>','window.open(','alert=','onclick='
            ];
            for (var i = 0; i < invalidStringArray.length; i++) {
                if (value.indexOf(invalidStringArray[i]) != -1) {
                    $window.alert('Invalid characters entered. Characters(#), HTML Tags or any character with ASCII value less than 32 are not allowed.');
                    return false;
                }
            }

            return true;
        };

        var isDTitleValid = function() {
            if (!$scope.item.dtitle) {
                $window.alert('Please select mandatory fields!');
                return false;
            }

            var dtitle = addCodePrefix($scope.item.dtitle, $scope.item.dref);
            for (var i = 0; i < $scope.data.section.length; i++) {
                var section = $scope.data.section[i];
                for (var j = 0; j < section.deliverable.length; j++) {
                    if (section.deliverable[j].dtitle == dtitle) {
                        $window.alert('Description must be unique!');
                        return false;
                    }
                }
            }

            return true;
        };

        // map modal id against type to save in db
        var dbMap = {
            itemdeliverables: "Deliverable",
            stagedeliverables: "DeliverableStage",
            findReplace: "DeliverableStage",
            deliverablecomment: "DeliverableComments",
            stagecomment: "DeliverableStageComments",
            subitemdeliverables: "DeliverableItem",
            folderselection: "DeliverableItem",
            subitemstage: "StageItem",
            uploaddocument: "StageItem",
            mapCDE: "StageItem",
            stagemanagement: "PLQStage",
            stage: "StageQuestions"
        };

        var removeHasing = function(obj, keys) {
            if (!angular.isArray(keys)) {
                keys = [keys];
            }

            for (var i = 0; i < keys.length; i++) {
                var k = keys[i];
                var val = obj[k];
                if (val && (typeof val == 'string')) {
                    obj[k] = val.split('$$')[0];
                }
            }
        }

        var updateInDB = function(data, type, operation, callback) {
            if (!isChildForm) {
                saveFormData(callback);
                return;
            }

            data = angular.copy(data);
            if (!angular.isArray(data)) {
                data = [data];
            }
            for (var i = 0; i < data.length; i++) {
                var item = data[i];
                if (item.stage)
                    delete item.stage;
                if (item.sub_items)
                    delete item.sub_items;
                if (item.comments)
                    delete item.comments;
                if (item.questions)
                    delete item.questions;
                if (angular.isArray(item.deliverables))
                    item.deliverables = item.deliverables.join(',');

                setLowLevelData(item, 'lastModifier');
                setLowLevelData(item, 'originator');
                setLowLevelData(item, 'author', 'author_');
                setLowLevelData(item, 'folder', '', ['folderId']);
                setLowLevelData(item, 'attrs', 'attrs_');

                removeHasing(item, ['folderId', 'revisionId', 'documentId']);
            }

            var json = { root: {} };
            json.root[type] = data;

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/manageIDPData",
                method: 'post',
                withCredentials: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: "projectId=" + projectId + '&msgId=' + $('#msgId').val() + '&entityName=' + type + '&operation=' + operation + '&jsonData=' + encodeURIComponent(angular.toJson(json))
            }).then(function(response) {
                if (response.data && !response.data.isSuccess) {
                    $window.alert(response.data.msg);
                }
                callback && callback(response);
            }, function() {
                // $window.alert('error');
            });
        };

        /**
         * apply changes on update click
         */
        $scope.updateRecord = function(skipPH, isCallDelegateAction) {
            if (ctrl.model.modelId == "folderselection") {
                if (!$scope.data.config.folderPath) {
                    if (!$scope.folder.defSelection) {
                        $window.alert('Please select folder!');
                        return;
                    } else if ([3, 4, 6].indexOf($scope.folder.defSelection.permissionValue) == -1) {
                        $window.alert("You do not have permission to create Deliverable Item over folder " + $scope.data.config.folderPath);
                        return;
                    }
                }

                $scope.data.folder = $scope.folder.defSelection;

                updateSubItemFolder(null, true);

                saveFormData();

                $scope.hideModal();
                return;
            }

            if (ctrl.model.modelId == 'uploaddocument' && !skipPH) {
                if (!$scope.upload.poi || !$scope.upload.rev) {
                    $window.alert('Please select mandatory fields!');
                    return;
                }

                if (!$scope.upload.status) {
                    alert('Default Status (' + $scope.data.config.defaultStatus + ') is not found.');
                    return;
                }

                uploadDocument($scope.subitem, $scope.substg, function() { $scope.updateRecord(true); });
                return;
            }

            if (ctrl.model.modelId == "projectdetails") {
                if (!$scope.item.pref || !$scope.item.ptitle || !$scope.item.pfacility || !$scope.item.region || !$scope.item.status) {
                    $window.alert('Please select mandatory fields!');
                    return;
                }
            }

            if (ctrl.model.modelId == "findReplace") {
                if (!$scope.validateFindReplace()) {
                    return;
                }

                getServerTime(function(date) {
                    updateFindReplace(date);
                });
            }

            var isNew = false;
            if (ctrl.model.modelId == 'deliverablecomment' && $scope.backup.subitem.isNewAddItem) {
                isNew = true;
                delete $scope.backup.subitem.isNewAddItem;
                delete $scope.subitem.isNewAddItem;
                $scope.backup.item.comments.push($scope.backup.subitem);
                var dbType = dbMap[ctrl.model.modelId];
                var subitemObj = $scope.subitem;
                updateInDB(subitemObj, dbType, 'Insert');
            }
            if (ctrl.model.modelId == 'subitemdeliverables') {
                if ($scope.subitem.uploaded) {
                    return;
                }
                if (!$scope.subitem.folder || !$scope.subitem.folder.folderId) {
                    $window.alert('Please select folder!');
                    return;
                } else if ([3, 4, 6].indexOf($scope.subitem.folder.permissionValue) == -1) {
                    $window.alert("You do not have permission to create Deliverable Item over folder " + $scope.subitem.folder.folderTitle);
                    return;
                }
                if (!$scope.subitem.dtitle ||
                    !$scope.subitem.location ||
                    !$scope.subitem.volume ||
                    !$scope.subitem.file_type ||
                    !$scope.subitem.role ||
                    !$scope.subitem.number) {
                    $window.alert('Please select mandatory fields!');
                    return;
                } else if (isDuplicateNumber($scope.subitem)) {
                    $window.alert('Same Deliverable Item already exist');
                    return;
                } else if ($scope.backup.subitem.isNewAddItem && !skipPH) {
                    isNew = true;
                    $scope.subitem.folder && (delete $scope.subitem.folder.childFolders);
                    delete $scope.backup.subitem.isNewAddItem;
                    delete $scope.subitem.isNewAddItem;
                    //check if subitem id already exists, then remove previous and add updated item
                    $scope.backup.item.sub_items = $scope.backup.item.sub_items.filter(function(el) {
                        return el.id !== $scope.backup.subitem.id;
                    });

                    $scope.backup.item.sub_items.push($scope.backup.subitem);
                    var dbType = dbMap[ctrl.model.modelId];
                    var subitemObj = $scope.subitem;
                    updateInDB(subitemObj, dbType, 'Insert');
                }
            } else if (ctrl.model.modelId == 'subitemstage') {
                var user = $scope.substg.author;
                if ($scope.substg.freeze || ($scope.data.config.placeholder && $scope.substg.uploaded) || (!skipPH && !isStageItemValid((user || {}).hUserID, $scope.substg))) {
                    return;
                }
            }

            // custom validation method called here like "docTitleValidationKeys:.
            if (!customValidations()) {
                return;
            }

            if (ctrl.model.modelId == 'itemdeliverables') {
                var itemDtitle = addCodePrefix($scope.item.dtitle, $scope.item.dref);
                if (itemDtitle != $scope.backup.item.dtitle) {
                    if (!isDTitleValid()) {
                        return;
                    }

                    manageAttributes('EDIT', [{
                        attributeName: $scope.data.config.attributes['DeliverableReference'],
                        inputTypeId: customDropdownAttrType,
                        inputValueList: [{
                            value: $scope.item.dref,
                            defaultName: itemDtitle,
                            oldValue: $scope.backup.item.dref,
                            oldDefaultName: $scope.backup.item.dtitle
                        }]
                    }]);
                }
                $scope.item.dtitle = itemDtitle;
            }

            if ($scope.data.config.placeholder && !skipPH) {
                if (ctrl.model.modelId == 'subitemstage') {
                    if (!isPhInOtherStage()) {
                        if (!$scope.backup.substg.revisionId) {
                            createPlaceholder($scope.subitem, $scope.substg, true, placeholderSuccess);
                            return;
                        } else if (!$scope.backup.substg.freeze && !$scope.backup.substg.uploaded && $scope.backup.substg.rag != 'Green') {

                            var stgno = $scope.substg.stgno - 1;
                            var hasPHinPrevStg = false;
                            if (stgno > 0) {
                                for (var i = stgno; i >= 0; i--) {
                                    var prevStg = $scope.subitem.stage[i];
                                    if (prevStg.revisionId) {
                                        hasPHinPrevStg = true;
                                        break;
                                    }
                                }
                            }

                            if (hasPHinPrevStg && $scope.substg.author.orgCode !== $scope.backup.substg.author.orgCode) {
                                activeDeactivatePH($scope.substg, false, null, null, null, true);
                                createPlaceholder($scope.subitem, $scope.substg, true, placeholderSuccess);
                            } else {
                                updatePlaceholder($scope.subitem, $scope.backup.subitem, $scope.substg, $scope.backup.substg, placeholderSuccess);
                            }
                            return;
                        }
                    }
                } else if (!isNew && ctrl.model.modelId == 'subitemdeliverables') {
                    updateMultiPlaceholder($scope.subitem, $scope.backup.subitem, placeholderSuccess);
                    return;
                }
            }

            if (angular.isObject($scope.backup.item) && angular.isObject($scope.item)) {
                delete $scope.item.sub_items;
                angular.merge($scope.backup.item, $scope.item);
            }

            var isUploadedInItem;
            if (angular.isObject($scope.backup.subitem) && angular.isObject($scope.subitem)) {
                isUploadedInItem = $scope.backup.subitem.uploaded != $scope.subitem.uploaded;
                delete $scope.subitem.stage;
                angular.merge($scope.backup.subitem, $scope.subitem);
            }

            var modalId = ctrl.model.modelId;
            setStageHistory(function() {
                if (angular.isObject($scope.backup.stg) && angular.isObject($scope.stg)) {
                    angular.merge($scope.backup.stg, $scope.stg);
                }

                if (angular.isObject($scope.backup.substg) && angular.isObject($scope.substg)) {
                    angular.merge($scope.backup.substg, $scope.substg);
                }

                if (ctrl.model.modelId == "stage" && $scope.pstg) {
                    if ($scope.pstg.questions && $scope.pstg.questions.length) {
                        for (var i = 0; i < $scope.pstg.questions.length; i++) {
                            $scope.pstg.questions[i].editing && cancelEditRow($scope.pstg.questions[i]);
                        }
                    }

                    $scope.backup.pstg.questions = $scope.pstg.questions;
                    angular.merge($scope.backup.pstg, $scope.pstg);
                }

                if (ctrl.model.modelId == "stagedeliverables") {
                    updateSubRag();
                }

                if ($scope.item && $scope.backup.stg && $scope.pstg) {
                    $scope.updateMask($scope.item, $scope.backup.stg, $scope.pstg);
                    if (!$scope.backup.stg.role) {
                        $scope.backup.stg.file_mask = "";
                        if (!$scope.backup.stg.dnote && !$scope.backup.stg.lod) {
                            delete $scope.backup.stg.lastModifier;
                            delete $scope.backup.stg.modifiedOn;
                        }
                    }
                }

                if ($scope.subitem && $scope.backup.substg && $scope.pstg)
                    $scope.updateSubMask($scope.stg, $scope.subitem, $scope.backup.substg, $scope.pstg);

                if (ctrl.model.modelId == "itemdeliverables" && $scope.backup.item) {
                    for (var i = 0; i < $scope.backup.item.stage.length; i++) {
                        var stge = $scope.backup.item.stage[i];
                        var pstge = $scope.data.programme.pstage[i];
                        $scope.updateMask($scope.backup.item, stge, pstge);
                    }
                } else if (ctrl.model.modelId == "subitemdeliverables" && $scope.backup.subitem) {
                    for (var i = 0; i < $scope.backup.subitem.stage.length; i++) {
                        var stge = $scope.backup.subitem.stage[i];
                        var pstge = $scope.data.programme.pstage[i];
                        $scope.updateSubMask($scope.backup.stg, $scope.backup.subitem, stge, pstge);
                        var foldrId = $scope.subitem.folder && $scope.subitem.folder.folderId || "";
                        stge.folderId = foldrId;
                        var foldrTtl = $scope.subitem.folder && $scope.subitem.folder.folderTitle || "";
                        stge.folderTitle = foldrTtl;
                    }
                    updateInDB($scope.backup.subitem.stage, dbMap.subitemstage, 'Update');
                }

                if (isChildForm) {
                    var dbType = dbMap[modalId];
                    switch (modalId) {
                        case 'itemdeliverables':
                            updateInDB($scope.backup.item, dbType, 'Update');
                            break;
                        case 'stagedeliverables':
                            updateInDB($scope.backup.stg, dbType, 'Update');
                            break;
                        case 'deliverablecomment':
                            if (!isNew) {
                                updateInDB($scope.backup.subitem, dbType, 'Update');
                            }
                            break;
                        case 'stagecomment':
                            updateInDB($scope.backup.substg, dbType, 'Update');
                            break;
                        case 'subitemdeliverables':
                            if (!isNew) {
                                updateInDB($scope.backup.subitem, dbType, 'Update');
                            }
                            break;
                        case 'subitemstage':
                            updateInDB($scope.backup.substg, dbType, 'Update', function() {
                                $scope.refreshCOBie([{ id: $scope.backup.substg.stgno }], true);
                            });
                            break;
                        case 'uploaddocument':
                            if (isUploadedInItem) {
                                updateInDB($scope.backup.subitem, dbType, 'Update');
                            }
                            updateInDB($scope.backup.substg, dbType, 'Update');
                            break;
                        case 'stagemanagement':
                            updateInDB($scope.backup.stg, dbType, 'Update', function() {
                                $scope.refreshCOBie($scope.backup.stg, true);
                            });
                            break;
                        case 'stage':
                            break;
                        default:
                            // update data on server
                            saveFormData();
                            break;
                    }
                } else {
                    saveFormData();
                }

                if (isCallDelegateAction) {
                    return; //Do not close the modal before submitDelegateAction callback response
                }

                $scope.updateFilterValues(ctrl.model.modelId);
                $scope.hideModal();
            });
        };

        $scope.updateFilterValues = function(modelId) {
            if (modelId == "deliverablecomment") {
                var orgCode = $scope.subitem.supplier;
                if ($scope.showComment.indexOf(orgCode) == -1) {
                    $scope.showComment.push(orgCode);
                }
                var optionsData = $scope.commentsListData && $scope.commentsListData[0] && $scope.commentsListData[0].options || [];
                var hasOrg = commonApi._.findWhere(optionsData, { modelValue: orgCode });
                if (hasOrg) {
                    hasOrg.checked = true
                } else {
                    $scope.commentsListData[0].options.push({
                        displayValue: orgCode + " : " + $scope.subitem.supplierName,
                        modelValue: orgCode,
                        checked: true
                    });
                }
            } else if (modelId == "subitemstage") {
                var orgCode = $scope.substg && $scope.substg.author && $scope.substg.author.orgCode || "";
                if (!orgCode)
                    return
                if ($scope.showItem.indexOf(orgCode) == -1) {
                    $scope.showItem.push(orgCode);
                }
                var optionsData = $scope.itemListData && $scope.itemListData[0] && $scope.itemListData[0].options || [];
                var hasOrg = commonApi._.findWhere(optionsData, { modelValue: orgCode });
                if (hasOrg) {
                    hasOrg.checked = true
                } else {
                    var orgData = commonApi._.findWhere($scope.orgList, { code: orgCode });
                    var orgName = orgData.name;
                    $scope.itemListData[0].options.push({
                        displayValue: orgCode + " : " + orgName,
                        modelValue: orgCode,
                        checked: true
                    });
                }
            } else if (modelId == "stagedeliverables") {
                //Check for Roles Filter
                var orgCode = $scope.stg.role;
                if ($scope.filterRole.indexOf(orgCode) == -1) {
                    $scope.filterRole.push(orgCode);
                }
                var optionsData = $scope.filterRoleListData && $scope.filterRoleListData[0] && $scope.filterRoleListData[0].options || [];
                var hasOrg = commonApi._.findWhere(optionsData, { modelValue: orgCode });
                if (hasOrg) {
                    hasOrg.checked = true
                } else {
                    $scope.filterRoleListData[0].options.push({
                        displayValue: orgCode + " : " + $scope.stg.roleName,
                        modelValue: orgCode,
                        checked: true
                    });
                }

                //Check for LODs filter
                var lodCode = $scope.stg.lod;
                if ($scope.filterLOD.indexOf(lodCode) == -1) {
                    $scope.filterLOD.push(lodCode);
                }
                var optionsData = $scope.filterLODListData && $scope.filterLODListData[0] && $scope.filterLODListData[0].options || [];
                var hasLOD = commonApi._.findWhere(optionsData, { modelValue: lodCode });
                if (hasLOD) {
                    hasLOD.checked = true
                } else {
                    $scope.filterLODListData[0].options.push({
                        displayValue: lodCode + " : " + $scope.stg.lodName,
                        modelValue: lodCode,
                        checked: true
                    });
                }
            }
        }

        $scope.moveto = {
            selected: '',
            list: []
        };
        var populateMoveTo = function(item, subitem, stg, substg) {
            if ($scope.data.config.placeholder) {
                return;
            }
            $scope.moveto.list = [];
            $scope.moveto.selected = '';
            for (var i = 0; i < $scope.data.programme.pstage.length; i++) {
                var pstg = $scope.data.programme.pstage[i];
                if (substg.stgno == pstg.id || !subitem.stage[i].author || !subitem.stage[i].author.orgCode || stg.role != item.stage[i].role) {
                    continue;
                }

                $scope.moveto.list.push({
                    id: pstg.id,
                    title: pstg.stageRef + ': ' + pstg.stageTitle
                });
            }
        };

        var onMoveSelect = function() {
            var currentStage = angular.copy($scope.backup.substg);
            var targetStage = angular.copy($scope.backup.subitem.stage[$scope.moveto.selected]);
            var targetDstage = $scope.item.stage[$scope.moveto.selected];
            var targetPstage = $scope.data.programme.pstage[$scope.moveto.selected];

            // var targetRevId = targetStage.revisionId;
            // var targetDocId = targetStage.documentId;
            var revId = currentStage.revisionId;
            targetStage.file_link = currentStage.file_link;
            targetStage.fileName = currentStage.fileName;
            targetStage.uploaded = true;
            targetStage.isPlaceholder = false;
            targetStage.isFileUploaded = false;
            targetStage.documentId = currentStage.documentId;
            targetStage.revisionId = currentStage.revisionId;
            $scope.updateSubMask(targetDstage, $scope.subitem, targetStage, targetPstage);

            currentStage.file_link = "";
            currentStage.fileName = "";
            currentStage.rag = "AOK";
            currentStage.uploaded = false;
            currentStage.isPlaceholder = false;
            currentStage.isFileUploaded = false;
            currentStage.documentId = "";
            currentStage.revisionId = "";
            currentStage.poiStatus = "";
            currentStage.rev_num = "";
            $scope.updateSubMask($scope.stg, $scope.subitem, currentStage, $scope.pstg);

            var hashedFolderId = $scope.subitem.folder.folderId;
            var f = findFolder($scope.folder.list, hashedFolderId);
            if (f) {
                hashedFolderId = f.folderId;
            }

            getDocsByDocRef({
                folderId: hashedFolderId,
                docRef: currentStage.attrs.DocRef
            }, function(files) {
                var revFound = false;
                for (var i = 0; i < files.length; i++) {
                    var f = files[i];
                    if (f.RevisionId == revId || f.RevisionId.split('$$')[0] == revId) {
                        revFound = true;
                        if (!f.DocStatusId) {
                            var statusList = $scope.upload.statusList,
                                statusId = "999";
                            if (statusList && statusList.length) {
                                statusId = (commonApi._.findWhere(statusList, { defaultName: f.DocStatus }) || {}).value || "";
                            }
                            f.DocStatusId = statusId;
                        }
                        $scope.xhr.multiPH.push(true);
                        lockEditAttributes(f.RevisionId, false, function() {
                            $scope.xhr.multiPH.pop();
                            updatePlaceholder($scope.subitem, $scope.backup.subitem, targetStage, currentStage, function(data) {
                                // merge data into form json
                                angular.merge($scope.backup.substg, currentStage);
                                angular.merge($scope.backup.subitem.stage[$scope.moveto.selected], targetStage);

                                // update both stage in DB
                                var targetCompleted = false,
                                    currentCompleted = false;
                                var onComplete = function() {
                                    targetCompleted && currentCompleted && $scope.refreshCOBie([{ id: targetStage.stgno }, { id: currentStage.stgno }], true);
                                };
                                updateInDB(targetStage, dbMap.subitemstage, 'Update', function() {
                                    targetCompleted = true;
                                    onComplete();
                                });
                                updateInDB(currentStage, dbMap.subitemstage, 'Update', function() {
                                    currentCompleted = true;
                                    onComplete();
                                });

                                // clear action for target revision
                                // if(targetRevId) {
                                // 	clearDocActions(targetRevId, targetDocId);
                                // }

                                // lock the current revision
                                lockEditAttributes(f.RevisionId, true);

                                $scope.hideModal();
                            }, null, f);
                        });
                        break;
                    }
                }
                if (!revFound) {
                    $window.alert('It seems that you have tried to perform an operation that is not valid for the current state of this object.');
                }
            });
        };

        $scope.onMoveChange = function() {
            setTimeout(function() {
                if (!window.confirm('Are you sure you want to move file from this item?')) {
                    $scope.moveto.selected = "";
                    return;
                }

                onMoveSelect();
            }, 0);
        };

        var clearDocActions = function(revisionid, documentId) {
            var documentDetails = {
                docId: documentId.split('$$')[0],
                revisionType: 4,
                revId: revisionid.split('$$')[0],
                apppliedActions: 14,
                userTypeId: $window.USP.userTypeId,
                typeName: 'IDP'
            };
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/clearDocumentActions",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&documentDetails=" + encodeURIComponent(angular.toJson(documentDetails))
            }).then(function(response) {

            }, function(xhr) {
                if (xhr.status != -1) {
                    $window.alert("ERROR");
                }
            });
        };

        /**
         * open the specific modal dialog
         * @param {number} id
         * @param {object} item
         * @param {object} subitem
         * @param {object} stage
         * @param {object} substg
         * @param {object} pstage
         */
        var prevModalId = undefined;
        var prevModalBackup = undefined;
        var prevModalCurrentData = {
            filledData: {},
            type: undefined
        };

        $scope.showModal = function(id, item, subitem, stage, substg, pstage, prevModal) {
            if ($scope.isPrintView || $scope.xhr.verify || (id == "subitemstage" && substg.locked)) {
                return;
            }

            $scope.hideModal();
            prevModalId = prevModal;
            if (prevModal) {
                prevModalBackup = $scope.backup;
            }

            if (id == "subitemstage" && substg.freeze) { // if stage is freezed due to placeholder creation in next stages
                return;
            }
            if ($scope.user.roles.indexOf('TM') > -1 && $scope.user.roles.indexOf('EPM') == -1 && (id == "stagemanagement" || id == "stagedeliverables" || id == "stagedeliverables")) {
                return;
            }

            if ((!$scope.user.org && (!$scope.data.config.freeStageItem || (id !== 'subitemstage' && id !== 'uploaddocument' && id !== 'itemdeliverables' && id !== 'subitemdeliverables' && id !== "manageAttributes" && id !== 'mapCDE'))) ||
                ($scope.user.roles.indexOf('EPM') == -1 && $scope.user.roles.indexOf('SIM') == -1 && $scope.user.roles.indexOf('SUP') == -1 &&
                    $scope.user.roles.indexOf('OTH') > -1 && id !== "projectdetails" && id !== "stagemanagement") || // if other supplier tries to open open other than project detail and stage management
                (id === "subitemstage" && $scope.user.roles.indexOf('EPM') == -1 &&
                    (!stage.role ||
                        (($scope.data.config.placeholder || !substg.author) && ($scope.user.usp.orgID != subitem.originator.orgID ||
                                (!$scope.data.config.freeStageItem && $scope.user.org != stage.role)) &&
                            (!substg.author || substg.author.hUserID != $scope.user.usp.userID))))) { // if supplier tries to open stage popup
                return;
            }



            if (id != "projectdetails" && id != "manageAttributes" && (!$scope.data.pref || !$scope.data.ptitle)) {
                $scope.showModal("projectdetails");
                return;
            }

            // apply data on modal
            if (prevModal == 'projectdetails') {
                prevModalCurrentData.filledData.item = $scope.item;
            }

            $scope.item = angular.copy(item);
            if (id == 'itemdeliverables' && $scope.item && $scope.item.dtitle && $scope.item.dtitle.indexOf($scope.item.dref + ' ') == 0) {
                $scope.item.dtitle = $scope.item.dtitle.replace($scope.item.dref + ' ', '');
            }

            if (id == "stage") {
                commonApi._.each(pstage.questions, function(p) {
                    removeOldPLQ(p);
                });
                getDeliverablesForPlqs($scope.newqCopy);
                $scope.newq = angular.copy($scope.newqCopy);
            }

            if (id != 'itemdeliverables') {
                if (prevModal == 'subitemdeliverables') {
                    prevModalCurrentData.filledData.subitem = $scope.subitem;
                }

                $scope.subitem = angular.copy(subitem);

                // preserve the filled data after location or volume edit
                if (!prevModal) {
                    if (prevModalCurrentData.filledData.item) {
                        $scope.item = prevModalCurrentData.filledData.item;
                        if (prevModalCurrentData.type == 'Region') {
                            $scope.item.region = item.region;
                            $scope.item.regionName = item.regionName;
                        }
                    } else if (prevModalCurrentData.filledData.subitem) {
                        $scope.subitem = prevModalCurrentData.filledData.subitem;
                        if (prevModalCurrentData.type == 'Volume') {
                            $scope.subitem.volume = subitem.volume;
                            $scope.subitem.volumeName = subitem.volumeName;
                        } else if (prevModalCurrentData.type == 'Location') {
                            $scope.subitem.location = subitem.location;
                            $scope.subitem.locationName = subitem.locationName;
                        }
                    }
                    prevModalCurrentData.filledData = {};
                    prevModalCurrentData.type = undefined;
                }

                $scope.stg = angular.copy(stage);
                $scope.substg = angular.copy(substg);
                $scope.pstg = angular.copy(pstage);
            }

            if (id == 'itemdeliverables') {
                $scope.idx = subitem;
                $scope.deliverableArray = stage;
                $scope.item.hasAttachement = hasDocInDel($scope.item);
            } else if (id == 'subitemdeliverables' || id == 'deliverablecomment') {
                $scope.idx = stage;
            }

            if (!$scope.readOnly && id == 'deliverablecomment' && !$scope.subitem.supplier) {
                $scope.subitem.supplier = $scope.user.org;
                $scope.onSupplierChange($scope.subitem);
            }

            // backup the original data
            $scope.backup = {
                item: item,
                subitem: subitem,
                stg: stage,
                substg: substg,
                pstg: pstage
            };

            // make mockup object for project detail for popup
            if (id == "projectdetails") {
                $scope.regionList = commonApi._.sortBy($scope.regionList, function(o) { return o.code; });
                if (!item) {
                    $scope.item = {
                        pref: $scope.data.pref,
                        ptitle: $scope.data.ptitle,
                        pfacility: $scope.data.pfacility,
                        ptemplate: $scope.data.ptemplate,
                        pmanager: $scope.data.pmanager,
                        region: $scope.data.region + "",
                        regionName: $scope.data.regionName + "",
                        status: $scope.data.status + "",
                        statusName: $scope.data.statusName + "",
                        ORI_FORMTITLE: $scope.data.ORI_FORMTITLE || "Information Delivery Plan"
                    };

                    $scope.backup.item = $scope.data;
                }
            }

            // inherit the parent role and lod
            if (!$scope.readOnly) {
                if (id == 'subitemstage') {
                    if (!$scope.substg.role) {
                        if($scope.user.org) {
                            $scope.substg.role = $scope.user.usp.userID;
                        }
                        $scope.substg.dueDate = (new Date() > new Date(commonApi.parseDate("dd-M-yy", $scope.pstg.stageEnd))) ? getCurrentDate() : $scope.pstg.stageEnd;

                        $scope.onAuthorChange($scope.substg);
                    }

                    if (!$scope.substg.lod) {
                        $scope.substg.lod = $scope.stg.lod;
                        $scope.onSubStgLODChange($scope.substg);
                    }

                    getDocrefAndAttributes($scope.subitem.folder, id);

                    bindUploadEvents();

                    populateMoveTo($scope.backup.item, $scope.backup.subitem, $scope.backup.stg, $scope.backup.substg);
                } else if (id == 'subitemdeliverables') {
                    getDocrefAndAttributes($scope.subitem.folder);
                }
            }

            if (!$scope.readOnly && id == 'stagedeliverables' && $scope.user.roles.indexOf('EPM') > -1) {
                if (!$scope.stg.role) {
                    $scope.stg.role = $scope.pstg.projInfoMan;
                    $scope.onSupplierRoleChange($scope.stg);
                }

                if (!$scope.stg.lod) {
                    $scope.stg.lod = $scope.pstg.lod;
                    $scope.onLODChange($scope.stg);
                }
            }

            if (!$scope.readOnly && id == 'findReplace' && $scope.user.roles.indexOf('EPM') > -1) {
                $scope.findReplace = {
                    supplierFilterStage: "",
                    existingRole: "",
                    existingFilterRoleOptions: [],
                    existingRoleCount: 0,
                    showValidation: false,
                    uniqueCounts: {},
                    newRole: ""
                };
                $scope.existingFilterRoleOptionsData = [];
                $scope.isSupplierFilterStage = false;
            }

            if (!$scope.readOnly && id == 'mapCDE') {
                $scope.folder.selectedForListing = $scope.data.folder;
                $scope.listingData.allItem = [];
                loadListing();
            }

            if (!$scope.readOnly && id == 'manageAttributes') {
                prevModalCurrentData.type = item;
                populateEntity(item);
            }

            if (id == 'subitemstage' || id == 'uploaddocument') {
                $scope.getPreviousRevisionDetails();
            }
            $scope.checkModalPopupForSingeValueDropdown(id);

            // show modal
            ctrl.model.modelId = id;
        };

        /**
         * close the modal dialog
         */
        $scope.hideModal = function() {
            if (prevModalId) {
                var modalId = prevModalId;
                var modalBackup = prevModalBackup;
                prevModalBackup = undefined;
                prevModalId = undefined;

                // special case : show stage modal after sub item stage modal hides
                if (modalId == 'stage') {
                    $scope.showModal('stage', null, null, null, null, $scope.backup.pstg);
                } else if (modalBackup) {
                    $scope.showModal(modalId, modalBackup.item, modalBackup.subitem, modalBackup.stg, modalBackup.substg, modalBackup.pstg);
                }

            } else {
                ctrl.model.modelId = "";
                resetAllEntity();
            }
        };

        function fetchUserList(role, callback) {
            var role = getRoleMap()[role];
            if (!role)
                return;

            // prepare roles for ajax call
            var epmRoles = role.split(',');
            var rolArgs = "";
            for (var i = 0; i < epmRoles.length; i++) {
                rolArgs += '&roleNames=' + encodeURIComponent(epmRoles[i]);
            }

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/usersByRoleName",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + rolArgs
            }).then(function(response) {
                var list = response.data || {};
                list = list.dataList || list || [];
                callback && callback(list);
            }, function() {
                //				$window.alert('error');
            });
        }

        // fetch user with Project manager based roles
        $scope.userList = undefined;

        function loadEpmList() {
            fetchUserList('EPM', function(list) {
                $scope.userList = list || [];
                var users = [];

                for (var i = 0; i < $scope.userList.length; i++) {
                    var u = $scope.userList[i];
                    users.push(u.username);
                }

                $scope.data.pmanager = users.join(', ');
            });
        }

        // fetch user with Template manager based roles
        var epmEmails = [];

        function loadTMList() {
            fetchUserList('TM', function(list) {
                epmEmails = list || [];
            });
        }

        $scope.sendSectionReqTM = function(section) {
            if($scope.user.roles.indexOf('TM') > -1) {
                $scope.addRow(null, section.deliverable, section, true);
                return;
            }
            var mailToStr = "mailto:";
            var subjectStr = "?subject=Add Section Deliverable [" + section.seref + "]";
            var extraLen = mailToStr.length + subjectStr.length;
            var emails = "";
            var emailList = [];

            for (var i = 0; i < epmEmails.length; i++) {
                var user = epmEmails[i];
                emails += user.email + ';';
                if ((emails.length + extraLen) > 2040) { // too long url not supported.
                    break;
                }
                emailList.push(user.email);
            }

            mailToStr += emailList.join(';') + subjectStr;
            if (commonApi.isIE()) {
                angular.element("body").append('<iframe id="iframeTempMailTo" src="' + mailToStr + '" width="0" height="0" >');
                angular.element("#iframeTempMailTo").remove();
            } else {
                window.location.href = mailToStr;
            }
        }

        $scope.newqCopy = {
            "PLQStage_ID": "",
            "note": "",
            "qno": "",
            "question": "",
            "_name": "",
            "answered": "",
            "_stage": "",
            "deliverables": [],
            "deliverableData": []
        };

        var updatePLQData = function(data) {
            if(!$scope.pstg.questions) {
                $scope.pstg.questions = [];
            }
            if(data) {
                $scope.newq.StageQuestions_ID = data.response;
            }
            $scope.pstg.questions.push($scope.newq);
            $scope.newq = angular.copy($scope.newqCopy);
            $scope.backup.pstg.questions = $scope.pstg.questions;

            $timeout(function() {
                var $body = angular.element('.m-body');
                if($body && $body.length) {
                    $body.scrollTop($body[0].scrollHeight)
                }
            }, 100);
        };
        
        $scope.addQuestion = function() {
            if($scope.user.roles.indexOf('TM') > -1) {
                $scope.newq.PLQStage_ID = $scope.pstg.PLQStage_ID;
                $scope.newq._stage = $scope.pstg.id;
                
                if(isChildForm) {
                    $scope.saveRow($scope.newq, true, function(r) {
                        if(r.data && r.data.isSuccess) {
                            updatePLQData(r.data);
                        }
                    });
                } else {
                    updatePLQData();
                    $scope.xhr.multiPH.push('true');
                    saveFormData(function() {
                        $scope.xhr.multiPH.pop();
                        callback && callback();
                    });
                }
            }
        };

        $scope.saveRow = function(item, isNew, callback) {
            var qRegx = /"|&|#|;|\x7C|<|>|%|\||\^|~|\*|—/;
            if($scope.user.roles.indexOf('TM') > -1) {
                if(!item._name || !item.qno || !item.question) {
                    $window.alert('Please select mandatory fields!');
                    return false;
                }
                
                if(!drtValidationKeysMethod(item._name, qRegx) || 
                   !drtValidationKeysMethod(item.qno, qRegx) ||
                   !drtValidationKeysMethod(item.question, qRegx)) {
                    return false;
                }
            }

            if (!drtValidationKeysMethod(item.note, qRegx)) {
                return false;
            }

            removeOldPLQ(item);
            $scope.xhr.multiPH.push('true');
            updateInDB(item, dbMap['stage'], isNew ? 'Insert' : 'Update', function(response) {
                $scope.xhr.multiPH.pop();
                callback && callback(response);
            });
            return true;
        };

        var getDeliverablesForPlqs = function(item) {
            item.deliverableData = [];
            for (var i = 0; i < $scope.data.section.length; i++) {
                var section = $scope.data.section[i];
                var optionsArr = [];
                for (var j = 0; j < section.deliverable.length; j++) {
                    optionsArr.push({
                        displayValue: section.deliverable[j].dref + " : " + section.deliverable[j].dtitle,
                        modelValue: section.deliverable[j].dref,
                        checked: (item.deliverables.indexOf(section.deliverable[j].dref) > -1)
                    });
                }
                item.deliverableData.push({
                    optlabel: section.seref + " : " + section.setitle,
                    options: optionsArr
                });
            }
        }

        $scope.editRow = function(item) {
            item.oldData = angular.copy(item);
            item.editing = true;
            getDeliverablesForPlqs(item);
        };

        $scope.deleteRow = function(item) {
            if($scope.user.roles.indexOf('TM') > -1 && window.confirm('Question will be removed with its answer. Are you sure you want to delete this Question?')) {
                var index = $scope.pstg.questions.indexOf(item);
                $scope.pstg.questions.splice(index, 1);
                $scope.backup.pstg.questions.splice(index, 1);
                updateInDB(item, dbMap['stage'], 'Delete');
            }
        };

        $scope.getItemSelectionArray = function(list, addDefault) {
            var retArr = [];

            for (var i = 0; i < list.length; i++) {
                retArr.push({
                    displayValue: list[i].displayValue,
                    displayName: list[i].name,
                    modelValue: list[i].code,
                    checked: false
                });
            }

            retArr = commonApi._.sortBy(retArr, function(o) { return o.displayValue; })

            if (addDefault) {
                retArr.splice(0, 0, {
                    displayValue: 'Please Select',
                    displayName: 'Please Select',
                    modelValue: '',
                    checked: true
                });
            }

            return retArr
        }

        var removeOldPLQ = function(item) {
            delete item.editing;
            delete item.oldData;
            delete item.deliverableData;
        };

        var cancelEditRow = function(item) {
            angular.extend(item, item.oldData);
            removeOldPLQ(item);
        };

        $scope.cancelEditRow = function(item) {
            cancelEditRow(item);
        };

        $scope.printPLQs = function(id) {
            var prtContent = document.getElementById(id);
            var WinPrint = $window.frames['print_frame'].contentWindow || $window.frames['print_frame'];

            var title = 'IDP_' + $scope.project + '_PLQ'
            var tempTitle = document.title;
            document.title = title;
            WinPrint.document.title = title;
            angular.element(WinPrint.document.body).html('<style>body {margin: 0;font-family: Arial, sans-serif;font-size: 16px;line-height: 20px;color: #333;background-color: #fff;}p{margin:0}.m-close,.m-footer,.modal-action-container,.m-header,input,.que-action-wrap,.ng-hide,.del-inpt-wrap{display:none !important}.plq-table td > span,.print-header,.plq-stage-links a{display:block !important}.plq-table tr{background-color: #eee;}.plq-table td{border: 1px solid #FFF;padding: 5px 7px;font-size: 13px;}.plq-note{display: block;word-break: break-word;word-wrap: break-word;max-width: 280px;}.new-que-section{display:none;}</style>' + prtContent.innerHTML);
            WinPrint.focus();
            WinPrint.print();
            document.title = tempTitle;
        };

        $scope.allPstg = [];
        $scope.printAllPLQs = function() {
            if ($scope.data.programme && $scope.data.programme.pstage) {
                for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                    var stage = $scope.data.programme.pstage[k];
                    //					if(stage.stageStat == 'CR') {
                    $scope.allPstg.push(stage);
                    //					}
                }
            }

            $timeout(function() {
                $scope.printPLQs('all-current-plqs');
                $scope.allPstg.length = 0;
            });
        };

        $scope.printForm = function(option) {
            switch (option) {
                case 'b':
                    $rootScope.$broadcast('printForm', { printtype: 'profiled' });
                    break;
                default:
                    $rootScope.$broadcast('printForm');
                    break;
            }
        };

        $scope.generateCOBie = function(COBieStage) {
            var COBieStageArr = COBieStage;
            var stages = [], statuses = [];
            if (!COBieStageArr || typeof(COBieStageArr) == "string") {
                COBieStageArr = [COBieStage];
            } else {
                for (var i = 0; i < COBieStageArr.length; i++) {
                    if (COBieStageArr[i] == "") {
                        COBieStageArr = [""];
                        break;
                    }
                }
            }

            for (var i = 0; i < COBieStageArr.length; i++) {
                var s = COBieStageArr[i];
                if (s.indexOf('Stage ') > -1) {
                    stages.push(s.replace('Stage ', ''));
                } else {
                    statuses.push(s);
                }
            }
            
            var obj = {
                cobieParamJson: angular.toJson({
                    appBuilderCode: $window.AppBuilderFormIDCode,
                    projectId: projectId,
                    statuses: statuses.join(),
                    stages: stages.join()
                })
            };

            var prevForm = document.getElementById('IDP_COBie_FORM');
            prevForm && prevForm.remove && prevForm.remove();

            var form = document.createElement('form');
            form.id = "IDP_COBie_FORM";
            form.method = "POST";
            form.target = "COBIE_DOWNLOAD";
            form.action = ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/cobieReportData";

            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    var inpt = document.createElement('input');
                    inpt.type = "hidden";
                    inpt.name = key;
                    inpt.value = obj[key];
                    form.appendChild(inpt);
                }
            }

            document.body.appendChild(form);
            form.submit();
        };

        var setValidateJSON = function(data) {
            if (!data.PLQStage || !data.PLQStage.length) {
                return;
            }

            for (var i = 0; i < data.PLQStage.length; i++) {
                var pstage = data.PLQStage[i];
                $scope.data.programme.pstage[pstage.id].rag = pstage.rag;
            }

            var sections = $scope.data.section;
            for (var i = 0; i < sections.length; i++) {
                var section = sections[i];

                var deliverables = section.deliverable;
                for (var j = 0; j < deliverables.length; j++) {
                    var deliverable = deliverables[j];

                    for (var l = 0; l < data.PLQStage.length; l++) {
                        var pstage = data.PLQStage[l];
                        var respDel = commonApi._.findWhere(pstage.DeliverableStage, { dref: deliverable.dref });
                        if (respDel) {
                            // update rag of deliverable stage
                            deliverable.stage[pstage.id].rag = respDel.rag || 'AOK';
                        }
                    }

                    var subItems = deliverable.sub_items;
                    if (!subItems || !subItems.length) {
                        continue;
                    }

                    for (var k = 0; k < subItems.length; k++) {
                        var subItem = subItems[k];

                        for (var l = 0; l < data.PLQStage.length; l++) {
                            var pstage = data.PLQStage[l];
                            var respDel = commonApi._.findWhere(pstage.DeliverableStage, { dref: deliverable.dref });
                            if (!respDel) {
                                continue;
                            }
                            var respItem = commonApi._.findWhere(respDel.StageItem, { siid: deliverable.dref + ':' + subItem.id });
                            if (respItem) {
                                // update rag of deliverable stage
                                subItem.stage[pstage.id].rag = respItem.rag || 'AOK';
                                if (respItem.file_link) {
                                    subItem.stage[pstage.id].file_link = respItem.file_link;
                                }
                            }
                        }
                    }
                }
            }
        };

        $scope.refreshCOBie = function(pstage, force, callback, isOnload) {
            var stages = [];
            if (angular.isArray(pstage)) {
                for (var i = 0; i < pstage.length; i++) {
                    stages.push(pstage[i].id);
                }
            } else if (!force && pstage.stageStat != "CR") {
                return;
            } else {
                stages = [pstage.id];
            }

            $element.addClass('verifying').removeClass('loaded');

            $scope.xhr.verify = true;
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/validateCobieReportData",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&msgId=" + $('#msgId').val() + "&documentDetails=" + encodeURIComponent(angular.toJson({
                    validationStatus: $scope.data.config.validationStatus,
                    attrMaskKey: $scope.data.config.attributes.MaskKey,
                    plqStageId: stages.join(','),
                    isOnFormLoad: !!isOnload
                }))
            }).then(function(response) {
                $scope.xhr.verify = false;
                setValidateJSON(response.data || {});
                callback && callback();
                $element.addClass('loaded').removeClass('verifying');
            }, function() {
                $scope.xhr.verify = false;
                $window.alert('Error while verifying');
            });
        };

        ctrl.model = {
            modelId: "",
            update: $scope.updateRecord,
            hideModal: $scope.hideModal,
            readOnly: $scope.readOnly
        };

        // update the Manager (Editors) fields
        $scope.editors = $scope.data.editors || "";
        var editorList = $scope.editors ? $scope.editors.split(', ') : [];
        $scope.editorChange = function() {
            var select = document.getElementById('newman');
            var editor = select ? select.value : '';
            editor && editorList.push(editor);
            editorList = commonApi._.uniq(editorList);
            $scope.editors = $scope.data.editors = editorList.join(', ');
        };

        // show form in maximize pane only for IDP form
        angular.element('#viewFormMainSection').find('.restored').click();

        /*************************** pidp - start *****************************/

        /*************************** placeholder functionality - start *****************************/

        var folderId = '';
        $scope.folder = {
            list: [],
            selection: {},
            defSelection: {},
            defFolderName: '',
            selectedForListing: undefined
        };

        //		1	No Access
        //		2	View
        //		3	Publish
        //		4	Admin
        //		5	View & Link
        //		6	Publish & Link

        var findFolder = function(list, folderId) {
            for (var i = 0; i < list.length; i++) {
                var folder = list[i];
                var targetFolderId = (folderId + "").split('$$')[0];
                var currentFolderId = (folder.folderId + "").split('$$')[0];
                if (currentFolderId === targetFolderId) {
                    return folder;
                } else if (folder.childFolders && folder.childFolders.length) {
                    var found = findFolder(folder.childFolders, folderId);
                    if (found) {
                        return found;
                    }
                }
            }
        };

        var setFolderAccess = function(list) {
            list = list || $scope.folder.list;
            for (var i = 0; i < list.length; i++) {
                var folder = list[i];

                // set noAccess 
                if ([3, 4, 6].indexOf(folder.permissionValue) == -1) {
                    folder.noAccess = true;
                } else {
                    delete folder.noAccess;
                }

                if (folder.childFolders && folder.childFolders.length) {
                    setFolderAccess(folder.childFolders);
                }
            }
        };

        var setDefFolder = function(isTemplate, folders) {
            var folder = folders ? folders[0] : $scope.folder.list[0];
            if (!isTemplate && $scope.data.folder && $scope.data.folder.folderId) {
                folder = findFolder($scope.folder.list, $scope.data.folder.folderId);
            }
            $scope.data.folder = $scope.folder.defSelection = angular.copy(folder);
            if ($scope.data.folder) {
                delete $scope.data.folder.childFolders;
                delete $scope.folder.defSelection.childFolders;
            }
            updateSubItemFolder(isTemplate);

            if (!$scope.readOnly && 
                ($scope.user.roles.indexOf('EPM') > -1 || 
                $scope.user.roles.indexOf('SIM') > -1 || 
                $scope.user.roles.indexOf('SUP') > -1)) {
                loadListing($scope.data.config.folderPath ? $scope.data.folder : {}, null, null, null, true);
            }
        };

        var updateSubItemFolder = function(override, save) {
            if (!$scope.data.section || !$scope.data.section.length) {
                return;
            }

            var subitems = [];
            var subitemStages = [];
            for (var i = 0; i < $scope.data.section.length; i++) {
                var sec = $scope.data.section[i];
                if (sec.deliverable && sec.deliverable.length) {
                    for (var j = 0; j < sec.deliverable.length; j++) {
                        var del = sec.deliverable[j];
                        if (del.sub_items && del.sub_items.length) {
                            for (var k = 0; k < del.sub_items.length; k++) {
                                var item = del.sub_items[k];

                                if (override || !item.folder) {
                                    if ($scope.data.folder) {
                                        item.folder = angular.copy($scope.data.folder);
                                        subitems.push(item);
                                    }
                                } else {
                                    var f = findFolder($scope.folder.list, item.folder.folderId);
                                    if (f) {
                                        item.folder = angular.copy(f);
                                        delete item.folder.childFolders;
                                        subitems.push(item);
                                    }
                                }

                                for (var l = 0; l < item.stage.length; l++) {
                                    var is = item.stage[l];
                                    if (override || !is.folderId) {
                                        is.folderId = item.folder.folderId;
                                        is.folderTitle = item.folder.folderTitle;
                                        subitemStages.push(is);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (save) {
                subitems.length && updateInDB(subitems, dbMap.subitemdeliverables, 'Update');
                subitemStages.length && updateInDB(subitemStages, dbMap.subitemstage, 'Update');
            }
        };

        var getAllFoldersForProject = function(isTemplate) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/folder/getAllFoldersForProject",
                method: 'post',
                withCredentials: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: "projectId=" + projectId
            }).then(function(response) {
                var data = response.data || [];
                data = data[0] || {};
                data = data.childFolders || [];
                onFolderComplete(data, isTemplate);
            }, function() {
                //				$window.alert('error');
            });
        }

        var onFolderComplete = function(list, isTemplate) {
            $scope.folder.list = list;
            setFolderAccess();
            setDefFolder(isTemplate);
            if (angular.element('#editORI').val() != "true" && angular.element('#editDraft').val() != "true" && window.currentViewName == 'ORI_VIEW') {
                var defFolder = $scope.data.folder;
                if (defFolder.noAccess) {
                    window.alert('You do not have permission to create Deliverable Item over folder ' + defFolder.folderTitle);
                    window.cancelForm && window.cancelForm();
                    return;
                }
            }
            var pstageIds = [];
            if ($scope.data.programme && $scope.data.programme.pstage) {
                pstageIds = commonApi._.map($scope.data.programme.pstage, function(o) {
                    return { id: o.id };
                });
            }
            $scope.update();
            $scope.refreshCOBie(pstageIds, true, null, true);
        };

        var getFolderDetailsByPath = function(isTemplate) {
            var path = $scope.data.config.folderPath;

            // convert all forward slash to backward slash
            path = path.replace(/\//g, '\\');

            // remove first slash
            if (path.indexOf('\\') == 0) {
                path = path.substr(1);
            }

            // remove last slash
            if (path.indexOf('\\') == (path.length - 1)) {
                path = path.substr(0, a.length - 1);
            }

            // add project name at first
            path = $scope.project + '\\' + path;

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/folder/getFolderDetailsByPath",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&folderPath=" + encodeURIComponent(path)
            }).then(function(response) {
                var data = response.data || {};
                if (data.map) {
                    $window.alert(data.map.error);
                    return;
                }

                data = [data];
                onFolderComplete(data, isTemplate);
            }, function() {
                $window.alert('Invalid folder path!');
            });
        };

        var stageItemUsers = [];
        $scope.stageItemUsers = [];
        var fetchUserListForStageItem = function(role, callback) {
            var map = getRoleMap();
            var role = [];
            if (map['EPM']) {
                role.push(map['EPM']);
            }
            if (map['SIM']) {
                role.push(map['SIM']);
            }
            if (map['SUP']) {
                role.push(map['SUP']);
            }

            role = role.join(',').replace(/,/g, '#');

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/role/getUsersByProjectRoleName",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&roleNames=' + encodeURIComponent(role)
            }).then(function(response) {
                stageItemUsers = response.data || [];
                stageItemUsers = commonApi._.uniq(stageItemUsers, function(o) { return o.hUserID; });
                onUserAndOrgLoad();
            }, function() {
                //				$window.alert('error');
            });
        };

        var onUserAndOrgLoad = function() {
            if ($scope.orgList && $scope.orgList.length && stageItemUsers && stageItemUsers.length) {
                for (var i = 0; i < stageItemUsers.length; i++) {
                    var u = stageItemUsers[i];
                    var orgObj = commonApi._.findWhere($scope.orgList, { name: u.orgName });
                    if (orgObj && orgObj.code) {
                        u.orgCode = orgObj.code;
                        $scope.stageItemUsers.push(u);
                    }
                }
            }
        };

        var docRefList = [];
        var fetchFolderDocRefs = function(substg, folder) {
            if ((substg && !substg.revisionId) || !folder || !folder.folderId) {
                return;
            }

            var folderId = folder.folderId;
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getDocRefForFolders",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&folderId=' + folderId
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                docRefList = response.data || [];
            }, function() {
                $scope.xhr.multiPH.pop();
                $window.alert('Error while fetching Doc-Refs');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var getAction = function(id) {
            if (!actionList || !actionList.length) {
                return;
            }

            for (var i = 0; i < actionList.length; i++) {
                var a = actionList[i];
                if (a.actionID.split('$$')[0] == id) {
                    return a;
                }
            }
        };

        var attributeListMap = {
            1: "documentRef",
            2: "revision",
            3: "documentTitle",
            4: "purposeOfIssue",
            5: "status",
            6: "isPrivateRevision",
            7: "revisionNotes",
            8: "zipFileName",
            9: "series",
            10: "paperSize",
            11: "scale",
            12: "attributes"
        };

        var getCompoundAttrValueMap = function(item, stage, pstage) {
            var map = {};

            var customAttrs = getCustomAttrValues(item, stage, pstage, null, null, null, true) || [];
            for (var i = 0; i < customAttrs.length; i++) {
                var attr = customAttrs[i];
                map[attr.attributeName] = attr.attributeValue;
            }

            return map;
        };

        var getCompoundValue = function(item, stage, pstage, callback) {
            var compoundAttrs = [];
            for (var i = 0; i < attributeList.length; i++) {
                var attr = attributeList[i];
                if (attr.attributeTypeId == 6) { // 6 for compound attribute
                    compoundAttrs.push(attr.attributeName);
                }
            }

            if (!compoundAttrs.length) {
                $window.alert('No compound attribute found');
                return;
            }

            var folderId = item.folder.folderId;
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getCompoundValue",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId +
                    "&folderId=" + folderId +
                    "&attributesNames=" + encodeURIComponent(compoundAttrs.join(',')) +
                    "&nameValues=" + encodeURIComponent(angular.toJson(getCompoundAttrValueMap(item, stage, pstage))) +
                    "&KeyToSearchAction=UploadController117"
            }).then(function(res) {
                $scope.xhr.multiPH.pop();
                var data = res.data;
                if (data.myHashMap.errorMsg && data.myHashMap.errorMsg.length) {
                    $window.alert(data.myHashMap.errorMsg[0]);
                    return;
                }

                callback && callback(data);

                var map = angular.copy(data.myHashMap);
                delete map.errorMsg;
                var attrs = $scope.data.config.attributes;
                stage.attrs = {};
                for (var cKey in attrs) {
                    if (cKey != 'generateURI' && attrs.hasOwnProperty(cKey) && map.hasOwnProperty(attrs[cKey])) {
                        stage.attrs[cKey] = map[attrs[cKey]];
                    }
                }
                stage.attrs['DocRef'] = map['Doc Ref'];
            }, function() {
                $scope.xhr.multiPH.pop();
                $window.alert('Error while fetching compound values!');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var getParentDeliverable = function(dref) {
            var data = $scope.data;
            if (!data.section || !data.section.length) {
                return;
            }

            for (var i = 0; i < data.section.length; i++) {
                var section = data.section[i];
                if (!section.deliverable || !section.deliverable.length) {
                    continue;
                }

                for (var j = 0; j < section.deliverable.length; j++) {
                    var d = section.deliverable[j];

                    if (!d.sub_items || !d.sub_items.length) {
                        continue;
                    }

                    for (var k = 0; k < d.sub_items.length; k++) {
                        if (d.sub_items[k].dref == dref) {
                            return d;
                        }
                    }
                }
            }
        };

        var getCustomAttrValues = function(item, stage, pstage, oldItem, oldStage, oldPstage, all, compoundValues) {
            var customAttrs = [];
            for (var i = 0; i < attributeList.length; i++) {
                var attr = attributeList[i];

                if (!all && (attr.isSystemAttribute || attributeListMap[attr.attributeId])) {
                    continue;
                }

                var obj = {
                    "attributeId": attr.attributeId,
                    "attributeValue": "",
                    "inputTypeId": attr.inputTypeId
                };

                if (oldItem || all) {
                    obj.attributeName = attr.attributeName;
                }

                var configAttrs = $scope.data.config.attributes;
                if (attr.attributeName == configAttrs['ProjectCode']) {
                    obj.attributeValue = $scope.data.pref || "";
                } else if (attr.attributeName == configAttrs['Organization']) {
                    if ($scope.stg && typeof $scope.stg === "object") {
                        obj.attributeValue = $scope.stg.role || "";

                        if (oldStage) {
                            obj.oldAttributeValue = $scope.backup.stg.role || "";
                        }
                    } else {
                        var pDeli = getParentDeliverable(item.dref);
                        if (pDeli) {
                            obj.attributeValue = pDeli.stage[pstage.id].role || "";

                            if (oldStage) {
                                obj.oldAttributeValue = pDeli.stage[pstage.id].role || "";
                            }
                        }
                    }
                } else if (attr.attributeName == configAttrs['MaskKey']) {
                    if (compoundValues && compoundValues[configAttrs['MaskKey']]) {
                        obj.attributeValue = compoundValues[configAttrs['MaskKey']];
                    } else {
                        obj.attributeValue = (stage.file_mask || "").replace('-' + item.dtitle, '');
                    }

                    if (oldStage) {
                        if (oldStage.attrs) {
                            obj.oldAttributeValue = oldStage.attrs['MaskKey'];
                        } else {
                            obj.oldAttributeValue = (oldStage.file_mask || "").replace('-' + oldItem.dtitle, '');
                        }
                    }
                } else if (attr.attributeName == configAttrs['Volume']) {
                    obj.attributeValue = item.volume || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.volume || "";
                    }
                } else if (attr.attributeName == configAttrs['Location']) {
                    obj.attributeValue = item.location || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.location || "";
                    }
                } else if (attr.attributeName == configAttrs['FileType']) {
                    obj.attributeValue = item.file_type || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.file_type || "";
                    }
                } else if (attr.attributeName == configAttrs['Role']) {
                    obj.attributeValue = item.role || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.role || "";
                    }
                } else if (attr.attributeName == configAttrs['FileNumber']) {
                    obj.attributeValue = item.number || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.number || "";
                    }
                } else if (attr.attributeName == configAttrs['DeliverableReference']) {
                    obj.attributeValue = item.dref || "";
                } else if (attr.attributeName == configAttrs['Stage']) {
                    obj.attributeValue = pstage.stageRef || "";

                    if (oldPstage) {
                        obj.oldAttributeValue = oldPstage.stageRef || "";
                    }
                } else if (attr.attributeName == configAttrs['DeliveryItemName']) {
                    obj.attributeValue = item.dtitle || "";

                    if (oldItem) {
                        obj.oldAttributeValue = oldItem.dtitle || "";
                    }
                } else if (attr.attributeName == configAttrs['LOD']) {
                    obj.attributeValue = stage.lod || "";

                    if (oldStage) {
                        obj.oldAttributeValue = oldStage.lod || "";
                    }
                } else if (attr.inputTypeName == "Dropdown list" && attr.inputValueList && attr.inputValueList.length) {
                    for (var j = 0; j < attr.inputValueList.length; j++) {
                        var opt = attr.inputValueList[j];
                        if (opt.isDefault) {
                            obj.attributeValue = opt.value || "";
                            break;
                        }
                    }
                }

                customAttrs.push(obj);
            }

            return customAttrs;
        };

        var getCurrentTime = function() {
            var date = new Date();
            var h = addZeroPad(date.getHours(), 2);
            var m = addZeroPad(date.getMinutes(), 2);
            var s = addZeroPad(date.getSeconds(), 2);

            return (h + ":" + m + ":" + s);
        };

        var getCurrentDate = function() {
            var todaysDate = new Date();
            var m_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
            var curr_date = todaysDate.getDate();
            var curr_month = todaysDate.getMonth();
            var curr_year = todaysDate.getFullYear();
            todaysDate = curr_date + "-" + m_names[curr_month] + "-" + curr_year;
            return todaysDate
        }

        var getDocRef = function(subitem) {
            return ($scope.data.pref + '-' + $scope.stg.role + '-' + subitem.volume + '-' +
                subitem.location + '-' + subitem.file_type + '-' + subitem.role + '-' + subitem.number);
        };

        $scope.xhr = {
            placeholder: false,
            verify: false,
            standardAttr: false,
            multiPH: []
        };

        var isStageItemValid = function(userID, substg) {
            if (!userID) {
                $window.alert('Please select Author');
                return false;
            }

            var date = new Date();
            date.setHours(0);
            date.setMinutes(0);
            date.setSeconds(0);
            date.setMilliseconds(0);
            if (!substg.dueDate) {
                $window.alert('Please select Planned Date');
                return false;
            } else if ($scope.data.config.dueDateValidation) {
                var d = commonApi.parseDate(idpDateFormat, substg.dueDate);
                if (d.getTime() < date.getTime()) {
                    $window.alert('Please select date greater than Current Date.');
                    return false;
                } else {
                    var pstg = $scope.data.programme.pstage[substg.stgno];
                    if (pstg.stageEnd) {
                        var stageEndDate = commonApi.parseDate(idpDateFormat, pstg.stageEnd);
                        if (d.getTime() > stageEndDate.getTime()) {
                            return $window.confirm('Selected Planned Date is later than Stage due date.\n\nContinue anyway?');
                        }
                    }
                }
            }

            return true;
        };

        var createPlaceholder = function(subitem, substg, isValidationRequired, callback, compoundValues) {
            var user = substg.author;
            var action = getAction(28); // for Upload

            var poi = (commonApi._.findWhere($scope.upload.poiList, { defaultName: $scope.data.config.defaultPOI }) || {}).value || "";
            if (!poi) {
                alert('Default Purpose Of Issue (' + $scope.data.config.defaultPOI + ') is not found.');
                return;
            }

            if (!compoundValues) {
                getCompoundValue(subitem, substg, $scope.data.programme.pstage[substg.stgno], function(data) {
                    createPlaceholder(subitem, substg, isValidationRequired, callback, data.myHashMap);
                });

                return;
            }

            var docRef = compoundValues['Doc Ref'] || getDocRef(subitem);
            var placeholderDetail = {
                "placeholderList": [{
                    "filename": "Not Uploaded",
                    "documentRef": docRef,
                    "revision": "---",
                    "documentTitle": subitem.dtitle || "",
                    "purposeOfIssue": (poi + ''), // 0 for ---, 9 for S0: WIP (work in progress)
                    "isPrivateRevision": true,
                    "revisionNotes": "",
                    "zipFileName": "",
                    "paperSize": "",
                    "scale": "",
                    "customAttributes": getCustomAttrValues(subitem, substg, $scope.data.programme.pstage[substg.stgno], null, null, null, false, compoundValues),
                    "tempId": 0,
                    "isCheckIn": false
                }]
            };

            var folderId = subitem.folder.folderId;
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            var dueD = commonApi.parseDate(idpDateFormat, substg.dueDate);
            var distObj = getDistDetails(user, action, (commonApi.formatDate(userDateFormat, dueD, { lang: true }) + " " + getCurrentTime()));

            $scope.xhr.placeholder = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/createPlaceholder",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&folderId=' + folderId +
                    '&filename1=Not Uploaded' +
                    '&docRef1=' + docRef +
                    '&revision1=---' +
                    '&hasAttachment1=true' +
                    '&rowNumbers=1' +
                    '&forPublishing=false' +
                    '&validationType=2' +
                    '&isFromPlaceholder=true' +
                    '&subject=' +
                    '&noAccessUsers=' +
                    '&isValidationRequired=' + isValidationRequired +
                    '&placeholderDetails=' + encodeURIComponent(angular.toJson(placeholderDetail)) +
                    '&distributionDetails=' + distObj
            }).then(function(response) {
                $scope.xhr.placeholder = false;
                var data = response.data || {};

                if (data.errorCode) {
                    if (data.allowContinue) {
                        var yes = $window.confirm('The Doc Ref shown below already has a revision uploaded\n\n- ' + data.docRef +
                            '\n\nSystem will create placeholder with new revision for the above Doc Ref.\n\nContinue ?');

                        if (yes) {
                            createPlaceholder(subitem, substg, false, callback);
                        }
                    } else if (data.errorCode == 2031) { // placeholder is already deactivated
                        var yes = $window.confirm('The Doc Ref shown below has a deactivated placeholder as a latest revision\n\n- ' + data.docRef +
                            '\n\nSystem will reactivate placeholder for the above Doc Ref.\n\nContinue ?');

                        if (yes) {
                            var revId = data.revisionId + "";
                            revId = revId.split('$$')[0];
                            if (revId) {
                                activeDeactivatePH(substg, true, callback, [parseInt(revId)], data.documentId);
                            }
                        }
                    } else {
                        $window.alert('The Doc Ref shown below already has empty Placeholders\n\n- ' + data.docRef +
                            '\n\nSystem will not create placeholder for the above Doc Ref.\n Please remove that placeholder first.');
                    }
                } else if (data.myHashMap) {
                    var map = data.myHashMap.savedPlaceholderDetails;
                    substg.revisionId = map.revisionIds;
                    substg.documentId = map.documentIds;
                    substg.isPlaceholder = true;
                    var fId = subitem.folder.folderId + "";
                    substg.folderId = fId.split('$$')[0];
                    substg.folderTitle = subitem.folder.folderTitle;

                    lockEditAttributes(substg.revisionId);
                    callback && callback();
                }
            }, function() {
                $scope.xhr.placeholder = false;
                $window.alert('Error while creating placeholder!!\nPlease check Permissions.');
            });
        };

        var lockEditAttributes = function(revisionId, lock, callback) {
            var lockObj = {
                "objectTypeId": 1,
                "objectType": "Document",
                "lockedObjectId": revisionId,
                "projectId": projectId,
                "lockedById": $window.USP.userID.split('$$')[0],
                "lockTypeId": 2,
                "objectActivity": [{
                    "activityId": 1001,
                    "activityName": "Revision Upload",
                    "generateURI": true
                }, {
                    "activityId": 1002,
                    "activityName": "File Distribution",
                    "generateURI": true
                }, {
                    "activityId": 1003,
                    "activityName": "Edit Attribute",
                    "generateURI": true
                }, {
                    "activityId": 1004,
                    "activityName": "Update Status",
                    "generateURI": true
                }, {
                    "activityId": 1005,
                    "activityName": "Commenting",
                    "generateURI": true
                }],
                "lockActivity": [],
                "lockCount": 1,
                "generateURI": true,
                "unLockActivity": [],
                "proxyUserId": $window.USP.proxyUserID
            };

            if (lock) {
                lockObj.lockActivity.push({ "activityId": "1003" });
            } else {
                lockObj.unLockActivity.push({ "activityId": "1003" });
            }

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "commonapi/lock/applyActivityLocks",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: 'activityParamVO=' + angular.toJson(lockObj)
            }).then(function(response) {
                callback && callback(response.data);
            }, function() {
                $window.alert('Error while attribute lock');
            });
        };

        var isSubItemDirty = function(subitem, oldSubitem) {
            var subItemEditableKeys = ['dtitle', 'volume', 'location', 'file_type', 'role', 'number'];
            for (var key in subitem) {
                if (subitem.hasOwnProperty(key) && key != 'generateURI' && subItemEditableKeys.indexOf(key) > -1 && subitem[key] != oldSubitem[key]) {
                    return true;
                }
            }

            var newFolder = subitem.folder || {};
            var oldFolder = oldSubitem.folder || {};
            if (newFolder.folderTitle !== oldFolder.folderTitle) {
                return true;
            }

            return false;
        };

        var isSubStgDirty = function(substg, oldSubstg) {
            var subStgEditableKeys = ['role', 'dueDate', 'lod'];
            for (var key in substg) {
                if (substg.hasOwnProperty(key) && key != 'generateURI' && subStgEditableKeys.indexOf(key) > -1 && substg[key] != oldSubstg[key]) {
                    return true;
                }
            }

            return false;
        };

        var isDocRefDuplicate = function(docRef, revid) {
            for (var i = 0; i < docRefList.length; i++) {
                var dr = docRefList[i];
                if (revid != dr.latest_rev_id.split('$$')[0] && docRef == dr.doc_ref) {
                    return true;
                }
            }

            return false;
        };

        var getFreshUserId = function(plainUserId) {
            var user = commonApi._.findWhere($scope.stageItemUsers, { hUserID: plainUserId }) || {};
            return user.userID;
        };

        var getDistDetails = function(user, action, actionDueDate, revisionId, roles) {
            var userId = getFreshUserId(user.hUserID) || "";
            var obj = {
                selectedDistGroups: "",
                selectedDistUsers: [{
                    hUserID: userId,
                    fname: user.fname,
                    lname: user.lname,
                    user_type: user.user_type,
                    hActionID: action.actionID,
                    actionDueDate: actionDueDate,
                    email: $scope.data.config.actionNotification
                }],
                selectedDistOrgs: [],
                selectedDistRoles: [],
                tempId: 0
            };

            if (revisionId) {
                obj.selectedRevIds = revisionId;
            }

            if (roles) {
                roles = roles.split(',');
                for (var i = 0; i < roles.length; i++) {
                    if (roles[i]) {
                        obj.selectedDistRoles.push({
                            roleName: roles[i],
                            hActionID: action.actionID,
                            actionDueDate: actionDueDate
                        });
                    }
                }
            }

            return encodeURIComponent(angular.toJson(obj));
        };

        var updateMultiPlaceholder = function(subitem, oldSubitem, callback) {
            if (!isSubItemDirty(subitem, oldSubitem)) {
                $scope.hideModal();
                return;
            }

            var phFound = false;
            for (var s = 0; s < subitem.stage.length; s++) {
                var stg = subitem.stage[s];
                if (stg.revisionId && stg.rag != 'Green') {
                    phFound = true;
                    updatePlaceholder(subitem, oldSubitem, stg, stg, callback);
                }
            }

            !phFound && callback && callback();
        };

        var updatePlaceholder = function(subitem, oldSubitem, substg, oldSubstg, callback, compoundValues, file) {
            var action = getAction(13); // for information
            var actionDueDate = "";

            if (substg.author && oldSubstg.author && substg.author.hUserID != oldSubstg.author.hUserID) {
                action = getAction(28); // for publish
                var dueD = commonApi.parseDate(idpDateFormat, substg.dueDate);
                actionDueDate = commonApi.formatDate(userDateFormat, dueD, { lang: true }) + " " + getCurrentTime();
            }

            if (substg !== oldSubstg && !isSubStgDirty(substg, oldSubstg)) {
                $scope.hideModal();
                return;
            }
            var poi;
            if ($scope.data.config.placeholder) {
                poi = (commonApi._.findWhere($scope.upload.poiList, { defaultName: $scope.data.config.defaultPOI }) || {}).value || "";
                if (!poi) {
                    alert('Default Purpose Of Issue (' + $scope.data.config.defaultPOI + ') is not found.');
                    return;
                }
            }

            if (!compoundValues) {
                getCompoundValue(subitem, substg, $scope.data.programme.pstage[substg.stgno], function(data) {
                    updatePlaceholder(subitem, oldSubitem, substg, oldSubstg, callback, data.myHashMap, file);
                });

                return;
            }

            var docRef = compoundValues['Doc Ref'] || getDocRef(subitem);
            if ($scope.data.config.placeholder && isDocRefDuplicate(docRef, substg.revisionId)) {
                $window.alert('Duplicate Doc Ref.');
                return;
            }

            var folderId = subitem.folder.folderId + "";
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            var user = substg.author || {};
            var oldDocRef = "";
            if (substg.attrs) {
                oldDocRef = substg.attrs['DocRef'];
            } else {
                oldDocRef = getDocRef(oldSubitem);
            }
            var plainProjectId = projectId.split('$$')[0];
            var plainFolderId = folderId.split('$$')[0];
            var fileName = $scope.data.config.placeholder ? "NOT PUBLISHED" : file.FileName
            var docNamingValidationObj = [{
                "filename": fileName,
                "docref": docRef,
                "isPH": false,
                "position": "1",
                "folderId": plainFolderId,
                "projectId": plainProjectId
            }];

            var placeholderDetail = [{
                "folderId": plainFolderId,
                "rev_id": substg.revisionId,
                "doc_id": file ? file.DocumentId.split('$$')[0] : substg.documentId,
                "fileName": fileName,
                "doc_ref": docRef,
                "old_doc_ref": oldDocRef,
                "doc_title": subitem.dtitle || '',
                "old_doc_title": oldSubitem.dtitle || '',
                "poi_id": file ? file.poiId : poi,
                "old_poi_id": file ? file.poiId : poi,
                "purpose": file ? file.PurposeOfIssue : "---",
                "old_purpose": file ? file.PurposeOfIssue : "---",
                "revision": file ? file.RevNo : "---",
                "old_revision": file ? file.RevNo : "---",
                "revisionNotes": "Edited via IDP",
                "old_revisionNotes": "Edited via IDP",
                "doc_link_type": "1",
                "oldDocLinkType": 0,
                "isUpdateProjectLink": false,
                "selectedMarkPrivateRevId": substg.revisionId,
                "is_private": true,
                "previousPrivateStatus": "true",
                "workPackages": [],
                "old_workPackages": [],
                "publicDocumentDetailsVO": {
                    "revisionPublicStatus": false,
                    "revisionId": substg.revisionId,
                    "projectId": plainProjectId
                },
                "customAttributes": getCustomAttrValues(subitem, substg, $scope.data.programme.pstage[substg.stgno], oldSubitem, oldSubstg, $scope.pstg, false, compoundValues),
                "is_link_superseded_revision": 0,
                "linkCriteria": [],
                "isLinked": "false",
                "status": file ? file.DocStatus : "Prepublished",
                "status_id": file ? file.DocStatusId : 999
            }];

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/updatePlaceholder",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&folderId=' + folderId +
                    '&isOnlyPlaceholderSelected=' + $scope.data.config.placeholder +
                    '&isOnlyDocSelected=' + !$scope.data.config.placeholder +
                    '&DocNamingValidationVO=' + encodeURIComponent(angular.toJson(docNamingValidationObj)) +
                    '&DocumentAttributeDetails=' + encodeURIComponent(angular.toJson(placeholderDetail))
                    // + '&extra=' + getDistDetails(user, action, actionDueDate, substg.revisionId)
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || "";
                !$scope.xhr.multiPH.length && callback && callback(data);
            }, function() {
                $scope.xhr.multiPH.pop();
                $window.alert('Error while updating ' + ($scope.data.config.placeholder ? 'placeholder' : 'document'));
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var actionList = [];
        var attributeList = [];
        var fetchActionAndAttributeDetails = function(folder, callback) {
            var folderId = folder.folderId;
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getActionAndAttributeDetails",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&folderId=' + folderId + '&KeyToSearchAction=UploadController117&subActionType=2'
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || {};
                actionList = (data.myHashMap || {}).actionVOList || [];
                attributeList = ((data.myHashMap || {}).filesAttributeDataVO || {}).allAttributesList || [];

                callback && callback();
            }, function() {
                $scope.xhr.multiPH.pop();
                $window.alert('Error while loading Attribute list!!');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var removeMultiPH = function(stages, callback) {
            var revList = [];
            for (var i = 0; i < stages.length; i++) {
                var s = stages[i];
                if (s.revisionId && s.isPlaceholder) {
                    revList.push(parseInt(s.revisionId));
                }
            }

            if (!revList.length) {
                callback && callback();
                return;
            }

            activeDeactivatePH(null, false, callback, revList);
        };

        var activeDeactivatePH = function(substg, status, callback, revList, documentId, silent) {
            revList = revList || [parseInt(substg.revisionId)];

            var distDetail = "";
            if (status) {
                var user = $scope.substg.author || {};
                var action = getAction(28); // for publish

                var dueD = commonApi.parseDate(idpDateFormat, substg.dueDate);
                var actionDueDate = commonApi.formatDate(userDateFormat, dueD, { lang: true }) + " " + getCurrentTime();
                distDetail = "&projectId=" + projectId + '&folderId=' + $scope.subitem.folder.folderId +
                    '&isOnlyPlaceholderSelected=true&isOnlyDocSelected=false' +
                    '&isDistributionRequired=true&extra=' + getDistDetails(user, action, actionDueDate, revList[0]);
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/changeStatusOfDocument",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: 'projectID=' + projectId + '&status=' + status + '&revisionIds=' + angular.toJson(revList) + '&selectedRevisions=[]' + distDetail
            }).then(function(response) {
                $scope.xhr.multiPH.pop();

                if (silent) {
                    return;
                }

                if (substg) {
                    if (!status) {
                        substg.revisionId = "";
                        substg.isPlaceholder = false;
                    } else {
                        substg.revisionId = revList[0];
                        substg.isPlaceholder = true;
                        substg.documentId = (documentId + "").split('$$')[0];
                    }
                    updateInDB(substg, dbMap.subitemstage, 'Update');
                }

                callback && callback();
            }, function() {
                $scope.xhr.multiPH.pop();
                $window.alert('Error: Check permission!!');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var isPhInRow = function() {
            for (var s = 0; s < $scope.subitem.stage.length; s++) {
                var stg = $scope.subitem.stage[s];
                if (stg.revisionId && stg.rag != 'Green') {
                    return true;
                }
            }
            return false;
        };

        var isPhInOtherStage = function() {
            for (var i = 0; i < $scope.subitem.stage.length; i++) {
                var cStg = $scope.subitem.stage[i];
                if (cStg.revisionId && $scope.substg.stgno != cStg.stgno && cStg.rag != 'Green') {
                    return true;
                }
            }

            return false;
        };

        var getDocrefAndAttributes = function(folder, id) {
            if ((id == 'subitemstage' && ((!$scope.data.config.placeholder && $scope.substg.revisionId) ||
                    (!$scope.substg.freeze && !$scope.substg.uploaded && !isPhInOtherStage() &&
                        (!$scope.substg.revisionId || $scope.substg.rag != 'Green')))) || (!$scope.subitem.uploaded && isPhInRow())) {
                fetchFolderDocRefs($scope.substg, folder);
                fetchActionAndAttributeDetails(folder, function() {
                    for (var i = 0; i < attributeList.length; i++) {
                        var item = attributeList[i];
                        if (item.inputTypeName == "Dropdown list" && item.inputValueList && item.inputValueList.length) {
                            if (item.attributeName == "Purpose of Issue") {
                                $scope.upload.poiList = item.inputValueList;
                            } else if (item.attributeName == "Status") {
                                $scope.upload.statusList = item.inputValueList;
                            }
                        }
                    }
                });
            }
        };

        /*************************** placeholder functionality - end *****************************/

        /*********************** add volume and location - start ******************/

        var isEntityValid = function(list, newItem, operation) {
            if (operation == 'REMOVE') {
                return window.confirm('Are you sure you want to delete this item?');
            }

            // if already used in form
            if (newItem.used) {
                return false;
            }

            var newItemCode = newItem.code.trim();
            var newItemName = newItem.name.trim();
            if (!newItemCode) {
                newItem.error = "Please select Code.";
                return false;
            } else if (newItemCode.length > 15) {
                newItem.error = "Code must be 15 characters or less.";
                return false;
            } else if (newItemCode.match(/[|&^<>#]/gi)) {
                newItem.error = "Restricted Characters specified! Restricted Characters | & ^ < > #  ";
                return false;
            }

            var nameWithCode = addCodePrefix(newItemName, newItemCode);
            if (!newItemName) {
                newItem.error = "Please select Name.";
                return false;
            } else if (nameWithCode.length > 100) {
                newItem.error = "Name must be 100 characters or less.";
                return false;
            } else if (newItemName.match(/[|&^<>#]/gi)) {
                newItem.error = "Restricted Characters specified! Restricted Characters | & ^ < > #  ";
                return false;
            }

            for (var i = 0; i < list.length; i++) {
                var item = list[i];
                // skip duplicate check for row itself in edit mode.
                if (operation == 'EDIT' && $scope.entity.oldEntity.code.trim() == item.code) {
                    continue;
                }

                if (item.code.trim().toUpperCase() == newItemCode) {
                    newItem.error = "Code already exist.";
                    return false;
                } else if (item.name.trim() == nameWithCode) {
                    newItem.error = "Name already exist.";
                    return false;
                }
            }

            var typeStr = $scope.entity.type || "item";
            typeStr = typeStr.toLowerCase();
            if ($scope.entity.standardList && $scope.entity.standardList.length) {
                if (!exstingStandardAttrs.length) {
                    newItem.error = "No standard " + typeStr + " code found.";
                    return false;
                }

                var codePreExist = false;
                for (var i = 0; i < $scope.entity.standardList.length; i++) {
                    var se = $scope.entity.standardList[i];
                    if (newItemCode.indexOf(se.code) == 0) {
                        codePreExist = true;
                        break;
                    }
                }

                if (!codePreExist) {
                    newItem.error = "New " + typeStr + " code should contain any of standard " + typeStr + " code as prefix.";
                    return false;
                }
            }

            return true;
        };

        var exstingStandardAttrs = [];
        var populateEntity = function(type) {
            if ($scope.xhr.standardAttr) {
                return;
            }

            $scope.entity.type = type;
            $scope.entity.standardList = [];

            var subItemKey = '';
            var usedEntity = [];

            if (type == 'Volume') {
                $scope.volumeList = commonApi._.sortBy($scope.volumeList, function(o) { return o.code; });
                $scope.entity.list = $scope.volumeList;
                $scope.entity.standardList = volumeStandardList;
                subItemKey = 'volume';
            } else if (type == 'Location') {
                $scope.locationList = commonApi._.sortBy($scope.locationList, function(o) { return o.code; });
                $scope.entity.list = $scope.locationList;
                $scope.entity.standardList = locationStandardList;
                subItemKey = 'location';
            } else if (type == 'Region') {
                $scope.regionList = commonApi._.sortBy($scope.regionList, function(o) { return o.code; });
                $scope.entity.list = $scope.regionList;
                $scope.data.region && usedEntity.push($scope.data.region);
            }

            if (subItemKey) {
                var sections = $scope.data.section;
                for (var i = 0; i < sections.length; i++) {
                    var section = sections[i];
                    var deliverables = section.deliverable;
                    if (!deliverables || !deliverables.length)
                        continue;

                    for (var j = 0; j < deliverables.length; j++) {
                        var deliverable = deliverables[j];
                        var subItems = deliverable.sub_items;

                        if (!subItems || !subItems.length) {
                            continue;
                        }

                        for (var k = 0; k < subItems.length; k++) {
                            var subItem = subItems[k];
                            if (subItem[subItemKey]) {
                                usedEntity.push(subItem[subItemKey]);
                            }
                        }
                    }
                }
            }

            // find out used entity in form.
            exstingStandardAttrs = [];
            for (var l = 0; l < $scope.entity.list.length; l++) {
                var e = $scope.entity.list[l];
                delete e.error;
                if (isStandardAttr(e.code)) {
                    e.used = true;
                    e.isStandard = true;
                    exstingStandardAttrs.push(e);
                } else {
                    e.used = (usedEntity.indexOf(e.code) > -1);
                }
            }
        };

        var isStandardAttr = function(code) {
            if ($scope.entity.standardList && $scope.entity.standardList.length) {
                for (var s = 0; s < $scope.entity.standardList.length; s++) {
                    var se = $scope.entity.standardList[s];
                    if (se.code === code) {
                        return true;
                    }
                }
            }

            return false;
        }

        var resetAllEntity = function() {
            $scope.entity = {
                search: {
                    displayValue: ''
                },
                list: [],
                standardList: [],
                type: '',
                oldEntity: { code: "", name: "", error: "" },
                editEntity: { code: "", name: "", error: "" },
                newEntity: { code: "", name: "", error: "" }
            };
        };

        resetAllEntity();

        var addCodePrefix = function(name, code) {
            var title = name || "";
            if (title.indexOf(code + ' ') != 0) {
                title = code + ' ' + title;
            }
            return title;
        };

        var replaceCode = function(entity) {
            var prefix = entity.code + ' ';
            if (entity.name.indexOf(prefix) == 0) {
                entity.name = entity.name.replace(prefix, '');
            }

            return entity;
        };

        $scope.editEntity = function(item) {
            // reset error message
            for (var l = 0; l < $scope.entity.list.length; l++) {
                var e = $scope.entity.list[l];
                delete e.error;
            }

            $scope.entity.oldEntity = item;
            $scope.entity.editEntity = replaceCode(angular.copy(item));
        }

        $scope.cancelEntity = function() {
            $scope.entity.editEntity = { code: "", name: "", error: "" };
            $scope.entity.oldEntity = { code: "", name: "", error: "" };
        };

        $scope.manageEntity = function(operation, entity, e) {
            entity.error = "";
            entity.code = entity.code.toUpperCase();
            if ((e && e.keyCode != 13) || !isEntityValid($scope.entity.list, entity, operation)) {
                return;
            }

            // if edit with no change
            var newEntityName = entity.name;
            var codePrefix = entity.code + ' ';
            if (entity.name.indexOf(codePrefix) != 0) {
                newEntityName = codePrefix + entity.name;
            }
            if (operation == 'EDIT' && $scope.entity.oldEntity.code == entity.code && $scope.entity.oldEntity.name == newEntityName) {
                $scope.cancelEntity();
                return;
            }

            var newValue = {
                value: entity.code,
                defaultName: newEntityName
            };

            if (operation == 'EDIT') {
                newValue.oldValue = $scope.entity.oldEntity.code;
                newValue.oldDefaultName = $scope.entity.oldEntity.name;
            }

            var attrType = $scope.data.config.attributes[$scope.entity.type];
            manageAttributes(operation, [{
                attributeName: attrType,
                inputTypeId: customDropdownAttrType,
                inputValueList: [newValue]
            }], function(data) {
                var newEntity = {
                    code: entity.code,
                    name: newEntityName,
                    displayValue: entity.code + ':' + newEntityName,
                };

                if (isStandardAttr(entity.code)) {
                    newEntity.used = true;
                    newEntity.isStandard = true;
                }

                if (operation == 'ADD') {
                    // clear search
                    $scope.entity.search.displayValue = "";

                    // add new entity
                    $scope.entity.list.push(newEntity);

                    // reset new input line
                    $scope.entity.newEntity = { code: "", name: "", error: "" };

                    // scroll to bottom
                    $timeout(function() {
                        var scrollEl = document.getElementById('manageAttributes-overflow');
                        if (scrollEl) {
                            scrollEl.scrollTop = 99999;
                        }
                    }, 100);
                } else if (operation == 'EDIT') {
                    // update edit row
                    angular.merge($scope.entity.oldEntity, newEntity);

                    // remove edit mode
                    $scope.cancelEntity();
                } else if (operation == 'REMOVE') {
                    // remove entity from list
                    var deleteIndex = $scope.entity.list.indexOf(entity);
                    if (deleteIndex > -1) {
                        $scope.entity.list.splice(deleteIndex, 1);
                    }
                }

                if (['Volume', 'Location', 'Region'].indexOf($scope.entity.type) > -1) {
                    updateCustomAttrDDList($scope.entity.type, $scope.entity.list);
                }
            });
        };

        var isAllowCreate = true;
        var manageAttributes = function(operation, customAttr, callback, updateOnLoad) {
            var list = customAttr[0].inputValueList || [];
            for (var i = 0; i < list.length; i++) {
                var e = list[i];
                e.defaultName = addCodePrefix(e.defaultName, e.value);
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "commonapi/document/manageAttributeValues",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&operation=" + operation + "&customAttributes=" + encodeURIComponent(angular.toJson(customAttr))
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || "";
                if (data.overAllStatus != "FAIL") {
                    callback && callback(data);
                } else {
                    var error = 'Error in adding Custom Attribute!';
                    if (data.msg) {
                        error = data.msg;
                    } else if (data.customAttribute[0].errorMsg) {
                        error = data.customAttribute[0].errorMsg;
                    }

                    isAllowCreate = false;
                    window.alert(error);
                    updateOnLoad && window.cancelForm && window.cancelForm();
                }
            }, function(xhr) {
                $scope.xhr.multiPH.pop();
                window.alert('Error in adding Custom Attribute!');
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var updateCustomAttrDDList = function(type, list) {
            var listArr = $scope.getItemSelectionArray(list);
            var data = [{
                optlabel: "",
                options: listArr
            }];

            if (type == "Volume") {
                $scope.volumeListData = data;
            } else if (type == "Location") {
                $scope.locationListData = data;
            } else if (type == "Region") {
                $scope.regionListData = data;
            }
        }

        /*********************** add volume and location - end ******************/

        /********************** upload and drag n drop - start ********************/
        $scope.upload = {
            poi: "",
            status: "",
            rev: "",
            poiList: [],
            statusList: []
        };

        $scope.canDragNDrop = function() {
            return canDragNDrop();
        };

        $scope.removeSeondaryFile = function(e) {
            var sFile = angular.element('#idpSecondary');
            var parent = sFile.parent();

            // remove event file input
            sFile.off('change').remove();
            $scope.upload.zipFile = undefined;

            // append new file input to rmeove the file selection
            parent.append('<input type="file" name="fileName" id="idpSecondary" />');

            bindSecondaryInptEvents();
        };

        var canDragNDrop = function() {
            if (!$scope.stg.role || $scope.substg.freeze) {
                return false;
            }
            if (!$scope.data.config.placeholder && $scope.backup.substg.role) {
                return true;
            }
            if ($scope.data.config.placeholder && $scope.substg.revisionId && $scope.substg.author && $scope.substg.author.hUserID == $scope.user.usp.userID) {
                if ($scope.substg.rag != 'Green' && ($scope.substg.isPlaceholder === true || $scope.substg.isPlaceholder === 'true')) {
                    return true;
                } else {
                    for (var i = (parseInt($scope.substg.stgno) + 1); i < $scope.subitem.stage.length; i++) {
                        if ($scope.subitem.stage[i].revisionId) {
                            return false;
                        }
                    }

                    return true;
                }
            }

            return false;
        };

        var bindUploadEvents = function() {
            if (canDragNDrop()) {
                $timeout(function() {
                    var targetDom = document.getElementById('idpDropArea');
                    var target = angular.element(targetDom);
                    if (targetDom) {
                        target.off('dragover dragenter dragleave drop').on('dragover dragenter', function(e) {
                            e = e.originalEvent || e;
                            var dataTransfer = e.dataTransfer;
                            if (dataTransfer && angular.element.inArray('Files', dataTransfer.types) !== -1) {
                                dataTransfer.dropEffect = 'copy';
                                e.preventDefault();
                                e.stopPropagation();
                                target.addClass('drag-enter');
                            }
                            return false;
                        }).on('dragleave', function(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            var pos = targetDom.getBoundingClientRect();
                            e = e.originalEvent || e;
                            if (e.clientY <= pos.top || e.clientY >= pos.bottom || e.clientX <= pos.left || e.clientX >= pos.right) {
                                target.removeClass('drag-enter');
                                return false;
                            }
                        }).on('drop', function(e) {
                            target.removeClass('drag-enter');
                            if (e.originalEvent.dataTransfer) {
                                if (e.originalEvent.dataTransfer.files.length) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    showUploadDocumentModal(e.originalEvent.dataTransfer.files);
                                }
                            }
                        });

                        target.find('input[type="file"]').off('change').on('change', function(e) {
                            showUploadDocumentModal(e.currentTarget.files);
                        });
                    }
                });
            }
        };

        var bindSecondaryInptEvents = function() {
            angular.element('#idpSecondary').off('change').on('change', function(e) {
                $scope.upload.zipFile = e.currentTarget.files[0];

                try {
                    $scope.$digest();
                } catch (e) {}
            });
        };

        var reOrderPoiCodes = function() {
            var poiSortByConfig = $scope.data.config.poiSortSeq || "";
            if (poiSortByConfig != "") {
                var allPoiCodes = $scope.upload.poiList;
                var sortedPoiCodes = [];
                poiSortByConfig = poiSortByConfig.split(",");

                for (var i = 0; i < poiSortByConfig.length; i++) {
                    var sortByTxt = poiSortByConfig[i];
                    //Filter out values that match our congif criteria.
                    var matchArr = commonApi._.filter(allPoiCodes, function(o) {
                        return (o.defaultName.substring(0, sortByTxt.length) == sortByTxt)
                    });
                    //Sort Array with Alphanumeric values
                    matchArr = matchArr.sort(function(a, b) {
                        var aMixed = commonApi.normalizeMixedDataValue(a.defaultName);
                        var bMixed = commonApi.normalizeMixedDataValue(b.defaultName);
                        return (aMixed < bMixed ? -1 : 1);
                    });
                    if (matchArr.length)
                        sortedPoiCodes = sortedPoiCodes.concat(matchArr);
                }
                if (sortedPoiCodes.length) {
                    sortedPoiCodes = commonApi._.uniq(sortedPoiCodes, 'defaultName');
                    if (allPoiCodes.length > sortedPoiCodes.length) {
                        sortedPoiCodes = sortedPoiCodes.concat(_.difference(allPoiCodes, sortedPoiCodes));
                    }
                    $scope.upload.poiList = sortedPoiCodes;
                }
            }
        }

        var showUploadDocumentModal = function(files) {
            $scope.upload.rev = "";
            $scope.upload.poi = "";
            $scope.upload.status = "";
            $scope.upload.file = files[0];
            $scope.upload.zipFile = undefined;

            $scope.showModal('uploaddocument', $scope.backup.item, $scope.backup.subitem, $scope.backup.stg, $scope.backup.substg, $scope.backup.pstg);

            fetchActionAndAttributeDetails($scope.subitem.folder, function() {
                for (var i = 0; i < attributeList.length; i++) {
                    var item = attributeList[i];
                    if (item.inputTypeName == "Dropdown list" && item.inputValueList && item.inputValueList.length) {
                        if (item.attributeName == "Purpose of Issue") {
                            $scope.upload.poiList = item.inputValueList;
                            $scope.upload.poi = "";
                        } else if (item.attributeName == "Status") {
                            $scope.upload.statusList = item.inputValueList;
                            $scope.upload.status = (commonApi._.findWhere(item.inputValueList, { defaultName: $scope.data.config.defaultStatus }) || {}).value || "";
                        }
                    }
                }

                reOrderPoiCodes();

                try {
                    $scope.$digest();
                } catch (e) {}

                bindSecondaryInptEvents();
            });
        };

        var uploadDocument = function(subitem, substg, callback, compoundValues) {
            var folderId = $scope.subitem.folder.folderId + "";
            var f = findFolder($scope.folder.list, folderId);
            if (f) {
                folderId = f.folderId;
            }

            if (!compoundValues) {
                getCompoundValue(subitem, substg, $scope.data.programme.pstage[substg.stgno], function(data) {
                    uploadDocument(subitem, substg, callback, data.myHashMap);
                });

                return;
            }

            substg.isFileUploaded = false;
            updateInDB(substg, dbMap.subitemstage, 'Update');

            var docRef = compoundValues['Doc Ref'] || getDocRef(subitem);
            var docDetail = {
                "filesAttributeList": [{
                    "filename": $scope.upload.file.name,
                    "documentRef": docRef,
                    "revision": $scope.upload.rev,
                    "documentTitle": subitem.dtitle || "",
                    "purposeOfIssue": $scope.upload.poi,
                    "status": $scope.upload.status,
                    "isPrivateRevision": true,
                    "revisionNotes": "",
                    "clientFileSize": $scope.upload.file.size,
                    "zipFileName": ($scope.upload.zipFile ? $scope.upload.zipFile.name : ""),
                    "paperSize": "",
                    "scale": "",
                    "customAttributes": getCustomAttrValues(subitem, substg, $scope.data.programme.pstage[substg.stgno], null, null, null, false, compoundValues),
                    "tempId": 0,
                    "isCheckIn": false,
                    "clientZipFileSize": -1
                }],
                "selectedDistGroups": "",
                "selectedDistUsers": [],
                "selectedDistOrgs": [],
                "selectedDistRoles": [],
                "tempId": 0
            };

            var formData = new FormData();
            formData.append('projId', projectId);
            formData.append('subject', '');
            formData.append('isSingleThreadUpload', 'no');
            formData.append('temp_file_name', $scope.upload.file.name);
            formData.append('isSmartObject', false);
            formData.append('folderId', folderId);
            formData.append('totalFiles', 1);
            formData.append('isAutoCheckout', false);
            formData.append('isZipContent_0', true);
            formData.append('fileName', $scope.upload.file);

            var headerObj = {};
            if ($scope.upload.zipFile) {
                formData.append('fileName', $scope.upload.zipFile);
                formData.append('isAutoCheckout', false);
                formData.append('isZipContent_1', true);

                headerObj = {
                    //					ApplicationId: 1,
                    hasAttachement: true
                };

                docDetail.FileName = [$scope.upload.file.name, $scope.upload.zipFile.name];
                docDetail.FileSize = [($scope.upload.file.size + ""), ($scope.upload.zipFile.size + "")];
            }

            formData.append('extra', angular.toJson(docDetail));

            $scope.xhr.placeholder = 'uploading';
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/adoddlenavigatorapi/documents/upload_file_with_distribution/" + projectId,
                method: 'post',
                withCredentials: true,
                transformRequest: angular.identity,
                headers: angular.extend({ 'Content-Type': undefined }, headerObj),
                data: formData
            }).then(function(response) {
                $scope.xhr.placeholder = false;
                var data = response.data || [];
                if (angular.isArray(data) && data.length) {
                    var data = angular.fromJson(data[0]);
                    substg.uploaded = true;
                    substg.isPlaceholder = false;
                    substg.locked = true;
                    substg.fileName = $scope.upload.file.name;
                    subitem.uploaded = true;
                    substg.revisionId = data[0].revisionId.split("$$")[0];
                    substg.documentId = data[0].documentId.split("$$")[0];

                    $scope.getPreviousRevisionDetails(function() {
                        var oriSubstg = $scope.backup.substg;
                        $scope.updateSubMask($scope.stg, $scope.subitem, oriSubstg, $scope.pstg);
                        pingTimeout = (new Date()).getTime();
                        $scope.updateRecord(true);
                        ping(subitem, oriSubstg);
                    });
                } else {
                    $window.alert('Something went wrong while uploading document!');
                }
            }, function() {
                $scope.xhr.placeholder = false;
                $window.alert('Error while uploading Document!!');
            });
        };

        var pingTimeout = undefined;
        var ping = function(subitem, substg, stg, pstg, oriSubstg) {
            var msgId = $('#msgId').val();
            stg = stg || $scope.stg;
            pstg = pstg || $scope.pstg;
            oriSubstg = oriSubstg || $scope.backup.substg;
            var item = subitem;
            var documentDetails = {
                "msgId": msgId.split('$$')[0],
                "MaskKey": $scope.data.pref + '-' + (stg.role || '?') + '-' + (item.volume || '?') + '-' + (item.location || '?') + '-' +
                    (item.file_type || '?') + '-' + (item.role || '?') + '-' + (item.number || '?') + '-' + item.dref + '-' + pstg.stageRef + '-' + (oriSubstg.lod || '?')
            };
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getIDPStageItemDetails",
                method: 'post',
                withCredentials: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: "projectId=" + projectId + "&documentDetails=" + angular.toJson(documentDetails)
            }).then(function(response) {
                var data = response.data;
                data = data.documentDetails ? angular.fromJson(data.documentDetails)[0] : {};
                if (data.isFileUploaded === true || data.isFileUploaded === "true" || data.isFileUploaded == 1) {
                    delete data.isFileUploaded;

                    mergeData(data, substg);

                    $scope.refreshCOBie(pstg, true, function() {
                        updateInDB(substg, dbMap.subitemstage, 'Update');
                    });
                } else if (response.data.documentDetailsError) {
                    $window.alert(response.data.documentDetailsError);
                } else {
                    if (((new Date()).getTime() - pingTimeout) > 120000) {
                        return;
                    }
                    $timeout(function() {
                        ping(subitem, substg, stg, pstg, oriSubstg);
                    }, 1000);
                }
            }, function() {
                $window.alert('Error while checking for latest data!');
                $window.location.reload();
            });
        };

        var mergeData = function(data, substg) {
            var sis = data;
            substg.file_link = sis.file_link;
            substg.rag = sis.rag || 'AOK';
            substg.uploaded = sis.uploaded;
            substg.isPlaceholder = sis.isPlaceholder;
            substg.locked = sis.locked;

            if (substg.isPlaceholder == 1) {
                substg.isPlaceholder = true;
            }
            substg.isFileUploaded = false;

            if (sis.documentId && sis.documentId !== "0") {
                substg.documentId = sis.documentId;
            }
            if (sis.revisionId && sis.revisionId !== "0") {
                substg.revisionId = sis.revisionId;
            }
        };

        /********************** upload and drag n drop - end ********************/

        /********************** Non idp document binding - start ********************/

        $scope.listingData = {
            allItem: [],
            totalRecords: 0,
            remainingDocs: 0,
            size: 0,
            rpp: 10,
            pages: [],
            pageNo: 1,
            gap: 5,
            sortField: 'revision_date',
            sortOrder: 'desc'
        };

        var loadListing = function(folder, pageNo, sortField, sortOrder, silent) {
            pageNo = pageNo || 1;
            $scope.listingData.pageNo = pageNo;
            folder = folder || $scope.folder.selectedForListing || {};

            var hashedFolderId = folder.folderId;
            var f = findFolder($scope.folder.list, hashedFolderId);
            if (f) {
                hashedFolderId = f.folderId;
            }

            if (sortField)
                $scope.listingData.sortField = sortField;

            if (sortOrder) {
                $scope.listingData.sortOrder = sortOrder;
            }

            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/getNonProfiledDocuments",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId +
                    "&msgId=" + angular.element('#msgId').val() +
                    (hashedFolderId ? ("&folderId=" + hashedFolderId) : '') +
                    "&recordStart=" + ((pageNo - 1) * 10 + 1) +
                    "&recordLimit=" + $scope.listingData.rpp +
                    "&sortField=" + $scope.listingData.sortField +
                    "&sortOrder=" + $scope.listingData.sortOrder
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || {};
                var isSuccess = data.isSuccess;
                data = data.response;
                data = angular.fromJson(data);
                if (!isSuccess) {
                    !silent && $window.alert("ERROR");
                    return;
                }
                $scope.listingData.allItem = data.elementVOList || [];
                $scope.listingData.totalRecords = parseInt(data.responseHeader['results-total']) || 0;
                if(!$scope.listingData.remainingDocs) {
                    $scope.listingData.remainingDocs = $scope.listingData.totalRecords;
                }
                prepareRange();
            }, function(xhr) {
                $scope.xhr.multiPH.pop();
                if (xhr.status != -1) {
                    $window.alert("ERROR");
                }
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var prepareRange = function() {
            var size = $scope.listingData.size = Math.ceil($scope.listingData.totalRecords / $scope.listingData.rpp),
                cpage = $scope.listingData.pageNo,
                ret = [],
                start, end;

            if (cpage < 1 || cpage > size) {
                $scope.listingData.pageNo = 1;
                cpage = 1;
            }

            var leftRightPages = Math.floor($scope.listingData.gap / 2);
            if (cpage <= leftRightPages) {
                start = 1;
                end = Math.min($scope.listingData.gap, size);
            } else if (cpage >= size - leftRightPages) {
                start = Math.max(size - $scope.listingData.gap, 1);
                end = size;
            } else {
                start = Math.max(cpage - leftRightPages, 1);
                end = Math.min(cpage + leftRightPages, size);
            }

            for (var i = start; i <= end; i++) {
                ret.push(i);
            }

            $scope.listingData.pages = ret;
        };

        var getLatestDocData = function(file, callback) {
            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/documentsearchapi/search",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "searchCriteria=" + angular.toJson({
                    "criteria": [{
                        "field": "project_id",
                        "operator": 1,
                        "values": [projectId]
                    }, {
                        "field": "revision_id",
                        "operator": 1,
                        "values": [file.RevisionId]
                    }],
                    "generateShareLink": "true",
                    "expiryAfterDuration": "15d",
                    "showLatestRevision": "true",
                    "sortField": "doc_ref",
                    "sortOrder": "desc",
                    "recordStart": 1,
                    "recordLimit": 1
                })
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || {};
                var docInfo = data.elementVOList || [];
                if (docInfo.length) {
                    callback && callback(docInfo[0]);
                }
            }, function(xhr) {
                $scope.xhr.multiPH.pop();
                if (xhr.status != -1) {
                    $window.alert("ERROR");
                }
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var getDocsByDocRef = function(file, callback) {
            var xhr = commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/documentsearchapi/search",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "searchCriteria=" + angular.toJson({
                    "criteria": [{
                        "field": "project_id",
                        "operator": 1,
                        "values": [projectId]
                    }, {
                        "field": "folder_id",
                        "operator": 1,
                        "values": [file.folderId]
                    }, {
                        "field": "revisions",
                        "operator": 1,
                        "values": ['CURRENT-SET', 'SUPERSEDED']
                    }, {
                        "field": "doc_ref",
                        "operator": 1,
                        "values": [file.docRef]
                    }],
                    "generateShareLink": "false",
                    "expiryAfterDuration": "15d",
                    "showLatestRevision": "false",
                    "sortField": "doc_ref",
                    "sortOrder": "desc",
                    "recordStart": 1,
                    "recordLimit": 1000
                })
            }).then(function(response) {
                $scope.xhr.multiPH.pop();
                var data = response.data || {};
                callback && callback(data.elementVOList || []);
            }, function(xhr) {
                $scope.xhr.multiPH.pop();
                if (xhr.status != -1) {
                    $window.alert("ERROR");
                }
            });

            $scope.xhr.multiPH.push(xhr);
        };

        var isStageAvailableForBind = function(dStage, item, substg) {
            if (substg.role) {
                return {
                    valid: false,
                    reason: alreadyActive
                };
            }

            if (substg.freeze || !dStage.role || ($scope.user.usp.orgID != item.originator.orgID ||
                    (!$scope.data.config.freeStageItem && $scope.user.org != dStage.role))) {
                return {
                    valid: false,
                    reason: noUserAccess
                };
            }

            var stgno = parseInt(substg.stgno) + 1;
            if (stgno < item.stage.length) {
                for (var i = stgno; i < item.stage.length; i++) {
                    if (item.stage[i].role) {
                        return {
                            valid: false,
                            reason: alreadyActive
                        };
                    }
                }
            }

            stgno = parseInt(substg.stgno) - 1;
            if (stgno >= 0) {
                for (var i = stgno; i >= 0; i--) {
                    var prevStg = item.stage[i];
                    if (prevStg.role && prevStg.rag != 'Green') {
                        return {
                            valid: false,
                            reason: alreadyActive
                        };
                    }
                }
            }

            return {
                valid: true
            };
        };

        var createSubStage = function(item, substg, file, targetPstage, dStage, maskKey) {
            substg.lastModifier = $scope.user.usp;
            substg.createdBy = printedBy;

            substg.attrs = {
                MaskKey: maskKey.join('-'),
                DocRef: file.DocRef
            };

            substg.folderId = item.folder && item.folder.folderId || "";
            substg.folderTitle = item.folder && item.folder.folderTitle || "";
            substg.file_link = file.DirectLink;

            lockEditAttributes(file.RevisionId);

            substg.rag = file.DocStatus == 'Published' ? 'Green' : 'Amber';

            substg.revisionId = file.RevisionId.split('$$')[0];
            substg.documentId = file.DocumentId.split('$$')[0];

            substg.role = file.publisherUserId.split('$$')[0];
            $scope.onAuthorChange(substg);

            substg.dueDate = (new Date() > new Date(commonApi.parseDate("dd-M-yy", targetPstage.stageEnd))) ? getCurrentDate() : targetPstage.stageEnd;

            substg.lod = maskKey[9];
            $scope.onSubStgLODChange(substg);

            substg.uploaded = true;
            substg.isPlaceholder = false;
            substg.fileName = file.FileName;

            if (!item.uploaded) {
                item.uploaded = true;
                updateInDB(item, dbMap.subitemdeliverables, 'Update');
            }

            freezePrevStages(item, substg);

            $scope.updateSubMask(dStage, item, substg, targetPstage);

            if (['For Publishing', 'For Sharing'].indexOf(file.DocStatus) > -1) {
                makeDocumentPublicPrivate(file, 1);
            } else {
                makeDocumentPublicPrivate(file, 0);
            }

            $scope.xhr.multiPH.push({ call: 'updateInDB' });
            getServerTime(function(date) {
                substg.modifiedOn = date;
                substg.createdOn = date;

                updateInDB(substg, dbMap.subitemstage, 'Update', function() {
                    $scope.xhr.multiPH.pop();
                    $scope.folder.selectedForListing = $scope.data.folder;
                    $scope.listingData.allItem = [];
                    $scope.folder.list = angular.copy($scope.folder.list);
                    // update remaining docs to map
                    $scope.listingData.remainingDocs--;
                    // refresh non profiled listing.
                    loadListing();
                });

                // update rag
                $scope.refreshCOBie(targetPstage, true);
            });
        };

        var makeDocumentPublicPrivate = function(doc, makePrivate) {
            if ((makePrivate && doc.isPrivate === "true") || (!makePrivate && doc.isPrivate !== "true")) {
                return;
            }

            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/document/updatePublicPrivateDocumentStatus",
                method: 'post',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + '&revisionId=' + doc.RevisionId +
                    '&documentId=' + doc.DocumentId + '&markFileVersion=' + makePrivate + '&selectVersion=4' // markFileVersion : 0 - public and 1 - private and 4 for latest version
            }).then(function(response) {

            }, function() {
                $window.alert('Error while Making document public');
            });
        };

        $scope.exportListing = function(folder) {
            folder = folder || $scope.folder.selectedForListing;
            var hashedFolderId = folder.folderId;
            var f = findFolder($scope.folder.list, hashedFolderId);
            if (f) {
                hashedFolderId = f.folderId;
            }

            var obj = {
                projectId: projectId,
                msgId: angular.element('#msgId').val(),
                folderId: hashedFolderId,
                recordStart: 1,
                recordLimit: 10000,
                sortField: $scope.listingData.sortField,
                sortOrder: $scope.listingData.sortOrder
            };

            var prevForm = document.getElementById('IDP_COBie_FORM');
            prevForm && prevForm.remove && prevForm.remove();

            var form = document.createElement('form');
            form.id = "IDP_COBie_FORM";
            form.method = "POST";
            form.target = "COBIE_DOWNLOAD";
            form.action = ($window.adoddleBaseUrl || "") + "/commonapi/htmlForm/exportNonProfiledDocuments";

            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    var inpt = document.createElement('input');
                    inpt.type = "hidden";
                    inpt.name = key;
                    inpt.value = obj[key];
                    form.appendChild(inpt);
                }
            }

            document.body.appendChild(form);
            form.submit();
        };

        $scope.onFolderChange = function(e, item) {
            loadListing(item);
        };

        $scope.sortListing = function(sortField) {
            var sortOrder = 'desc';
            if ($scope.listingData.sortField == sortField && $scope.listingData.sortOrder == 'desc') {
                sortOrder = 'asc';
            }
            loadListing(null, null, sortField, sortOrder);
        };

        $scope.onPageClick = function(page) {
            if ($scope.listingData.pageNo == page || page < 1 || page > $scope.listingData.size) {
                return;
            }
            loadListing(null, page);
        };

        var bindErrorMsg = "Meta data of file is not matching with existing Item";
        var statusMismatch = "File Status is not sufficient to map file with existing Stage item";
        var poiMismatch = "Status (Suitability) is not sufficient to map file with existing Stage item";
        var itemNotFound = 'Required Deliverable Item not found';
        var userNotAvail = "File publisher don't have access over related Stage Item";
        var alreadyActive = 'Already active item found within related Deliverable Item';
        var noUserAccess = "Current user don't have access over related Stage Item";
        var noFolderAccess = "Current user don't have publish access over ";
        var folderMismatch = "Folder containing current file is not mapped with related Deliverable Item";

        $scope.bindToIdp = function(file) {
            getLatestDocData(file, function(latestFileData) {
                var nonProfiledStatusMap = $scope.data.config.nonProfiledStatues;
                if (nonProfiledStatusMap && nonProfiledStatusMap.length) {
                    var isStatusFound = false;
                    for (var i = 0; i < nonProfiledStatusMap.length; i++) {
                        var s = nonProfiledStatusMap[i];
                        var statusArray = s.status.split(',');

                        if (statusArray.indexOf(latestFileData.DocStatus) > -1) {
                            isStatusFound = true;
                            if (s.pois && s.pois.indexOf(latestFileData.PurposeOfIssue) == -1) {
                                file.error = poiMismatch; //'POI does not match';
                                return;
                            }
                        }
                    }

                    if (!isStatusFound) {
                        file.error = statusMismatch; //'status does not match';
                        return;
                    }
                }

                var configAttrs = $scope.data.config.attributes;
                var maskKey = latestFileData.Attributes[configAttrs['MaskKey']][0] || '';
                maskKey = maskKey.split('-');

                if (!maskKey[0] || !maskKey[1] || !maskKey[2] || !maskKey[3] || !maskKey[4] ||
                    !maskKey[5] || !maskKey[6] || !maskKey[7] || !maskKey[8] || !maskKey[9]) {
                    file.error = bindErrorMsg; //'Mask key is incomplete';
                    return;
                }

                var ProjRef = maskKey[0];
                if (ProjRef != $scope.data.pref) {
                    file.error = bindErrorMsg; //'Project Ref does not match';
                    return;
                }

                var publisherUserId = file.publisherUserId.split('$$')[0];
                var isPublisherExist = false;
                if ($scope.stageItemUsers && $scope.stageItemUsers.length) {
                    for (var i = 0; i < $scope.stageItemUsers.length; i++) {
                        if ($scope.stageItemUsers[i].hUserID == publisherUserId) {
                            isPublisherExist = true;
                            break;
                        }
                    }
                }

                if (!isPublisherExist) {
                    file.error = userNotAvail;
                    return;
                }

                if (!$scope.data.section || !$scope.data.section.length) {
                    return;
                }

                var index = undefined;
                var targetPstage = undefined;
                if ($scope.data.programme && $scope.data.programme.pstage) {
                    for (var k = 0; k < $scope.data.programme.pstage.length; k++) {
                        var pstage = $scope.data.programme.pstage[k];
                        if (pstage.stageRef == maskKey[8]) {
                            targetPstage = pstage;
                            index = k;
                            break;
                        }
                    }
                }

                if (index === undefined) {
                    file.error = bindErrorMsg; //'Stage Reference does not match';
                    return;
                }

                for (var i = 0; i < $scope.data.section.length; i++) {
                    var section = $scope.data.section[i];
                    if (!section.deliverable || !section.deliverable.length) {
                        continue;
                    }

                    for (var j = 0; j < section.deliverable.length; j++) {
                        var d = section.deliverable[j];
                        var dStage = d.stage[index];

                        if (maskKey[7] == d.dref && maskKey[1] == dStage.role) {
                            if (!d.sub_items || !d.sub_items.length) {
                                continue;
                            }

                            for (var k = 0; k < d.sub_items.length; k++) {
                                var si = d.sub_items[k];
                                var siStage = si.stage[index];
                                
                                if (latestFileData.DocTitle == si.dtitle && maskKey[2] == si.volume &&
                                    maskKey[3] == si.location && maskKey[4] == si.file_type && 
                                    maskKey[5] == si.role && maskKey[6] == si.number) {
                                        
                                    var siFolder = si.folder.folderId + "";
                                    if (file.FolderId.split('$$')[0] != siFolder.split('$$')[0]) {
                                        file.error = folderMismatch;
                                        return;
                                    }

                                    var f = findFolder($scope.folder.list, si.folder.folderId);
                                    if (f && f.noAccess === true) {
                                        file.error = noFolderAccess + f.folderTitle;
                                        return;
                                    }

                                    var validationObj = isStageAvailableForBind(dStage, si, siStage);
                                    if (validationObj.valid) {
                                        createSubStage(si, siStage, file, targetPstage, dStage, maskKey);
                                    } else {
                                        file.error = validationObj.reason;
                                    }
                                }
                            }
                        }
                    }
                }

                file.error = itemNotFound;
            });
        };

        /********************** Non idp document binding - end ********************/

        $scope.onFolderSelect = function(e, item) {
            getDocrefAndAttributes(item);
        };

        $scope.removePH = function(substg) {
            if (substg.revisionId)
                activeDeactivatePH(substg, false);
        };

        var setLowLevelData = function(parentObj, targetKey, prefix, nodes) {
            if (!nodes) {
                if (targetKey == 'originator' || targetKey == 'lastModifier') {
                    nodes = ['orgCode', 'orgID', 'userID'];
                }
            }

            if (!prefix) {
                if (targetKey == 'originator') {
                    prefix = 'ori_';
                } else if (targetKey == 'lastModifier') {
                    prefix = 'lm_';
                }
            }

            var obj = parentObj[targetKey];
            if (!obj) {
                return;
            }

            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    var val = obj[key];
                    if (!nodes || !nodes.length || nodes.indexOf(key) > -1) {
                        parentObj[prefix + key] = val;
                    }
                }
            }

            delete parentObj[targetKey];
        }

        /**
         * this function invoked just before submit form
         * called from base.js
         */
        $scope.parseDataBeforeSubmit = function(ignoreChild) {
            if (!isAllowCreate) {
                window.cancelForm && window.cancelForm();
                return;
            }

            if ($scope.data.folder) {
                removeHasing($scope.data.folder, ['folderId', 'targetFolderId']);
                delete $scope.data.folder.projectId;
            }

            delete $scope.data.uploadedOn;

            if (!$scope.data.section || !$scope.data.section.length) {
                return;
            }

            for (var i = 0; i < $scope.data.section.length; i++) {
                var section = $scope.data.section[i];
                if (!section.deliverable || !section.deliverable.length) {
                    continue;
                }

                for (var j = 0; j < section.deliverable.length; j++) {
                    var d = section.deliverable[j];

                    if (!d.sub_items || !d.sub_items.length) {
                        continue;
                    }

                    for (var k = 0; k < d.sub_items.length; k++) {
                        var si = d.sub_items[k];

                        if (si.folder) {
                            removeHasing(si.folder, ['folderId', 'targetFolderId']);

                            delete si.folder.projectId;
                        }

                        if (!si.stage || !si.stage.length) {
                            continue;
                        }

                        for (var l = 0; l < si.stage.length; l++) {
                            var sis = si.stage[l];
                            removeHasing(sis, ['folderId', 'revisionId', 'documentId']);

                            if (sis.author) {
                                delete sis.author.roleID;
                                delete sis.author.userID;
                            }
                        }
                    }
                }
            }

            var submitData = angular.copy($scope.data);
            if (!ignoreChild && isChildForm) {
                if (angular.element('#editORI').val() != "true" && window.currentViewName == 'ORI_VIEW') {
                    submitData.FORM_CUSTOM_FIELDS = {
                        section: [],
                        programme: {}
                    };

                    setLowLevelDataForAll(submitData);
                } else {
                    delete submitData.FORM_CUSTOM_FIELDS;
                    delete submitData.DS_DB_INSERT;
                }
                delete submitData.section;
                delete submitData.programme;
            }
            return submitData;
        };

        var setLowLevelDataForAll = function(submitData) {
            for (var i = 0; i < submitData.programme.pstage.length; i++) {
                var pstg = submitData.programme.pstage[i];
                delete pstg.generateURI;
                setLowLevelData(pstg, 'lastModifier');

                if (!pstg.questions || !pstg.questions.length) {
                    continue;
                }

                for (var j = 0; j < pstg.questions.length; j++) {
                    var q = pstg.questions[j];
                    delete q.generateURI;
                    if (angular.isArray(q.deliverables)) {
                        q.deliverables = q.deliverables.join(',');
                    }
                }
            }

            var sections = [],
                deliverables = [],
                delItems = [];
            for (var i = 0; i < submitData.section.length; i++) {
                var section = submitData.section[i];
                if (section.deliverable && section.deliverable.length) {
                    for (var j = 0; j < section.deliverable.length; j++) {
                        var d = section.deliverable[j];

                        setLowLevelData(d, 'originator');

                        if (d.sub_items && d.sub_items.length) {
                            for (var k = 0; k < d.sub_items.length; k++) {
                                var si = d.sub_items[k];

                                setLowLevelData(si, 'originator');
                                setLowLevelData(si, 'folder', '', ['folderId']);

                                delete si.stage;
                                delete si.generateURI;
                                delItems.push(si);
                            }
                        }

                        delete d.stage;
                        delete d.sub_items;
                        delete d.comments;
                        delete d.generateURI;
                        deliverables.push(d);
                    }
                }

                delete section.deliverable;
                delete section.generateURI;
                sections.push(section);
            }

            submitData.FORM_CUSTOM_FIELDS_IDP = {
                section: sections,
                deliverable: deliverables,
                sub_items: delItems,
                programme: submitData.programme
            };
        }

        /**
         * this function invoked in create.form.js
         * in validateForHTML5Form function to validte the form
         */
        $window.customHTMLMethodBeforeCreate_ORI = function() {
            if (!$scope.ptemplate) {
                $window.alert('Please Import Data from Excel');
                return true;
            }
            if (!$scope.data.pref || !$scope.data.ptitle || !$scope.data.pfacility || !$scope.data.region || !$scope.data.status) {
                $window.alert('Please select mandatory fields!');
                return true;
            }

            if (!checkTemplateData()) {
                $window.alert('All "Deliverable Item" fields are mandatory. Please enter all pending Item values marked in red.');
                return true;
            }

            return false;
        };

        var headerTop = 100;
        var $header = $element.find('#tbl-header');
        var $headerTable = $element.find('#deliverables-header');
        var $content = $element.find('.tbl-content');
        var $contentTable = $element.find('#deliverables-body');
        var header = $element.find('#tbl-header')[0];
        var $win = angular.element(window);
        if (header) {
            headerTop = header.getBoundingClientRect();
            window.currentViewName == 'ORI_PRINT_VIEW' ? headerTop = (headerTop.top - 90) : headerTop = (headerTop.top - 20);
        }
        document.getElementById('tbl-header').style.width = document.getElementById('deliverables-body').clientWidth + "px";
        var onScroll = function(e) {
            var className = 'fixedHeader';
            if (window.currentViewName == 'ORI_PRINT_VIEW') {
                className = 'isOriFixedHeader';
            }
            $header.toggleClass(className, $win.scrollTop() >= headerTop);

            $headerTable.css('width', $contentTable.width() + "px");
            $header.css('width', $content.width() + "px");
        };

        $win.bind("scroll", onScroll);

        $content.bind("scroll", function() {
            $header.scrollLeft($content.scrollLeft());
        });

        var onResize = function(e) {
            $headerTable.css('width', $contentTable.width() + "px");
            $header.css('width', $content.width() + "px");
            $header.scrollLeft($content.scrollLeft());
        };
        angular.element($window).bind("resize", onResize);
        onResize();
        onScroll();

        setTimeout(function() {
            onResize();
            onScroll();
            setTimeout(function() {
                onResize();
                onScroll();
            }, 2000);
        }, 1000);

        if (angular.element('#editORI').val() != "true" && angular.element('#editDraft').val() != "true" && window.currentViewName == 'ORI_VIEW') {
            // fetch template data if template is available initially
            checkCrossWorkspaceData();
        } else {
            call_load_template(null);
        }
    }
    return FormController;
});