/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';


    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification, $filter) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none')
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        var currentViewName = window.currentViewName,
            isRespView = (currentViewName == 'RES_VIEW');

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        var STATIC_OBJECTS = {
            Doc_Details_Group: {
                DSI_DocumentReference: "",
                Doc_Ref: "",
                Doc_Title: "",
                DocumentNo: "",
                Revision: "",
                Transmittal_No: "",
                Transmittal_date: "",
                Date_of_Comments: "",
                Doc_View_URL: "",
                doc_id: "",
                Revision_ID: "",
                Is_Latest_Version: "YES"
            },
            DOC_COMMENTS: {
                DSI_Is_Delete: "",
                CR_isSelected: false,
                Auto_SeraialNo: "",
                Serial_No: "",
                Createor: "",
                Current_Doc_Ref: "",
                Current_Doc_Title:"",
                CurrCommentID: "",
                CreateorUserId: "",
                RespCreateorUserId: "",
                Comment_Details: "",
                Comment_Title: "",
                Comment_Date: "",
                Revision: "",
                Resolved: "",
                Resolved_Reason: "",
                Comment_Response: "",
                Comment_Response_Date: "",
                Comment_Response_Creator: "",
                Current_doc_id:"",
                Current_Revision_ID:"",
                isCommentFromDoc: false,
                CurrComment_Active : true,
                CurrComment_Deactive : false
            },
            PRE_DOC_COMMENTS: {
                dateForSort: "",
                DSI_Is_Delete_Pre: "",
                CR_pre_isSelected: "",
                Pre_Doc_Ref : "",
                Pre_Doc_Title : "",
                Serial_No_Pre: "",
                Auto_SeraialNo_Pre: "",
                Createor_Pre: "",
                PrevCommentID: "",
                PrevCreateorUserId: "",
                PrevRespCreateorUserId: "",
                Comment_Details_Pre: "",
                Comment_Title_Pre: "",
                Comment_Date_Pre: "",
                Revision_Pre: "",
                Resolved_Pre: "",
                Resolved_Pre_Reason: "",
                isCommentResolved: "false",
                Document_Ref_Pre: "",
                Document_Rev_No_Pre: "",
                CBI_Comments_Pre: "",
                Doc_View_URL_Pre: "",
                Form_Url_Link_Pre: "",
                Form_id_Pre: "",
                DB_Form_Id_Pre: "",
                Comment_Response_Date_Pre: "",
                Comment_Response_Creator_Pre: "",
                Pre_doc_id:"",
                Pre_Revision_ID:"",
                isPrevCommentFromDoc: false
            }
        },
            CONSTANTS_OBJ = {
                Contractor_USER_LIST_KEY: 'contractor-user-list',
                Contractor_USER_LIST_LABEL: 'Contractor Users'
            },
            DistributionNodeStr = {
                DS_PROJDISTUSERS: '',
                DS_FORMACTIONS: '',
                DS_ACTIONDUEDATE: ''
            };

        $scope.myFields = $scope.data['myFields'];
        $scope.serverDate = "";
        $scope.todayDateDbFormat = "";
        $scope.todayDateUKFormat = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
        });

        /**
          * Return todays date from time zone
          */
        function getDateFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.ORI_MSG_Custom_Fields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }

        $scope.getDateFromZone = function () {
            return getDateFromZone();
        };
        $scope.tableUtilSettings = {
            COMMENT_Details: {
                tooltip: "select to remove/remove all/Insert new comment data",
                hasDefaultRecord: true,
                checkboxModelKey: "CR_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJECTS.DOC_COMMENTS),
                ADD_NEW_BEFORE_TIP: "Insert before Comment Detail",
                ADD_NEW_AFTER_TIP: "Insert after Comment Detail",
                deleteAllRowTooltip: "Remove all Comment Detail",
                deleteCurrRowMsg: "Remove Comment Detail",
                deleteSelectedMsg: "Remove selected Comment Detail",
                addItemCallBack: function () { },
                deleteItemCallBack: function () { }  
            },
            PRE_COMMENT_Details: {
                tooltip: "select to remove/remove all/Insert previous comment data",
                hasDefaultRecord: true,
                checkboxModelKey: "CR_pre_isSelected",
                hideControlIcon: {
                    editRow: 0,
                },
                newStaticObject: angular.copy(STATIC_OBJECTS.PRE_DOC_COMMENTS),
                ADD_NEW_BEFORE_TIP: "Insert before previous comment Detail",
                ADD_NEW_AFTER_TIP: "Insert after previous comment Detail",
                deleteAllRowTooltip: "Remove all previous comment Detail",
                deleteCurrRowMsg: "Remove previous comment Detail",
                deleteSelectedMsg: "Remove selected previous comment Detail",
                addItemCallBack: function () { },
                deleteItemCallBack: function () { }
            }
        };

        $scope.DS_PROJECTNAME = angular.element('#DS_PROJECTNAME').val();
        $scope.FORM_CUSTOM_FIELDS = $scope.myFields['FORM_CUSTOM_FIELDS'];
        $scope.ORI_MSG_Custom_Fields = $scope.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
        $scope.RES_MSG_Custom_Fields = $scope.FORM_CUSTOM_FIELDS.RES_MSG_Custom_Fields;
        $scope.projectDetails = $scope.FORM_CUSTOM_FIELDS['projectDetails'];
        $scope.Document_Details = $scope.FORM_CUSTOM_FIELDS['Document_Details'];
        $scope.Doc_Details_List = $scope.FORM_CUSTOM_FIELDS.Doc_Details_List;
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.Document_Comments = $scope.FORM_CUSTOM_FIELDS['Document_Comments'];
        $scope.Document_Comments_Pre = $scope.FORM_CUSTOM_FIELDS['Document_Comments_Pre'];
        $scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
        $scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
        var mtaPsrHeaderDetails = $scope.getValueOfOnLoadData('DS_MTA_PSR_Header_Details')[0],
            workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0] || {},
            projDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');

        $scope.workingUserId = workingUserObj.Value.split('|')[0].trim();
        $scope.isValidaAssociation = false;
        $scope.isPreCommInProgress = false;
        $scope.isCurrCommInProgress = false;
        $scope.isDesignStatusHide = false;
        $scope.doc_id = '';
        $scope.Revision_ID = '';
        $scope.docIdRevisionId = '';

        var _5FormDataNode = $scope.Asite_System_Data_Read_Only['_5_Form_Data'],
            DSFormId = _5FormDataNode['DS_FORMID'],
            strIsDraft = _5FormDataNode['DS_ISDRAFT'].toLowerCase();

        var TableNameDetailsMap = {
            Document_Comments: 'Comment',
            Document_Comments_Pre: 'Comment_Pre'
        },
            DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS'),
            DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
            DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');

        /*-- Date Common Instance events Starts --*/
        $scope.isModalOpen = false;
        $scope.tempDate = '';
        $scope.responderList = [];

        var rowIndex = 0,
            whichTable = '',
            whichField = '';

        var offsetOnPage = function (el) {
            var rect = el.getBoundingClientRect(),
                scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
                scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            return {
                top: rect.top + scrollTop + 10,
                right: rect.right,
                bottom: rect.bottom,
                left: rect.left + scrollLeft
            };
        };

        $scope.openCalenderModal = function (event, index, tableName, fieldName) {
            $scope.isModalOpen = false;
            rowIndex = index;
            whichTable = tableName;
            whichField = fieldName;
            var DATE_PICKER_WIDTH_CONST = 255,
                DATE_PICKER_WIDTH_DIFF_CONST = 175,
                currTD = event.target,
                availOffSetOnPage = offsetOnPage(currTD);
            $timeout(function () {
                $scope.isModalOpen = true;
                $timeout(function () {
                    var modalObj = angular.element('#nng-date-modal');
                    if (availOffSetOnPage.right + DATE_PICKER_WIDTH_CONST > $window.screen.availWidth) {
                        modalObj.css({
                            'top': availOffSetOnPage.top + 'px',
                            'left': availOffSetOnPage.left - DATE_PICKER_WIDTH_DIFF_CONST + 'px'
                        });
                    } else {
                        modalObj.css({
                            'top': availOffSetOnPage.top + 'px',
                            'left': availOffSetOnPage.left + 'px'
                        });
                    }
                });
            });
        };
        function structureItemList(setFor, availList) {
            var tempList = [],
                optlabel = '';

            switch (setFor) {
                case CONSTANTS_OBJ.Contractor_USER_LIST_KEY:
                    angular.forEach(availList, function (item) {
                        tempList.push({
                            displayValue: item.split('#')[1].trim(),
                            modelValue: item
                        });
                    });
                    optlabel = CONSTANTS_OBJ.Contractor_USER_LIST_LABEL;
                    break;
            }
            return [{
                optlabel: optlabel,
                options: tempList
            }
            ];
        }
        $scope.Originator_User = true;
        function hideDateModal() {
            $scope.isModalOpen = false;
        }
        $scope.tempDateChange = function (newDate) {
            // set new date from date selection.
            $scope[whichTable][TableNameDetailsMap[whichTable]][rowIndex][whichField] = newDate;
            $scope.tempDate = "";
            $timeout(function () {
                hideDateModal();
            });
        };

        $scope.removeSelectedDate = function (rowIndex, whichTable, whichField) {
            $scope[whichTable][TableNameDetailsMap[whichTable]][rowIndex][whichField] = '';
        };
        $scope.contractorList = structureItemList(CONSTANTS_OBJ.Contractor_USER_LIST_KEY, commonApi.roleUsersListByRoleName('contractor', DS_PROJUSERS_ALL_ROLES));
        $document.on('click', function (event) {
            var modalObj = angular.element('#nng-date-modal')[0],
                calenderObj = angular.element('._720kb-datepicker-calendar')[0];
            if (event && modalObj && calenderObj && !modalObj.contains(event.target) && !calenderObj.contains(event.target)) {
                hideDateModal();
            }
        });

        /**
         * Set ConfigurableAttriburte Type Value in Location dropdown.
         */
        function getConfigurableAttriburteByType(type) {
            var location = [];
            if (type) {
                location = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return location;
        }

        /*-- Date Common Instance events End --*/

        var isAssocFromSameProject = function (assocDocObj) {
            if (assocDocObj.length) {
                var tempDocList = '';
                $scope.validprojectDocId = 'yes';
                for (var i = 0; i < assocDocObj.length; i++) {
                    tempDocList = assocDocObj[i];
                    if (tempDocList.projectId != $scope.projectId.split('$$')[0]) {
                        $scope.validprojectDocId = 'no';
                    }
                }
            }
            if ($scope.validprojectDocId == 'no') {
                Notification.warning({
                    title: 'Warning :: Document form Other Workspace',
                    message: "Document you are trying to Associate is from other Workspace.<br/> Please select document from the same Workspace"
                });
                // delete associated document if found multiple.
                $window.assocDocsObj.length = 0;
                return false;
            }
            return true;
        }, setCurrCommentDetails = function (docDetailsObjList) {
            var DOC_CURR_COMM_List = [];
            // resetting the comments section.
            $scope.Document_Comments.Comment = [];
            for (var i = 0; i < docDetailsObjList.length; i++) {
                var docDetailsObj = docDetailsObjList[i],
                    copyObj = angular.copy(STATIC_OBJECTS.DOC_COMMENTS);
                copyObj['Auto_SeraialNo'] = docDetailsObj.Value1;
                copyObj['Current_Doc_Ref'] = docDetailsObj.Value4;
                copyObj['Current_Doc_Title'] = docDetailsObj.Value15;
                copyObj['Revision'] = docDetailsObj.Value21;
                copyObj['Serial_No'] = docDetailsObj.Value2;
                copyObj['Comment_Title'] = docDetailsObj.Value11;
                copyObj['Comment_Details'] = docDetailsObj.Value9;
                copyObj['Createor'] = docDetailsObj.Value26.split(',')[0];
                copyObj['Comment_Date'] = docDetailsObj.Value27;
                copyObj['Comment_Response'] = docDetailsObj.Value10;
                copyObj['Comment_Response_Creator'] = docDetailsObj.Value5.split(',')[0];
                copyObj['Comment_Response_Date'] = docDetailsObj.Value12;
                copyObj['CreateorUserId'] = docDetailsObj.Value28;
                copyObj['CurrCommentID'] = docDetailsObj.Value29;
                copyObj['RespCreateorUserId'] = docDetailsObj.Value30;
                copyObj['Current_Revision_ID'] = docDetailsObj.Value24;
                copyObj['isCommentFromDoc'] = true;
                copyObj.CurrComment_Deactive = false;
                copyObj.Current_doc_id = docDetailsObj.Value32;
                //copyObj['Resolved'] = docDetailsObj.Value2;
                DOC_CURR_COMM_List.push(copyObj);
            }
            $scope.Document_Comments.Comment = DOC_CURR_COMM_List;
            $scope.isCurrCommInProgress = false;
        },
            /**
             *  Form_id, Auto_SeraialNo, Comment_Title, Comment_Response, Comment_Response_Creator, 
             *  Createor, Serial_No, Comment_Date, Comment_Response_Date, Comment_Details, 
             *  Revision, CR_isSelected, Resolved, DSI_Is_Delete, Doc_View_URL_Pre, 
             *  Document_Ref_Pre, Document_Rev_No_Pre, Form_id_Pre, DB_Form_Id_Pre, Form_Url_Link_Pre
             *  isCommentResolved
             *
            **/
            setPrevCommentDetails = function (prevCommentsDetailObj) {
                var DOC_PREV_COMM_List = [];
                // resetting the comments section.
                $scope.Document_Comments_Pre.Comment_Pre = [];

                if (prevCommentsDetailObj.length == 1 && prevCommentsDetailObj[0].Value24 == '' && prevCommentsDetailObj[0].Value2 == '') {
                    prevCommentsDetailObj = [];
                }
                for (var i = 0; i < prevCommentsDetailObj.length; i++) {
                    var prevComObj = prevCommentsDetailObj[i],
                        copyObj = angular.copy(STATIC_OBJECTS.PRE_DOC_COMMENTS);
                    copyObj['Auto_SeraialNo_Pre'] = prevComObj.Value2;
                    copyObj['Pre_Doc_Ref'] = prevComObj.Value27;
                    copyObj['Pre_Doc_Title'] = prevComObj.Value28;
                    copyObj['Revision_Pre'] = prevComObj.Value11;
                    copyObj['Serial_No_Pre'] = prevComObj.Value7;
                    copyObj['Comment_Title_Pre'] = prevComObj.Value3;
                    copyObj['Comment_Details_Pre'] = prevComObj.Value10;
                    copyObj['Createor_Pre'] = prevComObj.Value6.split(',')[0];
                    copyObj['Comment_Date_Pre'] = prevComObj.Value8;
                    copyObj['CBI_Comments_Pre'] = prevComObj.Value4;
                    copyObj['Comment_Response_Date_Pre'] = prevComObj.Value9;
                    copyObj['Resolved_Pre'] = prevComObj.Value13;
                    copyObj['isCommentResolved'] = (prevComObj.Value13 == "Agree" && prevComObj.Value21 == "true");
                    copyObj['Comment_Response_Creator_Pre'] = prevComObj.Value5.split(',')[0];
                    copyObj['dateForSort'] = prevComObj.Value22;
                    copyObj['PrevCreateorUserId'] = prevComObj.Value23;
                    copyObj['PrevCommentID'] = prevComObj.Value24;
                    copyObj['Resolved_Pre_Reason'] = prevComObj.Value25;
                    copyObj['PrevRespCreateorUserId'] = prevComObj.Value26;
                    copyObj['Pre_Revision_ID'] = prevComObj.Value29;
                    DOC_PREV_COMM_List.push(copyObj);
                }
                $scope.Document_Comments_Pre.Comment_Pre = DOC_PREV_COMM_List;
                $scope.isPreCommInProgress = false;
            },
            /***
             * docDetailsObj will have following sequence.
             * 
             *  Auto_SeraialNo, SeraialNo, project_name, Document_Ref, CommentCreatorName, Document_POI, Document_Issue_No, Document_Published_date, First_Parent_Cmnt, comment_text,   comment_title, comment_creation_date, Doc_distri_user_name, Document_Status, Document_Title, filename, folder_name, has_markup, Doc_Last_upd_date,                      private_public_Doc, Document_Revision, doc_assoc, doc_view_url, revision_id, cout_doc_assoc
             * 
             */
            fillUpRetrivedDetails = function (docDetailsObj) {
                setCurrCommentDetails(docDetailsObj);
                setCoordinatorRecommendedStatus();
                setApprover();
                // association button once if document gets associated.
                angular.element('.dropdown.more-options-dd').hide();
            }, getPrevCommentsDetails = function (assocDocObj) {
                var paramObj = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_MTA_CMNT_Get_Previous_Comments",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_CMNT_Get_Previous_Comments",
                            "fieldValue": assocDocObj
                        }]
                    }
                };

                $scope.isXHRon = true;
                $scope.isPreCommInProgress = true;
                $scope.getCallbackData(paramObj).then(function (response) {
                    var resData = response.data;
                    if (resData) {
                        var retrivedData = angular.fromJson(resData.DS_MTA_CMNT_Get_Previous_Comments).Items.Item;
                        $timeout(function () {
                            $scope.isXHRon = false;
                            setPrevCommentDetails(retrivedData);
                            $timeout(function () {
                                $scope.expandTextAreaOnLoad();
                            }, 100);
                        }, 100);
                    }
                }, function (errorResponse) {
                    Notification.error({ title: 'Server Error', message: 'Error in retriving Previous Comments details' });
                    $scope.isXHRon = false;
                    $scope.isPreCommInProgress = false;
                });
            }, getDocumentDetails = function (assocDocObj) {
                var paramObj = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_MTA_Get_Document_Details",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_Get_Document_Details",
                            "fieldValue": assocDocObj
                        }]
                    }
                };

                $scope.isXHRon = true;
                $scope.isCurrCommInProgress = true;
                $scope.getCallbackData(paramObj).then(function (response) {
                    var resData = response.data;
                    if (resData) {
                        var retrivedData = angular.fromJson(resData.DS_MTA_Get_Document_Details).Items.Item;
                        $timeout(function () {
                            $scope.isXHRon = false;
                            fillUpRetrivedDetails(retrivedData);
                            $timeout(function () {
                                $scope.expandTextAreaOnLoad();
                            }, 100);
                        }, 100);
                    }
                }, function (errorResponse) {
                    Notification.error({ title: 'Server Error', message: 'Error in retriving DocumentData' });
                    $scope.isXHRon = false;
                    $scope.isCurrCommInProgress = false;
                });
            }, calculateDistDate = function (days) {
                var strDueDate = "";
                if (days) {
                    var d = new Date($scope.serverDate);
                    d.setDate(d.getDate() + days);
                    var month = d.getMonth() + 1,
                        day = d.getDate(),
                        strDueDate = d.getFullYear() + '-' +
                            (month < 10 ? '0' : '') + month + '-' +
                            (day < 10 ? '0' : '') + day;
                }
                return strDueDate;
            }, setDistributionNode = function (strUser, strAction, strDays, autoDistNode) {
                var DistributionNode = angular.copy(DistributionNodeStr);
                DistributionNode.DS_PROJDISTUSERS = strUser;
                DistributionNode.DS_FORMACTIONS = strAction;
                DistributionNode.DS_ACTIONDUEDATE = strDays;
                $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users.push(DistributionNode);
                $scope.Asite_System_Data_Read_Write["DS_AUTODISTRIBUTE"] = autoDistNode;
            }, setCoordinatorRecommendedStatus = function () {
                $scope.formStausList = DS_ALL_FORMSTATUS.filter(function (statusObj) {
                    return statusObj.Name.toLowerCase().indexOf('consolidated') < 0;
                });
                var currApproverUserId = $scope.Document_Details.Approver && ($scope.Document_Details.Approver.split('|')[2].split('#')[0].trim() || '');
                if ($scope.workingUserId == currApproverUserId || ($scope.workingUserId == $scope.ORI_MSG_Custom_Fields.Originator_Id)) {
                    $scope.isDesignStatusHide = true;
                }
            }, setResponderList = function () {
                var userList = [];
                angular.forEach(projDistUsers, function (item) {
                    userList.push({
                        displayValue: item.Name.split(',')[0].trim(),
                        modelValue: item.Value.split('#')[0].trim()
                    });
                });
                $scope.responderList = [{
                    optlabel: 'Select User...',
                    options: userList
                }];

            }, setApprover = function () {
                $scope.approverList = DS_PROJUSERS_ALL_ROLES.filter(function (roleObj) {
                    return roleObj.Value.toLowerCase().indexOf('comment approver') > -1;
                });
                $scope.contractorUsersList = DS_PROJUSERS_ALL_ROLES.filter(function (roleObj) {
                    return roleObj.Value.toLowerCase().indexOf('contractor') > -1;
                });
            }, getFormStatusId = function (strStatus) {
                //get status according pass parameter          
                if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                    var statudObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                        return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                    });
                    if (statudObj.length) {
                        return statudObj[0].Value;
                    }
                }
                return "";
            }, approverChange = function (approverVal) {
                var autoDistNode = isRespView ? '13' : '3';
                approverVal = approverVal.split('|')[2].split('#')[0].trim();
                setDistributionNode(approverVal, "3#", calculateDistDate(7), autoDistNode);
                var strFormStatusId = getFormStatusId('Consolidated');
                if (strFormStatusId) {
                    $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "12,21";
                    $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
                }
            }, setRespViewWorkFlow = function () {
                if (!$scope.RES_MSG_Custom_Fields.res_Comment) {
                    var autoDistNode = isRespView ? '13' : '3';
                    setDistributionNode($scope.ORI_MSG_Custom_Fields.Originator_Id, "3#", calculateDistDate(7), autoDistNode);
                    $scope.RES_MSG_Custom_Fields.res_Comment = true;
                }

            }, callOriViewBaseFunc = function () {
                $window.assocDocsObj = $scope.$parent.assoc.files.data || [];
               if(!$scope.ORI_MSG_Custom_Fields.DPCL_FormIdDetails){
                    $window.updateDocsDetailsInXSN();
               }
                // resetting the node first
                $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];
                setResponderList();
            }, callResViewBaseFunc = function () {
                angular.element('.dropdown.more-options-dd').hide();
                setCoordinatorRecommendedStatus();
                // resetting the node first
                $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];
                $scope.approverUserId = $scope.Document_Details['Approver'] && $scope.Document_Details['Approver'].split('|')[2].split('#')[0].trim();
                setResponderList();
            }, getDefinedValueFromAssocDoc = function () {
                if ($window.assocDocsObj.length) {
                    var tempList = ''
                    $scope.validDoc = 'yes';
                    for (var i = 0; i < $window.assocDocsObj.length; i++) {
                        tempList = $window.assocDocsObj[i];
                        if (tempList.status.toLowerCase() == 'consolidated') {
                            $scope.validDoc = 'no'
                        }
                    }
                }
                if ($scope.validDoc == 'no') {
                    Notification.warning({
                        title: 'Warning',
                        message: "The associated document is already under review. Select a different document."
                    });
                    $window.assocDocsObj.length = 0;
                    return false;
                }

                var tmpArray = {},
                    tmpJson = [],
                    docID = '',
                    _keyJson = {},
                    allDocRevId = [];
                for (var i = 0; i < $window.assocDocsObj.length; i++) {
                    tmpArray = $window.assocDocsObj[i],
                        docID = (tmpArray.documentId && tmpArray.documentId.split('$$')[0]);
                    _keyJson = {
                        uploadFilename: tmpArray.uploadFilename || tmpArray.fileName || '',
                        docRef: (tmpArray.isPrivate == true ? tmpArray.docRef.split('#')[0] : tmpArray.docRef) || '',
                        docTitle: (tmpArray.description) || '',
                        revisionId: (tmpArray.revisionId && tmpArray.revisionId.split('$$')[0]) || '',
                        revisionNum: (tmpArray.revisionNum) || '',
                        documentId: docID || '',
                        publishDate: tmpArray.publishDate ? tmpArray.publishDate.split('#')[0] : '',
                        status: tmpArray.status,
                        projectId: tmpArray.projectId ? tmpArray.projectId.split('$$')[0] : ''
                    };
                    tmpJson.push(_keyJson);
                    allDocRevId.push(docID);
                }
                return tmpJson;
            }, setPsrProjectDetails = function () {
                $scope.projectDetails.Planning_Number = mtaPsrHeaderDetails.Value2;
                $scope.projectDetails.ProgramManager = mtaPsrHeaderDetails.Value3;
                $scope.projectDetails.ProjectPSE = mtaPsrHeaderDetails.Value4;
                $scope.projectDetails.ProjectDescr = mtaPsrHeaderDetails.Value5;
                $scope.projectDetails.KeyProject = mtaPsrHeaderDetails.Value6;
                $scope.projectDetails.ConstructionMgr = mtaPsrHeaderDetails.Value7;
                $scope.projectDetails.ProjectStatus = mtaPsrHeaderDetails.Value8;
                $scope.projectDetails.ProjectPhase = mtaPsrHeaderDetails.Value9;
                $scope.projectDetails.ProgramOfficer = mtaPsrHeaderDetails.Value10;
            }, setClientlogo = function () {
                if (workingUserObj.Name) {
                    var strOrgName = workingUserObj.Name.substr(workingUserObj.Name.indexOf(',') + 1).trim();
                    if (strOrgName) {
                        var orgdataObj = commonApi._.filter($scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'), function (val) {
                            return val.Name == strOrgName;
                        });
                        if (orgdataObj.length) {
                            var orgObj = commonApi._.filter($scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo'), function (val) {
                                return val.Value3 == orgdataObj[0].Name.trim();
                            });
                            if (orgObj.length) {
                                $scope.ORI_MSG_Custom_Fields.DS_Logo = orgObj[0].Value4.trim();
                            }
                        }
                    }
                }
            };

        function setActionsCommentCreators() {
            var autoDistNode = isRespView ? '13' : '3',
                commentObj = '';
            // set Respond Action to current Comments.
            for (var i = 0; i < $scope.Document_Comments['Comment'].length; i++) {
                commentObj = $scope.Document_Comments['Comment'][i];
                if (commentObj.CreateorUserId) {
                    setDistributionNode(commentObj.CreateorUserId, "3#", calculateDistDate(3), autoDistNode);
                }
            }
            // set Respond Action to previous Comments if it's not resolved.
            var autoDistNode = isRespView ? '13' : '3';
            for (var i = 0; i < $scope.Document_Comments_Pre['Comment_Pre'].length; i++) {
                var prevCommentObj = $scope.Document_Comments_Pre['Comment_Pre'][i];
                if (prevCommentObj.PrevCreateorUserId && prevCommentObj.Resolved_Pre != 'Agree') {
                    setDistributionNode(prevCommentObj.PrevCreateorUserId, "3#", calculateDistDate(3), autoDistNode);
                }
            }
        }

        $scope.coordinateRecomStatus = function (changedStatus) {
            if (currentViewName == 'RES_VIEW') {
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "12,21";
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = changedStatus;
            }
        };
        //add New Row In Document Cuurent Comment
        $scope.AddNewItem = function (repeatingData, objKeyName ){
            var newRowObject = angular.copy(STATIC_OBJECTS[objKeyName] );
            repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad();           
        };
        // Deactive Flag set
        $scope.deactiveComment = function ($index, repeatindData){
            for(var i = 0; i < repeatindData.length; i++){
                if(i == $index){
                    repeatindData[i].CurrComment_Deactive = true;
                }
            }
        }
        $scope.userSelectionChange = function (selectedItem, index, fromTable, fromColumn) {
            $scope[fromTable][TableNameDetailsMap[fromTable]][index][fromColumn] = selectedItem.displayValue;
        };
        /**
         * get Receive Dynamic Package Comment Log data 
         */
        function getDPCLFormIdDetaOnCallBack() {
            var fieldValue = $scope.ORI_MSG_Custom_Fields.DPCL_FormIdDetails;
            if (fieldValue) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_MTA_Dynamic_Package_Comment_Log_data",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_Dynamic_Package_Comment_Log_data",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var dpclDetails = JSON.parse(response.data.DS_MTA_Dynamic_Package_Comment_Log_data).Items.Item;
                    }
                    if (currentViewName == 'ORI_VIEW') {
                        if (dpclDetails.length) {
                            // set logo after valid document is selected.                    
                            setClientlogo();
                            $scope.isValidaAssociation = true;
                            $scope.Doc_Details_List.Doc_Details_Group = [];
                            var tempObj,
                                temp1,
                                tempID = '';
                            for (var index = 0; index < dpclDetails.length; index++) {
                                temp1 = dpclDetails[index];
                                if (!tempID) {
                                    tempID = temp1.Value10 + '|' + temp1.Value11;
                                } else {
                                    tempID = tempID + '$$' + temp1.Value10 + '|' + temp1.Value11;
                                }
                                tempObj = angular.copy(STATIC_OBJECTS.Doc_Details_Group);
                                tempObj.Doc_Ref = temp1.Value2,
                                    tempObj.Doc_Title = temp1.Value3,
                                    tempObj.Revision = temp1.Value5,
                                    tempObj.doc_id = temp1.Value10,
                                    tempObj.Revision_ID = temp1.Value11,
                                    $scope.Doc_Details_List.Doc_Details_Group.push(tempObj);
                            }
                            getDocumentDetails(tempID);
                            getPrevCommentsDetails(tempID);
                            $scope.docIdRevisionId = tempID;
                            $scope.doc_id = dpclDetails[0].Value10;
                            $scope.Revision_ID = dpclDetails[0].Value11;
                            if (!DSFormId || strIsDraft == 'yes') {
                                setPsrProjectDetails();
                            }
                        }
                    }
                }, function (error) {
                    window.console && window.console.log(error);
                });
            }
        }
        /**
         * associate the submission package in commenting form
         */
        $window.updateDocsDetailsInXSN = function () {
            if (currentViewName == 'ORI_VIEW') {
                var assocDocObj = getDefinedValueFromAssocDoc() || [];
                if (assocDocObj.length && isAssocFromSameProject(assocDocObj)) {
                    // set logo after valid document is selected.                    
                    setClientlogo();
                    $scope.isValidaAssociation = true;
                    $scope.Doc_Details_List.Doc_Details_Group = [];
                    var tempObj,
                        temp1,
                        tempID = '';
                    for (var index = 0; index < assocDocObj.length; index++) {
                        temp1 = assocDocObj[index];
                        if (!tempID) {
                            tempID = temp1.documentId + '|' + temp1.revisionId;
                        } else {
                            tempID = tempID + '$$' + temp1.documentId + '|' + temp1.revisionId;
                        }
                        tempObj = angular.copy(STATIC_OBJECTS.Doc_Details_Group);
                        tempObj.Doc_Ref = temp1.docRef,
                            tempObj.Doc_Title = temp1.docTitle,
                            tempObj.Revision = temp1.revisionNum,
                            tempObj.doc_id = temp1.documentId,
                            tempObj.Revision_ID = temp1.revisionId,
                            $scope.Doc_Details_List.Doc_Details_Group.push(tempObj);
                    }
                    getDocumentDetails(tempID);
                    getPrevCommentsDetails(tempID);
                    $scope.docIdRevisionId = tempID;
                    $scope.doc_id = assocDocObj[0].documentId;
                    $scope.Revision_ID = assocDocObj[0].revisionId;
                    if (!DSFormId || strIsDraft == 'yes') {
                        setPsrProjectDetails();
                    }
                }
            } else {
                Notification.warning({
                    title: 'Warning :: Not a valid Operation',
                    message: "You can only associate a document while creation time."
                });
            }
        }; 
        $window.removeDocsDetailsFromXSN = function () {
            if (typeof assocDocsObj == 'undefined' || assocDocsObj.length <= 1) {
                Notification.warning({
                    title: 'Scenario Not Valid',
                    message: "There must have an associated document."
                });
                $scope.isValidaAssociation = false;
                angular.element('.dropdown.more-options-dd').show();
            }
        };

        $window.mtaCommentingLogSubmit = function () {
            if (!$scope.isValidaAssociation) {
                $window.removeDocsDetailsFromXSN();
                return !$scope.isValidaAssociation;
            }
            if (currentViewName == 'RES_VIEW') {
                if (!$scope.RES_MSG_Custom_Fields.res_Comment) {
                    $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    setActionsCommentCreators();
                }
                setRespViewWorkFlow();
            }
            if (currentViewName == 'ORI_VIEW') {
                $scope.ORI_MSG_Custom_Fields['DSI_Send'] = $scope.docIdRevisionId;
                approverChange($scope.Document_Details['Approver']);
            }
            $scope.Asite_System_Data_Read_Write['DS_DB_INSERT'] = 'true';
            $element.removeClass('loaded');
            return !$scope.isValidaAssociation;
        };

        // View Base Functions called from here.
        if (currentViewName == 'ORI_VIEW') {
            $scope.disableItem = true;
            if (DSFormId == "") {
                getDPCLFormIdDetaOnCallBack();
                $scope.ORI_MSG_Custom_Fields.Originator_Id = $scope.workingUserId;
            }
            $scope.locationAttrList = commonApi.getItemSelectionList({
                arrayObject: getConfigurableAttriburteByType("Location Attribute"),
                groupNameKey: "",
                modelKey: "Value8",
                displayKey: "Value8"
            });
            callOriViewBaseFunc();
            var assocFiles = angular.element('#btnSaveForm').scope().assoc.files || [];
            !$scope.isValidaAssociation && (assocFiles.data.length = 0) && (assocFiles.index = 0);
        } else if (currentViewName == 'RES_VIEW') {
            $scope.isValidaAssociation = true;
            var temp = $scope.Document_Comments.Comment;
            for (var i = 0; i < temp.length; i++) {
                if (temp.length) {
                    temp[i].Comment_Response_Date = getDateFromZone();
                }
            }
            callResViewBaseFunc();
            $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ASSOC_STATUS_UPDATE'] = "12,21";
            $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = $scope.Document_Details.Comment_StatusCode;
        }
        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        $scope.update();
    }
    return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof mtaCommentingLogSubmit !== "undefined") {
        return mtaCommentingLogSubmit();
    }
}