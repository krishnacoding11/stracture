/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

		// restrict autosave Draft and hide Save Draft button.
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",

			STATIC_OBJ = {
				astaticTest: {
					staticTestSingleCar:"A. Static Test # 1: Single Car",
					A1type:"",
					A2time1:"",
					A2time2:"",
					A2time3:"",
					A3location:"",
					A4WitnessDowner:"",
					A4WitnessIndependentCertifier:"",
					A4WitnessTM:"",
					A4WitnessQR:"",
					A4WitnessBombardier: "",
					A4WitnessQtectic: "",
					A5TestResults:"",
					A6Comments:""
				},
				bstaticTest: {
					staticTestMultipleUnit:"B. Static Test # 1: Multiple Unit",
					B1time1:"",
					B1time2:"",
					B1time3:"",
					B2location:"",
					B3WitnessDowner:"",
					B3WitnessIndependentCertifier:"",
					B3WitnessTM:"",
					B3WitnessQR:"",
					B3WitnessBombardier: "",
					B3WitnessQtectic: "",
					B4TestResults:"",
					B5Comments:""
				}
			};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		$scope.addNewItem = function (repeatingData, addItemFor) {
			var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
			if (addItemFor == "astaticTest") {
                newRowObject.staticTestSingleCar = "A. Static Test # " +  (repeatingData.length + 1) + ": Single Car";
			}
			if (addItemFor == "bstaticTest") {
                newRowObject.staticTestMultipleUnit = "B. Static Test # " + (repeatingData.length + 1) + ": Multiple Unit";
			}
			repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad();
		};

		$scope.removeItem = function (nodeObj, list) {
			var index = list.indexOf(nodeObj);
			list.splice(index, 1);
		};
		// To reset  Index in Static Test: Single Car while remove Row.
		$scope.staticTestSinglecar = function() {
            $timeout(function () {
                var staticTestcar = $scope.oriMsgCustomFields.A_Static_Test['astaticTest'];
                for (var i = 0; i < staticTestcar.length; i++) {
                    staticTestcar[i].staticTestSingleCar = "A. Static Test # " + (i + 1) + ": Single Car";
                }
            }, 200);
		};
		// To reset Index Static Test: Multiple Unit while remove Row.
		$scope.staticTestMultipleunit = function() {
            $timeout(function () {
                var staticTestMulticar = $scope.oriMsgCustomFields.B_Static_Test['bstaticTest'];
                for (var i = 0; i < staticTestMulticar.length; i++) {
                    staticTestMulticar[i].staticTestMultipleUnit = "B. Static Test # " + (i + 1) + ": Multiple Unit";
                }
            }, 200);
		};

		//select at least one checkbox
		$scope.setOneNodeSelected = function (curObj) {
			for (var i in curObj) {
				if (curObj[i] == "Yes") {
						return false;
				}				
			}
			return true;
		};

		$scope.setOneNodeSelectedAttandace = function (curObj) {
			for (var i in curObj) {
				if (curObj[i] == "YES") {
						return false;
				}				
			}
			return true;
		};
          
		$scope.update();

		function formSubmitCallBack()
		{
			$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.todayDateUKFormat + " " + $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME;
			return false;
		}
		$window.oriformSubmitCallBack = function () {
			formSubmitCallBack();
		};
		$window.draftSubmitCallBack = function () {
			formSubmitCallBack();
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}