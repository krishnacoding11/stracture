/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, $filter,  Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        var currentViewName = window.currentViewName;
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    headerScrollBind();
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }
        var dsAsiConfigSets = $scope.getValueOfOnLoadData('DS_GET_ATTRIBUTE_SET_DTLS');
        var CONSTANTS_OBJ = {
           CONFIG_PMPSUB_LIST_NAME: "PMP104 Sub Section"
        };
        var STATIC_OBJECTS = {
            deliverablesDetails: {
                isShow: true,
                PMP104_Section: "",
                Location: "",
                CSI_Code: "",
                Due_Date: "",
                placeHolderStatus: "",
                placeHolderUrl: "",
                deDe_isSelected: "",
                guId: "",
                rowIndex: "",
                selectedFolderName: "",
                folderData: {
                    rowIndex: "",
                    folderName: "",
                    folderPath: "",
                    folderId: ""
                },
                docRef: "",
                asignee: "",
                fileName: "",
                vdrCodeTitle: "",
                vdrMilestone: "",
                vdrMilestoneDate: "",
                placeHolderCreationDate: "",
                remainingDays: "",
                isNegativeDays: "",
                resubmissionDate: "",
                publishDate: "",
                BID: "no",
                MDR: "no",
                IOM: "no",
                docFormat: "",
                docRev: "-",
                docStatus: "",
                docRemarks: "",
                docType: "",
                purposeOfIssue: "",
                poiID: "",
                vdrDocNumber: "",
                docSysMetaData: {
                    rowIndex: ""
                },
                selectedDisiplinVal: "",
                selectedCSICodeVal: "",
                selectedVdrCodeVal: "",
                docCustomMetaData: {
                    rowIndex: "",
                    attrDiscipline: {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    },
                    attrCSICode: {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    },
                    attrVdrCode: {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    },
                    attrVdrNumber: {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    },
                    attrDocType: {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    }, 
                    attrPMP104Section : {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    },
                    attrLocation : {
                        attributeId: "",
                        attributeValue: "",
                        inputTypeId: "",
                        defaultName: ""
                    }
                },
                trackerDetails: {
                    rowIndex: "",
                    documentIds: "",
                    revisionIds: "",
                    transactionId: "",
                    creationStatus: "",
                    filterCode: ""
                }
            },
            schedulConfigObj: {
                scheduleId: undefined,
                isDefaultSchedule: false,
                isSchDisable: false,
                scheduleCode: '',
                scheduleDesc: '',
                scheduleDays: ''
            },
            docRefObj: {
                Value: ""
            }
        },
            dsProjUsersAllRolse = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
            projDistUsersAll = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS'),
            workspaceFolderPath = $scope.getValueOfOnLoadData('DS_MTA_Get_WorkspaceFolderpath'),
            workspacePOIList = $scope.getValueOfOnLoadData('DS_ProjectPOIList'),
            availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
            WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID'),
            DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID'),
            mtaHeaderDetails = $scope.getValueOfOnLoadData("DS_MTA_PSR_Header_Details"),
            allRoles = [],
            submitFlag = false,
            guidNotAvailList = [],
            customAttrValueMap = {
                'selectedDisiplinVal': 'attrDiscipline',
                'selectedCSICodeVal': 'attrCSICode',
                'selectedVdrCodeVal': 'attrVdrCode',
                'vdrDocNumber': 'attrVdrNumber',
                'docType': 'attrDocType',
                'PMP104_Section': 'attrPMP104Section',
                'Location': 'attrLocation',
            },
            custAttrNameListMap = { // for bulk apply 
                'selectedDisiplinVal': 'disiplinCustAttr',// CSI Division
                'selectedCSICodeVal': 'CSICodeCustAttr',// CSI code
                'selectedVdrCodeVal': 'vdrCodeCustAttr',//PMP104 Sub Section
                'vdrDocNumber': 'vdrDocNumCustAttr',
                'PMP104_Section': 'PMP104SecCustAttr',
                'Location': 'locationCustAttr',
                'docType': 'docTypeCustAttr'
            },
            avilRowDocRefFolderWise = {},
            distributionNodeStr = {
                DS_PROJDISTUSERS: '',
                DS_FORMACTIONS: '',
                DS_ACTIONDUEDATE: ''
            },
            onLoadJsonBackup = {
                resubmissionDays: '',
                deliveryToSite: '',
                noOfDays: '',
                readyExWorks: '',
                runDate: '',
                deliverablesDetails: []
            },
            schDefined = {};

        $scope.myFields = $scope.data['myFields'];
        $scope.serverDate = "";
        $scope.todayDateDbFormat = "";
        $scope.todayDateUKFormat = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
            if (!$scope.DSFormId) {
                var serverDateObj = new Date(serverDate);
                serverDateObj.setDate(serverDateObj.getDate() + 5);
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
            }
        });
        $scope.ORI_MSG_Custom_Fields = $scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.projectDetails = $scope.ORI_MSG_Custom_Fields.projectDetails;
        $scope.titleDetails = $scope.ORI_MSG_Custom_Fields['titleDetails'];
        $scope.packageDetails = $scope.ORI_MSG_Custom_Fields['packageDetails'];
        $scope.deliverablesDetails = $scope.ORI_MSG_Custom_Fields['deliverablesDetails'] || [];
        $scope.deliverableNotes = $scope.ORI_MSG_Custom_Fields['deliverableNotes'];
        $scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
        $scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
        $scope.DSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
        $scope.dsDbInserted = $scope.Asite_System_Data_Read_Write['ORI_MSG_Fields']['DS_DB_INSERT'];
        $scope.isFieldsDisplayOnly = ($scope.dsDbInserted && $scope.packageDetails.isStatusAwarded == 'Yes');
        $scope.workspaceName = $scope.Asite_System_Data_Read_Only['_3_Project_Data']["DS_PROJECTNAME"];
        $scope.scheduleDetails = $scope.packageDetails['scheduleDetails'] || [];
        $scope.packageEngineersList = [];
        $scope.availableFoldersList = [];
        $scope.userAsigneeList = [];
        $scope.workspacePOIList = [];
        $scope.hashedFoldersList = [];
        $scope.allUsersList = [];
        $scope.actionList = [];
        $scope.attributeList = [];
        $scope.cutomAttrList = [];
        $scope.disiplinCustAttr = {};
        $scope.CSICodeCustAttr = {};
        $scope.docTypeCustAttr = {};
        $scope.vdrCodeCustAttr = {};
        $scope.vdrDocNumCustAttr = {};
        $scope.locationCustAttr = {};
        $scope.PMP104SecCustAttr = {};
        $scope.item = {
            folderName: '',
            folderPath: '',
            folderId: '',
            rowIndex: '',
            isForBulkApply: false
        };
        $scope.xhr = {
            activeAjaxCallCount: 0,
            guIdXhr: false,
            placeholder: false,
            platformXhr: false
        };
        $scope.tableUtilSettings = {
            deliverablesDetails: {
                tooltip: "select to remove/remove all/Insert new Deliverables data",
                hasDefaultRecord: true,
                checkboxModelKey: "deDe_isSelected",
                hideControlIcon: {
                    editRow: 0,
                    insertBefore: 0,
                    deleteAllRow: 0
                },
                newStaticObject: angular.copy(STATIC_OBJECTS.deliverablesDetails),
                ADD_NEW_BEFORE_TIP: "Insert before Deliverables Details",
                ADD_NEW_AFTER_TIP: "Insert after Deliverables Details",
                deleteAllRowTooltip: "Remove all Deliverables Details",
                deleteCurrRowMsg: "Remove Deliverables Details",
                deleteSelectedMsg: "Remove selected Deliverables Details",
                addItemCallBack: function () {

                },
                editRowCallBack: function () {

                },
                deleteItemCallBack: function () {
                    updateAvailalbeDocRefList();
                }
            }
        };
        $scope.isBulkApply = false;
        $scope.bulkApplyObj = {
            PMP104_Section: "",
            Location: "",
            CSI_Code: "",
            Due_Date: "",
            selectedFolderName: "",
            folderData: {
                rowIndex: "",
                folderName: "",
                folderPath: "",
                folderId: ""
            },
            docRef: "",
            asignee: "",
            fileName: "",
            vdrCodeTitle: "",
            vdrMilestone: "",
            vdrMilestoneDate: "",
            placeHolderCreationDate: "",
            BID: "no",
            MDR: "no",
            IOM: "no",
            docFormat: "",
            docRev: "-",
            docStatus: "",
            docRemarks: "",
            docType: "",
            purposeOfIssue: "",
            poiID: "",
            vdrDocNumber: "",
            selectedDisiplinVal: "",
            selectedCSICodeVal: "",
            selectedVdrCodeVal: "",
            docCustomMetaData: {
                attrDiscipline: {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                },
                attrCSICode: {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                },
                attrVdrCode: {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                },
                attrVdrNumber: {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                },
                attrDocType: {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                }, 
                attrPMP104Section : {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                },
                attrLocation : {
                    attributeId: "",
                    attributeValue: "",
                    inputTypeId: "",
                    defaultName: ""
                }
            }
        };
        $scope.filterObj = {
            isIncludeFailed: false,
            dateStatus: "all",
            placeHolderDocStatus: 'all'
        };
        // used it from https://www.w3.org/TR/html5/sec-forms.html#email-state-typeemail
        // which is used for input type=Email.
        $scope.emailRegExPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        $scope.wamRegExPattern = '([\+\-]?[0-9]{0,3})([^(a|A)])(a|A)$';
        var isImported = $scope.ORI_MSG_Custom_Fields.isImported.trim().toLowerCase(),
            strIsDraft = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'].toLowerCase(),
            dateFormatMap = {
                "en_GB": "dd-M-yy",
                "fr_FR": "d M yy",
                "es_ES": "dd-M-yy",
                "ru_RU": "dd.mm.yy",
                "en_AU": "dd/mm/yy",
                "en_CA": "d-M-yy",
                "en_US": "M d, yy",
                "zh_CN": "yy-m-d",
                "de_DE": "dd.mm.yy",
                "ga_IE": "d M yy",
                "en_ZA": "dd M yy",
                "ja_JP": "yy/mm/dd",
                "ar_SA": "dd/mm/yy",
                "en_IE": "dd-M-yy"
            },
            userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy";

        $scope.notCreatedPlaceHolder = [];
        $scope.isEditORI = ($scope.DSFormId != '' && strIsDraft == 'no');
        $scope.invalidDataLoaded = false;
        // to get Custom Attribute On Load.
        var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.projectNoList = commonApi._.where(customAttr, {
            Value3: "Project No",
            Value11: "Active"
        }) || [];
        $scope.vdrTemplateList = commonApi._.where(customAttr, {
            Value3: "VDR Template",
            Value11: "Active"
        }) || [];
        $scope.docrefDropdownList =[
            {
                value: "Project No--r1"
            },{
                value: "Package No--r2"
            },{
                value: "PMP104 Sub Section Code--r3"
            },{
                value: "CSI Division Code--r4"
            }
        ];
        $scope.docRefDropdownChange= function(index){
            var docRefConfig = $scope.ORI_MSG_Custom_Fields.docRefConfiguration.docRefConfigurationGroup.docRefConfigs;
            if(docRefConfig[index].Value){
                for(var i=0; i<docRefConfig.length; i++){
                    if(index != i && docRefConfig[index].Value == docRefConfig[i].Value){
                        docRefConfig[index].Value = "";
                        alert('Dropdown Value should not be duplicate');
                        break;
                    }
                }
            }
        };

        $scope.onGenerateDocRefClick = function(){
            if($scope.xhr.drXhr){
                return;
            }
            var docrefConf = $scope.ORI_MSG_Custom_Fields.docRefConfiguration;
            var docrefConfValues = docrefConf.docRefConfigurationGroup.docRefConfigs;
            var autoNumLength = docrefConf.AutoNumLength || "3";
            var strConcated = '', strConcatedDocRefs = "";
            if(!$scope.ORI_MSG_Custom_Fields.docRefConfigured){
                alert('Doc ref configuration not done');
                return;
            }
            for(var i = 0; i< docrefConfValues.length; i++){
                if(docrefConfValues[i].Value.toLowerCase().indexOf("project no") != -1  && (!$scope.projectNoList[0] || !$scope.projectNoList[0].Value8)){
                    alert('Project no is not available');
                    return;
                }
                if(docrefConfValues[i].Value.toLowerCase().indexOf("package no") != -1 && !$scope.packageDetails['package']){
                    alert('Package no is not available');
                    return;
                }
                if(i == docrefConfValues.length - 1){
                    strConcated = strConcated + docrefConfValues[i].Value.split('--')[1];
                }else{
                    strConcated = strConcated + docrefConfValues[i].Value.split('--')[1] + docrefConf.separator;
                }
            }
            strConcated = strConcated.toLowerCase();
            strConcatedDocRefs = docrefConf.separator + "||" + autoNumLength + "||";
            angular.forEach($scope.deliverablesDetails, function(item){
                var docRef = '';
                if(!item.docRef){
                    if((strConcated.indexOf('r3') == -1 || !!item.selectedVdrCodeVal) && (strConcated.indexOf('r4') == -1 || !!item.selectedDisiplinVal)){
                        docRef = strConcated;
                        if($scope.projectNoList[0] && $scope.projectNoList[0].Value8){
                            docRef = docRef.replace('r1', $scope.projectNoList[0].Value8);
                        }else{
                            docRef = docRef.replace('r1', "");
                        }
                        docRef = docRef.replace('r2', $scope.packageDetails['package']);
                        docRef = docRef.replace('r3', item.selectedVdrCodeVal);
                        docRef = docRef.replace('r4', item.selectedDisiplinVal);
                        item.docRef = docRef;
                        item.reqforAutonum = 'yes';
                        strConcatedDocRefs = strConcatedDocRefs + docRef + "#";
                    }
                }
            });
            if($scope.deliverablesDetails.length){
                setdocRefWithautoNumber(strConcatedDocRefs);
            }
        };

        function setdocRefWithautoNumber(strConcatedDocRefs) {
            var fieldValue = strConcatedDocRefs;
            if (fieldValue) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_MTA_GETAUTOCREATEDOCREF",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_GETAUTOCREATEDOCREF",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.xhr.drXhr = $scope.getCallbackData(form).then(function (response) {
                    var a = 0;
                    if (response.data) {
                        var autoDocRefs = JSON.parse(response.data['DS_MTA_GETAUTOCREATEDOCREF']).Items.Item;
                        for (var i = 0; i < autoDocRefs.length; i++) {
                            for (var j = 0; j < $scope.deliverablesDetails.length; j++) {
                                if($scope.deliverablesDetails[j].reqforAutonum == 'yes' && autoDocRefs[i].Value1 == $scope.deliverablesDetails[j].docRef){
                                    $scope.deliverablesDetails[j].docRef = autoDocRefs[i].Value2;
                                    delete($scope.deliverablesDetails[j].reqforAutonum);
                                    break;
                                }
                            }
                        }
                    }
                    $scope.xhr.drXhr = false;
                }, function (error) {
                    $scope.xhr.drXhr = false;
                    var errorMsg = 'Error retriving DocumentData<br/>' + error;
                    Notification.error({
                        title: 'Server Error',
                        message: errorMsg
                    });
                });
            }
        }

        /**
         * set psr detail in header
         */
        function setPsrProjectDetails() {
            if(!mtaHeaderDetails || !mtaHeaderDetails.length){
                return;
            }
            mtaHeaderDetails = mtaHeaderDetails[0];
            $scope.projectDetails.Planning_Number = mtaHeaderDetails.Value2;
            $scope.projectDetails.ProgramManager = mtaHeaderDetails.Value3;
            $scope.projectDetails.ProjectPSE = mtaHeaderDetails.Value4;
            $scope.projectDetails.ProjectDescr = mtaHeaderDetails.Value5;
            $scope.projectDetails.KeyProject = mtaHeaderDetails.Value6;
            $scope.projectDetails.ConstructionMgr = mtaHeaderDetails.Value7;
            $scope.projectDetails.ProjectStatus = mtaHeaderDetails.Value8;
            $scope.projectDetails.ProjectPhase = mtaHeaderDetails.Value9;
            $scope.projectDetails.ProgramOfficer = mtaHeaderDetails.Value10;
        }

        function setClientlogo() {
			var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
            if (WorkingUserID.length) {
				var strOrgName = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.ORI_MSG_Custom_Fields.DS_ADD_LINK = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
        }
        
        function setDocRefAsFormcontent(){
            var seperator = $scope.ORI_MSG_Custom_Fields.docRefConfiguration.separator || "";
            var foundDocRef = false;
            var docRefsconcated = seperator + "||";
            for (var j = 0; j < $scope.deliverablesDetails.length; j++) {
                if($scope.deliverablesDetails[j].docRef){
                    docRefsconcated  = docRefsconcated + $scope.deliverablesDetails[j].docRef.trim() + "#";
                    foundDocRef = true;
                }
            }
            if(foundDocRef){
                docRefsconcated = docRefsconcated.substring(0, docRefsconcated.length - 1);
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMCONTENT'] = docRefsconcated;
            }else{
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMCONTENT'] = "";
            }
        }

        $scope.hasDuplicateDocRef = function(){
            var hasDuplicate = false;
            $scope.duplicateDocRefIndex = [];
            if($scope.deliverablesDetails.length > 1){
                angular.forEach($scope.deliverablesDetails, function(item, index){
                    if(item.docRef){
                        var nextIndex = index+1;
                        if(item.docRef &&  nextIndex < $scope.deliverablesDetails.length){
                            for(var j= nextIndex; j<$scope.deliverablesDetails.length; j++){
                                if($scope.deliverablesDetails[j].docRef && item.docRef == $scope.deliverablesDetails[j].docRef){
                                    hasDuplicate = true;
                                    if($scope.duplicateDocRefIndex.indexOf(nextIndex + 1) == -1){
                                        $scope.duplicateDocRefIndex.push(nextIndex + 1);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            return hasDuplicate;
        };

        $scope.hasPastDueDates = function(){
            var pastDates = false;
            var todaysDate =  getDateFromZone();
            for(var i = 0; i < $scope.deliverablesDetails.length; i++){
                if(!$scope.deliverablesDetails[i].trackerDetails.revisionIds && $scope.deliverablesDetails[i].Due_Date && $scope.deliverablesDetails[i].Due_Date < todaysDate){
                    pastDates = true;
                    break;
                }
            }
            return pastDates;
        }

        var findFolder = function (list, folderId) {
            for (var i = 0; i < list.length; i++) {
                var folder = list[i];
                var targetFolderId = (folderId + "").split('$$')[0];
                var currentFolderId = (folder.folderId + "").split('$$')[0];
                if (currentFolderId === targetFolderId) {
                    return folder;
                } else if (folder.childFolders && folder.childFolders.length) {
                    var found = findFolder(folder.childFolders, folderId);
                    if (found) {
                        return found;
                    }
                }
            }
        },
            structureItemList = function (setFor, availList, optlabel) {
                var foldersList = [];
                if (setFor == 'for-folder-path') {
                    angular.forEach(availList, function (item) {
                        foldersList.push({
                            displayValue: item.Name,
                            folderName: item.Value1,
                            modelValue: item.Value2
                        });
                    });
                } else if (setFor == 'for-user-asignee') {
                    angular.forEach(availList, function (item) {
                        foldersList.push({
                            displayValue: item.Name.split(',')[0].trim(),
                            modelValue: item.Value
                        });
                    });
                }
                return [{
                    optlabel: optlabel,
                    options: foldersList
                }];
            },
            getFormStatusId = function (strStatus) {
                //get status according pass parameter          
                if (availFormStatuses && availFormStatuses.length > 0) {
                    var statudObj = commonApi._.filter(availFormStatuses, function (val) {
                        return val.Name.trim().toLowerCase() == strStatus.trim().toLowerCase();
                    });
                    if (statudObj.length) {
                        return statudObj[0].Value;
                    }
                }
                return "";
            },
            setCustomAttributeFields = function () {
                for (var i = 0; i < $scope.attributeList.length; i++) {
                    var attrObj = $scope.attributeList[i];
                    if (attrObj.attributeId > 1000) {
                        $scope.cutomAttrList.push(attrObj);
                        if (attrObj.attributeName.toLowerCase() == "csi division") {
                            $scope.disiplinCustAttr = attrObj;
                        }if (attrObj.attributeName.toLowerCase() == "csi code") {
                            $scope.CSICodeCustAttr = attrObj;
                        } else if (attrObj.attributeName.toLowerCase() == "document type") {
                            $scope.docTypeCustAttr = attrObj;
                        } else if (attrObj.attributeName.toLowerCase() == "pmp104 sub section") {
                            $scope.vdrCodeCustAttr = attrObj;
                        } else if (attrObj.attributeName.toLowerCase() == "vdr doc number" || attrObj.attributeName.toLowerCase() == "vdrdocnumber") {
                            $scope.vdrDocNumCustAttr = attrObj;
                        }else if (attrObj.attributeName.toLowerCase() == "location") {
                            $scope.locationCustAttr = attrObj;
                        }else if (attrObj.attributeName.toLowerCase() == "pmp104 section") {
                            $scope.PMP104SecCustAttr = attrObj;
                        }
                    }
                }
            },
            fetchActionAndAttributeDetails = function (folderId) {
                // get list from the first Folder Only.		
                $scope.xhr.platformXhr = true;
                commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getActionAndAttributeDetails",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "projectId=" + $scope.projectId + '&folderId=' + folderId + '&KeyToSearchAction=UploadController117&subActionType=2'
                }).then(function (response) {
                    var data = response.data || {};
                    $scope.actionList = (data.myHashMap || {}).actionVOList || [];
                    $scope.attributeList = ((data.myHashMap || {}).filesAttributeDataVO || {}).allAttributesList || [];
                    if ($scope.attributeList) {
                        setCustomAttributeFields();
                    }
                    if (isImported == "yes" && !$scope.isFieldsDisplayOnly) {
                        setRemainingDataForImport();
                    }
                    $scope.xhr.platformXhr = false;
                }, function () {
                    $scope.xhr.platformXhr = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while loading Attribute list!!'
                    });
                });
            },
            allHashedFolderList = function () {
                $scope.xhr.platformXhr = true;
                commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/folder/getAllFoldersForProject",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "projectId=" + $scope.projectId
                }).then(function (response) {
                    $scope.xhr.platformXhr = false;
                    var data = response.data || [];
                    data = data[0] || {};
                    data = data.childFolders || [];
                    $scope.hashedFoldersList = data;
                    if ($scope.hashedFoldersList.length) {
                        var folderId = workspaceFolderPath.length && workspaceFolderPath[0].Value2 || '',
                            f = findFolder($scope.hashedFoldersList, folderId);
                        if (f) {
                            folderId = f.folderId;
                        } else {
                            folderId = $scope.hashedFoldersList[0].folderId || '';
                        }
                        folderId && fetchActionAndAttributeDetails(folderId);
                    }
                }, function () {
                    $scope.xhr.platformXhr = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while fetching folders list of current workspace'
                    });
                });
            },
            setAllRolesList = function () {
                allRoles = dsProjUsersAllRolse.map(function (roleObj) {
                    return roleObj.Value.split('|')[0].trim();
                });
                allRoles = commonApi._.uniq(allRoles);
            },
            fetchAllRolesUserList = function (role) {
                var role = allRoles.join(',').replace(/,/g, '#');
                $scope.xhr.platformXhr = true;
                commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/role/getUsersByProjectRoleName",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "projectId=" + $scope.projectId + '&roleNames=' + encodeURIComponent(role)
                }).then(function (response) {
                    $scope.xhr.platformXhr = false;
                    $scope.allUsersList = response.data || [];
                }, function () {
                    $scope.xhr.platformXhr = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while fetching users list of current workspace'
                    });
                });
            },
            getAllFoldersForProject = function () {
                $scope.availableFoldersList = structureItemList('for-folder-path', workspaceFolderPath, "Workspace Folders' List");
            },
            setPOIforWorkspace = function () {
                $scope.workspacePOIList = workspacePOIList;
            },
            setUserAsigneeList = function () {
                $scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Assignee Users' List");
            },
            setPackageEngineerList = function () {
                $scope.packageEngineersList = commonApi._.filter(dsProjUsersAllRolse, function (roleUserObj) {
                    var roleNameString = roleUserObj.Value.trim().toLowerCase();
                    return (roleNameString.indexOf('package engineers') > -1);
                });
            },
            getDistDetails = function (user, action, actionDueDate) {
                var obj = {
                    selectedDistGroups: "",
                    selectedDistUsers: [{
                        hUserID: user.userID,
                        fname: user.fname,
                        lname: user.lname,
                        user_type: user.user_type,
                        hActionID: action,
                        actionDueDate: actionDueDate,
                        email: 'true'
                    }],
                    selectedDistOrgs: [],
                    selectedDistRoles: [],
                    tempId: 0
                };
                return encodeURIComponent(angular.toJson(obj));
            },
            addZeroPad = function (number, minChar) {
                number = number + "";
                while (number.length < minChar) {
                    number = "0" + number;
                }

                return number;
            },
            getCurrentTime = function () {
                var date = new Date();
                var h = addZeroPad(date.getHours(), 2);
                var m = addZeroPad(date.getMinutes(), 2);
                var s = addZeroPad(date.getSeconds(), 2);

                return (h + ":" + m + ":" + s);
            },
            getCustomAttrValues = function (deliverablesDetailsObj) {
                var customAttrs = [];
                for (var property in deliverablesDetailsObj.docCustomMetaData) {
                    if (deliverablesDetailsObj.docCustomMetaData.hasOwnProperty(property)) {
                        // Do things here
                        (typeof deliverablesDetailsObj.docCustomMetaData[property] == "object") && customAttrs.push(deliverablesDetailsObj.docCustomMetaData[property]);
                    }
                }
                return customAttrs;
            },
            createPlaceHolders = function (deliverablesDetailsObj, callbackFun, currentIndex) {
                var publisDuedate = '';
                var placeholderDetail = {
                    "placeholderList": [{
                        "filename": "Not Uploaded",
                        "documentRef": deliverablesDetailsObj.docRef,
                        "revision": '-', // "revision": deliverablesDetailsObj.docRev,
                        "documentTitle": deliverablesDetailsObj.vdrCodeTitle,
                        "purposeOfIssue": deliverablesDetailsObj.poiID, // setting id from user drop down dropdown for eg: 0 for ---
                        "isPrivateRevision": false,
                        "revisionNotes": '', // deliverablesDetailsObj.docRemarks,
                        "zipFileName": "",
                        "paperSize": "",
                        "scale": "",
                        "customAttributes": getCustomAttrValues(deliverablesDetailsObj),
                        "tempId": 0,
                        "isCheckIn": false
                    }]
                };
                // Initialize blank Dist Obj
                var distObj = encodeURIComponent(angular.toJson({
                    "selectedDistGroups": "",
                    "selectedDistUsers": [],
                    "selectedDistOrgs": [],
                    "selectedDistRoles": [],
                    "tempId": 0
                }));
                if (deliverablesDetailsObj.asignee) {
                    var userAsigneeId = deliverablesDetailsObj.asignee.split('#')[0],
                        user = commonApi._.filter($scope.allUsersList, function (userObj) {
                            return userObj.hUserID == userAsigneeId;
                        })[0] || {},
                        publishActionObj = commonApi._.filter($scope.actionList, function (actionObj) {
                            return actionObj.actionName == 'For Publishing';
                        })[0] || {}; // for Upload
                    if(deliverablesDetailsObj.Due_Date){
                        publisDuedate = (commonApi.formatDate(userDateFormat, new Date(deliverablesDetailsObj.Due_Date), {
                            lang: true
                        }) + " " + getCurrentTime());
                    }else{
                        publisDuedate = (commonApi.formatDate(userDateFormat, new Date(deliverablesDetailsObj.placeHolderCreationDate), {
                            lang: true
                        }) + " " + getCurrentTime());
                    }
                    distObj = getDistDetails(user, publishActionObj.actionID, publisDuedate);
                }
                var folderId = deliverablesDetailsObj.folderData.folderId;
                var f = findFolder($scope.hashedFoldersList, folderId);
                if (f) {
                    folderId = f.folderId;
                }

                $scope.xhr.placeholder = commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/document/createPlaceholder",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    rowIndex: currentIndex + 1,
                    data: "projectId=" + $scope.projectId + '&folderId=' + folderId +
                        '&filename1=Not Uploaded' +
                        '&docRef1=' + encodeURIComponent(deliverablesDetailsObj.docRef) +
                        '&revision1=---' +
                        '&hasAttachment1=true' +
                        '&rowNumbers=1' +
                        '&forPublishing=false' +
                        '&validationType=2' +
                        '&isFromPlaceholder=true' +
                        '&subject=' +
                        '&noAccessUsers=' +
                        '&isValidationRequired=true' + // this parameter will check the platforms validations while creating placeholder if true is there.
                        '&placeholderDetails=' + encodeURIComponent(angular.toJson(placeholderDetail)) +
                        '&distributionDetails=' + distObj
                }).then(function (response) {
                    $scope.xhr.activeAjaxCallCount++;
                    var data = response.data || {};
                    if (data.errorCode) {
                        if (data.allowContinue) {
                            Notification.warning({
                                title: 'The Doc Ref already exists',
                                message: 'The Doc Ref shown below already has a revision uploaded\n\n- ' + data.docRef
                            });
                            $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['creationStatus'] = "The Doc Ref already exists";
                        } else if (data.errorCode == 2031) {
                            Notification.warning({
                                title: 'Deactivated placeholder exists',
                                message: 'The Doc Ref shown below has a deactivated placeholder as a latest revision\n\n- ' + data.docRef
                            });
                            $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['creationStatus'] = "Deactivated placeholder exists.";
                        } else {
                            Notification.warning({
                                title: 'The Doc Ref already has an empty Placeholder',
                                message: 'The Doc Ref shown below already has an empty Placeholder\n\n- ' + data.docRef +
                                    '\n\nSystem will not create placeholder for the above Doc Ref.\n Please remove that placeholder first.'
                            });
                            $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['creationStatus'] = "Duplicate Placeholder";
                        }
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['filterCode'] = "ERR";
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['revisionIds'] = data.revisionId.split('$$')[0];
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['documentIds'] = data.documentId.split('$$')[0];
                    } else if (data.myHashMap) {
                        var createdPlaceHolderDetail = data.myHashMap.savedPlaceholderDetails;
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['revisionIds'] = createdPlaceHolderDetail.revisionIds;
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['documentIds'] = createdPlaceHolderDetail.documentIds;
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['transactionId'] = createdPlaceHolderDetail.transactionId;
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['creationStatus'] = "Success";
                        $scope.deliverablesDetails[response.config.rowIndex - 1]['trackerDetails']['filterCode'] = "SUCCESS";
                        Notification.success('<div class="text-center"> New placeholder for ' + $scope.deliverablesDetails[response.config.rowIndex - 1]['docRef'] + ' created successfully !</div>');
                    }
                    if ((!$scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.deliverablesDetails.length) || ($scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.notCreatedPlaceHolder.length)) {
                        $scope.xhr.placeholder = false;
                        callbackFun();
                    }
                }, function (errorObj) {
                    $scope.xhr.activeAjaxCallCount++;
                    $scope.deliverablesDetails[errorObj.config.rowIndex - 1]['trackerDetails']['creationStatus'] = "-";
                    $scope.deliverablesDetails[errorObj.config.rowIndex - 1]['trackerDetails']['filterCode'] = "ERR";
                    $scope.xhr.placeholder = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while creating placeholder!!\nPlease check Permissions.'
                    });
                    $timeout(function () {
                        headerScrollBind();
                    });
                });
            },
            getGUIdOnCallBack = function (totalNodes, callback) {
                var allNodes = [];
                var fieldValue = totalNodes;
                if (fieldValue) {
                    var form = {
                        "projectId": $scope.projectId,
                        "formId": $scope.formId,
                        "fields": "DS_GET_GUID",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_GET_GUID",
                                "fieldValue": fieldValue
                            }]
                        }
                    };
                    $scope.xhr.platformXhr = true;
                    $scope.xhr.guIdXhr = $scope.getCallbackData(form).then(function (response) {
                        if (response.data) {
                            var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
                            var strGetDetailsLength = strGetDetails.Items.Item.length;
                            for (var i = 0; i < strGetDetailsLength; i++) {
                                allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
                            }
                        }
                        callback(allNodes);
                    }, function (error) {
                        $scope.xhr.platformXhr = false;
                        $scope.xhr.guIdXhr = false;
                        var errorMsg = 'Error retriving DocumentData<br/>' + error;
                        Notification.error({
                            title: 'Server Error',
                            message: errorMsg
                        });
                    });
                }
            },
            headerScrollBind = function () {
                // bind header's vertical scrolling with table's inner scroll.
                $element.find('.details-table-wrapper .table-body-inner').bind('scroll', function (event) {
                    $element.find('.details-table-wrapper .table-header').scrollLeft(angular.element(event.target).scrollLeft());
                });
            },
            setRemainingDataForImport = function () {
                $scope.ORI_MSG_Custom_Fields.isDataCreatedByXsl = true;
                var deliverableList = [],
                    xslImportedData = $scope.deliverablesDetails;
                $scope.ORI_MSG_Custom_Fields.xslImportedData = xslImportedData;
                for (var i = 0; i < xslImportedData.length; i++) {
                    $scope.insertNewItems(deliverableList);
                    if(!deliverableList[i]){
                        deliverableList[i] = angular.copy(STATIC_OBJECTS.deliverablesDetails);
                    }
                    deliverableList[i].docRef = xslImportedData[i].docRef;
                    deliverableList[i].vdrCodeTitle = xslImportedData[i].vdrCodeTitle;
                    deliverableList[i].vdrMilestone = xslImportedData[i].vdrMilestone;
                    deliverableList[i].vdrMilestoneDate = xslImportedData[i].vdrMilestoneDate;
                    deliverableList[i].BID = xslImportedData[i].BID.trim().toLowerCase();
                    deliverableList[i].MDR = xslImportedData[i].MDR.trim().toLowerCase();
                    deliverableList[i].IOM = xslImportedData[i].IOM.trim().toLowerCase();
                    deliverableList[i].docFormat = xslImportedData[i].docFormat;
                    deliverableList[i].docRev = xslImportedData[i].docRev;
                    deliverableList[i].docRemarks = xslImportedData[i].docRemarks;
                    deliverableList[i].Due_Date = xslImportedData[i].Due_Date || "";

                     // set Vdr doc number Cust Attr
                     if (xslImportedData[i].vdrDocNumber) {
                        deliverableList[i].docCustomMetaData.attrVdrNumber.attributeId = $scope.vdrDocNumCustAttr.attributeId;
                        deliverableList[i].vdrDocNumber = xslImportedData[i].vdrDocNumber;
                        deliverableList[i].docCustomMetaData.attrVdrNumber.attributeValue = xslImportedData[i].vdrDocNumber;
                        deliverableList[i].docCustomMetaData.attrVdrNumber.inputTypeId = $scope.vdrDocNumCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrVdrNumber.defaultName = '';
                    }

                    // set location Cust Attr
                    if (xslImportedData[i].Location) {
                        var selectedLocationObj = $scope.locationCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].Location.trim().toLowerCase();
                        })[0] || {};
                        deliverableList[i].docCustomMetaData.attrLocation.attributeId = $scope.locationCustAttr.attributeId;
                        deliverableList[i].Location = selectedLocationObj.value;
                        deliverableList[i].docCustomMetaData.attrLocation.attributeValue = selectedLocationObj.value;
                        deliverableList[i].docCustomMetaData.attrLocation.inputTypeId = $scope.locationCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrLocation.defaultName = selectedLocationObj.defaultName;
                    }

                    // set PMP104_Section Cust Attr
                    if (xslImportedData[i].PMP104_Section) {
                        var selectedPMPSecObj = $scope.PMP104SecCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].PMP104_Section.trim().toLowerCase();
                        })[0] || {};
                        deliverableList[i].docCustomMetaData.attrPMP104Section.attributeId = $scope.PMP104SecCustAttr.attributeId;
                        deliverableList[i].PMP104_Section = selectedPMPSecObj.value || "";
                        deliverableList[i].docCustomMetaData.attrLocation.attributeValue = selectedPMPSecObj.value || "";
                        deliverableList[i].docCustomMetaData.attrLocation.inputTypeId = $scope.PMP104SecCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrLocation.defaultName = selectedPMPSecObj.defaultName || "";
                        if(selectedPMPSecObj){
                            $scope.onPmpSectionChange(deliverableList[i], deliverableList[i].PMP104_Section);
                        }
                    }
                    
                    // set pmp sub section base only if it is child of pmp104 section
                    if (xslImportedData[i].selectedVdrCodeVal) {
                        var selectedVdrCodeAttrObj = $scope.vdrCodeCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].selectedVdrCodeVal.trim().toLowerCase();
                        })[0] || {};
                        if(deliverableList[i].PMPSUBSectionList && deliverableList[i].PMPSUBSectionList.length && selectedVdrCodeAttrObj){
                            var pmpSubSectionSelected = deliverableList[i].PMPSUBSectionList.filter(function (valObj) {
                                return valObj.Value9.trim().toLowerCase() == xslImportedData[i].selectedVdrCodeVal.trim().toLowerCase();
                            })[0] || {};
                            deliverableList[i].docCustomMetaData.attrVdrCode.attributeId = $scope.vdrCodeCustAttr.attributeId;
                            deliverableList[i].selectedVdrCodeVal = pmpSubSectionSelected.Value11 || "";
                            deliverableList[i].docCustomMetaData.attrVdrCode.attributeValue = pmpSubSectionSelected.Value11 || "";
                            deliverableList[i].docCustomMetaData.attrVdrCode.inputTypeId = $scope.vdrCodeCustAttr.inputTypeId;
                            deliverableList[i].docCustomMetaData.attrVdrCode.defaultName = pmpSubSectionSelected.Value9 || "";
                        }else{
                            deliverableList[i].docCustomMetaData.attrVdrCode.attributeId = "";
                            deliverableList[i].selectedVdrCodeVal = "";
                            deliverableList[i].docCustomMetaData.attrVdrCode.attributeValue = "";
                            deliverableList[i].docCustomMetaData.attrVdrCode.inputTypeId = "";
                            deliverableList[i].docCustomMetaData.attrVdrCode.defaultName = "";
                        }
                    }
                    // csi code custom attr
                    if (xslImportedData[i].selectedCSICodeVal) {
                        var selectedCSICodeAttrObj = $scope.CSICodeCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].selectedCSICodeVal.trim().toLowerCase();
                        })[0] || {};
                        
                        deliverableList[i].docCustomMetaData.attrCSICode.attributeId = $scope.CSICodeCustAttr.attributeId;
                        deliverableList[i].selectedCSICodeVal = selectedCSICodeAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrCSICode.attributeValue = selectedCSICodeAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrCSICode.inputTypeId = $scope.CSICodeCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrCSICode.defaultName = selectedCSICodeAttrObj.defaultName;
                    }

                    // set Dicipline Cust Attr
                    if (xslImportedData[i].selectedDisiplinVal) {
                        var selectedDispAttrObj = $scope.disiplinCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].selectedDisiplinVal.trim().toLowerCase();
                        })[0] || {};
                        deliverableList[i].docCustomMetaData.attrDiscipline.attributeId = $scope.disiplinCustAttr.attributeId;
                        deliverableList[i].selectedDisiplinVal = selectedDispAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrDiscipline.attributeValue = selectedDispAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrDiscipline.inputTypeId = $scope.disiplinCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrDiscipline.defaultName = selectedDispAttrObj.defaultName;
                    }

                    // set Doc Type Cust Attr
                    if (xslImportedData[i].docType) {
                        var selectedDocTypeAttrObj = $scope.docTypeCustAttr.inputValueList.filter(function (valObj) {
                            return valObj.defaultName.trim().toLowerCase() == xslImportedData[i].docType.trim().toLowerCase();
                        })[0] || {};
                        deliverableList[i].docType = selectedDocTypeAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrDocType.attributeId = $scope.docTypeCustAttr.attributeId;
                        deliverableList[i].docCustomMetaData.attrDocType.attributeValue = selectedDocTypeAttrObj.value;
                        deliverableList[i].docCustomMetaData.attrDocType.inputTypeId = $scope.docTypeCustAttr.inputTypeId;
                        deliverableList[i].docCustomMetaData.attrDocType.defaultName = selectedDocTypeAttrObj.defaultName;
                    }

                    // set Purpose of Issue Cust Attr
                    if (xslImportedData[i].purposeOfIssue) {
                        var selectedPurposeOfIssueAttrObj = $scope.workspacePOIList.filter(function (valObj) {
                            return valObj.Value2.trim().toLowerCase() == xslImportedData[i].purposeOfIssue.trim().toLowerCase();
                        })[0] || {};
                        deliverableList[i].purposeOfIssue = selectedPurposeOfIssueAttrObj.Value2;
                    }
                }
                if (deliverableList.length) {
                    $scope.deliverablesDetails.length = 0;
                    $scope.deliverablesDetails = deliverableList;
                    $scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.deliverablesDetails.length = 0;
                    $scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.deliverablesDetails = deliverableList;
                    $scope.update();
                }
                if($scope.isEditORI){
                    if(!$scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE']){
                        $scope.getServerTime(function (serverDate) {
                            var serverDateObj = new Date(serverDate);
                            serverDateObj.setDate(serverDateObj.getDate() + 5);
                            $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
                        });
                    }
                    if(!$scope.packageDetails['isAwarded']){
                        $scope.packageDetails['isAwarded'] = "Not Awarded";
                    }
                    var strFormStatusId = getFormStatusId($scope.packageDetails['isAwarded'].trim().toLowerCase());
                    if (strFormStatusId) {
                        $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
                    }
                }
                $scope.ORI_MSG_Custom_Fields.isImported = "Completed";
            },
            updateAvailalbeDocRefList = function () {
                for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                    var docRef = $scope.deliverablesDetails[i].docRef || '',
                        docRef = docRef.trim().toLowerCase(),
                        folderId = $scope.deliverablesDetails[i].folderData.folderId || '';
                    if (docRef && folderId) {
                        avilRowDocRefFolderWise[i] = folderId + '_' + docRef;
                    }
                };
            },
            bulkApplyOnField = function (fieldName) {
                for (var t = 0; t < $scope.deliverablesDetails.length; t++) {
                    if (!$scope.deliverablesDetails[t].trackerDetails.revisionIds) {
                        if(fieldName == 'PMP104_Section&selectedVdrCodeVal'){
                            var f1 = fieldName.split('&')[0];
                            var f2 = fieldName.split('&')[1]
                            if($scope.bulkApplyObj[f1] == '' &&  $scope.bulkApplyObj[f2] == ''){
                                $scope.deliverablesDetails[t][f1] = "";
                                $scope.deliverablesDetails[t][f2] = "";
                            }else if($scope.bulkApplyObj[f1] != '' && $scope.bulkApplyObj[f2] != '' && (!$scope.deliverablesDetails[t][f1] || $scope.deliverablesDetails[t][f1] == '') && (!$scope.deliverablesDetails[t][f1] || $scope.deliverablesDetails[t][f2] == '') ){
                                $scope.deliverablesDetails[t][f1] = $scope.bulkApplyObj[f1];
                                $scope.onPmpSectionChange($scope.deliverablesDetails[t], $scope.bulkApplyObj[f1]);
                                $scope.deliverablesDetails[t][f2] = $scope.bulkApplyObj[f2];
                                $scope.custAttrSelection($scope.deliverablesDetails[t]['docCustomMetaData'][customAttrValueMap[f2]], $scope[custAttrNameListMap[f2]], $scope.bulkApplyObj[f2])
                            }
                        }else{
                            if ($scope.bulkApplyObj[fieldName] == '') {
                                $scope.deliverablesDetails[t][fieldName] = '';
                                continue;
                            }
                            if (fieldName == 'folderData') {
                                $scope.deliverablesDetails[t][fieldName]['folderName'] = $scope.bulkApplyObj[fieldName]['folderName'];
                                $scope.deliverablesDetails[t][fieldName]['folderPath'] = $scope.bulkApplyObj[fieldName]['folderPath'];
                                $scope.deliverablesDetails[t][fieldName]['folderId'] = $scope.bulkApplyObj[fieldName]['folderId'];
                            } else if (fieldName == 'asignee') {
                                $scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];
                                $scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Asignee Users' List");
                            } else {
                                if (!$scope.deliverablesDetails[t][fieldName] || $scope.deliverablesDetails[t][fieldName] == '' || $scope.deliverablesDetails[t][fieldName] == 'no' || $scope.deliverablesDetails[t][fieldName] == 'yes') {
                                    $scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];
                                    if (fieldName == 'asignee') {
                                        $scope.userAsigneeList = structureItemList('for-user-asignee', projDistUsersAll, "Asignee Users' List");
                                    } else if (fieldName == 'selectedDisiplinVal' || fieldName == 'selectedCSICodeVal' || fieldName == 'docType' || fieldName == 'vdrDocNumber' || fieldName == 'Location') {
                                        $scope.custAttrSelection($scope.deliverablesDetails[t]['docCustomMetaData'][customAttrValueMap[fieldName]], $scope[custAttrNameListMap[fieldName]], $scope.bulkApplyObj[fieldName])
                                    }
                                }
                            }
                        }
                        $scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
                    } else if ((fieldName == 'vdrMilestone' || fieldName == 'docRemarks') && (!$scope.deliverablesDetails[t][fieldName] || $scope.deliverablesDetails[t][fieldName] == '')) {
                        $scope.deliverablesDetails[t][fieldName] = $scope.bulkApplyObj[fieldName];
                        $scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
                    }
                }
                $scope.expandTextAreaOnLoad();
            },
            setDistributionNode = function (strUser, strAction, strDays) {
                var distributionNode = angular.copy(distributionNodeStr);
                distributionNode.DS_PROJDISTUSERS = strUser;
                distributionNode.DS_FORMACTIONS = strAction;
                distributionNode.DS_ACTIONDUEDATE = strDays;
                $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users.push(distributionNode);
                $scope.Asite_System_Data_Read_Write["DS_AUTODISTRIBUTE"] = "3";
            },
            setPackageEngWorkFlow = function (packageEngineer) {
                if (!packageEngineer) {
                    return;
                }
                setDistributionNode(packageEngineer.split('|')[2].trim(), "7#For Information", '');
            },
            setDocumentControllerFlow = function () {
                // set For Information to all Document Controller Role's User.
                var documentControllersList = commonApi._.filter(dsProjUsersAllRolse, function (roleUserObj) {
                    var roleNameString = roleUserObj.Value.trim().toLowerCase();
                    return (roleNameString.indexOf('doc controller') > -1 || roleNameString.indexOf('doccontroller') > -1);
                });

                for (var i = 0; i < documentControllersList.length; i++) {
                    var roleUserObj = documentControllersList[i];
                    setDistributionNode(roleUserObj.Value.split('|')[2].trim(), "7#For Information", '');
                }
            },
            setAutoDistUsersNodes = function () {
                setPackageEngWorkFlow($scope.packageDetails.packageEnginner);
                setDocumentControllerFlow();
            },
            setOldJsonBackup = function () {
                var onLoadJson = angular.fromJson($element.find('.json_data').val()).myFields,
                    oriMsg = onLoadJson.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields,
                    titleDetails = oriMsg.titleDetails;

                // set required old data backup of json.
                onLoadJsonBackup = {
                    resubmissionDays: oriMsg.packageDetails.resubmissionDate,
                    deliveryToSite: titleDetails.deliveryToSite,
                    noOfDays: titleDetails.noOfDays,
                    readyExWorks: titleDetails.readyExWorks,
                    runDate: titleDetails.runDate,
                    deliverablesDetails: oriMsg.deliverablesDetails
                };
            },
            setScheduleNoteAndPattern = function () {
                var schObj = {},
                    schCodeList = [],
                    schList = [];
                for (var i = 0; i < $scope.scheduleDetails.length; i++) {
                    schObj = $scope.scheduleDetails[i];
                    if (schObj.scheduleCode && schObj.scheduleDesc && schObj.scheduleDays) {
                        schList.push('<b>' + schObj.scheduleCode.toUpperCase() + '</b> ' + schObj.scheduleDesc + ' = ' + schObj.scheduleDays);
                        schCodeList.push(schObj.scheduleCode);
                        schDefined[schObj.scheduleCode.toLowerCase()] = parseInt(schObj.scheduleDays || 1);
                    }
                }
                // update new pattern to write.
                $scope.wamRegExPattern = '([\+\-]?[0-9]{0,3})([^(' + schCodeList.join('|').toLowerCase() + '|' + schCodeList.join('|').toUpperCase() + ')])(' + schCodeList.join('|').toLowerCase() + '|' + schCodeList.join('|').toUpperCase() + ')$';
                $scope.deliverableNotes.note1 = schList.join(', ');

                //to update the scope. 
                $scope.update();
            };
        
        /**
		 * Return date with day light saving
		 */
		function getDateFromZone(){
			var offset = 0;
			Date.prototype.stdTimezoneOffset = function () {
				var jan = new Date(this.getFullYear(), 0, 1);
				var jul = new Date(this.getFullYear(), 6, 1);
				return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
			};
			Date.prototype.isDstObserved = function () {
				return this.getTimezoneOffset() < this.stdTimezoneOffset();
			};
			var today = new Date();
			if (today.isDstObserved()) { 
				offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
			} else {
				offset = $window.USP.localeVO._timezone.rawOffset;
			}

			var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }

        $scope.custAttrSelection = function (custAttrObj, parentObj, selectedVal) {
            var selectedValObj = parentObj.inputValueList.filter(function (valueObj) {
                return valueObj.value == selectedVal;
            })[0] || {};
            custAttrObj.attributeId = parentObj.attributeId;
            custAttrObj.attributeValue = selectedVal;
            custAttrObj.inputTypeId = parentObj.inputTypeId;
            custAttrObj.defaultName = (selectedValObj && selectedValObj.defaultName) ? selectedValObj.defaultName : '';
        };

        /**
		 * This function invoked on PMP104 section value change 
		 * update PMP104 sub section list
		 * resets PMP104 sub sectio if is not avail in dropdownlist  list
		 * @param {object} VDRitem: row of vdr 
         * @param {object} SelectedpmpSection: selected pmp 104 section value  
		 */
		$scope.onPmpSectionChange = function(VDRitem, SelectedpmpSection){
			var uniqList = [];
			var tempList = commonApi._.filter(dsAsiConfigSets, function (val) {
				if (uniqList.indexOf(val.Value9 + val.Value8 + val.Value6) === -1) {
					uniqList.push(val.Value9 + val.Value8 + val.Value6);
					return val.Value8.indexOf(CONSTANTS_OBJ.CONFIG_PMPSUB_LIST_NAME) != -1 && val.Value7.indexOf(SelectedpmpSection) != -1;
				}
			});

			// do not reset IssueDescription if already has selected avail in list
			VDRitem.PMPSUBSectionList = tempList
			var foundObj = commonApi._.find(tempList, function(item){
                return item.Value9 == VDRitem.selectedVdrCodeVal;
			});
			if(!foundObj){
                VDRitem.selectedVdrCodeVal = '';
                $scope.custAttrSelection(VDRitem['docCustomMetaData']['attrVdrCode'], $scope.vdrCodeCustAttr, VDRitem['selectedVdrCodeVal']);
            }
            $scope.custAttrSelection(VDRitem['docCustomMetaData']['attrPMP104Section'], $scope.PMP104SecCustAttr, SelectedpmpSection);
		};

        var commonValidationFuncs = {
            duplicateDocRefValidation: function (value, index, isFolderEvent, folderId) {
                var docRef = value || $scope.deliverablesDetails[index].docRef || '',
                    docRef = docRef.trim().toLowerCase(),
                    isFolderEvent = isFolderEvent || false;

                if (!isFolderEvent) {
                    folderId = $scope.deliverablesDetails[index].folderData.folderId;
                }

                if (docRef && folderId) {
                    var uniqRef = folderId + '_' + docRef;
                    // resetting the object key to put latest.
                    avilRowDocRefFolderWise[index] = '';
                    if (Object.values(avilRowDocRefFolderWise).indexOf(uniqRef) > -1) {
                        if (!isFolderEvent) {
                            Notification.warning({
                                title: "Duplicate 'Doc Ref'",
                                message: "Duplicate 'Doc Ref' entered, please enter different 'Doc Ref'"
                            });
                            $scope.deliverablesDetails[index].docRef = '';
                        } else {
                            Notification.warning({
                                title: "Duplicate 'Doc Ref' in same Folder",
                                message: "Duplicate 'Doc Ref' entered for the same folder, please select another folder from available list\n Either change 'Doc Ref' for current row."
                            });
                            $scope.item.folderName = '';
                            $scope.item.folderPath = '';
                            $scope.item.folderId = '';
                        }
                        return false;
                    } else {
                        avilRowDocRefFolderWise[index] = uniqRef;
                    }
                }
                return true;
            },
            docrefInvalidChars: function (value, index) {
                var MSG_TITLE = 'Special character validation',
                    MSG_BODY = 'Enter valid characters only. (Restricted Characters ",/,\\,:,*,?,<,>,|,;,%,#,~ or any character with ASCII value less than 32)';
                if (value) {
                    var nospecial = /"|#|:|;|\x3F|\x7C|<|>|%|\\|\/|~|\*|—/;
                    var matches = value.match(nospecial);
                    if (matches && matches.length > 0) {
                        Notification.warning({
                            title: MSG_TITLE,
                            message: MSG_BODY
                        });
                        $scope.deliverablesDetails[index].docRef = '';
                    } else {
                        for (var i = 0; i < value.length; i++) {
                            if (value.charCodeAt(i) < 32) {
                                Notification.warning({
                                    title: MSG_TITLE,
                                    message: MSG_BODY
                                });
                                $scope.deliverablesDetails[index].docRef = '';
                                break;
                            }
                        }
                    }
                }
            }
        };

        /**
         * validate for bulk apply obj docref value for special charcter
         * @param {string} value : bulk apply obj docref value
         */
        $scope.bulkApplyDocrefInvalidChars = function(value){
            var MSG_TITLE = 'Special character validation',
                MSG_BODY = 'Enter valid characters only. (Restricted Characters ",/,\\,:,*,?,<,>,|,;,%,#,~ or any character with ASCII value less than 32)';
            if (value) {
                var nospecial = /"|#|:|;|\x3F|\x7C|<|>|%|\\|\/|~|\*|—/;
                var matches = value.match(nospecial);
                if (matches && matches.length > 0) {
                    Notification.warning({
                        title: MSG_TITLE,
                        message: MSG_BODY
                    });
                    $scope.bulkApplyObj['docRef'] = '';
                } else {
                    for (var i = 0; i < value.length; i++) {
                        if (value.charCodeAt(i) < 32) {
                            Notification.warning({
                                title: MSG_TITLE,
                                message: MSG_BODY
                            });
                            $scope.bulkApplyObj['docRef'] = '';
                            break;
                        }
                    }
                }
            }
        }
        
        $scope.commonValidations = function (validationsString, index, value) {
            var validationsList = validationsString.split(',');
            for (var h = 0; h < validationsList.length; h++) {
                var func = validationsList[h];
                commonValidationFuncs[func] && commonValidationFuncs[func].apply(this, [value, index]);
            }
        };

        /**
         * Remove milestone row from milestone popup
         * Also add confim message if milestone code used
         * @param {number} index :  retunr row index of each milestone
         */
        $scope.removeMilestoneRow = function (index) {
            var schCode = $scope.scheduleDetails[index]['scheduleCode'];
            var isUsedCode = false;
            var isConfirm = false;
            for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                var element = $scope.deliverablesDetails[i];
                if (element.vdrMilestone && element.vdrMilestone.indexOf(schCode) > -1) {
                    isUsedCode = true;
                    break;
                }
            }

            if (isUsedCode) {
                isConfirm = confirm("Milestone code already in use.\nDo you really want to remove?");
            }

            if (!isUsedCode || isConfirm) {
                $scope.scheduleDetails.splice(index, 1);
                setScheduleNoteAndPattern();
            }
        }

        // common item selection modal Start
        $scope.showModal = function (id, index, isForBulkApply) {
            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4');
                modalHeader.addClass('primary-header-bg white-font');
            }, 0);
            if (id === 'common-item-selection') {
                if (!isForBulkApply) {
                    $scope.item.rowIndex = index;
                    $scope.item.folderName = $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderName || '';
                    $scope.item.folderPath = $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderPath || '';
                    $scope.item.folderId = $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderId || '';
                } else {
                    $scope.item.folderName = '';
                    $scope.item.folderPath = '';
                    $scope.item.folderId = '';
                }
                $scope.item.isForBulkApply = isForBulkApply;
            } else if (id === 'schedule-config-model') {
                // TODO
            }else if (id === 'doc-ref-config-model') {
                // TODO
            }

            // to hide the update button 
            ctrl.model.readOnly = true;
            ctrl.model.modelId = id;
        };

        $scope.hideModal = function () {
            if (ctrl.model.modelId === 'common-item-selection') {
                if (!$scope.item.isForBulkApply) {
                    if (!commonValidationFuncs.duplicateDocRefValidation($scope.deliverablesDetails[$scope.item.rowIndex].docRef, $scope.item.rowIndex, true, $scope.item.folderId)) {
                        return;
                    } else {
                        $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderName = $scope.item.folderName;
                        $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderPath = $scope.item.folderPath;
                        $scope.deliverablesDetails[$scope.item.rowIndex].folderData.folderId = $scope.item.folderId;
                    }
                } else {
                    if ($scope.item.isForBulkApply) {
                        $scope.bulkApplyObj.folderData.folderName = $scope.item.folderName;
                        $scope.bulkApplyObj.folderData.folderPath = $scope.item.folderPath;
                        $scope.bulkApplyObj.folderData.folderId = $scope.item.folderId;
                    }
                }
                ctrl.model.modelId = '';
            } else if (ctrl.model.modelId === 'schedule-config-model') {
                var flag = true;
                for (var i = 0; i < $scope.scheduleDetails.length; i++) {
                    var schObj = $scope.scheduleDetails[i];
                    if (!schObj.scheduleCode || !schObj.scheduleDesc || !schObj.scheduleDays) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    setScheduleNoteAndPattern();
                    ctrl.model.modelId = '';
                } else {
                    alert("Please fill the mandatory fields");
                }
            } else if (ctrl.model.modelId === 'doc-ref-config-model') {
                var allFilledMenadory = true;
                var docrefConf = $scope.ORI_MSG_Custom_Fields.docRefConfiguration.docRefConfigurationGroup.docRefConfigs;
                for(var i=0; i< docrefConf.length; i++){
                    if(!docrefConf[i].Value){
                        allFilledMenadory = false;
                    }
                }
                if (allFilledMenadory) {
                    ctrl.model.modelId = '';
                } else {
                    alert("Please fill the mandatory fields");
                }
                $scope.ORI_MSG_Custom_Fields.docRefConfigured = docrefConf.length ? "yes" : "no"
            }
            $scope.backup.item = $scope.item;
        };

        $scope.updateModal = function () {
            $scope.hideModal();
        };

        ctrl.model = {
            modelId: "",
            showModal: $scope.showModal,
            update: $scope.updateModal,
            hideModal: $scope.hideModal,
            readOnly: $scope.readOnly
        };

        $scope.backup = {
            item: {
                folderName: '',
                folderPath: '',
                folderId: '',
                rowIndex: '',
                isForBulkApply: false
            }
        };

        // common item selection modal End

        $scope.setFocusToLastAddedElement = function (tableId) {
            $timeout(function () {
                angular.element('#' + tableId + '>tbody>tr:last input').last().focus();
            }, 50);
        };

        // below function is to call report mta vdr report
        $scope.exportAsiteVdrReport = function (event) {
            $window.showSelectedReportfromApp && $window.showSelectedReportfromApp('MTA_Vendor_Package_Report', 'XLSM', 'Ext', '', '');
        };

        $scope.insertNewItems = function (listToImport, objKey) {
            var newStaticObject = angular.copy(STATIC_OBJECTS[objKey]);
            if (objKey === 'schedulConfigObj') {
                newStaticObject.scheduleId = listToImport[listToImport.length - 1].scheduleId + 1 + '';
            }
            //Add item in items
            $scope.addRepeatingRow(listToImport, newStaticObject);
        };

        $scope.changeItemSelectionEvent = function (item, dropDownFor, isForBulkApply) {
            if (!isForBulkApply) {
                if (dropDownFor == 'folderpath-dropdown') {
                    $scope.item.folderPath = item.displayValue;
                    $scope.item.folderName = item.folderName;
                    $scope.item.folderId = item.modelValue;
                }
            }
        };

        $scope.setStatusAccordingly = function (selectedStatus) {
            var strFormStatusId = getFormStatusId(selectedStatus.trim().toLowerCase());
            if (strFormStatusId) {
                $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }
        };

        var mathOperation = {
            '+': function (x, y) {
                return x + y
            },
            '-': function (x, y) {
                return x - y;
            }
        };
        var dynamicCalculateMileStoneDays = function (paramObj) {
            if (!paramObj.vdrMilestone) {
                return 7;
            }
            var totalDays = 0,
                alphabetLow = '',
                splitedVal = paramObj.vdrMilestone.split(/(\d+)/);
            var operationType = splitedVal[0] || '+';
            var alphabetLow = splitedVal[2].toLowerCase();
            var tempNumber = (alphabetLow && alphabetLow.toLowerCase() == 'a') ? 0 : schDefined[alphabetLow];
            if (schDefined.hasOwnProperty(alphabetLow)) {
                //totalDays = (operationType == '-' ? -1 : 1) * Number(schDefined[alphabetLow]) * Number(splitedVal[1]) * Number(paramObj.noOfDays);
                totalDays = mathOperation[operationType](
                    Number(tempNumber) * Number(paramObj.noOfDays),
                    Number(splitedVal[1]) * Number(paramObj.noOfDays)
                );
            }
            return totalDays;
        };

        $scope.applyRunDateChange = function (selectedDate) {
            var todayServerDateObj = new Date($scope.serverDate),
                noOfDays = $scope.titleDetails.noOfDays || 7,
                selectedDateObj = '',
                deObj = {},
                oldDeObj = {},
                isWamValueUpdated = false;
            for (var i = 0; i < $scope.deliverablesDetails.length; i++) {

                selectedDateObj = new Date(selectedDate);
                deObj = $scope.deliverablesDetails[i];
                oldDeObj = (onLoadJsonBackup.deliverablesDetails.length && onLoadJsonBackup.deliverablesDetails[i]) || {},
                    isWamValueUpdated = (deObj.vdrMilestone != oldDeObj.vdrMilestone);

                if (deObj.vdrMilestone && (!deObj.guId || !deObj.trackerDetails.revisionIds || isWamValueUpdated)) {
                    var calculatedDays = dynamicCalculateMileStoneDays({
                        vdrMilestone: deObj.vdrMilestone,
                        noOfDays: noOfDays
                    })

                    // NaN occuress set default Week Days to 7.
                    isNaN(calculatedDays) && (calculatedDays = 7);
                    var dueDate = selectedDateObj.setDate(selectedDateObj.getDate() + calculatedDays);
                    typeof dueDate == 'number' && (dueDate = new Date(dueDate));
                    if (!selectedDate) {
                        $scope.deliverablesDetails[i].vdrMilestoneDate = '';
                    } else if (dueDate >= todayServerDateObj) {
                        !deObj.trackerDetails.revisionIds && ($scope.deliverablesDetails[i].placeHolderCreationDate = $scope.formatDate(dueDate, 'yy-mm-dd'));
                        $scope.deliverablesDetails[i].vdrMilestoneDate = $scope.formatDate(dueDate, 'yy-mm-dd');
                    } else {
                        !deObj.trackerDetails.revisionIds && ($scope.deliverablesDetails[i].placeHolderCreationDate = $scope.todayDateDbFormat);
                        $scope.deliverablesDetails[i].vdrMilestoneDate = $scope.formatDate(dueDate, 'yy-mm-dd');
                    }
                }
            }
        };

        $scope.bulkApplyOnField = function (fieldName, valueObj) {
            bulkApplyOnField(fieldName, valueObj);
        };

        /***
         * 
         *	isIncludeFailed: true/false	----> filterCode: ERR or Not ERR
         *	dateStatus: all,due,overdue	----> remainingDays: due days in positive, overdue days in negative.
         *	placeHolderDocStatus: all,submitted,notsubmitted ----> placeHolderStatus: submitted not prepublished, notsubmitted prepublished
         *
         * */

        var checkMultiConditions = function (filterObj, conditionsObj) {
            if ((filterObj.dateStatus == 'all') || (filterObj.dateStatus == 'due' && conditionsObj.isdateStatusDue) || (filterObj.dateStatus == 'overdue' && conditionsObj.isdateStatusOverDue) || (filterObj.dateStatus == 'submitted' && conditionsObj.isSubmitted)) {
                return true;
            }
            return false;
        };

        $scope.applyFilterCriteria = function (filterObj) {
            // set default to all i f blank is there.
            !filterObj.dateStatus && (filterObj.dateStatus = 'all');
            !filterObj.placeHolderDocStatus && (filterObj.placeHolderDocStatus = 'all');

            var conditionsObj = {},
                successHyphen = ['-', 'success'],
                prepublishHyphen = ['-', 'prepublished'];
            for (var s = 0; s < $scope.deliverablesDetails.length; s++) {
                var currObj = $scope.deliverablesDetails[s];
                conditionsObj.isNotInclude = (currObj.trackerDetails.filterCode && successHyphen.indexOf(currObj.trackerDetails.filterCode.toLowerCase()) > -1) || (currObj.placeHolderStatus.toLowerCase() != 'deactivated') || false;
                conditionsObj.isdateStatusOverDue = (!isNaN(currObj.remainingDays) && currObj.remainingDays.indexOf('-') > -1) || false;
                conditionsObj.isdateStatusDue = (currObj.remainingDays && !conditionsObj.isdateStatusOverDue) || false;
                conditionsObj.isNotSubmitted = (currObj.placeHolderStatus && prepublishHyphen.indexOf(currObj.placeHolderStatus.toLowerCase()) > -1) || false;
                conditionsObj.isSubmitted = !conditionsObj.isNotSubmitted;
                $scope.deliverablesDetails[s].isShow = false;
                if ((!filterObj.isIncludeFailed && conditionsObj.isNotInclude && checkMultiConditions(filterObj, conditionsObj)) || (filterObj.isIncludeFailed && checkMultiConditions(filterObj, conditionsObj))) {
                    $scope.deliverablesDetails[s].isShow = true;
                }
            }
        };

        var updateUnavailableGuidStatus = function () {
            // get All Indexes of the row without guid to make ajax call for only those elements.
            for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                if ($scope.deliverablesDetails[i].guId == '') {
                    guidNotAvailList.push(i);
                }
            }
        },
            recursiveFunCall = function (guidNotAvailList, callbackFun) {
                // loop to create placeholders.			
                for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                    var delivObj = $scope.deliverablesDetails[i];
                    if (delivObj.guId && delivObj.guId != '' && !guidNotAvailList.length && !delivObj.trackerDetails.revisionIds && $scope.packageDetails.isStatusAwarded.toLowerCase() == 'yes') {
                        angular.forEach($scope.workspacePOIList, function (item) {
                            if (item.Value2 == delivObj.purposeOfIssue) {
                                delivObj.poiID = item.Value1;
                            }
                        });
                        createPlaceHolders(delivObj, callbackFun, i);
                    } else if (!$scope.xhr.guIdXhr) {
                        if (guidNotAvailList.length != 0) {
                            getGUIdOnCallBack(guidNotAvailList.length, function (allGUID) {
                                if (allGUID.length) {
                                    angular.forEach(guidNotAvailList, function (index, i) {
                                        $scope.deliverablesDetails[index].guId = allGUID[i];
                                    });
                                    $scope.xhr.platformXhr = false;
                                    $scope.xhr.guIdXhr = false;
                                    guidNotAvailList = [];
                                    recursiveFunCall(guidNotAvailList, callbackFun);
                                }
                            });
                        } else if (!guidNotAvailList.length && $scope.packageDetails.isStatusAwarded.toLowerCase() == 'no') {
                            callbackFun();
                        }
                    }
                }
            };


        /**
         * vdrDocNumber field is not mandatory and it set attribute value in placeholder crate
         * So we need to pass blank or vdrDocNumber value in that attribute
         * otherwise placeholder not create and server throws error
         */
        function setPlaceholderAttributeRef() {
            for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                var element = $scope.deliverablesDetails[i];
                for (var key in customAttrValueMap) {
                    if (customAttrValueMap.hasOwnProperty(key) &&
                    element['docCustomMetaData'][ customAttrValueMap[key] ] && 
                    !element['docCustomMetaData'][ customAttrValueMap[key] ].attributeId) {
                        $scope.custAttrSelection(element['docCustomMetaData'][ customAttrValueMap[key] ], $scope.vdrDocNumCustAttr, element[key] || '');
                    }
                }
            }
        }

        $window.asiVendorPackageSubmit = function () {
            if($scope.hasDuplicateDocRef()){
                alert('Duplicate Doc ref No.')
                return true;
            }
            if($scope.hasPastDueDates()){
                alert('Due date should not be past date')
                return true;
            }
            setDocRefAsFormcontent();
            setPlaceholderAttributeRef();
            //check package number duplicate or not
            if ($scope.duplicatemessage) {
                return true;
            }

            if (submitFlag) {
                return false;
            }

            // set ORI form title
            $scope.ORI_MSG_Custom_Fields['ORI_FORMTITLE'] = $scope['ORI_MSG_Custom_Fields']['packageDetails']['package'] + ' - ' + $scope['ORI_MSG_Custom_Fields']['packageDetails']['title'];
            // set Package title in DS_FORMCONTENT2 for SP Use.
            $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMCONTENT2'] = $scope['ORI_MSG_Custom_Fields']['packageDetails']['package'];
            $scope.titleDetails.runDate && $scope.applyRunDateChange($scope.titleDetails.runDate);
            // set Auto User Distribution Nodes.
            setAutoDistUsersNodes();

            var execBizzLogic = function () {
                var callbackFun = function () {
                    submitFlag = true;
                    // remove loaded class to show loader
                    $element.removeClass('loaded');
                    $window.submitForm(1);
                };
                guidNotAvailList = [];
                updateUnavailableGuidStatus();
                recursiveFunCall(guidNotAvailList, callbackFun);
            };

            if ($scope.packageDetails.isStatusAwarded.toLowerCase() == 'yes') {
                // updating list of not created PlaceHolders
                var placeholderCreatedList = $scope.deliverablesDetails && $scope.deliverablesDetails.filter(function (deObj) {
                    return deObj.trackerDetails.revisionIds;
                }) || [];
                if (placeholderCreatedList.length == $scope.deliverablesDetails.length) {
                    submitFlag = true;
                    // remove loaded class to show loader	
                    $element.removeClass('loaded');
                    $window.submitForm(1);
                } else {
                    // reset while clicking on submit button.
                    $scope.xhr.activeAjaxCallCount = 0;
                    $scope.notCreatedPlaceHolder = $scope.deliverablesDetails && $scope.deliverablesDetails.filter(function (deObj) {
                        return !deObj.trackerDetails.revisionIds;
                    }) || [];
                }
            } else if ($scope.packageDetails.isStatusAwarded.toLowerCase() == 'no') {
                // set pre defined Status to - for both creation and placeHolder as well.
                for (var i = 0; i < $scope.deliverablesDetails.length; i++) {
                    $scope.deliverablesDetails[i].placeHolderStatus = "-";
                    $scope.deliverablesDetails[i].trackerDetails.creationStatus = "-";
                    $scope.deliverablesDetails[i].trackerDetails.filterCode = "-";
                };
                $element.removeClass('loaded');
            }
            if ($scope.packageDetails.isAwarded == 'Awarded') {
                $scope.Asite_System_Data_Read_Write['ORI_MSG_Fields']['DS_DB_INSERT'] = 'true';
                execBizzLogic();
                //($scope.packageDetails.isStatusAwarded == 'Yes') && execBizzLogic();
            } else if ($scope.packageDetails.isAwarded == 'Not Awarded') {
                submitFlag = true;
                // remove loaded class to show loader	
                $element.removeClass('loaded');
                $window.submitForm(1);
            }
            return true;
        };

        // View Base Functions called from here.
        if ($scope.deliverablesDetails.length) {
            if (currentViewName == 'ORI_VIEW') {
                setClientlogo();
                !$scope.isEditORI &&  setPsrProjectDetails();

                // to set old Json to compare WAM and Other fields that change vdrMilestoneDate.
                $scope.isEditORI && setOldJsonBackup();

                if($scope.isFieldsDisplayOnly){
                    if(angular.element("custom-common-dropdown[dd-name='import-excel']").length){
                        angular.element("custom-common-dropdown[dd-name='import-excel']").hide();
                    }else{
                        $timeout(function () {
                            angular.element("custom-common-dropdown[dd-name='import-excel']").hide();
                        }, 100);
                    }
                }

                setAllRolesList();
                allHashedFolderList();
                fetchAllRolesUserList();
                getAllFoldersForProject(false);
                setPOIforWorkspace();
                setUserAsigneeList();
                setPackageEngineerList();
                $scope.setStatusAccordingly($scope.packageDetails.isStatusAwarded.toLowerCase());
                // include new row if all records are created and not showing					
                $scope.notCreatedPlaceHolder = $scope.deliverablesDetails.filter(function (deObj) {
                    return !deObj.trackerDetails.revisionIds;
                }) || [];
                $scope.isEditORI && updateAvailalbeDocRefList();
                // blank Distribution node when form gets loaded.
                $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = [];

                //set default Not Awarded Status
                if ($scope.DSFormId == '') {
                    var selectedStatus = "Not Awarded";
                    var strFormStatusId = getFormStatusId(selectedStatus.trim().toLowerCase());
                    if (strFormStatusId) {
                        $scope.Asite_System_Data_Read_Only['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
                    }
                }
                setScheduleNoteAndPattern();

            } else if (currentViewName == 'ORI_PRINT_VIEW') {
                var placeholderDocStatus = $scope.getValueOfOnLoadData('DS_MTA_Placeholder_Doc_Status'),
                    isSDDLStatus = ($scope.packageDetails.isStatusAwarded == 'Yes'),
                    FIXED_STATUS_LIST = ['ifc', 'ifu', 'ifi', 'can'];
                for (var h = 0; h < $scope.deliverablesDetails.length; h++) {
                    var dObj = $scope.deliverablesDetails[h];
                    //	Initial Due Date. 
                   if (isSDDLStatus) {
                        for (var i = 0; i < placeholderDocStatus.length; i++) {
                            var plObj = placeholderDocStatus[i];
                            if (dObj.guId == plObj.Value2) {

                                //  'Due Date' is vdrMilestone date 
                                //  'resubmissionDate' is the date calculated after another placeholder created over document.
                                //  'remainingDays' is calculated on bases of resubmissionDate.
                                //  'isNegativeDays' is node which will describe remaining days are negative ot positive.
                                //  'publishDate' is the actual Document's publish date.							
                                // 	Document's current Status.				
                                $scope.deliverablesDetails[h].placeHolderStatus = plObj.Value3 || '-';
                                //	Resubmission Due Date.
                                $scope.deliverablesDetails[h].resubmissionDate = plObj.Value7 || '-';
                                // 	Date Received / Publish Date.
                                $scope.deliverablesDetails[h].publishDate = plObj.Value6 || '-';
                                //	Remaining Days and Days Late. 
                                $scope.deliverablesDetails[h].remainingDays = plObj.Value9 || '-';
                                // 	To check Whether negative days there in remaining Days Column.
                                $scope.deliverablesDetails[h].isNegativeDays = !isNaN(plObj.Value9) && parseInt(plObj.Value9) < 0;
                                // to show doc revision no
                                $scope.deliverablesDetails[h].docRev = plObj.Value10 || '-';
                                // 	flag is to highlight the StrikeThrough.
                                $scope.deliverablesDetails[h].isDocRefHighlight = false;
                                // 	to show deactivated Doc ref's in failed filter							
                                if (plObj.Value3 == 'Deactivated') {
                                    $scope.deliverablesDetails[h].trackerDetails.filterCode = "ERR";
                                    // 	set true if latest revision get found deactivated hence stricking through the whole TR.
                                    $scope.deliverablesDetails[h].isDocRefHighlight = true;
                                }
                                if (dObj.placeHolderStatus && dObj.placeHolderStatus != '-') {
                                    $scope.deliverablesDetails[h].placeHolderUrl = plObj.URL4;
                                }

                                //  Client's Requirement to show few things on condition bases. 
                                // 	set blank to Initial Due Date, Remaining Days, Days Late, Resubmission Due Date.
                                //  if ('ifc', 'ifu', 'ifi', 'can') any of these status available for latest revisioned doc from SP.

                                if (FIXED_STATUS_LIST.indexOf(plObj.Value3.toLowerCase()) > -1) {
                                    //	Initial Due Date.
                                    $scope.deliverablesDetails[h].vdrMilestoneDate = '';
                                    //	Remaining Days and Days Late. 
                                    $scope.deliverablesDetails[h].remainingDays = '';
                                    //	Resubmission Due Date.
                                    $scope.deliverablesDetails[h].resubmissionDate = '';
                                }

                                // if Resubmission Due Date OR Date Received / Publish Date available then Initial Due Date to blank 
                                // Value7 --> Resubmission Due Date
                                // Value6 --> Date Received / Publish Date
                                if (plObj.Value7 || plObj.Value6) {
                                    //	Initial Due Date.
                                    $scope.deliverablesDetails[h].vdrMilestoneDate = '';
                                }
                            }
                        }
                    }
                }
                $scope.applyFilterCriteria($scope.filterObj);
            }
        } else {
            $scope.invalidDataLoaded = true;
        }
        //get callback data
        $scope.duplicatemessage = false;
        $scope.checkDuplicate = function (strpackage) {
            var dataSourceName = "DS_MTA_CheckPackageDuplicate";
            //var paramvalue = $scope.packageDetails['package'];
            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": strpackage
                    }]
                }
            };

            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.update({
                    name: dataSourceName
                });

                if (resData) {
                    var spData = angular.fromJson(response.data[dataSourceName]);
                    spData = spData['Items']["Item"] || [];
                    var isduplicate = spData[0]['Value'].split('#');
                    if (isduplicate[0].trim() == "Yes") {
                        $scope.duplicatemessage = true;
                    } else {
                        $scope.duplicatemessage = false;
                    }
                }
            }, throwCallBackError);
        }

        function throwCallBackError(error) {
            console.log(error)
            $window.alert("Error\n\nDatasource callback failed!")
        }

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        $scope.update();
    }
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof asiVendorPackageSubmit !== "undefined") {
        return asiVendorPackageSubmit();
    }
}