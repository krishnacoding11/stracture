/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util','../components/item.selection'], function(angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var dateFormatMap = {"en_GB":"dd-M-yy","fr_FR":"d M yy","es_ES":"dd-M-yy","ru_RU":"dd.mm.yy","en_AU":"dd/mm/yy","en_CA":"d-M-yy","en_US":"M d, yy","zh_CN":"yy-m-d","de_DE":"dd.mm.yy","ga_IE":"d M yy","en_ZA":"dd M yy","ja_JP":"yy/mm/dd","ar_SA":"dd/mm/yy","en_IE":"dd-M-yy","nl_NL":"dd-M-yy"};
    	$scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.requests = {};

        var BAM_TIDP_CONSTANT = {
            non_gate_specific : "Non Gate Specific",
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",

            info :"info",
            review : "Review",
            task : "Task",
            wbsLocation : "WBS Location",
            wbsLifecycle : "WBS Lifecycle",
            wbsWorkType : "WBS Work Type",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation :"Submitted for Information",
            forInformation : "For Information",
            forAcceptance : "For Acceptance"
        }

        var todayDateObj = {};
        $scope.getServerTime(function (serverDate) {
            if(serverDate){
                var dateObj = commonApi.parseDate( BAM_TIDP_CONSTANT.db_date_format , serverDate.split('T')[0]);
                todayDateObj = {
                    strDate : serverDate.split('T')[0],
                    dateObj : dateObj
                }
            }
        });

        var STATIC_OBJ_DATA = {
            Gates_Header : {
                gateName: "",
                gateIdName: "",
                gateColor: "",
                gateNumber: ""
            },
            Gates_Section_Detail: {
                "Gate_Number": "",
                "Gate_Description": "",
                "Gate_Color_Chooser": "",
                "Gate_key_isSelected": ""
            },
            Purpose_Of_Issue_Section_Detail: {
                "Purpose_Of_Issue": "",
                "Commenting_Form_To_Be_Raised": "",
                "Status_To_Be_Picked_Up_For_Status": "",
                "POI_To_Be_Picked_Up_For_Status": "",
                "POI_key_isSelected": ""
            },
            Workflow_Matrix_Section_Detail: {
                "Step_No": "",
                "User_Role": "",
                "Accept": "",
                "Accept_Next_Step": "",
                "Reject": "",
                "Reject_Next_Step": "",
                "Action_Days": "",
                "WFC_key_isSelected": ""
            },

            Deliverables : {
                WBS_ID: "",
                Ref: "",
                Counter: "",
                Deliverable_Item: ""
             }
        }

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.searchFilter = $scope.oriMsgCustomFields['Search_Filter'];
        $scope.gate = $scope.oriMsgCustomFields['Gate'];
        $scope.programmeStage = $scope.oriMsgCustomFields['Programme_Stage'];
        $scope.stageStatus = $scope.oriMsgCustomFields['Stage_Status'];
        $scope.deliverables = $scope.oriMsgCustomFields['Deliverable']['Deliverables'];

        initFilterDropdown(true);

        $scope.GateStructure = {
            Gate_Number: "",
            Gate_Description: "",
            Gate_Color_Chooser: ""
        }
        $scope.POIStructure = {
            Purpose_Of_Issue: "",
            Commenting_Form_To_Be_Raised: "",
            Status_To_Be_Picked_Up_For_Status: "",
            POI_To_Be_Picked_Up_For_Status: ""
        }
        $scope.Workflow_Matrix = {
            Step_No: "",
            User_Role: "",
            Accept: "",
            Accept_Next_Step: "",
            Reject: "",
            Reject_Next_Step: "",
            Action_Days: ""
        }

        /**
         * Get SP data and Create Dynamic Headers For Gates
         */
        function createGatesHeader(){
            var dsAsiTidpGetGateDetails = $scope.getValueOfOnLoadData('DS_TFL_STD_GET_GATE_DETAILS');
            $scope.gatesHeader = [];
            $scope.gateHeaderPrefix = [];

            var i = 0, element, tempNode;
            
            for (; i < dsAsiTidpGetGateDetails.length; i++) {
                element = dsAsiTidpGetGateDetails[i];
                tempNode = angular.copy( STATIC_OBJ_DATA.Gates_Header );

                tempNode.gateNumber = element.Value1;
                tempNode.gateName = element.Value2;
                tempNode.gateIdName = element.Value1 + ' | ' + element.Value2;                
                tempNode.gateColor = element.Value3;
                
                $scope.gatesHeader.push(tempNode);

                $scope.oriMsgCustomFields['Gate']['Project_Type_Stage'+i] = "";
                $scope.programmeStage['Close_Date_Stage'+i] = "";
                $scope.stageStatus['Status_Stage'+i] = ""

                $scope.gateHeaderPrefix.push('Gate'+i);

                addStaticNodeOfGates(i);
            }

            var gateLength = $scope.gatesHeader.length;
            var totalCols = 2 + gateLength;
            var cellWidth = 210;
            $scope.dynamicTableWidth = (totalCols*cellWidth)+totalCols + "px";
        }

        /**
         * @param { Number } gateIndex : Passed Gate Index to create Static object for Deliverable
         */
        function addStaticNodeOfGates( gateIndex ){
            var tmpGatePrefix = "Gate" + gateIndex;
            var tmpGateKeys = [ "_Stage_No", "_RAG_Stage", "_PKG_URL", "_PKG_ID", "_PackageDeliveryDate", "_PackageDeliveryDueDate", "_IsRAGFlag", "_WBS_Location", "_Function", "_WBS_WorkType", "_Title", "_Revision", "_ActualSubmission", "_PkgStatus", "_StatusDate", "_ColorFlagActualSub", "_ColorFlagStatus", "_SubmissionPurpose" ];
            
            var tmpPackge = {},
                tmpNode, i = 0;
            for (; i < tmpGateKeys.length; i++) {
                tmpNode = tmpGatePrefix + tmpGateKeys[i];
                tmpPackge[ tmpNode ] = "";
            }
            tmpPackge[ "Ref_ID" ] = "";

            STATIC_OBJ_DATA[ tmpGatePrefix + "_Packages" ] = tmpPackge;
            STATIC_OBJ_DATA['Deliverables'][ tmpGatePrefix + "_Package" ] = {};
            STATIC_OBJ_DATA['Deliverables'][ tmpGatePrefix + "_Package" ][ tmpGatePrefix + "_Packages" ] = [];
        }

         /**
          * Initialize all Filter models and Dropdown lists
          * Also append Dynimc Headers data on Load
          * @param {boolean} onloadFlag : flag used to create dynamic header only first time
          */
        function initFilterDropdown(onloadFlag){

            if(onloadFlag){
                createGatesHeader();
            }
            
            $scope.searchFilter['WBS_Deliverable_Search'] = '';
            $scope.searchFilter['WBS_Location_Search'] = '';
            $scope.searchFilter['WBS_LifeCycle_Search'] = '';
            $scope.searchFilter['WBS_WorkType_Search'] = '';
            $scope.deliverables = [];
            
            var dsAsiTIDPgetPicklist = $scope.getValueOfOnLoadData('DS_TFL_STD_GET_PICKLIST');
            var dsProjectPOIList = $scope.getValueOfOnLoadData('DS_ProjectPOIList');
            var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            

            $scope.Logo = commonApi._.filter(dsAsiConfigurableAttributes , function(customAttr){
                return customAttr.Value3 == "LOGO";
            }).map(function(mapObj){
                return mapObj.Value8
            })[0] || BAM_TIDP_CONSTANT.defaultLogo;
            
            var tmpGate = [],
                i = 0, piclklist;

            for (; i < dsAsiTIDPgetPicklist.length; i++) {
                piclklist = dsAsiTIDPgetPicklist[i];    
                if(piclklist.Value1 == "13" && piclklist.Value3 != "508"){
                    tmpGate.push(piclklist);
                }
            }
        
            var gateParam = {
                arrayObject : $scope.gatesHeader,
                groupNameKey: "",
                modelKey : "gateNumber",
                displayKey : "gateIdName"
            }
            var gateList = commonApi.getItemSelectionList(gateParam);

            var poiParam = {
                arrayObject : dsProjectPOIList,
                groupNameKey: "",
                modelKey : "Value2",
                displayKey : "Value2"
            }
            var submissionPurpose = commonApi.getItemSelectionList(poiParam);

            $scope.filterDropdownList = {
                gate: gateList,
                task: [],
                location: [],
                lifeCycle: [],
                workType: [],
                submissionPurpose : submissionPurpose,
                page : []
            }

            $scope.filterModels = {
                gate: '',
                locationFilter: '',
                lifeCycleFilter: '',
                workTypeFilter: '',
                deliverableFilter: '',
                submissionPurpose: '',
                pagging: ''
            }

            setPagingData(1);
            $scope.filterModels.pagging = $scope.filterDropdownList.page[0].pageModal;
        }

        $scope.searchFilterDropdown = searchFilterDropdown;
        function searchFilterDropdown(filterArea) {
            
            var searchParam = "";
            var dataSourceName = '';

            switch(filterArea){
                case BAM_TIDP_CONSTANT.task:
                    if($scope.searchFilter['WBS_Deliverable_Search']){
                        searchParam = "|" + $scope.searchFilter['WBS_Deliverable_Search'];
                    }
                    dataSourceName = 'DS_TFL_STD_DELIVERABLES_DEF';
                    break;
                case BAM_TIDP_CONSTANT.wbsLocation:
                    searchParam = $scope.searchFilter['WBS_Location_Search'];
                    dataSourceName = 'DS_TFL_STD_WBS_LOCATION';
                    break;
                case BAM_TIDP_CONSTANT.wbsLifecycle:
                    searchParam = $scope.filterModels.locationFilter + "|" + $scope.searchFilter['WBS_LifeCycle_Search'];
                    dataSourceName = 'DS_TFL_STD_WBS_LIFECYCLE';
                    break;
                case BAM_TIDP_CONSTANT.wbsWorkType:
                    searchParam = $scope.filterModels.locationFilter + "|" + $scope.filterModels.lifeCycleFilter + "|" + $scope.searchFilter['WBS_WorkType_Search'];
                    dataSourceName = 'DS_TFL_STD_WBS_WORKTYPE';
                    break;
            }

            var paramFilter = {
                dataSourceName : dataSourceName,
                dataParam : searchParam,
                callback : fillItemSelection
            }
            tidpAjaxFilter(paramFilter);  
            
            function fillItemSelection(data){
                var tmpData = commonApi._.unique(data);
                var searchParam = {
                    arrayObject : tmpData,
                    groupNameKey: "",
                    modelKey : "Value2",
                    displayKey : "Value3"
                }
                var tmpList = commonApi.getItemSelectionList(searchParam);

                switch(filterArea){
                    case BAM_TIDP_CONSTANT.task:
                        searchParam.modelKey = "Value4";
                        tmpList = commonApi.getItemSelectionList(searchParam);
                        $scope.filterDropdownList.task = angular.copy( tmpList );
                        $scope.filterModels.deliverableFilter = "";
                        break;
                    case BAM_TIDP_CONSTANT.wbsLocation:
                        $scope.filterDropdownList.location = angular.copy( tmpList );
                        $scope.filterModels.locationFilter = "";
                        break;
                    case BAM_TIDP_CONSTANT.wbsLifecycle:
                        $scope.filterDropdownList.lifeCycle = angular.copy( tmpList );
                        $scope.filterModels.lifeCycleFilter = "";
                        break;
                    case BAM_TIDP_CONSTANT.wbsWorkType:
                        $scope.filterDropdownList.workType = angular.copy( tmpList );
                        $scope.filterModels.workTypeFilter = "";
                        break;
                }
            }
        }

        $scope.filterDeliverables = filterDeliverables;
        $scope.showAllData = showAllData;
        $scope.resetFilters = resetFilters;
        $scope.changePage = changePage;
        $scope.prevPage = prevPage;
        $scope.nextPage = nextPage;

        /**
         * Used to load previous page in Dashboard
         */
        function prevPage(){
            var currIndex = commonApi._.findIndex( $scope.filterDropdownList.page, {
                pageModal : $scope.filterModels.pagging
                });

            if(currIndex > 0){
                currIndex--;
                changePage( $scope.filterDropdownList.page[ currIndex ] )
            }
        }

        /**
         * Used to load next page in Dashboard
         */
        function nextPage(){
            var currIndex = commonApi._.findIndex( $scope.filterDropdownList.page, {
                pageModal : $scope.filterModels.pagging
                });

            if($scope.filterDropdownList.page.length-1 > currIndex){
                currIndex++;
                changePage( $scope.filterDropdownList.page[ currIndex ] )
            }
        }

        /**
         * Used to change page using 1,2,3 Paging icon in Dashboard
         * @param { String } pageObj.pageModal : Page String like 1-25, 25-50...
         * @param { Number } pageObj.pageDisplay : Page Number like 1,2,3...
         */
        function changePage(pageObj){
            $scope.filterModels.pagging = pageObj.pageModal;
            filterDeliverables();
        }

        /**
         * To display all data in Dashboard
         */
        function showAllData(){
            initFilterDropdown();
            $scope.filterModels.pagging = "1-25";
            filterDeliverables();
        }

        /**
         * To reset all seaarch filter
         */
        function resetFilters(){
            initFilterDropdown();
        }

        /**
         * Filter Deliverables based on searched data
         * It's common filter for all available filter in UI
         */
        function filterDeliverables(){
            var separatorString = '@$@';

            $scope.oriMsgCustomFields['Search_Filter']['Gate_Filter'] = $scope.filterModels.gate.toLowerCase();
            $scope.oriMsgCustomFields['Search_Filter']['WBS_Location_Filter'] = $scope.filterModels.locationFilter.toLowerCase();
            $scope.oriMsgCustomFields['Search_Filter']['WBS_LifeCycle_Filter'] = $scope.filterModels.lifeCycleFilter.toLowerCase();
            $scope.oriMsgCustomFields['Search_Filter']['WBS_WorkType_Filter'] = $scope.filterModels.workTypeFilter.toLowerCase();
            $scope.oriMsgCustomFields['Search_Filter']['WBS_Deliverable_Filter'] = $scope.filterModels.deliverableFilter.toLowerCase();
            $scope.oriMsgCustomFields['Search_Filter']['SubmissionPurpose'] = $scope.filterModels.submissionPurpose.toLowerCase();
            $scope.oriMsgCustomFields['Page_Filter']['Pagging'] = $scope.filterModels.pagging;

            var deliverablesParam = 
                $scope.oriMsgCustomFields['Search_Filter']['Gate_Filter'] + separatorString + 
                $scope.oriMsgCustomFields['Search_Filter']['WBS_Location_Filter'] + separatorString + 
                $scope.oriMsgCustomFields['Search_Filter']['WBS_LifeCycle_Filter'] + separatorString + 
                $scope.oriMsgCustomFields['Search_Filter']['WBS_WorkType_Filter'] + separatorString + 
                $scope.oriMsgCustomFields['Search_Filter']['WBS_Deliverable_Filter'] + separatorString + 
                $scope.oriMsgCustomFields['Page_Filter']['Pagging'] + separatorString + 
                $scope.oriMsgCustomFields['Search_Filter']['SubmissionPurpose'];

            var paramFilter = {
                dataSourceName : 'DS_TFL_STD_GET_DELIVERABLES',
                dataParam : deliverablesParam,
                callback : addNodeToDeliverable
            }
            tidpAjaxFilter(paramFilter);
        }

        /***
         * tidpAjaxFilter used to make getCallbackData to get SP data
         * @param dataSourceName { String } : SP name which return data as per param
         * @param dataParam { String } : param string which SP needs
         * @param callback { Function } : callback function after successfull ajax call
         */
        function tidpAjaxFilter(params) {
            var dataSourceName = params.dataSourceName;
            var dataParam = params.dataParam;
            var callback = params.callback;
            
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceName,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceName,
                        "fieldValue": dataParam
                    }]
                }
            };

            if(document.URL.indexOf('adoddle') > 0){
                form["callerApp"] = 10;
            }

            $scope.requests[dataSourceName] = true;
            $scope.add({
                name: dataSourceName,
                status: "incomplete"
            });
            $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                if(resData){
                    var spData = angular.fromJson(response.data[ dataSourceName ]);
                    spData = spData ? spData['Items']["Item"] : [];

                    callback(spData);
                }

                $scope.requests[ dataSourceName ] = false;
                $scope.update({
                    name: dataSourceName,
                    status: "completed"
                });
            }, throwCallBackError);
        }

        /**
         * This function used to manage callback Error in Ajax call
         * @param { Object } error : Error Object from server side
         */
        function throwCallBackError(error){
            console.log(error)
            $window.alert("Error\n\nDatasource callback failed!")
        }

        /**
         * addNodeToDeliverable Used to add sp data to deliverable Node based on filter and show all Data
         * @param { Array }
         */
        function addNodeToDeliverable( dataArray ){
            $scope.deliverables = [];

            var strTotalRecord = "0",
                hsTable = [],
                guid = "",
                xpnLoop, objDeleverables,
                strAgainst, strDeliverable,
                strLocation, strKey, gateArray,
                straDeli, k = 0, m,
                tmpGatePrefix, paramObj;
            
            for (; k < dataArray.length; k++) {
                xpnLoop = dataArray[k];
                objDeleverables = angular.copy( STATIC_OBJ_DATA.Deliverables )

                strAgainst = xpnLoop["Value2"];
                strDeliverable = xpnLoop["Value3"];
                strLocation = xpnLoop["Value5"];
                strTotalRecord = xpnLoop["Value12"];

                strKey = strAgainst + "|" + strDeliverable;

                if ( hsTable.indexOf(strKey) == -1 ){
                    hsTable.push(strKey);
                    guid = commonApi.guId();

                    straDeli = strDeliverable.split("||");

                    objDeleverables.WBS_ID = guid;
                    objDeleverables.Ref = strAgainst;
                    objDeleverables.Deliverable_Item = straDeli.length > 1 ? straDeli[1] : straDeli[0];

                    for (m = 0; m < $scope.gatesHeader.length; m++) {
                        tmpGatePrefix = "Gate"+m;
                        paramObj = {
                            gateIndex : m,
                            dataArray : dataArray,
                            strAgainst : strAgainst,
                            strDeliverable : strDeliverable,
                            strLocation : strLocation
                        }
                        gateArray = createGatesNode( paramObj );
                        objDeleverables[ tmpGatePrefix + '_Package' ][ tmpGatePrefix + '_Packages' ] = angular.copy( gateArray );
                    }   
                    $scope.deliverables.push(objDeleverables);
                }   
            }
            setPagingData(strTotalRecord);
        }

        /**
         * Create Deliverables filter based on total record return by SP
         * @param { Number } recordsCount : Count of number of deliverables
         */
        function setPagingData(recordsCount){
            var recordsCount = parseInt(recordsCount);
            var perPageCount = $scope.oriMsgCustomFields['Page_Filter']['Page_Size'];
            perPageCount = parseInt(perPageCount);

            var numberOfPage = Math.ceil(recordsCount/perPageCount),
                tempPage = [],
                pageStart = 1,
                pageEnd = perPageCount,
                pageStrForDB = "",
                i = 0;
            for (; i < numberOfPage; i++) {
                pageStrForDB = pageStart + '-' + pageEnd;
                
                tempPage.push({
                    pageDisplay: i+1,
                    pageModal: pageStrForDB
                });

                pageStart = pageEnd+1;
                pageEnd = pageEnd+perPageCount;
            }

            $scope.filterDropdownList.page = angular.copy(tempPage);
        }

        /**
         * Create Gate wise node and return Array of Pericular Gate
         * Like Gate0 , Gate1, Gate2... etc
         * @param gateIndex { Number } : which defined for which gate need to build
         * @param dataArray { Arraya } : data comes from db side , filtered data
         * @param strAgainst { String } : strAgainst string value which link with Gate
         * @param strDeliverable { String } : strDeliverable string value which link with Gate
         */
        function createGatesNode(paramObj) {
            var gateArray = [];
            var tmpVal7, tmpActGate;
            var gatePrefix = "Gate"+ paramObj.gateIndex;
            var gateSpecificArray = commonApi._.map( $scope.gatesHeader , function(gateObj){
                return gateObj.gateNumber
            });

            var xpniData = commonApi._.filter( paramObj.dataArray, function(objGate){
                tmpVal7 = objGate.Value7.split('|')[0];
                tmpActGate = tmpVal7 || "";
                tmpActGate = tmpActGate && tmpActGate.trim();

                return objGate.Value2 == paramObj.strAgainst && objGate.Value3 == paramObj.strDeliverable && tmpActGate == gateSpecificArray[ paramObj.gateIndex ];
            });

            var strPackageDeliveryDueDate = "",
                strRAG_Stage = "",
                strRAGFlag = "",
                m = 0, xpnNode, strSubmission,
                dtPackageDeliveryDueDate,
                diffTime,diffDays,
                geteObj;

            if(xpniData != null && xpniData.length > 0 ){
                for (; m < xpniData.length; m++) {
                    xpnNode = xpniData[m];
                    strSubmission = "";

                    strPackageDeliveryDueDate = xpnNode["Value8"] ? xpnNode["Value8"] : "";
                    strRAG_Stage = xpnNode["Value10"] ? xpnNode["Value10"] : "";

                    strRAGFlag = "";

                    dtPackageDeliveryDueDate = commonApi.parseDate( "dd/mm/yy" , strPackageDeliveryDueDate);
                    if(dtPackageDeliveryDueDate){

                        // For Green
                        if(strRAG_Stage.trim() == BAM_TIDP_CONSTANT.accepted || strRAG_Stage.trim() == BAM_TIDP_CONSTANT.acceptedWithComments || strRAG_Stage.trim() == BAM_TIDP_CONSTANT.submittedForInformation ){
                            strRAGFlag = "3";
                        }else{

                            // For RED
                            if(dtPackageDeliveryDueDate.getTime() <= todayDateObj.dateObj.getTime() ){
                                strRAGFlag = "1";
                            }

                            // For Amber
                            else {
                                diffTime = Math.abs( dtPackageDeliveryDueDate.getTime() - todayDateObj.dateObj.getTime());
                                diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                                
                                if ( diffDays <= 7 ) {
                                    strRAGFlag = "2";
                                }
                            }
                        }
                    }
                    
                    geteObj = angular.copy( STATIC_OBJ_DATA[ gatePrefix + "_Packages" ] );

                    geteObj[ "Ref_ID" ] = commonApi.guId();
                    geteObj[ gatePrefix + "_Stage_No" ] = xpnNode["Value7"];
                    geteObj[ gatePrefix + "_RAG_Stage" ] = xpnNode["Value10"];
                    geteObj[ gatePrefix + "_PKG_URL" ] = xpnNode["URL11"];
                    geteObj[ gatePrefix + "_PKG_ID" ] = xpnNode["Value11"];
                    geteObj[ gatePrefix + "_PackageDeliveryDate" ] = xpnNode["Value8"];
                    geteObj[ gatePrefix + "_PackageDeliveryDueDate" ] = xpnNode["Value9"];
                    geteObj[ gatePrefix + "_IsRAGFlag" ] = strRAGFlag;
                    geteObj[ gatePrefix + "_WBS_Location" ] = paramObj.strLocation;
                    geteObj[ gatePrefix + "_WBS_WorkType" ] = xpnNode["Value6"];
                    geteObj[ gatePrefix + "_Title" ] = xpnNode["Value13"];
                    geteObj[ gatePrefix + "_Revision" ] = xpnNode["Value14"] != "-" ? xpnNode["Value14"] : "";
                    geteObj[ gatePrefix + "_ActualSubmission" ] = xpnNode["Value15"];
                    geteObj[ gatePrefix + "_PkgStatus" ] = xpnNode["Value16"];
                    geteObj[ gatePrefix + "_StatusDate" ] = xpnNode["Value17"];
                    geteObj[ gatePrefix + "_ColorFlagActualSub" ] = xpnNode["Value18"];
                    geteObj[ gatePrefix + "_ColorFlagStatus" ] = xpnNode["Value19"];

                    if( xpnNode["Value21"] == "Yes"){
                        strSubmission = BAM_TIDP_CONSTANT.review;
                    }else{
                        strSubmission = BAM_TIDP_CONSTANT.info;
                    }

                    geteObj[ gatePrefix + "_SubmissionPurpose" ] = strSubmission;
                    gateArray.push(geteObj);
                }
            }

            return gateArray;
        }

        $scope.update();
    };
    return FormController;
});