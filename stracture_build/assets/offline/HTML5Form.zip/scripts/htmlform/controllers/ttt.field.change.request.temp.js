
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        //autoSaveDraft timeout from client side
        $scope.stopAutoSaveDraftTimerFromClientSide();

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var STATIC_OBJ_DATA = {
            DS_AutoDistribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: ""
            },
            FCR_Files: {
                FCR_Attachment: ""
            },
            Designer_File: {
                Designer_Attachment: ""
            },
            CAT3_Checker_File: {
                CAT3_Checker_Attachment: ""
            },
            DSI_Formsetting: {
                Setting_name: "",
                Original_value: "",
                Expected_value: ""
            }
        };
        $scope.tableUtilSettings = {
            FCR_Files: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "FCR_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.FCR_Files),
                ADD_NEW_BEFORE_TIP: "Insert before document",
                ADD_NEW_AFTER_TIP: "Insert after document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg: "Remove document",
                deleteSelectedMsg: "Remove selected document"
            },
            Designer_File: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "D_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Designer_File),
                ADD_NEW_BEFORE_TIP: "Insert before document",
                ADD_NEW_AFTER_TIP: "Insert after document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg: "Remove document",
                deleteSelectedMsg: "Remove selected document"
            },
            CAT3_Checker_File: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                },
                checkboxModelKey: "CAT_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.CAT3_Checker_File),
                ADD_NEW_BEFORE_TIP: "Insert before document",
                ADD_NEW_AFTER_TIP: "Insert after document",
                deleteAllRowTooltip: "Remove all documents",
                deleteCurrRowMsg: "Remove document",
                deleteSelectedMsg: "Remove selected document"
            }
        }
        var FCR_CONSTANT = {
            //To fill dropdown rolewise
            twcController:'FCR Temporary Works Coordinator',
            floController: 'FCR Temp FLO Controller',
            tideway: 'FCR Temp Tideway',
            fcrdesigner: 'FCR Temp Designer',
            catChecker: 'FCR Temp CAT3 Checker',

            //define status
            pendingbyTWCcontroller:"Pending by TWC Coordinator",
            pendingbyFLOcontroller: "Pending by FLO Controller",
            pendingbyOriginator: "Pending by Originator",
            pendingbyTideway: "Pending by Tideway",
            pendingbyDesigner: "Pending by Designer",
            pendingbyCATChecker: "Pending by CAT Checker",
            closedstatus: "Closed",
            rejectedClosed: "rejected-Closed"
        }

        /** Initialize db fields */
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadOnly = $scope.formCustomFields["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.formCustomFields["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadWrite["ORI_MSG_Fields"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.DesignManagersAssessment = $scope.oriMsgCustomFields["Design_Managers_Assessment"];
        $scope.dsiCurrentstage = $scope.oriMsgCustomFields["Stages"]["DSI_Current_Stage"];
        $scope.dsiNextstage = $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"];
        $scope.designer = $scope.oriMsgCustomFields['Response_by_the_Designer'];
        $scope.ds_Projdistgroups = $scope.getValueOfOnLoadData("DS_PROJDISTGROUPS");
        var ds_Projusers_Role = $scope.getValueOfOnLoadData("DS_PROJUSERS_ROLE");
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var ds_Incomplete_Actions_bymsg = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        $scope.ds_all_Status_Withcloseout = $scope.getValueOfOnLoadData('DS_ALL_STATUS_WithCloseout');
        $scope.ds_Asi_Get_All_Default_FormSettingDetails = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var dsWorkingUser = "";
        if (dsWorkingUserId[0]) {
            dsWorkingUser = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }


        var todayDate = '';
        $scope.getServerTime(function (serverDate) {
            todayDate = serverDate;
            initORIview();
        });

        function initORIview() {

            if (currentViewName == "ORI_VIEW") {
                var dbFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
                var isForwardDraftbyMSG = $scope.oriMsgFields['DS_ISDRAFT_FWD_MSG'];
                var isForwardDraftAll = $scope.oriMsgFields['DS_ISDRAFT_FWD'];
                var isDraftEditOri = $scope.oriMsgFields['DS_ISDRAFT_EDITORI'];
                var isDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
                var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');

                //check formsetting
                if (isDraft == "NO" && dbFormId == "") {
                    checkFormSetting();
                    $scope.oriMsgCustomFields['Work_Type'] = 'Temporary Work';
                }
                //check and discard all draft forms before creating new form.
                if (dbFormId != "" && isDraft == "NO") {
                    if (isForwardDraftbyMSG == "NO" && isForwardDraftAll == "YES") {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEditDraft = true;
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not authorised to create this form. please click the cancel button at the bottom of the form. \n \n If you want to create the new form than please discard draft forms.";
                        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
                        $scope.update();
                        return;
                    } else {
                        $scope.flagIsAllowEditDraft = false;
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
                    }
                }
                // check assign status for working user.
                if (dbFormId != "" && isDraft == "NO") {
                    var isrequired = checkPendingAction(dsWorkingUserId);
                    if (isrequired == false) {
                        //if not than dont allow to edit
                        $scope.flagIsAllowEdit = true;
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not authorised to create or edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
                        $scope.update();
                        return;

                    } else {
                        $scope.flagIsAllowEdit = false;
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
                    }
                }


                if (dbFormId != "" && isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                    $scope.oriMsgCustomFields["Stages"]["DSI_Current_Stage"] = $scope.dsiNextstage;
                    $scope.dsiCurrentstage = $scope.dsiNextstage;
                }

                if ($scope.dsiCurrentstage == "1") {
                    setRolewiseUser(FCR_CONSTANT.twcController);
                    setRolewiseUser(FCR_CONSTANT.floController);
                    setRolewiseUser(FCR_CONSTANT.tideway);
                    setRolewiseUser(FCR_CONSTANT.fcrdesigner);
                    setRolewiseUser(FCR_CONSTANT.catChecker);
                    $scope.oriMsgCustomFields['Originator'] = dsWorkingUser;
                    $scope.oriMsgCustomFields['Request_made_by'] = dsWorkingUser;

                    $scope.oriMsgCustomFields['OriginatorResDate'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');
                    $scope.oriMsgCustomFields['Response_requested_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');
                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        setStages();
                    }

                }
                if($scope.dsiCurrentstage == "1A"){
                    setRolewiseUser(FCR_CONSTANT.twcController);
                    setRolewiseUser(FCR_CONSTANT.floController);
                    setRolewiseUser(FCR_CONSTANT.tideway);
                    setRolewiseUser(FCR_CONSTANT.fcrdesigner);
                    setRolewiseUser(FCR_CONSTANT.catChecker);
                    
                    $scope.oriMsgCustomFields['TWC_Controller']['TWC_Res_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');
                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        $scope.oriMsgCustomFields['TWC_Controller']['TWC_Comment'] = "";
                        $scope.oriMsgCustomFields['TWC_Controller']['TWC_Stage1_Status'] = "";
                        setStages();
                    }
                }
                if ($scope.dsiCurrentstage == "1a") {
                    setRolewiseUser(FCR_CONSTANT.floController);
                    setRolewiseUser(FCR_CONSTANT.tideway);
                    setRolewiseUser(FCR_CONSTANT.fcrdesigner);
                    setRolewiseUser(FCR_CONSTANT.catChecker);

                    $scope.oriMsgCustomFields['FLO_Controller']['FCR_Res_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');
                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        setStages();
                    }

                }
                if ($scope.dsiCurrentstage == "2") {
                    $scope.oriMsgCustomFields['Tideway']['Tideway_Response_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');
                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        setStages();
                    }
                }
                if ($scope.dsiCurrentstage == "3" || $scope.dsiCurrentstage == "5") {
                    $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Response_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');

                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Comment'] = "";
                        $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_File_Group']['Designer_File'] = [];
                    }
                }
                if ($scope.dsiCurrentstage == "6") {
                    $scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_Response_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');

                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        $scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_Comment'] = "";
                        $scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_File_Group']['CAT3_Checker_File'] = [];
                    }
                }
                if ($scope.dsiCurrentstage == "4" || $scope.dsiCurrentstage == "7") {
                    setRolewiseUser(FCR_CONSTANT.floController);
                    setRolewiseUser(FCR_CONSTANT.tideway);
                    setRolewiseUser(FCR_CONSTANT.fcrdesigner);
                    setRolewiseUser(FCR_CONSTANT.catChecker);

                    $scope.oriMsgCustomFields['FLO_Controller']['FCR_Res_date_Stage4_7'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');

                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        $scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage4_7_Status'] = "";
                        $scope.oriMsgCustomFields['FLO_Controller']['FCR_Comment_Stage4_7'] = "";
                    }
                }
                if ($scope.dsiCurrentstage == "8") {
                    $scope.oriMsgCustomFields['Tideway']['Tideway_Response_date'] = $scope.formatDate(new Date(todayDate), 'dd/MM/yy');

                    if (isDraft == "NO" && isDraftEditOri == "NO" && isForwardDraftbyMSG == "NO") {
                        $scope.oriMsgCustomFields['Tideway']['Tideway_Status'] = "";
                        $scope.oriMsgCustomFields['Tideway']['Tideway_Comment'] = "";
                    }
                }
            }
        }
        $scope.setStages = setStages;
        function setStages() {
            var currentstage = $scope.dsiCurrentstage;
            if (currentstage) {
                switch (currentstage) {
                    case '1':
                        if ($scope.oriMsgCustomFields['Category'] != "") {
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "1A"
                            setFormStatus(FCR_CONSTANT.pendingbyTWCcontroller);

                            if($scope.oriMsgCustomFields['TWC_Controller']['TWC_Stage1_Status'] == "Reject"){
                                // resetting the node first
                                $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];
                                //set category 
                                var actualcategory = $scope.oriMsgCustomFields["Category"];
                                $scope.oriMsgCustomFields["Category_Old"] = angular.copy(actualcategory);
      
                                var controller = $scope.oriMsgCustomFields['TWC_Controller']['TWC_Name'];
                                allUserRoleChangeSet(controller, "1A");
                            }
                        }
                        break;
                    case '1A':
                        if ($scope.oriMsgCustomFields['TWC_Controller']['TWC_Stage1_Status'] == "Accept") {
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "1a"
                            setFormStatus(FCR_CONSTANT.pendingbyFLOcontroller);

                            //set category 
                            var actualcategory = $scope.oriMsgCustomFields["Category"];
                            $scope.oriMsgCustomFields["Category_Old"] = angular.copy(actualcategory);

                            var controller = $scope.oriMsgCustomFields['FLO_Controller']['FCR_Name'];
                            allUserRoleChangeSet(controller, "1a");
                        }
                        else if ($scope.oriMsgCustomFields['TWC_Controller']['TWC_Stage1_Status'] == "Reject") { 
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "1";
                            setFormStatus(FCR_CONSTANT.pendingbyOriginator);

                            // resetting the node first
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            
                            //set distribution
                            var strdate = calculateDistDate(1);
                            setAutoDistribution(stroriginator.split('|')[0], "2#", strdate, 1);
                            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                        }
                        break;
                    case '1a':
                        if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage1_Status'] == "Accept") {
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "2";
                            setFormStatus(FCR_CONSTANT.pendingbyTideway);

                            //set category 
                            var actualcategory = $scope.oriMsgCustomFields["Category"];
                            $scope.oriMsgCustomFields["Category_Old"] = angular.copy(actualcategory);

                            var controller = $scope.oriMsgCustomFields['Tideway']['Tideway_Name'];
                            allUserRoleChangeSet(controller, "2");
                        }
                        else if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage1_Status'] == "Reject") {
                            //set originator to for information and overallform status will be rejected-closed
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];
                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            setFormStatus(FCR_CONSTANT.rejectedClosed);
                            setAutoDistribution(stroriginator.split('|')[0], "7#", "", 1);
                        }
                        break;
                    case '2':
                        var oldcategory = "", newcategory = "";
                        oldcategory = $scope.oriMsgCustomFields['Category_Old'];
                        newcategory = $scope.oriMsgCustomFields['Category'];
                        if (oldcategory == newcategory) {
                            if ($scope.oriMsgCustomFields['Category'] == "Minor" || $scope.oriMsgCustomFields['Category'] == "Moderate") {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "3";
                                setFormStatus(FCR_CONSTANT.pendingbyDesigner);
                            }
                            if ($scope.oriMsgCustomFields['Category'] == "Major") {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "5";
                                setFormStatus(FCR_CONSTANT.pendingbyDesigner);
                            }
                            var controller = $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Name'];
                            allUserRoleChangeSet(controller, "3");
                        }
                        else {
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "1a";
                            setFormStatus(FCR_CONSTANT.pendingbyFLOcontroller);

                            // resetting the node first
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            var controller = $scope.oriMsgCustomFields['FLO_Controller']['FCR_Name'];
                            var approverVal = controller.split('|')[2].trim().split(' ')[0];

                            //set distribution
                            var strdate = calculateDistDate(1);
                            setAutoDistribution(approverVal, "2#", strdate, 1);
                            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;

                        }
                        break;
                    case '3':
                        if ($scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Comment'] != "") {
                            if ($scope.oriMsgCustomFields['Category'] == "Minor" || $scope.oriMsgCustomFields['Category'] == "Moderate") {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "4";
                                setFormStatus(FCR_CONSTANT.pendingbyOriginator);
                            }

                            // resetting the node first
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            //set Distribtion
                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            var strdate = calculateDistDate(1);
                            setAutoDistribution(stroriginator.split('|')[0], "2#", strdate, 1);

                            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                        }
                        break;
                    case '5':
                        if ($scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Comment'] != "") {
                            if ($scope.oriMsgCustomFields['Category'] == "Major") {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "6";
                                setFormStatus(FCR_CONSTANT.pendingbyCATChecker);

                                // resetting the node first
                                $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                                var catchecker = $scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_Name'];
                                var approverVal = catchecker.split('|')[2].trim().split(' ')[0];
                                //set distribution
                                var strdate = calculateDistDate(2);
                                setAutoDistribution(approverVal, "2#", strdate, 1);
                                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                            }
                        }
                        break;
                    case '6':
                        if ($scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_Comment'] != "") {
                            $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "7";
                            setFormStatus(FCR_CONSTANT.pendingbyOriginator);

                            // resetting the node first
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            //set Distribtion
                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            var strdate = calculateDistDate(1);
                            setAutoDistribution(stroriginator.split('|')[0], "2#", strdate, 1);

                            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                        }
                        break;
                    case '8':
                        if ($scope.oriMsgCustomFields['Tideway']['Tideway_Status'] == "Accept") {
                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            var strfcrname = $scope.oriMsgCustomFields['FLO_Controller']['FCR_Name'];
                            var strcatchecker = $scope.oriMsgCustomFields['CAT3_Checker']['CAT3_Checker_Name'];
                            var strdesigner = $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Name'];
                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            var fcrclosuregroup = commonApi._.filter($scope.ds_Projdistgroups, function (item) {
                                return item.Value.indexOf("FCR_Closure_Group") > -1;
                            });

                            if (fcrclosuregroup.length) {
                                fillFCRGroup(fcrclosuregroup[0].Value);
                            }
                            setAutoDistribution(strfcrname.split('|')[2].trim().split(' ')[0], "7#", "", 1);
                            if ($scope.oriMsgCustomFields['Category'] == "Major") {
                                setAutoDistribution(strcatchecker.split('|')[2].trim().split(' ')[0], "7#", "", 1);
                            }
                            setAutoDistribution(strdesigner.split('|')[2].trim().split(' ')[0], "7#", "", 1);
                            setAutoDistribution(stroriginator.split('|')[0], "7#", "", 1);

                            setFormStatus(FCR_CONSTANT.closedstatus);
                        }
                        if ($scope.oriMsgCustomFields['Tideway']['Tideway_Status'] == "Reject") {
                            if ($scope.oriMsgCustomFields['Category'] == "Minor" || $scope.oriMsgCustomFields['Category'] == "Moderate") {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "4";
                            }
                            else {
                                $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "7";
                            }

                            setFormStatus(FCR_CONSTANT.pendingbyOriginator);

                            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                            //set distribution
                            var stroriginator = $scope.oriMsgCustomFields['Originator'];
                            var strdate = calculateDistDate(1);
                            setAutoDistribution(stroriginator.split('|')[0], "2#", strdate, 1);
                            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
                        }
                        break;
                }
            }
            if ($scope.dsiCurrentstage == "7" || $scope.dsiCurrentstage == "4") {
                if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage4_7_Status'] == "Accept") {
                    $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "8";
                    setFormStatus(FCR_CONSTANT.pendingbyTideway);

                    $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                    var controller = $scope.oriMsgCustomFields['Tideway']['Tideway_Name'];
                    var approverVal = controller.split('|')[2].trim().split(' ')[0];

                    //set distribution
                    var strdate = calculateDistDate(2);
                    setAutoDistribution(approverVal, "2#", strdate, 1);

                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;

                }
                if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage4_7_Status'] == "Reject") {
                    if ($scope.dsiCurrentstage == "7") { $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "5"; }
                    else { $scope.oriMsgCustomFields["Stages"]["DSI_Next_Stage"] = "3"; }
                    setFormStatus(FCR_CONSTANT.pendingbyDesigner);

                    $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

                    var controller = $scope.oriMsgCustomFields['Response_by_the_Designer']['Designer_Name'];
                    var approverVal = controller.split('|')[2].trim().split(' ')[0];

                    //set distribution
                    var strdate = calculateDistDate(3);
                    setAutoDistribution(approverVal, "2#", strdate, 1);
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;

                }
                var controller = $scope.oriMsgCustomFields['FLO_Controller']['FCR_Name'];
                var approverVal = controller.split('|')[2].trim().split(' ')[0];
                setAutoDistribution(approverVal, "7#", "", 1);
            }

        }
        function setRolewiseUser(strRole) {
            if (ds_Projusers_Role.length) {
                var lstcontractor = commonApi._.filter(ds_Projusers_Role, function (val) {
                    if (val.Value.split('|')[0].trim() == strRole) {
                        return val.Value;
                    }
                });

                var objroleuser = [];
                for (var i = 0; i < lstcontractor.length; i++) {
                    objroleuser.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }

                if (strRole) {
                    switch (strRole) {
                        case FCR_CONSTANT.tideway:
                            $scope.objTideway = angular.copy(objroleuser);
                            break;
                        case FCR_CONSTANT.catChecker:
                            $scope.objcat = angular.copy(objroleuser);
                            break;
                        case FCR_CONSTANT.floController:
                            $scope.objfcr = angular.copy(objroleuser);
                            break;
                        case FCR_CONSTANT.fcrdesigner:
                            $scope.objDesign = angular.copy(objroleuser);
                            break;
                        case FCR_CONSTANT.twcController:
                            $scope.objtws = angular.copy(objroleuser);
                            break;
                    }
                }
            }
        }
        $scope.allUserRoleChange = function (approverVal, days, roletype) {

            if ($scope.dsiCurrentstage == "1" && roletype == "TWC") {
                allUserRoleChangeSet(approverVal, days)
            }
            if ($scope.dsiCurrentstage == "1A" && roletype == "FLO") {
                allUserRoleChangeSet(approverVal, days)
            }
            if ($scope.dsiCurrentstage == "1a" && roletype == "Tideway") {
                allUserRoleChangeSet(approverVal, days)
            }
            if ($scope.dsiCurrentstage == "4" || $scope.dsiCurrentstage == "7") {
                if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage4_7_Status'] == "Reject" && roletype == "Designer") {
                    allUserRoleChangeSet(approverVal, days)
                }
                if ($scope.oriMsgCustomFields['FLO_Controller']['FCR_Stage4_7_Status'] == "Accept" && roletype == "Tideway") {
                    allUserRoleChangeSet(approverVal, days)
                }
            }
        };
        function allUserRoleChangeSet(approverVal, days) {
            approverVal = approverVal.split('|')[2].trim().split(' ')[0];

            // resetting the node first
            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'] = [];

            //set distribution
            var strdate = calculateDistDate(days);

            setAutoDistribution(approverVal, "2#", strdate, 1);
            $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = strdate;
        }
        var fillFCRGroup = function (value) {
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": "DS_GET_DIST_GROUP_USERS_ROLES",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_GET_DIST_GROUP_USERS_ROLES",
                        "fieldValue": value
                    }]
                }
            };
            $scope.getCallbackData(form).then(function (response) {
                if (response.data) {
                    var ds_get_dist_group_users_roles = angular.fromJson(response.data['DS_GET_DIST_GROUP_USERS_ROLES']).Items.Item;

                    if (ds_get_dist_group_users_roles && ds_get_dist_group_users_roles.length) {
                        for (var i = 0; i < ds_get_dist_group_users_roles.length; i++) {
                            var loopNode = ds_get_dist_group_users_roles[i];
                            if (loopNode.Name) {
                                var strUserId = loopNode.Value1.trim();
                                setAutoDistribution(strUserId, "7#", "", 1);
                            }
                        }

                    }
                }
            });
        };

        function setAutoDistribution(strUser, strAction, strDueDate, iAutodistId) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //set distributr id for ORIview
            $scope.oriMsgFields['DS_AUTODISTRIBUTE'] = "3";

            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy(STATIC_OBJ_DATA.DS_AutoDistribute_Users)
            structDistribution.AutoDist_Id = iAutodistId;
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = strDueDate;

            $scope.oriMsgFields['DS_AutoDistribute_User_Group']['DS_AutoDistribute_Users'].push(structDistribution);
        }
        function calculateDistDate(days) {
            var strDueDate = "";
            if (days) {
                var d = new Date(todayDate);
                d.setDate(d.getDate() + parseInt(days));
                var month = d.getMonth() + 1,
                    day = d.getDate(),
                    strDueDate = d.getFullYear() + '-' +
                        (month < 10 ? '0' : '') + month + '-' +
                        (day < 10 ? '0' : '') + day;
            }
            return strDueDate;
        }
        function setFormStatus(strstatus) {
            var strFormStatusId = getFormStatusId(strstatus);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter          
            if (ds_all_Active_Form_Status && ds_all_Active_Form_Status.length > 0) {
                var statudObj = commonApi._.filter(ds_all_Active_Form_Status, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });
            $scope.expandTextAreaOnLoad();
        };
        $scope.setFormTitle = function () {
            $scope.oriMsgFields['ORI_FORMTITLE'] = $scope.oriMsgCustomFields['FCR_Title'];
            $scope.oriMsgCustomFields['Project'] = $scope.asiteSystemDataReadOnly['_4_Form_Type_Data']['DS_FORMNAME'];
        };
        function checkPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            ds_Incomplete_Actions_bymsg = commonApi._.filter(ds_Incomplete_Actions_bymsg, function (val) {
                return val.Value4 == "Assign Status";
            });
            if (ds_Incomplete_Actions_bymsg) {
                var strUserId = ds_Incomplete_Actions_bymsg[0] && ds_Incomplete_Actions_bymsg[0].Value1;
                if (strUserId) {
                    if (strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }
        //#region formsettings

        //form setting code
        function checkFormSetting() {
            /*====================================================================================================
            // check status is proper set or not
            ======================================================================================================*/
            var HTstatus = [];
            HTstatus.push(array("Deactivated", "Yes"));

            var strstatus = "Closed:Yes$Open:No$Pending by Tideway Engineer:No$Pending by CAT Checker:No$Pending by Designer:No$Pending by Tideway:No$Pending by FLO Controller:No$Pending by FLO Engineer:No";

            //update status string if it is passed in function as param (param name : strstatus)

            if (strstatus != "") {
                if (strstatus.indexOf("$") > -1) {
                    for (var i = 0; i < strstatus.split('$').length; i++) {
                        var strkey = strstatus.split('$')[i].split(':')[0].toString().trim();
                        var strval = strstatus.split('$')[i].split(':')[1].toString().trim();
                        var index = commonApi._.findIndex(HTstatus, { key: strkey });
                        if (index > -1) {
                            HTstatus[strkey] = strval;
                        }
                        else {
                            HTstatus.push(array(strkey, strval));
                        }

                    }
                }
                else if (strstatus.indexOf(":") > -1) {
                    var strkey = strstatus.split(':')[0].toString().trim();
                    var strval = strstatus.split(':')[1].toString().trim();
                    var index = commonApi._.findIndex(HTstatus, { key: strkey });
                    if (index > -1) {
                        HTstatus[strkey] = strval;
                    }
                    else {
                        HTstatus.push(array(strkey, strval));
                    }
                }
            }
            var strstatusSettings = checkstatusonload(HTstatus, strstatus);
            if (strstatusSettings != "") {
                var strvalsetting = "";
                for (var i = 0; i < $scope.ds_all_Status_Withcloseout.length; i++) {
                    var splitValue = $scope.ds_all_Status_Withcloseout[i].Value2;
                    if (splitValue != "") {
                        if (splitValue.indexOf("|") > -1) {
                            var strval1 = splitValue.split("|")[1].trim();
                            var strval2 = splitValue.split("|")[2].trim();
                        }
                        var strvalfinal = strval1 + ":" + strval2
                        strvalsetting = strvalsetting.concat(strvalfinal + ",");
                    }
                }

                $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following settings not stated properly";
                $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";

                var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                mainstrcutr.Setting_name = "Form status";
                mainstrcutr.Original_value = strvalsetting;
                mainstrcutr.Expected_value = strstatusSettings.replace("$", ",");
                $scope.oriMsgCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);

                //if formsettings are not matched
                $scope.flagIsformsetting = true;
                var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
            }
            else {
                $scope.flagIsformsetting = false;
            }
            /*====================================================================================================
                        //set and check other formsettings proper match or not
            ======================================================================================================*/

            var HTmain = [
                { key: "No_of_Form_Instances", value: "0" },
                { key: "FormType", value: "Form Type" },
                { key: "Form_Template_Type", value: "HTML AppBuilder" },
                { key: "Response_Type", value: "Combined Response Will have Custom Print View" },
                { key: "Appbuilder_Code", value: "ASI" },
                { key: "Is_Import_Emailin", value: "" },
                { key: "Is_Import_Emailin_Exchange", value: "Not Selected" },
                { key: "Exchange_Type", value: "" },
                { key: "E_catalogue", value: "Not Selected" },
                { key: "Cross_Workspace", value: "No" },
                { key: "Use_controller", value: "No" },
                { key: "Controller_Change_status", value: "No" },
                { key: "Response_allowed", value: "No" },
                { key: "Responder_Collaborate", value: "No" },
                { key: "Response_From", value: "Recipients Only" },
                { key: "Continue_Discussion", value: "No" },
                { key: "Enable_Draft_Responses", value: "No" },
                { key: "Show_Responses", value: "Always" },
                { key: "Allow_Editing_ORI", value: "No" },
                { key: "Is_Import_Editing_ORI", value: "No" },
                { key: "Action_Required", value: "For Information|0" },
                { key: "default_Action_required", value: "" },
                { key: "Distribution_ORI_creation", value: "Mandatory" },
                { key: "Allow_Distribution_after_creation", value: "Yes" },
                { key: "Allow_All", value: "No" },
                { key: "Allow_Originator", value: "Yes" },
                { key: "Allow_Receipients", value: "Yes" },
                { key: "Allow_Roles", value: "No" },
                { key: "Role_Name", value: "" },
                { key: "Allow_Edit_and_Forward", value: "No" },
                { key: "Allow_Attachments", value: "No" },
                { key: "Automatic_publish_to_folder", value: "No" },
                { key: "Allow_Form_Associations", value: "No" },
                { key: "Associations_bypass_Form_security", value: "No" },
                { key: "Allow_Doc_Association", value: "No" },
                { key: "Default_Doc_Association", value: "Static" },
                { key: "Associations_Extend_Document_Issue", value: "No" },
                { key: "Allow_Comment_Associations", value: "No" },
                { key: "Associations_bypass_folder_security", value: "No" },
                { key: "Allow_Attribute_Associations", value: "No" },
                { key: "Allow_View_Associations", value: "No" },
                { key: "Overall_Form_Statuses", value: "No" },
                { key: "status_list", value: "" },
                { key: "Closed_out_status_list", value: "" },
                { key: "Restrict_Status_Change_in_View_Form", value: "No" },
                { key: "Allow_Reopening_Form", value: "Yes" },
                { key: "Originator_can_Change_Status", value: "No" },
                { key: "Is_public", value: "No" },
                { key: "Use_Form_Distribution_Groups", value: "No" },
                { key: "Allow_autocreation_on_status_change", value: "No" },
                { key: "Enable_SpellCheck", value: "Not Selected" },
                { key: "Allow_External_Access", value: "No" },
                { key: "Embed_form_Content_emails", value: "No" },
                { key: "Can_Reply_via_emails", value: "No" },
                { key: "From_Actions_Notification_Email_Subject", value: "" },
                { key: "Is_Offline", value: "No" },
                { key: "Embed_form_Content_in_instant_emails_Type", value: "Setting Off" },
                { key: "Allow_Import_in_Edit_ORIValue", value: "Overwrite" },
                { key: "Allow_Import_in_Edit_ORI", value: "No" },
            ];

            //main string 
            var strmain = "Form_Group_Code:FCRT$" +
                "Appbuilder_Code:TTT-FCRT$" +
                "Allow_Editing_ORI:No$" +
                "Allow_Edit_and_Forward:Yes$" +
                "Action_Required:For Information|0$" +
                "default_Action_required:$" +
                "Distribution_ORI_creation:Optional$" +
                "Allow_Distribution_after_creation:$" +
                "Allow_Attachments:$" +
                "Allow_Form_Associations:$" +
                "Allow_Doc_Association:$" +
                "Allow_Reopening_Form:$" +
                "Allow_Originator:$" +
                "Allow_Attribute_Associations:$" +
                "Restrict_Status_Change_in_View_Form:Yes$" +
                "Allow_Receipients:$" +
                "Allow_External_Access:$" +
                "Use_Form_Distribution_Groups:Yes$" +
                "Overall_Form_Statuses:Yes";

            if (strmain != "") {
                if (strmain.indexOf('$') > -1) {
                    for (var i = 0; i < strmain.split('$').length; i++) {
                        var strkey = strmain.split('$')[i].split(':')[0].toString().trim();
                        var strval = strmain.split('$')[i].split(':')[1].toString().trim();
                        var index = commonApi._.findIndex(HTmain, { key: strkey });
                        if (index > -1) {
                            HTmain[index].value = strval;
                        }
                    }
                }
            }
            var strSettings = checkmainstringonload(HTmain);
            if (strSettings != "") {

                $scope.oriMsgCustomFields['DSI_Formsettingmessage'] = "Following settings not stated properly";
                $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1 | Form settings not stated properly";
                var Arrstr = [];
                if (strSettings.indexOf('&') > -1) {
                    Arrstr = strSettings.split('&');
                    for (var i = 0; i < Arrstr.length; i++) {
                        var item = Arrstr[i].split(':');
                        var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                        mainstrcutr.Setting_name = item[0];
                        mainstrcutr.Original_value = item[2];
                        mainstrcutr.Expected_value = item[1];
                        $scope.oriMsgCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                    }
                }
                else if (strSettings.indexOf(':') > -1) {
                    Arrstr = strSettings.split(':');
                    var mainstrcutr = angular.copy(STATIC_OBJ_DATA.DSI_Formsetting);
                    mainstrcutr.Setting_name = Arrstr[0];
                    mainstrcutr.Original_value = Arrstr[2];
                    mainstrcutr.Expected_value = Arrstr[1];
                    $scope.oriMsgCustomFields['DSI_Formsettings']['DSI_Formsetting'].push(mainstrcutr);
                }
                //if formsettings are not matched
                $scope.flagIsformsetting = true;
                var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
                $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
                $scope.update();
                return;
            }
            else {
                $scope.flagIsformsetting = false;
            }
        }
        function array(key, value) {
            return { key: key, value: value };
        }
        function checkmainstringonload(HTmain) {
            var sb = "";
            if ($scope.ds_Asi_Get_All_Default_FormSettingDetails != null) {
                var temp = $scope.ds_Asi_Get_All_Default_FormSettingDetails[0];
                for (var i = 1; i < 60; i++) {
                    var splitValue = [];
                    splitValue = temp["Value" + i.toString()];
                    if (splitValue.indexOf(':') > -1) {
                        var key = splitValue.split(':')[0].trim();
                        var value = splitValue.split(':')[1].trim();

                        var ind = commonApi._.findIndex(HTmain, { key: key });
                        if (ind > -1) {
                            if (HTmain[ind].value.trim() != "") {
                                if (HTmain[ind].value.trim().indexOf(value.trim()) == -1) {
                                    if (sb == "") {
                                        var result = splitValue.split(':')[0].trim() + ":" + HTmain[ind].value + ":" + splitValue.split(':')[1];
                                        sb = result;
                                    }
                                    else {
                                        var result1 = splitValue.split(':')[0].trim() + ":" + HTmain[ind].value + ":" + splitValue.split(':')[1];
                                        sb = sb.concat("&" + result1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return sb;
        };
        function checkstatusonload(HTstatus, strstatus) {
            var sb = "";
            var HTstatusSp = [];

            //Check status of Form settings
            if ($scope.ds_all_Status_Withcloseout != null) {

                if (strstatus.trim() != "") {
                    for (var i = 0; i < $scope.ds_all_Status_Withcloseout.length; i++) {
                        var splitValue = $scope.ds_all_Status_Withcloseout[i].Value2;
                        if (splitValue.indexOf("|") > -1) {
                            var key = splitValue.split('|')[1].trim();
                            var strrepstatus = splitValue.split('|')[2].trim();
                            var value = strrepstatus.replace(/\s\s+/g, ' ');

                            HTstatusSp.push(array(key, value));
                        }
                    }
                    if (HTstatus.length) {
                        for (var i = 0; i < HTstatus.length; i++) {
                            var key = HTstatus[i].key.trim();
                            var value = HTstatus[i].value.trim();
                            var ind = commonApi._.findIndex(HTstatusSp, { key: key });
                            if (ind > -1) {
                                if (HTstatusSp[ind].value.trim().indexOf(value.trim()) == -1) {
                                    sb = strstatus;
                                }
                            }
                            else {
                                sb = strstatus;
                            }
                        }
                    }
                }
            }
            return sb;
        };

        //#endregion
        $scope.update();

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 100);

    }
    return FormController;
});
