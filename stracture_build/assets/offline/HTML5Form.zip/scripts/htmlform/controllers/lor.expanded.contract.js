/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/signature'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.requests = {};

        $scope.currentOriTab = 'general-section.html';
        $scope.currentOriSubTab = '';
        $scope.Logo = '/images/htmlform/LOR/lor-ext-logo.png';
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $window.addEventListener('scroll', function() {
            if(window.scrollY) {
                $element.addClass('scroll-top');
                return;
            }
            $element.removeClass('scroll-top');
        });
        
        /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.oriMsgCustomFields.DS_Logo = $scope.Logo;
        $scope.validateBlur = {
            oldEmailValue : ''
        };
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.emailRegExPattern = new RegExp(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/);
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
        $scope.dsProjOrganisations.push({
            Value: "Other",
            Name: "Other"
        });
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        
        if(currentViewName == "ORI_VIEW") {
            $scope.loadConfig(function () {					
                $scope.oriMsgCustomFields.Tabs = angular.copy($scope.data.config.Tabs) || [];
                $scope.oriMsgCustomFields.SubContractGeneral = angular.copy($scope.data.config.SubContractGeneral) || {};
                $scope.oriMsgCustomFields.Clauses = angular.copy($scope.data.config.Clauses) || {};
                $scope.oriMsgCustomFields.Documents = angular.copy($scope.data.config.Documents) || [];
                $scope.oriMsgCustomFields.NewDocumentName = "";
                $scope.oriMsgCustomFields.SubContractorWorksDetail = angular.copy($scope.data.config.SubContractorWorksDetail) || {};
                $timeout(function() {
                    $scope.expandTextAreaOnLoad();
                }, 10);
            });
        }

        var logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1
        });
        if (currentViewName == "ORI_VIEW" && $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] == '' ) 
        {
            setClientLogo();
        }
        function setClientLogo() {
            if (logo && logo.length) {
                $scope.oriMsgCustomFields.DS_Logo = logo[0].Value8;
            }
        }
        $scope.setCurrentSection = function (tabURL) {
            $scope.currentOriTab = tabURL;
            $scope.setCurrentSubTabSelection('');
            $scope.scrollToTop();
            $timeout(function() {
                $scope.expandTextAreaOnLoad();
            }, 10);
        };

        $scope.setCurrentSubTabSelection = function (subTabId) {
            $scope.currentOriSubTab = subTabId || '';
            scrollIntoView(subTabId)
        };

        $scope.scrollToTop = function () {
            window.scrollTo({top: 0, behavior: 'smooth'});
        };

        $scope.addNewHoliday = function (listToImport) { 
            if($scope.oriMsgCustomFields.SubContractorWorksDetail.NewHoliday.trim()) {
                $scope.addRepeatingRow(listToImport, {title: $scope.oriMsgCustomFields.SubContractorWorksDetail.NewHoliday.trim()});    
                $scope.oriMsgCustomFields.SubContractorWorksDetail.NewHoliday = "";
            }
        };

        $scope.onAmountChange = function() {
            var totalAmount = 0;
            $scope.oriMsgCustomFields.SubContractorWorksDetail.ContractSum.forEach(function(contract)  {
                var amount = isNaN(parseInt(contract.Amount)) ? 0 : parseInt(contract.Amount);
                totalAmount = totalAmount + amount;
            });

            $scope.oriMsgCustomFields.SubContractorWorksDetail.ContractLumpSumTotal = totalAmount;
        }

        $scope.addNewDocumentInList = function (event, listToImport) { 
            if(event && event.keyCode === 13) {
                event.preventDefault();
            }
            if($scope.oriMsgCustomFields.NewDocumentName.trim()) {
                $scope.addRepeatingRow(listToImport, {Name: $scope.oriMsgCustomFields.NewDocumentName.trim()});    
                $scope.oriMsgCustomFields.NewDocumentName = "";
            }
        };

        $scope.addNewSumItem = function (listToImport) { 
			$scope.addRepeatingRow(listToImport, {
                Desc: "",
                Amount: ""
            });    
        };
        
        $scope.getUserId = function (mailId, objParent,key) {
          
            var fieldValue = mailId;
            $scope.validateBlur.oldEmailValue=mailId;
            if (fieldValue && ValidateEmail(fieldValue)) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_USER_DETAILS_ByEmail",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_USER_DETAILS_ByEmail",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_USER_DETAILS_ByEmail']);
                        strGetDetails = strGetDetails.Items.Item;
                        var strUserID = null;
                        var strOrgId = null;
                        if (strGetDetails[0] && strGetDetails[0].Value) {
                            strOrgId = strGetDetails[0].Value.split('|')[7].trim()
                            strUserID = strGetDetails[0].Value.split('|')[0].trim();
                            if (key=='consultant') {
                                objParent.CD_USER_ID = strUserID;
                                objParent.CD_ORG_ID = strOrgId;
                            } else if (key=='subContractor') {
                                objParent.SD_USER_ID = strUserID;
                                objParent.SD_ORG_ID = strOrgId;
                            } else if (key=='client') {
                                objParent.CNSD_USER_ID = strUserID;
                                objParent.CNSD_ORG_ID = strOrgId;
                            }
                        }
                        else
                        {
                            alert("User not exist on Asite Platform")
                            resetVal(objParent,key);
                        }
                    }
                }, function (error) {
                    console.log(error);
                });
            }
            else{
                resetVal(objParent,key);
            }
        }
        function resetVal(objParent,key)
        {
            if (key=='consultant') {
                objParent.CD_EmailAddress='';
                objParent.CD_USER_ID = 0;
                objParent.CD_ORG_ID = 0;
            } else if (key=='subContractor') {
                objParent.SD_EmailAddress='';
                objParent.SD_USER_ID = 0;
                objParent.SD_ORG_ID = 0;
            } else if (key=='client') {
                objParent.CNSD_EmailAddress='';
                objParent.CNSD_USER_ID = 0;
                objParent.CNSD_ORG_ID = 0;
            }
        }
        
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

      
        $window.subcontractAgreementFinalCallBack = function () {
            // remove config data not needed.
            delete $scope.data.config;
            $scope.asiteSystemDataReadWrite.DS_USER_ROLE_ASSIGNMENT_FLAG = true;
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_USERREF = $scope.oriMsgCustomFields.SubContractGeneral.ContractOrder;
            $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.ORI_FORMTITLE = $scope.oriMsgCustomFields.SubContractGeneral.ContractOrder;
            return false;
        };

        $window.draftSubmitCallBack = function () { 
            // remove config data not needed.
            delete $scope.data.config;
        }

        function ValidateEmail(inputText) 
        {
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if(inputText){
            if(inputText.match(mailformat))
            {
                return true;
            }else{
                alert("Invalid Email address")
                return false;}}
            else{return false;}
        }
        function scrollIntoView(elementId) {
            var ele = elementId && document.getElementById(elementId);
            ele && ele.scrollIntoView({behavior: "smooth", block: "start"});
        }
        $scope.update();
    }
    
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof subcontractAgreementFinalCallBack !== "undefined") {
        return subcontractAgreementFinalCallBack();
    }
}


function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}