define(['angular', './base', '../components/folder.selection', '../components/item.selection'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $rootScope, $element, commonApi, $controller, $window, $timeout, myConfig, api, lang, Notification) {


		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});

		var currentViewName = $window.currentViewName;
		var ctrl = this;
		var orgId = '';
		var email = '';
		$scope.cancelButtonName='Cancel';
		var sendObj = {};
		var dcId = 0;
		var tmpUserProfile = null;
		var FORMS_STATES = {
			supplier: "Supplier on Board",
			openInvite: "Open Invitation"
		}
		var FIELD_LOOKUP_ARRAY = ['entityType', 'businessType'];
		var hashedFormId = myConfig.formId;
		var hashedProjectId = myConfig.projectId;
		var hformTypeId = myConfig.formTypeId;
		hformTypeId = hformTypeId && hformTypeId.split('$$')[0];


		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}
		var defaultDate=function calculateDefaultDate(){
			var days = 7;
			var date = new Date();
			var last = new Date(date.getTime() + (days * 24 * 60 * 60 * 1000));
			return last;
		}
		$scope.invitationRoleName = '';
		$scope.companyName = undefined;
		$scope.clickSave = false;
		$scope.disableButton = false;
		$scope.subject = undefined;
		$scope.isAcceptReject = false;
		$scope.senderLogoURL = '';
		$scope.isStatus = false;
		$scope.isSenderLogoURL = true;
		$scope.statusValue = '';
		$scope.weightageId = '';
		$scope.isSameOrg = false;
		$scope.formsStates = angular.copy(FORMS_STATES);
		$scope.filedLookup = {};
		$scope.rawFiledLookup = {};
		$scope.marketPlaceServiceURL=top.marketPlaceServiceURL;
		$scope.noteMsg = "Note: Prequalification required is set to No, as there is already an ongoing process."
		ctrl.$onInit = function () {
			//Setting Deafult date on RespondBy date field.
			$rootScope.$broadcast("setResponseByDate",{date:commonApi.formatDate(myConfig.userDateFormat,defaultDate())});
			$scope.data = $scope.getFormData();
			
			$scope.oriMsgCustomFields = $scope.data['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields'];
			if (currentViewName === 'ORI_VIEW') {
				getUserPrivileges();
				setClientLogo();
				$scope.dsMktWtgDetails = $scope.getValueOfOnLoadData('DS_MKT_WTG_DETAILS');
				for (var i = 0; i < $scope.dsMktWtgDetails.length; i++) {
					$scope.dsMktWtgDetails[i]['ValueTemp'] = $scope.dsMktWtgDetails[i]['Value2'] + ($scope.dsMktWtgDetails[i]['Value3'] ? '-' + $scope.dsMktWtgDetails[i]['Value3'] : '');

				}
				$scope.dsMktWtgList = commonApi.getItemSelectionList({
					arrayObject: $scope.dsMktWtgDetails,
					groupNameKey: "",
					modelKey: "Value2",
					displayKey: "ValueTemp"
				});
				$scope.oriMsgCustomFields.orignatorOrgId = USP.orgID;
				getFieldLookupData();

				$scope.getServerTime(function (serverDate) {
					$scope.oriMsgCustomFields['formCreateDate'] = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
				});
			}

			if (currentViewName == "ORI_PRINT_VIEW") {
				if ((myConfig.aSessionID && myConfig.aSessionID != 'null') || (typeof $window.USP != 'undefined' && $window.USP && $window.USP.aSessionId && $window.USP.aSessionId != 'null')) {
					if (typeof $window.USP != 'undefined' && $scope.oriMsgCustomFields.orignatorOrgId == $window.USP.orgID) {
						$scope.isSameOrg = true;
					} else {
						$scope.getUOPData();
					}
				} else {
					$scope.isAcceptReject = true;
				}
				var dsMktWtgUrlDTLS = $scope.getValueOfOnLoadData('DS_MKT_WTG_URL_DTLS');
				$scope.weightageURL = dsMktWtgUrlDTLS[0] && dsMktWtgUrlDTLS[0].URL2;
				var currentFormStatus =angular.element("input[name =DS_FORMSTATUS]").val();
				if(currentFormStatus != $scope.data.cancel && myConfig.aSessionID!='null'){
					api.getFormSpecificPermission({
							formTypeIds: myConfig.formTypeId,
							paramProjectIds: myConfig.projectId
						}, function (data) {
							$scope.hadFormEditRight = api.hasAccess(data.privileges, 'PRIV_FORM_PROJECT_PRIV_CREATE');
						});
				}
				
			}
			$scope.update();
		
		}
		$scope.cancelOpenInvite = function (hadFormEditRight) {
			$scope.disableButton = true;
			if(hadFormEditRight){
				$scope.cancelButtonName='Cancel...';
			}
			var resourceURL =$scope.oriMsgCustomFields.DS_FORM_PUBLIC_URL.toString();
			  var UUID=resourceURL.split("/")[resourceURL.split("/").length-1];
			var projectIDOrg=myConfig.projectId.substr(0,myConfig.projectId.lastIndexOf("$$")); 
			var apiData={
				projectId: projectIDOrg,
				formId: hashedFormId,
				formTypeId: myConfig.formTypeId,
				evaluationStatus: "Rejected",
				prequalType:8,
                referenceResourceId:UUID
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/resetPreqaulProcess",
				method: 'post',
				withCredentials: true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
				data:apiData
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					$scope.hasFormEditRight=false;
					if (response.data) {
						alert('Open Invitation Cancelled Successfully')
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.location = top.marketPlaceServiceURL+"?origin=true";
					} else {
						alert('The operation failed to excute')
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
							window.location = top.marketPlaceServiceURL+"?origin=true";
						
					}
				}
			}, function () {
				$scope.cancelButtonName='Cancel';
				$scope.disableButton = false;
			});
		}
		$scope.showTooltip = function (event) {
			if (event.currentTarget && event.currentTarget.title) {
				$window.alert(event.currentTarget.title);
			}
		}

		$scope.setFieldValue = function (fldValue, fldStr) {
			var fldMap = {};
			var tempArray = angular.copy($scope.rawFiledLookup[fldStr]);
			if (tempArray.length) {
				switch (fldStr) {
					case FIELD_LOOKUP_ARRAY[0]:
						fldMap = {
							setStr: 'entityType',
							matchStr: 'entity_type_id',
							getStr: 'entity_type_name'
						}
						break;
					case FIELD_LOOKUP_ARRAY[1]:
						fldMap = {
							setStr: 'businessType',
							matchStr: 'business_type_id',
							getStr: 'business_type_name'
						}
						break;
				};

				if (!fldValue) {
					$scope.oriMsgCustomFields.Signup_Detail[fldMap.setStr] = fldValue;
				} else {
					for (var i = 0; i < tempArray.length; i++) {
						var element = tempArray[i];
						if (element[fldMap.matchStr] === fldValue) {
							$scope.oriMsgCustomFields.Signup_Detail[fldMap.setStr] = element[fldMap.getStr];
							if (element.dcId) {
								dcId = element.dcId
							}
							break;
						}
					}
				}
			}
		}

		$scope.getUOPData = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/user/userdetails",
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				if (response.data) {
					tmpUserProfile = response.data
					checkVendorRelation();
				}
			}, function (error) {
				$window.alert(error);
			});
		}

		function checkVendorRelation(data) {
			var vendorData = data;
			var url = top.marketPlaceServiceURL + "/marketplace/prequal/isOngoingPrequal?buyerOrgId=" + $scope.oriMsgCustomFields.orignatorOrgId;

			if(vendorData)
			url = top.marketPlaceServiceURL + "/marketplace/prequal/isOngoingPrequal?buyerOrgId=" + $scope.oriMsgCustomFields.orignatorOrgId +"&vendorOrgId="+vendorData.entity;

			commonApi.ajax({
				url: url,
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				if (!response.data) {
					$scope.isAcceptReject = true;
				}
				else{
					if(vendorData){
						angular.element("#no").trigger("click");
						$scope.showPrequalError = true;
						$scope.showQuestionnaire = false;
						$scope.data.isPrequalEnable = false;
						$scope.isPrequalEnable = 'No';
						$scope.update();
					}
				}
				$scope.showMsg(vendorData)
			}, function (error) {
				if(error.status == 412){
					Notification.error({
						title: 'Alert',
						message: 'Access Denied.'
					});
					return;
				}
				$window.alert("Error" + error.statusText);
			});
		}

		function getFieldLookupData() {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/uop/fieldLookupData/" + FIELD_LOOKUP_ARRAY.join(','),
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey,
				}
			}).then(function (response) {
				if (response.status === 200) {
					for (var i = 0; i < FIELD_LOOKUP_ARRAY.length; i++) {
						var fieldName = FIELD_LOOKUP_ARRAY[i];
						setItemDropdownData(fieldName, response.data[fieldName])
					}
				}
			}, function (error) {
				$window.alert('Error\n\n' + error.statusText);
			});

		}
		function getUserPrivileges() {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/user/getUserProjectPrivileges?userId='+myConfig.USP.userID,
				method: 'GET',
				withCredentials:true,
			  headers: {
					'ApiKey': top.marketPlaceApiKey,
				  	'Content-Type': 'application/json'
				},
			}).then(function (response) {
				if (response && response.data && response.data.privileges) {					
					if(response.data.privileges.indexOf('171') != -1){
						$scope.canAddasTradingPartner = true;
					}
					else{
						$scope.showQuestionnaire = true;
						$scope.isPrequalEnable = 'Yes';
						$scope.data.isPrequalEnable = true;
					}
				}
				}, function (error) {
					$window.alert('Privilege Check Fail');
			});
		}

		function setItemDropdownData(fieldName, resData) {
			var fldParam = {};
			switch (fieldName) {
				case FIELD_LOOKUP_ARRAY[0]:
					fldParam = {
						arrayObject: resData,
						groupNameKey: "",
						modelKey: "entity_type_id",
						displayKey: "entity_type_name"
					}
					break;
				case FIELD_LOOKUP_ARRAY[2]:
					fldParam = {
						arrayObject: resData,
						groupNameKey: "",
						modelKey: "business_type_id",
						displayKey: "business_type_name"
					}
					break;
			}
			$scope.filedLookup[fieldName] = commonApi.getItemSelectionList(fldParam);
			$scope.rawFiledLookup[fieldName] = angular.copy(resData);
		}

		$scope.setFormId = function (weightageId) {
			$scope.data['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = weightageId;
			for (var index = 0; index < $scope.dsMktWtgDetails.length; index++) {
				var element = $scope.dsMktWtgDetails[index];
				if (element.Value2 === weightageId) {
					$scope.oriMsgCustomFields.weightageFormId = element.Value4;
				}
			}
		}

		$scope.showForm = function (fType) {
			if (fType === 1) {
				$scope.oriMsgCustomFields.formState = FORMS_STATES.supplier;
				document.getElementById('btnSaveDraft').style.display = 'none'
			} else {
				$scope.oriMsgCustomFields.formState = FORMS_STATES.openInvite;
			}
		}

		$scope.closePreQualificationFormModal = function (e) {
			var obj = { 'message': 'closeModal' };
			window.top.postMessage(JSON.stringify(obj), "*");
			window.close();
			if ($scope.companyName == '') {
				$window.top.postMessage("closeCreateFormIframe:-1",'*')
			}
		}

		$scope.copyPublicLink = function () {
			$timeout(function () {
				$element.find('#publicLink').select();
				$element.find('#publicLinkBtn').click();
			});
		}

		$scope.isCopiedClass = false;
		$scope.onCopySuccess = function (e) {
			$scope.isCopiedClass = true;
			$timeout(function () {
				$scope.isCopiedClass = false;
				$scope.isCopyOpen = false;
			}, 1000);
		};

		$scope.onCopyError = function (e) {
			if (myConfig.applicationId === 2)
				return;

			api.copyToClipboard(e, e.text);
			$scope.isCopyOpen = false;
		};

		$scope.acceptReject = function (isAccept) {
			if (myConfig.aSessionID == 'null') {
				if ($scope.$parent && $scope.$parent.$parent && $scope.$parent.$parent.loginMarketplace) {
					$scope.$parent.$parent.loginMarketplace()
				} else {
					$window.alert("You need to login first to submit prequal");
				}
				return;
			}

			$scope.disableButton = true;
			if (isAccept) {
				$(".accept").text("Accept...");
			} else {
				$(".reject").text("Reject...")
			}

			var statusName = $scope.data.accept;
			if (!isAccept) {
				statusName = $scope.data.reject;
			}
			var paramData = {
				hashedFormId: hashedFormId,
				hashedProjectId: hashedProjectId,
				isAccept: isAccept,
				formTypeId: hformTypeId,
				settingTypeId: 1,
				statusName: statusName,
				weightageId: $scope.oriMsgCustomFields.weightageFormId,
				orgId: $scope.oriMsgCustomFields.orignatorOrgId,
				userRef: tmpUserProfile.tpdOrgName,
				formFields: [
					{
						"formFieldName": "recipient",
						"value": tmpUserProfile.email
					},
					{
						"formFieldName": "comment",
						"value":$scope.data.comment
					},
					{
						"formFieldName": "ORI_FORMTITLE",
						"value": $scope.oriMsgCustomFields.ORI_FORMTITLE
					},
					{
						"formFieldName": "subject",
						"value": $scope.oriMsgCustomFields.ORI_FORMTITLE
					},
					{
						"formFieldName": "message",
						"value": $scope.oriMsgCustomFields.Description
					},
					{
						"formFieldName": "companyName",
						"value": tmpUserProfile.tpdOrgName
					},
					{
						"formFieldName": "vendorOrgId",
						"value": tmpUserProfile.tpdOrgID
					},
					{
						"formFieldName": "buyerOrgId",
						"value": $scope.oriMsgCustomFields.orignatorOrgId
					},
					{
						"formFieldName": "Invitation_Role_Name",
						"value": "Invited Vendor"
					},
					{
						"formFieldName": "Project_Accept_Role",
						"value": "Vendor"
					},
					{
						"formFieldName": "Role_Assignment_Email",
						"value": tmpUserProfile.email
					},
					{
						"formFieldName": "accept",
						"value": "Pending"
					},
					{
						"formFieldName": "reject",
						"value": "Rejected"
					},
					{
						"formFieldName": "weightageId",
						"value": $scope.oriMsgCustomFields.weightageId
					},
					{
						"formFieldName": "weightageFormId",
						"value": $scope.oriMsgCustomFields.weightageFormId
					},
					{
						"formFieldName": "DS_FORMCONTENT1",
						"value": $scope.oriMsgCustomFields.weightageId
					},
					{
						"formFieldName": "DS_FORMCONTENT",
						"value": ""
					},
					{
						"formFieldName": "DS_FORMCONTENT2",
						"value": hashedFormId && hashedFormId.split('$$')[0]
					},
					{
						"formFieldName": "isViaOpenInvitation",
						"value": "true"
					},
					{
						"formFieldName": "isOpenInvitationAccept",
						"value": isAccept ? "true" : "false"
					},
					{
						"formFieldName": "Distribution",
						"valueObjects": [
							{
								"formFieldName": "Auto_Distribute_Users",
								"value": 3
							},
							{
								"formFieldName": "DS_PROJDISTUSERS",
								"value": tmpUserProfile.tpdUserID
							},
							{
								"formFieldName": "DS_FORMACTIONS",
								"value": "7#For Information"
							},
							{
								"formFieldName": "DS_ACTIONDUEDATE",
								"value": ""
							}
						]
					},
					{
						"formFieldName": "DS_AUTODISTRIBUTE",
						"value": 3
					}
				]
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/processPublicInvitation",
				method: 'post',
				withCredentials: true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
				data: paramData
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					if (response.data.prequalLink) {
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.location = response.data.prequalLink;
					} else {
						alert(response.data.linkStatus);
						if (window.top && window.top.opener) {
							window.top.opener.postMessage(JSON.stringify(sendObj), "*");
							window.close();
						} else {
							window.location = top.marketPlaceServiceURL+"?origin=true";
						}
					}
				}
			}, function (error) {
				var errorMsg = (error.data && error.data.errorCode) ? error.data.errorCode + '\n\n' + error.data.errorMessage : 'Error \n\n Please contact Asite Support for any further assistance';
				$window.alert(errorMsg);
				$scope.clickApprove = false;
				$scope.disableButton = false;
				//alert("Error In Evalution Submit");
			});
		}

		function disabledSaveBtn(visibleMode) {
			$("#btnSaveForm, #btnCancelForm ").prop("disabled", visibleMode);
		}

		function setClientLogo() {
			var DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			var logo = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
				return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1
			});
			if (logo && logo.length) {
				$scope.oriMsgCustomFields.DS_Logo = logo[0].Value8;
			}
		}
		$scope.toggleQuestionnaire = function (val){
			if (val == 'Yes') { 
				$scope.showQuestionnaire = true;
				$scope.data.isPrequalEnable = true;
				$scope.isPrequalEnable = 'Yes';
				
			} else {
				$scope.showQuestionnaire = false;
				$scope.data.isPrequalEnable = false;
				$scope.isPrequalEnable = 'No';
			}
		}
		function saveSupplierOnBoardData() {
			$scope.oriMsgCustomFields.Signup_Detail.countryId = 0;
			var jsonObj = {
				myFields: angular.copy($scope.data)
			}
			var paramData = {
				jsonData: angular.toJson(jsonObj),
				userRef: $scope.oriMsgCustomFields.Signup_Detail.companyName,
				isPrequalEnable: $scope.data.isPrequalEnable,
				formFields: [
					{
						"formFieldName": "recipient",
						"value": $scope.oriMsgCustomFields.Signup_Detail.email
					},
					{
						"formFieldName": "comment",
						"value": ""
					},
					{
						"formFieldName": "ORI_FORMTITLE",
						"value": $scope.oriMsgCustomFields.ORI_FORMTITLE
					},
					{
						"formFieldName": "subject",
						"value": $scope.oriMsgCustomFields.ORI_FORMTITLE
					},
					{
						"formFieldName": "message",
						"value": $scope.oriMsgCustomFields.Description
					},
					{
						"formFieldName": "companyName",
						"value": $scope.oriMsgCustomFields.Signup_Detail.companyName
					},
					{
						"formFieldName": "buyerOrgId",
						"value": $scope.oriMsgCustomFields.orignatorOrgId
					},
					{
						"formFieldName": "Invitation_Role_Name",
						"value": "Invited Vendor"
					},
					{
						"formFieldName": "Project_Accept_Role",
						"value": "Vendor"
					},
					{
						"formFieldName": "Role_Assignment_Email",
						"value": $scope.oriMsgCustomFields.Signup_Detail.email
					},
					{
						"formFieldName": "accept",
						"value": "Pending"
					},
					{
						"formFieldName": "reject",
						"value": "Rejected"
					},
					{
						"formFieldName": "weightageId",
						"value": $scope.oriMsgCustomFields.weightageId
					},
					{
						"formFieldName": "weightageFormId",
						"value": $scope.oriMsgCustomFields.weightageFormId
					},
					{
						"formFieldName": "DS_FORMCONTENT1",
						"value": $scope.oriMsgCustomFields.weightageId
					},
					{
						"formFieldName": "DS_FORMCONTENT",
						"value": ""
					},
					{
						"formFieldName": "DS_FORMCONTENT2",
						"value": ""
					},
					{
						"formFieldName": "isViaOpenInvitation",
						"value": "false"
					},
					{
						"formFieldName": "isOpenInvitationAccept",
						"value": "false"
					},
					{
						"formFieldName": "Distribution",
						"valueObjects": [
							{
								"formFieldName": "Auto_Distribute_Users",
								"value": 3
							},
							{
								"formFieldName": "DS_FORMACTIONS",
								"value": "7#For Information"
							},
							{
								"formFieldName": "DS_ACTIONDUEDATE",
								"value": ""
							}
						]
					},
					{
						"formFieldName": "DS_AUTODISTRIBUTE",
						"value": 3
					},
					{
						"formFieldName": "vendorOrgName",
						"value": $scope.oriMsgCustomFields.Signup_Detail.companyName
					},
					{
						"formFieldName": "buyerOrgName",
						"value": USP.tpdOrgName
					},
					{
						"formFieldName": "rejectionEmailID",
						"value": USP.email
					}
				],
				buyerEmailId: USP.email,
				hashedProjectId: hashedProjectId,
				settingTypeId: 1,
				weightageId: $scope.oriMsgCustomFields.weightageFormId,
				formTypeId: hformTypeId,
				orgId: $scope.oriMsgCustomFields.orignatorOrgId
			}

			
			
			disabledSaveBtn(true);
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/supplierRegistrationAndSendInvitation",
				method: 'post',
				withCredentials: true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
				data: paramData
			}).then(function (response) {
				if (response.data) {
					if (response.data && response.data.responseCode == 200) {
						$window.top.postMessage("updateSelectedRowDataForm:undefined:true",'*')
						$window.top.postMessage("formSavedSuccessMsg::closeCreateFormIframe:20",'*')
					} else {
						var rdata = response.data.responseData;
						if(typeof rdata === 'string') {
							rdata = angular.fromJson(rdata);
						}
						Notification.warning({
							title: 'Warning',
							message: 'The email you have used is already registered.'
						});
						disabledSaveBtn(false);
					}
				}
			}, function (error) {
				var errorMsg = (error.data && error.data.errorCode) ? error.data.errorCode + '\n\n' + error.data.errorMessage : 'Error \n\n Please contact Asite Support for any further assistance';
				$window.alert(errorMsg);
				disabledSaveBtn(false);
				$scope.clickApprove = false;
				$scope.disableButton = false;
			});
		}
		function validateUser(){
			var paramObj = {
				"companyName": $scope.oriMsgCustomFields.Signup_Detail.companyName,
				"countryId": $scope.oriMsgCustomFields.Signup_Detail.countryId || "1",
				"firstName": $scope.oriMsgCustomFields.Signup_Detail.firstName,
				"lastName": $scope.oriMsgCustomFields.Signup_Detail.lastName,
				"email": $scope.oriMsgCustomFields.Signup_Detail.email,
				"defaultRegionId": "01",
				"locale": USP.languageId
			};
			
			commonApi.ajax({
				url: window.baseUrl + "/commonapi/v2/marketplace/validateOnboardSignup",
				method: 'post',
				withCredentials: true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
				data: paramObj
			}).then(function (response) {
				if (response.data) {
					afterSuccess(response.data);
				}
			}, function (error) {
				$window.alert("Oops signup Error!");
			});
		}
		$scope.showMsg = function(data){
			$scope.showUserStatus = false;
			$scope.showOkBtn = false;
			$scope.emailRegistered = false;
			if(data.message){
				if(data.message == "Company already exists in platform and the user will be created for the Marketplace"){
					$scope.oriMsgCustomFields.Signup_Detail.signUpType = 4;
					$scope.showUserStatus = false;
					saveSupplierOnBoardData();
				}
				else if(data.message == "User already exists in platform and the company will be created for the Marketplace"){
					$scope.oriMsgCustomFields.Signup_Detail.signUpType = 5;
					commonApi.ajax({
						url: top.marketPlaceServiceURL + '/marketplace/user/getUserDetailByEmailId',
						data:"emailId="+$scope.oriMsgCustomFields.Signup_Detail.email,
						method: 'post',
						withCredentials: true,
						headers: {
							'ApiKey': top.marketPlaceApiKey,
							'Content-Type': 'application/x-www-form-urlencoded'
						},
					}).then(function (response) {
						if (response.data) {
							$scope.userStatusMsg = "User already exists in platform and the company will be created for the Marketplace";
							$scope.showUserStatus = true;
							$scope.showOkBtn = false;
						}
					}, function (error) {
						$window.alert("Error fetching user details!");
					});
				}
				else if(data.message == "User and the company already exists in the Marketplace.Please re-enter the user details"){
					$scope.oriMsgCustomFields.Signup_Detail.firstName = "";
					$scope.oriMsgCustomFields.Signup_Detail.lastName = "";
					$scope.oriMsgCustomFields.Signup_Detail.email = "";
					$scope.oriMsgCustomFields.Signup_Detail.companyName = "";
					$scope.oriMsgCustomFields.Signup_Detail.signUpType = 6;
					$scope.userStatusMsg = data.message;
					$scope.showUserStatus = true;
					$scope.showOkBtn = true;
				}
				else{
					if(data.message == 'The email you have used is already registered. <a href="${0}">Click here to Login</a>.'){
						$scope.emailRegistered = false;
						$scope.userStatusMsg = 'The email you have used is already registered for another organisation.'
					}
					else if(data.message == "vendor-register-with-another-org"){
						$scope.userStatusMsg = "This user is already registered to another company - "+$scope.oriMsgCustomFields.Signup_Detail.companyName+". If this is the company that you're trying to create, please go back an update the name so that it matches. If you believe that this user has been registered to a different company incorrectly, please contact your Asite Administrator to have this resolved."
					}
					else{
						$scope.userStatusMsg = data.message;
					}
					$scope.showUserStatus = true;
					$scope.showOkBtn = true;
				}
			}
			else{
				$scope.oriMsgCustomFields.Signup_Detail.signUpType = 3;
				saveSupplierOnBoardData();
			}
		}
		function afterSuccess(data){
			$scope.showPrequalError = false;
			$scope.oriMsgCustomFields.Signup_Detail.existingSupplierOrgId = '';
			if(data.entity){
				$scope.oriMsgCustomFields.Signup_Detail.existingSupplierOrgId = data.entity;
				checkVendorRelation(data);
			}
			else{
				delete $scope.oriMsgCustomFields.Signup_Detail.existingSupplierOrgId;
				$scope.showMsg(data);
			}
		}
		$scope.save = function(){
			$scope.disablePopupButtons = true;
			saveSupplierOnBoardData();
		}
		$scope.cancel = function(){
			$scope.showUserStatus = false;
			$scope.showPrequalError=false;
		}
		// function getDcUrl(dcId) {
		// 	var dcObj = {
		// 		dcMapSuffix: {},
		// 		caMapSuffix: {},
		// 		dcRegEx: undefined
		// 	};
		// 	var USER_DC_JSON = [{
		// 		"id": 1,
		// 		"suffix": "ak"
		// 	},
		// 	{
		// 		"id": 2,
		// 		"suffix": "b"
		// 	},
		// 	{
		// 		"id": 3,
		// 		"suffix": "d"
		// 	}]
		// 	var cdnUrl = top.marketPlaceServiceURL;

		// 	for (var i = 0; i < USER_DC_JSON.length; i++) {
		// 		dcObj.dcMapSuffix[USER_DC_JSON[i].id] = USER_DC_JSON[i].suffix
		// 	}

		// 	var str = "\\.|";
		// 	for (var i = 0; i < USER_DC_JSON.length; i++) {
		// 		if (i == USER_DC_JSON.length - 1) {
		// 			str += USER_DC_JSON[i].suffix + "\\."
		// 		} else {
		// 			str += USER_DC_JSON[i].suffix + "\\.|"
		// 		}
		// 	}
		// 	dcObj.dcRegEx = new RegExp(str, 'i');

		// 	if (!dcId) {
		// 		return "";
		// 	}
		// 	var dcSuffix = dcObj.dcMapSuffix[dcId];

		// 	var finalPath = cdnUrl || window['baseUrl'];
		// 	var splitPath = finalPath.split(".");
		// 	splitPath[0] += ".";
		// 	splitPath[0] = splitPath[0].replace(dcObj.dcRegEx, "") + dcSuffix;
		// 	return splitPath.join(".");
		// }

		$window.openInviteFinalCallBack = function (validate) {
			if ($scope.oriMsgCustomFields.formState === $scope.formsStates.supplier) {
				validateUser();
				return true;
			} else {
				return false;
			}
		}
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

	if (typeof openInviteFinalCallBack !== "undefined") {
		return openInviteFinalCallBack();
	}
}