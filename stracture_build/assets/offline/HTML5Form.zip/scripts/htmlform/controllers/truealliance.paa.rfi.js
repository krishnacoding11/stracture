/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement && event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
				!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
				!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function ($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
			taOptions.toolbar = [
				['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
				['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
				[]
			];
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function (color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
				taRegisterTool("fontColor", {
					display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
					action: function (color) {
						var me = this;
						if (this.$editor().wrapSelection) {
							return this.$editor().wrapSelection("foreColor", color)
						}
					},
					options: {
						replacerClassName: "fa fa-font",
						showButtons: !1,
						showAlpha: !1
					},
					color: "#000"
				}),
				taRegisterTool('fontName', {
					display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>" + "</button>",
					action: function (event, font) {
						//Ask if event is really an event.					
						if (!!event.stopPropagation) {
							//With this, you stop the event of textAngular.
							event.stopPropagation();
							//Then click in the body to close the dropdown.
							angular.element("body").trigger("click");
						}
						angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
						this.$element.toggleClass('open-fonts-list');
						return this.$editor().wrapSelection('fontName', font);
					},
					disabled: function () { },
					options: [
						{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
						{ name: 'Serif', css: "'times new roman', serif" },
						{ name: 'Wide', css: "'arial black', sans-serif" },
						{ name: 'Narrow', css: "'arial narrow', sans-serif" },
						{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
						{ name: 'Courier New', css: "'courier new', monospace" },
						{ name: 'Garamond', css: 'garamond, serif' },
						{ name: 'Georgia', css: 'georgia, serif' },
						{ name: 'Tahoma', css: 'tahoma, sans-serif' },
						{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
						{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
						{ name: 'Verdana', css: 'verdana, sans-serif' },
						{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
					]
				}),
				taRegisterTool('fontSize', {
					display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",
					action: function (event, size) {
						//Ask if event is really an event.					
						if (!!event.stopPropagation) {
							//With this, you stop the event of textAngular.
							event.stopPropagation();
							//Then click in the body to close the dropdown.
							angular.element("body").trigger("click");
						}
						angular.element('.open-fonts-list').removeClass('open-fonts-list');
						this.$element.toggleClass('open-fonts-size-list');
						return this.$editor().wrapSelection('fontSize', parseInt(size));
					},
					disabled: function () { },
					options: [
						{ name: 'xx-small', css: 'xx-small', value: 1 },
						{ name: 'x-small', css: 'x-small', value: 2 },
						{ name: 'small', css: 'small', value: 3 },
						{ name: 'medium', css: 'medium', value: 4 },
						{ name: 'large', css: 'large', value: 5 },
						{ name: 'x-large', css: 'x-large', value: 6 },
						{ name: 'xx-large', css: 'xx-large', value: 7 }

					]
				}),
				taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'), taOptions;
		}
		]);
	};

	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
	mainModule.config(function ($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
	});

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
 
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});

		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		$scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.todayDateDbFormat;
        });
		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadwrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];
		$scope.dSDraft = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'];
		var dsWorkingUser = $scope.Asite_System_Data_Read_Only._1_User_Data.DS_WORKINGUSER;
		var dSDraftRESMsg = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
		var DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS');
		var DS_PAA_MPC_CLAUSEEVENTDETAILS = $scope.getValueOfOnLoadData('DS_PAA_MPC_CLAUSEEVENTDETAILS');
		var DS_PAA_MPC_SETUP_SECTIONS = $scope.getValueOfOnLoadData('DS_PAA_MPC_SETUP_SECTIONS');
		var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
		$scope.curStage = $scope.oriMsgCustomFields.curStage;
		$scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
		$scope.DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
		$scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
		$scope.isDataLoaded = true;
		var dsWorkingUserId = $scope.getWorkingUserId();
		$scope.dropdownObj = {
			contractNoList: [],
			distSectionsList: [],
			engineerlist: [],
			communicationList: [],
			clausesList: [],
			forInfoUserslist: []
		};

		var TCHQ_CONSTANT = {
			RESPOND_ACTION: '3#Respond',
			INFO_ACTION: '7#For Information',
			oriDistNumb: 3,
            resDistNumb: 13,
		};
		var STATIC_OBJ_DATA = {
            All_Responses: {
                DSI_ResID: "",
                Response_Remarks: "",
                Response_Creator: "",
                Response_Date: "",
                DSI_ResFlag: "",
                resAction: "",
                Selected_Status: "",
            }
        };

		$scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
		$scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;

		if (currentViewName == "ORI_VIEW") {

			if ($scope.dSFormId && $scope.dSDraft == "NO") {
				$scope.oriMsgCustomFields.Can_Forward = "";
				$scope.hideSaveDraftButton();
			}
			if ($scope.dSFormId) {
                checkUserCanupdateDraft();
            }
			var contractData = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_EMP_CONTRACT');
			$scope.dropdownObj.contractNoList = commonApi.getItemSelectionList({
				arrayObject: contractData,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});
			$scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
		}
		if (currentViewName == "RES_VIEW") {
			checkUserCanRespond();
			$scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "";
			if (dSDraftRESMsg == "NO") {
                var strResCount = $scope.resMsgCustomFields.DSI_Res_Counter
                  , insertPoint = $scope.resMsgCustomFields.RESPONSES.All_Responses;
                if (insertPoint.length) {
                    for (var i = 0; i < insertPoint.length; i++) {
                        if (insertPoint[i].Response_Remarks) {
                            insertPoint[i].DSI_ResFlag = "Old"
                        }
                    }
                }
                $scope.getServerTime(function(serverDate) {
                    strResCount++;
                    var resNodes = angular.copy(STATIC_OBJ_DATA.All_Responses);
                    resNodes.DSI_ResID = strResCount;
                    resNodes.Response_Creator = dsWorkingUser;
                    resNodes.Response_Date = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
                    insertPoint.push(resNodes);
                })
            } else {
                var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function(val) {
                    return val.DSI_ResFlag != "Old"
                });
                if (responseObj.length) {
                    responseObj[0].Response_Creator = dsWorkingUser
                }
            }
		}
		if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
			if ($scope.dSFormId) {
				fillDropwdowns();
			}
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_SEND_MSG = "0";
			if ($scope.oriMsgCustomFields.Can_Forward) {
				var chkPermission = strIsUserDraftOnly();
				if (chkPermission.toLowerCase() == "yes") {
					setSendPermission("Draft");
				} else {
					setSendPermission("Send");
				}
			}
		}
		if(currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW'){
			$timeout(function () {
				$scope.hideExportBtn();
			}, 100);
			for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
				if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
					$scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
					break;
				}
			} 
		}

		$scope.isOriginator = $scope.oriMsgCustomFields.Originator_Id == dsWorkingUserId;

		$scope.onContractchange = function (conVal) {
			if (conVal) {
				$scope.isDataLoaded = false;
				var strParam = conVal.split('|')[0].trim();
				var tempConAppCode = conVal.split('|')[0].trim();
				var strAppcode = $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
				var tempCon = conVal.split('|');

				$scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
				$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
				$scope.oriMsgCustomFields.Contractor_Logo = tempCon[2].trim();
				var spParam = {
					dataSourceArray: [
						{
							"fieldName": "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_KEY_DATES_SUMMARY",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_SETUP_SECTIONS",
							"fieldValue": tempConAppCode + ',' + strAppcode
						}, {
							"fieldName": "DS_PAA_MPC_NEC_ASITE_DM_USED",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_NEC_BESPOKE",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_NEC_REASONCODE",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_NEC_FUNDINGTYPE",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
							"fieldValue": tempConAppCode
						}, {
							"fieldName": "DS_PAA_MPC_CLAUSEEVENTDETAILS",
							"fieldValue": tempConAppCode
						}, {
                            "fieldName": "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": tempConAppCode
                        }
					],
					successCallback: contractChangeCallback
				};
				$scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
					return obj.fieldName;
				});
				$scope.getCallbackSPdata(spParam);

				var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[11].trim();;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam; 
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.oriMsgCustomFields.Client_Logo = arrStr[3].trim();
                $scope.oriMsgCustomFields.Contractor_Logo = arrStr[2].trim();
				$scope.oriMsgCustomFields.SectionCBSCode = arrStr[11].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
				$scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();
				
                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
			}
		}

		function contractChangeCallback(responseList) {
			$scope.isDataLoaded = true;
			if (responseList["DS_PAA_MPC_SETUP_SECTIONS"]) {
				DS_PAA_MPC_SETUP_SECTIONS = responseList["DS_PAA_MPC_SETUP_SECTIONS"];
			}

			if (responseList["DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS"]) {
				DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS = responseList["DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS"];
			}

			if (responseList["DS_PAA_MPC_CLAUSEEVENTDETAILS"]) {
				DS_PAA_MPC_CLAUSEEVENTDETAILS = responseList["DS_PAA_MPC_CLAUSEEVENTDETAILS"];
			}
			if (responseList.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES) {
				setReplyDays(responseList);
				setRespondDate();
			}
			
			fillDropwdowns();
			if ($scope.dSFormId) {
                checkUserCanupdateDraft();
            }
			$scope.Asite_System_Data_Read_Only._5_Form_Data.DS_SEND_MSG = "0";
			if ($scope.oriMsgCustomFields.Can_Forward) {
				var chkPermission = strIsUserDraftOnly();
				if (chkPermission.toLowerCase() == "yes") {
					setSendPermission("Draft");
				} else {
					setSendPermission("Send");
				}
			}	
		}

		/**
         * setRespondDate is used to auto populate Respond Date 
         * * @param response: is used for fill this dropdown after contract callback
         * */
        function setRespondDate(){
            var todayDateDbFormat = $scope.todayDateDbFormat;
            
			if(todayDateDbFormat){
                var spParam = {
                    dataSourceArray: [{
                        fieldName: "DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY",
                        fieldValue: todayDateDbFormat + '|' + '' + '|' + $scope.oriMsgCustomFields.Reply_Days
                    }],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY.length){
                            $scope.oriMsgCustomFields.RespondDate = $scope.formatDate(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY[0].Value2, "yy-mm-dd", "dd/mm/yy");
                        }
                    }
                };
                $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                    return obj.fieldName
                });
                $scope.getCallbackSPdata(spParam)
			}
		}

		function setReplyDays(responseList){
			var dateResponse = responseList.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES;
            if (dateResponse && dateResponse.length) {
                var selectedData = commonApi._.filter(dateResponse, function (obj) {
                    return obj.Value3.toLowerCase() == "reply period for contract communications";
				})[0];
				$scope.oriMsgCustomFields.Reply_Days = selectedData ? selectedData.Value4 : '2';
			}
		}

		function strIsUserDraftOnly() {
			if (DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length) {
				var strValue = "",
					strRole = "",
					strTmpEmpId = "";
				for (var i = 0; i < DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
					strValue = DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
					strRole = strValue[1].trim();
					if (strRole.toLowerCase() == "alliance_technical_lead") {
						strTmpEmpId = strValue[2].split('#')[0].trim();
						if (strTmpEmpId == currentUserid)
							return "Yes";
					}
				}
			}
			return "No";
		}

		function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft" || !$scope.oriMsgCustomFields.Can_Reply) {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit. Draft form to be distributed using (add distribute icon) for internal review/approval prior to sending.";
            }
            $scope.Asite_System_Data_Read_Only._5_Form_Data.DS_SEND_MSG = strMsg;
        }
		function checkUserCanupdateDraft(){
            var isrequired = CheckPendingAction(dsWorkingUserId);
            var strCanReplay = "YES",
            strCanReplayStatus = "0",
            strReviewDraft = filterdata("Review Draft");
            $scope.oriMsgCustomFields.Can_Forward = "No";
            var objData = commonApi._.filter(DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function(val) {
                return val.Value.split("|")[2].split("#")[0].trim() == currentUserid;
			});
            if (!objData.length) {
                strCanReplay = "";
                strCanReplayStatus = "1";
            }
            if($scope.dSDraft == "YES"  && isrequired && !strReviewDraft && !$scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "No";
            } else if($scope.dSDraft == "YES" && !strReviewDraft && $scope.editDraft){
                $scope.oriMsgCustomFields.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.oriMsgCustomFields.Can_Reply = strCanReplay;
            $scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
		}
        function CheckPendingAction(strUser) {
            //check user have any pending action of not
            var IsAction = false;
            $scope.editDraft = "";
            var strNodes = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == "Review Draft";
            });
            if (strNodes) {
                var strUserId = "",
                    strCheckRespond = "";
                for (var i = 0; i < strNodes.length; i++) {
                    $scope.editDraft = "Yes";
                    strUserId = strNodes[i].Value1;
                    strCheckRespond = strNodes[i].Value4;
                    if (strCheckRespond == "Review Draft" && strUserId && strUserId == strUser.trim()) {
                        return true;
                    }
                }
            }
            return IsAction;
        }
		
		function checkUserCanRespond() {
			var strCanReplay = "YES",
				strCanReplayStatus = "0",
				strRespond = filterdata("Respond");
				
			if (!strRespond && currentViewName == "RES_VIEW") {
				strCanReplay = "";
				strCanReplayStatus = "2";
			}

			if (!strCanReplay) {
				$scope.hideSaveDraftButton();
			}
			$scope.oriMsgCustomFields.Can_Reply = strCanReplay;
			$scope.oriMsgCustomFields.Can_Reply_Status = strCanReplayStatus;
		}

		function filterdata(strAction) {
			var strFlag = "";
			var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
				return val.Name == strAction;
			});
			if (actionObj.length) {
				if (actionObj[0].Value.indexOf("|" + currentUserid + "|") > -1) {
					strFlag = "1";
				}
			}
			return strFlag;
		}

		function setWorkflow(actionmsgId, days, selectedStatus) {
			var onlyforInfo;
			if(selectedStatus && selectedStatus.split('#')[1] && selectedStatus.split('#')[1].toLowerCase().trim() == 'closed'){
				onlyforInfo = true;
			}
			$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var tempList = [];
			var allUsers = $scope.oriMsgFields.DS_PROJUSERS_ALL_ROLES,
				strAction = onlyforInfo ? TCHQ_CONSTANT.INFO_ACTION : TCHQ_CONSTANT.RESPOND_ACTION;
			if (allUsers) {
				tempList.push({
					strUser: allUsers.split('|')[2].trim(),
					strAction: strAction,
					strDate: $scope.oriMsgCustomFields.RespondDate
				});

				var infoUsers = $scope.oriMsgCustomFields.Dist_Group_Users;
				if (infoUsers.length) {
					for (var j = 0; j < infoUsers.length; j++) {
						tempList.push({
							strUser: infoUsers[j].split('|')[2].trim(),
							strAction: TCHQ_CONSTANT.INFO_ACTION,
							strDate: ""
						});
					}
				}
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
					DS_AUTODISTRIBUTE: actionmsgId || TCHQ_CONSTANT.oriDistNumb
				});
				$scope.oriMsgCustomFields.curStage = "2";
			}
		}

		function fillDropwdowns() {
			var currUserObj = commonApi._.filter(DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
				return val.Value.split('|')[2].split('#')[0].trim() == currentUserid;
			});

			if (currUserObj.length) {
				var currUserRole = currUserObj[0].Value.split('|')[1].trim();
				if(currUserRole.indexOf('Alliance') == -1){
					currUserRole = 'owner';
				}else{
					currUserRole = 'alliance';
				}
				$scope.oriMsgCustomFields.Filter_Role = currUserRole;
				if (currentViewName == 'ORI_VIEW') {
					$scope.oriMsgCustomFields.Ori_Filter_Role = currUserRole;
				}
			}

			$scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
				arrayObject: DS_PAA_MPC_SETUP_SECTIONS,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			var uniqMemberList = commonApi._.uniq(DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS,function(obj){return obj.Name});
			$scope.dropdownObj.engineerlist = commonApi.getItemSelectionList({
				arrayObject: uniqMemberList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			$scope.dropdownObj.forInfoUserslist = commonApi.getItemSelectionList({
				arrayObject: uniqMemberList,
				groupNameKey: "",
				modelKey: "Value",
				displayKey: "Name"
			});

			DS_PAA_MPC_CLAUSEEVENTDETAILS = commonApi._.filter(DS_PAA_MPC_CLAUSEEVENTDETAILS, function (obj) {
                obj.NewValue = obj.Value4 + " | " + obj.Value6;
                return obj.Value5.indexOf('C. Communications') > -1
            });
            DS_PAA_MPC_CLAUSEEVENTDETAILS = DS_PAA_MPC_CLAUSEEVENTDETAILS.sort(function(a,b){
                return a.Value3 && b.Value3 && Number(a.Value3.split('.')[0]) - Number(b.Value3.split('.')[0])
            });

			if (DS_PAA_MPC_CLAUSEEVENTDETAILS.length) {
				$scope.dropdownObj.clausesList = commonApi.getItemSelectionList({
					arrayObject: DS_PAA_MPC_CLAUSEEVENTDETAILS, modelKey: 'NewValue', displayKey: 'NewValue'
				})
			}
		}
		var isCallForDraft = false;
		$scope.update();

		function formSubmitCallBack(isDraftCall) {
			$scope.Asite_System_Data_Read_Only._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = $scope.oriMsgCustomFields.RespondDate;
			if (currentViewName == "ORI_VIEW") {
				if (!$scope.oriMsgCustomFields.Can_Forward) {
					alert("You are not authorised to edit this Draft message. Please click on cancel button to exit.");
					return true;
				}
				if (!$scope.oriMsgCustomFields.Can_Reply && !isCallForDraft) {
					alert("You are not authorised to Create this form. Please Contact your Workspace Administrator.");
					return true;
				}
				setWorkflow('', $scope.oriMsgCustomFields['Reply_Days']);
			}else if (currentViewName == "RES_VIEW") {
				if ($scope.oriMsgCustomFields.Can_Reply_Status == '2') {
					alert("You currently do not have 'Respond' action and therefore you can not reply on the form.");
					return true;
				}

				if ($scope.oriMsgCustomFields.Can_Reply_Status == '1') {
					alert("You are not authorised to respond to this form. You therefore cannot send a response, please click the cancel button at the bottom of the form.");
					return true;
				}

				var resObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function(obj){
					return obj.DSI_ResFlag != 'Old'; 
				})[0];

				if(resObj && !isDraftCall){
					$scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
					var userId;
					if($scope.curStage == '1'){
						if(resObj.Selected_Status){
							$scope.Asite_System_Data_Read_Only._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = resObj.Selected_Status;
						}
						// response workflow for originator
						setWorkflow(TCHQ_CONSTANT.resDistNumb, $scope.oriMsgCustomFields['Reply_Days'], resObj.Selected_Status);
						$scope.oriMsgCustomFields.curStage = '2';
					}else{
						userId = $scope.oriMsgCustomFields.Originator_Id;
						$scope.oriMsgCustomFields.curStage = '1';
						if(userId){
							commonApi.setDistributionNode({
								actionNodeList: [{
									strUser: userId,
									strAction: TCHQ_CONSTANT.RESPOND_ACTION,
									strDate: $scope.oriMsgCustomFields.RespondDate
								}],
								autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
								asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
								DS_AUTODISTRIBUTE: TCHQ_CONSTANT.resDistNumb
							});
						}
					}
				}
			}
			return false;
		};

		$window.oriformSubmitCallBack = function () {
			return formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {
			isCallForDraft = true;
			formSubmitCallBack(true);
		}
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}