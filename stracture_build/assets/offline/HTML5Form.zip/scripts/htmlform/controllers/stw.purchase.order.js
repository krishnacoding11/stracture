define(['angular', './base', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = $window.currentViewName;        
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.purchaseOrder = $scope.oriMsgCustomFields.purchaseOrder;
        $scope.poListingGroup = $scope.oriMsgCustomFields.poListingGroup;
        $scope.updatedPoListingGroup = $scope.oriMsgCustomFields.updatedPoListingGroup;
        $scope.oriMsgCustomFields.data_selections = $scope.oriMsgCustomFields.data_selections || 'Yes';

		$scope.xhr = {
			isXHRon : false			
		}

		$scope.filterFieldObj = {
            wbsElement : '',
            poNumber : '',
            poName : '',
            contractorName : '',
            poStatus : '',
            poDesc : '',
            poCategoryCode : '',
            netValue : ''
		};

        var STATIC_OBJ_DATA = {            
            Pages: {
                Page_Range: ""
            },
            purchaseOrderObj : {
                purchaseOrderGuid : '',
                isPoSelected : '',
                isPoShow: true,
                isPoDisable: false,
                isFieldDisable: false,
                wbsElement : '',
                poNumber : '',
                poName : '',
                contractorName : '',
                poStatus : '',
                poDesc : '',
                poCategoryCode : '',
                netValue : '',
                pendingValue:''
            }
        },
        onloadBackUp = {
            projCodeList: []
        },
        guidRowObj = {},
        classApp = angular.module('classApp', []),
        isOriView = (currentViewName == "ORI_VIEW"),
        isOriPrintView = (currentViewName == "ORI_PRINT_VIEW");

        classApp.controller('classCtrl', function ($scope) {
            $scope.isActive = false;
            $scope.activeButton = function () {
                $scope.isActive = !$scope.isActive;
            }
        });

        var putRecordInUpdation = function(paramObj) {
            var rowObj = {};
            for (var i = 0; i < paramObj.multipleList.length; i++) {
                rowObj = paramObj.parent[paramObj.multipleList[i]];
                guidRowObj[rowObj.mappingGuid] = rowObj;
            }
        };

        $scope.tableUtilSettings = {
            purchaseOrderObj: {
                tooltip: "Select to Edit",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0,
                    deleteSelected: 0,
                    editRow: 0,
                    deactivateRow: 1,
                    reactivateRow: 1
                },
                checkboxModelKey: "isPoSelected",
                disableRowKey: "isPoDisable",
                editRowCallBack: function(rowData) {
                    $scope.openModal('mapping-cost-code', rowData);
                },
                DEACTIVATE_MSG: "Deactivate selected row/rows",
                deactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },
                REACTIVATE_MSG: "Reactivate selected row/rows",
                reactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },                
                newStaticObject: angular.copy(STATIC_OBJ_DATA.purchaseOrderObj),
                deleteCurrRowMsg: "Remove Purchase Order Detail",
                deleteSelectedMsg: "Remove selected Purchase Order Detail"
            },
        };

        var resetFilterFields = function () {
            $scope.filterFieldObj = {
                wbsElement : '',
                poNumber : '',
                poName : '',
                contractorName : '',
                poStatus : '',
                poDesc : '',
                poCategoryCode : '',
                netValue : ''
            };
            $scope.oriMsgCustomFields.data_selections = "Yes";
            $scope.oriMsgCustomFields.Page_Sel = "";
        };

        $scope.resetTrackerFilter = function (event) {
            resetFilterFields();
            $scope.filterTrackerLog(event, true, false);
        };

        var isRowBelongsToFilter = function(rowObj) {
            return ((($scope.oriMsgCustomFields.data_selections == 'Yes' && rowObj.isProjDisable == false) 
            || ($scope.oriMsgCustomFields.data_selections == 'No' && rowObj.isProjDisable == true)) 
            && rowObj.wbsElement.trim().toLowerCase().indexOf($scope.filterFieldObj.wbsElement.trim().toLowerCase()) > -1
            && rowObj.poNumber.trim().toLowerCase().indexOf($scope.filterFieldObj.poNumber.trim().toLowerCase()) > -1
            && rowObj.poName.trim().toLowerCase().indexOf($scope.filterFieldObj.poName.trim().toLowerCase()) > -1
            && rowObj.contractorName.trim().toLowerCase().indexOf($scope.filterFieldObj.contractorName.trim().toLowerCase()) > -1
			&& rowObj.poStatus.trim().toLowerCase().indexOf($scope.filterFieldObj.poStatus.trim().toLowerCase()) > -1
            && rowObj.poDesc.trim().toLowerCase().indexOf($scope.filterFieldObj.poDesc.trim().toLowerCase()) > -1
            && rowObj.poCategoryCode.trim().toLowerCase().indexOf($scope.filterFieldObj.poCategoryCode.trim().toLowerCase()) > -1
            && rowObj.netValue.trim().toLowerCase().indexOf($scope.filterFieldObj.netValue.trim().toLowerCase()) > -1);
        },  getPagingArray = function (totalRecords) {
            var pageSize = parseInt($scope.oriMsgCustomFields.Page_Slice);
            var pageStart = 1;
            var totalItemCount = totalRecords;
            var pageArray = [];

            var currPageIndex = 1;
            var totalPage = Math.ceil(totalItemCount / pageSize);
            var tmpTotalCount = totalItemCount;
            while (currPageIndex <= totalPage) {
                var pageEnd = (pageSize > tmpTotalCount ? tmpTotalCount : pageSize) + pageStart - 1;
                pageArray.push(pageStart + '-' + pageEnd);
                tmpTotalCount = tmpTotalCount - pageSize;
                currPageIndex++;
                pageStart = pageEnd + 1;
            }
            return pageArray;
        },  addNewPageNode =function (pageParam) {
            var tmpTotalCount = pageParam.totalCount,
                nodeKey = pageParam.nodeKey,
                parentNode = pageParam.parentNode,
                pageNode = pageParam.pageNode,
                dropdownModal = pageParam.dropdownModal;

            var pageNumberArray = getPagingArray(tmpTotalCount);

            if (!$scope.oriMsgCustomFields[dropdownModal]) {
                $scope.oriMsgCustomFields[dropdownModal] = pageNumberArray[0];
            }

            for (var index = 0; index < pageNumberArray.length; index++) {
                var pageStr = pageNumberArray[index];
                var newPageNode = angular.copy(STATIC_OBJ_DATA[nodeKey]);
                newPageNode[pageNode] = pageStr;
                $scope.oriMsgCustomFields[parentNode][nodeKey].push(newPageNode);
            }
        },  setPagingData = function () {
            var pageParamObj = {};
            $scope.oriMsgCustomFields.Tabbed_Paging.Pages = [];
            pageParamObj = {
                totalCount: $scope.oriMsgCustomFields.Total_Pages,
                nodeKey: 'Pages',
                parentNode: 'Tabbed_Paging',
                pageNode: 'Page_Range',
                dropdownModal: 'Page_Sel'
            };
            addNewPageNode(pageParamObj);
        };

        $scope.setPagination = function (pageIndex) {
            var temp = angular.copy(onloadBackUp.projCodeList);
            var splittedIndex = pageIndex.split('-'),
                pageSlice = parseInt($scope.oriMsgCustomFields["Page_Slice"]) || 50,
                spliceCount = (parseInt(splittedIndex[0]) + pageSlice > onloadBackUp.projCodeList.length) && !(parseInt(splittedIndex[1]) + pageSlice > onloadBackUp.projCodeList.length) ? ((onloadBackUp.projCodeList.length - 1) - parseInt(splittedIndex[0])) : pageSlice,
                pageRangeList = temp.splice(splittedIndex[0] - 1, spliceCount);
            $scope.poListingGroup.poListing = pageRangeList;
        };

        $scope.filterTrackerLog = function(event, isForReset, isOnload) {
            // if(!isOnload && !$scope.poListingGroup.poListing.length) {
            //     return false
            // }

            var dataSourceInc = "DS_ASI_STD_ECC4_STW_PURCHASE_ORDER",
            tmpTrackerParam = $scope.filterFieldObj.wbsElement + '|' + $scope.filterFieldObj.poNumber + '|' + $scope.filterFieldObj.poName + '|' + $scope.filterFieldObj.contractorName + '|' + $scope.filterFieldObj.poStatus + '|'+ $scope.filterFieldObj.poDesc + '|' + $scope.filterFieldObj.poCategoryCode + '|' + $scope.filterFieldObj.netValue + '|' + $scope.oriMsgCustomFields.data_selections;

            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": tmpTrackerParam
                    }]
                }
            };			

            $scope.xhr.isXHRon = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.xhr.isXHRon = false;
                if (resData) {
                    var lstvalue = angular.fromJson(response.data[dataSourceInc]).Items.Item,rowObj,foundedIndex,
                        isBlankFilter = !$scope.filterFieldObj.wbsElement && !$scope.filterFieldObj.poNumber && !$scope.filterFieldObj.poName && !$scope.filterFieldObj.contractorName && !$scope.filterFieldObj.poStatus && !$scope.filterFieldObj.poDesc && !$scope.filterFieldObj.poCategoryCode && !$scope.filterFieldObj.netValue;
                    $scope.poListingGroup.poListing = [];
                    
                    for (var i = 0; i < lstvalue.length; i++) {
                        $scope.poListingGroup.poListing.push({
                            purchaseOrderGuid : lstvalue[i].Value1,
                            isPoSelected : '',
                            isPoShow: true,
                            isPoDisable: false,
                            isFieldDisable: false,
                            wbsElement : lstvalue[i].Value2,
                            poNumber : lstvalue[i].Value3,
                            poName : lstvalue[i].Value4,
                            contractorName : lstvalue[i].Value5,
                            poStatus : lstvalue[i].Value6,
                            poDesc : lstvalue[i].Value7,
                            poCategoryCode : lstvalue[i].Value8,
                            netValue : parseFloat(lstvalue[i].Value9 || 0),
                            pendingValue : parseFloat(lstvalue[i].Value10 || 0)
                        });                           
                    }

                    // Push updated nodes to the list if changed before filter.                        
                    for (var key in guidRowObj) {
                        // skip loop if the property is from prototype
                        if (!guidRowObj.hasOwnProperty(key)) continue;
                        rowObj = guidRowObj[key];
                        if(isRowBelongsToFilter(rowObj)) {
                            foundedIndex = commonApi._.findIndex($scope.poListingGroup.poListing, {
                                mappingGuid : rowObj.mappingGuid 
                            });
                            if(foundedIndex>-1){
                                $scope.poListingGroup.poListing[foundedIndex] = rowObj;
                            } else if (rowObj) {
                                $scope.poListingGroup.poListing.push(rowObj);
                            }
                        }
                    }
                    isOnload && (onloadBackUp.projCodeList = angular.copy($scope.poListingGroup.poListing));
                    $scope.oriMsgCustomFields.Total_Pages = $scope.poListingGroup.poListing.length;                        
                    ($scope.poListingGroup.poListing.length < 50) ? $scope.oriMsgCustomFields.Page_Sel = '1-'+$scope.poListingGroup.poListing.length : $scope.oriMsgCustomFields.Page_Sel = '1-50';
                    setPagingData(); 
                    if(isForReset || (!isForReset && $scope.poListingGroup.poListing.length > 50 && isBlankFilter)) {
                        $scope.setPagination($scope.oriMsgCustomFields.Page_Sel);
                    }                    
                }
            }, function (error) {
                $scope.xhr.isXHRon = false;                
                var errorMsg = 'Error retriving DocumentData<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
            });
        };

        $scope.applyFilterCall = function (event) {
            if(event.which != 13) {
                return false;
            }
            $scope.filterTrackerLog(event, false, false);
        };

        if (isOriView) {
            $scope.getServerTime(function (serverDate) {
                $scope.strTime = new Date(serverDate).getTime();
                $scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
            });            
        } else if (isOriPrintView) {
            $scope.poListingGroup.poListing = [];        
            resetFilterFields();
            // set data on load.
            $scope.filterTrackerLog(event, false, true);
        }
        
        var setUpdatedDataNodes = function () {
            var rowObj = {};
            // reset the update nodes first.
            $scope.updatedPoListingGroup.updatedPoListing = [];
            for (var key in guidRowObj) {
                // skip loop if the property is from prototype
                if (!guidRowObj.hasOwnProperty(key)) continue;
                rowObj = guidRowObj[key] || {};
                if (!angular.equals({}, rowObj)) {
                    $scope.updatedPoListingGroup.updatedPoListing.push({
                        updatedPurchaseOrderGuid: rowObj.purchaseOrderGuid,
                        isUpdatedPoSelected: rowObj.isPoSelected,
                        isUpdatedPoShow: rowObj.isPoShow,
                        isUpdatedPoDisable: rowObj.isPoDisable,
                        isUpdatedFieldDisable: rowObj.isFieldDisable,
                        updatedWbsElement: rowObj.wbsElement,
                        updatedPoNumber: rowObj.poNumber,
                        updatedPoName: rowObj.poName,
                        updatedContractorName: rowObj.contractorName,
                        updatedPoStatus: rowObj.poStatus,
                        updatedPoDesc: rowObj.poDesc,
                        updatedPoCategoryCode: rowObj.poCategoryCode,
                        updatedNetValue : rowObj.netValue                        
                    });
                    
                }
            }
        };

        $window.projControlSubmit = function () {
            $scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.oriMsgCustomFields.ORI_USERREF;
            setUpdatedDataNodes();
            return false;
        };

        $scope.update();
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof projControlSubmit !== "undefined") {
        return projControlSubmit();
    }
}