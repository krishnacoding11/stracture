/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/inlineattachment', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout,Notification) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var currServerDate = '';
        $scope.getServerTime(function (serverDate) {
            currServerDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        var RESTRICT_CHAR_MSG = "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #";

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.requests = {};

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        var projectRole = ["Project Manager", "Site Manager/Foreman", "Contracts Administrator","Design Manager","Design Coordinator","Business Development Manager"];
        var STATIC_OBJ_DATA = {
            Project_Team: {
                PM_isSelected: false,
                PM_isDeleted : false,
                Project_Role:"",
				Project_Name:"",
				Project_Mobile:"",
				Project_Phone:"",
                Project_Email:"",
                Project_Lic_NO:"",
				PM_isNew:true
            },
            Client_Details: {
                CLCD_isSelected: false,
				CLCD_isDeleted: false,				
				Client_Contact:"",
				Client_Mobile:"",
				Client_Phone:"",
				Client_Email:"",
				Client_Role:"",
				isNew:true
            },
            Consultants_Details: {
                CD_isSelected: false,
                CD_isDeleted : false,
                CD_Discipline: "",
                CD_CSA_Number: "",
                CD_Company: "",
                CD_Contact: "",
                CD_Phone_Number: "",
                CD_EmailAddress: "",
                CD_USER_ID: "",
                CD_ORG_ID: "",
                CD_Lic_NO:"",
                isNew:true
            },
            Subcontractor_Details: {
                SD_isSelected: false,
                SD_isDeleted : false,
                SD_Trade: "",
                SD_Order_Number: "",
                SD_Cost_Code: "",
                SD_Company: "",
                SD_Contact: "",
                SD_Phone_Number: "",
                SD_EmailAddress: "",
                SD_USER_ID: "",
                SD_ORG_ID: "",
                SD_Lic_NO:"",
                isNew:true
            },
            Suppliers_Details: {
                SU_isSelected: false,
                SU_isDeleted : false,
                SU_Trade: "",
                SU_Order_Number: "",
                SU_Cost_Code: "",
                SU_Company: "",
                SU_Contact: "",
                SU_Phone_Number: "",
                SU_EmailAddress: "",
                SU_USER_ID: "",
                SU_ORG_ID: "",
                SU_Lic_NO:"",
                isNew:true
            },
            Client_Nominated_SubContractor_Details: {
                CNSD_isSelected: false,
                CNSD_isDeleted : false,
                CNSD_Trade: "",
                CNSD_Order_Number: "",
                CNSD_Cost_Code: "",
                CNSD_Company: "",
                CNSD_Contact: "",
                CNSD_Phone_Number: "",
                CNSD_EmailAddress: "",
                CNSD_USER_ID: "",
                CNSD_ORG_ID: "",
                isNew:true
            }
        }

        $scope.tableUtilSettings = {
            Project_Team: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0
                },
                checkboxModelKey: "PM_isSelected",
                disableRowKey: "PM_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.PM_isSelected = false);
                    });
                   
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Project_Team),
                ADD_NEW_BEFORE_TIP: "Insert before Project Team Detail",
                ADD_NEW_AFTER_TIP: "Insert after Project Team  Detail",
                deleteAllRowTooltip: "Remove all Project Team  Detail",
                deleteCurrRowMsg: "Remove Project Team  Detail",
                deleteSelectedMsg: "Remove selected Project Team  Detail"
            },
            Client_Contractor: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0,
                    deactivateRow: 0,
                    deleteSelected:1
                },
                disableRowKey: "CLCD_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.CLCD_isSelected = false);
                    });
                   
                },
                checkboxModelKey: "CLCD_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Client_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Client Contractor Detail",
                ADD_NEW_AFTER_TIP: "Insert after Client Contractor  Detail",
                deleteAllRowTooltip: "Remove all Client Contractor  Detail",
                deleteCurrRowMsg: "Remove Client Contractor  Detail",
                deleteSelectedMsg: "Remove selected Client Contractor  Detail"
            },
            Consultants_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0,
                    deactivateRow: 0,
                    deleteSelected:1
                    
                },
                checkboxModelKey: "CD_isSelected",
                disableRowKey: "CD_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.CD_isSelected = false);
                    });
                   
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Consultants_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Consultants Detail",
                ADD_NEW_AFTER_TIP: "Insert after Consultants Detail",
                deleteAllRowTooltip: "Remove all Consultants Detail",
                deleteCurrRowMsg: "Remove Consultants Detail",
                deleteSelectedMsg: "Remove selected Consultants Detail"
            },
            Subcontractor_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0,
                    deactivateRow: 0,
                    deleteSelected:1
                    
                },
                checkboxModelKey: "SD_isSelected",
                disableRowKey: "SD_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.SD_isSelected = false);
                    });
                   
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Subcontractor_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Subcontractor Record",
                ADD_NEW_AFTER_TIP: "Insert after Subcontractor Record",
                deleteAllRowTooltip: "Remove all Subcontractor Records",
                deleteCurrRowMsg: "Remove Subcontractor Record",
                deleteSelectedMsg: "Remove selected Subcontractor Record"
            },
            Suppliers_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0,
                    deactivateRow: 0,
                    deleteSelected:1
                },
                checkboxModelKey: "SU_isSelected",
                disableRowKey: "SU_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.SU_isSelected = false);
                    });
                   
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Suppliers_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Supplier Record",
                ADD_NEW_AFTER_TIP: "Insert after Supplier Record",
                deleteAllRowTooltip: "Remove all Supplier Records",
                deleteCurrRowMsg: "Remove Supplier Record",
                deleteSelectedMsg: "Remove selected Supplier Record"
            },
            Client_Nominated_SubContractor_Details: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "CNSD_isSelected",
                hideControlIcon: {
                    editRow: 0,
                    deleteAllRow:0,
                    deactivateRow: 0,
                    deleteSelected:1
                },
                checkboxModelKey: "CNSD_isSelected",
                disableRowKey: "CNSD_isDeleted",
                deactivateRowCallBack: function (paramObj) {
                    var xpniNoNodes = commonApi._.filter(paramObj.parent, function(o) {
                        return (o.CNSD_isSelected = false);
                    });
                   
                },
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Client_Nominated_SubContractor_Details),
                ADD_NEW_BEFORE_TIP: "Insert before Employee Detail",
                ADD_NEW_AFTER_TIP: "Insert after Employee Detail",
                deleteAllRowTooltip: "Remove all Employee Detail",
                deleteCurrRowMsg: "Remove Employee Detail",
                deleteSelectedMsg: "Remove selected Employee Detail"
            }
        }


        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.validateBlur = {
            oldEmailValue : ''
        };
        $scope.Client_Contractor = $scope.oriMsgCustomFields["Client_Details"]["Client_Contractor"];
        $scope.Project_Details = $scope.oriMsgCustomFields["Project_Team"];
        $scope.ConsultantsDetails = $scope.oriMsgCustomFields["Consultants_Details"];
        $scope.SubContractorDetails = $scope.oriMsgCustomFields["Subcontractor_Details"];
        $scope.SuppliersDetails = $scope.oriMsgCustomFields["Suppliers_Details"];
        $scope.Client_Nominated_SubContractor_Details = $scope.oriMsgCustomFields["Client_Nominated_SubContractor_Details"];
        $scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.getUserRoledetails= $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        
        $scope.emailRegExPattern = new RegExp(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/);
        $scope.dsProjOrganisations = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
        $scope.dsProjOrganisations.push({
            Value: "Other",
            Name: "Other"
        });
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
            return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1
        });
        if (currentViewName == "ORI_VIEW" && $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] != '' && $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT == 'NO') 
        {
            if ($scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT_EDITORI == 'NO') {
                setEditOriData();
            }
        }
        if (currentViewName == "ORI_VIEW" && $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMID'] == '' ) 
        {
            setClientLogo();
        }
        function setClientLogo() {
            if (logo && logo.length) {
                $scope.oriMsgCustomFields.DS_Logo = logo[0].Value8;
            }
        }
        function setEditOriData(){
             for (var i = 0; i < $scope.Project_Details.length; i++) {
                $scope.Project_Details[i].PM_isSelected=false;
            }
            for (var i = 0; i < $scope.Client_Contractor.length; i++) {
                $scope.Client_Contractor[i].CLCD_isSelected=false;
            }
            for (var i = 0; i < $scope.ConsultantsDetails.length; i++) {
                $scope.ConsultantsDetails[i].CD_isSelected=false;
                $scope.ConsultantsDetails[i].CD_USER_ID =0;
                $scope.ConsultantsDetails[i].CD_ORG_ID = 0;
            }
            for (var i = 0; i < $scope.SubContractorDetails.length; i++) {
                $scope.SubContractorDetails[i].SD_isSelected==false;
                $scope.SubContractorDetails[i].SD_USER_ID =0;
                $scope.SubContractorDetails[i].SD_ORG_ID = 0;
            }
            for (var i = 0; i < $scope.Client_Nominated_SubContractor_Details.length; i++) {
                $scope.Client_Nominated_SubContractor_Details[i].CNSD_isSelected==false;
                $scope.Client_Nominated_SubContractor_Details[i].CNSD_USER_ID =0;
                $scope.Client_Nominated_SubContractor_Details[i].CNSD_ORG_ID = 0;
            }
            for (var i = 0; i < $scope.SuppliersDetails.length; i++) {
                $scope.SuppliersDetails[i].SU_isSelected==false;
                $scope.SuppliersDetails[i].SU_USER_ID =0;
                $scope.SuppliersDetails[i].SU_ORG_ID = 0;
            }
         
            $scope.tableUtilSettings.Client_Contractor.hideControlIcon.deactivateRow = 1;            
            $scope.tableUtilSettings.Client_Contractor.hideControlIcon.deleteSelected = 0;   
            $scope.tableUtilSettings.Consultants_Details.hideControlIcon.deactivateRow = 1;            
            $scope.tableUtilSettings.Consultants_Details.hideControlIcon.deleteSelected = 0;
            $scope.tableUtilSettings.Subcontractor_Details.hideControlIcon.deactivateRow = 1;            
            $scope.tableUtilSettings.Subcontractor_Details.hideControlIcon.deleteSelected = 0;
            $scope.tableUtilSettings.Client_Nominated_SubContractor_Details.hideControlIcon.deactivateRow = 1;            
            $scope.tableUtilSettings.Client_Nominated_SubContractor_Details.hideControlIcon.deleteSelected = 0;   
            $scope.tableUtilSettings.Suppliers_Details.hideControlIcon.deactivateRow = 1;            
            $scope.tableUtilSettings.Suppliers_Details.hideControlIcon.deleteSelected = 0;            
                      
        }

        var checkDuplicateValue = function (args) {
			var currentTargetName = args.model[args.key] || '',
				allTagretData = args.repetObj,
				isCaseSensitive = args.isCaseSensitive || false,
				isValidFlag = true;

			for (var i = 0; i < allTagretData.length; i++) {
                var ele = allTagretData[i];
                if(ele[args.flagToExclude]) {
                    continue;
                }
				var eleStr = ele[args.key];
				var isMatched = isCaseSensitive ? currentTargetName.toLowerCase() == eleStr.toLowerCase() : currentTargetName == eleStr;
				if (eleStr && i != args.index && isMatched) {
					ADODDLE.alert({ title: "Duplicate " + args.msg + " selected !!!", msg: "Select a different " + args.msg });
					args.model[args.key] = "";
					isValidFlag = false;
					break;
				}
			};
			return isValidFlag;
        };
        
        $scope.checkDuplicateValue = function (args) {
            checkDuplicateValue(args);
        };

        $scope.getUserId = function (mailId, objParent,key) {
          
            var fieldValue = mailId;
            $scope.validateBlur.oldEmailValue=mailId;
            if (fieldValue && ValidateEmail(fieldValue)) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_USER_DETAILS_ByEmail",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_USER_DETAILS_ByEmail",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_USER_DETAILS_ByEmail']);
                        strGetDetails = strGetDetails.Items.Item;
                        var strUserID = null;
                        var strOrgId = null;
                        if (strGetDetails[0] && strGetDetails[0].Value) {
                            strOrgId = strGetDetails[0].Value.split('|')[7].trim()
                            strUserID = strGetDetails[0].Value.split('|')[0].trim();
                            if (key == 'consultant') {
                                objParent.CD_USER_ID = strUserID;
                                objParent.CD_ORG_ID = strOrgId;
                            } else if (key == 'subContractor') {
                                objParent.SD_USER_ID = strUserID;
                                objParent.SD_ORG_ID = strOrgId;
                            }
                            else if (key == 'SuppliersDetails') {
                                objParent.SU_USER_ID = strUserID;
                                objParent.SU_ORG_ID = strOrgId;
                            } else if (key == 'client') {
                                objParent.CNSD_USER_ID = strUserID;
                                objParent.CNSD_ORG_ID = strOrgId;
                            }
                        } else {
                            alert("Asite user account does not exist, please create Asite account first and then re-assign to relevant role.")
                            resetVal(objParent, key);
                        }
                    }
                }, function (error) {
                    window.console && window.console.log(error);
                });
            }
            else{
                resetVal(objParent,key);
            }
        }
        function resetVal(objParent,key)
        {
            if (key=='consultant') {
                objParent.CD_EmailAddress='';
                objParent.CD_USER_ID = 0;
                objParent.CD_ORG_ID = 0;
            } else if (key=='subContractor') {
                objParent.SD_EmailAddress='';
                objParent.SD_USER_ID = 0;
                objParent.SD_ORG_ID = 0;
            } 
            else if (key=='SuppliersDetails') {
                objParent.SU_EmailAddress='';
                objParent.SU_USER_ID = 0;
                objParent.SU_ORG_ID = 0;
            } else if (key=='client') {
                objParent.CNSD_EmailAddress='';
                objParent.CNSD_USER_ID = 0;
                objParent.CNSD_ORG_ID = 0;
            }
        }
        
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }

        $scope.setHideOnDeleteFlag = function(item, nodeKey) {
            item[nodeKey] = !item[nodeKey];
        };
      
        //if item is deleted than make one entry mandatory
        $scope.deleteItem = function (obj, repeatingData) {

            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);

        };

        $scope.deleteRow = function (index, repeatindData) {
            if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
        };

        
        $window.pydUserAssignmentFinalCallBack = function () {
            var strConsultant = "";
            var strSubContractor = "";
            var strClientNominatedSubContractor = "";
            var strMain = "";
                        
            for (var i = 0; i < $scope.Client_Contractor.length; i++) {
                if ($scope.Client_Contractor[i].Client_Email) {
                    $scope.Client_Contractor[i].isNew = false;
                }
            }

            if ($scope.ConsultantsDetails.length) {
                strConsultant = returnUserIdString($scope.ConsultantsDetails, "Consultant");
            }
            if ($scope.SubContractorDetails.length) {
                strSubContractor = returnUserIdString($scope.SubContractorDetails, "SubContractor");
            }
            if ($scope.Client_Nominated_SubContractor_Details.length) {
                strClientNominatedSubContractor = returnUserIdString($scope.Client_Nominated_SubContractor_Details, "Client Nominated SubContractors");
            }
            if (strConsultant || strSubContractor || strClientNominatedSubContractor) {
                strMain = strConsultant + "$$$" + strSubContractor + "$$$" + strClientNominatedSubContractor;
            }
            $scope.asiteSystemDataReadWrite.DS_USER_ROLE_ASSIGNMENT_STRING = strMain;
            $scope.asiteSystemDataReadWrite.DS_USER_ROLE_ASSIGNMENT_FLAG = true;
            console.log(strMain);

            return false;
        };

        $window.checkMandatoryFields =function() {
            var isRetuFlag = false;
            if (currentViewName == "ORI_VIEW") {
                for (var i = 0; i< $scope.oriMsgCustomFields.Project_Team.length; i++) {
                    if($scope.oriMsgCustomFields.Project_Team[i].Email) {
                        isRetuFlag=true;
                        break;
                    }
                }
                for (var i = 0; !isRetuFlag && i< $scope.ConsultantsDetails.length; i++) {
                    if($scope.ConsultantsDetails[i].CD_EmailAddress) {
                        isRetuFlag=true;
                        break;
                    }
                }
                for (var i = 0; !isRetuFlag && i< $scope.SubContractorDetails.length; i++) {
                    if($scope.SubContractorDetails[i].SD_EmailAddress) {
                        isRetuFlag=true;
                        break;
                    }
                }
                for (var i = 0; !isRetuFlag && i< $scope.SuppliersDetails.length; i++) {
                    if($scope.SuppliersDetails[i].SU_EmailAddress) {
                        isRetuFlag=true;
                        break;
                    }
                }
                for (var i = 0; !isRetuFlag && i< $scope.Client_Nominated_SubContractor_Details.length; i++) {
                    if($scope.Client_Nominated_SubContractor_Details[i].CNSD_EmailAddress) {
                        isRetuFlag=true;
                        break;
                    }
                }
               if(!isRetuFlag) {
                    Notification.error({
                        title: 'Alert',
                        message: 'This form contains validation errors. At least one user must be specified.'
                    });
                }
            }            
            return isRetuFlag;
        }
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
        };
        function ValidateEmail(inputText) 
        {
            var mailformat = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
            if(inputText){
            if(inputText.match(mailformat))
            {
                return true;
            }else{
                alert("Invalid Email address")
                return false;}}
            else{return false;}
        }
        function returnUserIdString(tempObj, key) {
            var arrayTmp = [];
            var strUserID = "";
            var strOrgID = "";            
            for (var i = 0; i < tempObj.length; i++) {
                if (key == "Consultant" && tempObj[i].CD_USER_ID && tempObj[i].CD_USER_ID>0) {
                    tempObj[i].isNew=false;
                    strUserID = tempObj[i].CD_USER_ID;
                    strOrgID = tempObj[i].CD_ORG_ID;
                    arrayTmp.push(strUserID+"#"+strOrgID);
                }
                if (key == "SubContractor" && tempObj[i].SD_USER_ID && tempObj[i].SD_USER_ID>0) {
                    tempObj[i].isNew=false;
                    strUserID = tempObj[i].SD_USER_ID;
                    strOrgID = tempObj[i].SD_ORG_ID;
                    arrayTmp.push(strUserID+"#"+strOrgID);
                }
                if (key == "Client Nominated SubContractors" && tempObj[i].CNSD_USER_ID && tempObj[i].CNSD_USER_ID>0) {
                    tempObj[i].isNew=false;
                    strUserID = tempObj[i].CNSD_USER_ID;
                    strOrgID = tempObj[i].CNSD_ORG_ID;
                    arrayTmp.push(strUserID+"#"+strOrgID);
                }
            }
            arrayTmp = arrayTmp.join();
            arrayTmp = key + "|" + arrayTmp;
            return arrayTmp;
        }

        $scope.update();
    }
    
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pydUserAssignmentFinalCallBack !== "undefined") {
        if(checkMandatoryFields()){
            return pydUserAssignmentFinalCallBack();
        }
        else{return true;}
    }
}
