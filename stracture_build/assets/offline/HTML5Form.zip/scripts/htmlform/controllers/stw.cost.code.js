define(['angular', './base', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.showTenderDataTable = false;
        $scope.isDataLoaded = true;
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.GenralGroup = $scope.oriMsgCustomFields["General_Group"];
        $scope.Stw_Cost_Code_Group = $scope.oriMsgCustomFields["Stw_Cost_Code_Group"];
        $scope.updateStwCostCodeGroup = $scope.oriMsgCustomFields["Update_Stw_Cost_Code_Group"];
        $scope.DS_ASI_STD_ECC4_STW_CODE_PAGING = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_STW_CODE_PAGING');
        $scope.DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');

        $scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
        $scope.isEditori = false;
        
        $scope.isXHRon = false;
        $scope.costCodeXhr = false;
        
        $scope.guidXhr = false;
        $scope.disableTenderName = false;
        var modelRowIndex = -1;        
        var STATIC_OBJ_DATA = {
            Stw_Cost_Code: {
                Stw_Cost_Code_isSelected: "",
                Stw_is_disable: false,
                Cost_Code_1: "",
                Cost_Code_1_Dec: "",
                Cost_Code_1_Digi: "",
                Report_Code3: "",
                Report_Code3_Dec: "",
                Report_Code2: "",
                Report_Code1: "",
                Cost_Code2: "",
                Description: "",
                Unit: "",
                Rules_for_Use: "",
                Ground_in_the: "",
                Guid_Stw: "",
                data_selections: "",
                modal_disable: false,
                historyLogString : ""
            },
            Update_Stw_Cost_Code: {
                Update_Stw_Cost_Code_isSelected: "",
                Update_is_disable: false,
                Update_Cost_Code_1: "",
                Update_Cost_Code_1_Dec: "",
                Update_Cost_Code_1_Digi: "",
                Update_Report_Code3: "",
                Update_Report_Code3_Dec: "",
                Update_Report_Code2: "",
                Update_Report_Code1: "",
                Update_Cost_Code2: "",
                Update_Description: "",
                Update_Unit: "",
                Update_Rules_for_Use: "",
                Update_Ground_in_the: "",
                Update_Guid_Stw: "",
                modal_disable: true,
                historyLogString : ""
            },
            Pages: {
                Page_Range: ""
            }
        };
        var onloadBackUp = {
            costCodeList: [],
            onChangingList : []
        },
        guidRowObj = {},
        classApp = angular.module('classApp', []),
        isImported = (($scope.oriMsgCustomFields.isImported || '').trim().toLowerCase() == 'yes');

        classApp.controller('classCtrl', function ($scope) {
            $scope.isActive = false;
            $scope.activeButton = function () {
                $scope.isActive = !$scope.isActive;
            }
        });
        var getGUIdOnCallBack = function (guidLength, callBack) {
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": 'DS_GET_GUID',
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": 'DS_GET_GUID',
                        "fieldValue": guidLength
                    }]
                }
            };
            $scope.guidXhr = $scope.getCallbackData(form).then(function (response) {
                var strGetDetails = []
                if (response.data) {
                    strGetDetails = angular.fromJson(response.data['DS_GET_GUID']).Items.Item;
                }
                callBack(strGetDetails);
                $scope.guidXhr = false;
            }, function (error) {
                var errorMsg = 'Error retriving Guid <br/>' + error;
                Notification.error({
                    title: 'Server Error',
                    message: errorMsg
                });
                $scope.guidXhr = false;
            });
        };

        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Stw_Cost_Code_Group);
        $scope.openModal = function (modalId, rowData) {
            // show modal
            ctrl.model.modelId = modalId;

            $timeout(function () {
                var modalHeader = angular.element('.m-header.shade4');
                modalHeader.addClass('primary-header-bg white-font')
            }, 5);

            modelRowIndex = -1;
            if (rowData) {
                modelRowIndex = rowData.index;
                $scope.form.title = "Edit Cost Code Details";
                $scope.modelData = angular.copy(rowData.row);
                if (currentViewName == "ORI_PRINT_VIEW") {
                    ctrl.model.readOnly = true;
                }
            } else {
                $scope.form.title = "Add Cost Code Details";
                // get single guid on add row
                getGUIdOnCallBack(1, function (guidResp) {
                    if (modalId == 'Stw_Cost_Code') {
                        $scope.modelData = angular.copy(STATIC_OBJ_DATA.Stw_Cost_Code);
                        // set first record guid.
                        $scope.modelData.Guid_Stw = guidResp[0].Value2;
                    }
                });
            }
        }

        function updateRecord() {
            if ($scope.guidXhr || $scope.costCodeXhr) {
                return false;
            }

            $timeout(function () {
                if (!($scope.modelData.Cost_Code_1 && $scope.modelData.Cost_Code_1_Dec && $scope.modelData.Cost_Code_1_Digi && $scope.modelData.Report_Code3 && $scope.modelData.Report_Code3_Dec && $scope.modelData.Report_Code2 && $scope.modelData.Report_Code1 && $scope.modelData.Cost_Code2 && $scope.modelData.Description && $scope.modelData.Unit)) {
                    Notification.warning({
                        title: "Validation",
                        message: 'Please fill mandatory fields.!!'
                    });
                    return false;
                }

                var rowIndex = modelRowIndex,
                    newNode = angular.copy($scope.modelData);
                if(ctrl.model.modelId == 'Stw_Cost_Code'){
                    if (rowIndex > -1) {
                        $scope.Stw_Cost_Code_Group['Stw_Cost_Code'][rowIndex] = newNode;
                    } else {
                        $scope.Stw_Cost_Code_Group['Stw_Cost_Code'].unshift(newNode);
                        onloadBackUp.onChangingList.unshift(newNode);
                    }
                    guidRowObj[newNode.Guid_Stw] = newNode;
                }
                hideModal();

            }, 200);
        }
        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false,
            disableBtn: !$scope.guidXhr
        };

        $scope.deleteItem = function (obj, repeatingData) {
            var index = repeatingData.indexOf(obj);
            repeatingData.splice(index, 1);
        };

        function hideModal() {
            ctrl.model.modelId = '';
        }

        function putRecordInUpdation(paramObj) {
            var rowObj = {};
            for (var i = 0; i < paramObj.multipleList.length; i++) {
                rowObj = paramObj.parent[paramObj.multipleList[i]];
                guidRowObj[rowObj.Guid_Stw] = rowObj;
            }
        }

        $scope.tableUtilSettings = {
            Stw_Cost_Code: {
                tooltip: "Select to Edit",
                hasDefaultRecord: true,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    deleteAllRow: 0,
                    deleteSelected: 0,
                    editRow: 1,
                    deactivateRow: 1,
                    reactivateRow: 1
                },
                checkboxModelKey: "Stw_Cost_Code_isSelected",
                disableRowKey: "Stw_is_disable",
                editRowCallBack: editStw_Cost_CodeModal,
                DEACTIVATE_MSG: "Deactivate selected row/rows",
                deactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },
                REACTIVATE_MSG: "Reactivate selected row/rows",
                reactivateRowCallBack: function (paramObj) {
                    putRecordInUpdation(paramObj);
                },                
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Stw_Cost_Code),
                deleteCurrRowMsg: "Remove Stw_Cost_Code Detail",
                deleteSelectedMsg: "Remove selected Stw_Cost_Code Detail"
            },
        }
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

        };

        function setDefaultRange () {
            if(!$scope.oriMsgCustomFields.Tabbed_Paging.Pages.length || !$scope.oriMsgCustomFields.Tabbed_Paging.Pages[0].Page_Range) {
                $scope.oriMsgCustomFields.Page_Sel = '0-0';            
                $scope.oriMsgCustomFields.Tabbed_Paging.Pages = [{
                    Page_Range : '0-0'
                }];
            }
        };

        function setPagingData() {
            $scope.oriMsgCustomFields['Tabbed_Paging']['Pages'] = [];
            var pageParamObj = {
                totalCount: $scope.oriMsgCustomFields['Total_Pages'],
                nodeKey: 'Pages',
                parentNode: 'Tabbed_Paging',
                pageNode: 'Page_Range',
                dropdownModal: 'Page_Sel'
            };
            addNewPageNode(pageParamObj);
            setDefaultRange();
        }

        function getPagingArray(totalRecords) {
            var pageSize = parseInt($scope.oriMsgCustomFields["Page_Slice"]);
            var pageStart = 1;
            var totalItemCount = totalRecords;
            var pageArray = [];

            var currPageIndex = 1;
            var totalPage = Math.ceil(totalItemCount / pageSize);
            var tmpTotalCount = totalItemCount;
            while (currPageIndex <= totalPage) {
                var pageEnd = (pageSize > tmpTotalCount ? tmpTotalCount : pageSize) + pageStart - 1;
                pageArray.push(pageStart + '-' + pageEnd);
                tmpTotalCount = tmpTotalCount - pageSize;
                currPageIndex++;
                pageStart = pageEnd + 1;
            }
            return pageArray;
        }

        function addNewPageNode(pageParam) {
            var tmpTotalCount = pageParam.totalCount,
                nodeKey = pageParam.nodeKey,
                parentNode = pageParam.parentNode,
                pageNode = pageParam.pageNode,
                dropdownModal = pageParam.dropdownModal;

            var pageNumberArray = getPagingArray(tmpTotalCount);

            if (!$scope.oriMsgCustomFields[dropdownModal]) {
                $scope.oriMsgCustomFields[dropdownModal] = pageNumberArray[0];
            }

            for (var index = 0; index < pageNumberArray.length; index++) {
                var pageStr = pageNumberArray[index];
                var newPageNode = angular.copy(STATIC_OBJ_DATA[nodeKey]);
                newPageNode[pageNode] = pageStr;
                $scope.oriMsgCustomFields[parentNode][nodeKey].push(newPageNode);
            }
        }

        $scope.setPagination = function (pageIndex) {
            var temp = angular.copy(onloadBackUp.onChangingList);            
            var splittedIndex = pageIndex.split('-'),
                pageSlice = parseInt($scope.oriMsgCustomFields["Page_Slice"]) || 50,
                spliceCount = (parseInt(splittedIndex[0]) + pageSlice > onloadBackUp.onChangingList.length) && !(parseInt(splittedIndex[1]) + pageSlice > onloadBackUp.onChangingList.length) ? ((onloadBackUp.onChangingList.length - 1) - parseInt(splittedIndex[0])) : pageSlice,
                pageRangeList = temp.splice(splittedIndex[0]-1 , spliceCount);
            $scope.Stw_Cost_Code_Group.Stw_Cost_Code = pageRangeList;
        };

        var checkCostCodeInDB = function(contCostCode) {
            var dataSourceInc = 'DS_ASI_STD_ECC4_STW_CODE_CHECK_DUPLICATE';
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": dataSourceInc,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": 'STW-CCD|'+contCostCode
                    }]
                }
            };			

            $scope.costCodeXhr = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.costCodeXhr = false;
                if (resData) {
                    // taking the only first one
                    var contCostCodeObj = angular.fromJson(response.data[dataSourceInc]).Items.Item[0] || {};
                    if(contCostCodeObj.Value9 && contCostCodeObj.Value1) {
                        Notification.error({
                            title: 'Duplicate Entry Found.',
                            message: 'Duplicate cost code found,Please enter different cost code..!'
                        });
                        $scope.modelData.Cost_Code2 = '';
                    }
                }
            }, function (error) {
                $scope.costCodeXhr = false;                
                var errorMsg = 'Error retriving data<br/>' + error;
                Notification.error({
                    title: 'Server Error', 
                    message: errorMsg 
                });
            });
        };

        $scope.validateForDuplicate = function (contCostCode) {
            if(!contCostCode) {
                return false;
            }

            var dupCostCode = onloadBackUp.costCodeList.filter(function(codeObj) {
                return codeObj.Cost_Code2 == contCostCode;
            }) || [];

            if(!dupCostCode.length) {
                var rowObj;
                for (var key in guidRowObj) {
                    // skip loop if the property is from prototype
                    if (!guidRowObj.hasOwnProperty(key)) continue;
                    rowObj = guidRowObj[key] || {};
                    if (rowObj.Cost_Code2 == contCostCode) {
                        dupCostCode.push(rowObj);
                        break;
                    }
                }
            }

            if(!dupCostCode.length) {
                checkCostCodeInDB(contCostCode);
            }

            if(dupCostCode.length) {
                Notification.error({
                    title: 'Duplicate Entry Found.',
                    message: 'Duplicate cost code found,Please enter different cost code..!'
                });
                $scope.modelData.Cost_Code2 = '';
            }
        };
        
        var resetFilterFields = function() {
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Cost_Code_1'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Code_1_Dec'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Code_1_Digi'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code3'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Code3_Dec'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code2'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code1'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Cost_Code2'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Description'] = "";
            $scope.oriMsgCustomFields['Filter_Table']['Filter_Unit'] = "";
            $scope.oriMsgCustomFields['data_selections'] = "Yes";
            $scope.oriMsgCustomFields.Page_Sel = "";
        };

        $scope.resetTrackerFilter = function (event) {
            resetFilterFields();
            filterTrackerLog(event, true);
        }

        $scope.filterTrackerLog = filterTrackerLog;
        function filterTrackerLog(event, isForReset) {
            var dataSourceInc = "DS_ASI_STD_ECC4_STW_CODE_PAGING";
            var tmpFormField = dataSourceInc;
            var tmpTrackerParam = $scope.oriMsgCustomFields['Filter_Table']['Filter_Cost_Code_1'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Code_1_Dec'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Code_1_Digi'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code3'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Code3_Dec'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code2'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Report_Code1'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Cost_Code2'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Description'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Unit'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Rules_for_Use'] + '|' + $scope.oriMsgCustomFields['Filter_Table']['Filter_Ground_in_the'] + '|' + "" + '|' + $scope.oriMsgCustomFields['data_selections'];
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": tmpFormField,
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": dataSourceInc,
                        "fieldValue": tmpTrackerParam
                    }]
                }
            };

            var isRowBelongsToFilter = function(rowObj) {
                return ((($scope.oriMsgCustomFields.data_selections == 'Yes' && rowObj.Stw_is_disable == false) 
                || ($scope.oriMsgCustomFields.data_selections == 'No' && rowObj.Stw_is_disable == true)) 
                && rowObj.Cost_Code_1.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Cost_Code_1.trim().toLowerCase()) > -1
                && rowObj.Cost_Code_1_Dec.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Code_1_Dec.trim().toLowerCase()) > -1
                && rowObj.Cost_Code_1_Digi.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Code_1_Digi.trim().toLowerCase()) > -1
                && rowObj.Report_Code3.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code3.trim().toLowerCase()) > -1
                && rowObj.Report_Code3_Dec.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Code3_Dec.trim().toLowerCase()) > -1
                && rowObj.Report_Code2.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code2.trim().toLowerCase()) > -1
                && rowObj.Report_Code1.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code1.trim().toLowerCase()) > -1
                && rowObj.Cost_Code2.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Cost_Code2.trim().toLowerCase()) > -1
                && rowObj.Description.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Description.trim().toLowerCase()) > -1
                && rowObj.Unit.trim().toLowerCase().indexOf($scope.oriMsgCustomFields.Filter_Table.Filter_Unit.trim().toLowerCase()) > -1);
            };

            $scope.isXHRon = $scope.getCallbackData(form).then(function (response) {
                var resData = response.data;
                $scope.isXHRon = false;
                if (resData) {
                    var lstvalue = angular.fromJson(response.data['DS_ASI_STD_ECC4_STW_CODE_PAGING']).Items.Item,
                        objcostcode,rowObj,foundedIndex,
                        isBlankFilter = !$scope.oriMsgCustomFields.Filter_Table.Filter_Cost_Code_1 && !$scope.oriMsgCustomFields.Filter_Table.Filter_Code_1_Dec && !$scope.oriMsgCustomFields.Filter_Table.Filter_Code_1_Digi && !$scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code3 && !$scope.oriMsgCustomFields.Filter_Table.Filter_Code3_Dec && !$scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code2 && !$scope.oriMsgCustomFields.Filter_Table.Filter_Report_Code1 && !$scope.oriMsgCustomFields.Filter_Table.Filter_Cost_Code2 && !$scope.oriMsgCustomFields.Filter_Table.Filter_Description && !$scope.oriMsgCustomFields.Filter_Table.Filter_Unit;
                    $scope.Stw_Cost_Code_Group.Stw_Cost_Code = [];
                    
                    for (var i = 0; i < lstvalue.length; i++) {
                        objcostcode = angular.copy(STATIC_OBJ_DATA.Stw_Cost_Code);
                        objcostcode.Cost_Code_1 = lstvalue[i].Value1;
                        objcostcode.Cost_Code_1_Dec = lstvalue[i].Value2;
                        objcostcode.Cost_Code_1_Digi = lstvalue[i].Value3;
                        objcostcode.Report_Code3 = lstvalue[i].Value4;
                        objcostcode.Report_Code3_Dec = lstvalue[i].Value5;
                        objcostcode.Report_Code2 = lstvalue[i].Value6;
                        objcostcode.Report_Code1 = lstvalue[i].Value7;
                        objcostcode.Cost_Code2 = lstvalue[i].Value8;
                        objcostcode.Description = lstvalue[i].Value9;
                        objcostcode.Unit = lstvalue[i].Value10;
                        objcostcode.Rules_for_Use = lstvalue[i].Value11;
                        objcostcode.Ground_in_the = lstvalue[i].Value12;
                        objcostcode.Guid_Stw = lstvalue[i].Value14;
                        objcostcode.Stw_is_disable = (lstvalue[i].Value15 == 'true');
                        objcostcode.historyLogString = lstvalue[i].Value16;
                        objcostcode.modal_disable = true;
                        $scope.Stw_Cost_Code_Group.Stw_Cost_Code.push(objcostcode);                           
                    }

                    // Push updated nodes to the list if changed before filter.                        
                    for (var key in guidRowObj) {
                        // skip loop if the property is from prototype
                        if (!guidRowObj.hasOwnProperty(key)) continue;
                        rowObj = guidRowObj[key];
                        foundedIndex = commonApi._.findIndex($scope.Stw_Cost_Code_Group.Stw_Cost_Code, {
                            Guid_Stw : rowObj.Guid_Stw 
                        });
                        if(isRowBelongsToFilter(rowObj)) {
                            if(foundedIndex>-1){
                                $scope.Stw_Cost_Code_Group.Stw_Cost_Code[foundedIndex] = rowObj;
                            } else if (rowObj) {
                                $scope.Stw_Cost_Code_Group.Stw_Cost_Code.unshift(rowObj);
                            }
                        } else if($scope.oriMsgCustomFields.data_selections == 'All' && foundedIndex>-1){
                            // remove element if it doesn't suit in the filter from pagination array.
                            $scope.Stw_Cost_Code_Group.Stw_Cost_Code[foundedIndex] = rowObj;                        
                        } else if($scope.oriMsgCustomFields.data_selections != 'All' && foundedIndex>-1){
                            // remove element if it doesn't suit in the filter from pagination array.
                            $scope.Stw_Cost_Code_Group.Stw_Cost_Code.splice(foundedIndex, 1);                           
                        }
                    }

                    // data back up with 'onChangingList' key changed while active inactive selection.
                    onloadBackUp.onChangingList = angular.copy($scope.Stw_Cost_Code_Group.Stw_Cost_Code);

                    $scope.oriMsgCustomFields.Total_Pages = $scope.Stw_Cost_Code_Group.Stw_Cost_Code.length;                        
                    ($scope.Stw_Cost_Code_Group.Stw_Cost_Code.length < 50) ? $scope.oriMsgCustomFields.Page_Sel = '1-'+$scope.Stw_Cost_Code_Group.Stw_Cost_Code.length : $scope.oriMsgCustomFields.Page_Sel = '1-50';
                    setPagingData(); 
                    if(isForReset || (!isForReset && $scope.Stw_Cost_Code_Group.Stw_Cost_Code.length > 50 && isBlankFilter)) {
                        $scope.setPagination($scope.oriMsgCustomFields.Page_Sel);
                    }                       
                }
            });
        }

        $scope.applyFilterCall = function (event) {
            if(event.which != 13) {
                return false;
            }

            $scope.filterTrackerLog(event, false);
        };

        function editStw_Cost_CodeModal(rowData) {
            $scope.openModal('Stw_Cost_Code', rowData);
        }

        function setBackUpAndPagination (isOriView) {
            onloadBackUp.costCodeList = angular.copy($scope.Stw_Cost_Code_Group["Stw_Cost_Code"]);
            onloadBackUp.onChangingList = angular.copy($scope.Stw_Cost_Code_Group["Stw_Cost_Code"]);
            $scope.oriMsgCustomFields.Total_Pages = $scope.Stw_Cost_Code_Group["Stw_Cost_Code"].length;
            // set first 50 on load.
            $scope.setPagination($scope.oriMsgCustomFields.Page_Sel || '1-50');
        }

        resetFilterFields();
        if (currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.data_selections = 'Yes';
            if(isImported){
                var newAddedRecords = $scope.Stw_Cost_Code_Group.Stw_Cost_Code.filter(function(stwObj) {
                    return !stwObj.Guid_Stw;
                }) || [];
                if(newAddedRecords.length) {
                    getGUIdOnCallBack(newAddedRecords.length, function (guidResp) {
                        var i, lastUsedGuidIndex = 0;
                        for(i=0; i<$scope.Stw_Cost_Code_Group.Stw_Cost_Code.length; i++){
                            if(!$scope.Stw_Cost_Code_Group.Stw_Cost_Code[i].Guid_Stw) {
                                $scope.Stw_Cost_Code_Group.Stw_Cost_Code[i].Guid_Stw = guidResp[lastUsedGuidIndex].Value2 || '';
                                guidRowObj[guidResp[lastUsedGuidIndex].Value2] = $scope.Stw_Cost_Code_Group.Stw_Cost_Code[i];
                                lastUsedGuidIndex++;
                            }
                        }
                        // reset page selection to set pagination.
                        $scope.oriMsgCustomFields.Page_Sel = '';
                        setBackUpAndPagination();
                        setPagingData(true);
                    });
                } else {
                    // reset page selection to set pagination.
                    $scope.oriMsgCustomFields.Page_Sel = '';
                    setBackUpAndPagination();
                    setPagingData(true);
                }
            } else {
                setcostcodedata();
                // reset page selection to set pagination.
                $scope.oriMsgCustomFields.Page_Sel = '';
                setBackUpAndPagination();     
                setPagingData(true);
            }
            $scope.getServerTime(function (serverDate) {
                $scope.strTime = new Date(serverDate).getTime();
                $scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = $scope.todayDateDbFormat;
            });
            $scope.oriMsgCustomFields.loggedInUser = $scope.getValueOfOnLoadData('DS_LOGGEDIN_USERID')[0].Value;
            $scope.oriMsgCustomFields.workingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value;
        } else if (currentViewName == "ORI_PRINT_VIEW") {
            $scope.oriMsgCustomFields.data_selections = 'Yes';
            !isImported && setcostcodedata();
            setBackUpAndPagination();
            setPagingData(false);
        }

        function setcostcodedata() {            
            var lstvalue = $scope.DS_ASI_STD_ECC4_STW_CODE_PAGING;
            var objcostcode;
            $scope.Stw_Cost_Code_Group.Stw_Cost_Code = [];
            if ($scope.DS_ASI_STD_ECC4_STW_CODE_PAGING.length) {
                for (var i = 0; i < lstvalue.length; i++) {
                    objcostcode = angular.copy(STATIC_OBJ_DATA.Stw_Cost_Code);

                    objcostcode.Cost_Code_1 = lstvalue[i].Value1;
                    objcostcode.Cost_Code_1_Dec = lstvalue[i].Value2;
                    objcostcode.Cost_Code_1_Digi = lstvalue[i].Value3;
                    objcostcode.Report_Code3 = lstvalue[i].Value4;
                    objcostcode.Report_Code3_Dec = lstvalue[i].Value5;
                    objcostcode.Report_Code2 = lstvalue[i].Value6;
                    objcostcode.Report_Code1 = lstvalue[i].Value7;
                    objcostcode.Cost_Code2 = lstvalue[i].Value8;
                    objcostcode.Description = lstvalue[i].Value9;
                    objcostcode.Unit = lstvalue[i].Value10;
                    objcostcode.Rules_for_Use = lstvalue[i].Value11;
                    objcostcode.Ground_in_the = lstvalue[i].Value12;
                    objcostcode.Guid_Stw = lstvalue[i].Value14;
                    objcostcode.Stw_is_disable = (lstvalue[i].Value15 == 'true');
                    objcostcode.historyLogString = lstvalue[i].Value16;
                    objcostcode.modal_disable = true; 
                    if (i == 0) {
                        $scope.oriMsgCustomFields['Total_Pages'] = lstvalue[i]['Value13'];
                    }
                    $scope.Stw_Cost_Code_Group["Stw_Cost_Code"].push(objcostcode);
                }                
            }
        }
        $scope.update();

        var setUpdatedDataNodes = function () {
            var rowObj = {};
            // reset the update nodes first.
            $scope.updateStwCostCodeGroup.Update_Stw_Cost_Code = [];
            for (var key in guidRowObj) {
                // skip loop if the property is from prototype
                if (!guidRowObj.hasOwnProperty(key)) continue;
                rowObj = guidRowObj[key];
                if (rowObj) {
                    $scope.updateStwCostCodeGroup.Update_Stw_Cost_Code.push({
                        Update_Stw_Cost_Code_isSelected: rowObj.Stw_Cost_Code_isSelected,
                        Update_is_disable: rowObj.Stw_is_disable,
                        Update_Cost_Code_1: rowObj.Cost_Code_1,
                        Update_Cost_Code_1_Dec: rowObj.Cost_Code_1_Dec,
                        Update_Cost_Code_1_Digi: rowObj.Cost_Code_1_Digi,
                        Update_Report_Code3: rowObj.Report_Code3,
                        Update_Report_Code3_Dec: rowObj.Report_Code3_Dec,
                        Update_Report_Code2: rowObj.Report_Code2,
                        Update_Report_Code1: rowObj.Report_Code1,
                        Update_Cost_Code2: rowObj.Cost_Code2,
                        Update_Description: rowObj.Description,
                        Update_Unit: rowObj.Unit,
                        Update_Rules_for_Use: rowObj.Rules_for_Use,
                        Update_Ground_in_the: rowObj.Ground_in_the,
                        Update_Guid_Stw: rowObj.Guid_Stw,
                        modal_disable: rowObj.modal_disable
                    });
                }
            }
        };

        $window.costCodeSubmit = function () {
            $scope.oriMsgCustomFields.ORI_FORMTITLE  = 'STW Cost Code';
            setUpdatedDataNodes();
            return false;
        };
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof costCodeSubmit !== "undefined") {
        return costCodeSubmit();
    }
}