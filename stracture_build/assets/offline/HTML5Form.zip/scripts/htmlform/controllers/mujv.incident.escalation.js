/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection'], function(angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $controller, $window, $timeout, commonApi) {

        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;        
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.incidentEscalation = $scope.oriMsgCustomFields.incidentEscalation;
        

        var isOriView = (currentViewName == "ORI_VIEW"),
            isOriPrintView = (currentViewName == "ORI_PRINT_VIEW"),
            isRespView = (window.currentViewName == 'RES_VIEW'),
            
            CONSTANTS_OBJ = {
                CALL_LOG_LIST_KEY : 'call-log-list',
                CALL_LOG_LIST_LABEL : 'Call Log Forms List',
                COMM_TEAM_USER_LIST_KEY : 'commteam-user-list',
                COMM_TEAM_USER_LIST_LABEL : 'Commercial Team Users List'
            },
            projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
            availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS')           
            var structureItemList = function(setFor, availList) {
                var tempList = [],
                    optlabel = '';

                switch (setFor) {
                    case CONSTANTS_OBJ.CALL_LOG_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.Value1,
                                modelValue: item.Value1,
                                workOrderNo : item.Value3,
                                callLogFor : item.Value2,
                                location : item.Value6,
                                assetID  : item.Value10,
                                garrision : item.Value9,
                                supplyChainUser : item.Value8
                            });
                        });
                        optlabel = CONSTANTS_OBJ.CALL_LOG_LIST_LABEL;
                        break;
                    case CONSTANTS_OBJ.COMM_TEAM_USER_LIST_KEY:
                        angular.forEach(availList, function (item) {
                            tempList.push({
                                displayValue: item.split('#')[1].trim(),
                                modelValue: item
                            });
                        });
                        optlabel = CONSTANTS_OBJ.COMM_TEAM_USER_LIST_LABEL;
                        break;
                }
                return [{
                    optlabel: optlabel,
                    options: tempList
                }];
            };
            //location field should be find from the call log form
            var callLogFormsList = $scope.getValueOfOnLoadData('DS_MUJV_CREQ_List');
          
            $scope.incEscForChangeEvt = function (selectedItem, itemListKey) {
                if(itemListKey == 'call-log-list')
                {
                    if (selectedItem) {
                        $scope.incidentEscalation.locationDetails = selectedItem.location;
                        $scope.incidentEscalation.hdNo = selectedItem.workOrderNo;
                        $scope.incidentEscalation.assetNo = selectedItem.assetID;
                        $scope.incidentEscalation.garrision = selectedItem.garrision;
                        $scope.incidentEscalation.supplyChain = selectedItem.supplyChainUser;    
                    }
                }
            };

        $scope.setDateDisplayFormat = function (propertyKey, obj) {
            obj['display'+propertyKey] = $scope.formatDate(obj[propertyKey], 'dd M yy', 'yy-mm-dd');
        };
        $scope.incidentEscalation.dateOfIncident = $scope.formatDate($scope.incidentEscalation.dateOfIncident, 'dd M yy','yy-mm-dd');

        $scope.workOrderChangeEvt = function (workOrderNo) {
            if(workOrderNo == 'no') {
                $scope.incidentEscalation.callLogRef.callLogWorkOrderNo ='';
                $scope.incidentEscalation.assetNo = '';
                $scope.incidentEscalation.garrision = '';
                $scope.incidentEscalation.locationDetails = '';
            }
        };

        var setOriView = function () {
            $scope.getServerTime(function(serverDate) {
                $scope.serverDate = serverDate;
                $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
                $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');          
            });
            $scope.workOrderNoList = structureItemList(CONSTANTS_OBJ.CALL_LOG_LIST_KEY, callLogFormsList);
            var workingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
            $scope.incidentEscalation.Originator = workingUser['0'].Value.split('|')[1].split('#')[0].trim();
        };
        
        if (isOriView) {
            setOriView();
        } else if (isOriPrintView) {
        } 
        
        var setFormCommonNodes = function () {
            $scope.oriMsgCustomFields.ORI_FORMTITLE = 'Incident Escalation ' + $scope.incidentEscalation.callLogRef.callLogWorkOrderNo;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = $scope.incidentEscalation.callLogRef.callLogWorkOrderNo;
        },  setAppWorkflow = function () {
            var commerciallist = commonApi.roleUsersListByRoleName('business support', projAllRolesList),
                commercialDistList = [],
                currFormStaus = '',
                autoDistNode = isRespView ? '13' : '3';
            // resetting auto distribution node.
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];                
            if(isOriView ) {
                for (var i = 0; i < commerciallist.length; i++) {
                    commercialDistList.push({
                        strUser: commerciallist[i],
                        strAction: "7#For Information"
                    });
                }
                if (commercialDistList.length) {
                    commonApi.setDistributionNode({
                        actionNodeList: commercialDistList,
                        autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                        asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                        DS_AUTODISTRIBUTE: autoDistNode
                    });
                }
            } 

            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {  
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
			}
        };
          
        //to Hide Export Button in print view
        angular.element(".export-btn").hide();
        
        $scope.update();
        $window.oriformSubmitCallBack = function() {
            setAppWorkflow();
            setFormCommonNodes();
            return false;
        };
    }
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}