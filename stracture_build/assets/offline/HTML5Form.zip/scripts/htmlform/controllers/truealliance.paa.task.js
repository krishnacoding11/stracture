define(["angular", "./base", "../components/number-format", "../components/table.util", "../components/item.selection", "../components/signature"], function (angular, baseController) {
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass("loaded");
                    $scope.expandTextAreaOnLoad()
                }, 100)
            }
        });
        $scope.stopAutoSaveDraftTimerFromClientSide();

        var ctrl = this;
        var CAN_REPLY_CHECKED = false;
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.Todays_Date = $scope.todayDateDbFormat
        });
        var dateFormatMap = {
            en_GB: "dd-M-yy",
            fr_FR: "d M yy",
            es_ES: "dd-M-yy",
            ru_RU: "dd.mm.yy",
            en_AU: "dd/mm/yy",
            en_CA: "d-M-yy",
            en_US: "M d, yy",
            zh_CN: "yy-m-d",
            de_DE: "dd.mm.yy",
            ga_IE: "d M yy",
            en_ZA: "dd M yy",
            ja_JP: "yy/mm/dd",
            ar_SA: "dd/mm/yy",
            en_IE: "dd-M-yy",
            nl_NL: "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || "dd/mm/yy";
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null") {
            projectId = window.currProjId
        }
        var formId = document.getElementById("formId") && document.getElementById("formId").value || "";
        var currentViewName = window.currentViewName;
        $scope.selectionlst = {
            conData: [],
            projectManlist: [],
            interfaceCoList: [],
            maintEngList: [],
            assetOwnerList: []
        };


        $scope.asiteSystemDataReadOnly = $scope.data.myFields["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data.myFields["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data.myFields["FORM_CUSTOM_FIELDS"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly._5_Form_Data;
        $scope.DS_FORMNAME = document.getElementById("DS_FORMNAME").value;
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData("DS_ALL_FORMSTATUS");
        $scope.oriMsgCustomFields = $scope.formCustomFields.ORI_MSG_Custom_Fields;
        $scope.resMsgCustomFields = $scope.formCustomFields.RES_MSG_Custom_Fields;
        $scope.DS_PROJECTNAME = document.getElementById("DS_PROJECTNAME").value;
        var DS_PAA_MPC_NEC_EMP_CONTRACT = $scope.getValueOfOnLoadData("DS_PAA_MPC_NEC_EMP_CONTRACT");
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var ds_Projusers_Role = $scope.getValueOfOnLoadData("DS_PROJUSERS_ROLE");
        var dsWorkingUserId = $scope.getWorkingUserId();
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData("DS_ALL_ACTIVE_FORM_STATUS");
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        $scope.DS_PAA_MPC_GET_REF_FORM_URL_DTLS = $scope.getValueOfOnLoadData('DS_PAA_MPC_GET_REF_FORM_URL_DTLS');
        $scope.isDataLoaded = false;
        if (currentViewName == "ORI_VIEW") {
            $scope.selectionlst.conData = commonApi.getItemSelectionList({
                arrayObject: DS_PAA_MPC_NEC_EMP_CONTRACT,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });
        }
        var STATIC_OBJ_DATA = {
            "Auto_Distribute_Action": {
                "DS_ADO_TYPE": "3",
                "DS_ADO_FORM": "",
                "DS_ADO_MSG_TYPE": "",
                "DS_ADO_FORMACTIONS": "",
                "DS_ADO_PROJDISTGROUPS": "",
                "DS_ADO_ACTIONDUEDATE": "",
                "DS_ADO_PROJDISTUSERS": "",
                "DS_ADO_ORIG_USERID": "",
                "DS_ADO_TYPE_DIST_FLAG": ""
            }
        };
        var PAA_CONSTANT = {
            forInformation: "For Information",
            projectMan: "Project Manager",
            interfaceCo: "Interface Co-ordinator",
            maintEng: "Maintenance Engineer",
            assetOwner: "[Discipline] Asset Owner",

            // Form Statuses
            Closed: 'Closed',
            rejected: 'Rejected',
            Approved: 'Approved',
            InProgress: 'In Progress',
            Open: 'Open',
            Resolved: 'Resolved',

            defectModal: "Defects",
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',

            // Manage date as per Holiday Calender
            oriDistNumb: "401",
            resDistNumb: "411",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",
        };

        if (currentViewName == 'ORI_PRINT_VIEW' || currentViewName == 'RES_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && $scope.oriMsgCustomFields.Contract && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.Contract.split('|')[0]) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break;
                }
            }
        }
        $scope.onContractChange = function (conVal) {
            $scope.isDataLoaded = false;
            contractChangeCallback(conVal);
        }
        function contractChangeCallback(conVal) {

            if (conVal) {
                var strParam = conVal.split('|')[0].trim();
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_CONTRACT = conVal;
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                    }
                }
                $scope.isDataLoaded = true;
            }

        }

        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false,
            scrollTop: 0
        };

        function showModal(id) {
            var body = document.body;
            var docElement = document.documentElement;
            ctrl.model.scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            ctrl.model.modelId = id;

            $timeout(function () {
                var focusElem = $element.find('[autofocus]');
                focusElem[0] && focusElem[0].focus();
            })
        };

        function hideModal() {
            ctrl.model.modelId = '';

            $timeout(function () {
                var scrollObj = document.body
                if (scrollObj.scrollTop == 0) {
                    scrollObj = document.documentElement;
                }

                scrollObj.scrollTop = ctrl.model.scrollTop;
            }, 200)
        }

        function editSectionModal(rowData) {
            $scope.openModal(PAA_CONSTANT.defectModal, rowData);
        }

        $scope.onLocationDateChange = function (curRow, chagedField) {
            if (curRow.StartLoc && curRow.EndLoc && curRow.StartLoc > curRow.EndLoc) {
                $window.alert('Start Location should not be greater than End Location!!!');
                curRow[chagedField] = '';
            }
        };

        function validateModalForm(modalId) {
            var mandatorySingleFieldArray = [];
            var mandatoryRepeatFieldArray = [];
            var validaFlag = true;
            var repeatindData = null;
            switch (modalId) {
                case PAA_CONSTANT.defectModal:
                    mandatorySingleFieldArray = ['CDSInput'];
                    break;
            }

            validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

            if (repeatindData && validaFlag) {
                for (var k = 0; k < repeatindData.length; k++) {
                    if (validaFlag) {
                        validaFlag = checkFieldValueInObject(repeatindData[k], mandatoryRepeatFieldArray);
                    } else {
                        break;
                    }
                }
            }

            function checkFieldValueInObject(objectData, keyArray) {
                for (var index = 0; index < keyArray.length; index++) {
                    var element = keyArray[index];
                    var strElem = objectData[element];
                    if (!strElem) {
                        return false;
                    }
                }
                return true;
            }

            return validaFlag;
        }

        function updateRecord() {
            var rowIndex = modelRowIndex,
                newNode = angular.copy($scope.modalData);

            if (!validateModalForm(ctrl.model.modelId)) {
                $window.alert(PAA_CONSTANT.mandatoryValMsg);
                return;
            }

            switch (ctrl.model.modelId) {
                case PAA_CONSTANT.defectModal:
                    if (rowIndex > -1) {
                        $scope.oriMsgCustomFields.SectionsGroup.sections[rowIndex] = newNode;
                    }
                    else {
                        $scope.oriMsgCustomFields.SectionsGroup.sections.push(newNode);
                    }
                    break;

            }

            $timeout(function () {
                hideModal();
            })

        }

        /**
         * To check if user has action or not
         */
        function checkHasRespondAction() {
            var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                Name: "Respond"
            });
            if (!spNode) {
                return false;
            }

            var incompleteUserActionIds = spNode.Value.trim();
            if (incompleteUserActionIds && dsWorkingUserId && incompleteUserActionIds.indexOf(dsWorkingUserId) > -1) {
                return true;
            }
            return false;
        };

        initFormsData();
        function initFormsData() {
            if ($scope.oriMsgCustomFields.Contract && currentViewName == "ORI_VIEW") {
                $scope.onContractChange($scope.oriMsgCustomFields.Contract);
            }
            if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {

                $scope.oriMsgCustomFields.Reply_Days = "7";
                $scope.isTaskUser = dsWorkingUserId == getUserId($scope.oriMsgCustomFields.taksUser);
                $scope.isRespond = currentViewName == "RES_VIEW";
                $scope.initFormStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
                $scope.isOriginator = $scope.oriMsgCustomFields.altUserId == dsWorkingUserId;
                $scope.hasPendingAction = checkHasRespondAction();
                $scope.canReply = $scope.hasPendingAction || $scope.isOriginator;

                if ($scope.isRespond) {
                    if ($scope.isTaskUser) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS = PAA_CONSTANT.InProgress;
                    }

                    if ($scope.isOriginator && $scope.hasPendingAction) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS = PAA_CONSTANT.Approved;
                    }

                    $scope.oriMsgCustomFields["ResponderName"] = document.getElementById('DS_WORKINGUSER').value;
                    $scope.oriMsgCustomFields["ResponderUserId"] = dsWorkingUserId;
                    $scope.oriMsgCustomFields.Res_Comment = "";
                    $scope.oriMsgCustomFields.showActionField = true;
                }
            }
        }

        /**
         * Used to get userId from string given by sp
         * @param {String} userString 
         */
        function getUserId(userString) {
            if (userString) {
                return userString.split('|')[2].split('#')[0].trim();
            } else {
                return "";
            }
        }

        /**
         * Clear other user action based on userId's array
         * @param {Array<string>} userIdsArray 
         */
        function clearUsersAction(userIdsArray) {
            if (userIdsArray && userIdsArray.length) {
                var dsAppBuilderID = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];
                $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
                for (var index = 0; index < userIdsArray.length; index++) {
                    var msgType = getMsgIdOfUserId(userIdsArray[index]);
                    $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                        DS_AC_TYPE: "clear",
                        DS_AC_FORM: dsAppBuilderID,
                        DS_AC_MSG_TYPE: (msgType && msgType.indexOf("RES") > -1) ? "RES" : "ORI",
                        DS_AC_USERID: userIdsArray[index],
                        DS_AC_ACTION: "3",
                        DS_AC_ACTION_REMARKS: "Action Cleared"
                    })
                }
            }
        }

        /**
         * get msgId of form which one user have action,
         * @param {string} userId 
         */
        function getMsgIdOfUserId(userId) {
            for (var index = 0; index < DS_INCOMPLETE_ACTIONS_BYMSG.length; index++) {
                var element = DS_INCOMPLETE_ACTIONS_BYMSG[index];
                if (element.Value1 == userId && element.Value4 == "Respond") {
                    return element.Value3
                }
            }
            return "";
        }

        /**
         * Set form flow based on status and current user role
         */
        function setflow() {
            var userTodistribute = [];
            var autoDistNumber = PAA_CONSTANT.resDistNumb;
            var actionValue = PAA_CONSTANT.respondNumber;
            $scope.asiteSystemDataReadWrite.REPEATING_VALUES.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'] = [];
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "";

            $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
            $scope.asiteSystemDataReadWrite['Auto_Distribution_Actions']['DS_AUTODISTRIBUTE_OTHERS_APP_ID'] = "0";
            $scope.asiteSystemDataReadWrite['Form_Status_Change'] = {};

            if ($scope.isTaskUser) {
                if ($scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == PAA_CONSTANT.InProgress) {
                    userTodistribute = [getUserId($scope.oriMsgCustomFields.taksUser)];
                } else {
                    userTodistribute = [$scope.oriMsgCustomFields.altUserId];
                }
                setFormStatus($scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS);
            } else {
                if ($scope.hasPendingAction && $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == PAA_CONSTANT.Approved) {
                    distributeActionOnDefect();
                    setFormStatus(PAA_CONSTANT.Approved);
                } else if ($scope.hasPendingAction && $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS == PAA_CONSTANT.rejected) {
                    userTodistribute = [getUserId($scope.oriMsgCustomFields.taksUser)];
                    setFormStatus(PAA_CONSTANT.rejected);
                } else {
                    var spNode = commonApi._.findWhere(DS_INCOMPLETE_ACTIONS, {
                        Name: "Respond"
                    });
                    var incompleteUserActionIds = spNode && spNode.Value.split('#')[0].split('|');
                    incompleteUserActionIds = commonApi._.filter(incompleteUserActionIds, function (user) { return user.trim() != "" && user != dsWorkingUserId && user });

                    incompleteUserActionIds.length && clearUsersAction(incompleteUserActionIds);
                    userTodistribute = [getUserId($scope.oriMsgCustomFields.taksUser)];
                    setFormStatus($scope.initFormStatus);
                    $scope.oriMsgCustomFields.showActionField = false;
                }
            }

            if (userTodistribute.length) {
                var taskFormCode = $scope.data["myFields"]["Asite_System_Data_Read_Only"]['_5_Form_Data']['DS_AppBuilderID'];
                var distDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.todayDateDbFormat,
                    days: $scope.oriMsgCustomFields['Reply_Days'] || 7
                });
                for (var index = 0; index < userTodistribute.length; index++) {
                    distributeActionBasedOnForm(userTodistribute[index], distDate, taskFormCode)
                }
            }
            // Form's Staus will be set from below code.
            function setFormStatus(currFormStaus) {
                var strFormStatusId = commonApi.getFormStatusId({
                    availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                    strStatus: currFormStaus
                });

                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }

            return false;
        }

        /**
         * Distribute action on Defect form
         */
        function distributeActionOnDefect() {
            var allTaskCount = DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT.length; // Open
            var openTaskCount = commonApi._.filter(DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT, function (obj) {
                return obj.Value3 == PAA_CONSTANT.Approved;
            }).length;

            if (allTaskCount - 1 == openTaskCount) {
                var distDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.todayDateDbFormat,
                    days: $scope.oriMsgCustomFields['Reply_Days'] || 7
                });

                var allGroupUserIds = $scope.oriMsgCustomFields['groupUsers'] ? $scope.oriMsgCustomFields['groupUsers'].split(',') : [];

                for (var index = 0; index < allGroupUserIds.length; index++) {
                    distributeActionBasedOnForm(allGroupUserIds[index], distDate, $scope.oriMsgCustomFields['parentFormCode']);
                }

                changeDefectStatus();
            }
        }

        /**
         * set auto distribute node for same or another form.
         * @param {string} userId : for which user get action
         * @param {string} distDate : due date for action
         * @param {string} formCode : for which form you need to send this action
         */
        function distributeActionBasedOnForm(userId, distDate, formCode) {
            var distributeToOthers = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Action);
            distributeToOthers.DS_ADO_TYPE = "3";
            distributeToOthers.DS_ADO_FORM = formCode;
            distributeToOthers.DS_ADO_MSG_TYPE = "RES";
            distributeToOthers.DS_ADO_FORMACTIONS = PAA_CONSTANT.respondNumber;
            distributeToOthers.DS_ADO_ACTIONDUEDATE = distDate;
            distributeToOthers.DS_ADO_PROJDISTUSERS = userId;

            $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action.push(distributeToOthers);
            $scope.asiteSystemDataReadWrite['Auto_Distribution_Actions']['DS_AUTODISTRIBUTE_OTHERS_APP_ID'] = "1";
        }

        /**
         * Change status of defect form 
         */
        function changeDefectStatus() {
            var statusToSet = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: PAA_CONSTANT.Resolved
            });

            var selObj = [$scope.oriMsgCustomFields.parentFormCode]

            var newStatusId = "";
            for (var index = 0; index < selObj.length; index++) {
                newStatusId += index == selObj.length - 1 ? statusToSet.split('#')[0].trim() : statusToSet.split('#')[0].trim() + ",";
            }

            selObj = selObj.length && selObj.join(',');

            if (selObj && newStatusId) {
                $scope.asiteSystemDataReadWrite['Form_Status_Change'] = {
                    DS_CHANGE_STATUS_FORMS: selObj,
                    DS_CHANGE_STATUS_IDS: newStatusId
                }
            }
        }

        var DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT;
        /**
         * Check SP data for concurrency issue 
         */
        function checkOtherTaskForm() {
            var spParam = {
                dataSourceArray: [
                    {
                        "fieldName": "DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT",
                        "fieldValue": $scope.oriMsgCustomFields.parentFormCode
                    }
                ],
                successCallback: function (response) {
                    DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT = response.DS_PAA_MPC_TASK_LIST_AGAINST_DEFECT;
                    setflow();
                    CAN_REPLY_CHECKED = true;
                    $window.submitForm(1);
                }
            };

            $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                return obj.fieldName;
            });

            $scope.getCallbackSPdata(spParam);
        }

        $window.defFinalCallBack = function () {
            if ($scope.isRespond && !$scope.canReply) {
                $window.alert("Alert!\n\nYou do not have permission to reply on this message.")
                return true;
            } else if (CAN_REPLY_CHECKED) {
                return false;
            } else if ($scope.isRespond) {
                checkOtherTaskForm();
                return true;
            } else {
                return setflow();
            }
        }

        $scope.update();
    }
    return FormController
});
function customHTMLMethodAfterValidationError() { }
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof defFinalCallBack !== "undefined") {
        return defFinalCallBack()
    }
};