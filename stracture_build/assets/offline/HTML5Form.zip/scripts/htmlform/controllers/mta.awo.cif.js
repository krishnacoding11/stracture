
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule",'./base', '../components/item.selection'], function (angular, mainModule,baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
      
        var STATIC_OBJ_DATA = {
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            }
        };
        var MTA_CONSTANT = {
            //To fill dropdown rolewise
            constructionManager : 'construction manager',
            SVPSponsor: 'svp sponsor or user department',
            chiefDiscipline: 'chief discipline engineer or architect',
            designManager: 'Design Manager',
        }

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        $scope.isDraftEditOri = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_EDITORI;
        var ds_MTA_AWO_Get_Contract_Basic_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_Contract_Basic_Details');
        var ds_MTA_AWO_Get_Pricebreakdown_Section_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_Pricebreakdown_Section_Details');
        var ds_Projusers_Role = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');


        var strFormId = $scope.formdata5.DS_FORMID;
        var strIsDraft = $scope.formdata5.DS_ISDRAFT;

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
            $scope.ds_Workinguserid = dsWorkingUserId;
        }
        $scope.isDataLoaded = true;
        $scope.isConSelected = false;
        $scope.selectionlst = {
            contractNoList: [],
            sectionList:[],
            constructionManagerList:[],
            svpSponsorList:[],
            chiefDisciplineList:[],
            designManagerList:[]
        };
        initFormsData();
        function initFormsData()
        {
            if(currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW")
            {
                var isdsIsdraftRes = $scope.formdata5['DS_ISDRAFT_RES'];
                var isdsIsdraftResMsg = $scope.formdata5['DS_ISDRAFT_RES_MSG'];

                setRolewiseUser(MTA_CONSTANT.constructionManager);
                setRolewiseUser(MTA_CONSTANT.SVPSponsor);
                setRolewiseUser(MTA_CONSTANT.chiefDiscipline);
                setRolewiseUser(MTA_CONSTANT.designManager);

                if (currentViewName == "ORI_VIEW") {
                    fillcontract();
                    sectionfilldetails(ds_MTA_AWO_Get_Pricebreakdown_Section_Details);
                    if($scope.isDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'YES')){
                        $scope.selectionlst.sectionList = [];               
                        fillcontract();
                        sectionfilldetails(ds_MTA_AWO_Get_Pricebreakdown_Section_Details);
                    }
                }
                else if(currentViewName == "RES_VIEW")
                {
                    if(isdsIsdraftRes == "NO" && isdsIsdraftResMsg == "NO"){
                        var dsiNextstage = $scope.oriMsgCustomFields["DSI_NextStage"];
                        $scope.oriMsgCustomFields["DSI_CurrentStage"] = dsiNextstage;
                        $scope.oriMsgCustomFields.Comment = "";
                    }
                }
            }
            if(currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW")
            {
                getContractUrl();  
            }
        }
      
        function fillcontract()
        {
            $scope.selectionlst.contractNoList = commonApi.getItemSelectionList({
                arrayObject: ds_MTA_AWO_Get_Contract_Basic_Details,
                groupNameKey: "",
                modelKey: "Value6",
                displayKey: "Value5"
            }); 
        }
        $scope.onContractchange = function (conVal) {
			if (conVal) {
                $scope.isDataLoaded = false;
                var tempCon = conVal.split('||');
                $scope.formdata5.DS_FORMCONTENT1 = tempCon[0].trim();
                $scope.oriMsgCustomFields.Contract_Code = tempCon[1].trim();
				$scope.oriMsgCustomFields.Contract_Name = tempCon[2].trim();
				$scope.oriMsgCustomFields.Logo.Client_Logo = tempCon[4].trim();
                $scope.oriMsgCustomFields.Logo.Contractor_Logo = tempCon[3].trim();
                $scope.oriMsgCustomFields['ORI_FORMTITLE'] = tempCon[1].trim();
                $scope.oriMsgCustomFields['ORI_USERREF'] = tempCon[1].trim();
				var spParam = {
					dataSourceArray: [{
						"fieldName": "DS_MTA_AWO_Get_Pricebreakdown_Section_Details",
						"fieldValue": tempCon[0].trim()
					}],
					successCallback: contractChangeCallback
				};

				$scope.getCallbackSPdata(spParam);
			}
        }
        function contractChangeCallback(responseList) {	
            $scope.isConSelected = true;
            ds_MTA_AWO_Get_Pricebreakdown_Section_Details = responseList["DS_MTA_AWO_Get_Pricebreakdown_Section_Details"];
            sectionfilldetails(ds_MTA_AWO_Get_Pricebreakdown_Section_Details);

			$scope.isDataLoaded = true;
        }
        
        function sectionfilldetails(lstvalue) {
            if (lstvalue.length) {
                var seccode = "",
                    secname = "",
                    secguid = "",
                    lstdisplay = "",
                    lstval = "";
                for (var i = 0; i < lstvalue.length; i++) {
                    seccode = lstvalue[i].Value5.trim();
                    secname = lstvalue[i].Value6.trim();
                    secguid = lstvalue[i].Value7.trim();
                    lstdisplay = seccode + '-' + secname;
                    lstval = seccode + "-" + secname + "$$" + secguid;
                    if (seccode && secname && secguid) {
                        $scope.selectionlst.sectionList.push({
                            optlabel: "",
                            options: [{
                                displayValue: lstdisplay,
                                modelValue: lstval,
                                checked: false
                            }]
                        });
                    }
                }
            }
        }

        //final callback
        $window.mtaAWOFinalCallBack = function () {
        return setflow();
        }
        function setflow(){
            var currentstage = $scope.oriMsgCustomFields["DSI_CurrentStage"];
            var strTodayDate = $scope.setDbDateClientSide(0);
            if (currentstage) {
                switch (currentstage) {
                    case '0':
                        $scope.oriMsgCustomFields["DSI_NextStage"] = "1";

                        $scope.asiteSystemDataReadwrite['DS_AUTODISTRIBUTE'] = "3";
                        $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
                        
                        var conman = $scope.oriMsgCustomFields.Sendto_Construction_Manager;
                        var conmanVal = conman.split('|')[2].trim().split(' ')[0];

                        var svpSponsor = $scope.oriMsgCustomFields.Sendto_SvpSponsor;
                        var svpSponsorVal = svpSponsor.split('|')[2].trim().split(' ')[0];

                        var chiefDiscipline = $scope.oriMsgCustomFields.Sendto_ChiefDisciplineEngineer;
                        var chiefDisciplineVal = chiefDiscipline.split('|')[2].trim().split(' ')[0];

                        var designman = $scope.oriMsgCustomFields.Sendto_DesignManager;
                        var designmanVal = designman.split('|')[2].trim().split(' ')[0];

                        //set section code
                        var seccode = $scope.oriMsgCustomFields['Section'];
                        if(seccode != '')
                        {
                            $scope.formdata5.DS_FORMCONTENT2 = seccode.split('$$')[1].trim();
                        }
                        //set originator details
                        $scope.oriMsgCustomFields.Originator = dsWorkingUserId;
                        //set distribution
                        var strdate = $scope.setDbDateClientSide(5);
                        setAutoDistribution(conmanVal,"7#",strdate,"0");  
                        setAutoDistribution(svpSponsorVal,"7#",strdate,"0");  
                        setAutoDistribution(chiefDisciplineVal,"7#",strdate,"0");  
                        setAutoDistribution(designmanVal,"7#",strdate,"0");  

                        setAutoCreateNodesValues();
                    break;
                    case '1':
                        var strstatus = $scope.oriMsgCustomFields.CIF_Status;
                        if(strstatus != '')
                        {
                            setFormStatus(strstatus);
                        }
                        clearAutoCreateNodesValues();
                        $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users']=[];
                    break;
                }
            }
        }
        function setFormStatus(strstatus) {              
            var strFormStatusId = getFormStatusId(strstatus);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }          
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter          
            if (ds_all_Active_Form_Status && ds_all_Active_Form_Status.length > 0) {
                var statudObj = commonApi._.filter(ds_all_Active_Form_Status, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        function setAutoDistribution(strUser, strAction, strDueDate,strDueDays) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = strDueDate;
            structDistribution.DS_DUEDAYS = strDueDays;

            $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push(structDistribution);
        }
        function clearAutoCreateNodesValues()
        {
            $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
            $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = ""
            $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "";
        }
        function setAutoCreateNodesValues() {
            var strformcontent  = $scope.oriMsgCustomFields['Contract']+"$$"+"<<DS_AppBuilder_Id>>" +"$$"+"<<DS_Form_ID>>"+"$$"+$scope.oriMsgCustomFields['Section'];
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
            $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = "MTA-AWO-AWO"
            $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "1";

			$scope.ACF_01_FORM.ACF_01_CREATED_BY = dsWorkingUserId;
			$scope.ACF_01_FORM.ACF_01_ORI_USERREF = $scope.oriMsgCustomFields['ORI_USERREF'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMTITLE = $scope.oriMsgCustomFields['ORI_FORMTITLE'];
            $scope.ACF_01_FORM.ACF_01_ORI_FORMTITLE = $scope.oriMsgCustomFields['ORI_FORMTITLE'];
            $scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT = strformcontent;
            $scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT1 = $scope.formdata5.DS_FORMCONTENT1;
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT3 = "<<DS_Form_ID>>";

        }
        $scope.resetvalue = function(strtype)
        {
            if(strtype == 'design')
            {
                $scope.oriMsgCustomFields.Designed_By.Design_Con_Name = "";
            }
            if(strtype == 'inspect')
            {
                $scope.oriMsgCustomFields.Inspected_By.Inspect_Con_Name = "";
            }
        }
        function setRolewiseUser(strRole) {
            //set role wise list dropdown
            if (ds_Projusers_Role.length) {
                var lstcontractor = commonApi._.filter(ds_Projusers_Role, function (val) {
                    if (val.Value.split('|')[0].trim() == strRole) {
                        return val.Value;
                    }
                });
                
                var objroleuser = [];
                for (var i = 0; i < lstcontractor.length; i++) {
                    objroleuser.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }

                if (strRole) {
                    switch (strRole) {
                        case MTA_CONSTANT.constructionManager:
                            $scope.selectionlst.constructionManagerList = angular.copy( objroleuser );
                            break;
                        case MTA_CONSTANT.SVPSponsor:
                            $scope.selectionlst.svpSponsorList = angular.copy( objroleuser );
                            break;
                        case MTA_CONSTANT.chiefDiscipline:
                            $scope.selectionlst.chiefDisciplineList = angular.copy( objroleuser );
                            break;
                        case MTA_CONSTANT.designManager:
                            $scope.selectionlst.designManagerList = angular.copy( objroleuser );
                            break;
                    }
                }
            }
        }
                
        function getContractUrl() {
            //get status according pass parameter   
            var conUrlLink = $scope.formdata5['DS_FORMCONTENT1'];     
            if (ds_MTA_AWO_Get_Contract_Basic_Details && ds_MTA_AWO_Get_Contract_Basic_Details.length > 0) {
                var conUrlLinkObj = commonApi._.filter(ds_MTA_AWO_Get_Contract_Basic_Details, function (val) {
                    return val.Value2.toLowerCase().trim() == conUrlLink.toLowerCase().trim();
                });
                if (conUrlLinkObj.length) {
                    $scope.oriMsgCustomFields['ContractURL'] = conUrlLinkObj[0].URL7;
                }
            }
            return "";
        }

       $scope.update();
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof mtaAWOFinalCallBack !== "undefined") {
        return mtaAWOFinalCallBack();
    }
}