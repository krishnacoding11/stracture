define(['angular', './base'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout) {
		var ctrl = this,
			projectId,
			instaceGroupId,
			total,
			lastsectionId = 402;

		
		
		$scope.staticJson=[{label:'',selected:false,id:400,isvalid:true,data:[{label:'',selected:false,isvalid:true,id:401,data:[{label:'',invalid:false,fieldId:402,fieldName:'',fieldTypeId:1,value:'',width:'col-md-6'}]}]}];
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.currentTab = 1;
		$scope.jsonWeightage = {};
		$scope.isWeightageexceed=false; 
		$scope.clickSave = false;

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});

		ctrl.$onInit = function () {
			$scope.data = $scope.getFormData();
			if($scope.data.section && $scope.data.section.length > 0){
				for(var i=0;i<$scope.data.section.length;i++){
					for(var j=0;j<$scope.data.section[i].data.length;j++){
						if($scope.data.section[i].data[j].value){
							$scope.data.section[i].data[j].value = parseInt($scope.data.section[i].data[j].value);
						}
					}
					if($scope.data.section[i].value){
						$scope.data.section[i].value = parseInt($scope.data.section[i].value);
					}
				}
				for(var i=0;i<$scope.data.customsection.length;i++){
					for(var j=0;j<$scope.data.customsection[i].data.length;j++){
						if($scope.data.customsection[i].data[j].value){
							$scope.data.customsection[i].data[j].value = parseInt($scope.data.customsection[i].data[j].value);
						}
					}
					if($scope.data.customsection[i].value){
						$scope.data.customsection[i].value = parseInt($scope.data.customsection[i].value);
					}
				}
			$scope.jsonWeightage = $scope.data;
			}else{
				$scope.getFormJson();
			}
				
			$scope.update();	
		}
		$scope.getFormJson = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/uop/weightageSections',
				method: 'GET',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey' :  top.marketPlaceApiKey
				},
			}).then(function (response) {
				response.data && response.data.length > 0 && updatejson(response.data);
				
			}, function () {

			});
		}

		var updatejson = function(data){
			var jsonWeightage = {};
			var arrayWeighage = [];
			
			for (var index = 0; index < data.length; index++) {
				data[index].isvalid = true;
				data[index].selected = true;
				if(data[index].parentId == 0){
					data[index].data = [];
					jsonWeightage[data[index].sectionId] = data[index];
				}
			}
			for (var index = 0; index < data.length; index++) {
				if(data[index].parentId > 0){
					jsonWeightage[data[index].parentId].data.push( data[index]);
				}
			}
			for(var key in jsonWeightage){
				arrayWeighage.push(jsonWeightage[key]);
			}
			for (var i = 0; i < arrayWeighage.length; i++) {
				for (var j = 0; j < arrayWeighage[i].data.length; j++) {
					if(arrayWeighage[i].data[j].value == 0){
						arrayWeighage[i].data[j].value = '';
					}
				}
				arrayWeighage[i].value = parseInt(arrayWeighage[i].value);
				if(arrayWeighage[i].value == 0){
					arrayWeighage[i].value = '';
				}
			}
			for (var i = 0; i < $scope.staticJson.length; i++) {
				for (var j = 0; j < $scope.staticJson[i].data.length; j++) {
					if($scope.staticJson[i].data[j].value == 0){
							$scope.staticJson[i].data[j].value = '';
					}											
				}
				if($scope.staticJson[i].value == 0){
					$scope.staticJson[i].value = '';
				}						
			}
			for(var i=0 ;i< arrayWeighage.length;i++){
				if(arrayWeighage[i].data && arrayWeighage[i].data.length == 0){
					arrayWeighage[i].selected = false;
				}
			}
			arrayWeighage[-1] = arrayWeighage[4];
			arrayWeighage[4] = arrayWeighage[2];
			arrayWeighage[2] = arrayWeighage[-1];
			delete arrayWeighage[-1];
			$scope.data.section = arrayWeighage;
			$scope.data.customsection = JSON.parse(JSON.stringify($scope.staticJson));
			$scope.update();
		};
		
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ?  $scope.currentTab = ' ' :  $scope.currentTab = eID ;
		};

		$scope.validateValue = function(section,subsection,array){
			total = 0;
			subsection.isvalid = true;

			if(section){
				section.isvalid = true	
			}else{
				$scope.isWeightageexceed = false;
			}
			
			if(parseInt(subsection.value) > 100){
				subsection.isvalid = false;
			}
			for (var i = 0; i < array.length; i++) {
				total+=array[i].value || 0;
			}
			if(total != 100){
				if(section){
					section.isvalid = false;
				}else{
					$scope.isWeightageexceed = true;
				}
			}
		}

		$scope.selectSection= function(section){
			for(var i=0;i<section.data.length;i++){
				if(section.selected){
					section.data[i].selected = true;
				}else{
					section.data[i].selected = false;
				}
			}
			
		}
		$scope.selectSubsection= function(subsection,section){
			if(!subsection.selected){
				var selectedSubSectionLength = section.data.length;
				for(var i=0;i<section.data.length;i++){
					if(section.data[i].selected){
						selectedSubSectionLength = selectedSubSectionLength + 1;
					}else{
						selectedSubSectionLength = selectedSubSectionLength - 1;
					}
				}
				if(selectedSubSectionLength <= 0){
					section.selected = false;
					 setTimeout(function () {
                       $scope.selectSection(section)
                    }, 50);
				}
			}
		}
		
		$scope.removeItem= function(array,index){
			array.splice(index, 1);
		}

		$scope.addMultpleItem = function(data,item){
			
			
			var json = JSON.parse(JSON.stringify(item[0]));
			if(json.id){
				lastsectionId++;
				json.id = lastsectionId;
			}
			if(json.data && json.data[0]){
				lastsectionId++;
				json.data[0].id = lastsectionId;
			}	
			data.push(json);
		}

		var validateForm =function(){
			var section = $scope.jsonWeightage.section,
			    formWeightage = 0,
			    sectionWeightage = 0,
			    valid = true;
			for (var i = 0; i < section.length; i++) {
				sectionWeightage = 0;
				for (var j = 0; j < section[i].data.length; j++) {
					if(section[i].data[j].value){
						if(section[i].data[j].value > 100){
							alert('form contain error pls fix it');
							valid = false;
							break;
						}else{
							sectionWeightage+=section[i].data[j].value;
						}
					}
				}
				if(section[i].value){
					if(section[i].value > 100){
						alert('form contain error pls fix it')
						valid = false;
						break;
					}else{
						formWeightage+=section[i].value;
					}
				}
				if(sectionWeightage > 100){
					alert('form contain error pls fix it')
					valid = false;
					break;
				}
				
			}
			if(formWeightage > 100){
				alert('form contain error pls fix it')
				valid = false;
			}
			return valid;
			
		}
		$window.weightageFinalCallBack = function () {
			if($scope.data['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['isEvalutionEnable'] === 'Yes'){
				var isvalid = false;
				var subSectionTotal = 0;
				var sectionTotal = 0;
				for(var i=0;i<$scope.data.section.length;i++){
					if($scope.data.section[i].selected){
						subSectionTotal = 0;
						if($scope.data.section[i].data.length){
							for(var j=0;j<$scope.data.section[i].data.length;j++){
								if($scope.data.section[i].data[j].selected){
									subSectionTotal += $scope.data.section[i].data[j].value;
								}
							}
						}
						if(subSectionTotal > 100 || subSectionTotal < 100){
							$window.alert("Validation \n\n It seems that subsection weightage total is not equal to 100. Please ensure that total of each subsection is exactly 100." );
							return true;
						}
						sectionTotal += $scope.data.section[i].value;
					}
				}
				
				for(var i=0;i<$scope.data.customsection.length;i++){
					if($scope.data.customsection[i].selected){
						subSectionTotal = 0;
						if($scope.data.customsection[i].data.length){
							for(var j=0;j<$scope.data.customsection[i].data.length;j++){
								if($scope.data.customsection[i].data[j].selected){
									subSectionTotal += $scope.data.customsection[i].data[j].value;
								}
							}
						}
						if(subSectionTotal > 100 || subSectionTotal < 100){
							$window.alert("Validation \n\n It seems that subsection weightage total is not equal to 100. Please ensure that total of each subsection is exactly 100." );
							return true;
						}
						sectionTotal += $scope.data.customsection[i].value;
					}
				}
				if(sectionTotal > 100 || sectionTotal < 100){
					$window.alert("Validation \n\n It seems that Sections weightage total is not equal to 100. Please ensure that total of all the sections is exactly 100." );
					return true;
				}
			}
			return false;
        }
		$scope.saveWeightageForm= function(){
			$scope.clickSave = true;
			if(!validateForm()){
				return;
				$scope.clickSave = false;
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveweightage",
				method: 'post',
				withCredentials: true,
				headers : {
					'Content-Type': 'application/json',
					'ApiKey' :  top.marketPlaceApiKey
				},
				data : angular.toJson({
					formJson : angular.toJson({
						myFields : $scope.jsonWeightage
					}),
					projectId : $("input[name ='projectId']").val().split('$$')[0],
					instaceGroupId : $('#instance_group_id').val().split('$$')[0],
					formId: $("input[name ='formId']").val().split('$$')[0]
				})
			}).then(function(response) {
				if(response.data){
					$window.top.postMessage("closeCreateFormIframe:-1",'*')
				}
			}, function() {
				$scope.clickSave = false;
				
			});
		}


		$scope.cancel = function () {
			$window.top.postMessage("closeCreateFormIframe:-1",'*')
		}

	}

	return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof weightageFinalCallBack !== "undefined") {
        return weightageFinalCallBack();
    }
}