/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = $window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
        });
		
        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy", "nl_NL": "dd-M-yy" };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var costCodeDataArray = [];
        var linkFormDataArray = [];

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            oriTitle: "Project Co Compensation Events",
            responseTitle: "TFL Response to NCE",

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation: "Submitted for Information",
            forInformation: "For Information",
            forAcceptance: "For Acceptance",
            respond: "Respond",
            openStatus: "Open",
            subjectToChangeAppraisal: "Subject to Change Appraisal",
            subjectToConfirmationNotice: "Subject to Change Confirmation Notice",
            acceptQuote: "Accept Quote",
            reviseAndResubmit: "Revise and Resubmit",
            WithdrawnPCN: "Withdraw PCN",
            Withdrawn: 'Withdrawn',
            subjectToICA: "Subject to ICA",
            Closed: 'Closed',

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",

            // Appbuidler codes of forms
            changeAppraisal: "STT-CAF",
            supplierChangeNotice: "STT-SCN",
            projectChangeNotice: "STT-PCN",
            changeAppraisalInstruction: "STT-CAI",
            changeConfirmNotice: "STT-CCN",
            initChangeAppraisal: "STT-ICA",

            // Static role used in Code
            tflRepresentative: "TFL Representative",
            preojectManager: "Project Manager",
            contractor: "Contractor",

            // Data source 
            dsSttNnecSertuoSections: "DS_STT_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_STT_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_STT_SECTION_USERS",
            dsSttNnecSecLck: "DS_STT_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_STT_ALL_CONTRACT_TEAM_MEMBERS",
            dsSttNnecGetFormDetailsByStatus: "DS_STT_GET_FORM_DETAILS_BY_STATUS",
            dsAllActiveWsStatus: "DS_ALL_ACTIVE_WS_STATUS",
            dsSttNecAllEwn: "DS_STT_NEC_ALL_EWN",
            dsSttNecKeyContractDates: "DS_STT_NEC_KEY_CONTRACT_DATES"
        }

        var STATIC_OBJ_DATA = {

            Auto_Distribute_Users: {
                "DS_PROJDISTUSERS": "",
                "DS_FORMACTIONS": "",
                "DS_ACTIONDUEDATE": "",
                "DS_DUEDAYS": "",
                "AutoDist_Id": 1,
                "dist_isSelected": false,
                "isEditable": "1"
            }
        }

        $scope.tableUtilSettings = {
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.sectionDetails)
            }
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        var dsSttBlNnecNecOrgConctract = $scope.getValueOfOnLoadData('DS_STT_NEC_ORG_CONTRACT');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_STT_NEC_CONTRACT');
        var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_STT_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData(TFL_CONSTANT.dsSttNnecAllContractTeamMembers);
        var dsWorkingUserId = $scope.getWorkingUserId();
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();

        if (currentViewName == "RES_VIEW") {
            $scope.formCustomFields.formData.appTitle = TFL_CONSTANT.responseTitle;
            $scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "0";
            $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = "";
            $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = "";
            var strOriginatorid = $scope.oriMsgCustomFields.Originator_Id;
            var strCanReplay = "YES",
                strReviewDraft = filterdata("Review Draft"),
                strRespond = filterdata("Respond"),
                strForAction = filterdata("For Action");

            if (!strReviewDraft && !strRespond && !strForAction) {
                strCanReplay = "";
            }
            if (strOriginatorid == dsWorkingUserId) {
                strCanReplay = "";
            }
            var userObj = commonApi._.filter(DS_STT_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
                return val.Value.split('#')[0].split('|')[2].trim() == dsWorkingUserId;
            });
            if (!userObj.length) {
                strCanReplay = "";
            }
            if (!strCanReplay) {
                $scope.hideSaveDraftButton();
            }
            $scope.formCustomFields.DSI_CREATE_FWD_RES.DSI_Can_Reply = strCanReplay;
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
            $scope.update();
        } else if (currentViewName == "ORI_VIEW") {

            if (strFormId && strIsDraft == "NO") {
                $scope.formCustomFields.DSI_CREATE_FWD_RES.Can_Forward = "";
                $scope.hideSaveDraftButton();
            }
            $scope.isConSelected = false;
            $scope.formCustomFields.formData.appTitle = TFL_CONSTANT.oriTitle;
            $scope.dropdownObj = {
                contractList: [],
                tflReprentList: [],
                distSectionsList: [],
                sectionsList: [],
                distUsersList: [],
                formActionList: [],
                contractorList: [],
                linkFormList: [],
                statusList: [],
                ewnList: []
            };

            fillDropwdowns();
            initFormData();
            $scope.update();
        } else {
            for (var i = 0; i < $scope.linkContractURL.length; i++) {
                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            }
            $scope.linkEarlyWarningURL = $scope.getValueOfOnLoadData('DS_STT_NEC_EWN_LINK');
            for (var i = 0; i < $scope.linkEarlyWarningURL.length; i++) {
                if ($scope.linkEarlyWarningURL[i] && $scope.linkEarlyWarningURL[i].Value && $scope.linkEarlyWarningURL[i].Value.indexOf($scope.oriMsgCustomFields.EWN_ID) > -1) {
                    $scope.linkEarlyWarningURL = $scope.linkEarlyWarningURL[i].URL;
                    break;
                }
            }            
            var strContractor = $scope.oriMsgCustomFields['TFL_Representative'];
            var checkRole = strContractor && strContractor.split('|')[1].trim();
            strContractor = strContractor && strContractor.split('|')[2].trim();
            $scope.checkContractorOrNot = false;
            var strWorkingId = $scope.getWorkingUserId();
            if (strContractor && checkRole == TFL_CONSTANT.contractor) {
                strContractor = strContractor.split('#')[0].trim();
                if (strWorkingId && strContractor == strWorkingId) {
                    $scope.checkContractorOrNot = true;
                }
            }

            $scope.update();
        }


        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.onContractChange = onContractChange;

        function onContractChange() {
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            var tempConAppCode = commonApi._.filter(contractDataArray, function (mapObj) {
                return mapObj.contractID == contractNumber;
            })[0];

            if ($scope.linkContractURL.length) {
                if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                    var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                        return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes) {
                            $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                        }    
                    }
                }    
            }

            loadClientLogo(tempConAppCode);

            tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

            var paramAppbuilderCode = TFL_CONSTANT.projectChangeNotice;
            var paramStatus = TFL_CONSTANT.openStatus;

            if (tempConAppCode) {
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSertuoSections,
                        "fieldValue": tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecNecContractSummary,
                        "fieldValue": tempConAppCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                        "fieldValue": tempConAppCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus,
                        "fieldValue": tempConAppCode + "|" + paramAppbuilderCode + "|" + paramStatus
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNecAllEwn,
                        "fieldValue": tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsSttNecKeyContractDates,
                        "fieldValue": tempConAppCode
                    }],
                    successCallback: contractChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        $scope.onDaysChange = function(enteredDaysNode, ContractDaysNode, replyDateNode) {
            var enteredDays = $scope.oriMsgCustomFields[enteredDaysNode];
            var contractDays = $scope.oriMsgCustomFields[ContractDaysNode];
            if ((enteredDays && contractDays && parseInt(enteredDays) < parseInt(contractDays)) || (!enteredDays && contractDays)) {
                alert("Entered days cannnot be less than contract days");
                $scope.oriMsgCustomFields[enteredDaysNode] = $scope.oriMsgCustomFields[ContractDaysNode];
            }
            var replyDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days : $scope.oriMsgCustomFields[enteredDaysNode]
            });
            $scope.oriMsgCustomFields[replyDateNode] = replyDate;
        }

        $scope.onSectionChange = function (strVal) {

            if (strVal) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue": strParam
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue": strParam
                    }],
                    successCallback: sectionChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        // on EWN Reference Change
        $scope.onEWN_Change = function () {
            var ewnRef = $scope.oriMsgCustomFields.DS_STT_NEC_ALL_EWN;
            $scope.oriMsgCustomFields.EWN_ID = ewnRef.split('#')[1].split('|')[0].trim();
            if (ewnRef) {
                var ewnAppId = ewnRef.split('|')[4].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = ewnAppId;
            }
        }

        /* uncheck suboptions 
            reset all subOptions on uncheck event type parent checkbox uncheck all suboptions 
        */

        $scope.resetSuboptions = function (eventType, boolCurrentValue) {
            if (!boolCurrentValue) {
                if (eventType == "qualifyingEvent") {
                    var allSubOptions = $scope.oriMsgCustomFields.QualifyingEventSubOptions;
                    allSubOptions.UnexplodedOrdnance = false;
                    allSubOptions.UnknownManMadeObstruction = false;
                    allSubOptions.UnknownContamination = false;
                    allSubOptions.HistoricalRemains = false;
                    allSubOptions.HighCostUtility = false;
                    allSubOptions.UnknownUtility = false;
                    allSubOptions.UnknownGeologicalCondition = false;
                }
                if (eventType == "reliefEvent") {
                    var allSubOptions = $scope.oriMsgCustomFields.ReliefEventSubOptions;
                    allSubOptions.CauseDelayToPerformObligations = false;
                    allSubOptions.Fire = false;
                    allSubOptions.Explosion = false;
                    allSubOptions.Lightning = false;
                    allSubOptions.Storm = false;
                    allSubOptions.Tempest = false;
                    allSubOptions.Flood = false;
                    allSubOptions.BurstingOrOverflowingOfWater = false;
                    allSubOptions.TanksApparatusOrPipesIonisingRadiation = false;
                }
                if (eventType == "compensationEvent") {
                    var allSubOptions = $scope.oriMsgCustomFields.CompensationEventSubOptions;
                    allSubOptions.ChangeInProjectCosts = false;
                    allSubOptions.LossOfRevenue = false;
                    allSubOptions.ScheduleDelay = false;
                }
            }
        }


        function fillDropwdowns() {

            // Contract downdown

            for (var i = 0; i < dsSttBlNnecNecOrgConctract.length; i++) {
                var element = dsSttBlNnecNecOrgConctract[i];
                element = element.Value ? element.Value.split('|') : [];
                if (element.length) {
                    contractDataArray.push({
                        contractID: element[2].trim(),
                        contractorLogo: element[4].trim(),
                        clientLogo: element[5].trim(),
                        contractName: element[8].trim(),
                        contractAppCode: element[0].trim(),
                        contractIdName: dsSttBlNnecNecOrgConctract[i].Name
                    });
                }
            }
            
            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });


            // TFL Reprensetative downdown
            var tflRepresentativeArray = [];
            for (var i = 0; i < dsProjUserRole.length; i++) {
                var element = dsProjUserRole[i];
                if (element.Value.indexOf(TFL_CONSTANT.tflRepresentative) > -1) {
                    tflRepresentativeArray.push({
                        userName: element.Name,
                        userID: element.Value
                    });
                }
            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject: tflRepresentativeArray,
                groupNameKey: "",
                modelKey: "userID",
                displayKey: "userName"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })


            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

        }

        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(tempConAppCode) {
            $scope.oriMsgCustomFields.contractorLogo = tempConAppCode.contractorLogo || TFL_CONSTANT.defaultLogo;
            $scope.oriMsgCustomFields.clientLogo = tempConAppCode.clientLogo || TFL_CONSTANT.defaultLogo;  
        }

        function strIsUserDraftOnly() {
            if (DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_STT_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        } 

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsSttNnecSectionUsers];
            var distLockflag = spDataList[TFL_CONSTANT.dsSttNnecSecLck];

            if (distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');
                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }    

                var strMatchAction = nodeVal[2].trim() + '#' +nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";

                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                tempList.push({
                    strUser: nodeVal[0].trim() + "#" + userName.trim(),
                    strAction:strAction,//"7#For Information",
                    strDate: distDate
                });
            }

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
        }

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList) {
            $scope.isConSelected = true;
            // Sections dropdown data based on setup form
            if (responseList[TFL_CONSTANT.dsSttNnecSertuoSections]) {
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[TFL_CONSTANT.dsSttNnecSertuoSections],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            //EWN data
            if (responseList[TFL_CONSTANT.dsSttNecAllEwn]) {
                var allNodes = responseList[TFL_CONSTANT.dsSttNecAllEwn];
                var match = true;
                var matchNode = "";
                $scope.dropdownObj.ewnList = commonApi.getItemSelectionList({
                    arrayObject: allNodes,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
                if ($scope.oriMsgCustomFields['EWN_ID']) {
                    for (var i = 0; i < allNodes.length; i++) {
                        matchNode = allNodes[i].Name.split('|')[0].trim();
                        if (matchNode == $scope.oriMsgCustomFields['EWN_ID']) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        $scope.oriMsgCustomFields['DS_STT_NEC_ALL_EWN'] = "";
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = "";
                        $scope.oriMsgCustomFields['EWN_ID'] = "";
                        $scope.linkEarlyWarningURL = "";
                    }
                }    
            }

            // Contract Activity Summry Data
            costCodeDataArray = responseList[TFL_CONSTANT.dsSttNnecNecContractSummary]
            var tempCostCodeDataArray = angular.copy(costCodeDataArray);
            if (tempCostCodeDataArray.length) {
                tempCostCodeDataArray = commonApi._.uniq(tempCostCodeDataArray, 'Value3');
                $scope.dropdownObj.sectionsList = commonApi.getItemSelectionList({
                    arrayObject: tempCostCodeDataArray,
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value18"
                })
            }

            // Contractor Data list
            var contractTeamMemberList = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers]
            if (contractTeamMemberList.length) {
                //contractTeamMemberList = commonApi._.uniq(contractTeamMemberList,'Value3');
                var matchRole = TFL_CONSTANT.preojectManager;
                var tempVal = [], tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if (tempVal.indexOf(element.Value) == -1 && roleName == matchRole) {
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            var linkFormList = responseList[TFL_CONSTANT.dsSttNnecGetFormDetailsByStatus];
            if (linkFormList) {
                linkFormDataArray = [];
                for (var index = 0; index < linkFormList.length; index++) {
                    var element = linkFormList[index];
                    linkFormDataArray.push({
                        pcnNo: element.Value1,
                        pcnTitle: element.Value1 + ' | ' + element.Value2,
                        pcnFormCode: element.Value3
                    })
                }

                $scope.dropdownObj.linkFormList = commonApi.getItemSelectionList({
                    arrayObject: linkFormDataArray,
                    groupNameKey: "",
                    modelKey: "pcnTitle",
                    displayKey: "pcnTitle"
                })
            }

            // Contractor response days Data list
            var contractResponseDaysList = responseList[TFL_CONSTANT.dsSttNecKeyContractDates]
            if (contractResponseDaysList.length) {
                var responseDays = "";
                for (var i = 0; i < contractResponseDaysList.length; i++) {
                    if (contractResponseDaysList[i].Value2 == "14") {
                        responseDays = contractResponseDaysList[i].Value4;
                    }
                }
                $scope.oriMsgCustomFields['NCE_Reply_Days'] = responseDays;
                $scope.oriMsgCustomFields['NCE_Reply_Days_Backup'] = responseDays;
                var replyDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: responseDays
                });
                $scope.oriMsgCustomFields['Reply_Date'] = replyDate;
            }
            DS_STT_ALL_CONTRACT_TEAM_MEMBERS = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers];
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
        }


        /**
         * Initialize all form data on load
         */
        function initFormData() {
            $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
            if ($scope.oriMsgCustomFields['ContractNo']) {
                onContractChange();
            }
        }
        

        /**
         * @param {Integer} distNumber : it defines DS_AUTODISTRIBUTE value which require to send auto distribute
         * it will be 3 for OR and 13 for Respond 
         */
        function setDistributionNodeForPM(distNumber) {

            var actionStr = TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond;

            setAutoDistributeNode({
                autoDistFlag: distNumber,
                action: actionStr,
                days: $scope.oriMsgCustomFields['NCE_Reply_Days'],
                users: $scope.oriMsgCustomFields['TFL_Representative'].split('|')[2].trim()
            });
        }

        function setForInfoDistributionNodeForContractor() {
            var tmpUserID = commonApi._.filter(dsProjUserRole, function (obj) {
                return obj.Value.indexOf($scope.oriMsgCustomFields.Originator_Id) > -1;
            })[0];

            tmpUserID = tmpUserID.Value && tmpUserID.Value.split('|')[2].trim();
            if (tmpUserID) {
                tmpUserID = tmpUserID.split('#');
                setAutoDistributeNode({
                    action: TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation,
                    autoDistFlag: TFL_CONSTANT.resDistNumb,
                    days: $scope.oriMsgCustomFields['NCE_Reply_Days'],
                    users: tmpUserID[0].trim() + "#" + tmpUserID[1].trim()
                });
            }
        }         

        /**
         * 
         * @param {String} param.action : pass action name like For Information/Respond
         * @param {Interger} param.days : pass days in number which indicates due date
         * @param {String} param.user : set User id which you want to send action
         * @param {Interger} param.autoDistFlag : this flag vary distribution ORI and RES view
         */
        function setAutoDistributeNode(param) {
            var actionStr = param.action;
            var days = param.days;
            var users = param.users;
            var autoDistFlag = param.autoDistFlag

            var distDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days: days
            });

            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: users,
                    strAction: actionStr,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: autoDistFlag
            });
        }
        /**
        * @param {Integer} strAction : this function checks if user has pending action based on parameter
        * it will return 0 if user have perticular action other wise return blank
        */
        function filterdata(strAction) {
            var strFlag = "";
            var actionObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                return val.Name == strAction;
            });
            if (actionObj.length) {
                if (actionObj[0].Value.indexOf("|" + dsWorkingUserId + "|") > -1) {
                    strFlag = "0";
                }
            }
            return strFlag;
        }

        function setEwnData() {
            var ewnRef = $scope.oriMsgCustomFields.DS_STT_NEC_ALL_EWN;
            if (ewnRef) {
                var ewnAppId = ewnRef.split('|')[4].trim();
                var statusIds = $scope.getFormStatus({
                    spName: TFL_CONSTANT.dsAllActiveWsStatus,
                    status: TFL_CONSTANT.Closed
                });
                if (statusIds) {
                    $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = ewnAppId;
                    $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = statusIds.split('#')[0].trim();
                }
            }
        }

        $window.pcnFinalCallBack = function () {
            var statusIdWithdrawn = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.Withdrawn
            });

            var statusIdSubToICA = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.subjectToICA
            });
            
            if (currentViewName == "ORI_VIEW") {

                if (!$scope.formCustomFields.DSI_CREATE_FWD_RES.Can_Forward) {
                    alert("You are not permitted to edit this form, please cancel this process and use the Distribute option to forward to additional recipients.");
                    return true;
                }
                if ($scope.oriMsgCustomFields['TFL_Representative']) {
                    setDistributionNodeForPM(TFL_CONSTANT.oriDistNumb);
                }
                var strQuaEvent = $scope.oriMsgCustomFields.qualifyingEvent;
                var strRelEvent = $scope.oriMsgCustomFields.reliefEvent;
                var strComEvent = $scope.oriMsgCustomFields.compensationEvent;
                if (strRelEvent && !strQuaEvent && !strComEvent) {
                    $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users[0].DS_FORMACTIONS = TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation;
                }
                setEwnData();
            }
            if (currentViewName == "RES_VIEW") {
                $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                if (!$scope.formCustomFields.DSI_CREATE_FWD_RES.DSI_Can_Reply) {
                    alert("You are not authorised to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.");
                    return true;
                }
                if($scope.oriMsgCustomFields.furtherActionResponse == "Further information is required (Clause 26.1(b)(ii)"){
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = "Yes";
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdSubToICA;
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdWithdrawn;
                }
                setForInfoDistributionNodeForContractor();
            }
            return false;
        }

    };
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pcnFinalCallBack !== "undefined") {
        return pcnFinalCallBack();
    }
}