
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
    'use strict';

    function FormController($scope, $element, $controller, $window, $timeout) {
        var ctrl = this;        
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');    
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null") {
            $scope.projectId = window.currProjId;
        }

        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        $element.addClass('loaded');

        // constant Strings
        var PARENT_NO_MSG = '"Parent Id" should be less than Current "Index Id"',
            DELETE_NODE_REFERENCE_AFFECT_MSG = "Deleting this row may affect it's all references",
            DUPLICATE_VALUE_FIELDS_MSG = "Duplicate value 'fieldValue' entered in 'fieldName'.\nIt is available in any other Row.\nPlease check for Already created data by Search.";

        var ORI_MSG_Custom_Fields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"],
            Asite_System_Data_Read_Only = $scope.data['myFields']['Asite_System_Data_Read_Only'],
            currentViewName = window.currentViewName,
            InsertMasterInitArray = {
                'sectionsSetup': {
                    'autoId': '',
                    'sequenceId': '',
                    'formTypeIds': '',
                    'sectionId': '',
                    'sectionDescription': '',
                    'sectionParentId': '',
                    'additionalMetaDataValue': [],
                    'hierarchySequenceId': '',
                    'hierarcyStructure': {},
                    'isChildFormHide': false,
                    'isDisplayIdHide': false, 
                    'isHeaderRow' : false,
                    'isMultipleRemove': false,
                    'isDbSearchResult': false,
                    'isDeleteSection': false
                },
                'additionalMetaDataValue': {
                    'metaDataId': '',
                    'metaDataLable': '',
                    'metaDataValue': '',
                    'isDeleteMetaData': false
                },
                'additionalMetaDataSetup': {
                    'metaDataSetupId': '',
                    'metaDataSetupLable': '',
                    'isMultipleRemove': false,
                    'isDbSearchResult': false,
                    'isDeleteMetaData': false,
                    'autoGenId': ''
                }
            },
            deleteFlagJsonKeyMap = {
                'additionalMetaDataSetup' : 'isDeleteMetaData',
                'sectionsSetup' : 'isDeleteSection'
            };

        $scope.ORI_MSG_Custom_Fields = ORI_MSG_Custom_Fields;
        $scope.isXHRon = false;
        $scope.isMetaData = $scope.ORI_MSG_Custom_Fields['isMetaData'] || false;
        $scope.isSectionSetupOpen = true;
        $scope.isSubSectionHieSetupOpen = false;
        $scope.isSearchSectionOpen = false;
        $scope.isSectionRowBlank = false;
        $scope.isSubSectionRowBlank = false;
        $scope.blankFieldName = "";
        $scope.subSectionBlankFieldName = "";
        $scope.lastIndex = parseInt($scope.ORI_MSG_Custom_Fields['lastIndex']) || 0;
        $scope.lastMetaIndex = parseInt($scope.ORI_MSG_Custom_Fields['lastMetaIndex']) || 0;
        $scope.workspaceName = Asite_System_Data_Read_Only['_3_Project_Data']['DS_PROJECTNAME'];
        $scope.isDSFormId = (Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID']!='');
        $scope.isEditORI = ($scope.isDSFormId && (Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT'] == 'NO'));
        $scope.editORIMsg = false;
        $scope.readOnly = false;
        $scope.bulkApplyText = "";
        $scope.showMetaSecInEditORI = ($scope.isDSFormId && !ORI_MSG_Custom_Fields.isMetaData && ORI_MSG_Custom_Fields.additionalMetaDataSetup.length < 2 && (!ORI_MSG_Custom_Fields.additionalMetaDataSetup[0].autoGenId || (!ORI_MSG_Custom_Fields.additionalMetaDataSetup[0].metaDataSetupId && !ORI_MSG_Custom_Fields.additionalMetaDataSetup[0].metaDataSetupLable)));
        $scope.item = {
            additionalMetaDataValue: [],
            index: '',
            isBulkApply : false
        };
        $scope.jsonAvailableData = {
            sectionsSetup : [],
            additionalMetaDataSetup : [],
            lastIndex : 0,
            lastMetaIndex : 0
        };
        $scope.searchQueryObj = {
            'indexId': '',
            'displayId': '',
            'orderId': '',
            'description': '',
            'formTypeId':'',
            'parentId':''
        };
        $scope.fieldName = '';
        $scope.fieldValue = '';
        $scope.deletedMetaDataIndex = [];
        $scope.deletedSectionSequenceId = [];

        var takeJsonDataOnLoad = function() {
            $scope.jsonAvailableData.sectionsSetup = $scope.ORI_MSG_Custom_Fields.sectionsSetup;
            $scope.jsonAvailableData.additionalMetaDataSetup = $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup;
            $scope.jsonAvailableData.lastIndex = parseInt($scope.ORI_MSG_Custom_Fields.lastIndex);   
            $scope.jsonAvailableData.lastMetaIndex = parseInt($scope.ORI_MSG_Custom_Fields.lastMetaIndex);   
        };
        
        var flushOutJsonDataForEditORI = function() {
            $scope.resetSearchCriteria(null, true);            
            $scope.editORIMsg = true;
        };
        
        $scope.isScrollBar = function () {
            var divTable= angular.element('#level-setup-table>tbody'), // need real DOM Node, not jQuery wrapper
                hasVerticalScrollbar= (divTable[0].scrollHeight>divTable[0].clientHeight+5);
                
            return hasVerticalScrollbar;
        };
        
        $scope.isSetPosRel = function() {
            return (angular.element("#level-setup-table>tbody")[0].offsetHeight > 250);
        };

        $scope.setFocusToLastAddedElement = function(tableId){
            $timeout(function () {
                angular.element('#'+tableId+'>tbody>tr:last input').last().focus();                
            }, 50);           
        };

        $scope.onLoadActivities = function () {
            // get Back First that will help to validate things.            
            takeJsonDataOnLoad();
            if ($scope.ORI_MSG_Custom_Fields['sectionsSetup'].length && $scope.ORI_MSG_Custom_Fields['sectionsSetup'][0].sequenceId === '') {
                $scope.lastIndex = 1;
                $scope.ORI_MSG_Custom_Fields['sectionsSetup'][0].sequenceId = $scope.lastIndex;
            }
            $scope.readOnly = (currentViewName === 'ORI_PRINT_VIEW');
            $scope.isSubSectionHieSetupOpen = $scope.ORI_MSG_Custom_Fields.isMetaData;           
            $scope.isSearchSectionOpen = ($scope.ORI_MSG_Custom_Fields.isMetaData && $scope.isEditORI) || $scope.readOnly;
            $scope.isEditORI && !$scope.readOnly && flushOutJsonDataForEditORI();
            // set Data from the Db
            $scope.readOnly && $scope.resetSearchCriteria(null, false);
            $timeout(function(){
                $scope.expandTextAreaOnLoad();                
                $scope.setFocusToLastAddedElement('meta-data-setup-table');
                $scope.setFocusToLastAddedElement('level-setup-table');
            }, 100);
        };

        ctrl.$onInit = function() {
            $scope.onLoadActivities();
        };


        $scope.enableMetaDataSection = function () {
            $timeout(function(){
                $scope.setFlag('isSubSectionHieSetupOpen');
            }, 50);
            $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'] = [];
            $scope.insertNewItems('additionalMetaDataSetup', false);
            if (!$scope.ORI_MSG_Custom_Fields.isMetaData) {
                resetMetaDataList();
            }
        };

        var resetMetaDataList = function () {
            for (var t = 0; t < $scope.ORI_MSG_Custom_Fields.sectionsSetup.length; t++) {
                $scope.ORI_MSG_Custom_Fields.sectionsSetup[t].additionalMetaDataValue = [];
            }
        };

        $scope.insertNewItems = function (valueFor, isMaintainIndex) {
            var setUpObj = $scope.ORI_MSG_Custom_Fields[valueFor];
            var item = angular.copy(InsertMasterInitArray[valueFor]);
            
            autoSequenceId(valueFor, item);
            if (isMaintainIndex) {
                // Add Additional Meta Data Obj to the latest added Setup Obj.
                for(var t=0; t<$scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'].length; t++) {
                    var addMetaObj = angular.copy(InsertMasterInitArray['additionalMetaDataValue']);
                    addMetaObj.metaDataId = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'][t].metaDataSetupId;
                    addMetaObj.metaDataLable = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'][t].metaDataSetupLable;
                    addMetaObj.isDeleteMetaData = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'][t].isDeleteMetaData;
                    addMetaObj.autoGenId = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'][t].autoGenId;
                    item['additionalMetaDataValue'].push(addMetaObj);
                }
            } 
            //Add item in items
            $scope.addRepeatingRow(setUpObj, item);            

            if(!isMaintainIndex) {                
                // Add Additional Meta Data Obj to the latest added Setup Obj.
                for (var s=0; s<$scope.ORI_MSG_Custom_Fields['sectionsSetup'].length; s++) {  
                    var sectionObj = $scope.ORI_MSG_Custom_Fields['sectionsSetup'][s];
                    for(var t=0; t<$scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'].length; t++) {
                        var addMetaListObj = sectionObj.additionalMetaDataValue[t],
                            metaListObj = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'][t];

                        if((!sectionObj.additionalMetaDataValue.length || !addMetaListObj ) && (!metaListObj.isDeleteMetaData)) {
                            var existedMetaList = sectionObj.additionalMetaDataValue.filter(function(obj){
                                return obj.autoGenId == metaListObj.autoGenId && obj.metaDataId == metaListObj.metaDataSetupId;
                            });

                            if(!existedMetaList.length) {                               
                                var addMetaObj = angular.copy(InsertMasterInitArray['additionalMetaDataValue']);
                                addMetaObj.metaDataId = metaListObj.metaDataSetupId;
                                addMetaObj.metaDataLable = metaListObj.metaDataSetupLable;                            
                                addMetaObj.isDeleteMetaData = metaListObj.isDeleteMetaData;  
                                addMetaObj.autoGenId = metaListObj.autoGenId;                        
                                sectionObj['additionalMetaDataValue'].push(addMetaObj);                                
                            }
                        }
                    }
                }
            }  

            return item;
        };

        /**
         * function to create Auto Sequence Id and maintaining last available Index.
         */

        var autoSequenceId = function (valueFor, item) {
            if(valueFor == 'sectionsSetup'){
                $scope.lastIndex =  parseInt($scope.lastIndex) + 1;
                item.sequenceId = $scope.lastIndex;
            } else if (valueFor == 'additionalMetaDataSetup') {
                $scope.lastMetaIndex =  parseInt($scope.lastMetaIndex) + 1;
                item.autoGenId = $scope.lastMetaIndex;
            }

        };
        
        /*
        *   function is to validate Parent Id not greater than or equal with sequence(Index Id).
        */

        $scope.validateCurrentIndex = function (event, sectionsSetup, whichField) {
            // truncating Leading Zeros from input.
            sectionsSetup.sectionId && (sectionsSetup.sectionId = parseInt(sectionsSetup.sectionId));
            sectionsSetup.sectionParentId && (sectionsSetup.sectionParentId = parseInt(sectionsSetup.sectionParentId));
            if(whichField === 'sectionParentId' && sectionsSetup.sectionParentId == 0) {
                sectionsSetup.isChildFormHide = false;
                sectionsSetup.isDisplayIdHide = false;
                sectionsSetup.isHeaderRow = false;
            }

            if(whichField === 'sectionParentId' && (sectionsSetup.sectionParentId >= sectionsSetup.sequenceId)) {
                alert(PARENT_NO_MSG);
                // blank out section parent Id on blur.
                sectionsSetup.sectionParentId = '';
                sectionsSetup.isChildFormHide = false;
                sectionsSetup.isDisplayIdHide = false;
                sectionsSetup.isHeaderRow = false;
                sectionsSetup.autoId = sectionsSetup.sectionId;
                event.preventDefault();                
            } else if(sectionsSetup.sectionParentId < sectionsSetup.sequenceId && $scope.deletedSectionSequenceId.indexOf(sectionsSetup.sectionParentId)>-1) {     
                sectionsSetup.sectionParentId = '';
                sectionsSetup.isChildFormHide = false;
                sectionsSetup.isDisplayIdHide = false;
                sectionsSetup.isHeaderRow = false;
                sectionsSetup.autoId = '';
                alert('Parent Node you have entered is not available. Please fill this field from available nodes.'); 
                event.preventDefault();
            }
            $scope.updateAutoIds(sectionsSetup);
        };

        /*
         * below group of functions are for the 'Auto Id' field.
         */

        $scope.updateAutoIds = function (sectionsSetup) {                  
            updateAutoIds(sectionsSetup);
            updateAutoIdsHie(sectionsSetup);           
        };

        var updateAutoIds = function (sectionsSetup) {         
            if(sectionsSetup.sectionParentId == 0){
                sectionsSetup.autoId = sectionsSetup.sectionId;
            } else {
                var rootParent = $scope.findRootParent(sectionsSetup),
                    rootParentId = rootParent.autoHId;
                if(rootParentId && sectionsSetup.sectionId > -1){
                    sectionsSetup.autoId = rootParentId + '.' + sectionsSetup.sectionId;                    
                } else {
                    sectionsSetup.autoId = sectionsSetup.sectionId;
                }
            }
        };       

        var updateAutoIdsHie =function(sectionsSetup) {   
            var heirarchyList = getHierarchyList('sectionsSetup', sectionsSetup, true, false);
            for(var k=0; k<heirarchyList.length; k++) {
                for(var j=0; j<$scope.ORI_MSG_Custom_Fields['sectionsSetup'].length; j++) {                    
                    if(sectionsSetup.sequenceId != $scope.ORI_MSG_Custom_Fields['sectionsSetup'][j].sequenceId && $scope.ORI_MSG_Custom_Fields['sectionsSetup'][j].sequenceId == heirarchyList[k].sequenceId) {
                        updateAutoIds($scope.ORI_MSG_Custom_Fields['sectionsSetup'][j]);                        
                    }                    
                }
                // changing in other back up nodes aswell.
                for(var l=0; l<$scope.jsonAvailableData.sectionsSetup.length; l++) {                    
                    if(sectionsSetup.sequenceId != $scope.jsonAvailableData.sectionsSetup[l].sequenceId && $scope.jsonAvailableData.sectionsSetup[l].sequenceId == heirarchyList[k].sequenceId) {
                        updateAutoIds($scope.jsonAvailableData.sectionsSetup[l]);
                    }                    
                }
            }
        };

        $scope.findRootParent = function(sectionsSetup) {
            var autoHId = sectionsSetup.sectionParentId,
                isRootFounded = false;
            for (var t=0; t<$scope.ORI_MSG_Custom_Fields['sectionsSetup'].length; t++) {
                var item = $scope.ORI_MSG_Custom_Fields['sectionsSetup'][t];
                if(sectionsSetup.sectionId > -1 && sectionsSetup.sectionParentId > -1 && (sectionsSetup.sectionParentId == item.sequenceId)) {
                    autoHId = item.autoId;
                    isRootFounded = true;
                    break;
                }
            }

            if(!isRootFounded) {
                for (var t=0; t<$scope.jsonAvailableData.sectionsSetup.length; t++) {
                    var item = $scope.jsonAvailableData.sectionsSetup[t];
                    if(sectionsSetup.sectionId > -1 && sectionsSetup.sectionParentId > -1 && (sectionsSetup.sectionParentId == item.sequenceId) && !item.isDeleteSection) {
                        autoHId = item.autoId;
                    }
                }
            }

            return {
                autoHId : autoHId,
                isRootFounded : isRootFounded
            };
        };

        /**
         * below function is for maintaining 'ID' - 'sequenceId' on delete.
         */

        $scope.updateIndexOnDelete = function (valueFor, removedIndex) {
            if($scope.ORI_MSG_Custom_Fields[valueFor].length == 0){
                $scope.lastIndex = 0;
                return false;
            }

            for(var i=removedIndex; i<$scope.ORI_MSG_Custom_Fields[valueFor].length; i++){
                var lastObjSeqId = i > 0 ? $scope.ORI_MSG_Custom_Fields[valueFor][i-1].sequenceId : 0;
                $scope.lastIndex =  parseInt(lastObjSeqId) + 1;
                $scope.ORI_MSG_Custom_Fields[valueFor][i].sequenceId = $scope.lastIndex;
            }
        };

        /**
         * Group of Functions to delete item row wise for Normal and EditORI cases.
         */

        $scope.deleteItems = function (valueFor, index, isMaintainIndex, currentObj) {
            var isConfirm = true;

            if(valueFor == 'sectionsSetup'){
                isConfirm = confirm(DELETE_NODE_REFERENCE_AFFECT_MSG);
            }

            if(isConfirm){
                var isForEdit = false;
                if($scope.isEditORI){
                    isForEdit = (isMaintainIndex && currentObj.isDbSearchResult && $scope.ORI_MSG_Custom_Fields.sectionsSetup[index].sequenceId <= $scope.jsonAvailableData.lastIndex);
                    if(isForEdit){
                        editOriDeleteItems(valueFor, currentObj, isForEdit);
                    } else if (valueFor == 'additionalMetaDataSetup') {
                        if(parseInt(currentObj.autoGenId) <= $scope.jsonAvailableData.lastMetaIndex) {
                            currentObj.isDeleteMetaData = true;
                            $scope.deletedMetaDataIndex.push(parseInt(currentObj.metaDataSetupId));
                            for(var b=0; b<$scope.ORI_MSG_Custom_Fields.sectionsSetup.length; b++) {
                                var listLength = $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue.length;
                                for (var m=0; m<listLength; m++) {
                                    if($scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue[m].autoGenId == currentObj.autoGenId && $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue[m].metaDataId == currentObj.metaDataSetupId){
                                        $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue[m].isDeleteMetaData = currentObj.isDeleteMetaData;
                                    }
                                }
                            }
                            for(var b=0; b<$scope.jsonAvailableData.sectionsSetup.length; b++) {
                                var listLength = $scope.jsonAvailableData.sectionsSetup[b].additionalMetaDataValue.length;
                                for (var m=0; m<listLength; m++) {
                                    if($scope.jsonAvailableData.sectionsSetup[b].additionalMetaDataValue[m].autoGenId == currentObj.autoGenId && $scope.jsonAvailableData.sectionsSetup[b].additionalMetaDataValue[m].metaDataId == currentObj.metaDataSetupId){
                                        $scope.jsonAvailableData.sectionsSetup[b].additionalMetaDataValue[m].isDeleteMetaData = currentObj.isDeleteMetaData;
                                    }
                                }
                            }
                        } else {
                            normalDeleteItems(valueFor, index, isMaintainIndex, currentObj, isForEdit); 
                        }
                    } else {
                        normalDeleteItems(valueFor, index, isMaintainIndex, currentObj, isForEdit);
                    }
                } else {
                    normalDeleteItems(valueFor, index, isMaintainIndex, currentObj, isForEdit);
                }
            }
        };

        var normalDeleteItems = function(valueFor, index, isMaintainIndex, currentObj, isForEdit) {           
            if(isMaintainIndex){                       
                findDelHierarchy(valueFor, currentObj, isForEdit);                
            } else {
                $scope.ORI_MSG_Custom_Fields[valueFor].splice(index, 1);
                for(var b=0; b<$scope.ORI_MSG_Custom_Fields.sectionsSetup.length; b++) {
                    $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue.length && $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue.splice(index, 1); 
                }
            }
        };

        var editOriDeleteItems = function(valueFor, currentObj, isForEdit) { 
            currentObj[deleteFlagJsonKeyMap[valueFor]] = currentObj.isDbSearchResult;
            findDelHierarchy(valueFor, currentObj, isForEdit); 
        };

        /**
         * Find all the Hierarchy nodes.
        */
        var getHierarchyList = function(valueFor, currentObj, isCurrObjInclude, isForDelete) {
            var tempObj = currentObj,
                heirarchyList = [],
                allSequences = [],
                directNodes = [], 
                directNewNodes = [],
                sequenceHie = {};

            if(isCurrObjInclude) {
                heirarchyList.push(tempObj),
                allSequences.push(tempObj.sequenceId+'');
            }

            for(var i=0; i<allSequences.length; i++) {

                directNewNodes = $scope.ORI_MSG_Custom_Fields[valueFor].filter( function(obj) {
                    return obj.sectionParentId == allSequences[i];
                });

                for(var k=0; k<directNewNodes.length; k++) {                       
                    if(allSequences.indexOf(directNewNodes[k].sequenceId+'')<0) {
                        allSequences.push(directNewNodes[k].sequenceId+'');
                        heirarchyList.push(directNewNodes[k]);
                    } else {
                        break;
                    }
                }

                if(!isForDelete) {
                    directNodes = $scope.jsonAvailableData[valueFor].filter( function(obj) {
                        return obj.sectionParentId == allSequences[i];
                    });
    
                    for(var j=0; j<directNodes.length; j++) {  
                        if(allSequences.indexOf(directNodes[j].sequenceId+'')<0) {
                            allSequences.push(directNodes[j].sequenceId+'');
                            heirarchyList.push(directNodes[j]);
                        } else {
                            break;
                        }
                    }
                }

                sequenceHie[allSequences[i]] = directNodes;        
            }                        
            return heirarchyList;
        };

        /**
         * Delete Founded Hierarchy List from main JSON.
        */

        var findDelHierarchy = function(valueFor, currentObj, isForEdit) {             
            var heirarchyList = getHierarchyList(valueFor, currentObj, true , true);
            // removing for the main Oject or set relevant delete flag for db.
            for(var k=0; k<heirarchyList.length; k++) {
                for(var j=0; j<$scope.ORI_MSG_Custom_Fields[valueFor].length; j++) {                    
                    if((typeof $scope.ORI_MSG_Custom_Fields[valueFor][j] != 'undefined' || typeof $scope.ORI_MSG_Custom_Fields[valueFor][j] != undefined ) && ($scope.ORI_MSG_Custom_Fields[valueFor][j].sequenceId == heirarchyList[k].sequenceId) && ($scope.ORI_MSG_Custom_Fields[valueFor][j].autoId == heirarchyList[k].autoId)) {
                        if(isForEdit && $scope.ORI_MSG_Custom_Fields[valueFor][j].isDbSearchResult) {                           
                            $scope.ORI_MSG_Custom_Fields[valueFor][j][deleteFlagJsonKeyMap[valueFor]] = $scope.ORI_MSG_Custom_Fields[valueFor][j].isDbSearchResult;
                            $scope.deletedSectionSequenceId.push(parseInt($scope.ORI_MSG_Custom_Fields[valueFor][j].sequenceId));
                        } else {
                            $scope.ORI_MSG_Custom_Fields[valueFor].splice(j,1);
                        }
                    }                    
                }
            }            
        };

        /**
         * Functiion will change the passed flag's status available in Scope.
         * Type : boolean
         * Accepts : flag name.
         */

        $scope.setFlag = function (flag) {
            $scope[flag] = !$scope[flag];
        };

        /**
         * Duplicate Record Existed check function.
         * 
         */

        var metaDuplicateCheck = function (sectionObj, rowObj, valueFor) {
            var isSameHashKey = (sectionObj.autoGenId != '' && rowObj.autoGenId != sectionObj.autoGenId),
                isSameMetaId = (rowObj.metaDataSetupId+'' !='' && sectionObj.metaDataSetupId+'' !='' && sectionObj.metaDataSetupId == parseInt(rowObj.metaDataSetupId)),
                isSameMetaLable = (rowObj.metaDataSetupLable && rowObj.metaDataSetupLable != '' && sectionObj.metaDataSetupLable && sectionObj.metaDataSetupLable.toLowerCase() == rowObj.metaDataSetupLable.toLowerCase()),
                isDuplicate = ( isSameHashKey && ( isSameMetaId || isSameMetaLable) && !sectionObj[deleteFlagJsonKeyMap[valueFor]]);
            if(isDuplicate){
                if(isSameMetaId) {
                    $scope.fieldName = 'Id';
                    $scope.fieldValue = rowObj.metaDataSetupId;
                    rowObj.metaDataSetupId = '';
                }

                if(isSameMetaLable) {
                    $scope.fieldName = 'Meta Data Label';
                    $scope.fieldValue = rowObj.metaDataSetupLable;
                    rowObj.metaDataSetupLable = '';
                }                       
                for(var b=0; b<$scope.ORI_MSG_Custom_Fields.sectionsSetup.length; b++) {
                    var listLength = $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue.length;
                    if(listLength){
                        $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue[listLength-1].metaDataId = rowObj.metaDataSetupId; 
                        $scope.ORI_MSG_Custom_Fields.sectionsSetup[b].additionalMetaDataValue[listLength-1].metaDataLable = rowObj.metaDataSetupLable; 
                    } 
                }
            }

            return isDuplicate;
        };

        $scope.checkDuplicateRecord = function(valueFor, rowObj){
            var isDuplicateRecord = false;
            if(valueFor === 'additionalMetaDataSetup'){
                rowObj.metaDataSetupId && (rowObj.metaDataSetupId = parseInt(rowObj.metaDataSetupId));
                isDuplicateRecord = $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup.length > 1 && $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup.some( function(sectionObj) {                    
                    return metaDuplicateCheck(sectionObj, rowObj, valueFor);
                });
                
                if(!isDuplicateRecord){
                    isDuplicateRecord = $scope.jsonAvailableData.additionalMetaDataSetup.some( function(sectionObj) {
                        return metaDuplicateCheck(sectionObj, rowObj, valueFor);
                    });
                }
            } 
                     
            if(isDuplicateRecord){
                alert(DUPLICATE_VALUE_FIELDS_MSG.replace("'fieldName'", '"'+ $scope.fieldName +'"').replace("'fieldValue'", '"'+ $scope.fieldValue +'"'));
            }
        };

        $scope.checkParentNodeExist = function(rowObj) {
            if(rowObj.sectionId && rowObj.sectionParentId){ 
                var isParentRowExist = true,
                    isParentFound = false,
                    parentNodeObj = {};

                if(rowObj.sectionId != '' && rowObj.sectionId != 0 && rowObj.sectionParentId != '' && rowObj.sectionParentId != 0){ 
                    if($scope.ORI_MSG_Custom_Fields.sectionsSetup.length > 1) {
                        for (var i=0; i<$scope.ORI_MSG_Custom_Fields.sectionsSetup.length; i++) {
                            var obj = $scope.ORI_MSG_Custom_Fields.sectionsSetup[i];
                            if(obj.sequenceId == rowObj.sectionParentId){
                                isParentRowExist = true;
                                isParentFound = true;
                                parentNodeObj = obj;
                                break;
                            } else {
                                isParentRowExist = false;
                            }
                        }
                    }
                    if(!isParentFound) {
                        for (var i=0; i<$scope.jsonAvailableData.sectionsSetup.length; i++) {
                            var obj = $scope.jsonAvailableData.sectionsSetup[i];
                            if((obj.sequenceId == rowObj.sectionParentId) && !obj.isDeleteSection){
                                isParentRowExist = true;
                                parentNodeObj = obj;
                                break;
                            } else {
                                isParentRowExist = false;
                            }
                        }
                    }
                }

                !angular.equals({}, parentNodeObj) && $scope.updateAutoIds(parentNodeObj);
                if(!isParentRowExist && angular.equals({}, parentNodeObj)) {
                    rowObj.sectionId = '';
                    rowObj.sectionParentId = '';
                    rowObj.autoId = '';
                    rowObj.isChildFormHide = false;
                    rowObj.isDisplayIdHide = false;
                    rowObj.isHeaderRow = false;
                    alert('Parent Node you have entered is not available. Please fill it from available nodes.'); 
                }   
            }     
        };
        
        /**
         * below function will maintain Meta Data Sections to communicate with Model and tooltip Hover area.
         */

        $scope.updateMetaDataSetup  = function(additionalMetaDataSetup, index) {            
            if($scope.ORI_MSG_Custom_Fields.sectionsSetup.length){                    
                for (var i = 0; i < $scope.ORI_MSG_Custom_Fields.sectionsSetup.length; i++) {
                    var sectionRowObj = $scope.ORI_MSG_Custom_Fields.sectionsSetup[i];
                    if(sectionRowObj.hasOwnProperty('additionalMetaDataValue')){
                        var existedObj = sectionRowObj['additionalMetaDataValue'].filter(function(tempObj){
                            return tempObj.autoGenId == additionalMetaDataSetup.autoGenId;
                        })[0],
                        existedIndex = sectionRowObj['additionalMetaDataValue'].indexOf(existedObj);
                        index = existedIndex > -1 ? existedIndex : index;
                        if(!sectionRowObj['additionalMetaDataValue'][index]){
                            sectionRowObj['additionalMetaDataValue'].push(angular.copy(InsertMasterInitArray['additionalMetaDataValue']));
                        }        
                        sectionRowObj['additionalMetaDataValue'][index].metaDataId = additionalMetaDataSetup.metaDataSetupId;
                        sectionRowObj['additionalMetaDataValue'][index].metaDataLable = additionalMetaDataSetup.metaDataSetupLable;
                        sectionRowObj['additionalMetaDataValue'][index].isDeleteMetaData = additionalMetaDataSetup.isDeleteMetaData;
                    }
                }
            }
        };

        /**
         * Group of Functions are to maintain the modal popup show, hide and it's data manipulation on update.
         */

        var putMetaDataObjInSectionSetup = function (additionalMetaDataValue, index) {
            if(additionalMetaDataValue && !additionalMetaDataValue.length) {
                for (var i = 0; i < $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup.length; i++) {
                    if(!$scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup[i].isDeleteMetaData) {
                        var obj = angular.copy(InsertMasterInitArray['additionalMetaDataValue']);
                        obj.metaDataId = $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup[i].metaDataSetupId;
                        obj.metaDataLable = $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup[i].metaDataSetupLable;
                        obj.autoGenId = $scope.ORI_MSG_Custom_Fields.additionalMetaDataSetup[i].autoGenId;
                        additionalMetaDataValue.push(obj);       
                    }
                }
            } 
            $scope.item.additionalMetaDataValue = additionalMetaDataValue;
            $scope.item.index = index;
        };

        $scope.openBulkAppluModel = function(event, isBulkApply) {            
            if(isBulkApply) {
                $scope.showModal('bulk-apply', null, null);
            }
        };

        $scope.bulkApply = function(operationFor){
            if(operationFor == 'append') {
                for(var i=0; i< $scope.item.sectionsSetup.length; i++) {
                    var obj = $scope.item.sectionsSetup[i];
                    if(!obj.formTypeIds || obj.formTypeIds == '') {
                        $scope.item.sectionsSetup[i].formTypeIds = $scope.item.bulkApplyText;
                    } else {
                        $scope.item.sectionsSetup[i].formTypeIds = obj.formTypeIds + ',' + $scope.item.bulkApplyText;
                    }
                }
            } else if(operationFor == 'apply') {
                for(var i=0; i< $scope.item.sectionsSetup.length; i++) {
                    var obj = $scope.item.sectionsSetup[i];
                    if(!obj.formTypeIds || obj.formTypeIds == '') {
                        $scope.item.sectionsSetup[i].formTypeIds = $scope.item.bulkApplyText;
                    }
                }   
            } else {
                for(var i=0; i< $scope.item.sectionsSetup.length; i++) {
                    $scope.item.sectionsSetup[i].formTypeIds = "";
                }
            }
        };

        $scope.showModal = function (id, additionalMetaDataValue, index) {
            if(id=='additional-meta-data') {
                putMetaDataObjInSectionSetup(additionalMetaDataValue, index);            
            } else {
                $scope.item.bulkApplyText = $scope.bulkApplyText;
                $scope.item.sectionsSetup = $scope.ORI_MSG_Custom_Fields.sectionsSetup;
            }
            ctrl.model.readOnly = true;
            ctrl.model.modelId = id;
        };

        $scope.hideModal = function () {
            $scope.backup.item = $scope.item;            
            if(ctrl.model.modelId=='additional-meta-data') {
                $scope.item = {
                    additionalMetaDataValue: [],
                    index: ''
                };                
            } else {
                $scope.item.isBulkApply = false;
                $scope.bulkApplyText = "";
            }
            ctrl.model.modelId = '';
        };

        $scope.updateModal = function () {
            $scope.hideModal();
        };

        ctrl.model = {
            modelId: "",
            showModal: $scope.showModal,
            update: $scope.updateModal,
            hideModal: $scope.hideModal,
            readOnly : $scope.readOnly
        };

        $scope.backup = {
            item: {
                additionalMetaDataValue: [],
                bulkApplyText : "",
                sectionsSetup : [],
                index: ''
            }
        };

        /**
         * Function will make an Ajax call on Search Button using 'searchQueryObj' available.        
         * 'DS_NNG_Setup_Filter' is called to get data from DB.
         * ARGUMENT SEQUENCE : indexId, displayId, orderId, description, formTypeId, parentId.      
         */

        $scope.makeSerachAjaxCall = function(event, isOnLoad) {  
            if($scope.searchQueryObj.description && $scope.searchQueryObj.description.length < 3){
                alert('Minimum 3 characters required in "Section Description" field to proceed your custom Search');                    
                return false;                
            }

            if($scope.searchQueryObj.formTypeId && $scope.searchQueryObj.formTypeId.length < 3){
                alert('Minimum 3 characters required in "Form Type Ids" field to proceed your custom Search');
                return false;                
            }
            
            var paramObj = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_NNG_Setup_Filter",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_NNG_Setup_Filter",
                        "fieldValue":   $scope.searchQueryObj.indexId       +'|'+
                                        $scope.searchQueryObj.displayId     +'|'+
                                        $scope.searchQueryObj.orderId       +'|'+
                                        $scope.searchQueryObj.description   +'|'+
                                        $scope.searchQueryObj.formTypeId    +'|'+
                                        $scope.searchQueryObj.parentId
                    }]
                }
            };

            $scope.isXHRon = true;
            $scope.getCallbackData(paramObj).then(function (response) {                
                var resData = response.data;
                if(resData){                    
                    var oldRecords = $scope.ORI_MSG_Custom_Fields['sectionsSetup'];
                    $scope.ORI_MSG_Custom_Fields['sectionsSetup'] = [];
                    $scope.lastIndex = $scope.jsonAvailableData.lastIndex;
                    if($scope.isMetaData) {
                        $scope.lastMetaIndex = $scope.jsonAvailableData.lastMetaIndex;                        
                    }
                    $scope.deletedSectionSequenceId = [];
                    var filteredData = angular.fromJson(response.data['DS_NNG_Setup_Filter']).Items.Item;                 
                    searchDataResponse({
                        oldRecords : oldRecords,
                        filteredData : filteredData,
                        isOnLoad : isOnLoad
                    });
                    $timeout(function () {
                        $scope.expandTextAreaOnLoad();
                        $scope.setFocusToLastAddedElement('level-setup-table');
                    },100);
                    $scope.isXHRon = false;
                }
            });
        };

        /**
         * Function will reset Search Criteria.         
         */

        $scope.resetSearchCriteria = function(event, isOnLoad) {
            $scope.searchQueryObj = {
                'indexId': '',
                'displayId': '',
                'orderId': '',
                'description': '',
                'formTypeId':'',
                'parentId':''
            };
            $scope.makeSerachAjaxCall(event, isOnLoad||false);
        };

        /**
         * Function to manage Search CAll Back Response and Showing Data. 
         * Result Set from DB Sequence Map
         * SequenceId(Value2), DisplayId(Value3), SectionId(Value4), SectionDescription(Value5), FormTypeIds(Value6), SectionParentId(Value7), MetaDataValue(Value 8), isChildFormHide(Value 9).
         */
        var searchDataResponse = function (paramObj) {            
            for(var i=0; i<paramObj.filteredData.length; i++) {
                var sectionItem = angular.copy(InsertMasterInitArray['sectionsSetup']);                
                var filteredDataObj = paramObj.filteredData[i];
                
                sectionItem.sequenceId = filteredDataObj.Value2;
                sectionItem.autoId = filteredDataObj.Value3;
                sectionItem.sectionId = filteredDataObj.Value4;
                sectionItem.sectionDescription = filteredDataObj.Value5;
                sectionItem.formTypeIds = filteredDataObj.Value6;
                sectionItem.sectionParentId = filteredDataObj.Value7;
                sectionItem.isDbSearchResult = true;                
                sectionItem.additionalMetaDataValue = createMetaDataList(filteredDataObj.Value8); 
                sectionItem.isChildFormHide = (filteredDataObj.Value9 == 'true');
                sectionItem.isDisplayIdHide = (filteredDataObj.Value10 == 'true');
                sectionItem.isHeaderRow = (filteredDataObj.Value11 == 'true');
                $scope.ORI_MSG_Custom_Fields['sectionsSetup'].push(sectionItem);
            }
            // get all data.
            if(paramObj.isOnLoad) {
                takeJsonDataOnLoad();
                $scope.ORI_MSG_Custom_Fields['sectionsSetup'] = [];
            }

        };

        /**       
         *  Function to create Meta Data Value Table Structure.'         
         *  String Seprators. Id, Lable, Value: '|@|' and New Meta Data: '$@$'.         
         */

        var createMetaDataList = function(metaDataStr){
            var metaDataList = metaDataStr.split('$@$'),
                metaDataListLen = metaDataList.length,
                additionalMetaDataSetupList = $scope.ORI_MSG_Custom_Fields['additionalMetaDataSetup'].filter(function(obj){
                    return !obj.isDeleteMetaData;
                }),
                additionalMetaDataSetupLen = additionalMetaDataSetupList.length,
                tempList = [],
                availableMetaIds = [];

            for(var k=0; k<additionalMetaDataSetupLen; k++) {
                var additionalMetaDataObj = additionalMetaDataSetupList[k];
                for(var h=0; h<metaDataListLen; h++) {
                    var metaItem = angular.copy(InsertMasterInitArray['additionalMetaDataValue']),
                        metaDataRow = metaDataList[h],
                        metaDataRowVal = metaDataRow.split('|@|'),
                        metaId = metaDataRowVal[0],
                        metaLabel = metaDataRowVal[1]; 

                    if(additionalMetaDataObj && additionalMetaDataObj.metaDataSetupId+'' && availableMetaIds.indexOf(additionalMetaDataObj.metaDataSetupId)<0) {
                        if(additionalMetaDataObj.metaDataSetupId == metaId && additionalMetaDataObj.metaDataSetupLable == metaLabel && $scope.deletedMetaDataIndex.indexOf(metaId) < 0) {
                            metaItem.metaDataId     = metaId;
                            metaItem.metaDataLable  = metaLabel;
                            metaItem.metaDataValue  = metaDataRowVal[2];
                            metaItem.autoGenId      = metaDataRowVal[3] && parseInt(metaDataRowVal[3]);
                            if($scope.deletedMetaDataIndex.indexOf(metaId) > -1) {
                                metaItem.isDeleteMetaData = true;
                            }
                            tempList.push(metaItem);
                            availableMetaIds.push(metaItem.metaDataId);
                            k++;
                            additionalMetaDataObj = additionalMetaDataSetupList[k];                            
                        } else if(!additionalMetaDataObj.isDeleteMetaData) {
                            metaItem.metaDataId     = additionalMetaDataObj.metaDataSetupId;
                            metaItem.metaDataLable  = additionalMetaDataObj.metaDataSetupLable;
                            metaItem.autoGenId  = additionalMetaDataObj.autoGenId;
                            tempList.push(metaItem);
                            availableMetaIds.push(metaItem.metaDataId);
                        }
                    }
                } 
            }

            return tempList;
        };

        /**
         * Function to handle final submit call.
         * wrote here to access the $scope variable to do Some data Manipulations.
         */

        $window.pickListFinalCallBack = function() {           
            $scope.ORI_MSG_Custom_Fields['lastIndex'] =  parseInt($scope.lastIndex);
            $scope.ORI_MSG_Custom_Fields['lastMetaIndex'] =  parseInt($scope.lastMetaIndex);
            $scope.data["myFields"]['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_DB_INSERT'] = 'true';
            return false;
        };

        /**
         * Handle on not allowing any characters in the text field
         * @param {event} e - paste
         */

        $scope.restrictCharOnlyNumber = function(event){
            var validKeys = [37,38,39,40,27,8,9,13,46,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,8,46,9,190]; 
            var inputVal = (event.which) ? event.which : event.keyCode;
            $scope.restrictChar(event, inputVal);
            if (validKeys.indexOf( inputVal ) == -1) {                 
                event.preventDefault();
            }            
        };       
    }
    return FormController;
});


/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof pickListFinalCallBack !== "undefined") {
        return pickListFinalCallBack();
    }
}
