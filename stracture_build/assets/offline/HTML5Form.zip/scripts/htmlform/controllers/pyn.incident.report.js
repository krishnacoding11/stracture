/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();
        if (tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.DS_Incident_Date == "-") {
            tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.DS_Incident_Date = "";
        }
        if (tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.Incident_Time == "-") {
            tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.Incident_Time = "";
        }
        if (tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.DS_Date_Reported == "-") {
            tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.DS_Date_Reported = "";
        }
        if (tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.Time_Reported == "-") {
            tempData.FORM_CUSTOM_FIELDS.DS_STEP1_FIELDS.Time_Reported = "";
        }
        $scope.data = {
            myFields: tempData
        };

        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.witnessStructure = {
            isSelected: false,
            Witness_Name: "",
            Witness_Contact_details: ""
        }

        $scope.DistributionStructure = {
            AutoDist_Id: "",
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }

        $scope.completeActionStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }

        $scope.autocreateStructure = {
            ACF_01_CREATED_BY: "",
            ACF_01_Date_Created: "",
            ACF_01_DS_CLOSE_DUE_DATE: "",
            ACF_01_DS_AUTODISTRIBUTE: "",
            ACF_01_DS_FORMCONTENT1: "",
            ACF_01_DS_FORMCONTENT2: "",
            ACF_01_DS_Logo_Link: "",
            ACF_01_DS_FORMTITLE: "",
            ACF_01_Task_Details: "",
            ACF_01_Task_Reference: "",
            ACF_01_Task_Type: "",
            ACF_01_Task_Ref_Id: "",
            ACF_01_Assigned_To: "",
            ACF_01_DS_WF_Next_Step: "",
            ACF_01_DS_ORG_PREFIX: "",
            ACF_01_DS_Logo: "",
            ACF_01_DS_Ref_AppId: "",
            ACF_01_Verification_Required: "Yes",
            ACF_01_DS_UniqueFormRef: "",
            ACF_01_DS_Task_Due_Days: "",
            ACF_01_isSelected: "",
            ACF_01_REPEATING_VALUES: {
                ACF_01_DS_AutoDistribute_User_Group: {
                    ACF_01_DS_AutoDistribute_Users: [{
                        ACF_01_DS_PROJDISTUSERS: "",
                        ACF_01_DS_FORMACTIONS: "",
                        ACF_01_DS_ACTIONDUEDATE: "",
                        ACF_01_DS_DUEDAYS: ""
                    }]
                }
            }
        }
        $scope.injuryStructure = {
            Name: "",
            Date_of_Birth: "",
            Occupation: "",
            Employer: "",
            Gender: "",
            Employment: "",
            Supervisor: "",
            First_aid_provided: "",
            First_aid_by: "",
            First_aid_details: "",
            Medical_aid_provided: "",
            Medical_aid_by: "",
            Medical_aid_details: "",
            Body_Location: "",
            Body_Location_Side: "",
            Nature_of_Injury: "",
            Mechanics_of_Injury: "",
            Agency_of_Injury: "",
            Injury_Outcome:""
        }

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });

        $scope.tableUtilSettings = {
            DS_All_Witnesses: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy($scope.witnessStructure),
                ADD_NEW_BEFORE_TIP: "Insert before Witness",
                ADD_NEW_AFTER_TIP: "Insert after Witness",
                deleteAllRowTooltip: "Remove all Witness",
                deleteCurrRowMsg: "Remove Witness",
                deleteSelectedMsg: "Remove selected Witnesses"
            },
            ACF_01_FORM: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: true,
                checkboxModelKey: "ACF_01_isSelected",
                newStaticObject: angular.copy($scope.autocreateStructure),
                ADD_NEW_BEFORE_TIP: "Insert before corrective action",
                ADD_NEW_AFTER_TIP: "Insert after corrective action",
                deleteAllRowTooltip: "Remove all corrective action",
                deleteCurrRowMsg: "Remove corrective action",
                deleteSelectedMsg: "Remove selected corrective actions"
            }
        }

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.ORI_MSG_Fields = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields;
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];

        $scope.dsAllStepFields = $scope.formCustomFields["DS_ALL_STEP_FIELDS"];
        $scope.dsStep1Fields = $scope.formCustomFields["DS_STEP1_FIELDS"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.ORI_MSG_Fields.DS_ISDRAFT;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
        $scope.DS_PYD_DSD_GET_ALL_TASK_DETAIL = $scope.getValueOfOnLoadData("DS_PYD_DSD_GET_ALL_TASK_DETAIL");
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var idpDateFormat = "dd/mm/yy",
        dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || idpDateFormat;
        if (currentViewName == "ORI_VIEW") {
            $scope.strCanReply = "";
            var tmpIncidentTypelist = [];
            var tmpBody_Locationlist = [];
            var tmpBody_Location_Sidelist = [];
            var tmpNature_of_Injurylist = [];
            var tmpMechanics_of_Injurylist = [];
            var tmpAgency_of_Injurylist = [];
            var tmpInjuryClassificationList = [];

            for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
                var element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === "Incident_Category") {
                    tmpIncidentTypelist.push(element);
                } else if (element.Value3 === "Incident_Body_Location") {
                    tmpBody_Locationlist.push(element);
                } else if (element.Value3 === "Incident_Body_Location_Side") {
                    tmpBody_Location_Sidelist.push(element);
                } else if (element.Value3 === "Incident_Nature_of_Injury") {
                    tmpNature_of_Injurylist.push(element);
                } else if (element.Value3 === "Incident_Mechanics_of_Injury") {
                    tmpMechanics_of_Injurylist.push(element);
                } else if (element.Value3 === "Incident_Agency_of_Injury") {
                    tmpAgency_of_Injurylist.push(element);
                } else if (element.Value3 === "Incident_Classification") {
                    tmpInjuryClassificationList.push(element);
                }
            }
            $scope.IncidentTypelist = tmpIncidentTypelist;
            $scope.Body_Locationlist = tmpBody_Locationlist;
            $scope.Body_Location_Sidelist = tmpBody_Location_Sidelist;
            $scope.Nature_of_Injurylist = tmpNature_of_Injurylist;
            $scope.Mechanics_of_Injurylist = tmpMechanics_of_Injurylist;
            $scope.Agency_of_Injurylist = tmpAgency_of_Injurylist;
            $scope.InjuryClassificationList = tmpInjuryClassificationList;

            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                $scope.strCanReply = "yes";
                if ($scope.strFormId == "") {
                    removeDashfromfields();
                }
            }

            if ($scope.strFormId && $scope.strIsDraft == "NO") {
                var userid = WorkingUserID['0'].Value.split('|')[0].trim();
                var actionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                    return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(userid) != -1
                });
                if (actionData && actionData.length) {
                    $scope.strCanReply = "yes";
                }


            }
        }
        $scope.update();

        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };

        $scope.dateRepotedValidation = function(parentNode, reportedDate, matchDate){
            if(reportedDate && matchDate){
                var reportedDateObj = commonApi.parseDate('yy-mm-dd', parentNode[ reportedDate ]);
                var matchDateObj = commonApi.parseDate('yy-mm-dd', parentNode[ matchDate ]);
                $scope.dsStep1Fields.Date_Reported = $scope.formatDate(new Date(reportedDateObj), 'dd/mm/yy');
                if( matchDateObj && reportedDateObj && matchDateObj.getTime() > reportedDateObj.getTime()) {
                    parentNode[ reportedDate ] = "";
                    $window.alert("Validation \n\n Date reported should be greater than Incident date.");
                }
            }
        }

        $scope.incidentTimeValidation = function(currFields){
            var formObj = $scope.myform;
            formObj['Incident_Time'].$setValidity('valid', true);
            formObj['Time_Reported'].$setValidity('valid', true);

            var dateOfIncident = $scope.dsStep1Fields['DS_Incident_Date'];
            var dateOfReported = $scope.dsStep1Fields['DS_Date_Reported'];

            var timeOfIncident = $scope.dsStep1Fields['Incident_Time'];
            var timeOfReported = $scope.dsStep1Fields['Time_Reported'];

            if(dateOfIncident && dateOfReported && dateOfIncident == dateOfReported && timeOfIncident && timeOfReported){
                var incDate = commonApi.parseDate('yy-mm-dd', dateOfIncident);
                var repDate = commonApi.parseDate('yy-mm-dd', dateOfReported);

                var incTime = get24HrDate(timeOfIncident);
                var repTime = get24HrDate(timeOfReported);
                
                var incDateParse = mergeTimeInDate(incDate, incTime);
                var repDateParse = mergeTimeInDate(repDate, repTime);
                
                if(incDateParse > repDateParse){
                    if(currFields){
                        formObj[currFields].$setValidity('valid', false);
                    }else{
                        formObj['Incident_Time'].$setValidity('valid', false);
                        formObj['Time_Reported'].$setValidity('valid', false);
                    }
                }
            }

        }

        function get24HrDate(strTime){
            var tmpTime = strTime.split(':');
            if(strTime.indexOf('PM') > -1 && tmpTime[0] < 12){
                tmpTime[0] = parseInt(tmpTime[0])+12;
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }else{
                tmpTime[1] = tmpTime[1].split(' ')[0];
                return tmpTime;
            }
        }

        function mergeTimeInDate(dateObj , timeArray){
            dateObj.setHours(timeArray[0]);
            dateObj.setMinutes(timeArray[1]);
            
            return dateObj;
        }

        function removeDashfromfields() {
            $scope.ORI_MSG_Fields.ORI_FORMTITLE = "";
            $scope.dsStep1Fields.Reported_To = "";
            $scope.dsStep1Fields.Location = "";
            $scope.dsStep1Fields.Task = "";
            $scope.dsStep1Fields.Primary_Category = "";
            $scope.dsStep1Fields.Secondary_Category = "";
            $scope.dsStep1Fields.Days_Lost = "";
            $scope.dsStep1Fields.DS_Initial_Classification = "";
            $scope.dsStep1Fields.Description = "";
            $scope.dsStep1Fields.Hazard_Identified_PRM_Plan = "";
            $scope.dsStep1Fields.Hazard_Identified_SWMS = "";
            $scope.dsStep1Fields.People_Trained = "";
            $scope.dsStep1Fields.SWMS_Followed = "";
            $scope.dsStep1Fields.People_Instructed = "";
            $scope.dsStep1Fields.Induction_Completed = "";
            $scope.dsStep1Fields.Immidiate_Actions = "";
            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
        }

        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var statudObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        function setAutoDistribution(strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistricution = angular.copy($scope.DistributionStructure)
            structDistricution.DS_PROJDISTUSERS = strUser;
            structDistricution.DS_FORMACTIONS = strAction;
            structDistricution.DS_ACTIONDUEDATE = strDueDate;

            $scope.formCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users.push(structDistricution);
        }

        function setRolewiseDistribution(strRole) {

            var strusers = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                return val.Value.toLowerCase().indexOf(strRole.toLowerCase()) != -1
            });

            if (strusers && strusers.length) {
                $scope.formCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
                for (var i = 0; i < strusers.length; i++) {
                    var strUser = strusers[i].Value.split('|');
                    var strUserId = strUser[2].split('#')[0].trim();
                    var strdisuser = commonApi._.filter($scope.DS_PROJDISTUSERS, function (val) {
                        return val.Value.indexOf(strUserId) != -1
                    });

                    if (strdisuser) {
                        $scope.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                        setAutoDistribution(strdisuser[0].Value, "2#", calculateDistDate(3));
                    }
                }
            }
        }

        function calculateDistDate(days) {
            var strDueDate = "";
            if (days) {
                var d = new Date($scope.todayDateDbFormat);
                d.setDate(d.getDate() + days);
                var month = d.getMonth() + 1;
                var day = d.getDate();
                var strDueDate = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' +
                    (day < 10 ? '0' : '') + day;
            }
            return strDueDate;
        }

        function clearAction() {
            if (DS_INCOMPLETE_ACTIONS && DS_INCOMPLETE_ACTIONS.length) {
                var actionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                    return val.Name == 'Assign Status';
                });
                if (actionData && actionData.length) {
                    var lstsplit = actionData[0].Value.split('|');
                    if (lstsplit.length > 2) {

                        $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                        $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                        var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                        var userid = WorkingUserID['0'].Value.split('|')[0].trim();
                        for (var i = 1; i < lstsplit.length - 1; i++) {
                            if (lstsplit[i] && lstsplit[i] != userid) {
                                var AutocompleteActionStructure = angular.copy($scope.completeActionStructure);
                                AutocompleteActionStructure.DS_MSG_AC_TYPE = "clear";
                                AutocompleteActionStructure.DS_MSG_AC_FORM = AppId;
                                AutocompleteActionStructure.DS_MSG_AC_MSG_TYPE = "ORI001";
                                AutocompleteActionStructure.DS_MSG_AC_USERID = lstsplit[i];
                                AutocompleteActionStructure.DS_MSG_AC_ACTION = "2";
                                AutocompleteActionStructure.DS_MSG_AC_ACTION_REMARKS = "clear actions";
                                insertpoint.push(AutocompleteActionStructure);
                            }
                        }
                    }
                }
            }
        }

        function setAutocreateNodes() {
            var allNodes = $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;
            if (allNodes && allNodes.length) {
                var userid = WorkingUserID['0'].Value.split('|')[0].trim();
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
                for (var i = 0; i < allNodes.length; i++) {
                    var strUser = allNodes[i].ACF_01_Assigned_To,
                        strAction = "3#Respond",
                        strDuedays = calculateDistDate(allNodes[i].ACF_01_DS_Task_Due_Days);

                    allNodes[i].ACF_01_CREATED_BY = userid;
                    allNodes[i].ACF_01_Date_Created = $scope.todayDateDbFormat;
                    allNodes[i].ACF_01_DS_CLOSE_DUE_DATE = strDuedays;
                    allNodes[i].ACF_01_DS_AUTODISTRIBUTE = "3";
                    allNodes[i].ACF_01_DS_FORMCONTENT1 = $scope.strFormId;
                    allNodes[i].ACF_01_DS_Ref_AppId = AppId;
                    allNodes[i].ACF_01_Task_Reference = $scope.strFormId;

                    var childNodes = allNodes[i].ACF_01_REPEATING_VALUES.ACF_01_DS_AutoDistribute_User_Group.ACF_01_DS_AutoDistribute_Users;
                    if (childNodes && childNodes.length) {
                        for (var j = 0; j < childNodes.length; j++) {
                            childNodes[j].ACF_01_DS_PROJDISTUSERS = strUser;
                            childNodes[j].ACF_01_DS_FORMACTIONS = strAction;
                            childNodes[j].ACF_01_DS_ACTIONDUEDATE = strDuedays;
                        }
                    }
                }
            }
        }

        $scope.restrictCharOnlyNumber = function () {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(RESTRICT_CHAR_MSG);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }

        }

        $window.pydIncidentFinalCallBack = function () {
            return $scope.checkMandatoryFields();
        }
        $scope.checkMandatoryFields = function () {
            if (!$scope.strCanReply) {
                alert("You are not authorized to Edit the form contact your Administrator");
                return true;
            }
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";

            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                var strFormStatusId = getFormStatusId("Raised");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                    setRolewiseDistribution("HSE Team");
                }
            }
            if ($scope.strFormId && $scope.strIsDraft == "NO") {
                if ($scope.DS_FORMSTATUS.toLowerCase() == "raised") {
                    var strFormStatusId = getFormStatusId("Investigation Completed");
                    if (strFormStatusId) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                        setRolewiseDistribution("HSE Manager");
                        clearAction();
                        setAutocreateNodes();
                    }
                }

                if ($scope.DS_FORMSTATUS.toLowerCase() == "investigation completed") {
                    var strFormStatusId = getFormStatusId("Closed");
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                    $scope.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "";
                    $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "";
                }
            }
            return false;
        }
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pydIncidentFinalCallBack !== "undefined") {
        return pydIncidentFinalCallBack();
    }
}