/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					freezedHeaderColScrollBind();
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');					
				}, 100);
			}
		});

		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');		
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');		
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');		
		$scope.isRespPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.isDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'] == 'YES');
		$scope.isFWDDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_FWD_MSG'] == 'YES');
		$scope.isRESDraft = ($scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES'] == 'YES');
		$scope.appMsgId = $scope.asiteSystemDataReadOnly['_6_Form_MSG_Data']['DS_MSGID'];
		$scope.formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
		
		// form's user interaction nodea starts here.
		$scope.rectificationWork = $scope.oriMsgCustomFields.rectificationWork;
		$scope.rectificationDetails = $scope.rectificationWork.rectificationDetails || [];

		// behave same if it is revised and resubmitted though it has been accepted before in workflow.
		$scope.isFormResubmit = $scope.formStatus === 'Revised and Resubmit';
		$scope.isFormAccepted = (($scope.formStatus === 'Accepted') || ($scope.isFormResubmit && $scope.rectificationWork.isAcceptedOnce));
		
		$scope.calculatedTotalAmounts = $scope.rectificationWork.calculatedTotalAmounts || {
			activityTotal: '',
			variationTotal: '',
			prelimsTotal: '',
			designFeesTotal: '',
			contingencyTotal: '',
			inflationTotal: '',
			nec4FeeTotal: '',
			ohSumTotal: '',
			targetCostTotal: '',
			targetVariationCostTotal : ''
		};

		$scope.measCalculatedTotalAmounts = $scope.rectificationWork.measCalculatedTotalAmounts || {
			measActivityTotal : '',
			measVariationTotal : '',
			measPrelimsTotal : '',
			measDesignFeesTotal : '',
			measContingencyTotal : '',
			measInflationTotal : '',
			measNec4FeeTotal : '',
			measOhSumTotal : '',
			measTargetCostTotal : '',
			measTargetVariationCostTotal : ''
		};

		$scope.rectificationDetails = $scope.rectificationWork.rectificationDetails;

		$scope.mapRoomsDetails = $scope.rectificationWork.mapRoomsDetails || [];
		$scope.roomListMap = [];

		$scope.isAllFieldsAvail = $scope.rectificationWork.isAllFieldsAvail || false;
		$scope.isShowTabled = $scope.rectificationWork.isShowTabled || false;
		$scope.xhr = {
			rectificationXhr : false
		};		

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			CONSTANTS_OBJ = {
				IMAGE_ASITE_DEFAULT_STR : '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR : 'images/htmlform/interserve/interserve-logo.png',
				QS_REF_LIST_KEY : 'qs-ref-list',
				QS_REF_LABEL : 'Qs Reference List',
				ROOM_NO_LIST_KEY : 'room-no-list',
				ROOM_NO_LABEL : 'Location\'s List',
				DIST_USER_LIST_KEY : 'dist-user-list',
				DIST_USER_LIST_LABEL : 'Role Users',
				BOQ_Details_by_QSref : 'DS_INS_BOQ_Details_by_QSref',
				PRICEDOCDETAIL_BY_QSREF : 'DS_INS_PRICEDOCDETAIL_BY_QSREF'
			},
			STATIC_OBJ = {
				rectDetails : {					
					rectGuid: '',
					isRectSelected : false,
					isRectShow : true,
					isRectDeleted : false,
					isRectHeader : false,
					rectificationCode: '',
					rectificationName: '',
					rectBoqQuantity : {
						boqQty: '',
						boqUom: '',
						boqRate: '',
						boqNetCost: '',
                        boqNetCostVariation : ''
					},
					rectMeasuredQuantity : {
						measuredQty: '',
						measuredUom: '',
						measuredRate: '',
						measuredTotal : '',
						measuredTotalVariation : ''
					},
					calculationDetails : {
						prelims : '',
						designFees : '',
						contingency : '',
						inflation : '',
						nec4Fee : '',
						ohSum : '',
						targetCost : '',
						targetVariationCost : ''
					},
					measCalculationDetails : {
                        measprelims: '' ,
                        measdesignFees: '' ,
                        meascontingency: '' ,
                        measinflation: '' ,
                        measnec4Fee: '' ,
                        measohSum: '' ,
                        meastargetCost: '' ,
                        meastargetVariationCost: ''
                    },
					customColumns : {
						
					}
				},
				roomDetails: {
					roomNo: "",
					'new': true
				}
			},
            FORMID = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] || '',			
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
			callBackResp = {},
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
			roomList = [];

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);

			$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
		});
		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		$scope.oriMsgCustomFields.isDefaultLogo = true;	
		
		$scope.tableUtilSettings = {
			rectDetails: {
				tooltip: "select to remove/remove all/Insert new BOQ data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRectSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore:0,
					deleteAllRow:0
				},
				newStaticObject: angular.copy(STATIC_OBJ.rectDetails),
				ADD_NEW_BEFORE_TIP: "Insert before BOQ Details",
				ADD_NEW_AFTER_TIP: "Insert after BOQ Details",
				deleteAllRowTooltip: "Remove all BOQ Details",
				deleteCurrRowMsg: "Remove BOQ Details",
				deleteSelectedMsg: "Remove selected BOQ Details",
				addItemCallBack: function () {},
				editRowCallBack: function () {},
				deleteItemCallBack: function () {}
			}
		};	
		
		var freezedHeaderColScrollBind = function(){		
			$timeout(function () {
				var objTableWrapper = $element.find('.table-wrapper'),
					objHeaderTR = $element.find('.headerTR th');

				objTableWrapper.bind('scroll', function(event){
					var objFixTds = $element.find('.freezeTd');
					objFixTds.css('left', ( event.target.scrollLeft )+ "px" );
					objHeaderTR.css('top' , ( event.target.scrollTop )+ "px");
				});
			},200);
		},	totalAmontKey = [
			'prelimsTotal',
			'designFeesTotal',
			'contingencyTotal',
			'inflationTotal',
			'nec4FeeTotal',
			'ohSumTotal',
			'targetCostTotal'
		],	amontKeys = [
			'prelims',
			'designFees',
			'contingency',
			'inflation',
			'nec4Fee',
			'ohSum',
			'targetCost'
		],	calculationsKeyMap = {
			boqQty : {
				nodeParent : 'rectBoqQuantity',
				total : 'boqNetCost',
				calcNode : 'calculationDetails',
				totalCalcNode : 'calculatedTotalAmounts',
				preFix : ''
			}, measuredQty : {
				nodeParent : 'rectMeasuredQuantity',
				total : 'measuredTotalVariation',
				//	total : 'measuredTotal',
				calcNode : 'measCalculationDetails',
				totalCalcNode : 'measCalculatedTotalAmounts',
				preFix : 'meas'
			}
		},	calculateIndividualTotal = function (calcFor) {
			for(var k=0; k<amontKeys.length; k++) {				
				var currObjKey = calculationsKeyMap[calcFor]['totalCalcNode'],
					currRowPropKey = calculationsKeyMap[calcFor]['preFix'] + amontKeys[k],
					currTotalAmontKey = calcFor == 'measuredQty' ? totalAmontKey[k].charAt(0).toUpperCase() + totalAmontKey[k].slice(1) : totalAmontKey[k],
					currPropertyKey = calculationsKeyMap[calcFor]['preFix'] + currTotalAmontKey;
				
				//  reset key total first.
				$scope[currObjKey][currPropertyKey] = 0;
				for(var i=0; i< $scope.rectificationDetails.length; i++) {
					if(!$scope.rectificationDetails[i].isRectHeader) {					
						$scope[currObjKey][currPropertyKey] = (parseFloat($scope[currObjKey][currPropertyKey]) || 0) + (parseFloat($scope.rectificationDetails[i][calculationsKeyMap[calcFor]['calcNode']][currRowPropKey]) || 0) ;
						$scope[currObjKey][currPropertyKey] = $scope[currObjKey][currPropertyKey].toFixed(2);

					}
				}
			}
		},	calculateAllTotal = function () {			
			$scope.rectificationWork.targetVariCost = (parseFloat($scope.calculatedTotalAmounts.targetCostTotal || 0) + parseFloat($scope.measCalculatedTotalAmounts.measTargetCostTotal || 0));
			$scope.rectificationWork.targetVariCost = $scope.rectificationWork.targetVariCost.toFixed(2);
		}, 	calcPrelims = function (tempObj, calcFor, totalKey) {
			// =Y24*$AN$14
			var prelims = parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']])*parseFloat($scope.rectificationWork.activityOverHead.prelimnaries/100);			
			return prelims.toFixed(2);
		}, 	calcDesignFees = function (tempObj , calcFor, totalKey) {
			// =(AH24+Y24)*$AN$15
			var designFees = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]))*parseFloat($scope.rectificationWork.activityOverHead.profDesignFees/100);
			return designFees.toFixed(2);
		}, 	calcContingency = function (tempObj, calcFor, totalKey) {
			// =((AI24+AH24+Y24)*$AN$16)
			var contingency = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]))* parseFloat($scope.rectificationWork.activityOverHead.contingency/100);
			return contingency.toFixed(2);
		}, 	calcInflation = function (tempObj, calcFor, totalKey) {
			// =((AI24+AH24+Y24)*$AN$17)
			var inflation = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']])) * parseFloat($scope.rectificationWork.activityOverHead.inflation/100);
			return inflation.toFixed(2);
		}, 	calcNec4Fee = function (tempObj, calcFor, totalKey) {
			// =((AH24+AI24+Y24+AK24)*$AN$18)
			var nec4Fee = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'inflation'])) * parseFloat($scope.rectificationWork.activityOverHead.NEC4basedFee/100);
			return nec4Fee.toFixed(2);
		}, 	calcOhSum = function (tempObj, calcFor, totalKey) {
			// =SUM(AH24:AL24)
			var ohSum = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'prelims']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'designFees']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'contingency']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'inflation']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'nec4Fee']));
			return ohSum.toFixed(2);
		}, 	calcTargetCost = function (tempObj, calcFor, totalKey) {
			// =AM24+Y24
			var targetCost = (parseFloat(tempObj[calculationsKeyMap[calcFor]['calcNode']][calculationsKeyMap[calcFor]['preFix'] + 'ohSum']) + parseFloat(tempObj[calculationsKeyMap[calcFor]['nodeParent']][calculationsKeyMap[calcFor]['total']]));
			return targetCost.toFixed(2);
		}, 	calcTargetVariationCost = function (tempObj, calcFor, totalKey) {
			// calculatedTotalAmounts.targetVariationCostTotal
			return;
		}, 	setActivityHeadDataOnResp = function (respData) {
			if(!respData) {
				return;
			}

			$scope.rectificationWork.activityOverHead.prelimnaries = respData.Value4;
			$scope.rectificationWork.activityOverHead.profDesignFees = respData.Value3;
			$scope.rectificationWork.activityOverHead.NEC4basedFee = respData.Value5;
			$scope.rectificationWork.activityDesc = respData.Value16;
			$scope.rectificationWork.genScopeOfWork = respData.Value17;
			$scope.rectificationWork.refDocDesc = respData.Value18;

			$scope.isAlreadyCreated = !!respData.Value15;
			if($scope.isAlreadyCreated) {
				$scope.rectificationWork.qsRef = '';
				$scope.rectificationWork.rectificationWork = '';
				$scope.qsRefList = structureItemList(CONSTANTS_OBJ.QS_REF_LIST_KEY, $scope.getValueOfOnLoadData('DS_INS_QSREFLIST'));
			}
			$scope.rectificationWork.formType = respData.Value14;
			if(respData.Value14 === "Rectification") {
				$scope.rectificationWork.formTitle = "Schedule 6. Rectification Work.";                
				$scope.rectificationWork.tableColumnHeader = "Rectification (Contractor pricing detail)";
				
			} else if(respData.Value14 === "Enhancement") {
				$scope.rectificationWork.formTitle = "Schedule 7. Enhancement Work.";
                $scope.rectificationWork.tableColumnHeader = "Enhancements (Contractor pricing detail)";
			}
		},	setBOQDataOnResp = function (respData) {			
			var tempList = [],
				respDataObj = {},
				priceDetailResp = callBackResp[CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF];
			for (var i = 0; i < respData.length; i++) {
				var tempObj = angular.copy(STATIC_OBJ.rectDetails);
				respDataObj = respData[i];

				tempObj.rectGuid = respDataObj.Value7;
				tempObj.rectificationCode = respDataObj.Value1;
				tempObj.isRectHeader = !respDataObj.Value1;
				tempObj.rectificationName = respDataObj.Value2;
				tempObj.rectBoqQuantity.boqQty = respDataObj.Value3;
				tempObj.rectBoqQuantity.boqUom = respDataObj.Value4;
				tempObj.rectBoqQuantity.boqRate = respDataObj.Value5;
				// set Pre filled rate of measured quantity as boq item's rate.
				tempObj.rectMeasuredQuantity.measuredRate = respDataObj.Value5;
				tempObj.rectBoqQuantity.boqNetCost = respDataObj.Value6;
				tempObj.rectMeasuredQuantity.measuredUom = respDataObj.Value4;

				if(!tempObj.isRectHeader) {
					// Calculated Individual Nodes in background
					tempObj.calculationDetails.prelims = calcPrelims(tempObj, 'boqQty', 'prelimsTotal');
					tempObj.calculationDetails.designFees = calcDesignFees(tempObj, 'boqQty', 'designFeesTotal');
					tempObj.calculationDetails.contingency = calcContingency(tempObj, 'boqQty', 'contingencyTotal');
					tempObj.calculationDetails.inflation =calcInflation(tempObj, 'boqQty', 'inflationTotal');
					tempObj.calculationDetails.nec4Fee = calcNec4Fee(tempObj, 'boqQty', 'nec4FeeTotal');
					tempObj.calculationDetails.ohSum = calcOhSum(tempObj, 'boqQty', 'ohSumTotal');
					tempObj.calculationDetails.targetCost = calcTargetCost(tempObj, 'boqQty', 'targetCostTotal');
				}
				
				tempList.push(tempObj);
			}

			$scope.rectificationWork.rectificationDetails = tempList;
			$scope.rectificationDetails = $scope.rectificationWork.rectificationDetails;
			
			// Set calculated total with BOQ after manual calculation.
			$scope.calculatedTotalAmounts.prelimsTotal = priceDetailResp.Value20;
			$scope.calculatedTotalAmounts.designFeesTotal = priceDetailResp.Value19;					
			// both user entry fields.
			$scope.calculatedTotalAmounts.contingencyTotal = 0;
			$scope.calculatedTotalAmounts.inflationTotal = 0;

			$scope.calculatedTotalAmounts.nec4FeeTotal = priceDetailResp.Value21;
			$scope.calculatedTotalAmounts.ohSumTotal = (parseFloat(priceDetailResp.Value19 || 0) + parseFloat($scope.calculatedTotalAmounts.contingencyTotal || 0) + parseFloat($scope.calculatedTotalAmounts.inflationTotal || 0) + parseFloat(priceDetailResp.Value20 || 0) + parseFloat(priceDetailResp.Value21 || 0)).toFixed(2);
			// calculation of above all
			$scope.calculatedTotalAmounts.targetCostTotal = parseFloat(priceDetailResp.Value6 || 0).toFixed(2);

			// function for the whole total calculations.
			calculateIndividualTotal('boqQty');
			calculateAllTotal();
		},	getBOQAndPriceDetails = function (selectedItem) {
			$scope.rectificationWork.rectificationRef = selectedItem.rectRef;
			$scope.oriMsgCustomFields.ORI_USERREF = selectedItem.modelValue; 
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": CONSTANTS_OBJ.BOQ_Details_by_QSref+','+CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": CONSTANTS_OBJ.BOQ_Details_by_QSref,
						"fieldValue": selectedItem.modelValue
					},{
						"fieldName": CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF,
						"fieldValue": selectedItem.modelValue
					}]
				}
			};
			$scope.xhr.rectificationXhr = $scope.getCallbackData(form).then(function (response) {					
				if (response.data) {
					callBackResp[CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF] = angular.fromJson(response.data[CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF]).Items.Item[0];
					setActivityHeadDataOnResp(callBackResp[CONSTANTS_OBJ.PRICEDOCDETAIL_BY_QSREF]);
					if(!$scope.isAlreadyCreated) {
						callBackResp[CONSTANTS_OBJ.BOQ_Details_by_QSref] = angular.fromJson(response.data[CONSTANTS_OBJ.BOQ_Details_by_QSref]).Items.Item;						
					}
				}
				$scope.xhr.rectificationXhr = false;
				$scope.update();
				freezedHeaderColScrollBind();
				// set the flag to disable button to show table.
				$scope.setIsAllFieldsAvail();
			}, function (error) {
				$scope.xhr.rectificationXhr = false;
				$scope.update();
				freezedHeaderColScrollBind();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error', 
					message: errorMsg 
				});				
			});
		};

		$scope.selectionChangeEvnt = function (selectedItem, eventFor, index) {
			if(eventFor == 'qs-ref') {
				getBOQAndPriceDetails(selectedItem);
			}
		};

		$scope.itemListOpen = function (index, currRoomNo) {			
			var selectedRoomNo = [],
				filteredList = roomList || [];

			$scope.mapRoomsDetails.forEach(function(roomObj) {
				if(roomObj.roomNo && roomObj.roomNo != currRoomNo) {
					selectedRoomNo.push(roomObj.roomNo);
				}	
			});

			if(selectedRoomNo.length) {
				filteredList = roomList.filter(function(item) {
					return selectedRoomNo.indexOf(item.Value7 + '#' + item.Value8) < 0;
				});
			} 

			$scope.roomListMap[index] = structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, filteredList);
		};

		$scope.setIsAllFieldsAvail = function () {
			$scope.isAllFieldsAvail = false;
			if($scope.rectificationWork.qsRef && $scope.rectificationWork.activityOverHead.contingency && $scope.rectificationWork.activityOverHead.inflation) {
				$scope.isAllFieldsAvail = true;
			}
		};

		$scope.showTableFun = function () {
			if($window.confirm("It will disable values you have entered, Do you want to procceed?")){
				$scope.isShowTabled = true;
				// to update the DOM.	
				setBOQDataOnResp(callBackResp[CONSTANTS_OBJ.BOQ_Details_by_QSref]);
				$scope.update();
				freezedHeaderColScrollBind();
			} else {
				$scope.isShowTabled = false;
			}
		};

		var boqBgVariationCalculation = function (tempObj, calcFor) {			
			// Calculated Individual Nodes 
			tempObj.calculationDetails.prelims = calcPrelims(tempObj, calcFor, 'prelimsTotal');
			tempObj.calculationDetails.designFees = calcDesignFees(tempObj, calcFor, 'designFeesTotal');
			tempObj.calculationDetails.contingency = calcContingency(tempObj, calcFor, 'contingencyTotal');
			tempObj.calculationDetails.inflation =calcInflation(tempObj, calcFor, 'inflationTotal');
			tempObj.calculationDetails.nec4Fee = calcNec4Fee(tempObj, calcFor, 'nec4FeeTotal');
			tempObj.calculationDetails.ohSum = calcOhSum(tempObj, calcFor, 'ohSumTotal');
			tempObj.calculationDetails.targetCost = calcTargetCost(tempObj, calcFor, 'targetCostTotal');
			// function for the whole total calculations.
			calculateIndividualTotal(calcFor);
			calculateAllTotal();
			
		},	bgVariationCalculation = function (tempObj, calcFor) {			
			// Calculated Individual Nodes 
			tempObj.measCalculationDetails.measprelims = calcPrelims(tempObj, calcFor, 'measPrelimsTotal');
			tempObj.measCalculationDetails.measdesignFees = calcDesignFees(tempObj, calcFor, 'measDesignFeesTotal');
			tempObj.measCalculationDetails.meascontingency = calcContingency(tempObj, calcFor, 'measContingencyTotal');
			tempObj.measCalculationDetails.measinflation =calcInflation(tempObj, calcFor, 'measInflationTotal');
			tempObj.measCalculationDetails.measnec4Fee = calcNec4Fee(tempObj, calcFor, 'measNec4FeeTotal');
			tempObj.measCalculationDetails.measohSum = calcOhSum(tempObj, calcFor, 'measOhSumTotal');
			tempObj.measCalculationDetails.meastargetCost = calcTargetCost(tempObj, calcFor, 'measTargetCostTotal');
			// function for the whole total calculations.
			calculateIndividualTotal(calcFor);
			calculateAllTotal();
		};

		$scope.addNewRoom = function(list) {
			list.push(angular.copy(STATIC_OBJ.roomDetails));			
			$scope.roomListMap.push(structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, roomList));
		};

		$scope.removeRoomNo = function(index) {			
			$scope.mapRoomsDetails.splice(index, 1);
			$scope.roomListMap.splice(index, 1);
		};
		
		$scope.calculateMeasuredTotal = function (paramObj) {
			paramObj.calcNode[paramObj.totalKey] = 0;
			paramObj.calcNode[paramObj.totalKey] = parseInt(paramObj.calcNode.measuredQty || 0) * parseFloat(paramObj.calcNode.measuredRate || 0);
			paramObj.calcNode[paramObj.totalKey] = paramObj.calcNode[paramObj.totalKey].toFixed(2);
			
			// set variation code code calculation in another node.
			paramObj.calcNode['measuredTotalVariation'] = 0;
			if(paramObj.isVariationCalc && paramObj.calcNode.measuredQty && paramObj.calcNode.measuredRate) {
				paramObj.calcNode['measuredTotalVariation'] = parseFloat(paramObj.calcNode[paramObj.totalKey]) - parseFloat(paramObj.item.rectBoqQuantity.boqNetCost);
				paramObj.calcNode['measuredTotalVariation'] = paramObj.calcNode['measuredTotalVariation'].toFixed(2);
			}			
			bgVariationCalculation(paramObj.item, paramObj.calcFor);
		};

		$scope.calculateBoqTotal = function (paramObj) {
			paramObj.calcNode[paramObj.totalKey] = 0;
			paramObj.calcNode[paramObj.totalKey] = parseInt(paramObj.calcNode.boqQty || 0) * parseFloat(paramObj.calcNode.boqRate || 0);
			paramObj.calcNode[paramObj.totalKey] = paramObj.calcNode[paramObj.totalKey].toFixed(2);
			boqBgVariationCalculation(paramObj.item, paramObj.calcFor);
			$scope.calculateMeasuredTotal({
				item : paramObj.item,
				calcNode : paramObj.item.rectMeasuredQuantity,
				totalKey : 'measuredTotal',
				calcFor : 'measuredQty',
				isVariationCalc : true
			});
		};
		
		var structureItemList = function(setFor, availList) {    			
			var tempList=[],
				optlabel = '';  				
			switch (setFor) {
				case CONSTANTS_OBJ.QS_REF_LIST_KEY:
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Value1,
							rectRef : item.Value2, 							
							modelValue:  item.Value1
						});	
					});
					optlabel = CONSTANTS_OBJ.QS_REF_LABEL;
					break;
				case CONSTANTS_OBJ.DIST_USER_LIST_KEY:
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.split('#')[1].trim(),							
							modelValue:  item
						});	
					});
					optlabel = CONSTANTS_OBJ.DIST_USER_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.ROOM_NO_LIST_KEY:
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Value8,                         
							modelValue:  item.Value7 + '#' + item.Value8
						});	
					});
					optlabel = CONSTANTS_OBJ.ROOM_NO_LABEL;
					break;					
			}     
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};

		var workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0],
			workingUserId = $scope.getWorkingUserId(),
			trustRoleUserList = commonApi.roleUsersListByRoleName('trust', projAllRolesList),			
			isUserTrustRoleMember = !!(trustRoleUserList.filter(function(userObj){
				return (workingUserId == userObj.split('#')[0].trim());
			}).length),
			incompleteActionsList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS'),
			incompleteActionsByMsgList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG'),			
			isForCreate = !!($scope.isOriView && FORMID == '') || !!($scope.isOriView && FORMID != '' && $scope.isDraft),
			isEditAndFwd = ($scope.isOriView && !$scope.isDraft && $scope.appMsgId != '') || !!($scope.isOriView && !$scope.isDraft && FORMID);

		$scope.authorizedToWork = false;
		$scope.isOriginatorUser = ($scope.rectificationWork.distUserDetails.originatorUser && (workingUserId == $scope.rectificationWork.distUserDetails.originatorUser.split('#')[0].trim()));
		var checkWorkingAccess = function() {
			$scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "1| You are not authorised to raise or edit this Form.";				
			return isForCreate || !isUserTrustRoleMember || isEditAndFwd;
		};

		var setOriViewBase = function () {
			// set Block Number Dynamically from the Custom attribute.
			$scope.trustRoleUsersList = structureItemList(CONSTANTS_OBJ.DIST_USER_LIST_KEY, trustRoleUserList);
			
			roomList = configAttributesList.filter(function(attrObj) {
				return (attrObj.Value3.toLowerCase() == 'room no' || attrObj.Value3.toLowerCase() == 'roomno') && attrObj.Value11 == 'Active';
			});

			// set Form Stages.
			$scope.rectificationWork.currentStage = 'at originator';
			$scope.rectificationWork.nextStage = 'at trust user';

			// set originator on load.
			if(isForCreate) {
				$scope.qsRefList = structureItemList(CONSTANTS_OBJ.QS_REF_LIST_KEY, $scope.getValueOfOnLoadData('DS_INS_QSREFLIST'));
				
				// to set block number dynamically
				if(!$scope.rectificationWork.block) {
					// default set 5.
					$scope.rectificationWork.block = (configAttributesList.filter(function(attrObj) {
						return (attrObj.Value3.toLowerCase() == 'block number' || attrObj.Value3.toLowerCase() == 'blocknumber') && attrObj.Value11 == 'Active';
					})[0] || {Value7 : '05'}).Value7;
				}

				var workingUser = workingUserObj.Value.split('#')[0];
				$scope.rectificationWork.distUserDetails.originatorUser = workingUser.replace('|','#').trim();
				!$scope.mapRoomsDetails.length && $scope.addNewRoom($scope.mapRoomsDetails);			
			}
			
			if(isEditAndFwd) {
				for (var i=0; i<$scope.mapRoomsDetails.length; i++) {
					$scope.itemListOpen(i, $scope.mapRoomsDetails[i].roomNo);
				}
			}
		};

		if(!$scope.rectificationWork.formSubTitle) {
			$scope.rectificationWork.formSubTitle = $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME;
		}

		if ($scope.isOriView) {
			$scope.authorizedToWork = checkWorkingAccess();
			if($scope.authorizedToWork) {
				$scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = "0";
				setOriViewBase();
				// boq details call will be made only if all required details are not available while editing draft.
				if($scope.isDraft) {
					if(!$scope.isShowTabled) {
						getBOQAndPriceDetails({
							rectRef : $scope.rectificationWork.rectificationRef,
							modelValue : $scope.rectificationWork.qsRef 
						});
					}					
					$scope.mapRoomsDetails.forEach(function(roomObj, index) {
						$scope.itemListOpen(index, roomObj.roomNo);
					});
				}

				// resetting auto distribution node.
				$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			}
		} else if ($scope.isRespView) {	
			// reset the Form Status and Comments respectivly as well.
			if($scope.isOriginatorUser){
				$scope.rectificationWork.responseDetails.originatorComments = '';		
			} else {
				$scope.rectificationWork.responseDetails.responseComment = '';
			}
			$scope.rectificationWork.responseDetails.responseStatus = '';
			if($scope.rectificationWork.nextStage == 'at trust user') {
				$scope.rectificationWork.currentStage = 'at trust user';
				$scope.rectificationWork.nextStage = 'at originator';
			} else if($scope.rectificationWork.nextStage == 'at originator') {
				$scope.rectificationWork.currentStage = 'at originator';
				$scope.rectificationWork.nextStage = 'at trust user';
			}

		} else if ($scope.isOriPrintView) {
			$scope.$parent.priv.canForward = !$scope.isFWDDraft && !$scope.isRESDraft && $scope.isOriginatorUser && ($scope.isFormAccepted || $scope.isFormResubmit);
		} else if ($scope.isRespPrintView) {}
	
		var setFormWorkflow = function () {
			var userTodistribute = '',
				currFormStaus = '',
				autoDistNode = '3';

			// Distribution Will be made from here
			// resetting auto distribution node.
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if($scope.isOriView) {
				userTodistribute = $scope.rectificationWork.distUserDetails.distUser;
				currFormStaus = 'for approval';				
				if(isEditAndFwd) {
					$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
					$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
					commonApi.setClearCompletePendingActions({
						//	actionsList : incompleteActionsList,
						actionsList : incompleteActionsByMsgList,
						nodeToSet : $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action,
						appBuilderCode : $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID,
						//	actionSpNodeKey : 'Name',
						actionSpNodeKey : 'Value4',
						actionStr : 'Respond',
						acttionId : '3',
						type : 'clear',
						remarks : 'clear actions',
						isAllActionClear : true
					});
				}
			} else if($scope.isRespView) {
				currFormStaus = $scope.rectificationWork.responseDetails.responseStatus || 'for approval';
				autoDistNode = '13';
				if(currFormStaus == 'revised and resubmit') {
					userTodistribute = $scope.rectificationWork.distUserDetails.originatorUser; 
				} else if(currFormStaus == 'for approval') {
					userTodistribute = $scope.rectificationWork.distUserDetails.distUser;
				}
			} 

			if(userTodistribute) {
				commonApi.setDistributionNode({
					actionNodeList : [{
						strUser : userTodistribute,
						strAction : "3#Respond",
						strDate : commonApi.calculateDistDateFromDays({
							baseDate: $scope.serverDate,
							days : 7
						})                    
					}],
					autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE : autoDistNode
				});
			}

            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {  
				$scope.rectificationWork.responseDetails.responseStatus = currFormStaus;           
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		};

		$scope.update();
		$window.oriformSubmitCallBack = function () {
			setFormWorkflow();
			$scope.rectificationWork.isShowTabled = $scope.isShowTabled;
			$scope.rectificationWork.isAllFieldsAvail = $scope.isAllFieldsAvail;

			$scope.mapRoomsDetails.forEach(function(roomDetail) {
				delete roomDetail['new'];
			});

			//	set form title.
			if(!$scope.oriMsgCustomFields.ORI_FORMTITLE) {
				$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.rectificationWork.formType + ' ' + $scope.oriMsgCustomFields.ORI_USERREF;
			}

			// DB entry check.
			$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = ($scope.isRespView && $scope.rectificationWork.responseDetails.responseStatus == 'accepted').toString();
			if(!$scope.rectificationWork.isAcceptedOnce && $scope.rectificationWork.responseDetails.responseStatus == 'accepted') {
				$scope.rectificationWork.isAcceptedOnce = true;
			}
			return false;
		};
		
		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			$scope.rectificationWork.isShowTabled = $scope.isShowTabled;
			$scope.rectificationWork.isAllFieldsAvail = $scope.isAllFieldsAvail;
			// remove auto draft node value for draft.
			if(!$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.length) {
				$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
			}
		}
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}