/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];

		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_ASI_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GetITBs');
		$scope.DS_PROJORGANISATIONS = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS');
		$scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		$scope.DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');

		$scope.update();
		$scope.DSI_isLoaded = true;
		$scope.DistributionStructure = {
			DS_PROJDISTUSERS: "",
			DS_FORMACTIONS: "",
			DS_ACTIONDUEDATE: "",
			Dist_Organisation: ""
		}
	
		$scope.logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});

		function setClientLogo() {
			if ($scope.logo && $scope.logo[0].Value8) {
				$scope.oriMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
			}
		}
		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			var strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date(strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(strTime), 'dd-M-yy');
		});
		if (currentViewName == "ORI_VIEW") {
			if (strFormId == "" || strIsDraft == "YES") {
				setClientLogo();
			}

			if (strFormId == "") {
				removeDashOnNormalLoad();
				$timeout(function () {
					if (localStorage) {
						var numVal = localStorage.getItem('formcode_num')
						if (numVal) {
							if (numVal) {
								$scope.setITTDetails(numVal);
							}
							localStorage.removeItem('formcode_num');
						}
					}
				}, 1000);
			}
		}
		if (currentViewName == "ORI_PRINT_VIEW" || currentViewName == "FORM_PRINT_VIEW") {
			var itbURL = commonApi._.filter($scope.DS_ASI_STD_TNDR_GetITBs, function (val) {
				return val.Value1 == ($scope.oriMsgCustomFields.ITB_Info.Select_ITB || $scope.oriMsgCustomFields.ITB_Info.ITB);
			});

			if (itbURL && itbURL.length) {
				$scope.oriMsgCustomFields.ITB_Info.ITB_URL = itbURL[0].URL6;
			}
		}

		$scope.AddNewItem = function (repeatingData, fromStructure) {
			var item = angular.copy(fromStructure);
			repeatingData.push(item);
		};
		$scope.DeleteRow = function (index, repeatindData) {
			if (repeatindData.length > index) {
				repeatindData.splice(index, 1);
			}
		};
		$scope.DeleteItem = function (obj, repeatingData) {
			//delete data by index
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
		};

		$timeout(function () {
			$scope.expandTextAreaOnLoad();
		}, 1000);
		$scope.setITTDetails = function (str) {
			if (str) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_ASI_STD_TNDR_GET_ITBSDETAILS,DS_ASI_STD_ADD_BM_Bid_Recipients",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_ASI_STD_TNDR_GET_ITBSDETAILS",
							"fieldValue": str
						}, {
							"fieldName": "DS_ASI_STD_ADD_BM_Bid_Recipients",
							"fieldValue": str
						}]
					}
				};
				$scope.DSI_isLoaded = false;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var ITBData = angular.fromJson(response.data['DS_ASI_STD_TNDR_GET_ITBSDETAILS']).Items.Item;
						var DS_ASI_STD_ADD_BM_Bid_Recipients = angular.fromJson(response.data['DS_ASI_STD_ADD_BM_Bid_Recipients']).Items.Item;
						if (ITBData && ITBData.length) {
							var strBidAdmin = ITBData[0].Value5;
							var strOrgTitle = ITBData[0].Value3;
							var strItbAppBuilderId = ITBData[0].Value1;
							var strItbId = ITBData[0].Value2;
							$scope.oriMsgCustomFields.ORI_FORMTITLE = strOrgTitle;
							$scope.oriMsgCustomFields.ITB_Info.Bid_Administrator = strBidAdmin;
							$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strItbAppBuilderId;
							$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = strItbId;
							$scope.oriMsgCustomFields.ITB_Info.ITB = $scope.oriMsgCustomFields.ITB_Info.Select_ITB;
						}
						setDistNodes(DS_ASI_STD_ADD_BM_Bid_Recipients);
						$scope.DSI_isLoaded = true;
					}
				});
			}
		}

		function setDistNodes(DS_ASI_STD_ADD_BM_Bid_Recipients) {
			$scope.oriMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.AutoDirstribute_Users = [];
			var strrecepients = commonApi._.filter(DS_ASI_STD_ADD_BM_Bid_Recipients, function (val) {
					return val.Value7 != 'Rejected'
				});
			$scope.oriMsgCustomFields.DS_AUTODISTRIBUTE = "3";
			for (var i = 0; i < strrecepients.length; i++) {
				var strUserId = strrecepients[i].Value5.trim();

				var strUserDetails = getUserName(strUserId);
				var strOrgDetails = strrecepients[i].Value4.trim();
				if(strUserDetails!="" && strOrgDetails !="")
					setAutoDistribution(strUserDetails, "7#For Information", "", strOrgDetails);
			}
		}

		function getUserName(strUserId) {
			var Allusers = $scope.DS_PROJDISTUSERS;
			if (Allusers && Allusers.length) {
				for (var i = 0; i < Allusers.length; i++) {
					var strValue = Allusers[i].Value.trim();
					if (strValue && strValue.split('#')[0] == strUserId) {
						return strValue;
					}
				}
			}
			return "";
		}
		function setAutoDistribution(strUser, strAction, strDueDate, strOrg) {

			if (strDueDate) {
				strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
			}
			//get copy of distribution and set user ,date ,action to distribute
			var structDistricution = angular.copy($scope.DistributionStructure)
			structDistricution.DS_PROJDISTUSERS = strUser;
			structDistricution.DS_FORMACTIONS = strAction;
			structDistricution.DS_ACTIONDUEDATE = strDueDate;
			structDistricution.Dist_Organisation = strOrg;
			$scope.oriMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.AutoDirstribute_Users.push(structDistricution);
		}

		function removeDashOnNormalLoad() {
			if ($scope.oriMsgCustomFields.ORI_FORMTITLE == "-") {
				$scope.oriMsgCustomFields.ORI_FORMTITLE = "";
			}
			if ($scope.oriMsgCustomFields.Response == "-") {
				$scope.oriMsgCustomFields.Response = "";
			}
			if ($scope.oriMsgCustomFields.ITB_Info.ITB == "-") {
				$scope.oriMsgCustomFields.ITB_Info.ITB = "";
			}
			if ($scope.oriMsgCustomFields.Addenda_Notes == "-") {
				$scope.oriMsgCustomFields.Addenda_Notes = "";
			}
			if ($scope.oriMsgCustomFields.DS_AUTODISTRIBUTE == "-") {
				$scope.oriMsgCustomFields.DS_AUTODISTRIBUTE = "";
			}
			if ($scope.oriMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.AutoDirstribute_Users[0].DS_PROJDISTUSERS == "-") {
				$scope.oriMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.AutoDirstribute_Users = [];
				var structDistricution = angular.copy($scope.DistributionStructure);
				$scope.oriMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.AutoDirstribute_Users.push(structDistricution);
			}
			if ($scope.oriMsgCustomFields.IsRespond == "-") {
				$scope.oriMsgCustomFields.IsRespond = "False";
			}

		}
		$scope.CheckDuplicateUser = function (args) {
			checkDuplicateValue(args);

		};
		function checkDuplicateValue(args) {
			var currentIndex = args.repeatObj.indexOf(args.curObj);
			angular.forEach(args.repeatObj, function (item, index) {
				if (currentIndex != index && args.value != "" && item[args.objName] == args.value) {
					alert("Duplicate " + args.msg + " selected !!!\n\nSelect a different " + args.msg);
					args.curObj[args.objName] = "";
					return true;
				}
			});
			return false;
		}

		$scope.SetDistDate = function (args) {
			if (args) {
				var strVal = args.value;
				if (strVal != "7#For Information") {
					args.curObj.DS_ACTIONDUEDATE = $scope.todayDateDbFormat;
				}
				else {
					args.curObj.DS_ACTIONDUEDATE = "";
				}
			}
		}
		$window.ASI_FinalCallBack = function () {
			return $scope.FinalCallBack();
		}

		$scope.FinalCallBack = function () {
			return false;
		}
	}

	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof ASI_FinalCallBack !== "undefined") {
		return ASI_FinalCallBack();
	}
}