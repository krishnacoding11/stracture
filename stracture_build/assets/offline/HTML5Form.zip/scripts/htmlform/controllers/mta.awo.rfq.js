
/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule",'./base', '../components/number-format', '../components/item.selection'], function (angular, mainModule,baseController) {
    'use strict';

    /**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {	
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if(!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') && 
			!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if(!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') && 
			!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function(taRegisterTool, taOptions) {
            taOptions.toolbar = [
                ['bold', 'italics', 'underline', 'strikeThrough', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
                []
            ];
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
			taRegisterTool("fontColor", {
				display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("foreColor", color)
					}
				},
				options: {
					replacerClassName: "fa fa-font",
					showButtons: !1,
                    showAlpha : !1
				},
				color: "#000"
			}),
			taRegisterTool('fontName', {
				display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>"+"</button>",
				action: function (event, font) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
					this.$element.toggleClass('open-fonts-list');
					return this.$editor().wrapSelection('fontName', font);
				},	
				disabled: function() {},			
				options: [
					{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
					{ name: 'Serif', css: "'times new roman', serif" },
					{ name: 'Wide', css: "'arial black', sans-serif" },
					{ name: 'Narrow', css: "'arial narrow', sans-serif" },
					{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
					{ name: 'Courier New', css: "'courier new', monospace" },
					{ name: 'Garamond', css: 'garamond, serif' },
					{ name: 'Georgia', css: 'georgia, serif' },
					{ name: 'Tahoma', css: 'tahoma, sans-serif' },
					{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
					{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
					{ name: 'Verdana', css: 'verdana, sans-serif' },
					{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
				]
			}),
			taRegisterTool('fontSize', {
				display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",				
				action: function (event, size) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-list').removeClass('open-fonts-list');
					this.$element.toggleClass('open-fonts-size-list');					
					return this.$editor().wrapSelection('fontSize', parseInt(size));					
				},			                
				disabled: function() {},
				options: [
					{ name: 'xx-small', css: 'xx-small', value: 1 },
					{ name: 'x-small', css: 'x-small', value: 2 },
					{ name: 'small', css: 'small', value: 3 },
					{ name: 'medium', css: 'medium', value: 4 },
					{ name: 'large', css: 'large', value: 5 },
					{ name: 'x-large', css: 'x-large', value: 6 },
					{ name: 'xx-large', css: 'xx-large', value: 7 }

				]
			}),
			taOptions.toolbar[2].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'),taOptions;
		}
        ]);
	};
	
	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
    });

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $document, $window, $timeout) {

        $controller(baseController, { $scope: $scope, $element: $element });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        $scope.todayDate = '';
        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
      
        var STATIC_OBJ_DATA = {
            CONFIG_JSON : [],
            Contract_Activities: {
                CSection_Guid: "",
                Activity_Code: "",
                Activity_Name: "",
                Activity_Value: "0",
                Applied_Value:"0",
                Approved_Value:"0",
                Activity_Guid:""
            },
            
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: ""
            }
            
        };
        var MTA_CONSTANT = {
            //status
            reviseandresubmit:'Revise and Resubmit',
            submit:'Submitted',
            rejected:'Rejected',
            Accepted:'Accepted',

            //roles
            rolecontractor:'Contractor'
        }

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.sectionGroup = $scope.oriMsgCustomFields["Section_Group"];
        $scope.Activity_Group = $scope.sectionGroup['Sections']['Activity_Group'];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly['_5_Form_Data'];
        var ds_MTA_AWO_Get_Contract_Basic_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_Contract_Basic_Details');
        var ds_MTA_AWO_Get_Pricebreakdown_Activity_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_Pricebreakdown_Activity_Details');
        var ds_MTA_AWO_Get_CIF_Details = $scope.getValueOfOnLoadData('DS_MTA_AWO_Get_CIF_Details');
        var ds_PROJUSERS_ROLE = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');

        var strFormId = $scope.formdata5.DS_FORMID;
        var strIsDraft = $scope.formdata5.DS_ISDRAFT;

        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        $scope.isDataLoaded = true;
        $scope.isSecLoaded = true;
        $scope.selectionlst = {
            contractNoList: [],
            sectionList:[],
            cifList:[],
            contractorlist:[]
        };
        initFormsData();
        function initFormsData()
        {
            if(currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW")
            {
                    var isdsIsdraftRes = $scope.formdata5['DS_ISDRAFT_RES'];
                    var isdsIsdraftResMsg = $scope.formdata5['DS_ISDRAFT_RES_MSG'];
                if (currentViewName == "ORI_VIEW") {
                    $scope.selectionlst.contractNoList = commonApi.getItemSelectionList({
                        arrayObject: ds_MTA_AWO_Get_Contract_Basic_Details,
                        groupNameKey: "",
                        modelKey: "Value6",
                        displayKey: "Value5"
                    }); 

                    //set content
                    setRolewiseUser(MTA_CONSTANT.rolecontractor);
                    loadConfig(function () {
                    $scope.update();
                    });
                }
                else if(currentViewName == "RES_VIEW")
                {
                    if(isdsIsdraftRes == "NO" && isdsIsdraftResMsg == "NO"){
                        var dsiNextstage = $scope.oriMsgCustomFields["DSI_NextStage"];
                        $scope.oriMsgCustomFields["DSI_CurrentStage"] = dsiNextstage;

                        if($scope.oriMsgCustomFields["DSI_CurrentStage"] == '2')
                        {
                            $scope.oriMsgCustomFields['RFQ_Status'] = '';
                            $scope.oriMsgCustomFields['Comment'] = '';
                        }
                    }
                }
            }
            if(currentViewName == "ORI_PRINT_VIEW" || currentViewName == "RES_PRINT_VIEW")
            {
                getContractUrl(); 
            }
        }

        

        function loadConfig(callback) {
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getConfigJson",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&appBuilderId=" + $window.AppBuilderFormIDCode
            }).then(function (response) {
                if(strFormId == "" && strIsDraft == "NO"){
                    var strRFP_Content = response.data.RFP_Content || [];
                    $scope.oriMsgCustomFields['RFP_Content'] = strRFP_Content;
                }
                callback && callback();
            });
        };

        $scope.onContractchange = function (conVal) {
			if (conVal) {
                $scope.isDataLoaded = false;
                var tempCon = conVal.split('||');
                $scope.oriMsgCustomFields.Contract_Code = tempCon[1].trim();
				$scope.oriMsgCustomFields.Contract_Name = tempCon[2].trim();
				$scope.oriMsgCustomFields.Logo.Client_Logo = tempCon[4].trim();
                $scope.oriMsgCustomFields.Logo.Contractor_Logo = tempCon[3].trim();
                $scope.oriMsgCustomFields['ORI_USERREF'] =  tempCon[1].trim();
                $scope.formdata5['DS_FORMCONTENT1'] = tempCon[0].trim();
				var spParam = {
					dataSourceArray: [{
						"fieldName": "DS_MTA_AWO_Get_CIF_Details",
						"fieldValue": tempCon[0].trim()
					}],
					successCallback: contractChangeCallback
				};

				$scope.getCallbackSPdata(spParam);
			}
		}

		function contractChangeCallback(responseList) {	

            ds_MTA_AWO_Get_CIF_Details = responseList["DS_MTA_AWO_Get_CIF_Details"];
            ciflistdetails(ds_MTA_AWO_Get_CIF_Details);

			$scope.isDataLoaded = true;
        }
        function ciflistdetails(ds_MTA_AWO_Get_CIF_Details)
        {
            if(ds_MTA_AWO_Get_CIF_Details != null && ds_MTA_AWO_Get_CIF_Details.length > 0)
            {
                $scope.selectionlst.cifList = commonApi.getItemSelectionList({
                    arrayObject: ds_MTA_AWO_Get_CIF_Details,
                    groupNameKey: "",
                    modelKey: "Value5",
                    displayKey: "Value5"
                }); 
            }
        }
         
        $scope.onCIFChange = function (secVal) {
			if (secVal) {
                setAWONumber(secVal)
                $scope.isSecLoaded = false;
                var strparam = secVal.split('|')[0].trim();
                $scope.formdata5['DS_FORMCONTENT3'] = strparam;
				var spParam = {
					dataSourceArray: [{
						"fieldName": "DS_MTA_AWO_Get_Pricebreakdown_Activity_Details",
						"fieldValue": strparam
					}],
					successCallback: CIFChangeCallback
				};

				$scope.getCallbackSPdata(spParam);
			}
        }
        function CIFChangeCallback(responseList) {	
            ds_MTA_AWO_Get_Pricebreakdown_Activity_Details = responseList["DS_MTA_AWO_Get_Pricebreakdown_Activity_Details"];
            buildActivity(ds_MTA_AWO_Get_Pricebreakdown_Activity_Details);
			$scope.isSecLoaded = true;
        }
        
        function setAWONumber(secVal)
        {
            if (ds_MTA_AWO_Get_CIF_Details.length) {
                var lstawonumber = commonApi._.filter(ds_MTA_AWO_Get_CIF_Details, function (val) {
                        return val.Value5 == secVal;
                });
                 $scope.oriMsgCustomFields['AWO_Number'] = lstawonumber[0].Value6.trim();                  
                 $scope.oriMsgCustomFields['ORI_FORMTITLE'] = 'Request for Proposal for '+ lstawonumber[0].Value6.trim();
            }
        }

        function buildActivity(lstvalue)
        {
            $scope.Activity_Group["Contract_Activities"] = [];
            var objActivity ;
            if (lstvalue != null && lstvalue.length) {
                var strCode="",strname="",strValue="",strCSecguid="",strActGuid="",strSectionCode="",strSectionName="";
                for (var i = 0; i < lstvalue.length; i++) {
                    objActivity = angular.copy(STATIC_OBJ_DATA.Contract_Activities);
                    strCode = lstvalue[i].Value5;
                    strname = lstvalue[i].Value6;
                    strValue = lstvalue[i].Value7;
                    strCSecguid = lstvalue[i].Value10;
                    strActGuid = lstvalue[i].Value9;
                    strSectionCode = lstvalue[i].Value11;
                    strSectionName = lstvalue[i].Value12;
                    if(strCode != "")
                    {
                        objActivity.Activity_Code = strCode; 
                        objActivity.Activity_Name = strname;
                        objActivity.Activity_Value = strValue;
                        objActivity.Activity_Guid = strActGuid;
                        objActivity.CSection_Guid = strCSecguid;
                        $scope.sectionGroup['Sections']['Section_Code'] = strSectionCode;
                        $scope.sectionGroup['Sections']['Section_Name'] = strSectionName;
                        $scope.Activity_Group["Contract_Activities"].push(objActivity);
                    }
                }
            }
        }
        //calculation of Activity amount
        $scope.activityTotalamount = activityTotalamount;
        function activityTotalamount(strcalckey,strtotalkey) {
            $scope.calcFieldTotal({
                repData: $scope.Activity_Group["Contract_Activities"],
                calcKey: strcalckey,
                parObject: $scope.oriMsgCustomFields,
                totalKey: strtotalkey
            });
        }
        $scope.calcFieldTotal = function (paramObject) {
            var repData = paramObject.repData;
            var calcKey = paramObject.calcKey;
            var parObject = paramObject.parObject;
            var totalKey = paramObject.totalKey;

            var tempTotal = 0;
            for (var index = 0; index < repData.length; index++) {
                var element = repData[index][calcKey];
                tempTotal += (parseFloat(element) || 0);
            }
            parObject[totalKey] = angular.copy(tempTotal.toFixed(2));
            $scope.totalofdamage = tempTotal; 
        }
        
        function setRolewiseUser(strroletype) {
            if (ds_PROJUSERS_ROLE.length) {
                var lstcontractor = commonApi._.filter(ds_PROJUSERS_ROLE, function (val) {
                    if (val.Value.split('|')[0].trim() == strroletype) {
                        return val.Value;
                    }
                });
                for (var i = 0; i < lstcontractor.length; i++) {
                   $scope.selectionlst.contractorlist.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }                  
            }
        }
        function setAutoDistribution(strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = strDueDate;
            $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push(structDistribution);
        }

        //final callback
        $window.mtaAWOFinalCallBack = function () {
        return setflow();
        }
        function setflow(){
            var currentstage = $scope.oriMsgCustomFields["DSI_CurrentStage"];
            var strdate = $scope.setDbDateClientSide(5);

            if (currentstage) {
                switch (currentstage) {
                    case '0':
                    var strVal = $scope.oriMsgCustomFields['SendTo_RFP'];
                    if(strVal != '')
                    {
                            $scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "3"
                            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                            var struser = strVal.split('|')[2].trim();
                            var straction = "3#Respond";
                            setAutoDistribution(struser.split('#')[0].trim(), straction, strdate);   
                            $scope.oriMsgCustomFields["DSI_NextStage"] = "1";
 
                    }
                    $scope.oriMsgCustomFields['Originator'] = dsWorkingUserId;
                    break;
                    case '1':
                        $scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "13"
                        $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                        var struser = $scope.oriMsgCustomFields['Originator'];
                        var straction = "3#Respond";
                        setAutoDistribution(struser, straction, strdate); 
                        
                        var strstatus = $scope.oriMsgCustomFields.RFQ_Status;

                        if(strstatus == MTA_CONSTANT.rejected)
                        {
                            setFormStatus(MTA_CONSTANT.reviseandresubmit);
                        }
                        else
                        {
                            setFormStatus(MTA_CONSTANT.submit);
                        }
                        $scope.oriMsgCustomFields["DSI_NextStage"] = "2";
                    break;
                    case '2':
                        var strstatus = $scope.oriMsgCustomFields.RFQ_Status;
                        if(strstatus != '')
                        {
                            setFormStatus(strstatus);
                        }
                        $scope.asiteSystemDataReadwrite['Auto_Distribute_Group']['Auto_Distribute_Users']=[];
                        if(strstatus == MTA_CONSTANT.rejected)
                        {
                            $scope.asiteSystemDataReadwrite.DS_AUTODISTRIBUTE = "13"
                            var strVal = $scope.oriMsgCustomFields['SendTo_RFP'];
                            var struser = strVal.split('|')[2].trim();
                            var straction = "3#Respond";
                            setAutoDistribution(struser.split('#')[0].trim(), straction, strdate);   
                            $scope.oriMsgCustomFields["DSI_NextStage"] = "1";

                        }
                        
                    break;
                }
            }
        }
        function setFormStatus(strstatus) {              
            var strFormStatusId = getFormStatusId(strstatus);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
            }          
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter          
            if (ds_all_Active_Form_Status && ds_all_Active_Form_Status.length > 0) {
                var statudObj = commonApi._.filter(ds_all_Active_Form_Status, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        function getContractUrl() {
            //get status according pass parameter   
            var conUrlLink = $scope.formdata5['DS_FORMCONTENT1'];     
            if (ds_MTA_AWO_Get_Contract_Basic_Details && ds_MTA_AWO_Get_Contract_Basic_Details.length > 0) {
                var conUrlLinkObj = commonApi._.filter(ds_MTA_AWO_Get_Contract_Basic_Details, function (val) {
                    return val.Value2.toLowerCase().trim() == conUrlLink.toLowerCase().trim();
                });
                if (conUrlLinkObj.length) {
                    $scope.oriMsgCustomFields['ContractURL'] = conUrlLinkObj[0].URL7;
                }
            }
            return "";
        }

       $scope.update();
    }
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof mtaAWOFinalCallBack !== "undefined") {
        return mtaAWOFinalCallBack();
    }
}