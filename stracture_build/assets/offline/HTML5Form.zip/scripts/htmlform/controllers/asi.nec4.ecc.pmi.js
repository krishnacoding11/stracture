/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 50);
            }
        });

        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        var ctrl = this;
        var modelRowIndex = -1;
        $scope.modalData = {};

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });

        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        $scope.isDataLoaded = true;
        $scope.isSectionLoaded = true;
        $scope.isEwnRefLoaded = true;
        var STATIC_OBJ_DATA = {
            Auto_Distribute_Users: {
                AutoDist_Id: "",
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                isEditable: "1",
                dist_isSelected: false,
                ActionDue_Group: {
                    DS_ACTIONDUEDATE: "",
                    DS_DUEDAYS: ""
                }
            },
            ACF_01_Impacted_Activities: {
                ACF_01_Section_Code: "",
                ACF_01_Section_Name: "",
                ACF_01_Activity_Code: "",
                ACF_01_Activity_Name: "",
                ACF_01_Act_Current_Additions: "",
                ACF_01_Act_Sel: ""
            },
            ACF_01_Impacted_Key_Dates: {
                ACF_01_Key_Date_Id: "",
                ACF_01_Date_Description: "",
                ACF_01_KD_Current_Additions: "",
                ACF_01_Date_Type: "",
                ACF_01_Date_Ref: "",
                ACF_01_KD_Sel: ""
            },
            ALL_Clauses_List: {
                CL_SEL: "",
                Cl_No: "",
                Cl_ID: "",
                CL_VAL: "",
                Cl_ID_VAL: "",
                CL_isSelected: ""
            },
            CEN_EVENT_CLAUSES: {
                ClauseNo: "",
                Clause_Text: "",
                CEN_Event_Clause: "",
                cls_isSelected: false,
            }
        };
        $scope.Referenced_Docs = {
            Doc_Hyperlink: "",
            Doc_Description: "",
            doc_isSelected: false,
        }
        $scope.regFortime = "(((0[1-9])|(1[0-2])):([0-5])[0-9] (A|P)M)";
        $scope.tableUtilSettings = {
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                editRowCallBack: editDistModal,
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users),
                ADD_NEW_BEFORE_TIP: "Insert before Recipient",
                ADD_NEW_AFTER_TIP: "Insert after Recipient",
                deleteAllRowTooltip: "Remove all Recipients",
                deleteCurrRowMsg: "Remove Recipient",
                deleteSelectedMsg: "Remove selected Recipient"
            },
            Referenced_Docs: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "doc_isSelected",
                newStaticObject: angular.copy($scope.Referenced_Docs),
                ADD_NEW_BEFORE_TIP: "Insert before Reference Document",
                ADD_NEW_AFTER_TIP: "Insert after Reference Document",
                deleteAllRowTooltip: "Remove all Reference Document",
                deleteCurrRowMsg: "Remove Reference Document",
                deleteSelectedMsg: "Remove selected Reference Document"
            },
            CEN_EVENT_CLAUSES: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "doc_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.CEN_EVENT_CLAUSES),
                ADD_NEW_BEFORE_TIP: "Insert before Clause",
                ADD_NEW_AFTER_TIP: "Insert after Clause",
                deleteAllRowTooltip: "Remove all Clauses",
                deleteCurrRowMsg: "Remove Clauses",
                deleteSelectedMsg: "Remove selected Clause"
            }
        }
        var NEC4_CONSTANT = {
            restrictedCharMsg: "Validation \n\n Restricted Characters specified!!! Restricted Characters | < > #",
            mandatoryValMsg: 'Validation\n\n Please fill mandatory fields!',
            distribution: 'distribution'
        }

        $scope.openModal = function (viewId, rowData) { // rowData used when user edit row , rowData come from table.util component as param
            modelRowIndex = -1;

            switch (viewId) {
                case NEC4_CONSTANT.distribution:
                    if (rowData) {
                        modelRowIndex = rowData.index;
                        $scope.modalData = angular.copy(rowData.row);
                    } else {
                        $scope.modalData = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users);
                    }
                    break;
            }

            showModal(viewId)
        }

        ctrl.model = {
            modelId: "",
            update: updateRecord,
            hideModal: hideModal,
            showloader: false,
            readOnly: false
        };

        function showModal(id) {
            // show modal
            ctrl.model.modelId = id;
        };

        function hideModal() {
            ctrl.model.modelId = '';
        }

        function editDistModal(rowData) {
            $scope.openModal(NEC4_CONSTANT.distribution, rowData);
        }

        function updateRecord() {
            var rowIndex = modelRowIndex,
                newNode = angular.copy($scope.modalData);

            if (!validateModalForm(ctrl.model.modelId)) {
                $window.alert(NEC4_CONSTANT.mandatoryValMsg);
                return;
            }
            switch (ctrl.model.modelId) {
                case NEC4_CONSTANT.distribution:
                    if (rowIndex > -1) {
                        $scope.autoDistNodes['Auto_Distribute_Users'][rowIndex] = newNode;
                    } else {
                        $scope.autoDistNodes['Auto_Distribute_Users'].push(newNode);
                    }
                    break;
            }
            $timeout(function () {
                hideModal();
            })

        }

        function validateModalForm(modalId) {
            var mandatorySingleFieldArray = [];
            var validaFlag = true;
            switch (modalId) {
                case NEC4_CONSTANT.distribution:
                    if ($scope.modalData.DS_FORMACTIONS.indexOf("7#") < 0) {
                        mandatorySingleFieldArray = ['DS_PROJDISTUSERS', 'DS_FORMACTIONS', 'DS_ACTIONDUEDATE'];
                    } else {
                        mandatorySingleFieldArray = ['DS_PROJDISTUSERS', 'DS_FORMACTIONS'];
                    }
                    break;
            }

            validaFlag = checkFieldValueInObject($scope.modalData, mandatorySingleFieldArray);

            function checkFieldValueInObject(objectData, keyArray) {
                var strElem = "";
                for (var index = 0; index < keyArray.length; index++) {
                    var element = keyArray[index];
                    if (element == "DS_ACTIONDUEDATE") {
                        strElem = objectData.ActionDue_Group[element];
                    } else {
                        strElem = objectData[element];
                    }
                    if (!strElem) {
                        return false;
                    }
                }
                return true;
            }
            return validaFlag;
        }
        /** Initialize db fields */

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.oriMsgFields = $scope.asiteSystemDataReadwrite["ORI_MSG_Fields"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.autocreateformfields = $scope.asiteSystemDataReadwrite.AUTOCREATE_FORM_FIELDS.ACF_01_AUTOCREATE_FORM;
        var DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        var DS_ASI_STD_ECC4_NEC_EMP_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_EMP_CONTRACT');
        var DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS');
        var DS_ASI_STD_ECC4_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_CONTRACT');
        var DS_ASI_STD_ECC4_SETUP_SECTIONS = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_SETUP_SECTIONS');
        var DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var DS_ASI_STD_ECC4_NEC_ALL_EWN = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_ALL_EWN');
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_ASI_STD_ECC4_NEC_ALL_CLAUSES = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_NEC_ALL_CLAUSES');
        var DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE = $scope.getValueOfOnLoadData('DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE');
        

        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;

        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        if (dsWorkingUserId[0]) {
            dsWorkingUserId = dsWorkingUserId[0].Value;
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.split('|')[0] : '';
            dsWorkingUserId = dsWorkingUserId ? dsWorkingUserId.trim() : '';
        }
        $scope.autoDistNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group;
        if (currentViewName == "ORI_VIEW") {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            if ($scope.strFormId && $scope.strIsDraft == "NO") {
                $scope.oriMsgFields.DS_AUTODISTRIBUTE = "";
            }

            setContractlist();
            buildRecipientlist();
            buildActionslist();
            setContractorlist();
            setSectionlist();
            if ($scope.strIsDraft == "YES") {
                var chkPermission = strIsUserDraftOnly();
                if (chkPermission.toLowerCase() == "yes")
                    setSendPermission("Draft");
                else
                    setSendPermission("Send");

                resetAllDates();
            }
        }
        if (currentViewName == "ORI_PRINT_VIEW") {
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var urlObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_CONTRACT, function (val) {
                return val.Value.split('|')[0].trim() == strConAppid.trim();
            });
            if (urlObj.length) {
                $scope.oriMsgCustomFields.Contract_URL = urlObj[0].URL;
            }
        }

        $scope.update();

        function calculateDistDate(days, callback) {
            var strDueDate = "";
            $scope.getServerTime(function (serverDate) {
                if (days) {
                    var d = new Date(serverDate);
                    d.setDate(d.getDate() + parseInt(days));
                    var month = d.getMonth() + 1;
                    var day = d.getDate();
                    strDueDate = d.getFullYear() + '-' +
                        (month < 10 ? '0' : '') + month + '-' +
                        (day < 10 ? '0' : '') + day;
                }
                callback(strDueDate);
            });
        }

        $scope.restrictCharOnlyNumber = function (event) {
            var validKeys = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 8, 46, 9, 190];

            switch (event.keyCode) {
                case 51:
                case 188:
                case 190:
                case 220:
                    if (event.shiftKey) {
                        alert(RESTRICT_CHAR_MSG);
                        event.preventDefault();
                    }
                    break;
            }

            if (validKeys.indexOf(event.keyCode) == -1) {
                event.preventDefault();
            }

        }

        $scope.restrictCharOnlyNumberPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                event.preventDefault();
                return false;
            }
        };

        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };

        function setContractlist() {
            if (DS_ASI_STD_ECC4_NEC_EMP_CONTRACT.length) {
                $scope.conData = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_NEC_EMP_CONTRACT.length; i++) {
                    $scope.conData.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_NEC_EMP_CONTRACT[i].Name,
                            modelValue: DS_ASI_STD_ECC4_NEC_EMP_CONTRACT[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.onContractchange = function (conVal) {
            if (conVal) {
                $scope.oriMsgCustomFields.DS_ASI_STD_ECC4_NEC_ALL_CONTRACT = conVal;
                var strParam = conVal.split('|')[0].trim();
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES, DS_ASI_STD_ECC4_NEC_ALL_CLAUSES, DS_ASI_STD_ECC4_NEC_CONTRACT_SUMMARY, DS_ASI_STD_ECC4_NEC_ALL_EWN, DS_ASI_STD_ECC4_NEC_CONTRACT_CONTRACTORS, DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS, DS_ASI_STD_ECC4_SETUP_SECTIONS,DS_ASI_STD_ECC4_NEC_ASITE_DM_USED, DS_ASI_STD_ECC4_NEC_BESPOKE, DS_ASI_STD_ECC4_NEC_FUNDINGTYPE,DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE,DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_ALL_CLAUSES",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_CONTRACT_SUMMARY",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_ALL_EWN",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_CONTRACT_CONTRACTORS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_SETUP_SECTIONS",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_ASITE_DM_USED",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_BESPOKE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_NEC_FUNDINGTYPE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE",
                            "fieldValue": strParam
                        }, {
                            "fieldName": "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
                            "fieldValue": strParam
                        }]
                    }
                };
                $scope.isDataLoaded = false;
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        DS_ASI_STD_ECC4_NEC_ALL_EWN = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_ALL_EWN']).Items.Item;
                        setEwnList();
                        DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS = angular.fromJson(response.data['DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS']).Items.Item;
                        setContractorlist();

                        DS_ASI_STD_ECC4_SETUP_SECTIONS = angular.fromJson(response.data['DS_ASI_STD_ECC4_SETUP_SECTIONS']).Items.Item;
                        setSectionlist();

                        var DS_ASI_GET_CURRENCY_FROM_CONTRACT = angular.fromJson(response.data['DS_ASI_GET_CURRENCY_FROM_CONTRACT']).Items.Item;
                        if (DS_ASI_GET_CURRENCY_FROM_CONTRACT.length) {
                            $scope.formCustomFields.Currency = DS_ASI_GET_CURRENCY_FROM_CONTRACT[0].Value2.trim();
                        }

                        var DS_ASI_STD_ECC4_NEC_ASITE_DM_USED = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_ASITE_DM_USED']).Items.Item;
                        var DS_ASI_STD_ECC4_NEC_BESPOKE = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_BESPOKE']).Items.Item;
                        var DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES']).Items.Item;
                        DS_ASI_STD_ECC4_NEC_ALL_CLAUSES = angular.fromJson(response.data['DS_ASI_STD_ECC4_NEC_ALL_CLAUSES']).Items.Item;
                        DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE = angular.fromJson(response.data['DS_ASI_STD_ECC4_LIST_QUO_WITHOUT_CE']).Items.Item;
                        setClauses(DS_ASI_STD_ECC4_NEC_ALL_CLAUSES);
                        $timeout(function () {
                            $scope.expandTextAreaOnLoad();
                        }, 1000);
                        var strFormStatusId = getFormStatusId("Closed");
                        if (strFormStatusId) {
                            $scope.autocreateformfields.ACF_01_DS_ALL_FORMSTATUS = strFormStatusId;
                        }
                        setFormContent();
                        setINCFormContent();
                        if (DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES.length) {
                            var keyDatesObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_KEY_CONTRACT_DATES, function (val) {
                                return val.Value2.trim() == "4";
                            });

                            if (keyDatesObj.length) {
                                $scope.asiteSystemDataReadwrite.tempDueDate = keyDatesObj[0].Value4.trim();
                            }
                        }

                        setAsiteDMUsedFlag(DS_ASI_STD_ECC4_NEC_ASITE_DM_USED);
                        setBespokeContractFlag(DS_ASI_STD_ECC4_NEC_BESPOKE);

                        var chkPermission = strIsUserDraftOnly();
                        if (chkPermission.toLowerCase() == "yes")
                            setSendPermission("Draft");
                        else
                            setSendPermission("Send");

                        $scope.isDataLoaded = true;
                    }
                });
                var arrStr = conVal.split('|');
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim();
                var strAllPmi = arrStr[0].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + "<<DS_AppBuilder_Id>>" + " | " + "<<DS_Form_ID>>" + " | " + " " + " | " + " " + " # " + "<<DS_Form_ID>>" + " | " + " " + " | " + " ";
                $scope.oriMsgCustomFields.DS_ASI_STD_ECC4_NEC_CONTRACT = conVal;
                $scope.autocreateformfields.ACF_01_DS_ASI_STD_ECC4_NEC_ALL_CONTRACT = strAllCon;
                $scope.autocreateformfieldsACF_01_DS_ASI_STD_ECC4_NEC_CONTRACT = conVal;
                $scope.autocreateformfields.ACF_01_Contract = arrStr[6].trim() + "-" + arrStr[7].trim();
                $scope.autocreateformfields.ACF_01_DS_ASI_STD_ECC4_NEC_ALL_PMI = strAllPmi;
                $scope.autocreateformfields.ACF_01_Notice_No = "<<DS_Form_ID>>";
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                $scope.oriMsgCustomFields.DS_ASI_STD_ECC4_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.autocreateformfields.ACF_01_Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.autocreateformfields.ACF_01_Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.autocreateformfields.ACF_01_Client_Logo = arrStr[3].trim();
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strParam;
                $scope.autocreateformfields.ACF_01_DS_FORMCONTENT1 = strParam;
                $scope.autocreateformfields.ACF_01_DS_CLOSE_DUE_DATE = "";
                $scope.autocreateformfields.ACF_01_Notice_Date = "";


                if (DS_ASI_STD_ECC4_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strNotes = notesObj[0].Value;
                        $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes.split('|')[3].trim();
                    }
                }
            }
        }

        function setContractorlist() {
            if (DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var lstcontractor = commonApi._.filter(DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS, function (val) {
                    return val.Value.split('|')[1].trim() == 'Contractor';
                });
                $scope.objContractor = [];
                for (var i = 0; i < lstcontractor.length; i++) {
                    $scope.objContractor.push({
                        optlabel: "",
                        options: [{
                            displayValue: lstcontractor[i].Name,
                            modelValue: lstcontractor[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function setSectionlist() {
            if (DS_ASI_STD_ECC4_SETUP_SECTIONS.length) {
                $scope.objSections = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_SETUP_SECTIONS.length; i++) {
                    $scope.objSections.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_SETUP_SECTIONS[i].Name,
                            modelValue: DS_ASI_STD_ECC4_SETUP_SECTIONS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function setEwnList() {
            if (DS_ASI_STD_ECC4_NEC_ALL_EWN.length) {
                $scope.objEwnlist = [];
                for (var i = 0; i < DS_ASI_STD_ECC4_NEC_ALL_EWN.length; i++) {
                    $scope.objEwnlist.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_ASI_STD_ECC4_NEC_ALL_EWN[i].Name,
                            modelValue: DS_ASI_STD_ECC4_NEC_ALL_EWN[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var strIsce = $scope.formCustomFields.Is_CE;
            strFormContent = strConAppid + "|" + strIsce;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }

        function buildRecipientlist() {
            if (DS_PROJDISTUSERS.length) {
                $scope.objRecipients = [];
                for (var i = 0; i < DS_PROJDISTUSERS.length; i++) {
                    $scope.objRecipients.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_PROJDISTUSERS[i].Name,
                            modelValue: DS_PROJDISTUSERS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        function buildActionslist() {
            if (DS_FORMACTIONS.length) {
                $scope.objActions = [];
                for (var i = 0; i < DS_FORMACTIONS.length; i++) {
                    $scope.objActions.push({
                        optlabel: "",
                        options: [{
                            displayValue: DS_FORMACTIONS[i].Name,
                            modelValue: DS_FORMACTIONS[i].Value,
                            checked: false
                        }]
                    });
                }
            }
        }

        $scope.onSectionChange = function (strVal) {
            if (strVal) {
                $scope.oriMsgCustomFields.Distribution_Section.Dist_Section_Code = strVal.split('|')[0].trim();
            }
            var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.asiteSystemDataReadwrite.DS_FORM_APPBUILDERCODE;
            var form = {
                "projectId": projectId,
                "formId": formId,
                "fields": "DS_ASI_STD_ECC4_SECTION_USERS,DS_ASI_STD_ECC4_SEC_LCK",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_ASI_STD_ECC4_SECTION_USERS",
                        "fieldValue": strParam
                    }, {
                        "fieldName": "DS_ASI_STD_ECC4_SEC_LCK",
                        "fieldValue": strParam
                    }]
                }
            };
            $scope.isSectionLoaded = false;
            $scope.getCallbackData(form).then(function (response) {
                if (response.data) {
                    var DS_ASI_STD_ECC4_SECTION_USERS = angular.fromJson(response.data['DS_ASI_STD_ECC4_SECTION_USERS']).Items.Item;
                    var DS_ASI_STD_ECC4_SEC_LCK = angular.fromJson(response.data['DS_ASI_STD_ECC4_SEC_LCK']).Items.Item;
                    if (DS_ASI_STD_ECC4_SEC_LCK.length) {
                        $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = DS_ASI_STD_ECC4_SEC_LCK[0].Name.trim();
                    }
                    $scope.oriMsgFields.DS_AUTODISTRIBUTE = "3"
                    $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    var strTouser = $scope.formCustomFields.DS_PROJUSERS_ROLE;
                    var struser = strTouser.split('|')[2].trim();
                    var strDays = $scope.asiteSystemDataReadwrite.tempDueDate;
                    var iAutodistId = 1;
                    calculateDistDate(strDays, function (retdate) {
                        setAutoDistribution(struser, "36#For Action", retdate, iAutodistId, strDays);
                    });

                    setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS, iAutodistId);
                }
            });
        }
        var iCount = 0;

        function setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS, iAutodistId) {
            if (DS_ASI_STD_ECC4_SECTION_USERS.length) {
                var strValue = "",
                    strAction = "",
                    strDueDays = "",
                    strDate = "";
                strValue = DS_ASI_STD_ECC4_SECTION_USERS[iCount].Value.split('|');
                strAction = strValue[2].trim() + "#" + strValue[3].trim();
                strDueDays = strValue[4].split('#')[0].trim();
                calculateDistDate(strDueDays, function (retdate) {
                    strDate = retdate
                    var strDistusersp = setRecipientUser(strValue[0].trim());
                    if (strCheckAction(strValue[2].trim()).trim() == "1") {
                        iAutodistId = parseInt(iAutodistId) + 1;
                        setAutoDistribution(strDistusersp, strAction, strDate, iAutodistId, strDueDays);
                    }
                    iCount++;
                    if (iCount < DS_ASI_STD_ECC4_SECTION_USERS.length)
                        setDistSectionUsers(DS_ASI_STD_ECC4_SECTION_USERS);
                    else
                        $scope.isSectionLoaded = true;
                });
            } else
                $scope.isSectionLoaded = true;
        }

        function setRecipientUser(strUserid) {
            var usersObj = commonApi._.filter(DS_PROJDISTUSERS, function (val) {
                return val.Value.trim().indexOf(strUserid) > -1;
            });
            if (usersObj.length) {
                return usersObj[0].Value.trim();
            }
            return "";
        }

        function strCheckAction(strActionId) {
            var strFound = "0";
            var actionsObj = commonApi._.filter(DS_FORMACTIONS, function (val) {
                return val.Value.trim().indexOf(strActionId) > -1;
            });
            if (actionsObj.length) {
                strFound = "1";
            }
            return strFound;
        }

        function setAutoDistribution(strUser, strAction, strDueDate, iAutodistId, strDueDays) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            structDistribution.AutoDist_Id = iAutodistId;
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.ActionDue_Group.DS_ACTIONDUEDATE = strDueDate;
            structDistribution.ActionDue_Group.DS_DUEDAYS = strDueDays;

            $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
        }

        function strIsUserDraftOnly() {
            if (DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_ASI_STD_ECC4_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }

        function setAsiteDMUsedFlag(DS_ASI_STD_ECC4_NEC_ASITE_DM_USED) {
            var strXmlIsDMUsed = "YES";
            if (DS_ASI_STD_ECC4_NEC_ASITE_DM_USED.length) {
                strXmlIsDMUsed = DS_ASI_STD_ECC4_NEC_ASITE_DM_USED[0].Name.trim();
            }
            $scope.oriMsgCustomFields.isAsiteDMUsed = strXmlIsDMUsed;
        }

        function setBespokeContractFlag(DS_ASI_STD_ECC4_NEC_BESPOKE) {
            var strXmlBContract = "NO"
            if (DS_ASI_STD_ECC4_NEC_BESPOKE.length) {
                strXmlBContract = DS_ASI_STD_ECC4_NEC_BESPOKE[0].Value1.trim();
            }
            $scope.formCustomFields.Bespoke_Contract.Access_Based = strXmlBContract;
            $scope.formCustomFields.Bespoke_Contract.CE_Access_Based = strXmlBContract;
        }

        function resetAllDates() {
            var distNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users;
            if (distNodes.length) {
                var strDays = "",
                    strDueDate = "";
                for (var i = 0; i < distNodes.length; i++) {
                    strDays = distNodes[i].ActionDue_Group.DS_DUEDAYS;
                    if (strDays) {
                        calculateDistDate(strDays, function (retdate) {
                            strDueDate = $scope.formatDate(new Date(retdate), 'yy-mm-dd');
                            distNodes[i].ActionDue_Group.DS_ACTIONDUEDATE = strDueDate;
                        });
                    }
                }
            }
        }

        $scope.onActionDueDateChange = function () {

            var strMsgFlag = "";
            var strDraftMsg = "";
            strMsgFlag = validatePastDate();
            if (strMsgFlag == "1") {
                strDraftMsg = "2|WARNING! You have assigned a past date to a review draft action.  Please click Cancel to select a date in the future or click OK and the action will be cleared when the draft version of the form is saved.";
            } else {
                strDraftMsg = "0"
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_DRAFT_MSG = strDraftMsg;
        }

        function validatePastDate() {
            var strMsgFlag = "0";
            var distNodes = $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users;
            var strDueDate = "",
                strFormActions = "",
                strDatediff = "";
            var strtodaydate = $scope.parseDate("yy-mm-dd", $scope.todayDateDbFormat);
            if (distNodes.length) {
                for (var i = 0; i < distNodes.length; i++) {
                    strFormActions = distNodes[i].DS_FORMACTIONS;
                    if (strFormActions && strFormActions.split('#')[1].trim().toLowerCase() == "review draft") {
                        strDueDate = distNodes[i].ActionDue_Group.DS_ACTIONDUEDATE;
                        if (strDueDate) {
                            strDueDate = $scope.parseDate("yy-mm-dd", strDueDate);
                            strDatediff = (strDueDate - strtodaydate) / 1000 / 60 / 60 / 24;
                            if (strDatediff < 0)
                                strMsgFlag = "1";
                        }
                    }

                }
            }
            return strMsgFlag;
        }

        function setFormContent1() {
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = $scope.autocreateformfields.ACF_01_EWN_Ref;
        }

        function setFormContent2() {
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = $scope.resMsgCustomFields.Total_Cost_Change;
        }

        function setFormContent3() {
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = $scope.resMsgCustomFields.Total_Programme_Change;
        }

        function setINCFormContent() {

            // This function sets the Form Content3 field
            //Format of Form Content is as under
            // Form Content - AppBuilder Id (CON) | Notice_No | PM_CE_Due_Date | Effects | Comments | EWN_Ref | Notice_Date |

            var strIncFormcontent, strEffects = "",
                strComments = "",
                strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId,
                strRefFormId = "<<DS_FORM_ID>>",
                strEWNRef = $scope.autocreateformfields.ACF_01_EWN_Ref,
                strNoticeDate = $scope.autocreateformfields.ACF_01_Notice_Date,
                strQUODueDate = $scope.autocreateformfields.ACF_01_QUO_Due_Date,
                strPMCEDue = $scope.autocreateformfields.ACF_01_PM_CE_Due_Date;

            strIncFormcontent = strConAppid + "|" + strRefFormId + "|" + strPMCEDue + "|" + strEffects + "|" + strComments + "|" + strEWNRef + "|" + strNoticeDate + "|" + strQUODueDate + "|";

            $scope.autocreateformfields.ACF_01_DS_FORMCONTENT = strIncFormcontent;
        }

        $scope.onEwnRefChange = function (strVal) {

            setFormContent1();
            setINCFormContent();
            if (strVal) {
                var stParam = strVal.split('|')[4].trim();
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_ASI_STD_ECC4_EWN_COST_CHANGES,DS_ASI_STD_ECC4_EWN_PROG_CHANGES",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_ASI_STD_ECC4_EWN_COST_CHANGES",
                            "fieldValue": stParam
                        }, {
                            "fieldName": "DS_ASI_STD_ECC4_EWN_PROG_CHANGES",
                            "fieldValue": stParam
                        }]
                    }
                };
                $scope.isEwnRefLoaded = false;
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        setEWNStatusChange("Closed")
                        var DS_ASI_STD_ECC4_EWN_COST_CHANGES = angular.fromJson(response.data['DS_ASI_STD_ECC4_EWN_COST_CHANGES']).Items.Item;
                        var DS_ASI_STD_ECC4_EWN_PROG_CHANGES = angular.fromJson(response.data['DS_ASI_STD_ECC4_EWN_PROG_CHANGES']).Items.Item;
                        setAllAutoCreateNodes(DS_ASI_STD_ECC4_EWN_COST_CHANGES, DS_ASI_STD_ECC4_EWN_PROG_CHANGES);
                        $scope.isEwnRefLoaded = true;
                    }
                });
            } else {
                $scope.autocreateformfields.DS_CHANGE_STATUS_IDS = "";
                flushAllAutoCreateNodes();
            }

        }

        function setEWNStatusChange(strStatus) {
            var strEwnAppid = $scope.autocreateformfields.ACF_01_EWN_Ref;
            $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_FORMS = strEwnAppid;
            var strFormStatusId = getFormStatusId(strStatus);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadwrite.Form_Status_Change.DS_CHANGE_STATUS_IDS = strFormStatusId;
            }
        }

        function flushAllAutoCreateNodes() {
            $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Cost_Changes.ACF_01_Impacted_Activities = [];
            var insertPoint = $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Cost_Changes.ACF_01_Impacted_Activities;
            var structActivity = angular.copy(STATIC_OBJ_DATA.ACF_01_Impacted_Activities);
            insertPoint.push(structActivity);
            $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Prog_Changes.ACF_01_Impacted_Key_Dates = [];
            var insertPointKey = $scope.autocreateformfields.ACF_01_Prog_Changes.ACF_01_Impacted_Key_Dates;
            var structkeys = angular.copy(STATIC_OBJ_DATA.ACF_01_Impacted_Key_Dates);
            insertPointKey.push(structkeys);
        }

        function setAllAutoCreateNodes(DS_ASI_STD_ECC4_EWN_COST_CHANGES, DS_ASI_STD_ECC4_EWN_PROG_CHANGES) {
            $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Cost_Changes.ACF_01_Impacted_Activities = [];
            var insertPoint = $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Cost_Changes.ACF_01_Impacted_Activities;
            var strCostChanges = 0;
            if (DS_ASI_STD_ECC4_EWN_COST_CHANGES.length) {
                var strSectionCode = "",
                    strActivityCode = "",
                    strActivityValue = "",
                    structActivity;

                for (var i = 0; i < DS_ASI_STD_ECC4_EWN_COST_CHANGES.length; i++) {
                    strSectionCode = DS_ASI_STD_ECC4_EWN_COST_CHANGES[i].Value1;
                    strActivityCode = DS_ASI_STD_ECC4_EWN_COST_CHANGES[i].Value2;
                    strActivityValue = DS_ASI_STD_ECC4_EWN_COST_CHANGES[i].Value3;
                    strCostChanges = strCostChanges + parseFloat(strActivityValue);
                    structActivity = angular.copy(STATIC_OBJ_DATA.ACF_01_Impacted_Activities);
                    structActivity.ACF_01_Section_Code = strSectionCode;
                    structActivity.ACF_01_Activity_Code = strActivityCode;
                    structActivity.ACF_01_Act_Current_Additions = strActivityValue;

                    insertPoint.push(structActivity);
                }
            }
            $scope.autocreateformfields.ACF_01_DS_FORMCONTENT2 = strCostChanges;
            $scope.autocreateformfields.ACF_01_LOWEST_ESTIMATE = strCostChanges;
            $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Prog_Changes.ACF_01_Impacted_Key_Dates = [];
            var insertPoint = $scope.autocreateformfields.ACF_01_REPEATING_VALUES.ACF_01_Prog_Changes.ACF_01_Impacted_Key_Dates;
            var strProgChanges = 0;
            if (DS_ASI_STD_ECC4_EWN_PROG_CHANGES.length) {
                var strKeyId = "",
                    strKeyValue = "",
                    structkeys;
                for (var i = 0; i < DS_ASI_STD_ECC4_EWN_PROG_CHANGES.length; i++) {
                    strKeyId = DS_ASI_STD_ECC4_EWN_PROG_CHANGES[i].Value1;
                    strKeyValue = DS_ASI_STD_ECC4_EWN_PROG_CHANGES[i].Value2;
                    strProgChanges = strProgChanges + parseFloat(strKeyValue);

                    structkeys = angular.copy(STATIC_OBJ_DATA.ACF_01_Impacted_Key_Dates);
                    structkeys.ACF_01_Key_Date_Id = strKeyId;
                    structkeys.ACF_01_KD_Current_Additions = strKeyValue;
                    insertPoint.push(structkeys);
                }
            }
            $scope.autocreateformfields.ACF_01_DS_FORMCONTENT3 = strProgChanges;
            $scope.autocreateformfields.ACF_01_Programme_Changes = strProgChanges;
        }

        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var statusObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statusObj.length) {
                    return statusObj[0].Value;
                }
            }
            return "";
        }

        function setClauses(DS_ASI_STD_ECC4_NEC_ALL_CLAUSES) {
            $scope.oriMsgCustomFields.ALL_Clauses_Grp.ALL_Clauses_List = [];
            var insertPoint = $scope.oriMsgCustomFields.ALL_Clauses_Grp.ALL_Clauses_List;
            if (DS_ASI_STD_ECC4_NEC_ALL_CLAUSES.length) {
                var strClauseNo = "",
                    strClauseID = "",
                    strClauseValue = "",
                    strClauseFullvalue = "",
                    structClauses;
                for (var i = 0; i < DS_ASI_STD_ECC4_NEC_ALL_CLAUSES.length; i++) {
                    strClauseNo = DS_ASI_STD_ECC4_NEC_ALL_CLAUSES[i].Value2.trim();
                    strClauseID = DS_ASI_STD_ECC4_NEC_ALL_CLAUSES[i].Value3.trim();
                    strClauseValue = DS_ASI_STD_ECC4_NEC_ALL_CLAUSES[i].Value4.trim();
                    strClauseFullvalue = DS_ASI_STD_ECC4_NEC_ALL_CLAUSES[i].Value5.trim();
                    structClauses = angular.copy(STATIC_OBJ_DATA.ALL_Clauses_List);
                    structClauses.Cl_No = strClauseNo;
                    structClauses.Cl_ID = strClauseID;
                    structClauses.CL_VAL = strClauseValue;
                    structClauses.Cl_ID_VAL = strClauseFullvalue;

                    insertPoint.push(structClauses);
                }
            }
        }

        $scope.onInstructiontypechange = function (strVal) {
            var strIsCE = "NO",
                strClause = "",
                strClauseNo = "",
                strClauseValue = "",
                strOption4 = "Option4";

            if (strVal == "14.3 A change to the Works Information or a Key Date or the manner in which the Contractor Provides the Works") {

                $scope.formCustomFields.Search_Toggle = "0";
                $scope.oriMsgCustomFields.Originator_ORI.Quotation_Submitted = false;
                $scope.oriMsgCustomFields.Originator_ORI.Early_Warning = false;
                $scope.oriMsgCustomFields.Approved_Quotation = "";

                var clauseObj = commonApi._.filter(DS_ASI_STD_ECC4_NEC_ALL_CLAUSES, function (val) {
                    return val.Value3.trim() == '60.1(1)';
                });
                if (clauseObj.length) {
                    strClause = clauseObj[0].Value2.trim();
                    strClauseNo = clauseObj[0].Value3.trim();
                    strClauseValue = clauseObj[0].Value4.trim();
                }

                strIsCE = "YES";
                strOption4 = "";
            } else if (strVal == "Any other instruction by the Project Manager which invokes a compensation event under clause 60.1 other than 60.1.(1)") {
                strIsCE = "YES";
                $scope.oriMsgCustomFields.Originator_ORI.Quotation_Submitted = false;
                $scope.oriMsgCustomFields.Originator_ORI.Early_Warning = false;
                $scope.oriMsgCustomFields.Approved_Quotation = "";
            }

            $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES[0].CEN_Event_Clause = strClause;
            $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES[0].ClauseNo = strClauseNo;
            $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES[0].Clause_Text = strClauseValue;
            $scope.oriMsgCustomFields.Originator_ORI.Option4 = strOption4;
            $scope.oriMsgCustomFields.Originator_ORI.Delete = "";
            $scope.oriMsgCustomFields.Originator_ORI.Add = "";
            $scope.oriMsgCustomFields.Originator_ORI.Amend = "";
            $scope.formCustomFields.Is_CE = strIsCE;
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 1000);
        }

        $scope.filterClauses = function (strVal) {
            var strClauseNo = "",
                strClauseDesc = "";
            if (strVal == "search") {
                strClauseNo = $scope.formCustomFields.Search_Filters.Clause_No;
                strClauseDesc = $scope.formCustomFields.Search_Filters.Clause_Description;
            } else if (strVal == "Reset") {
                $scope.formCustomFields.Search_Filters.Clause_No = "";
                $scope.formCustomFields.Search_Filters.Clause_Description = "";
            }
            $scope.formCustomFields.Temp_Search_Filters.TClause_No = strClauseNo;
            $scope.formCustomFields.Temp_Search_Filters.TClause_Description = strClauseDesc;
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 1000);
        }

        $scope.clauseFilter = function (strVal) {
            var strClauseNo = $scope.formCustomFields.Temp_Search_Filters.TClause_No.toLowerCase();
            var strClauseDesc = $scope.formCustomFields.Temp_Search_Filters.TClause_Description.toLowerCase();
            return (strVal.Cl_ID.toLowerCase().indexOf(strClauseNo) > -1 && strVal.CL_VAL.toLowerCase().indexOf(strClauseDesc) > -1);
        }

        $scope.assignClauses = function (currrObj) {
            var insertPoint = $scope.oriMsgCustomFields.CEN_EVENT_ALL_CLAUSES.CEN_EVENT_CLAUSES;
            var clauseObj = commonApi._.filter(insertPoint, function (val) {
                return val.ClauseNo.trim() == currrObj.Cl_ID;
            });
            if (clauseObj.length) {
                alert("Clause Already Added");
                return;
            }
            var structClauses = angular.copy(STATIC_OBJ_DATA.CEN_EVENT_CLAUSES);
            structClauses.ClauseNo = currrObj.Cl_ID;
            structClauses.Clause_Text = currrObj.CL_VAL;
            structClauses.Clause_Explanation = currrObj.CL_VAL;
            structClauses.CEN_Event_Clause = currrObj.Cl_No;
            insertPoint.push(structClauses);
        }
        $window.pmiFinalCallBack = function () {

            if ($scope.oriMsgCustomFields.Price_Inc == "No" && $scope.oriMsgCustomFields.Delay_Completion == "No" && $scope.oriMsgCustomFields.Impair_Performance == "No" && $scope.oriMsgCustomFields.Delay_Meeting == "No" && $scope.oriMsgCustomFields.Work_employer == 'No' && $scope.oriMsgCustomFields.breach_consent == "No" && $scope.oriMsgCustomFields.party_costs == "No" && $scope.oriMsgCustomFields.defined_cost == "No") {
                alert("Select Atleast one event");
                return true;
            }
            setFormContent1();
            setFormContent2();
            setFormContent3();
            setINCFormContent();
            setFormContent();
            return false;
        }

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pmiFinalCallBack !== "undefined") {
        return pmiFinalCallBack();
    }
}