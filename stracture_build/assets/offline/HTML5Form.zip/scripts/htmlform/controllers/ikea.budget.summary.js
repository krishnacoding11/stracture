
define(['angular', "mainModule", './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $filter, $timeout) {
		var ctrl = this;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.Codes_Group_Bunch = $scope.oriMsgCustomFields.Codes_Group_Bunch;
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.editForward = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] && $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT != 'YES';
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isResPrintView = (window.currentViewName == 'RES_PRINT_VIEW');
		$scope.CurrformStatus  = angular.element('#DS_FORMSTATUS').val() || "";
		$scope.duplicateProjectCode = false;
		var STATIC_OBJ = {
			CODE_GROUP: {
				Group_Code: "",
				Group_Name: "",
				Group_Code_GUID: "",
				Is_Default: "no",
				Is_Finalized: "no",
				Code_List_group: {
					Code_list: []
				},
				Total_Approved_Budget: "",
				Total_Managed_Budget: "",
				Total_Budget_Modification: "",
				Total_Cost_Sqft_of_GBA: "",
				Total_Contracts: "",
				Total_Approved_Amendments: "",
				Total_Unapproved_Amendments: "",
				Total_Balance_Budget: "",
				Total_Final_Cost: "",
				Total_Approved_Payment: "",
				Total_Balance_to_Finish: "",
				Total_Deviation: ""
			},
			COST_CODE: {
				Code: "",
				Cost_Name: "",
				Code_GUID: "",
				Code_Parent_GUID: "",
				Is_Default: "no",
				Approved_Budget: "",
				Managed_Budget: "",
				Budget_Modification: "",
				Cost_Sqft_of_GBA: "",
				Contracts: "",
				Approved_Amendments: "",
				Unapproved_Amendments: "",
				Balance_Budget: "",
				Final_Cost: "",
				Approved_Payment: "",
				Balance_to_Finish: "",
				Deviation: ""
			}
		},
		CONSTANTS_OBJ = {
			IMAGE_DEFAULT_STR: 'images/asite.gif',
			OPEN: "Open",
			APPROVED_FINAL:"approved - final",
			APPROVED:"approved",
			REVISE_RESUBMIT: "revise and resubmit",
			COST_ORIGINATOR: "Budget Originator",
			FOR_INFO: "7#For Information",
			ORI_ACTION_CODE: "3",
		},
		dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'],
		DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var isDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT == 'NO' ? false : true;
			
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			if (!dSFormId || isDraft) {
				var serverDateObj = new Date(serverDate);
				serverDateObj.setDate(serverDateObj.getDate() + 7);
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
			}
		});

		if($scope.isOriView){
			var curStatus = $scope.CurrformStatus.toLowerCase();
			$scope.isCostOriginator = hasCostOriginatorinROle();
			$scope.currencyList = getConfigurableAttriburteByType('Currency');
			$scope.hideSaveDraftButton();
			if(!isDraft && !dSFormId){
				var logos = getLefRightLogo();
				$scope.oriMsgCustomFields.leftLogo =  logos[0];
				$scope.oriMsgCustomFields.rightLogo =  logos[1];
				loadConfig();
			}
			// to edit and forward availabel for given status
			$scope.isAvailforEditAndForward = (curStatus == CONSTANTS_OBJ.REVISE_RESUBMIT || curStatus == CONSTANTS_OBJ.APPROVED_FINAL);
			
			if(curStatus == CONSTANTS_OBJ.APPROVED_FINAL && $scope.oriMsgCustomFields.AddedForApprovedFinal != 'yes'){
				fixCodeandUpdateManagedBudget();
				$scope.oriMsgCustomFields.AddedForApprovedFinal = 'yes';
			}
			if(dSFormId && !isDraft){
				hideimportFromExcel();
			}
		}
		if($scope.isRespView){
			var curUserId = $scope.getWorkingUserId();
			var currUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
			$scope.hasResponseAction = false;
			var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS').filter(function(item){
				return item.Name.toLowerCase() == 'respond'  && item.Value.indexOf(curUserId) > -1;
				});
			if(incompleteAction.length){
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
				$scope.resMsgCustomFields.Comments = "";
				if(currUser && currUser.length){
					$scope.resMsgCustomFields.responseBy = currUser[0].Name;
				}
				
				$scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS')
				$scope.availableStatus = commonApi.getItemSelectionList({
					arrayObject: $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
					groupNameKey: "",
					modelKey: "Value",
					displayKey: "Name"
				});
				$scope.hasResponseAction = true;
			}
		}
		if($scope.isOriPrintView || $scope.isResPrintView){
			$scope.ContractAMDINVDetails = $scope.getValueOfOnLoadData('DS_IKEA_Form_BSF_CON_CAM_INV_List');
			setCOntractINvoiceDataINList($scope.ContractAMDINVDetails);
			bindTableScollEvent("budget-items-scroll-wrapper", "bud-table-header");
			$scope.hideExportBtn();
		}

		function getLefRightLogo(){
			var logos = getConfigurableAttriburteByType('Logo');
			var logoLeft = CONSTANTS_OBJ.IMAGE_DEFAULT_STR, logoRight = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
			angular.forEach(logos, function(item){
				if(item.Value7 && item.Value7.toLowerCase() == 'left logo'){
					logoLeft = item.Value8;
				}
				if(item.Value7 && item.Value7.toLowerCase() == 'right logo'){
					logoRight = item.Value8;
				}
			})
			return [logoLeft, logoRight];
		}

		function bindTableScollEvent(tableId, headerClass) {
            var objTableWrapper = document.getElementById(tableId);
            var objHeaderTR = $element.find('.' + headerClass).parent();

            angular.element(objTableWrapper).bind('scroll', function (event) {
                objHeaderTR.scrollLeft(event.target.scrollLeft);
            });
		}
		
		/**
		 * set contract, invoice, amendment data in list 
		 * @param {array} ContractAMDINVDetails: dataget from sp
		 */
		function setCOntractINvoiceDataINList(ContractAMDINVDetails){
			if(!ContractAMDINVDetails || !ContractAMDINVDetails.length){
				return;
			}
			var selectedItem, selectedGroup;
			angular.forEach($scope.Codes_Group_Bunch.Codes_Group, function(item){
				angular.forEach(item.Code_List_group.Code_list, function(subItem){
					selectedItem = commonApi._.find(ContractAMDINVDetails, function(conInvItem){
						return conInvItem.Value6 == subItem.Code_GUID;
					})
					if(selectedItem){
						subItem.Contracts = selectedItem.Value13;
						subItem.Approved_Amendments = selectedItem.Value14;
						subItem.Unapproved_Amendments = selectedItem.Value15;
						subItem.Balance_Budget = selectedItem.Value16;
						subItem.Final_Cost = selectedItem.Value17;
						subItem.Approved_Payment = selectedItem.Value18;
						subItem.Balance_to_Finish = selectedItem.Value19;
						subItem.Deviation = selectedItem.Value20;
					}
				});
				selectedGroup = commonApi._.find(ContractAMDINVDetails, function(conInvItem){
					return conInvItem.Value4 == item.Group_Code_GUID;
				});
				if(selectedGroup){
					item.Total_Contracts = selectedGroup.Value25;
					item.Total_Approved_Amendments = selectedGroup.Value26;
					item.Total_Unapproved_Amendments = selectedGroup.Value27;
					item.Total_Balance_Budget = selectedGroup.Value28;
					item.Total_Final_Cost = selectedGroup.Value29;
					item.Total_Approved_Payment = selectedGroup.Value30;
					item.Total_Balance_to_Finish = selectedGroup.Value31;
					item.Total_Deviation = selectedGroup.Value32;
				}
			});
		}
		
		/**
		 * Return true if working yuser has cost originator role
		 */
		function hasCostOriginatorinROle(){
			var aUserRoles = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
			if(aUserRoles && aUserRoles.length && aUserRoles[0].Value){
				var found = commonApi._.find(aUserRoles[0].Value.split(','), function(item){
					return item.trim().toLowerCase() == CONSTANTS_OBJ.COST_ORIGINATOR.toLowerCase();
				})
				return !!found;
			}else{
				return false;
			}
		}
		
		function hideimportFromExcel(){
			$timeout(function () {
				var objGetExcelComponent = document.getElementsByClassName('component-wrapper');
				if (objGetExcelComponent && objGetExcelComponent.length) {
					objGetExcelComponent[0].style.display = 'none';
				}
			});
		}

		/**
		 * return array custom attribute is matched with attribute name
		 * @param {string} type: confugured attrbite name
		 */
		function getConfigurableAttriburteByType(type){
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var AttributeByType = [];
			if(type){
				AttributeByType = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
					Value3: type,
					Value11: "Active"
				});
			}
			return AttributeByType;
		}

		/* This function load data of config.json file, 
        *  which added in .zip file,
        *  @param:callback which occures after load config file
        **/
	   function loadConfig(callback) {
			commonApi.fetchConfigData(function (response) {
				var CONFIG_code_groups = response.data.Codes_Groups || [];
				var costGroup, CostCode, groupId;
				if (!isDraft && !dSFormId) {
					$scope.Codes_Group_Bunch.Codes_Group = []
					angular.forEach(CONFIG_code_groups, function(item){
						groupId = commonApi.guId();
						costGroup = angular.copy(STATIC_OBJ.CODE_GROUP);
						costGroup.Group_Code = item.Group_Code;
						costGroup.Group_Name = item.Group_Name;
						costGroup.Group_Code_GUID = groupId;
						costGroup.Is_Default = 'yes';
						angular.forEach(item.Code_list, function(subitem){
							CostCode = angular.copy(STATIC_OBJ.COST_CODE)
							CostCode.Code = subitem.Code;
							CostCode.Cost_Name = subitem.Cost_Name;
							CostCode.Code_GUID = commonApi.guId();
							CostCode.Code_Parent_GUID = groupId;
							CostCode.Is_Default = 'yes';
							costGroup.Code_List_group.Code_list.push(CostCode);
						})
						$scope.Codes_Group_Bunch.Codes_Group.push(costGroup);
					});
				}
				callback && callback();
			});
		}

		/**
		 * set form status
		 * @param {string} StrStatus: status to set
		 */
		function updateFormStatus(StrStatus) {
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var _Status = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = _Status;
				}
			}
		}
		
		/**
		 * fixing code and group if status is approved - fianl and ading Budget_Modification to Managed_Budget 
		 * Update total value of managed budget and budget modification
		 */
		function fixCodeandUpdateManagedBudget(){
			angular.forEach($scope.Codes_Group_Bunch.Codes_Group, function(item){
				if(item.Group_Code_GUID){
					item.Is_Group_Finalized = 'yes'
				}
				item.Total_Managed_Budget = 0;
				item.Total_Budget_Modification = 0;
				item.Total_Cost_Sqft_of_GBA = 0;
				if(item.Code_List_group && item.Code_List_group.Code_list){
					angular.forEach(item.Code_List_group.Code_list, function(subitem){
						subitem.Is_Finalized = 'yes';
						subitem.Managed_Budget = Number(subitem.Managed_Budget) + Number(subitem.Budget_Modification);
						subitem.Budget_Modification = "";
						item.Total_Managed_Budget = item.Total_Managed_Budget + Number(subitem.Budget_Modification);
						subitem.Cost_Sqft_of_GBA = Number(subitem.Managed_Budget) / Number($scope.oriMsgCustomFields.Gross_Building_Area);
						item.Total_Cost_Sqft_of_GBA = item.Total_Cost_Sqft_of_GBA + Number(subitem.Cost_Sqft_of_GBA)
					})
				}
			});
		}

		/**
		 * invoked on form send
		 * add guid to group and cost code item if guid is not present
		 * remove selection from cost code is selected
		 */
		function addGUIDsAndRemoveSelectionFromList(){
			angular.forEach($scope.Codes_Group_Bunch.Codes_Group, function(item){
				if(!item.Group_Code_GUID){
					item.Group_Code_GUID = commonApi.guId();
				}
				if(item.Code_List_group && item.Code_List_group.Code_list){
					angular.forEach(item.Code_List_group.Code_list, function(subitem){
						if(subitem.isRecordSelected){
							subitem.isRecordSelected = false;
						}
						if(!subitem.Code_GUID){
							subitem.Code_GUID = commonApi.guId();
						}
						subitem.Code_Parent_GUID = item.Group_Code_GUID;
					})
				}
			});
		}

		/**
		 * cumpute and set total value for cost code and group
		 * 
		 */
		function computeTOtalForGroup(){
			var grandAprBud = 0, grandmangeBud = 0, grandmodificationBud = 0, grandCostSqftOfGBA = 0;
			angular.forEach($scope.Codes_Group_Bunch.Codes_Group, function(item){
				item.Total_Approved_Budget = 0;
				item.Total_Managed_Budget = 0;
				item.Total_Budget_Modification = 0;
				item.Total_Cost_Sqft_of_GBA = 0;
				if(item.Code_List_group && item.Code_List_group.Code_list){
					angular.forEach(item.Code_List_group.Code_list, function(subitem){
						item.Total_Approved_Budget = item.Total_Approved_Budget + Number(subitem.Approved_Budget)
						item.Total_Managed_Budget = item.Total_Managed_Budget + Number(subitem.Managed_Budget)
						item.Total_Budget_Modification = item.Total_Budget_Modification + Number(subitem.Budget_Modification)
						subitem.Cost_Sqft_of_GBA = (Number(subitem.Managed_Budget) + Number(subitem.Budget_Modification)) / Number($scope.oriMsgCustomFields.Gross_Building_Area);
						item.Total_Cost_Sqft_of_GBA = item.Total_Cost_Sqft_of_GBA + Number(subitem.Cost_Sqft_of_GBA)
					})
				}
				grandAprBud = grandAprBud + Number(item.Total_Approved_Budget);
				grandmangeBud = grandmangeBud + Number(item.Total_Managed_Budget);
				grandmodificationBud = grandmodificationBud + Number(item.Total_Budget_Modification);
				grandCostSqftOfGBA = grandCostSqftOfGBA + Number(item.Total_Cost_Sqft_of_GBA);
			});
			$scope.oriMsgCustomFields.Grand_Approved_Budget = grandAprBud;
			$scope.oriMsgCustomFields.Grand_Managed_Budget = grandmangeBud;
			$scope.oriMsgCustomFields.Grand_Budget_Modification = grandmodificationBud;
			$scope.oriMsgCustomFields.Grand_Cost_Sqft_of_GBA = grandCostSqftOfGBA;
		}

        $scope.checkDuplicate = function (ProjCode, submitType){
			if(!ProjCode){
				$scope.duplicateProjectCode = false;
				return;
			}
			$scope.uniqueNameValidationXHR = true;
			var spName = "DS_IKEA_validate_Project_Code_BSF";
			var form =  {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": spName,
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": spName,
						"fieldValue": ProjCode.trim()
					}]
				}
			};
			$scope.getCallbackData(form).then(function (response) {
				var respItems = angular.fromJson(response.data[spName]).Items.Item;
				$scope.uniqueNameValidationXHR = false;
				if(respItems[0].Value2 && respItems[0].Value2.toLowerCase() == 'yes'){
					$scope.duplicateProjectCode = true;
					$scope.submitFlag = false;
					if(submitType){
						alert('Duplicate Project Code');
					}
				}else{
					$scope.duplicateProjectCode = false;
					if(submitType && (submitType == 'send' || submitType == 'draft')){
						$scope.submitFlag = true;
						if(submitType == 'send'){
							$window.submitForm(1);
						}else{
							$window.submitForm(0);
						}
					}
				}
			}, function (errorObj) {
				Notification.error({
					title: 'Server Error',
					message: 'Error while Validation Check.'
				});
				$scope.duplicateProjectCode = false;
				$scope.uniqueNameValidationXHR = false;
			});
		};

		/**
		 * check for date comarission validation and give alert
		 * @param {string} date1: start date
		 * @param {string} date2: end date
		 * @param {string} changedfield: which field is changed in oriMsgCustomFields
		 */
		$scope.validateMinMaxDate = function(date1, date2, changedfield){
			if(date1 && date2 && date1 > date2 ){
				alert('End date should not be less than start date.');
				$scope.oriMsgCustomFields[changedfield] = "";
			}
		}

		$scope.grossBuildChange = function(){
			var grossbildArea = $scope.oriMsgCustomFields.Gross_Building_Area;
			if(grossbildArea && Number(grossbildArea) <= 0){
				alert('Gross building area should not be Nagative or Zero.');
				$scope.oriMsgCustomFields.Gross_Building_Area = '';
			}
		};

		/**
		 * return user with given role
		 * @param {array} role: array of role names 
		 */
		function getArrayOfUserbyRole(role){
			var projUserWithRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			var userArray= [], added;
			for(var i=0; i<projUserWithRole.length; i++){
				var userRoles = projUserWithRole[i].Value.split('|')[0].split(',');
				added = false;
				for(var j=0; j<userRoles.length; j++){
					if(!added && userRoles[j].toLowerCase().trim() == role.toLowerCase()){
						userArray.push(projUserWithRole[i].Value.split('|')[2].trim());
						added = true;
					}
				}
			}
			return userArray;
		}

		/**
		 * Commen function to assing action to user
		 * @param {*} userToDist: array or string users list or sing user 
		 * @param {string} action: action to assign
		 * @param {string} DS_AUTODISTRIBUTE
		 * @param {*} distDate: due date fo action
		 */
		function assignActionToUser(userToDist, action, DS_AUTODISTRIBUTE, distDate){
			var tempList = [];
			if(angular.isArray(userToDist) && userToDist.length){
				for (var j = 0; j < userToDist.length; j++) {
					tempList.push({
						strUser: userToDist[j],
						strAction: action,
						strDate: distDate
					});
				}
			}else{
				tempList.push({
					strUser: userToDist,
					strAction: action,
					strDate: distDate
				});
			}
			commonApi.setDistributionNode({
				actionNodeList: tempList,
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: DS_AUTODISTRIBUTE
			});
		}

		$scope.tableUtilSettings = {
			costCode: {
				tooltip: "select to remove/remove all Row",
				hasDefaultRecord: false,
				checkboxModelKey: "isRecordSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore: 0,
					insertAfter: 0,
					deleteAllRow: 0
				},
				newStaticObject: angular.copy(STATIC_OBJ.COST_CODE),
				deleteCurrRowMsg: "Remove Row",
				deleteSelectedMsg: "Remove selected Row"
			}
		};

		$scope.addNewItem = function (list, addItemFor) {
			var copiedObj = angular.copy(STATIC_OBJ[addItemFor]);
			$scope.addRepeatingRow(list, copiedObj);
		};
		
		$scope.deleteItem = function (list, index) {
			list.splice(index, 1);
		};

		$scope.update();
		
		/**
		 * invoked on form submit
		 * check unique wbs code for concurrency
		 * Set guid to all table row, set planned total for table, sets matrial dummy node to show section total
		 */
		$window.oriformSubmitCallBack = function () {
			var orimsg = $scope.oriMsgCustomFields;
			if($scope.isOriView){
				if($scope.editForward && !$scope.isCostOriginator){
					alert('You are not allowed to edit and forward')
					return true;
				}
				if($scope.editForward && $scope.isCostOriginator && !$scope.isAvailforEditAndForward){
					alert('Approval in progress')
					return true;
				}
				if(!$scope.editForward){
					if($scope.uniqueNameValidationXHR){
						alert('Wait, Project code validation check request running');
						return true;
					}
					if(!$scope.submitFlag && orimsg.Project_Code){
						$scope.checkDuplicate(orimsg.Project_Code, 'send');
						return true;
					}
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = $scope.oriMsgCustomFields.Project_Code;
				}
				$scope.oriMsgCustomFields.ORI_FORMTITLE =  $scope.oriMsgCustomFields.Project_Name;
				$scope.oriMsgCustomFields.ORI_USERREF =  $scope.oriMsgCustomFields.Project_Code;
				addGUIDsAndRemoveSelectionFromList();
				computeTOtalForGroup();
				$scope.oriMsgCustomFields.Budget_Rev = Number($scope.oriMsgCustomFields.Budget_Rev) + 1;
				assignActionToUser(getArrayOfUserbyRole(CONSTANTS_OBJ.COST_ORIGINATOR), CONSTANTS_OBJ.FOR_INFO, CONSTANTS_OBJ.ORI_ACTION_CODE, '');
				updateFormStatus(CONSTANTS_OBJ.OPEN);
				$scope.oriMsgCustomFields.AddedForApprovedFinal = 'no';
				orimsg.isRespView = 'no';
			}
			if($scope.isRespView){
				if(!$scope.hasResponseAction){
					alert('You are not authorized to response.');
					return true;
				}
				orimsg.isRespView = 'yes';
			}
			return false;
		};
		$window.draftSubmitCallBack = function () {
			var orimsg = $scope.oriMsgCustomFields;
			if($scope.isOriView){
				if($scope.editForward && !$scope.isCostOriginator){
					alert('You are not allowed to edit and forward')
					return true;
				}
				if($scope.editForward && $scope.isCostOriginator && !$scope.isAvailforEditAndForward){
					alert('Approval in progress')
					return true;
				}
				if(!$scope.editForward){
					if($scope.uniqueNameValidationXHR){
						alert('Wait, Project code validation check request running');
						return true;
					}
					if(!$scope.submitFlag && orimsg.Project_Code){
						$scope.checkDuplicate(orimsg.Project_Code, 'draft');
						return true;
					}
					$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = $scope.oriMsgCustomFields.Project_Code;
				}
				$scope.oriMsgCustomFields.ORI_FORMTITLE =  $scope.oriMsgCustomFields.Project_Name;
				$scope.oriMsgCustomFields.ORI_USERREF =  $scope.oriMsgCustomFields.Project_Code;
				orimsg.isRespView = 'no';
			}
			if($scope.isRespView){
				if(!$scope.hasResponseAction){
					alert('You are not authorized to response.');
					return true;
				}
				orimsg.isRespView = 'yes';
			}
			return false;
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}