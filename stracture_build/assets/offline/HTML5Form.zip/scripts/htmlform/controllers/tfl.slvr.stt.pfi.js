/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base',  '../components/item.selection','../components/number-format','../components/table.util'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = $window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
        });

        var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy", "nl_NL": "dd-M-yy" };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            // Appbuidler codes of forms
            changeAppraisal: "STT-CAF",
            supplierChangeNotice: "STT-SCN",
            projectChangeNotice: "STT-PCN",
            changeAppraisalInstruction: "STT-CAI",
            changeConfirmNotice: "STT-CCN",
            initChangeAppraisal: "STT-ICA",

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            // Static role used in Code
            tflRepresentative: "TFL Representative",
            preojectManager: "Project Manager",
            contractor: "Contractor",
           
            //dropdown menu key and label
            Qualifying_LIST_KEY: 'qualifying-list',
            Qualifying_LIST_LABEL: 'Qualifying Event Lists',
            Relief_LIST_KEY: 'Relief-list',
            Relief_LIST_LABEL: 'Relief Event Lists',

            // Data source 
            dsSttNnecSertuoSections: "DS_STT_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_STT_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_STT_SECTION_USERS",
            dsSttNnecSecLck: "DS_STT_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_STT_ALL_CONTRACT_TEAM_MEMBERS",
            dsAsiGetCurrencyFromContract: "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
        }

        var STATIC_OBJ_DATA = {
            Auto_Distribute_Users: {
                "DS_PROJDISTUSERS": "",
                "DS_FORMACTIONS": "",
                "DS_ACTIONDUEDATE": "",
                "DS_DUEDAYS": "",
                "AutoDist_Id": 1,
                "dist_isSelected": false,
                "isEditable": "1"
            }
        }

        $scope.tableUtilSettings = {
            Auto_Distribute_Users: {
                tooltip: "select to remove/remove all/Insert new Record",
                hasDefaultRecord: false,
                hideControlIcon: {
                    editRow: 0
                },
                checkboxModelKey: "dist_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users)
            }
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.impactDetails = $scope.oriMsgCustomFields['impactDetails'];
        var DS_STT_ALL_CONTRACT_TEAM_MEMBERS = $scope.getValueOfOnLoadData('DS_STT_ALL_CONTRACT_TEAM_MEMBERS');
        var dsSttPfiOrgConctract = $scope.getValueOfOnLoadData('DS_STT_NEC_ORG_CONTRACT');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_INCOMPLETE_MSG_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_STT_NEC_CONTRACT'); 
        var dsSttReveandQuaeFormDtls = $scope.getValueOfOnLoadData('DS_STT_REVE_AND_QUAE_FORM_DTLS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        var dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        dsWorkingUser = dsWorkingUser ? dsWorkingUser.value : '';
        var dsWorkingUserId = $scope.getWorkingUserId();
        var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();
       
        if (currentViewName == "ORI_VIEW"){
            var workingUser = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.split('#')[0].replace('|','#').replace(',',' ,').trim();
			$scope.oriMsgCustomFields.originator = workingUser.replace('|','#').trim();
        }
        if(currentViewName == 'RES_PRINT_VIEW' || currentViewName == 'ORI_PRINT_VIEW'){
            initFormData();
            //to Hide Export Button in print view
            angular.element(".export-btn").hide();
        }   
        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
            $scope.isConSelected = false;
            $scope.dropdownObj = {
                contractList: [],             
                tflReprentList : [],
                contractorList: [],
                distSectionsList: [],
                formActionList: [],
                distUsersList: []
            };

            fillDropwdowns();
            $scope.qualifyingList = structureItemList(TFL_CONSTANT.Qualifying_LIST_KEY,dsSttReveandQuaeFormDtls);
             $scope.reliefList = structureItemList(TFL_CONSTANT.Relief_LIST_KEY,dsSttReveandQuaeFormDtls);
             
            if (!$scope.oriMsgCustomFields['ContractNo']) {
                $scope.isConSelected = false;
            } else {
                $scope.isConSelected = true;
                if (currentViewName == "ORI_VIEW") {
                    onContractChange();
                }    
            }

            initFormData();
            $scope.update();
        } else {
            for (var i = 0; i < $scope.linkContractURL.length; i++) {
                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            } 
            for(var i=0; i< dsSttReveandQuaeFormDtls.length; i++){
                if(dsSttReveandQuaeFormDtls[i] && dsSttReveandQuaeFormDtls[i].Value5){
                    $scope.linkFormURL = dsSttReveandQuaeFormDtls[i].URL5;
                    break;
                }
            }          
            $scope.update();
        }

        /**
         * 
         * @param {*} setFor list key
         * @param {*} availList SP Variable On Load Data
         */
         function structureItemList(setFor, availList) {
            var tempList = [],
                optlabel = '';

            switch (setFor) {
                case TFL_CONSTANT.Qualifying_LIST_KEY:  
                    angular.forEach(availList, function (item) {
                        var event = item.Value4.split("-")[1]
                        if(event.charAt() == 'Q'){
                            tempList.push({
                                displayValue: item.Value2 + ' '+ item.Value3,
                                modelValue: item.Value2,
                            });
                        }
                    });
                    optlabel = TFL_CONSTANT.Qualifying_LIST_LABEL;
                    break;
                case TFL_CONSTANT.Relief_LIST_KEY:
                    angular.forEach(availList, function (item) {
                        var event = item.Value4.split("-")[1]
                        if(event.charAt() == 'R'){
                            tempList.push({
                                displayValue: item.Value2 + ' '+ item.Value3,
                                modelValue: item.Value2,
                            });
                        }
                    });
                    optlabel = TFL_CONSTANT.Relief_LIST_LABEL;
                    break;
            }
            return [{
                optlabel: optlabel,
                options: tempList
            }];
        };

        
        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };

        $scope.onContractChange = onContractChange;

        function onContractChange() {
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            var tempConAppCode = commonApi._.filter(contractDataArray, function (mapObj) {
                return mapObj.contractID == contractNumber;
            })[0];

            if ($scope.linkContractURL.length) {
                if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                    var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                        return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes) {
                            $scope.asiteSystemDataReadWrite.Dist_Guidance_Notes = strNotes;
                        }    
                    }
                }    
            } 
            loadClientLogo(tempConAppCode);
            tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

            if (tempConAppCode) {
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSertuoSections,
                        "fieldValue": tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                        "fieldValue": tempConAppCode
                    },{
                        "fieldName": TFL_CONSTANT.dsAsiGetCurrencyFromContract,
                        "fieldValue": tempConAppCode
                    }],

                    successCallback: contractChangeCallback
                };
                    $scope.getCallbackSPdata(spParam);
                }        
        }

        $scope.onSectionChange = function (strVal) {
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            if (strVal) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue": strParam
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue": strParam
                    }],
                    successCallback: sectionChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        function fillDropwdowns() {

            // Contract downdown

            for (var i = 0; i < dsSttPfiOrgConctract.length; i++) {
                var obj = dsSttPfiOrgConctract[i];
                obj = obj.Value ? obj.Value.split('|') : [];
                if (obj.length) {
                    contractDataArray.push({
                        contractID: obj[2].trim(),
                        contractorLogo: obj[4].trim(),
                        clientLogo: obj[5].trim(),
                        contractName: obj[8].trim(),
                        contractAppCode: obj[0].trim(),
                        contractIdName: dsSttPfiOrgConctract[i].Name
                    });
                }
            }

            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });

            //TFL Representative Dropdown
            var tflRepresentativeArray = []
            for(var i=0; i<dsProjUserRole.length; i++){
                var element = dsProjUserRole[i];
                if(element.Value.indexOf(TFL_CONSTANT.tflRepresentative) > -1){
                    tflRepresentativeArray.push({
                        userName: element.Name,
                        userId: element.Value
                    })
                }

            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject : tflRepresentativeArray,
                groupNameKey : "",
                modelKey : "Value",
                displayKey : "Name"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })
            
            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })

        }
        
        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(contractData) {
            $scope.oriMsgCustomFields.contractorLogo = contractData.contractorLogo || TFL_CONSTANT.defaultLogo;
            $scope.oriMsgCustomFields.clientLogo = contractData.clientLogo || TFL_CONSTANT.defaultLogo;            
        }

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList){
            
            var sectionUsersData = spDataList[ TFL_CONSTANT.dsSttNnecSectionUsers ];
            var distLockflag = spDataList[ TFL_CONSTANT.dsSttNnecSecLck ];

            if (distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            for (var i =0; i<sectionUsersData.length; i++) {			
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');
                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0] ) ? nodeVal[4].split('#')[0].trim() : 3 ;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days : parseInt( distDate.trim() )
                    })                
                }    

                var strMatchAction = nodeVal[2].trim() + '#' +nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";

                // To conver Username like Pratik Parkeh , Asite Solutions to Pratik Parkeh, Asite Solutions because DS_PROJDISTUSERS returns diffent name
                var userName = setRecipientUser(nodeVal[0].trim());
                var userIdName = userName.split("#")[1].replace(' ,',',').trim();
                // var userName = nodeVal[1] && nodeVal[1].replace(' ,',',');
                tempList.push({
                    strUser : nodeVal[0].trim() + "#" + userIdName.trim(),
                    strAction :strAction,//"7#For Information",
                    strDate : distDate
                });                
            }

            commonApi.setDistributionNode({
                actionNodeList : tempList,
                autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE : 3
            });
        }

        function setRecipientUser(strUserid) {
            var usersObj = commonApi._.filter(dsProjDistUsers, function (val) {
                return val.Value.trim().indexOf(strUserid) > -1;
            });
            if (usersObj.length) {
                return usersObj[0].Value.trim();
            }
            return "";
        }

        function strIsUserDraftOnly() {
            if (DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < DS_STT_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = DS_STT_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == "draft only") {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }

        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        } 

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList) {
            $scope.isConSelected = true; 
             // Sections dropdown data based on setup form
             if (responseList[TFL_CONSTANT.dsSttNnecSertuoSections]) {
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[TFL_CONSTANT.dsSttNnecSertuoSections],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }
            
             // Contractor Data list
             var contractTeamMemberList = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers];
             if (contractTeamMemberList.length) {
                 var matchRole = TFL_CONSTANT.preojectManager;
                 var tempVal = [], tempNode = [];
                 for (var i = 0; i < contractTeamMemberList.length; i++) {
                     var element = contractTeamMemberList[i];
                     var roleName = element.Value.split('|')[1].trim();
                     if (tempVal.indexOf(element.Value) == -1 && roleName == matchRole) {
                         tempNode.push(element);
                         tempVal.push(element.Value);
                     }
                 }
                 
                 $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                     arrayObject: tempNode,
                     groupNameKey: "",
                     modelKey: "Value",
                     displayKey: "Name"
                 })
             }
             DS_STT_ALL_CONTRACT_TEAM_MEMBERS = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers];

             var contractCurrency = responseList[ TFL_CONSTANT.dsAsiGetCurrencyFromContract ];
             if(contractCurrency){
                 $scope.oriMsgCustomFields['currency'] = contractCurrency[0].Value2.trim();
             }

             var chkPermission = strIsUserDraftOnly();
             if (chkPermission.toLowerCase() == "yes")
                 setSendPermission("Draft");
             else
                 setSendPermission("Send");
        }
       
        /**
         * Initialize all form data on load
         */
        function initFormData() {
            if ($scope.oriMsgCustomFields['ContractNo'] && currentViewName == "ORI_VIEW") {
                onContractChange();
            }
            $scope.notAllow = true;
            $scope.notAllowMessage = "";
            $scope.oriMsgCustomFields.DSI_PreviousMsgId = DS_INCOMPLETE_MSG_ACTIONS.length ? DS_INCOMPLETE_MSG_ACTIONS[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId; 
            if(currentViewName == 'ORI_PRINT_VIEW'){
                $scope.oriMsgCustomFields.isStatus = true;
                $scope.oriMsgCustomFields.showTable = false;
            }
            if(currentViewName == 'RES_VIEW'){
                var isrequired = commonApi.checkPendingActionOnMsg({
                    incompleteActionsByMsgList: DS_INCOMPLETE_ACTIONS_BYMSG,
                    actionName: 'Respond',
                    strUser: dsWorkingUserId,
                    isCheckMsgId: true,
                    strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
                });    
                if (isrequired == false) {
                    //if not than dont allow to edit
                    $scope.notAllowMessage = "You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    $scope.notAllow = false;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    return;
                } else {
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
                }
                $scope.oriMsgCustomFields.isStatus = false;
                $scope.oriMsgCustomFields.showTable = false;
                if($scope.oriMsgCustomFields.progChangeFlag == 'Revise and Resubmit'){
                    $scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'] = '';
                    $scope.oriMsgCustomFields['PM_Comment'] = '';
                    $scope.oriMsgCustomFields.progChangeFlag = 'Resubmit';
                    onContractChange();
                    $scope.oriMsgCustomFields.isStatus = true;
                    $scope.oriMsgCustomFields.showTable = false;
                    $scope.oriMsgCustomFields.stageFlow = parseInt($scope.oriMsgCustomFields.stageFlow);
                    if($scope.oriMsgCustomFields.stageFlow >= 1){
                        $scope.oriMsgCustomFields.showTable = true;
                    }
                }
                else if($scope.oriMsgCustomFields.progChangeFlag == 'Agree'){
                    $scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'] = '';
                    $scope.oriMsgCustomFields['PM_Comment'] = '';
                    $scope.oriMsgCustomFields.progChangeFlag = 'isAgreed';
                    onContractChange();
                    $scope.oriMsgCustomFields.isStatus = true;
                    $scope.oriMsgCustomFields.showTable = true;
                }
            }else {
                $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            }
            if(currentViewName == 'RES_PRINT_VIEW'){
                $scope.oriMsgCustomFields.isStatus = false;
                $scope.oriMsgCustomFields.showTable = false;
                if($scope.oriMsgCustomFields.progChangeFlag == 'Resubmit'){
                    $scope.oriMsgCustomFields.isStatus = true;
                    $scope.oriMsgCustomFields.stageFlow = parseInt($scope.oriMsgCustomFields.stageFlow);
                    if($scope.oriMsgCustomFields.stageFlow >= 1){
                        $scope.oriMsgCustomFields.showTable = true;
                    }
                }
                if($scope.oriMsgCustomFields.progChangeFlag == 'isAgreed'){
                    $scope.oriMsgCustomFields.isStatus = true;
                    $scope.oriMsgCustomFields.showTable = true;
                }
            }
            var chkPermission = strIsUserDraftOnly();
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");
        }
        
        /**
         * Reset the Radio button (on-change)
         */
       
            $scope.isFlushed = function(){
                if($scope.oriMsgCustomFields['changeType'] == 'Qualifying Event'){
                    $scope.oriMsgCustomFields.reliefEvent = '';
                }
                else{
                    $scope.oriMsgCustomFields.qualifyingEvent = '';
                }
            }
        
        $scope.daySelection = function(){
            $scope.oriMsgCustomFields['timeImpact'] = parseInt($scope.oriMsgCustomFields['timeImpact']);
            $scope.oriMsgCustomFields['cpidInitial'] = parseInt($scope.oriMsgCustomFields['cpidInitial']);
            $scope.oriMsgCustomFields['cpidAfter'] = parseInt($scope.oriMsgCustomFields['cpidAfter']);
            $scope.oriMsgCustomFields['tbmDelayDays'] = parseInt($scope.oriMsgCustomFields['tbmDelayDays']);
        }
        /**
         * Set common node and binds with DS_FORMCONTENT1 So, Same Entry is not availble on Send and Save Draft Button
         */
        function setFormCommonNodes(){
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = $scope.oriMsgCustomFields.qualifyingEvent ? $scope.oriMsgCustomFields.qualifyingEvent : $scope.oriMsgCustomFields.reliefEvent;
        }

        /**
         * Set The App Workflow
         */
        function setAppWorkflow() {
            
            var userTodistribute = '',
                currFormStaus = '',
                tfluser = '',
            autoDistNode = (currentViewName == 'RES_VIEW') ? '13' : '3';
            
        // resetting auto distribution node.
            if(currentViewName == 'RES_VIEW'){
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            }
            if(currentViewName == "ORI_VIEW"){
                tfluser = $scope.oriMsgCustomFields['TFL_Representative'];
                userTodistribute = tfluser.split("|")[2].trim();
                $scope.oriMsgCustomFields.isStatus = false;
            }
            if(currentViewName == 'RES_VIEW'){
                if($scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'] == 'Agree'){
                    userTodistribute = $scope.oriMsgCustomFields.originator;
                    $scope.oriMsgCustomFields.progChangeFlag = $scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'];
                    $scope.oriMsgCustomFields.stageFlow = parseInt($scope.oriMsgCustomFields.stageFlow);
                    $scope.oriMsgCustomFields.stageFlow += 1;
                    if($scope.oriMsgCustomFields.stageFlow >= 2){
                        currFormStaus = 'closed';
                        userTodistribute = '';
                    }
                }
                else if($scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'] == 'Revise and Resubmit'){
                    userTodistribute = $scope.oriMsgCustomFields.originator;
                    $scope.oriMsgCustomFields.progChangeFlag = $scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'];
                }
                else if($scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'] == 'Disagree'){
                    $scope.oriMsgCustomFields.progChangeFlag = $scope.oriMsgCustomFields['tflAgreeWithProjCoFlag'];
                    currFormStaus = 'closed';
                }
                else if($scope.oriMsgCustomFields.progChangeFlag == 'Resubmit'){
                    tfluser = $scope.oriMsgCustomFields['TFL_Representative'];
                    userTodistribute = tfluser.split("|")[2].trim();
                }
                else if($scope.oriMsgCustomFields.progChangeFlag = 'isAgreed'){
                    tfluser = $scope.oriMsgCustomFields['TFL_Representative'];
                    userTodistribute = tfluser.split("|")[2].trim();
                }
            }
            if(userTodistribute) {            
                commonApi.setDistributionNode({
                    actionNodeList : [{
                        strUser : userTodistribute.split("#")[0].trim(),
                        strAction : "3#Respond",
                        strDate : commonApi.calculateDistDateFromDays({
                            baseDate: $scope.serverDate,
                            days : 5
                        })                    
                    }],
                    autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
                    asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                    DS_AUTODISTRIBUTE : autoDistNode
                });
            }
            else
            {
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
            }
            // Form's Staus will be set from below code.
				 var strFormStatusId = commonApi.getFormStatusId({
					availFormStatusesList : availFormStatuses,
					strStatus : currFormStaus
				});
				
				if (strFormStatusId) {  
					$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
					$scope.impactDetails.impactStatus= currFormStaus;
                }
                $element.removeClass('loaded');
        }
        $window.pfiFinalCallBack = function() {
            setAppWorkflow();
            setFormCommonNodes();
            return false;
        };
        $window.draftSubmitCallBack = function(){
            setFormCommonNodes();
        }
    };
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pfiFinalCallBack !== "undefined") {
        return pfiFinalCallBack();
    }
}
function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}