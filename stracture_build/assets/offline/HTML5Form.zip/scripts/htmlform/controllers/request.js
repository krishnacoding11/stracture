define(['angular', './base', '../components/folder.selection', '../components/inlineattachment', '../components/item.selection'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout,Notification,lang) {

		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});
		var ctrl = this;
		var orgId = '';
		var email = '';
		var sendObj = {};
		$scope.invitationRoleName = '';
		$scope.companyName = undefined;
		$scope.clickSave = false;
		$scope.disableButton = false;
		$scope.subject = undefined;
		$scope.isAcceptReject = true;
		$scope.senderLogoURL = '';
		$scope.isStatus = false;
		$scope.isSenderLogoURL = true;
		$scope.statusValue = '';
		$scope.weightageId = '';
		$scope.weightageFormId = '';
		$scope.isSameOrg = false;
		$scope.dsMktWtgDetails = $scope.getValueOfOnLoadData('DS_MKT_WTG_DETAILS');
		$scope.activeStatus = "";
		$scope.showCancelButton = false;
		$scope.prequalLinkDetails = {};
		$scope.cancelButtonName = 'Cancel';
		$scope.selectedProducts = "";
		$scope.otherProductDetails = undefined;
		$scope.commentObj = {
			comment: ''
		};
		$scope.otherTextBox = false;
		$scope.entityName = "";
		$scope.supplierArray = [];
		$scope.attachments = {};
		ctrl.$onInit = function () {
			try{
				if(window.requestType == "std")
				parent.document.querySelectorAll("#createFormIframe")[0].style.height = "450px";
			}
			catch(c){}

			$scope.update();
			var iframeUrl = decodeURIComponent($window.location.href);
			var data = $scope.getFormData();
			$scope.senderLogoURL = data.senderLogoURL;
			if ($scope.senderLogoURL == "marketimages/no_company_logo.jpg") {
				$scope.isSenderLogoURL = false;
			}
			var dataString = iframeUrl.split('?');
			var isAcceptRejectValue = $scope.getValueOfOnLoadData('DS_CHECK_RECIPIENT_TO_APPROVE');
			var currentFormStatus = angular.element("input[name =DS_FORMSTATUS]").val();
			if (isAcceptRejectValue.length && isAcceptRejectValue[0].Value == "True" && currentFormStatus != 'Cancelled') {
				$scope.isAcceptReject = true;
			} else {
				$scope.isAcceptReject = false;
			}
			if (dataString[1]) {
				var dataArray = dataString[1].split('&');
				var tempCompanyName = (dataString[1].split('companyName=')[1] || '');
				$scope.companyName = tempCompanyName.split("&bfpc")[0];
				for (var i = 0; i < dataArray.length; i++) {
					if (dataArray[i].indexOf('orgId') > -1) {
						orgId = dataArray[i].split('=')[1];
					}
					if (dataArray[i].indexOf('email') > -1) {
						email = dataArray[i].split('=')[1];
					}
				}
			} else {
				$scope.companyName = data.companyName;
				$scope.subject = data.subject;
				$scope.descripation = data.message;
				$scope.weightageId = data.weightageId;
				$scope.weightageFormId = data.weightageFormId;
			}
			$scope.vendorOrgName = data.vendorOrgName;
			$scope.buyerOrgName = data.buyerOrgName;
			$scope.rejectionEmailID = data.rejectionEmailID;
			$scope.buyerOrgId = data.buyerOrgId;
			$scope.invitationRoleName = data.invitationRoleName;
			$scope.acceptStatusName = data.accept;
			$scope.rejectStatusName = data.reject;
			$scope.cancelStatusName = data.cancel;
			$scope.vendorOrgId = data.vendorOrgId;
			$scope.commentObj.comment = data.comment;
			$scope.entityName = data.entity;			
			$scope.otherProductDetails = data.otherProductDetails;
			$scope.selectedProducts = data.selectedProducts;		   
			$scope.fileAttachments=[];

			if(data.formFields.length){
				for(var f in data.formFields){
					if(Object.keys(data.formFields[f])[0] == "buyerOrgId")
					$scope.buyerOrgId = data.formFields[10].buyerOrgId;

					for(var d in $scope){
						if(Object.keys(data.formFields[f])[0] == d){
							$scope[d] = data.formFields[f][Object.keys(data.formFields[f])[0]]
						}
					}
				}
			}
			
			for(var d in data){
				if(d.indexOf("xdoc_") == 0){
					if($scope.fileAttachments.indexOf(data[d]) == -1)
					$scope.fileAttachments.push(data[d])
				}
			}
			if (window.currentViewName == "ORI_PRINT_VIEW") {
				$scope.dsMktWtgDetails = $scope.getValueOfOnLoadData('DS_MKT_WTG_DETAILS');
				getStatus();

				var dsMktWtgUrlDTLS = $scope.getValueOfOnLoadData('DS_MKT_WTG_URL_DTLS');
				$scope.weightageURL = dsMktWtgUrlDTLS[0] && dsMktWtgUrlDTLS[0].URL2				
				if (USP && USP.orgID == $scope.buyerOrgId && $scope.weightageURL) {
					$scope.weightageId = data.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1;
					$scope.isSameOrg = true;
				}
			}
			

			console.log(data);
			if(data.category_array){
				$scope.supplierArray = data.category_array.supplier;
				$scope.consultantArray = data.category_array.consultant;
				$scope.contractorArray = data.category_array.contractor;
			}
			if(data["Repeating-Table"])
			$scope.repeatingTable = data["Repeating-Table"].value;
		}
		$scope.setFormId = function (weightageId) {
			for (var index = 0; index < $scope.dsMktWtgDetails.length; index++) {
				var element = $scope.dsMktWtgDetails[index];
				if (element.Value4 === weightageId) {
					$scope.weightageFormId = element.Value2;
				}
			}
		}
		$scope.onChangeEvent = function (param, array) {
			$scope.otherTextBox = param.indexOf("Other") == -1 ? false : true;
			$scope.selectedProducts = param.join(",");
			if(!$scope.otherTextBox){
				$scope.otherProductDetails=""
			}		
		}
		$scope.setTopOffset = function(){
			setTimeout(function(){
				angular.element(".item-selection")[0].style.top = angular.element("item-selection").offset().top +25+"px";
			},200)			
		}
		var getStatus = function () {
			var hashedFormId = $("input[name ='formId']").val();
			var hashedProjectId = $("input[name ='projectId']").val();
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/getPrequalLinkDetails?project_id=" + hashedProjectId + "&form_id=" + hashedFormId,
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				$scope.prequalLinkDetails = response.data;
				if (response.data) {
					if (!response.data.validLink) {
						$scope.isAcceptReject = false;
						$scope.showCancelButton = false;
						if (response.data.accept) {
							$scope.statusValue = 'ACCEPTED';
							$scope.isStatus = true;
						} else {
							$scope.statusValue = 'REJECTED';
							$scope.isStatus = true;
						}
					}
					if (response.data.validLink && USP && USP.orgID == $scope.vendorOrgId) {
						$scope.showCancelButton = true;
					}
				}

			}, function () {

			});
		}

		$scope.setEntityFields = function (selectedEntity) {
			$scope.otherTextBox = false;
			$scope.otherProductDetails=""
			if (selectedEntity == "Suppliers"  || selectedEntity == "Manufacturer") {
				$scope.productList = commonApi.getItemSelectionList({
					arrayObject: $scope.supplierArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				})
			}
			if (selectedEntity == "Consultant") {
				$scope.productList = commonApi.getItemSelectionList({
					arrayObject: $scope.consultantArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				})
			}
			if (selectedEntity == "Contractor") {
				$scope.productList = commonApi.getItemSelectionList({
					arrayObject: $scope.contractorArray,
					groupNameKey: "",
					modelKey: "name",
					displayKey: "name"
				})
			}
			if(selectedEntity ==""){
				$scope.productList=[];
			}
		}
		$scope.addRow = function (index) {
			var newRow = { "Attachment": "" };
			(void 0 !== index ? $scope.repeatingTable.splice(-1 == index ? 0 : index, 0, newRow) : $scope.repeatingTable.push(newRow))
		}

		$scope.removeRow = function (index) {
			$scope.repeatingTable && void 0 !== index && $scope.repeatingTable.length > index && $scope.repeatingTable.splice(index, 1)
		}
		$scope.onEvent = function (handler) {
			if (handler) try {
				eval(handler)
			}
				catch (e) {
					console.error("Error when execute method on event. Method: ", e, handler)
				}
		}
		$scope.cancelRequest = function (showCancelButton) {
			var FormId = $("input[name ='formId']").val();
			var ProjectId = $("input[name ='projectId']").val();
			ProjectId = ProjectId.split("$$")[0];
			var formTypeId = $("input[name ='formTypeId']").val();
			if (showCancelButton) {
				$scope.cancelButtonName = 'Cancel...';
			}
			$scope.disableButton = true;
			if(!$scope.isStatus && showCancelButton && $scope.prequalLinkDetails.validLink && !$scope.isAcceptReject && !$scope.prequalLinkDetails.accept){
				commonApi.ajax({
					url: top.marketPlaceServiceURL + "/marketplace/prequal/resetPreqaulProcess",
					method: 'post',
					withCredentials: true,
					headers: {
						'ApiKey': top.marketPlaceApiKey,
						'Content-Type': 'application/json'
					},
					data: {
						formId: FormId,
						projectId: ProjectId,
						isApprove: $scope.prequalLinkDetails.accept,
						formTypeId: formTypeId,
						prequalType: 2,
						evaluationStatus: $scope.cancelStatusName,
						
					}
				}).then(function(response){
					$scope.showCancelButton=false;
					sendObj.refreshStatus = true;
					if (response.data) {
						alert('Request Cancelled Successfully');
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.location = top.marketPlaceServiceURL+"?origin=true";
					} else {
						alert('The operation failed to excute');
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
							window.location = top.marketPlaceServiceURL+"?origin=true";
						
					}
				},function () {
					$scope.cancelButtonName='Cancel';
					$scope.disableButton = false;
				})
			}
		}
		$scope.closePreQualificationFormModal = function (e) {
			var obj = { 'message': 'closeModal' };
			window.top.postMessage(JSON.stringify(obj), "*");
			window.close();
			if ($scope.companyName == '') {
				$window.top.postMessage("closeCreateFormIframe:-1",'*')
			}
		}
		$scope.checkOtherTextBox=function(text){
			$scope.otherProductDetails=text;
		}
		$scope.sendData = function (e) {
			$scope.clickSave = true;
			sendObj.ORI_FORMTITLE = $scope.subject;
			sendObj.message = $scope.descripation;
			sendObj.invitationRoleName = $scope.invitationRoleName;
			sendObj.acceptStatusName = $scope.acceptStatusName;
			sendObj.rejectStatusName = $scope.rejectStatusName;
			sendObj.cancelStatusName = $scope.cancelStatusName;
			sendObj.companyName = $scope.companyName;    
			sendObj.comment = $scope.commentObj.comment;
			sendObj.entity = $scope.entityName;
			sendObj.selectedProducts = $scope.selectedProducts;
			sendObj.refreshStatus = true;
			sendObj.otherProductDetails = $scope.otherProductDetails;
			sendObj.otherTextBox=$scope.otherTextBox;
			sendObj.weightageFormId = $scope.weightageFormId;
			sendObj.weightageId = $scope.weightageId;
			if(sendObj.ORI_FORMTITLE==""||sendObj.ORI_FORMTITLE==undefined){
				var validateMSG = lang.get("form-submit-validation-msg");
				Notification.error({ title: lang.get('alert'), message: validateMSG });
				$scope.clickSave=false;
				return;
			}
			if(window.requestType != "std"){
				if(sendObj.entity==""){
					var validateMSG = lang.get("form-submit-validation-msg");
					Notification.error({ title: lang.get('alert'), message: validateMSG });
					$scope.clickSave=false;
					return;
				}
				if(sendObj.selectedProducts==""){
					var validateMSG = lang.get("form-submit-validation-msg");
					Notification.error({ title: lang.get('alert'), message: validateMSG });
					$scope.clickSave=false;
					return;
				}
				if($scope.otherTextBox && sendObj.otherProductDetails==""){
					var validateMSG = lang.get("form-submit-validation-msg");
					Notification.error({ title: lang.get('alert'), message: validateMSG });
					$scope.clickSave=false;
					return;
				}
			}
			sendObj.vendorOrgName = $scope.vendorOrgName;
			sendObj.buyerOrgName = $scope.buyerOrgName;
			sendObj.rejectionEmailID = $scope.rejectionEmailID;
			sendObj.buyerOrgId = $scope.buyerOrgId;
			sendObj.inlineAttachments = [];
			sendObj.repeatingTable=[];
			sendObj.attachDocFolderID = $("input[name ='attachDocFolderID']").val();
			sendObj.msgId = $("input[name ='msgId']").val();
			sendObj.formId = $("input[name ='formId']").val();			
			sendObj.editOri = false;			
			sendObj.formAction = 'create';
			var $attachInputs = $("input[name^='xdoc_']");
			for (var i = 0; i < $attachInputs.length; i++) {
				sendObj.inlineAttachments.push(
					{ "name": $attachInputs[i].name, "value": $attachInputs[i].value }
				)

				sendObj[$attachInputs[i].id] = {
					'@inline': $attachInputs[i].name,
					'content': ''
				}
			}
			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				sendObj[$fakepathids[i].name] = $fakepathids[i].value;
			}
		
			$scope.data = $scope.getFormData();
			var formJson = {
				myFields: $scope.data
			}
			
			var $attachInputs = $("input[name^='xdoc_']");
			for (var i = 0; i < $attachInputs.length; i++) {				
				formJson.myFields[$attachInputs[i].id] = {
					'@inline': $attachInputs[i].name,
					'content': ''
				}
			}
			formJson.myFields.attachments = [];
			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				formJson.myFields[$fakepathids[i].name] = $fakepathids[i].value;
			}						
			sendObj.formJson = formJson;
			window.top.postMessage(JSON.stringify(sendObj), "*");
		}
		var genXdocId = function(){
            var xId = "x_x_x_x".replace(/[x]/g, function(c) {
                var r = Math.random() * 9 | 0,v = c == "x" ? r : "0";
                return v
            }) + "_my"
 
            return 'xdoc_'+xId+':Asite';
        }
		$scope.setAcceptFlag = function (flag) {
			$scope.activeStatus = !flag ? $scope.acceptStatusName : "";
		}

		$scope.acceptReject = function (isAccept, weightageId) {
			// restrict form to submit as Questionnaire fields is mendatory. 
			if (isAccept && !weightageId) {
				alert('Please select Questionnaire');
				return false;
			}
			var formFields = [{
				formFieldName: 'comment',
				value: $scope.commentObj.comment
			}];
			$scope.disableButton = true;
			if (isAccept) {
				$(".accept").text("Accept...")
			} else {
				$(".reject").text("Reject...")
			}
			var hashedFormId = $("input[name ='formId']").val();
			var hashedProjectId = $("input[name ='projectId']").val();
			var hformTypeId = $("input[name ='formTypeId']").val();
			var msgId = $("input[name ='msgId']").val();
			hformTypeId = hformTypeId && hformTypeId.split('$$')[0];
			var statusName = $scope.acceptStatusName;
			if (!isAccept) {
				statusName = $scope.rejectStatusName;
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/processPrequalLink",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: {
					hashedFormId: hashedFormId,
					hashedProjectId: hashedProjectId,
					isAccept: isAccept,
					formTypeId: hformTypeId,
					settingTypeId: 2,
					statusName: statusName,
					weightageId: weightageId,
					msgId:msgId,
					formFields: [
						{
							formFieldName: 'comment',
							value: $scope.commentObj.comment
						},						
						{
							formFieldName: "DS_FORMCONTENT1",
							value: $scope.weightageFormId
						}
					],
					notificationData:
					{
						subject: $scope.subject,
						recipientMailId: $scope.rejectionEmailID,
						buyerOrgName: $scope.buyerOrgName,
						message: $scope.descripation,
						vendorOrgName: $scope.vendorOrgName,
						buyerOrgId: $scope.buyerOrgId,
						vendorOrgId: $scope.vendorOrgId
					}
				}
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					if (response.data.prequalLink) {
						window.top && window.top.opener && window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.location = response.data.prequalLink;
					} else {
						alert('Request Response Submitted Successfully');
						if (window.top && window.top.opener) {
							window.top.opener.postMessage(JSON.stringify(sendObj), "*");
							window.close();
						} else {
							window.location = top.marketPlaceServiceURL+"?origin=true";
						}
					}
				}
			}, function (response) {
				if(response.status == 403){
					alert('This request to prequalify is no longer valid.');
					sendObj.refreshStatus = true;
					if (window.top && window.top.opener) {
						window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.close();
					} else {
						window.location = top.marketPlaceServiceURL+'/marketplace/companies/directory-search' + "?origin=true";
					}
					//window.location = top.marketPlaceServiceURL+"?origin=true";
				}
				if(response.status == 412){
					alert('Your Prequalification is already in progress.');
					sendObj.refreshStatus = true;
					if (window.top && window.top.opener) {
						window.top.opener.postMessage(JSON.stringify(sendObj), "*");
						window.close();
					} else {
						window.location = top.marketPlaceServiceURL+'/marketplace/companies/directory-search' + "?origin=true";
					}
					//window.location = top.marketPlaceServiceURL+"?origin=true";
				}
				$scope.clickApprove = false;
				$scope.disableButton = false;
				//alert("Error In Evalution Submit");
			});
		}

	}
	return FormController;
});