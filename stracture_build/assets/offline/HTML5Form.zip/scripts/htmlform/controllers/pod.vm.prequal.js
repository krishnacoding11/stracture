define([
	'angular',
	'./base',
	'../components/folder.selection',
	'../components/inlineattachment',
	'../components/item.selection',
	'../components/table.util',
	'../components/signature',
], function (angular, baseController) {
	'use strict';
	/**
	 * FieldType used in Apps
	 * Input: 1
	 * Dropdown: 2
	 * Checkbox: 3
	 * Textarea : 4
	 * Radiobutton: 5
	 * readOnly: 6
	 * */

	function FormController($scope, $element, commonApi, $controller, $window, $timeout, myConfig, $document, Notification, lang) {
		var ctrl = this;
		var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
		if (projectId == "null")
			projectId = $window.currProjId;
		var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var editDraft = document.getElementById('editDraft') ? document.getElementById('editDraft').value : null;
		var currentViewName = $window.currentViewName;
		var userRef = '---';
		var sendObj = {};
		var isDraft = false;
		var dcId;
		var actionDataByFormId = {};
		var weightageId = 0;
		$scope.showDisqualifyButton=true;
		if ($scope.msgThread) {
			isDraft = $scope.msgThread.isDraft;
		}else{
			isDraft = editDraft == "true";
		}

		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		var STATIC_OBJ_DATA = {
			entity: {
				name: "",
				tradingAddress: "",
				description: "",
				yearsOfExperience: "",
				role: ""
			},
			b1_3_1: {
				nameOfEmployer: "",
				projectDescription: "",
				contractValueDuration: "",
				FormOfContract: "",
				WorksUndertaken: "",
				keySubContractors: "",
				contractSatisfactorily: ""
			},
			projects: {
				description: "",
				employer: "",
				useOfBuilding: "",
				cost: "",
				principleQuantities: "",
				constructionMethods: "",
				commencementDate: "",
				completionDate: "",
				formOfContract: "",
				proectSatisfactorilyOnTime: "",
				liquidatedDamagesIncurred: "",
				workDeleveredDirectly: "",
				subContractorsSpend: ""
			},
			clientRef: {
				nameOrCompany: "",
				addressOrTelephoneOrEmail: ""
			},
			numberOfStaff: {
				professional: "",
				techanical: "",
				administrative: ""
			},
			numberOfOperative: {
				skilled: "",
				semiSkilled: "",
				unSkilled: ""
			},
			directorOrSeniorManager: {
				name: "",
				presentPosition: "",
				experienceWithQualifications: ""
			},
			management: {
				role: "",
				name: "",
				qualification: "",
				experience: ""
			},
			annualValueOfContruction: {
				year: "",
				turnoverFromConstruction: ""
			},
			workInHand: {
				year: "",
				projectedTurnover: "",
				secured: ""
			},
			bankersDetails: {
				name: "",
				address: ""
			},
			insuranceDetails: {
				insuranceType: "",
				insuranceValue: "",
				certRefProvided: ""
			},
			questionAppendix: {
				question: "",
				appendixNo: "",
				aAppx_isSelected: false
			},
			managementItem: {
				role: "",
				name: "",
				qualification: "",
				experience: ""
			}
		}

		$scope.tableUtilSettings = {
			questionAppendix: {
				tooltip: "select to remove/remove all/Insert new Record",
				hasDefaultRecord: true,
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0
				},
				checkboxModelKey: "aAppx_isSelected",
				newStaticObject: angular.copy(STATIC_OBJ_DATA.questionAppendix),
				deleteCurrRowMsg: "Remove Records"
			},
			b1_3_1: {
				tooltip: "select to remove/remove all/Insert new Record",
				hasDefaultRecord: true,
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0
				},
				checkboxModelKey: "b1_3_1_isSelected",
				newStaticObject: angular.copy(STATIC_OBJ_DATA.b1_3_1),
				deleteCurrRowMsg: "Remove Records"
			},
			clientRef: {
				tooltip: "select to remove/remove all/Insert new Record",
				hasDefaultRecord: true,
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0
				},
				checkboxModelKey: "clRef_isSelected",
				newStaticObject: angular.copy(STATIC_OBJ_DATA.clientRef),
				deleteCurrRowMsg: "Remove Records"
			}
		};

		$scope.currentTab = 1;
		$scope.canEvalution = true;
		$scope.uopAttachments = [];
		$scope.isForSaveDraft = false;
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});


		
		/**
		 * To get WeighategFormDetails based on buyerOrgId and WeightageId
		 */
		$scope.getWeitageDetails = function () {
			if (currentViewName == "ORI_VIEW" || currentViewName == "ORI_VIEW_PRINT") {
				var iframeUrl = decodeURIComponent($window.location.href);
				var dataString = iframeUrl && iframeUrl.split('?');
				var canEvalution = $scope.getValueOfOnLoadData('DS_IS_USER_ACTION_INCOMPLETE');
				if (canEvalution.length && canEvalution[0].Value == "Y") {
					$scope.canEvalution = true;
				} else {
					$scope.canEvalution = false;
				}
				var dataArray = dataString[1] && dataString[1].split('&');
				if (currentViewName == "ORI_VIEW" && dataArray && !isDraft) {
					$scope.data.buyerOrgId = 0;
					for (var i = 0; i < dataArray.length; i++) {
						if (dataArray[i].indexOf('mailrecipient') > -1) {
							$scope.data.recipient = dataArray[i].split('=')[1];
						}
						if (dataArray[i].indexOf('formSelectRadiobutton') > -1) {
							var tempData = dataArray[i].split('=')[1];
							dcId = tempData.split('_')[0];
						}
						if (dataArray[i].indexOf('buyerOrgId') > -1) {
							var buyerOrgId = dataArray[i].split('=')[1];
							$scope.data.buyerOrgId = buyerOrgId.split('$$')[0];
							commonApi.ajax({
								url: top.marketPlaceServiceURL + "/marketplace/uop/getUOPByOrgId/" + $scope.data.buyerOrgId,
								method: 'GET',
								withCredentials: true,
								data: {},
								headers: {
									'Content-Type': 'application/json',
									'ApiKey': top.marketPlaceApiKey
								},
							}).then(function (response) {
								if (response.status === 200) {
									$scope.data.buyerOrgName = response.data.companyName;
									$scope.update();
									resizeTextarea()
								}
							}, function (error) {
								$window.alert("Error \n\n Probelm while fetching UOP by Org ID");
								console.log(error)
								$scope.update();
								resizeTextarea()
							});
						}
						if (dataArray[i].indexOf('weightage') > -1) {
							weightageId = dataArray[i].split('=')[1];
						}

						if (dataArray[i].indexOf('userRef') > -1) {
							userRef = dataArray[i].split('=')[1];
						}
					}
					
					$scope.data.sectionHideFlag = {};
					if (currentViewName == "ORI_VIEW") {
						addStaticDataIntoJson();
						getUOPData();
					}

					commonApi.ajax({
						url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages?boid=" + $scope.data.buyerOrgId + "&weightageId=" + weightageId,
						method: 'GET',
						withCredentials: true,
						data: {},
						headers: {
							'Content-Type': 'application/json',
							'ApiKey': top.marketPlaceApiKey
						},
					}).then(function (response) {
						if (response.status === 200) {
							$scope.WeitageDetails = response.data;
							setViewFlag();
							$scope.update();
							resizeTextarea()
						}
					}, function (error) {
						$window.alert("Error \n\n Probelm while fetching weightage template");
						console.log(error)
						$scope.update();
						resizeTextarea()
					});
					if(!$scope.data.buyerOrgId)
					getBuyerSettings()
				} else {
					weightageId = $scope.data.referenceResourceId;
					setCollapseFlagForCustomSection();
					$scope.update();
					resizeTextarea()
				}
			} else if (currentViewName == "PREQUAL_RES_VIEW") {
				$scope.companyName = $scope.data.ORI_FORMTITLE;
				weightageId = $scope.data.weightageId;
				getPrequalWeightages();
				actionDataByFormId = $scope.getValueOfOnLoadData('DS_GET_FORM_DATA_BY_DB_FORM_ID');
			} else if (currentViewName == "PREQUAL_RES_VIEW_PRINT") {
				$scope.jsonWeightage = $scope.data;
				$scope.showCancelButton = angular.element("input[name =DS_FORMSTATUS]").val() != $scope.data.cancelStatus;
				//hide the cancel button for vendor after preqaulification
				if(angular.element("#DS_WORKINGUSERROLE").val() == "Vendor"){
					$scope.showCancelButton = false;
				}
				$scope.update();
				resizeTextarea()
			}
		}

		/**
		 * To initialize toggle flag and call onload function
		 */
		ctrl.$onInit = function () {
			$scope.data = $scope.getFormData();
			$scope.mainSections = $scope.data.Sections;
			$scope.section = {
				appendix_A: {
					isHide: false
				},
				appendix_B: {
					isHide: false
				},
				GeneralIns: {
					isHide: false
				},
				appendix: {
					isHide: false
				},
				appendixE: {
					isHide: false
				},
			}
			$scope.getWeitageDetails();
		}
		//CancelInvitation implementation 
		
		$scope.cancelInvitation = function () {
			var FormId = $("input[name ='formId']").val();
			var ProjectId = $("input[name ='projectId']").val();
			ProjectId = ProjectId.split("$$")[0];
			var formTypeId = $("input[name ='formTypeId']").val();
			if ($scope.showCancelButton) {
				$scope.clickCancel = true;
				commonApi.ajax({
					url: top.marketPlaceServiceURL + "/marketplace/prequal/resetPreqaulProcess",
					method: 'post',
					withCredentials: true,
					headers: {
						'ApiKey': top.marketPlaceApiKey,
						'Content-Type': 'application/json'
					},
					data: {
						formId: FormId,
						projectId: ProjectId,
						isApprove: true,
						formTypeId: formTypeId,
						prequalType: 1,
						evaluationStatus: $scope.data.cancelStatus || 'Cancelled',

					}
				}).then(function (response) {
					$scope.showCancelButton = false;
					if (response.data) {
						alert('Prequalification Cancelled Successfully')
						if (window.top && window.top.opener) {
							sendObj.refreshStatus = true;
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
							window.close();
							window.top.close();
							return;
						}
					}else {
						alert('The operation failed to excute')
					}
					window.location = top.marketPlaceServiceURL+"?origin=true";
				})
			}
		}
		/**
		 * Toggle section/div to hide/show based on user interaction
		 */
		$scope.toggleSetion = function (secObj) {
			secObj.isHide = !secObj.isHide;
		}

		$scope.openReplyView = function(){
			$window.scrollTo(0,0);
			$timeout(function(){
				$scope.reply('all','','','',$scope.data.vendorOrgId);
			},100);
		}

		/**
		 * Expand only one section/div as per user interaction
		 */
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ? $scope.currentTab = ' ' : $scope.currentTab = eID;
		};

		/**
		 * Calculate rating based on value/percentage added in Evalution stage
		 */
		$scope.calculateRating = function (section, subsection) {
			var totalWeightageOfSubsection = 0;
			for (var i = 0; i < section.subSections.length; i++) {
				if (section.subSections[i].isSubSectionActive && section.subSections[i].evalutionWeightageValue) {
					totalWeightageOfSubsection += (parseInt(section.subSections[i].subSectionPercentage) * parseInt(section.subSections[i].evalutionWeightageValue))
				}
			}
			var tempWeightage = (totalWeightageOfSubsection / 100);
			section.evalutionWeightageValue = tempWeightage;
			finalRatingCountCalculate();
			var ratingInput = document.getElementsByClassName("ratingInput");
			for (var i = 0; i < ratingInput.length; i++) {
				if (parseInt(ratingInput[i].value) >= 0 && parseInt(ratingInput[i].value) <= 100) {
					$scope.validateRating = false
				} else {
					$scope.validateRating = true;
					return
				}
			}
		}

		/**
		 * Submit all prequal data to marketplace API rather than addodle apps
		 * because there are some value need to extract and store them to marketplace DB
		 */
		$scope.savePrequalWeightage = function (approve) {
			var FormError = $scope.$parent.myform.$error;
			if (FormError && !commonApi._.isEmpty(FormError)) {
				var validateMSG = lang.get("form-submit-validation-msg");
				Notification.error({ title: lang.get('alert'), message: validateMSG });
				return;
			}
			$scope.clickApprove = true;
			if (approve) {
				$scope.clickApprove = false;
				$scope.clickReject = true;
			} else {
				var getJsonData = $window.getJSONData && JSON.parse(window.getJSONData());
				var refData = "";
				if (getJsonData && getJsonData.myFields) {
					$scope.jsonWeightage.prequalType = getJsonData.myFields.prequalType;
					refData = $scope.jsonWeightage.referenceResourceId = getJsonData.myFields.referenceResourceId;

				}
				var jsonReadWrite = {
					"Asite_System_Data_Read_Only": {
						"_5_Form_Data": {
							"DS_FORMCONTENT1": refData
						}
					},
					"Asite_System_Data_Read_Write": {
						"Auto_Distribution_Msg_Actions": {
							"DS_AUTODISTRIBUTE_OTHERS_MSG_APP_ID": 1,
							"Auto_Distribution_Msg_Action": [{
								"DS_MSG_ADO_TYPE": 2,
								"DS_MSG_ADO_FORM": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value2,
								"DS_MSG_ADO_MSG_TYPE": "ORI001",
								"DS_MSG_ADO_FORMACTIONS": "3#Respond",
								"DS_MSG_ADO_PROJDISTGROUPS": "",
								"DS_MSG_ADO_ACTIONDUEDATE": 7,
								"DS_MSG_ADO_PROJDISTUSERS": actionDataByFormId && actionDataByFormId[0] && actionDataByFormId[0].Value5
							}]
						}
					}
				}
				$scope.jsonWeightage && angular.extend($scope.jsonWeightage, jsonReadWrite);
			}
			$scope.jsonWeightage.ORI_FORMTITLE = $scope.companyName;
			$scope.data && angular.extend($scope.data, $scope.jsonWeightage);
			var myFields = {
				myFields: $scope.data
			}
			var formFields= [{
				formFieldName: 'comment',
				value:$scope.data.comment
			}];
			var formJson = {
				formJson: angular.toJson(myFields),
				projectId: $("input[name ='projectId']").val().split('$$')[0],
				formTypeId: top.$("input[name ='formTypeId']").val(),
				msgId: $("input[name ='msgId']").val(),
				formId: formId,
				msgTypeId: 2,
				parentMsgId: $("input[name ='parent_msg_id']").val(),
				isApprove: $scope.clickApprove,
				vendorOrgId: $scope.data.vendorOrgId,
				evaluationStatus: $scope.clickApprove ? $scope.approveStatus : $scope.rejectStatus,
				formFields: [{
					formFieldName: 'comment',
					value: $scope.commentObj && $scope.commentObj.comment
				}],
				notificationData:
				{
					subject: $scope.data.companyName,
					recipientMailId: $scope.data.rejectionEmailIDSave,
					vendorOrgName: $scope.data.vendorOrgName,
					message: $scope.data.descripation,
					buyerOrgName: $scope.data.buyerOrgName,
					buyerOrgId: $scope.data.buyerOrgId,
					vendorOrgId: $scope.data.vendorOrgId
				}
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveeval",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					alert("Evaluation Submitted Successfully");
					if (window.top && window.top.opener) {
						window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						window.close();
						window.top.close();
					} else {
						top.location = top.marketPlaceServiceURL+"?origin=true";
					}
				}
			}, function (response) {
				if(response.status = 403){
					alert('This prequalification questionnaire is no longer valid.');
					sendObj.refreshStatus = true;
					window.top.opener.postMessage(JSON.stringify(sendObj), "*");
					window.close();
					//window.location = top.marketPlaceServiceURL+"?origin=true";
				}
				alert("Error In Evaluation Submit.");
				$scope.clickApprove = false;
			});
		}

		/**
		 * To UOP data vendor to pre fill some data
		 */
		var getUOPData = function () {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/uop/orgregionuop?regionId=" + dcId + "&orgId=" + USP.orgID,
				method: 'get',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				}
			}).then(function (response) {
				mergeUOPData(response.data);
				resizeTextarea();
			}, function () {

			});
		}

		/**
		 * 
		 * @param {Array} data : Array data of UOP,
		 * function return key value paired json with Key UOP field key and object as its value 
		 */
		function getObjByFieldId(data) {
			var obj = {};
			if (data.length) {
				for (var i = 0; i < data.length; i++) {
					var subDataA = data[i];
					if (subDataA.data.length) {
						for (var j = 0; j < subDataA.data.length; j++) {
							var subDataB = subDataA.data[j];
							if (subDataB.data.length) {
								for (var k = 0; k < subDataB.data.length; k++) {
									var subDataC = subDataB.data[k];
									subDataC.fieldId && (obj[parseInt(subDataC.fieldId)] = subDataC);
								}
							}
						}
					}
				}
			}
			return obj;
		};

		/**
		 * function used to resize textarea in all fields
		 * to display all context of fields after angular/api data loaded
		 */
		function resizeTextarea(){
			$timeout(function(){
				$scope.expandTextAreaOnLoad();
			}, 1000);
		}

		/**
		 * set company name and id based on UOP data
		 */
		function mergeUOPData(data) {
			$scope.companyName = data.companyName
			$scope.data.uopId = data.uopId;
			var UOP_FIELDS = getObjByFieldId(data.uopData);
			var ADDRESS_UOP = UOP_FIELDS[4].value[0];

			$scope.data.appendix_B.B1_1.b1_1_1.fullName = UOP_FIELDS[1].value || "";
			$scope.data.appendix_B.B1_1.b1_1_1.registeredAddress = (ADDRESS_UOP[0].value ? ADDRESS_UOP[0].value + '\n' : "") +
				(ADDRESS_UOP[1].value ? ADDRESS_UOP[1].value + '\n' : "") + (ADDRESS_UOP[2].value ? ADDRESS_UOP[2].value + '\n' : "") + (ADDRESS_UOP[3].value ? ADDRESS_UOP[3].value + '\n' : "") + (ADDRESS_UOP[4].value ? ADDRESS_UOP[1].value + '\n' : "") + (ADDRESS_UOP[8].value || "");

			$scope.data.appendix_B.B1_1.b1_1_1.tradingAddress = UOP_FIELDS[16].value;
			$scope.data.appendix_B.B1_1.b1_1_1.nameOfContact = (UOP_FIELDS[26].value || "") + " " + (UOP_FIELDS[27].value || "");
			$scope.data.appendix_B.B1_1.b1_1_1.postCode = ADDRESS_UOP[4].value || "";
			$scope.data.appendix_B.B1_1.b1_1_1.telephoneNo = ADDRESS_UOP[5].value || "";
			$scope.data.appendix_B.B1_1.b1_1_1.emailAddress = ADDRESS_UOP[7].value || "";
			$scope.data.appendix_B.B1_1.b1_1_1.companyRegistrationNo = UOP_FIELDS[240].value || "";

			$scope.data.appendix_B.B1_2.b1_2_1.primaryBusinnessActivity = UOP_FIELDS[14].value || "";

			$scope.data.appendix_B.B1_2.b1_2_4.listOfDocumentSubmitted = UOP_FIELDS[31].value[0][2].value || "";

			$scope.data.appendix_B.B1_2.b1_2_5.parentCompanyGuarantee = UOP_FIELDS[53].value ? "Yes" : "No";

			$scope.data.appendix_B.B1_3.b1_3_1[0].contractValueDuration = (UOP_FIELDS[261].value || "") + ", " + (UOP_FIELDS[263].value || "");
			$scope.data.appendix_B.B1_3.b1_3_1[0].projectDescription = (UOP_FIELDS[260].value || "");
			$scope.data.appendix_B.B1_3.b1_3_1[0].FormOfContract = UOP_FIELDS[262].value || "";

			var tmpNumberOfStaff = [];
			for (var i = 0; i < UOP_FIELDS[114].value.length; i++) {
				var element = UOP_FIELDS[114].value[i];
				tmpNumberOfStaff.push({
					professional: element[0].value || "",
					techanical: element[1].value || ""
				});
			}

			$scope.data.appendix_B.B1_4.b1_4_1.numberOfStaff = angular.copy(tmpNumberOfStaff);

			var tmpNumberOfOperative = [];
			for (var i = 0; i < UOP_FIELDS[117].value.length; i++) {
				var element = UOP_FIELDS[117].value[i];
				tmpNumberOfOperative.push({
					skilled: element[0].value || "",
					semiSkilled: element[1].value || ""
				});
			}

			$scope.data.appendix_B.B1_4.b1_4_2.numberOfOperative = angular.copy(tmpNumberOfOperative);

			var tmpAnnualValueOfContruction = [];
			for (var i = 0; i < UOP_FIELDS[50].value.length; i++) {
				var element = UOP_FIELDS[50].value[i];
				if(element[0].value && element[1].value){
					tmpAnnualValueOfContruction.push({
						year: element[0].value,
						turnoverFromConstruction: element[1].value
					});
				}
			}

			if(tmpAnnualValueOfContruction.length) {
				$scope.data.appendix_B.B1_5.b1_5_1.annualValueOfContruction = angular.copy(tmpAnnualValueOfContruction);
			}

			if(UOP_FIELDS[57].value && UOP_FIELDS[58].value && UOP_FIELDS[59].value){
				$scope.data.appendix_B.B1_5.b1_5_4.bankersDetails[0].name = UOP_FIELDS[57].value;
				$scope.data.appendix_B.B1_5.b1_5_4.bankersDetails[0].address = UOP_FIELDS[58].value + ", " + UOP_FIELDS[59].value;
			}

			var tmpInsuranceDetails  = [];
			for (var i = 0; i < UOP_FIELDS[120].value.length; i++) {
				var element = UOP_FIELDS[120].value[i];
				if(element[0].value && element[1].value && element[3].value){
					tmpInsuranceDetails.push({
						"insuranceType": element[0].value,
						"insuranceValue": element[1].value,
						"certRefProvided": element[3].value
					});
				}
			}
			if(tmpInsuranceDetails.length){
				$scope.data.appendix_B.B1_5.b1_5_5.insuranceDetails = angular.copy(tmpInsuranceDetails);
			}

			$scope.data.appendix_B.B1_7 = UOP_FIELDS[132].value[0][0].value || "";

			$scope.data.appendix_B.B1_7 = UOP_FIELDS[88].value || "";

			setHealthAndSafety(UOP_FIELDS);
			setEnvironmentDetails(UOP_FIELDS);
		}

		function setEnvironmentDetails(uopData){
			var ENVIRONMENT_MANAGEMENR = [
				{
					"environmentNumber": "1",
					"environmentText": "Has your company been convicted of breaching environmental legislation, or had any notice served upon it, in the last three years by any environmental regulator or authority (including local authority)? \n\nIf your answer to this question is “Yes”, please provide details in a separate Appendix of the conviction or notice and details of any remedial action or changes you have made as a result of conviction or notices served.\n\nThe Employer will not select bidder(s) that have been prosecuted or served notice under environmental legislation in the last 3 years, unless the Employer is satisfied that appropriate remedial action has been taken to prevent future occurrences/breaches.",
					"environmentValue": "No"
				},
				{
					"environmentNumber": "2",
					"environmentText": "If you use sub-contractors, do you have processes in place to check whether any of these organisations have been convicted or had a notice served upon them for infringement of environmental legislation?",
					"environmentValue": "No"
				}
			]
			$scope.data.appendix_B.B1_11.environmentManagement = angular.copy(ENVIRONMENT_MANAGEMENR);
		}

		function setHealthAndSafety(uopData){
			var HEALTH_AND_SAFETY_ENV = [
				{
					"question": "a)	Health & Safety Policy",
					"answer": uopData[37].value || "",
					"evidenceProvided": ""
				},
				{
					"question": "b)	Accident Frequency Ratio (AFR) at end of Jan 2019 (as defined by HSE)",
					"answer": "",
					"evidenceProvided": ""
				},
				{
					"question": "c)	Accreditation to a Safety Scheme in Procurement http://www.ssip.org.uk",
					"answer": "",
					"evidenceProvided": ""
				},
				{
					"question": "d)	Environmental Management – ISO14001 – Accredited",
					"answer": uopData[83].value || "",
					"evidenceProvided": (uopData[84].value[0][0].value ? uopData[84].value[0][0].value + " , " : "") + (uopData[84].value[0][1].value ? uopData[84].value[0][1].value + " , " : "")
				},
				{
					"question": "e)	Quality Management – ISO9001 – Accredited",
					"answer": uopData[77].value || "",
					"evidenceProvided": (uopData[78].value[0][0].value ? uopData[78].value[0][0].value + " , " : "") + (uopData[78].value[0][1].value ? uopData[78].value[0][1].value + " , " : "")
				}
			];

			var HEALTH_AND_SAFETY = [
				{
					"healthSafetyNumber": "1",
					"healthSafetyText": "Please self-certify that your company has a Health and Safety Policy that complies with current legislative requirements.",
					"healthSafetyValue": uopData[37].value || "No"
				},
				{
					"healthSafetyNumber": "2",
					"healthSafetyText": "Has your company or any of its Directors or Executive Officers been in receipt of enforcement/remedial orders in relation to the Health and Safety Executive (or equivalent body) in the last 3 years? \n\n If your answer to this question was “Yes”, please provide details in a separate Appendix of any enforcement/ remedial orders served and give details of any remedial action or changes to procedures you have made as a result. \n\nThe Employer will exclude bidder(s) that have been in receipt of enforcement/remedial action orders unless the bidder(s) can demonstrate to the Employer’s satisfaction that appropriate remedial action has been taken to prevent future occurrences or breaches.",
					"healthSafetyValue": uopData[49].value || "No"
				},
				{
					"healthSafetyNumber": "3",
					"healthSafetyText": "If you use sub-contractors, do you have processes in place to check whether any of the above circumstances apply to these other organisations?",
					"healthSafetyValue": "No"
				}
			]

			$scope.data.appendix_B.B1_9.b1_9_1.healthAndSafety = angular.copy(HEALTH_AND_SAFETY_ENV);
			$scope.data.appendix_B.B1_12.healthAndSafety = angular.copy(HEALTH_AND_SAFETY);
		}


		/**
		 * Final rating calculation based on value added evalution stage
		 */
		var finalRatingCountCalculate = function () {
			$scope.jsonWeightage.finalRatingCount = 0;
			for (var i = 0; i < $scope.jsonWeightage.Sections.length; i++) {
				if ($scope.jsonWeightage.Sections[i].evalutionWeightageValue) {
					var sectionPerValue = (parseInt($scope.jsonWeightage.Sections[i].sectionPercentage) * $scope.jsonWeightage.Sections[i].evalutionWeightageValue) / 100;
					$scope.jsonWeightage.finalRatingCount = $scope.jsonWeightage.finalRatingCount + sectionPerValue;
				}
			}
		}

		/**
		 * To insert new row in repeating table based on param
		 * @param { Array } repeatingData: repeating data 
		 * @param { String } objKeyName: object key used to fetch static object from STATIC_OBJ_DATA
		 */
		$scope.addNewItem = function (repeatingData, objKeyName) {
			var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
			repeatingData.push(newRowObject);

			resizeTextarea();
		};

		/**
		 * set custom section data which fetched from API to display in print view
		 */
		function setViewFlag() {
			var allSections = $scope.WeitageDetails.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.Sections;
			$scope.data['customSections'] = $scope.WeitageDetails.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.customSections;
			for (var index = 0; index < allSections.length; index++) {
				var element = allSections[index];
				$scope.data.sectionHideFlag[element.sectionId] = element.isSectionActive;

				for (var subIndex = 0; subIndex < element.subSections.length; subIndex++) {
					var subElement = element.subSections[subIndex];
					$scope.data.sectionHideFlag[subElement.subSectionId] = subElement.isSubSectionActive;
				}
			}
			setCollapseFlagForCustomSection();
		}

		/**
		 * Enable collapse/expand for custom section which inherited from Weightage form
		 */
		function setCollapseFlagForCustomSection() {
			if ($scope.data['customSections']) {
				for (var index = 0; index < $scope.data['customSections'].length; index++) {
					$scope.section['custom_' + (index + 1)] = {
						isHide: false
					}
				}
			}
		}

		/**
		 * Add default value in fields which are prepopulated in form
		 */
		function addStaticDataIntoJson() {
			var MANAGEMENT = [
				{
					"role": "",
					"name": "",
					"qualification": "",
					"experience": ""
				}
			];

			var ANNUALVALUE_OF_CONSTRUCTION = [
				{
					"year": "2017",
					"turnoverFromConstruction": ""
				},
				{
					"year": "2018",
					"turnoverFromConstruction": ""
				},
				{
					"year": "2019",
					"turnoverFromConstruction": ""
				},
				{
					"year": "2020(Forecast)",
					"turnoverFromConstruction": ""
				},
				{
					"year": "2021(Forecast)",
					"turnoverFromConstruction": ""
				}
			];

			var WORK_IN_HAND = [
				{
					"year": "2021",
					"projectedTurnover": "",
					"secured": ""
				},
				{
					"year": "2022",
					"projectedTurnover": "",
					"secured": ""
				}
			];

			var INSURANCE_DETAILS = [
				{
					"insuranceType": "The Works / Contractors All Risks (Minimum £10,000,000)",
					"insuranceValue": "",
					"certRefProvided": ""
				},
				{
					"insuranceType": "Third Party Liabilities / Public Liability (including joint insurance of the Employer)",
					"insuranceValue": "",
					"certRefProvided": ""
				},
				{
					"insuranceType": "Employer’s Liability  (Minimum £10,000,000)",
					"insuranceValue": "",
					"certRefProvided": ""
				},
				{
					"insuranceType": "Professional Indemnity - state Conditions and Exclusions, (Minimum £2,000,000)",
					"insuranceValue": "",
					"certRefProvided": ""
				},
				{
					"insuranceType": "Details of the maximum Professional Indemnity that will be offered? (beyond £2,000,000) ",
					"insuranceValue": "",
					"certRefProvided": ""
				}
			];

			var EQUALITY_LEGISLATION = [
				{
					"number": "1",
					"complianceText": "In the last three years, has any finding of unlawful discrimination been made against your company by an Employment Tribunal, an Employment Appeal Tribunal or any other court (or in comparable proceedings in any jurisdiction other than the UK)?",
					"complianceValue": "No"
				},
				{
					"number": "2",
					"complianceText": "In the last three years, has your company had a complaint upheld following an investigation by the Equality and Human Rights Commission or its predecessors (or a comparable body in any jurisdiction other than the UK), on grounds of alleged unlawful discrimination?\n\nIf you have answered “yes” to one or both of the questions in this module, please provide, as a separate Appendix, a summary of the nature of the investigation and an explanation of the outcome of the investigation to date.\n\nIf the investigation upheld the complaint against your company, please use such Appendix to explain what action (if any) you have taken to prevent unlawful discrimination from reoccurring. \n\nYou may be excluded if you are unable to demonstrate to the Employer’s satisfaction that appropriate remedial action has been taken to prevent similar unlawful discrimination reoccurring.",
					"complianceValue": "No"
				},
				{
					"number": "3",
					"complianceText": "If you use sub-contractors, do you have processes in place to check whether any of the above circumstances apply to these other organisations?",
					"complianceValue": "No"
				}
			]

			var GENERAL_DATA_PROTECTION = [{
				"generalDataNumber": "1",
				"generalDataText": "Please self-certify that your company has a Policy that complies with GDPR legislative requirements. ",
				"generalDataValue": "No"
			}];

			$scope.data.appendix_B.B1_4.b1_4_4.management = angular.copy(MANAGEMENT);
			$scope.data.appendix_B.B1_5.b1_5_1.annualValueOfContruction = angular.copy(ANNUALVALUE_OF_CONSTRUCTION);
			$scope.data.appendix_B.B1_5.b1_5_2.workInHand = angular.copy(WORK_IN_HAND);
			$scope.data.appendix_B.B1_5.b1_5_5.insuranceDetails = angular.copy(INSURANCE_DETAILS);
			
			$scope.data.appendix_B.B1_10.equalityLegislation = angular.copy(EQUALITY_LEGISLATION);			
			$scope.data.appendix_B.B1_13.generalDataProtection = angular.copy(GENERAL_DATA_PROTECTION);
		}

		/**
		 * Get weighateg details in evalution stage
		 */
		function getPrequalWeightages() {
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages?boid=" + $scope.data.buyerOrgId + "&weightageId=" + weightageId,
				method: 'GET',
				withCredentials: true,
				data: {},
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
			}).then(function (response) {
				if (window.currentViewName == "PREQUAL_RES_VIEW") {
					var resMyFields = response.data && response.data.myFields;
					if (resMyFields) {
						$scope.jsonWeightage = resMyFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;

						for (var i = 0; i < $scope.jsonWeightage.customSections.length; i++) {
							var custSection = $scope.jsonWeightage.customSections[i];
							var tempSubObj = [];
							for (var k = 0; k < custSection.customSubSections.length; k++) {
								var subElement = custSection.customSubSections[k];
								tempSubObj.push({
									"parenRef": custSection.customSectionId,
									"subSectionPercentage": subElement.customSubPercentage,
									"isSubSectionValid": subElement.isCustomSubSectionValid,
									"isSubSectionActive": subElement.isCustomSubActive,
									"evalutionWeightageValue": "",
									"subSectionId": subElement.customSubSectionId,
									"subSectionName": subElement.label
								});
							}
							$scope.jsonWeightage.Sections.push({
								"sectionName": custSection.label,
								"sectionPercentage": custSection.customPercentage,
								"isSubSectionValid": custSection.isCustomSectionValid,
								"evalutionWeightageValue": "",
								"sectionId": custSection.customSectionId,
								"isSectionValid": custSection.isCustomSectionValid,
								"isSectionActive": custSection.isCustomActive,
								"subSections": tempSubObj
							})
						}

						$scope.approveStatus = $scope.data.approveStatus;
						$scope.rejectStatus = $scope.data.rejectStatus;
						$scope.update();
						resizeTextarea();
					}
				} else {
					$scope.prequalJsonWeightage = response.data.myFields;
					showHidePrequalSection();
					$scope.currentSubItem = $scope.data.uopData[0].data[0].id;
					$scope.currentSubItemData = $scope.data.uopData[0].data[0];
					$scope.uopJSON = $scope.data;
					$scope.update();
					resizeTextarea();
				}

			}, function () {
			});
		}

		/**
		 * Canel button event to close form
		 */
		$scope.cancel = function () {
			if($window.top.closeCreateFormIframe){
                $window.top.closeCreateFormIframe(-1);
            }else{
				if($window.top){
					$window.top.close()
				}
				$window.close()
            }		}

		/**
		 * save prequal form using marketplace API
		 */
		$scope.savePrequalForm = function (isForSaveDraft) {
			if (!weightageId || !$scope.data.buyerOrgId) {
				Notification.error({ title: lang.get('alert'), message: "Form does not have buyer or questionnaire template" });
				return;
			}
			
			var FormError = $scope.$parent.myform.$error;
			if (FormError && !commonApi._.isEmpty(FormError) && !isForSaveDraft) {
				var validateMSG = lang.get("form-submit-validation-msg");
				Notification.error({ title: lang.get('alert'), message: validateMSG });
				return;
			}

			$scope.isForSaveDraft = isForSaveDraft;
			$scope.data.vendorOrgId = USP.orgID;
			$scope.data.ORI_FORMTITLE = $scope.companyName;
			$scope.data.vendorOrgName = USP.tpdOrgName;
			$scope.data.prequalType = myConfig.prequalType ? myConfig.prequalType : 1;
			$scope.data.referenceResourceId = myConfig.referenceResourceId ?  myConfig.referenceResourceId.split("$$")[0] : "0";
			$scope.data.weightageId = weightageId;
			$scope.data.Asite_System_Data_Read_Only._5_Form_Data.DS_FORMCONTENT1 = $scope.data.referenceResourceId;

			$scope.appendAttachmentHiddenFields && $scope.appendAttachmentHiddenFields(window.getJSONData());
			$scope.appendAttachHiddenFields();
			$scope.data.rejectionEmailIDSave = USP.email;
			var formJson = {
				jsonData: {
					myFields: $scope.data
				},
				projectId: projectId  && (projectId.indexOf('$$') > 0 ? projectId.split('$$')[0] : projectId),
				formTypeId: formTypeId && formTypeId.split('$$')[0],
				userRef: userRef,
				uopAttachments: [],
				recipientMailId: $scope.data.rejectionEmailIDSave
			}
			formJson.inlineAttachments = [];
			var $attachInputs = $("input[name^='xdoc_']");
			for (var i = 0; i < $attachInputs.length; i++) {
				formJson.inlineAttachments.push(
					{ "name": $attachInputs[i].name, "value": $attachInputs[i].value }
				)
			}
			formJson.jsonData.myFields.attachments = [];

			var $fakepathids = $("input[name^='attchment_']");

			for (var i = 0; i < $fakepathids.length; i++) {
				formJson.jsonData.myFields[$fakepathids[i].name] = $fakepathids[i].value;
			}


			for (var i = 0, xsnId; i < $scope.uopAttachments.length; i++) {
				xsnId = genXdocId();
				formJson.uopAttachments.push({
					"name": $scope.uopAttachments[i].id + '',
					"value": xsnId.split(':')[0]
				});
				formJson.inlineAttachments.push({
					"name": xsnId,
					"value": 'xdInlineFile:/' + $scope.uopAttachments[i].name
				});
				formJson.jsonData.myFields[xsnId] = {
					'@inline': xsnId,
					'content': ''
				}
			}
			var attachdocs = angular.element("input[name=attachedDocs]");
			var attachdocs_ = angular.element("input[name=attachedDocs_]");
			if(attachdocs.length)
			formJson.attachedDocs = [];

			if(attachdocs_.length)
			formJson.attachedDocs_ = [];
			for(var i=0;i<attachdocs.length;i++){
				if(formJson.attachedDocs.indexOf(attachdocs[i].value == -1))
				formJson.attachedDocs.push(attachdocs[i].value);
			}
			for(var i=0;i<attachdocs_.length;i++){
				if(formJson.attachedDocs_.indexOf(attachdocs_[i].value == -1))
				formJson.attachedDocs_.push(attachdocs_[i].value);
			}

			var attachxdoc_ = angular.element("input[id^=attchment_xdoc_]");
			formJson.dataMap = {};
			for(var i=0;i<attachxdoc_.length;i++){
				var attachxdoc_Name = attachxdoc_[i].name;				
				formJson.dataMap[attachxdoc_Name]=attachxdoc_[i].value;
			}						
			formJson.eOriDraftMsgId = $("input[name ='msgId']").val();

			formJson.attachDocFolderID = $("input[name ='attachDocFolderID']").val();
			formJson.msgId = $("input[name ='msgId']").val();
			formJson.formId = formId;
			
			if ($scope.isForSaveDraft) {
				formJson.saveAsDraft = true;
			}
			formJson.editOri = false;
			if ($("input[name ='editDraft']").val() == "true") {
				formJson.formAction = 'edit';
			} else {
				formJson.formAction = 'create';
			}
			
			formJson.jsonData = angular.toJson(formJson.jsonData);
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/save",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshStatus = true;
					$scope.isForSaveDraft ? $window.alert("Form Saved as Draft.") : $window.alert("Prequalification Submitted Successfully.");
					if (window.top && window.top.opener) {
						if (ie_ver && ie_ver() > 0) {
							window.opener.reloadPublicURL && window.opener.reloadPublicURL();
						} else {
							window.top.opener.postMessage("PublicURLreload", "*");
							window.top.opener.postMessage(JSON.stringify(sendObj), "*")
						}
						window.top.close();
					} else {
						window.location = top.marketPlaceServiceURL+"?origin=true";
					}
				}
			}, function (response) {
				if(response.status = 403){
					alert('This invitation to prequalify is no longer valid.');
					sendObj.refreshStatus = true;
					window.top.opener.postMessage(JSON.stringify(sendObj), "*");
					window.close();
					//window.location = top.marketPlaceServiceURL+"?origin=true";
				}
				$window.alert("Error In Prequalification Submit.");
				$scope.clickSave = false;
				$scope.isForSaveDraft = false;
			});
		}
		function getBuyerSettings(){
			commonApi.ajax({
				url: top.marketPlaceServiceURL + '/marketplace/prequal/getBuyerSettings',
				method: 'GET',
				withCredentials:true,
				headers: {
					'ApiKey': top.marketPlaceApiKey,
					'Content-Type': 'application/json'
				},
			}).then(function (response) {
				var displayMsg = '';
				if (response && response.data) {
					$scope.isBuyer = true;
					displayMsg = 'You are unauthorized to create PQQ from here. Please return to the Marketplace view, go to the appropriate user, and complete the prequal action.'
				} else {
					$scope.isVendor = true;
					displayMsg = 'You are unauthorised to submit your PQQ from here. Please return to the Marketplace view, go to the appropriate buyer and complete the prequal action.'
				}
				var msgElem = '<div class="custom-popup">'+
								'<div class="confirm-box">'+
									'<div class="overlay"></div>'+
									'<div class="confirm-body">'+    
										'<div>'+displayMsg+'</div>'+
										'<div class="footer">'+
											'<button type="button" class="btn btn-ok">Ok</button>'+
											'<button type="button" class="btn btn-mktp" >Marketplace</button>'+
										'</div>'+
									'</div>'+
								'</div>'+
						'</div>';
				angular.element("body").append(msgElem);
				angular.element('.btn-ok').bind('click', function (e) {
					e.stopPropagation();
					$window.cancelForm && $window.cancelForm(true, true);
				});
				angular.element('.btn-mktp').bind('click', function (e) {
					e.stopPropagation();
					window.location = top.marketPlaceServiceURL+"?origin=true"
				});
			}, function (error) {
				$window.alert('Buyer setting call failed');
			})
		}
	}
	return FormController;
});