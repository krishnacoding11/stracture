/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/inlineattachment', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, htmlformservice, $filter) {

		var currentViewName = window.currentViewName;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data.myFields;
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS.RES_MSG_Custom_Fields;
		$scope.asiteSystemDataReadOnly = $scope.myFields.Asite_System_Data_Read_Only;
		$scope.asiteSystemDataReadWrite = $scope.myFields.Asite_System_Data_Read_Write;
		$scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
		$scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		$scope.strIsDraft_Res = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES;
		$scope.strIsDraft_Res_Msg = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
		var projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
		var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
		$scope.AllLocation = $scope.getValueOfOnLoadData('DS_getAllLocationByProject_PF');
		$scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		$scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		var dsAldSiteDetails = $scope.getValueOfOnLoadData('DS_ALD_SITETASK_DETAILS_RFS_RFDS');

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			isOriView = (currentViewName == "ORI_VIEW"),
			isOriPrintView = (currentViewName == "ORI_PRINT_VIEW"),
			isRespView = (currentViewName == 'RES_VIEW'),
			isRespPrintView = (currentViewName == 'RES_PRINT_VIEW'),

			STATIC_OBJ = {
				Apartment_Room_Group: {
					Building: "",
					Level: "",
					Apartment_No: "",
					Apartment_Type: ""
				},
				Location_Group: {
					Location: "",
					Architectural: "",
					Mechanical: "",
					Electrical: "",
					Arch_User_sna_comp: "",
					Mechanical_sna_comp: "",
					Electrical_sna_comp: "",
					Arch__sna_com_Desc: "",
					Mech_sna_com_Desc: "",
					Elec_sna_com_Desc: ""
				},
				Sites_Details_Group: {
					formCode: "",
					formTitle: "",
					formOrignator: "",
					formOrgName: "",
					formStatus: "",
					siteformId: "",
					formURL: "",
					formCreateDate: "",
					formDisplaydate: "",
					formOrignatorId: "",
					formlocation: ""
				},
				autocompleteMsgStructure: {
					DS_MSG_AC_TYPE: "",
					DS_MSG_AC_FORM: "",
					DS_MSG_AC_MSG_TYPE: "",
					DS_MSG_AC_USERID: "",
					DS_MSG_AC_ACTION: "",
					DS_MSG_AC_ACTION_REMARKS: ""
				},
				site: {},
			},
			CONSTANTS_OBJ = {
				closed: 'Closed-Rejected',
				Open: 'Open',
				location: 'Location',
				snaggingClosed: 'Snagging Closed',
				Mechanical_USER_LIST_KEY: 'mechanical-user-list',
				Mechanical_USER_LIST_KEY_LABEL: 'Mechanical Users',
				Architectural_USER_LIST_KEY: 'architectural-user-list',
				Architectural_USER_LIST_KEY_LABEL: 'Architectural Users',
				Electrical_USER_LIST_KEY: 'electrical-user-list',
				Electrical_USER_LIST_KEY_LABEL: 'Electrical Users',
				Architectural_Engineer_LIST_KEY: 'architectural-engineer-user-list',
				Mechanical_Engineer_LIST_KEY: 'mechanical-engineer-user-list',
				Electrical_Engineer_LIST_KEY: 'electrical-engineer-user-list',
				Architectural_Engineer_LABEL: 'Architectural Engineer Users',
				Mechanical_Engineer_LABEL: 'Mechanical Engineer Users',
				Electrical_Enginee_LABEL: 'Electrical Engineer Users'
			};
		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		//if item is deleted than make one entry mandatory
		$scope.deleteItem = function (obj, repeatingData) {
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);

		};
		$scope.addNewItem = function (repeatingData, objKeyName) {
			var newRowObject = angular.copy(STATIC_OBJ[objKeyName]);
			repeatingData.push(newRowObject);
			$scope.expandTextAreaOnLoad();
		};
		//Flush value of Accepted Description
		$scope.approveChangeEvt = function (descNodeKey, mainNode) {
			mainNode[descNodeKey] = '';
			$scope.rejectChangeEvt('Accepted');
		};
		//Set flag value of Reject.
		$scope.rejectChangeEvt = function (nodeValue) {
			$scope.isShowDescNode = (nodeValue == 'Rejected');
		};
		//Flush value of Reject Users
		$scope.rejectEvt = function () {
			$scope.resMsgCustomFields.Architectural_Engineer = "";
			$scope.resMsgCustomFields.Mechanical_Engineer = "";
			$scope.resMsgCustomFields.Electrical_Engineer = "";
		};

		function structureItemList(setFor, availList) {
			var tempList = [],
				optlabel = '';

			switch (setFor) {
				case CONSTANTS_OBJ.location:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Value10,
							modelValue: item.Value9,
							Value3: item.Value3,
							Value5: item.Value5,
							Value7: item.Value7,
							Value11: item.Value11
						});
					});
					optlabel = CONSTANTS_OBJ.location;
					break;
				case CONSTANTS_OBJ.Mechanical_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Mechanical_USER_LIST_KEY_LABEL;
					break;
				case CONSTANTS_OBJ.Architectural_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Architectural_USER_LIST_KEY_LABEL;
					break;
				case CONSTANTS_OBJ.Electrical_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Electrical_USER_LIST_KEY_LABEL;
					break;

				case CONSTANTS_OBJ.Architectural_Engineer_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Architectural_Engineer_LABEL;
					break;

				case CONSTANTS_OBJ.Mechanical_Engineer_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Mechanical_Engineer_LABEL;
					break;

				case CONSTANTS_OBJ.Electrical_Engineer_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.split('#')[1].trim(),
							modelValue: item
						});
					});
					optlabel = CONSTANTS_OBJ.Electrical_Enginee_LABEL;
					break;

			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		}

		$scope.mechanicalUserList = structureItemList(CONSTANTS_OBJ.Mechanical_USER_LIST_KEY, commonApi.roleUsersListByRoleName('mechanical inspector', projAllRolesList));
		$scope.architecturalUserList = structureItemList(CONSTANTS_OBJ.Architectural_USER_LIST_KEY, commonApi.roleUsersListByRoleName('architectural inspector', projAllRolesList));
		$scope.electricalUserList = structureItemList(CONSTANTS_OBJ.Electrical_USER_LIST_KEY, commonApi.roleUsersListByRoleName('electrical inspector', projAllRolesList));


		/**
		 * Set location values and isCalibrated value
		 * invoked on load of ori-view
		 * @param {object} item 
		 */
		function setLocationValue() {
			var locationId = commonApi.getParamObj().locationId;
			var isCalibrated = commonApi.getParamObj().isCalibrated;
			if ($window._isOffline) {
				locationId = objConfigData.locationId;
				isCalibrated = objConfigData.isCalibrated;
			}
			var locations = $scope.getValueOfOnLoadData('DS_getAllLocationByProject_PF');
			if (locations.length) {
				if (isCalibrated == 'true' && $scope.oriMsgCustomFields.Location) {
					$scope.oriMsgCustomFields.isCalibrated = true;
				} else {
					$scope.oriMsgCustomFields.isCalibrated = false;
				}
			}
		}
		/**
		 * Set location, locationName, PF_Location_Detail value from object 
		 * @param {object} item: matched item from location sp data
		 */
		function setLocationsFieldsValue(item) {
			var strPF_Details = "";
			$scope.oriMsgCustomFields.LocationName = "";
			if (item && item.Value9) {
				$scope.oriMsgCustomFields.Location = item.Value9 || '';
				strPF_Details = item.Value3.trim() + "|" + item.Value5.trim() + "|" + item.Value7.trim() + "|" + item.Value11.trim();
				$scope.oriMsgCustomFields.PF_Location_Detail = strPF_Details;
				$scope.oriMsgCustomFields.LocationName = item.Value9.split('|')[2];
			}
		}
		/**
		 * inoked when location changed from pin icon and associated location
		 * used to set location detail on location change from pin
		 * @param {assocObj}: Array of associated location
		 */
		htmlformservice.associateLocationComplete = function (assocObj) {
			var tempList = assocObj.selectedLocation;
			if (tempList && tempList.length && tempList[0].pfLocationTreeDetail) {
				var locationId = tempList[0].pfLocationTreeDetail.locationId;
				if (locationId && $scope.AllLocation.length) {
					var selectedLocation = $scope.AllLocation.filter(function (item) {
						return item.Value3 == locationId;
					});
					setLocationsFieldsValue(selectedLocation[0]);
				}
			}
		};

		//Location : select value is unique
		$scope.onLocationChange = function (currObj, repeatingObj, $index) {
			for (var i = 0; i < repeatingObj.length; i++) {
				if (currObj.Location && i != $index &&
					repeatingObj[i].Location == currObj.Location) {
					alert("You can not select same Location");
					currObj.Location = "";
				}
			}
		};
		$scope.filterSearchLocation = function (type) {
			var locationType = [];
			if (type) {
				locationType = commonApi._.filter($scope.AllLocation, function (val) {
					return val.Value9.toLowerCase().indexOf(type) != -1;
				});
				locationType = commonApi._.first(locationType, 100);
				$scope.LocationItems = commonApi.getItemSelectionList({
					arrayObject: locationType,
					groupNameKey: "",
					modelKey: "Value9",
					displayKey: "Value10"
				});
			}
		};

		$scope.sitesFormDetails = function (locationgroup) {
			var aldSite,
				tempObj = [];
			for (var j = 0; j < dsAldSiteDetails.length; j++) {
				aldSite = dsAldSiteDetails[j];
				for (var i = 0; i < locationgroup.length; i++) {
					if (locationgroup[i].Location && locationgroup[i].Location == aldSite.Value8) {
						tempObj.push({
							formURL: aldSite.URL5,
							siteformId: aldSite.Value5,
							formStatus: aldSite.Value3,
							formTitle: aldSite.Value4,
							formOrignator: aldSite.Value6,
							formCreateDate: aldSite.Value7,
							formlocation: aldSite.Value9
						});

					}
				}
			}
			$scope.resMsgCustomFields.Sites_Details_Data.Sites_Details_Group = angular.copy(tempObj);
			if (dsAldSiteDetails.length && tempObj.length) {
				var siteDataToAdd = angular.copy(tempObj);
				if ($scope.resMsgCustomFields.Sites_Details_List.site == '') {
					$scope.resMsgCustomFields.Sites_Details_List.site = angular.copy(tempObj);
				} else {
					$scope.resMsgCustomFields.Sites_Details_List.site = $scope.resMsgCustomFields.Sites_Details_List.site.concat(siteDataToAdd);
				}

			}
		};
		$scope.disabledSendAction = function (obj) {
			if (obj == 'yes') {
				$scope.disableSaveActions(false);
			} else if (obj == 'no') {
				$scope.disableSaveActions(true);
			}
		};

		function getConfigurableAttriburteByType(type) {
			var AttributeByType = [];
			if (type) {
				AttributeByType = commonApi._.filter(dsAsiConfigurableAttributes, function (val) {
					return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1;
				});
			}
			return AttributeByType;
		}
		if (isRespView) {
			if ($scope.currentUserid == $scope.resMsgCustomFields.Architectural_Engineer.split('#')[0].trim()) {
				$scope.resMsgCustomFields.Architectural_User = true;
			}
			if ($scope.currentUserid == $scope.resMsgCustomFields.Mechanical_Engineer.split('#')[0].trim()) {
				$scope.resMsgCustomFields.Mechanical_User = true;
			}
			if ($scope.currentUserid == $scope.resMsgCustomFields.Electrical_Engineer.split('#')[0].trim()) {
				$scope.resMsgCustomFields.Electrical_User = true;
			}
			$scope.resMsgCustomFields.completed_snagging = '';
			$scope.resMsgCustomFields.completed_Comment = '';
			var dsiNextstage = $scope.oriMsgCustomFields.DSI_NextStage;
			$scope.oriMsgCustomFields.DSI_CurrentStage = dsiNextstage;

			$scope.mechanicalEngiList = structureItemList(CONSTANTS_OBJ.Mechanical_Engineer_LIST_KEY, commonApi.roleUsersListByRoleName('mechanical engineer', projAllRolesList));
			$scope.architecturalEngirList = structureItemList(CONSTANTS_OBJ.Architectural_Engineer_LIST_KEY, commonApi.roleUsersListByRoleName('architectural engineer', projAllRolesList));
			$scope.electricalEngiList = structureItemList(CONSTANTS_OBJ.Electrical_Engineer_LIST_KEY, commonApi.roleUsersListByRoleName('electrical engineer', projAllRolesList));

			var pendingActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
				return val.Value4 == 'Respond';
			});
			if (pendingActionData.length == 1) {
				$scope.sendActionToAtk_Manager = 'yes';
			}
		}

		if (isOriView) {
			if (!$scope.strFormId) {
				$scope.oriMsgCustomFields.Originator_Id = $scope.currentUserid;
				setLocationValue();
			}
		}
		if (isOriView || isRespView) {
			$scope.wirStatus = commonApi.getItemSelectionList({
				arrayObject: getConfigurableAttriburteByType("Wir Status"),
				groupNameKey: "",
				modelKey: "Value8",
				displayKey: "Value8"
			});
		}
		if (isRespPrintView || isOriPrintView) {
			var aldSiteList,
				locaList = $scope.oriMsgCustomFields.Location_List.Location_Group,
				tempsiteList = [];
			for (var j = 0; j < dsAldSiteDetails.length; j++) {
				aldSiteList = dsAldSiteDetails[j];
				for (var i = 0; i < locaList.length; i++) {
					if (locaList[i].Location && locaList[i].Location == aldSiteList.Value8) {
						tempsiteList.push({
							formURL: aldSiteList.URL5,
							siteformId: aldSiteList.Value5,
							formStatus: aldSiteList.Value3,
							formTitle: aldSiteList.Value4,
							formOrignator: aldSiteList.Value6,
							formCreateDate: aldSiteList.Value7,
							formlocation: aldSiteList.Value9
						});
					}
				}
			}
			$scope.oriMsgCustomFields.siteList = angular.copy(tempsiteList);
		}
		function assignToRespond(distNodes) {
			var tempList = [];
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if (distNodes.length) {
				for (var i = 0; i < distNodes.length; i++) {
					if (distNodes[i].Architectural) {
						tempList.push({
							strUser: distNodes[i].Architectural.split('#')[0].trim(),
							strAction: "3#",
							strDate: commonApi.calculateDistDateFromDays({
								baseDate: $scope.serverDate,
								days: 5
							})
						});
					}
					if (distNodes[i].Electrical) {
						tempList.push({
							strUser: distNodes[i].Electrical.split('#')[0].trim(),
							strAction: "3#",
							strDate: commonApi.calculateDistDateFromDays({
								baseDate: $scope.serverDate,
								days: 5
							})
						});
					}
					if (distNodes[i].Mechanical) {
						tempList.push({
							strUser: distNodes[i].Mechanical.split('#')[0].trim(),
							strAction: "3#",
							strDate: commonApi.calculateDistDateFromDays({
								baseDate: $scope.serverDate,
								days: 5
							})
						});
					}
				}
			}
			if (tempList.length) {
				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: isRespView ? '13' : '3',
				});
			}
		}
		function assignToEngineer(engineer) {
			var autoDistNode = isRespView ? '13' : '3';
			commonApi.setDistributionNode({
				actionNodeList: [{
					strUser: engineer.split('#')[0].trim(),
					strAction: "3#Respond",
					strDate: commonApi.calculateDistDateFromDays({
						baseDate: $scope.serverDate,
						days: 5
					})
				}],
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: autoDistNode
			});
		}
		/**
		 * set response action to distribution users.
		 */
		function setDistribution() {
			var tempList = [],
				atkinsUserRole = commonApi.roleUsersListByRoleName('atkins qa qc manager', projAllRolesList);
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if (atkinsUserRole.length) {
				for (var i = 0; i < atkinsUserRole.length; i++) {
					tempList.push({
						strUser: atkinsUserRole[i].split('#')[0].trim(),
						strAction: "3#",
						strDate: commonApi.calculateDistDateFromDays({
							baseDate: $scope.serverDate,
							days: 5
						})
					});
				}

				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: isRespView ? '13' : '3'
				});
			}
		}
		function setFormStatusAndFlow() {
			var userTodistribute = '',
				currFormStaus = 'Open' || '',
				autoDistNode = isRespView ? '13' : '3',
				userForInfo = '';
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if (isOriView) {
				setDistribution();
				currFormStaus = 'Open';
			} else if (isRespView) {
				var currentstage = $scope.oriMsgCustomFields.DSI_CurrentStage;
				if (currentstage) {
					switch (currentstage) {
						case '0':
							if ($scope.resMsgCustomFields.Atkins_Manager_ApproveReject == 'Rejected') {
								userForInfo = $scope.oriMsgCustomFields.Originator_Id;
								currFormStaus = CONSTANTS_OBJ.closed;
							} else if (!$scope.resMsgCustomFields.manager_approveReject && $scope.resMsgCustomFields.Atkins_Manager_ApproveReject == 'Accepted') {
								$scope.resMsgCustomFields.manager_approveReject = true;
								$scope.resMsgCustomFields.Atkins_Manager = WorkingUserID['0'].Value.trim();
								$scope.oriMsgCustomFields.DSI_NextStage = "1";
								$scope.resMsgCustomFields.Engineers = true;
								if ($scope.resMsgCustomFields.Architectural_Engineer) {
									assignToEngineer($scope.resMsgCustomFields.Architectural_Engineer);
								}
								if ($scope.resMsgCustomFields.Mechanical_Engineer) {
									assignToEngineer($scope.resMsgCustomFields.Mechanical_Engineer);
								}
								if ($scope.resMsgCustomFields.Electrical_Engineer) {
									assignToEngineer($scope.resMsgCustomFields.Electrical_Engineer);
								}

							}
							break;
						case '1':
							if ($scope.resMsgCustomFields.manager_approveReject && $scope.resMsgCustomFields.Atkins_Manager_ApproveReject == 'Accepted') {
								$scope.resMsgCustomFields.manager_approveReject = true;
								var userlist = $scope.oriMsgCustomFields.Location_List.Location_Group;
								if (userlist.length) {
									$scope.sendAction = 'yes';
									for (var i = 0; i < userlist.length; i++) {
										if (userlist[i].Architectural == '' || userlist[i].Mechanical == '' || userlist[i].Electrical == '') {
											$scope.sendAction = '';
										}
									}
								}
								if ($scope.sendAction == 'yes') {
									assignToRespond(userlist);
									$scope.oriMsgCustomFields.DSI_NextStage = "2";
								} else {
									$scope.oriMsgCustomFields.DSI_NextStage = "1";
									$scope.resMsgCustomFields.Architectural_User = false;
									$scope.resMsgCustomFields.Mechanical_User = false;
									$scope.resMsgCustomFields.Electrical_User = false;
								}
								currFormStaus = CONSTANTS_OBJ.Open;
							}
							break;
					}
				}

			}

			if (userTodistribute) {
				commonApi.setDistributionNode({
					actionNodeList: [{
						strUser: userTodistribute.split('#')[0].trim(),
						strAction: "3#Respond",
						strDate: commonApi.calculateDistDateFromDays({
							baseDate: $scope.serverDate,
							days: 5
						})
					}],
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: autoDistNode
				});
			}

			if (userForInfo) {
				// Distribution Will be made from here for 
				commonApi.setDistributionNode({
					actionNodeList: [{
						strUser: userForInfo.trim(),
						strAction: "7#For Information",
					}],
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: autoDistNode
				});
			}

			// Form's Staus will be set from below code.
			var strFormStatusId = commonApi.getFormStatusId({
				availFormStatusesList: availFormStatuses,
				strStatus: currFormStaus
			});
			if (strFormStatusId) {
				$scope.resMsgCustomFields.appCurrentStatus = currFormStaus;
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
				$scope.resMsgCustomFields.lastApproveReject = $scope.approveReject;
			}

		}
		/**
		 * clear action in response view.
		 */
		function clearActionByMsg() {
			var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
				return val.Value4 == 'Respond';
			});
			if (ActionData.length) {
				$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
				$scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
				var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
				var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
				for (var i = 0; i < ActionData.length; i++) {
					var AutocompleteMsg = angular.copy(STATIC_OBJ.autocompleteMsgStructure);
					AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
					AutocompleteMsg.DS_MSG_AC_FORM = AppId;
					AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
					AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
					AutocompleteMsg.DS_MSG_AC_ACTION = "3";
					AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";
					insertpoint.push(AutocompleteMsg);
				}
			}
		}
		//to Hide Export Button in print view
		angular.element(".export-btn").hide();
		$scope.update();
		function formSubmitCallBack() {
			$scope.oriMsgCustomFields.ORI_FORMTITLE = $scope.asiteSystemDataReadOnly._4_Form_Type_Data.DS_FORMNAME;
			$element.removeClass('loaded');
			return false;
		}
		$window.oriformSubmitCallBack = function () {
			if (isRespView && !$scope.resMsgCustomFields.manager_approveReject) {
				clearActionByMsg();
			}
			$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';
			setFormStatusAndFlow();
			return formSubmitCallBack();
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
