/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if ($scope.projectId == "null")
            $scope.projectId = window.currProjId;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.serverDate = "";
        $scope.todayDateDbFormat = "";
        $scope.todayDateUKFormat = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-mm-yy');            
            if (!$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE']) {
                var serverDateObj = new Date(serverDate);
                serverDateObj.setDate(serverDateObj.getDate() + 7);
                $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_CLOSE_DUE_DATE'] = $scope.formatDate(serverDateObj, 'yy-mm-dd');
            }
        });
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.TenderContractorsData = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["TenderContractorsData"];
        $scope.documentCheckbox = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["documentCheckbox"];
        $scope.SubcontractorTenderComparisonBlock = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"]["SubcontractorTenderComparisonBlock"];
        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.DS_PYD_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_PYD_STD_TNDR_GetITBs');
        var userDetailsData = $scope.getValueOfOnLoadData('DS_PYD_STD_TNDR_GET_PROJECT_DETAILS');
        $scope.isXHRon = false;
        $scope.disableTenderName = false;
        $scope.isWorkingUserHasAction = true; 
        $scope.isUserWithStage = {
            isCA : false,
            isPM : false,
            isCM : false,
            isGM : false
        };    
        $scope.restrictionMessage = "You currently do not have 'Assign Status' action and therefore you can not edit the form.";
        $timeout(function () {
            $scope.expandTextAreaOnLoad();
        }, 1000);
        $scope.appNotApproveList = [{
            displayName : 'Approved',
            value : 'approved'
        },{
            displayName : 'Not Approved',
            value : 'not approved'
        }];

        var isDraftElem = document.getElementById("DS_ISDRAFT"),
            fWDDraftElem = document.getElementById("DS_ISDRAFT_FWD_MSG"),
            isFormIdElem = document.getElementById("DS_FORMID"),
            ISDRAFT = isDraftElem.value ? isDraftElem.value : '',
            FDWMSGDRAFT = fWDDraftElem.value ? fWDDraftElem.value : '',            
            FORMID =  isFormIdElem.value ? isFormIdElem.value : '',
            workflowUserSeq = $scope.oriMsgCustomFields.workflowCurrentStage || "",
            availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
            
        if (currentViewName == "ORI_VIEW") {
            setProjUserDetail();
            $timeout(function () {
                $scope.switchTabs(null, 'Summary', "onload");
                if ($element.find('.tablinks').length) {
                    $element.find('.tablinks').first().addClass("active");
                }
            }, 500);
        }
        
        function checkUserHasAction (userId, strActionName, projUserDetails) {            
            var incompletedActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
            if(incompletedActionList.length) {                
                var strActionMatch = '|' + userId + '| # ' + strActionName,
                incompleteActionObj = commonApi._.find(incompletedActionList, function(obj) {
                    return obj.Value == strActionMatch;
                }) || {};

                if(incompleteActionObj.Value) {
                    return true;
                }
            } else if(!incompletedActionList.length && (FORMID == "") && $scope.workingUserId == projUserDetails.CAUserId) {
                return true;
            }
            return false;
        }
        
        function userWithStageObj() {             
            $scope.isUserWithStage.isCA = ($scope.workingUserId == $scope.oriMsgCustomFields.projUserDetails.CAUserId) && (!$scope.oriMsgCustomFields.workflowCurrentStage || $scope.oriMsgCustomFields.workflowCurrentStage == '' || $scope.oriMsgCustomFields.workflowCurrentStage == '0');
            $scope.isUserWithStage.isPM = ($scope.workingUserId == $scope.oriMsgCustomFields.projUserDetails.PMUserId) && ($scope.oriMsgCustomFields.workflowCurrentStage == '1');
            $scope.isUserWithStage.isCM = ($scope.workingUserId == $scope.oriMsgCustomFields.projUserDetails.CMUserId) && ($scope.oriMsgCustomFields.workflowCurrentStage == '2');
            $scope.isUserWithStage.isGM = ($scope.workingUserId == $scope.oriMsgCustomFields.projUserDetails.GMUserId) && ($scope.oriMsgCustomFields.workflowCurrentStage == '3');            
        }

        function setUserRoleAccessFlag(projUserDetails, isForCreate, isFwdCreateFlag) {            
            var workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
            $scope.workingUserId = workingUserObj.Value.split('|')[0].trim() ||'';
            var userExistInRoleIndex = [projUserDetails.CAUserId,projUserDetails.PMUserId,projUserDetails.CMUserId,projUserDetails.GMUserId].indexOf($scope.workingUserId);
            $scope.isWorkingUserHasAction = false;
            if(isForCreate){
                $scope.isWorkingUserHasAction = true;
                $scope.oriMsgCustomFields.projUserDetails.CAUserId = $scope.workingUserId;
                if(currentViewName == 'ORI_VIEW' && FORMID == '') {
                    $scope.SubcontractorTenderComparisonBlock.ConAdminDate = $scope.todayDateDbFormat;
                    $scope.oriMsgCustomFields.roleWiseApproved.isCAApproved = 'approved';
                }
            } else if(userExistInRoleIndex > -1 && (!isForCreate || !isFwdCreateFlag)){ 
                $scope.isWorkingUserHasAction = checkUserHasAction($scope.workingUserId, 'Assign Status', projUserDetails);
            }
            if($scope.isWorkingUserHasAction) {
                userWithStageObj();
                workflowUserSeq && (workflowUserSeq = parseInt(workflowUserSeq));                
                $scope.oriMsgCustomFields.DSI_Hide_Show = "1";
            }
        }

        function getTenderDetails() {            
            if (currentViewName !== "ORI_VIEW") {
                return;
            }

            //Hide Draft
            var tenderID = $scope.oriMsgCustomFields.TenderContractorsData.tenderID,
                strSpList = "DS_PYD_TND_COST_COMPARISION,DS_PYD_STD_TNDR_GET_PROJ_DTL",
                spsObjList = [{
                    "fieldName": "DS_PYD_TND_COST_COMPARISION",
                    "fieldValue": tenderID
                },{
                    "fieldName": "DS_PYD_STD_TNDR_GET_PROJ_DTL",
                    "fieldValue": tenderID
                }];

            if(!$scope.oriMsgCustomFields.projUserDetails.isProjectDetailsAvail) {
                strSpList = strSpList + ",DS_PYD_STD_TNDR_GET_PROJECT_DETAILS";
                spsObjList.push({
                    "fieldName": "DS_PYD_STD_TNDR_GET_PROJECT_DETAILS",
                    "fieldValue": $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3
                });
            }

            var form = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": strSpList,
                "callbackParamVO": {
                    "customFieldVOList": spsObjList
                }
            };          

            $scope.isXHRon = true;
            $scope.getCallbackData(form).then(function (response) {
                if (!response.data) {
                    return;
                }
                initDynamicColumns();
                $scope.disableTenderName = true;
                var resData = angular.fromJson(response.data['DS_PYD_TND_COST_COMPARISION']).Items.Item;
                var allHeader = [{
                        modalValue: '',
                        dispValue: 'Budget Description / Cost Centre'
                    },
                    {
                        modalValue: '',
                        dispValue: 'Budget Amount'
                    }
                ];
                var allTempHeader = resData[0].Value3;
                allTempHeader = allTempHeader.split(' | ');
                for (var i = 0; i < allTempHeader.length; i++) {
                    if (allTempHeader[i] == "Zzz") {
                        allTempHeader[i] = {
                            modalValue: '',
                            dispValue: 'Zzz'
                        };
                    } else {
                        allTempHeader[i] = {
                            modalValue: allTempHeader[i].indexOf(',') != -1 ? allTempHeader[i].split(',')[1].trim() : allTempHeader[i].trim(),
                            dispValue: allTempHeader[i].indexOf(',') != -1 ? allTempHeader[i].split(',')[1].trim() : allTempHeader[i].trim()
                        };
                    }
                }
                allHeader = allHeader.concat(allTempHeader);
                for(var i=0; i<allHeader.length; i++){
                    allHeader[i].id = i;
                }

                var tempItemValues = [];
                var tempColData = [];
                for (var i = 1; i < resData.length; i++) {
                    var tempColData = [{
                        value: resData[i].Value1,
                        "rowId": 1,
                        "colId": 1,
                        "isExcluded":''
                    }, {
                        value: parseFloat(resData[i].Value2),
                        "rowId": 1,
                        "colId": 2,
                        "isExcluded":''
                    }];
                    if (resData[i].Value3) {
                        var splitVal = resData[i].Value3.split(' | ');
                        for (var k = 0; k < splitVal.length; k++) {
                            tempColData.push({
                                value: parseFloat(splitVal[k]),
                                "rowId": k + 2,
                                "colId": i + 3,
                                "isExcluded":''
                            });
                        }
                    }
                    tempItemValues.push({
                        "colId": i,
                        "colData": tempColData
                    });
                }
                $scope.TenderContractorsData.headerData.headerValues = angular.copy(allHeader);
                $scope.TenderContractorsData.itemData.itemValues = angular.copy(tempItemValues);
                $scope.TenderContractorsData.columnCount = tempColData.length;
                $scope.TenderContractorsData.rowmnCount = $scope.TenderContractorsData.itemData.itemValues.length

                // set Project Details set in Project Form
                var projDtlResData = angular.fromJson(response.data['DS_PYD_STD_TNDR_GET_PROJ_DTL']).Items.Item;
                $scope.SubcontractorTenderComparisonBlock.projName = projDtlResData[0].Value1;
                $scope.SubcontractorTenderComparisonBlock.jobRef = projDtlResData[0].Value5;
                $scope.SubcontractorTenderComparisonBlock.clientName = projDtlResData[0].Value2;
                $scope.SubcontractorTenderComparisonBlock.tradePackage = projDtlResData[0].Value3;
                $scope.SubcontractorTenderComparisonBlock.date = projDtlResData[0].Value4;

                if(!$scope.oriMsgCustomFields.projUserDetails.isProjectDetailsAvail) {
                    // set User Details set in Project Form
                    var userDetailsData = angular.fromJson(response.data['DS_PYD_STD_TNDR_GET_PROJECT_DETAILS']).Items.Item[0];                    
                    $scope.oriMsgCustomFields.projUserDetails.PMUserId = userDetailsData.Value16;
                    $scope.oriMsgCustomFields.projUserDetails.PMUserName = userDetailsData.Value17;
                    $scope.oriMsgCustomFields.projUserDetails.CMUserId = userDetailsData.Value18;
                    $scope.oriMsgCustomFields.projUserDetails.CMUserName = userDetailsData.Value19;
                    $scope.oriMsgCustomFields.projUserDetails.GMUserId = userDetailsData.Value20;
                    $scope.oriMsgCustomFields.projUserDetails.GMUserName = userDetailsData.Value21;
                    $scope.oriMsgCustomFields.projUserDetails.isProjectDetailsAvail = true;
                    setUserRoleAccessFlag($scope.oriMsgCustomFields.projUserDetails, true, false);
                    // Form Title will set here.                    
                    var tenderObj = commonApi._.find($scope.DS_PYD_STD_TNDR_GetITBs, function(tendObj){
                        return tendObj.Value1 == tenderID;        
                    });
                    tenderObj.Value2 && ($scope.oriMsgCustomFields.ORI_FORMTITLE = tenderObj.Value2);
                }
                $timeout(function () {
                    initialTenderAdjustments();
                    $scope.calcBudgetSubTotal();
                    $scope.isXHRon = false;
                    //$scope.oriMsgCustomFields.DSI_Hide_Show = "1";
                });
            });            
        };

        $scope.setTenderTotalAdjustments = function (adjustmentValue, index, parentindex) {
            //Set Value in TenderAdjustments
            if (!adjustmentValue.no || adjustmentValue.isAdjustmentExcluded) {
                adjustmentValue.no = 0;
            }
            $scope.TenderContractorsData.TenderAdjustments[parentindex].value[index] = adjustmentValue;
            doAllToalCalculation();
        }
        
        $scope.setOriUserRef = function (selectedTender) {
            var dataObj = commonApi._.filter($scope.DS_PYD_STD_TNDR_GetITBs, function (val) {
                return val.Value1.trim() == selectedTender.trim();
            });
            var strValue7 = "",
                strValue3 = "",
                strValue8 = "";
            if (dataObj.length) {
                strValue7 = dataObj[0].Value7.trim();
                strValue3 = dataObj[0].Value3.trim();
                strValue8 = dataObj[0].Value8.trim();
            }
            $scope.oriMsgCustomFields.ORI_USERREF = strValue7.split('-' + strValue3)[0];
            $scope.oriMsgCustomFields.Project_Code = strValue7;
            //  set DS_FORMCONTENT1 and DS_FORMCONTENT3 here.
            //  DS_FORMCONTENT1 - ITB FORM's ID strValue3 indicates ITB Form Id.
            //  DS_FORMCONTENT3 - PROJ FORM's ID strValue8 indicates PROJ Form Id.
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strValue3;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT3 = strValue8;
        }
        $scope.UpdateRecommended = function () {
            var headers = $scope.TenderContractorsData.headerData.headerValues;
            var TenderTotalAdjustmentsSum = [];
            for (var i = 0; i < headers.length; i++) {
                if (headers[i].modalValue != "") {
                    TenderTotalAdjustmentsSum.push({
                        modalValue: headers[i].modalValue,
                        dispValue: headers[i].dispValue,
                        id : i
                    });                    
                    $scope.TenderContractorsData.headerData.headerValues[i].id = i;
                }
            }
            $scope.TenderContractorsData.SubContracters = TenderTotalAdjustmentsSum;
        }

        $scope.setApproveDate = function(value, nodeName, field) {
            $scope[nodeName][field] = "";
            value && ($scope[nodeName][field] = $scope.todayDateDbFormat);
        };

        function calculateTenderTotalAdjustments() {
            var TenderTotalAdjustmentsSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                TenderTotalAdjustmentsSum.push(0);
            }
            if ($scope.TenderContractorsData.TenderAdjustments) {
                for (var i = 0; i < $scope.TenderContractorsData.TenderAdjustments.length; i++) {
                    var tenderAdjustment = $scope.TenderContractorsData.TenderAdjustments[i].value;
                    for (var j = 0; j < TenderTotalAdjustmentsSum.length; j++) {
                        if (tenderAdjustment[j + 1].isAdjustmentExcluded == '') {
                            TenderTotalAdjustmentsSum[j] += parseFloat(tenderAdjustment[j + 1].no);
                        }
                    }
                }
                $scope.TenderContractorsData.TenderTotalAdjustments = ["Total Adjustments"].concat(TenderTotalAdjustmentsSum);
                calculateProposedTradeGainLoss();
                calculateTenderTradeGainLoss();
            }
        };

        function calculateProposedTradeGainLoss() {
            var ProposedTradeGainLossSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                ProposedTradeGainLossSum.push(0);
            }
            for (var j = 0; j < ProposedTradeGainLossSum.length; j++) {
                ProposedTradeGainLossSum[j] = parseFloat($scope.TenderContractorsData.TenderTotalAdjustments[j + 1]) + parseFloat($scope.TenderContractorsData.SubTotal[j + 1]);
            }
            $scope.TenderContractorsData.ProposedTradeGainLoss = ["Proposed Total Budget / Let Value"].concat(ProposedTradeGainLossSum);
        }

        function calculateTenderTradeGainLoss() {
            var TenderTradeGainLossSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                TenderTradeGainLossSum.push(0);
            }
            for (var j = 1; j < TenderTradeGainLossSum.length; j++) {
                TenderTradeGainLossSum[j] = parseFloat($scope.TenderContractorsData.ProposedTradeGainLoss[1]) - parseFloat($scope.TenderContractorsData.ProposedTradeGainLoss[j + 1]);
            }
            $scope.TenderContractorsData.TenderTradeGainLoss = ["Tender Trade Gain  / Loss to Budget"].concat(TenderTradeGainLossSum);
        }
        $scope.setTenderAllowances = function (allowancesValue) {
            //Set Value in TenderAdjustments
            if(allowancesValue.isAllowanceExcluded){
                allowancesValue.no = 0;
            }
            doAllToalCalculation();
        };

        function doAllToalCalculation() {
            calculateTenderTotalAdjustments();
            calculateTenderTotalAllowances();
            calculateTotalAllowances();
            calculateTradeAllowances();
        }

        function calculateTenderTotalAllowances() {
            var TenderTotalAllowancesSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                TenderTotalAllowancesSum.push(0);
            }
            if ($scope.TenderContractorsData.Allowances) {
                for (var i = 0; i < $scope.TenderContractorsData.Allowances.length; i++) {
                    var tenderAllowances = $scope.TenderContractorsData.Allowances[i].value;
                    for (var j = 0; j < TenderTotalAllowancesSum.length; j++) {
                        if (tenderAllowances[j + 1].isAllowanceExcluded == '') {
                            TenderTotalAllowancesSum[j] += parseFloat(tenderAllowances[j + 1].no);
                        }
                    }
                }
                $scope.TenderContractorsData.SubTotalAllowances = ["Sub-Total Allowances"].concat(TenderTotalAllowancesSum);
            }
        };

        function calculateTotalAllowances() {
            var TotalAllowancesSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                TotalAllowancesSum.push(0);
            }
            for (var j = 0; j < TotalAllowancesSum.length; j++) {
                TotalAllowancesSum[j] = parseFloat($scope.TenderContractorsData.ProposedTradeGainLoss[j + 1]) + parseFloat($scope.TenderContractorsData.SubTotalAllowances[j + 1]);
            }
            $scope.TenderContractorsData.TotalAllowances = ["Total Budget / Tender and Allowances"].concat(TotalAllowancesSum);
        };

        function calculateTradeAllowances() {
            var TradeAllowancesSum = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                TradeAllowancesSum.push(0);
            }
            var totalBudgetTenderAllowance = $scope.TenderContractorsData.TotalAllowances[1];
            for (var j = 0; j < TradeAllowancesSum.length; j++) {
                TradeAllowancesSum[j] = parseFloat(totalBudgetTenderAllowance) - parseFloat($scope.TenderContractorsData.TotalAllowances[j + 1]);
            }
            TradeAllowancesSum.shift();
            $scope.TenderContractorsData.TradeAllowances = ["Trade loss / Gain Including Allowances", ""].concat(TradeAllowancesSum);
        };

        $scope.getTenderDetailsData = function () {            
            if (FORMID == "" || ISDRAFT == "YES") {
                getTenderDetails();
            }
        };
        
        function initDynamicColumns() {
            $scope.calcBudgetSubTotal();
            initialTenderAdjustments();
            $timeout(function () {
                $scope.switchTabs(null, 'Summary', "onload");
                if ($element.find('.tablinks').length) {
                    $element.find('.tablinks').first().addClass("active");
                }
            }, 500);
            calculateTenderTotalAdjustments();
            calculateTenderTotalAllowances();
            calculateTotalAllowances();
            calculateTradeAllowances();
        };
        $scope.calcBudgetSubTotal = function () {
            var itemValues = $scope.TenderContractorsData.itemData.itemValues;
            $scope.TenderContractorsData.SubTotal = ["Sub-Total Tender / Budget"];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                var sum = 0;
                for (var j = 0; j < itemValues.length; j++) {
                    if(['Excluded','Included'].indexOf(itemValues[j].colData[i + 1].isExcluded) == -1) {
                        sum += parseInt(itemValues[j].colData[i + 1].value) || 0;
                    } else {
                        itemValues[j].colData[i + 1].value = "0";
                    }
                }
                $scope.TenderContractorsData.SubTotal.push(sum);
            }
            doAllToalCalculation();
        };

        function initialTenderAdjustments() {
            
            var dynamicColumnValues = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                dynamicColumnValues.push(0);
            }
            $scope.TenderContractorsData.RecommendedSubContractorName = "";
            $scope.TenderContractorsData.TenderAdjustments = [];
            var headers = $scope.TenderContractorsData.headerData.headerValues;
            var strReviewCoordinatorUserArr = commonApi._.filter(headers, function (obj) {
                return obj.dispValue.indexOf("Zzz") < 0
            });
            $scope.TenderContractorsData.SubContracters = strReviewCoordinatorUserArr.slice(2, $scope.TenderContractorsData.columnCount);

            $scope.TenderContractorsData.TenderTotalAdjustments = ["Total Adjustments"].concat(dynamicColumnValues);
            
            $scope.TenderContractorsData.TenderTradeGainLoss = ["Tender Trade Gain  / Loss to Budget"].concat(dynamicColumnValues);
            
            $scope.TenderContractorsData.ProposedTradeGainLoss = ["Proposed Total Budget / Let Value"].concat(dynamicColumnValues);
            
            $scope.TenderContractorsData.Allowances = [];
            
            $scope.TenderContractorsData.SubTotalAllowances = ["Sub-Total Allowances"].concat(dynamicColumnValues);
            
            $scope.TenderContractorsData.TotalAllowances = ["Total Budget / Tender and Allowances"].concat(dynamicColumnValues);
            
            $scope.TenderContractorsData.TradeAllowances = ["Trade loss / Gain Inculding Allowances"].concat(dynamicColumnValues);
        };
        $scope.addBudget = function () {
            var dynamicColumnValues = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                dynamicColumnValues.push(0);
            }

            var rowLength = $scope.oriMsgCustomFields.TenderContractorsData.itemData.itemValues.length;
            var tempLastRowData = $scope.oriMsgCustomFields.TenderContractorsData.itemData.itemValues[0];

            var tempItemValues = [];
            var tempColData = [];

            if (tempLastRowData.colData) {
                for (var k = 0; k < tempLastRowData.colData.length; k++) {
                    tempColData.push({
                        value: k == 0 ? '' : 0,
                        "rowId": k,
                        "colId": rowLength,
                        "isExcluded":''
                    });
                }
            }
            tempItemValues = {
                "colId": rowLength,
                "colData": tempColData
            };
            $scope.oriMsgCustomFields.TenderContractorsData.itemData.itemValues.push(tempItemValues);
        };

        $scope.removeBudget = function (index) {
            $scope.TenderContractorsData.itemData.itemValues.splice(index, 1);
            for (var i = 0; i < $scope.TenderContractorsData.itemData.itemValues.length; i++) {
                $scope.TenderContractorsData.itemData.itemValues[i].rowId = i + 1;
            }
        };
        $scope.addTenderAdjustment = function () {
            var dynamicColumnValues = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                dynamicColumnValues.push({no:0,isAdjustmentExcluded:""});
            }
            var index = $scope.TenderContractorsData.TenderAdjustments.length + 1;
            $scope.TenderContractorsData.TenderAdjustments.push({
                "adjustmentRowId": index,
                "value": [""].concat(dynamicColumnValues)
            });
        };
        $scope.removeTenderAdjustment = function (index) {
            $scope.TenderContractorsData.TenderAdjustments.splice(index, 1);
            for (var i = 0; i < $scope.TenderContractorsData.TenderAdjustments.length; i++) {
                $scope.TenderContractorsData.TenderAdjustments[i].adjustmentRowId = i + 1;
            }
            calculateTenderTotalAdjustments();
        };
        $scope.addAllowances = function () {
            var dynamicColumnValues = [];
            for (var i = 0; i < $scope.TenderContractorsData.columnCount - 1; i++) {
                dynamicColumnValues.push({no:0,isAllowanceExcluded:""});
            }
            var index = $scope.TenderContractorsData.Allowances.length + 1;
            $scope.TenderContractorsData.Allowances.push({
                "allowanceRowId": index,
                "value": [""].concat(dynamicColumnValues)
            });
        };
        $scope.removeAllowances = function (index) {
            $scope.TenderContractorsData.Allowances.splice(index, 1);
            for (var i = 0; i < $scope.TenderContractorsData.Allowances.length; i++) {
                $scope.TenderContractorsData.Allowances[i].allowanceRowId = i + 1;
            }
            calculateTenderTotalAllowances();
        };

        $scope.SubContractersLatestData = [];
        $scope.switchTabs = function (evt, tab, calledOnload) {
            var i, tabcontent, tablinks;
            tabcontent = $element.find(".tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = $element.find(".tablinks");
            tablinks.removeClass("active");            

            if (document.getElementById(tab)) {
                document.getElementById(tab).style.display = "block";
            }
            if (calledOnload != "onload") {
                $element.find(evt.currentTarget).addClass("active");
            }

            if (tab == "TenderReport") {
                loadSubContratorData();
            }
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            }, 1000);
        };

        /**
         * Form's current Stage Map 
         * 0- CA [ Form is at Contracts Administrator ]
         * 1- PM [ Form is at Project Manager ]
         * 2- CM [ Form is at Contracts Manager ]
         * 3- GM [ Form is at General Manager ]
         */

        function setFormWorkflow() {            
            var userTodistribute = '',
                currFormStaus = '';
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = []; 
            switch ( workflowUserSeq+'' ) {
                case "":                    
                case "0":                    
                    if(workflowUserSeq == '' && FORMID != '' && !$scope.oriMsgCustomFields.projUserDetails.isProjectDetailsAvail) {
                        break;
                    }
                    if($scope.oriMsgCustomFields.roleWiseApproved.isCAApproved == 'approved') {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "1";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.PMUserId;
                        currFormStaus = "contracts administrator approved";
                    } else {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "0";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.CAUserId;
                        currFormStaus = "contracts administrator rejected";
                    }
                    break;
				case "1":
                    if($scope.oriMsgCustomFields.roleWiseApproved.isPMApproved == 'approved') {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "2";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.CMUserId;
                        currFormStaus = "project manager approved";
                    } else {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "0";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.CAUserId;
                        currFormStaus = "project manager rejected";
                    }
                    break;
				case "2":
                    if($scope.oriMsgCustomFields.roleWiseApproved.isCMApproved == 'approved') {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "3";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.GMUserId;
                        currFormStaus = "contracts manager approved";
                    } else {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "0";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.CAUserId;
                        currFormStaus = "contracts manager rejected";
                    }
                    break;
                case "3":                    
                    if($scope.oriMsgCustomFields.roleWiseApproved.isGMApproved == 'approved') {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "4";
                        commonApi.setDistributionNode({
                            actionNodeList : [{
                                strUser : $scope.oriMsgCustomFields.projUserDetails.CAUserId,
                                strAction : "7#For Information",
                                strDate : ""
                            },{
                                strUser : $scope.oriMsgCustomFields.projUserDetails.PMUserId,
                                strAction : "7#For Information",
                                strDate : ""
                            },{
                                strUser : $scope.oriMsgCustomFields.projUserDetails.CMUserId,
                                strAction : "7#For Information",
                                strDate : ""
                            }],
                            autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
                            asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                            DS_AUTODISTRIBUTE : '3'
                        });                         
                        currFormStaus = "operations manager approved";
                    } else {
                        $scope.oriMsgCustomFields.workflowCurrentStage = "0";
                        userTodistribute = $scope.oriMsgCustomFields.projUserDetails.CAUserId;
                        currFormStaus = "operations manager rejected";
                    }
                    break;
            }

            // Distribution Will be made from here
            commonApi.setDistributionNode({
                actionNodeList : [{
                    strUser : userTodistribute,
                    strAction : "2#AssignStatus",
                    strDate : commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days : 3
                    })                    
                }],
                autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE : '3'
            });
            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
            });
			if (strFormStatusId) {             
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
        }

        function loadSubContratorData() {            
            $scope.SubContractersLatestData = [];
            var headers = $scope.TenderContractorsData.headerData.headerValues;
            var tmpSubContractor = headers.slice(2, $scope.TenderContractorsData.columnCount);
            var tmpSubContractorTenders = $scope.TenderContractorsData.SubTotal.slice(2, $scope.TenderContractorsData.columnCount);
            var tmpSubContractorAdjustments = $scope.TenderContractorsData.TenderTotalAdjustments.slice(2, $scope.TenderContractorsData.columnCount);
            $scope.TenderContractorsData.recid = 0;
            if ($scope.TenderContractorsData.RecommendedSubContractorName) {
                var index = 0;
                for (var j = 0; j < tmpSubContractor.length; j++) {
                    if (tmpSubContractor[j].modalValue == $scope.TenderContractorsData.RecommendedSubContractorName) {
                        index = j
                        break;
                    }
                }
                $scope.TenderContractorsData.recid = parseInt(index)+2; 
                var oldSubContObj = commonApi._.find($scope.oriMsgCustomFields.SubContractersLatestData , function(subConDataObj) {
                    return $scope.TenderContractorsData.RecommendedSubContractorName == subConDataObj.name && tmpSubContractor[j].id == subConDataObj.id;
                }) || {};                
                $scope.SubContractersLatestData.push({
                    name: $scope.TenderContractorsData.RecommendedSubContractorName,
                    id: tmpSubContractor[j].id,
                    tender: tmpSubContractorTenders[index],
                    adjustment: tmpSubContractorAdjustments[index],
                    finalTender: parseFloat(tmpSubContractorTenders[index]) + parseFloat(tmpSubContractorAdjustments[index]),
                    indigenous: oldSubContObj.indigenous || false,
                    estimate: oldSubContObj.estimate || false,
                    local: oldSubContObj.local || false
                });
            }
            for (var i = 0; i < tmpSubContractor.length; i++) {                
                if ($scope.TenderContractorsData.RecommendedSubContractorName != tmpSubContractor[i].modalValue) {
                    var modalValue = tmpSubContractor[i].modalValue.indexOf(',') != -1 ? tmpSubContractor[i].modalValue.split(',')[1] : tmpSubContractor[i].modalValue,
                        headerColumnId = tmpSubContractor[i].id,
                        oldSubContObj = commonApi._.find($scope.oriMsgCustomFields.SubContractersLatestData , function(subConDataObj) {
                            return modalValue && modalValue == subConDataObj.name && headerColumnId == subConDataObj.id;
                        }) || {}; 
                    if(modalValue) {
                        $scope.SubContractersLatestData.push({
                            name: modalValue,
                            id: tmpSubContractor[i].id,
                            tender: tmpSubContractorTenders[i],
                            adjustment: tmpSubContractorAdjustments[i],
                            finalTender: parseFloat(tmpSubContractorTenders[i]) + parseFloat(tmpSubContractorAdjustments[i]),
                            indigenous: oldSubContObj.indigenous || false,
                            estimate: oldSubContObj.estimate || false,
                            local: oldSubContObj.local || false                        
                        });
                    }
                }
            }
            $scope.oriMsgCustomFields.SubContractersLatestData = angular.copy($scope.SubContractersLatestData);           
        }

        var isCreateFlag = ISDRAFT.toLowerCase() == 'yes' ? true : false,
            isFwdCreateFlag = FDWMSGDRAFT.toLowerCase() == 'yes' ? true : false;
        if(currentViewName == 'ORI_VIEW' && FORMID != '' && $scope.oriMsgCustomFields.projUserDetails.isProjectDetailsAvail) {
            setUserRoleAccessFlag($scope.oriMsgCustomFields.projUserDetails, isCreateFlag, isFwdCreateFlag);
        }

        function setProjUserDetail() {
            if (userDetailsData.length) {
                $scope.oriMsgCustomFields.projUserDetails.PMUserId = userDetailsData[0].Value16;
                $scope.oriMsgCustomFields.projUserDetails.PMUserName = userDetailsData[0].Value17;
                $scope.oriMsgCustomFields.projUserDetails.CMUserId = userDetailsData[0].Value18;
                $scope.oriMsgCustomFields.projUserDetails.CMUserName = userDetailsData[0].Value19;
                $scope.oriMsgCustomFields.projUserDetails.GMUserId = userDetailsData[0].Value20;
                $scope.oriMsgCustomFields.projUserDetails.GMUserName = userDetailsData[0].Value21;
            }
        }

        $scope.update();
        $scope.isCallForDraft = false;
        $window.compFinalCallBack = function () {
            if(!$scope.isCallForDraft && $scope.oriMsgCustomFields.DSI_Hide_Show != '1') {
                $window.alert( "You currently do not have 'Assign Status' action and therefore you can not edit the form." );
                return true;
            } else if($scope.oriMsgCustomFields.DSI_Hide_Show == '1') {
                loadSubContratorData();
                !$scope.isCallForDraft && setFormWorkflow();
            }
            return false;
        }

        $window.compDraftCallBack = function () {            
            $scope.isCallForDraft = true;
            $window.compFinalCallBack();
        }

    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof compFinalCallBack !== "undefined") {
        return compFinalCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof compDraftCallBack !== "undefined") {
		return compDraftCallBack();
	}
}
