/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = $window.currentViewName;

        /**
         * Stop Autosave draft in ORI_VIEW
         */
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo White"
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                }, 500);
            }
        });


        // Define JSON fields
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.projectSnapshot = $scope.oriMsgCustomFields["Project_Snapshot"];

        // define SP fields
        var dsAsiGetProjectList = $scope.getValueOfOnLoadData('DS_ASI_GET_Project_List');
        var dsAsiGetBudgetFormValue = $scope.getValueOfOnLoadData('DS_ASI_GET_BUDGET_FORM_VALUE');

        if (currentViewName == "ORI_VIEW") {
            loadClientLogo();
            initFormData();
        } else {
            initPrintViewData();
        }

        if (currentViewName == "ORI_PRINT_VIEW") {
            /**
             * Freeze pane in print view
             * attach on scroll event for table to freeze columns
             *  */ 
            loadClientLogo();
            $scope.hideExportBtn();
            $timeout(function () {
                var objDivWrapper = $element.find('.freeze-container');
                var objHeaderTR = $element.find('.div-header')
                $scope.update();
                objDivWrapper.bind('scroll', function (event) {
                    var objFixTds = $element.find('.freezeTd');
                    objFixTds.css('left', (event.target.scrollLeft) + "px");
                    objHeaderTR.css('top', (event.target.scrollTop) + "px");
                });

            }, 200);
        } else {
            $scope.update();
        }

        /**
         * Set ORI_FORMTITLE and DS_FORMCONTENT1 on project selection in ORI_VIEW
         */
        $scope.setFormTitle = function () {
            var projCode = $scope.projectSnapshot.Project_Code;
            var allData = commonApi._.filter(dsAsiGetProjectList, function (objData) {
                return projCode == objData.Value2;
            })[0];

            if (allData) {
                $scope.data["myFields"]['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'] = allData.Value3;
                $scope.projectSnapshot.Project_Name = allData.Value3;
                $scope.data["myFields"]['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = allData.Value1;
            }
        }


        /**
         * Load clients logo from Configurable Attributes
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo() {
            var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
            var logoUrl = "";
            var index = 0;
            var element;
            for (; index < dsAsiConfigurableAttributes.length; index++) {
                element = dsAsiConfigurableAttributes[index];

                if (element.Value3 === TFL_CONSTANT.confAttrClientLogo) {
                    logoUrl = element.Value8;
                }
            }
            $scope.oriMsgCustomFields['Logo'] = logoUrl || TFL_CONSTANT.defaultLogo;
        }


        /**
         * Initialize all form data on load
         */
        function initFormData() {

            // To fill project list dropdown
            $scope.arrProjList = commonApi.getItemSelectionList({
                arrayObject: dsAsiGetProjectList,
                groupNameKey: "",
                modelKey: "Value2",
                displayKey: "Value3"
            })
        }

        function initPrintViewData() {

            // Define static object which used to bind data in Printview
            var STATIC_ROW_OBJ = {
                ApprovedVariations: 0,
                UnapprovedVariations: 0,
                OriginalBudget: 0,
                Package_Id: "",
                PackageName: "",
                BudgetModifiPending: 0,
                BudgetModifiApproved: 0,
                budgetTransPending: 0,
                budgetTransApproved: 0,
                currentTotalBudget: 0,
                anticipatedTotal: 0,
                requisitionsPending: 0,
                poApproved: 0,
                antiCipatedChangeOrderPending: 0,
                pendChangeOrderPending: 0,
                pendChangeOrderApproved: 0,
                changeOrderApproved: 0,
                riskAmount: 0,
                pendingCommitments: 0,
                approvedCommitments: 0,
                totalCommitedToDate: 0,
                availableToCommit: 0,
                estimateToComplete: 0,
                internalCosts: 0,
                miscCosts: 0,
                invoices: 0,
                spendsToDate: 0,
                openEncumbraces: 0,
                anticipatedFinalCost: 0,
                variance: 0
            };

            var totalObj = {
                OriginalBudgetTotal:0,
                BudgetModifiPendingTotal:0,
                BudgetModifiApprovedTotal:0,
                budgetTransPendingTotal:0,
                budgetTransApprovedTotal:0,
                riskAmountTotal:0,
                antiCipatedChangeOrderPendingTotal:0,
                poApprovedTotal:0,
                requisitionsPendingTotal:0,
                pendChangeOrderApprovedTotal:0,
                changeOrderApprovedTotal:0,
                pendChangeOrderPendingTotal:0,
                miscCostsTotal:0,
                invoicesTotal:0,
                currentTotalBudgetTotal:0,
                anticipatedTotal:0,
                pendingCommitmentsTotal:0,
                approvedCommitmentsTotal:0,
                totalCommitedToDateTotal:0,
                availableToCommitTotal:0,
                estimateToCompleteTotal:0,
                spendsToDateTotal:0,
                openEncumbracesTotal:0,
                anticipatedFinalCostTotal:0,
                varianceTotal:0
            };

            $scope.printTable = [];
            $scope.totalTable = [];

            // Merge Contract Package Data
            for (var i = 0; i < dsAsiGetBudgetFormValue.length; i++) {
                var budgetObj = dsAsiGetBudgetFormValue[i];
                var tempObj = angular.copy(STATIC_ROW_OBJ);

                tempObj.OriginalBudget = parseFloat(budgetObj.Value4) || 0;
                totalObj.OriginalBudgetTotal = totalObj.OriginalBudgetTotal + tempObj.OriginalBudget;

                tempObj.BudgetModifiPending = parseFloat(budgetObj.Value5) || 0;
                totalObj.BudgetModifiPendingTotal = totalObj.BudgetModifiPendingTotal + tempObj.BudgetModifiPending;

                tempObj.BudgetModifiApproved = parseFloat(budgetObj.Value6) || 0;
                totalObj.BudgetModifiApprovedTotal = totalObj.BudgetModifiApprovedTotal + tempObj.BudgetModifiApproved;

                tempObj.budgetTransPending = parseFloat(budgetObj.Value7) || 0;
                totalObj.budgetTransPendingTotal = totalObj.budgetTransPendingTotal + tempObj.budgetTransPending;

                tempObj.budgetTransApproved = parseFloat(budgetObj.Value8) || 0;
                totalObj.budgetTransApprovedTotal = totalObj.budgetTransApprovedTotal + tempObj.budgetTransApproved;

                tempObj.riskAmount = parseFloat(budgetObj.Value9) || 0;
                totalObj.riskAmountTotal = totalObj.riskAmountTotal + tempObj.riskAmount;

                tempObj.antiCipatedChangeOrderPending = parseFloat(budgetObj.Value10) || 0;
                totalObj.antiCipatedChangeOrderPendingTotal = totalObj.antiCipatedChangeOrderPendingTotal + tempObj.antiCipatedChangeOrderPending;

                tempObj.poApproved = parseFloat(budgetObj.Value11) || 0;
                totalObj.poApprovedTotal = totalObj.poApprovedTotal + tempObj.poApproved;

                tempObj.requisitionsPending = parseFloat(budgetObj.Value12) || 0;
                totalObj.requisitionsPendingTotal = totalObj.requisitionsPendingTotal + tempObj.requisitionsPending;
                
                tempObj.pendChangeOrderApproved = parseFloat(budgetObj.Value13) || 0;
                totalObj.pendChangeOrderApprovedTotal = totalObj.pendChangeOrderApprovedTotal + tempObj.pendChangeOrderApproved;

                tempObj.changeOrderApproved = parseFloat(budgetObj.Value14) || 0;
                totalObj.changeOrderApprovedTotal = totalObj.changeOrderApprovedTotal + tempObj.changeOrderApproved;

                tempObj.pendChangeOrderPending = parseFloat(budgetObj.Value15) || 0;
                totalObj.pendChangeOrderPendingTotal = totalObj.pendChangeOrderPendingTotal + tempObj.pendChangeOrderPending;
                
                tempObj.miscCosts = parseFloat(budgetObj.Value16) || 0;
                totalObj.miscCostsTotal = totalObj.miscCostsTotal + tempObj.miscCosts;

                tempObj.invoices = parseFloat(budgetObj.Value17) || 0;
                totalObj.invoicesTotal = totalObj.invoicesTotal + tempObj.invoices;

                tempObj.Package_Id = budgetObj.Value3 || "";
                tempObj.PackageName = budgetObj.Value18 || "";

                tempObj.currentTotalBudget = ( tempObj.OriginalBudget + tempObj.BudgetModifiApproved + tempObj.budgetTransApproved) || 0;
                totalObj.currentTotalBudgetTotal = totalObj.currentTotalBudgetTotal + tempObj.currentTotalBudget;

                tempObj.anticipatedTotal = ( tempObj.OriginalBudget + tempObj.BudgetModifiPending + tempObj.BudgetModifiApproved + tempObj.budgetTransPending + tempObj.budgetTransApproved) || 0;
                totalObj.anticipatedTotal = totalObj.anticipatedTotal + tempObj.anticipatedTotal;

                tempObj.pendingCommitments = ( tempObj.requisitionsPending + tempObj.antiCipatedChangeOrderPending + tempObj.pendChangeOrderPending + tempObj.riskAmount) || 0;
                totalObj.pendingCommitmentsTotal = totalObj.pendingCommitmentsTotal + tempObj.pendingCommitments;

                tempObj.approvedCommitments = ( tempObj.poApproved + tempObj.pendChangeOrderApproved + tempObj.changeOrderApproved) || 0;

                totalObj.approvedCommitmentsTotal = totalObj.approvedCommitmentsTotal + tempObj.approvedCommitments;

                tempObj.totalCommitedToDate = ( tempObj.approvedCommitments + tempObj.pendingCommitments ) || 0;
                totalObj.totalCommitedToDateTotal = totalObj.totalCommitedToDateTotal + tempObj.totalCommitedToDate;

                tempObj.availableToCommit = ( tempObj.currentTotalBudget - tempObj.totalCommitedToDate ) || 0;
                totalObj.availableToCommitTotal = totalObj.availableToCommitTotal + tempObj.availableToCommit;

                tempObj.estimateToComplete = ( tempObj.requisitionsPending + tempObj.antiCipatedChangeOrderPending + tempObj.pendChangeOrderApproved + tempObj.riskAmount ) || 0;
                totalObj.estimateToCompleteTotal = totalObj.estimateToCompleteTotal + tempObj.estimateToComplete;

                tempObj.spendsToDate = ( tempObj.internalCosts + tempObj.miscCosts + tempObj.invoices ) || 0;
                totalObj.spendsToDateTotal = totalObj.spendsToDateTotal + tempObj.spendsToDate;

                tempObj.openEncumbraces = ( tempObj.totalCommitedToDate - tempObj.spendsToDate ) || 0;
                totalObj.openEncumbracesTotal = totalObj.openEncumbracesTotal + tempObj.openEncumbraces;

                tempObj.anticipatedFinalCost = ( tempObj.totalCommitedToDate + tempObj.estimateToComplete ) || 0;
                totalObj.anticipatedFinalCostTotal = totalObj.anticipatedFinalCostTotal + tempObj.anticipatedFinalCost;

                tempObj.variance = ( tempObj.currentTotalBudget - tempObj.anticipatedFinalCost ) || 0;
                totalObj.varianceTotal = totalObj.varianceTotal + tempObj.variance;

                $scope.printTable.push(tempObj);
            }
            $scope.totalTable = angular.copy(totalObj);
        }
    };
    return FormController;
});