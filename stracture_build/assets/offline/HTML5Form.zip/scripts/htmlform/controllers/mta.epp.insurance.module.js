/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/inlineattachment'], function (angular, mainModule, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $controller, $window, $timeout, commonApi, Notification, myConfig, $filter) {

        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });
        
        var tempData = $scope.getFormData();
        if (!tempData.myFields) {
            $scope.data = {
                myFields: tempData
            };
        } else {
            $scope.data = tempData;
        }

        var STATIC_OBJ = {
            Contracts: {
                DOB_ContractNo: "",
                Contractcost: "",
                EstStrDate: "",
                EstEndDate: "",
                ShortDescription: "",
                ContractorName: "",
                TypeofWork: "",
                MailAddress: "",
                MangerPhNo: "",
                MangerEmail: "",
                OldNewFlag: "",
                DateCheckFlag: "",
                isDataLoaded: "",
                xhr: "",
                isDobFilled: false 
            },
            SignedAgreement: {
                attachedDocs: ""
            },
            AdditionalAttachDoc: {
                attachedDocs: ""
            },
            PolicyAttachDoc: {
                attachedDocs: ""
            },
            PrimaryAttachDoc: {
                attachedDocs: ""
            },
            EndorsementAttachDoc: {
                attachedDocs: ""
            },
            PnEndorAttachDoc: {
                attachedDocs: ""
            },
            SubmissionAttachDoc: {
                attachedDocs: ""
            },
            AddDocumentAttachDoc: {
                attachedDocs: "",
            },
        };

        var INS_CONSTANT = {
            underReview: "Under Review"
        }

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.Insurance = $scope.oriMsgCustomFields.Insurance;
        $scope.ContractInfo = $scope.oriMsgCustomFields.ContractInfo;
        $scope.Contracts = $scope.ContractInfo.Contracts;
        $scope.DS_MTA_EPP_DetailsBasedOncontractDOBNo = $scope.getValueOfOnLoadData('DS_MTA_EPP_DetailsBasedOncontractDOBNo');
        var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT.toLowerCase();
        var DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        loadConfig();

        $scope.setCurrentSection = function (tabURL) {
            $scope.currentOriTab = tabURL;
            $timeout(function () {
                $scope.expandTextAreaOnLoad();
            });
        };
        if (currentViewName == 'ORI_PRINT_VIEW') {
            //to Hide Export Button in print view
            $scope.hideExportBtn();
        }
        $scope.isValidUser = false;
        $scope.isValidUserforEppAdmin = false;
        if (strFormId != "" && strIsDraft == "no" && DS_WORKINGUSER_ALL_ROLES.length) {
            if ((currentViewName == 'ORI_VIEW') && DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf('epp insurance admin') > -1) {
                $scope.isValidUserforEppAdmin = true;
            }
            if ((currentViewName == 'ORI_PRINT_VIEW') && (DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf('epp insurance admin') > -1 || DS_WORKINGUSER_ALL_ROLES[0].Value.toLowerCase().indexOf('epp insurance review team') > -1)) {
                $scope.isValidUser = true;
            }
        }
        if (currentViewName == 'ORI_VIEW') {
            var DS_WORKINGUSER_WITHOUT_ROLE = $scope.getValueOfOnLoadData('DS_WORKINGUSER_WITHOUT_ROLE')[0];
            $scope.currentOriTab = 'Insurance.html';
            if(!$scope.isValidUserforEppAdmin){
                $scope.oriMsgCustomFields.workingUser = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value1.split('|')[0].trim();
                $scope.oriMsgCustomFields.workingUserEmailId = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value4;
                $scope.oriMsgCustomFields.workingUserName = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value5;
            }
            //EditORI : Comapre Today Date with Insurance Expired Date and disable field based on condition.
            if (strFormId != "" && strIsDraft == "no") {
                var contractDOBTable = $scope.Contracts.length;
                for (var i = 0; i < contractDOBTable; i++) {
                    $scope.ContractInfo["Contracts"][i].OldNewFlag = "Old";
                    if ($scope.ContractInfo["Contracts"][i].DOB_ContractNo != '') {
                        $scope.ContractInfo["Contracts"][i].isDobFilled = true;
                    }
                }
                if (!$scope.isValidUserforEppAdmin) {
                    getCheckInsuranceisExpired();
                }
            }

            /**
            * Fn is used to check whether any Insurance Date is expired in section 2 & section 3.
            */
            function getCheckInsuranceisExpired() {
                $scope.btndisabled = false;
                var todayDate = getDateFromZone(),
                    expiredDate = $scope.Insurance.RRPL_Insurance_Expiration_Date,
                    commDate = $scope.Insurance.Accord_Commercial_Expiration_Date,
                    autoDate = $scope.Insurance.Accord_Automobile_Expiration_Date,
                    umbrellaDate = $scope.Insurance.Accord_Umbrella_Expiration_Date,
                    workerDate = $scope.Insurance.Accord_Workers_Expiration_Date,
                    contractDOBTable = $scope.Contracts.length;

                if (commDate) {
                    if (todayDate > commDate) {
                        for (var i = 0; i < contractDOBTable; i++) {
                            $scope.ContractInfo["Contracts"][i].DateCheckFlag = 'Modified';
                            $scope.btndisabled = true;
                        }
                        if ($scope.btndisabled) {
                            Notification.error({
                                delay: 8000,
                                title: 'Your Insurance is Expired.',
                                message: 'Please update your Insurance details if you want to Add New Contract Information.'
                            });
                        }
                        return false;
                    }
                }
                if (autoDate) {
                    if (todayDate > autoDate) {
                        for (var i = 0; i < contractDOBTable; i++) {
                            $scope.ContractInfo["Contracts"][i].DateCheckFlag = 'Modified';
                            $scope.btndisabled = true;
                        }
                        if ($scope.btndisabled) {
                            Notification.error({
                                delay: 8000,
                                title: 'Your Insurance is Expired.',
                                message: 'Please update your Insurance details if you want to Add New Contract Information.'
                            });
                        }
                        return false;
                    }
                }
                if (umbrellaDate) {
                    if (todayDate > umbrellaDate) {
                        for (var i = 0; i < contractDOBTable; i++) {
                            $scope.ContractInfo["Contracts"][i].DateCheckFlag = 'Modified';
                            $scope.btndisabled = true;
                        }
                        if ($scope.btndisabled) {
                            Notification.error({
                                delay: 8000,
                                title: 'Your Insurance is Expired.',
                                message: 'Please update your Insurance details if you want to Add New Contract Information.'
                            });
                        }
                        return false;
                    }
                }
                if (workerDate) {
                    if (todayDate > workerDate) {
                        for (var i = 0; i < contractDOBTable; i++) {
                            $scope.ContractInfo["Contracts"][i].DateCheckFlag = 'Modified';
                            $scope.btndisabled = true;
                        }
                        if ($scope.btndisabled) {
                            Notification.error({
                                delay: 8000,
                                title: 'Your Insurance is Expired.',
                                message: 'Please update your Insurance details if you want to Add New Contract Information.'
                            });
                        }
                        return false;
                    }
                }
                if (expiredDate) {
                    if (todayDate > expiredDate) {
                        for (var i = 0; i < contractDOBTable; i++) {
                            $scope.ContractInfo["Contracts"][i].DateCheckFlag = 'Modified';
                            $scope.btndisabled = true;
                        }
                        if ($scope.btndisabled) {
                            Notification.error({
                                delay: 8000,
                                title: 'Your Insurance is Expired.',
                                message: 'Please update your Insurance details if you want to Add New Contract Information.'
                            });
                        }
                        return false;
                    }
                }
                if (todayDate <= expiredDate || todayDate <= commDate || todayDate <= autoDate || todayDate <= umbrellaDate || todayDate <= workerDate) {
                    for (var i = 0; i < contractDOBTable; i++) {
                        $scope.ContractInfo["Contracts"][i].DateCheckFlag = '';
                    }
                }
                return true;
            }

            /**
            * Remove Attachmnet when Checkbox value is Empty.
            * @param {Array} recordItem : Array of Insurance.
            */
            $scope.onRemoveAttachChkBoxCLick = function (recordItem) {
                if ($scope.Insurance.isAccordChecked == 'No') {
                    var additionalAttachDoc = commonApi._.filter(recordItem.AdditionalAttachDoc, function (attachment) {
                        return attachment.attachedDocs;
                    });
                    recordItem.AdditionalAttachDoc = additionalAttachDoc;
                    if (recordItem.AdditionalAttachDoc) {
                        recordItem.AdditionalAttachDoc = [{
                            "attachedDocs": ""
                        }];
                    }
                }
                if ($scope.Insurance.isPolicyChecked == 'No') {
                    var policyAttachDoc = commonApi._.filter(recordItem.PolicyAttachDoc, function (attachment) {
                        return attachment.attachedDocs;
                    });
                    recordItem.PolicyAttachDoc = policyAttachDoc;
                    if (recordItem.PolicyAttachDoc) {
                        recordItem.PolicyAttachDoc = [{
                            "attachedDocs": ""
                        }];
                    }
                }
            };

            $scope.addNewItem = function (repeatingData, addItemFor) {
                var newRowObject = angular.copy(STATIC_OBJ[addItemFor]);
                repeatingData.push(newRowObject);
            };

            $scope.removeItem = function (nodeObj, list) {
                var index = list.indexOf(nodeObj);
                list.splice(index, 1);
            };

            // date comparison with other date logic 
            $scope.dateChangeEvent = function (paramObj) {
                if (paramObj.node[paramObj.compareDate1] && paramObj.node[paramObj.compareDate2]) {
                    var date1 = new Date(paramObj.node[paramObj.compareDate1]),
                        date2 = new Date(paramObj.node[paramObj.compareDate2]);

                    if (paramObj.comparionMethod == 'greater' && date1 >= date2) {
                        Notification.error({
                            title: 'Validation Error',
                            message: paramObj.fieldName2 + ' should be smaller than ' + paramObj.fieldName1
                        });
                        paramObj.node[paramObj.compareDate1] = '';
                    } else if (paramObj.comparionMethod == 'less' && date1 <= date2) {
                        Notification.error({
                            title: 'Validation Error',
                            message: paramObj.fieldName1 + ' should be greater than ' + paramObj.fieldName2
                        });
                        paramObj.node[paramObj.compareDate1] = '';
                    }
                }
            };
        }
        
        /**
         * Validate E-mail on ng-blurm.
         * @param {Array} nodeObj : Array of Insurance,
         * @param {String} inputText : input text field of Insurance section,
         * @param {key} nodeKey : key of Insurance section field.
         */
         $scope.ValidateEmail = function(nodeObj,inputText,nodeKey){
            var mailformat = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
            if (inputText) {
                if (inputText.match(mailformat))
                    return true;
                else {
                    alert("Invalid Email address");
                    nodeObj[nodeKey] = '';
                    return false;
                }
            } else {
                return false;
            }
        }

        /**
         * To Avoid Duplication of DOB/Contarct No in Same Form.
         * @param {Array} currObj : Array of Contract,
         * @param {Array} repeatingObj : Repeating Array of Contract,
         * @param {Number} $index : current Index of Array.
         */
        $scope.onCheckDobContractNo = function (currObj, repeatingObj, $index) {
            $scope.isConValid = true;
            for (var i = 0; i < repeatingObj.length; i++) {
                if (currObj.DOB_ContractNo && i != $index &&
                    repeatingObj[i].DOB_ContractNo == currObj.DOB_ContractNo) {
                    alert("This DOB/Contract Number is already available in the same Form.Please Type another DOB/Contract Number");
                    currObj.DOB_ContractNo = "";
                    $scope.isConValid = false;
                }
            }
        }

        $scope.onDobContractNoChange = function (strVal, obj) {
            if (strVal && $scope.isConValid) {
                getDobContractNumberData(strVal, obj);
            }
        }

        /**
         * Callback event When user enter Dob/Contract Number.
         * @param {String} strVal : Dob/Contract Number,
         * @param {Array} obj : Array of Contract.
         */
        function getDobContractNumberData(strVal, obj) {

            if (strVal) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_MTA_EPP_DetailsBasedOncontractDOBNo",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_EPP_DetailsBasedOncontractDOBNo",
                            "fieldValue": strVal
                        }]
                    }
                };
                obj.isDataLoaded = false;
                obj.xhr = true;
                $scope.disableSaveActions(true);
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var dataObj = angular.fromJson(response.data['DS_MTA_EPP_DetailsBasedOncontractDOBNo']).Items.Item;
                        if (dataObj[0].Value29 == "1") {
                            alert("This DOB/Contract Number is already available Please Type another DOB/Contract Number");
                            obj.DOB_ContractNo = '';
                        } else if (dataObj[0].Value30 == "0") {
                            alert("This DOB/Contract Number is not available Please Type another DOB/Contract Number");
                            obj.DOB_ContractNo = '';
                        } else if (dataObj.length) {
                            obj.BoroughType = dataObj[0].Value11;
                            obj.HouseNummber = dataObj[0].Value12;
                            obj.OtherType = dataObj[0].Value13;
                            obj.StreetName = dataObj[0].Value14;
                            obj.Block = dataObj[0].Value15;
                            obj.Lot = dataObj[0].Value16;
                            obj.ZipCode = dataObj[0].Value17;
                            obj.StreetIntersection = dataObj[0].Value18;
                            obj.StationName = dataObj[0].Value19;
                            obj.TransitType = dataObj[0].Value20;
                            obj.LineName = dataObj[0].Value21;
                            obj.ApproxDistance = dataObj[0].Value22;
                            obj.TypeofWork = dataObj[0].Value9;
                            obj.isDataLoaded = true;
                        }
                    }
                    obj.xhr = false;
                    $scope.disableSaveActions(false);
                });
            }
        }

        /**
         * this function checks weather input value is number otherwise blank it.
         *  @argument {Array} currObj : Array of contract fields.
		 *  @argument {String} inputValue : value of input field.
		 *  @argument {String} key : key which contains input.
         */
        $scope.checkValueNumber = function (currObj, inputValue, key) {
            if (inputValue && isNaN(inputValue)) {
                alert('Validation\n\nOnly numeric value expected.');
                currObj[key] = "";
            }
        }

        /**
         * Return today's date from time zone of US.
         */
        function getDateFromZone() {
            var offset = 0;
            Date.prototype.stdTimezoneOffset = function () {
                var jan = new Date(this.getFullYear(), 0, 1);
                var jul = new Date(this.getFullYear(), 6, 1);
                return Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
            }

            Date.prototype.isDstObserved = function () {
                return this.getTimezoneOffset() < this.stdTimezoneOffset();
            }

            var today = new Date();
            if (today.isDstObserved()) {
                offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            } else {
                offset = $window.USP.localeVO._timezone.rawOffset;
            }
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }

        /**
        * Remove Empty Attachmnet at send button in All section.
        */
        function removeEmptyAttachments() {
            var filtered = commonApi._.filter($scope.oriMsgCustomFields.Insurance.AddDocumentAttachDoc, function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance.AddDocumentAttachDoc = filtered;

            var section1Attachment = commonApi._.filter($scope.oriMsgCustomFields.Insurance['SignedAgreement'], function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance['SignedAgreement'] = section1Attachment;

            var section4Attachment = commonApi._.filter($scope.oriMsgCustomFields.Insurance['PrimaryAttachDoc'], function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance['PrimaryAttachDoc'] = section4Attachment;

            var section5Attachment = commonApi._.filter($scope.oriMsgCustomFields.Insurance['EndorsementAttachDoc'], function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance['EndorsementAttachDoc'] = section5Attachment;

            var section6Attachment = commonApi._.filter($scope.oriMsgCustomFields.Insurance['PnEndorAttachDoc'], function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance['PnEndorAttachDoc'] = section6Attachment;

            var section7Attachment = commonApi._.filter($scope.oriMsgCustomFields.Insurance['SubmissionAttachDoc'], function (attachment) {
                return attachment.attachedDocs;
            });
            $scope.oriMsgCustomFields.Insurance['SubmissionAttachDoc'] = section7Attachment;
        }

        /** 
        * Check at least one option selected for all the Questions , at least one file upload and date is selected in form.
        */
        $scope.checkBtnField = function () {
            var isSection1doc = false,
                issection2doc = false,
                issection3doc = false,
                issection4doc = false,
                issection5doc = false,
                issection6doc = false,
                issection7doc = false;
            if (!$scope.Insurance.AccordSelection || !$scope.Insurance.LimitSelection || !$scope.Insurance.NAICSelection || !$scope.Insurance.CertificateSelection || !$scope.Insurance.AdditionalSelection
                || !$scope.Insurance.WaiverSelection || !$scope.Insurance.InsuredSelection || !$scope.Insurance.PrimarySelection || !$scope.Insurance.EndorsementSelection || !$scope.Insurance.ListedSelection
                || !$scope.Insurance.PnEndorSelection) {
                Notification.error({
                    delay: 8000,
                    title: 'One button must be selected.',
                    message: 'Please Select At least One Option Yes/No for the following Questions.'
                });
                $scope.setCurrentSection('Insurance.html');
                $window.parent.postMessage("scrollToTop", '*');
                return false;
            }
            for (var i = 0; i < $scope.Insurance['SignedAgreement'].length; i++) {
                if ($scope.Insurance['SignedAgreement'][i].attachedDocs != '') {
                    isSection1doc = true;
                }
            }
            for (var i = 0; i < $scope.Insurance['PrimaryAttachDoc'].length; i++) {
                if ($scope.Insurance['PrimaryAttachDoc'][i].attachedDocs != '') {
                    issection4doc = true;
                }
            }
            for (var i = 0; i < $scope.Insurance['EndorsementAttachDoc'].length; i++) {
                if ($scope.Insurance['EndorsementAttachDoc'][i].attachedDocs != '') {
                    issection5doc = true;
                }
            }
            for (var i = 0; i < $scope.Insurance['PnEndorAttachDoc'].length; i++) {
                if ($scope.Insurance['PnEndorAttachDoc'][i].attachedDocs != '') {
                    issection6doc = true;
                }
            }
            for (var i = 0; i < $scope.Insurance['SubmissionAttachDoc'].length; i++) {
                if ($scope.Insurance['SubmissionAttachDoc'][i].attachedDocs != '') {
                    issection7doc = true;
                }
            }
            if ($scope.Insurance.AccordForm['attachedDocs'] != '' && $scope.Insurance.AccordForm['attachedDocs'].length != 0) {
                issection2doc = true;
            }
            if ($scope.Insurance.WaiverSelection == 'No' && $scope.Insurance.RRPLBinder['attachedDocs'] != '' && $scope.Insurance.RRPLBinder['attachedDocs'].length != 0) {
                issection3doc = true;
            }
            if ($scope.Insurance.WaiverSelection == 'Yes') {
                issection3doc = true;
            }
            if (isSection1doc == false || issection2doc == false || issection3doc == false || issection4doc == false || issection5doc == false || issection6doc == false || issection7doc == false) {
                Notification.error({
                    delay: 8000,
                    title: 'File attachment required.',
                    message: 'Please Attach At least One File in All Section.'
                });
                $scope.setCurrentSection('Insurance.html');
                $window.parent.postMessage("scrollToTop", '*');
                return false;
            }
            if ($scope.Insurance.Accord_Commercial_Expiration_Date == '' && $scope.Insurance.Accord_Automobile_Expiration_Date == '' && 
                $scope.Insurance.Accord_Umbrella_Expiration_Date == '' && $scope.Insurance.Accord_Workers_Expiration_Date == '') {
                    Notification.error({
                        delay: 8000,
                        title: 'Date is required.',
                        message: 'Please Select At least One Date in Section 2.Accord 25 Form.'
                    });
                    $scope.setCurrentSection('Insurance.html');
                    $window.parent.postMessage("scrollToTop", '*');
                    return false;
            }
            if ($scope.Insurance.WaiverSelection == 'No' && $scope.Insurance.RRPL_Insurance_Expiration_Date == '') {
                Notification.error({
                    delay: 8000,
                    title: 'Date is required.',
                    message: 'Please Select Date in Section 3.RRPL Binder/Policy Including Named Insured Endorsement.'
                });
                $scope.setCurrentSection('Insurance.html');
                $window.parent.postMessage("scrollToTop", '*');
                return false;
            }
            if ($scope.Insurance.ProjectAddress == '' || $scope.Insurance.ProjectDescription == '' || $scope.Insurance.CompanyName == ''
                || $scope.Insurance.CompanyBillAddress == '' || $scope.Insurance.AgreementPersonName == '' || $scope.Insurance.AgreementPersonTitle == ''
                || $scope.Insurance.AgreementPersonEmail == '' || $scope.Insurance.AgreementPersonPhone == '' || $scope.Insurance.ContactPersonName == ''
                || $scope.Insurance.ContactPersonTitle == '' || $scope.Insurance.ContactPersonEmail == '' || $scope.Insurance.ContactPersonPhone == '') {
                Notification.error({
                    delay: 8000,
                    title: 'Validation Error.',
                    message: 'Please fill up mandatory textbox field.'
                });
                $scope.setCurrentSection('Insurance.html');
                $window.parent.postMessage("scrollToTop", '*');
                return false;
            }
            return true;
        };

        /** 
        * To Check All mandatory details are filled in Contract-Information Tab.
        */
        function checkMandatoryFields() {
            var ContractData = $scope.oriMsgCustomFields["ContractInfo"]["Contracts"];
            if (currentViewName == "ORI_VIEW") {
                if (ContractData.length) {
                    $scope.setCurrentSection('Contractor.html');
                    for (var i = 0; i < ContractData.length; i++) {
                        if (ContractData[i].Contractcost == '' || ContractData[i].ContractorName == ''
                            || ContractData[i].EstStrDate == '' || ContractData[i].EstEndDate == '' || ContractData[i].ShortDescription == ''
                            || ContractData[i].MailAddress == '' || ContractData[i].MangerPhNo == '' || ContractData[i].MangerEmail == '') {
                            Notification.error({
                                delay: 8000,
                                title: 'Contracts details are missing.',
                                message: 'At least one Contract information must be filled before submit application.'
                            });
                            $window.parent.postMessage("scrollToTop", '*');
                            return false;
                        }
                    }
                } else {
                    $scope.setCurrentSection('Contractor.html');
                    Notification.error({
                        delay: 8000,
                        title: 'Contracts details are missing.',
                        message: 'At least one Contract information must be filled before submit application.'
                    });
                    $window.parent.postMessage("scrollToTop", '*');
                    return false;
                }
            }
            return true;
        }

        /** 
         * App Workflow.
         */
        function setFormWorkflow() {
            if (formId != "" && !$scope.isValidUserforEppAdmin) {
                $scope.oriMsgCustomFields.workingUserOrg = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value2.substr(DS_WORKINGUSER_WITHOUT_ROLE.Value2.indexOf(',') + 1).trim();
                $scope.oriMsgCustomFields.ORI_FORMTITLE = "Insurance submitted by " + $scope.oriMsgCustomFields.workingUserOrg;
                setFormStatus(INS_CONSTANT.underReview);
            }
        }
 
        function setFormContent() {
            // Form's DS_FORMCONTENT  will be set from below code.
            var strFormContent = "";
            var userName = $scope.oriMsgCustomFields.workingUserName;
            var userOrg = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value2.substr(DS_WORKINGUSER_WITHOUT_ROLE.Value2.indexOf(',') + 1).trim();
            strFormContent = userName + ', ' + userOrg;
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent;
        }
        function setFormStatus(currFormStaus) {
            // Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: availFormStatuses,
                strStatus: currFormStaus
            });

            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        $scope.update();

        $window.oriformSubmitCallBack = function () {
            removeEmptyAttachments();
            if ($scope.checkBtnField() && checkMandatoryFields()) {
                setFormWorkflow();
                if(!$scope.isValidUserforEppAdmin && strFormId == ""){
                    setFormContent();
                }
                return false;
            }
            return true;
        };
        function getParameterByName(name, urlstr) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(urlstr);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        };
        function loadConfig() {
            var had;
            if (window.location.href.indexOf("had") != -1) {
                had = getParameterByName('had', window.location.href)
            }
            if (((had && had.split("$$")[0] == 1) || myConfig.bfpc) && !angular.element("input[id=bfpc]").length) {
                var bfpc_val = getParameterByName('bfpc', window.location.href) || myConfig.bfpc;
                var bfpc = document.createElement('input');
                bfpc.type = "hidden";
                bfpc.name = "bfpc";
                bfpc.id = "bfpc";
                bfpc.value = bfpc_val;
                angular.element(document.myform).append(bfpc);
            }   
            
            commonApi.ajax({
                url: ($window.adoddleBaseUrl || "") + "/commonapi/form/getConfigJson",
                method: 'POST',
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: "projectId=" + projectId + "&appBuilderId=" + $window.AppBuilderFormIDCode
            }).then(function (response) {
                if(response && response.data){
                    var boroughData = response.data['Borough'] || {};
                    $scope.boroughTypeList = commonApi.getItemSelectionList({
                        arrayObject: boroughData,
                        groupNameKey: "",
                        modelKey: "BoroughDataList",
                        displayKey: "BoroughDataList"
                    });
                }
                if (response && response.data && response.data.Project && response.data.Project[0].ProjectName) {
                    var projectName = response.data.Project[0].ProjectName;
                    if (myConfig.editORI != "true"){
                        getprojectDetails(projectName);
                    }
                }
            });
        };
        function getprojectDetails(projectName) {
            var appBuilderId = angular.element("input[name='appBuilderId']").val();
            var formId = angular.element("input[name='formId']").val();
            var msgId = angular.element("input[name='msgId']").val();

            commonApi.ajax({
                url: (window.baseUrl || "") + '/commonapi/form/getFormTypeDetailsByProjectNameAndAppBuilderID',
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                withCredentials: true,
                data: "projectName=" + projectName +
                    "&appBuilderId=" + appBuilderId +
                    "&formId=" + formId +
                    "&msgId=" + msgId
            }).then(function (response) {
                replaceProjectDetails(response.data);
            }, function () {
            });
        }
        function replaceProjectDetails(data) {
            angular.element("#instance_group_id").val(data.instance_group_id),
                angular.element("#projectId").val(data.projectId),
                angular.element("#rmft").val(data.formTypeID),
                angular.element("#hashed_project_id").val(data.projectId),
                angular.element("#project_id").val(data.projectId),
                angular.element("#cFormAttachFolderId").val(data.folderId),
                angular.element("input[name='attachDocFolderID']").val(data.folderId),
                myConfig.projectId = data.projectId,
                myConfig.FOLDERID_FORM = data.folderId,
                myConfig.autoPublishToFolder = data.auto_publish_to_folder,
                myConfig.autoPublishFolderId = data.default_folder_id;
        }
        $window.beforeSubmitForm = function (submitFn) {      
            $scope.appendAttachHiddenFields();    
            $scope.submitXhr(function (data) {                     
                if(myConfig.isEditORI == "false"){
                    var msgElem = '<div class="payment-wrapper">' + 
                    '<div class="after-msg">' +  
                    '<p>Your Insurance Application has been submitted successfully!<br/>Please check under My Applications tab within Insurance Section for more details.</p>' + 
                    '<button type="button" class="btn btn-default ok-btn">Ok</button>' + 
                    '</div></div>'; 
                    angular.element("body").append(msgElem); 
                    angular.element('.ok-btn').bind('click', function(e){ 
                        e.stopPropagation(); 
                        $window.cancelForm && $window.cancelForm(true, true); 
                    });                 
                }
                else{
                    $window.cancelForm && $window.cancelForm(true, true);
                }
            }); 
            
        }; 
    } 
    return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}