/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', "mainModule",  './base',  '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';	

	/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {	
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if(!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') && 
			!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if(!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') && 
			!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	}, addTextAngularOptions = function($provide) {
		$provide.decorator("taOptions", ["taRegisterTool", "$delegate", function(taRegisterTool, taOptions) {
			return taRegisterTool("backgroundColor", {
				display: "<div spectrum-colorpicker class='spectrum-colorpicker' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("backColor", color)
					}
					setTimeout(function() {
						me.action(color)
					}, 100)
				},
				options: {
					replacerClassName: "fa fa-paint-brush",
					showButtons: !1
				},
				color: "#fff"
			}),
			taRegisterTool("fontColor", {
				display: "<spectrum-colorpicker class='spectrum-colorpicker' trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'/>",
				action: function(color) {
					var me = this;
					if (this.$editor().wrapSelection) {
						return this.$editor().wrapSelection("foreColor", color)
					}
					setTimeout(function() {
						me.action(color)
					}, 100)
				},
				options: {
					replacerClassName: "fa fa-font",
					showButtons: !1,
                    showAlpha : !1
				},
				color: "#000"
			}),
			taRegisterTool('fontName', {
				display: "<button type='button' class='font-name btn btn-blue bar-btn-dropdown dropdown' ng-disabled='showHtml()'><i class='fa fa-font'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-family: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.css)'><i ng-if='o.active' class='fa fa-check'></i>{{o.name}}</div></li></ul>"+"</button>",
				action: function (event, font) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-size-list').removeClass('open-fonts-size-list');
					this.$element.toggleClass('open-fonts-list');
					return this.$editor().wrapSelection('fontName', font);
				},	
				disabled: function() {},			
				options: [
					{ name: 'Sans-Serif', css: 'Arial, Helvetica, sans-serif' },
					{ name: 'Serif', css: "'times new roman', serif" },
					{ name: 'Wide', css: "'arial black', sans-serif" },
					{ name: 'Narrow', css: "'arial narrow', sans-serif" },
					{ name: 'Comic Sans MS', css: "'comic sans ms', sans-serif" },
					{ name: 'Courier New', css: "'courier new', monospace" },
					{ name: 'Garamond', css: 'garamond, serif' },
					{ name: 'Georgia', css: 'georgia, serif' },
					{ name: 'Tahoma', css: 'tahoma, sans-serif' },
					{ name: 'Trebuchet MS', css: "'trebuchet ms', sans-serif" },
					{ name: "Helvetica", css: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
					{ name: 'Verdana', css: 'verdana, sans-serif' },
					{ name: 'Proxima Nova', css: 'proxima_nova_rgregular' }
				]
			}),
			taRegisterTool('fontSize', {
				display: "<button type='button' class='font-size bar-btn-dropdown dropdown btn btn-blue' ng-disabled='showHtml()'><i class='fa fa-text-height'></i><div class='sp-dd'>▼</div>" + "<ul class='dropdown-menu'><li ng-repeat='o in options'><div class='checked-dropdown' style='font-size: {{o.css}}; width: 87.5%' type='button' ng-click='action($event, o.value)'><i ng-if='o.active' class='fa fa-check'></i> {{o.name}}</div></li></ul>" + "</button>",				
				action: function (event, size) {
					//Ask if event is really an event.					
					if (!!event.stopPropagation) {
						//With this, you stop the event of textAngular.
						event.stopPropagation();
						//Then click in the body to close the dropdown.
						angular.element("body").trigger("click");
					}
					angular.element('.open-fonts-list').removeClass('open-fonts-list');
					this.$element.toggleClass('open-fonts-size-list');					
					return this.$editor().wrapSelection('fontSize', parseInt(size));					
				},			                
				disabled: function() {},
				options: [
					{ name: 'xx-small', css: 'xx-small', value: 1 },
					{ name: 'x-small', css: 'x-small', value: 2 },
					{ name: 'small', css: 'small', value: 3 },
					{ name: 'medium', css: 'medium', value: 4 },
					{ name: 'large', css: 'large', value: 5 },
					{ name: 'x-large', css: 'x-large', value: 6 },
					{ name: 'xx-large', css: 'xx-large', value: 7 }

				]
			}),
			taOptions.toolbar[1].push('fontName', 'fontSize', 'backgroundColor', 'fontColor'),taOptions;
		}
		]);
		$provide.decorator("taToolFunctions", ["$delegate", function($delegate) {
				var imgOnSelectActionFn = $delegate.imgOnSelectAction;
				return $delegate.imgOnSelectAction = function(event, $element, editorScope) {
					imgOnSelectActionFn(event, $element, editorScope),
					editorScope.displayElements.popover.css("width", "auto"),
					editorScope.displayElements.popover.find(".btn-group").eq(1).remove()
				},$delegate;
			}
		])
	};
	
	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
    mainModule.config(function($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
    });


	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, Notification) {		
		var ctrl = this;
		if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_ASI_STD_TNDR_GetITBs_WITHOUT_ACL = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GetITBs_WITHOUT_ACL');
		$scope.DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
		$scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		var DS_WORKINGUSER_WITHOUT_ROLE = $scope.getValueOfOnLoadData('DS_WORKINGUSER_WITHOUT_ROLE')[0],			
			DS_WORKINGUSER = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value5,
			DS_WORKINGUSER_ID = DS_WORKINGUSER_WITHOUT_ROLE && DS_WORKINGUSER_WITHOUT_ROLE.Value1.split('|')[0].trim();

		$scope.oriMsgCustomFields.EOIDetails.userForEOI = $scope.oriMsgCustomFields.EOIDetails.userForEOI || DS_WORKINGUSER || '';
		$scope.launchFromITBId = $scope.oriMsgCustomFields.EOIDetails.otherExtraDetails.itbFormId;
		$scope.launchFromITBTitle = $scope.oriMsgCustomFields.EOIDetails.EOIForTender;
		
		$scope.submitFlag = false;
		$scope.clickSave = false;
		$scope.clickSaveDraft = false;
		var isForSaveDraft = false;

		$scope.update();
		$scope.DSI_isLoaded = true;
		$scope.DistributionStructure = {
			DS_PROJDISTUSERS: "",
			DS_FORMACTIONS: "",
			DS_ACTIONDUEDATE: "",
			Dist_Organisation: ""
		};
		$scope.AutoDistActionStructure = {
			DS_ADO_TYPE: "",
			DS_ADO_FORM: "",
			DS_ADO_MSG_TYPE: "",
			DS_ADO_FORMACTIONS: "",
			DS_ADO_PROJDISTGROUPS: "",
			DS_ADO_ACTIONDUEDATE: "",
			DS_ADO_PROJDISTUSERS: ""
		};
		$scope.ItemsDataList = [];
		$scope.logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});
		var sendObj = {};

		/**
		 * Variables for defined for the Form creating from Marketplace Button.		
		 * */ 
		var splitedUrlValue = $window.location.href.split('_');
		var isUrlContainsITB = (splitedUrlValue[4] && splitedUrlValue[4].indexOf('ITB') > -1);
		$scope.ITBfromMarketPlace = isUrlContainsITB ? splitedUrlValue[4] : undefined;
		$scope.isFromMarketPlace = isUrlContainsITB;

		$scope.isITBValid = true;

		/**
		 * Set client's logo.
		 */
		var setClientLogo = function () {
			if ($scope.logo && $scope.logo[0].Value8) {
				$scope.oriMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
			}
		};

		/**
		 * Function to set the Form Title.
		 */
		var setFormTitle = function() {			
			$scope.oriMsgCustomFields.ORI_FORMTITLE = "EOI For " +$scope.launchFromITBId;
		};
		
		/**
		 * Function to created data for 'item-select' component.
		 */
		var createSetItemList = function() {			
			$scope.ItemsDataList = structureItemList();			
		};
		
		/**
		 * Function to ready data for 'item-select' component's required structure.
		 */
		var structureItemList = function() {
			var lineData=[];
			angular.forEach($scope.DS_ASI_STD_TNDR_GetITBs_WITHOUT_ACL, function(item){		
				var isSameITB = (item.Value1 == $scope.launchFromITBId);
				lineData.push({
					displayValue: item.Value3, 
					modelValue:  item.Value1,
					checked: isSameITB					
				});	
			});
			return [{
				optlabel: "",
				options: lineData
			}];
		};
		
		/**
		 * @param {isFromLaunched :Boolean} isFromLaunched.
		 */
		var setTitleAndEoiTender = function(isFromLaunched) {
			setFormTitle();
			$scope.oriMsgCustomFields.EOIDetails.EOIForTender = !isFromLaunched ? $scope.launchFromITBTitle : $scope.launchFromITBId+'-'+$scope.launchFromITBTitle;
		};

		/**
		 * @param {changeItemSelectionEvent : Object}
		 * set ITB Tender form Id as well 
		 */
		$scope.changeItemSelectionEvent = function(item) {
			$scope.launchFromITBId = item.modelValue; 
			$scope.launchFromITBTitle = item.displayValue;
			setTitleAndEoiTender(false);			
		};

		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
		});
		
		/**		 
		 * @param {Number} days calculatung the date on base of given days
		 */
		var calculateDistDate = function(days) {
			var strDueDate = "";
            if (days) {
				var d = new Date();
                d.setDate(d.getDate() + days);
                var month = d.getMonth() + 1,
				day = d.getDate(),
				strDueDate = d.getFullYear() + '-' +
				(month < 10 ? '0' : '') + month + '-' +
				(day < 10 ? '0' : '') + day;
            }
            return strDueDate;
		};
		
		/**		  
		 * @param {*function} revCallBack will execute after all code exicution of this function. 
		 * @param {*Array} addPfcDataList 		 
		 * This Function will set all nodes for distribution and send action to other Forms.
		 */
		var setRespectiveDistNodes = function(revCallBack, addPfcDataList) {
			if(DS_WORKINGUSER_ID) {
				var workingUserId = DS_WORKINGUSER_ID,
					respondNodes = setRespondActionToITB(workingUserId),
					respondNodesList = [respondNodes],
					addPfcNodesList = setAddPfcActionNodes(addPfcDataList, workingUserId),
					allNodes = respondNodesList.concat(addPfcNodesList);
				
				if (allNodes.length) {
					$scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = allNodes;				
					$scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS_APP_ID = "1";
					revCallBack.revCallBackFn();
				}
			}
		};

		/**		
		 * @param {*} workingUserId 
		 * set node for to send RESPOND action on ITB Tender Form.
		 */
		var setRespondActionToITB = function(workingUserId){					
			var AutoDistActionStructure = angular.copy($scope.AutoDistActionStructure);
				AutoDistActionStructure.DS_ADO_TYPE = "3";
				AutoDistActionStructure.DS_ADO_FORM = "ASI-STD-"+$scope.launchFromITBId;
				AutoDistActionStructure.DS_ADO_MSG_TYPE = "ORI";
				AutoDistActionStructure.DS_ADO_FORMACTIONS = "3";
				AutoDistActionStructure.DS_ADO_ACTIONDUEDATE = calculateDistDate(5);
				// get user id and submit
				AutoDistActionStructure.DS_ADO_PROJDISTUSERS = workingUserId;

			return AutoDistActionStructure;
		};

		/**		 
		 * @param {*} addPfcDataList, List of Adendom and Point for clearification Forms on which action will be send.
		 * @param {*} workingUserId 
		 * This Function will set 
		 */
		var setAddPfcActionNodes = function(addPfcDataList, workingUserId){
			var addPfcParsedList = JSON.parse(addPfcDataList.DS_ASI_STD_ADD_PCL_DTLS).Items.Item,
				addPfcIds = addPfcParsedList.length && addPfcParsedList[0].Value3.split(',') || [],
				addPfcActionNodes = []; 

				for(var i=0; i<addPfcIds.length; i++){
					var appBuilderId = addPfcIds[i];
					var AutoDistActionStructure = angular.copy($scope.AutoDistActionStructure);
						AutoDistActionStructure.DS_ADO_TYPE = "3";
						AutoDistActionStructure.DS_ADO_FORM = appBuilderId;
						AutoDistActionStructure.DS_ADO_MSG_TYPE = "ORI";
						AutoDistActionStructure.DS_ADO_FORMACTIONS = "7";						
						// get user id and submit
						AutoDistActionStructure.DS_ADO_PROJDISTUSERS = workingUserId;
					addPfcActionNodes.push(AutoDistActionStructure);
				}
			
			return addPfcActionNodes;
		};

		if (currentViewName == "ORI_VIEW") {
			if (strFormId == "" || strIsDraft == "YES") {
				setClientLogo();
				if ($scope.launchFromITBId) {
					setTitleAndEoiTender(true);
					if(!$scope.launchFromITBId){
						$scope.isITBValid = false;
					} 
				} else if ($scope.isFromMarketPlace) {
					if($scope.ITBfromMarketPlace) {
						var ITBFormObj = $scope.DS_ASI_STD_TNDR_GetITBs_WITHOUT_ACL.filter(function(itbObj){
							return itbObj.Value1 == $scope.ITBfromMarketPlace;
						})[0];
						if(ITBFormObj && !angular.equals({}, ITBFormObj)){
							$scope.changeItemSelectionEvent({
								modelValue : ITBFormObj.Value1,
								displayValue : ITBFormObj.Value3 
							});
							// set pre selected Value.
							$scope.oriMsgCustomFields.EOIDetails.otherExtraDetails.itbFormId = $scope.ITBfromMarketPlace;
						} else {
							$scope.isITBValid = false;
						}
					}
				}
				createSetItemList();				
			}
		}		

		/**
		 * 
		 * @param {*} revCallBack 
		 * Function makes an Ajax call to get List of Adendom and Point for clearification Forms on which action will be send.
		 */		
		var getPclAndAddFormDetails = function(revCallBack) {
			var paramObj = {
                "projectId": $scope.projectId,
                "formId": $scope.formId,
                "fields": "DS_ASI_STD_ADD_PCL_DTLS",
                "callbackParamVO": {
                    "customFieldVOList": [{
                        "fieldName": "DS_ASI_STD_ADD_PCL_DTLS",
                        "fieldValue": "ASI-STD-"+$scope.launchFromITBId
                    }]
                }
            };

			$scope.isXHRon = true;
            $scope.getCallbackData(paramObj).then(function (response) {                
                var resData = response.data;
                if(resData){                                    					
                    $timeout(function () {
						setRespectiveDistNodes(revCallBack, resData);						
                    },100);
                    $scope.isXHRon = false;
                }
            });
		};

		$scope.editorNativePasteEvent = function($html) {						
			return $html;
		};

		$scope.contentChangeOnBlur = function(event, EOIReasonValue) {			
			$scope.oriMsgCustomFields.EOIDetails.otherExtraDetails.rtfHTMLDetails = EOIReasonValue;
		};

		$scope.cancel = function () {
			$window.top.postMessage("closeCreateFormIframe:-1",'*');
		};

		var saveEOIForm = function () {	
			isForSaveDraft ? ($scope.clickSaveDraft = isForSaveDraft) : $scope.clickSave = true;		
			var formJson = {
				formJson: $scope.data,
				projectId: $scope.projectId.split('$$')[0],
				formTypeId: formTypeId.split('$$')[0],
				invitationRoleName: $scope.oriMsgCustomFields.EOIDetails.invitationRoleName
			};
			if(isForSaveDraft){
				formJson.saveAsDraft =  true;
			}
			formJson.formJson = angular.toJson(formJson.formJson);			
			commonApi.ajax({
				url: $window.marketPlaceServiceURL + '/marketplace/opportunities/saveeoi',
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': $window.marketPlaceApiKey
				},
				data: angular.toJson(formJson)
			}).then(function (response) {
				if (response.data) {
					sendObj.refreshOppo = true;
					alert("Expression Of Interest Submitted Successfully.");
					if(window.top && window.top.opener){
						if (isIE()) {
							window.top.opener.updateBidAndExpress();
						} else {
							var href = window.top.opener.location.href;
							if(href) {
								if((href.indexOf('adoddle') > -1) && (href.indexOf('adoddlepublic') > -1)) {
									window.top.opener.postMessage("close::reload::parentreload", "*");
								} else { 
									// refresh for Parent Tender Form in Form View in Adoddle
									window.top.opener.postMessage("close::reload", "*");
									// refresh for Projects Listing in Market Place.
									window.top.opener.postMessage(JSON.stringify(sendObj), "*");
								}
							}
						}
						window.top.close();
					}else{
						window.location = top.marketPlaceServiceURL + "/marketplace/opportunity";
					}
				}
			}, function () {
				Notification.error({title: 'Server Error', message: 'Error In Expression Of Interest Submit.'});
				$scope.submitFlag = false;
				$scope.clickSave = false;
				$scope.clickSaveDraft = false;
			});
		};

		/**
		 * Final Submit call to submit function.
		 */

		var isIE = function() {
			return ((navigator.userAgent.indexOf(".NET CLR") > -1) || (navigator.userAgent.indexOf("MSIE") > -1) || 
			!!navigator.userAgent.match(/Trident\//) || !!navigator.userAgent.match(/Edge\//));
		};
		$scope.finalSubmitCallBack = function (isApprove) {			
			if($scope.submitFlag) {
				return false;
			}
			var revCallBack = {
				revCallBackFn : function(isValid){
					$scope.submitFlag = true;
					$scope.oriMsgCustomFields.EOIDetails.otherExtraDetails.isFromMarketPlace = $scope.isFromMarketPlace;
					// set ITB id in DS_FORMCONTENT for SP Use.
					$scope.Form_Data['DS_FORMCONTENT1'] = $scope.oriMsgCustomFields.EOIDetails.otherExtraDetails.itbFormId;
					// mentioned rolname in which user will be added if not available in this property.
					$scope.oriMsgCustomFields.EOIDetails.invitationRoleName = "Vendor";
					saveEOIForm(isApprove);
				}
			};
			
			if($window.validateForHTML5Form()) {
				getPclAndAddFormDetails(revCallBack);
			}			
		};

	}
	return FormController;
});