/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $timeout,$sce) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}
		$scope.RecipientStructure = {
			Tenderer_Organisation: "",
			Tenderer_Recipient: ""
		};
		var UserStructure = {
			User_Organisation: "",
			User_Recipient: ""
		};
		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.ORIMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
			   
		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.Responses = $scope.ORIMsgCustomFields.RES_MSG_Custom_Fields.RESPONSES.ALL_RES;

		var DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_GEO_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_GEO_STD_TNDR_GetITBs');
		var getRfqDetails = $scope.getValueOfOnLoadData('DS_GEO_STD_RFQ_ORI_DTLS');
		$scope.DS_ALL_EMAIL_MSG = $scope.getValueOfOnLoadData('DS_ALL_EMAIL_MSG');
		$scope.actionsDropDown = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
		$scope.DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Value.split('|')[0];;
		$scope.projDistUser = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		$scope.update();

		$scope.logo = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});
		$scope.setOrg=function(obj)
		{
			obj.Tenderer_Organisation=obj.Tenderer_Recipient?obj.Tenderer_Recipient.split(',')[1]:'';
		}

		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
		var strResDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			var strDays = (new Date(serverDate)).getTime() + (86400000 * 3);
			var strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
			$scope.strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date($scope.strTime), 'dd-M-yy');
			$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = strCloseDueDate;
		});
		if (window.currentViewName == "ORI_VIEW") {
			
			if (strFormId == "" || strIsDraft == "YES") {
				$scope.ORIMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
				$timeout(function () {
					if (localStorage) {
						var numVal = localStorage.getItem('formcode_num')
						if (numVal) {
							if (numVal) {
								$scope.setFormContentOnITBChange(numVal);
							}
							localStorage.removeItem('formcode_num');
						}
					}
				}, 1000);
			}
			if (strIsDraft == "YES") {
                $timeout(function () {
                    chkDuplicateonDraft();
                });
            }
		}
		function chkDuplicateonDraft()
		{
			var repNodes = $scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode;
            if (repNodes && repNodes.length) {
                for (var i = 0; i < repNodes.length; i++) {
                    $scope.checkDuplicateRecord({
                        repeatObj: $scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode,
                        objName: 'Tenderer_Recipient'
                    });
                }
            }
		}
	    $scope.checkDuplicateRecord = function (args) {
            $scope.arrMain = [];
            var isValidFlag = false;
            var formNode = this.myform;
            for (var index = 0; index < args.repeatObj.length; index++) {
                var element = args.repeatObj[index];
                if ($scope.arrMain.indexOf(element[args.objName]) > -1) {
                    isValidFlag = true;
                    formNode[args.objName + index].$setValidity('duplicate', !isValidFlag)
                } else {
                    $scope.arrMain.push(element[args.objName]);
                    isValidFlag = false;
                    formNode[args.objName + index].$setValidity('duplicate', !isValidFlag)
                }
            }
        }

		$scope.setFormContentOnITBChange = function (selectedITBValue) {
			var strSel_ITB = selectedITBValue.split('-')[0].trim();
			var form = {
				"projectId": $scope.projectId,
				"formId": $scope.formId,
				"fields": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
				"callbackParamVO": {
					"customFieldVOList": [{
						"fieldName": "DS_GEO_STD_TNDR_GET_ITBSDETAILS",
						"fieldValue": strSel_ITB
					}]
				}
			}
			$scope.ORIMsgCustomFields.DSI_isLoading = true;
			$scope.getCallbackData(form).then(function (response) {
				if (response.data) {
					$scope.ORIMsgCustomFields.DSI_isLoading = false;
					var DS_GEO_STD_TNDR_GET_ITBSDETAILS = angular.fromJson(response.data['DS_GEO_STD_TNDR_GET_ITBSDETAILS']);
					if (DS_GEO_STD_TNDR_GET_ITBSDETAILS && DS_GEO_STD_TNDR_GET_ITBSDETAILS.Items.Item.length) {
						DS_GEO_STD_TNDR_GET_ITBSDETAILS = DS_GEO_STD_TNDR_GET_ITBSDETAILS.Items.Item;
						var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
							return val.Value1.indexOf(strSel_ITB) != -1;
						});
						$scope.ORIMsgCustomFields['Select_ITB'] = dropDownValueObj[0].Value1;
						if (DS_GEO_STD_TNDR_GET_ITBSDETAILS) {
							var strItbId = DS_GEO_STD_TNDR_GET_ITBSDETAILS[0].Value1;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT1'] = strItbId;
							$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMCONTENT2'] = strSel_ITB;
						}
					}
				}
			});
		}
		$scope.DeleteRow = function (index, repeatindData) {
			if (repeatindData.length > index) {
				repeatindData.splice(index, 1);
			}
		};
		$scope.AddNewItem = function(repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
		$scope.SetUsers = function () {
			var tempList = [],
				recipients = [];
			for (var i = 0; i < $scope.ORIMsgCustomFields.Role_Name.length; i++) {
				tempList = commonApi._.filter($scope.actionsDropDown, function (val) {
					return val.Value.indexOf($scope.ORIMsgCustomFields.Role_Name[i]) > -1
				});
				Array.prototype.push.apply(recipients, tempList);
			}
			recipients = commonApi._.uniq(recipients, function (userObj) {
				return userObj.Name;
			});
			$scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode = [];
			if (recipients.length) {
				for (var i = 0; i < recipients.length; i++) {
					var strusername = recipients[i].Value.trim().split('|');
                    var strid = strusername[2].split('#')[0].trim();
                    var userwithid = "";
                    var strdistUser = commonApi._.filter($scope.projDistUser, function (val) {
                        return val.Value.split('#')[0] == strid;
                    });
                    if (strdistUser.length) {
                        userwithid = strdistUser[0].Value;
                    }
                    var arrReceipien = angular.copy($scope.RecipientStructure);
                    arrReceipien.Tenderer_Organisation = strusername[1].split(',')[1].trim();
                    arrReceipien.Tenderer_Recipient = userwithid.trim();
                    $scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode.push(arrReceipien);
				}
				$scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode=commonApi._.sortBy($scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode,function (num) {
					return num.Tenderer_Organisation;
				});
			}
			else {
				var arrReceipien = angular.copy($scope.RecipientStructure);
				arrReceipien.Tenderer_Organisation = '';
				arrReceipien.Tenderer_Recipient = '';
				$scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode.push(arrReceipien);
			}
		}
		if (window.currentViewName == "ORI_PRINT_VIEW" || window.currentViewName == "FORM_PRINT_VIEW" || window.currentViewName == "RES_PRINT_VIEW") {
			var strSel_ITB = $scope.ORIMsgCustomFields['Select_ITB'];
			var dropDownValueObj = commonApi._.filter($scope.DS_GEO_STD_TNDR_GetITBs, function (val) {
				return val.Value3.indexOf(strSel_ITB) != -1;
			});
			if (dropDownValueObj.length) {
				$scope.ORIMsgCustomFields['ITB_URL'] = dropDownValueObj[0].URL6;
			}
			if($scope.ORIMsgCustomFields.DSI_Orignator.trim() == WorkingUserID.trim()){
				$scope.ISOrignator=true;
			}
		}
		if (window.currentViewName == "ORI_PRINT_VIEW"){
			$scope.DS_DOC_ASSOCIATIONS_ALL = $scope.getValueOfOnLoadData('DS_DOC_ASSOCIATIONS_ALL');
			$scope.DS_DOC_ATTACHMENTS_ALL = $scope.getValueOfOnLoadData('DS_DOC_ATTACHMENTS_ALL');
		}

		if (window.currentViewName == "RES_VIEW") {

			if (strResDraft == "YES") {
				return;
			}
			var intResponseNodeLength = $scope.Responses.length;
			for (var i = 0; i < intResponseNodeLength; i++) {
				if ($scope.Responses[i].RFI_Response.length > 0) {
					$scope.Responses[i].DSI_ResFlag = "Old";
				}
			}			
			setResponseData(getRfqDetails);
			var strResCount = $scope.ORIMsgCustomFields['RES_MSG_Custom_Fields']['DSI_Res_Counter'],
				strWorkingUser = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'],
				BlankResponseNode = {
					"DSI_ResID": "",
					"RFI_Response": "",
					"RFI_ResponseBy": "",
					"RFI_ResponseDate": "",
					"DSI_ResFlag": ""
				},
				strToday = $scope.setDbDateClientSide(0),
				intCount = strResCount;

			if (strFormId.trim().length > 0 && (strIsDraft == "NO" || strIsDraft == "")) {
				if (intCount == 1) {
					$scope.Responses[0]['RFI_ResponseBy'] = strWorkingUser;
					$scope.Responses[0]['RFI_ResponseDate'] = strToday;
					intCount++;
				} else {
					intCount++;
					var responseNode = angular.copy(BlankResponseNode);
					responseNode.DSI_ResID = intCount.toString();
					responseNode.RFI_ResponseBy = strWorkingUser;
					responseNode.RFI_ResponseDate = strToday;
					responseNode.DSI_ResFlag = "New";
					if (responseNode) {
						$scope.Responses.push(responseNode);
					}
				}
			}
			$scope.ORIMsgCustomFields['RES_MSG_Custom_Fields']['DSI_Res_Counter'] = intCount.toString();
		}
		if (window.currentViewName == "RES_PRINT_VIEW") {
			setResEmailMsg();
		}

		function setResEmailMsg() {

			if (!$scope.DS_ALL_EMAIL_MSG.length) { $scope.ORIMsgCustomFields.DSI_Email_Response == "" }

			for (var index = 0; index < $scope.DS_ALL_EMAIL_MSG.length; index++) {
				var msgid = $scope.DS_ALL_EMAIL_MSG[index].Value1.trim();
				if (msgid && msgid == $scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_MSGID.trim()) {
					$scope.ORIMsgCustomFields.DSI_Email_Response = $sce.trustAsHtml($scope.DS_ALL_EMAIL_MSG[index].Value5);
					break;
				}
			}
		}
        function setResponseData(AllResData) {
            if (AllResData && AllResData.length) {
                for (var i = 0; i < AllResData.length; i++) {
					$scope.ORIMsgCustomFields.ORI_FORMTITLE = AllResData[i]["Value3"] || "";
					$scope.ORIMsgCustomFields.Description = AllResData[i]["Value4"] || "";
					$scope.ORIMsgCustomFields.Reply_Due_Date = AllResData[i]["Value5"] || "";
                }
            }            
        }
		function setDistribution() {
			var distDate = $scope.ORIMsgCustomFields.Reply_Due_Date;
			var tempList = [];
			$scope.ORIMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.Auto_Distribute_Users = [];
			var distNodes = $scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode;

			if (distNodes.length) {
				for (var i = 0; i < distNodes.length; i++) {
					tempList.push({
						strUser: distNodes[i].Tenderer_Recipient,
						strAction: "3#Respond",
						strDate: distDate
					});
				}

				commonApi.setDistributionNode({
					actionNodeList: tempList,
					autoDistributeUsers: $scope.ORIMsgCustomFields.REPEATING_VALUES.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: 3
				});
			}
		}
		if (strFormId != "" && strIsDraft == "NO") {
			$scope.ORIMsgCustomFields.DSI_isLoading = false;
		}
		function formSubmitCallBack() {

			if (currentViewName == 'ORI_VIEW') {

				if ($scope.ORIMsgCustomFields.Reply_Due_Date < $scope.todayDateDbFormat) {
					alert("Due Date cannot be less then today date");
					return true;
				}
				if (!$scope.ORIMsgCustomFields.REPEATING_VALUES.Tender_Temp_Dist_Nodes.Temp_DistNode.length) {
					alert("You can not create the form because you have missed to add recipients.");
					return true;
				}
				$scope.ORIMsgCustomFields.DSI_Orignator=WorkingUserID
				setDistribution();
			}
			return false;
		}
		window.oriformSubmitCallBack = function () {
			return formSubmitCallBack();
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}