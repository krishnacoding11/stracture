define(['angular', './base', '../components/folder.selection', '../components/item.selection'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout, Notification,myConfig) {

		$controller(baseController, { $scope: $scope, $element: $element });

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});

		var ctrl = this;
		$scope.DS_WORKSPACE_ROLES_NOT_USED_BIDLIST = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_NOT_USED_BIDLIST');
		$scope.Bidtype = commonApi._.filter($scope.DS_WORKSPACE_ROLES_NOT_USED_BIDLIST, function (val) {
			return val.Name.toLowerCase().indexOf('wp') > -1
		});

		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		ctrl.$onInit = function () {
			$scope.update();
			$scope.data = $scope.getFormData();
			
			$scope.sections = null;			
			$scope.logos = null;
			$scope.deleteEnabled = false;
			$scope.showDeletePopup = false;			
			$scope.isEditForm = false;
			$scope.showDelete = false;
			$scope.showRemovePopup = false;
			$scope.removeOrg = null;
			$scope.printSectionArry=[];
			$scope.fieldNames ={
				"Company Summary": "legalCompanyName",
				"Address":"address",
				"Business Details":"industrycategory,no_of_employees",
				"Annual Turnover":"annualTurnover",
				"QA Policy":"Does_your_organisation_have_BS_EN_ISO9001_certified_by_a_UKAS_accredited_body?",
				"Accreditation":"Do_you_hold_ISO18001_accreditation_from_a_UKAS_accredited_body?",
				"Insurances":"typeOfCover"
			}
			$scope.orgIds = myConfig.orgIds;
			
			var editORI = document.getElementById("editORI");
			if(editORI && editORI.value == "true"){
				$scope.bidType = $scope.data.bidTypeValue;
				$scope.repeatingTable = $scope.data.repeatingTable;
				$scope.title = $scope.data.ORI_FORMTITLE;
				$scope.description = $scope.data.description;
				$scope.projectName = $scope.data.projectName;
				$scope.budget = $scope.data.budget;
				$scope.estimate = $scope.data.estimate;
				$scope.currency = $scope.data.currency;
				$scope.isEditForm = true;

				if($scope.orgIds){
					var newOrgList  = $scope.orgIds.split(",");
					var finalArry = [];
					for(var n=0;n<newOrgList.length;n++){
						for(var r=0;r<$scope.repeatingTable.length;r++){
							if(finalArry.indexOf(newOrgList[n]) == -1)
							finalArry.push(newOrgList[n]);
							if(finalArry.indexOf($scope.repeatingTable[r].orgId) == -1)
							finalArry.push($scope.repeatingTable[r].orgId);
						}
					}
					$scope.companiesLength = finalArry.length;
					$scope.setIframeHeight();
					$scope.getOrgDetails(finalArry);
				}
				var obj = { 'message': 'editORI' };
				window.top.postMessage(JSON.stringify(obj), "*");
			}
			else{					
				$scope.bidType = $scope.data.bidType;
				$scope.title = $scope.data.ORI_FORMTITLE;
				$scope.description = $scope.data.description;
				$scope.budget = $scope.data.budget;
				$scope.estimate = $scope.data.estimate;
				$scope.currency = $scope.data.currency;
				$scope.projectName = $scope.data.projectName || myConfig.ProjectName;
				
				//set form params when viewing the form from marketplace bid list
				if(myConfig.fromMarketplaceBidList == "true"){
					$scope.showDelete = true;
					$scope.logos = myConfig.logos;
					var logoImages = $scope.logos.split(",");
					var companyNames = myConfig.companyNames.split(",");
					var orgLogos = [];
					for(var l=0;l<logoImages.length;l++){
						orgLogos.push({
							"title":companyNames[l],
							"img":logoImages[l]
						});
					}
					$scope.logos = orgLogos;
					$scope.projectId = myConfig.projectId;
					$scope.formId = myConfig.formId;
					$scope.userID = myConfig.USP.userID;
					$scope.msgId = myConfig.msgId;
					$scope.formStatus = myConfig.formStatus;
					$scope.tenderId = myConfig.tenderId;
					$scope.uopIds = myConfig.uopIds;
					$scope.senderLogoURL = myConfig.senderLogoURL;
					
					if($scope.formStatus == "Approved" && $scope.tenderId != "undefined"){
						$scope.showDelete = false;
					}

					getUOPSectionData();
				}
				else{
					$scope.getOrgDetails();
					
					if($scope.orgIds && !$scope.orgIds[0]){
						document.getElementsByClassName("topContent")[0].style.maxWidth="600px"
						document.getElementsByClassName("topContent")[0].style.borderBottom="none"
						document.getElementsByClassName("bottomContent")[0].style.display="none"
					}

					var obj = { 'message': 'hideLoader' };
					window.top.postMessage(JSON.stringify(obj), "*");
				}				
			}
			listen();
		}
		var listen = function() {			
			$scope.$on('status:changedFromMarketplace', function(event, status) {
				$scope.closeForm();
			});
			try{
				if(document.getElementsByClassName("mainSection")[0] && document.getElementsByClassName("mainSection")[0].length){
					document.getElementsByClassName("mainSection")[0].addEventListener("scroll", function(){
						var scrollleft = "-" + document.getElementsByClassName("mainSection")[0].scrollLeft+"px";
						document.getElementsByClassName("comparision-grid")[0].style.marginRight = scrollleft;
					})
				}
			}
			catch(c){}
		};		
		//return organization details
		$scope.getOrgDetails = function(orgArry){
			$scope.orgIds = $scope.orgIds && $scope.orgIds.split(",");
			
			var params = {
				"freeTextSearch": "",
				"sortField": "company_name",
				"listingType": "list",
				"startFrom": 0,
				"recordBatchSize": 30,
				"filters": [
				  {
					"filteId": 1,
					"filterName": "org_id",
					"filterValues": orgArry || $scope.orgIds
				  }
				],
				"regionId": 0,
				"tabId": 2
			  }
			commonApi.ajax({
				url: $window.marketPlaceServiceURL + "/marketplace/uop/getOrgDetailsForBidList",			
				method: 'POST',
				withCredentials: true,
				data: params				
			}).then(function (response) {
				if(response && response.data){
					$scope.repeatingTable = response.data.data;
					if($scope.repeatingTable && $scope.repeatingTable.length){
						for(var r=0;r<$scope.repeatingTable.length;r++){
							$scope.repeatingTable[r].extendedData.businessTypeName = $scope.repeatingTable[r].extendedData.companyIndustryName;
							if($scope.repeatingTable[r].extendedData.Logo)
                            $scope.repeatingTable[r].comanyLogo = $window.marketPlaceServiceURL + '/marketplace/uop/orglogo?logoId='+ $scope.repeatingTable[r].extendedData.Logo;
							else
							$scope.repeatingTable[r].comanyLogo = "https://uk.marketplaceqa2.asite.com/marketscripts/ng-marketplace/assets/marketimages/default-logo.svg";
						}
					}					
					if($scope.logos && $scope.logos.length){
						for(var r=0;r<$scope.logos.length;r++){
							if($scope.logos.extendedData.Logo)
                            $scope.logos.comanyLogo = $window.marketPlaceServiceURL + '/marketplace/uop/orglogo?logoId'+ $scope.logos.extendedData.Logo;
							else
							$scope.logos[r].img = "https://uk.marketplaceqa2.asite.com/marketscripts/ng-marketplace/assets/marketimages/default-logo.svg";
						}
					}
				}

			}, function () {

			});
		}
		//returns all the subsection titles
		var getUOPSectionData = function () {
			commonApi.ajax({
				url: $window.marketPlaceServiceURL + "/marketplace/uop/getUOPSectionList",			
				method: 'POST',
                withCredentials: true,
				data: "fieldNames=legalCompanyName,tradingName,annualTurnover,address,industrycategory,Does_your_organisation_have_BS_EN_ISO9001_certified_by_a_UKAS_accredited_body?,Do_you_hold_ISO18001_accreditation_from_a_UKAS_accredited_body?,typeOfCover",
				headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
			}).then(function (response) {
				if(response && response.data){
					var sectionData = response.data;
					var companySummary;
					for(var r=0;r<sectionData.length;r++){
						if(sectionData[r].label == "Company Summary")
						companySummary = sectionData[r];
					}
					var subSections = [];
					for(var section in sectionData){
						if(sectionData[section].data && sectionData[section].data.length){
							for(var subsection in sectionData[section].data){
								var subSection = sectionData[section].data[subsection];
                                subSection.parentId = sectionData[section].id;
								subSection.selected = false;
								subSection.value = [];
								subSection.showLoader = false;
								subSections.push(subSection)
							}
						}
					}
					if(companySummary)
					subSections.splice(0,0,companySummary);

					$scope.subSections = subSections;
										
					$scope.toggleSelection($scope.subSections[0],"initialLoad");
										
					$scope.calculatedWidth = document.getElementsByClassName("mainTable")[0].offsetWidth-20;					

					if(document.getElementsByClassName("mainTable")[0].offsetWidth < document.getElementsByClassName("bottomContent")[0].offsetWidth)
					$scope.calculatedWidth = document.getElementsByClassName("bottomContent")[0].offsetWidth-32;

					setTimeout(function(){						
						var cols = document.getElementsByClassName('mainTable');
						for(var i = 0; i < cols.length; i++) {
							cols[i].style.tableLayout = 'fixed';
						}
						
						if($scope.showDelete && ($scope.formStatus == "Approved" || !document.getElementById("form-action-btn"))){						
							document.getElementsByClassName("btn-delete")[0].style.left="20px";
						}
						if(document.getElementsByClassName("btn-print")[0]){
							if($scope.formStatus == "Approved" && $scope.tenderId != "undefined"){
								document.getElementsByClassName("btn-print")[0].style.left="20px";
							}
							else if($scope.showDelete && ($scope.formStatus == "Approved" || !document.getElementById("form-action-btn"))){
								document.getElementsByClassName("btn-print")[0].style.left="90px";
							}
							else{
								document.getElementsByClassName("btn-print")[0].style.left="148px";
							}
							document.getElementsByClassName("btn-print")[0].style.display="block";
						}
					},500)
									
					var obj = { 'message': 'hideLoader' };
					window.top.postMessage(JSON.stringify(obj), "*");
				}								
			}, function () {

			});
		}
		
		//toggle delete tender list popup
		$scope.toggleDeletePopup = function(show){
			if(show)
			$scope.showDeletePopup = true;
			else 
			$scope.showDeletePopup = false;
		}
		//deativates/deletes the current tender list
		$scope.deactivateTender = function(){
			commonApi.ajax({
				url: $window.marketPlaceServiceURL + "/marketplace/app/deactivateForms",			
				method: 'post',
                withCredentials: true,
				data: 	"projectId=" + $scope.projectId+
						"&formId=" + $scope.formId+
						"&msgCreatorUserID=" + $scope.userID+
						"&msgId=" + $scope.msgId,
				headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
			}).then(function (response) {	
				if(response && response.data){
					Notification.success('<div class="text-center">Bid list deleted successfully!</div>');
					$scope.closeForm();
				}		
			}, function () {

			});
		}
		//setting form data at the time of saving the form
		$scope.sendData = function (e) {		
			if(!$scope.title || !$scope.bidType){
				Notification.error({ title: 'Alert', message: "Please enter value for mandatory field(s)" })
				return;
			}
			if(!$scope.repeatingTable.length){
				Notification.error({ title: 'Alert', message: 'Please select an organization!' })
				return;
			}
			if(($scope.estimate || $scope.budget) && !$scope.currency){
				Notification.error({ title: 'Alert', message: 'Please select currency!' })
				return;
			}
			if(Number($scope.estimate) == 0 || Number($scope.budget) == 0){
				var msg;
				if(Number($scope.budget) == 0)
				msg = "Please enter a value greater than 0 for Work package budget";
				else
				msg = "Please enter a value greater than 0 for Pre-bid estimate";

				Notification.error({ title: 'Alert', message: msg })
				return;
			}

			$scope.data.repeatingTable = $scope.repeatingTable;
			$scope.data.ORI_FORMTITLE = $scope.title;
			$scope.data.description = $scope.description;
			$scope.data.projectName = $scope.projectName;
			$scope.data.bidTypeValue = $scope.bidType;
			$scope.data.bidType = $scope.bidType && $scope.bidType.split('#')[1].trim();
			$scope.data.bidTypeId = $scope.bidType && $scope.bidType.split('|')[0].trim();
			$scope.data.formUserRef = $scope.data.bidType;
			$scope.data.budget = $scope.budget;
			$scope.data.currency = $scope.currency;
			$scope.data.estimate = $scope.estimate;
						
			$scope.submitForm(1);
		}
		$window.beforeSubmitForm = function (submitFn) {                        
			$scope.submitXhr(function (data) { 
				$scope.closeForm();
			})
		};
		//for toggling the sections in comparision view
		$scope.toggleSelection = function(item,from){
			var currentSection = item.label;
			if(!from || (from == "initialLoad" && currentSection == "Company Summary")){
				item.showLoader = true;
				var isSectionLoaded = false;
				for(var subsections in $scope.subSections){
					if($scope.subSections[subsections].label == currentSection){
						if($scope.subSections[subsections].value && $scope.subSections[subsections].value.length){
							isSectionLoaded = true						
						}
					}
				}			
				if(isSectionLoaded){
					item.selected = !item.selected;
					item.showLoader = false;
					return;
				}
			}
			commonApi.ajax({
				url: $window.marketPlaceServiceURL + "/marketplace/uop/getFieldDetailsForOrgs",		
				method: 'post',
                withCredentials: true,
				data: "ids=" +$scope.uopIds+"&fieldNames="+$scope.fieldNames[item.label],
				headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
			}).then(function (response) {
				$scope.createSubSectionJson(response.data,currentSection,from);
				if(!from || (from == "initialLoad" && currentSection == "Company Summary")){
					item.selected = !item.selected;
					item.showLoader = false;	
				}			
			}, function () {

			});						
		}
		//fetching the currenlty selected subsection data
		$scope.createSubSectionJson=function(data,currentSection,from){
			if(currentSection == "Annual Turnover"){
				for(var record in data){
					if(data[record].length){
						for(var r=0;r<data[record].length;r++){
							if(data[record][r].value && data[record][r].value.length){					
								var newArry = [],annualPeriodExists=true;
								for(var v=0;v<data[record][r].value.length;v++){
									for(var s=0;s<data[record][r].value[v].length;s++){
										if(data[record][r].value[v][s].fieldName == "annualTurnoverPeriod"){
											if(data[record][r].value[v][s].value){
												newArry.push({
													"fieldId": 50,
													"dataSource": "",
													"dataSourceType": null,
													"fieldName": "annualTurnover",
													"fieldTypeId": 8,
													"label": "Annual Turnover - " + data[record][r].value[v][s].value,
													"nullable": false,
													"validationTypeId": "",
													"value": ""
												})
											}
											else
											annualPeriodExists = false;
										}
										else if(data[record][r].value[v][s].value && annualPeriodExists){
											newArry[v].value=numRound(data[record][r].value[v][s].value);
										}
									}
								}
							}
						}
						data[record] = newArry;
					}
				}
			}
			if(currentSection == "Address"){
				for(var record in data){
					var emailIdObj = [];
					if(data[record].length){
						for(var r=0;r<data[record].length;r++){
							if(data[record][r].value && data[record][r].value.length){			
								var isPrimaryAddressIndexArry=[];
								for(var v=0;v<data[record][r].value.length;v++){
									for(var s=0;s<data[record][r].value[v].length;s++){			
										if(data[record][r].value[v][s].fieldName == "primaryAddress" && data[record][r].value[v][s].value == "true"){
											isPrimaryAddressIndexArry.push(data[record][r].value[v]);
										}
									}
								}
								if(isPrimaryAddressIndexArry.length){	
									data[record][r].value=isPrimaryAddressIndexArry;
								}
							}
						}
						for(var r=0;r<data[record].length;r++){
							if(data[record][r].value && data[record][r].value.length){					
								var newArry = Object.assign([], data[record][r].value);
                                var countryIndex,zipIndex,countryObj,emailIdObj = [],isPrimaryAddressIndexArry=[];
								for(var v=0;v<data[record][r].value.length;v++){
									for(var s=0;s<data[record][r].value[v].length;s++){					
										if(data[record][r].value[v][s].fieldName == "country"){
											countryIndex=s;
                                            countryObj = data[record][r].value[v][s];
										}
										else if(data[record][r].value[v][s].fieldName == "zip"){
											zipIndex=s;
										}
										else if(data[record][r].value[v][s].fieldName == "emailId"){	
											var valobj = [data[record][r].value[v][s]]
											emailIdObj.push(valobj)
											data[record][r].value[v].splice(s,1)
										}
									}
								}
							}
						}
                        for(var n=0;n<newArry.length;n++){
                            newArry[n].splice(zipIndex+1,0,countryObj);
                            newArry[n].splice(countryIndex,1);
                        }
					}

					if(emailIdObj.length){
						data[record].push(
							{
								"fieldName": "Contact Email",
								"label": "Contact Email",
								"value": emailIdObj
							}
						)   
					}
				}
			}
			var orgIdAry = $scope.orgIds.split(",")
			var sortedData = [];
			for(var org in orgIdAry){
				for(var company in data){        
					if(company == orgIdAry[org]){
						sortedData.push(data[company])
					}
				}
			}
			data = sortedData;
			var subSectionArry = [];
			if(data && data.length){
				for(var d in data){
					var subSectionData = data[d].length ? data[d] : [""];

					for(var sub=0;sub<subSectionData.length;sub++){
										
						var subSectionName = subSectionData[sub].label;
						var subSectionValue = subSectionData[sub].value;
						var subSectionFeildId = subSectionData[sub].fieldId;
						
						if(d == Object.keys(data)[0] || !subSectionArry[sub] || (subSectionName && subSectionName.indexOf("Annual Turnover") != -1 && subSectionArry.filter(function(e) { return e.name === subSectionName; }).length == 0)){
							subSectionArry.push(
								{
									"name":subSectionName,
									"value":[]
								}
							)
						}
						if(subSectionArry[sub].length < subSectionData.length && subSectionArry.filter(function(e) { return e.name === subSectionName; }).length == 0){
							subSectionArry[sub].push(
								{
									"name":subSectionName,
									"value":[]
								}
							)
							var s = subSectionArry.length-1;
							if(subSectionArry[s].value.length < subSectionArry[0].value.length){
								for(var v=0;v<subSectionArry[0].value.length;v++){
									if(!subSectionArry[s].value[v])subSectionArry[s].value[v] = ""
								}
							}
						}
						if(!subSectionArry[0].name && (subSectionName && subSectionName.indexOf("Annual Turnover") != -1))
						subSectionArry.splice(0,1)

						if(!subSectionArry[0].name)
						subSectionArry[0].name = subSectionName;


						if(subSectionFeildId && subSectionFeildId == 257 && Object.keys(subSectionValue).length){
							subSectionValue = subSectionValue.name;
						}
		
						if(subSectionValue && typeof subSectionValue == "object" && subSectionValue != null){
							if(subSectionValue[0] && subSectionValue[0].length){
								var valArry = [];
								for(var a=0;a<subSectionValue.length;a++){
									for(var v=0;v<subSectionValue[a].length;v++){
										if(subSectionValue[a][v].value && Object.keys(subSectionValue[a][v].value).length != 0 && subSectionValue[a][v].value != "true" && subSectionValue[a][v].value != "false"){
											if(typeof subSectionValue[a][v].value =="object"){
												valArry.push(subSectionValue[a][v].value.name);
											}
											else{											
												if(subSectionName == 'Address' || subSectionName == 'Contact Email'){
                                                    valArry.push({'fieldName':subSectionValue[a][v].fieldName, value:subSectionValue[a][v].value});
                                                }
                                                else{
                                                    valArry.push(subSectionValue[a][v].value);
                                                }	
											}
										}										
									}
								}		
								if(subSectionName != 'Address' && subSectionName != 'Contact Email')	
								subSectionValue = valArry.join(", ");
							}
							else{
								if(subSectionValue.link)
								subSectionValue = subSectionValue.link;
								else{
									if(Object.keys({}).length == 0)
									subSectionValue = "";
								}										
							}
						}
						else{
							if(typeof subSectionValue != "string")
							subSectionValue = "";
						}        
		
						if(subSectionValue == "false")
							subSectionValue = "No";
						else if(subSectionValue == "true")
							subSectionValue = "Yes";

						var index = subSectionArry.findIndex(function(element, index){
							if (element.name === (subSectionName || ((subSectionArry[0].name && subSectionArry[0].name.indexOf("Annual Turnover") == -1) ? subSectionArry[0].name : false))) {
								return true
							}
						})

						if(subSectionData.length > 1){
							var subSecLengthAry = [], maxLength = 0, shiftValue = false;
							for(var s=0;s<subSectionArry.length;s++){	
								subSecLengthAry.push(subSectionArry[s].value.length)
							}

							maxLength = subSecLengthAry.reduce(function(a, b) { return Math. max(a, b); });
							for(var s=0;s<subSectionArry.length;s++){
								if(subSectionArry[s].value.length < maxLength){
									shiftValue = true;
									for(var m=0; m<maxLength;m++){
										if(!subSectionArry[s].value[m])
										subSectionArry[s].value[m] = "";
									}
								}
								if(subSectionArry[s].name == subSectionName){
									if(subSectionName && subSectionName.indexOf("Annual Turnover") != -1){
                                        for(var s=0;s<subSectionArry.length;s++){
                                            if(subSectionArry[s].value.length < sortedData.length){
                                                for(var v=0;v<sortedData.length;v++){
                                                    if(!subSectionArry[s].value[v])subSectionArry[s].value[v] = ""
                                                }
                                            }
                                        } 
                                        subSectionArry[index].value[d]=subSectionValue;
                                    }
                                    else{
                                        if(shiftValue)
                                        subSectionArry[index].value[subSectionArry[index].value.length - 1] = subSectionValue;
                                        else
                                        subSectionArry[s].value.push(subSectionValue);	
                                    }	
								}
							}
						}
						else{
							if(subSectionName && subSectionName.indexOf("Annual Turnover") != -1){
                                for(var s=0;s<subSectionArry.length;s++){
                                    if(subSectionArry[s].value.length < sortedData.length){
                                        for(var v=0;v<sortedData.length;v++){
                                            if(!subSectionArry[s].value[v])
											subSectionArry[s].value[v] = ""
                                        }
                                    }
                                }
                                subSectionArry[index].value[d]=subSectionValue;
                            }                            
                            else if(index != -1)
							subSectionArry[index].value.push(subSectionValue)
						}		
					}
				}
			}
			for(var s=0;s<subSectionArry.length;s++){
				if(subSectionArry[s].value.length < sortedData.length){
					for(var v=0;v<sortedData.length;v++){
						if(!subSectionArry[s].value[v])subSectionArry[s].value[v] = ""
					}
				}
				if(subSectionArry[0].name == "Registered Company Name"){
					for(var v=0;v<subSectionArry[0].value.length;v++){
						$scope.logos[v].title = subSectionArry[0].value[v]
					}
				}
			}
			if(subSectionArry[0].name)
			$scope.subSectionFields = subSectionArry;
			else 
			$scope.subSectionFields = undefined;		
			
			if(from){
				var obj = {};
				obj[currentSection]=$scope.subSectionFields;
				$scope.printSectionArry.push(obj);
				
				if($scope.printSectionArry.length<$scope.subSections.length){
					$scope.toggleSelection($scope.subSections[$scope.printSectionArry.length],"initialLoad");
				}
				else{
					if(!$scope.finalPrintArry){
						$scope.updatePrintArry();
					}
				}				
			}
			
			if(currentSection){
				for(var i=0;i<$scope.subSections.length;i++){
					if($scope.subSections[i].label == currentSection)
					$scope.subSections[i].value = $scope.subSectionFields
				}
			}
		}
		function chunk(array, chunkSize) {
			var chunkCount = Math.ceil(array.length / chunkSize);
			var chunks = new Array(chunkCount);
			for(var i = 0, j = 0, k = chunkSize; i < chunkCount; ++i) {
				chunks[i] = array.slice(j, k);
				j = k;
				k += chunkSize;
			}
			return chunks;
		}
		$scope.updatePrintArry = function(){
			var printLogos = chunk($scope.logos,4);
			var logoObj = [];
			for(var l=0;l<printLogos.length;l++){
				var logo = {"logos": {}};
				logo["logos"]["logos"] = printLogos[l];
				logoObj.push(logo);
			}
			var allSections = $scope.printSectionArry;
			var tempAry = [],sectionName,subSectionName,finalAllSectionAry = [],subSectionVal,subsection;
			for(var i=0;i<allSections.length;i++){
				sectionName = Object.keys(allSections[i])[0];
				subsection = allSections[i][Object.keys(allSections[i])];
				
				if(subsection && subsection.length){
					for(var a=0;a<subsection.length;a++){
						subSectionName = subsection[a].name;
						subSectionVal = subsection[a].value						
						if(subSectionVal && subSectionVal.length){			
							tempAry = chunk(subSectionVal, 4);	
							for(var t=0;t<tempAry.length;t++){
								var emptyVal = true;
								for(var e=0;e<tempAry[t].length;e++){
									if(tempAry[t][e])
									emptyVal = false;
								}
								if(emptyVal && sectionName.indexOf("Annual Turnover") == -1){
									var tempObj = {};
									tempObj[sectionName] = undefined;
									if (subsection.length > 1 && finalAllSectionAry[i] && finalAllSectionAry[i].length) {
                                        finalAllSectionAry[i][t] = tempObj;
                                    } else {
                                        (finalAllSectionAry[i] && finalAllSectionAry[i].length) ? finalAllSectionAry[i].push(tempObj) : finalAllSectionAry[i] = [tempObj]
                                    }									
								}
								else{
									var tempObj = {};
									tempObj[sectionName] = {};
									tempObj[sectionName][subSectionName]= tempAry[t];
									if(subsection.length>1 && finalAllSectionAry[i] && finalAllSectionAry[i].length == tempAry.length){
										finalAllSectionAry[i][t][sectionName][subSectionName] = tempAry[t];
									}
									else{
										(finalAllSectionAry[i] && finalAllSectionAry[i].length) ? finalAllSectionAry[i].push(tempObj) : finalAllSectionAry[i] = [tempObj];
									}
								}
							}
						}
					}
				}
				else{
					finalAllSectionAry[i]={};
					finalAllSectionAry[i][sectionName] = undefined;
				}

			}
			finalAllSectionAry.unshift(logoObj);
			var loopedAry = [];
			for(var f=0;f<finalAllSectionAry.length;f++){
				for(var c=0;c<tempAry.length;c++){
					if(loopedAry.length<=tempAry.length){
						if(!loopedAry[c])loopedAry[c] = [];
						if(finalAllSectionAry[f][c])
						loopedAry[c].push(finalAllSectionAry[f][c])
						else
						loopedAry[c].push(finalAllSectionAry[f])
					}					
				}
			}
			
			$scope.finalPrintArry = loopedAry;
		}
		$scope.showRemoveDialog = function(item){
			$scope.showRemovePopup = true;
			$scope.removeOrg = item;
		}
		$scope.setIframeHeight = function(){
			var editORI = document.getElementById("editORI");
			if(editORI && editORI.value == "true"){
				var obj = { 'message': 'viewFormIframe', 'companies': $scope.companiesLength};
				window.top.postMessage(JSON.stringify(obj), "*");
			}
			else{
				var obj = { 'message': 'createFormIframe'};
				window.top.postMessage(JSON.stringify(obj), "*");
			}
		}
		//delete company row
		$scope.removeRow = function(close){		
			$scope.showRemovePopup = false;
			
			if(close) return;

			for(var org in $scope.repeatingTable){
				if($scope.repeatingTable[org].orgId == $scope.removeOrg.orgId){
					$scope.repeatingTable.splice(org,1);
					$scope.setIframeHeight();
				}
			}
		}
		
		//closes the tender list form popup 
		$scope.closeForm = function(close){			
			var obj = { 'message': 'closeBidLsitModal' };
			if(close)
			obj = { 'message': 'closeModalOnly' };

			window.top.postMessage(JSON.stringify(obj), "*");
		}
		$scope.restrictToNum = function(type,val){
			if(val){
				var checkChars = /[^0-9.,]/gi;
				if(val.split(".").length>2){
					val = val.substring(0, val.lastIndexOf(".")) +"" +val.substring(val.lastIndexOf(".") + 1);
				}			
				if(checkChars.test(val)) {
					val = val.replace(checkChars,"");
				}
				if(type == "budget")
				$scope.budget = val;
				else if(type == "estimate")
				$scope.estimate = val;
			}
		}
		$scope.convertNum = function(type,val){
			if(val){
				if(Number(val) == 0){
					var msg;
					if(type == "budget")
					msg = "Please enter a value greater than 0 for Work package budget";
					else if(type == "estimate")
					msg = "Please enter a value greater than 0 for Pre-bid estimate";

					Notification.error({ title: 'Alert', message: msg })
					return;
				}
				val = Number(val.replaceAll(",",""));
				if(type == "budget")
				$scope.budget = new Intl.NumberFormat("en", {minimumFractionDigits: 2,maximumFractionDigits: 2}).format(val);
				else if(type == "estimate")
				$scope.estimate = new Intl.NumberFormat("en", {minimumFractionDigits: 2,maximumFractionDigits: 2}).format(val);
			}
		}
		$scope.printForm = function(){
			angular.element(".close-icon,.thread-header,.button-toggle,.hideOnPrint").hide();
			angular.element(".showOnPrint").show();
			angular.element("title").remove();
			var obj = { 'message': 'printBidList' };
			window.top.postMessage(JSON.stringify(obj), "*");
			setTimeout(function(){						
				window.print();
				angular.element(".close-icon,.thread-header,.button-toggle,.hideOnPrint").show();
				angular.element(".showOnPrint").hide();
			},200)
		}
		function numRound(num) {
			num = Math.abs(Number(num))
			const billions = num/1.0e+9
			const millions = num/1.0e+6
			const thousands = num/1.0e+3
			return num >= 1.0e+9 && billions >= 100  ? Math.round(billions)  + "B"
				 : num >= 1.0e+9 && billions >= 10   ? billions.toFixed(1)   + "B"
				 : num >= 1.0e+9                     ? billions.toFixed(2)   + "B"
				 : num >= 1.0e+6 && millions >= 100  ? Math.round(millions)  + "M"
				 : num >= 1.0e+6 && millions >= 10   ? millions.toFixed(1)   + "M"
				 : num >= 1.0e+6                     ? millions.toFixed(2)   + "M"
				 : num >= 1.0e+3 && thousands >= 100 ? Math.round(thousands) + "K"
				 : num >= 1.0e+3 && thousands >= 10  ? thousands.toFixed(1)  + "K"
				 : num >= 1.0e+3                     ? thousands.toFixed(2)  + "K"
				 : num.toFixed()
		}
	}
	return FormController;
});