/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/number-format', '../components/table.util', '../components/item.selection'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        var projectId = $window.hashprojectId || $window.hashedprojectid || $window.viewerProjectId || $window.currProjId;
        if (projectId == "null")
            projectId = $window.currProjId;
        var currentViewName = $window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.serverDate = "";
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;
        });
 
        var dateFormatMap = {
            "en_GB": "dd-M-yy",
            "fr_FR": "d M yy",
            "es_ES": "dd-M-yy",
            "ru_RU": "dd.mm.yy",
            "en_AU": "dd/mm/yy",
            "en_CA": "d-M-yy",
            "en_US": "M d, yy",
            "zh_CN": "yy-m-d",
            "de_DE": "dd.mm.yy",
            "ga_IE": "d M yy",
            "en_ZA": "dd M yy",
            "ja_JP": "yy/mm/dd",
            "ar_SA": "dd/mm/yy",
            "en_IE": "dd-M-yy",
            "nl_NL": "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || 'dd/mm/yy';

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        var contractDataArray = [];
        var costCodeDataArray = [];
        var linkFormDataArray = [];

        var TFL_CONSTANT = {
            db_date_format: "yy-m-d",
            defaultLogo: "images/asite.gif",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondActionDays: 5,

            // Configurable Attribute keys
            confAttrClientLogo: "Client Logo",

            //Static Status used in Forms
            accepted: "Accepted",
            acceptedWithComments: "Accepted With Comments",
            submittedForInformation: "Submitted for Information",
            forInformation: "For Information",
            forAcceptance: "For Acceptance",
            respond: "Respond",
            openStatus: "Open",
            subjectToChangeAppraisal: "Subject to Change Appraisal",
            icaRaised: "ICA raised",
            subjectToConfirmationNotice: "Subject to Change Confirmation Notice",
            acceptQuote: "Accept Quote",
            reviseAndResubmit: "Revise and Resubmit",
            WithdrawnPCN: "Withdraw PCN",
            Withdrawn: 'Withdrawn',
            subjectToICA: "Subject to ICA",

            // Static Action Number require to send action to users
            respondNumber: "3#",
            forInfoNumber: "7#",

            // Appbuidler codes of forms
            changeAppraisal: "TFL-DTUP-MCA",
            supplierChangeNotice: "TFL-DTUP-MCN",
            projectChangeNotice: "TFL-DTUP-PCN",
            changeAppraisalInstruction: "TFL-DTUP-PCAI",
            changeConfirmNotice: "TFL-DTUP-PCCN",
            initChangeAppraisal: "TFL-DTUP-MICA",
            compensationEvent: "TFL-DTUP-MCE",

            // Static role used in Code
            tflRepresentative: "TFL Representative",
            projectManager: "Project Manager",
            contractor: "Contractor",

            // Data source 
            dsSttNnecSetupSections: "DS_DTUP_SETUP_SECTIONS",
            dsSttNnecNecContractSummary: "DS_DTUP_NEC_CONTRACT_ACTIVITY_SUMMARY",
            dsSttNnecSectionUsers: "DS_DTUP_SECTION_USERS",
            dsSttNnecSecLck: "DS_DTUP_SEC_LCK",
            dsSttNnecAllContractTeamMembers: "DS_DTUP_ALL_CONTRACT_TEAM_MEMBERS",
            dsSttNnecGetFormDetailsByStatus: "DS_DTUP_GET_FORM_DETAILS_BY_STATUS",
            dsAllActiveWsStatus: "DS_ALL_ACTIVE_WS_STATUS",
            dsAsiGetCurrencyFromContract: "DS_ASI_GET_CURRENCY_FROM_CONTRACT",
            dsSttNecKeyContractDates: "DS_DTUP_NEC_KEY_CONTRACT_DATES"
        }
 
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

       
        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.asiteSystemDataReadwrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.arrCostOptionGroup = $scope.oriMsgCustomFields["costOptionGroup"];
        $scope.arrSectionDetailGroups = $scope.oriMsgCustomFields["sectionDetailGroups"];
        $scope.Programme_Key_Details = $scope.oriMsgCustomFields["Programme_Key_Dates"]["Programme_Key_Details"];
        $scope.Provisional_Acc_Details = $scope.oriMsgCustomFields["Provisional_Acc"]["Provisional_Acc_Details"];
        $scope.Final_Acc_Details = $scope.oriMsgCustomFields["Final_Acc"]["Final_Acc_Details"];
        $scope.Fleet_Acc_Details = $scope.oriMsgCustomFields["Fleet_Acc"]["Fleet_Acc_Details"]; 
        var dsSttBlNnecNecOrgConctract = $scope.getValueOfOnLoadData('DS_DTUP_NEC_ORG_CONTRACT');
        var dsProjUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var dsProjDistUsers = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var dsFormActions = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var dsAllActiveWsStatus = $scope.getValueOfOnLoadData(TFL_CONSTANT.dsAllActiveWsStatus);
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_INCOMPLETE_MSG_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
        $scope.linkContractURL = $scope.getValueOfOnLoadData('DS_DTUP_NEC_CONTRACT');
        var dsWorkingUserId = $scope.getWorkingUserId();

        var dsALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        $scope.formCustomFields.formData.appBuilderCode = dsALLFormSettings && dsALLFormSettings[0] && dsALLFormSettings[0].Value6.split(":")[1].trim();

        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            $scope.isConSelected = false;
            $scope.dropdownObj = {
                contractList: [],
                tflReprentList: [],
                distSectionsList: [],
                sectionsList: [],
                distUsersList: [],
                formActionList: [],
                contractorList: [],
                linkFormList: [],
                statusList: [],
                optionsList: []
            };

            fillDropwdowns();
            initFormData();
            $scope.update();
        } else {
            $scope.linkFielURL = $scope.getValueOfOnLoadData('DS_DTUP_GET_URL_DETAILS');
            $scope.linkFielURL = $scope.linkFielURL[0] && $scope.linkFielURL[0].URL;

            for (var i = 0; i < $scope.linkContractURL.length; i++) {

                if ($scope.linkContractURL[i] && $scope.linkContractURL[i].Value && $scope.linkContractURL[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.linkContractURL = $scope.linkContractURL[i].URL;
                    break;
                }
            }

            $scope.update();
        }


        /**
         * @param{ Array } repeatingData : repeating Array where to insert new Row/Object
         * @param{ String } objKeyName : key name of STATIC_OBJ_DATA , which are added as new node
         */
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);

            if (objKeyName == "costOptions") {
                var newOptionNumber = repeatingData.length + 1;
                newRowObject.optionName = "Option " + newOptionNumber;
                newRowObject.CostcodeGroup.Costcode[0].ccGuId = "Option " + newOptionNumber
            }

            if (objKeyName == "Costcode") {
                newRowObject.ccGuId = repeatingData[0].ccGuId;
            }

            repeatingData.push(newRowObject);

            $timeout(function () {
                var bodypartObj = document.getElementById('tbl_' + objKeyName);

                if (bodypartObj) {
                    var scrollStr = bodypartObj.scrollHeight;
                    bodypartObj.scrollTop = scrollStr;
                }
            });

            $scope.expandTextAreaOnLoad();
        };



        var STATIC_OBJ_DATA = {
            Programme_Key_Details: {
                Programme_Key_Date: "",
                Programme_Accepted: "",
                Programme_Proposed: "",
                Programme_Variance: ""
            },
            Provisional_Acc_Details: {
                Provisional_Accepted: "",
                Provisional_Proposed: "",
                Provisional_Variance: ""
            },
            Final_Acc_Details: {
                Final_Accepted: "",
                Final_Proposed: "",
                Final_Variance: ""
            },
            Fleet_Acc_Details: {
                Fleet_Accepted: "",
                Fleet_Proposed: "",
                Fleet_Variance: ""
            }
        }

 
        $scope.tableUtilSettings = {
            Programme_Key_Details: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon:  { 
                    editRow : 0,
                    deleteAllRow: 0,
                    insertBefore : 0,
                    insertAfter : 0,
                },
                checkboxModelKey: "Programme_Key_isSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Programme_Key_Details),
                deleteItemCallBack: deleteRowCallbackAppliedvalue
             },
             Provisional_Acc_Details: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon:  { 
                    editRow : 0,
                    insertBefore : 0,
                    deleteAllRow: 0,
                    insertAfter : 0,
                },
                checkboxModelKey: "Provisional_Acc_isSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Provisional_Acc_Details),
                deleteItemCallBack: deleteRowCallbackProvision
             },
             Final_Acc_Details: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon:  { 
                    editRow : 0,
                    deleteAllRow: 0,
                    insertBefore : 0,
                    insertAfter : 0,
                },
                checkboxModelKey: "Final_Acc_isSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Final_Acc_Details),
                deleteItemCallBack: deleteRowCallbackFinal
             },
             Fleet_Acc_Details: {
                tooltip: "select to remove data",
                hasDefaultRecord: true,
                hideControlIcon:  { 
                    editRow : 0,
                    deleteAllRow: 0,
                    insertBefore : 0,
                    insertAfter : 0,
                },
                checkboxModelKey: "Fleet_Acc_isSelected",
                newStaticObject : angular.copy(STATIC_OBJ_DATA.Fleet_Acc_Details),
                deleteItemCallBack: deleteRowCallbackFleet
             }
         }

        function deleteRowCallbackAppliedvalue() {
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.Programme_Key_Details,
                    calcKey: 'Programme_Variance',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'var_total_amount'
                });
            }, 100);
        } 
        function deleteRowCallbackProvision() {
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.Provisional_Acc_Details,
                    calcKey: 'Provisional_Variance',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'Perovis_total_amount'
                });
            }, 100);
        }
        function deleteRowCallbackFinal() {
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.Final_Acc_Details,
                    calcKey: 'Final_Variance',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'Final_total_amount'
                });
            }, 100);
        }
        function deleteRowCallbackFleet() {
            $timeout(function () {
                $scope.calcFieldTotal({
                    repData: $scope.Fleet_Acc_Details,
                    calcKey: 'Fleet_Variance',
                    parObject: $scope.oriMsgCustomFields,
                    totalKey: 'Fleet_total_amount'
                });
            }, 100);
        }
 


        $scope.onContractChange = onContractChange;
        function onContractChange() {
            var contractNumber = $scope.oriMsgCustomFields['ContractNo'];
            if (contractNumber) {
                var changeAppraisalFor = $scope.oriMsgCustomFields['changeType'];
                var tempConAppCode = commonApi._.filter(contractDataArray, function (mapObj) {
                    return mapObj.contractID == contractNumber;
                })[0];

                if ($scope.linkContractURL.length) {
                    if ($scope.linkContractURL.length && tempConAppCode.contractAppCode) {
                        var notesObj = commonApi._.filter($scope.linkContractURL, function (val) {
                            return val.Value.split('|')[0].trim() == tempConAppCode.contractAppCode.trim();
                        });
                        if (notesObj.length) {
                            var strValue = notesObj[0].Name,
                                strNotes = strValue.split('|')[3].trim()
                            if (strNotes) {
                                $scope.asiteSystemDataReadwrite.Dist_Guidance_Notes = strNotes;
                            }    
                        }
                    }    
                }

                loadClientLogo(tempConAppCode);
                tempConAppCode = tempConAppCode && tempConAppCode.contractAppCode;

                if (tempConAppCode) {
                    $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = tempConAppCode;
                    var spParam = {
                        dataSourceArray: [{
                            "fieldName": TFL_CONSTANT.dsSttNnecSetupSections,
                            "fieldValue": tempConAppCode + "," + $scope.formCustomFields.formData.appBuilderCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNnecNecContractSummary,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNnecAllContractTeamMembers,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsAsiGetCurrencyFromContract,
                            "fieldValue": tempConAppCode
                        }, {
                            "fieldName": TFL_CONSTANT.dsSttNecKeyContractDates,
                            "fieldValue": tempConAppCode
                        }],

                        successCallback: contractChangeCallback
                    };

                    $scope.getCallbackSPdata(spParam);
                }
            } else {
                alert('Please select Contract');
                $scope.oriMsgCustomFields['changeType'] = "";
            }
        }

        $scope.onDaysChange = function(enteredDaysNode, ContractDaysNode, replyDateNode) {
            var enteredDays = $scope.oriMsgCustomFields[enteredDaysNode];
            var contractDays = $scope.oriMsgCustomFields[ContractDaysNode];
            if ((enteredDays && contractDays && parseInt(enteredDays) < parseInt(contractDays)) || (!enteredDays && contractDays)) {
                alert("Entered days cannnot be less than contract days");
                $scope.oriMsgCustomFields[enteredDaysNode] = $scope.oriMsgCustomFields[ContractDaysNode];
            }
            var replyDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days : $scope.oriMsgCustomFields[enteredDaysNode]
            });
            $scope.oriMsgCustomFields[replyDateNode] = replyDate;
        }


        $scope.onSectionChange = function (strVal) {

            if (strVal) {
                var strParam = $scope.oriMsgCustomFields.CON_AppBuilderId + "," + strVal.split('#')[0].trim() + "," + $scope.formCustomFields.formData.appBuilderCode;
                var spParam = {
                    dataSourceArray: [{
                        "fieldName": TFL_CONSTANT.dsSttNnecSectionUsers,
                        "fieldValue": strParam
                    }, {
                        "fieldName": TFL_CONSTANT.dsSttNnecSecLck,
                        "fieldValue": strParam
                    }],
                    successCallback: sectionChangeCallback
                };

                $scope.getCallbackSPdata(spParam);
            }
        }

        /**
         * To Clear all objection checkbox on change objection ye/no
         */
        $scope.icaObjectCheckChange = function () {
            $scope.oriMsgCustomFields['objectionFlags']['Illegal'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['Contravene'] = 'No';
            $scope.oriMsgCustomFields['objectionFlags']['Technically'] = 'No';
        }

        // To create ICA form form PCN
        $scope.launchICAForm = function () {
            $window.launchCreateForm(TFL_CONSTANT.initChangeAppraisal);
        }

        // To reset cost optins while check/uncheck TFL agree flag
        $scope.resetCostOption = function () {
            $scope.oriMsgCustomFields['costOption'] = ""
        }

        // To fill cost code dropdown while selecting sections in CA and ICA
        $scope.fillConstCodes = function (currObj) {
            var strSecname = commonApi._.filter(costCodeDataArray, function (val) {
                return val.Value3 == currObj.sections;
            });

            currObj.Section_Name = strSecname[0] && strSecname[0].Value4 || "";

            currObj.costCodes = "";

            currObj.costList = commonApi.getItemSelectionList({
                arrayObject: strSecname,
                groupNameKey: "",
                modelKey: "Value14",
                displayKey: "Value14"
            });
        }

        // on Activity change
        $scope.onActivityChange = function (currObj, repeatingObj, $index) {
            for (var i = 0; i < repeatingObj.length; i++) {
                if (currObj.costCodes && currObj.sections && i != $index &&
                    repeatingObj[i].sections == currObj.sections && repeatingObj[i].costCodes == currObj.costCodes) {
                    alert("Section and Activity should not be same. please select different activity");
                    currObj.costCodes = "";
                    var strSecname = commonApi._.filter(costCodeDataArray, function (val) {
                        return val.Value3 == currObj.sections;
                    });
                    currObj.costList = commonApi.getItemSelectionList({
                        arrayObject: strSecname,
                        groupNameKey: "",
                        modelKey: "Value14",
                        displayKey: "Value14"
                    });
                }
            }
        }

        $scope.onTFLAgreeChange = function () {
            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
            if ($scope.oriMsgCustomFields['projCoObjFlag'] == 'No') {
                if ($scope.oriMsgCustomFields['isTFLagreed'] == 'Yes') {
                    var statusIds = $scope.getFormStatus({
                        spName: TFL_CONSTANT.dsAllActiveWsStatus,
                        status: TFL_CONSTANT.subjectToChangeAppraisal
                    });
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
                    $scope.oriMsgCustomFields.costOption = "";
                }
            }
        }

        function fillDropwdowns() {

            // Contract downdown

            for (var i = 0; i < dsSttBlNnecNecOrgConctract.length; i++) {
                var element = dsSttBlNnecNecOrgConctract[i];
                element = element.Value ? element.Value.split('|') : [];
                if (element.length) {
                    contractDataArray.push({
                        contractID: element[2].trim(),
                        contractorLogo: element[4].trim(),
                        clientLogo: element[5].trim(),
                        contractName: element[8].trim(),
                        contractAppCode: element[0].trim(),
                        contractIdName: dsSttBlNnecNecOrgConctract[i].Name
                    });
                }
            }

            $scope.dropdownObj.contractList = commonApi.getItemSelectionList({
                arrayObject: contractDataArray,
                groupNameKey: "",
                modelKey: "contractID",
                displayKey: "contractIdName"
            });


            // TFL Reprensetative downdown
            var tflRepresentativeArray = [];
            for (var i = 0; i < dsProjUserRole.length; i++) {
                var element = dsProjUserRole[i];
                if (element.Value.indexOf(TFL_CONSTANT.tflRepresentative) > -1) {
                    tflRepresentativeArray.push({
                        userName: element.Name,
                        userID: element.Value
                    });
                }
            }

            $scope.dropdownObj.tflReprentList = commonApi.getItemSelectionList({
                arrayObject: tflRepresentativeArray,
                groupNameKey: "",
                modelKey: "userID",
                displayKey: "userName"
            })

            $scope.dropdownObj.distUsersList = commonApi.getItemSelectionList({
                arrayObject: dsProjDistUsers,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });


          
            $scope.dropdownObj.formActionList = commonApi.getItemSelectionList({
                arrayObject: dsFormActions,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            });


            $scope.dropdownObj.optionsList = commonApi.getItemSelectionList({
                arrayObject: $scope.arrCostOptionGroup['costOptions'],
                groupNameKey: "",
                modelKey: "optionName",
                displayKey: "optionName"
            });

            setActionDropdownList($scope.oriMsgCustomFields['isTFLagreed']);
        }

        function setActionDropdownList(tflAgreFlag) {
            // Dropdown for Status list in RES_VIEW
            var tempStatuses = [];
            if (tflAgreFlag == 'No') {
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus, function (obj) {
                    return (obj.Name == TFL_CONSTANT.Withdrawn || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            } else {
                tempStatuses = commonApi._.filter(dsAllActiveWsStatus, function (obj) {
                    return (obj.Name == TFL_CONSTANT.subjectToChangeAppraisal || obj.Name == TFL_CONSTANT.Withdrawn || obj.Name == TFL_CONSTANT.acceptQuote || obj.Name == TFL_CONSTANT.reviseAndResubmit);
                });
            }
            $scope.dropdownObj.statusList = commonApi.getItemSelectionList({
                arrayObject: tempStatuses,
                groupNameKey: "",
                modelKey: "Value",
                displayKey: "Name"
            })
        }

        // To reset Option Index while remove CostOptions
        function optionIndexReset() {
            $timeout(function () {
                var costOptions = $scope.arrCostOptionGroup['costOptions'];
                for (var i = 0; i < costOptions.length; i++) {
                    costOptions[i].optionName = "Option " + (i + 1);
                }
            }, 200);
        }
        function strIsUserDraftOnly(strMatch, data) {
            if (data.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < data.length; i++) {
                    strValue = data[i].Value.split('|');
                    strRole = strValue[1].trim();
                    if (strRole.toLowerCase() == strMatch) {
                        strTmpEmpId = strValue[2].split('#')[0].trim();
                        if (strTmpEmpId == dsWorkingUserId)
                            return "Yes";
                    }
                }
            }
            return "No";
        }
        function setSendPermission(strVal) {
            var strMsg = "0";
            if (strVal.toLowerCase() == "draft") {
                strMsg = "1| You are only allowed to create Drafts for this Contract. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
            }
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
        }

        /**
         * Load clients logo from selected Contracts
         * Store that data in data modal to display in PRINT_VIEW using thymeleaf
         */
        function loadClientLogo(tempConAppCode) {
            $scope.oriMsgCustomFields.contractorLogo = tempConAppCode.contractorLogo || TFL_CONSTANT.defaultLogo;
            $scope.oriMsgCustomFields.clientLogo = tempConAppCode.clientLogo || TFL_CONSTANT.defaultLogo;
        }

        /**
         * function called after get Dsitribution data while selection sections
         * @param {Object} spDataList : data source object from SP 
         */
        function sectionChangeCallback(spDataList) {

            var sectionUsersData = spDataList[TFL_CONSTANT.dsSttNnecSectionUsers];
            var distLockflag = spDataList[TFL_CONSTANT.dsSttNnecSecLck];

            if (distLockflag.length) {
                $scope.oriMsgCustomFields.Distribution_Section.isDS_Locked = distLockflag[0].Name.trim();
            }

            var tempList = [];
            for (var i = 0; i < sectionUsersData.length; i++) {
                var nodeVal = sectionUsersData[i];
                nodeVal = nodeVal.Value.split('|');
                var distDate = (nodeVal[4] && nodeVal[4].split('#')[0]) ? nodeVal[4].split('#')[0].trim() : 3;
                if (distDate) {
                    distDate = commonApi.calculateDistDateFromDays({
                        baseDate: $scope.serverDate,
                        days: parseInt(distDate.trim())
                    })
                }

                var strMatchAction = nodeVal[2].trim() + '#' +nodeVal[3].trim() || "";
                var strAction = commonApi._.filter(dsFormActions, function (obj) {
                    return obj.Value.indexOf(strMatchAction) > -1;
                });

                strAction = strAction[0] && strAction[0].Value || "";
                var userName = nodeVal[1] && nodeVal[1].replace(' ,', ',');
                tempList.push({
                    strUser: nodeVal[0].trim() + "#" + userName.trim(),
                    strAction: strAction, //"7#For Information",
                    strDate: distDate
                });
            }

            commonApi.setDistributionNode({
                actionNodeList: tempList,
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: 3
            });
        }

        /**
         * function called after get Sections data while selection contract
         * @param {Object} responseList : data source object from SP 
         */
        function contractChangeCallback(responseList) {
            $scope.isConSelected = true;
            // Sections dropdown data based on setup form
            if (responseList[TFL_CONSTANT.dsSttNnecSetupSections]) {
                $scope.dropdownObj.distSectionsList = commonApi.getItemSelectionList({
                    arrayObject: responseList[TFL_CONSTANT.dsSttNnecSetupSections],
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }
            var contractCurrency = responseList[TFL_CONSTANT.dsAsiGetCurrencyFromContract];
            if (contractCurrency) {
                $scope.oriMsgCustomFields['currency'] = contractCurrency[0].Value2.trim();
            }

            // Contract Activity Summry Data
            costCodeDataArray = responseList[TFL_CONSTANT.dsSttNnecNecContractSummary]
            var tempCostCodeDataArray = angular.copy(costCodeDataArray);
            if (tempCostCodeDataArray.length) {
                tempCostCodeDataArray = commonApi._.uniq(tempCostCodeDataArray, 'Value3');
                $scope.dropdownObj.sectionsList = commonApi.getItemSelectionList({
                    arrayObject: tempCostCodeDataArray,
                    groupNameKey: "",
                    modelKey: "Value3",
                    displayKey: "Value18"
                })
            }

            // Contractor Data list
            var contractTeamMemberList = responseList[TFL_CONSTANT.dsSttNnecAllContractTeamMembers]
            if (contractTeamMemberList.length) {
                var matchRole = TFL_CONSTANT.projectManager
                var tempVal = [],
                    tempNode = [];
                for (var i = 0; i < contractTeamMemberList.length; i++) {
                    var element = contractTeamMemberList[i];
                    var roleName = element.Value.split('|')[1].trim();
                    if (tempVal.indexOf(element.Value) == -1 && roleName == matchRole) {
                        tempNode.push(element);
                        tempVal.push(element.Value);
                    }
                }

                $scope.dropdownObj.contractorList = commonApi.getItemSelectionList({
                    arrayObject: tempNode,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }

            var strPcnNumberCode = $scope.oriMsgCustomFields['PCN_AppNumber_LaunchButton'];
            if (strPcnNumberCode) {
                $scope.pcnListChange('pcnNumber', 'OnloadAutoLoadFlag');
                for (var i = 0; i < linkFormDataArray.length; i++) {
                    if (linkFormDataArray[i].pcnNo == strPcnNumberCode) {
                        $scope.oriMsgCustomFields.pcnNumber = linkFormDataArray[i].pcnTitle;
                        break;
                    }
                }
            }

            // Contractor response days Data list
            var contractResponseDaysList = responseList[TFL_CONSTANT.dsSttNecKeyContractDates]
            if (contractResponseDaysList.length) {
                $scope.oriMsgCustomFields['ICA_TFL_Reply_Days'] = contractResponseDaysList[4].Value4;
                $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'] = contractResponseDaysList[3].Value4;
                $scope.oriMsgCustomFields['ICA_TFL_Reply_Days_Backup'] = contractResponseDaysList[4].Value4;
                $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days_Backup'] = contractResponseDaysList[3].Value4;
                var replyDate = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days : contractResponseDaysList[4].Value4
                });
                var replyDateResponse = commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days : contractResponseDaysList[3].Value4
                });                
                $scope.oriMsgCustomFields['Reply_Date'] = replyDate;
                $scope.oriMsgCustomFields['Reply_Date_Response'] = replyDateResponse;
            }
            var chkPermission = strIsUserDraftOnly("draft only", responseList[ TFL_CONSTANT.dsSttNnecAllContractTeamMembers ]);
            if (chkPermission.toLowerCase() == "yes")
                setSendPermission("Draft");
            else
                setSendPermission("Send");

        } 

		function CheckPendingAction(strUser) {
		    //check user have any pending action of not
		    var IsAction = false;
		    var strLastMsgId = $scope.oriMsgCustomFields.DSI_PreviousMsgId;
		    DS_INCOMPLETE_ACTIONS_BYMSG = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
		        return val.Value4 == "Respond";
		    });
		    if (DS_INCOMPLETE_ACTIONS_BYMSG) {
		        var strUserId = DS_INCOMPLETE_ACTIONS_BYMSG[0] && DS_INCOMPLETE_ACTIONS_BYMSG[0].Value1;
		        var strMsgId = DS_INCOMPLETE_ACTIONS_BYMSG[0] && DS_INCOMPLETE_ACTIONS_BYMSG[0].Value3;
		        if (strUserId) {
		            if (strUserId && strUserId == strUser.trim() && strLastMsgId == strMsgId) {
		                return true;
		            }
		        }
		    }
		    return IsAction;
		}


        /**
         * Initialize all form data on load
         */
        function initFormData() {
            if ($scope.oriMsgCustomFields['ContractNo'] && currentViewName == "ORI_VIEW") {
                onContractChange();
            }
            $scope.notAllow = true;
            $scope.notAllowMessage = "";
            $scope.oriMsgCustomFields.DSI_PreviousMsgId = DS_INCOMPLETE_MSG_ACTIONS.length ? DS_INCOMPLETE_MSG_ACTIONS[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId;
            if (currentViewName == "RES_VIEW") {
                var isrequired = CheckPendingAction($scope.getWorkingUserId());
                if (isrequired == false) {
                    //if not than dont allow to edit
                    $scope.notAllowMessage = "You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    $scope.notAllow = false;
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not allowed to respond this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
                    return;
                } else {
                    $scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
                }
                $scope.isRespond = true;
                $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

                if ($scope.oriMsgCustomFields['stageFlow'] == 0) {
                    onContractChange();
                    $scope.oriMsgCustomFields['Comment'] = "";
                } else {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = "";
                    $scope.oriMsgCustomFields['PM_Comment'] = "";
                }

            } else {
                $scope.oriMsgCustomFields.Originator_Id = $scope.getWorkingUserId();
            }
        }


        /**
         * @param {Integer} distNumber : it defines DS_AUTODISTRIBUTE value which require to send auto distribute
         * it will be 3 for OR and 13 for Respond 
         */
        function setDistributionNodeForPM(distNumber) {
            var actionStr = TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond;

            setAutoDistributeNode({
                autoDistFlag: distNumber,
                action: actionStr,
                days: $scope.oriMsgCustomFields['ICA_TFL_Reply_Days'],
                users: $scope.oriMsgCustomFields['TFL_Representative'].split('|')[2].trim()
            });
        }

        function setDistributionNodeForContractor() {
            var tmpUserID = commonApi._.filter(dsProjUserRole, function (obj) {
                return obj.Value.indexOf($scope.oriMsgCustomFields.Originator_Id) > -1;
            })[0];

            tmpUserID = tmpUserID.Value && tmpUserID.Value.split('|')[2].trim();
            if (tmpUserID) {
                tmpUserID = tmpUserID.split('#');
                $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                setAutoDistributeNode({
                    action: TFL_CONSTANT.respondNumber + TFL_CONSTANT.respond,
                    autoDistFlag: TFL_CONSTANT.resDistNumb,
                    days: $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'],
                    users: tmpUserID[0].trim() + "#" + tmpUserID[1].trim()
                });
            }
        }

        function setForInfoDistributionNodeForContractor() {
            var tmpUserID = commonApi._.filter(dsProjUserRole, function (obj) {
                return obj.Value.indexOf($scope.oriMsgCustomFields.Originator_Id) > -1;
            })[0];

            tmpUserID = tmpUserID.Value && tmpUserID.Value.split('|')[2].trim();
            if (tmpUserID) {
                tmpUserID = tmpUserID.split('#');
                $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                setAutoDistributeNode({
                    action: TFL_CONSTANT.forInfoNumber + TFL_CONSTANT.forInformation,
                    autoDistFlag: TFL_CONSTANT.resDistNumb,
                    days: $scope.oriMsgCustomFields['ICA_Contractor_Reply_Days'],
                    users: tmpUserID[0].trim() + "#" + tmpUserID[1].trim()
                });
            }
        }

        /**
         * 
         * @param {String} param.action : pass action name like For Information/Respond
         * @param {Interger} param.days : pass days in number which indicates due date
         * @param {String} param.user : set User id which you want to send action
         * @param {Interger} param.autoDistFlag : this flag vary distribution ORI and RES view
         */
        function setAutoDistributeNode(param) {
            var actionStr = param.action;
            var days = param.days;
            var users = param.users;
            var autoDistFlag = param.autoDistFlag

            var distDate = commonApi.calculateDistDateFromDays({
                baseDate: $scope.serverDate,
                days: days
            });

            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: users,
                    strAction: actionStr,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadwrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadwrite,
                DS_AUTODISTRIBUTE: autoDistFlag
            });
        }

        function estimateCostTotalOnDelete() {
            $timeout(function () {
                var allOptions = $scope.arrCostOptionGroup['costOptions'];
                for (var i = 0; i < allOptions.length; i++) {
                    if (allOptions[i]) {
                        $scope.calcFieldTotal({
                            repData: allOptions[i]['CostcodeGroup']['Costcode'],
                            calcKey: 'costValue',
                            parObject: allOptions[i]['CostcodeGroup'],
                            totalKey: 'costValueTotal'
                        });
                    }
                }
            }, 100);
        }

        // To set workflow for ICA forms
        function icaFormsFlow() {
            var tempStageFlow = (parseInt($scope.oriMsgCustomFields['stageFlow']) || 0) + 1
            var tempPcnFormCode = $scope.oriMsgCustomFields['PCN_AppBuilderId'];
            var statusIds = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.icaRaised
            });

            var statusIdWithdrawn = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.Withdrawn
            });

            var statusIdSubToChangeAppraisal = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.subjectToChangeAppraisal
            });

            var statusIdSubToICA = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.subjectToICA
            });

            var statusIdReviseAndResubmit = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.reviseAndResubmit
            });

            var statusIdOpen = $scope.getFormStatus({
                spName: TFL_CONSTANT.dsAllActiveWsStatus,
                status: TFL_CONSTANT.openStatus
            });

            if ($scope.isRespond) {
                if ($scope.oriMsgCustomFields['stageFlow'] == 0) { // contractor
                    setDistributionNodeForPM(TFL_CONSTANT.resDistNumb);
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIdOpen;
                } else if ($scope.oriMsgCustomFields['projCoObjFlag'] == "No") { // No Objection, objection check box checked with no objection
                    if ($scope.oriMsgCustomFields['isTFLagreed'] == 'No') { // TFL Project Manager Agree or disagree
                        var strCurrentFormStatus = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS;
                        if (strCurrentFormStatus == statusIdReviseAndResubmit) {
                            statusIds = statusIdSubToICA;
                        } else {
                            setForInfoDistributionNodeForContractor();
                            statusIds = statusIdWithdrawn;
                            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                        }
                        if (strCurrentFormStatus && strCurrentFormStatus.indexOf(TFL_CONSTANT.reviseAndResubmit) > -1) {
                            setDistributionNodeForContractor();
                            // Set Stage 1 becasue it send back to Contractor
                            tempStageFlow = 0;
                        }
                    } else {
                        setForInfoDistributionNodeForContractor();
                        statusIds = statusIdSubToChangeAppraisal;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    }
                } else if ($scope.oriMsgCustomFields['projCoObjFlag'] == "Yes") { // have Objection, objection check box checked with objection
                    if ($scope.oriMsgCustomFields['isTFLagreed'] == 'Yes') { // TFL Project Manager Agree or disagree
                        statusIds = statusIdWithdrawn;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    } else {
                        statusIds = statusIdSubToChangeAppraisal;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = statusIds;
                    }
                    setForInfoDistributionNodeForContractor();
                }
            } else {
                if ($scope.oriMsgCustomFields['TFL_Representative']) {
                    setDistributionNodeForPM(TFL_CONSTANT.oriDistNumb);
                }
            }

            // To display loader on screen;
            $element.removeClass('loaded');

            /** 
             * Define stage for workflow based form. 
             * stageFlow=0 i.e ORI_VEW/RES_VEW by Contractor
             * stageFlow=1 i.e RES_VEW by PM
             * */
            $scope.oriMsgCustomFields['stageFlow'] = tempStageFlow;
        }

        $window.pcnFinalCallBack = function () {
            var returnFlag = false;
            var checkObjectValueSelectedOrNot = $scope.oriMsgCustomFields['projCoObjFlag'] == 'Yes' 
            && $scope.oriMsgCustomFields['objectionFlags']['Technically'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['Illegal'] == 'No' 
            && $scope.oriMsgCustomFields['objectionFlags']['Contravene'] == 'No';
            if (checkObjectValueSelectedOrNot) {
                alert("Please select any objection");
                returnFlag = true;
            } else {
                icaFormsFlow();
            }    
            return returnFlag;
        }

    };
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {

    if (typeof pcnFinalCallBack !== "undefined") {
        return pcnFinalCallBack();
    }
} 