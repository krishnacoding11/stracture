define(["angular", "./base", "../components/inlineattachment", "../components/number-format", "../components/item.selection", "../components/table.util"], function (angular, baseController) {
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        $scope.stopAutoSaveDraftTimerFromClientSide();
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.todayDate = "";
        
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass("loaded");
                    $scope.expandTextAreaOnLoad()
                }, 50)
            }
        });
        var dateFormatMap = {
            en_GB: "dd-M-yy",
            fr_FR: "d M yy",
            es_ES: "dd-M-yy",
            ru_RU: "dd.mm.yy",
            en_AU: "dd/mm/yy",
            en_CA: "d-M-yy",
            en_US: "M d, yy",
            zh_CN: "yy-m-d",
            de_DE: "dd.mm.yy",
            ga_IE: "d M yy",
            en_ZA: "dd M yy",
            ja_JP: "yy/mm/dd",
            ar_SA: "dd/mm/yy",
            en_IE: "dd-M-yy",
            nl_NL: "dd-M-yy"
        };
        $scope.userDateFormat = dateFormatMap[$window.USP.languageId] || "dd/mm/yy";
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null") {
            projectId = window.currProjId
        }
        var formId = document.getElementById("formId") && document.getElementById("formId").value || "";

        /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data.myFields["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data.myFields["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data.myFields["FORM_CUSTOM_FIELDS"];
        $scope.formdata5 = $scope.asiteSystemDataReadOnly._5_Form_Data;
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData("DS_ALL_FORMSTATUS");
        $scope.oriMsgCustomFields = $scope.formCustomFields.ORI_MSG_Custom_Fields;
        $scope.resMsgCustomFields = $scope.formCustomFields.RES_MSG_Custom_Fields;
        $scope.SectionsGroup = $scope.oriMsgCustomFields.SectionsGroup;
        $scope.Prog_Changes = $scope.oriMsgCustomFields.Prog_Changes;
        var workingUserAllRole = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var dsWorkingUserId = $scope.getWorkingUserId();
        var ds_all_Active_Form_Status = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_CONTRACT');
        var DS_PAA_MPC_NEC_KEY_CONTRACT_DATES = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_KEY_CONTRACT_DATES');
        WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.oriMsgCustomFields.Org_Name = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();
        var currentViewName = window.currentViewName;
        var strIsDraft = $scope.formdata5.DS_ISDRAFT;
        var strFormId = $scope.formdata5.DS_FORMID;
        $scope.isDataLoaded = true;
        $scope.selectionlst = {
            ewnWorkspaceUserslist: [],
            setContractlist: [],
            sectionList: [],
            nopReferenceList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "NOP1 VolkerRail"
                }, {
                    Name: "NOP2 Murphy"
                }, {
                    Name: "NOP3 Siemens"
                }, {
                    Name: "NOP4 SYSTRA"
                }, {
                    Name: "OP Network Rail"
                }, {
                    Name: "Other"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.todayDateDbFormat;
            if (currentViewName == "ORI_VIEW") {
                setRespondDate();
            }
        });

        /** Initialize CONSTANT and STATIC_OBJ_DATA Variable */
        var ASC_CONSTANT = {
            ewnWorkspaceUsers: 'Workspace - Administrator',
            respond: "Respond",
            forInformation: "For Information",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondNumber: "3#",
            forInfoNumber: "7#",
            reviseResubmit: 'Revise Resubmit'
        };
        var STATIC_OBJ_DATA = {
            ProposedCostings: {
                ProposedItem: "",
                ProposedUnit: "",
                ProposedProposed: "",
                ProposedProjectPro: "",
                ProposedDesc: ""
            },
            AttachementsFiles: {
                attachments: ""
            },
            CommercialImpact: "0.00",
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            },
        };

        /** 
         * tableUtilSettings is used to attached multiple files 
         */
        $scope.tableUtilSettings = {
            ProposedCostings: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: true,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "key_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.ProposedCostings),
                ADD_NEW_BEFORE_TIP: "Insert before reference document",
                ADD_NEW_AFTER_TIP: "Insert after reference document",
                deleteAllRowTooltip: "Remove all reference document",
                deleteCurrRowMsg: "Remove reference document",
                deleteSelectedMsg: "Remove selected reference document",
            },
            AttachementsFiles: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: true,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Att_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.AttachementsFiles),
                ADD_NEW_BEFORE_TIP: "Insert before reference document",
                ADD_NEW_AFTER_TIP: "Insert after reference document",
                deleteAllRowTooltip: "Remove all reference document",
                deleteCurrRowMsg: "Remove reference document",
                deleteSelectedMsg: "Remove selected reference document",
            }
        };
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad()
        };

        /**
         * This condition is used for display Contract value as link and redirect to particular Contract
         * */
        if (currentViewName == 'ORI_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break;
                }
            }
        } else if ($scope.oriMsgCustomFields.Contract) {
            onContractchange($scope.oriMsgCustomFields.Contract, true);
        }

        /**
         * set form status
         * @param {string} StrStatus: set form final status
         */
        function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: ds_all_Active_Form_Status,
                strStatus: currFormStaus
            });
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId
            }
        }

        /**
         * This function is used for setting other fileds data on Contract selection 
         * * @param {string} conVal: conVal is set form tempConAppCode
         * * @param {boolean} onloadFlag: onloadFlag iused to fill other dropdown on onContractchange
         * */
        $scope.onContractchange = onContractchange;

        function onContractchange(conVal, onloadFlag) {
            if (conVal) {
                $scope.isDataLoaded = false;
                var tempConAppCode = conVal.split('|')[0].trim();
                var arrStr = $scope.oriMsgCustomFields.Contract.split("|");
                $scope.oriMsgCustomFields.CON_AppBuilderId = tempConAppCode;
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[12].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.oriMsgCustomFields.Client_Logo = arrStr[3].trim();
                $scope.oriMsgCustomFields.Contractor_Logo = arrStr[2].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[12].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                setFormContent();
                var spParam = {
                    dataSourceArray: [{
                        fieldName: "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                        fieldValue: tempConAppCode
                    }, {
                        fieldName: "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                        fieldValue: tempConAppCode
                    }, {
                        fieldName: "DS_PAA_Contract_Activity_Group_dtls",
                        fieldValue: tempConAppCode
                    }, {
                        fieldName: "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                        fieldValue: tempConAppCode
                    }],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if (!onloadFlag) {
                            $scope.selectionlst.ewnWorkspaceUserslist = [];
                            $scope.selectionlst.sectionList = [];
                        }
                        setUserList(response);
                        sectionList(response);
                        if ($scope.formdata5.DS_FORMID == null || $scope.formdata5.DS_FORMID == '') {
                            var allowCreate = checkContractDate(response, arrStr[arrStr.length - 2]);
                            var chkPermission = allowCreate.toLowerCase() == "yes" ? strIsCreateUser(response) : "Yes";
                            if (chkPermission.toLowerCase() == "no") {
                                setCreatePermission();
                            }
                        }
                    }
                };
                $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                    return obj.fieldName
                });
                $scope.getCallbackSPdata(spParam)

                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split('|')[0].trim() == arrStr[0].trim();
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split('|')[3].trim()
                        if (strNotes)
                            $scope.asiteSystemDataReadWrite.Dist_Guidance_Notes = strNotes;
                    }
                }
            }
        };

        /**
         * setUserAction used to assign action to user form Request to dropdown selesction 
         * userId is selected user form dropdown 
         * strAction is respond action which you wont to assign to selected user
         * distDate is form close date 
         * strDueDays is define how many day after this form is close
         * */
        $scope.setUserAction = function () {
            var userId = $scope.oriMsgCustomFields.EWNIssutoName;
            userId = userId && userId.split(" | ")[2];
            userId = userId && userId.split("#")[0];
            var strAction = ASC_CONSTANT.respondNumber + ASC_CONSTANT.respond;
            var strDueDays = $scope.oriMsgCustomFields.Reply_Days || 2;
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users);
            structDistribution.DS_PROJDISTUSERS = userId;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = $scope.oriMsgCustomFields.RespondDate;
            structDistribution.DS_DUEDAYS = strDueDays;
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
            setUserAction(userId, strAction, $scope.oriMsgCustomFields.RespondDate, strDueDays);
        };

        /**
         * setUserAction used to assign action to user form Request to dropdown selesction 
         * @param {string} userId: is assign action to feacthed user
         * @param {string} action: is assign action to selected user
         * @param distDate is form close date 
         * @param DueDays is define how many day after this form is close
         * */
        function setUserAction(userId, action, distDate) {
            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: userId,
                    strAction: action,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: '3',
            })
        }

        /**
         * initFormsData is used from satrt load the form
         * strIsDraft is used to check user is darft user or not
         * Set form stage 
         * */
        initFormsData();

        function initFormsData() {

            if (currentViewName == "ORI_VIEW") {
                var conDataList = $scope.getValueOfOnLoadData('DS_PAA_MPC_NEC_ALL_EMP_CONTRACT');
                angular.forEach(conDataList, function (item) {
                    var index = item.Name.lastIndexOf('|');
                    if (index > -1) {
                        item.Name = item.Name.substring(0, item.Name.lastIndexOf('|'));
                    }
                });
                $scope.selectionlst.setContractlist = commonApi.getItemSelectionList({
                    arrayObject: conDataList,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });

                if (strFormId == "" || strIsDraft == "YES") {
                    $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId;
                }
                $scope.Msg = "You are not authorised to create/edit the form currently. For more information, contact your Administrator."
                $scope.strCanReply = "";

                if (strIsDraft == "NO") {
                    if ($scope.oriMsgCustomFields.DSI_Next_Stage == "") {
                        $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                    }
                    if ($scope.oriMsgCustomFields.DSI_Current_Stage == "") {
                        $scope.oriMsgCustomFields.DSI_Current_Stage = 1;
                    } else {
                        $scope.oriMsgCustomFields.DSI_Current_Stage = $scope.oriMsgCustomFields.DSI_Next_Stage;
                    }
                }
                if ($scope.oriMsgCustomFields.DSI_Current_Stage > 1) {
                    var actionData = commonApi._.filter(incompleteAction, function (val) {
                        return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(dsWorkingUserId) != -1
                    });
                    if (actionData && actionData.length) {
                        $scope.strCanReply = "yes";
                    }
                }
                if (workingUserAllRole && $scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
                    if (workingUserAllRole[0].Value.toLowerCase().indexOf("workspace") != -1) {
                        $scope.strCanReply = "yes";
                    }
                }
                strIsUserDraftOnly();
            }

            $scope.DS_FORMNAME = document.getElementById('DS_FORMNAME').value;
            $scope.DS_PROJECTNAME = document.getElementById('DS_PROJECTNAME').value;
        }

        function strIsUserDraftOnly() {
            if (workingUserAllRole[0].Value.indexOf("Commercial Team") == -1) {
                var $sendBtn = $window.document.getElementById('btnSaveForm');
                $sendBtn && ($sendBtn.style.display = 'none');
                $scope.strCanCreate = true;
                var strMsg = "0";
                strMsg = "You are only allowed to create Drafts for this form. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
                alert(strMsg);
            }
            else
            {
                $scope.strCanCreate = false;
            }
        }

        /**
         * strIsCreateUser used for check current user us member of Alliance Contract management team or not
         * @param response: is used for check user data on contract callback
         * */
        function strIsCreateUser(response) {
            if (response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS.length; i++) {
                    strValue = response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS[i].Value.split('|');
                    strRole = strValue[1].trim();
                    //if (strRole.toLowerCase() == "create only") {
                    strTmpEmpId = strValue[2].split('#')[0].trim();
                    if (strTmpEmpId == dsWorkingUserId)
                        return "No";
                    //}
                }
            }
            return "Yes";
        }

        /**
         * setCreatePermission used for check current user us member of Alliance Contract management team or not
         * */ 
        function setCreatePermission() {
            $scope.oriMsgCustomFields.isApprovalRequired = "No";
        }

        /**
         * checkContractDate used for check today date is  is greater than Contract date+lock period or not
         *  @param {string} contractDate: is get selected contract created date.
         *  * @param response: is used for check date contract callback
         * */
        function checkContractDate(response, contractDate) {
            var dateResponse = response.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES;
            if (dateResponse && dateResponse.length) {
                var selectedData = commonApi._.filter(dateResponse, function (obj) {
                    return obj.Value3.toLowerCase() == "resource approval lock period";
                })[0];
                if (selectedData) {
                    $scope.replyExpiryDate =  parseInt(selectedData.Value4);
                    if (contractDate != null && contractDate != undefined && contractDate != '') {
                        var replyExpiry = new Date(new Date(contractDate).getFullYear(), new Date(contractDate).getMonth(), new Date(contractDate).getDate() + $scope.replyExpiryDate);
                        if (new Date() > replyExpiry) {
                            return "No";
                        }
                    }

                }
            }
            return "Yes";
        }

        /**
         * setRespondDate is used to auto populate Respond Date 
         * * @param response: is used for fill this dropdown after contract callback
         * */
        function setRespondDate(){
            var todayDateDbFormat = $scope.todayDateDbFormat;
            
			if(todayDateDbFormat){
                var spParam = {
                    dataSourceArray: [{
                        fieldName: "DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY",
                        fieldValue: todayDateDbFormat + '|' + '' + '|' + 7
                    }],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY.length){
                            $scope.oriMsgCustomFields.RespondDate = $scope.formatDate(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY[0].Value2, "yy-mm-dd", "dd/mm/yy");
                        }
                    }
                };
                $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                    return obj.fieldName
                });
                $scope.getCallbackSPdata(spParam)
			}
		}

        /**
         * setUserList is used to fill Request user dropdown
         * * @param response: is used for fill this dropdown after contract callback
         * */
        function setUserList(response) {
            if (response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS) {
                var ownerUserList = commonApi._.filter(response.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, function (obj) {
                    return obj.Value && obj.Value.toLowerCase().indexOf('alliance_leadership_team') > -1;
                });

                $scope.selectionlst.ewnWorkspaceUserslist = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(ownerUserList, function (obj) {
                        return obj.Name
                    }),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
            }
        }

        /**
         * sectionList is used to fill Request user dropdown
         * * @param response: is used for fill this dropdown after contract callback
         * */
        function sectionList(response) {
            var sectionDataList = [];
            var sortSec = [];
            var secList = response.DS_PAA_Contract_Activity_Group_dtls;
            for (var i = 0; i < secList.length; i++) {
                var lvl68Custom = (secList[i].Value8 || secList[i].Value7);
                sectionDataList.push({
                    sectionName: secList[i].Value15.trim() + " | " + lvl68Custom,
                    lvl68Custom: lvl68Custom
                })
            }

            sortSec = commonApi._.uniq(sectionDataList, 'sectionName');
            sortSec = commonApi._.sortBy(sectionDataList, 'sectionName');

            $scope.selectionlst.sectionList = commonApi.getItemSelectionList({
                arrayObject: sortSec,
                groupNameKey: "",
                modelKey: "sectionName",
                displayKey: "sectionName"
            })
        }

        /**
         * set FormContent like AppBuilderId
         * */
        function setFormContent() {
            var strFormContent = "";
            var strConAppid = $scope.oriMsgCustomFields.CON_AppBuilderId;
            var strConequences = $scope.oriMsgCustomFields.Consequences;
            var strProbability = $scope.oriMsgCustomFields.Probability;
            var strActionComments = $scope.resMsgCustomFields ? $scope.resMsgCustomFields.Actions_and_Comments : "";
            var strRRMNotes = $scope.resMsgCustomFields ? $scope.resMsgCustomFields.RRM_Notes : "";
            var strIncreasePrice = $scope.oriMsgCustomFields.Increase_Price;
            strFormContent = strConAppid + "|" + strConequences + "|" + strProbability + "|" + strActionComments + "|" + strRRMNotes + "|" + strIncreasePrice + "|";
            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT = strFormContent
        }

        $scope.update()

        /**
         * paaAlcFinalCallBack is used for final call on form sending 
         * @in userToforInfoaction is used form assign action to respond further process of the form 
         * @param currFormStaus is used to set form status
         */
        $window.paaAlcFinalCallBack = function () {
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
            $scope.formdata5.Status_Data.DS_CLOSE_DUE_DATE = $scope.oriMsgCustomFields.RespondDate;
            
            var userTodistribute = "",
                currFormStaus = "";
            // if (!$scope.strCanReply) {
            //     alert($scope.Msg);
            //     return true;
            // } 
            if ($scope.oriMsgCustomFields.isApprovalRequired == "Yes") {
                if ($scope.oriMsgCustomFields.DSI_Current_Stage == 1 || ($scope.oriMsgCustomFields.Res_Status == "Revise Resubmit" && $scope.oriMsgCustomFields.DSI_Current_Stage == 1)) {
                    userTodistribute = $scope.oriMsgCustomFields.Issueto.split("|")[2];
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 2;
                }
                if ($scope.oriMsgCustomFields.Res_Status == "Approved" || $scope.oriMsgCustomFields.Res_Status == "Not-Approved") {
                    var userToforInfoaction = $scope.oriMsgCustomFields.Originator_Id;
                    if (userToforInfoaction) {
                        var userId = userToforInfoaction;
                        var strAction = "7#";
                        var strDate = $scope.oriMsgCustomFields.RespondDate;
                        setUserAction(userId, strAction, strDate, 7);
                    }
                    currFormStaus = $scope.oriMsgCustomFields.Res_Status;
                } else if ($scope.oriMsgCustomFields.Res_Status == "Further Information Required") {
                    if ($scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
                        userTodistribute = $scope.oriMsgCustomFields.Issueto.split("|")[2];
                        $scope.oriMsgCustomFields.DSI_Next_Stage = 2;
                        currFormStaus = ASC_CONSTANT.reviseResubmit;
                    } else {
                        var userToforInfoaction = $scope.oriMsgCustomFields.Originator_Id;
                        if (userToforInfoaction) {
                            var userId = userToforInfoaction;
                            var strAction = "2#";
                            var strDate = $scope.oriMsgCustomFields.RespondDate;
                            setUserAction(userId, strAction, strDate, 7);
                        }
                        $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                        currFormStaus = $scope.oriMsgCustomFields.Res_Status;
                    }
                }
            } else {
                currFormStaus = "Approved";
            }


            if (userTodistribute) {
                var userId = userTodistribute.split('#')[0].trim();
                var strAction = "2#";
                var strDate = $scope.oriMsgCustomFields.RespondDate;
                setUserAction(userId, strAction, strDate, 7);
            }

            if (currFormStaus) {
                setFormStatus(currFormStaus)
            }
        }
    }
    return FormController
});

/*
 *   Final Call back fuction
 */
function customHTMLMethodBeforeCreate_ORI() {

    if (typeof paaAlcFinalCallBack !== "undefined") {
        return paaAlcFinalCallBack();
    }
}