define(['angular', "mainModule", './base', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';
    /*
    * @constructor
    * @alias module:Form-Controller/FormController
    */
    function FormController($scope, $element, $document, $filter, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 500);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.oriMsgCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"]["ORI_MSG_Custom_Fields"];
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.commissioningGrp = $scope.formCustomFields["Commissioning_Details"];
        $scope.checklistItems = $scope.commissioningGrp.CommissioningChecklist_Items
        var incompleteAction = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var incompleteActionMsg = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var allformStatus = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        $scope.workingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        var guID = $scope.getValueOfOnLoadData('DS_GET_GUID');
        var projUserRole = $scope.getValueOfOnLoadData('DS_PROJUSERS_ROLE');
        var workspaceFolderPath = $scope.getValueOfOnLoadData('DS_NNG_COMM_Get_WorkspaceFolderpath');
        $scope.checklistDocref = $scope.getValueOfOnLoadData('DS_NNG_COMM_CheckListDocDetail');
        var formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']["Status_Data"]["DS_ALL_FORMSTATUS"];
        formStatus = formStatus && formStatus.split('#')[1].trim();
        var docRefList = [];
        var submitFlag = false;
        $scope.hashedFoldersList = [];
        $scope.commissioningCustAttr = {};
        $scope.folderId = "";
        $scope.notCreatedPlaceHolder = [];
        $scope.allAprroved = false;
        $scope.editOriDisp = false;
        $scope.cmtDisplay = false;
        $scope.dispDiv = false;
        $scope.isChkcreated = false;
        $scope.isEditORI = ($scope.strFormId != '' && $scope.strIsDraft == 'NO');
        $scope.xhr = {
            activeAjaxCallCount: 0,
            guIdXhr: false,
            placeholder: false,
            platformXhr: false
        };

        $scope.operations_RES = {
            opUser: "",
            resDate: "",
            opComments: "",
            opAcceptObj: "",
            Is_Old: "New"
        }
        $scope.DistributionStructure = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.itemStructure = {
            Item_Name: "",
            Item_Comments: "",
            Item_GUID: "",
            Items_IS_Old: "New",
            Item_DocReF: "",
            Item_Counter: "",
            Item_Display: "",
            Checklist_Name: "",
            Checklist_Status: "",
            Checklist_Date: "",
            TrackerDetails: {
                rowIndex: "",
                documentIds: "",
                revisionIds: "",
                transactionId: "",
                creationStatus: "",
                filterCode: ""
            },
            attrCheckList: {
                attributeId: "",
                attributeValue: "",
                inputTypeId: "",
                defaultName: ""
            },
            folderData: {
                rowIndex: "",
                folderName: "",
                folderPath: "",
                folderId: ""
            }
        }
        $scope.jobBookStructure = {
            Mark_No: "",
            Manual_Description: "",
            OperationsTeam_Date: "",
            CC_Date: "",
            JobBookEquipment_Comments: ""
        }
        $scope.permitStructure = {
            PermitProvision: "",
            InspectorAck_Date: "",
            Inspector_CC_Date: "",
            ROWAgent_Date: "",
            PermitProvision_Comments: ""
        }
        $scope.startupStructure = {
            SA_Mark_No: "",
            SA_Description: "",
            SA_Vendor: "",
            SA_Comments: ""
        }
        $scope.ACF_01_FORM = {
            ACF_01_DSI_state: "",
            ACF_01_DSI_region: "",
            ACF_01_DSI_projectteam: "",
            ACF_01_ORI_FORMTITLE: "",
            ACF_01_DS_FORMTITLE: "",
            ACF_01_DSI_RFSDate: "",
            ACF_01_CREATED_BY: "",
            ACF_01_commissioningActivity: "",
            ACF_01_projectManager: "",
            ACF_01_operationsManager: "",
            ACF_01_constructionCoordinator: "",
            ACF_01_operationsTeam: "",
            ACF_01_leadInspector: "",
            ACF_01_projectEngineer: "",
            ACF_01_divisionEnvironmental: "",
            ACF_01_rightWayAgent: "",
            ACF_01_documentationSpecialist: "",
            ACF_01_UnitID: "",
            ACF_01_BuildingName: "",
            ACF_01_LocationID: "",
            ACF_01_DS_FORMCONTENT1: "<<DS_Form_ID>>",
            ACF_01_DS_Ref_AppId: "",
            ACF_01_DS_AUTODISTRIBUTE: "",
            ACF_01_REPEATING_VALUES: {
                ACF_01_DS_AutoDistribute_User_Group: {
                    ACF_01_DS_AutoDistribute_Users: [{
                        ACF_01_DS_PROJDISTUSERS: "",
                        ACF_01_DS_FORMACTIONS: "",
                        ACF_01_DS_ACTIONDUEDATE: ""

                    }]
                }
            }
        }

        $scope.ALL_RES_STATIC_OBJ = {
            Inspector_RES: {
                Inspector: "",
                Ins_resDate: "",
                InsComments: "",
                InsAcceptObj: "",
                Role: "",
                RES_User: "",
                InsIsOld: "New"

            },
            Coordinator_RES: {
                Coordinator: "",
                Co_resDate: "",
                Co_Comments: "",
                CoAcceptObj: "",
                Co_IsOld: "New"
            },
            OManager_RES: {
                OManager: "",
                OM_resDate: "",
                OMComments: "",
                OMAcceptObj: "",
                OM_IsOld: "New"
            },
            DS_RES: {
                DS: "",
                DS_resDate: "",
                DSComments: "",
                DSAcceptObj: "",
                DS_IsOld: "New"
            }
        }
        if (currentViewName == "ORI_VIEW") {
            $scope.strCanReply = "";

            // include new row if all records are created and not showing					
            $scope.notCreatedPlaceHolder = $scope.checklistItems.filter(function (deObj) {
                return !deObj.TrackerDetails.revisionIds;
            }) || [];

            $scope.projectManager = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Project Manager");
            });
            $scope.operationsManager = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Operations Manager");
            });

            $scope.constructionCoordinator = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Construction Coordinator");
            });
            $scope.operationsTeam = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Operations Team Contact");
            });
            $scope.leadInspector = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Inspector");
            });
            $scope.projectEngineer = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Project Engineer");
            });
            $scope.divisionEnvironmental = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Division Environmental Specialist");
            });
            $scope.rightwayAgent = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "ROW Agent");
            });
            $scope.documentationSpecialist = commonApi._.filter(projUserRole, function (val) {
                return (val.Value.split('|')[0].trim() == "Documentation Specialist");
            });
        }
        function setBlankVal() {
            if ($scope.commissioningGrp.operationsManager == "-")
                $scope.commissioningGrp.operationsManager = "";
            if ($scope.commissioningGrp.constructionCoordinator == "-")
                $scope.commissioningGrp.constructionCoordinator = "";
            if ($scope.commissioningGrp.documentationSpecialist == "-")
                $scope.commissioningGrp.documentationSpecialist = "";

        }
        if (currentViewName == "ORI_VIEW") {
            $scope.strCanReply = "";
        }
        if (currentViewName == "ORI_PRINT_VIEW") {
            angular.element('.export-btn').hide();
        }
        $scope.custAttrSelection = function (custAttrObj, parentObj, selectedVal) {
            if (parentObj.inputValueList) {
                var selectedValObj = parentObj.inputValueList.filter(function (valueObj) {
                    return valueObj.value == selectedVal
                })[0] || {};
                custAttrObj.attrCheckList.attributeId = parentObj.attributeId;
                custAttrObj.attrCheckList.attributeValue = selectedVal;
                custAttrObj.attrCheckList.inputTypeId = parentObj.inputTypeId;
                custAttrObj.attrCheckList.defaultName = selectedValObj && selectedValObj.defaultName;
                custAttrObj.folderData.folderId = $scope.folderId
                custAttrObj.folderData.folderId
                custAttrObj.Checklist_Name = selectedValObj && selectedValObj.defaultName.replace(selectedVal, "").trim();
            }

        }
        if ($scope.isEditORI && currentViewName == "ORI_VIEW") {
            setBlankVal()
            $scope.Msg = "You are not authorised to edit the form currently. For more information, contact your Administrator."
            $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = commonApi.calculateDistDateFromDays({
                baseDate: getDateTimeFromZone(),
                days: 7
            });
            if ($scope.checklistDocref.length != 0) {
                $scope.isChkcreated = true;
                for (var i = 0; i < $scope.checklistItems.length; i++) {
                    var dObj = $scope.checklistItems[i];
                    for (var j = 0; j < $scope.checklistDocref.length; j++) {
                        var chKObj = $scope.checklistDocref[j];
                        if (dObj.Item_DocReF == chKObj.Value1) {
                            dObj.Checklist_Status = chKObj.Value2;
                            dObj.Checklist_Date = chKObj.Value3;
                        }
                    }
                }
                for (var j = 0; j < $scope.checklistItems.length; j++) {
                    if ($scope.checklistItems[j].Checklist_Status == '') {
                        $scope.checklistItems[j].Items_IS_Old = 'New';
                        $scope.checklistItems[j].Item_DocReF = '';
                    }
                }
            }
            else {
                for (var j = 0; j < $scope.checklistItems.length; j++) {
                    if ($scope.checklistItems[j].Items_IS_Old == 'Old') {
                        $scope.checklistItems[j].Items_IS_Old = 'New';
                        $scope.checklistItems[j].Item_DocReF = '';
                        $scope.isChkcreated = true;
                    }
                }
            }

        }
        else if (!$scope.isEditORI && currentViewName == "ORI_VIEW") {
            $scope.Msg = "This form may not be created manually.  It is auto-created when the Commissioning Turnover Form (XTF) is launched by the Project Manager to begin the commissioning process.";
        }

        if (currentViewName == "ORI_VIEW" && $scope.strIsDraft == "NO") {

            if ($scope.oriMsgCustomFields.DSI_Next_Stage == "") {
                $scope.oriMsgCustomFields.DSI_Next_Stage = 1
            }
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == "") {
                $scope.oriMsgCustomFields.DSI_Current_Stage = 1
            }
            else {
                $scope.oriMsgCustomFields.DSI_Current_Stage = $scope.oriMsgCustomFields.DSI_Next_Stage
            }
        }
        function getInspector() {
            var statudObj = commonApi._.filter($scope.commissioningGrp['Inspector_RES'], function (val) {
                return val.Inspector != "";
            });
            if (statudObj.length) {
                return statudObj[0].Inspector;
            }
            return "";

        }
        function chkApproved() {


            var strRes = commonApi._.filter($scope.checklistDocref, function (val) {
                return val.Value2.toLowerCase() == "approved";
            });
            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
                var isInspector = commonApi._.filter($scope.leadInspector, function (val) {
                    return val.Value.indexOf($scope.workingUserID[0].Value.split('|')[0].trim()) != -1
                });
                if ($scope.checklistItems.length > 0 && strRes.length == $scope.checklistItems.length &&
                    $scope.checklistItems.length == $scope.commissioningGrp.CommissioningChecklist_Items.length && isInspector.length > 0)
                    $scope.allAprroved = true;
            }
            else {
                if ($scope.checklistItems.length > 0 && strRes.length == $scope.checklistItems.length)
                    $scope.allAprroved = true;
            }

            if ($scope.oriMsgCustomFields.DSI_Current_Stage == 3 && getInspector().split('|')[0].trim() != $scope.workingUserID[0].Value.split('|')[0].trim()) {
                $scope.allAprroved = false
            }

            if ($scope.allAprroved == false && $scope.oriMsgCustomFields.DSI_Current_Stage < 3) {
                $scope.editOriDisp = true;
            }
        }
        if ($scope.isEditORI && currentViewName == "ORI_VIEW") {

            if ((formStatus.toLowerCase() == 'objection' || formStatus.toLowerCase() == 'submitted' || formStatus.toLowerCase() == 'not required' || formStatus.toLowerCase() == 'complete') && ($scope.oriMsgCustomFields.DSI_Current_Stage != 3)) {
                var userid = $scope.workingUserID['0'].Value.split('|')[0].trim();
                var actionData = commonApi._.filter(incompleteAction, function (val) {
                    return val.Name.indexOf('Assign Status') > -1 && val.Value.indexOf(userid) != -1
                });
                if (actionData && actionData.length) {
                    $scope.strCanReply = "yes";
                }
            }
            else {
                $scope.strCanReply = "yes";
            }
            // Check all Approved
            chkApproved();

        }



        var projectMasterFormDetails = $scope.getValueOfOnLoadData("DS_NNG_PMF_GET_ProjectMasterForm_Details")[0] || {};
        $scope.commissioningGrp.DSI_workOrderNo = projectMasterFormDetails.Value1 || "";//Work_Order_Number
        $scope.commissioningGrp.DSI_projectName = projectMasterFormDetails.Value3 || "";//Project_Name
        $scope.commissioningGrp.DSI_state = projectMasterFormDetails.Value9 || "";//State
        $scope.commissioningGrp.DSI_region = projectMasterFormDetails.Value8 || "";//Region 
        $scope.commissioningGrp.DSI_projectteam = projectMasterFormDetails.Value52 || "";//Project Team
        $scope.commissioningGrp.DSI_RFSDate = $scope.formatDate(new Date(projectMasterFormDetails.Value24), 'mm/dd/yy') || "";

        //Add Table
        if ($scope.oriMsgCustomFields.DSI_Current_Stage == 2 && currentViewName == "ORI_VIEW") {
            var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                return val.Is_Old.indexOf("New") != -1
            });
            if (strRes.length == 0)
                $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));

        }
        else if (($scope.oriMsgCustomFields.DSI_Current_Stage > 2) && currentViewName == "ORI_VIEW" && $scope.allAprroved == true) {
            var strRes = commonApi._.filter($scope.commissioningGrp.Inspector_RES, function (val) {
                return val.InsIsOld.indexOf("New") != -1
            });
            if (strRes.length == 0)
                $scope.commissioningGrp.Inspector_RES.push(angular.copy($scope.ALL_RES_STATIC_OBJ.Inspector_RES));
        }

        if ($scope.isEditORI && currentViewName == "ORI_VIEW" && $scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
            if (formStatus.toLowerCase() == "objection" && $scope.commissioningGrp.operations_RES.length > 0 &&
                $scope.commissioningGrp.operations_RES[0].opAcceptObj == 'Object') {
                $scope.cmtDisplay = true;
                var strRes = commonApi._.filter($scope.commissioningGrp.operations_RES, function (val) {
                    return val.Is_Old.indexOf("New") != -1
                });
                if (strRes.length == 0)
                    $scope.commissioningGrp.operations_RES.push(angular.copy($scope.operations_RES));
            }
        }
        $scope.getServerTime(function (serverDate) {
            $scope.serverDate = serverDate;

        });
        $scope.deleteRow = function (index, repeatindData, type) {
            if (repeatindData.length == 1) {
                alert('Atleaset one row required');
                return false;
            }
            else if (repeatindData.length > index) {
                repeatindData.splice(index, 1);
            }
            if (type == 'Chklist') {
                if ($scope.allAprroved == false) {
                    chkApproved();
                    if ($scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].Inspector == ''
                        && $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].RES_User == '') {
                        $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsAcceptObj = '';
                        $scope.commissioningGrp.Inspector_RES[$scope.commissioningGrp.Inspector_RES.length - 1].InsComments = '';
                    }
                }
            }
        };
        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };
        $scope.setGuid = function () {
            $scope.commissioningGrp.CommissioningChecklist_Items[0].Item_GUID = guID[0].Value2;
        }
        $scope.addChecklistItem = function (repeatingData, fromStructure) {
            $scope.allAprroved = false
            getGUIdOnCallBack(1, function (guidResp) {
                var item = angular.copy(fromStructure);
                item.Item_GUID = guidResp[0];
                repeatingData.push(item);
                chkApproved();
            });


        }
        $scope.showDiv = function () {
            if ($scope.dispDiv)
                $scope.dispDiv = false;
            else
                $scope.dispDiv = true;
        }

        var findFolder = function (list, folderId) {
            for (var i = 0; i < list.length; i++) {
                var folder = list[i];
                var targetFolderId = (folderId + "").split('$$')[0];
                var currentFolderId = (folder.folderId + "").split('$$')[0];
                if (currentFolderId === targetFolderId) {
                    return folder;
                } else if (folder.childFolders && folder.childFolders.length) {
                    var found = findFolder(folder.childFolders, folderId);
                    if (found) {
                        return found;
                    }
                }
            }
        }, getCustomAttrValues = function (deliverablesDetailsObj) {
            var customAttrs = [];
            customAttrs.push(deliverablesDetailsObj.attrCheckList)
            return customAttrs;
        }
            , setCustomAttributeFields = function () {
                for (var i = 0; i < $scope.attributeList.length; i++) {
                    var attrObj = $scope.attributeList[i];
                    if (attrObj.attributeId > 1000) {
                        if (attrObj.attributeName.toLowerCase() == "commissioning checklist") {
                            $scope.commissioningCustAttr = attrObj;
                        }
                    }
                }
            }
            , fetchActionAndAttributeDetails = function (folderId) {
                // get list from the first Folder Only.		
                $scope.xhr.platformXhr = true;
                commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/document/getActionAndAttributeDetails",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "projectId=" + $scope.projectId + '&folderId=' + folderId + '&KeyToSearchAction=UploadController117&subActionType=2'
                }).then(function (response) {
                    var data = response.data || {};
                    $scope.actionList = (data.myHashMap || {}).actionVOList || [];
                    $scope.attributeList = ((data.myHashMap || {}).filesAttributeDataVO || {}).allAttributesList || [];
                    if ($scope.attributeList) {
                        setCustomAttributeFields();
                    }

                    $scope.xhr.platformXhr = false;
                }, function () {
                    $scope.xhr.platformXhr = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while loading Attribute list!!'
                    });
                });
            }
            , allHashedFolderList = function () {
                $scope.xhr.platformXhr = true;
                commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/folder/getAllFoldersForProject",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    data: "projectId=" + $scope.projectId
                }).then(function (response) {
                    $scope.xhr.platformXhr = false;
                    var data = response.data || [];
                    data = data[0] || {};
                    data = data.childFolders || [];
                    $scope.hashedFoldersList = data;
                    if ($scope.hashedFoldersList.length) {
                        var folderId = workspaceFolderPath.length && workspaceFolderPath[0].Value2 || '',
                            f = findFolder($scope.hashedFoldersList, folderId);
                        $scope.folderId = folderId;
                        if (f) {
                            folderId = f.folderId;
                        } else {
                            folderId = $scope.hashedFoldersList[0].folderId || '';
                        }
                        folderId && fetchActionAndAttributeDetails(folderId);
                    }
                }, function () {
                    $scope.xhr.platformXhr = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while fetching folders list of current workspace'
                    });
                });
            },
            reportByParam = commonApi.getItemSelectionList({
                arrayObject: dsAsiConfigurableAttributes.filter(function (custObj) {
                    return custObj.Value3.toLowerCase() == 'commissioning checklist';
                }),
                groupNameKey: "",
                modelKey: "Value7",
                displayKey: "Value8"
            }),
            createPlaceHolders = function (checkListObj, callbackFun, currentIndex) {
                var placeholderDetail = {
                    "placeholderList": [{
                        "filename": "Not Uploaded",
                        "documentRef": checkListObj.Item_DocReF,
                        "revision": 0,
                        "documentTitle": checkListObj.Item_Comments,
                        "purposeOfIssue": '0', 	// 0 for ---
                        "isPrivateRevision": false,
                        "revisionNotes": '',	// deliverablesDetailsObj.docRemarks,
                        "zipFileName": "",
                        "paperSize": "",
                        "scale": "",
                        "customAttributes": getCustomAttrValues(checkListObj),
                        "tempId": 0,
                        "isCheckIn": false
                    }]
                };
                var folderId = checkListObj.folderData.folderId;
                var f = findFolder($scope.hashedFoldersList, folderId);
                if (f) {
                    folderId = f.folderId;
                }
                $scope.xhr.placeholder = commonApi.ajax({
                    url: ($window.adoddleBaseUrl || "") + "/commonapi/document/createPlaceholder",
                    method: 'post',
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    rowIndex: currentIndex + 1,
                    data: "projectId=" + $scope.projectId + '&folderId=' + folderId +
                        '&filename1=Not Uploaded' +
                        '&docRef1=' + checkListObj.Item_DocReF +
                        '&revision1=---' +
                        '&hasAttachment1=true' +
                        '&rowNumbers=1' +
                        '&forPublishing=false' +
                        '&validationType=2' +
                        '&isFromPlaceholder=true' +
                        '&subject=' +
                        '&noAccessUsers=' +
                        '&isValidationRequired=true' +	// this parameter will check the platforms validations while creating placeholder if true is there.
                        '&placeholderDetails=' + encodeURIComponent(angular.toJson(placeholderDetail)) +
                        '&distributionDetails={"selectedDistGroups":"","selectedDistUsers":[],"selectedDistOrgs":[],"selectedDistRoles":[],"tempId":0}'
                }).then(function (response) {
                    $scope.xhr.activeAjaxCallCount++;
                    var data = response.data || {};
                    if (data.errorCode) {
                        if (data.allowContinue) {
                            Notification.warning({
                                title: 'The Doc Ref already exists',
                                message: 'The Doc Ref shown below already has a revision uploaded\n\n- ' + data.docRef
                            });
                            $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['creationStatus'] = "The Doc Ref already exists";
                        } else if (data.errorCode == 2031) {
                            Notification.warning({
                                title: 'Deactivated placeholder exists',
                                message: 'The Doc Ref shown below has a deactivated placeholder as a latest revision\n\n- ' + data.docRef
                            });
                            $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['creationStatus'] = "Deactivated placeholder exists.";
                        } else {
                            Notification.warning({
                                title: 'The Doc Ref already has an empty Placeholder',
                                message: 'The Doc Ref shown below already has an empty Placeholder\n\n- ' + data.docRef +
                                    '\n\nSystem will not create placeholder for the above Doc Ref.\n Please remove that placeholder first.'
                            });
                            $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['creationStatus'] = "Duplicate Placeholder";
                        }
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['filterCode'] = "ERR";
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['revisionIds'] = data.revisionId.split('$$')[0];
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['documentIds'] = data.documentId.split('$$')[0];
                    } else if (data.myHashMap) {
                        var createdPlaceHolderDetail = data.myHashMap.savedPlaceholderDetails;
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['revisionIds'] = createdPlaceHolderDetail.revisionIds;
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['documentIds'] = createdPlaceHolderDetail.documentIds;
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['transactionId'] = createdPlaceHolderDetail.transactionId;
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['creationStatus'] = "Success";
                        $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['TrackerDetails']['filterCode'] = "SUCCESS";
                        Notification.success('<div class="text-center"> New placeholder for ' + $scope.commissioningGrp.CommissioningChecklist_Items[response.config.rowIndex - 1]['Item_DocReF'] + ' created successfully !</div>');
                    }
                    if ((!$scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.commissioningGrp.CommissioningChecklist_Items.length) || ($scope.isEditORI && $scope.xhr.activeAjaxCallCount == $scope.notCreatedPlaceHolder.length)) {
                        $scope.xhr.placeholder = false;
                        callbackFun();
                    }
                }, function (errorObj) {
                    $scope.xhr.activeAjaxCallCount++;
                    $scope.commissioningGrp.CommissioningChecklist_Items[errorObj.config.rowIndex - 1]['TrackerDetails']['creationStatus'] = "-";
                    $scope.commissioningGrp.CommissioningChecklist_Items[errorObj.config.rowIndex - 1]['TrackerDetails']['filterCode'] = "ERR";
                    $scope.xhr.placeholder = false;
                    Notification.error({
                        title: 'Server Error',
                        message: 'Error while creating placeholder!!\nPlease check Permissions.'
                    });
                    callbackFun();
                });
            },
            getGUIdOnCallBack = function (totalNodes, callback) {
                var allNodes = [];
                var fieldValue = totalNodes;
                if (fieldValue) {
                    var form = {
                        "projectId": $scope.projectId,
                        "formId": $scope.formId,
                        "fields": "DS_GET_GUID",
                        "callbackParamVO": {
                            "customFieldVOList": [{
                                "fieldName": "DS_GET_GUID",
                                "fieldValue": fieldValue
                            }]
                        }
                    };
                    $scope.xhr.platformXhr = true;
                    $scope.xhr.guIdXhr = $scope.getCallbackData(form).then(function (response) {
                        if (response.data) {
                            var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
                            var strGetDetailsLength = strGetDetails.Items.Item.length;
                            for (var i = 0; i < strGetDetailsLength; i++) {
                                allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
                            }
                        }
                        callback(allNodes);
                    }, function (error) {
                        $scope.xhr.platformXhr = false;
                        $scope.xhr.guIdXhr = false;
                        var errorMsg = 'Error retriving DocumentData<br/>' + error;
                        Notification.error({
                            title: 'Server Error',
                            message: errorMsg
                        });
                    });
                }
            },
            getPlaceholderCallBack = function (placeHolderVal, callback) {
                {
                    var allNodes = [];
                    var fieldValue = placeHolderVal;
                    if (fieldValue) {
                        var form = {
                            "projectId": $scope.projectId,
                            "formId": $scope.formId,
                            "fields": "DS_NNG_COMM_GetNewDocRef",
                            "callbackParamVO": {
                                "customFieldVOList": [{
                                    "fieldName": "DS_NNG_COMM_GetNewDocRef",
                                    "fieldValue": fieldValue
                                }]
                            }
                        };
                        $scope.xhr.platformXhr = true;
                        $scope.xhr.dcXhr = $scope.getCallbackData(form).then(function (response) {
                            if (response.data) {
                                var strGetDetails = JSON.parse(response.data['DS_NNG_COMM_GetNewDocRef']);
                                var strGetDetailsLength = strGetDetails.Items.Item.length;
                                for (var i = 0; i < strGetDetailsLength; i++) {
                                    var x = {
                                        "guID": strGetDetails.Items.Item[i].Value2,
                                        "docRef": strGetDetails.Items.Item[i].Value1,
                                        "Counter": strGetDetails.Items.Item[i].Value4,
                                        "Display": strGetDetails.Items.Item[i].Value5
                                    }
                                    allNodes.push(x);
                                }
                            }
                            callback(allNodes);
                        }, function (error) {
                            $scope.xhr.platformXhr = false;
                            $scope.xhr.dcXhr = false;
                            var errorMsg = 'Error retriving DocumentData<br/>' + error;
                            Notification.error({
                                title: 'Server Error',
                                message: errorMsg
                            });
                        });
                    }
                }
            };
        if (currentViewName == "ORI_VIEW") {
            allHashedFolderList();
        }
        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (allformStatus && allformStatus.length > 0) {
                var statudObj = commonApi._.filter(allformStatus, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }
        function setStatus(statusname) {
            var strFormStatusId = getFormStatusId(statusname);
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
            }
        }

        function updateUnavailableGuidStatus() {
            var docRefData = "";
            docRefList = [];
            for (var i = 0; i < $scope.commissioningGrp.CommissioningChecklist_Items.length; i++) {
                if ($scope.commissioningGrp.CommissioningChecklist_Items[i].Item_DocReF == '') {
                    var j = i;
                    var docRefString = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1.replace(/[^\d.]/g, '') + "-" + $scope.commissioningGrp.CommissioningChecklist_Items[i].Item_Name + "||" + $scope.commissioningGrp.CommissioningChecklist_Items[i].Item_GUID + '||' + parseInt(j + 1);
                    if (docRefData == "") {
                        docRefData = docRefString
                    }
                    else { docRefData = docRefData + '#' + docRefString }
                    docRefList.push(docRefData);
                }
            }
        }
        function recursiveFunCall(docRefList, callbackFun) {
            // loop to create placeholders.			
            for (var i = 0; i < $scope.commissioningGrp.CommissioningChecklist_Items.length; i++) {
                var delivObj = $scope.commissioningGrp.CommissioningChecklist_Items[i];
                if (delivObj.Item_GUID && delivObj.Item_GUID != '' && !docRefList.length && !delivObj.TrackerDetails.revisionIds && delivObj.Item_DocReF != '' && delivObj.Items_IS_Old == 'New') {
                    createPlaceHolders(delivObj, callbackFun, i);
                    delivObj.Items_IS_Old = 'Old';
                } else if (!$scope.xhr.dcXhr) {
                    if (docRefList.length != 0) {
                        getPlaceholderCallBack(docRefList[docRefList.length - 1], function (allDocREfdetails) {
                            if (allDocREfdetails.length) {
                                angular.forEach(docRefList, function (index, i) {
                                    var obj = commonApi._.filter($scope.commissioningGrp.CommissioningChecklist_Items, function (allDocREfObj) {
                                        return allDocREfObj.Item_GUID == allDocREfdetails[i].guID
                                    })[0];
                                    obj.Item_DocReF = allDocREfdetails[i].docRef;
                                    obj.Item_Counter = allDocREfdetails[i].Counter;
                                    obj.Item_Display = allDocREfdetails[i].Display;
                                });
                                $scope.xhr.platformXhr = false;
                                $scope.xhr.dcXhr = false;
                                docRefList = [];
                                recursiveFunCall(docRefList, callbackFun);
                            }
                        });
                    } else if (!docRefList.length) {
                        callbackFun();
                    }
                }
            }
        }
        $scope.filterDropdownList = {
            reportByList: reportByParam
        }

        $scope.clearData = function () {
            if ($scope.allAprroved == false && $scope.oriMsgCustomFields.DSI_Current_Stage < 3) {
                $scope.editOriDisp = true;
            }
            if ($scope.commissioningGrp.commissioningChecklist == 'No') {
                $scope.commissioningGrp.CommissioningChecklist_Items = [];
                $scope.commissioningGrp.JobBookEquipment_Lists.JobBookEquipment_List = [];
                $scope.commissioningGrp.PermitProvision_Lists.PermitProvision_List = [];
                $scope.commissioningGrp.StartupAssistance_Lists.StartupAssistance_List = [];
                $scope.addNewItem($scope.commissioningGrp.CommissioningChecklist_Items, $scope.itemStructure);
                $scope.addNewItem($scope.commissioningGrp.JobBookEquipment_Lists.JobBookEquipment_List, $scope.jobBookStructure);
                $scope.addNewItem($scope.commissioningGrp.PermitProvision_Lists.PermitProvision_List, $scope.permitStructure);
                $scope.addNewItem($scope.commissioningGrp.StartupAssistance_Lists.StartupAssistance_List, $scope.startupStructure);
            }
            else {
                if ($scope.cmtDisplay == true) {
                    var operationsRES = $scope.commissioningGrp['operations_RES'];
                    operationsRES[operationsRES.length - 1].opComments = '';
                }
                else
                    $scope.commissioningGrp.suppComments = "";
            }
        }
        function setAutocreateNodes() {
            var newTaskNode = {};
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";

            newTaskNode = angular.copy($scope.ACF_01_FORM);
            newTaskNode.ACF_01_DSI_state = $scope.commissioningGrp.DSI_state;
            newTaskNode.ACF_01_DSI_region = $scope.commissioningGrp.DSI_region;
            newTaskNode.ACF_01_ORI_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_01_DS_FORMTITLE = $scope.oriMsgCustomFields.ORI_FORMTITLE;
            newTaskNode.ACF_01_DSI_projectteam = $scope.commissioningGrp.DSI_projectteam;
            newTaskNode.ACF_01_DSI_RFSDate = $scope.commissioningGrp.DSI_RFSDate;
            newTaskNode.ACF_01_CREATED_BY = $scope.workingUserID[0].Value.split('|')[0].trim();
            newTaskNode.ACF_01_commissioningActivity = $scope.commissioningGrp.commissioningActivity;
            newTaskNode.ACF_01_projectManager = $scope.commissioningGrp.projectManager;
            newTaskNode.ACF_01_operationsManager = $scope.commissioningGrp.operationsManager;
            newTaskNode.ACF_01_constructionCoordinator = $scope.commissioningGrp.constructionCoordinator;
            newTaskNode.ACF_01_operationsTeam = $scope.commissioningGrp.operationsTeam;
            newTaskNode.ACF_01_leadInspector = $scope.commissioningGrp.leadInspector;
            newTaskNode.ACF_01_projectEngineer = $scope.commissioningGrp.projectEngineer;
            newTaskNode.ACF_01_divisionEnvironmental = $scope.commissioningGrp.divisionEnvironmental;
            newTaskNode.ACF_01_rightWayAgent = $scope.commissioningGrp.rightWayAgent;
            newTaskNode.ACF_01_documentationSpecialist = $scope.commissioningGrp.documentationSpecialist;
            newTaskNode.ACF_01_UnitID = $scope.commissioningGrp.UnitID;
            newTaskNode.ACF_01_BuildingName = $scope.commissioningGrp.BuildingName;
            newTaskNode.ACF_01_LocationID = $scope.commissioningGrp.LocationID;
            newTaskNode.ACF_01_CommissioningDate = $scope.commissioningGrp.CommissioningDate;
            newTaskNode.ACF_01_DS_Ref_AppId = $window.AppBuilderFormIDCode;
            newTaskNode.ACF_01_DS_FORMCONTENT1 = '<<DS_Form_ID>>';
            newTaskNode.ACF_01_DS_AUTODISTRIBUTE = "";

            // final pushing node.
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM = [];
            $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.push(newTaskNode);

        }
        function getDateTimeFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
        }
        function setDistribution(userTodistribute, Days, autoDistNode, actionName) {
            if (userTodistribute) {
                var structDistricution = angular.copy($scope.DistributionStructure)
                structDistricution.DS_PROJDISTUSERS = userTodistribute.indexOf('#') > -1 ? userTodistribute.split("#")[0].split("#")[0].split('|')[2].trim() : userTodistribute;
                structDistricution.DS_FORMACTIONS = actionName;
                structDistricution.DS_ACTIONDUEDATE = commonApi.calculateDistDateFromDays({
                    baseDate: getDateTimeFromZone(),
                    days: Days
                })
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistricution);
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = autoDistNode;
            }
        }

        function clearUserActionById(userPrevName) {
            if (!userPrevName) {
                return;
            }
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "1";
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['Auto_Complete_Action'].push({
                DS_AC_TYPE: "clear",
                DS_AC_FORM: $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_AppBuilderID'],
                DS_AC_MSG_TYPE: "ORI",
                DS_AC_USERID: userPrevName,
                DS_AC_ACTION: "2",
                DS_AC_ACTION_REMARKS: "Action Complete"
            });

        }

        function autoDistuserBymsg(strUserName, strAction) {
            if (!strUserName) {
                return;
            }
            strUserName = strUserName.indexOf('#') > -1 ? strUserName.split("#")[0].split("#")[0].split('|')[2].trim() : strUserName

            var msgType = "ORI001";
            $scope.asiteSystemDataReadWrite['Auto_Distribution_Msg_Actions']["DS_AUTODISTRIBUTE_OTHERS_MSG_APP_ID"] = 1;
            $scope.asiteSystemDataReadWrite['Auto_Distribution_Msg_Actions']['Auto_Distribution_Msg_Action'].push({
                DS_MSG_ADO_TYPE: 3,
                DS_MSG_ADO_FORM: "NNG-" + $scope.strFormId,
                DS_MSG_ADO_MSG_TYPE: msgType,
                DS_MSG_ADO_FORMACTIONS: strAction,
                DS_MSG_ADO_ACTIONDUEDATE: commonApi.calculateDistDateFromDays({
                    baseDate: $scope.serverDate,
                    days: 7
                }),
                DS_MSG_ADO_PROJDISTUSERS: strUserName

            });

        };
        $scope.update();
        $window.oriformSubmitCallBack = function () {
            $scope.oriMsgCustomFields.REPEATING_VALUES.DS_AutoDistribute_User_Group.DS_AutoDistribute_Users = [];
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
            //clear action
            $scope.asiteSystemDataReadWrite.Auto_Complete_Actions.Auto_Complete_Action = [];
            $scope.asiteSystemDataReadWrite['Auto_Complete_Actions']['DS_AUTOCOMPLETE_ACTION_APP_ID'] = "";
            //Distribution
            $scope.asiteSystemDataReadWrite.Auto_Distribution_Msg_Actions.Auto_Distribution_Msg_Action = [];
            $scope.asiteSystemDataReadWrite['Auto_Distribution_Msg_Actions']["DS_AUTODISTRIBUTE_OTHERS_MSG_APP_ID"] = "";
            // supp response


            if (!$scope.strCanReply) {
                alert($scope.Msg);
                return true;
            }
            //set attribute

            if ($scope.commissioningGrp.commissioningChecklist == 'Yes') {
                for (var j = 0; j < $scope.commissioningGrp.CommissioningChecklist_Items.length; j++) {
                    if ($scope.commissioningGrp.CommissioningChecklist_Items[j].folderData.folderId == '') {
                        $scope.custAttrSelection($scope.commissioningGrp.CommissioningChecklist_Items[j], $scope.commissioningCustAttr, $scope.commissioningGrp.CommissioningChecklist_Items[j].Item_Name);
                    }
                }
            }
            var strMsg = "";
            if ($scope.commissioningGrp.operationsManager == '') { if (strMsg == '') { strMsg = 'Operations Manager'; } }
            if ($scope.commissioningGrp.constructionCoordinator == '' && $scope.commissioningGrp.commissioningChecklist == 'Yes') {
                if (strMsg == '') { strMsg = 'Construction Coordinator'; }
                else { strMsg = strMsg + ', Construction Coordinator' }
            }
            if ($scope.commissioningGrp.documentationSpecialist == '' && $scope.commissioningGrp.commissioningChecklist == 'Yes') {
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'];
                if (inspectorRES[inspectorRES.length - 1].InsAcceptObj == 'Accept' && $scope.oriMsgCustomFields.DSI_Current_Stage == 4) {
                    if (strMsg == '') { strMsg = 'Documentation Specialist' }
                    else { strMsg = strMsg + ', Documentation Specialist' }
                }
            }
            if (strMsg != '') {

                Notification.error({ title: 'Alert', message: strMsg + ' must be assigned. Contact that Project Manager to have the proper user assignment made on the XTF.' });
                return true;
            }

            if ($scope.commissioningGrp.commissioningChecklist == 'No' && $scope.oriMsgCustomFields.DSI_Current_Stage == 1) {
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                $scope.oriMsgCustomFields.DSI_orignatorID = $scope.workingUserID[0].Value.split('|')[0].trim();
                $scope.oriMsgCustomFields.DSI_submittedUser = $scope.workingUserID[0].Name;
                $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_AUTODISTRIBUTE = "3";
                setDistribution($scope.commissioningGrp.operationsManager, 7, 3, "2#");
                setStatus("Submitted");
                $scope.oriMsgCustomFields.DSI_Next_Stage = parseInt($scope.oriMsgCustomFields.DSI_Current_Stage) + 1;
                if ($scope.cmtDisplay == true) {
                    var operationsRES = $scope.commissioningGrp['operations_RES'];
                    for (var i = 0; i < operationsRES.length; i++) {
                        if (operationsRES[operationsRES.length - 1].Is_Old == "New") {
                            operationsRES[operationsRES.length - 1].opUser = $scope.workingUserID[0].Value;
                            operationsRES[operationsRES.length - 1].resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                            operationsRES[operationsRES.length - 1].Is_Old = "Old";
                        }
                    }
                }
                return false;
            }
            // place holder
            else if ($scope.commissioningGrp.commissioningChecklist == 'Yes' && $scope.oriMsgCustomFields.DSI_Current_Stage == 1
                && $scope.allAprroved == false) {
                if (submitFlag) {
                    return false;
                }
                if ($scope.commissioningGrp.commissioningChecklist.toLowerCase() == 'yes') {

                    // updating list of not created PlaceHolders
                    var placeholderCreatedList = $scope.commissioningGrp.CommissioningChecklist_Items && $scope.commissioningGrp.CommissioningChecklist_Items.filter(function (deObj) {
                        return deObj.TrackerDetails.revisionIds;
                    }) || [];
                    if (placeholderCreatedList.length == $scope.commissioningGrp.CommissioningChecklist_Items.length) {
                        submitFlag = true;
                        $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                        setStatus("Open");
                        // remove loaded class to show loader	
                        $element.removeClass('loaded');
                        // reset while clicking on submit button.
                        window.submitForm(1);

                    } else {
                        $scope.xhr.activeAjaxCallCount = 0;
                        $scope.notCreatedPlaceHolder = $scope.commissioningGrp.CommissioningChecklist_Items && $scope.commissioningGrp.CommissioningChecklist_Items.filter(function (deObj) {
                            return !deObj.TrackerDetails.revisionIds;
                        }) || [];
                    }
                }
                var callbackFun = function () {
                    submitFlag = true;
                    setStatus("Open");
                    if ($scope.isChkcreated == false) {
                        setAutocreateNodes();
                    }
                    else {
                        $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                    }
                    // remove loaded class to show loader
                    $element.removeClass('loaded');
                    $window.submitForm(1);
                };
                docRefList = [];
                updateUnavailableGuidStatus();
                recursiveFunCall(docRefList, callbackFun);
                return true;
            }
            //operations Res
            else if ($scope.commissioningGrp.commissioningChecklist == 'No' && $scope.oriMsgCustomFields.DSI_Current_Stage == 2) {

                var operationsRES = $scope.commissioningGrp['operations_RES'];
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = '';
                if ($scope.commissioningGrp.operations_RES[operationsRES.length - 1].opAcceptObj == 'Accept') {
                    setStatus("Not required")
                } else if ($scope.commissioningGrp.operations_RES[operationsRES.length - 1].opAcceptObj == 'Object') {
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 1;
                    setDistribution($scope.oriMsgCustomFields.DSI_orignatorID, 7, 3, "2#");
                    setStatus("Objection")
                }
                for (var i = 0; i < operationsRES.length; i++) {
                    if (operationsRES[i].Is_Old == "New") {
                        operationsRES[i].opUser = $scope.workingUserID[0].Value;
                        operationsRES[i].resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                        operationsRES[i].Is_Old = "Old";
                    }
                }
                return false;
            }
            //Inspector REs
            else if ($scope.commissioningGrp.commissioningChecklist == 'Yes' && ($scope.oriMsgCustomFields.DSI_Current_Stage == 1 || $scope.oriMsgCustomFields.DSI_Current_Stage == 3) && $scope.allAprroved == true) {


                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "2#");
                setStatus("Submitted");
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'];
                for (var i = 0; i < inspectorRES.length; i++) {
                    if (inspectorRES[i].InsIsOld == "New") {
                        inspectorRES[i].Inspector = $scope.workingUserID[0].Value;
                        inspectorRES[i].Ins_resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                        inspectorRES[i].InsIsOld = "Old";
                        inspectorRES[i].Role = "Inspector";
                    }
                }
                $scope.oriMsgCustomFields.DSI_Next_Stage = 4;
                return false;
            }
            //Constructor REs
            else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 4) {
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'];
                inspectorRES[inspectorRES.length - 1].RES_User = $scope.workingUserID[0].Value;
                inspectorRES[inspectorRES.length - 1].Ins_resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                inspectorRES[inspectorRES.length - 1].InsIsOld = "Old";
                inspectorRES[inspectorRES.length - 1].Role = "Construction Coordinator";

                if (inspectorRES[inspectorRES.length - 1].InsAcceptObj == 'Accept') {
                    autoDistuserBymsg($scope.commissioningGrp.operationsManager, 2)
                    clearUserActionById($scope.workingUserID[0].Value.split('|')[0].trim())
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 5;
                } else {
                    setStatus("Objection");
                    setDistribution(inspectorRES[0].Inspector.split('|')[0].trim(), 7, 3, "2#");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
                }

                return false;
            }
            //Operation Manger  REs
            else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 5) {
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'];
                inspectorRES[inspectorRES.length - 1].RES_User = $scope.workingUserID[0].Value;
                inspectorRES[inspectorRES.length - 1].Ins_resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                inspectorRES[inspectorRES.length - 1].InsIsOld = "Old";
                inspectorRES[inspectorRES.length - 1].Role = "Operations Manger";
                if (inspectorRES[inspectorRES.length - 1].InsAcceptObj == 'Accept') {
                    setStatus("Complete");
                    setDistribution($scope.commissioningGrp.documentationSpecialist, 7, 3, "2#");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 6;
                } else {
                    setStatus("Objection");
                    setDistribution(inspectorRES[0].Inspector.split('|')[0].trim(), 7, 3, "2#");
                    setDistribution($scope.commissioningGrp.constructionCoordinator, 7, 3, "7#");
                    $scope.oriMsgCustomFields.DSI_Next_Stage = 3;
                }

                return false;
            }
            //DS REs
            else if ($scope.oriMsgCustomFields.DSI_Current_Stage == 6) {
                $scope.asiteSystemDataReadWrite.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
                var inspectorRES = $scope.commissioningGrp['Inspector_RES'];
                inspectorRES[inspectorRES.length - 1].RES_User = $scope.workingUserID[0].Value;
                inspectorRES[inspectorRES.length - 1].Ins_resDate = $scope.formatDate(new Date(), 'mm/dd/yy');
                inspectorRES[inspectorRES.length - 1].InsIsOld = "Old";
                inspectorRES[inspectorRES.length - 1].Role = "Documentation Specialist";
                setStatus("Closed");
                $scope.oriMsgCustomFields.DSI_Next_Stage = 6;
                return false;
            }
        };
    }

    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof oriformSubmitCallBack !== "undefined") {
        return oriformSubmitCallBack();
    }
}