/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/table.util', '../components/item.selection'], function (angular, mainModule, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, commonApi, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        var tempData = $scope.getFormData();

        $scope.data = {
            myFields: tempData
        };

        $scope.getServerTime(function (serverDate) {
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
        });
        $scope.isDataLoaded = true;

        $scope.structDistribution = {
            DS_PROJDISTUSERS: "",
            DS_FORMACTIONS: "",
            DS_ACTIONDUEDATE: ""
        }
        $scope.distributeActionstruct = {
            DS_ADO_TYPE: "",
            DS_ADO_FORM: "",
            DS_ADO_MSG_TYPE: "",
            DS_ADO_FORMACTIONS: "",
            DS_ADO_PROJDISTGROUPS: "",
            DS_ADO_ACTIONDUEDATE: "",
            DS_ADO_PROJDISTUSERS: ""
        }
        $scope.furtherActionuserstruct = {
            RFI_Dist_User: "",
            RFI_Proj_Roles: "",
            RFI_Actions: "",
            isSelected: false
        }
        $scope.ConActionuserstruct = {
            Con_Dist_User: "",
            Con_Proj_Roles: "",
            Con_Actions: "",
            Con_isSelected: false
        }
        $scope.furtherActiongroupstruct = {
            RFI_Group_Name: "",
            RFI_User_Id: "",
            RFI_User_Name: "",
            RFI_Action_Name: "",
            isSelected: false
        }
        var oriUserStruct = {
            ORI_Dist_User: "",
            ORI_Actions: "",
            ORI_Proj_Roles: ""
        }
        var oriActionGroupStruct = {
            ORI_Group_Name: "",
            ORI_User_Id: "",
            ORI_User_Name: "",
            ORI_Action_Name: ""
        }
        var paramObject = {
            strTitle: "",
            strContractorRefNo: "",
            strReasonforRequst: "",
            strActionRequested: "",
            strProbabbleCostEffect: "",
            strProbabbleTimeEffect: "",
            strInitialEstimatedCost: "",
            strInitialEstimatedtime: "",
            strPriority: "",
            strDrawingNo: "",
            strDetailNo: "",
            strCSICode: "",
            strOtherRef: "",
            strInfoRequested: "",
            strRecommendation: "",
            strNotes: "",
            strSubRef: "",
            strPrimaryres: "",
            strRoles: "",
            strUsersRoles: "",
            strGroups: "",
            strUsersGroups: "",
            strUsersGroupsName: "",
            strPrimaryResGroup: "",
			Location_List:{
				Location_Val: ""
			}
        };
        var autocompleteMsgStructure = {
            DS_MSG_AC_TYPE: "",
            DS_MSG_AC_FORM: "",
            DS_MSG_AC_MSG_TYPE: "",
            DS_MSG_AC_USERID: "",
            DS_MSG_AC_ACTION: "",
            DS_MSG_AC_ACTION_REMARKS: ""
        }
        $scope.tableUtilSettings = {
            Response_Distribution_Users: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy($scope.furtherActionuserstruct),
                hideControlIcon: {
                    insertBefore: 0,
                    editRow: 0
                },
                deleteAllRowTooltip: "Remove Responder",
                deleteCurrRowMsg: "Remove Responder",
                deleteSelectedMsg: "Remove Responder"
            },
            Con_Distribution_Users: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                checkboxModelKey: "Con_isSelected",
                newStaticObject: angular.copy($scope.ConActionuserstruct),
                hideControlIcon: {
                    insertBefore: 0,
                    editRow: 0
                },
                deleteAllRowTooltip: "Remove Responder",
                deleteCurrRowMsg: "Remove Responder",
                deleteSelectedMsg: "Remove Responder"
            },
            Response_Groups: {
                tooltip: "select to remove/remove all/Insert new data",
                hasDefaultRecord: false,
                checkboxModelKey: "isSelected",
                newStaticObject: angular.copy($scope.furtherActiongroupstruct),
                hideControlIcon: {
                    insertBefore: 0,
                    editRow: 0
                },
                deleteAllRowTooltip: "Remove Responder",
                deleteCurrRowMsg: "Remove Responder",
                deleteSelectedMsg: "Remove Responder"
            }
        }

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.ORI_MSG_Fields = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields;
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
        $scope.DS_FORMSTATUS = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_FORMSTATUS;
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
        var DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
        $scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
        var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.DS_ALL_FORMSTATUS = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');
        $scope.DS_MTA_RFI_GET_PREVIOUS_DATA = $scope.getValueOfOnLoadData('DS_MTA_RFI_GET_PREVIOUS_DATA');
        var DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
        var DS_MTA_RFI_GET_ALL_DATA = $scope.getValueOfOnLoadData('DS_MTA_RFI_GET_ALL_DATA');
        var DS_WORKSPACE_ROLES_with_ID = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES_with_ID');
        $scope.DS_FORMACTIONS = $scope.getValueOfOnLoadData('DS_FORMACTIONS');
        var DS_DIST_GROUP_DETAILS = $scope.getValueOfOnLoadData('DS_DIST_GROUP_DETAILS');
        var DS_DLF_GET_DTF_DISTRIBUTION_LIST = $scope.getValueOfOnLoadData('DS_DLF_GET_DTF_DISTRIBUTION_LIST');
        var DS_Get_All_Responses = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
        var DS_GET_GUID = $scope.getValueOfOnLoadData('DS_GET_GUID');
        var DS_WORKINGUSER_ALL_ROLES = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ALL_ROLES');
        var DS_ASI_Get_All_Default_FormSettingDetails = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
        var DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
        var DS_ASI_GET_Organization_Logo = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
        var mtaHeaderDetails = $scope.getValueOfOnLoadData('DS_MTA_PSR_Header_Details')[0];
        $scope.projectDetails = $scope.oriMsgCustomFields.projectDetails;
        var strDraftResMsg = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT_RES_MSG;
        var DS_INCOMPLETE_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');
        var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
        var DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA = $scope.getValueOfOnLoadData('DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA');
        var DS_FIRST_RES_MSG_DTLS = $scope.getValueOfOnLoadData('DS_FIRST_RES_MSG_DTLS');
        

        $scope.DS_PROJDISTGROUPS = $scope.getValueOfOnLoadData('DS_PROJDISTGROUPS');
        var DS_RES_COUNT = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_RES_COUNT;
        var setPsrProjectDetails = function (dataObj) {
            $scope.projectDetails.Planning_Number = dataObj.Value2;
            $scope.projectDetails.ProgramManager = dataObj.Value3;
            $scope.projectDetails.ProjectPSE = dataObj.Value4;
            $scope.projectDetails.ProjectDescr = dataObj.Value5;
            $scope.projectDetails.KeyProject = dataObj.Value6;
            $scope.projectDetails.ConstructionMgr = dataObj.Value7;
            $scope.projectDetails.ProjectStatus = dataObj.Value8;
            $scope.projectDetails.ProjectPhase = dataObj.Value9;
            $scope.projectDetails.ProgramOfficer = dataObj.Value10;
        };

        $scope.currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
        var currentUserOrg = WorkingUserID['0'].Name.split(',')[1].trim();
        if (currentViewName == "ORI_VIEW") {

            if ($scope.strFormId == "") {
                $scope.oriMsgCustomFields.Originator_Id = $scope.currentUserid;
                var strDuedays = getDistdays();
                if (strDuedays) {
                    calculateDistDate(strDuedays, function (retdate) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = retdate;
                    });
                }

                var strFormStatusId = getFormStatusId("Open");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }
            if ($scope.strFormId == "" || $scope.strIsDraft == "YES") {
                if (mtaHeaderDetails) {
                    setPsrProjectDetails(mtaHeaderDetails);
                }

                $scope.csiCode = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "CSI Code" && val.Value11 == "Active";
                });

                $scope.reasonForRequest = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "Reason For Request" && val.Value11 == "Active";
                });

                $scope.actionRequested = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "Action Requested" && val.Value11 == "Active";
                });

                $scope.probabbleCostEffect = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "Probable Cost Effect" && val.Value11 == "Active";
                });

                $scope.probabbleTimeEffect = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "Probable Time Effect" && val.Value11 == "Active";
                });

                $scope.priority = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3 == "Priority" && val.Value11 == "Active";
                });

                $scope.locationAttrList = commonApi.getItemSelectionList({
                    arrayObject: getConfigurableAttriburteByType("Location Attribute"),
                    groupNameKey: "",
                    modelKey: "Value8",
                    displayKey: "Value8"
                });

                $scope.locationChangeEvt = function (obj) {
                    $scope.oriMsgCustomFields.Location_Attribute = obj;
                    $scope.oriMsgCustomFields.Location_Group.Location_List = [];
                    var temp = [];
                    for (var i = 0; i < obj.length; i++) {
                        temp.push({
                            Location_Val: obj[i]
                        });
                    }
                    $scope.oriMsgCustomFields.Location_Group.Location_List = angular.copy(temp);
                };
            }
        }
        if (currentViewName == "RES_VIEW") {

            if ($scope.strFormId != "" || $scope.strIsDraft == "NO") {

                var isContractorUser = isCurrentUserContractor();
                $scope.strCanReply = 'yes';

                if (isContractorUser && isContractorUser.length) {
                    if (isContractorUser === 'YES') {
                        $scope.strCanReply = '';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_DRAFT_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                    } else if (isContractorUser === 'NO') {

                        $scope.strCanReply = 'yes';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_DRAFT_MSG'] = '0';
                    }
                }
                if ($scope.DS_FORMSTATUS.toLowerCase().indexOf('close') > -1) {
                    var isPrimaryResponder = isCurrentUserPrimaryResponder();

                    if (isPrimaryResponder != 'NO') {
                        $scope.strCanReply = 'yes';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '0';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_DRAFT_MSG'] = '0';

                    }else if (isPrimaryResponder === 'NO') {
                        $scope.strCanReply = '';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_SEND_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                        $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_DRAFT_MSG'] = '1 | You are not authorized to respond to this Notification. You therefore cannot send a reply, please click the cancel button at the bottom of the form.';
                }
            }
        }
            if (strDraftResMsg != "YES") {
                getPreviousData($scope.strFormId);
            }            
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
            $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "";
            if (WorkingUserID.length) {
                var strUser = WorkingUserID['0'].Value.trim();
                var actionsObj = commonApi._.filter(DS_INCOMPLETE_ACTIONS, function (val) {
                    return val.Name == "Respond" && val.Value.indexOf($scope.currentUserid) > -1;
                });
                if ($scope.DS_FORMSTATUS.toLowerCase() == 'open' && actionsObj.length && DS_RES_COUNT == '0') {
                    $scope.oriMsgCustomFields.Primary_Responder = strUser.split('|')[0].trim() + "#" + strUser.split('#')[1].trim();
                    clearActionByMsg();
                }
                $scope.resMsgCustomFields.RESPONSES.RFI_ResponseBy = strUser;
                $scope.getServerTime(function (serverDate) {
                    $scope.resMsgCustomFields.RESPONSES.RFI_ResponseDate = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
                });
            }
            if (DS_MTA_RFI_GET_ALL_DATA.length) {
                $scope.oriMsgCustomFields.Originator_Id = DS_MTA_RFI_GET_ALL_DATA[0].Value2.trim();
                $scope.oriMsgCustomFields.ORI_FORMTITLE = DS_MTA_RFI_GET_ALL_DATA[0].Value4.trim();
            }
        }        
        if (currentViewName == "ORI_VIEW" || currentViewName == "RES_VIEW") {
            setClientlogo();
            $scope.roles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {                                              
                return val.Name.toLowerCase().indexOf('contractor')==-1;  
            });
            $scope.conRoles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {                
                return val.Name.toLowerCase().indexOf('contractor')>=0;
            });
        }
        if (currentViewName == "ORI_PRINT_VIEW") {
            $scope.strRole = commonApi._.filter(DS_WORKINGUSER_ALL_ROLES, function (val) {
                return val.Value.indexOf('Contractor') != -1
            });
        }

        if(currentViewName=="ORI_PRINT_VIEW" || currentViewName=="RES_PRINT_VIEW"){
            var isContractorUser=isCurrentUserContractor();
            if(isContractorUser && isContractorUser.length){
                if(isContractorUser==="YES"){
                    $scope.oriMsgCustomFields.IsContractorUser="YES";
                }
                else if(isContractorUser==="NO"){
                    $scope.oriMsgCustomFields.IsContractorUser="NO";
                }
            }
        }
        function getWorkingUserId() {
            var strWorkingUserId = WorkingUserID[0].Value.split('|')[0].trim() || "";
            return strWorkingUserId;
        }
        function isCurrentUserContractor(){
            var workingUserID = getWorkingUserId();

            if (DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA.length) {

                for (var i = 0; i < DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA.length; i++) {

                    if(DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA[i].Value3.length){
                        var conId = DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA[i].Value3.split('|')[2].trim();
                        if (conId) {
                            if (conId === workingUserID) {
                               return "YES";
                            } 
                        }
                    }
                    
                }
                return "NO";
            }
        }
        function isCurrentUserPrimaryResponder() {
            var workingUserID = getWorkingUserId();

            if (DS_FIRST_RES_MSG_DTLS.length) {

                for (var i = 0; i < DS_FIRST_RES_MSG_DTLS.length; i++) {

                    if (DS_FIRST_RES_MSG_DTLS[i].Value3.length) {
                        var primaryUserId = DS_FIRST_RES_MSG_DTLS[i].Value2.trim();
                        if (primaryUserId) {
                            if (primaryUserId === workingUserID) {                                
                                return DS_FIRST_RES_MSG_DTLS[i].Value2.trim() + '#' + DS_FIRST_RES_MSG_DTLS[i].Value3.trim();
                            }
                        }
                    }
                }
                return 'NO';
            }
        }
        $scope.update();

        $scope.addNewItem = function (repeatingData, fromStructure) {
            var item = angular.copy(fromStructure);
            repeatingData.push(item);
        };

        /**
         * Set ConfigurableAttriburte Type Value in Location dropdown.
         */
        function getConfigurableAttriburteByType(type) {
            var location = [];
            if (type) {
                location = commonApi._.filter(DS_ASI_Configurable_Attributes, function (val) {
                    return val.Value3.toLowerCase() == type.toLowerCase() && val.Value11.indexOf('Active') != -1
                });
            }
            return location;
        }
        
        function getFormStatusId(strStatus) {
            //get status according pass parameter
            if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length > 0) {
                var statudObj = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
                    return val.Name.toLowerCase().trim() == strStatus.toLowerCase().trim();
                });
                if (statudObj.length) {
                    return statudObj[0].Value;
                }
            }
            return "";
        }

        function setAutoDistribution(strUser, strAction, strDueDate) {
            if (strDueDate) {
                strDueDate = $scope.formatDate(new Date(strDueDate), 'yy-mm-dd');
            }
            //get copy of distribution and set user ,date ,action to distribute
            var structDistribution = angular.copy($scope.structDistribution)
            structDistribution.DS_PROJDISTUSERS = strUser;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = strDueDate;

            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
        }

        function calculateDistDate(days, callback) {
            var strDueDate = "";
            $scope.getServerTime(function (serverDate) {
                if (days) {
                    var d = new Date(serverDate);
                    d.setDate(d.getDate() + parseInt(days));
                    var month = d.getMonth() + 1;
                    var day = d.getDate();
                    strDueDate = d.getFullYear() + '-' +
                        (month < 10 ? '0' : '') + month + '-' +
                        (day < 10 ? '0' : '') + day;
                }
                callback(strDueDate);
            });
        }

        function setFurtherAction() {
            var strUserFromRoles = $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users;
            var strUserFromGroup = $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups;
            if (strUserFromRoles.length == 0 && strUserFromGroup.length == 0) {
                alert("Please select atleast one user for distribution");
                return true;
            }
            $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
            var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;
            var strDuedays = getDistdays();
            if (strDuedays) {
                calculateDistDate(strDuedays, function (retdate) {
                    var distDate = retdate;
                    if (strUserFromRoles.length) {
                        for (var i = 0; i < strUserFromRoles.length; i++) {
                            var strResponder = strUserFromRoles[i].RFI_Dist_User;
                            var strAction = strUserFromRoles[i].RFI_Actions;
                            var strRole = strUserFromRoles[i].RFI_Proj_Roles;

                            if (strRole && (!strResponder || !strAction)) {
                                alert("Please select atleast one user for distribution");
                                return true;
                            }

                            if (strResponder && strAction && strRole) {
                                var strid = strResponder.split('|')[2].split('#')[0].trim();
                                var autoDiststruct = angular.copy($scope.distributeActionstruct);
                                autoDiststruct.DS_ADO_TYPE = "3";
                                autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                                autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                                autoDiststruct.DS_ADO_FORMACTIONS = strAction.split('#')[0].trim();
                                autoDiststruct.DS_ADO_ACTIONDUEDATE = distDate;
                                autoDiststruct.DS_ADO_PROJDISTUSERS = strid;
                                insertpoint.push(autoDiststruct);
                            }
                        }

                    }
                    if (strUserFromGroup.length) {
                        for (var i = 0; i < strUserFromGroup.length; i++) {
                            var strResponderid = strUserFromGroup[i].RFI_User_Id;
                            var strAction = strUserFromGroup[i].RFI_Action_Name;
                            var strGroup = strUserFromGroup[i].RFI_Group_Name;

                            if (strGroup && (!strResponderid || !strAction)) {
                                alert("Please select atleast one user for distribution");
                                return true;
                            }

                            if (strResponderid && strAction && strGroup) {
                                var autoDiststruct = angular.copy($scope.distributeActionstruct);
                                autoDiststruct.DS_ADO_TYPE = "3";
                                autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                                autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                                autoDiststruct.DS_ADO_FORMACTIONS = strAction.split('#')[0].trim();
                                autoDiststruct.DS_ADO_ACTIONDUEDATE = distDate;
                                autoDiststruct.DS_ADO_PROJDISTUSERS = strResponderid;
                                insertpoint.push(autoDiststruct);
                            }
                        }
                    }

                    if (!insertpoint.length) {
                        alert("Please select atleast one user for distribution");
                        return true;
                    }

                    var strPrimaryres = $scope.oriMsgCustomFields.Primary_Responder;
                    if (strPrimaryres) {
                        var strPrimaryresId = strPrimaryres.split('#')[0].trim();
                        var autoDiststruct = angular.copy($scope.distributeActionstruct);
                        autoDiststruct.DS_ADO_TYPE = "3";
                        autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                        autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                        autoDiststruct.DS_ADO_FORMACTIONS = "2";
                        autoDiststruct.DS_ADO_ACTIONDUEDATE = distDate;
                        autoDiststruct.DS_ADO_PROJDISTUSERS = strPrimaryresId;
                        insertpoint.push(autoDiststruct);
                    }
                    if (insertpoint.length) {
                        $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS = "1";
                    }
                    $scope.submitFlag = true;
                    $window.submitForm(1);
                });
            }
        }
        function setForinfoContractor() {
            var strOrigid = $scope.oriMsgCustomFields.Originator_Id;
            var strUserFromRoles = $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users;
            var strUserFromGroup = $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups;
            var contractorlist = DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA;
            var strConUsersFromRoles = $scope.resMsgCustomFields.Con_Distribution.Con_Distribution_Users;
            $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
            var strResponder = "",
                strRole = "",
                strResponderid = "",
                strGroup = "",
                strid = "",
                strAction = "7";

            var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;
            if (strOrigid) {
                var autoDiststruct = angular.copy($scope.distributeActionstruct);
                autoDiststruct.DS_ADO_TYPE = "3";
                autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                autoDiststruct.DS_ADO_FORMACTIONS = strAction;
                autoDiststruct.DS_ADO_PROJDISTUSERS = strOrigid;
                insertpoint.push(autoDiststruct);
            }

            if (strUserFromRoles.length) {
                for (var i = 0; i < strUserFromRoles.length; i++) {
                    strResponder = strUserFromRoles[i].RFI_Dist_User;
                    strRole = strUserFromRoles[i].RFI_Proj_Roles;

                    if (strResponder && strAction && strRole) {
                        strid = strResponder.split('|')[2].split('#')[0].trim();
                        var autoDiststruct = angular.copy($scope.distributeActionstruct);
                        autoDiststruct.DS_ADO_TYPE = "3";
                        autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                        autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                        autoDiststruct.DS_ADO_FORMACTIONS = strAction;
                        autoDiststruct.DS_ADO_PROJDISTUSERS = strid;
                        insertpoint.push(autoDiststruct);
                    }
                }
            }
            if(contractorlist.length){
                for (var i = 0; i < contractorlist.length; i++) {
                    strResponder = contractorlist[i].Value3.trim();
                   
                    if (strResponder && strAction) {
                        strid = strResponder.split('|')[2].trim();
                        var autoDiststruct = angular.copy($scope.distributeActionstruct);
                        autoDiststruct.DS_ADO_TYPE = "3";
                        autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                        autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                        autoDiststruct.DS_ADO_FORMACTIONS = strAction;
                        autoDiststruct.DS_ADO_PROJDISTUSERS = strid;
                        insertpoint.push(autoDiststruct);
                    }
                }
            }
            if(strConUsersFromRoles.length){
                for (var i = 0; i < strConUsersFromRoles.length; i++) {
                    strResponder = strConUsersFromRoles[i].Con_Dist_User;
                   
                    if (strResponder && strAction) {
                        strid = strResponder.split('|')[2].split('#')[0].trim();
                        var autoDiststruct = angular.copy($scope.distributeActionstruct);
                        autoDiststruct.DS_ADO_TYPE = "3";
                        autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                        autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                        autoDiststruct.DS_ADO_FORMACTIONS = strAction;
                        autoDiststruct.DS_ADO_PROJDISTUSERS = strid;
                        insertpoint.push(autoDiststruct);
                    }
                }
            }
            if (strUserFromGroup.length) {
                for (var i = 0; i < strUserFromGroup.length; i++) {
                    strResponderid = strUserFromGroup[i].RFI_User_Id;
                    strGroup = strUserFromGroup[i].RFI_Group_Name;

                    if (strResponderid && strAction && strGroup) {
                        var autoDiststruct = angular.copy($scope.distributeActionstruct);
                        autoDiststruct.DS_ADO_TYPE = "3";
                        autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                        autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                        autoDiststruct.DS_ADO_FORMACTIONS = strAction;
                        autoDiststruct.DS_ADO_PROJDISTUSERS = strResponderid;
                        insertpoint.push(autoDiststruct);
                    }
                }
            }

            if (insertpoint.length) {
                $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS = "1";
            }
        }        
        function setDistributiontoAlluser(strPrimaryres) {
            if (DS_DLF_GET_DTF_DISTRIBUTION_LIST && DS_DLF_GET_DTF_DISTRIBUTION_LIST.length) {
                var userlist = [];
                var contractordata = DS_MTA_RFI_GET_CON_DISTRIBUTION_DATA;
                var conlist=[];
                var strOrigid = $scope.oriMsgCustomFields.Originator_Id;
                $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;
                var strActionId = "32";

                if (contractordata.length) {

                    for (var i = 0; i < contractordata.length; i++) {
                       
                        if(contractordata[i].Value3.length){
                            var conId = contractordata[i].Value3.split('|')[2].trim();
                            if (conId) {
                                conlist.push(conId);
                            }
                        }                        
                    }
                }

                for (var i = 0; i < DS_DLF_GET_DTF_DISTRIBUTION_LIST.length; i++) {
                    var strResponder = DS_DLF_GET_DTF_DISTRIBUTION_LIST[i].Value2.trim();
                    var removeCon = "NO"
                    if (strOrigid == strResponder)
                        continue;

                    if (userlist.indexOf(strResponder) > -1)
                        continue;

                    if(conlist.indexOf(strResponder)>-1){
                        removeCon="YES";
                    }

                    if (strResponder == strPrimaryres)
                        strActionId = "7";
                    else
                        strActionId = "32";

                    if (strResponder) {
                        if (removeCon === "NO") {
                            userlist.push(strResponder);
                            var autoDiststruct = angular.copy($scope.distributeActionstruct);
                            autoDiststruct.DS_ADO_TYPE = "3";
                            autoDiststruct.DS_ADO_FORM = $scope.strFormId;
                            autoDiststruct.DS_ADO_MSG_TYPE = "RES";
                            autoDiststruct.DS_ADO_FORMACTIONS = strActionId;
                            autoDiststruct.DS_ADO_PROJDISTUSERS = strResponder;
                            insertpoint.push(autoDiststruct);
                        }
                    }
                }
                if (insertpoint.length) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS = "1";
                }
            }
        }

        $scope.buildItemSelecionArray = function (currObj, strVal) {
            if (strVal != '1') {
                currObj.RFI_Dist_User = "";
            }
            var strRole = currObj.RFI_Proj_Roles,
                users = "";
            if (strRole) {
                var roleName = strRole.split('#')[1].trim();
                if (currentViewName == "ORI_VIEW") {
                    users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                        return val.Value.indexOf(roleName) > -1;
                    });
                } else {
                    users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                        return val.Value.indexOf(roleName) > -1
                    });
                }
            }

            var lineData = [];
            for (var i = 0; i < users.length; i++) {
                lineData.push({
                    optlabel: "",
                    options: [{
                        displayValue: users[i].Name,
                        modelValue: users[i].Value,
                        checked: false
                    }]
                });
            }
            currObj.lineData = angular.copy(lineData);
        }

        $scope.chekDuplicateusers = function (args) {
            var isDuplicate = $scope.checkDuplicateValue(args);
            if (!isDuplicate)
                $scope.buildItemSelecionArray(args.model);
        }

        $scope.filterUserFromgroup = function (currObj, strVal) {
            if (strVal != "1") {
                currObj.RFI_User_Id = "";
                currObj.RFI_User_Name = "";
            }
            var strGroup = currObj.RFI_Group_Name,
                usersObj;
            if (currentViewName == "ORI_VIEW") {
                usersObj = commonApi._.filter(DS_DIST_GROUP_DETAILS, function (val) {
                    return val.Value2 == strGroup;
                });
            } else {
                usersObj = commonApi._.filter(DS_DIST_GROUP_DETAILS, function (val) {
                    return val.Value2 == strGroup;
                });
            }
            var lineData = [];
            for (var i = 0; i < usersObj.length; i++) {
                lineData.push({
                    optlabel: "",
                    options: [{
                        displayValue: usersObj[i].Value11,
                        modelValue: usersObj[i].Value5,
                        checked: false
                    }]
                });
            }
            currObj.lineData = angular.copy(lineData);
        }

        $scope.checkDuplicateusergroup = function (args) {
            var isDuplicate = $scope.checkDuplicateValue(args);
            if (!isDuplicate)
                $scope.filterUserFromgroup(args.model);
        }

        $scope.onFurtherinfochange = function (str) {
            if (str == "Yes") {
                $scope.oriMsgCustomFields.Complete_response = "No";
                $scope.resMsgCustomFields.Final_Responses.ALL_RES.Response = "";
                $scope.resMsgCustomFields.Final_Responses.ALL_RES.ResponseBy = "";
                $scope.resMsgCustomFields.Final_Responses.ALL_RES.ResponseDate = "";
                $scope.oriMsgCustomFields.State = "";
                var strFormStatusId = getFormStatusId("Under Review");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }
            flushDistributionNodes();
        }

        $scope.onRescompletechange = function (str) {
            if (str == "Yes") {
                $scope.oriMsgCustomFields.Further_Info_Required = "No";
                $scope.oriMsgCustomFields.State = "Locked";
                setAllResponses();
                var strFormStatusId = getFormStatusId("RFI-Closed");
                if (strFormStatusId) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
                }
            }
            flushDistributionNodes();
        }

        function flushDistributionNodes() {
            $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users = [];
            $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups = [];
            $scope.resMsgCustomFields.Con_Distribution.Con_Distribution_Users = [];
            $scope.addNewItem($scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users, $scope.furtherActionuserstruct);
            $scope.addNewItem($scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups, $scope.furtherActiongroupstruct);
            $scope.addNewItem($scope.resMsgCustomFields.Con_Distribution.Con_Distribution_Users, $scope.ConActionuserstruct);
        }

        $scope.setUserNameFromsp = function (currObj) {
            var userName = "";
            if (currObj) {
                var strid = currObj.RFI_User_Id;
                if (strid) {
                    var userObj = commonApi._.filter(DS_DIST_GROUP_DETAILS, function (val) {
                        return val.Value5 == strid;
                    });
                    if (userObj.length) {
                        userName = userObj[0].Value11;
                    }
                }
            }
            currObj.RFI_User_Name = userName;
        }
        $scope.createContractorItemSelectionArray = function (currObj, strVal) {
            if (strVal != '1') {
                currObj.Con_Dist_User = "";
            }
            var strRole = currObj.Con_Proj_Roles,
                users = "";
            if (strRole) {
                var roleName = strRole.split('#')[1].trim();
                if (currentViewName == "ORI_VIEW") {
                    users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                        
                        var roleNamePipe = val.Value.split('|')[0].trim(),                            
                            roleNamePipeSplit = roleNamePipe.split(','),
                            roleNameSP = null;

                        for (var i = 0; i < roleNamePipeSplit.length; i++) {
                            roleNameSP = roleNamePipeSplit[i].trim();
                            if (roleNameSP.length) {
                                if (roleNameSP == roleName) {
                                    return true;                                    
                                }
                            }
                        }                        
                    });
                } else {
                    users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                        return val.Value.split('|')[0].indexOf(roleName) > -1
                    });
                }
            }

            var lineData = [];
            for (var i = 0; i < users.length; i++) {
                lineData.push({
                    optlabel: "",
                    options: [{
                        displayValue: users[i].Name,
                        modelValue: users[i].Value,
                        checked: false
                    }]
                });
            }
            currObj.lineData = angular.copy(lineData);
        }
        $scope.chekDuplicateConUsers = function (args) {
            var isDuplicate = $scope.checkDuplicateValue(args);
            if (!isDuplicate)
                $scope.createContractorItemSelectionArray(args.model);
        }

        $scope.onRfiChange = function (strVal) {
            if (strVal) {
                var repObj = commonApi._.filter($scope.DS_MTA_RFI_GET_PREVIOUS_DATA, function (val) {
                    return val.Value2 == strVal;
                });
                if (repObj.length) {
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = repObj[0].Value3;
                    var strRev = repObj[0].Value4.trim();
                    var strAppcode = repObj[0].Value5.trim();
                    if (strRev) {
                        var intRev = parseInt(strRev);
                        intRev++;
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = intRev;
                    }
                    if (strAppcode) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AUTO_ASSOC_FORMS = ":#:" + strAppcode;
                    }
                }
            } else {
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = "";
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = "";
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AUTO_ASSOC_FORMS = "";
            }
            getPreviousData(strVal);
        }

        function setAllResponses() {
            if (DS_Get_All_Responses.length) {
                var finalResponse = "";
                for (var i = 0; i < DS_Get_All_Responses.length; i++) {
                    var strResponse = DS_Get_All_Responses[i].Value7.trim();
                    var strName = DS_Get_All_Responses[i].Value2.trim();
                    finalResponse = finalResponse + "[" + strName + "] " + strResponse + "\n\n";
                }
                $scope.resMsgCustomFields.RESPONSES.RFI_Response = finalResponse;
                $timeout(function () {
                    $scope.expandTextAreaOnLoad();
                }, 1000);
            }
        }
        $scope.restrictCharOnlyNumber = function (event, charlist) {
            $scope.restrictChar(event, charlist);
            var validKeys = [46, 8, 9, 27, 13, 110, 190];
            // Allow: backspace, delete, tab, escape, enter and .
            if (validKeys.indexOf(event.keyCode) !== -1 ||
                // Allow: Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X, Command+A
                ((event.keyCode == 65 || event.keyCode == 86 || event.keyCode == 88 || event.keyCode == 67) && (event.ctrlKey === true || event.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (event.keyCode >= 35 && event.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if (((event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) && (event.keyCode < 96 || event.keyCode > 105)) || (event.shiftKey && event.keyCode > 57)) {
                event.preventDefault();
            }
        }

        $scope.restrictCharOnlyNumberPaste = function (event) {
            var inputValue;
            if ($window.clipboardData) { //IE
                inputValue = $window.clipboardData.getData('Text');
            } else {
                inputValue = event.originalEvent.clipboardData.getData('text/plain');
            }
            if (isNaN(inputValue) || inputValue.indexOf('.') > -1) {
                alert('Validation\n\nOnly numeric value expected.');
                event.preventDefault();
                return false;
            }
        };

        function getDistdays() {
            var strDuedays = "";
            if (DS_ASI_Get_All_Default_FormSettingDetails.length) {
                var strActions = DS_ASI_Get_All_Default_FormSettingDetails[0].Value22;
                if (strActions) {
                    var lstActions = strActions.split(':')[1].split(',');
                    var closeObj = commonApi._.filter(lstActions, function (val) {
                        return val.indexOf("Respond") > -1
                    });
                    if (closeObj.length)
                        strDuedays = closeObj[0].split('|')[1].trim();
                }
            }
            return strDuedays;
        }

        function setClientlogo() {
            if (WorkingUserID.length) {
                var strOrgName = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',') + 1).trim();
                if (strOrgName) {
                    var orgdataObj = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
                        return val.Name == strOrgName;
                    });
                    if (orgdataObj.length) {
                        var orgObj = commonApi._.filter(DS_ASI_GET_Organization_Logo, function (val) {
                            return val.Value3 == orgdataObj[0].Name.trim();
                        });
                        if (orgObj.length) {
                            $scope.oriMsgCustomFields.DS_Logo = orgObj[0].Value4.trim();
                        }
                    }
                }
            }
        }

        function getPreviousData(strVal) {

            if (strVal) {
                var form = {
                    "projectId": projectId,
                    "formId": formId,
                    "fields": "DS_MTA_RFI_GET_PREVIOUS_DATA",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_MTA_RFI_GET_PREVIOUS_DATA",
                            "fieldValue": strVal
                        }]
                    }
                };
                $scope.isDataLoaded = false;
                $scope.getCallbackData(form).then(function (response) {
                    if (response.data) {
                        var prevDataobj = angular.fromJson(response.data['DS_MTA_RFI_GET_PREVIOUS_DATA']).Items.Item;
                        if (prevDataobj.length) {
                            var strCopyobj = angular.copy(paramObject);
                            strCopyobj.strTitle = prevDataobj[0].Value6.trim();
                            strCopyobj.strContractorRefNo = prevDataobj[0].Value9.trim();
                            strCopyobj.strReasonforRequst = prevDataobj[0].Value10.trim();
                            strCopyobj.strActionRequested = prevDataobj[0].Value11.trim();
                            strCopyobj.strProbabbleCostEffect = prevDataobj[0].Value12.trim();
                            strCopyobj.strProbabbleTimeEffect = prevDataobj[0].Value13.trim();
                            strCopyobj.strInitialEstimatedCost = prevDataobj[0].Value14.trim();
                            strCopyobj.strInitialEstimatedtime = prevDataobj[0].Value15.trim();
                            strCopyobj.strPriority = prevDataobj[0].Value16.trim();
                            strCopyobj.strDrawingNo = prevDataobj[0].Value17.trim();
                            strCopyobj.strDetailNo = prevDataobj[0].Value18.trim();
                            strCopyobj.strCSICode = prevDataobj[0].Value19.trim();
                            strCopyobj.strOtherRef = prevDataobj[0].Value20.trim();
                            strCopyobj.strInfoRequested = prevDataobj[0].Value21.trim();
                            strCopyobj.strRecommendation = prevDataobj[0].Value22.trim();
                            strCopyobj.strNotes = prevDataobj[0].Value23.trim();
                            strCopyobj.strSubRef = prevDataobj[0].Value24.trim();
                            strCopyobj.strPrimaryres = prevDataobj[0].Value25.trim();
                            strCopyobj.strRoles = prevDataobj[0].Value26.trim();
                            strCopyobj.strUsersRoles = prevDataobj[0].Value27.trim();
                            strCopyobj.strGroups = prevDataobj[0].Value28.trim();
                            strCopyobj.strUsersGroups = prevDataobj[0].Value29.trim();
                            strCopyobj.strUsersGroupsName = prevDataobj[0].Value30.trim();
                            strCopyobj.strPrimaryResGroup = prevDataobj[0].Value42.trim();
                            strCopyobj.Location_List.Location_Val = prevDataobj[0].Value44.trim();
                            setFormData(strCopyobj);
                            if (currentViewName == "ORI_VIEW") {
                                setRepeatingData(strCopyobj);
                            }
                            if (currentViewName == "RES_VIEW") {
                                setORIRepeatingData(strCopyobj);
                                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = prevDataobj[0].Value4.trim();
                                $scope.oriMsgCustomFields.ORI_USERREF = prevDataobj[0].Value31.trim();
                                $scope.oriMsgCustomFields.Due_Date = prevDataobj[0].Value40.trim();
                                $scope.oriMsgCustomFields.DS_Logo_Ori = prevDataobj[0].Value41.trim();
                                setPsrProjectDetails({
                                    Value2: prevDataobj[0].Value32.trim(),
                                    Value3: prevDataobj[0].Value33.trim(),
                                    Value4: prevDataobj[0].Value34.trim(),
                                    Value5: prevDataobj[0].Value35.trim(),
                                    Value6: prevDataobj[0].Value36.trim(),
                                    Value7: prevDataobj[0].Value37.trim(),
                                    Value8: prevDataobj[0].Value38.trim(),
                                    Value9: prevDataobj[0].Value39.trim(),
                                    Value10: prevDataobj[0].Value43.trim()
                                });
                            }
                            $timeout(function () {
                                $scope.expandTextAreaOnLoad();
                            }, 1000);
                            $scope.isDataLoaded = true;
                        }
                    }
                });
            } else {
                setFormData(paramObject);
                flushDistributionNodes();
            }
        }

        function setFormData(paramObject) {
            $scope.oriMsgCustomFields.ORI_FORMTITLE = paramObject.strTitle;
            $scope.oriMsgCustomFields.ContractorRefNo = paramObject.strContractorRefNo;
            $scope.oriMsgCustomFields.Reason_for_Request = paramObject.strReasonforRequst;
            $scope.oriMsgCustomFields.Action_Requested = paramObject.strActionRequested;
            $scope.oriMsgCustomFields.Probable_Cost_Effect = paramObject.strProbabbleCostEffect;
            $scope.oriMsgCustomFields.Probable_Time_Effect = paramObject.strProbabbleTimeEffect;
            $scope.oriMsgCustomFields.Initial_Estimate_Cost = paramObject.strInitialEstimatedCost;
            $scope.oriMsgCustomFields.Initial_Estimate_Time = paramObject.strInitialEstimatedtime;
            $scope.oriMsgCustomFields.Priority = paramObject.strPriority;
            $scope.oriMsgCustomFields.Drawing_No = paramObject.strDrawingNo;
            $scope.oriMsgCustomFields.Detail_No = paramObject.strDetailNo;
            $scope.oriMsgCustomFields.CSI_Code = paramObject.strCSICode;
            $scope.oriMsgCustomFields.Other_Ref = paramObject.strOtherRef;
            $scope.oriMsgCustomFields.Information_Requested = paramObject.strInfoRequested;
            $scope.oriMsgCustomFields.Recommendation = paramObject.strRecommendation;
            $scope.oriMsgCustomFields.Notes = paramObject.strNotes;
            $scope.oriMsgCustomFields.Sub_Ref = paramObject.strSubRef;
            $scope.oriMsgCustomFields.Primary_Responder_Goup = paramObject.strPrimaryResGroup;
            var tmpPrimaryRes = '';
            var primaryResponder = isCurrentUserPrimaryResponder();
            if (primaryResponder && primaryResponder.length && primaryResponder!='NO') {
                $scope.oriMsgCustomFields.Primary_Responder = primaryResponder;
            } else {

                if (paramObject.strPrimaryres) {
                    var usersObj = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                        return val.Value.split('#')[0].split('|')[2].trim() == paramObject.strPrimaryres;
                    });
                    if (usersObj.length) {
                        tmpPrimaryRes = usersObj[0].Value.split('|')[2].trim();
                    }
                    $scope.oriMsgCustomFields.Primary_Responder = tmpPrimaryRes;
                }
            }
        }

        function setRepeatingData(paramObject) {
            if (paramObject.strRoles && paramObject.strUsersRoles) {
                var arrRoles = paramObject.strRoles.split('|');
                var arrusersRoles = paramObject.strUsersRoles.split('|');
                var roles = "",
                    users = "";
                if (arrRoles.length == arrusersRoles.length) {
                    $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users = [];
                    var insertpoint = $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users;
                    for (var i = 0; i <= arrRoles.length - 1; i++) {
                        var structRoles = angular.copy($scope.furtherActionuserstruct);
                        roles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                            return val.Value.split('|')[0].trim() == arrRoles[i].trim();
                        });
                        if (roles.length) {
                            structRoles.RFI_Proj_Roles = roles[0].Value.trim();
                        }
                        users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                            return val.Value.split('#')[0].split('|')[2].trim() == arrusersRoles[i].trim();
                        });

                        if (users.length) {
                            structRoles.RFI_Dist_User = users[0].Value.trim();
                        }

                        insertpoint.push(structRoles);
                        $scope.buildItemSelecionArray(structRoles, "1");
                    }
                }
            } else {
                $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users = [];
                $scope.addNewItem($scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users, $scope.furtherActionuserstruct);
            }

            if (paramObject.strGroups && paramObject.strUsersGroups) {
                var arrGroups = paramObject.strGroups.split('|');
                var arrusersGroups = paramObject.strUsersGroups.split('|');
                var arrusersName = paramObject.strUsersGroupsName.split('|');
                if (arrGroups.length == arrusersGroups.length) {
                    $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups = [];
                    var insertpoint = $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups;

                    for (var i = 0; i <= arrGroups.length - 1; i++) {
                        var structGroups = angular.copy($scope.furtherActiongroupstruct);
                        structGroups.RFI_Group_Name = arrGroups[i].trim();
                        structGroups.RFI_User_Id = arrusersGroups[i].trim();
                        structGroups.RFI_User_Name = arrusersName[i].trim();
                        insertpoint.push(structGroups);
                        $scope.filterUserFromgroup(structGroups, "1");
                    }
                }
            } else {
                $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups = [];
                $scope.addNewItem($scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups, $scope.furtherActiongroupstruct);
            }
            
            if (paramObject.Location_List.Location_Val) {
                var strdata = paramObject.Location_List.Location_Val;
                strdata = strdata && strdata.split("|");
                if (strdata.length) {
                    var tempData = [];
                    $scope.oriMsgCustomFields.Location_Group.Location_List = [];
                    $scope.oriMsgCustomFields.Location_Attribute = strdata;
                    for (var i = 0; i < strdata.length; i++) {
                        tempData = angular.copy(paramObject.Location_List);
                        tempData.Location_Val = strdata[i];
                        $scope.oriMsgCustomFields.Location_Group.Location_List.push(tempData);
                        $scope.locationAttrList = commonApi.getItemSelectionList({
                            arrayObject: getConfigurableAttriburteByType("Location Attribute"),
                            groupNameKey: "",
                            modelKey: "Value8",
                            displayKey: "Value8"
                        });
                    }
                }
            }
        }

        function setORIRepeatingData(paramObject) {
            if (paramObject.strRoles && paramObject.strUsersRoles) {
                var arrRoles = paramObject.strRoles.split('|');
                var arrusersRoles = paramObject.strUsersRoles.split('|');
                var roles = "",
                    users = "";
                if (arrRoles.length == arrusersRoles.length) {
                    $scope.oriMsgCustomFields.ORI_Distribution.ORI_Distribution_Users = [];
                    var insertpoint = $scope.oriMsgCustomFields.ORI_Distribution.ORI_Distribution_Users
                    for (var i = 0; i <= arrRoles.length - 1; i++) {
                        var structRoles = angular.copy(oriUserStruct);
                        roles = commonApi._.filter(DS_WORKSPACE_ROLES_with_ID, function (val) {
                            return val.Value.split('|')[0].trim() == arrRoles[i].trim();
                        });
                        if (roles.length) {
                            structRoles.ORI_Proj_Roles = roles[0].Value.trim();
                        }
                        users = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                            return val.Value.split('#')[0].split('|')[2].trim() == arrusersRoles[i].trim();
                        });

                        if (users.length) {
                            structRoles.ORI_Dist_User = users[0].Value.trim();
                        }
                        insertpoint.push(structRoles);
                    }
                }
            }

            if (paramObject.strGroups && paramObject.strUsersGroups) {
                var arrGroups = paramObject.strGroups.split('|');
                var arrusersGroups = paramObject.strUsersGroups.split('|');
                var arrusersName = paramObject.strUsersGroupsName.split('|');
                if (arrGroups.length == arrusersGroups.length) {
                    $scope.oriMsgCustomFields.ORI_Dist_Groups.ORI_Groups = [];
                    var insertpoint = $scope.oriMsgCustomFields.ORI_Dist_Groups.ORI_Groups;

                    for (var i = 0; i <= arrGroups.length - 1; i++) {
                        var structGroups = angular.copy(oriActionGroupStruct);
                        structGroups.ORI_Group_Name = arrGroups[i].trim();
                        structGroups.ORI_User_Id = arrusersGroups[i].trim();
                        structGroups.ORI_User_Name = arrusersName[i].trim();
                        insertpoint.push(structGroups);
                    }
                }
            }

            if (paramObject.Location_List.Location_Val) {
                var strdata = paramObject.Location_List.Location_Val;
                $scope.oriMsgCustomFields.Location_Attribute = strdata;
                if (strdata) {
                    strdata = strdata.split("|");
                    if (strdata.length) {
                        var tempData = [];
                        $scope.oriMsgCustomFields.Location_Group.Location_List = [];
                        for (var i = 0; i < strdata.length; i++) {
                            tempData = angular.copy(paramObject.Location_List);
                            tempData.Location_Val = strdata[i];
                            $scope.oriMsgCustomFields.Location_Group.Location_List.push(tempData);
                        }
                    }
                }
            }
        }

        function clearActionByMsg() {
            var ActionData = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
                return val.Value4 == 'Respond';
            });
            if (ActionData.length) {
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action = [];
                $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.DS_AUTOCOMPLETE_ACTION_MSG_APP_ID = "1";
                var AppId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_AppBuilderID;
                var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Complete_msg_Actions.Auto_Complete_msg_Action;
                for (var i = 0; i < ActionData.length; i++) {
                    var AutocompleteMsg = angular.copy(autocompleteMsgStructure);
                    AutocompleteMsg.DS_MSG_AC_TYPE = "clear";
                    AutocompleteMsg.DS_MSG_AC_FORM = AppId;
                    AutocompleteMsg.DS_MSG_AC_MSG_TYPE = ActionData[i].Value3.trim();
                    AutocompleteMsg.DS_MSG_AC_USERID = ActionData[i].Value1.trim();
                    AutocompleteMsg.DS_MSG_AC_ACTION = "3";
                    AutocompleteMsg.DS_MSG_AC_ACTION_REMARKS = "clear actions";

                    insertpoint.push(AutocompleteMsg);
                }
            }
        }
        $window.mtaRfiFinalCallBack = function () {
            if ($scope.submitFlag) {
                return false;
            }
            
            if ($window.confirm("Are you sure you want to send this form? Please associate any necessary files.")) {
                return $scope.checkMandatoryFields();
            }
            else {
                return true;
            }
        }
        $scope.checkMandatoryFields = function () {
            if (currentViewName == "ORI_VIEW") {
                // var strClosedate = $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE;
                // if (strClosedate < $scope.todayDateDbFormat) {
                //     alert("End date cannot be less than today date");
                //     return true;
                // }
                var strRfiref = $scope.oriMsgCustomFields.RFI_Reference;
                if (!strRfiref) {
                    if (DS_GET_GUID.length) {
                        var strGuid = DS_GET_GUID[0].Value2.trim();
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strGuid;
                        $scope.oriMsgCustomFields.ORI_USERREF = "";
                    }
                    $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = "1";
                } else {
                    $scope.oriMsgCustomFields.ORI_USERREF = strRfiref;
                    var repObj = commonApi._.filter($scope.DS_MTA_RFI_GET_PREVIOUS_DATA, function (val) {
                        return val.Value2 == strRfiref;
                    });
                    if (repObj.length) {
                        $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = repObj[0].Value3;
                        var strRev = repObj[0].Value4;
                        if (strRev) {
                            var intRev = parseInt(strRev);
                            intRev++;
                            $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT2 = intRev;
                        }
                    }
                }
                var strPrimaryResGroup = $scope.oriMsgCustomFields.Primary_Responder_Goup;
                if (strPrimaryResGroup) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "3";
                    var strDuedays = getDistdays();
                    if (strDuedays) {
                        calculateDistDate(strDuedays, function (retdate) {
                            var usersObj = commonApi._.filter(DS_PROJUSERS_ALL_ROLES, function (val) {
                                return val.Value.indexOf(strPrimaryResGroup) > -1;
                            });
                            if (usersObj.length) {
                                for (var j = 0; j < usersObj.length; j++) {
                                    var strUser = usersObj[j].Value.split('|')[2].trim();
                                    setAutoDistribution(strUser, "3#Respond", retdate);
                                }
                            } else {
                                alert("There is no user exist in Primary Responders Role. Please Contact your Workspace Administrator");
                                return true;
                            }
                            var strUserFromRoles = $scope.resMsgCustomFields.Response_Distribution.Response_Distribution_Users;
                            var strConUsersFromRoles = $scope.resMsgCustomFields.Con_Distribution.Con_Distribution_Users;
                            var strUserFromGroup = $scope.resMsgCustomFields.Response_Dist_Groups.Response_Groups;
                            if (strUserFromRoles.length) {
                                for (var i = 0; i < strUserFromRoles.length; i++) {
                                    var strResponder = strUserFromRoles[i].RFI_Dist_User;
                                    if (strResponder) {
                                        var strid = strResponder.split('|')[2].split('#')[0].trim();
                                        setAutoDistribution(strid, "7#For Information", "");
                                    }
                                }
                            }
                            if (strConUsersFromRoles.length) {
                                for (var i = 0; i < strConUsersFromRoles.length; i++) {
                                    var strResponder = strConUsersFromRoles[i].Con_Dist_User;
                                    if (strResponder) {
                                        var strid = strResponder.split('|')[2].split('#')[0].trim();
                                        setAutoDistribution(strid, "7#For Information", "");
                                    }
                                }
                            }
                            if (strUserFromGroup.length) {
                                for (var i = 0; i < strUserFromGroup.length; i++) {
                                    var strResponderid = strUserFromGroup[i].RFI_User_Id;
                                    if (strResponderid) {
                                        setAutoDistribution(strResponderid, "7#For Information", "");
                                    }
                                }
                            }
                            $scope.submitFlag = true;
                            $window.submitForm(1);
                        });
                    }
                }
            } else if (currentViewName == "RES_VIEW") {
                var strFurtherinfo = $scope.oriMsgCustomFields.Further_Info_Required;
                var strResolve = $scope.oriMsgCustomFields.Complete_response;
                var strPrimaryres = $scope.oriMsgCustomFields.Primary_Responder;
                var strPrimaryresId = "";
                if (strPrimaryres) {
                    strPrimaryresId = strPrimaryres.split('#')[0].trim();
                }
                if (strFurtherinfo == "Yes") {
                    setFurtherAction();
                    return true;
                } else if (strResolve == "Yes") {
                    setForinfoContractor();                     
                    clearActionByMsg();                  
                    return false;
                } else if ($scope.currentUserid != strPrimaryresId.trim()) {
                    setDistributiontoAlluser(strPrimaryresId)
                    return false;
                } else {
                    alert("Please select atleast one checkbox");
                    return true;
                }
            }
            return true;
        }
    };
    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {

    if (typeof mtaRfiFinalCallBack !== "undefined") {
        return mtaRfiFinalCallBack();
    }
}