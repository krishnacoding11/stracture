define(['angular', './base'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
		var ctrl = this,
			lastsectionId = 402;

		$scope.staticJson = {
			"label": "",
			"isCustomActive": "true",
			"isCustomSectionValid": "false",
			"customSectionId": "",
			"customPercentage": "",
			"customSubSections": [{
				"subLabel": "",
				"isCustomSubActive": "true",
				"customSubPercentage": "",
				"isCustomSubSectionValid": "false",
				"customParentRef": "",
				"customSubSectionId": "",
				"fields": [{
					"fieldParentRef": "",
					"fieldId": "",
					"mainParentRef": "",
					"fieldLabel": "",
					"isFieldActive": "true",
					"isFieldValid": "false",
					"fieldName": "",
					"fieldType": "",
					"fieldValue": ""
				}]
			}]

		};
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.currentTab = 1;
		$scope.jsonWeightage = {};
		$scope.isWeightageexceed = false;
		$scope.clickSave = false;

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});

		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		/**
		 * Initialize all UI scope and related data
		 */
		ctrl.$onInit = function () {
			if (document.URL.indexOf('adoddle') === -1) {
				$element.addClass('isClassic');
			}
			$scope.data = $scope.getFormData();
			$scope.mainSections = $scope.data['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['Sections'];
			$scope.customSections = $scope.data['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['customSections'];
			setGUIDforCustomFields();

			$scope.update();
		}

		/**
		 * Open only one section/div at same time
		 */
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ? $scope.currentTab = ' ' : $scope.currentTab = eID;
		};

		/**
		 * Set GUID for custom fields which user add manually
		 */
		function setGUIDforCustomFields() {
			for (var index = 0; index < $scope.customSections.length; index++) {
				var element = $scope.customSections[index];
				element.customSectionId = commonApi.guId();
				for (var k = 0; k < element.customSubSections.length; k++) {
					var subElement = element.customSubSections[k];
					subElement.customSubSectionId = commonApi.guId();
					subElement.customParentRef = element.customSectionId;
					for (var j = 0; j < subElement.fields.length; j++) {
						var fieldObj = subElement.fields[j];
						fieldObj.fieldParentRef = subElement.customSubSectionId;
						fieldObj.fieldId = commonApi.guId();
						fieldObj.mainParentRef = element.customSectionId;
					}
				}
			}
		}

		/**
		 * Valiadate users entered percentage and check form logic
		 */
		$scope.validateValue = function (param) {

			var section = param.section;
			var subsection = param.subsection;
			var parentSection = param.parentSection;
			var percentageKey = param.percentageKey;
			var sectionValidKey = param.sectionValidKey;
			var subSectionValidKey = param.subSectionValidKey;

			var total = 0;
			subsection[subSectionValidKey] = true;

			if (section) {
				section[sectionValidKey] = true
			} else {
				$scope.isWeightageexceed = false;
			}

			if (section && parseInt(subsection[percentageKey]) > 100) {
				subsection[subSectionValidKey] = false;
			}
			if (parentSection) {
				for (var i = 0; i < parentSection.length; i++) {
					total += parentSection[i][percentageKey] ? Number(parentSection[i][percentageKey]) : 0;
				}
			}
			if (total != 100) {
				if (section) {
					section[sectionValidKey] = false;
				} else {
					$scope.isWeightageexceed = true;
				}
			}
		}

		/**
		 * To make active deactive section based on checked value
		 */
		$scope.selectSection = function (param) {
			var sectObj = param.obj;
			var activekey = param.activeKey;
			var isActive = param.isActive;
			for (var i = 0; i < sectObj.length; i++) {
				if (isActive) {
					sectObj[i][activekey] = true;
				} else {
					sectObj[i][activekey] = false;
				}
			}

		}

		/**
		 * Select sub section based on users selection
		 */
		$scope.selectSubsection = function (subsection, section) {
			if (!subsection.selected) {
				var selectedSubSectionLength = section.length;
				for (var i = 0; i < section.length; i++) {
					if (section[i].selected) {
						selectedSubSectionLength = selectedSubSectionLength + 1;
					} else {
						selectedSubSectionLength = selectedSubSectionLength - 1;
					}
				}
				if (selectedSubSectionLength <= 0) {
					section.selected = false;
					setTimeout(function () {
						$scope.selectSection(section)
					}, 50);
				}
			}
		}

		/**
		 * Remove added custom section/subsection
		 */
		$scope.removeItem = function (array, index) {
			array.splice(index, 1);
		}

		/**
		 * User add multiple custom section or sunsections
		 */
		$scope.addMultpleItem = function (data, item) {

			var json = JSON.parse(JSON.stringify(item));
			if (json.id) {
				lastsectionId++;
				json.id = lastsectionId;
			}
			if (json.data && json.data[0]) {
				lastsectionId++;
				json.data[0].id = lastsectionId;
			}
			data.push(json);
		}

		/**
		 * Validate form before submit
		 * to check user added percentage per section and subsection
		 */
		var validateForm = function () {
			var section = $scope.jsonWeightage.section,
				formWeightage = 0,
				sectionWeightage = 0,
				valid = true;
			for (var i = 0; i < section.length; i++) {
				sectionWeightage = 0;
				for (var j = 0; j < section[i].data.length; j++) {
					if (section[i].data[j].value) {
						if (section[i].data[j].value > 100) {
							alert('form contain error pls fix it');
							valid = false;
							break;
						} else {
							sectionWeightage += section[i].data[j].value;
						}
					}
				}
				if (section[i].value) {
					if (section[i].value > 100) {
						alert('form contain error pls fix it')
						valid = false;
						break;
					} else {
						formWeightage += section[i].value;
					}
				}
				if (sectionWeightage > 100) {
					alert('form contain error pls fix it')
					valid = false;
					break;
				}

			}
			if (formWeightage > 100) {
				alert('form contain error pls fix it')
				valid = false;
			}
			return valid;

		}

		/**
		 * Before submite forms validation for percentage
		 * Also add GUID for custom sections
		 */
		$window.weightageFinalCallBack = function () {
			var isvalid = false;
			var subSectionTotal = 0;
			var sectionTotal = 0;
			var mainObj = null;
			var subObj = null;
			for (var i = 0; i < $scope.mainSections.length; i++) {
				mainObj = $scope.mainSections[i];
				if (mainObj.isSectionActive) {
					subSectionTotal = 0;
					if (mainObj.subSections.length) {
						for (var j = 0; j < mainObj.subSections.length; j++) {
							subObj = mainObj.subSections[j];
							if (subObj.isSubSectionActive) {
								subSectionTotal += subObj.subSectionPercentage ? Number(subObj.subSectionPercentage) : 0;
							}
						}
					}
					if (subSectionTotal > 100 || subSectionTotal < 100) {
						$window.alert("Validation \n\n It seems that subsection weightage total is not equal to 100. Please ensure that total of each subsection is exactly 100.");
						return true;
					}
					sectionTotal += mainObj.sectionPercentage ? Number(mainObj.sectionPercentage) : 0;
				}
			}

			for (var i = 0; i < $scope.customSections.length; i++) {
				mainObj = $scope.customSections[i];
				if (mainObj.isCustomActive) {
					subSectionTotal = 0;
					if (mainObj.customSubSections.length) {
						for (var j = 0; j < mainObj.customSubSections.length; j++) {
							subObj = $scope.customSections[i].customSubSections[j];
							if (subObj.isCustomSubActive) {
								subSectionTotal += subObj.customSubPercentage ? Number(subObj.customSubPercentage) : 0;
							}
						}
					}
					if (subSectionTotal > 100 || subSectionTotal < 100) {
						$window.alert("Validation \n\n It seems that subsection weightage total is not equal to 100. Please ensure that total of each subsection is exactly 100.");
						return true;
					}
					sectionTotal += mainObj.customPercentage ? Number(mainObj.customPercentage) : mainObj.customPercentage;
				}
			}
			if (sectionTotal > 100 || sectionTotal < 100) {
				$window.alert("Validation \n\n It seems that Sections weightage total is not equal to 100. Please ensure that total of all the sections is exactly 100.");
				return true;
			}

			setGUIDforCustomFields();
		}

		/**
		 * Submit weitage app data to marketplace API
		 */
		$scope.saveWeightageForm = function () {
			$scope.clickSave = true;
			if (!validateForm()) {
				return;
				$scope.clickSave = false;
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveweightage",
				method: 'post',
				withCredentials: true,
				headers: {
					'Content-Type': 'application/json',
					'ApiKey': top.marketPlaceApiKey
				},
				data: angular.toJson({
					formJson: angular.toJson({
						myFields: $scope.jsonWeightage
					}),
					projectId: $("input[name ='projectId']").val().split('$$')[0],
					instaceGroupId: $('#instance_group_id').val().split('$$')[0],
					formId: $("input[name ='formId']").val().split('$$')[0]
				})
			}).then(function (response) {
				if (response.data) {
					$window.top.postMessage("closeCreateFormIframe:-1",'*');
				}
			}, function () {
				$scope.clickSave = false;

			});
		}

		/**
		 * Cancel or close form 
		 */
		$scope.cancel = function () {
			$window.top.postMessage("closeCreateFormIframe:-1",'*');
		}

	}

	return FormController;
});
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof weightageFinalCallBack !== "undefined") {
		return weightageFinalCallBack();
	}
}