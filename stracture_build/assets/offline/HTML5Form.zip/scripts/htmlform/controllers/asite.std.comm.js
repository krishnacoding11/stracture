/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../../nicEdit', '../components/item.selection'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, $filter, commonApi, $controller, $window, $timeout, Notification) {
		var ctrl = this;
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
					addRichtext();
				}, 500);
			}
		});
		$scope.stopAutoSaveDraftTimerFromClientSide();
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.Asite_System_Data_Read_Only = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.Asite_System_Data_Read_Write = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMID'];		
		var dSDraftRESMsg = $scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_ISDRAFT_RES_MSG'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];																		
		$scope.commUserRolesList = $scope.oriMsgCustomFields.commUserRolesList;
		$scope.commReferenceClauses = $scope.oriMsgCustomFields.commReferenceClauses;
		$scope.commExternalReference = $scope.oriMsgCustomFields.commExternalReference;
		$scope.disDetails = $scope.getValueOfOnLoadData('DS_GET_MSG_DISTRIBUTION_LIST');
		$scope.docAssociationDetails = $scope.getValueOfOnLoadData('DS_DOC_ASSOCIATIONS_ALL');
		$scope.docAttachmentDetails = $scope.getValueOfOnLoadData('DS_DOC_ATTACHMENTS_ALL');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var dsWorkingUser = $scope.Asite_System_Data_Read_Only._1_User_Data.DS_WORKINGUSER;
		var currentUserid = WorkingUserID['0'].Value.split('|')[0].trim();
		$scope.tempToRoleList = [];
		$scope.tempCopyToRoleList = [];
		$scope.tempToUsersList = [];
		$scope.tempCopyToUsersList = [];		
		$scope.formStatusList = [];
		$scope.allRespMsgList = [];
		$scope.isOriView = (currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (currentViewName == 'RES_VIEW');
		$scope.isRespPrintView = (currentViewName == 'RES_PRINT_VIEW');
		$scope.xhr = {
			guIdXhr: false,
			platformXhr: false
		};

		var STATIC_OBJ_DATA = {
			All_Responses: {
				"DSI_ResID": "",
				"Response_Remarks": "",
				"Response_Creator": "",
				"Response_Date": "",
				"DSI_ResFlag": ""
			}
		}

		var dsAsiConfigurableAttributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			selectedRoles = {
				toList : [],
				copyToList : []
			},	fieldNameKeyMap = {
				'to-role': 'toList',
				'copy-to-role': 'copyToList'
			},	listNameKeyMap = {
				'to-role' : 'toRole',
				'copy-to-role' : 'copyToRole',
			},	userListKeyMap = {
				'to-role' : 'toUsersStr',
				'copy-to-role' : 'copyToUsersStr',
			}, 	tempListKeyMap = {
				'to-role' : 'tempToUsersList',
				'copy-to-role' : 'tempCopyToUsersList'
			},  tempRolesListKeyMap = {
				'to-role' : 'tempToRoleList',
				'copy-to-role' : 'tempCopyToRoleList'
			}, 	strKeyRevMap = {
				'to-role-users' : 'to-role',
				'copy-to-role-users' : 'copy-to-role'	
			};

		$scope.serverDate = "";
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.userFormatedDate = "";
		$scope.userDateFormat = userDateFormat,
		$scope.getServerTime(function (serverDate) {			
			$scope.serverDate = serverDate;			
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
		});
		$scope.userFormatedDate = $scope.formatDate(getDateTimeFromZone(), 'dd/mm/yy', 'yy-mm-dd');
		$scope.todayDateDbFormat = $scope.formatDate(getDateTimeFromZone(), 'dd/mm/yy', 'yy-mm-dd');
		$scope.noAccessToPerform = false;

		// to get Custom Attribute On Load.
		var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes'),
			logo = commonApi._.findWhere(customAttr, {
				Value3: "LOGO",
				Value7: "LOGO"
			}) || {},
			allRoleUsersList = [],			
			allUsersList = [],
			allRolesList = [],
			configAttributesList = [],
			incompletedActionList = [],			
			availFormStatuses = [],		
			workingUserObj = {},
			formActionDays = {},
			contDataList = [],
			strRespondDays = '',
			isDraft = '',
			isEditOriDraft = '',
			isFwdMsgDraft = '',
			isRespDraft = '',
			isRespMsgDraft = '',
			_5_Form_Data = $scope.Asite_System_Data_Read_Only['_5_Form_Data'];
		$scope.Logo = logo.Value8 || '/images/Logo_Century.png';
		if (currentViewName == "ORI_VIEW") {
			$scope.oriMsgCustomFields.DS_Logo = $scope.Logo;
			$scope.oriMsgCustomFields.isDefaultLogo = ($scope.Logo == '/images/Logo_Century.png');
		}	
		if(currentViewName=="RES_VIEW"){

			if (dSDraftRESMsg == "NO") {
				var strResCount = $scope.resMsgCustomFields.DSI_Res_Counter,
					insertPoint = $scope.resMsgCustomFields.RESPONSES.All_Responses;
					strResCount++;
					$scope.resMsgCustomFields.DSI_Res_Counter = strResCount;
				if (insertPoint.length) {
					for (var i = 0; i < insertPoint.length; i++) {
						if (insertPoint[i].Response_Remarks) {
							insertPoint[i].DSI_ResFlag = "Old";
						}
					}
				}
				var resNodes = angular.copy(STATIC_OBJ_DATA.All_Responses);
					resNodes.DSI_ResID = "RES00" + strResCount;
					resNodes.Response_Creator = dsWorkingUser;
					resNodes.Response_Date = $scope.formatDate(getDateTimeFromZone(), 'dd/mm/yy', 'yy-mm-dd');
					insertPoint.push(resNodes);
					
			} else {
				var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
					return val.DSI_ResFlag != "Old";
				});
				if (responseObj.length) {
					responseObj[0].Response_Creator = dsWorkingUser;
				}
			}

		}
		/**All Common functions will be start from here */
		// Value22 contains selected actions and it's days from the form Setting
		var setFormSettingActionDays = function (formsSettings) {			
			var allActions = formsSettings.Value22.split(':')[1],
				actionsList = allActions.split(','),
				actionSplited = '';
			for(var i=0; i<actionsList.length; i++) {
				actionSplited = actionsList[i].split('|');
				formActionDays[actionSplited[0]] = actionSplited[1];
			}
			// default value for Respond action set 3 as per decision.
			strRespondDays = formActionDays['Respond'] || 3;
		};

		var setIncompleteAction = function () {						
			workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
			incompletedActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS');			
			// set working user Id.
			$scope.workingUserId = workingUserObj.Value.split('|')[0].trim() ||'';
		};
		//N
		if (currentViewName == "ORI_VIEW") {
			var dicipline = [];
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			var projectCode = commonApi._.findWhere(customAttr, {
				Value3: "Project Code",
				Value11: "Active"
			}) || {};
			projectCode = projectCode && projectCode.Value7;
			var getAllOrgDetails = $scope.getValueOfOnLoadData('DS_ASI_GET_Organization_Logo');
			var objCurrentOrg = commonApi._.findWhere(getAllOrgDetails, {
				Value3: $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Name.split(',')[1].trim()
			}) || {};
			var orgCode = objCurrentOrg.Value5;
			if (objCurrentOrg.Value4) {
				$scope.oriMsgCustomFields.isDefaultLogo = objCurrentOrg.Value4;
			}	
			var getAllSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
			var currentFormCode = getAllSettings[0].Value1.split(":")[1].trim();
			if (projectCode && orgCode && currentFormCode) { 
				var strPrefix = projectCode + "-" + orgCode + "-" + currentFormCode;
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']['DS_FORMAUTONO_PREFIX'] = strPrefix;
				$scope.oriMsgCustomFields['ORI_USERREF'] = strPrefix + "-" + "<<NEXT_AUTONO>>";
			}	
			for (var index = 0; index < dsAsiConfigurableAttributes.length; index++) {
				var element = dsAsiConfigurableAttributes[index];
				
				 if (element.Value3 === "FDiscipline" && element.Value11==="Active") {
					dicipline.push(element);
				} 
			}                
			$scope.Dicipline = dicipline;
	}
	if(currentViewName=="ORI_PRINT_VIEW" || currentViewName=="RES_PRINT_VIEW"){
		if($scope.docAssociationDetails.length>0){
			$scope.oriMsgCustomFields.AssociationCount='1';
		}

		if($scope.docAttachmentDetails.length>0){
			$scope.oriMsgCustomFields.AttachmentCount='1';
		}
	}
	//End N
		var setFormMsgRelatedFlags = function() {
			// from Replated Flags's values
			isDraft = _5_Form_Data["DS_ISDRAFT"].toLowerCase();
			isEditOriDraft = _5_Form_Data["DS_ISDRAFT_EDITORI"].toLowerCase();
			isFwdMsgDraft = _5_Form_Data["DS_ISDRAFT_FWD_MSG"].toLowerCase();            
			isRespDraft = _5_Form_Data["DS_ISDRAFT_RES"].toLowerCase();
			isRespMsgDraft = _5_Form_Data["DS_ISDRAFT_RES_MSG"].toLowerCase();
		};

		var getSetSPValues = function() {
			allRoleUsersList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');
			allUsersList = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
			allRolesList = $scope.getValueOfOnLoadData('DS_WORKSPACE_ROLES');
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');			
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS');			
			setFormSettingActionDays($scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails')[0]);
		};

		var checkUserHasAction = function(userId, strActionName) {			
            if(incompletedActionList.length) {                
				var splitedVal = '',
	                incompleteActionObj = commonApi._.find(incompletedActionList, function(obj) {					
						splitedVal = obj.Value.split('#');
						return splitedVal[0].trim().indexOf(userId)>-1 && splitedVal[1].trim() == strActionName;
					}) || {};

                if(incompleteActionObj.Value) {
                    return true;
                }
            } else if(!incompletedActionList.length || (isDraft == "yes")) {
				return true;
            }
            return false;
		};
			
		function getDateTimeFromZone() {
            var offset = 0;
            offset = $window.USP.localeVO._timezone.rawOffset + parseFloat($window.USP.localeVO._timezone.dstSavings);
            $scope.oriMsgCustomFields.DSI_TimeZone_Offset = offset;
            var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
            var now = new Date();
            var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
            utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
            var nd = new Date(parseInt(utcDate.getTime()) + parseInt(offset));
            nd = $filter('date')(nd, 'yyyy-MM-dd');
            return nd;
		}	
		
		var structureItemList = function(setFor, availList) {    			
			var tempList=[],
				optlabel = '';  				
			switch (setFor) {
				case 'role-list':
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Name, 							
							modelValue:  item.Value					
						});	
					});
					optlabel = 'Roles list';
					break;
				case 'user-list':
					angular.forEach(availList, function(item){
						tempList.push({
							displayValue: item.Name,                         
							modelValue:  item.Value					
						});	
					});
					optlabel = 'Users list';
					break;
			}	

			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};	
		
		var updateRolesList = function (forField, index) {
			// Prepare list and bind it for html template
			$scope[tempRolesListKeyMap[forField]][index] = structureItemList('role-list', allRolesList);
		};
		
		var setUsersOnRoleSelection = function (forField, index, roleName) {		
			if(roleName) {
				roleName = roleName.split('#')[0].trim();
				$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allRoleUsersList.filter(function(userRoleObj){
					return userRoleObj.Value.indexOf(roleName) > -1
				}));
			} else {
				$scope[tempListKeyMap[forField]][index] = structureItemList('user-list', allUsersList);	
			}
			updateRolesList(forField, index);
		};
		
		var checkAndSetSelectedRoleExist = function (forField, index, roleName) {
			var currList = selectedRoles[fieldNameKeyMap[forField]],
				currIndex = currList.indexOf(roleName);
			if(roleName && currList.length && currIndex != index && currIndex > -1) {
				Notification.warning({
					title: "Role is already selected",
					message: "Please select different role."
				});	
				roleName = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = '';
				$scope.commUserRolesList[fieldNameKeyMap[forField]][index][userListKeyMap[forField]] = '';
				$scope[tempListKeyMap[forField]][index] = [];
			} 
			selectedRoles[fieldNameKeyMap[forField]][index] = roleName;
			setUsersOnRoleSelection(forField, index, roleName);			
		};

		/**
		 *  All Needed ORI functions will be initiated form here if user has action or user creating it for the first time.
		 * 	Else 'noAccessToPerform' flag will be set to true that will not allow any user perform action.
		 */

		var setRoleAndUsersListData = function() {
			var keyNames = ['to-role','copy-to-role'], currNodeNameStr = '', currList = [], currObj = {}, currRoleName = '';	
			for(var i=0; i<keyNames.length; i++) {
				currNodeNameStr = keyNames[i];
				currList = $scope.commUserRolesList[fieldNameKeyMap[currNodeNameStr]];
				for(var k=0; k<currList.length; k++) {
					currObj = currList[k];
					// set already selected Roles in list to check duplication while response view					
					selectedRoles[fieldNameKeyMap[currNodeNameStr]][k] = currObj[listNameKeyMap[currNodeNameStr]];
					currRoleName = currObj[listNameKeyMap[currNodeNameStr]];
					currRoleName = currRoleName && currRoleName.split('#')[0].trim();					
					setUsersOnRoleSelection(currNodeNameStr, k, currRoleName);					
				}
			}
		};

		var setOriResViewBase = function () {
			setIncompleteAction();			
			setFormMsgRelatedFlags();
			//if(checkUserHasAction($scope.workingUserId, 'Respond')) {
				getSetSPValues();			
				$scope.oriMsgCustomFields.commFormName = $scope.Asite_System_Data_Read_Only['_4_Form_Type_Data']['DS_FORMNAME'];
				$scope.oriMsgCustomFields.commWorkspaceName = $scope.Asite_System_Data_Read_Only['_3_Project_Data']['DS_PROJECTNAME'];	
				$scope.Asite_System_Data_Read_Only['_5_Form_Data']["DS_SEND_MSG"] = "0";				
				if($scope.isRespView) {					
					// As Per Discussion Flushing Out commResponse field for response
					$scope.oriMsgCustomFields.commResponse = '';
				} 
				setRoleAndUsersListData();
		};

		var setPrintViewBase = function() {
			$scope.allRespMsgList = $scope.getValueOfOnLoadData('DS_Get_All_Responses');
			for (var index = 0; index < $scope.allRespMsgList.length; index++) {
				$scope.allRespMsgList[index].Value4 = commonApi._.unescape($scope.allRespMsgList[index].Value4);
			}
		};

		/**All Common functions will be End from here */

		$scope.insertNewItems = function (addToList, insertFor) { 
			var newObj = {};
			switch(insertFor) {
				case 'to-role-users':
					newObj = {
						toRole : '',
						toUsersStr : []
					};
					break;
				case 'copy-to-role-users':
					newObj = {
						copyToRole : '',
						copyToUsersStr : []
					};
					break;
			}
			//Add item in items
			$scope.addRepeatingRow(addToList, newObj);   			
			setUsersOnRoleSelection(strKeyRevMap[insertFor], addToList.length-1, '');			
		};

		$scope.removeItem = function(index, list, forField) {
			if(forField) {
				// it will remove the temp users list.
				$scope[tempListKeyMap[forField]].splice(index, 1);
				// it will remove the temp roles list.
				$scope[tempRolesListKeyMap[forField]].splice(index, 1);
				// it will remove indexed role from the selected role's list
				// that manages the duplication check of selection role.
				selectedRoles[fieldNameKeyMap[forField]].splice(index, 1);
			}
			list.splice(index, 1);	
		};

		$scope.resetRow = function(forField, index){
			$scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]] = "";
			$scope.changeItemSelectionEvent(forField, index)
		};

		// common item selection modal End
		$scope.changeItemSelectionEvent = function (forField, index) {
			switch(forField) {
				case 'to-role':								
				case 'copy-to-role':					
					var roleName = $scope.commUserRolesList[fieldNameKeyMap[forField]][index][listNameKeyMap[forField]];
					checkAndSetSelectedRoleExist(forField, index, roleName);
					break;
				case 'to-users':
				case 'copy-to-users':
					break;
			}
		};

		/**
		* Form's workflow logic		
		*/

		var setWorkflow = function() {            
			var allListName = ['toList', 'copyToList'],
				currNodeName = "",
				tempList = [],
				tempNodeObj = {},
				childNodeObj = {},
				strRespActionDate = commonApi.calculateDistDateFromDays({
					baseDate: $scope.serverDate,
					days : parseInt(strRespondDays)
				}),
				autoDistNodeVal = $scope.isRespView ? '13' : '3';
			for (var i =0; i<allListName.length; i++) {			
				currNodeName = allListName[i];
				tempNodeObj = $scope.commUserRolesList[currNodeName];
				for(var j =0; j<tempNodeObj.length; j++) {
					childNodeObj = tempNodeObj[j];
					if(currNodeName == 'toList') {						
						for(var k=0; k<childNodeObj.toUsersStr.length; k++) {							
							tempList.push({
								strUser : childNodeObj.toUsersStr[k].indexOf('|') > -1 ? childNodeObj.toUsersStr[k].split('|')[2].trim() : childNodeObj.toUsersStr[k],
								strAction : "3#Respond",
								strDate : strRespActionDate
							});
						}
					} else {
						for(var k=0; k<childNodeObj.copyToUsersStr.length; k++) {
							tempList.push({
								strUser : childNodeObj.copyToUsersStr[k].indexOf('|') > -1 ? childNodeObj.copyToUsersStr[k].split('|')[2].trim() : childNodeObj.copyToUsersStr[k],
								strAction : "7#For Information",
								strDate : ""             
							});
						}
					}
				}
			}
			$scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users = []; 
			// Distribution Will be made from here
			if(tempList.length) {
				commonApi.setDistributionNode({
					actionNodeList : tempList,
					autoDistributeUsers : $scope.Asite_System_Data_Read_Write.Auto_Distribute_Group.Auto_Distribute_Users,				
					asiteSystemDataReadWrite: $scope.Asite_System_Data_Read_Write,
					DS_AUTODISTRIBUTE : autoDistNodeVal
				});
			}
		};
		function setFormTitle_CreatedDate(){
			// Form Title Set from here
			$scope.oriMsgCustomFields['commSubject'] = $scope.oriMsgCustomFields.ORI_FORMTITLE;
			// set Date to Show on the Print Views.
			$scope.oriMsgCustomFields['commServerDate'] = $scope.userFormatedDate;
			$scope.oriMsgCustomFields['commServerDateDBFormat'] = $scope.todayDateDbFormat;
			$scope.oriMsgCustomFields.Last_ResponderId = currentUserid;
		}
		if ($scope.isOriView || $scope.isRespView) {
			setOriResViewBase();
			if($scope.isRespView){
				setReplayUsers();
			}
		} else if ($scope.isOriPrintView || $scope.isRespPrintView) {
			setPrintViewBase();
		}

		function setReplayUsers() {
			var toUsers = $scope.commUserRolesList.toList,
				index = -1,
				lastResponder = allUsersList.filter(function (val) {
					return val.Value.indexOf($scope.oriMsgCustomFields.Last_ResponderId) > -1;
				});
			if (toUsers.length) {
				for (var i = 0; i < toUsers.length; i++) {
					for (var j = 0; j < toUsers[i].toUsersStr.length; j++) {
						index = toUsers[i].toUsersStr[j].indexOf(currentUserid);
						if (index > -1) {
							delete toUsers[i].toUsersStr[j];
							if (lastResponder.length) {
								toUsers[i].toUsersStr.push(lastResponder[0].Value);
							}
						}
					}
				}
			}
		}

		function addRichtext() {
			if (window.nicEditor) {
				if (currentViewName == 'ORI_VIEW') {
					createRichtext("commDesciption");
				}
				if (currentViewName == 'RES_VIEW') {
					createRichtext("Response_Remarks");
				}
			}
		}

		function createRichtext(elemId) {
			var editor = new nicEditor({
				buttonList: ['bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'indent', 'outdent', 'image', 'link', 'unlink', 'forecolor', 'bgcolor', 'fontSize', 'fontFamily', 'strikethrough', 'subscript', 'superscript', 'removeformat', 'hr'],
				iconsPath: '../images/nicEditorIcons_new.gif',
				maxHeight: 300
			}).panelInstance(elemId);

			var editorInstance = nicEditors.findEditor(elemId);
			var content = editorInstance.getContent();
			if (content == "" || content == "<br>") {
				content = "";
			}
			if (isDraft == 'yes' && content == "") {
				content = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'][elemId];
				editorInstance.setContent(content);
			}
			editor.addEvent('blur', function () {
				// Your code here that is called whenever the user blurs (stops editing) the nicedit instance
				editorInstance = nicEditors.findEditor(elemId);
				content = editorInstance.getContent();
				if (content == "" || content == "<br>") {
					content = "";
				}
				switch (elemId) {
					case 'commDesciption':
						$scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'][elemId] = content;
						break;
					case 'Response_Remarks':
						var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
							return val.DSI_ResFlag != "Old";
						});
						if (responseObj.length) {
							responseObj[0].Response_Remarks = content;
						}
						break;
				}
			});
		}
	    $scope.isCallForDraft = false;
		var formSubmitCallBack = function () {

			if(currentViewName == 'ORI_VIEW' && !$scope.isCallForDraft){
				if(!$scope.oriMsgCustomFields.commDesciption){
					alert("Please Enter Description");
					return true;
				}
			}
			if(currentViewName == 'ORI_VIEW'){
				if(!$scope.oriMsgCustomFields.ORI_FORMTITLE){
					alert("Please Enter Subject");
					return true;
				}
			}			
			if(currentViewName == 'RES_VIEW'){
				var responseObj = commonApi._.filter($scope.resMsgCustomFields.RESPONSES.All_Responses, function (val) {
					return val.DSI_ResFlag != "Old";
				});
				if (responseObj.length && !responseObj[0].Response_Remarks) {
					alert("Please Enter Respone Details");
					return true;
				}
			}
			setWorkflow();
			setFormTitle_CreatedDate()
			return false;
		};
		
		$scope.update();

		$window.oriformSubmitCallBack = function() {			
			return formSubmitCallBack();
		};

		$window.respformSubmitCallBack = function() {			
			return formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {            
            $scope.isCallForDraft = true;
            return formSubmitCallBack();
        }
	}

	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {		
		return oriformSubmitCallBack();
	} 
}

function customHTMLMethodBeforeCreate_RES() {
	if (typeof respformSubmitCallBack !== "undefined") {		
		return respformSubmitCallBack();
	} 
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}