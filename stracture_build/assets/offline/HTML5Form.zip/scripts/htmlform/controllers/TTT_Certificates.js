/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		$scope.requests = {};
		$scope.logo = "/images/htmlform/commenting/tideway.png";
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		var tmpFormIds = [];
		var strFormTitle = [];
		var strFormCode = [];
		var strFormUserRef = [];
		var strAllDBFormId = [];
		var strAllAppBuilderId = [];
		var strDocumentKeys = [];
		var strChildAllAppBuilderId = [];
		var strChildAllAppBuilderIdCowl = [];

		var tmpArrDocs = [];

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.ORIMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
		$scope.SubContractorPreparedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Contractor_Statement"]["certificate_preparedBy_SUB"];
		$scope.ContractorPreparedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Contractor_Statement"]["certificate_preparedBy"];
		$scope.QualityManagerCheckedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Contractor_Statement"]["certificate_checkedBy"];
		$scope.ConstrutionManagerApprovedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Contractor_Statement"]["certificate_ApprovedBy"];
		$scope.Supervisor = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Supervisor_Statement"];
		$scope.TidewayDC = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["TidewayDC_Statement"];
		$scope.ProjectManager = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["ProjectManager_Statement"];
		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];

		var DS_INCOMPLETE_ACTIONS_BYMSG = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
		var DS_INCOMPLETE_MSG_ACTIONS = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData('DS_ALL_ACTIVE_FORM_STATUS');
		var DS_ALLFormSettings = $scope.getValueOfOnLoadData('DS_ASI_Get_All_Default_FormSettingDetails');
		var strAppBuilderCode = DS_ALLFormSettings && DS_ALLFormSettings[0] && DS_ALLFormSettings[0].Value6.split(":")[1].trim();
		var strAppBuilderCodeFinal = "";
		var mainTitle = "";
		var mainTitleFinal = "";
		var subChildMainTitle = "";
		if (strAppBuilderCode == "TTT-SUBC") {
			mainTitle = "DRAFT SUB-CONSTRUCTION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_SUBCONSTRUCTION_CHECK_CERTIFICATE_REFERENCE";
			strAppBuilderCodeFinal = "TTT-SUBCF";
			mainTitleFinal = "SUB-CONSTRUCTION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-CCON") {
			mainTitle = "DRAFT CONSTRUCTION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_CONSTRUCTION_CHECK_CERTIFICATE_REFERENCE";
			strAppBuilderCodeFinal = "TTT-CCONF";
			subChildMainTitle = "SUB-CONSTRUCTION CERTIFICATE";
			mainTitleFinal = "CONSTRUCTION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-WRK-SITER") {
			mainTitle = "DRAFT WORKSITE READY CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_WORKSITE_CHECK_CERTIFICATE_REFERENCE";
			strAppBuilderCodeFinal = "TTT-WRK-SITERF";
			subChildMainTitle = "CONSTRUCTION CERTIFICATE";
			mainTitleFinal = "WORKSITE READY CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-WRK-SITE") {
			mainTitle = "DRAFT WORKSITE COMPLETION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_WORKSITE_COMPLETE_CHECK_CERTI_REF";
			strAppBuilderCodeFinal = "TTT-WRK-SITEF";
			subChildMainTitle = "CONSTRUCTION CERTIFICATE";
			mainTitleFinal = "WORKSITE COMPLETION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-SEC") {
			mainTitle = "DRAFT SECTION COMPLETION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_SECTIONAL_CHECK_CERTIFICATE_REFERENCE";
			strAppBuilderCodeFinal = "TTT-SECF";
			subChildMainTitle = "WORKSITE READY CERTIFICATE";
			mainTitleFinal = "SECTION COMPLETION CERTIFICATE";
		}

		if (strAppBuilderCode == "TTT-SUBCF") {
			mainTitle = "SUB-CONSTRUCTION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_SUBCONSTRUCTION_CHECK_CERTIFICATE_REFERENCE";
		} else if (strAppBuilderCode == "TTT-CCONF") {
			mainTitle = "CONSTRUCTION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_CONSTRUCTION_CHECK_CERTIFICATE_REFERENCE";
			subChildMainTitle = "SUB-CONSTRUCTION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-WRK-SITERF") {
			mainTitle = "WORKSITE READY CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_WORKSITE_CHECK_CERTIFICATE_REFERENCE";
			subChildMainTitle = "CONSTRUCTION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-WRK-SITEF") {
			mainTitle = "WORKSITE COMPLETION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_WORKSITE_COMPLETE_CHECK_CERTI_REF";
			subChildMainTitle = "CONSTRUCTION CERTIFICATE";
		} else if (strAppBuilderCode == "TTT-SECF") {
			mainTitle = "SECTION COMPLETION CERTIFICATE";
			$scope.checkCertificateRefSP = "DS_TTT_SECTIONAL_CHECK_CERTIFICATE_REFERENCE";
			subChildMainTitle = "WORKSITE READY CERTIFICATE";
		}
		$scope.data['myFields']["FORM_CUSTOM_FIELDS"]['DSI_AppbuilderCode'] = strAppBuilderCode;
		$scope.ORIMsgCustomFields.MainTitle = mainTitle;
		$scope.ORIMsgCustomFields.SubChildMainTitle = subChildMainTitle;
		$scope.mainTitleFinal = mainTitleFinal;
		var DraftFormFlag = false;

		if (strAppBuilderCode == "TTT-SUBCF" || strAppBuilderCode == "TTT-CCONF" || strAppBuilderCode == "TTT-WRK-SITERF" || strAppBuilderCode == "TTT-WRK-SITEF" || strAppBuilderCode == "TTT-SECF") {
			$scope.Documents_Section = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.Documents_Section;
			$scope.GetFormsDetailsOfCowlAndCommenting = $scope.ORIMsgCustomFields.GetFormsDetailsOfCowlAndCommenting;
			$scope.ChildFormsDetails = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.ChildFormsDetails;
			$scope.ChildCowlDetails = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.ChildFormsCowlDetails;
		} else {
			$scope.Documents_Section = $scope.ORIMsgCustomFields["Documents_Section"];
			if ($scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS) {
				$scope.CowlDetails = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_02_FORM.ACF_02_REPEATING_VALUES.ACF_02_Cowls.ACF_02_Cowl;
				$scope.ChildFormsDetails = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsDetails;
				$scope.ChildCowlDetails = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsCowlDetails;
			}
			DraftFormFlag = true;
		}

		//Worksite complete Final scopes and paths 
		if (strAppBuilderCode == "TTT-WRK-SITEF") {
			$scope.Ready_SubContractorPreparedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_Contractor_Statement"]["Ready_certificate_preparedBy_SUB"];
			$scope.Ready_ContractorPreparedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_Contractor_Statement"]["Ready_certificate_preparedBy"];
			$scope.Ready_QualityManagerCheckedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_Contractor_Statement"]["Ready_certificate_checkedBy"];
			$scope.Ready_ConstrutionManagerApprovedBy = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_Contractor_Statement"]["Ready_certificate_ApprovedBy"];
			$scope.Ready_Supervisor = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_Supervisor_Statement"];
			$scope.Ready_ProjectManager = $scope.formCustomFields["ORI_MSG_Custom_Fields"]["Ready_ProjectManager_Statement"];
			$scope.Ready_Documents_Section = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.Ready_Documents_Section;
			$scope.Ready_GetFormsDetailsOfCowlAndCommenting = $scope.ORIMsgCustomFields.Ready_GetFormsDetailsOfCowlAndCommenting;
			$scope.Ready_ChildFormsDetails = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.Ready_ChildFormsDetails;
			$scope.Ready_ChildCowlDetails = $scope.data.myFields.FORM_CUSTOM_FIELDS.REPEATING_VALUES.Ready_ChildFormsCowlDetails;
		}

		$scope.ExportToExcel = function () {
			// function description in parmaters param1, param2, param3, param4, param5 this function is called in reportFromApp.js
			// form_template_name, Report_format, reportType, valueArray, reportName
			//to do
			showSelectedReportfromApp("TTT_work_site_complete_cowl_form_dtls Report","XLS","","","Cowl to Defect Report");
		}

		$scope.getCertificateRef = function (certiRef, event) {
			var fieldValue = certiRef;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": $scope.checkCertificateRefSP,
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": $scope.checkCertificateRefSP,
							"fieldValue": fieldValue
						}]
					}
				};
				$scope.ORIMsgCustomFields.DSI_isLoading = true;
				$scope.errorFlag = false;
				$scope.ORIMsgCustomFields['Certificate_Ref'] = fieldValue.toUpperCase().trim();
				disableSaveActions(true);
				$scope.childCowlLength = false;
				if (strAppBuilderCode == "TTT-CCON" || strAppBuilderCode == "TTT-WRK-SITE" || strAppBuilderCode == "TTT-WRK-SITER" || strAppBuilderCode == "TTT-SEC") {
					disableSaveActions(true);
					getChildSubReferences(fieldValue);
					if (strAppBuilderCode != "TTT-SEC") {
						getChildSubReferencesCowl(fieldValue);
					}
				}
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						$scope.certificateRef = JSON.parse(response.data[$scope.checkCertificateRefSP]);
						$scope.errorMsg = $scope.certificateRef.Items.Item[0].Value3;
						if ($scope.certificateRef && $scope.certificateRef.Items.Item.length && $scope.errorMsg == "") {
							var str = $scope.ORIMsgCustomFields['Certificate_Ref'];
							setValuesOfCertificate(str);
							$scope.formCustomFields.DSI_IsPermanent = $scope.certificateRef.Items.Item[0].Value4;
							$scope.ORIMsgCustomFields['Contract_Number'] = $scope.certificateRef.Items.Item[0].Value1.trim();
							$scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'] = $scope.certificateRef.Items.Item[0].Value5.trim();
							$scope.ORIMsgCustomFields.DSI_isLoading = false;
							if ($scope.certificateRef.Items.Item[0].Value4 == "Temporary Works" || $scope.certificateRef.Items.Item[0].Value6 == "TTT-SEC") {
								$scope.oriviewtabs = [{
									title: 'Statements',
									url: 'Statements.html'
								}, {
									title: 'Package Listing',
									url: 'packageListing.html'
								}]
							} else {
								$scope.oriviewtabs = [{
									title: 'Statements',
									url: 'Statements.html'
								}, {
									title: 'Package Listing',
									url: 'packageListing.html'
								}, {
									title: 'COWL',
									url: 'COWL.html'
								}]
							}
							disableSaveActions(false);
						} else {
							$scope.ORIMsgCustomFields.DSI_isLoading = false;
							if ($scope.errorMsg != "") {
								$scope.errorFlag = true;
							}
							setValuesOfCertificate();
							clearCertificateReferenceData();
							disableSaveActions(false);
						}
					}
				}, function (error) {
					$scope.ORIMsgCustomFields.DSI_isLoading = false;
					setValuesOfCertificate();
					clearCertificateReferenceData();
					$scope.errorFlag = false;
					window.console && window.console.log(error);
					disableSaveActions(false);
				});
			} else {
				setValuesOfCertificate();
				clearCertificateReferenceData();
				$scope.errorFlag = false;
				//reset child nodes for construction forms data
				strChildAllAppBuilderId = [];
				$scope.showDetailsFlag = false;
				$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = "";
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsDetails = [];
				disableSaveActions(false);
			}
		}

		function getChildSubReferences(certiRef) {
			var fieldValue = certiRef + "#" + strAppBuilderCode;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": 'DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_FORM_DETAILS',
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": 'DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_FORM_DETAILS',
							"fieldValue": fieldValue
						}]
					}
				};
				$scope.showDetailsFlag = false;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var getChildFormDetails = JSON.parse(response.data['DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_FORM_DETAILS']);
						if (getChildFormDetails && getChildFormDetails.Items.Item.length) {
							$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsDetails = [];
							getChildFormDetails = getChildFormDetails.Items.Item;
							strChildAllAppBuilderId = [];
							for (var i = 0; i < getChildFormDetails.length; i++) {
								$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsDetails.push({
									"ACF_01_Certificate_Reference": getChildFormDetails[i].Value5,
									"ACF_01_Form_ID": getChildFormDetails[i].Value1,
									"ACF_01_Form_Title": getChildFormDetails[i].Value2,
									"ACF_01_Form_Status": getChildFormDetails[i].Value4,
									"ACF_01_Revision_Number": getChildFormDetails[i].Value3,
									"ACF_01_ChildAppBuilderIds": getChildFormDetails[i].Value6,
									"ACF_01_AppbuilderCode": getChildFormDetails[i].Value8
								});
								if (getChildFormDetails[i].Value6) {
									strChildAllAppBuilderId.push(":" + getChildFormDetails[i].Value6);
								}
							}
							$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = $scope.ORIMsgCustomFields['Certificate_Ref'];
							$scope.showDetailsFlag = true;
							disableSaveActions(false);
						}
					}
				}, function (error) {
					$scope.ORIMsgCustomFields.DSI_isLoading = false;
					window.console && window.console.log(error);
				});
			}
		}

		function getChildSubReferencesCowl(certiRef) {
			var fieldValue = certiRef + "#" + strAppBuilderCode;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": 'DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_COWL_DETAILS',
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": 'DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_COWL_DETAILS',
							"fieldValue": fieldValue
						}]
					}
				};
				$scope.showDetailsFlag = false;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var getChildFormDetails = JSON.parse(response.data['DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_COWL_DETAILS']);
						if (getChildFormDetails && getChildFormDetails.Items.Item.length) {
							$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsCowlDetails = [];
							getChildFormDetails = getChildFormDetails.Items.Item;
							strChildAllAppBuilderIdCowl = [];
							for (var i = 0; i < getChildFormDetails.length; i++) {
								$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_ChildFormsCowlDetails.push({
									"ACF_01_Certificate_Reference": getChildFormDetails[i].Value6,
									"ACF_01_Form_ID": getChildFormDetails[i].Value2,
									"ACF_01_Form_HyperLink": getChildFormDetails[i].URL2,
									"ACF_01_Form_Title": getChildFormDetails[i].Value3,
									"ACF_01_Revision_Number": getChildFormDetails[i].Value4,
									"ACF_01_Form_Status": getChildFormDetails[i].Value5,
									"ACF_01_COWL_Description": getChildFormDetails[i].Value7,
									"ACF_01_Asite_Ref": getChildFormDetails[i].Value8,
									"ACF_01_Is_Approved": getChildFormDetails[i].Value18,
									"ACF_01_Approved_Status": getChildFormDetails[i].Value11,
									"ACF_01_Action_Required_To_Close": getChildFormDetails[i].Value19,
									"ACF_01_Date_Closed": getChildFormDetails[i].Value16,
									"ACF_01_Send_For_Approval": getChildFormDetails[i].Value14
								});
								if (getChildFormDetails[i].Value9) {
									strChildAllAppBuilderIdCowl.push(":" + getChildFormDetails[i].Value9);
								}
							}
							$scope.showDetailsFlag = true;
							$scope.childCowlLength = getChildFormDetails[0] && getChildFormDetails[0].Value6 ? true : false;
							if ($scope.childCowlLength) {
								$scope.formCustomFields.DSI_IsCowlAutoCreate = true;
							}
							disableSaveActions(false);
						}
					}
				}, function (error) {
					$scope.ORIMsgCustomFields.DSI_isLoading = false;
					window.console && window.console.log(error);
				});
			}
		}

		function clearCertificateReferenceData() {
			$scope.formCustomFields.DSI_IsPermanent = "";
			$scope.ORIMsgCustomFields['Contract_Number'] = "";
			$scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'] = "";
		}

		function setValuesOfCertificate(str) {
			var strFunction = "",
				strOrg = "",
				strLoc = "",
				strWorkType = "",
				strContent = "",
				strDocType = "",
				strNum = "";

			if (str) {
				str = str && str.split('-');
				strFunction = str[0] && str[0].trim();
				strOrg = str[1] && str[1].trim();
				strLoc = [2] && str[2].trim();
				strWorkType = str[3] && str[3].trim();
				strContent = str[4] && str[4].trim();
				strDocType = str[5] && str[5].trim();
				strNum = str[6] && str[6].trim();
			}
			$scope.ORIMsgCustomFields['Certificate_Function'] = strFunction;
			$scope.ORIMsgCustomFields['Certificate_Organisation'] = strOrg;
			$scope.ORIMsgCustomFields['Certificate_Location'] = strLoc;
			$scope.ORIMsgCustomFields['Certificate_WorkType'] = strWorkType;
			$scope.ORIMsgCustomFields['Certificate_Content'] = strContent;
			$scope.ORIMsgCustomFields['Certificate_DocType'] = strDocType;
			$scope.ORIMsgCustomFields['Certificate_Number'] = strNum;
		}

		function disableSaveActions(flag) {
			var saveEle = document.getElementById('btnSaveForm');
			var draftEle = document.getElementById('btnSaveDraft');
			if (saveEle) {
				saveEle.disabled = flag;
			}
			if (draftEle) {
				draftEle.disabled = flag;
			}
		}

		$scope.getRevId = function (parent, event, args, index) {
			var boolCheckDuplicate = $scope.checkDuplicateValues(args);
			if (boolCheckDuplicate) {
				parent.FormsDisableFlag = false;
				parent.rowColorFlag = '0';
				parent.Rejection_Comments = "";
				parent.Error_Code = "";
				return;
			}
			var fieldValue = parent.Document_Number;
			var rowIndex = index;
			var tmpKey = parent.Ref_Parent_Seq_Number + '-' + parent.Ref_Sub_Sequence_Number + '-' + rowIndex;			
			if (parent.Document_Number && parent.Document_Revision) {
				var docRef = parent.Document_Number;
				var docRev = parent.Document_Revision;
				var fieldValue = docRef + "|" + docRev;
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_TTT_SUBCONSTRUCTION_GET_REVISIONID",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_TTT_SUBCONSTRUCTION_GET_REVISIONID",
							"fieldValue": fieldValue
						}]
					}
				};
				parent.isLoading = true;
				disableSaveActions(true);
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var strGetDetails = JSON.parse(response.data['DS_TTT_SUBCONSTRUCTION_GET_REVISIONID']);
						var strFlag = strGetDetails && strGetDetails.Items.Item.length && strGetDetails.Items.Item[0].Value7;
						var strRejectComments = strGetDetails && strGetDetails.Items.Item.length && strGetDetails.Items.Item[0].Value8;
						wipeOutDocumentsData(parent);
						parent.RevisionID = strGetDetails.Items.Item[0].Value2;
						parent.Commenting_Form_ID = strGetDetails.Items.Item[0].Value5;
						parent.Is_Latest = strGetDetails.Items.Item[0].Value3;
						parent.Document_Title = strGetDetails.Items.Item[0].Value10;
						parent.Purpose_Of_Issue = strGetDetails.Items.Item[0].Value11;
						parent.Document_Status = strGetDetails.Items.Item[0].Value6;
						parent.Doc_Path = strGetDetails.Items.Item[0].Value12;
						if (strRejectComments) {
							parent.Rejection_Comments = strRejectComments;
						}
						if (strFlag == 'TRUE') {
							parent.Rejection_Comments = "";
							parent.Error_Code = "";
							if (strGetDetails.Items.Item[0].Value2 && strGetDetails.Items.Item[0].Value13 && strGetDetails.Items.Item[0].Value14) {
								strDocumentKeys[tmpKey] = strGetDetails.Items.Item[0].Value2 + '#' + strGetDetails.Items.Item[0].Value13 + '#' + strGetDetails.Items.Item[0].Value14;
							}
							parent.isLoading = false;
							parent.rowColorFlag = '2';
						} else {
							parent.isLoading = false;
							if (strRejectComments) {
								parent.Error_Code = strRejectComments.split('|')[0].trim();
								strRejectComments = strRejectComments.split('|')[1].trim();
								parent.Rejection_Comments = strRejectComments;
								if (strRejectComments == 'FileNotFound') {
									//if status is 'FileNotFound' then row color yellow and user able to submit form
									parent.rowColorFlag = '3';
								} else {
									//if status is 'Status Mismatch' OR status is 'Purpose Mismatch' then row color Red and user not able to submit form
									parent.rowColorFlag = '1';
								}
							}
						}
						disableSaveActions(false);
					}
				}, function (error) {
					wipeOutDocumentsData(parent);
					parent.isLoading = false;
					parent.rowColorFlag = '1';
					window.console && window.console.log(error);
					disableSaveActions(false);
				});
			} else {
				wipeOutDocumentsData(parent);
				delete strDocumentKeys[tmpKey];
				disableSaveActions(false);
			}
		}

		function wipeOutDocumentsData(parent) {
			var allDocsNodes = angular.copy(tmpArrDocs);
			if (allDocsNodes.length) {
				for (var i = 0; i < allDocsNodes.length; i++) {
					var ids = allDocsNodes[i] && allDocsNodes[i].revisionId.split('$$')[0];
					if (parent.RevisionID && parent.RevisionID != "0" && ids && ids.indexOf(parent.RevisionID) > -1) {
						tmpArrDocs.splice(i, 1);
					}
				}
			}
			parent.rowColorFlag = '0';
			parent.Rejection_Comments = "";
			parent.Error_Code = "";
			parent.RevisionID = "";
			parent.Commenting_Form_ID = "";
			parent.Is_Latest = "";
			parent.Document_Title = "";
			parent.Purpose_Of_Issue = "";
			parent.Document_Status = "";
			parent.Doc_Path = "";
		}

		$scope.getFormDetail = function (parent, event, args, index) {
			var boolCheckDuplicate = $scope.checkDuplicateValues(args);
			if (boolCheckDuplicate) {
				parent.DocsDisableFlag = false;
				parent.rowColorFlag = '0';
				parent.Rejection_Comments = "";
				parent.Error_Code = "";
				return;
			}
			var rowIndex = index;
			var tmpKey = parent.Ref_Parent_Seq_Number + '-' + parent.Ref_Sub_Sequence_Number + '-' + rowIndex;

			if (parent.Form_ID) {
				var formCode = parent.Form_ID;
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"applicationId": "1",
					"fields": "DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS",
							"fieldValue": formCode
						}]
					}
				};
				parent.isLoading = true;
				parent.Form_ID = formCode && formCode.toUpperCase();
				disableSaveActions(true);
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var formDetails = JSON.parse(response.data['DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS']);
						var strFlag = formDetails && formDetails.Items.Item.length && formDetails.Items.Item[0].Value10;
						var strRejectComments = formDetails && formDetails.Items.Item.length && formDetails.Items.Item[0].Value11;
						wipeOutFormData(parent);
						parent.Form_Code = formDetails.Items.Item[0].Value1;
						parent.Form_Title = formDetails.Items.Item[0].Value2;
						parent.Form_UserRef = formDetails.Items.Item[0].Value3;
						parent.dbFormId = formDetails.Items.Item[0].Value7;
						parent.Form_Status = formDetails.Items.Item[0].Value9;
						if (strRejectComments) {
							parent.Rejection_Comments = strRejectComments;
						}
						if (strFlag == 'TRUE') {
							strFormCode.push(formDetails.Items.Item[0].Value1);
							strFormTitle.push(formDetails.Items.Item[0].Value2);
							strFormUserRef.push(formDetails.Items.Item[0].Value3);
							strAllDBFormId.push(formDetails.Items.Item[0].Value7);
							strAllDBFormId = strAllDBFormId.filter(onlyUnique);
							parent.Rejection_Comments = "";
							parent.Error_Code = "";
							if (formDetails.Items.Item[0].Value8 != "") {
								strAllAppBuilderId[tmpKey] = formDetails.Items.Item[0].Value8;
								parent.isLoading = false;
								parent.rowColorFlag = '2';
								disableSaveActions(false);
							}
						} else {
							parent.isLoading = false;
							if (strRejectComments) {
								parent.Error_Code = strRejectComments.split('|')[0].trim();
								parent.Rejection_Comments = strRejectComments.split('|')[1].trim();
							}
							parent.rowColorFlag = '1';
							disableSaveActions(false);
						}
					}
				}, function (error) {
					wipeOutFormData(parent);
					parent.isLoading = false;
					parent.rowColorFlag = '1';
					window.console && window.console.log(error);
					disableSaveActions(false);
				});
			} else {
				wipeOutFormData(parent);
				delete strAllAppBuilderId[tmpKey];
				disableSaveActions(false);
			}
		}

		function wipeOutFormData(parent) {
			parent.rowColorFlag = '0';
			parent.Rejection_Comments = "";
			parent.Error_Code = "";
			parent.Form_Code = "";
			parent.Form_Title = "";
			parent.Form_UserRef = "";
			parent.dbFormId = "";
			parent.Form_Status = "";
		}

		var strAllDocDetails = "";

		function getRevIdOnLoad(onLoadArray) {
			var fieldValue = onLoadArray;	
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_TTT_SUBCONSTRUCTION_GET_REVISIONID",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_TTT_SUBCONSTRUCTION_GET_REVISIONID",
							"fieldValue": fieldValue
						}]
					}
				};
				disableSaveActions(true);
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var strGetDetails = JSON.parse(response.data['DS_TTT_SUBCONSTRUCTION_GET_REVISIONID']);
						strAllDocDetails = strGetDetails.Items.Item;
						setValuesOnLoad(strAllDocDetails, "Docs");
					}
				}, function (error) {
					window.console && window.console.log(error);
				});
			}
		}

		var strAllformDetails = "";

		function getFormDetailOnLoad(onLoadArray) {
			var fieldValue = onLoadArray;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"applicationId": "1",
					"fields": "DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS",
							"fieldValue": fieldValue
						}]
					}
				};
				disableSaveActions(true);
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var formDetails = JSON.parse(response.data['DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS']);
						if (formDetails && formDetails.Items.Item.length) {
							strAllformDetails = formDetails.Items.Item;
							for (var i = 0; i < $scope.ChildFormsDetails.length; i++) {
								if ($scope.ChildFormsDetails[i].ACF_01_ChildAppBuilderIds) {
									strChildAllAppBuilderId.push(":" + $scope.ChildFormsDetails[i].ACF_01_ChildAppBuilderIds);
								}
							}
							setValuesOnLoad(strAllformDetails, "Forms");
							disableSaveActions(false);
						}
					}
				}, function (error) {
					window.console && window.console.log(error);
				});
			}
		}

		function setValuesOnLoad(onLoadArray, Flag) {
			if ($scope.Documents_Section) {
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
					if (documents) {
						for (var j = 0; j < documents.length; j++) {
							var docs = documents[j] && documents[j].Alldocs.docs;
							if (docs) {
								for (var k = 0; k < docs.length; k++) {
									var tmpKey = docs[k].Ref_Parent_Seq_Number + '-' + docs[k].Ref_Sub_Sequence_Number + '-' + k;
									if (Flag == "Forms") {
										if (docs[k].Form_ID != "") {
											var obj = findObjectByKeys(onLoadArray, {
												"Value6": docs[k].Form_ID
											});
											if (obj) {
												strAllAppBuilderId[tmpKey] = obj.Value8;

												docs[k].Form_ID = obj.Value6.toUpperCase();
												var strFlag = obj.Value10;
												var strRejectComments = obj.Value11;
												if (strFlag == "TRUE") {
													docs[k].rowColorFlag = "2";
													docs[k].Error_Code = "";
													docs[k].Rejection_Comments = "";
													docs[k].AppBuilderId = obj.Value8;
												} else {
													if (strRejectComments) {
														docs[k].Rejection_Comments = strRejectComments.split('|')[1].trim();
														docs[k].Error_Code = strRejectComments.split('|')[0].trim();
														docs[k].rowColorFlag = "1";
													}
												}
												docs[k].dbFormId = obj.Value7;
												docs[k].Form_Status = obj.Value9;
												docs[k].Form_Title = obj.Value2;
												docs[k].isLoading = false;
											}
										}
									}
									if (Flag == "Docs") {
										if (docs[k].Document_Number != "" && docs[k].Document_Revision != "") {
											var obj = findObjectByKeys(onLoadArray, {
												"Value1": docs[k].Document_Number,
												"Value9": docs[k].Document_Revision
											});
											if (obj) {
												var strFlag = obj.Value7;
												var strRejectComments = obj.Value8;
												if (strFlag == 'TRUE') {
													if (obj.Value2 && obj.Value13 && obj.Value14) {
														strDocumentKeys[tmpKey] = obj.Value2 + '#' + obj.Value13 + '#' + obj.Value14;
													}
													docs[k].rowColorFlag = "2";
													docs[k].Error_Code = "";
													docs[k].Rejection_Comments = "";
												} else {
													if (strRejectComments) {
														docs[k].Error_Code = strRejectComments.split('|')[0].trim();
														strRejectComments = strRejectComments.split('|')[1].trim();
														docs[k].Rejection_Comments = strRejectComments;
														if (strRejectComments == 'FileNotFound') {
															//if status is 'FileNotFound' then row color yellow and user able to submit form
															docs[k].rowColorFlag = '3';
														} else {
															//if status is 'Status Mismatch' OR status is 'Purpose Mismatch' then row color Red and user not able to submit form
															docs[k].rowColorFlag = '1';
														}
													}
												}
												docs[k].RevisionID = obj.Value2;
												docs[k].Commenting_Form_ID = obj.Value5;
												docs[k].Is_Latest = obj.Value3;
												docs[k].Document_Status = obj.Value6;
												docs[k].Document_Title = obj.Value10;
												docs[k].Purpose_Of_Issue = obj.Value11;
												docs[k].Doc_Path = obj.Value12;
												docs[k].isLoading = false;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}


		function findObjectByKeys(array, matchObj) {
			for (var i = 0; i < array.length; i++) {
				var matched = true;
				for (var key in matchObj) {
					var value = matchObj[key];
					if (array[i][key].toLowerCase() != value.toLowerCase()) {
						matched = false;
						break;
					}
				}
				if (matched) {
					return array[i];
				}
			}
			return null;
		}

		//On load data call for all project roles

		$scope.allRolesDataOnLoad = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');

		$scope.contractorDropDown = commonApi._.filter($scope.allRolesDataOnLoad, function (val) {
			return val.Value.indexOf("MWC Engineer") > -1;
		});

		$scope.qualityManagerDropDown = commonApi._.filter($scope.allRolesDataOnLoad, function (val) {
			return val.Value.indexOf("MWC Quality Manager") > -1;
		});

		$scope.constructionManagerDropDown = commonApi._.filter($scope.allRolesDataOnLoad, function (val) {
			return val.Value.indexOf("MWC Project Manager") > -1;
		});

		$scope.tideWayDropDown = commonApi._.filter($scope.allRolesDataOnLoad, function (val) {
			return val.Value.indexOf("TTT Document Controller") > -1;
		});

		$scope.subContractor = commonApi._.filter($scope.allRolesDataOnLoad, function (val) {
			return val.Value.indexOf("MWC Sub-Contractor") > -1;
		});

		$scope.flagIsAllowEdit = true;
		$scope.flagIsAllowEditCheckEngineerFromCommenting = false;
		var boolFirstTimeLoad = false;

		function CheckPendingAction(strUser) {
			//check user have any pending action of not
			var IsAction = false;
			var strLastMsgId = $scope.formCustomFields.DSI_PreviousMsgId;
			DS_INCOMPLETE_ACTIONS_BYMSG = commonApi._.filter(DS_INCOMPLETE_ACTIONS_BYMSG, function (val) {
				return val.Value4 == "Assign Status";
			});
			if (DS_INCOMPLETE_ACTIONS_BYMSG) {
				var strUserId = DS_INCOMPLETE_ACTIONS_BYMSG[0] && DS_INCOMPLETE_ACTIONS_BYMSG[0].Value1;
				var strMsgId = DS_INCOMPLETE_ACTIONS_BYMSG[0] && DS_INCOMPLETE_ACTIONS_BYMSG[0].Value3;
				if (strUserId) {
					if (strUserId && strUserId == strUser.trim() && strLastMsgId == strMsgId) {
						return true;
					}
				}
			}
			return IsAction;
		}

		$scope.hideDetails = false;
		$scope.showCowlCheckBox = false;
		if (window.currentViewName == "ORI_VIEW") {
			var strFormId = $scope.Form_Data['DS_FORMID'];
			var strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
			var strWorkingId = WorkingUserID[0].Value && WorkingUserID[0].Value.split("|")[0].trim();
			var certificateRev = $scope.ORIMsgCustomFields.Certificate_Revision;
			var isImported = $scope.formCustomFields.DSI_isImported;

			if (strFormId == "" || strIsDraft == "YES") {
				var strCertificateRef = $scope.ORIMsgCustomFields['Certificate_Ref'];
				$scope.getCertificateRef(strCertificateRef);
				$scope.data.myFields["Asite_System_Data_Read_Only"]["_5_Form_Data"]["DS_FORMCONTENT3"] = "P01";
				// form status date
				$scope.getServerTime(function (serverDate) {
					var strDays = (new Date(serverDate)).getTime() + (86400000 * 28);
					var strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
					$scope.strTime = new Date(serverDate).getTime();
					$scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
					$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = strCloseDueDate;
				});
				setStage(strWorkingId);
				$scope.flagIsAllowEdit = false;
				boolFirstTimeLoad = true;
			}

			if (strFormId != "" && strIsDraft == "NO") {
				var objGetExcelComponent = document.getElementsByClassName('component-wrapper');
				if (objGetExcelComponent && objGetExcelComponent.length) {
					objGetExcelComponent[0].style.display = 'none';
				}
				var DS_TTT_TIDP_CHECK_CCMNT_RESP_BY_ENGINEER = $scope.getValueOfOnLoadData('DS_TTT_TIDP_CHECK_CCMNT_RESP_BY_ENGINEER');
				var checkOriginatorRespondedOnCommentingFormOrNot = DS_TTT_TIDP_CHECK_CCMNT_RESP_BY_ENGINEER[0] && DS_TTT_TIDP_CHECK_CCMNT_RESP_BY_ENGINEER[0].Value2.toLowerCase();
				$scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
				$scope.certificateInputDisable = true;
				$scope.ORIMsgCustomFields.DSI_isLoading = false;
				var nextStage = $scope.formCustomFields.DSI_Next_Stage;
				$scope.formCustomFields.DSI_Current_Stage = nextStage;
				var currentStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];

				// check assign status for working user.
				var strWorkinguser = WorkingUserID[0].Value;
				$scope.formCustomFields.DSI_PreviousMsgId = DS_INCOMPLETE_MSG_ACTIONS.length ? DS_INCOMPLETE_MSG_ACTIONS[0].Name.split('|')[1] : $scope.formCustomFields.DSI_PreviousMsgId;
				var isrequired = CheckPendingAction(strWorkinguser.split('|')[0].trim());
				if (isrequired == false) {
					//if not than dont allow to edit
					$scope.flagIsAllowEdit = true;
					$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|You are not authorised to create or edit this form. You therefore cannot create, please click the cancel button at the bottom of the form.";
					$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_DRAFT_MSG"] = "1|You are not authorised to draft or edit this form. You therefore cannot draft, please click the cancel button at the bottom of the form.";
				} else {
					$scope.flagIsAllowEdit = false;
					$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
					$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_DRAFT_MSG"] = "0";
				}

				currentStatus = currentStatus.toLowerCase();
				if ((currentStatus == "raised" || currentStatus == "revise-resubmit") && $scope.formCustomFields.DSI_Current_Stage == 2) {
					$scope.hideDetails = false;
				}

				//workflow reject flow
				if (currentStatus.indexOf('revise-resubmit') > -1) {
					setStage(strWorkingId);
					if (isrequired == false) {
						$scope.flagIsAllowEdit = true;
					}
					resetAllFields();
				}

				if (currentStatus.indexOf('not accepted') > -1) {
					if (checkOriginatorRespondedOnCommentingFormOrNot == "yes") { // || $scope.TidewayDC.TidewayDC_Status.toLowerCase() == "qa not accepted" || currentStatus.indexOf('accepted with comments') > -1
						$scope.flagIsAllowEdit = false;
						$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "0";
						$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_DRAFT_MSG"] = "0";
						var strIsDraftFwdMsg = $scope.data.myFields["Asite_System_Data_Read_Only"]["_5_Form_Data"]["DS_ISDRAFT_FWD_MSG"];
						if (certificateRev && strIsDraftFwdMsg == 'NO') {
							var strNum = certificateRev.substring(1);
							var strInc = parseInt(strNum) + 1;
							if (strInc > 9) {
								var strStatic = certificateRev.substring(0, 1);
							} else {
								var strStatic = certificateRev.substring(0, 2);
							}
							certificateRev = strStatic + strInc;
							$scope.ORIMsgCustomFields['Certificate_Revision'] = certificateRev;
							$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT3'] = certificateRev;
						}
						setStage(strWorkingId);
						if (isrequired == false) {
							$scope.flagIsAllowEdit = true;
						}
						resetAllFields();
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = "";
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "";
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "";
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_DSI_isLatest = '';
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_DS_AU_OTH_FORM = '';
						$scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields'].DS_AU_OTH_FORM = "";
						$scope.formCustomFields.DSI_isLatest = '';
						//COWL reset
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_CODE = "";
						$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_LOOKUP_SEQ = "";
					} else {
						$scope.flagIsAllowEditCheckEngineerFromCommenting = true;
						$scope.flagIsAllowEdit = false;
						$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_SEND_MSG"] = "1|The certificate could be updated only after completing the respond task of the associated Commenting form of the previous revision.";
						$scope.asiteSystemDataReadOnly['_5_Form_Data']["DS_DRAFT_MSG"] = "1|The certificate could be updated only after completing the respond task of the associated Commenting form of the previous revision.";
					}
				}
				blockCurrentUserToSelectDifferentUser();
			}
			if (isImported == 'yes') {
				$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AUTO_ASSOC_FORMS'] = "";
				$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_ASSOCDOC'] = "";
				tmpArrDocs = [];
				updateImportNodesValues();
			}
			$scope.getServerTime(function (serverDate) {
				var strDays = (new Date(serverDate)).getTime() + (86400000 * 28);
				$scope.strCloseDueDate = $scope.formatDate(new Date(strDays), 'yy-mm-dd');
			});
		}
		// if Contractor And SubContrator Both set Originator then stage 2 otherwise stage 1
		function setStage(strWorkingId) {
			if ($scope.subContractor) {
				for (var i = 0; i < $scope.subContractor.length; i++) {
					var id = $scope.subContractor[i].Value && $scope.subContractor[i].Value.split("|")[2].split("#")[0].trim();
					if (id == strWorkingId) {
						$scope.flagIsAllowEdit = false;
						$scope.formCustomFields.DSI_OriginatorId = strWorkingId;
						$scope.subConstructorFlag = true;
					}
				}
			}
			if ($scope.contractorDropDown) {
				for (var i = 0; i < $scope.contractorDropDown.length; i++) {
					var id = $scope.contractorDropDown[i].Value && $scope.contractorDropDown[i].Value.split("|")[2].split("#")[0].trim();
					if (id == strWorkingId) {
						$scope.hideDetails = true;
						$scope.flagIsAllowEdit = false;
						$scope.formCustomFields.DSI_OriginatorId = strWorkingId;
						$scope.constructorFlag = true;
					}
				}
			}
			if (($scope.subConstructorFlag == true && $scope.constructorFlag == true) || $scope.constructorFlag == true) {
				$scope.hideDetails = true;
				$scope.formCustomFields.DSI_Current_Stage = 2;
				$scope.formCustomFields.DSI_Next_Stage = 2;
			} else {
				$scope.formCustomFields.DSI_Current_Stage = 1;
				$scope.formCustomFields.DSI_Next_Stage = 1;
			}
		}

		function resetAllFields() {
			$scope.SubContractorPreparedBy.SentTo_Contractor = "";
			$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Date = "";
			$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Name = "";
			$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Position = "";
			$scope.SubContractorPreparedBy.SUB_Contractor_on_behalf_Of_OrgName = "";
			$scope.ContractorPreparedBy.SentTo_QualityManager = "";
			$scope.ContractorPreparedBy.Contractor_Status = "";
			$scope.ContractorPreparedBy.Contractor_preparedBy_Date = "";
			$scope.ContractorPreparedBy.Contractor_preparedBy_Name = "";
			$scope.ContractorPreparedBy.Contractor_preparedBy_Position = "";
			$scope.ContractorPreparedBy.Contractor_preparedBy_on_behalf_Of_OrgName = "";
			$scope.ContractorPreparedBy.Contractor_Comments = "";
			$scope.QualityManagerCheckedBy.SentTo_ConstructionManager = "";
			$scope.QualityManagerCheckedBy.QualityManager_Status = "";
			$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Date = "";
			$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Name = "";
			$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Position = "";
			$scope.QualityManagerCheckedBy.QualityManager_checkedBy_on_behalf_Of_OrgName = "";
			$scope.QualityManagerCheckedBy.QualityManager_Comments = "";
			$scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_Status = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Date = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Name = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Position = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_on_behalf_Of_OrgName = "";
			$scope.ConstrutionManagerApprovedBy.ConstructionManager_Comments = "";
			$scope.TidewayDC.TidewayDC_Status = "";
			$scope.TidewayDC.TidewayDC_Date = "";
			$scope.Supervisor.Supervisor_Date = "";
			$scope.Supervisor.Supervisor_Name = "";
			$scope.Supervisor.Supervisor_Position = "";
			$scope.Supervisor.Supervisor_For_and_on_behalf_Of_OrgName = "";
			$scope.ProjectManager.ProjectManager_Date = "";
			$scope.ProjectManager.ProjectManager_Name = "";
			$scope.ProjectManager.ProjectManager_Date = "";
			$scope.ProjectManager.ProjectManager_For_and_on_behalf_Of = "";
			$scope.ProjectManager.ProjectManager_FormStatus = "";
		}

		function blockCurrentUserToSelectDifferentUser() {
			$scope.disableAlreadySelected = false;
			if ($scope.formCustomFields.DSI_Current_Stage == 1) {
				var oldValue = $scope.SubContractorPreparedBy.SentTo_Contractor_Old;
				if (oldValue) {
					var contractorDropDownSelected = commonApi._.filter($scope.contractorDropDown, function (val) {
						return val.Value.indexOf(oldValue) > -1;
					});
					if (contractorDropDownSelected.length) {
						$scope.SubContractorPreparedBy.SentTo_Contractor = oldValue;
						$scope.disableAlreadySelected = true;
					}
				}
			}

			if ($scope.formCustomFields.DSI_Current_Stage == 2) {
				var oldValue = $scope.ContractorPreparedBy.SentTo_QualityManager_Old;
				if (oldValue) {
					var qualityManagerDropDownSelected = commonApi._.filter($scope.qualityManagerDropDown, function (val) {
						return val.Value.indexOf(oldValue) > -1;
					});
					if (qualityManagerDropDownSelected.length) {
						$scope.ContractorPreparedBy.SentTo_QualityManager = oldValue;
						$scope.disableAlreadySelected = true;
					}
				}
			}

			if ($scope.formCustomFields.DSI_Current_Stage == 3) {
				var oldValue = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager_Old;
				if (oldValue) {
					var constructionManagerDropDownSelected = commonApi._.filter($scope.constructionManagerDropDown, function (val) {
						return val.Value.indexOf(oldValue) > -1;
					});
					if (constructionManagerDropDownSelected.length) {
						$scope.QualityManagerCheckedBy.SentTo_ConstructionManager = oldValue;
						$scope.disableAlreadySelected = true;
					}
				}
			}
		}

		$scope.expandTextAreaOnLoad = function () {
			var textAreaObj = $element.find('textarea');
			if (textAreaObj) {
				for (var i = 0; i < textAreaObj.length; i++) {
					textAreaObj[i].style.height = 'auto';
					textAreaObj[i].style.height = textAreaObj[i].scrollHeight + 'px';
				}
			}
		}

		$timeout(function () {
			$scope.expandTextAreaOnLoad();
		}, 500);

		function updateImportNodesValues() {
			$scope.arrayExcelFormId = [];
			$scope.arrayExcelDocRefAndDocRev = [];
			var strCertificateRef = $scope.ORIMsgCustomFields['Certificate_Ref'];
			disableSaveActions(false);
			$scope.childCowlLength = false;
			if (strAppBuilderCode == "TTT-CCON" || strAppBuilderCode == "TTT-WRK-SITE" || strAppBuilderCode == "TTT-WRK-SITER" || strAppBuilderCode == "TTT-SEC") {
				disableSaveActions(true);
				getChildSubReferences(strCertificateRef);
				if (strAppBuilderCode != "TTT-SEC") {
					getChildSubReferencesCowl(strCertificateRef);
				}
			}
			var strFormId = $scope.Form_Data['DS_FORMID'];
			var strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
			if ($scope.Documents_Section) {
				var fieldValue = "";
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
					if (documents) {
						for (var j = 0; j < documents.length; j++) {
							var docs = documents[j] && documents[j].Alldocs.docs;
							if (docs) {
								for (var k = 0; k < docs.length; k++) {
									if (docs[k].Form_ID != "") {
										$scope.arrayExcelFormId.push(docs[k].Form_ID);
										$scope.arrayExcelFormId = $scope.arrayExcelFormId.filter(onlyUnique);
									}
									if (docs[k].Document_Number != "" && docs[k].Document_Revision != "") {
										fieldValue = docs[k].Document_Number + "|" + docs[k].Document_Revision;
										$scope.arrayExcelDocRefAndDocRev.push(fieldValue);
										$scope.arrayExcelDocRefAndDocRev = $scope.arrayExcelDocRefAndDocRev.filter(onlyUnique);
									}
								}
							}
						}
					}
				}

				if (strFormId == "" || strIsDraft == "YES") {
					if (strCertificateRef) {
						$scope.getCertificateRef(strCertificateRef);
					}
				}
				if ($scope.arrayExcelFormId) {
					$scope.arrayExcelFormId = $scope.arrayExcelFormId.toString();
					getFormDetailOnLoad($scope.arrayExcelFormId);
				}
				if ($scope.arrayExcelDocRefAndDocRev) {
					$scope.arrayExcelDocRefAndDocRev = $scope.arrayExcelDocRefAndDocRev.join('*@*');
					getRevIdOnLoad($scope.arrayExcelDocRefAndDocRev);
				}
			}
		}

		$scope.currentStage = $scope.formCustomFields.DSI_Current_Stage;

		$scope.launchCommmentingForm = function () {
			$scope.setValuesOfLaunchButton();
			launchCreateForm("TTT-CERT-CMNT");
			$scope.disableLaunchButton = true;
		}

		$scope.setValuesOfLaunchButton = function () {
			$window.DP_DOC_ASSOC = '';
			$window.DS_ASSOCIATED_DOCS_UPDATES = '';
			$window.DP_FORM_ASSOC_CURRENT = '';
			$window.DS_ATTACH_AUTOASSOCIATE_MSG = '';
			$window.DS_COPY_CONTENT = 'Yes';
			$window.prePopulatemapping = new Object();
			$window.prePopulatemapping['DYNAMIC_TOTALMAPPING'] = '16';
			$window.prePopulatemapping['SRC1'] = $scope.ORIMsgCustomFields['Certificate_Ref'];
			$window.prePopulatemapping['TG1'] = 'Certificate_Ref';
			$window.prePopulatemapping['SRC2'] = $scope.ORIMsgCustomFields['Contract_Number'];
			$window.prePopulatemapping['TG2'] = 'Contract_Number';
			$window.prePopulatemapping['SRC3'] = $scope.ORIMsgCustomFields['Certificate_Function'];
			$window.prePopulatemapping['TG3'] = 'Certificate_Function';
			$window.prePopulatemapping['SRC4'] = $scope.ORIMsgCustomFields['Certificate_Organisation'];
			$window.prePopulatemapping['TG4'] = 'Certificate_Organisation';
			$window.prePopulatemapping['SRC5'] = $scope.ORIMsgCustomFields['Certificate_Location'];
			$window.prePopulatemapping['TG5'] = 'Certificate_Location';
			$window.prePopulatemapping['SRC6'] = $scope.ORIMsgCustomFields['Certificate_WorkType'];
			$window.prePopulatemapping['TG6'] = 'Certificate_WorkType';
			$window.prePopulatemapping['SRC7'] = $scope.ORIMsgCustomFields['Certificate_Content'];
			$window.prePopulatemapping['TG7'] = 'Certificate_Content';
			$window.prePopulatemapping['SRC8'] = $scope.ORIMsgCustomFields['Certificate_DocType'];
			$window.prePopulatemapping['TG8'] = 'Certificate_DocType';
			$window.prePopulatemapping['SRC9'] = $scope.ORIMsgCustomFields['Certificate_Number'];
			$window.prePopulatemapping['TG9'] = 'Certificate_Number';
			$window.prePopulatemapping['SRC10'] = $scope.ORIMsgCustomFields['Certificate_Revision'];
			$window.prePopulatemapping['TG10'] = 'Certificate_Revision';
			$window.prePopulatemapping['SRC11'] = $scope.ORIMsgCustomFields['Contractor_Name'];
			$window.prePopulatemapping['TG11'] = 'Contractor_Name';
			$window.prePopulatemapping['SRC12'] = $scope.formCustomFields['DSI_AppbuilderIdOld'];
			$window.prePopulatemapping['TG12'] = 'Cert_Appbuilder_Code';
			$window.prePopulatemapping['SRC13'] = $scope.formCustomFields['DSI_AppbuilderCodeOld'];
			$window.prePopulatemapping['TG13'] = 'ParentAppBuilderCode';
			$window.prePopulatemapping['SRC14'] = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'];
			$window.prePopulatemapping['TG14'] = 'ORI_USERREF';
			$window.prePopulatemapping['SRC15'] = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['DS_AppBuilderID'];
			$window.prePopulatemapping['TG15'] = 'AppbuilderId_Final';
			$window.prePopulatemapping['SRC16'] = $scope.formCustomFields['DSI_AppbuilderCode'];
			$window.prePopulatemapping['TG16'] = 'AppBuilderCode_Final';
		}

		function showHideLaunchButtonInPrintView() {
			//isLatest condition check
			var getLatestCertificateFwdDetails = $scope.getValueOfOnLoadData('DS_TTT_LATEST_CERTIFICATE_FWD_DETAILS');
			var strWorkingId = WorkingUserID[0].Value && WorkingUserID[0].Value.split("|")[0].trim();
			$scope.formCustomFields.DSI_launchCommentingForm_Flag = false;
			if (currentViewName == "ORI_PRINT_VIEW") {
				$scope.strIsDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
				$scope.strIsDraftFwdMsg = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_ISDRAFT_FWD_MSG'];
				var isPermanent = $scope.formCustomFields.DSI_IsPermanent;
				var isLatest = $scope.formCustomFields.DSI_isLatest;
				var getLatestCertificateFwdDetails = getLatestCertificateFwdDetails[0] && getLatestCertificateFwdDetails[0].Value3.toLowerCase();
				if ($scope.tideWayDropDown) {
					for (var i = 0; i < $scope.tideWayDropDown.length; i++) {
						var id = $scope.tideWayDropDown[i].Value && $scope.tideWayDropDown[i].Value.split("|")[2].split("#")[0].trim();
						if (id && strWorkingId && isPermanent && isLatest && id == strWorkingId && isPermanent.toLowerCase() == "permanent works" && isLatest == "yes" && getLatestCertificateFwdDetails == "no") {
							$scope.formCustomFields.DSI_launchCommentingForm_Flag = true;
							break;
						}
					}
				}
			}
		}

		function setPrintViewURLs() {
			$scope.getChildFormDetails = $scope.getValueOfOnLoadData('DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_FORM_DETAILS');
			var getChildFormDetails = $scope.getValueOfOnLoadData('DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_FORM_DETAILS');
			var getChildCowlDetails = $scope.getValueOfOnLoadData('DS_TTT_DRAFT_CERTIFICATES_GET_CHILD_COWL_DETAILS');
			var getCowlComnDetails = $scope.getValueOfOnLoadData('DS_TTT_CERTIFICATES_GET_COMN_COWL_DETAILS');
			var getFormDetails = $scope.getValueOfOnLoadData('DS_TTT_SUBCONSTRUCTION_GET_FORMDETAILS');
			var getDocsDetails = $scope.getValueOfOnLoadData('DS_TTT_SUBCONSTRUCTION_GET_REVISIONID');
			var getSupervisorAndManagerDetails = $scope.getValueOfOnLoadData('DS_TTT_GET_SUPERVISOR_AND_PROJECTMANAGER_DETAILS');
			$scope.getWorksiteReadyDataInCompleteFinal = $scope.getValueOfOnLoadData('DS_TTT_GET_WRKS_READY_DATA_IN_WRKS_COMPLETE_FORM');

			if (currentViewName == "ORI_PRINT_VIEW") {
				if ($scope.Documents_Section) {
					for (var i = 0; i < $scope.Documents_Section.length; i++) {
						var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
						if (documents) {
							for (var j = 0; j < documents.length; j++) {
								var docs = documents[j] && documents[j].Alldocs.docs;
								if (docs) {
									for (var k = 0; k < docs.length; k++) {
										for (var l = 0; l < getFormDetails.length; l++) {
											if (docs[k].Form_ID != "") {
												var xmlFormId = docs[k].dbFormId;
												var dbFormId = getFormDetails[l].Value7;
												if (dbFormId == xmlFormId) {
													docs[k].Form_HyperLink = getFormDetails[l].URL6;
													docs[k].Form_Code = getFormDetails[l].Value1;
													docs[k].Form_Title = getFormDetails[l].Value2;
													docs[k].Form_UserRef = getFormDetails[l].Value3;
													docs[k].Error_Code = getFormDetails[l].Value11 ? getFormDetails[l].Value11.split('|')[0] : "";
												}
											}
										}

										for (var m = 0; m < getDocsDetails.length; m++) {
											if (docs[k].Document_Number != "") {
												var docXmlRevId = docs[k].RevisionID;
												var dbDocRevId = getDocsDetails[m].Value2;
												if (dbDocRevId == docXmlRevId) {
													docs[k].DocRef_HyperLink = getDocsDetails[m].URL4;
													docs[k].Commenting_HyperLink = getDocsDetails[m].URL5;
													docs[k].Commenting_Form_ID = getDocsDetails[m].Value5;
													docs[k].Is_Latest = getDocsDetails[m].Value3;
													docs[k].Error_Code = getDocsDetails[m].Value8 ? getDocsDetails[m].Value8.split('|')[0] : "";
												}
											}
										}
									}
								}
							}
						}
					}
				}

				//set Supervisor and Manager Details
				if (getSupervisorAndManagerDetails) {
					for (var i = 0; i < getSupervisorAndManagerDetails.length; i++) {

						if (getSupervisorAndManagerDetails[i].Value6 == 'ready' && getSupervisorAndManagerDetails[i].Value1.toLowerCase() == "supervisor") {
							dynamicBindingSupervisor(getSupervisorAndManagerDetails[i], "Ready_");
						}
						if (getSupervisorAndManagerDetails[i].Value6 == 'ready' && getSupervisorAndManagerDetails[i].Value1.toLowerCase() == "project manager") {
							dynamicBindingProjectManager(getSupervisorAndManagerDetails[i], "Ready_");
						}

						if ((getSupervisorAndManagerDetails[i].Value6 == '' || getSupervisorAndManagerDetails[i].Value6 == 'complete') && getSupervisorAndManagerDetails[i].Value1.toLowerCase() == "project manager") {
							dynamicBindingProjectManager(getSupervisorAndManagerDetails[i]);
						}
						if ((getSupervisorAndManagerDetails[i].Value6 == '' || getSupervisorAndManagerDetails[i].Value6 == 'complete') && getSupervisorAndManagerDetails[i].Value1.toLowerCase() == "supervisor") {
							dynamicBindingSupervisor(getSupervisorAndManagerDetails[i]);
						}
					}
				}

				$scope.showDetailsFlag = false;
				$scope.childCowlLength = getChildCowlDetails[0] && getChildCowlDetails[0].Value6 ? true : false;
				if (getChildFormDetails.length && (strAppBuilderCode == "TTT-CCON" || strAppBuilderCode == "TTT-WRK-SITE" || strAppBuilderCode == "TTT-WRK-SITER" || strAppBuilderCode == "TTT-SEC")) {
					$scope.showDetailsFlag = true;
					$scope.ChildFormsDetails = [];
					$scope.ChildCowlDetails = [];
					for (var i = 0; i < getChildFormDetails.length; i++) {
						$scope.ChildFormsDetails.push({
							"ACF_01_Certificate_Reference": getChildFormDetails[i].Value5,
							"ACF_01_Form_ID": getChildFormDetails[i].Value1,
							"ACF_01_Form_HyperLink": getChildFormDetails[i].URL1,
							"ACF_01_Form_Title": getChildFormDetails[i].Value2,
							"ACF_01_Form_Status": getChildFormDetails[i].Value4,
							"ACF_01_Revision_Number": getChildFormDetails[i].Value3
						});
					}
					for (var i = 0; i < getChildCowlDetails.length; i++) {
						$scope.ChildCowlDetails.push({
							"ACF_01_Certificate_Reference": getChildCowlDetails[i].Value6,
							"ACF_01_Form_ID": getChildCowlDetails[i].Value2,
							"ACF_01_Form_HyperLink": getChildCowlDetails[i].URL2,
							"ACF_01_Form_Title": getChildCowlDetails[i].Value3,
							"ACF_01_Form_Status": getChildCowlDetails[i].Value5,
							"ACF_01_Revision_Number": getChildCowlDetails[i].Value4,
							"ACF_01_Send_For_Approval": getChildCowlDetails[i].Value14,
							"ACF_01_COWL_Description": getChildCowlDetails[i].Value7,
							"ACF_01_Action_Required_To_Close": getChildCowlDetails[i].Value19,
							"ACF_01_Asite_Ref": getChildCowlDetails[i].Value8,
							"ACF_01_Is_Approved": getChildCowlDetails[i].Value18,
							"ACF_01_Approved_Status": getChildCowlDetails[i].Value11,
							"ACF_01_Date_Closed": getChildCowlDetails[i].Value16
						});
					}
				} else if (getChildFormDetails.length && (strAppBuilderCode == "TTT-CCONF" || strAppBuilderCode == "TTT-WRK-SITEF" || strAppBuilderCode == "TTT-WRK-SITERF" || strAppBuilderCode == "TTT-SECF")) {
					$scope.showDetailsFlag = true;
					$scope.ChildFormsDetails = [];
					$scope.ChildCowlDetails = [];
					$scope.Ready_ChildFormsDetails = [];
					for (var i = 0; i < getChildFormDetails.length; i++) {
						if (getChildFormDetails[i].Value7 && getChildFormDetails[i].Value7 == "ready") {
							dynamicBindingChildForm($scope.Ready_ChildFormsDetails, getChildFormDetails[i], "Ready_");
						} else {
							dynamicBindingChildForm($scope.ChildFormsDetails, getChildFormDetails[i]);
						}
					}
					for (var i = 0; i < getChildCowlDetails.length; i++) {
						$scope.ChildCowlDetails.push({
							"Certificate_Reference": getChildCowlDetails[i].Value6,
							"Form_ID": getChildCowlDetails[i].Value2,
							"Form_HyperLink": getChildCowlDetails[i].URL2,
							"Form_Title": getChildCowlDetails[i].Value3,
							"Form_Status": getChildCowlDetails[i].Value5,
							"Revision_Number": getChildCowlDetails[i].Value4,
							"Send_For_Approval": getChildCowlDetails[i].Value14,
							"COWL_Description": getChildCowlDetails[i].Value7,
							"Action_Required_To_Close": getChildCowlDetails[i].Value19,
							"Asite_Ref": getChildCowlDetails[i].Value8,
							"Is_Approved": getChildCowlDetails[i].Value11,
							"Approved_Status": getChildCowlDetails[i].Value18,
							"Date_Closed": getChildCowlDetails[i].Value16
						});
					}
				}

				if (getCowlComnDetails.length) {
					$scope.GetFormsDetailsOfCowlAndCommenting = [];
					$scope.Ready_GetFormsDetailsOfCowlAndCommenting = [];
					$scope.showExportToExcelButton = false;
					var currentStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_FORMSTATUS'];
					currentStatus = currentStatus && currentStatus.toLowerCase();					
					for (var j = 0; j < getCowlComnDetails.length; j++) {
						if (getCowlComnDetails[j].Value8) {
							if (strAppBuilderCode == "TTT-WRK-SITER" || strAppBuilderCode == "TTT-WRK-SITERF" || getCowlComnDetails[j].Value8 == 'TTT-WRK-SITEF' || getCowlComnDetails[j].Value8 == 'TTT-SUBCF' || getCowlComnDetails[j].Value8 == 'TTT-CCONF' || getCowlComnDetails[j].Value8 == 'TTT-SECF') {
								dynamicBindingCowlComm($scope.GetFormsDetailsOfCowlAndCommenting, getCowlComnDetails[j], "", currentStatus);
							} else {
								dynamicBindingCowlComm($scope.Ready_GetFormsDetailsOfCowlAndCommenting, getCowlComnDetails[j], "Ready_", currentStatus);
							}
						}
					}
				}

				//set single and repeating nodes of worksite complete final form
				if (strAppBuilderCode == "TTT-WRK-SITEF") {
					if ($scope.getWorksiteReadyDataInCompleteFinal.length) {
						$scope.ORIMsgCustomFields.Ready_PreciseLimits = $scope.getWorksiteReadyDataInCompleteFinal[0].Value72;

						$scope.Ready_SubContractorPreparedBy.Ready_SUB_Contractor_preparedBy_Name = $scope.getWorksiteReadyDataInCompleteFinal[0].Value48;
						$scope.Ready_SubContractorPreparedBy.Ready_SUB_Contractor_preparedBy_Position = $scope.getWorksiteReadyDataInCompleteFinal[0].Value51;
						$scope.Ready_SubContractorPreparedBy.Ready_SUB_Contractor_preparedBy_Date = $scope.getWorksiteReadyDataInCompleteFinal[0].Value50;
						$scope.Ready_SubContractorPreparedBy.Ready_SUB_Contractor_on_behalf_Of_OrgName = $scope.getWorksiteReadyDataInCompleteFinal[0].Value49;
						$scope.Ready_SubContractorPreparedBy.Ready_SentTo_Contractor = $scope.getWorksiteReadyDataInCompleteFinal[0].Value47;

						$scope.Ready_ContractorPreparedBy.Ready_Contractor_preparedBy_Name = $scope.getWorksiteReadyDataInCompleteFinal[0].Value40;
						$scope.Ready_ContractorPreparedBy.Ready_Contractor_preparedBy_Position = $scope.getWorksiteReadyDataInCompleteFinal[0].Value43;
						$scope.Ready_ContractorPreparedBy.Ready_Contractor_preparedBy_Date = $scope.getWorksiteReadyDataInCompleteFinal[0].Value41;
						$scope.Ready_ContractorPreparedBy.Ready_Contractor_preparedBy_on_behalf_Of_OrgName = $scope.getWorksiteReadyDataInCompleteFinal[0].Value42;
						$scope.Ready_ContractorPreparedBy.Ready_SentTo_QualityManager = $scope.getWorksiteReadyDataInCompleteFinal[0].Value45;

						$scope.Ready_QualityManagerCheckedBy.Ready_QualityManager_checkedBy_Name = $scope.getWorksiteReadyDataInCompleteFinal[0].Value53;
						$scope.Ready_QualityManagerCheckedBy.Ready_QualityManager_checkedBy_Position = $scope.getWorksiteReadyDataInCompleteFinal[0].Value54;
						$scope.Ready_QualityManagerCheckedBy.Ready_QualityManager_checkedBy_Date = $scope.getWorksiteReadyDataInCompleteFinal[0].Value55;
						$scope.Ready_QualityManagerCheckedBy.Ready_QualityManager_checkedBy_on_behalf_Of_OrgName = $scope.getWorksiteReadyDataInCompleteFinal[0].Value52;
						$scope.Ready_QualityManagerCheckedBy.Ready_SentTo_ConstructionManager = $scope.getWorksiteReadyDataInCompleteFinal[0].Value57;

						$scope.Ready_ConstrutionManagerApprovedBy.Ready_ConstructionManager_ApprovedBy_Name = $scope.getWorksiteReadyDataInCompleteFinal[0].Value62;
						$scope.Ready_ConstrutionManagerApprovedBy.Ready_ConstructionManager_ApprovedBy_Position = $scope.getWorksiteReadyDataInCompleteFinal[0].Value63;
						$scope.Ready_ConstrutionManagerApprovedBy.Ready_ConstructionManager_ApprovedBy_Date = $scope.getWorksiteReadyDataInCompleteFinal[0].Value60;
						$scope.Ready_ConstrutionManagerApprovedBy.Ready_ConstructionManager_ApprovedBy_on_behalf_Of_OrgName = $scope.getWorksiteReadyDataInCompleteFinal[0].Value61;
						$scope.Ready_ConstrutionManagerApprovedBy.Ready_SentTo_TideWayDC = $scope.getWorksiteReadyDataInCompleteFinal[0].Value59;

					}
				}

			}
		}

		function dynamicBindingCowlComm(obj, currentNode, prefix, currentStatus) {
			prefix = prefix || "";
			var tmpObj = {};
			tmpObj[prefix + "Certificate_Reference"] = currentNode.Value1;
			tmpObj[prefix + "Form_ID"] = currentNode.Value2;
			tmpObj[prefix + "Form_HyperLink"] = currentNode.URL2;
			tmpObj[prefix + "Commenting_ID"] = currentNode.Value3;
			tmpObj[prefix + "Commenting_HyperLink"] = currentNode.URL3;
			tmpObj[prefix + "Revision_Number"] = currentNode.Value4;
			tmpObj[prefix + "Form_Status"] = currentNode.Value5;
			tmpObj[prefix + "Cowl_ID"] = currentNode.Value6;
			tmpObj[prefix + "Cowl_HyperLink"] = currentNode.URL6;
			tmpObj[prefix + "Cowl_Status"] = currentNode.Value7;

			obj.push(tmpObj);
			if (strAppBuilderCode == "TTT-WRK-SITEF" && !prefix && currentNode.Value7 != "Closed" && currentStatus == 'accepted') {
				$scope.showExportToExcelButton = true;
			}			
		}

		function dynamicBindingChildForm(obj, currentNode, prefix) {
			prefix = prefix || "";
			var tmpObj = {};

			tmpObj[prefix + "Certificate_Reference"] = currentNode.Value5;
			tmpObj[prefix + "Form_ID"] = currentNode.Value1;
			tmpObj[prefix + "Form_HyperLink"] = currentNode.URL1;
			tmpObj[prefix + "Form_Title"] = currentNode.Value2;
			tmpObj[prefix + "Form_Status"] = currentNode.Value4;
			tmpObj[prefix + "Revision_Number"] = currentNode.Value3;

			obj.push(tmpObj);
		}

		function dynamicBindingSupervisor(currentNode, prefix) {
			prefix = prefix || "";

			var strDynamicSupervisor = prefix + "Supervisor";

			$scope[strDynamicSupervisor][prefix + "Supervisor_Date"] = currentNode.Value3;
			$scope[strDynamicSupervisor][prefix + "Supervisor_Name"] = currentNode.Value2;
			$scope[strDynamicSupervisor][prefix + "Supervisor_Position"] = currentNode.Value1;
			$scope[strDynamicSupervisor][prefix + "Supervisor_For_and_on_behalf_Of_OrgName"] = currentNode.Value4;

		}

		function dynamicBindingProjectManager(currentNode, prefix) {
			prefix = prefix || "";

			var strDynamicProjectManager = prefix + "ProjectManager";

			$scope[strDynamicProjectManager][prefix + "ProjectManager_Date"] = currentNode.Value3;
			$scope[strDynamicProjectManager][prefix + "ProjectManager_Name"] = currentNode.Value2;
			$scope[strDynamicProjectManager][prefix + "ProjectManager_Position"] = currentNode.Value1;
			$scope[strDynamicProjectManager][prefix + "ProjectManager_For_and_on_behalf_Of"] = currentNode.Value4;
			$scope[strDynamicProjectManager][prefix + "ProjectManager_FormStatus"] = currentNode.Value5.toUpperCase();

		}

		$timeout(function () {
			setPrintViewURLs();
			showHideLaunchButtonInPrintView();
		}, 600);

		function onlyUnique(value, index, self) {
			return self.indexOf(value) === index;
		}

		// Update Form Status

		function updateFormStatus(StrStatus) {
			//get status according pass parameter
			if (DS_ALL_ACTIVE_FORM_STATUS && DS_ALL_ACTIVE_FORM_STATUS.length) {
				DS_ALL_ACTIVE_FORM_STATUS = commonApi._.filter(DS_ALL_ACTIVE_FORM_STATUS, function (val) {
					return val.Name.toLowerCase() == StrStatus.toLowerCase();
				});
				//set status
				if (DS_ALL_ACTIVE_FORM_STATUS) {
					var strStatus = DS_ALL_ACTIVE_FORM_STATUS[0].Value;
					$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strStatus;
				}
			}
		}

		$window.TTT_AssociateDocsAndForms = function () {
			return $scope.TTT_WorkFlow();
		}

		$scope.TTT_WorkFlow = function () {
			if ($scope.submitFlag) {
				return false;
			}

			var currentStage = $scope.formCustomFields.DSI_Current_Stage;
			var status = "",
				sentTo = "";
			var workingUser = WorkingUserID[0].Name;
			var workingUserName = workingUser && workingUser.split(',')[0].trim();
			var workingUserOrg = workingUser && workingUser.split(',')[1].trim();
			var strTodayDate = $scope.setDbDateClientSide(0);
			if (currentStage == 1) {
				sentTo = $scope.SubContractorPreparedBy.SentTo_Contractor && $scope.SubContractorPreparedBy.SentTo_Contractor.split('|')[2].split('#')[0].trim();
				if (sentTo) {
					$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Date = strTodayDate;
					$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Name = workingUserName;
					$scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Position = "Sub Contractor";
					$scope.SubContractorPreparedBy.SUB_Contractor_on_behalf_Of_OrgName = workingUserOrg;
					updateFormStatus('Raised');
					$scope.SubContractorPreparedBy.SentTo_Contractor_Old = $scope.SubContractorPreparedBy.SentTo_Contractor;
				}
			} else if (currentStage == 2) {
				status = $scope.ContractorPreparedBy.Contractor_Status;
				sentTo = $scope.ContractorPreparedBy.SentTo_QualityManager && $scope.ContractorPreparedBy.SentTo_QualityManager.split('|')[2].split('#')[0].trim();
				$scope.ContractorPreparedBy.Contractor_preparedBy_Date = strTodayDate;
				$scope.ContractorPreparedBy.Contractor_preparedBy_Name = workingUserName;
				$scope.ContractorPreparedBy.Contractor_preparedBy_Position = "Contractor";
				$scope.ContractorPreparedBy.Contractor_preparedBy_on_behalf_Of_OrgName = workingUserOrg;
				if (status && status == "Accept" && $scope.hideDetails == false) {
					updateFormStatus('Submitted for Internal Review');
				}
				if ($scope.hideDetails == true) {
					updateFormStatus('Submitted for Internal Review');
				}
				$scope.ContractorPreparedBy.SentTo_QualityManager_Old = $scope.ContractorPreparedBy.SentTo_QualityManager;
			} else if (currentStage == 3) {
				sentTo = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager && $scope.QualityManagerCheckedBy.SentTo_ConstructionManager.split('|')[2].split('#')[0].trim();
				status = $scope.QualityManagerCheckedBy.QualityManager_Status;
				$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Date = strTodayDate;
				$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Name = workingUserName;
				$scope.QualityManagerCheckedBy.QualityManager_checkedBy_Position = "Quality Manager";
				$scope.QualityManagerCheckedBy.QualityManager_checkedBy_on_behalf_Of_OrgName = workingUser && workingUser.split(',')[1].trim();
				if (status == "Accept") {
					updateFormStatus('Submitted for Internal Acceptance');
					$scope.QualityManagerCheckedBy.SentTo_ConstructionManager_Old = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager;
				}
			} else if (currentStage == 4) {
				sentTo = $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC && $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC.split('|')[2].split('#')[0].trim();;
				status = $scope.ConstrutionManagerApprovedBy.ConstructionManager_Status;
				$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Date = strTodayDate;
				$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Name = workingUserName;
				$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Position = "Constuction Manager";
				$scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_on_behalf_Of_OrgName = workingUserOrg;
				if (status == "Accept" && sentTo != "") {
					var isPermanent = $scope.formCustomFields.DSI_IsPermanent;
					if (isPermanent.toLowerCase() == 'permanent works') {
						updateFormStatus('Issued to Tideway');
					} else {
						updateFormStatus('Submitted for Information');
					}
					$scope.ORIMsgCustomFields['Contractor_Name'] = workingUserOrg;
					$scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'] = $scope.strCloseDueDate;
					$scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC_Old = $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC;
					$scope.TTT_SetFormContent();
					setAutoCreateNodesValues();
				}
			}
			if (status == "Reject") { //status == "QA Not Accepted"
				$scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
				$scope.formCustomFields.DSI_Current_Stage = "1";
				$scope.formCustomFields.DSI_Next_Stage = "1";
				Set_Auto_Distribution($scope.formCustomFields.DSI_OriginatorId, "2#Assign Status", 3);
				var intEngineerUserId = $scope.SubContractorPreparedBy.SentTo_Contractor ? $scope.SubContractorPreparedBy.SentTo_Contractor.split('|')[2].split('#')[0].trim() : $scope.formCustomFields.DSI_OriginatorId;
				if (currentStage == 1) {
					$scope.SubContractorPreparedBy.SentTo_Contractor = "";
				}
				if (currentStage == 2) {
					$scope.ContractorPreparedBy.SentTo_QualityManager = "";
				}
				if (currentStage == 3) {
					$scope.QualityManagerCheckedBy.SentTo_ConstructionManager = "";
					Set_Auto_Distribution(intEngineerUserId, "7#For Information", "");
				}
				if (currentStage == 4) {
					$scope.ORIMsgCustomFields['Contractor_Name'] = workingUserOrg;
					$scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC = "";
					Set_Auto_Distribution($scope.ContractorPreparedBy.SentTo_QualityManager.split('|')[2].split('#')[0].trim(), "7#For Information", "");
					Set_Auto_Distribution(intEngineerUserId, "7#For Information", "");
				}
				updateFormStatus('Revise-Resubmit');
			} else {
				$scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'] = [];
				var intEngineerUserId = $scope.SubContractorPreparedBy.SentTo_Contractor ? $scope.SubContractorPreparedBy.SentTo_Contractor.split('|')[2].split('#')[0].trim() : $scope.formCustomFields.DSI_OriginatorId;
				if (currentStage < 4) {
					if (sentTo != "") {
						Set_Auto_Distribution(sentTo, "2#Assign Status", 3);
					}
					if (currentStage == 3) {
						Set_Auto_Distribution(intEngineerUserId, "7#For Information", "");
					}
					$scope.formCustomFields.DSI_Next_Stage = currentStage && parseInt(currentStage) + 1;
				} else {
					//$scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "0";
					Set_Auto_Distribution($scope.ContractorPreparedBy.SentTo_QualityManager.split('|')[2].split('#')[0].trim(), "7#For Information", "");
					Set_Auto_Distribution(intEngineerUserId, "7#For Information", "");
				}
			}
			var isImported = $scope.formCustomFields.DSI_isImported;
			var flag = false;
			var checkManadatoryValue = $scope.checkMandatory();
			var isPermanent = $scope.formCustomFields.DSI_IsPermanent;

			if ($scope.CowlDetails.length && strAppBuilderCode != "TTT-SEC" && isPermanent.toLowerCase() == 'permanent works' && $scope.formCustomFields.DSI_IsCowlAutoCreate) {
				for (var i = 0; i < $scope.CowlDetails.length; i++) {
					if (!$scope.CowlDetails[i].ACF_02_Cowl_Action) {
						alert("In Cowl Tab, Enter Action required to close to create form");
						flag = true;
						break;
					}
				}
			}

			if (isImported != "yes" && boolFirstTimeLoad == true) {
				alert("Please upload Import Sheet to create form");
				flag = true;
			} else if ($scope.errorFlag) {
				alert("Please Enter correct certificate reference to create form");
				flag = true;
			} else if ($scope.ORIMsgCustomFields.DSI_isLoading == true) {
				alert("Certificate reference is loading. Please submit form once loading is completed.");
				flag = true;
			} else if (checkManadatoryValue == 3 || (currentStage == 1 && !sentTo) || (currentStage == 2 && (($scope.hideDetails == false && status == "") || ($scope.hideDetails == true && !sentTo))) || ((currentStage == 3 || currentStage == 4 || currentStage == 5) && status == "") || (status == "Accept" && !sentTo)) {
				alert("Please fill all mandatory fields to create form");
				flag = true;
			} else if (checkManadatoryValue == 1) {
				alert("In Package listing Tab, Enter proper Docs and Forms details to create form");
				flag = true;
			} else if (checkManadatoryValue == 2) {
				alert("Post back not completed yet. Please submit form once loading is completed");
				flag = true;
			} else if (checkManadatoryValue == 4) {
				alert("In Package listing Tab, Enter section description or sub section description to create form");
				flag = true;
			}
			if (flag == true) {
				return true;
			} else {
				if (currentStage != 4) {
					$scope.TTT_SetFormContent();
				}
				var assoFormsStr = ':#';
				var assoDocsStr = "";
				for (var key in strAllAppBuilderId) {
					if (assoFormsStr == ":#") {
						assoFormsStr += ':' + strAllAppBuilderId[key];
					} else {
						assoFormsStr += ',:' + strAllAppBuilderId[key];
					}
				}

				if (strChildAllAppBuilderId.length) {
					if (assoFormsStr == ":#" && strChildAllAppBuilderId.length == 1) {
						assoFormsStr = assoFormsStr + strChildAllAppBuilderId[0];
					} else if (assoFormsStr == ":#" && strChildAllAppBuilderId.length > 1) {
						assoFormsStr = assoFormsStr + strChildAllAppBuilderId.join();
					} else if (assoFormsStr.length > 2) {
						assoFormsStr = assoFormsStr + ',' + strChildAllAppBuilderId.join();
					}
				}
				if (assoFormsStr.length > 2) {
					$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AUTO_ASSOC_FORMS'] = assoFormsStr;
				}

				assoDocsStr = commonApi._.values(strDocumentKeys).join();
				$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AUTO_ASSOC_DOCS'] = assoDocsStr;
				wipeOutBlankNodes();
				//sending or flush using below code to forward messages $scope.formCustomFields.DSI_isImported = "no";
			}

			if ($scope.CowlDetails[0].ACF_02_Cowl_Guid == "") {
				getGUIdOnCallBack($scope.CowlDetails.length, function (allGUID) {
					if (allGUID.length) {
						angular.forEach($scope.CowlDetails, function (allCowlNodes, i) {
							allCowlNodes.ACF_02_Cowl_Guid = allGUID[i];
						});
						$scope.submitFlag = true;
						$window.submitForm(1);
					}
				});
			} else {
				$scope.submitFlag = true;
				$window.submitForm(1);
			}
			return true;
		}

		$scope.checkMandatory = function () {
			var flag = false;
			if ($scope.Documents_Section) {
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					if ($scope.Documents_Section.Section_Description == "") {
						flag = 4;
					} else {
						var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
						if (documents) {
							if ($scope.Documents_Section.Sub_Section_Description == "") {
								flag = 4;
							} else {
								for (var j = 0; j < documents.length; j++) {
									var docs = documents[j] && documents[j].Alldocs.docs;
									if (docs) {
										for (var k = 0; k < docs.length; k++) {
											if (docs[k].rowColorFlag == "1") {
												flag = 1;
												break;
											}
											if (docs[k].isLoading == true) {
												flag = 2;
												break;
											}
											if ((docs[k].Document_Number && docs[k].Document_Revision == "") || (docs[k].Document_Number == "" && docs[k].Document_Revision)) {
												flag = 3;
												break;
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return flag;
		}

		//wipe out blank nodes
		function wipeOutBlankNodes() {
			if ($scope.Documents_Section) {
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
					if (documents) {
						for (var j = 0; j < documents.length; j++) {
							var docs = angular.copy(documents[j] && documents[j].Alldocs.docs);
							if (docs) {
								for (var k = docs.length - 1; k > -1; k--) {
									if (documents[j].Alldocs.docs.length > 1) {
										if (docs[k].Document_Number == "" && docs[k].Document_Revision == "" && docs[k].Form_ID == "") {
											documents[j].Alldocs.docs.splice(k, 1);
										}
									}
								}
							}
						}
					}
				}
			}
		}

		function setAutoCreateNodesValues() {
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;

			$scope.ACF_01_FORM.ACF_01_MainTitle = $scope.mainTitleFinal;
			$scope.ACF_01_FORM.ACF_01_SubChildMainTitle = $scope.ORIMsgCustomFields.SubChildMainTitle;
			$scope.ACF_01_FORM.ACF_01_DS_FORMTITLE = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
			$scope.ACF_01_FORM.ACF_01_ORI_FORMTITLE = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
			$scope.ACF_01_FORM.ACF_01_DSI_launchCommentingForm_Flag = $scope.formCustomFields.DSI_launchCommentingForm_Flag;
			$scope.ACF_01_FORM.ACF_01_DSI_AppbuilderCodeOld = $scope.data['myFields']["FORM_CUSTOM_FIELDS"]['DSI_AppbuilderCode'];
			$scope.ACF_01_FORM.ACF_01_DSI_AppbuilderIdOld = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_AppBuilderID'];
			$scope.ACF_01_FORM.ACF_01_DSI_IsPermanent = $scope.formCustomFields.DSI_IsPermanent;
			$scope.ACF_01_FORM.ACF_01_Certificate_Ref = $scope.ORIMsgCustomFields['Certificate_Ref'];
			$scope.ACF_01_FORM.ACF_01_Contract_Number = $scope.ORIMsgCustomFields['Contract_Number'];
			$scope.ACF_01_FORM.ACF_01_Contract_Deliverable_Number = $scope.ORIMsgCustomFields['Contract_Deliverable_Number'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Function = $scope.ORIMsgCustomFields['Certificate_Function'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Organisation = $scope.ORIMsgCustomFields['Certificate_Organisation'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Location = $scope.ORIMsgCustomFields['Certificate_Location'];
			$scope.ACF_01_FORM.ACF_01_Certificate_WorkType = $scope.ORIMsgCustomFields['Certificate_WorkType'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Content = $scope.ORIMsgCustomFields['Certificate_Content'];
			$scope.ACF_01_FORM.ACF_01_Certificate_DocType = $scope.ORIMsgCustomFields['Certificate_DocType'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Number = $scope.ORIMsgCustomFields['Certificate_Number'];
			$scope.ACF_01_FORM.ACF_01_Certificate_Revision = $scope.ORIMsgCustomFields['Certificate_Revision'];
			$scope.ACF_01_FORM.ACF_01_Contractor_Name = $scope.ORIMsgCustomFields['Contractor_Name'];
			$scope.ACF_01_FORM.ACF_01_NameAndLocation = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
			$scope.ACF_01_FORM.ACF_01_PreciseLimits = $scope.ORIMsgCustomFields['PreciseLimits'];
			$scope.ACF_01_FORM.ACF_01_SUB_Contractor_preparedBy_Date = $scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Date;
			$scope.ACF_01_FORM.ACF_01_SUB_Contractor_preparedBy_Name = $scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Name;
			$scope.ACF_01_FORM.ACF_01_SUB_Contractor_preparedBy_Position = $scope.SubContractorPreparedBy.SUB_Contractor_preparedBy_Position;
			$scope.ACF_01_FORM.ACF_01_SUB_Contractor_on_behalf_Of_OrgName = $scope.SubContractorPreparedBy.SUB_Contractor_on_behalf_Of_OrgName;
			$scope.ACF_01_FORM.ACF_01_SentTo_Contractor = $scope.SubContractorPreparedBy.SentTo_Contractor;
			$scope.ACF_01_FORM.ACF_01_Contractor_preparedBy_Date = $scope.ContractorPreparedBy.Contractor_preparedBy_Date;
			$scope.ACF_01_FORM.ACF_01_Contractor_preparedBy_Name = $scope.ContractorPreparedBy.Contractor_preparedBy_Name;
			$scope.ACF_01_FORM.ACF_01_Contractor_preparedBy_Position = $scope.ContractorPreparedBy.Contractor_preparedBy_Position;
			$scope.ACF_01_FORM.ACF_01_Contractor_preparedBy_on_behalf_Of_OrgName = $scope.ContractorPreparedBy.Contractor_preparedBy_on_behalf_Of_OrgName;
			$scope.ACF_01_FORM.ACF_01_SentTo_QualityManager = $scope.ContractorPreparedBy.SentTo_QualityManager;
			$scope.ACF_01_FORM.ACF_01_QualityManager_checkedBy_Date = $scope.QualityManagerCheckedBy.QualityManager_checkedBy_Date;
			$scope.ACF_01_FORM.ACF_01_QualityManager_checkedBy_Name = $scope.QualityManagerCheckedBy.QualityManager_checkedBy_Name;
			$scope.ACF_01_FORM.ACF_01_QualityManager_checkedBy_Position = $scope.QualityManagerCheckedBy.QualityManager_checkedBy_Position;
			$scope.ACF_01_FORM.ACF_01_QualityManager_checkedBy_on_behalf_Of_OrgName = $scope.QualityManagerCheckedBy.QualityManager_checkedBy_on_behalf_Of_OrgName;
			$scope.ACF_01_FORM.ACF_01_SentTo_ConstructionManager = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager;
			$scope.ACF_01_FORM.ACF_01_ConstructionManager_ApprovedBy_Date = $scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Date;
			$scope.ACF_01_FORM.ACF_01_ConstructionManager_ApprovedBy_Name = $scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Name;
			$scope.ACF_01_FORM.ACF_01_ConstructionManager_ApprovedBy_Position = $scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_Position;
			$scope.ACF_01_FORM.ACF_01_ConstructionManager_ApprovedBy_on_behalf_Of_OrgName = $scope.ConstrutionManagerApprovedBy.ConstructionManager_ApprovedBy_on_behalf_Of_OrgName;
			$scope.ACF_01_FORM.ACF_01_SentTo_TideWayDC = $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC;

			//auto distribute nodes
			$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Auto_Distribute_Group.ACF_01_AUTODISTRIBUTE_USERS = [];
			var intTidewayDcUserId = $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC && $scope.ConstrutionManagerApprovedBy.SentTo_TideWayDC.split('|')[2].split('#')[0].trim();
			var intContractorPMUserId = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager && $scope.QualityManagerCheckedBy.SentTo_ConstructionManager.split('|')[2].split('#')[0].trim();
			var intQualityManagerUserId = $scope.ContractorPreparedBy.SentTo_QualityManager && $scope.ContractorPreparedBy.SentTo_QualityManager.split('|')[2].split('#')[0].trim();
			var intEngineerUserId = $scope.SubContractorPreparedBy.SentTo_Contractor ? $scope.SubContractorPreparedBy.SentTo_Contractor.split('|')[2].split('#')[0].trim() : $scope.formCustomFields.DSI_OriginatorId;
			var isPermanent = $scope.formCustomFields.DSI_IsPermanent;

			if (isPermanent.toLowerCase() == 'permanent works') {
				Set_Auto_Distribution_ACF(intTidewayDcUserId, "36#For Action", 3);
			} else {
				Set_Auto_Distribution_ACF(intTidewayDcUserId, "7#For Information", "");
			}
			Set_Auto_Distribution_ACF(intContractorPMUserId, "7#For Information", "");
			Set_Auto_Distribution_ACF(intQualityManagerUserId, "7#For Information", "");
			Set_Auto_Distribution_ACF(intEngineerUserId, "7#For Information", "");

			//formstatus and close due date and other flags
			var formStatus = $scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'];
			$scope.ACF_01_FORM.ACF_01_DS_ALL_FORMSTATUS = formStatus && formStatus.split('#')[0].trim();
			$scope.ACF_01_FORM.ACF_01_DS_CLOSE_DUE_DATE = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'];
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_CODE = strAppBuilderCodeFinal;
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[0].ACF_LOOKUP_SEQ = "1";
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.DS_AUTOCREATE_FORM = "24";
			$scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields'].DS_AU_OTH_FORM = "1";
			$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM.ACF_01_DS_AU_OTH_FORM = "1";
			$scope.ACF_01_FORM.ACF_01_DSI_isLatest = 'yes';
			$scope.formCustomFields.DSI_isLatest = 'yes';

			//set form content
			var strLastMsgId = "";
			if ($scope.Form_Data['DS_FORMID'] != "") {
				strLastMsgId = $scope.formCustomFields.DSI_PreviousMsgId;
			}
			$scope.ACF_01_FORM.ACF_01_ORI_USERREF = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT1 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'];
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT2 = $scope.Form_Data['DS_FORMID'] + "#" + strLastMsgId;
			$scope.ACF_01_FORM.ACF_01_DS_FORMCONTENT3 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT3'];

			// repeating nodes values

			if ($scope.Documents_Section.length) {
				$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Documents_Section = [];
				angular.forEach($scope.Documents_Section, function (item, index) {
					var autoCreateNodes = angular.copy(autoCreateDocumentSection);
					autoCreateNodes.ACF_01_Sequence_Number = item.Sequence_Number;
					autoCreateNodes.ACF_01_Section_Description = item.Section_Description;
					var documents = item && item.Documents_Group.Documents;
					autoCreateNodes.ACF_01_Documents_Group.ACF_01_Documents = [];
					if (documents) {
						angular.forEach(item.Documents_Group.Documents, function (documents, j) {
							var documentsAutoCreate = angular.copy(autoCreateDocuments);
							documentsAutoCreate.ACF_01_Sub_Sequence_Number = documents.Sub_Sequence_Number;
							documentsAutoCreate.ACF_01_Sub_Section_Description = documents.Sub_Section_Description;
							documentsAutoCreate.ACF_01_Ref_Sequence_Number = documents.Ref_Sequence_Number;
							autoCreateNodes.ACF_01_Documents_Group.ACF_01_Documents.push(documentsAutoCreate);
							documentsAutoCreate.ACF_01_Alldocs.ACF_01_docs = [];
							var docs = documents && documents.Alldocs.docs;
							if (docs) {
								angular.forEach(documents.Alldocs.docs, function (docs, k) {
									var docsAutoCreate = angular.copy(autoCreateDocs);
									docsAutoCreate.ACF_01_Document_Number = docs.Document_Number;
									docsAutoCreate.ACF_01_Document_Title = docs.Document_Title;
									docsAutoCreate.ACF_01_Document_Revision = docs.Document_Revision;
									docsAutoCreate.ACF_01_Purpose_Of_Issue = docs.Purpose_Of_Issue;
									docsAutoCreate.ACF_01_Document_Status = docs.Document_Status;
									docsAutoCreate.ACF_01_Is_Latest = docs.Is_Latest;
									docsAutoCreate.ACF_01_Commenting_Form_ID = docs.Commenting_Form_ID;
									docsAutoCreate.ACF_01_Rejection_Comments = docs.Rejection_Comments;
									docsAutoCreate.ACF_01_Error_Code = docs.Error_Code;
									docsAutoCreate.ACF_01_Form_ID = docs.Form_ID;
									docsAutoCreate.ACF_01_dbFormId = docs.dbFormId;
									docsAutoCreate.ACF_01_Form_Status = docs.Form_Status;
									docsAutoCreate.ACF_01_rowColorFlag = docs.rowColorFlag;
									docsAutoCreate.ACF_01_RevisionID = docs.RevisionID;
									docsAutoCreate.ACF_01_Ref_Parent_Seq_Number = docs.Ref_Parent_Seq_Number;
									docsAutoCreate.ACF_01_Ref_Sub_Sequence_Number = docs.Ref_Sub_Sequence_Number;
									docsAutoCreate.ACF_01_DocsDisableFlag = docs.DocsDisableFlag;
									docsAutoCreate.ACF_01_FormsDisableFlag = docs.FormsDisableFlag;
									docsAutoCreate.ACF_01_dbSeq = docs.dbSeq;
									documentsAutoCreate.ACF_01_Alldocs.ACF_01_docs.push(docsAutoCreate);
								});
							}
						});
					}
					$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Documents_Section.push(autoCreateNodes);
				});
			}
			//COWL autocreate development
			var isPermanent = $scope.formCustomFields.DSI_IsPermanent;
			var isCowlAutoCreate = $scope.formCustomFields.DSI_IsCowlAutoCreate;

			var arrayLength = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP.length;
			if (arrayLength < 2) {
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP.push({
					"ACF_LOOKUP_SEQ": "",
					"ACF_CODE": ""
				});
			}
			if (isPermanent.toLowerCase() == 'permanent works' && isCowlAutoCreate == true) {
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_CODE = "TTT-COWL";
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_LOOKUP_SEQ = "2";
				$scope.ACF_02_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_02_FORM;
				$scope.ACF_02_FORM.ACF_02_Sub_construction = $scope.ORIMsgCustomFields['Certificate_Ref'];
				$scope.ACF_02_FORM.ACF_02_DS_FORMCONTENT1 = $scope.ORIMsgCustomFields['Certificate_Ref'];
				$scope.ACF_02_FORM.ACF_02_ORI_FORMTITLE = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
				$scope.ACF_02_FORM.ACF_02_DS_FORMTITLE = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
				$scope.ACF_02_FORM.ACF_02_ORI_USERREF = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'];
				$scope.ACF_02_FORM.ACF_02_Package_Description = $scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_FORMTITLE'];
				$scope.ACF_02_FORM.ACF_02_DSI_Current_Stage = "1";
				$scope.ACF_02_FORM.ACF_02_Construction_certificate = "";
				$scope.ACF_02_FORM.ACF_02_DS_FORMCONTENT3 = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT3'];
				$scope.ACF_02_FORM.ACF_02_DS_FORMCONTENT2 = $scope.Form_Data['DS_FORMID'] + "#" + strLastMsgId;
				$scope.ACF_02_FORM.ACF_02_Rev_no = $scope.ORIMsgCustomFields.Certificate_Revision;
				$scope.ACF_02_FORM.ACF_02_DSI_Eng = $scope.SubContractorPreparedBy.SentTo_Contractor ? $scope.SubContractorPreparedBy.SentTo_Contractor.split('|')[2].split('#')[0].trim() : $scope.formCustomFields.DSI_OriginatorId;
				$scope.ACF_02_FORM.ACF_02_DSI_Qm = $scope.ContractorPreparedBy.SentTo_QualityManager && $scope.ContractorPreparedBy.SentTo_QualityManager.split('|')[2].split('#')[0].trim();
				$scope.ACF_02_FORM.ACF_02_DSI_Cont_PM = $scope.QualityManagerCheckedBy.SentTo_ConstructionManager && $scope.QualityManagerCheckedBy.SentTo_ConstructionManager.split('|')[2].split('#')[0].trim();
				$scope.ACF_02_FORM.ACF_02_DS_CLOSE_DUE_DATE = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_CLOSE_DUE_DATE'];
				$scope.ACF_02_FORM.ACF_02_DSI_Certi_AppbilderCode = $scope.data['myFields']["FORM_CUSTOM_FIELDS"]['DSI_AppbuilderCode'];
			} else {
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_CODE = "";
				$scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.AUTOCREATE_FORM_LOOKUP[1].ACF_LOOKUP_SEQ = "";
			}
		}

		function getGUIdOnCallBack(totalNodes, callback) {
			var allNodes = [];
			var fieldValue = totalNodes;
			if (fieldValue) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_GET_GUID",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_GET_GUID",
							"fieldValue": fieldValue
						}]
					}
				};
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var strGetDetails = JSON.parse(response.data['DS_GET_GUID']);
						var strGetDetailsLength = strGetDetails.Items.Item.length;
						for (var i = 0; i < strGetDetailsLength; i++) {
							allNodes.push(strGetDetails && strGetDetailsLength && strGetDetails.Items.Item[i].Value2);
						}
					}
					callback(allNodes);
				}, function (error) {
					window.console && window.console.log(error);
				});
			}
		}

		function Set_Auto_Distribution(strUser, strAction, strDueDays) {
			var strDueDate = "";
			if (strDueDays != "") {
				strDueDate = $scope.setDbDateClientSide(strDueDays);
			}
			$scope.asiteSystemDataReadWrite['DS_AUTODISTRIBUTE'] = "3";
			$scope.asiteSystemDataReadWrite['Auto_Distribute_Group']['Auto_Distribute_Users'].push({
				DS_PROJDISTUSERS: strUser,
				DS_FORMACTIONS: strAction,
				DS_ACTIONDUEDATE: strDueDate
			});
		}

		function Set_Auto_Distribution_ACF(strUser, strAction, strDueDays) {
			var strDueDate = "";
			if (strDueDays != "") {
				strDueDate = $scope.setDbDateClientSide(strDueDays);
			}
			$scope.ACF_01_FORM.ACF_01_DS_AUTODISTRIBUTE = "3";
			$scope.ACF_01_FORM = $scope.data.myFields.Asite_System_Data_Read_Write.AUTOCREATE_FORM_FIELDS.ACF_01_FORM;
			$scope.ACF_01_FORM.ACF_01_REPEATING_VALUES.ACF_01_Auto_Distribute_Group.ACF_01_AUTODISTRIBUTE_USERS.push({
				ACF_01_DS_PROJDISTUSERS: strUser,
				ACF_01_DS_ACTIONDUEDATE: strDueDate,
				ACF_01_DS_FORMACTIONS: strAction
			});
		}

		$scope.TTT_SetFormContent = function () {
			var tempArray = [];
			var formContent = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT'];
			if ($scope.Documents_Section) {
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
					if (documents) {
						for (var j = 0; j < documents.length; j++) {
							var docs = documents[j] && documents[j].Alldocs.docs;
							if (docs) {
								for (var k = 0; k < docs.length; k++) {
									if (docs[k].Document_Number != "" && docs[k].Document_Revision != "") {
										var fieldValue = docs[k].Document_Number + "|" + docs[k].Document_Revision;
										tempArray.push(fieldValue);
										tempArray = tempArray.filter(onlyUnique);
										if (formContent == "") {
											formContent = fieldValue + "#";
										} else {
											var splitDocDetails = formContent.split('#')[0];
											var splitFormDetails = formContent.split('#')[1];
											if (splitDocDetails == "") {
												formContent = fieldValue + "#" + splitFormDetails;
											} else {
												formContent = tempArray.join('*@*') + "#" + splitFormDetails;
											}
										}
									}
									if (docs[k].Form_ID != "") {
										var fieldValue = docs[k].Form_ID;
										if (formContent == "") {
											formContent = "#" + fieldValue;
										} else {
											var splitDocDetails = formContent.split('#')[0];
											var splitFormDetails = formContent.split('#')[1];
											tmpFormIds.push(fieldValue);
											if (splitFormDetails == "") {
												formContent = splitDocDetails + "#" + tmpFormIds.toString();
											} else {
												formContent = splitDocDetails + "#" + tmpFormIds.toString();
											}
										}
									}
								}
							}
						}
					}
				}
			}
			$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT'] = formContent;
			$scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data']['DS_FORMCONTENT1'] = $scope.ORIMsgCustomFields['Certificate_Ref'];
			$scope.data['myFields']['Asite_System_Data_Read_Write']['ORI_MSG_Fields']['ORI_USERREF'] = $scope.ORIMsgCustomFields['Certificate_Ref'];
		}
		// $scope.restrictCharPaste, $scope.restrictChar, $scope.delayedResize, $scope.expandTextArea $scope.expandTextAreaOnLoad generic code Added in base.js

		$scope.CheckDuplicate = function (args) {
			var currentIndex = args.repeatObj.indexOf(args.curObj);
			angular.forEach(args.repeatObj, function (item, index) {
				if (currentIndex != index && args.value != "" && item[args.objName] != "" && item[args.objName].toLowerCase() == args.value.toLowerCase()) {
					alert("Duplicate " + args.msg + " Entered !!!\n\Enter a different " + args.msg);
					args.curObj[args.objName] = "";
					return true;
				}
			});
			//checkDuplicateValueSubSectionAtSectionLevel
			if (args.objName == "Sub_Section_Description") {
				if (args.value != "" && args.repeatParentObj[args.parentObjName] && args.repeatParentObj[args.parentObjName].toLowerCase() == args.value.toLowerCase()) {
					alert("Duplicate " + args.msg + " Entered !!!\n\nEnter a different " + args.msg);
					args.curObj[args.objName] = "";
					return true;
				}
			}
			if (args.objName == 'Section_Description') {
				angular.forEach(args.childObj, function (item) {
					if (args.value != "" && item[args.childObjName] && item[args.childObjName].toLowerCase() == args.value.toLowerCase()) {
						alert("Duplicate " + args.msg + " Entered !!!\n\nEnter a different " + args.msg);
						args.curObj[args.objName] = "";
						return true;
					}
				});
			}
			return false;
		};

		$scope.checkDuplicateValues = function (args) {
			var flagSingleOrMulipleCheck = args.flag,
				formId = "",
				dbFormId = "",
				docRef = "",
				dbDocRef = "",
				docRev = "",
				dbDocRev = "",
				count = 0;
			if ($scope.Documents_Section) {
				for (var i = 0; i < $scope.Documents_Section.length; i++) {
					var documents = $scope.Documents_Section[i] && $scope.Documents_Section[i].Documents_Group.Documents;
					if (documents) {
						for (var j = 0; j < documents.length; j++) {
							var docs = documents[j] && documents[j].Alldocs.docs;
							if (docs) {
								for (var k = 0; k < docs.length; k++) {
									if (flagSingleOrMulipleCheck == "single") {
										dbFormId = docs[k].Form_ID && docs[k].Form_ID.toLowerCase();
										formId = args.value[0] && args.value[0].toLowerCase();
										if (formId != "" && dbFormId == formId) {
											count++;
										}
									} else {
										docRef = args.value[0] && args.value[0].toLowerCase();
										docRev = args.value[1] && args.value[1].toLowerCase();
										dbDocRef = docs[k].Document_Number && docs[k].Document_Number.toLowerCase();
										dbDocRev = docs[k].Document_Revision && docs[k].Document_Revision.toLowerCase();
										if (docRef && docRev && dbDocRef == docRef && dbDocRev == docRev) {
											count++;
										}
									}
								}
							}
						}
					}
				}
			}
			if (count > 1) {
				if (flagSingleOrMulipleCheck == "single") {
					alert("Duplicate " + args.msg[0] + " selected !!!\n\nSelect a different " + args.msg[0]);
					args.curObj[args.objName[0]] = "";
					return true;
				} else if (flagSingleOrMulipleCheck == "multiple") {
					alert("Duplicate " + args.msg[0] + " and " + args.msg[1] + " selected !!!\n\nSelect a different " + args.msg[0] + " and " + args.msg[1]);
					args.curObj[args.objName[0]] = "";
					args.curObj[args.objName[1]] = "";
					return true;
				}
			}
			return false;
		}

		function UpdateSubSequence(docSection) {
			var Count = 0;
			angular.forEach(docSection.Documents_Group.Documents, function (item, index) {
				Count++;
				var strAppend = Count && Count.toString();
				if (strAppend && strAppend.toString().length == 1) {
					strAppend = "0" + strAppend;
				}
				if (item) {
					item.Sub_Sequence_Number = docSection.Sequence_Number && docSection.Sequence_Number.toString() + "." + strAppend;
					item.Ref_Sequence_Number = docSection.Sequence_Number;
				}
				angular.forEach(docSection.Documents_Group.Documents[index]['Alldocs']['docs'], function (childItem, childIndex) {
					if (childItem) {
						childItem.Ref_Sub_Sequence_Number = docSection.Sequence_Number && docSection.Sequence_Number.toString() + "." + strAppend;
						childItem.Ref_Parent_Seq_Number = docSection.Sequence_Number;
					}
				});
			});
		}

		$scope.AddNewRowSequence = function (repeatingData, fromStructure, parentStructure, parentIndex) {
			var count = 0;
			count = parentStructure && parentStructure.Documents_Group && parentStructure.Documents_Group.Documents && parentStructure.Documents_Group.Documents.length;
			var item = angular.copy(fromStructure);
			repeatingData.push(item);
			if (count) {
				count++;
				var strAppend = count && count.toString();
				if (strAppend && strAppend.length == 1) {
					strAppend = "0" + strAppend;
				}
				if (item) {
					item.Sub_Sequence_Number = parentStructure.Sequence_Number && parentStructure.Sequence_Number.toString() + "." + strAppend;
					item.Ref_Sequence_Number = parentStructure.Sequence_Number;
				}
				angular.forEach(item['Alldocs']['docs'], function (childItem, childIndex) {
					if (childItem) {
						childItem.Ref_Sub_Sequence_Number = parentStructure.Sequence_Number && parentStructure.Sequence_Number.toString() + "." + strAppend;
						childItem.Ref_Parent_Seq_Number = parentStructure.Sequence_Number;
					}
				});
			}
		}

		$scope.AddNewRow = function (repeatingData, fromStructure, flag) {
			var item = angular.copy(fromStructure);
			if (flag == "Document") {
				if (repeatingData.length) {
					var strLen = repeatingData.length - 1;
					var strGetDbSeq = repeatingData[strLen].dbSeq;
					var strSetDbSeq = parseInt(strGetDbSeq) + 1;
					if (repeatingData[strLen].Ref_Parent_Seq_Number != "") {
						item.Ref_Parent_Seq_Number = repeatingData[strLen].Ref_Parent_Seq_Number;
						item.Ref_Sub_Sequence_Number = repeatingData[strLen].Ref_Sub_Sequence_Number;
					}
					item.dbSeq = strSetDbSeq;
				}
			}
			if (flag == "DocumentSection") {
				var strSeqNo = repeatingData[repeatingData.length - 1].Sequence_Number;
				if (strSeqNo) {
					var intSeqNo = parseInt(strSeqNo) + 1;
					item.Sequence_Number = intSeqNo;
					item.Documents_Group.Documents[0].Sub_Sequence_Number = intSeqNo + ".01";
					item.Documents_Group.Documents[0].Ref_Sequence_Number = intSeqNo;
					item.Documents_Group.Documents[0].Alldocs.docs[0].Ref_Parent_Seq_Number = intSeqNo;
					item.Documents_Group.Documents[0].Alldocs.docs[0].Ref_Sub_Sequence_Number = intSeqNo + ".01";
				}
			} else {
				var strSeqNo = repeatingData[repeatingData.length - 1].ACF_02_Sequence_Number;
				if (strSeqNo) {
					var intSeqNo = parseInt(strSeqNo) + 1;
					item.ACF_02_Sequence_Number = intSeqNo;
				}
			}
			repeatingData.push(item);
			if (flag == "DocumentSection") {
				//sending latest current index node
				UpdateSubSequence(item);
			}
		}

		$scope.DeleteRow = function (obj, repeatingData, flag) {
			var index = repeatingData.indexOf(obj);
			if (index > -1 && (flag == "Doc_Section" && repeatingData[index].SecDoNotDelete == true) || (flag == "Doc_Sub_Section" && repeatingData[index].SubSecDoNotDelete == true) || (flag == "Document" && repeatingData[index].DocDoNotDelete == true)) {
				return;
			} else if (repeatingData.length == 1) {
				if (flag == "Doc_Section") {
					alert("This is a mandatory section and therefore cannot be deleted.");
				}
				if (flag == "Doc_Sub_Section") {
					alert("One Document Sub-Section is mandatory.");
				}
				if (flag == "Document") {
					alert("One row of reference is mandatory.");
				}
				return;
			} else if (confirm('Are you sure you want to delete the row?')) {
				if (flag == "Doc_Section") {
					// this code added to remove doc association and form association form main doc section remove/delete row.
					var currentSectionNode = repeatingData[index] && repeatingData[index].Documents_Group.Documents;
					var objCurrentDoc = {};
					var objAllSubSectionNodes = {};
					if (currentSectionNode.length) {
						for (var i = 0; i < currentSectionNode.length; i++) {
							objAllSubSectionNodes = currentSectionNode[i].Alldocs.docs;
							for (var j = 0; j < objAllSubSectionNodes.length; j++) {
								objCurrentDoc = objAllSubSectionNodes[j];
								var tmpKey = objCurrentDoc.Ref_Parent_Seq_Number + '-' + objCurrentDoc.Ref_Sub_Sequence_Number + '-' + j;
								if (objCurrentDoc.Document_Number && objCurrentDoc.Document_Revision) {
									delete strDocumentKeys[tmpKey];
								}
								if (objCurrentDoc.Form_ID != "") {
									
									delete strAllAppBuilderId[tmpKey];
								}
							}
						}
					}
					refreshSequence(repeatingData, "Sequence_Number");
				}
				if (flag == "Doc_Sub_Section") {
					// this code added to remove doc association and form association form doc sub section remove/delete row.
					var objCurrentDoc = {};
					var currentSubSectionNode = repeatingData[index] && repeatingData[index].Alldocs.docs;
					if (currentSubSectionNode.length) {
						for (var j = 0; j < currentSubSectionNode.length; j++) {
							objCurrentDoc = currentSubSectionNode[j];
							var tmpKey = objCurrentDoc.Ref_Parent_Seq_Number + '-' + objCurrentDoc.Ref_Sub_Sequence_Number + '-' + j;
							if (objCurrentDoc.Document_Number && objCurrentDoc.Document_Revision) {
								delete strDocumentKeys[tmpKey];
							}
							if (objCurrentDoc.Form_ID != "") {
								delete strAllAppBuilderId[tmpKey];
							}
						}
					}
					subSequenceUpdate(repeatingData);
				}
				if (flag == "Document") {
					var tmpKey = obj.Ref_Parent_Seq_Number + '-' + obj.Ref_Sub_Sequence_Number + '-' + index;
					if (obj.Document_Number && obj.Document_Revision) {
						delete strDocumentKeys[tmpKey];
					}
					if (obj.Form_ID != "") {
						delete strAllAppBuilderId[tmpKey];
					}
				}
				repeatingData.splice(index, 1);
			}
		}

		function subSequenceUpdate(repeatingData) {
			var count = 0;
			if (repeatingData) {
				angular.forEach(repeatingData, function (subSection, subSectionIndex) {
					count++;
					var strAppend = count && count.toString();
					if (strAppend && strAppend.length == 1) {
						strAppend = "0" + strAppend;
					}
					subSection.Sub_Sequence_Number = subSection.Ref_Sequence_Number && subSection.Ref_Sequence_Number.toString() + "." + strAppend;
					angular.forEach(subSection['Alldocs']['docs'], function (childItem, childIndex) {
						if (childItem) {
							childItem.Ref_Sub_Sequence_Number = subSection.Sub_Sequence_Number;
						}
					});
				});
			}
		}

		$scope.DeleteRowCowl = function (obj, repeatingData, flag) {
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
			if (flag == "Cowl_Section") {
				if (repeatingData.length == 0) {
					var item = angular.copy($scope.cowl);
					repeatingData.push(item);
				}
			}
			refreshSequence(repeatingData, "ACF_02_Sequence_Number");
		}

		function refreshSequence(AllNodes, nodeToUpdate) {
			var sequenceCounter = 1;
			angular.forEach(AllNodes, function (docSection, index) {
				docSection[nodeToUpdate] = sequenceCounter;
				sequenceCounter++;
				if (nodeToUpdate == "Sequence_Number") {
					var Count = 0;
					angular.forEach(docSection.Documents_Group.Documents, function (item, index) {
						Count++;
						var strAppend = Count && Count.toString();
						if (strAppend && strAppend.toString().length == 1) {
							strAppend = "0" + strAppend;
						}
						if (item) {
							item.Sub_Sequence_Number = docSection.Sequence_Number && docSection.Sequence_Number.toString() + "." + strAppend;
							item.Ref_Sequence_Number = docSection.Sequence_Number;
						}
						angular.forEach(docSection.Documents_Group.Documents[index]['Alldocs']['docs'], function (childItem, childIndex) {
							if (childItem) {
								childItem.Ref_Sub_Sequence_Number = docSection.Sequence_Number && docSection.Sequence_Number.toString() + "." + strAppend;
								childItem.Ref_Parent_Seq_Number = docSection.Sequence_Number;
							}
						});
					});
				}
			});
		}

		/****************************************/
		//Implement TABs in Angular for ORI view
		/****************************************/

		var isPermanent = $scope.formCustomFields.DSI_IsPermanent;
		if (strAppBuilderCode == "TTT-SEC" || isPermanent.toLowerCase() == 'temporary works') {
			DraftFormFlag = false;
			$scope.oriviewtabs = [{
				title: 'Statements',
				url: 'Statements.html'
			}, {
				title: 'Package Listing',
				url: 'packageListing.html'
			}]
		} else {
			$scope.oriviewtabs = [{
				title: 'Statements',
				url: 'Statements.html'
			}, {
				title: 'Package Listing',
				url: 'packageListing.html'
			}, {
				title: 'COWL',
				url: 'COWL.html'
			}]
		}

		$scope.currentOriViewTab = 'Statements.html';

		if (DraftFormFlag == true) {
			$scope.oriprintviewtabs = [{
				title: 'Statements',
				url: 'Statements.html'
			}, {
				title: 'Package Listing',
				url: 'packageListing.html'
			}, {
				title: 'COWL',
				url: 'COWL.html'
			}, {
				title: "References",
				url: "References.html"
			}];
		} else {
			$scope.oriprintviewtabs = [{
				title: "Statements",
				url: "Statements.html"
			}, {
				title: "Package Listing",
				url: "packageListing.html"
			}, {
				title: "References",
				url: "References.html"
			}];
		}

		if (strAppBuilderCode != "TTT-WRK-SITEF") {
			$scope.currentOriPrintViewTab = 'Statements.html';
		}

		// worksite complete final form tabs
		if (strAppBuilderCode == "TTT-WRK-SITEF") {
			$scope.oriPrintViewWorksiteCompleteFinalTabs = [{
				title: "Ready",
				url: "worksiteReady.html"
			}, {
				title: "Complete",
				url: "worksiteComplete.html"
			}];

			$scope.currentOriPrintViewReadyCompleteFinalTab = 'worksiteReady.html';

			$scope.oriprintviewtabsReady = [{
				title: "Statements",
				url: "StatementsReady.html"
			}, {
				title: "Package Listing",
				url: "packageListingReady.html"
			}, {
				title: "References",
				url: "ReferencesReady.html"
			}];
			$scope.currentOriPrintViewReadyFinalTab = 'StatementsReady.html';

		}


		/****************************************/
		$scope.isActiveTab = function (tabUrl, calledform) {
			if (calledform == "ori_print_view_main") {
				return tabUrl == $scope.currentOriPrintViewTab;
			} else if (calledform == "ori_view_main") {
				return tabUrl == $scope.currentOriViewTab;
			} else if (calledform == "ori_print_view_worksite_final_main") {
				return tabUrl == $scope.currentOriPrintViewReadyCompleteFinalTab;
			} else if (calledform == "ori_print_view_ready_main") {
				return tabUrl == $scope.currentOriPrintViewReadyFinalTab;
			}

		}

		/****************************************/

		$scope.setTitle = "STATEMENTS";
		$scope.setPartNo = "1";
		$scope.flagReadyOrComplete = "Ready";
		$scope.onClickTab = function (tab, calledform) {
			var strFlag = "STATEMENTS",
				intPartNo = "1";
			if (calledform == "ori_view_main") {
				$scope.currentOriViewTab = tab.url;
			}
			if (calledform == "ori_print_view_main") {
				$scope.currentOriPrintViewTab = tab.url;
			}
			if (calledform == "ori_print_view_worksite_final_main") {
				if (tab.title == "Ready") {
					$scope.flagReadyOrComplete = "Ready";
					$scope.currentOriPrintViewReadyFinalTab = 'StatementsReady.html';
					$scope.currentOriPrintViewTab = '';
				} else if (tab.title == "Complete") {
					$scope.flagReadyOrComplete = "Complete";
					$scope.currentOriPrintViewTab = 'Statements.html';
					$scope.currentOriPrintViewReadyFinalTab = '';
				}
				$scope.currentOriPrintViewReadyCompleteFinalTab = tab.url;
			}
			if (calledform == "ori_print_view_ready_main") {
				$scope.currentOriPrintViewReadyFinalTab = tab.url;
			}
			if (tab.title == "Package Listing") {
				strFlag = "PACKAGE LISTING";
				intPartNo = "2";
			}
			if (tab.title == "COWL" && DraftFormFlag == true) {
				strFlag = "COWL";
				intPartNo = "3";
			}
			if (tab.title == "References" && DraftFormFlag == true) {
				strFlag = "REFERENCES";
				intPartNo = "4";
			}
			if (tab.title == "References" && DraftFormFlag != true) {
				strFlag = "REFERENCES";
				intPartNo = "3";
			}
			$scope.setTitle = strFlag;
			$scope.setPartNo = intPartNo;

			$timeout(function () {
				$scope.expandTextAreaOnLoad();
			}, 500);
		}

		// Common function for store init array of All Tables
		$scope.documentSection = {
			"Documents_Group": {
				"Sequence_Number": "",
				"Section_Description": "",
				"SecDoNotDelete": "",
				"Documents": [{
					"Sub_Sequence_Number": "",
					"Sub_Section_Description": "",
					"Ref_Sequence_Number": "",
					"SubSecDoNotDelete": "",
					"Alldocs": {
						"docs": [{
							"Document_Number": "",
							"DocRef_HyperLink": "",
							"Document_Title": "",
							"Document_Revision": "",
							"Purpose_Of_Issue": "",
							"Document_Status": "",
							"Is_Latest": "",
							"Commenting_Form_ID": "",
							"Commenting_HyperLink": "",
							"Rejection_Comments": "",
							"Error_Code": "",
							"Form_ID": "",
							"dbFormId": "",
							"Form_HyperLink": "",
							"Form_Title": "",
							"Form_Status": "",
							"Form_Code": "",
							"Form_UserRef": "",
							"DocsDisableFlag": "false",
							"FormsDisableFlag": "false",
							"rowColorFlag": "",
							"isLoading": "",
							"RevisionID": "",
							"Ref_Parent_Seq_Number": "",
							"Ref_Sub_Sequence_Number": "",
							"dbSeq": "1",
							"DocDoNotDelete": "",
							"Doc_Path": "",
							"AppBuilderId": ""
						}]
					}
				}]
			}
		};

		$scope.documents = {
			"Sub_Sequence_Number": "",
			"Sub_Section_Description": "",
			"Ref_Sequence_Number": "",
			"SubSecDoNotDelete": "",
			"Alldocs": {
				"docs": [{
					"Document_Number": "",
					"DocRef_HyperLink": "",
					"Document_Title": "",
					"Document_Revision": "",
					"Purpose_Of_Issue": "",
					"Document_Status": "",
					"Is_Latest": "",
					"Commenting_Form_ID": "",
					"Commenting_HyperLink": "",
					"Rejection_Comments": "",
					"Error_Code": "",
					"Form_ID": "",
					"dbFormId": "",
					"Form_HyperLink": "",
					"Form_Title": "",
					"Form_Status": "",
					"Form_Code": "",
					"Form_UserRef": "",
					"DocsDisableFlag": "false",
					"FormsDisableFlag": "false",
					"rowColorFlag": "",
					"isLoading": "",
					"RevisionID": "",
					"Ref_Parent_Seq_Number": "",
					"Ref_Sub_Sequence_Number": "",
					"dbSeq": "1",
					"DocDoNotDelete": "",
					"Doc_Path": "",
					"AppBuilderId": ""
				}]
			}
		};

		$scope.docs = {
			"Document_Number": "",
			"DocRef_HyperLink": "",
			"Document_Title": "",
			"Document_Revision": "",
			"Purpose_Of_Issue": "",
			"Document_Status": "",
			"Is_Latest": "",
			"Commenting_Form_ID": "",
			"Commenting_HyperLink": "",
			"Rejection_Comments": "",
			"Error_Code": "",
			"Form_ID": "",
			"dbFormId": "",
			"Form_HyperLink": "",
			"Form_Title": "",
			"Form_Status": "",
			"Form_Code": "",
			"Form_UserRef": "",
			"DocsDisableFlag": "false",
			"FormsDisableFlag": "false",
			"rowColorFlag": "",
			"isLoading": "",
			"RevisionID": "",
			"Ref_Parent_Seq_Number": "",
			"Ref_Sub_Sequence_Number": "",
			"dbSeq": "1",
			"DocDoNotDelete": "",
			"Doc_Path": "",
			"AppBuilderId": ""
		};

		$scope.cowl = {
			"ACF_02_Cowl_isactive": "",
			"ACF_02_Cowl_Desc": "",
			"ACF_02_Cowl_Action": "",
			"ACF_02_Cowl_Asiteref": "",
			"ACF_02_Cowl_Closed_Date": "",
			"ACF_02_Send_approve": "",
			"ACF_02_Is_approved": "",
			"ACF_02_Sequence_Number": "",
			"ACF_02_Approved_Status": "Not Submitted",
			"ACF_02_Is_Update": "",
			"ACF_02_Is_New": "",
			"ACF_02_Cowl_Guid": "",
			"ACF_02_Cowl_Certificate_Reference": "",
			"ACF_02_Cowl_Id": "",
			"ACF_02_Cowl_Url": ""
		};

		// Common function for store init array of autocreate All Tables
		var autoCreateDocumentSection = {
			"ACF_01_Sequence_Number": "",
			"ACF_01_Section_Description": "",
			"ACF_01_SecDoNotDelete": "",
			"ACF_01_Documents_Group": {
				"ACF_01_Documents": [{
					"ACF_01_Sub_Sequence_Number": "",
					"ACF_01_Sub_Section_Description": "",
					"ACF_01_Ref_Sequence_Number": "",
					"ACF_01_SubSecDoNotDelete": "",
					"ACF_01_Alldocs": {
						"ACF_01_docs": [{
							"ACF_01_Document_Number": "",
							"ACF_01_DocRef_HyperLink": "",
							"ACF_01_Document_Title": "",
							"ACF_01_Document_Revision": "",
							"ACF_01_Purpose_Of_Issue": "",
							"ACF_01_Document_Status": "",
							"ACF_01_Is_Latest": "",
							"ACF_01_Commenting_Form_ID": "",
							"ACF_01_Commenting_HyperLink": "",
							"ACF_01_Rejection_Comments": "",
							"ACF_01_Error_Code": "",
							"ACF_01_Form_ID": "",
							"ACF_01_dbFormId": "",
							"ACF_01_Form_HyperLink": "",
							"ACF_01_Form_Title": "",
							"ACF_01_Form_Status": "",
							"ACF_01_Form_Code": "",
							"ACF_01_Form_UserRef": "",
							"ACF_01_DocsDisableFlag": "false",
							"ACF_01_FormsDisableFlag": "false",
							"ACF_01_rowColorFlag": "",
							"ACF_01_isLoading": "",
							"ACF_01_RevisionID": "",
							"ACF_01_Ref_Parent_Seq_Number": "",
							"ACF_01_Ref_Sub_Sequence_Number": "",
							"ACF_01_dbSeq": "1",
							"ACF_01_DocDoNotDelete": "",
							"ACF_01_Doc_Path": ""
						}]
					}
				}]
			}
		}

		var autoCreateDocuments = {
			"ACF_01_Sub_Sequence_Number": "",
			"ACF_01_Sub_Section_Description": "",
			"ACF_01_Ref_Sequence_Number": "",
			"ACF_01_SubSecDoNotDelete": "",
			"ACF_01_Alldocs": {
				"ACF_01_docs": [{
					"ACF_01_Document_Number": "",
					"ACF_01_DocRef_HyperLink": "",
					"ACF_01_Document_Title": "",
					"ACF_01_Document_Revision": "",
					"ACF_01_Purpose_Of_Issue": "",
					"ACF_01_Document_Status": "",
					"ACF_01_Is_Latest": "",
					"ACF_01_Commenting_Form_ID": "",
					"ACF_01_Commenting_HyperLink": "",
					"ACF_01_Rejection_Comments": "",
					"ACF_01_Error_Code": "",
					"ACF_01_Form_ID": "",
					"ACF_01_dbFormId": "",
					"ACF_01_Form_HyperLink": "",
					"ACF_01_Form_Title": "",
					"ACF_01_Form_Status": "",
					"ACF_01_Form_Code": "",
					"ACF_01_Form_UserRef": "",
					"ACF_01_DocsDisableFlag": "false",
					"ACF_01_FormsDisableFlag": "false",
					"ACF_01_rowColorFlag": "",
					"ACF_01_isLoading": "",
					"ACF_01_RevisionID": "",
					"ACF_01_Ref_Parent_Seq_Number": "",
					"ACF_01_Ref_Sub_Sequence_Number": "",
					"ACF_01_dbSeq": "1",
					"ACF_01_DocDoNotDelete": "",
					"ACF_01_Doc_Path": ""
				}]
			}
		}

		var autoCreateDocs = {
			"ACF_01_Document_Number": "",
			"ACF_01_DocRef_HyperLink": "",
			"ACF_01_Document_Title": "",
			"ACF_01_Document_Revision": "",
			"ACF_01_Purpose_Of_Issue": "",
			"ACF_01_Document_Status": "",
			"ACF_01_Is_Latest": "",
			"ACF_01_Commenting_Form_ID": "",
			"ACF_01_Commenting_HyperLink": "",
			"ACF_01_Rejection_Comments": "",
			"ACF_01_Error_Code": "",
			"ACF_01_Form_ID": "",
			"ACF_01_dbFormId": "",
			"ACF_01_Form_HyperLink": "",
			"ACF_01_Form_Title": "",
			"ACF_01_Form_Status": "",
			"ACF_01_Form_Code": "",
			"ACF_01_Form_UserRef": "",
			"ACF_01_DocsDisableFlag": "false",
			"ACF_01_FormsDisableFlag": "false",
			"ACF_01_rowColorFlag": "",
			"ACF_01_isLoading": "",
			"ACF_01_RevisionID": "",
			"ACF_01_Ref_Parent_Seq_Number": "",
			"ACF_01_Ref_Sub_Sequence_Number": "",
			"ACF_01_dbSeq": "1",
			"ACF_01_DocDoNotDelete": "",
			"ACF_01_Doc_Path": ""
		}

		$scope.disableDocAndForms = function (parent, flag) {
			if (flag == 'FormId') {
				if (parent.Document_Number != "" && parent.Document_Revision != "") {
					parent.FormsDisableFlag = true;
					parent.Form_ID = "";
				} else {
					parent.FormsDisableFlag = false;
				}
			} else {
				if (parent.Form_ID != "") {
					parent.DocsDisableFlag = true;
					parent.Document_Revision = "";
					parent.Document_Number = "";
				} else {
					parent.DocsDisableFlag = false;
				}
			}
		}
		$scope.update();
	}
	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof TTT_AssociateDocsAndForms !== "undefined") {
		return TTT_AssociateDocsAndForms();
	}
}