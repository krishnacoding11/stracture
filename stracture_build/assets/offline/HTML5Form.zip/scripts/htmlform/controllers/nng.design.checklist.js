define(['angular', './base', '../components/signature'], function(angular, baseController) {
     'use strict';
     
      /*
      * @constructor
      * @alias module:Form-Controller/FormController
      */
     function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout) {       
        var printedOn = "";
        var currentViewName = $window.currentViewName;
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        
        $scope.isFullLoaded({
            onComplete: function () {
            	$timeout(function() {
            		$scope.loaded = true;
            		$element.addClass('loaded');                
            	}, 50);
            }
        });

        if($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        
        $scope.commentList = [];

        $scope.getCommentsListArray = function() {
            var retArray = [];
            for (var i = 0; i < $scope.data.myFields.NNG_Forms.Design_Checklist.length; i++) {
                var section = $scope.data.myFields.NNG_Forms.Design_Checklist[i];
                for (var j = 0; j < section.Sub_Section.length; j++) {
                    var sub_sec = section.Sub_Section[j];
                    if(sub_sec.Meets == 'Other' && sub_sec.Comment) {
                        retArray.push(sub_sec);
                    }
                }
            }            
            return retArray;
        };

        $scope.onChangeMeets = function(sub_sec, section){
            sub_sec.Meets = sub_sec.Meets || '';
            var value = sub_sec.Meets;            
            if(value=="Yes" || value=="No"){
                sub_sec.Comment = "";
            }

            section.rowspan = section.Sub_Section.filter(function(subSecObj) {
                return !subSecObj.isHide;
            }).length;
            for (var j = 0; j < section.Sub_Section.length; j++) {
                var subsec = section.Sub_Section[j];
                subsec.rowspan = subsec.categoryCount;

                if(subsec.Meets == 'Other') {
                    section.rowspan++;
                    var firstSubSection = section.Sub_Section[j - (subsec.categoryIndex - 1)]
                    firstSubSection.rowspan++;
                }
            }
        };

        $scope.filterDsProjUserAllRoles = function(item){
            var userRole = item.Value.split('|')[0] || "";
            userRole = userRole.toLowerCase();
            if(userRole.indexOf("project engineer") > -1 || userRole.indexOf("electrical engineer") > -1){
                return true;
            }
        }

        $scope.OnPipelineFacilityChange = function(){
            var title = $scope.data.myFields['FORM_CUSTOM_FIELDS']['ORI_MSG_Custom_Fields']['ORI_FORMTITLE'];
            if(title){                
                $scope.data.myFields['NNG_Forms']['Pipeline_Facility'] = title;
            }
        }

        var strFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
        var strIsDraft = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_ISDRAFT'];        
        if(currentViewName == "ORI_VIEW" && (strFormId == '' || strIsDraft == "YES")){
            $scope.getServerTime(function(serverDate) {
                $scope.data.myFields['group1']['Date']  = $scope.formatDate(new Date(serverDate), 'mm/dd/yy');                
            });    
        }

        $scope.DS_PROJUSERS_ALL_ROLES = [];

        var DS_PROJUSERS_ALL_ROLES = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES') || [];
         if(DS_PROJUSERS_ALL_ROLES[0] && DS_PROJUSERS_ALL_ROLES[0].Value){
            $scope.DS_PROJUSERS_ALL_ROLES = DS_PROJUSERS_ALL_ROLES;
            for(var t=0; t<$scope.DS_PROJUSERS_ALL_ROLES.length; t++) {
                $scope.DS_PROJUSERS_ALL_ROLES[t].Name = $scope.DS_PROJUSERS_ALL_ROLES[t].Name.split(',')[0].trim();
            }
        }
        
        

        var projectMasterFormDetails = $scope.getValueOfOnLoadData("DS_NNG_PMF_GET_ProjectMasterForm_Details")[0] || {}; 
        $scope.projectName = projectMasterFormDetails.Value3 || "";//Project_Name
        $scope.workOrderNo = projectMasterFormDetails.Value1 || "";//Work_Order_Number
        $scope.projectDescription = projectMasterFormDetails.Value17 || "";//LegalLandDescription
        
        if (currentViewName == "ORI_VIEW" && (strIsDraft == "NO" || strIsDraft == "") && strFormId == "") {
            
            var checkListData = $scope.getValueOfOnLoadData("DS_NNG_Checklist_Data") || {};
            var allParenNode = getMatchValueFromArray(checkListData, '0', 'Value4',true);
            var newCheckListData = [];
    
            for (var index = 0; index < allParenNode.length; index++) {
                var element = allParenNode[index];
                var allChildNodes = getMatchValueFromArray(checkListData, element.Value1, 'Value4',true);
                var tmpChildNodes = getSubSectionsArray(allChildNodes, checkListData);
    
                newCheckListData.push({
                    "Section_No": element.Value2,
                    "Section_Title": element.Value3,
                    "Sub_Section": tmpChildNodes,
                    "rowspan": tmpChildNodes.filter(function(subSec){
                        return !subSec.isHide;
                    }).length,
                    "isHide" : (element.Value7 == "true"),
                    "isSectionIdHide" : (element.Value8 == "true"),
                    "isHeaderRow" : (element.Value9 == "true"),
                });
                
            }           
            $scope.data.myFields.NNG_Forms.Design_Checklist = newCheckListData;
        }

        $timeout(function(){
            $scope.expandTextAreaOnLoad();
        }, 500);
        $scope.update();

        function getSubSectionsArray(allChildNodes, checkListData){
            var tmpIndex = 0;
            var tmpChildNodes = [];

            // object pushed for section nodes with no childs.
            if(!allChildNodes.length){
                tmpChildNodes.push({
                    Catogery_No: "",
                    Comment: "",
                    Description: "",
                    Initials: "",
                    Meets: "",
                    Paragraph: "",
                    Section_No: "",
                    Standards: "",
                    isSubSec: true,
                    Sub_Section_No: "",
                    categoryCount: 1,
                    categoryIndex: 1,
                    rowspan: 1,
                    isHide : false,
                    isSectionIdHide : false,
                    isHeaderRow : false
                });
                return tmpChildNodes;
            }

            for (var k = 0; k < allChildNodes.length; k++) {
                var chNode = allChildNodes[k];
                var subSecNode = getMatchValueFromArray(checkListData, chNode.Value1, 'Value4',true);
                var sameCateGoryNode = getMatchValueFromArray(allChildNodes, chNode.Value2, 'Value2',true);
                var showenRowlength = sameCateGoryNode.filter(function(sameCatObj) {
                    return sameCatObj.Value7 != "true";
                }).length;
                
                var isSubSec = false;
                var tempChildNodes = [];
                if(subSecNode && subSecNode.length > 0){
                    tempChildNodes = getSubSectionsArray(subSecNode, checkListData);                    
                    if(tempChildNodes.length > 0) {
                        isSubSec = true;
                    }
                }
                
                if(chNode.Value7 == 'true'){                                    
                    if(tempChildNodes.length > 0){
                        tmpChildNodes = tmpChildNodes.concat(tempChildNodes);                            
                    }                
                    continue;
                }

                if(tmpIndex < showenRowlength){
                    tmpIndex++;
                }

                tmpChildNodes.push({
                    Catogery_No: chNode.Value2,
                    Comment: "",
                    Description: chNode.Value3,
                    Initials: "",
                    Meets: "",
                    Paragraph: chNode.Value5,
                    Section_No: chNode.Value2,
                    Standards: chNode.Value6,
                    isSubSec: isSubSec,
                    Sub_Section_No: chNode.Value2,
                    categoryCount:  showenRowlength,
                    categoryIndex: tmpIndex,
                    rowspan: showenRowlength,
                    isHide : (chNode.Value7 == "true"),
                    isSectionIdHide : (chNode.Value8 == "true"),
                    isHeaderRow : (chNode.Value9 == "true")
                });
                if(tempChildNodes.length > 0){
                    tmpChildNodes = tmpChildNodes.concat(tempChildNodes);
                }

                if(tmpIndex == showenRowlength){
                    tmpIndex=0;
                }
            }            
            return tmpChildNodes;
        }

        function getMatchValueFromArray( scpObject , matchVal ,keys, isEqualMatch ){
            return commonApi._.filter( scpObject , function(a){
                return isEqualMatch ? (a[keys] == matchVal) : (a[keys].indexOf( matchVal ) > -1)
            });
        }
    }
     
    return FormController;
 });