/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util', '../components/signature', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		var ctrl = this;

		// restrict autosave Draft and hide Save Draft button.
		if ($window.stopAutoSaveTimer) {
			$window.stopAutoSaveTimer();
		} else if ($window.oAutoSaveTimer) {
			$window.clearTimeout($window.oAutoSaveTimer);
			$window.oAutoSaveTimer = null;
		}

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		var currentViewName = window.currentViewName;

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 1000);
			}
		});

		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (currentViewName == 'ORI_VIEW');
		$scope.isRespView = (currentViewName == 'RES_VIEW');
		$scope.isOriPrintView = (currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespPrintView = (currentViewName == 'RES_PRINT_VIEW');
		var projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES');

		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;
		$scope.cvmpChecklist = $scope.oriMsgCustomFields.cvmpChecklist;
		$scope.approvalCorrectiveActionsDetails = $scope.oriMsgCustomFields.approvalCorrectiveActionsDetails;
		$scope.isContentFilledOut = !!($scope.oriMsgCustomFields['formCreatedServerDate']);
		$scope.xhr = {
			guIdXhr: false,
			platformXhr: false
		};
		var dateFormatMap = {
				"en_GB": "dd-M-yy",
				"fr_FR": "d M yy",
				"es_ES": "dd-M-yy",
				"ru_RU": "dd.mm.yy",
				"en_AU": "dd/mm/yy",
				"en_CA": "d-M-yy",
				"en_US": "M d, yy",
				"zh_CN": "yy-m-d",
				"de_DE": "dd.mm.yy",
				"ga_IE": "d M yy",
				"en_ZA": "dd M yy",
				"ja_JP": "yy/mm/dd",
				"ar_SA": "dd/mm/yy",
				"en_IE": "dd-M-yy"
			},
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			_5_Form_Data = $scope.asiteSystemDataReadOnly['_5_Form_Data'],
			isDraft = (_5_Form_Data.DS_ISDRAFT.toLowerCase() == 'yes'),
			isEditOri = !!($scope.dSFormId && !isDraft),
			workspaceName = $scope.asiteSystemDataReadOnly['_3_Project_Data']['DS_PROJECTNAME'],

			CONSTANTS_OBJ = {
				DS_GET_GUID: 'DS_GET_GUID',
				DOC_ASSESSMENT_KEY: 'doc-assessment',
				CONTRACTORS_USERS_KEY: 'inductees-users-list',
				DIST_USERS_LABEL_STR: 'Inductee list',
			},
			STATIC_OBJ = {
				CONFIG_JSON: [],
				questionsList: {
					queNo: "",
					question: "",
					queGuId: "",
					DSI_Flag: "",
					options: [{
						answer: "",
						selectAnswer: "",
						refqueGuId: "",
						correctAnswer: ""
					}],
					isDefaultQuestion: true
				},
				options: {
					answer: "",
					selectAnswer: "",
					refqueGuId: "",
					correctAnswer: ""
				},
				checkBoxList1: {
					licenceName: "",
					Number: "",
					docAssAttachedDocs: [{
						attachedDoc: "",
						refqueGuId: ""
					}],
					isMandatoryattachedDoc: true,
					isHolding: false,
					Guid: ""
				},

				Qualification_Trade_ticket: {
					isRecordSelected: false,
					isRecordShow: true,
					isRecordDeleted: false,
					isRecordHeader: false,
					isRatesForExchangeData: false,
					Other_Qualifications: "",
					List1AttachmentDocs: [{
						"attachedDoc": ""
					}]
				},
				DrivLicenseAttached: {
					isRecordSelected: false,
					isRecordShow: true,
					isRecordDeleted: false,
					isRecordHeader: false,
					isdrivLicenseFile: false,
					"attachedDoc": ""
				}
			};
		var workingUserId = $scope.getWorkingUserId('DS_WORKINGUSER_ID');
		var msgIncompleteActionList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_MSG_ACTIONS');
		var incompleteActionsByMsgList = $scope.getValueOfOnLoadData('DS_INCOMPLETE_ACTIONS_BYMSG');
		$scope.userDateFormat = userDateFormat;

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			var serverDateObj = new Date(serverDate);
			$scope.todayDateDbFormat = $scope.formatDate(serverDateObj, 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(serverDateObj, 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(serverDateObj, userDateFormat);
			$scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields']['siteInductionDetails']['serverDateObj'] = serverDateObj;
		});
		var strTodayDateTime = getDateTimeFromZone();

		$scope.Logo = '/images/htmlform/sfp/sfpjv-logo.png';
		$scope.oriMsgCustomFields.DS_Logo = $scope.Logo;
		$scope.oriMsgCustomFields.isDefaultLogo = true;
		$scope.isShowOtherFields = false;
		$scope.isPendingAction = false;

		/**All Common functions will be start from here */
		function getDateTimeFromZone() {
			var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
			var now = new Date();
			var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
			utcDate.setHours(todayUTCSplit[0], todayUTCSplit[1], todayUTCSplit[2]);
			return (new Date(parseInt(utcDate.getTime()) + (parseFloat($window.USP.localeVO._timezone.rawOffset) + parseFloat($window.USP.localeVO._timezone.dstSavings))));

		}

		// set contractorlist only when contractor is selected.
		function structureItemList(setFor, availList) {
			var tempList = [],
				optlabel = '';
			switch (setFor) {
				case CONSTANTS_OBJ.CONTRACTORS_USERS_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value
						});
					});
					optlabel = CONSTANTS_OBJ.DIST_USERS_LABEL_STR;
					break;
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		}

		$scope.tableUtilSettings = {
			Qualification_Trade_ticket: {
				tooltip: "select to remove/remove all/Insert new Data",
				hasDefaultRecord: true,
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0,
					insertBefore: 0,
					insertAfter: 0
				},
				DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Data?",
				checkboxModelKey: "isRatesForExchangeData",
				newStaticObject: angular.copy(STATIC_OBJ.Qualification_Trade_ticket),
				deleteAllRowTooltip: "Remove all Data",
				deleteCurrRowMsg: "Remove Data",
				deleteSelectedMsg: "Remove Selected Data"
			},
			DrivLicenseAttached: {
				tooltip: "select to remove/remove all/Insert new Data",
				hasDefaultRecord: true,
				hideControlIcon: {
					editRow: 0,
					deleteAllRow: 0,
					insertBefore: 0,
					insertAfter: 0
				},
				DELETE_ALL_CONFIRM_MSG: "Do you want to remove all Data?",
				checkboxModelKey: "isdrivLicenseFile",
				newStaticObject: angular.copy(STATIC_OBJ.DrivLicenseAttached),
				deleteAllRowTooltip: "Remove all Data",
				deleteCurrRowMsg: "Remove Data",
				deleteSelectedMsg: "Remove Selected Data"
			}
		};

		function setallLists() {
			$scope.siteInductionDetails = $scope.oriMsgCustomFields.siteInductionDetails;
			$scope.personalDetail = $scope.siteInductionDetails.personalDetail;
			$scope.questionnnaire = $scope.siteInductionDetails.siteSafetyInductionQuestionnnaire;
			$scope.userDetails = $scope.siteInductionDetails.userDetails;
		}
		// set selected User msg
		function setUserSelectFirstMsg() {
			if (!$scope.cvmpChecklist.fillUpUserRole) {
				$scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1|Form can not be submitted. Please select your option or click cancel.";
			} else {
				$scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
				$scope.isOriginatorUser = ($scope.cvmpChecklist.fillUpUserRole == 'originator');
				$scope.fillUpUserRole = $scope.cvmpChecklist.fillUpUserRole;
				
				$scope.contractorsList = structureItemList(CONSTANTS_OBJ.CONTRACTORS_USERS_KEY, projAllRolesList.filter(function (obj) {
					return obj.Value.split('|')[0].toLowerCase().trim().indexOf('contractors') > -1
				}));
				if ($scope.isOriView && !$scope.cvmpChecklist.selectedOriginator) {
					$scope.cvmpChecklist.selectedOriginator = commonApi._.find(projAllRolesList, function (roleObj) {
						return roleObj.Value.indexOf(workingUserId) > -1;
					}).Value;
				}
			}
		}
		//Set view data accordingly Ori view.
		function setOriViewBase() {
			setallLists();
			setUserSelectFirstMsg();
			// set workspace name if not matched with the latest one
			if ($scope.personalDetail.detailsGroup.projectName != workspaceName) {
				$scope.personalDetail.detailsGroup.projectName = workspaceName;
			}

			if (strTodayDateTime) {
				// set Inductee and Inductor's Date prepopulated.
				$scope.personalDetail.detailsGroup.inducteeDate = $scope.formatDate(strTodayDateTime, 'yy-mm-dd');
				$scope.userDetails.inductorDate = $scope.formatDate(strTodayDateTime, 'yy-mm-dd');
			}

			// default hide dependend sections on blank value of 'List2UserVal' node's blank value'
			$scope.setIsShowOtherFieldsFlag($scope.personalDetail.questionsGroup.queGroupList.filter(function (obj) {
				return obj.isAllowToAttach;
			})[0]);

		}

		/**
		 * Set view data accordingly response view.
		 */
		function setResViewBase() {
			$scope.isPendingAction = commonApi.checkPendingActionOnMsg({
				incompleteActionsByMsgList: incompleteActionsByMsgList,
				actionName: 'Respond',
				strUser: workingUserId,
				isCheckMsgId: false,
				strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
			});

			if ($scope.isPendingAction || !$scope.dsDbInserted) {
				setallLists();
				setUserSelectFirstMsg();

				$scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "0";
			} else {
				$scope.asiteSystemDataReadOnly['_5_Form_Data'].DS_SEND_MSG = "1| You do not have the required 'Respond' task assigned. Please 'Cancel' the form to return to the previous view.";
			}
		}

		$scope.setFillupUser = function (fillupUserRole) {
			$scope.cvmpChecklist.fillUpUserRole = fillupUserRole;
			$scope.oriMsgCustomFields['ORI_FORMTITLE'] = fillupUserRole == 'originator' ? 'PIR::Inductor' : 'PIR::Inductee';
			setUserSelectFirstMsg();
		};

		if (currentViewName == "ORI_VIEW") {
			if (!isDraft) {
				fillQueAnswers();
			}
		}
		// check selceted answer vali or not
		function validateAnswers() {
			var validAnswer = $scope.oriMsgCustomFields.siteSafetyInductionQuestion.questionsList;
			if (validAnswer.length) {
				for (var i = 0; i < validAnswer.length; i++) {
					for (var j = 0; j < validAnswer[i].options.length; j++) {
						if (validAnswer[i].options[j].correctAnswer != validAnswer[i].options[j].selectAnswer && validAnswer[i].options[j].selectAnswer == true) {
							Notification.warning({
								title: "All answers are not Correct.",
								message: 'Please select write Answer!!!'
							});
							return false;
						}
						$window.parent.postMessage("scrollToTop", '*');
					}
				}
			}
			return true;
		}

		// check this function at list One node is selected
		$scope.setOneNodeSelected = function (curObj, index) {
			var item = curObj.options;
			for (var i = 0; i < item.length; i++) {
				if (i != index) {
					item[i].selectAnswer = false;
				}
			}
			var checkBoxObj = commonApi._.filter(item, function (val) {
				return val.selectAnswer == true;
			});
			curObj.DSI_Flag = checkBoxObj.length ? "yes" : "";
		};
        // set Question and Answer From SITE SAFETY INDUCTION QUESTIONNAIRE form
		function fillQueAnswers() {
			var queAnsDetails = $scope.getValueOfOnLoadData('DS_HSE_SFP_QUE_QUESTIONS_ANSWER_DETAILS');
			$scope.oriMsgCustomFields.siteSafetyInductionQuestion.questionsList = [];
			if (queAnsDetails.length) {
				var insertData = $scope.oriMsgCustomFields.siteSafetyInductionQuestion.questionsList,
					newQue = {},
					newChildNode = {},
					lstCode = [],
					queGuId = "";

				for (var i = 0; i < queAnsDetails.length; i++) {
					newQue = angular.copy(STATIC_OBJ.questionsList);
					queGuId = queAnsDetails[i].Value3;
					if (lstCode.indexOf(queGuId) < 0) {
						newQue.queNo = queAnsDetails[i].Value6;
						newQue.question = queAnsDetails[i].Value5;
						lstCode.push(queGuId);
						newQue.options = [];
						var childObj = commonApi._.filter(queAnsDetails, function (val) {
							return val.Value3 == queGuId;
						});
						for (var j = 0; j < childObj.length; j++) {
							newChildNode = angular.copy(STATIC_OBJ.options);
							newChildNode.answer = childObj[j].Value8;
							newChildNode.correctAnswer = childObj[j].Value9 == "true";
							newChildNode.refqueGuId = queGuId;
							newQue.options.push(newChildNode);
						}
						insertData.push(newQue);
					}
				}
			}
		}

		/**
		 * Get Onload config data
		 */

		function loadConfig() {
			$scope.xhr.platformXhr = true;
			$scope.loadConfig(function () {
				// set default available config data to reset fields purpose.				
				STATIC_OBJ.CONFIG_JSON = angular.copy($scope.data.config);
				$scope.oriMsgCustomFields.DSI_PreviousMsgId = msgIncompleteActionList.length ? msgIncompleteActionList[0].Name.split('|')[1] : $scope.oriMsgCustomFields.DSI_PreviousMsgId;
				if (!isEditOri && !isDraft) {

					// Check box Group Details.			
					$scope.oriMsgCustomFields.siteInductionDetails.personalDetail.checkBoxGroup = angular.copy(STATIC_OBJ.CONFIG_JSON['checkBoxGroup']) || [];

					// personal Details Questionary.
					$scope.oriMsgCustomFields.siteInductionDetails.personalDetail.questionsGroup = angular.copy(STATIC_OBJ.CONFIG_JSON['questionsGroup']) || [];
					// siteSafetyInductionQuestionnnaire Details.			
					$scope.oriMsgCustomFields.siteInductionDetails.siteSafetyInductionQuestionnnaire = angular.copy(STATIC_OBJ.CONFIG_JSON['siteSafetyInductionQuestionnnaire']) || [];
				}
				if ($scope.isOriView) {
					setOriViewBase();
				} else if ($scope.isRespView) {
					setResViewBase();
				}
				$scope.isConfigDataNotAvail = false;
				$scope.xhr.platformXhr = false;
			}, function (xhr) {
				$scope.isConfigDataNotAvail = true;
				$scope.xhr.platformXhr = false;
				Notification.error({
					title: 'Server Error While Fetching Data',
					message: 'Error while fetching config data!!'
				});
				// set Save and Save Draft button to hide if config data is not available.									
				angular.element('#btnSaveForm').hide();
				angular.element('#btnSaveDraft').hide();
			});

		}
		// Show Other FieldsFlag
		function resetNotShowFields() {
			$scope.personalDetail.checkBoxGroup = STATIC_OBJ.CONFIG_JSON.checkBoxGroup;
			$scope.questionnnaire = STATIC_OBJ.CONFIG_JSON.siteSafetyInductionQuestionnnaire;
		}

		$scope.insertNewItems = function (addToList, insertFor) {
			var newObj = {};
			switch (insertFor) {
				case 'induction-criteria':
					newObj = {
						seqNo: '',
						icGuId: '',
						icTitle: '',
						icText: '',
						icValue: false,
						icNote: '',
						isDefaultIc: false
					};
					break;
				case 'questionnnaire':
					newObj = {
						queNo: '',
						queGuId: '',
						question: '',
						answer: '',
						answerCounts: 1,
						isDefaultQue: false
					};
					break;
				case 'Qualification_Trade_ticket':
					newObj = {
						isRecordSelected: false,
						isRecordShow: true,
						isRecordDeleted: false,
						isRecordHeader: false,
						isRatesForExchangeData: false,
						Other_Qualifications: "",
						List1AttachmentDocs: [{
							"attachedDoc": ""
						}]
					};
					break;
				case 'DrivLicenseAttached':
					newObj = {
						isRecordSelected: false,
						isRecordShow: true,
						isRecordDeleted: false,
						isRecordHeader: false,
						isdrivLicenseFile: false,
						"attachedDoc": ""
					};
					break;
			}
			//Add item in items
			$scope.addRepeatingRow(addToList, newObj);
		};

		$scope.removeItem = function (index, list) {
			list.splice(index, 1);
		};

		/**
		 *  will blank employer value if origin value set to'sfp employee'.
		 */
		$scope.setOriginDependentNodes = function (originVal) {
			if (originVal == 'sfp employee') {
				$scope.personalDetail.detailsGroup.employer = '';
				$scope.personalDetail.detailsGroup.phNo = '';
			}
		};

		// to reset attachment
		$scope.resetAttachment = function (queObj, resetFor) {
			queObj[resetFor] = [{
				attachedDoc: ""
			}];
		};

		$scope.setIsShowOtherFieldsFlag = function (queObj) {
			if (queObj.isAllowToAttach == true) {
				if (!queObj.queUserValue || queObj.queUserValue == 'no') {
					$scope.isShowOtherFields = true;
					// set default attacheddoc node if you put no 
					$scope.resetAttachment(queObj, 'queAttachmentDoc');
					resetNotShowFields();
					$scope.update();
				} else {
					$scope.isShowOtherFields = false;
				}
			}

			var queUserSelectValue = $scope.personalDetail.questionsGroup.queGroupList.indexOf(queObj);
			if (queUserSelectValue == 0) {
				$scope.oriMsgCustomFields.queUser_Value1 = queObj.queUserValue;
			} else {
				$scope.oriMsgCustomFields.queUser_Value2 = queObj.queUserValue;
			}

		};

		// set checkBox group2 unchecked and reset value on bases of hide and show.
		$scope.setCheckBoxGroup = function () {
			for (var i = 0; i < $scope.personalDetail.checkBoxGroup.checkBoxList2.length; i++) {
				// reset isRequired value when value for 'List2UserVal' changes.
				$scope.personalDetail.checkBoxGroup.checkBoxList2[i].isRequired = '';
			}
		};

		/**
		 * this function is seprate to remove inline attachment.
		 */
		$scope.deleteAttchmentItem = function (obj, repeatingData) {
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
		};

		$scope.setAttchmentMandatory = function (currObj) {
			if (!currObj.isHolding) {
				currObj.docAssAttachedDocs = [{
					"attachedDoc": ""
				}];
			}
		};

		$scope.setGuidCheckboxGroup = function () {
			getGUIdOnCallBack($scope.oriMsgCustomFields.siteInductionDetails.personalDetail.checkBoxGroup.checkBoxList1.length);
		};
 
		function getGUIdOnCallBack(paramVal) {
			var spParam = {
				dataSourceArray: [{
					"fieldName": "DS_GET_GUID",
					"fieldValue": paramVal
				}],
				successCallback: function (responseList) {
					if (responseList["DS_GET_GUID"]) {
						var guiObj = commonApi._.map(responseList["DS_GET_GUID"], function (val) {
							return val.Value2;
						});

						var guid = $scope.personalDetail.checkBoxGroup.checkBoxList1;
						for (var i = 0; i < guid.length; i++) {
							guid[i].Guid = guiObj[i];

							for (var j = 0; j < guid[i].docAssAttachedDocs.length; j++) {
								guid[i].docAssAttachedDocs[j].refqueGuId = guiObj[i];
							}
						}
					}
				}
			};

			$scope.getCallbackSPdata(spParam);
		}
		// ticked any chckbox in High Risk Licenses then One Attachment is mandatory
		$scope.setCheckboxchecked = function (checkBox) {
			if (checkBox) {
				if (checkBox.isHolding) {
					$scope.oriMsgCustomFields.selectCheckboxesCheck.push(checkBox.Number);
				} else {
					var index = $scope.oriMsgCustomFields.selectCheckboxesCheck.indexOf(checkBox.Number);
					if (index != -1) {
						$scope.oriMsgCustomFields.selectCheckboxesCheck.splice(index, 1);
						//After unticked-checkBox  Remaining Selected checkbox array  and Also Remaining selected checkbox array sort
						var slectboxses = $scope.oriMsgCustomFields.selectCheckboxesCheck;
						slectboxses.sort(function (a, b) {
							return a - b
						});
						$scope.oriMsgCustomFields.selectCheckboxesCheck = slectboxses;
					}
				}
			}
		};

		$scope.onInducteeChange = function (curobj) {
			$scope.oriMsgCustomFields.cvmpChecklist.InducteeUser = curobj.split('|')[1].split('#')[0].trim();
		};

		$scope.inducteeChangeOnSite = function (curobj) {
			$scope.oriMsgCustomFields.cvmpChecklist.InducteeUser = curobj;
		};

		function assignLatestValue() {
			$scope.oriMsgCustomFields.siteInductionDetails.personalDetail = $scope.personalDetail;
			$scope.oriMsgCustomFields.siteInductionDetails.siteSafetyInductionQuestionnnaire = $scope.questionnnaire;
		}
		// set Form status
		function setFormStatusAndFlow() {
			var availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
				currFormStaus = 'open',
				dsAutoDistribute = $scope.isRespView ? '13' : '3',
				formSelectedStaus = $scope.approvalCorrectiveActionsDetails.isPlantApprovedForUseOnSite,
				queUserSelecedStaus = $scope.personalDetail.questionsGroup.queGroupList,
				userTodistribute = '',
				queUserForInfo = '';

			if ($scope.cvmpChecklist.fillUpUserRole == 'originator') {
				if (formSelectedStaus == 'I am Satisfied') {
					currFormStaus = 'approved';
				} else {
					currFormStaus = 'rejected';
				}
			} else if ($scope.cvmpChecklist.fillUpUserRole == 'contractor') {
				if (!$scope.dsDbInserted && $scope.isOriView) {
					currFormStaus = 'raised';
					userTodistribute = $scope.cvmpChecklist.selectedContractorName;

				} else if (queUserSelecedStaus.length) {
					if (queUserSelecedStaus[1].queUserValue == 'no') {
						currFormStaus = 'rejected';
						queUserForInfo = $scope.cvmpChecklist.selectedOriginator;
					} else {
						// change the user role after form filled by contractor.
						$scope.cvmpChecklist.fillUpUserRole = 'originator';
						userTodistribute = $scope.cvmpChecklist.selectedOriginator;
					}
				}
			}

			if (queUserForInfo) {
				// Distribution Will be made from here for 
				commonApi.setDistributionNode({
					actionNodeList: [{
						strUser: queUserForInfo.split('|')[2].trim(),
						strAction: "7#For Information",
					}],
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: $scope.isRespView ? '13' : '3'
				});
			}

			if (userTodistribute) {
				// Distribution Will be made from here for 
				commonApi.setDistributionNode({
					actionNodeList: [{
						strUser: userTodistribute.split('|')[2].trim(),
						strAction: "3#Respond",
						strDate: commonApi.calculateDistDateFromDays({
							baseDate: $scope.serverDate,
							days: 7
						})
					}],
					autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
					asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
					DS_AUTODISTRIBUTE: dsAutoDistribute
				});
			}

			// Form's Staus will be set from below code.

			var strFormStatusId = commonApi.getFormStatusId({
				availFormStatusesList: availFormStatuses,
				strStatus: currFormStaus
			});

			if (strFormStatusId) {
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId;
			}
		}

		// Form staus 
		function setPMTeamDistNodes() {
			var formSelectedStaus = $scope.approvalCorrectiveActionsDetails.isPlantApprovedForUseOnSite;
			if (formSelectedStaus == 'I am Satisfied' || formSelectedStaus == 'I am not Satisfied') {
				var pmTeamUsersList = commonApi.roleUsersListByRoleName('pm team', projAllRolesList),
					pmTeamDistList = [];

				for (var i = 0; i < pmTeamUsersList.length; i++) {
					pmTeamDistList.push({
						strUser: pmTeamUsersList[i],
						strAction: "7#For Information",
						strDate: ""
					});
				}
				if (pmTeamDistList.length) {
					// reseting the auto dist node.
					commonApi.setDistributionNode({
						actionNodeList: pmTeamDistList,
						autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
						asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
						DS_AUTODISTRIBUTE: $scope.isRespView ? '13' : '3'
					});
				}
			}

		}

		function setFormWorkflow() {
			// remove config data not needed.
			delete $scope.data.config;
			// set default obj.
			$scope.userDetails.inducteeName = $scope.personalDetail.detailsGroup.inducteeName;
			$scope.userDetails.inducteeDate = $scope.personalDetail.detailsGroup.inducteeDate;

			// flag to show in thyme leaf view for easy condition making.
			$scope.siteInductionDetails.isShowOtherFields = $scope.isShowOtherFields;
			// Form Title Set from here
			if ($scope.isOriView) {
				$scope.oriMsgCustomFields['ORI_FORMTITLE'] = $scope.isOriginatorUser ? 'PIR::Inductor' : 'PIR::Inductee';
			}

			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			if ($scope.dsDbInserted || (!$scope.dsDbInserted && $scope.isOriginatorUser) || ($scope.isRespView && !$scope.isOriginatorUser)) {
				// set Date to Show on the Print Views.
				$scope.oriMsgCustomFields['formCreatedServerDate'] = $scope.serverDate;
				// set node to identify form on originator's view.
				$scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT = 'true';
				// set all latest binded values.
				assignLatestValue();
				setFormStatusAndFlow();
				setPMTeamDistNodes();
				$scope.xhr.guIdXhr = false;
			} else {
				setFormStatusAndFlow();
				setPMTeamDistNodes();
			}
		}

		if ($scope.isOriView) {
			var strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID,
				strIsDraft = $scope.asiteSystemDataReadOnly["_5_Form_Data"]["DS_ISDRAFT"],
				strPrefix = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMAUTONO_PREFIX;
			if (strIsDraft == "YES" || strFormId == "") {
				$scope.oriMsgCustomFields.siteInductionDetails.personalDetail.detailsGroup.inductionNo = strPrefix + "<<NEXT_AUTONO>>";
			}
		}

		$scope.isDraft = isDraft;
		if ($scope.isOriView || $scope.isRespView) {
			loadConfig();
		} else if ($scope.isOriPrintView || $scope.isRespPrintView) {
			//  execute below code only form is created.
			setallLists();
			if (!$scope.isDraft) {
				$scope.isPendingAction = commonApi.checkPendingActionOnMsg({
					incompleteActionsByMsgList: incompleteActionsByMsgList,
					actionName: 'Respond',
					strUser: workingUserId,
					isCheckMsgId: false,
					strLastMsgId: $scope.oriMsgCustomFields.DSI_PreviousMsgId
				});
			}
			// set originator and user role field.
			$scope.isOriginatorUser = ($scope.cvmpChecklist.fillUpUserRole == 'originator');
			$scope.fillUpUserRole = $scope.cvmpChecklist.fillUpUserRole;
		}

		$scope.isCallForDraft = false;

		function formSubmitCallBack() {
			if (!$scope.isCallForDraft && validateAnswers()) {
				setFormWorkflow();
				return false;
			} else {
				return true;
			}
		}
		//to Hide Export Button in print view
		angular.element(".export-btn").hide();
		$scope.update();
		$window.oriformSubmitCallBack = function () {
			return formSubmitCallBack();
		};

		$window.draftSubmitCallBack = function () {
			$scope.isCallForDraft = true;
			delete $scope.data.config;
			assignLatestValue();
			formSubmitCallBack();
		};
	}
	return FormController;
});

/*
 *   Final Call back fuction before common function get's controll.
 */
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}