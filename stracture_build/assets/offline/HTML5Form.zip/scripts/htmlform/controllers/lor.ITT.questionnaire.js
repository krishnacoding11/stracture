
define(['angular', "mainModule", './base', '../components/inlineattachment'], function (angular, mainModule, baseController) {
	'use strict';
	
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $controller, $window, $timeout) {
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
					$scope.expandTextAreaOnLoad();
				}, 100);
			}
		});
		
		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';
		
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.dsDbInserted = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_DB_INSERT;

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			STATIC_OBJ = {
				Attachement: {
					attachedPhoto: ''
				},
				_11_4_List: {
					"_11_4_Bussiness_Name": "",
					"_11_4_Business_ABN": "",
					"_11_4_Role": "",
					"_11_4_Know_relation": "",
					"_11_4_Contact_Email": "",
					"_11_4_Contact_Phone": ""
				},
				_4_1_List:{
					"_4_1_Project": "",
					"_4_1_Client": "",
					"_4_1_Project_Description": "",
					"_4_1_Scope_Description": "",
					"_4_1_value_contract": "",
					"_4_1_date_of_comp": ""
				},
				_5_1_List:{
					"_5_1_Project": "",
					"_5_1_Client": "",
					"_5_1_Project_Description": "",
					"_5_1_Scope_Description": "",
					"_5_1_value_contract": "",
					"_5_1_date_of_comp": ""
				},
			};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		$scope.addNewItem = function (list, addItemFor) {
			//Add item in items
			$scope.addRepeatingRow(list, angular.copy(STATIC_OBJ[addItemFor]));
		};
		$scope.deleteItem = function (list, index) {
			list.splice(index, 1);
		};	
		
		$scope.update();

		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView){
			}
			return false;
		};

		$window.draftSubmitCallBack = function () {
			return false;
		};
	}
	return FormController;
});

/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}
function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}