define(['angular', './base'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $rootScope, $document, commonApi, $controller, $window, $timeout) {
		var ctrl = this;
		$controller(baseController, { $scope: $scope, $element: $element });
		$scope.currentTab = 1;
		$scope.jsonWeightage = {};
		$scope.clickApprove = false;
		$scope.clickReject = false;
		$scope.finalRatingCount = 0;

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 50);
			}
		});
	
		ctrl.$onInit = function () {
			$scope.data = $scope.getFormData();
			getPrequalWeightages();
		}
		
		var getPrequalWeightages = function(){
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/weightages",
				method: 'GET',
				withCredentials: true,
				data:{},
				headers : {
					 'Content-Type': 'application/json',
					 'ApiKey' : top.marketPlaceApiKey
				},
			}).then(function(response) {
				if(response.data && response.data.myFields){
					if(response.data.myFields.customsection.length > 0){
						for(var i=0;i<response.data.myFields.customsection.length;i++){
							response.data.myFields.section.push(response.data.myFields.customsection[i]);
						}
					}
					$scope.jsonWeightage = response.data.myFields;
					$scope.update();	
				}
				
			}, function() {
			});
		}
		
		$scope.gotoDiv = function (eID) {
			$scope.currentTab == eID ?  $scope.currentTab = ' ' :  $scope.currentTab = eID ;
		};
		$scope.calculateRating = function(section,subsection) {
			var totalWeightageOfSubsection = 0 ;
            for(var i=0;i<section.data.length;i++){
				if(section.data[i].selected && section.data[i].evalutionWeightageValue){
					totalWeightageOfSubsection += (parseInt(section.data[i].value) * parseInt(section.data[i].evalutionWeightageValue));
				}
			}
			var tempWeightage = (totalWeightageOfSubsection/100) * parseInt(section.value);
			section.evalutionWeightageValue = tempWeightage/100;
			finalRatingCountCalculate();
        }
		var finalRatingCountCalculate = function(){
			$scope.finalRatingCount = 0;
			for(var i=0;i<$scope.jsonWeightage.section.length;i++){
				if($scope.jsonWeightage.section[i].evalutionWeightageValue){
					$scope.finalRatingCount = $scope.finalRatingCount + $scope.jsonWeightage.section[i].evalutionWeightageValue;
				}
			}
		}
		var validateForm =function(){
			var section = $scope.jsonWeightage.section,
			    formWeightage = 0,
			    sectionWeightage = 0,
			    valid = true;
			for (var i = 0; i < section.length; i++) {
				sectionWeightage = 0;
				for (var j = 0; j < section[i].data.length; j++) {
					if(section[i].data[j].value){
						if(section[i].data[j].value > 100){
							alert('form contain error pls fix it');
							valid = false;
							break;
						}else{
							sectionWeightage+=section[i].data[j].value;
						}
					}
				}
				if(section[i].value){
					if(section[i].value > 100){
						alert('form contain error pls fix it')
						valid = false;
						break;
					}else{
						formWeightage+=section[i].value;
					}
				}
				if(sectionWeightage > 100){
					alert('form contain error pls fix it')
					valid = false;
					break;
				}
				
			}
			if(formWeightage > 100){
				alert('form contain error pls fix it')
				valid = false;
			}
			return valid;
			
		}
		
		$scope.savePrequalWeightage= function(){
			$scope.clickApprove = true;
			
			var myFields = {
					myFields : $scope.jsonWeightage
			}
			var formJson ={
				formJson : angular.toJson(myFields),
				projectId : $("input[name ='projectId']").val().split('$$')[0],
				formTypeId : top.$("input[name ='formTypeId']").val(),
				msgId : $("input[name ='msgId']").val(),
				formId : $("input[name ='formId']").val(),
				msgTypeId: 2,
				parentMsgId: $("input[name ='parent_msg_id']").val()
			}
			commonApi.ajax({
				url: top.marketPlaceServiceURL + "/marketplace/prequal/saveeval",
				method: 'post',
				withCredentials: true,
				headers : {
					 'Content-Type': 'application/json',
					 'ApiKey' : top.marketPlaceApiKey
				},
				data : angular.toJson(formJson)
			}).then(function(response) {
				if(response.data){
					top.ADODDLE ? top.ADODDLE.notification({'type': 2, 'autoHide': true, 'msg': "Evalution Submitted Successfully."}) : ADODDLE.notification({'type': 2, 'autoHide': true, 'msg': "Evalution Submitted Successfully."});
					top.ADODDLE ? $window.top.postMessage("closeCreateFormIframe:-1",'*') : window.location = top.marketPlaceServiceURL+"?origin=true";
				}
			}, function() {
				$scope.clickApprove = false;
				top.ADODDLE ? top.ADODDLE.notification({'type': 3, 'autoHide': true, 'msg': "Error In Evalution Submit"}) : ADODDLE.notification({'type': 3, 'autoHide': true, 'msg': "Error In Evalution Submit"});
			});
		}
	}

	return FormController;
});