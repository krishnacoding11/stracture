define(["angular", "./base", "../components/item.selection", "../components/number-format", "../components/inlineattachment", "../components/table.util"], function (angular, baseController) {
    function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = document.getElementById("formId") && document.getElementById("formId").value || "";
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });
        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $element.addClass("loaded")
                }, 500)
            }
        });
        $scope.todayDate = "";
        
        $scope.stopAutoSaveDraftTimerFromClientSide();
        $scope.isDataLoaded = true;
        $scope.selectionlist = {
            projDistUsers: [],
            setContractlist: [],
            sectionList: [],
            nopReferenceList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "NOP1 VolkerRail"
                }, {
                    Name: "NOP2 Murphy"
                }, {
                    Name: "NOP3 Siemens"
                }, {
                    Name: "NOP4 SYSTRA"
                }, {
                    Name: "OP Network Rail"
                }, {
                    Name: "Other"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
            employmentCategotyList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "Employed Staff"
                }, {
                    Name: "Consultant"
                }, {
                    Name: "Agency Staff"
                }, {
                    Name: "Various"
                }, {
                    Name: "Specialist"
                }, {
                    Name: "Other"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
            resourcePoolList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "Business Improvement"
                }, {
                    Name: "Commercial"
                }, {
                    Name: "Design"
                }, {
                    Name: "Engineering"
                }, {
                    Name: "Planning, HR, Operations"
                }, {
                    Name: "Programme Services"
                }, {
                    Name: "Project E1"
                }, {
                    Name: "Project E2,3&4"
                }, {
                    Name: "Proposals"
                }, {
                    Name: "SHES"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
            unitList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "Per Hour"
                }, {
                    Name: "Per Week"
                }, {
                    Name: "Per Day"
                }, {
                    Name: "Per Shift"
                }, {
                    Name: "Per Item"
                }, {
                    Name: "Other"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
            unitBasedsList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "Per Hour"
                }, {
                    Name: "Per Week"
                }, {
                    Name: "Per Day"
                }, {
                    Name: "Per Shift"
                }, {
                    Name: "Per Accounting Period"
                }, {
                    Name: "Not Limited"
                }, {
                    Name: "Per Year"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            }),
            rateTypeList: commonApi.getItemSelectionList({
                arrayObject: [{
                    Name: "Actualised Rates as proxy for Reimbursable Costs"
                }, {
                    Name: "Actualised Rate"
                }],
                groupNameKey: "",
                modelKey: "Name",
                displayKey: "Name"
            })
        };
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };
        $scope.myFields = $scope.data.myFields;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.formCustomFields.ORI_MSG_Custom_Fields;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.Form_Data = $scope.data.myFields.Asite_System_Data_Read_Only._5_Form_Data;
        var DS_ALL_ACTIVE_FORM_STATUS = $scope.getValueOfOnLoadData("DS_ALL_ACTIVE_FORM_STATUS");
        var DS_ALLFormSettings = $scope.getValueOfOnLoadData("DS_ASI_Get_All_Default_FormSettingDetails");
        var strAppBuilderCode = DS_ALLFormSettings && DS_ALLFormSettings[0] && DS_ALLFormSettings[0].Value6.split(":")[1].trim();
        var incompleteAction = $scope.getValueOfOnLoadData("DS_INCOMPLETE_ACTIONS");
        var workingUserAllRole = $scope.getValueOfOnLoadData("DS_WORKINGUSER_ALL_ROLES");
        $scope.DS_PROJECTNAME = document.getElementById("DS_PROJECTNAME").value;
        $scope.DS_FORMNAME = document.getElementById("DS_FORMNAME").value;
        var DS_PAA_MPC_NEC_CONTRACT = $scope.getValueOfOnLoadData("DS_PAA_MPC_NEC_CONTRACT");
        var dsWorkingUserId = $scope.getWorkingUserId();
        var strFormId = $scope.Form_Data.DS_FORMID;
        var strIsDraft = $scope.asiteSystemDataReadWrite.ORI_MSG_Fields.DS_ISDRAFT;
        var currentViewName = window.currentViewName;
        $scope.data.myFields.FORM_CUSTOM_FIELDS.DSI_AppbuilderCode = strAppBuilderCode;
        WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
        $scope.oriMsgCustomFields.Org_Name = WorkingUserID[0].Name.substr(WorkingUserID[0].Name.indexOf(',')+1).trim();

        $scope.getServerTime(function (serverDate) {
            $scope.todayDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), "yy-mm-dd");
            $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields.formCreationDate = $scope.todayDateDbFormat;
            if (currentViewName == "ORI_VIEW") {
                setRespondDate();
            }
        });

        var ASC_CONSTANT = {
            ewnWorkspaceUsers: "Workspace - Administrator",
            respond: "Respond",
            forInformation: "For Information",
            oriDistNumb: 3,
            resDistNumb: 13,
            respondNumber: "3#",
            forInfoNumber: "7#",
            reviseResubmit: "Revise Resubmit"
        };
        var STATIC_OBJ_DATA = {
            AttachementsFiles: {
                attachments: ""
            },
            Auto_Distribute_Users: {
                DS_PROJDISTUSERS: "",
                DS_FORMACTIONS: "",
                DS_ACTIONDUEDATE: "",
                DS_DUEDAYS: "",
            },
            RateBuildFiles: {
                attachmentsRateBuild: ""
            }
        };
        var isEditORI = (strFormId != "" && strIsDraft == "NO");
        $scope.tableUtilSettings = {
            AttachementsFiles: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Att_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.AttachementsFiles),
                ADD_NEW_BEFORE_TIP: "Insert before reference document",
                ADD_NEW_AFTER_TIP: "Insert after reference document",
                deleteAllRowTooltip: "Remove all reference document",
                deleteCurrRowMsg: "Remove reference document",
                deleteSelectedMsg: "Remove selected reference document",
                addItemCallBack: function () {},
                deleteItemCallBack: function () {}
            },
            RateBuildFiles: {
                tooltip: "Select to Edit/Remove/Remove all data",
                hasDefaultRecord: false,
                editRowCallBack: "",
                hideControlIcon: {
                    insertBefore: 0,
                    insertAfter: 0,
                    editRow: 0,
                },
                checkboxModelKey: "Rate_isSelected",
                newStaticObject: angular.copy(STATIC_OBJ_DATA.RateBuildFiles),
                ADD_NEW_BEFORE_TIP: "Insert before reference document",
                ADD_NEW_AFTER_TIP: "Insert after reference document",
                deleteAllRowTooltip: "Remove all reference document",
                deleteCurrRowMsg: "Remove reference document",
                deleteSelectedMsg: "Remove selected reference document",
                addItemCallBack: function () {},
                deleteItemCallBack: function () {}
            }
        };
        $scope.addNewItem = function (repeatingData, objKeyName) {
            var newRowObject = angular.copy(STATIC_OBJ_DATA[objKeyName]);
            repeatingData.push(newRowObject);
            $scope.expandTextAreaOnLoad()
        };
        /**
         * This condition is used for display Contract value as link and redirect to particular Contract
         * */
        if (currentViewName == 'ORI_PRINT_VIEW') {
            $scope.hideExportBtn();
            for (var i = 0; i < DS_PAA_MPC_NEC_CONTRACT.length; i++) {
                if (DS_PAA_MPC_NEC_CONTRACT[i] && DS_PAA_MPC_NEC_CONTRACT[i].Value && DS_PAA_MPC_NEC_CONTRACT[i].Value.indexOf($scope.oriMsgCustomFields.CON_AppBuilderId) > -1) {
                    $scope.DS_PAA_MPC_NEC_CONTRACT = DS_PAA_MPC_NEC_CONTRACT[i].URL;
                    break
                }
            }
        } else if ($scope.oriMsgCustomFields.Contract) {
            onContractchange($scope.oriMsgCustomFields.Contract, true);
        }

        $scope.calculateWeek = calculateWeek;
        function calculateWeek() {
            var ProposedCommenc = $scope.oriMsgCustomFields.proposedDateOfCommencement;
            var ProposedLeaving = $scope.oriMsgCustomFields.proposedLeavingDate;
            var diff = Math.abs(new Date(ProposedLeaving) - new Date(ProposedCommenc));
            var diffWeeks = Math.floor((diff / (1000 * 60 * 60 * 24))/7);
            $scope.oriMsgCustomFields.durationOfAppointment = diffWeeks;
        }

        $scope.validateDate = function (callType) {
            var startDate = $scope.oriMsgCustomFields.proposedDateOfCommencement;
            var endDate = $scope.oriMsgCustomFields.proposedLeavingDate;

            if ((Date.parse(startDate) > Date.parse(endDate))) {
                if (callType == "ProposedLeaving") {
                    alert("Proposed Leaving Date date should be greater than Proposed date of commencement date");
                    $scope.oriMsgCustomFields.proposedLeavingDate = "";
                }
                if (callType == "Proposedcommencement") {
                    alert("Proposed date of commencement date should be less than Proposed Leaving Date date date");
                    $scope.oriMsgCustomFields.proposedDateOfCommencement = "";
                }
            }
        }

        $scope.onContractchange = onContractchange;

        function onContractchange(conVal, onloadFlag) {
            if (conVal) {
                var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
                if (projectId == "null") {
                    projectId = window.currProjId
                }
                var formId = document.getElementById("formId") && document.getElementById("formId").value || "";
                $scope.isDataLoaded = false;
                var strParam = conVal.split("|")[0].trim();
                var strAppcode = $scope.asiteSystemDataReadWrite.DS_FORM_APPBUILDERCODE;
                var arrStr = $scope.oriMsgCustomFields.Contract.split("|");
                $scope.oriMsgCustomFields.CON_AppBuilderId = strParam;
                var strAllCon = arrStr[0].trim() + "|" + arrStr[1].trim() + "|" + arrStr[5].trim() + "|" + arrStr[6].trim() + "|" + arrStr[7].trim() + "#" + arrStr[6].trim() + "|" + arrStr[7].trim() + "|" + arrStr[12].trim();
                $scope.oriMsgCustomFields.DS_PAA_MPC_NEC_ALL_CONTRACT = strAllCon;
                $scope.oriMsgCustomFields.Contract_Code = arrStr[6].trim();
                $scope.oriMsgCustomFields.Project_Code = arrStr[4].trim();
                $scope.oriMsgCustomFields.Project_AppBuilderId = arrStr[1].trim();
                $scope.formCustomFields.Client_Logo = arrStr[3].trim();
                $scope.formCustomFields.Contractor_Logo = arrStr[2].trim();
                $scope.oriMsgCustomFields.SectionCBSCode = arrStr[12].trim();
                $scope.oriMsgCustomFields.SectionDescription = arrStr[7].trim();
                $scope.oriMsgCustomFields.SectionNo = arrStr[6].trim();

                var form = {
                    projectId: projectId,
                    formId: formId,
                    fields: "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS, DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS, DS_PAA_Contract_Activity_Group_dtls,DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                    callbackParamVO: {
                        customFieldVOList: [{
                            fieldName: "DS_PAA_MPC_NEC_CONTRACT_CONTRACTORS",
                            fieldValue: strParam
                        }, {
                            fieldName: "DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS",
                            fieldValue: strParam
                        }, {
                            fieldName: "DS_PAA_Contract_Activity_Group_dtls",
                            fieldValue: strParam
                        }, {
                            fieldName: "DS_PAA_MPC_NEC_KEY_CONTRACT_DATES",
                            fieldValue: strParam
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function (response) {
                    $scope.isDataLoaded = true;
                    if (response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS) {
                        if (!onloadFlag) {
                            $scope.selectionlist.projDistUsers = []
                        }
                        UserList(response);

                    }
                    if (response.data) {
                        if (!onloadFlag) {
                            $scope.selectionlist.sectionList = []
                        }
                        var DS_PAA_Contract_Activity_Group_dtls = angular.fromJson(response.data.DS_PAA_Contract_Activity_Group_dtls).Items.Item;
                        setSectionList(DS_PAA_Contract_Activity_Group_dtls)
                        if (strFormId == null || strFormId == '') {
                            var allowCreate = checkContractDate(response, arrStr[arrStr.length - 2]);
                            var chkPermission = allowCreate.toLowerCase() == "yes" ? strIsCreateUser(response) : "Yes";
                            if ((chkPermission.toLowerCase() == "no" && allowCreate.toLowerCase() == "no") || chkPermission.toLowerCase() == "no") {
                                setCreatePermission();
                            }
                        }
                        setRespondDate();
                    }
                });
                if (DS_PAA_MPC_NEC_CONTRACT.length) {
                    var notesObj = commonApi._.filter(DS_PAA_MPC_NEC_CONTRACT, function (val) {
                        return val.Value.split("|")[0].trim() == arrStr[0].trim()
                    });
                    if (notesObj.length) {
                        var strValue = notesObj[0].Name,
                            strNotes = strValue.split("|")[3].trim();
                        if (strNotes) {
                            $scope.asiteSystemDataReadWrite.Dist_Guidance_Notes = strNotes
                        }
                    }
                }
            }
        }

        function setSectionList(resList) {
            if (resList) {
                var SECTION_ARRAY = [];
                var sortSec = [];
                for (var i = 0; i < resList.length; i++) {
                    var lvl68Custom = (resList[i].Value8 || resList[i].Value7);
                    SECTION_ARRAY.push({
                        sectionName: resList[i].Value15.trim() + " | " + lvl68Custom,
                        lvl68Custom: lvl68Custom
                    })
                }
                sortSec = commonApi._.uniq(SECTION_ARRAY, "sectionName");
                sortSec = commonApi._.sortBy(SECTION_ARRAY, "sectionName");
                $scope.selectionlist.sectionList = commonApi.getItemSelectionList({
                    arrayObject: sortSec,
                    groupNameKey: "",
                    modelKey: "sectionName",
                    displayKey: "sectionName"
                })
            }
        }

        function UserList(response) {
            if (response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS) {
                var ownerUserList = commonApi._.filter(JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item, function (obj) {
                    return obj.Value && obj.Value.toLowerCase().indexOf("alliance_leadership_team") > -1
                });
                $scope.selectionlist.projDistUsers = commonApi.getItemSelectionList({
                    arrayObject: commonApi._.uniq(ownerUserList, function (obj) {
                        return obj.Name
                    }),
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                })
            }
        }

        $scope.currentStage = $scope.formCustomFields.DSI_Current_Stage;
        $scope.update();

        $window.TTT_AssociateDocsAndForms = function () {
            return $scope.TTT_WorkFlow()
        };
        $scope.TTT_WorkFlow = function () {
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
            $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "0";
            $scope.Form_Data.DS_CLOSE_DUE_DATE = $scope.oriMsgCustomFields.RespondDate;
            if ($scope.submitFlag) {
                return false
            }
            var userTodistribute = "",
                currFormStaus = "";
            var status = "",
                sentTo = "";
            if ($scope.oriMsgCustomFields.isApprovalRequired == "Yes") {
                if (currentViewName == "ORI_VIEW" && $scope.formCustomFields.DSI_Current_Stage == 1) {
                    userTodistribute = $scope.oriMsgCustomFields.RequestTo;
                    if (userTodistribute) {
                        var userId = userTodistribute.split("|")[2].split("#")[0].trim();
                        var strAction = "2#";
                        var strDate = $scope.oriMsgCustomFields.RespondDate;
                        setUserAction(userId, strAction, strDate, 7)
                    }
                    $scope.formCustomFields.DSI_Next_Stage = 2
                }
                if ($scope.oriMsgCustomFields.Res_Status == "Approved" || $scope.oriMsgCustomFields.Res_Status == "Not-Approved" || $scope.oriMsgCustomFields.Res_Status == "Rate Type Approved") {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    var userToforInfoaction = $scope.oriMsgCustomFields.Originator_Id;
                    if (userToforInfoaction) {
                        var userId = userToforInfoaction;
                        var strAction = "7#";
                        var strDate = $scope.oriMsgCustomFields.RespondDate;
                        setUserAction(userId, strAction, strDate, 7)
                    }
                    currFormStaus = $scope.oriMsgCustomFields.Res_Status
                }
                if ($scope.oriMsgCustomFields.Res_Status == "Further Information Required" && $scope.formCustomFields.DSI_Current_Stage == 2) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    var userToforInfoaction = $scope.oriMsgCustomFields.Originator_Id;
                    if (userToforInfoaction) {
                        var userId = userToforInfoaction;
                        var strAction = "2#";
                        var strDate = $scope.oriMsgCustomFields.RespondDate;
                        setUserAction(userId, strAction, strDate, 7)
                    }
                    $scope.formCustomFields.DSI_Next_Stage = 1;
                    currFormStaus = $scope.oriMsgCustomFields.Res_Status
                }
                if ($scope.oriMsgCustomFields.Res_Status == "Further Information Required" && $scope.formCustomFields.DSI_Current_Stage == 1) {
                    $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
                    userTodistribute = $scope.oriMsgCustomFields.RequestTo;
                    if (userTodistribute) {
                        var userId = userTodistribute.split("|")[2].split("#")[0].trim();
                        var strAction = "2#";
                        var strDate = $scope.oriMsgCustomFields.RespondDate;
                        setUserAction(userId, strAction, strDate, 7)
                    }
                    $scope.formCustomFields.DSI_Next_Stage = 2;
                    currFormStaus = ASC_CONSTANT.reviseResubmit
                }
            } else {
                currFormStaus = "Approved";
            }
            if (currFormStaus) {
                setFormStatus(currFormStaus)
            }
        };

        function setFormStatus(currFormStaus) {
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList: DS_ALL_ACTIVE_FORM_STATUS,
                strStatus: currFormStaus
            });
            if (strFormStatusId) {
                $scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_ALL_FORMSTATUS = strFormStatusId
            }
        }
        $scope.setUserAction = function () {
            var userId = $scope.oriMsgCustomFields.RequestTo;
            userId = userId && userId.split(" | ")[2];
            userId = userId && userId.split("#")[0];
            var strAction = ASC_CONSTANT.respondNumber + ASC_CONSTANT.respond;
            var strDueDays = $scope.oriMsgCustomFields.Reply_Days || 2;
            var structDistribution = angular.copy(STATIC_OBJ_DATA.Auto_Distribute_Users);
            structDistribution.DS_PROJDISTUSERS = userId;
            structDistribution.DS_FORMACTIONS = strAction;
            structDistribution.DS_ACTIONDUEDATE = $scope.oriMsgCustomFields.RespondDate;
            structDistribution.DS_DUEDAYS = strDueDays;
            $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users.push(structDistribution);
            setUserAction(userId, strAction, $scope.oriMsgCustomFields.RespondDate, strDueDays)
        };

        function setUserAction(userId, action, distDate) {
            commonApi.setDistributionNode({
                actionNodeList: [{
                    strUser: userId,
                    strAction: action,
                    strDate: distDate
                }],
                autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
                asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
                DS_AUTODISTRIBUTE: "3",
            })
        }
        initFormsData();

        function initFormsData() {

            if (currentViewName == "ORI_VIEW") {
                var conDataList = $scope.getValueOfOnLoadData("DS_PAA_MPC_NEC_ALL_EMP_CONTRACT");
                angular.forEach(conDataList, function (item) {
                    var index = item.Name.lastIndexOf('|');
                    if (index > -1) {
                        item.Name = item.Name.substring(0, item.Name.lastIndexOf('|'));
                    }
                });
                $scope.selectionlist.setContractlist = commonApi.getItemSelectionList({
                    arrayObject: conDataList,
                    groupNameKey: "",
                    modelKey: "Value",
                    displayKey: "Name"
                });
                if (strFormId == "" || strIsDraft == "YES") {
                    $scope.oriMsgCustomFields.Originator_Id = dsWorkingUserId
                }
                $scope.Msg = "You are not authorised to create/edit the form currently. For more information, contact your Administrator.";
                $scope.strCanReply = "";
                if (strIsDraft == "" || strIsDraft == "NO") {
                    if ($scope.formCustomFields.DSI_Next_Stage == "") {
                        $scope.formCustomFields.DSI_Next_Stage = 1
                    }
                    if ($scope.formCustomFields.DSI_Current_Stage == "") {
                        $scope.formCustomFields.DSI_Current_Stage = 1
                    } else {
                        $scope.formCustomFields.DSI_Current_Stage = $scope.formCustomFields.DSI_Next_Stage
                    }
                }
                if ($scope.formCustomFields.DSI_Current_Stage > 1) {
                    var actionData = commonApi._.filter(incompleteAction, function (val) {
                        return val.Name.indexOf("Assign Status") > -1 && val.Value.indexOf(dsWorkingUserId) != -1
                    });
                    if (actionData && actionData.length) {
                        $scope.strCanReply = "yes"
                    }
                }
                if (workingUserAllRole && $scope.formCustomFields.DSI_Current_Stage == 1) {
                    if (workingUserAllRole[0].Value.toLowerCase().indexOf("workspace") != -1) {
                        $scope.strCanReply = "yes"
                    }
                }
                strIsUserDraftOnly();
            }
            $scope.DS_FORMNAME = document.getElementById("DS_FORMNAME").value;
            $scope.DS_PROJECTNAME = document.getElementById("DS_PROJECTNAME").value
        }

        function strIsUserDraftOnly() {
            if (workingUserAllRole[0].Value.indexOf("Commercial Team") == -1) {
                var $sendBtn = $window.document.getElementById('btnSaveForm');
                $sendBtn && ($sendBtn.style.display = 'none');
                $scope.strCanCreate = true;
                var strMsg = "0";
                strMsg = "You are only allowed to create Drafts for this form. Please click on Save Draft button to save the form as Draft or click on Cancel button to exit.";
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_SEND_MSG = strMsg;
                alert(strMsg);
            }
            else
            {
                $scope.strCanCreate = false;
            }
        }

        /**
         * strIsCreateUser used for check current user us member of Alliance Contract management team or not
         * @param response: is used for check user data on contract callback
         * */
        function strIsCreateUser(response) {
            var checkUser = JSON.parse(response.data.DS_PAA_MPC_ALL_CONTRACT_TEAM_MEMBERS).Items.Item;
            if (checkUser.length) {
                var strValue = "",
                    strRole = "",
                    strTmpEmpId = "";
                for (var i = 0; i < checkUser.length; i++) {
                    strValue = checkUser[i].Value.split('|');
                    strRole = strValue[1].trim();
                    //if (strRole.toLowerCase() == "create only") {
                    strTmpEmpId = strValue[2].split('#')[0].trim();
                    if (strTmpEmpId == dsWorkingUserId)
                        return "No";
                    //}
                }
            }
            return "Yes";
        }

        /**
         * setRespondDate is used to auto populate Respond Date 
         * * @param response: is used for fill this dropdown after contract callback
         * */        
        function setRespondDate(){
            var todayDateDbFormat = $scope.todayDateDbFormat;
            
			if(todayDateDbFormat){
                var spParam = {
                    dataSourceArray: [{
                        fieldName: "DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY",
                        fieldValue: todayDateDbFormat + '|' + '' + '|' + 7
                    }],
                    successCallback: function (response) {
                        $scope.isDataLoaded = true;
                        if(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY.length){
                            $scope.oriMsgCustomFields.RespondDate = $scope.formatDate(response.DS_FETCH_HOLIIDAY_CALENDAR_SUMMARY[0].Value2, "yy-mm-dd", "dd/mm/yy");
                        }
                    }
                };
                $scope.dataSourceName = commonApi._.map(spParam.dataSourceArray, function (obj) {
                    return obj.fieldName
                });
                $scope.getCallbackSPdata(spParam)
			}
		}

        /**
         * setCreatePermission used for check current user us member of Alliance Contract management team or not
         * */ 
        function setCreatePermission() {
            $scope.oriMsgCustomFields.isApprovalRequired = "No";
        }

        /**
         * checkContractDate used for check today date is  is greater than Contract date+lock period or not
         *  @param {string} contractDate: is get selected contract created date.
         *  * @param response: is used for check date contract callback
         * */
        function checkContractDate(response, contractDate) {
            var dateResponse = angular.fromJson(response.data.DS_PAA_MPC_NEC_KEY_CONTRACT_DATES).Items.Item;
            if (dateResponse && dateResponse.length) {
                var selectedData = commonApi._.filter(dateResponse, function (obj) {
                    return obj.Value3.toLowerCase() == "resource approval lock period";
                })[0];
                if (selectedData) {
                    $scope.replyExpiryDate =  parseInt(selectedData.Value4);
                    if (contractDate != null && contractDate != undefined && contractDate != '') {
                        var replyExpiry = new Date(new Date(contractDate).getFullYear(), new Date(contractDate).getMonth(), new Date(contractDate).getDate() + $scope.replyExpiryDate);
                        if (new Date() > replyExpiry) {
                            return "No";
                        }
                    }
                }
            }
            return "Yes";
        }
    }
    return FormController
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof TTT_AssociateDocsAndForms !== "undefined") {
        return TTT_AssociateDocsAndForms()
    }
};