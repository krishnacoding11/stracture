/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', '../components/signature'], function(angular, baseController) {
    'use strict';

    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $controller, $window, $timeout) {

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function() {
                $timeout(function() {
                    $scope.loaded = true;
                    $element.addClass('loaded');
                    $scope.expandTextAreaOnLoad();
                }, 50);
            }
        });

        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.stopAutoSaveDraftTimerFromClientSide();

        $scope.getServerTime(function(serverDate) {
            $scope.serverDate = serverDate;
            $scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
            $scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd/M/yy');
            $scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
        });

        $scope.Logo = '/images/htmlform/LOR/lor-logo.jpg';
        $scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';

        $window.addEventListener('scroll', function() {
            if ($window.scrollY || document.documentElement.scrollTop) {
                $element.addClass('scroll-top');
                return;
            }
            $element.removeClass('scroll-top');
        });

        /** Initialize db fields */
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
        $scope.strFormId = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMID;
        $scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
        $scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
        $scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
        $scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
        $scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
        $scope.oriClausesDetails = $scope.oriMsgCustomFields["Clauses"];
        $scope.oriAppendicesDetails = $scope.oriMsgCustomFields["Appendices"];
        $scope.oriCommentDetails = $scope.oriMsgCustomFields["CommentDetails"];
        $scope.oriMsgCustomFields.DS_Logo = $scope.Logo;

        $scope.DS_PROJUSERS = $scope.getValueOfOnLoadData('DS_PROJUSERS');
        $scope.dsWorkingUserId = $scope.getWorkingUserId();
        $scope.dsWorkingUser = document.getElementById('DS_WORKINGUSER');
        $scope.dsWorkingUser = $scope.dsWorkingUser ? $scope.dsWorkingUser.value : '';

        if (currentViewName == "ORI_VIEW") {
            if ($scope.strFormId == "") {
                getSelectedClausesDataOnCallBack();
                getSelectedAppendicesDataOnCallBack();
                $scope.oriCommentDetails[0].Name = $scope.dsWorkingUser;
            }
        }

        if (currentViewName == "RES_VIEW") {
            if ($scope.strFormId != "") {
                $scope.oriCommentDetails.push({
                    Comments: "",
                    OldNewFlag: "",
                    Name: $scope.dsWorkingUser,
                    Date: ""
                });
            }
        }

        $scope.scrollToTop = function() {
            window.scrollTo(0, 0);
        };

        $window.subcontractAgreementFinalCallBack = function() {
            var commentsTableLength = $scope.oriCommentDetails.length;
            for (var i = 0; i < commentsTableLength; i++) {
                $scope.oriMsgCustomFields["CommentDetails"][i].OldNewFlag = "Old";
            }
            $scope.oriMsgCustomFields["CommentDetails"][commentsTableLength - 1].Date = $scope.todayDateUKFormat;
            $scope.oriMsgCustomFields["Clauses"] = $scope.oriClausesDetails;
            $scope.oriMsgCustomFields["Appendices"] = $scope.oriAppendicesDetails;
            return false;
        };

        $window.draftSubmitCallBack = function() {
            $scope.oriMsgCustomFields["Clauses"] = $scope.oriClausesDetails;
            $scope.oriMsgCustomFields["Appendices"] = $scope.oriAppendicesDetails;
            return false;
        }

        function getSelectedClausesDataOnCallBack() {
            var fieldValue = $scope.oriMsgCustomFields.SelectedClauseDetails;
            if (fieldValue) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_LOR_CHT_SUBCONTRACT_AGREEMENT_DETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_LOR_CHT_SUBCONTRACT_AGREEMENT_DETAILS",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function(response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_LOR_CHT_SUBCONTRACT_AGREEMENT_DETAILS']);
                        strGetDetails = strGetDetails.Items.Item;
                        var tmpObj = {};
                        var tmpArray = [];
                        $scope.oriClausesDetails = [];
                        if (strGetDetails.length && strGetDetails[0].Value2) {
                            for (var i = 0; strGetDetails.length; i++) {
                                tmpObj = strGetDetails[i];
                                if (tmpArray.indexOf(tmpObj.Value7) < 0) {
                                    $scope.oriClausesDetails.push({
                                        ClauseNo: tmpObj.Value2,
                                        ProposedClauseDesc: tmpObj.Value3,
                                        OriginalClauseDesc: tmpObj.Value4,
                                        GUID: tmpObj.Value7,
                                        LinkedClause: []
                                    })
                                    if (tmpObj.Value5) {
                                        var selectedObj = $scope.oriClausesDetails.filter(function(obj) {
                                            return obj.GUID == tmpObj.Value7
                                        });
                                        selectedObj[0].LinkedClause.push({
                                            ClauseNo: tmpObj.Value5,
                                            ClauseDesc: tmpObj.Value6,
                                            Ref_GUID: tmpObj.Value8
                                        })
                                    }
                                } else {
                                    var selectedObj = $scope.oriClausesDetails.filter(function(obj) {
                                        return obj.GUID == tmpObj.Value7
                                    });
                                    selectedObj[0].LinkedClause.push({
                                        ClauseNo: tmpObj.Value5,
                                        ClauseDesc: tmpObj.Value6,
                                        Ref_GUID: tmpObj.Value8
                                    })
                                }
                                tmpArray.push(tmpObj.Value7);
                            }

                            $scope.oriMsgCustomFields["Clauses"] = $scope.oriClausesDetails;
                        }    
                    }
                }, function(error) {
                    window.console && window.console.log(error);
                });
            }
        }

        function getSelectedAppendicesDataOnCallBack() {
            var fieldValue = $scope.oriMsgCustomFields.SelectedAppendicesDetails;
            if (fieldValue) {
                var form = {
                    "projectId": $scope.projectId,
                    "formId": $scope.formId,
                    "fields": "DS_LOR_CHT_SUBCONTRACT_AGREEMENT_APPENDICES_DETAILS",
                    "callbackParamVO": {
                        "customFieldVOList": [{
                            "fieldName": "DS_LOR_CHT_SUBCONTRACT_AGREEMENT_APPENDICES_DETAILS",
                            "fieldValue": fieldValue
                        }]
                    }
                };
                $scope.getCallbackData(form).then(function(response) {
                    if (response.data) {
                        var strGetDetails = JSON.parse(response.data['DS_LOR_CHT_SUBCONTRACT_AGREEMENT_APPENDICES_DETAILS']);
                        strGetDetails = strGetDetails.Items.Item;
                        var tmpObj = {};
                        var tmpArray = [];
                        $scope.oriAppendicesDetails = [];
                        if (strGetDetails.length && strGetDetails[0].Value2) {
                            for (var i = 0; strGetDetails.length; i++) {
                                tmpObj = strGetDetails[i];
                                if (tmpArray.indexOf(tmpObj.Value2) < 0) {
                                    $scope.oriAppendicesDetails.push({
                                        AppendixName: tmpObj.Value2,
                                        Comments: tmpObj.Value3
                                    })
                                }
                                tmpArray.push(tmpObj.Value2);
                            }

                            $scope.oriMsgCustomFields["Appendices"] = $scope.oriAppendicesDetails;
                        }    
                    }
                }, function(error) {
                    window.console && window.console.log(error);
                });
            }
        }

        $scope.update();
    }

    return FormController;
});


function customHTMLMethodBeforeCreate_ORI() {
    if (typeof subcontractAgreementFinalCallBack !== "undefined") {
        return subcontractAgreementFinalCallBack();
    }
}

function customHTMLMethodBeforeSaveDraft() {
    if (typeof draftSubmitCallBack !== "undefined") {
        return draftSubmitCallBack();
    }
}