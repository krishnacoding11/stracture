/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', "mainModule", './base', '../components/item.selection', '../components/table.util'], function (angular, mainModule, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout, Notification) {

		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});

		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});

		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';


		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.dSFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isOriPrintView = (window.currentViewName == 'ORI_PRINT_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.inspectionRecord = $scope.oriMsgCustomFields.inspectionRecord;
		$scope.contractNumbers = ['63420 (Block 16)','63421 (Block 05)','63422 (Block 10)'];

		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			CONSTANTS_OBJ = {
				IMAGE_ASITE_DEFAULT_STR: '/images/asiteWhite60x200.png',
				IMAGE_DEFAULT_STR: 'images/htmlform/interserve/interserve-logo.png',
				ROOM_NO_LIST_KEY: 'location-list',
				ROOM_NO_LIST_LABEL: 'Location List',
				DIST_USER_LIST_KEY: 'dist-user-list',
				QS_REF_BY_LOCATION_KEY: 'DS_INS_RTS_QSRefList',
				SUB_CONTRACTOR_LIST_KEY: 'sub-contractor-list',
				SUB_CONTRACTOR_LIST_LABEL: 'Sub Contractors list',
			},
			STATIC_OBJ = {
				locationDetails: {
					recordGuid: '',
					isRecordSelected: false,
					isRecordShow: true,
					isRecordDeleted: false,
					isRecordHeader: false,
					isLoading: false,
					inspecttionElement: {
						location: "",
						locationList: [],
						qsRefDetailsList : [{
							location: "",
							qsRef : "",
							boqItemActivityList : [{
								location: "",
								qsRef : "",
								code: "",
								val: "",
								boqActivity : ""
							}]
						}]
					}
				},
				qsRefDetailItem: {
					location: "",
					qsRef : "",
					boqItemActivityList : [{
						location: "",
						qsRef : "",
						code: "",
						val: "",
						boqActivity : "",
					}]
				},
				userPresent: {
					userName: ""
				},
				WitnessUser: {
					witnessedBy: "",
					witnessedDate: ""
				}
			},
			cacheLocationDetailData = {},
			FORMID = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'] || '',
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');

		

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});

		$scope.oriMsgCustomFields.DS_Logo = CONSTANTS_OBJ.IMAGE_DEFAULT_STR;
		$scope.oriMsgCustomFields.isDefaultLogo = true;

		$scope.tableUtilSettings = {
			locationDetails: {
				tooltip: "select to remove/remove all/Insert new Location Record data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRecordSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore: 0,
					deleteAllRow: 0
				},
				newStaticObject: angular.copy(STATIC_OBJ.locationDetails),
				ADD_NEW_BEFORE_TIP: "Insert before Location Record Details",
				ADD_NEW_AFTER_TIP: "Insert after Location Record Details",
				deleteAllRowTooltip: "Remove all Location Record Details",
				deleteCurrRowMsg: "Remove Location Record Details",
				deleteSelectedMsg: "Remove selected Location Record Details",
				addItemCallBack: function () {
					refreshLocationList();
				},
				deleteItemCallBack: function (index_selected) {
					refreshLocationList();
				}
			}
		};

		$scope.onLocationChanged = function (location, curRow) {
			refreshLocationList();

			curRow.inspecttionElement.qsRefDetailsList.splice(0);
			curRow.inspecttionElement.qsRefDetailsList.push(angular.copy(STATIC_OBJ.qsRefDetailItem));

			getQsRefDetails(location, curRow);
		};

		$scope.onTypeOfTestChange = function(selectedItem){
			$scope.inspectionRecord.testTypeLabel =  selectedItem.displayValue || "";
		};

		$scope.addNewItem = function (list, addItemFor) {
			list.push(angular.copy(STATIC_OBJ[addItemFor]));

			if(addItemFor === 'locationDetails') {
				refreshLocationList();
				return;
			}
		};

		$scope.checkStartEndTime = function(newTime, timeIput){
			var sTime =  $scope.inspectionRecord.timeStarted;
			var eTime =  $scope.inspectionRecord.timeFinished;

			if(timeIput == "startTime"){
				sTime =  newTime;
			}else{
				eTime =  newTime;
			}

			if(sTime && eTime){
				if(get24HrDate(sTime) >=  get24HrDate(eTime)){
					if(timeIput == "startTime"){
						$timeout(function () {
							alert("Invalid time specified !!! \n\n Start Time should be less than Finished  Time.");
							$scope.inspectionRecord.timeStarted = "";
						}, 100);
					}else{
						$timeout(function () {
							alert("Invalid time specified !!! \n\n Finished Time should be greater than Start Time.");
							$scope.inspectionRecord.timeFinished = "";
						}, 100);
					}
				}
			}
		};
		
		if($scope.isOriView && FORMID == '') {
			var workingUserObj = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0];
			var workingUser = workingUserObj.Value.split('#')[0];
			$scope.inspectionRecord.submittedBy = workingUser.replace('|','#').trim();
			$scope.inspectionRecord.submittedByName = workingUserObj.Name;
			// contract number list
			if(!$scope.inspectionRecord.contractNo) {
				// default set 5.
				var blockNo = (configAttributesList.filter(function(attrObj) {
					return ((attrObj.Value3.toLowerCase() == 'block number' || attrObj.Value3.toLowerCase() == 'blocknumber')) && attrObj.Value11 == 'Active';
				})[0] || {Value7 : '05'}).Value7;

				switch(blockNo) {
					case '05':
						$scope.contractNumberList = [{
							displayName : '63421 (Block 05)',
							value : '63421 (Block 05)'
						}];
						$scope.inspectionRecord.contractNo = '63421 (Block 05)';
						break;
					case '10':
						$scope.contractNumberList = [{
							displayName : '63422 (Block 10)',
							value : '63422 (Block 10)'
						}];
						$scope.inspectionRecord.contractNo = '63422 (Block 10)';
						break;
					case '16':
						$scope.contractNumberList = [{
							displayName : '63420 (Block 16)',
							value : '63420 (Block 16)'
						}];
						$scope.inspectionRecord.contractNo = '63420 (Block 16)';
						break;
				}
			}
		}

		if($scope.isRespView){
			var testTypeObj = getTestTypeObj();
			$scope.testTypeObjList = commonApi.getItemSelectionList({
                arrayObject: testTypeObj,
                groupNameKey: "",
                modelKey: "Value7",
                displayKey: "Value8"
            });
		}

		if ($scope.isOriView) {
			$scope.inspectionRecord.submittedDate = $scope.formatDate(new Date(), 'dd/mm/yy');
			setOriViewBase();
		}

		$scope.update();

		function getQsRefDetails(location, currentRow) {
			var locationCode = location.split('#')[0].trim();
			if(cacheLocationDetailData[locationCode]) {
				refreshLocationDetails(location, locationCode, currentRow);
				return;
			}

			cacheLocationDetailData[locationCode] = [];
			currentRow.isLoading = true;
			var form = {
				projectId: $scope.projectId,
				formId: $scope.formId,
				fields: CONSTANTS_OBJ.QS_REF_BY_LOCATION_KEY,
				callbackParamVO: {
					customFieldVOList: [{
						fieldName: CONSTANTS_OBJ.QS_REF_BY_LOCATION_KEY,
						fieldValue: location
					}]
				}
			};

			$scope.getCallbackData(form).then(function (response) {
				currentRow.isLoading = false;
				if (response.data) {
					cacheLocationDetailData[locationCode] = angular.fromJson(response.data[CONSTANTS_OBJ.QS_REF_BY_LOCATION_KEY]).Items.Item;
					refreshLocationDetails(location, locationCode, currentRow);
				}
				$scope.update();
			}, function (error) {
				currentRow.isLoading = false;
				$scope.update();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error',
					message: errorMsg
				});
			});
		};

		function refreshLocationList() {
			var selectedLocations = [];
			var list = $scope.inspectionRecord.locationDetails;
			list.forEach(function(record) {
				if(record.inspecttionElement.location) {
					selectedLocations.push(record.inspecttionElement.location);
				}
			});

			list.forEach(function(record) {
				var excludeLocations = angular.copy(selectedLocations);
				var ind = excludeLocations.indexOf(record.inspecttionElement.location);
				if(ind != -1) {
					excludeLocations.splice(ind, 1);
				}
				record.inspecttionElement.locationList = structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, $scope.getValueOfOnLoadData('DS_INS_RTS_RoomNoList'), excludeLocations);
			});
		};

		function refreshLocationDetails(location, locationCode, curRow) {
			if(!cacheLocationDetailData[locationCode]) {
				return;
			}

			curRow.inspecttionElement.qsRefDetailsList.splice(0);

			var oData = {};

			(cacheLocationDetailData[locationCode] || []).forEach(function(qsRefmodel) {
				if(!oData[qsRefmodel.Value1]) {
					oData[qsRefmodel.Value1] = {
						location: location,
						qsRef: qsRefmodel.Value1,
						boqItemActivityList: []
					};
				}
				oData[qsRefmodel.Value1].boqItemActivityList.push({
					location: location,
					qsRef: qsRefmodel.Value1,
					code: qsRefmodel.Value2,
					val: ((qsRefmodel.Value4 || '').split('|')[1] || '').trim(),
					boqActivity : qsRefmodel.Value4
				});
			});

			for(var key in oData) {
				curRow.inspecttionElement.qsRefDetailsList.push(oData[key]);
			}

			$timeout(function () {
				$scope.expandTextAreaOnLoad();
			}, 10);
		};

		function get24HrDate(strTime) {
			var tmpTime = strTime.split(':');
			if(strTime.toLowerCase().indexOf('pm') > -1){
				if(tmpTime[0] < 12){
					tmpTime[0] = parseInt(tmpTime[0]) + 12;
					tmpTime[1] = tmpTime[1].split(' ')[0];
				}else{
					tmpTime[1] = tmpTime[1].split(' ')[0];
					
				}
			}else{
				if(tmpTime[0] >= 12){
					tmpTime[0] = 0;
				}
                tmpTime[1] = tmpTime[1].split(' ')[0];
			}
			tmpTime = tmpTime.join('.');
			return parseFloat(tmpTime);
		}
		
		function structureItemList(setFor, availList, excludeModels) {
			var tempList = [],
				optlabel = '';

			if(!excludeModels) {
				excludeModels = [];
			}

			switch (setFor) {
				case CONSTANTS_OBJ.ROOM_NO_LIST_KEY:
					angular.forEach(availList, function (item) {
						var val = item.Value1+'#'+item.Value2;
						if(excludeModels.indexOf(val) == -1) {
							tempList.push({
								displayValue: item.Value2,                         
								modelValue:  val
							});	
						}
					});
					optlabel = CONSTANTS_OBJ.ROOM_NO_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.DIST_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value.split('|')[2].trim()
						});
					});
					optlabel = CONSTANTS_OBJ.DIST_USER_LIST_LABEL;
					break;
				case CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value.trim()
						});
					});
					optlabel = CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_LABEL;
					break;
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};
		
		function getTestTypeObj() {
			var customAttr = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
			$scope.DS_ASI_Configurable_AttributesArr = customAttr || [];
			var testTypeArr = commonApi._.where($scope.DS_ASI_Configurable_AttributesArr, {
				Value3: "Test Type",
				Value11: "Active"
			});
			return testTypeArr;
		};

		function pojectListWithoutSelfOrg() {
			return $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS').filter(function (org) {
				return org.Value.toLowerCase().indexOf('interserve') == -1 ;
			});
		};

		function setOriViewBase() {
			refreshLocationList();

			$scope.userTODitrubute = structureItemList(CONSTANTS_OBJ.DIST_USER_LIST_KEY, projAllRolesList.filter(function (roleUserObj) {
				return roleUserObj.Value.split('|')[0].toLowerCase().trim().indexOf('project manager') != -1;
			}));

			$scope.projectOrg = structureItemList(CONSTANTS_OBJ.SUB_CONTRACTOR_LIST_KEY, pojectListWithoutSelfOrg());
		};

		function removeItemSelectionData() {
			$scope.inspectionRecord.locationDetails.forEach(function(record) {
				delete record.inspecttionElement.locationList;
			});
		};

		function setFormStatus(currFormStaus) {
			// Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {             
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		};

		function acceptOrRejectForm() {
			$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			setFormStatus($scope.inspectionRecord.testResult);
			
		};

		function setDistributionNodeForPM() {
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
			
			commonApi.setDistributionNode({
				actionNodeList : [{
					strUser : $scope.inspectionRecord.distUserDetails.distUser,
					strAction : "3#Respond",
					strDate : commonApi.calculateDistDateFromDays({
						baseDate: $scope.serverDate,
						days : 3
					})                    
				}],
				autoDistributeUsers : $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,				
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE :  3
			});

			setFormStatus('open');
		};


		
		$window.oriformSubmitCallBack = function () {
			if($scope.isOriView) {
				removeItemSelectionData();
				setDistributionNodeForPM();
				// set Form Title.
				$scope.oriMsgCustomFields.ORI_FORMTITLE = 'Record of testing for '+ $scope.inspectionRecord.locationDetails.map(function(conreObj){
					return (conreObj.inspecttionElement.location || '').split('#')[1].trim();
				}).join(',');
				return false;
			}

			if($scope.isRespView){
				if(!$scope.inspectionRecord.testResult){
					return true;
				}

				acceptOrRejectForm();
				return false;
			}
		};

		$window.customHTMLMethodAfterValidationError = function(){
			if($scope.isRespView && widowObj){
				$window.parent.postMessage("scrollToTop", '*');
			 }
        };
	}

	return FormController;
});



/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}