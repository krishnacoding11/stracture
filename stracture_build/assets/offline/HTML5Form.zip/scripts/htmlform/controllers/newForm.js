define(['angular', './base'], function (angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
    function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
        var ctrl = this;
        // restrict autosave Draft and hide Save Draft button.
        var $saveDraftBtn = $window.document.getElementById('btnSaveDraft');
        $saveDraftBtn && ($saveDraftBtn.style.display = 'none');
        var projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if (projectId == "null")
            projectId = window.currProjId;
        var formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;        
        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        // auto save draft
        if ($window.stopAutoSaveTimer) {
            $window.stopAutoSaveTimer();
        } else if ($window.oAutoSaveTimer) {
            $window.clearTimeout($window.oAutoSaveTimer);
            $window.oAutoSaveTimer = null;
        }

        $scope.isFullLoaded({
            onComplete: function () {
                $timeout(function () {
                    $scope.loaded = true;
                    $scope.expandTextAreaOnLoad();
                    $element.addClass('loaded');
                }, 500);
            }
        });
        var tempData = $scope.getFormData();
        $scope.data = {
            myFields: tempData
        };

        $scope.asiteSystemDataReadOnly = $scope.data.myFields.Asite_System_Data_Read_Only;
        $scope.asiteSystemDataReadWrite = $scope.data.myFields.Asite_System_Data_Read_Write;
        $scope.formCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS;
        $scope.oriMsgCustomFields = $scope.data.myFields.FORM_CUSTOM_FIELDS.ORI_MSG_Custom_Fields;
        $scope.callLogDetails = $scope.oriMsgCustomFields.callLogDetails;

        var isOriView = (currentViewName == "ORI_VIEW"),
        isOriPrintView = (currentViewName == "ORI_PRINT_VIEW");

        if (isOriView) {            
            $scope.getServerTime(function (serverDate) {
                $scope.strTime = new Date(serverDate).getTime();
                $scope.todayDateDbFormat = $scope.formatDate(new Date($scope.strTime), 'yy-mm-dd');
                $scope.asiteSystemDataReadOnly._5_Form_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
            });
        } else if (isOriPrintView) {

        }

        $scope.update();

        $window.submitTheNewForm = function () {
            return false;
        };
    }
    return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
    if (typeof submitTheNewForm !== "undefined") {
        return submitTheNewForm();
    }
}