/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
define(['angular', './base', "mainModule", '../components/item.selection', '../components/table.util', '../components/inlineattachment'], function (angular, baseController) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, $document, commonApi, $controller, $window, $timeout, Notification) {
		
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$scope.expandTextAreaOnLoad();
					$element.addClass('loaded');
				}, 100);
			}
		});

		// restrict autosave Draft and hide Save Draft button.
		$scope.stopAutoSaveDraftTimerFromClientSide();

		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = angular.element('#formId') && angular.element('#formId').val() || '';

		var tempData = $scope.getFormData();
		$scope.data = {
			myFields: tempData
		};

		$scope.getServerTime(function (serverDate) {
			$scope.serverDate = serverDate;
			$scope.todayDateDbFormat = $scope.formatDate(new Date(serverDate), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(serverDate), 'dd-M-yy');
			$scope.userFormatedDate = $scope.formatDate(new Date(serverDate), userDateFormat);
		});
		
		$scope.myFields = $scope.data['myFields'];
		$scope.oriMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['ORI_MSG_Custom_Fields'];
		$scope.resMsgCustomFields = $scope.myFields.FORM_CUSTOM_FIELDS['RES_MSG_Custom_Fields'];
		$scope.asiteSystemDataReadOnly = $scope.myFields['Asite_System_Data_Read_Only'];
		$scope.asiteSystemDataReadWrite = $scope.myFields['Asite_System_Data_Read_Write'];
		$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = "";
		$scope.isOriView = (window.currentViewName == 'ORI_VIEW');
		$scope.isRespView = (window.currentViewName == 'RES_VIEW');
		$scope.contractNumbers = ['63420 (Block 16)','63421 (Block 05)','63422 (Block 10)'];
		$scope.NoticeForCloseDetail = $scope.oriMsgCustomFields.NoticeForCloseDetail;

		$scope.oriMsgCustomFields.DS_Logo = 'images/htmlform/interserve/interserve-logo.png';
		$scope.oriMsgCustomFields.isDefaultLogo = true;
		
		var dateFormatMap = { "en_GB": "dd-M-yy", "fr_FR": "d M yy", "es_ES": "dd-M-yy", "ru_RU": "dd.mm.yy", "en_AU": "dd/mm/yy", "en_CA": "d-M-yy", "en_US": "M d, yy", "zh_CN": "yy-m-d", "de_DE": "dd.mm.yy", "ga_IE": "d M yy", "en_ZA": "dd M yy", "ja_JP": "yy/mm/dd", "ar_SA": "dd/mm/yy", "en_IE": "dd-M-yy" },
			userDateFormat = dateFormatMap[$window.USP.languageId] || "dd-M-yy",
			CONSTANTS_OBJ = {
				ROOM_NO_LIST_KEY: 'room-no-list',
				ROOM_NO_LABEL : 'Location List',
				DIST_USER_LIST_KEY: 'dist-user-list',
				QS_REF_BY_ROOM_NO_KEY: 'DS_INS_NPTC_RoomNoWithQSRef'
			},
			STATIC_OBJ = {
				NoticeForCloseDetail: {
					nfcGuid : "",
                    isNfcShow : true,
                    isNfcDisable : false,
					isRecordSelected: false,
					isLoading: false,
                    spaceItem : {
						roomNo : "",
						roomNoList: [],
						nfcQsRefList: [{
							roomNo: "",
							qsRef: "",
							description: ""
						}]
                    }
				},
				qsRefItem: {
					roomNo: "",
					qsRef: "",
					description: ""
				},
				locationPhoto : {
					attachedPhoto : ''
				}
			},
			roomList = [],
			locationDetailResps = {},
			availFormStatuses = $scope.getValueOfOnLoadData('DS_ALL_FORMSTATUS'),
			projAllRolesList = $scope.getValueOfOnLoadData('DS_PROJUSERS_ALL_ROLES'),
			configAttributesList = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		
		$scope.tableUtilSettings = {
			noticeDetails: {
				tooltip: "Select to remove/remove all/Insert new Notice Record data",
				hasDefaultRecord: true,
				checkboxModelKey: "isRecordSelected",
				hideControlIcon: {
					editRow: 0,
					insertBefore: 0,
					deleteAllRow: 0
				},
				newStaticObject: angular.copy(STATIC_OBJ.NoticeForCloseDetail),
				ADD_NEW_BEFORE_TIP: "Insert before Notice Record Details",
				ADD_NEW_AFTER_TIP: "Insert after Notice Record Details",
				deleteAllRowTooltip: "Remove all Notice Record Details",
				deleteCurrRowMsg: "Remove Notice Record Details",
				deleteSelectedMsg: "Remove selected Notice Record Details",
				addItemCallBack: function () {
					refreshRoomNoList();
				},
				deleteItemCallBack: function () {
					refreshRoomNoList();
				}
			}
		};

		$scope.addNewItem = function (list, addItemFor) {
			list.push(angular.copy(STATIC_OBJ[addItemFor]));

			if(addItemFor === 'NoticeForCloseDetail') {
				refreshRoomNoList();
			}
		};

		$scope.deleteItem = function (list, index) {
			list.splice(index, 1);
		};

		$scope.onLocationChanged = function(location, curRow) {
			refreshRoomNoList();

			curRow.spaceItem.nfcQsRefList.splice(0);
			curRow.spaceItem.nfcQsRefList.push(angular.copy(STATIC_OBJ.qsRefItem));

			getLocationDetails(location, curRow);
		};

		if ($scope.isOriView) {
			if(!$scope.oriMsgCustomFields.CreationDate) {
				$scope.oriMsgCustomFields.Originator = $scope.getWorkingUserId() + ' # ' + document.getElementById('DS_WORKINGUSER').value;
				$scope.oriMsgCustomFields.CreationDate = $scope.todayDateDbFormat;
				$scope.asiteSystemDataReadOnly._5_Form_Data.Status_Data.DS_CLOSE_DUE_DATE = $scope.todayDateDbFormat;
			}

			// contract number list
			if(!$scope.NoticeForCloseDetail.contractNo) {
				// default set 5.
				var blockNo = (configAttributesList.filter(function(attrObj) {
					return ((attrObj.Value3.toLowerCase() == 'block number' || attrObj.Value3.toLowerCase() == 'blocknumber')) && attrObj.Value11 == 'Active';
				})[0] || {Value7 : '05'}).Value7;

				switch(blockNo) {
					case '05':
						$scope.contractNumberList = [{
							displayName : '63421 (Block 05)',
							value : '63421 (Block 05)'
						}];
						$scope.NoticeForCloseDetail.contractNo = '63421 (Block 05)';
						break;
					case '10':
						$scope.contractNumberList = [{
							displayName : '63422 (Block 10)',
							value : '63422 (Block 10)'
						}];
						$scope.NoticeForCloseDetail.contractNo = '63422 (Block 10)';
						break;
					case '16':
						$scope.contractNumberList = [{
							displayName : '63420 (Block 16)',
							value : '63420 (Block 16)'
						}];
						$scope.NoticeForCloseDetail.contractNo = '63420 (Block 16)';
						break;
				}
			}

			$scope.userTODitrubute = structureItemList(CONSTANTS_OBJ.DIST_USER_LIST_KEY, projAllRolesList.filter(function (roleUserObj) {
				var userExist = false;
				var aroles = roleUserObj.Value.split('|')[0].toLowerCase().trim().split(',');
				aroles.forEach(function(role) {
					if(!userExist && role.toLowerCase().trim().indexOf('sub contractor')!= -1) {
						userExist = true;
					}
				});
				return userExist;
			}));

			roomList = $scope.getValueOfOnLoadData('DS_INS_NPTC_RoomNoList');
			refreshRoomNoList();
		}

		if($scope.isRespView) {
			if(!$scope.resMsgCustomFields.PermitBy) {
				$scope.resMsgCustomFields.PermitBy = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID')[0].Name;
			}

			if(!$scope.resMsgCustomFields.PermitOn) {
				$scope.resMsgCustomFields.PermitOn = $scope.formatDate(new Date(), 'dd/mm/yy');
			}
		}

		$scope.update();



		function getLocationDetails(location, curRow) {
			if(!location || !curRow) {
				return;
			}

			var locationCode = location.split('#')[0].trim();

			if(locationDetailResps[locationCode]) {
				refreshQsRefList(locationCode, curRow);
				return;
			}

			curRow.isLoading = true;
			locationDetailResps[locationCode] = [];

			var form = {
				projectId: $scope.projectId,
				formId: $scope.formId,
				fields: CONSTANTS_OBJ.QS_REF_BY_ROOM_NO_KEY,
				callbackParamVO: {
					customFieldVOList: [{
						fieldName: CONSTANTS_OBJ.QS_REF_BY_ROOM_NO_KEY,
						fieldValue: location
					}]
				}
			};

			$scope.getCallbackData(form).then(function (response) {					
				curRow.isLoading = false;
				if (response.data) {
					locationDetailResps[locationCode] = angular.fromJson(response.data[CONSTANTS_OBJ.QS_REF_BY_ROOM_NO_KEY]).Items.Item;
					refreshQsRefList(locationCode, curRow);
				}
				$scope.update();
			}, function (error) {
				curRow.isLoading = false;
				$scope.update();
				var errorMsg = 'Server Error occurred' + error;
				Notification.error({
					title: 'Server Error', 
					message: errorMsg 
				});				
			});
		};

		function setNestedLoopData() {
			$scope.NoticeForCloseDetail.nfcList.forEach(function(record) {
				record.spaceItem.nfcQsRefList.forEach(function(QsRefItem) {
					QsRefItem.roomNo = record.spaceItem.roomNo;
				});
			});
		};

		function removeItemSelectionData() {
			$scope.NoticeForCloseDetail.nfcList.forEach(function(record) {
				delete record.spaceItem.roomNoList;
			});
		};
		
		function setFormWorkflow() {
			if($scope.isOriView) {
				if ($scope.NoticeForCloseDetail.distUserDetails) {
					removeItemSelectionData();
					setNestedLoopData();
					removeEmptyAttachments();
					setDistributionNode();
					setFormStatus('open');
					// set Form Title.
					$scope.oriMsgCustomFields.ORI_FORMTITLE = "Notice / Permit to Close space for " + $scope.NoticeForCloseDetail.nfcList.map(function(conreObj) {
						return (conreObj.spaceItem.roomNo || '').split('#')[1].trim()
					}).join(",");
					return false;
				}
				alert("Please select one of the distribution user.");
				return true;
			}

			if($scope.isRespView) {
				$scope.asiteSystemDataReadWrite.DS_AUTODISTRIBUTE = 0;
				$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];
				setFormStatus('accepted');
				return false;
			}

			return false;
		};

		function setDistributionNode() {
			$scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users = [];

			var distUser = ($scope.isRespView) ? $scope.oriMsgCustomFields.Originator : $scope.NoticeForCloseDetail.distUserDetails;
			commonApi.setDistributionNode({
				actionNodeList: [{
					strUser: distUser,
					strAction: "3#Respond",
					strDate : commonApi.calculateDistDateFromDays({
						baseDate: $scope.serverDate,
						days : 3
					})   
				}],
				autoDistributeUsers: $scope.asiteSystemDataReadWrite.Auto_Distribute_Group.Auto_Distribute_Users,
				asiteSystemDataReadWrite: $scope.asiteSystemDataReadWrite,
				DS_AUTODISTRIBUTE: ($scope.isRespView) ? 13 : 3
			});
		};

		function setFormStatus(currFormStaus) {
			// Form's Staus will be set from below code.
            var strFormStatusId = commonApi.getFormStatusId({
                availFormStatusesList : availFormStatuses,
                strStatus : currFormStaus
			});
			
			if (strFormStatusId) {             
				$scope.asiteSystemDataReadOnly['_5_Form_Data']['Status_Data']['DS_ALL_FORMSTATUS'] = strFormStatusId;
			}
		};

		function structureItemList(setFor, availList, excludedModels) {
			var tempList = [],
				optlabel = '';

			if(!excludedModels) {
				excludedModels = [];
			}

			switch (setFor) {
				case CONSTANTS_OBJ.ROOM_NO_LIST_KEY:
					angular.forEach(availList, function(item){
						var val = item.Value1+'#'+item.Value2;
						if(excludedModels.indexOf(val) == -1) {
							tempList.push({
								displayValue: item.Value2,                         
								modelValue:  val
							});	
						}
					});
					optlabel = CONSTANTS_OBJ.ROOM_NO_LABEL;
					break;	

				case CONSTANTS_OBJ.DIST_USER_LIST_KEY:
					angular.forEach(availList, function (item) {
						tempList.push({
							displayValue: item.Name,
							modelValue: item.Value.split('|')[2].trim()
						});
					});
					optlabel = CONSTANTS_OBJ.DIST_USER_LIST_LABEL;
					break;
			}
			return [{
				optlabel: optlabel,
				options: tempList
			}];
		};

		function refreshRoomNoList() {
			var selectedRoomNo = [];
			var list = $scope.NoticeForCloseDetail.nfcList;
			list.forEach(function(record) {
				if(record.spaceItem.roomNo) {
					selectedRoomNo.push(record.spaceItem.roomNo);
				}
			});

			list.forEach(function(record) {
				var excludeRoomNo = angular.copy(selectedRoomNo);
				var ind = excludeRoomNo.indexOf(record.spaceItem.roomNo);
				if(ind != -1) {
					excludeRoomNo.splice(ind, 1);
				}
				record.spaceItem.roomNoList = structureItemList(CONSTANTS_OBJ.ROOM_NO_LIST_KEY, roomList, excludeRoomNo);
			});
		};

		function refreshQsRefList(location, curRow) {
			if(!locationDetailResps[location] || !locationDetailResps[location].length) {
				return;
			}

			curRow.spaceItem.nfcQsRefList.splice(0);

			locationDetailResps[location].forEach(function(model) {
				curRow.spaceItem.nfcQsRefList.push({
					roomNo: model.Value2.replace(' | ', '#'),
					qsRef: model.Value1,
					description: ""
					
				});
			});
		};

		function removeEmptyAttachments() {
			$scope.resMsgCustomFields.photoes.forEach(function(attachment, index) {
				if(!attachment.attachedPhoto) {
					$scope.deleteItem($scope.resMsgCustomFields.photoes, index);
				}
			});
		}



		$window.oriformSubmitCallBack = function () {
			return setFormWorkflow();
		};

		$window.draftSubmitCallBack = function () {
			removeItemSelectionData();
			removeEmptyAttachments();
			setNestedLoopData();
			return false;
		};
	}
	
	return FormController;
});



/*
*   Final Call back fuction before common function get's controll.
*/
function customHTMLMethodBeforeCreate_ORI() {
	if (typeof oriformSubmitCallBack !== "undefined") {
		return oriformSubmitCallBack();
	}
}

function customHTMLMethodBeforeSaveDraft() {
	if (typeof draftSubmitCallBack !== "undefined") {
		return draftSubmitCallBack();
	}
}