/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */
window.updateFormXsnTitle = function () {};
define(['angular', './base'], function(angular, baseController) {
    'use strict';
    /**
     * @constructor
     * @alias module:Form-Controller/FormController
     */
     function FormController($scope, $element, $attrs, $document, $filter, commonApi, $controller, $window, $timeout, $q) {
        var ctrl = this;
        
        $scope.projectId = window.hashprojectId || window.hashedprojectid || window.viewerProjectId || window.currProjId;
        if($scope.projectId == "null")
        	$scope.projectId = window.currProjId;
        
        $scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
        var currentViewName = window.currentViewName;

        $controller(baseController, {
            $scope: $scope,
            $element: $element
        });

        $scope.isFullLoaded({
            onComplete: function () {
             $timeout(function() {
                $scope.loaded = true;
                $element.addClass('loaded');                
              }, 500);
            }
        });
        
        var tempData = $scope.getFormData();
        $scope.data = {
			myFields: tempData
		};
        
        $scope.showDetails = true;
        $scope.requests = {};
        $scope.mfrRecords = $scope.getValueOfOnLoadData("DS_PPMT_GET_MFR_DETAILS_PAGING") || [];
        
        $scope.asiteSystemDataReadOnly = $scope.data["myFields"]["Asite_System_Data_Read_Only"];
    	$scope.asiteSystemDataReadWrite = $scope.data["myFields"]["Asite_System_Data_Read_Write"];
    	$scope.formCustomFields = $scope.data["myFields"]["FORM_CUSTOM_FIELDS"];
    	$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
    	$scope.resMsgCustomFields = $scope.formCustomFields["RES_MSG_Custom_Fields"];
    	$scope.projectSearch = $scope.formCustomFields["Project_Search"];
    	
    	var setPagingData = function()
        {
            var iPageSlice = parseInt($scope.formCustomFields['Page_Slice']);
            var iTotalCount = parseInt($scope.formCustomFields['Total_Pages']) || 0;

            $scope.formCustomFields['Tabbed_Paging']['Pages'] = [];

            if (iTotalCount > iPageSlice)
            {
                var iStart = 1;
                while (iStart < iTotalCount)
                {
                    var iEnd = iStart + (iPageSlice - 1);

                    if (iEnd > iTotalCount)
                    {
                        iEnd = iTotalCount;
                    }
                    var tmpPageRange = iStart + "-" + iEnd;
                    
                    $scope.formCustomFields['Tabbed_Paging']['Pages'].push({ Page_Range : tmpPageRange });

                    iStart += iPageSlice;
                }
            }
            else
            {
                var strPageRange = "";
                if (iTotalCount == 0)
                {
                    strPageRange = "0-0";
                }
                else
                {
                    strPageRange = "1-" + iTotalCount;
                }
                
                $scope.formCustomFields['Tabbed_Paging']['Pages'].push({ Page_Range : strPageRange });
            }
        };
        
        var fetchData = function(pg) {
        	if(!pg) {
        		$scope.formCustomFields['isFiltered'] = "0";
        	}
        	
        	$scope.formCustomFields["Page_Sel_Filtered"] = (pg || $scope.formCustomFields['Select_PG']) + " | " + 
	   													   ($scope.projectSearch.SNProject_No || "").trim() + " | " + 
	   													   ($scope.projectSearch.SIBIS_Code || "").trim() + " | " + 
	   													   ($scope.projectSearch.SProject_Name || "").trim();
        	
        	var form = {
				"projectId" : $scope.projectId,
				"formId" : $scope.formId,
				"fields" : "DS_PPMT_GET_MFR_DETAILS_PAGING",
				"callbackParamVO" : {
					"customFieldVOList" : [{
						"fieldName" : "DS_PPMT_GET_MFR_DETAILS_PAGING",	
						"fieldValue" : $scope.formCustomFields["Page_Sel_Filtered"]
					}]
				}
			};

            $scope.requests['paging'] = true;
			$scope.getCallbackData(form).then(function(response) {
				$scope.requests['paging'] = false;
				if (response.data) {
					var xpnifundgr = JSON.parse(response.data['DS_PPMT_GET_MFR_DETAILS_PAGING']);
					xpnifundgr = xpnifundgr['Items']["Item"];
					if (!xpnifundgr.length || xpnifundgr[0].Name == "")
		            {
		                ADODDLE.alert({title : "" , msg : "No Records Found!" });
		                return;
		            }
		            
		            $scope.mfrRecords = xpnifundgr;
		            $scope.formCustomFields['Total_Pages'] = xpnifundgr[0].Value35 || 0;
		            
		            all_monthlyfunding_map();
		            
		            setPagingData();
		            
		            var strFiltered = $scope.formCustomFields['isFiltered']
		            if (strFiltered == "1")
		            {
		            	var strFirstRecord = $scope.formCustomFields['Tabbed_Paging']['Pages'][0]['Page_Range'];
		            	$scope.formCustomFields['Select_PG'] = strFirstRecord;
		            }
		            
		            $scope.formCustomFields['isFiltered'] = "0";
				}
			});
        };
        
        var all_monthlyfunding_map = function()
        {
            var xpnifundgrp = $scope.mfrRecords || [];
            var iPrjCtr = 0;
            var objFunding = [];
            $scope.oriMsgCustomFields['All_Funding_Group']['All_Project_Fundings'] = [];

            if (xpnifundgrp.length)
            {
                var hstProject = {};
                var hstFundingNode = {};
                for (var i = 0; i < xpnifundgrp.length; i++)
                {
                	var xpnLoopNode = xpnifundgrp[i];
                	
                	$scope.formCustomFields['Total_Pages'] = xpnLoopNode.Value35 || 0;
                	
                    var strcheckprojno = xpnLoopNode.Value1;
                    var strcheckF_src_Type = xpnLoopNode.Value7;
                    var strcheckFtype = xpnLoopNode.Value8;
                    var strcheckFgroup = xpnLoopNode.Value9;

                    if (!hstProject[strcheckprojno])
                    {
                        iPrjCtr++;
                        var obj = {
                        	ProjectNodeXml : [],
                        	FundingChildXml : []
                        };
                        
                        obj.ProjectNodeXml.push(XMLPROJIBISDetails(xpnLoopNode, iPrjCtr));
                        obj.FundingChildXml.push(childXMLPROJIBISDetails(xpnLoopNode, iPrjCtr + ""));
                        
                        objFunding.push(obj);
                        
                        hstProject[strcheckprojno] = iPrjCtr;
                        hstFundingNode[strcheckprojno + strcheckF_src_Type + strcheckFtype + strcheckFgroup] = strcheckprojno;
                    }
                    else
                    {
                        if (!hstFundingNode[strcheckprojno + strcheckF_src_Type + strcheckFtype + strcheckFgroup]) 
                        {
                            var iId = hstProject[strcheckprojno];
                            objFunding[iId - 1].FundingChildXml.push(childXMLPROJIBISDetails(xpnLoopNode, iPrjCtr + ""));
                            hstFundingNode[strcheckprojno + strcheckF_src_Type + strcheckFtype + strcheckFgroup] = iPrjCtr;
                        }
                    }
                }
            }
            
            var allProjectFundings = [];
            if(objFunding.length) {
            	for (var iCounter = 1; iCounter <= iPrjCtr; iCounter++)
            	{
            		var projectNode = objFunding[iCounter - 1].ProjectNodeXml;
            		projectNode[0]['Funding_Information']['Funding_Records'] = objFunding[iCounter - 1].FundingChildXml;
            		allProjectFundings = commonApi._.union(allProjectFundings, projectNode);
            	}
            }
            
            if (allProjectFundings.length)
            {
            	$scope.oriMsgCustomFields['All_Funding_Group']['All_Project_Fundings'] =  allProjectFundings;
            	$scope.oriMsgCustomFields['All_Funding_Group']['Prj_Ctr_Ref'] = iPrjCtr + "";
            }
        };
        
        var XMLPROJIBISDetails = function(xpnNode, iProjectCtr)
        {
            return {
            	Project_No : xpnNode.Value1,
            	Project_Name : xpnNode.Value2,
            	IBIS_Code : xpnNode.Value3,
            	National_Project_No : xpnNode.Value4,
            	Project_Manager_Id : xpnNode.Value5,
            	Project_Record_Owner_Id : xpnNode.Value6,
            	Project_Manager : xpnNode.Value29,
            	Project_Record_Owner : xpnNode.Value30,
            	Funding_ctr_ref : 0,
            	Prj_Ctr : iProjectCtr + "",
            	Area : xpnNode.Value32,
            	Project_Team : xpnNode.Value33,
            	Delivery_Owner : xpnNode.Value34,
            	Funding_Information: { Funding_Records : [] }
            };
        };
        
        var childXMLPROJIBISDetails = function(xpnNode, strPrj_FCtr)
        {
            return {
        		Ref_Project_No : xpnNode.Value1,
        		Funding_Source_Type : xpnNode.Value7,
        		Funding_Type : xpnNode.Value8,
        		Funding_Group : xpnNode.Value9,
        		Funding_Status : xpnNode.Value10,
        		Funding_Details : xpnNode.Value11,
        		InKind_Details : xpnNode.Value12,
        		Prev_Year_Funding_Value : xpnNode.Value13,
        		Y1_Q1_Funding_Value : xpnNode.Value14,
        		Y1_Funding_Value : xpnNode.Value15,
        		Y2_Funding_Value : xpnNode.Value16,
        		Y3_Funding_Value : xpnNode.Value17,
        		Y4_Funding_Value : xpnNode.Value18,
        		Y5_Funding_Value : xpnNode.Value19,
        		Y6_Funding_Value : xpnNode.Value20,
        		Y7_Funding_Value : xpnNode.Value21,
        		Y8_Funding_Value : xpnNode.Value22,
        		Y9_Funding_Value : xpnNode.Value23,
        		Y10_Funding_Value : xpnNode.Value24,
        		Y11_Y15_Funding_Value : xpnNode.Value25,
        		Y16_Y20_Funding_Value : xpnNode.Value26,
        		Cash_InKind : xpnNode.Value27,
        		Funding_Line_Total : xpnNode.Value28,
        		Funding_ctr : strPrj_FCtr,
        		Funding_Rule : xpnNode.Value36,
        		Funding_RuleID : xpnNode.Value37
            };
        };
        
        $scope.sum = function(key, target, type) {
        	var sum = 0;
        	
        	if(target) 			// total by type
        	{
        		var array = target.Funding_Information.Funding_Records;
        		for(var i = 0; i < array.length; i++) {
        			var record = array[i];
        			if(record.Cash_InKind.indexOf(type) > -1) {
        				sum += (parseFloat(record[key]) || 0);
        			}
        		}
        	} 
        	else 				// grand total of all projects
        	{				
        		var projFundings = $scope.oriMsgCustomFields.All_Funding_Group.All_Project_Fundings;
        		for(var j = 0; j < projFundings.length; j++) {
        			var array = projFundings[j].Funding_Information.Funding_Records;
	        		for(var i = 0; i < array.length; i++) {
        				sum += (parseFloat(array[i][key]) || 0);
	        		}
        		}
        	}
        	
        	return sum;
        };
        
        $scope.On_Enter = function(e) {
        	if(e.keyCode == 13 || e.which == 13) {
        		$scope.On_Submit();
        	}
        };
        
        $scope.On_Submit = function()
        {
        	$scope.formCustomFields['isFiltered'] = "1";
        	fetchData("1-" + $scope.formCustomFields['Page_Slice']);
        };

        $scope.On_Select_PG_Changed = function()
        {
        	fetchData();
        };
        
        var On_FormEvents_Loading = function() {
        	var strisDraft = $scope.asiteSystemDataReadWrite['ORI_MSG_Fields']['DS_ISDRAFT'];
            var strFormId = $scope.asiteSystemDataReadOnly['_5_Form_Data']['DS_FORMID'];
            
            if (!strFormId || strisDraft == "YES") {
                return;
            }
            
            var strgetDataValidation = $scope.getValueOfOnLoadData("DS_PPMT_MFR_DATA_VALIDATION") || [];
            strgetDataValidation = strgetDataValidation[0] || {};
            strgetDataValidation = strgetDataValidation.Value || "";
            
            var strachkDataValidation = strgetDataValidation.split('#')[0].split('|');
            for (var ichk_ctr = 0; ichk_ctr < strachkDataValidation.length; ichk_ctr++)
            {
                if (strachkDataValidation[ichk_ctr].trim() == "0")
                {
                	$scope.formCustomFields['Invalid_MFR_DataFlag'] =  "0";
                    break;
                }
            }

            var strImported = $scope.oriMsgCustomFields['Import_Flag'];
            var strWorkingUser = $scope.asiteSystemDataReadOnly['_1_User_Data']['DS_WORKINGUSER'];
            if (strWorkingUser.length)
            {
                setPagingData();
                var strisFiltered = $scope.formCustomFields['isFiltered'];
                if (strisFiltered == "1")
                {
                    var strFirstRecord = $scope.formCustomFields['Tabbed_Paging']['Pages'][0]['Page_Range'];
                    if (strFirstRecord)
                    {
                    	$scope.formCustomFields['Select_PG'] = strFirstRecord;
                    }
                }
                $scope.formCustomFields['isFiltered'] = "0";
            }
        };
        
        var On_FormEvents_ViewSwitched = function() {
        	if (currentViewName == "ORI_VIEW") {
        		return;
            }
        	
            all_monthlyfunding_map();
            
            setPagingData();
            var strFirstRecord = $scope.formCustomFields['Tabbed_Paging']['Pages'][0]['Page_Range'];
            if (strFirstRecord)
            {
            	$scope.formCustomFields['Select_PG'] = strFirstRecord; 
            }
        };
        
		On_FormEvents_Loading();
        On_FormEvents_ViewSwitched();
        
        // show form in maximize pane only for IDP form
        angular.element('#viewFormMainSection').find('.restored').click();

        $scope.update();
        
        var msgContainer = document.getElementById('messageDetails');
        if(msgContainer) {
        	$element.find('.fundingRecordSection').width(window.innerWidth - 27);
        }
	}
     
    return FormController;
});