/**
 * Form Controller module.
 * This module will return Form Controller.
 * @module Form-Controller
 */

define(['angular', './base'], function (angular, baseController) {
	'use strict';
	/**
	 * @constructor
	 * @alias module:Form-Controller/FormController
	 */
	function FormController($scope, $element, commonApi, $controller, $window, $timeout) {
		$scope.projectId = window.hashprojectId || window.viewerProjectId || window.projectId || window.currProjId || window.hashedprojectid;
		$scope.formId = document.getElementById('formId') && document.getElementById('formId').value || '';
		var currentViewName = window.currentViewName;
		$controller(baseController, {
			$scope: $scope,
			$element: $element
		});
		$scope.isFullLoaded({
			onComplete: function () {
				$timeout(function () {
					$scope.loaded = true;
					$element.addClass('loaded');
				}, 500);
			}
		});
		var tempData = $scope.getFormData();
		if (!tempData.myFields) {
			$scope.data = {
				myFields: tempData
			};
		} else {
			$scope.data = tempData;
		}

		$scope.myFields = $scope.data['myFields'];
		$scope.formCustomFields = $scope.data['myFields']["FORM_CUSTOM_FIELDS"];
		$scope.oriMsgCustomFields = $scope.formCustomFields["ORI_MSG_Custom_Fields"];
		$scope.asiteSystemDataReadWrite = $scope.data['myFields']["Asite_System_Data_Read_Write"];
		$scope.asiteSystemDataReadOnly = $scope.data['myFields']['Asite_System_Data_Read_Only'];
		$scope.Form_Data = $scope.data['myFields']['Asite_System_Data_Read_Only']['_5_Form_Data'];
		$scope.DS_ASI_Configurable_Attributes = $scope.getValueOfOnLoadData('DS_ASI_Configurable_Attributes');
		$scope.DS_ASI_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GetITBs');
		var DS_PROJORGANISATIONS_ID = $scope.getValueOfOnLoadData('DS_PROJORGANISATIONS_ID');
		$scope.DS_PROJDISTUSERS = $scope.getValueOfOnLoadData('DS_PROJDISTUSERS');
		var WorkingUserID = $scope.getValueOfOnLoadData('DS_WORKINGUSER_ID');
		var bidCloseDetails = $scope.getValueOfOnLoadData('DS_ASI_STD_ADD_BM_Bid_CloseDetails');

		$scope.DSI_isLoaded = true;
		$scope.DistributionStructure = {
			DS_PROJDISTUSERS: "",
			DS_FORMACTIONS: "",
			DS_ACTIONDUEDATE: "",
			Dist_Organisation: ""
		}
		$scope.AutoDistActionStructure = {
			DS_ADO_TYPE: "",
			DS_ADO_FORM: "",
			DS_ADO_MSG_TYPE: "",
			DS_ADO_FORMACTIONS: "",
			DS_ADO_PROJDISTGROUPS: "",
			DS_ADO_ACTIONDUEDATE: "",
			DS_ADO_PROJDISTUSERS: ""
		}

		$scope.logo = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
			return val.Value3.indexOf('Client Logo') != -1 && val.Value11.indexOf('Active') != -1;
		});

		function setClientLogo() {
			if ($scope.logo && $scope.logo[0].Value8) {
				$scope.oriMsgCustomFields.DS_Logo = $scope.logo[0].Value8;
			}
		}
		var strFormId = $scope.Form_Data['DS_FORMID'];
		var strIsDraft = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_ISDRAFT;
		// form status date
		$scope.todayDateDbFormat = "";
		$scope.todayDateUKFormat = "";
		$scope.getServerTime(function (serverDate) {
			var strTime = new Date(serverDate).getTime();
			$scope.todayDateDbFormat = $scope.formatDate(new Date(strTime), 'yy-mm-dd');
			$scope.todayDateUKFormat = $scope.formatDate(new Date(strTime), 'dd-M-yy');
		});
		if (currentViewName == "ORI_VIEW") {
			var strWorkingUserOrg = WorkingUserID['0'].Name.split(',')[1].trim();
			$scope.orgFilter = commonApi._.filter(DS_PROJORGANISATIONS_ID, function (val) {
				return val.Name.indexOf(strWorkingUserOrg) < 0;
			});

			if (strFormId == "" || strIsDraft == "YES") {
				setClientLogo();
				if (strFormId == "") {
					$timeout(function () {
						if (localStorage) {
							var numVal = localStorage.getItem('formcode_num')
							if (numVal) {
								if (numVal) {
									$scope.setITTDetails(numVal);
								}
								localStorage.removeItem('formcode_num');
							}
						}
					}, 1000);
				}
			}
			if (strIsDraft == "YES") {
				$scope.oriMsgCustomFields.ITB_Info.Select_ITB = "";
				$scope.asiteSystemDataReadWrite.Distribution.AutoDirstribute_Users = [];
				var AutoDistStructure = angular.copy($scope.DistributionStructure);
				var insertpoint = $scope.asiteSystemDataReadWrite.Distribution.AutoDirstribute_Users
				insertpoint.push(AutoDistStructure);
			}
			checkForMultiResponse();
		}

		$scope.DS_ASI_STD_TNDR_GetITBs = $scope.getValueOfOnLoadData('DS_ASI_STD_TNDR_GetITBs');
		if (window.currentViewName == "ORI_PRINT_VIEW" || window.currentViewName == "FORM_PRINT_VIEW") {
			var strSel_ITB = $scope.oriMsgCustomFields.ITB_Info.Select_ITB;
			var dropDownValueObj = commonApi._.filter($scope.DS_ASI_STD_TNDR_GetITBs, function (val) {
				return val.Value3.indexOf(strSel_ITB) != -1;
			});
			if (dropDownValueObj.length) {
				$scope.oriMsgCustomFields['ITB_URL'] = dropDownValueObj && dropDownValueObj[0].URL6;
			}
		}
		$scope.update();

		$scope.AddNewItem = function (repeatingData, fromStructure) {
			var item = angular.copy(fromStructure);
			repeatingData.push(item);
		};
		$scope.DeleteRow = function (index, repeatindData) {
			if (repeatindData.length > index) {
				repeatindData.splice(index, 1);
			}
		};
		$scope.DeleteItem = function (obj, repeatingData) {
			//delete data by index
			var index = repeatingData.indexOf(obj);
			repeatingData.splice(index, 1);
		};


		$scope.setITTDetails = function (str) {
			if (str) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_ASI_STD_GET_ADDITIONAL_DATA,DS_ASI_STD_TNDR_GET_ITBSDETAILS,DS_ASI_STD_ADD_BM_Bid_Recipients,DS_ASI_STD_ADD_BM_Bid_CloseDetails",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_ASI_STD_GET_ADDITIONAL_DATA",
							"fieldValue": str
						}, {
							"fieldName": "DS_ASI_STD_TNDR_GET_ITBSDETAILS",
							"fieldValue": str
						}, {
							"fieldName": "DS_ASI_STD_ADD_BM_Bid_Recipients",
							"fieldValue": str
						}, {
							"fieldName": "DS_ASI_STD_ADD_BM_Bid_CloseDetails",
							"fieldValue": str
						}]
					}
				};
				$scope.DSI_isLoaded = false;
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var ITBData = angular.fromJson(response.data['DS_ASI_STD_TNDR_GET_ITBSDETAILS']).Items.Item;
						$scope.DS_ASI_STD_GET_ADDITIONAL_DATA = angular.fromJson(response.data['DS_ASI_STD_GET_ADDITIONAL_DATA']).Items.Item;
						$scope.DS_ASI_STD_ADD_BM_Bid_Recipients = angular.fromJson(response.data['DS_ASI_STD_ADD_BM_Bid_Recipients']).Items.Item;
						bidCloseDetails = angular.fromJson(response.data['DS_ASI_STD_ADD_BM_Bid_CloseDetails']).Items.Item;
						if (ITBData && ITBData.length) {
							var strBidAdmin = ITBData[0].Value5;
							var strOrgTitle = ITBData[0].Value3;
							var strItbId = ITBData[0].Value1;
							var strOrgUserRef = ITBData[0].Value4;
							var strItbMsgType = ITBData[0].Value14;

							$scope.oriMsgCustomFields.ITB_Info.ORI_FORMTITLE = strOrgTitle;
							$scope.oriMsgCustomFields.ITB_Info.ORI_USERREF = strOrgUserRef;
							$scope.oriMsgCustomFields.ITB_Info.Bid_Administrator = strBidAdmin;
							$scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1 = strItbId;
							$scope.oriMsgCustomFields.ITB_MSG_TYPE = strItbMsgType;
							if (bidCloseDetails.length) {
								$scope.oriMsgCustomFields.ITB_End_Date = $scope.formatDate(new Date(bidCloseDetails[0].Value5), 'yy-mm-dd');
							}
						}
						$scope.DSI_isLoaded = true;
					}
				});
			}
		}

		$scope.OnUserChanged = function () {
			var strItbAppid = $scope.asiteSystemDataReadOnly._5_Form_Data.DS_FORMCONTENT1;
			var hstFormsList = [];
			hstFormsList.push(array(strItbAppid, "3"));
			getAddPFCForms(hstFormsList);
			setDistribute(hstFormsList);

		}

		function array(key, value) {
			return {
				key: key,
				value: value
			};
		}

		function getAddPFCForms(hstFormsList) {
			var strAddData = $scope.DS_ASI_STD_GET_ADDITIONAL_DATA;
			if (strAddData && strAddData.length) {
				for (var i = 0; i < strAddData.length; i++) {
					var strAppCode = strAddData[i].Name;
					if (strAppCode) {
						hstFormsList.push(array(strAppCode, "7"));
					}
				}
			}
		}

		function setDistribute(hstFormsList) {
			var distNodes = $scope.asiteSystemDataReadWrite.Distribution.AutoDirstribute_Users;
			$scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action = [];
			var insertpoint = $scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.Auto_Distribute_Action;

			if (distNodes && distNodes.length) {
				var struser = "", strAction = "", strMsgType = "", strEndDate = $scope.oriMsgCustomFields.ITB_End_Date;
				$scope.asiteSystemDataReadWrite.Auto_Distribution_Actions.DS_AUTODISTRIBUTE_OTHERS_APP_ID = "1";
				for (var i = 0; i < distNodes.length; i++) {
					struser = distNodes[i].DS_PROJDISTUSERS;
					if (struser) {
						var strUserid = struser.split('#')[0].trim();
						for (var j = 0; j < hstFormsList.length; j++) {
							strAction = hstFormsList[j].value;
							if (strAction == "3") {
								strMsgType = $scope.oriMsgCustomFields.ITB_MSG_TYPE;
							} else {
								strMsgType = "ORI";
							}
							var AutoDistActionStructure = angular.copy($scope.AutoDistActionStructure);
							AutoDistActionStructure.DS_ADO_TYPE = "3";
							AutoDistActionStructure.DS_ADO_FORM = hstFormsList[j].key;
							AutoDistActionStructure.DS_ADO_MSG_TYPE = strMsgType;
							AutoDistActionStructure.DS_ADO_FORMACTIONS = strAction;
							AutoDistActionStructure.DS_ADO_ACTIONDUEDATE = strEndDate;
							AutoDistActionStructure.DS_ADO_PROJDISTUSERS = strUserid;
							insertpoint.push(AutoDistActionStructure);
						}
					}
				}
			}
		}

		$scope.CheckDuplicate = function (args) {
			if ($scope.oriMsgCustomFields.MultipleUserInSupplementary == "no") {
				checkDuplicateValue(args);
			}
		};
		$scope.CheckDuplicateUser = function (args) {
			checkDuplicateValue(args);
		};

		function checkDuplicateValue(args) {
			var currentIndex = args.repeatObj.indexOf(args.curObj);
			angular.forEach(args.repeatObj, function (item, index) {
				if (currentIndex != index && args.value != "" && item[args.objName] == args.value) {
					alert("Duplicate " + args.msg + " selected !!!\n\nSelect a different " + args.msg);
					args.curObj[args.objName] = "";
					return true;
				}
			});
			return false;
		}

		function checkForMultiResponse() {
			$scope.oriMsgCustomFields.MultipleUserInSupplementary = "";
			var Attribute = commonApi._.filter($scope.DS_ASI_Configurable_Attributes, function (val) {
				return val.Value3 == 'MultipleUserInSupplementary' && val.Value11.indexOf('Active') != -1
			});

			if (Attribute && Attribute.length) {
				var strValue8 = Attribute[0].Value8;
				if (strValue8.toLowerCase() == "no") {
					$scope.oriMsgCustomFields.MultipleUserInSupplementary = "no";
				}
			}
		}

		$window.ASI_FinalCallBack = function () {
			return $scope.FinalCallBack();
		}

		$scope.FinalCallBack = function () {
			$scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_SEND_MSG = "0";
			var strITTId = $scope.oriMsgCustomFields.ITB_Info.Select_ITB;
			if (strITTId) {
				var form = {
					"projectId": $scope.projectId,
					"formId": $scope.formId,
					"fields": "DS_ASI_STD_TNDR_GET_ITBSDETAILS",
					"callbackParamVO": {
						"customFieldVOList": [{
							"fieldName": "DS_ASI_STD_TNDR_GET_ITBSDETAILS",
							"fieldValue": strITTId
						}]
					}
				};
				$scope.getCallbackData(form).then(function (response) {
					if (response.data) {
						var ITBData = angular.fromJson(response.data['DS_ASI_STD_TNDR_GET_ITBSDETAILS']).Items.Item;
						if (ITBData && ITBData.length) {
							var val12 = ITBData[0].Value12;
							if (val12 && val12 == "1") {
								$scope.asiteSystemDataReadOnly._6_Form_MSG_Data.DS_SEND_MSG = "1| Supplementary can not be created subsequent to the release of responses.";
								return true;
							}
						}

					}
				});
			}

			return false;
		}

	}

	return FormController;
});

function customHTMLMethodBeforeCreate_ORI() {
	if (typeof ASI_FinalCallBack !== "undefined") {
		return ASI_FinalCallBack();
	}
}