var attachPathCnt = 0;
var attachCount = 0;
var globalPath = "/scripts/htmlform";
var isOriView = false;
var isAttchmentAvail = true;
$(document).ready(function() {
	(function sendEvent() {
	       	var iframe = document.createElement("IFRAME");
	    	iframe.setAttribute("src", "js-frame:getData");
	    	document.documentElement.appendChild(iframe);
	    	iframe.parentNode.removeChild(iframe);
	    	iframe = null;
	})();
	$("body").append('<form name="myform" id="myform" class="ng-pristine ng-invalid ng-invalid-required ng-valid-pattern">');
	/*$("body").prepend('<div id="viewFormHeaderTable" istextcontrol="0"><div class="intro-scheme clearfix"><div class="firstcol "><strong>Title:</strong><strong><br>Status:</strong><br></div><div class="secondcol"><strong>User Ref Code:</strong><strong><br>Expected Close Date:</strong></div><div class="thirdcol"><strong>Originator:</strong><strong><br>Controller: </strong></div></div></div>');
	$("body").prepend(' <div class="fullwidth-box-top add-minwidth"style="background: #568BC9 !important;"><h2><strong>View Form</strong></h2><div class="clearfix"></div></div>');*/
	$(".container-fluid").append('<div id="attachDiv" style="border: 1pt solid #dcdcdc;margin-top: 10px;height: 25%;overflow: overlay;width: 70%; margin-bottom:11px; visibility:hidden"></div>');
	$(".container-fluid").append('<div id="attachCountDiv" style="padding-bottom: 10px; visibility:hidden"><label>Attachments</label><label id="attachCount">(0)</label></div>');
	$(".map-control-group").parent().hide();
		
	try {
		var input_json = $('.json_data').val();
		var tempData = input_json ? JSON.parse(input_json) : {};
		tempData = tempData.myFields.attachments || [];
		if(tempData && tempData.length) {
			for (var i = 0; i < tempData.length; i++) {
				var attach = tempData[i];
				for ( var key in attach) {
					if(attach.hasOwnProperty(key)) {
						var count = key.replace('txtAttachedPath', '');
						addAttachElement(count, attach[key]);
					}
				}
			}
			attachPathCnt = tempData.length + 1;
		}
	} catch(e) {
		console.log('error while getting form json', e);
	}
	
	$(".container-fluid").append('<div class="btnsaveCancelForm" id="btnsaveCancelForm" style="display: block;padding-top: 10px;float: left;clear: both;"><button id="btnSaveForm" role="button" data-toggle="modal" onclick="javascript:offLineFormSubmitClicked();" title="Information last saved draft on 25-May-2017 07:18 WET" style=" background-color: #568BC9;font-size: 14px;color: white;border: none;padding: 6px 15px;border-radius: 3px;font-size: 14px;float: left;cursor: pointer;margin-left: 5px;">Save</button><button id="btnSaveDraftForm" role="button" data-toggle="modal" onclick="javascript:offLineFormSubmitDraftClicked();" title="Information last saved draft on 25-May-2017 07:18 WET" style=" background-color: #568BC9;font-size: 14px;color: white;border: none;padding: 6px 15px;border-radius: 3px;font-size: 14px;float: left;cursor: pointer;margin-left: 5px;">Save Draft</button><input id="btnAttchForm" onclick="javascript:offLineFormAttachmentClicked()" style="background-color:#568BC9;font-size: 14px;color: white;border: none;padding: 6px 15px;border-radius: 3px;font-size: 14px;float: left;cursor: pointer;width: 105px;margin-left: 5px;" value="Attach files" type="button"/><input id="btnCancelForm" onclick="javascript:offLineFormCancelClicked()" style="background-color:#363636;font-size: 14px;color: white;border: none;padding: 6px 11px;border-radius: 3px;font-size: 14px;float: left;cursor: pointer;width: 66px;margin-left: 10px;" type="button" value="Cancel"></div>');
	var $formContainer = $(".form-container");
	$("form#myform").append($formContainer);
	$("#btnSaveForm,#btnAttchForm,#btnCancelForm,#btnSaveDraftForm").css({
		'-webkit-appearance' : 'none',
		'-moz-appearance' : 'none',
		'appearance' : 'none'
	});
	setInterval(
	function(){
		 $('div.formBuilder .btn-danger[disabled]').css('background-color','#568BC9');
		 $('div.formBuilder .btn-danger[disabled]').css('border-color','#568BC9');
		 $('div.formBuilder .btn-danger[disabled]').css('background-image','none');
		 $('div.formBuilder .table-settings button').css('background-image','none');
		 $('div.formBuilder .table-settings button').css('border-color','#568BC9');
		 $('div.formBuilder .table-settings button').css('background-color','#568BC9');
		 $('div.formBuilder .btn-danger').css('background-color','#568BC9');
		 $('div.formBuilder .btn-danger').css('border-color','#568BC9');
		 $('div.formBuilder .btn-danger').css('background-image','none');
	}, 1000)
	if(isOriView == true){
		setTimeout(disableAllElements, 1000);
	}
});

function setJSONData(jsonData){
	//if(isOriView == true){
		isAttchmentAvail = jsonData && jsonData.allow_attachments;	
		if(!isAttchmentAvail){
			$('form#myform #btnAttchForm').hide();
		}
	//}
}

function offLineFormSubmitClicked(){
	var isValid = validateForHTML5Form();
	if(isValid){
		var iframe = document.createElement('IFRAME');
		iframe.setAttribute('src', 'js-frame:offLineFormSubmitClicked');
		document.documentElement.appendChild(iframe);
		iframe.parentNode.removeChild(iframe);iframe = null;
	}
	
} 

function offLineFormSubmitDraftClicked(){
	var isValid = true;
	if(isValid){
		var iframe = document.createElement('IFRAME');
		iframe.setAttribute('src', 'js-frame:offLineFormSubmitDraftClicked');
		document.documentElement.appendChild(iframe);
		iframe.parentNode.removeChild(iframe);iframe = null;
	}
	
} 
 
function offLineFormAttachmentClicked(){
	var iframe = document.createElement('IFRAME');
	iframe.setAttribute('src','js-frame:offLineFormAttachmentClicked');
	document.documentElement.appendChild(iframe);
	iframe.parentNode.removeChild(iframe);
	iframe = null;
} 
function offLineFormCancelClicked(){
	var iframe = document.createElement('IFRAME');
	iframe.setAttribute('src','js-frame:offLineFormCancelClicked');
	document.documentElement.appendChild(iframe);
	iframe.parentNode.removeChild(iframe);
	iframe = null;
}
function addAttachElement(pathCnt, value){
	var br = document.createElement("br");
	var appendDiv = document.getElementById("attachDiv");
	if(appendDiv!=null){
		appendDiv.style.visibility = 'visible';
	}
	var attachPath = document.createElement("input");
	if(pathCnt === undefined) {
		pathCnt = ++attachPathCnt;
	}
	value && attachPath.setAttribute("value", value);
	attachPath.setAttribute("id","txtAttachedPath"+(pathCnt));
	attachPath.setAttribute("readonly","readonly");
	appendDiv.appendChild(attachPath);
	
	var removeIcon = document.createElement("img");
	removeIcon.setAttribute("src",globalPath + "remove.png");
	removeIcon.setAttribute("id","btnRemove_"+pathCnt);
	removeIcon.setAttribute("class","remove-icon");
	removeIcon.setAttribute("onclick","removeAttachment(this);");
	appendDiv.appendChild(removeIcon);
	appendDiv.appendChild(br);
	var attachCountDiv = document.getElementById('attachCountDiv');
	if(attachCountDiv!=null){
		attachCountDiv.style.visibility = 'visible';
	}
	var attachCountLabel = document.getElementById("attachCount");
	attachCount++;
	attachCountLabel.textContent ='('+attachCount+')';
}

function removeAttachment(clickedObject){
	var clickedObjectId = clickedObject.id;
	var clickedObjCnt = clickedObjectId.substring((clickedObjectId.lastIndexOf("_")+1));
	var appendDiv = document.getElementById("attachDiv");
	clickedObject.nextElementSibling.remove();
	var txtAttPathObj = document.getElementById('txtAttachedPath'+clickedObjCnt);
	appendDiv.removeChild(clickedObject);
	appendDiv.removeChild(txtAttPathObj);
	var iframe = document.createElement("IFRAME");
	iframe.setAttribute("src", "js-frame:removeAttachment#"+clickedObject.id);
	document.documentElement.appendChild(iframe);
	iframe.parentNode.removeChild(iframe);
	iframe = null;
	var attachCountLabel = document.getElementById("attachCount");
	attachCount--;
	attachCountLabel.textContent ='('+attachCount+')';
}
function validateForHTML5Form() {
    var formObj = document.myform;
    if (formObj) {
        var FormError = angular && angular.element(formObj).scope().myform.$error;
        if (FormError && !$.isEmptyObject(FormError)) {
            var validateMSG = "This form contains validation errors or mandatory fields are not specified. Errors are marked with either a red asterisk (required fields) or a red dashed border (invalid values). Please update and click on Create/Update button again.";
            ADODDLE.alert({
                title: "",
                msg: validateMSG
            });
            return false
        } else {
            var sendMsg = document.getElementById("DS_SEND_MSG");
            if (sendMsg && sendMsg.value) {
                var pipeIndex = sendMsg.value.indexOf("|");
                if (pipeIndex > -1) {
                    var flag = "" + Trim(sendMsg.value.substring(0, pipeIndex));
                    var message = Trim(sendMsg.value.substring(pipeIndex + 1));
                    if (flag == "1") {
                        ADODDLE.alert({
                            title: "Alert Message",
                            msg: message
                        });
                        return false
                    }
                    if (flag == "2") {
                        if (!confirm(message)) {
                            return false
                        }
                    }
                }
            }
            if (typeof customHTMLMethodBeforeCreate_ORI != "undefined" && customHTMLMethodBeforeCreate_ORI()) {
                return false
            }
        }
    }
    return true
}

// function to disable all elements of the VIEW as well hide save,attachment as well.
function disableAllElements(){
	// disable all input,select elements.
	$("form#myform :input, form#myform select, form#myform button").attr("disabled", true);
	$("form#myform #btnCancelForm").attr("disabled",false);
	$('form#myform .add-row, form#myform .remove-icon, form#myform #btnSaveForm,#btnSaveDraftForm, form#myform #btnAttchForm, form#myform .form-group> div[text-angular]> div[text-angular-toolbar]').hide();
	// hide rich-text-box toolbar pannel and set text area contenteditable false.
	//$('form#myform .form-group').find('div[text-angular-toolbar]').hide();
	$('form#myform .form-group').find('div[contenteditable]').attr('contenteditable',false);
	// set background color for the date picker for disabled.	
	$('form#myform .form-group').find(".ang-datepciker").attr('disabled',true).css('background-color','#eee');	
	$('form#myform .form-group').find(".remove-date").hide();
}