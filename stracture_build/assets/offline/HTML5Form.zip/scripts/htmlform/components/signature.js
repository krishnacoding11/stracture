/**
 * Signature component.
 * This module will initialize the Signature component for angular application.
 * @module Signature
 */
define(['angular', 'mainModule'], function (angular, mainModule) {
	'use strict';

	/**
	 * @constructor
	 * @alias module:Signature/SignatureController
	 * Example: <asite-signature width="600px" parent="data" key="sigData" disable="true"></asite-signature>
	 */
	function SignatureController($scope, $element, $attrs, $document, $window) {
		var ctrl = this,
			initialized = false,
			ignoreValChangeEvent = false,
			$signature = $element.find('div');

		ctrl.$onInit = function () {
			draw();
			if ($window.resetSignatureOnEdit) {
				reset();
			}
			initialized = true;
			var resetBtn = $signature.find('.reset');
			resetBtn[0].innerHTML = Language.get('reset')
			var undoBtn = $signature.find('.undo');
			undoBtn[0].innerHTML = Language.get('undo')
		}

		ctrl.$onDestroy = function () {
			if(ctrl.form){
				ctrl.form.$setValidity("signatureRequired" + $scope.$id, true);
			}
		}

		ctrl.$onChanges = function(changedProps) {
			if(changedProps && initialized) {
				if(changedProps.required != undefined) {
					validateRequiredField();
				}

				if(changedProps.readonly  != undefined) {
					if(changedProps.readonly) {
						$signature.jSignature('disable', true);
						$signature.find('.reset, .undo').attr('disabled', true);
					}else {
						$signature.jSignature('enable', true);
						$signature.find('.reset, .undo').attr('disabled', false);
					}
				}

				if(changedProps.signatureVal != undefined){
					if(ignoreValChangeEvent) {
						ignoreValChangeEvent = false;
						return;
					}
					draw();
				}
			}
		}

		function draw() {
			ignoreValChangeEvent = false;
			$signature.unbind('change');
			set();
			var emptySVS='<?xml version="1.0" encoding="UTF-8" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="0" viewBox="0 0 0 0" ></svg>';
			if (ctrl.parent[ctrl.key] && typeof ctrl.parent[ctrl.key] == 'string') {
				try {
					var val = JSON.parse(ctrl.parent[ctrl.key]);
					ctrl.parent[ctrl.key] = val;
				} catch (e) {
					console.log(e);
				}
			}
			if (ctrl.parent[ctrl.key] && ctrl.parent[ctrl.key].length == 2 && ctrl.parent[ctrl.key][1] != emptySVS) {
				$signature.find('canvas').remove();
				// $signature.find('svg').css({'width':'auto'});
				$signature.prepend(ctrl.parent[ctrl.key][1]);
				$signature.find('.reset').css({
					'position': 'absolute',
					'float': 'right',
					'right': '89px',
					'top': '0px'
				}).attr('disabled', false).unbind('click').bind('click', function (e) {
					reset();
				});	
				$signature.find('svg').css({'width':'auto'});			
			}			
		}

		function set() {
			$signature.empty();
			$signature.jSignature({
				"width": '100%',
				"height": '100px',
				"UndoButton": ctrl.readonly == true ? false : true,
				"ResetButton": ctrl.readonly == true ? false : true,
				"lineWidth": 2
			});

			if(ctrl.readonly || ctrl.disable == "true") {
				$signature.jSignature('disable', true);
			}

			$signature.unbind('change').bind('change', function (e) {
				ignoreValChangeEvent = true;
				var signData = $signature.jSignature('getData', 'svg');
				var svgData = signData[1];

				ctrl.parent[ctrl.key] = ctrl.signatureVal = $(svgData)[1].innerHTML == "" ? "" : signData;//$signature.jSignature('getData', 'svg');
				validateRequiredField();
				try {
					$scope.$apply();
					ctrl.signatureChange && ctrl.signatureChange();
				} catch (e) {
					console.log(e);
				}
			});
			validateRequiredField();
		}

		function reset() {
			ignoreValChangeEvent = false;
			ctrl.parent[ctrl.key] = ctrl.signatureVal = '';
			set();
		}

		function validateRequiredField() {
			if (ctrl.required != "true" || !ctrl.form || ctrl.disable == "true") {
				$signature.attr('title', "").css('border', 'none');
				if(ctrl.form) {
					ctrl.form.$setValidity("signatureRequired" + $scope.$id, true);
				}
				return;
			}

			var isModified = $signature.jSignature('isModified');
			var emptyCanvas = ["image/svg+xml", '<?xml version="1.0" encoding="UTF-8" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="0" height="0"></svg>'];

			if (!isModified && (ctrl.parent[ctrl.key] == '' || JSON.stringify(ctrl.parent[ctrl.key]) == JSON.stringify(emptyCanvas))) {
				$signature.attr('title', "Please fill out this field.").css('border', '1px solid red');
				ctrl.form.$setValidity("signatureRequired" + $scope.$id, false);
			} else {
				$signature.attr('title', "").css('border', 'none');
				ctrl.form.$setValidity("signatureRequired" + $scope.$id, true);
			}
		}

	}

	mainModule.component('asiteSignature', {
		template: '<div ng-style="{\'background-color\': \'#f5f5f5\',width:\'100%\'}" class="clearfix"></div>',
		controller: SignatureController,
		bindings: {
			width: '@',
			key: '@',
			disable: '@',
			parent: '=',
			required: '@',
			readonly: '=',
			signatureVal: '<',
			signatureChange: '&',
			form: '='
		}
	});
});