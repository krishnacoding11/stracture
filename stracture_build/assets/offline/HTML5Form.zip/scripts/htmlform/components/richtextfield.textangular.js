/**
 * richTextField component.
 * This module will initialize the richTextField component based on textAngular for angular application[ HTML5 forms ].
 * http://textangular.com/
 * @module richTextField
 */
define(['angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	/** 
     * @param {string} model : to store value in json, accept as json field in string
	 * @param {string} name : to identify component
	 * @param {boolean} required : to make component mandatory,
	 * @param {boolean} disabled : to disabled component,
	 * @param {Function} onBlur: on blur event of component,
	 * @param {Array} options: To customize toolbar
	 * 
	 * @example
	 * <rich-text-field model="oriMsgCustomFields.Comments" name="Comments" required="true" disabled="false" on-blur="onBlurEvent()" options="[['h1','h2','h3'],['bold','italics']]"></rich-text-field>
     */

	
	/**
	 * removeToobarOptions : @taOptions required,
	 * toggleMenu : @refElm : clicked element, @menuClass : class to be toggled. 
	 * hideOnOutside: Function for hiding the font-size and font-name menues on outside click on page.
	 * addTextAngularOptions : Function to add other options like 'font-name, font-size, color-picker' etc.. to 'text-angular' rich-text box editor 
	 */
	var hideOnOutside = function () {
		angular.element('body').on('click', function (event) {
			var $eventTarget = angular.element(event.target),
				targetClassList = event.target.classList,
				targetParentClassList = event.target.parentElement && event.target.parentElement.classList,
				$editorToolbar = angular.element('.artf-editor-toolbar');
			if (!targetClassList.contains('font-name') && !targetParentClassList.contains('font-name') &&
				!$eventTarget.closest('.font-name').hasClass('open-fonts-list')) {
				$editorToolbar.find('.font-name').removeClass('open-fonts-list');
			}
			if (!targetClassList.contains('font-size') && !targetParentClassList.contains('font-size') &&
				!$eventTarget.closest('.font-size').hasClass('open-fonts-size-list')) {
				$editorToolbar.find('.font-size').removeClass('open-fonts-size-list');
			}
		});
	};

	var removeToobarOptions = function (taOptions) {
        var toolsToRemove = ["pre", "quote", "html", "insertVideo", "wordcount", "charcount"];
        if (taOptions.toolbar && taOptions.toolbar.length)
            for (var i = 0; i < toolsToRemove.length; i++)
                for (var j = 0; j < taOptions.toolbar.length; j++) {
                    var index = taOptions.toolbar[j].indexOf(toolsToRemove[i]);
                    -1 < index && taOptions.toolbar[j].splice(index, 1)
                }
    },
    addTextAngularOptions = function ($provide) {
        $provide.decorator("taOptions", ["taRegisterTool", "$delegate", function (taRegisterTool, taOptions) {
                    return removeToobarOptions(taOptions),
                    taRegisterTool("backgroundColor", {
                        display: "<div spectrum-colorpicker ng-model='color' on-change='!!color && action(color)' format='\"rgb\"' options='options'></div>",
                        action: function (color) {
                            var me = this;
                            if (this.$editor().wrapSelection)
                                return this.$editor().wrapSelection("backColor", color);
                            setTimeout(function () {
                                me.action(color)
                            }, 100)
                        },
                        options: {
                            replacerClassName: "fa fa-paint-brush",
                            showButtons: !1
                        },
                        color: "#fff"
                    }),
                    taRegisterTool("fontColor", {
                        display: "<spectrum-colorpicker trigger-id='{{trigger}}' ng-model='color' on-change='!!color && action(color)' format='\"hex\"' options='options'></spectrum-colorpicker>",
                        action: function (color) {
                            var me = this;
                            if (this.$editor().wrapSelection)
                                return this.$editor().wrapSelection("foreColor", color);
                            setTimeout(function () {
                                me.action(color)
                            }, 100)
                        },
                        options: {
                            replacerClassName: "fa fa-font",
                            showButtons: !1,
                            showAlpha: !1
                        },
                        color: "#000"
                    }),
                    taOptions.toolbar[1].push("backgroundColor", "fontColor"),
                    taOptions
                }
            ]),
        $provide.decorator("taToolFunctions", ["$delegate", function ($delegate) {
                    var imgOnSelectActionFn = $delegate.imgOnSelectAction;
                    return $delegate.imgOnSelectAction = function (event, $element, editorScope) {
                        imgOnSelectActionFn(event, $element, editorScope),
                        editorScope.displayElements.popover.css("width", "auto"),
                        editorScope.displayElements.popover.find(".btn-group").eq(1).remove()
                    },
                    $delegate
                }
            ])
	}

	/**
	 * configuring and Binding the created text-angular options to the MainModule.
	 */
	mainModule.config(function ($translateProvider, $provide) {
		addTextAngularOptions($provide);
		hideOnOutside();
	});

	function rtfController() {
		var ctrl = this;
		ctrl.$onInit = function() {
			loadCss('textAngular_$','../../../css/htmlform/textAngular.css');
			loadCss('spectrum_$','../../../css/htmlform/spectrum.css');
		};


		ctrl.$onDestroy = function() {
			
		}

		function loadCss(id,url) {
			var linkObj = document.getElementById(id);
			if(!linkObj){
				var link = document.createElement("link");
				link.type = "text/css";
				link.rel = "stylesheet";
				link.href = url;
				document.getElementsByTagName("head")[0].appendChild(link);
			}
		}

	};

	mainModule.component('richTextField', {
		template: '<div class="artf-container component" ng-class="{\'required\': $ctrl.required && !$ctrl.model}">'+
			
			// Without ta-toolbar
			'<div ng-if="!$ctrl.options" text-angular name="{{$ctrl.name}}" ng-model="$ctrl.model" ta-keep-styles="true" class="richtext-control" ta-editor-class="artf-editor" ta-disabled="$ctrl.disabled" ta-toolbar-class="artf-editor-toolbar" ng-required="$ctrl.required" ta-paste="editorNativePasteEvent($html);" ng-blur="$ctrl.onBlur && $ctrl.onBlur()"></div>' +

			// With ta-toolbar
			'<div ng-if="$ctrl.options" text-angular name="{{$ctrl.name}}" ng-model="$ctrl.model" ta-keep-styles="true" class="richtext-control" ta-editor-class="artf-editor" ta-disabled="$ctrl.disabled" ta-toolbar-class="artf-editor-toolbar" ng-required="$ctrl.required" ta-paste="editorNativePasteEvent($html);" ng-blur="$ctrl.onBlur && $ctrl.onBlur()" ta-toolbar="$ctrl.options"></div>' +

		'</div>',

		bindings: {
			model: "=",
			name: "<",
			required: "<",
			disabled: "<",
			onBlur: '&',
			options: "<"
		},
		controller: rtfController
	});
});