/**
 * rtfNicEdit component.
 * This module will initialize the rtfNicEdit component based on nicEdit for angular application[ HTML5 forms ].
 * http://nicedit.com/
 * @module rtfNicEdit
 */
define(['angular', 'mainModule', '../../nicEdit'], function (angular, mainModule) {
	'use strict';

	/** 
	 * @param {string} model : to store value in json, accept as json field in string
	 * @param {boolean} required : to make component mandatory,
	 * @param {boolean} disabled : to disabled component,
	 * @param {Function} onBlur: on blur event of component,
	 * @param {Array} options: To customize toolbar
	 * 
	 * @example
	 * <rtf-nic-edit model="oriMsgCustomFields.Comments" required="true" disabled="false" on-blur="onBlurEvent()" options="['left', 'center', 'right', 'justify']"></rtf-nic-edit>
	 */

	function nicEditController($scope, $timeout, $element) {
		var ctrl = this;
		var $componentInstance;
		ctrl.$onInit = function () {
			$scope.componentId = "nicEdit_" + generateUUID();
			createRichtext($scope.componentId);
		};

		function generateUUID() {
			var dateTime = new Date().getTime();//Timestamp
			var microTime = ((typeof performance !== 'undefined') && performance.now && (performance.now() * 1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (charStr) {
				var randomNumber = Math.random() * 16;//random number between 0 and 16
				if (dateTime > 0) {//Use timestamp until depleted
					randomNumber = (dateTime + randomNumber) % 16 | 0;
					dateTime = Math.floor(dateTime / 16);
				} else {//Use microseconds since page-load if supported
					randomNumber = (microTime + randomNumber) % 16 | 0;
					microTime = Math.floor(microTime / 16);
				}
				return (charStr === 'x' ? randomNumber : (randomNumber & 0x3 | 0x8)).toString(16);
			});
		}



		ctrl.$onDestroy = function () {

		}

		ctrl.$onChanges = function () {
			enableDisableComponent();
		};

		function enableDisableComponent() {

			if (ctrl.disabled) {
				$element.find('.nicEdit-main').attr('contenteditable', 'false');
				$element.find('.nicEdit-panel').hide();
			} else {
				$element.find('.nicEdit-main').attr('contenteditable', 'true');
				$element.find('.nicEdit-panel').show();
			}
		}

		function createRichtext(elemId) {
			$timeout(function () {
				var elemObj = document.getElementById(elemId)
				if (elemObj) {
					var editor = new nicEditor({
						buttonList: ctrl.options || ['bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'indent', 'outdent', 'image', 'link', 'unlink', 'forecolor', 'bgcolor', 'fontSize', 'fontFamily', 'strikethrough', 'subscript', 'superscript', 'removeformat', 'hr'],
						iconsPath: '../images/nicEditorIcons_new.gif',
						maxHeight: 300
					}).panelInstance(elemId);

					$componentInstance = nicEditors.findEditor(elemId);
					var content = $componentInstance.getContent();
					if (content == "" || content == "<br>") {
						content = "";
					}
					if (ctrl.model && content == "") {
						content = ctrl.model;
						$componentInstance.setContent(content);
					}
					editor.addEvent('blur', function () {
						var SURROGATE_PAIR_REGEXP = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g;
						// Your code here that is called whenever the user blurs (stops editing) the nicedit instance
						content = $componentInstance.getContent();
						if (content == "" || content == "<br>") {
							content = "";
						}

						content = content.replace(SURROGATE_PAIR_REGEXP, function (value) {
							var hi = value.charCodeAt(0);
							var low = value.charCodeAt(1);
							return '&#' + (((hi - 0xD800) * 0x400) + (low - 0xDC00) + 0x10000) + ';';
						}); // To remove smiley character from UI

						ctrl.model = content;
						ctrl.onBlur && ctrl.onBlur();
						$scope.$apply();
					});

					enableDisableComponent()

				} else {
					createRichtext(elemId);
				}
			}, 100);

		}

	};

	mainModule.component('rtfNicEdit', {
		template: '<div class="nic-container" ng-class="{\'required\': $ctrl.required && !$ctrl.model}">' +

			'<textarea id="{{componentId}}" name="{{componentId}}" ng-disabled="$ctrl.disabled" contenteditable={{$ctrl.disabled}}></textarea>' +
			'<input ng-model="$ctrl.model" type="text" class="hide" ng-required="$ctrl.required" />' +

			'</div>',

		bindings: {
			model: "=",
			required: "<",
			disabled: "<",
			onBlur: '&',
			options: "<"
		},
		controller: nicEditController
	});
});