/**
 * Radio group component.
 * This module will initialize the radio group switches.
 * functionality
 *  - switch with desired color
 *  - required, disable and reaonly 
 *  - rounded corner style
 * @module radioGroupSwitch
 * Example: with list and model only
 * 	<radio-group-switch model="oriMsgCustomFields.preferedLang" list="LanguageList"></radio-group-switch>
 * Example: selected option with desired color, required and required="true" on change callback
 * 	<radio-group-switch model="oriMsgCustomFields.preferedLang" list="LanguageList" selected-bgcolor="'#b78b27'" selected-fgcolor="'#000'" on-selection-change="onLangSelectionChange(selectionitem);"></radio-group-switch>
 * Example: disabled selection
 * 	<radio-group-switch model="oriMsgCustomFields.preferedLang" list="LanguageList" selectiondisabled="true"></radio-group-switch>
 * Example: read only
 * 	<radio-group-switch model="oriMsgCustomFields.preferedLang" list="LanguageList" viewonly="true"></radio-group-switch>
 */
define([ 'angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	mainModule.component('radioGroupSwitch', {
		template : '<div class="btn-group btn-group-toggle" data-toggle="buttons" ng-class="{requiredval: $ctrl.required && !$ctrl.model, disablechange: $ctrl.selectiondisabled, edgerounded: $ctrl.edgeround, viewonlyelem: $ctrl.viewonly}" >'+
						'<label class="btn" ng-repeat="objRedioItem in $ctrl.copiedList" ng-style="objRedioItem.modelVal == $ctrl.model && objRedioItem.selectedBgcolor && {'+"'background-color'"+': objRedioItem.selectedBgcolor,'+"'color'"+': objRedioItem.selectedFgcolor}" ng-class="{'+"'btn-danger'"+': objRedioItem.modelVal == $ctrl.model && !objRedioItem.selectedBgcolor,'+"'btn-default'"+': objRedioItem.modelVal != $ctrl.model, '+"'selected-radio'"+': objRedioItem.modelVal == $ctrl.model}">'+
							'<input type="radio" autocomplete="off" ng-model="$ctrl.model" ng-required="$ctrl.required" ng-change="onRadioSelectionChange(objRedioItem)" ng-disabled="$ctrl.selectiondisabled || $ctrl.viewonly" value={{objRedioItem.modelVal}}><span class="display-value">{{objRedioItem.displayVal}}</span>'+
						'</label>'+
					'</div>',
		bindings : {
			model: '=', // To store custom Attribute logo in json field
			list : '<', // list items with modelVal and displayVal
			required: '<',			//Check if value is required
			selectedBgcolor: '<', // background color of selected button
			selectedFgcolor: '<', // color of selected button
			onSelectionChange: '&',	//call function onchange of value,
			selectiondisabled: "<",	//Check if button is disabled
			viewonly: '<', // readonly you can not change 
			edgeround: "<" // if want rounded edge to chip
		},
		
		controller : ['$scope', '$timeout', function($scope, $timeout) {
			var ctrl = this;
			ctrl.$onInit = function() {
				ctrl.copiedList = angular.copy(ctrl.list);
				for(var i = 0; i<ctrl.copiedList.length; i++){
					if(!ctrl.copiedList[i].selectedBgcolor){
						ctrl.copiedList[i].selectedBgcolor = ctrl.selectedBgcolor;
					}
					if(!ctrl.copiedList[i].selectedFgcolor){
						ctrl.copiedList[i].selectedFgcolor = ctrl.selectedFgcolor || '#ffffff';
					}
				}
			};

			$scope.onRadioSelectionChange = function (optitem) {
				$timeout(function () {
					ctrl.onSelectionChange && ctrl.onSelectionChange({ selectionitem: optitem });
				});
			};
		}]
	});
});