/**
 * DatePicker component.
 * This module will initialize the DatePicker component for angular application.
 * @module DatePicker
 */
define([ 'angular', 'mainModule' ], function(angular, mainModule) {
	
	'use strict';

	var A_DAY_IN_MILLISECONDS = 86400000,
	lastOpenCalendar = null,
	isMobile = (function isMobile() {
		if (navigator.userAgent && (navigator.userAgent.match(/Android/i)
			|| navigator.userAgent.match(/webOS/i)
			|| navigator.userAgent.match(/iPhone/i)
			|| navigator.userAgent.match(/iPad/i)
			|| navigator.userAgent.match(/iPod/i)
			|| navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent
			.match(/Windows Phone/i))) {
			return true;
		}
	}()), 
	
	generateMonthAndYearHeader = function generateMonthAndYearHeader(prevButton, nextButton) {
		return [
				'<div class="_720kb-datepicker-calendar-header calender-header clearfix">',
				'<div class="_720kb-datepicker-calendar-header-left" ng-hide="showYearsPagination || showMonths">',
				'<a tabindex="-1" class="_720kb-datepicker-calendar-month-button" href="javascript:void(0)" ng-class="{\'_720kb-datepicker-item-hidden\': !willPrevMonthBeSelectable()}" ng-click="prevMonth()" title="{{ buttonPrevTitle }}">',
				prevButton,
				'</a>',
				'</div>',
				'<div class="_720kb-datepicker-calendar-header-right" ng-hide="showYearsPagination || showMonths">',
				'<a tabindex="-1" class="_720kb-datepicker-calendar-month-button" ng-class="{\'_720kb-datepicker-item-hidden\': !willNextMonthBeSelectable()}" href="javascript:void(0)" ng-click="nextMonth()" title="{{ buttonNextTitle }}">',
				nextButton, '</a>', 
				'</div>',
				'<div class="_720kb-datepicker-calendar-header-middle _720kb-datepicker-calendar-month">',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="showMonths = !showMonths;showYearsPagination = false;">',
				'<span>{{month}} <i class="_720kb-datepicker-calendar-header-closed-pagination"></i></span>',
				'</a>&nbsp;',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="paginateYears(year); showYearsPagination = !showYearsPagination;showMonths = false;">',
				'<span>{{year}} <i class="_720kb-datepicker-calendar-header-closed-pagination"></i></span>',
				'</a>', '</div>', '</div>' ];
	}, 
	
	generateYearsPaginationHeader = function generateYearsPaginationHeader(prevButton, nextButton) {
		return [
		        '<div class="_720kb-datepicker-calendar-header months" ng-show="showMonths">',
		        '<a tabindex="-1" ng-repeat="item in months" title="{{ dateMonthTitle }}" ng-class="{\'_720kb-datepicker-active\': item === month, \'_720kb-datepicker-disabled\': !isSelectableMaxMonth($index) || !isSelectableMinMonth($index)}" href="javascript:void(0)" ng-click="selectedMonthHandle($index)">',
				'{{ item }}',
				'</a>',
		        '</div>',
				'<div class="_720kb-datepicker-calendar-header years" ng-show="showYearsPagination">',
				'<div class="_720kb-datepicker-calendar-years-pagination">',
				'<a tabindex="-1" ng-class="{\'_720kb-datepicker-active\': y === year, \'_720kb-datepicker-disabled\': !isSelectableMaxYear(y) || !isSelectableMinYear(y)}" href="javascript:void(0)" ng-click="setNewYear(y)" ng-repeat="y in paginationYears">',
				'{{y}}',
				'</a>',
				'</div>',
				'<div class="_720kb-datepicker-calendar-years-pagination-pages">',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="paginateYears(paginationYears[0])" ng-class="{\'_720kb-datepicker-item-hidden\': paginationYearsPrevDisabled}">',
				prevButton,
				'</a>',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="paginateYears(paginationYears[paginationYears.length -1 ])" ng-class="{\'_720kb-datepicker-item-hidden\': paginationYearsNextDisabled}">',
				nextButton, '</a>', '</div>', '</div>' ];
	}, 
	
	generateDaysColumns = function generateDaysColumns() {
		return [
				'<div class="_720kb-datepicker-calendar-days-header clearfix">',
				'<div ng-repeat="d in daysInString">', '{{d}}',
				'</div>', '</div>' ];
	}, 
	
	generateDays = function generateDays() {
		return [
				'<div class="_720kb-datepicker-calendar-body clearfix">',
				'<a tabindex="-1" href="javascript:void(0)" ng-repeat="px in prevMonthDays" class="_720kb-datepicker-calendar-day _720kb-datepicker-disabled" ng-click="setDatepickerDay(px, \'prev\')">',
				'{{px}}',
				'</a>',
				'<a tabindex="-1" href="javascript:void(0)" ng-repeat="item in days" ng-click="setDatepickerDay(item)" ng-class="{\'_720kb-datepicker-active\': day === item, \'_720kb-datepicker-disabled\': !isSelectableMinDate(year + \'/\' + monthNumber + \'/\' + item ) || !isSelectableMaxDate(year + \'/\' + monthNumber + \'/\' + item) || !isSelectableDate(monthNumber, year, item)}" class="_720kb-datepicker-calendar-day">',
				'{{item}}',
				'</a>',
				'<a tabindex="-1" href="javascript:void(0)" ng-repeat="nx in nextMonthDays" class="_720kb-datepicker-calendar-day _720kb-datepicker-disabled" ng-click="setDatepickerDay(nx, \'next\')">',
				'{{nx}}', 
				'</a>', '</div>',
				'<div class="_720kb-datepicker-calendar-footer">',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="setToday();" class="_720kb-datepicker-calendar-footer__today-btn">{{todayTitle}}</a>',
				'<a tabindex="-1" href="javascript:void(0)" ng-click="hideCalendar();" class="_720kb-datepicker-calendar-footer__close-btn">{{closeTitle}}</a>',
				'</div>' ];
	}, 
	
	generateHtmlTemplate = function generateHtmlTemplate(prevButton, nextButton) {
		var toReturn = [ '<div class="_720kb-datepicker-calendar {{datepickerClass}} {{datepickerID}} {{classForToggle}}" ng-blur="hideCalendar()">', '</div>' ], 
			monthAndYearHeader = generateMonthAndYearHeader(prevButton, nextButton), 
			yearsPaginationHeader = generateYearsPaginationHeader(prevButton, nextButton), 
			daysColumns = generateDaysColumns(), 
			days = generateDays(), 
			iterator = function iterator(aRow) {
				toReturn.splice(toReturn.length - 1, 0, aRow);
			};

		monthAndYearHeader.forEach(iterator);
		yearsPaginationHeader.forEach(iterator);
		daysColumns.forEach(iterator);
		days.forEach(iterator);

		return toReturn.join('');
	},
	
	linkingFunction = function linkingFunction($scope, $element, $attrs, commonApi, $window, $compile, $locale, $filter, $interpolate, $timeout, lang) {
		var ctrl = this;
		var element = $element;
		var attr = $attrs;
		var defaultFormat = 'dd/mm/yy';
		
		// get child input
		var selector = '', 
			dateFormat = defaultFormat,
			dateViewFormat = dateFormat,
			thisInput = null,
			hiddenInput = null,
			theCalendar = undefined,
			dateIcon = null,
			clearInput = null,
			defaultPrevButton = '<b class="_720kb-datepicker-default-button">&lang;</b>', 
			defaultNextButton = '<b class="_720kb-datepicker-default-button">&rang;</b>',
			prevButton = "",
			nextButton = "",
			dateDisabledDates = null, 
			date = new Date(),
			datetime = $locale.DATETIME_FORMATS, 
			hours24h = 86400000, 
			htmlTemplate = null,
			unregisterDataSetWatcher = null;

		$scope.isInputClicked = false;
		$scope.isCalenderClicked = false;

		ctrl.$onInit = function() {
			dateFormat = (function() {
				var format = ctrl.dateFormat || defaultFormat;
				
				// hack for already created forms
				if(format == 'dd/MM/yyyy')
					format = defaultFormat;
				
				return format;
			})();
			
			dateViewFormat = ctrl.dateViewFormat || dateFormat;

			// is disabled then force to readonly
			if(ctrl.disable) {
				ctrl.editable = false;
			}
			
			$scope.dateMinLimit = ctrl.dateMinLimit;
			$scope.dateMaxLimit = attr.dateMaxLimit;
			
			$scope.datepickerAppendTo = attr.datepickerAppendTo || 'body';
			
			var isDate = angular.isDate($scope.dateMinLimit);
			if(!isDate && ($scope.dateMinLimit || $scope.dateMinLimit == 0)) {
				var number = Number($scope.dateMinLimit);
				if(angular.isNumber(number)) {
					$scope.dateMinLimit = getMinMaxDate(number);
				} else if(!isDate) {
					try {
						$scope.dateMinLimit = commonApi.parseDate(dateFormat, $scope.dateMinLimit, {lang: ctrl.language ? ctrl.language : false});
					} catch(e) {
						$scope.dateMinLimit = undefined;
					}
				}
			}
			
			isDate = angular.isDate($scope.dateMaxLimit);
			if(!isDate && ($scope.dateMaxLimit || $scope.dateMaxLimit == 0)) {
				var number = Number($scope.dateMaxLimit);
				if(angular.isNumber(number)) {
					$scope.dateMaxLimit = getMinMaxDate(number);
				} else if(!isDate) {
					try {
						$scope.dateMaxLimit = commonApi.parseDate(dateFormat, $scope.dateMaxLimit, {lang: ctrl.language ? ctrl.language : false});
					} catch(e) {
						$scope.dateMaxLimit = undefined;
					}
				} 
			}
			
			// get child input
			selector = attr.selector || 'ang-datepciker';
			thisInput = angular.element(element[0].querySelector('.' + selector));
			hiddenInput = angular.element(element[0].querySelector('.ang-datepciker-hidden'));
			dateIcon = angular.element(element[0].querySelector('.ang-datepicker-icon'));
			clearInput = angular.element(element[0].querySelector('.remove-date'));
			prevButton = attr.buttonPrev || defaultPrevButton;
			nextButton = attr.buttonNext || defaultNextButton; 
			dateDisabledDates = $scope.$eval($scope.dateDisabledDates); 

			// respect previously configured interpolation symbols.
			htmlTemplate = generateHtmlTemplate(prevButton, nextButton);
			htmlTemplate = htmlTemplate.replace(/{{/g, $interpolate.startSymbol()).replace(/}}/g, $interpolate.endSymbol());
		
			$scope.dateMonthTitle = $scope.dateMonthTitle || 'Select month';
			$scope.dateYearTitle = $scope.dateYearTitle || 'Select year';
			$scope.buttonNextTitle = $scope.buttonNextTitle || 'Next';
			$scope.buttonPrevTitle = $scope.buttonPrevTitle || 'Prev';
			$scope.todayTitle = (lang.get("today") || "").toLowerCase() || 'Today';
			$scope.closeTitle = lang.get("close") || 'Close';
			$scope.month = $filter('date')(date, 'MMMM'); // december-November like
			$scope.monthNumber = Number($filter('date')(date, 'MM')); // 01-12 like
			$scope.day = Number($filter('date')(date, 'dd')); // 01-31 like

			if ($scope.dateMaxLimit) {
				$scope.year = Number($filter('date')(new Date($scope.dateMaxLimit), 'yyyy')); // 2014 like
			} else {
				$scope.year = Number($filter('date')(date, 'yyyy')); // 2014 like
			}
			
			$scope.months = datetime.MONTH;
			$scope.daysInString = [ '0', '1', '2', '3', '4', '5', '6' ].map(function mappingFunc(el) {
				return $filter('date')(new Date(new Date('06/08/2014').valueOf() + A_DAY_IN_MILLISECONDS * el), 'EEE');
			});
			
			// can this toggle blur/focus?
			if ($scope.datepickerToggle === 'false') {
				$scope.classForToggle = 'no-toggle';
			}
			
			// create the calendar holder and append where needed
			if ($scope.datepickerAppendTo && $scope.datepickerAppendTo.indexOf('.') !== -1) {
				$scope.datepickerID = 'datepicker-id-' + new Date().getTime() + (Math.floor(Math.random() * 6) + 8);
				angular.element(document.getElementsByClassName($scope.datepickerAppendTo.replace('.', ''))[0])
				.append($compile(angular.element(htmlTemplate))($scope, function afterCompile(el) {
					theCalendar = angular.element(el)[0];
				}));
			} else if ($scope.datepickerAppendTo && $scope.datepickerAppendTo.indexOf('#') !== -1) {
				$scope.datepickerID = 'datepicker-id-' + new Date().getTime() + (Math.floor(Math.random() * 6) + 8);
				angular.element(document.getElementById($scope.datepickerAppendTo.replace('#', '')))
				.append($compile(angular.element(htmlTemplate))($scope, function afterCompile(el) {
					theCalendar = angular.element(el)[0];
				}));
			} else if ($scope.datepickerAppendTo && $scope.datepickerAppendTo === 'body') {
				$scope.datepickerID = 'datepicker-id-' + (new Date().getTime() + (Math.floor(Math.random() * 6) + 8));
				angular.element(document).find('body').append($compile(angular.element(htmlTemplate))($scope,
				function afterCompile(el) {
					theCalendar = angular.element(el)[0];
				}));
			} else {
				element.append($compile(angular.element(htmlTemplate))($scope));
				
				// get the calendar as element
				theCalendar = element[0].querySelector('._720kb-datepicker-calendar');
			}
			
			// some tricky dirty events to fire if click is outside of the calendar
			// and show/hide calendar when needed
			if(!ctrl.disable) {
				thisInput.on('focus click', function onFocusAndClick() {
					showCalendar();
					$scope.isInputClicked = true;
				});
				
				thisInput.on('blur', function onBlurAndFocusOut() {
					if(!$scope.isCalenderClicked) {
						$scope.hideCalendar();
						$scope.isInputClicked = false;
					}
				});
				
				angular.element(theCalendar).on('mousedown', function onMouseEnter() {
					$timeout.cancel(docTimeout);
					$scope.isCalenderClicked = true;
				});
				
				if(navigator.userAgent.indexOf('Trident/') > 0) {
					dateIcon.on('click', function onIconClick() {
						thisInput.focus();
					});
				}
				
				clearInput.on('click', function onClear() {
					thisInput.val('');
					hiddenInput.val('');
					ctrl.dateSet = "";
					ctrl.dateSetVisible = "";
					
					if(navigator.userAgent.indexOf('Trident/') > 0) {
						thisInput.focus();
					}
				});
				
				var docTimeout = undefined;
				angular.element(document).on('click.dp', function onClickOnWindow() {
					if (!$scope.isInputClicked && !$scope.isCalenderClicked && theCalendar) {
						$scope.hideCalendar();
					}
					
					$timeout.cancel(docTimeout);
					docTimeout = $timeout(function() {
						$scope.isCalenderClicked = false;
						$scope.isInputClicked = false;
					}, 0);
				});
				
				angular.element($window).on('keyup.dp', function onEscape(e) {
					if(e.keyCode == 27 || e.which == 27) {
						$scope.hideCalendar();
						$scope.isInputClicked = false;
						$scope.isCalenderClicked = false;
					}
				});
			}

			// check always if given range of dates is ok
			if ($scope.dateMinLimit && !$scope.isSelectableMinYear($scope.year)
				|| !$scope.isSelectableMinDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.day)) {

				resetToMinDate();
			}

			if ($scope.dateMaxLimit && !$scope.isSelectableMaxYear($scope.year)
				|| !$scope.isSelectableMaxDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.day)) {

				resetToMaxDate();
			}

			$scope.paginateYears($scope.year);
			setDaysInMonth($scope.monthNumber, $scope.year);
			
			watch();

			if(ctrl.inline && ctrl.inline == "true"){
				$timeout(function(){
					var parentLable = thisInput[0].parentNode;
					parentLable.classList.add('_720kb-datepicker-input-inline');
					theCalendar.classList.add('_720kb-datepicker-calender-inline');

					showCalendar();
				});
			}
		};
		
		ctrl.$onDestroy = function() {
			unregisterDataSetWatcher && unregisterDataSetWatcher();
			thisInput.off('focus click blur');
			angular.element(document).off('click.dp');
			angular.element($window).off('keyup.dp');
			angular.element(theCalendar).off('mousedown').remove();
		};
		
		var watch = function() {
			unregisterDataSetWatcher = $scope.$watch('$ctrl.dateSet', function dateSetWatcher(newValue, oldValue) {
				var date = "";
				if (newValue) {
					try {
						date = commonApi.parseDate(dateFormat, newValue, {lang: ctrl.language ? ctrl.language : false});
					} catch(e) {
						date = commonApi.tryToParseDate(newValue, dateFormat);
					}
					ctrl.dateSetVisible = commonApi.formatDate(dateViewFormat, date);
				} else {
					date = new Date();
					ctrl.dateSetVisible = "";
				}
				
				if(!date) {
					date = new Date();
				}
				
				$scope.month = $filter('date')(date, 'MMMM'); // december-November
				$scope.monthNumber = Number($filter('date')(date, 'MM')); // 01-12
				$scope.day = Number($filter('date')(date, 'dd')); // 01-31 like
				$scope.year = Number($filter('date')(date, 'yyyy')); // 2014 like

				if(newValue != oldValue && ctrl.dateChange){
					ctrl.dateChange({newDate: newValue});
				}
				
				setDaysInMonth($scope.monthNumber, $scope.year);
			});
		};
		
		var getMinMaxDate = function(number) {
			var today = (new Date()).getTime();
			var target = today + (A_DAY_IN_MILLISECONDS * number);
			return (new Date(target));
		},
		resetToMinDate = function resetToMinDate() {
			$scope.month = $filter('date')(new Date($scope.dateMinLimit), 'MMMM');
			$scope.monthNumber = Number($filter('date')(new Date($scope.dateMinLimit), 'MM'));
			$scope.day = Number($filter('date')(new Date($scope.dateMinLimit), 'dd'));
			$scope.year = Number($filter('date')(new Date($scope.dateMinLimit), 'yyyy'));
		}, 
		resetToMaxDate = function resetToMaxDate() {
			$scope.month = $filter('date')(new Date($scope.dateMaxLimit), 'MMMM');
			$scope.monthNumber = Number($filter('date')(new Date($scope.dateMaxLimit), 'MM'));
			$scope.day = Number($filter('date')(new Date($scope.dateMaxLimit), 'dd'));
			$scope.year = Number($filter('date')(new Date($scope.dateMaxLimit), 'yyyy'));
		},
		resetToDate = function resetToDate(date) {
			if(typeof date == "string") {
				date = commonApi.parseDate(dateFormat, date, {lang: ctrl.language ? ctrl.language : false});
			}
			
			$scope.month = $filter('date')(date, 'MMMM');
			$scope.monthNumber = Number($filter('date')(date, 'MM'));
			$scope.day = Number($filter('date')(date, 'dd'));
			$scope.year = Number($filter('date')(date, 'yyyy'));
		},
		prevYear = function prevYear() {
			var currYear = Number($scope.year);
			if(ctrl.minYearLimit && currYear <= Number(ctrl.minYearLimit) ){
				return;
			}
			$scope.year = currYear - 1;
		}, 
		nextYear = function nextYear() {
			var currYear = Number($scope.year);
			if(ctrl.maxYearLimit && currYear >= Number(ctrl.maxYearLimit) ){
				return;
			}
			$scope.year = Number($scope.year) + 1;
		}, 
		setInputValue = function setInputValue() {
			if ($scope.isSelectableMinDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.day)
				&& $scope.isSelectableMaxDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.day)) {

				var modelDate = new Date();
				modelDate.setDate(1);		// this hack for 31st date issue
				modelDate.setMonth(0);		// this hack for 29th feb date issue
				modelDate.setFullYear($scope.year);
				modelDate.setMonth($scope.monthNumber - 1);
				modelDate.setDate($scope.day);

				if (dateFormat) {
					ctrl.dateSet = commonApi.formatDate(dateFormat, modelDate);
				} else {
					ctrl.dateSet = modelDate;
				}
			} else {
				return false;
			}
		}, 
		classHelper = {
			'add' : function add(ele, klass) {
				var classes;
				if (ele.className.indexOf(klass) > -1) {
					return;
				}

				classes = ele.className.split(' ');
				classes.push(klass);
				ele.className = classes.join(' ');
			},
			'remove' : function remove(ele, klass) {
				var i, classes;
				if (ele.className.indexOf(klass) === -1) {
					return;
				}

				classes = ele.className.split(' ');
				for (i = 0; i < classes.length; i += 1) {
					if (classes[i] === klass) {
						classes = classes.slice(0, i).concat(classes.slice(i + 1));
						break;
					}
				}
				ele.className = classes.join(' ');
			}
		}, 
		showCalendar = function showCalendar() {
			if(ctrl.disable) {
				return;
			}
			
			// lets hide all the latest instances of datepicker
			if(lastOpenCalendar) {
				if (lastOpenCalendar.classList) {
					lastOpenCalendar.classList.remove('_720kb-datepicker-open');
				} else {
					classHelper.remove(lastOpenCalendar, '_720kb-datepicker-open');
				}
			}
			
			lastOpenCalendar = theCalendar;
			
			if($scope.datepickerAppendTo && $scope.datepickerAppendTo === 'body') {
				theCalendar.style.left = '0px';
				theCalendar.style.top = '0px';
			}
			
			try {
				var body = document.body;
				var docElement = document.documentElement;
				var rect = thisInput[0].getBoundingClientRect();
				var bottomDef = body.clientHeight - rect.bottom;
				if(bottomDef < 255) {
					if (theCalendar.classList) {
						theCalendar.classList.add('up');
					} else {
						classHelper.add(theCalendar, 'up');
					}
				} else {
					if (theCalendar.classList) {
						theCalendar.classList.remove('up');
					} else {
						classHelper.remove(theCalendar, 'up');
					}
				}
				
				if($scope.datepickerAppendTo && $scope.datepickerAppendTo === 'body') {
					var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
					var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;
					theCalendar.style.left = (rect.left + hDiff) + 'px';
					theCalendar.style.top = (rect.top + vDiff + 23) + 'px';
				}

				ctrl.onToggle && ctrl.onToggle({open: true});
			} catch(e) {}

			if (theCalendar.classList) {
				theCalendar.classList.add('_720kb-datepicker-open');
			} else {
				classHelper.add(theCalendar, '_720kb-datepicker-open');
			}
			
//			resetToDate(ctrl.dateSet);
//			setDaysInMonth($scope.monthNumber, $scope.year);
		}, 
		setDaysInMonth = function setDaysInMonth(month, year) {
			var i, 
				limitDate = new Date(year, month, 0).getDate(), 
				firstDayMonthNumber = new Date(year + '/' + month + '/' + 1).getDay(), 
				lastDayMonthNumber = new Date(year + '/' + month + '/' + limitDate).getDay(), 
				prevMonthDays = [], 
				nextMonthDays = [], 
				howManyNextDays, 
				howManyPreviousDays, 
				monthAlias;

			$scope.days = [];

			for (i = 1; i <= limitDate; i += 1) {
				$scope.days.push(i);
			}

			// get previous month days is first day in month is not Sunday
			if (firstDayMonthNumber === 0) {
				// no need for it
				$scope.prevMonthDays = [];
			} else {
				howManyPreviousDays = firstDayMonthNumber;
				// get previous month
				if (Number(month) === 1) {
					monthAlias = 12;
				} else {
					monthAlias = month - 1;
				}
				
				// return previous month days
				var aliasDate = new Date(year, monthAlias, 0).getDate();
				for (i = 1; i <= aliasDate; i += 1) {
					prevMonthDays.push(i);
				}
				
				// attach previous month days
				$scope.prevMonthDays = prevMonthDays.slice(-howManyPreviousDays);
			}

			// get next month days is first day in month is not Sunday
			if (lastDayMonthNumber < 6) {
				howManyNextDays = 6 - lastDayMonthNumber;
				
				// return next month days
				for (i = 1; i <= howManyNextDays; i += 1) {
					nextMonthDays.push(i);
				}
				
				// attach previous month days
				$scope.nextMonthDays = nextMonthDays;
			} else {
				// no need for it
				$scope.nextMonthDays = [];
			}
		};

		$scope.nextMonth = function nextMonth() {
			if(!angular.isNumber($scope.monthNumber)){
			$scope.monthNumber=Number($scope.monthNumber)
			}
			if ($scope.monthNumber === 12) {
				$scope.monthNumber = 1;
				// its happy new year
				nextYear();
			} else {
				$scope.monthNumber += 1;
			}

			// check if max date is ok
			if ($scope.dateMaxLimit) {
				if (!$scope.isSelectableMaxDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.days[0])) {
					resetToMaxDate();
				}
			}

			// set next month
			$scope.month = $filter('date')(new Date($scope.year, $scope.monthNumber - 1), 'MMMM');
			// reinit days
			setDaysInMonth($scope.monthNumber, $scope.year);
			// deactivate selected day
			$scope.day = undefined;
		};

		$scope.willPrevMonthBeSelectable = function willPrevMonthBeSelectable() {
			var monthNumber = $scope.monthNumber, year = $scope.year, prevDay = $filter('date')(new Date(new Date(year + '/' + monthNumber + '/01').getTime() - hours24h), 'dd'); 

			// get last day in previous month
			if (monthNumber === 1) {
				monthNumber = 12;
				year = year - 1;
			} else {
				monthNumber -= 1;
			}

			if ($scope.dateMinLimit) {
				if (!$scope.isSelectableMinDate(year + '/' + monthNumber + '/' + prevDay)) {
					return false;
				}
			}

			return true;
		};

		$scope.willNextMonthBeSelectable = function willNextMonthBeSelectable() {
			var monthNumber = $scope.monthNumber, 
				year = $scope.year;

			if (monthNumber === 12) {
				monthNumber = 1;
				year += 1;
			} else {
				monthNumber += 1;
			}

			if ($scope.dateMaxLimit) {
				if (!$scope.isSelectableMaxDate(year + '/' + monthNumber + '/01')) {
					return false;
				}
			}

			return true;
		};

		$scope.prevMonth = function managePrevMonth() {
			if ($scope.monthNumber === 1) {
				$scope.monthNumber = 12;
				// its happy new year
				prevYear();
			} else {
				$scope.monthNumber -= 1;
			}
			// check if min date is ok
			if ($scope.dateMinLimit) {
				if (!$scope.isSelectableMinDate($scope.year + '/' + $scope.monthNumber + '/' + $scope.days[$scope.days.length - 1])) {
					resetToMinDate();
				}
			}
			// set next month
			$scope.month = $filter('date')(new Date($scope.year, $scope.monthNumber - 1), 'MMMM');
			// reinit days
			setDaysInMonth($scope.monthNumber, $scope.year);
			// deactivate selected day
			$scope.day = undefined;
		};

		$scope.selectedMonthHandle = function manageSelectedMonthHandle(selectedMonthNumber) {
			if (!$scope.isSelectableMaxMonth(selectedMonthNumber)) {
				return;
			}

			if (!$scope.isSelectableMinMonth(selectedMonthNumber)) {
				return;
			}
			
			selectedMonthNumber = (selectedMonthNumber + 1) + "";
			if(selectedMonthNumber.length == 1) {
				selectedMonthNumber = "0" + selectedMonthNumber;
			}

			$scope.monthNumber = selectedMonthNumber;
			setDaysInMonth($scope.monthNumber, $scope.year);
			
			$scope.month = $filter('date')(new Date($scope.year, $scope.monthNumber - 1), 'MMMM');
			$scope.showMonths = false;
		};

		$scope.setNewYear = function setNewYear(year) {
			// deactivate selected day
			if (!isMobile) {
				$scope.day = undefined;
			}

			if ($scope.dateMaxLimit && $scope.year < Number(year)) {
				if (!$scope.isSelectableMaxYear(year)) {
					return;
				}
			} else if ($scope.dateMinLimit && $scope.year > Number(year)) {
				if (!$scope.isSelectableMinYear(year)) {
					return;
				}
			}

			$scope.year = Number(year);
			setDaysInMonth($scope.monthNumber, $scope.year);
			$scope.paginateYears(year);
			$scope.showYearsPagination = false;
		};

		$scope.hideCalendar = function hideCalendar() {

			if (theCalendar.classList) {
				theCalendar.classList.remove('_720kb-datepicker-open');
			} else {
				classHelper.remove(theCalendar, '_720kb-datepicker-open');
			}
			
			lastOpenCalendar = null;

			ctrl.onToggle && ctrl.onToggle({open: false});
		};

		$scope.setDatepickerDay = function setDatepickerDay(day, strFlag) {
			var tmpNewYear = $scope.year;
			var tmpNewMonth = $scope.monthNumber;
			
			if(strFlag == 'next'){
				tmpNewYear = $scope.monthNumber == 12 ? $scope.year + 1 : $scope.year;
				tmpNewMonth = $scope.monthNumber == 12 ? 1 : $scope.monthNumber + 1;
			}else if(strFlag == 'prev'){
				tmpNewYear = $scope.monthNumber == 1 ? $scope.year - 1 : $scope.year;
				tmpNewMonth = $scope.monthNumber == 1 ? 12 : $scope.monthNumber - 1;
			}

			if ($scope.isSelectableDate(tmpNewMonth, tmpNewYear, day)
				&& $scope.isSelectableMaxDate(tmpNewYear + '/' + tmpNewMonth + '/' + day)
				&& $scope.isSelectableMinDate(tmpNewYear + '/' + tmpNewMonth + '/' + day)) {
				
				$scope.day = Number(day);
				if(strFlag){
					$scope.year = tmpNewYear;
					$scope.monthNumber = tmpNewMonth;
				}
				setInputValue();

				if (attr.hasOwnProperty('dateRefocus')) {
					thisInput[0].focus();
				}

				$scope.hideCalendar();
			}
		};

		$scope.paginateYears = function paginateYears(startingYear) {
			var i, theNewYears = [], daysToPrepend = 10, daysToAppend = 10;

			$scope.paginationYears = [];
			if (isMobile) {
				daysToPrepend = 50;
				daysToAppend = 50;
				if ($scope.dateMinLimit && $scope.dateMaxLimit) {

					startingYear = new Date($scope.dateMaxLimit)
							.getFullYear();
					daysToPrepend = startingYear
							- new Date($scope.dateMinLimit)
									.getFullYear();
					daysToAppend = 1;
				}
			}


			for (i = daysToPrepend; i > 0; i -= 1) {
				if(ctrl.minYearLimit){
					if( Number(startingYear) - i >=  Number( ctrl.minYearLimit ) ){
						theNewYears.push(Number(startingYear) - i);
					}
				}else{
					theNewYears.push(Number(startingYear) - i);
				}
			}

			for (i = 0; i < daysToAppend; i += 1) {

				if(ctrl.maxYearLimit){
					if( ( Number(startingYear) + i ) <=  Number( ctrl.maxYearLimit ) ){
						theNewYears.push(Number(startingYear) + i);
					}
				}else{
					theNewYears.push(Number(startingYear) + i);
				}
			}
			
			// date typing in input date-typer
			if ($scope.dateTyper === 'true' || ctrl.dateTyper === 'true') {
				thisInput.on('keyup blur', function() {
					if (!thisInput[0].value) 
						return;
					
					try {
						date = commonApi.parseDate(dateViewFormat, thisInput[0].value, {lang: ctrl.language ? ctrl.language : false});
						if (date.getFullYear() && (date.getDay() || date.getDay() == 0) && (date.getMonth() || date.getMonth() == 0)
							&& $scope.isSelectableDate(date) && $scope.isSelectableMaxDate(date) && $scope.isSelectableMinDate(date)) {
							ctrl.dateSet = commonApi.formatDate('dd-M-yy', date);
							
							$scope.$apply(function() {
								$scope.month = $filter('date')(date, 'MMMM'); // december-November
								$scope.monthNumber = Number($filter('date')(date,'MM')); // 01-12 like
								$scope.day = Number($filter('date')(date, 'dd')); // 01-31 like

								if (date.getFullYear().toString().length === 4) {
									$scope.year = Number($filter('date')(date,'yyyy')); // 2014 like
								}
								
								setDaysInMonth($scope.monthNumber, $scope.year);
							});
						}
					} catch (e) {
						window.console && window.console.log("Invalid Date : Error : ", e);
					}
				});
			}
			
			// check range dates
			$scope.paginationYearsNextDisabled = ($scope.dateMaxLimit && theNewYears && theNewYears.length
				&& !$scope.isSelectableMaxYear(Number(theNewYears[theNewYears.length - 1]) + 1));

			$scope.paginationYearsPrevDisabled = ($scope.dateMinLimit && theNewYears && theNewYears.length
				&& !$scope.isSelectableMinYear(Number(theNewYears[0]) - 1));

			$scope.paginationYears = theNewYears;
		};

		$scope.isSelectableDate = function isSelectableDate(monthNumber, year, day) {
			var i = 0;
			if (dateDisabledDates && dateDisabledDates.length > 0) {
				for (i; i <= dateDisabledDates.length; i += 1) {
					if (new Date(dateDisabledDates[i]).getTime() === new Date(monthNumber + '/' + day + '/' + year).getTime()) {
						return false;
					}
				}
			}
			return true;
		};

		$scope.isSelectableMinDate = function isSelectableMinDate(aDate) {
			// if current date
			if (!!$scope.dateMinLimit && !!new Date($scope.dateMinLimit)
				&& new Date(aDate).getTime() < new Date($scope.dateMinLimit).getTime()) {

				return false;
			}

			return true;
		};

		$scope.isSelectableMaxDate = function isSelectableMaxDate(aDate) {
			// if current date
			if (!!$scope.dateMaxLimit && !!new Date($scope.dateMaxLimit)
				&& new Date(aDate).getTime() > new Date($scope.dateMaxLimit).getTime()) {

				return false;
			}

			return true;
		};

		$scope.isSelectableMaxYear = function isSelectableMaxYear(year) {
			if (!!$scope.dateMaxLimit && year > new Date($scope.dateMaxLimit).getFullYear()) {
				return false;
			}

			return true;
		};

		$scope.isSelectableMinYear = function isSelectableMinYear(year) {
			if(!$scope.dateMinLimit) {
				return true;
			}
			
			var minDate = new Date($scope.dateMinLimit.getTime() + A_DAY_IN_MILLISECONDS);
			if (year < minDate.getFullYear()) {
				return false;
			}

			return true;
		};

		$scope.isSelectableMaxMonth = function isSelectableMaxMonth(month) {
			if (!$scope.dateMaxLimit) {
				return true;
			}

			if (!$scope.isSelectableMaxYear($scope.year)) {
				return false;
			}

			var maxDate = new Date($scope.dateMaxLimit);
			if($scope.year == maxDate.getFullYear() && month > maxDate.getMonth()) {
				return false;
			}

			return true;
		};

		$scope.isSelectableMinMonth = function isSelectableMinMonth(month) {
			if(!$scope.dateMinLimit) {
				return true;
			}

			if (!$scope.isSelectableMinYear($scope.year)) {
				return false;
			}

			var minDate = new Date($scope.dateMinLimit.getTime() + A_DAY_IN_MILLISECONDS);
			if($scope.year == minDate.getFullYear() && month < minDate.getMonth()) {
				return false;
			}

			return true;
		};
		
		$scope.setToday = function setToday() {
			resetToDate(new Date());
			setDaysInMonth($scope.monthNumber, $scope.year);
			setInputValue();
			if (attr.hasOwnProperty("dateRefocus")) {
				thisInput[0].focus()
			}
			$scope.hideCalendar()
		};
	};

	mainModule.component('datepicker', {
		'template' : '<label class="ang-date-controls">' +
						'<input ng-model="$ctrl.dateSetVisible" type="text" ng-disabled="$ctrl.disable" ng-readonly="!$ctrl.editable" class="ang-datepciker" ng-required="$ctrl.dateRequired" />' +
						'<input ng-model="$ctrl.dateSet" type="hidden" class="ang-datepciker-hidden" />' +
						'<img ng-show="!$ctrl.hideDateIcon" class="ang-datepicker-icon" src="/images/icons/calendar.png" alt="Select Date" />' +
						'<span ng-show="!$ctrl.disable && $ctrl.dateSetVisible" class="remove-date">' +
							'<img src="/images/htmlform/CWR/remove.png" alt="Remove Date" />' +
						'</span>' +
					'</label>',
		'bindings' : {
			'dateSet' : '=',
			'hideDateIcon' : '@',
			'dateMinLimit' : '<',
			'dateMaxLimit' : '<',
			'dateMonthTitle' : '@',
			'dateYearTitle' : '@',
			'buttonNextTitle' : '@',
			'buttonPrevTitle' : '@',
			'dateDisabledDates' : '@',
			'dateTyper' : '@',
			'datepickerAppendTo' : '@',
			'datepickerToggle' : '@',
			'datepickerClass' : '@',
			'editable' : '@',
			'disable' : '<',
			'dateRequired' : '=',
			'dateName' : '@',
			'dateViewFormat': '@',
			'dateFormat': '@',
			'inline': '@', // default open calendar
			'onToggle' : '&', // calendar toggle Event, i.e open/close
			'dateChange': '&', // Date Change Event 
			'minYearLimit': '<',
			'maxYearLimit': '<',
			'language': '<',
		},
		'controller' : linkingFunction
	});
});