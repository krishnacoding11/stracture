/**
 * Item selection component.
 * This module will initialize the items selection component for angular application.
 * @module itemSelection
 */
define(['angular', 'mainModule'], function (angular, mainModule) {
	'use strict';

	/* *********** Component Format ***********
	[
		{
			optlabel: "Option Group Label",
			options: [
				{
					displayValue: "AAA", 
					modelValue:  "aaa",
					checked: true
				},
				...
			]
		}, 
		...
	]
	********************************************* */

	mainModule.component('itemSelection', {
		template: '<div class="item-holder">' +
			'<button ng-if="!$ctrl.label" type="button" class="btn btn-default text-ellipsis" ng-class="{required: ($ctrl.required && ( ($ctrl.multiple && !$ctrl.selection.length) || (!$ctrl.multiple && !$ctrl.selection )) ), disable: $ctrl.itemdisabled}" ng-click="toggleDropdown()" ng-keydown="searchKeyDown($event)">' +
			'<span class="caret"></span>' +
			'<div class="text-ellipsis" title="{{selectedCheckCode}}">{{selectedCheckCode}}</div>' +
			'<input ng-model="$ctrl.selection" type="text" class="hide" ng-required="$ctrl.required" />' +
			'</button>' +
			'<div class="drop-toggle-label" ng-if="$ctrl.label" ng-click="toggleDropdown()">' +
			'{{$ctrl.label}} ' +
			'</div>' +
			'</div>',
		controller: ['$scope', '$element', '$timeout', '$compile', 'lang', function ($scope, $element, $timeout, $compile, lang) {
			var ctrl = this;

			var drawer_panel = '<div class="item-selection drop-show" ng-class="{open: showDropDown}" id="{{itemSelectionID}}">' +
				'<div class="searchItemsContainer" ng-if="$ctrl.search">' +
				'<input type="text" autocomplete="off" placeholder="Search" class="searchItems" ng-model="search.displayValue" ng-keyup="searchOptions($event,search.displayValue)"  ng-keydown="searchKeyDown($event)"/>' +
				'</div>' +
				'<div class="selectAll" ng-if="$ctrl.multiple && $ctrl.selectAll && !search.displayValue">' +
				'<a href="" ng-click="checkUncheckAllItems(list, true)"> {{ selectAllMsg }} </a>' +
				'<a href="" class="pull-right" ng-click="checkUncheckAllItems(list, false)"> {{ clearAllMsg }} </a>' +
				'</div>' +
				'<div class="itemContainer">' +
				'<div ng-repeat="item in list">' +
				'<label class="optionlabel" ng-if="item.optlabel" ng-bind="item.optlabel"></label>' +
				'<label class="checkboxitem" ng-mouseover="mouseoverOnListItem($parent.$index , $index)" ng-repeat="optitem in item.options" ng-click="onCheckboxChange(optitem)" ng-class="{ selected : isSelected(optitem), focus :  ( $parent.$index == focusObject.groupIndex-1 && focusObject.rowIndex-1 == $index ) }">' +
				'<input ng-if="$ctrl.multiple" type="checkbox" ng-model="optitem.checked">' +
				'<span class="dispVal" ng-bind="optitem.displayValue" title="{{optitem.displayValue}}"></span>' +
				'</label>' +
				'<p class="no-record" ng-if="!item.options.length && !search.displayValue">No Matches</p>' +
				'</div>' +

				'<p class="no-record" ng-if="list.length === 0 && !search.displayValue">No Matches</p>' +
				'<p class="no-record" ng-if="list.length === 0 && search.displayValue">No Search Matches</p>' +
				'</div>' +
				'</div>';

			var objDrawerPanel = null,
				initialDrawerHeight = null,
				thisInput = null;

			ctrl.$onInit = function () {
				$scope.itemSelectionID = '';
				initAndAppendTemplate();
				init();
				bindEvents();
				setTextAsPerLang();
			};

			function setTextAsPerLang() {
				$scope.selectAllMsg = lang.get("select-all") ? lang.get("select-all") : "Select All";
				$scope.clearAllMsg = lang.get("clear_all") ? lang.get("clear_all") : "Clear All";
				$scope.pleaseSelectMsg = lang.get("please-select") ? lang.get("please-select") : "Please Select";
			}

			ctrl.$onChanges = function () {
				init();
			};

			ctrl.$onDestroy = function () {
				$scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
			}

			var KEYS = {
				UP: 38,
				DOWN: 40,
				ENTER: 13,
				ESC: 27
			};

			var IS_ENTER_PRESSED = false;

			var init = function () {
				if (ctrl.list)
					$scope.backuplist = $scope.list = ctrl.list || [];

				$scope.search = { displayValue: "" };

				setAllCheckedItemFalse();
				setAllCheckedFromSelection(ctrl.list, ctrl.selection);

				/* TO highligh row when user use up and down arrow key and mousehover too*/
				$scope.focusObject = {
					groupIndex: 1,
					rowIndex: 1
				}
			};

			var bindEvents = function () {
				$(document).bind("mousedown keyup click", closeDropdown);
			}

			function initAndAppendTemplate() {
				var selectorAppendTo = $element.find('.item-holder');
				if (ctrl.appendTo) {
					selectorAppendTo = angular.element(document).find(ctrl.appendTo);
				}
				$scope.itemSelectionID = 'item-selection-id-' + (new Date().getTime() + (Math.floor(Math.random() * 6) + 8));
				selectorAppendTo.append($compile(angular.element(drawer_panel))($scope,
					function afterCompile(el) {
						objDrawerPanel = angular.element(el)[0];
					}));
			}

			function closeDropdown(e) {
				if(e.type == "mousedown" || e.type == "keyup" || (e.type == "click" && (e.target.classList.contains("richtextbox") || !!angular.element(e.target).closest('.richtextbox').length))){					
					var flg = !$element.has(e.target).length && !angular.element(objDrawerPanel).has(e.target).length;
					if (flg || e.keyCode === KEYS.ESC) {
						if ($scope.showDropDown) {
							$scope.showDropDown = false;
							$scope.$digest();
							setFocusOnButtonControl();
							ctrl.onClose && ctrl.onClose();
						}
					}
				}
			}

			var setAllCheckedItemFalse = function () {
				if (!ctrl.list || !ctrl.list.length)
					return;

				for (var i = 0; i < ctrl.list.length; i++) {
					var listObj = ctrl.list[i].options;
					if (listObj && listObj.length) {
						for (var j = 0; j < listObj.length; j++) {
							listObj[j].checked = false;
						}
					}
				}
			};

			var setAllCheckedFromSelection = function (list, selection) {
				var retStr = (ctrl.defaulttext) ? ctrl.defaulttext : $scope.pleaseSelectMsg;
				if (!list || !list.length || (!ctrl.selection || ctrl.selection.length == 0)) {
					$scope.selectedCheckCode = retStr;
					return;
				}

				for (var k = 0; k < selection.length; k++) {
					var isFound = false;
					for (var i = 0; i < list.length; i++) {
						var listObj = list[i].options;
						if (listObj && listObj.length) {
							for (var j = 0; j < listObj.length; j++) {
								var optObj = listObj[j];
								var optObjCode = optObj.modelValue || optObj.code || optObj[ctrl.checkcodekey] || "";
								if (ctrl.multiple) {
									if (selection[k] == optObjCode) {
										optObj.checked = true;
										isFound = true;
									}
								} else if (selection == optObjCode) {
									optObj.checked = true;
								}
							}
						}
					}
					if (ctrl.multiple && !isFound) {
						selection.splice(k, 1);
						k--;
					}
				}
				$scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
			};

			var getSelectedCheckCodes = function (list, checkcodekey) {
				var retStr = (ctrl.defaulttext) ? ctrl.defaulttext : $scope.pleaseSelectMsg;
				var checkedArr = [];
				if (!list || !list.length)
					return retStr;

				for (var i = 0; i < list.length; i++) {
					var listObj = list[i].options;
					if (listObj && listObj.length) {
						for (var j = 0; j < listObj.length; j++) {
							var optObj = listObj[j];
							if ((ctrl.multiple && optObj.checked) || (ctrl.selection == optObj.modelValue)) {
								var checkedVal = optObj[checkcodekey];
								if (!checkedVal)
									checkedVal = (ctrl.multiple) ? optObj.modelValue : optObj.displayValue;
								checkedArr.push(checkedVal);
							}
						}
					}
				}
				if (checkedArr.length) {
					return checkedArr.join(", ");
				}
				return retStr;
			};

			$scope.mouseoverOnListItem = function (groupInd, rowInd) {
				$scope.focusObject = {
					groupIndex: groupInd + 1,
					rowIndex: rowInd + 1
				}
			}

			$scope.searchKeyDown = function (event) {
				if ($scope.list.length == 0) {
					return;
				}

				//var objItemContainer = $element.find('.itemContainer');
				var objItemContainer = angular.element(objDrawerPanel).find('.itemContainer');
				var currentOffset = objItemContainer.offset().top + objItemContainer.outerHeight(false);

				var currGroupIndex = $scope.focusObject.groupIndex - 1;
				if (event.keyCode == KEYS.ENTER && $scope.showDropDown) {// For Enter key
					IS_ENTER_PRESSED = true;
					var selRowIndex = $scope.focusObject.rowIndex - 1;
					if (ctrl.multiple) {
						$scope.list[currGroupIndex].options[selRowIndex].checked = !$scope.list[currGroupIndex].options[selRowIndex].checked;
					}
					$scope.onCheckboxChange($scope.list[currGroupIndex].options[selRowIndex]);
					return;
				} else if (event.keyCode == KEYS.UP) {// For Up Arrow

					if (1 < $scope.focusObject.rowIndex && $scope.focusObject.rowIndex <= $scope.list[currGroupIndex].options.length) {
						$scope.focusObject.rowIndex--;
					} else if ($scope.list[currGroupIndex - 1]) {
						var previosIndex = getPreviousGroupIndex(currGroupIndex);
						if (previosIndex > -1) {
							$scope.focusObject.rowIndex = $scope.list[previosIndex].options.length;
							$scope.focusObject.groupIndex = previosIndex + 1;
						}
					}
					event.preventDefault();
				} else if (event.keyCode == KEYS.DOWN) { // For Down Arrow

					if ($scope.focusObject.rowIndex < $scope.list[currGroupIndex].options.length) {
						$scope.focusObject.rowIndex++;
					} else if ($scope.list[currGroupIndex + 1]) {
						var nextIndex = getNextGroupIndex($scope.focusObject.groupIndex);
						if (nextIndex > 0) {
							$scope.focusObject.rowIndex = 1;
							$scope.focusObject.groupIndex = nextIndex;
						}
					}
					event.preventDefault();
				}

				$timeout(function () {
					var $next = objItemContainer.find('.focus');
					var nextOffset = $next.offset();
					var nextBottom = (nextOffset && nextOffset.top) + (2 * $next.outerHeight(false));
					var nextOffset = objItemContainer.scrollTop() + (nextBottom - currentOffset);

					if ($scope.focusObject.groupIndex === 1 && $scope.focusObject.rowIndex === 1) {
						objItemContainer.scrollTop(0);
					} else if (nextBottom > currentOffset || nextBottom > (currentOffset - 200)) {
						objItemContainer.scrollTop(nextOffset);
					}
				});
			}

			function getNextGroupIndex(currGroupIndex) {
				if ($scope.list[currGroupIndex]) {
					if ($scope.list[currGroupIndex].options.length > 0) {
						currGroupIndex++;
						return currGroupIndex
					} else {
						currGroupIndex++;
						return getNextGroupIndex(currGroupIndex);
					}
				} else {
					return -1
				}
			}

			function getPreviousGroupIndex(currGroupIndex) {
				currGroupIndex--;
				if ($scope.list[currGroupIndex]) {
					if ($scope.list[currGroupIndex].options.length > 0) {
						return currGroupIndex
					} else {
						return getPreviousGroupIndex(currGroupIndex);
					}
				} else {
					return -1
				}
			}

			$scope.searchOptions = function (event, searchKey) {
				var restictKey = [KEYS.ENTER, KEYS.UP, KEYS.DOWN]; // Enter key , Up arrow key and down arrow key, becuase it used to manage list focus and down key selection
				if (event && restictKey.indexOf(event.keyCode) == -1) {
					$scope.focusObject = {
						groupIndex: 1,
						rowIndex: 1
					}
				}

				if (searchKey == "") {
					$scope.list = $scope.backuplist;
				} else {
					var searchArray = [];
					var list = $scope.backuplist
					for (var i = 0; i < list.length; i++) {
						var listOpt = list[i].options;
						if (listOpt && listOpt.length) {
							var matchedOptionsArr = [];
							for (var j = 0; j < listOpt.length; j++) {
								var dispValue = listOpt[j].displayValue.toLowerCase();
								if (dispValue.indexOf(searchKey.toLowerCase()) !== -1) {
									matchedOptionsArr.push(listOpt[j])
								}
							}
							if (matchedOptionsArr.length) {
								searchArray.push({
									optlabel: list[i].optlabel,
									options: matchedOptionsArr
								});
							}
						}
					}
					$scope.list = searchArray;
				}
				
				$timeout(function () {
					ctrl.appendTo && setPositionOfDrawer();
				}, 200);
			}

			$scope.toggleDropdown = function () {
				if (ctrl.itemdisabled || IS_ENTER_PRESSED) {
					IS_ENTER_PRESSED = false;
					return;
				}

				if (!$scope.showDropDown) {

					ctrl.appendTo && setPositionOfDrawer();

					ctrl.onOpen && ctrl.onOpen();
					$scope.search = { displayValue: "" };
					$scope.searchOptions(null, "");
					$scope.focusObject = {
						groupIndex: 1,
						rowIndex: 1
					}
				}

				$scope.showDropDown = !$scope.showDropDown;

				//Focus on search				
				if ($scope.showDropDown && ctrl.search) {
					setFocusOnSearchControl();
				}
			};

			/**
			 * Function used to set position of drawer
			 */
			 function setPositionOfDrawer(){
				thisInput = $element.find('.item-holder .btn');
				var drpdownTopOffset =  $element[0].offsetTop +35+"px";
				var position = $element[0].getAttribute("open");
				var body = document.body;
				var docElement = document.documentElement;
				var rect = thisInput[0].getBoundingClientRect();

				if(!initialDrawerHeight){
					objDrawerPanel.style.top = "-999px";
					objDrawerPanel.style.display = 'block';
					initialDrawerHeight = objDrawerPanel.clientHeight || 180;
					objDrawerPanel.style.cssText = "";
				}
				var drawerHeight = objDrawerPanel.clientHeight || initialDrawerHeight;
				var bottomDef = body.clientHeight - rect.bottom;
				
				if(ctrl.sameDropdownWidth){
					objDrawerPanel.style.width = (rect.width) + 'px';
					angular.element(objDrawerPanel).find('.searchItems').css('min-width', 'auto')
				}
				
				var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
				var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;
				objDrawerPanel.style.left = (rect.left + hDiff) + 'px';

				if(position && position == "bottom" && drpdownTopOffset)
				objDrawerPanel.style.top = $element[0].offsetTop + 35 + 'px';
				else
				objDrawerPanel.style.top = (rect.top + vDiff + (bottomDef-vDiff < 450 ? -drawerHeight : 23 )) + 'px';
			}

			$scope.checkUncheckAllItems = function (list, isCheckAll) {
				for (var i = 0; i < list.length; i++) {
					var listObj = list[i].options;
					if (listObj && listObj.length) {
						for (var j = 0; j < listObj.length; j++) {
							listObj[j].checked = isCheckAll;
							$scope.onCheckboxChange(listObj[j]);
						}
					}
				}
			};


			/** TO set focus on button control when dropdown closed,
			 * It help user to navigate next form control using tab key
			 */
			function setFocusOnButtonControl() {
				$timeout(function () {
					$element.find('.btn').focus();
				}, 50)
			}


			/** TO set focus on search input ,
			 * It help user to search in list data while open drawer list
			 */
			function setFocusOnSearchControl() {
				$timeout(function () {
					var objItemContainer = angular.element(objDrawerPanel).find('.itemContainer');
					objItemContainer.scrollTop(0);
					angular.element(objDrawerPanel).find('.searchItems').focus();
				}, 50)
			}

			/* Return true or false , to add selected class on row */
			$scope.isSelected = function (optitem) {
				if (ctrl.multiple) {
					return ctrl.selection && ctrl.selection.length > 0 && optitem.modelValue.length > 0 && ctrl.selection.indexOf(optitem.modelValue) > -1 ? true : false;
				} else {
					return ctrl.selection && ctrl.selection.length > 0 && optitem.modelValue.length > 0 && ctrl.selection == optitem.modelValue ? true : false;
				}
			}

			$scope.onCheckboxChange = function (optitem) {
				if (!ctrl.selection)
					ctrl.selection = (ctrl.multiple) ? [] : "";

				if (ctrl.multiple) {
					if(typeof ctrl.selection == "string"){
						ctrl.selection = ctrl.selection.split();
					}
					if (optitem.checked) {
						ctrl.selection.push(optitem.modelValue);
					} else {
						var index = ctrl.selection.indexOf(optitem.modelValue);
						if (index !== -1) {
							ctrl.selection.splice(index, 1);
						}
					}
					ctrl.selection = _.uniq(ctrl.selection, function (item, key, a) {
						return item;
					});
				} else {
					setAllCheckedItemFalse();
					optitem.checked = true;
					ctrl.selection = optitem.modelValue;
					$scope.showDropDown = false;
					setFocusOnButtonControl();
				}

				$timeout(function () {
					IS_ENTER_PRESSED = false;
					ctrl.onSelectionChange && ctrl.onSelectionChange({ item: optitem });
				});

				$scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
				
				//setFocusOnSearchControl();
			};
			$scope.$watch('$ctrl.selection', function () {				
				$scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
			}, true);
		}],
		bindings: {
			list: '<',
			label: '@',				//To show label text. If false or undefined, then show button (checkcodekey should be blank if label is defined)
			selection: '=',			//for binding the ng-model value
			multiple: '<',			//Is for single check or for multiple check(i.e. show checkbox)
			selectAll: '<',			//Is selectAll/ClearAll required
			search: '<',			//Is search inputbox required?
			defaulttext: '@',
			checkcodekey: '@',		//value to display on button
			required: "@",			//Check if value is required
			itemdisabled: "<",		//Check if button is disabled
			onSelectionChange: '&',	//call function onchange of value
			onOpen: '&',
			appendTo: '@' ,         //Define this attribute when you need to change default append[pass css selector as argument]
			onClose:'&',				//call function onClose of toggleDropdown
			sameDropdownWidth: '<'      // set control's width to dropdown
		}
	});
});

