/**
 * Custom Dropdown component.
 * This module will initialize the custom dropdown component for angular application.
 * @module customDropdown
 */
require(['angular', 'mainModule'], function (angular, mainModule) {
    'use strict';

    /* *********** Component Format ***********
    [
        {
            optlabel: "Option Group Label",
            options: [
                {
                    displayValue: "AAA", 
                    modelValue:  "aaa",
                    checked: true
                },
                ...
            ]
        }, 
        ...
    ]

    <!----------------------------------------------------------------------------------------!>
    **Example-1**: show drop-down with comma seprated field with default-text="Please select..."
    <custom-dropdown list="tempStationList" selection="oriMsgCustomFields.tempData"
	    defaulttext="Please Select..." checkcodekey="code" append-to="body" required="true"">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>

    <!----------------------------------------------------------------------------------------!>
    **Example-2**: if label is not defined && "show-item-counter='true'" && show drop-down with default-text="Please select...".
    <custom-dropdown list="tempStationList" selection="oriMsgCustomFields.stationData" 
        show-item-counter="true" defaulttext="Please Select..." search="true" checkcodekey="code"
		append-to="body" select-all="true" max-item-length="10" required="true">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>

    <!----------------------------------------------------------------------------------------!>
    **Example-3**: if label && "show-item-counter='true'" && maxItemLength define then show list of maxlength size if not default value is "10"
    <custom-dropdown list="tempStationList" label="Station Name" selection="oriMsgCustomFields.stationData" 
        show-item-counter="true" defaulttext="Please Select..." search="true" checkcodekey="code"
        max-item-length="15" append-to="body" select-all="true" max-item-length="10" required="true">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>

    <!----------------------------------------------------------------------------------------!>
    **Example-4**: if label is define && "show-item-counter='true'".
    <custom-dropdown list="tempStationList" label="Station Name" selection="oriMsgCustomFields.stationData" 
        show-item-counter="true" defaulttext="Please Select..." search="true" checkcodekey="code"
		append-to="body" select-all="true" max-item-length="10" required="true">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>

    <!----------------------------------------------------------------------------------------!>
    **Example-5**: if label is define && "show-item-counter='true'" && "show-item-in-chips='true'".
    <custom-dropdown list="tempStationList" selection="oriMsgCustomFields.stationData" 
        show-item-counter="true" defaulttext="Please Select..." search="true" checkcodekey="code"
		append-to="body" select-all="true" max-item-length="10" required="true">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>

    <!----------------------------------------------------------------------------------------!>
    **Example-6**: if label is define && "show-item-counter='true'" && "show-item-in-chips='true'" apply manual property for (counter & chips).
    <custom-dropdown list="tempStationList" selection="oriMsgCustomFields.stationData" 
        show-item-counter="true" defaulttext="Please Select..." search="true" checkcodekey="code"
        selected-chip-fg-color="'#000'" selected-chip-bg-color="'rgb(239 229 81)'" counter-fg-color="'aqua'" counter-bg-color="'#000'"
		append-to="body" select-all="true" max-item-length="10" required="true">
	</custom-dropdown>
    <!----------------------------------------------------------------------------------------!>
    *****************************************************************************/

    mainModule.component('customDropdown', {
        template: '<div class="custom-item-holder">' +
            '<button ng-if="$ctrl.showItemCounter" aria-expanded="false" aria-haspopup="true" ng-class="{required: ($ctrl.required && ( ($ctrl.multiple && !$ctrl.selection.length) || (!$ctrl.multiple && !$ctrl.selection )) ), disable: $ctrl.itemdisabled}" class="btn btn-default text-ellipsis" type="button" tabindex="0" ng-click="toggleDropdown()" ng-keydown="searchKeyDown($event)">' +
            '<span class="caret"></span>' +
            '<div id="filterList">' +
            '<span ng-if="!$ctrl.label">'+
            '<span ng-if="!setCheckedItem.length">{{selectedCheckCode}}</span>' +
            '<span ng-if="setCheckedItem.length == 1">Selected item</span>'+
            '<span ng-if="setCheckedItem.length > 1">Selected item(s)</span>'+
            '</span>'+
            '<span class="custom-label item-overflow label-width" ng-if="$ctrl.label">{{$ctrl.label}}</span>'+
            '<span class="filter-icon-size" ng-if="$ctrl.iconForLabel" ng-bind-html="$ctrl.iconForLabel"></span>'+
            '<span class="item-counter-main-section" id="listItemCounter" ng-if="$ctrl.showItemCounter && setCheckedItem.length">' +
            '<span class="counter-item-property counter-background item-text-color" ng-if="$ctrl.showItemCounter && setCheckedItem.length" ng-style="{'+"'background-color'"+': $ctrl.counterBgColor,'+"'color'"+': $ctrl.counterFgColor}" title="{{selectedCheckCode}}">{{setCheckedItem.length}}</span>' +
            '</span>' +
            '</div>' +
            '</button>' +
            '<button ng-if="!$ctrl.showItemCounter" type="button" class="btn btn-default text-ellipsis" ng-class="{required: ($ctrl.required && ( ($ctrl.multiple && !$ctrl.selection.length) || (!$ctrl.multiple && !$ctrl.selection )) ), disable: $ctrl.itemdisabled}" ng-click="toggleDropdown()" ng-keydown="searchKeyDown($event)">' +
			'<span class="caret"></span>' +
			'<div class="text-ellipsis" title="{{selectedCheckCode}}">{{selectedCheckCode}}</div>' +
			'<input ng-model="$ctrl.selection" type="text" class="hide" ng-required="$ctrl.required" />' +
			'</button>' +
            '</div>',
        controller: ['$scope', '$element', '$timeout', '$compile', 'lang', function ($scope, $element, $timeout, $compile, lang) {
        var ctrl = this;

        var drawer_panel = '<div class="custom-dropdown drop-show" ng-class="{open: showDropDown}" id="{{customDropdownID}}">' +   
            '<div class="chip-item-conatiner" ng-if="$ctrl.showItemInChips && setCheckedItem.length">' +
            '<div class="chip-item-box-height">' +
            '<div class="multiple-item-flex" ng-style="{'+"'background-color'"+': $ctrl.selectedChipBgColor}" ng-repeat="listItem in setCheckedItem">' +
            '<div class="mutiple-item-overflow">' +
            '<div role="presentation">' +
            '<div class="chip-item-flex" id="selectedChipItem">' +
            '<div class="item-overflow item-text-color" ng-style="{'+"'color'"+': $ctrl.selectedChipFgColor}">{{listItem.displayValue}}</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="close-item-container">' +
            '<div aria-hidden="true">' +
            '<span role="img" aria-label="clear" class="close-item-inline">' +
            '<i class="fa fa-close item-text-color" ng-style="{'+"'color'"+': $ctrl.selectedChipFgColor}" aria-hidden="true" ng-click="onCheckboxChange(listItem, true);"></i>'+
            '</span>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'+
            '<div class="search-items" ng-if="$ctrl.search">' +
            '<input type="text" class="form-control searchItems" placeholder="Search" ng-model="search.displayValue" ng-keyup="searchOptions($event, search.displayValue)" ng-keydown="searchKeyDown($event)" id="searchTextFilter" title="search" autocomplete="off"/>' +
            '<i class="fa fa-search positon-search" title="Search Categories"></i>' +
            '</div>' + 
            '<div class="selectAll align-link" ng-if="$ctrl.multiple && $ctrl.selectAll && !search.displayValue">' +
            '<a href="" class="pull-left" ng-click="checkUncheckAllItems(list, true)"> {{ selectAllMsg }} </a>' +
            '<a href="" class="pull-right" ng-click="checkUncheckAllItems(list, false)"> {{ clearAllMsg }} </a>' +
            '<a href="" ng-class="{hide : isAllDataRetrived}" class="showall-block" ng-click="showAllListData(list);"> {{ showAllMsg }} </a>' +
            '</div>' +
            '<div class="itemContainer clearItem">' +
            '<div ng-repeat="item in sliceList">' +
            '<label class="optionlabel label-size" ng-if="item.optlabel" ng-bind="item.optlabel"></label>' +
            '<label class="item-uib-row" ng-mouseover="mouseoverOnListItem($parent.$index , $index)" ng-repeat="optitem in item.options" ng-class="{ selected : isSelected(optitem), focus :  ( $parent.$index == focusObject.groupIndex-1 && focusObject.rowIndex-1 == $index ) }">' +
            '<a href="javascript:void(0)" class="name ripple" title="{{optitem.displayValue}}" ng-if="!optitem.hide">' +
            '<label class="catListLabel">' +
            '<input type="checkbox" class="checkmark" ng-click="onCheckboxChange(optitem)" ng-model="optitem.checked" ng-disabled="optitem.disabled" />' +
            '<span ng-style="{color : optitem.selectedCheckColor}"></span>' +
            '<div class="align-list-name" ng-bind="optitem.displayValue" title="{{optitem.displayValue}}"></div>' +
            '</label>' +
            '</label>' +
            '<p class="no-record" ng-if="!item.options.length && !search.displayValue">No Matches</p>' +
            '</div>' +
            '<p class="no-record" ng-if="sliceList.length === 0 && !search.displayValue">No Matches</p>' +
            '<p class="no-record" ng-if="sliceList.length === 0 && search.displayValue">No Search Matches</p>' +
            '</div>' +
            '</div>';

        var objDrawerPanel = null,
            initialDrawerHeight = null,
            thisInput = null;

        $scope.searchTextEnabled = false;
        $scope.isAllDataRetrived = false;

        ctrl.$onInit = function () {
            $scope.customDropdownID = '';
            initAndAppendTemplate();
            init();
            bindEvents();
            setTextAsPerLang();
        };

        /**Fn is used to set text as per language. */
        function setTextAsPerLang() {
            $scope.selectAllMsg = lang.get("select-all") ? lang.get("select-all") : "Select All";
            $scope.clearAllMsg = lang.get("clear_all") ? lang.get("clear_all") : "Clear All";
            $scope.showAllMsg = lang.get("show-all") ? lang.get("show-all") : "Show All";
            $scope.pleaseSelectMsg = lang.get("please-select") ? lang.get("please-select") : "Please Select";
        }

        ctrl.$onChanges = function () {
            init();
        };

        ctrl.$onDestroy = function () {
            $scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
        }

        var KEYS = {
            UP: 38,
            DOWN: 40,
            ENTER: 13,
            ESC: 27
        };

        var IS_ENTER_PRESSED = false;

        /**Init function used to initailze maxlengh && slice list.*/
        var init = function () {
            if (ctrl.list){
                $scope.backuplist = $scope.list = ctrl.list || [];
                ctrl.maxItemLength = ctrl.maxItemLength || 10;
                ctrl.multiple = ctrl.multiple || "true";
            } 
            if (ctrl.maxItemLength){
                var arrayList = [], userDefinedList = [];
                for(var i=0; i<$scope.list.length; i++){
                    var listCounter = 1;
                    arrayList = $scope.list[i].options;
                    userDefinedList.push({
                        optlabel : $scope.list[i].optlabel,
                        options: []
                    });
                    for(var j=0; j<arrayList.length; j++){
                        if(listCounter <= ctrl.maxItemLength){
                            if(userDefinedList && userDefinedList[i].optlabel){
                                userDefinedList[i].options.push(arrayList[j]);
                            }
                            listCounter++;
                        }
                    }
                }
                $scope.sliceList = angular.copy(userDefinedList);
                $scope.backUpUserList =  $scope.sliceList;
            }
               
            $scope.search = { displayValue: "" };

            setAllCheckedItemFalse();
            setAllCheckedFromSelection(ctrl.list, ctrl.selection);

            /* TO highligh row when user use up and down arrow key and mousehover too*/
            $scope.focusObject = {
                groupIndex: 1,
                rowIndex: 1
            }
        }

        /**Bind event function used to close dropdown when following mention event in function is called. */
        var bindEvents = function () {
            $(document).bind("mousedown keyup click", closeDropdown);
        }

        /**Fn is used to append dropdown body and assiging dropdown Id. */
        function initAndAppendTemplate() {
            var selectorAppendTo = $element.find('.custom-item-holder');
            if (ctrl.appendTo) {
                selectorAppendTo = angular.element(document).find(ctrl.appendTo);
            }
            $scope.customDropdownID = 'custom-dropdown-id-' + (new Date().getTime() + (Math.floor(Math.random() * 6) + 8));
            selectorAppendTo.append($compile(angular.element(drawer_panel))($scope,
                function afterCompile(el) {
                    objDrawerPanel = angular.element(el)[0];
                }));
        }

        /**Fn is used to close the dropdown. */
        function closeDropdown(e) {
            if (e.type == "mousedown" || e.type == "keyup" || (e.type == "click" && (e.target.classList.contains("richtextbox") || !!angular.element(e.target).closest('.richtextbox').length))) {
                var flg = !$element.has(e.target).length && !angular.element(objDrawerPanel).has(e.target).length;
                if (flg || e.keyCode === KEYS.ESC) {
                    if ($scope.showDropDown) {
                        $scope.showDropDown = false;
                        $scope.$digest();
                        setFocusOnButtonControl();
                        ctrl.onClose && ctrl.onClose();
                    }
                }
            }
        }

        /**Initally set all list items as "checked":false */
        var setAllCheckedItemFalse = function () {
            if (!ctrl.list || !ctrl.list.length)
                return;

            for (var i = 0; i < ctrl.list.length; i++) {
                var listObj = ctrl.list[i].options;
                if (listObj && listObj.length) {
                    for (var j = 0; j < listObj.length; j++) {
                        listObj[j].checked = false;
                    }
                }
            }
        };

        /**Fn is used to checked item from form selection. */
        var setAllCheckedFromSelection = function (list, selection) {
            var retStr = (ctrl.defaulttext) ? ctrl.defaulttext : $scope.pleaseSelectMsg;
            if (!list || !list.length || (!ctrl.selection || ctrl.selection.length == 0)) {
                $scope.selectedCheckCode = retStr;
                return;
            }

            for (var k = 0; k < selection.length; k++) {
                var isFound = false;
                for (var i = 0; i < list.length; i++) {
                    var listObj = list[i].options;
                    if (listObj && listObj.length) {
                        for (var j = 0; j < listObj.length; j++) {
                            var optObj = listObj[j];
                            var optObjCode = optObj.modelValue || optObj.code || optObj[ctrl.checkcodekey] || "";
                            if (ctrl.multiple) {
                                if (selection[k] == optObjCode) {
                                    optObj.checked = true;
                                    isFound = true;
                                }
                            } else if (selection == optObjCode) {
                                optObj.checked = true;
                            }
                        }
                    }
                }
                if (ctrl.multiple && !isFound) {
                    selection.splice(k, 1);
                    k--;
                }
            }
            $scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
        };

        /**Fn is used to return selected item code, counter increment && push them in array */
        var getSelectedCheckCodes = function (list, checkcodekey) {
            var retStr = (ctrl.defaulttext) ? ctrl.defaulttext : $scope.pleaseSelectMsg;
            var checkedArr = [];
            $scope.setCheckedItem = [];
            if (!list || !list.length)
                return retStr;

            for (var i = 0; i < list.length; i++) {
                var listObj = list[i].options;
                if (listObj && listObj.length) {
                    for (var j = 0; j < listObj.length; j++) {
                        var optObj = listObj[j];
                        if ((ctrl.multiple && optObj.checked) || (ctrl.selection == optObj.modelValue)) {
                            var checkedVal = optObj[checkcodekey];
                            if (!checkedVal)
                                checkedVal = (ctrl.multiple) ? optObj.modelValue : optObj.displayValue;
                            checkedArr.push(checkedVal);
                            $scope.setCheckedItem.push(optObj);
                        }
                    }
                }
            }

            if (checkedArr.length) {
                return checkedArr.join(", ");
            }
            return retStr;
        };

        /**Fn is used for focus on list item. */
        $scope.mouseoverOnListItem = function (groupInd, rowInd) {
            $scope.focusObject = {
                groupIndex: groupInd + 1,
                rowIndex: rowInd + 1
            }
        }

        /**Fn is used when user type any string in search box. */
        $scope.searchKeyDown = function (event) {
            if ($scope.list.length == 0) {
                return;
            }

            //var objItemContainer = $element.find('.itemContainer');
            var objItemContainer = angular.element(objDrawerPanel).find('.itemContainer');
            var currentOffset = objItemContainer.offset().top + objItemContainer.outerHeight(false);

            var currGroupIndex = $scope.focusObject.groupIndex - 1;
            if (event.keyCode == KEYS.ENTER && $scope.showDropDown) {// For Enter key
                IS_ENTER_PRESSED = true;
                var selRowIndex = $scope.focusObject.rowIndex - 1;
                if (ctrl.multiple) {
                    $scope.list[currGroupIndex].options[selRowIndex].checked = !$scope.list[currGroupIndex].options[selRowIndex].checked;
                }
                $scope.onCheckboxChange($scope.list[currGroupIndex].options[selRowIndex]);
                return;
            } else if (event.keyCode == KEYS.UP) {// For Up Arrow

                if (1 < $scope.focusObject.rowIndex && $scope.focusObject.rowIndex <= $scope.list[currGroupIndex].options.length) {
                    $scope.focusObject.rowIndex--;
                } else if ($scope.list[currGroupIndex - 1]) {
                    var previosIndex = getPreviousGroupIndex(currGroupIndex);
                    if (previosIndex > -1) {
                        $scope.focusObject.rowIndex = $scope.list[previosIndex].options.length;
                        $scope.focusObject.groupIndex = previosIndex + 1;
                    }
                }
                event.preventDefault();
            } else if (event.keyCode == KEYS.DOWN) { // For Down Arrow

                if ($scope.focusObject.rowIndex < $scope.list[currGroupIndex].options.length) {
                    $scope.focusObject.rowIndex++;
                } else if ($scope.list[currGroupIndex + 1]) {
                    var nextIndex = getNextGroupIndex($scope.focusObject.groupIndex);
                    if (nextIndex > 0) {
                        $scope.focusObject.rowIndex = 1;
                        $scope.focusObject.groupIndex = nextIndex;
                    }
                }
                event.preventDefault();
            }

            $timeout(function () {
                var $next = objItemContainer.find('.focus');
                var nextOffset = $next.offset();
                var nextBottom = (nextOffset && nextOffset.top) + (2 * $next.outerHeight(false));
                var nextOffset = objItemContainer.scrollTop() + (nextBottom - currentOffset);

                if ($scope.focusObject.groupIndex === 1 && $scope.focusObject.rowIndex === 1) {
                    objItemContainer.scrollTop(0);
                } else if (nextBottom > currentOffset || nextBottom > (currentOffset - 200)) {
                    objItemContainer.scrollTop(nextOffset);
                }
            });
        }

        /**Fn is used  in search key down event for next group index.*/
        function getNextGroupIndex(currGroupIndex) {
            if ($scope.list[currGroupIndex]) {
                if ($scope.list[currGroupIndex].options.length > 0) {
                    currGroupIndex++;
                    return currGroupIndex
                } else {
                    currGroupIndex++;
                    return getNextGroupIndex(currGroupIndex);
                }
            } else {
                return -1
            }
        }

         /**Fn is used  in search key down event for previous group index.*/
        function getPreviousGroupIndex(currGroupIndex) {
            currGroupIndex--;
            if ($scope.list[currGroupIndex]) {
                if ($scope.list[currGroupIndex].options.length > 0) {
                    return currGroupIndex
                } else {
                    return getPreviousGroupIndex(currGroupIndex);
                }
            } else {
                return -1
            }
        }

        /**Fn is used when user searchs any string then list automatically update in UI based on Input string. */
        $scope.searchOptions = function (event, searchKey) {
            var restictKey = [KEYS.ENTER, KEYS.UP, KEYS.DOWN]; // Enter key , Up arrow key and down arrow key, becuase it used to manage list focus and down key selection
            if (event && restictKey.indexOf(event.keyCode) == -1) {
                $scope.focusObject = {
                    groupIndex: 1,
                    rowIndex: 1
                }
            }

            if (searchKey == "") {
                // $scope.list = $scope.backuplist;
                // $scope.sliceList =  $scope.backUpUserList;

                if($scope.sliceList.length == 0){
                    for(var s=0; s<$scope.list.length; s++){
                        $scope.sliceList.push({
                            optlabel : $scope.list[s].optlabel,
                            options: []
                        });
                    }
                }
                for(var k=0; k<$scope.sliceList.length; k++){
                    if($scope.sliceList[k].options){
                        $scope.sliceList[k].options = [];
                    }
                }
                
                for(var i=0; i<$scope.list.length; i++){
                    for(var j=0; j<$scope.list[i].options.length; j++){
                        if($scope.list[i].options[j].checked){
                            $scope.sliceList[i].options.push({
                                "displayValue":$scope.list[i].options[j].displayValue,
                                "modelValue":$scope.list[i].options[j].modelValue,
                                "checked":$scope.list[i].options[j].checked
                            });
                        }
                    }
                }
                for(var m=0; m<$scope.list.length; m++){
                    var count = 1;
                    for(var n=0; n<$scope.list[m].options.length; n++){
                        if(!$scope.list[m].options[n].checked && count <= ctrl.maxItemLength){
                            $scope.sliceList[m].options.push({
                                "displayValue":$scope.list[m].options[n].displayValue,
                                "modelValue":$scope.list[m].options[n].modelValue,
                                "checked":$scope.list[m].options[n].checked
                            });
                            count ++;
                        }
                    }
                }
            } else {
                var searchArray = [];
                var list = $scope.backuplist;
                // var list = $scope.backupSliceList;
                for (var i = 0; i < list.length; i++) {
                    var listOpt = list[i].options;
                    if (listOpt && listOpt.length) {
                        var matchedOptionsArr = [];
                        for (var j = 0; j < listOpt.length; j++) {
                            var dispValue = listOpt[j].displayValue.toLowerCase();
                            if (dispValue.indexOf(searchKey.toLowerCase()) !== -1) {
                                matchedOptionsArr.push(listOpt[j])
                            }
                        }
                        if (matchedOptionsArr.length) {
                            searchArray.push({
                                optlabel: list[i].optlabel,
                                options: matchedOptionsArr
                            });
                        }
                    }
                }
                // $scope.list = searchArray;
                $scope.sliceList = searchArray;
            }

            $timeout(function () {
                ctrl.appendTo && setPositionOfDrawer();
            }, 200);
        }

        /**Toggle event of dropdown when user click on dropdown. */
        $scope.toggleDropdown = function () {
            if (ctrl.itemdisabled || IS_ENTER_PRESSED) {
                IS_ENTER_PRESSED = false;
                return;
            }

            if (!$scope.showDropDown) {
                $scope.isAllDataRetrived = false;
                ctrl.appendTo && setPositionOfDrawer();

                ctrl.onOpen && ctrl.onOpen();
                $scope.search = { displayValue: "" };
                $scope.searchOptions(null, "");
                $scope.focusObject = {
                    groupIndex: 1,
                    rowIndex: 1
                }
            }

            $scope.showDropDown = !$scope.showDropDown;

            //Focus on search				
            if ($scope.showDropDown && ctrl.search) {
                setFocusOnSearchControl();
            }
        };

        /**
         * Function used to set position of drawer
         */
        function setPositionOfDrawer() {
            thisInput = $element.find('.custom-item-holder .btn');
            var drpdownTopOffset = $element[0].offsetTop + 35 + "px";
            var position = $element[0].getAttribute("open");
            var body = document.body;
            var docElement = document.documentElement;
            var rect = thisInput[0].getBoundingClientRect();

            if (!initialDrawerHeight) {
                objDrawerPanel.style.top = "-999px";
                objDrawerPanel.style.display = 'block';
                initialDrawerHeight = objDrawerPanel.clientHeight || 180;
                objDrawerPanel.style.cssText = "";
            }
            var drawerHeight = objDrawerPanel.clientHeight || initialDrawerHeight;
            var bottomDef = body.clientHeight - rect.bottom;

            if (ctrl.sameDropdownWidth) {
                objDrawerPanel.style.width = (rect.width) + 'px';
                angular.element(objDrawerPanel).find('.searchItems').css('min-width', 'auto')
            }

            var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
            var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;
            objDrawerPanel.style.left = (rect.left + hDiff) + 'px';

            if (position && position == "bottom" && drpdownTopOffset)
                objDrawerPanel.style.top = $element[0].offsetTop + 35 + 'px';
            else
                objDrawerPanel.style.top = (rect.top + vDiff + (bottomDef - vDiff < 450 ? -drawerHeight : 23)) + 'px';
        }

        /**Fn is used when user click on select all and clear text*/
        $scope.checkUncheckAllItems = function (list, isCheckAll) {
            if(ctrl.maxItemLength){
                list = angular.copy($scope.sliceList);
            }
            for (var i = 0; i < list.length; i++) {
                var listObj = list[i].options;
                if (listObj && listObj.length) {
                    for (var j = 0; j < listObj.length; j++) {
                        listObj[j].checked = isCheckAll;
                        $scope.onCheckboxChange(listObj[j], false, true);
                    }
                }
            }
            $timeout(function () {
                IS_ENTER_PRESSED = false;
                ctrl.onSelectionChange && ctrl.onSelectionChange({list : list, isSelectAll: true, isClearAll: true});
            });

        };

        /**Fn is used when user click on show all text. */
        $scope.showAllListData = function (list){
            $scope.sliceList = angular.copy(list);
            $scope.isAllDataRetrived = true;
        }
        /** TO set focus on button control when dropdown closed,
         * It help user to navigate next form control using tab key
         */
        function setFocusOnButtonControl() {
            $timeout(function () {
                $element.find('.btn').focus();
            }, 50)
        }


        /** TO set focus on search input ,
         * It help user to search in list data while open drawer list
         */
        function setFocusOnSearchControl() {
            $timeout(function () {
                var objItemContainer = angular.element(objDrawerPanel).find('.itemContainer');
                objItemContainer.scrollTop(0);
                angular.element(objDrawerPanel).find('.searchItems').focus();
            }, 50)
        }

        /* Return true or false , to add selected class on row */
        $scope.isSelected = function (optitem) {
            if (ctrl.multiple) {
                return ctrl.selection && ctrl.selection.length > 0 && optitem.modelValue.length > 0 && ctrl.selection.indexOf(optitem.modelValue) > -1 ? true : false;
            } else {
                return ctrl.selection && ctrl.selection.length > 0 && optitem.modelValue.length > 0 && ctrl.selection == optitem.modelValue ? true : false;
            }
        }

        /**Fn is used when user select de-select any items in the list. */
        $scope.onCheckboxChange = function (optitem, value, selectAllOrClearAll) {
            if (!ctrl.selection)
                ctrl.selection = [];

            if(value!=undefined && optitem.checked){
                optitem.checked = !value;
                for(var m=0; m<$scope.sliceList.length; m++){
                    for(var n=0; n<$scope.sliceList[m].options.length; n++){
                        if($scope.sliceList[m].options[n].modelValue == optitem.modelValue){
                            $scope.sliceList[m].options[n].checked = !value;
                        }
                    }
                }
            }
                  
            if (ctrl.multiple) {
                if (typeof ctrl.selection == "string") {
                    ctrl.selection = ctrl.selection.split();
                }
                if (optitem.checked) {
                    ctrl.selection.push(optitem.modelValue);
                } else {
                    var index = ctrl.selection.indexOf(optitem.modelValue);
                    if (index !== -1) {
                        ctrl.selection.splice(index, 1);
                    }
                }
                ctrl.selection = _.uniq(ctrl.selection, function (item, key, a) {
                    return item;
                });

                for (var k = 0; k < $scope.sliceList.length; k++) {
                    for (var l = 0; l < $scope.sliceList[k].options.length; l++) {
                        if ($scope.sliceList[k].options[l].modelValue == optitem.modelValue) {
                            $scope.sliceList[k].options[l].checked = optitem.checked;
                        }
                    }
                }
                for (var i = 0; i < ctrl.list.length; i++) {
                    if (ctrl.list[i].options && ctrl.list[i].options.length) {
                        for (var j = 0; j < ctrl.list[i].options.length; j++) {
                            if (ctrl.list[i].options[j].modelValue == optitem.modelValue) {
                                ctrl.list[i].options[j].checked = optitem.checked;
                                break;
                            }
                        }
                    }
                }
            }
            if(!selectAllOrClearAll){
                $timeout(function () {
                    IS_ENTER_PRESSED = false;
                    ctrl.onSelectionChange && ctrl.onSelectionChange({ item: optitem });
                });
            }
            
           $scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
            
            //setFocusOnSearchControl();
        };
        $scope.$watch('$ctrl.selection', function () {
            $scope.selectedCheckCode = getSelectedCheckCodes(ctrl.list, ctrl.checkcodekey);
        }, true);
        }],
        bindings: {
            list: '<',
            label: '@',				//To show label text. If false or undefined, then show button (checkcodekey should be blank if label is defined)
            selection: '=',			//for binding the ng-model value
            selectAll: '<',			//Is selectAll/ClearAll required
            search: '<',			//Is search inputbox required?
            defaulttext: '@',
            checkcodekey: '@',		//value to display on button
            required: "@",			//Check if value is required
            itemdisabled: "<",		//Check if button is disabled
            onSelectionChange: '&',	//call function onchange of value
            onOpen: '&',
            appendTo: '@',         //Define this attribute when you need to change default append[pass css selector as argument]
            onClose: '&',				//call function onClose of toggleDropdown
            sameDropdownWidth: '<',      // set control's width to dropdown
            maxItemLength: '<',          // set maxItemLength of list to shown on UI(i.e. 10,20,30...)
            showItemCounter: '<',     // Used to show counter in drop-down list or not(i.e. true or false)
            showItemInChips:'<',     // Used to show selected Items in Chips format or not above search bar(i.e. true or false)
            selectedChipFgColor:"<",   //Apply chip font color. default color is "'#fff'"(i.e. "'aliceblue'")
            selectedChipBgColor:"<",   //Apply chip background color. default color is "'#0986b5'"(i.e. "'#000'")
            counterFgColor:"<",   //Apply selected counter font color. default color is "'#fff'"(i.e. "'aliceblue'")
            counterBgColor:"<",   //Apply selected counter background color. default color is "'#0986b5'"(i.e. "'#000'")
            iconForLabel:"<"    //Apply Font-Awsome Icon in custom-dropdown.
        }
    });
});