/**
 * File Upload component.
 * This module will initialize the File Upload component for angular application.
 * @module FileUpload
 */
define(['angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	mainModule.directive('fileModel', ['$rootScope',
		function($rootScope) {
			return {
				restrict: 'A',
				link: function(scope, element, attrs) {
					element.bind('change', function() {
						scope.$apply(function() {
							scope.currentItem.file = element[0].files[0];
							scope.currentItem.fileElement = element;
							$rootScope.disbaleUploadBtn = false;
						});
					});
				}
			};
		}
	]);
});