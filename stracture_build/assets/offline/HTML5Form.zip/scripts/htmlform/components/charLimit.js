/**
* charLimit directive.
*/
define(['angular', 'mainModule'], function (angular, mainModule) {
    'use strict';
    mainModule.directive('rtbCharLimit', ['$timeout',
        function ($timeout) {

            return {
                require: 'ngModel',
                link: function (scope, elem, attrs, ctrl) {
                    ctrl.$validators.rtbCharLimit = function () {
                        var myElemFind = elem.find('.ta-editor.form-control');
                        var charLimit = Number(attrs.charLimit);
                        if (myElemFind && myElemFind[0].innerText) {
                            var valueRTF = myElemFind[0].innerText;
                            valueRTF = valueRTF.replace(/[\u200B-\u200D\uFEFF]/g, '');
                            if (valueRTF && valueRTF.length > charLimit) {
                                return false;
                            } else {
                                return true;
                            }
                        }
                    }
                }
            }
        }
    ]);
});