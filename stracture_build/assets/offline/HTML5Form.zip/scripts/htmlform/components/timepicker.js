/**
 * TimePicker component.
 * This module will initialize the TimePicker component for angular application.
 * @module TimePicker
 * Example: 24 hrs format
 * <timepicker  time-required="false" time-format="24" time-set="oriMsgCustomFields.wakesup" ></timepicker>
 * Example: 12hrs format(default)
 * <timepicker  time-required="false" time-set="oriMsgCustomFields.wakesup" ></timepicker>
 * Example: with modal support
 * <timepicker  time-required="false" allow-modal="true" time-set="oriMsgCustomFields.wakesup" ></timepicker>
 */
 define([ 'angular', 'mainModule' ], function(angular, mainModule) {
	
	'use strict';

	mainModule.directive('masked', ['$parse',  function() {
		return {
			restrict: 'A',
			require: '?ngModel',
			link: function(scope, elm, attrs, ngModelCtrl) {
					elm.mask(attrs.format, {completed: function() {
						ngModelCtrl.$setViewValue(elm.val());  
						scope.$apply();
					}
				});                   
			}
		};
	}]);

	mainModule.component('timepicker', {
		template : '<input type="text" autocomplete="off" id="timePicker" title="12 Hours format allowed." name="time-picker" ng-if="$ctrl.timeFormat != 24" class="ang-timepciker textUppercase" placeholder="HH:MM AM/PM" ng-model="$ctrl.timeSet" ng-disabled="$ctrl.disabled" ng-readonly="$ctrl.readonly" ng-required="$ctrl.timeRequired" masked format="99:99 aa" ng-pattern="/^(((0[1-9])|(1[0-2])):([0-5])[0-9] ((A|P)(M|m)|(a|p)(M|m)))/" ng-change="onTimeChangeCallback()" ng-keyup="OpenDropDown($event)"  ng-click="OpenDropDown($event, true);"/>' +
				   '<input type="text" autocomplete="off" id="timePicker" title="24 Hours format allowed." name="time-picker" ng-if="$ctrl.timeFormat == 24" class="ang-timepciker textUppercase" placeholder="HH:MM" ng-model="$ctrl.timeSet" ng-disabled="$ctrl.disabled" ng-readonly="$ctrl.readonly" ng-required="$ctrl.timeRequired" masked format="99:99" ng-pattern="/^(((0[0-9])|(1[0-9])|(2[0-3])):([0-5])[0-9])/" ng-change="onTimeChangeCallback()" ng-keyup="OpenDropDown($event)"  ng-click="OpenDropDown($event, true);"/>',
		bindings : {
			timeSet : '=',
			timeRequired : '<',
			timeFormat : '<',
			readonly : '<',
			disabled : '<',
			timeChangeEvt: '&', // Time Change Event
			allowModal: '<'
		},
		controller : ['$scope', '$element', '$timeout', '$compile', function($scope, $element, $timeout, $compile) {
			var ctrl = this;

			var drawerPane = '<div class="time-pkr-model drop-show" id="{{timePickerID}}" ng-class="{modalWoMeridian : $ctrl.timeFormat == 24, open: showDropDown}"><div ng-if="showDropDown">' +
			'<div class="time-model-hdr"><div class="time-hdr-itm">Hr</div><div class="time-hdr-itm">Min</div><div ng-if="$ctrl.timeFormat != 24" class="time-hdr-itm">Am/Pm</div></div>' +
			'<div class="time-model-cont"> '+
			'<div class="hrminItems-wrapper"><div class="hrminItems-container" id="scrollHrWrapper"><div ng-repeat="hritem in hrslist" class="hrminItem btn" ng-class="{'+ "'btn-danger'"+ ' :hritem.itemSelected, isSelectedItem:hritem.itemSelected}" ng-click="clickedOnModelsListItem(hrslist, hritem)";>{{hritem.labelVal}}</div></div></div>'+
			'<div class="hrminItems-wrapper"><div class="hrminItems-container" id="scrollminWrapper"><div ng-repeat="minitem in minlist" class="hrminItem btn" ng-class="{'+ "'btn-danger'"+ ' :minitem.itemSelected, isSelectedItem:minitem.itemSelected}" ng-click="clickedOnModelsListItem(minlist, minitem)">{{minitem.labelVal}}</div></div></div>'+
			'<div class="hrminItems-wrapper"><div ng-if="$ctrl.timeFormat != 24" class="hrminItems-container"><div ng-repeat="ampmitem in ampmlist" class="hrminItem btn" ng-class="{'+ "'btn-danger'"+ ' :ampmitem.itemSelected, isSelectedItem:ampmitem.itemSelected}" ng-click="clickedOnModelsListItem(ampmlist, ampmitem)">{{ampmitem.labelVal}}</div></div></div>'+
			'</div>' + 
			'<div class="time-model-ftr"><div class="btn btn-default" ng-click="closeDropdownExplicitly();">Cancel</div><div class="btn btn-danger float-right" ng-click="onOkClick();">Ok</div></div>' + 
			'</div></div>';

			var KEYS = {
				UP: 38,
				DOWN: 40,
				ENTER: 13,
				ESC: 27
			};
			$scope.timePickerID = '';
			var initialDrawerHeight;
			var objDrawerPanel = null;
			ctrl.$onInit = function() {
				$scope.showDropDown = false;
				// is disabled then force to readonly
				if(ctrl.disabled) {
					ctrl.readonly = false;
				}
				
				if(ctrl.allowModal){
					$scope.hrslist = [];
					$scope.minlist = [];
					$scope.ampmlist = [];
					var hrsAllow = 12;
					if(ctrl.timeFormat == '24'){
						hrsAllow = 24;
					}
					setInitialLists($scope.hrslist, hrsAllow, true);
					setInitialLists($scope.minlist, 60);
					if(ctrl.timeFormat != '24'){
						setInitialistMeridian();
					}
					initAndAppendTemplate();
					bindEvents();
				}
			};

			function initAndAppendTemplate() {
                var strSelectorAppendTo = 'body'; //ctrl.appendTo || 'body';
                var selectorAppendTo = angular.element(document).find(strSelectorAppendTo);

                $scope.timePickerID = 'time-pkr-id-' + (new Date().getTime() + (Math.floor(Math.random() * 6) + 8));
                selectorAppendTo.append($compile(angular.element(drawerPane))($scope,
                    function afterCompile(el) {
                        objDrawerPanel = angular.element(el)[0];
                    }));
            }

			function bindEvents() {
				$(document).bind("mousedown keyup click", closeDropdown);
			}

			function closeDropdown(e) {
				if(e.type == "mousedown" || e.type == "keyup" || (e.type == "click" && (e.target.classList.contains("richtextbox") || !!angular.element(e.target).closest('.richtextbox').length))){					
					var flg = !$element.has(e.target).length && !angular.element(objDrawerPanel).has(e.target).length;
					if (flg || e.keyCode === KEYS.ESC) {
						if ($scope.showDropDown) {
							$scope.showDropDown = false;
							$scope.$digest();
						}
					}
				}
			}

			/** TO set focus on button control when dropdown closed,
			 * It help user to navigate next form control using tab key
			 */
			 function setFocusOnInputControl() {
				$timeout(function () {
					$element.find('input').focus();
				}, 0);
			}

			function setInitialLists(list, numberMaxAllow, isHrs){
				var numberVal;
				for(var i = 0; i< numberMaxAllow; i++){
					if(i < 10){
						numberVal = "0" + i;
					}else{
						numberVal = "" + i;
					}
					if(isHrs && numberMaxAllow == 12 && i == 0){
						numberVal = "12";	
					}

					list.push({
						labelVal: numberVal,
						itemSelected: false
					});
				}
			}

			function setInitialistMeridian(){
				$scope.ampmlist = [{
					labelVal: 'AM',
					itemSelected: false
				},{
					labelVal: 'PM',
					itemSelected: false
				}];
			}

			function setModalsTimeValue(){
				if(ctrl.timeSet){
					setValHrMinInModal($scope.hrslist, 'hrs');
					setValHrMinInModal($scope.minlist, 'mins');
					setMeredianValuInModal();
				}else{
					setModalsDafaultValue($scope.hrslist);
					setModalsDafaultValue($scope.minlist);
					setModalsDafaultValue($scope.ampmlist, true);
				}
			}

			/**
			 * set value in modal list to show selected in list.
			 */
			function setValHrMinInModal(list, type){
				var selectVal;
				if(ctrl.timeSet){
					if(type == 'hrs'){
						selectVal = ctrl.timeSet.split(':')[0].trim();
					}else{
						selectVal = ctrl.timeSet.split(':')[1].split(' ')[0].trim();
					}
					for(var i = 0; i< list.length; i++){
						list[i].itemSelected = false;
						if(selectVal == list[i].labelVal){
							list[i].itemSelected = true;
						}
					}
				}
			}

			function setMeredianValuInModal(){
				if(ctrl.timeSet && ctrl.timeFormat != '24'){
					var meridiem = ctrl.timeSet.split(' ')[1].trim();
					for(var i = 0; i< $scope.ampmlist.length; i++){
						$scope.ampmlist[i].itemSelected = false;
						if(meridiem == $scope.ampmlist[i].labelVal){
							$scope.ampmlist[i].itemSelected = true;
						}
					}
				}
			}

			/**
			 * sets default value on open
			 */
			function setModalsDafaultValue(list, isMeridian){
				if(ctrl.timeFormat == '24' && isMeridian){
					return;
				}
				for(var i = 0; i< list.length; i++){
					if(i == 0){
						list[i].itemSelected = true;
					}else{
						list[i].itemSelected = false;
					}
				}
			}

			/**
			 * called on ok click from modal
			 * set value selected in modal in model key i.e timeSet
			 */
			function setMOdalsValueinInput(){
				var selHr = getModalSelectedVal($scope.hrslist);
				var selMin = getModalSelectedVal($scope.minlist);
				if(ctrl.timeFormat != '24'){
					var SelMeridiem = getModalSelectedVal($scope.ampmlist);
					ctrl.timeSet = selHr + ":" + selMin + " " + SelMeridiem;
				}else{
					ctrl.timeSet = selHr + ":" + selMin;
				}
			}

			function getModalSelectedVal(list){
				for(var i = 0; i< list.length; i++){
					if(list[i].itemSelected){
						return list[i].labelVal;
					}
				}
				return "";
			}

			/**
			 * set postion of scroll on modals hours and minute list to show selected item in center
			 */
			function setScrollPositionInModal(IdName){
				var i, itemsList, parentCHeight, sHight;
				var extrapadd= 50;
				var elScrollable = angular.element(objDrawerPanel).find('#' + IdName);
				if(elScrollable && elScrollable.length){
					itemsList = elScrollable.find('.hrminItem');
					parentCHeight =  elScrollable[0].clientHeight;
					sHight =  elScrollable[0].scrollHeight;
					for(i = 0; i < itemsList.length; i++){
						if(itemsList[i].classList.contains('isSelectedItem') && itemsList[i].offsetTop > (parentCHeight/ 2)){
							if(sHight >= ((itemsList[i].offsetTop + itemsList[i].clientHeight) + ((parentCHeight - extrapadd) / 2))){
								elScrollable[0].scrollTop = itemsList[i].offsetTop - ((parentCHeight - extrapadd)/2) - (itemsList[i].clientHeight/2);
							}else{
								elScrollable[0].scrollTop = sHight - parentCHeight;
							}
						}
					}
				}
			}

			/**
			 * Function used to set position of modal
			 */
			 function setPositionOfMOdal(){
				var thisInput = $element.find('#timePicker');
				var body = document.body;
				var docElement = document.documentElement;
				var rect = thisInput[0].getBoundingClientRect();
				
				if(!initialDrawerHeight){
					objDrawerPanel.style.top = "-999px";
					objDrawerPanel.style.display = 'block';
					initialDrawerHeight = objDrawerPanel.clientHeight || 180;
					objDrawerPanel.style.cssText = "";
				}
				var drawerHeight = objDrawerPanel.clientHeight || initialDrawerHeight;
				var bottomDef = body.clientHeight - rect.bottom;
				
				var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
				var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;
				objDrawerPanel.style.left = (rect.left + hDiff) + 'px';

				objDrawerPanel.style.top = (rect.top + vDiff + (bottomDef-vDiff < 304 ? -drawerHeight : 27 )) + 'px';
			}

			$scope.onOkClick = function(){
				setMOdalsValueinInput();
				$scope.closeDropdownExplicitly();
				$timeout(function() {
					ctrl.timeChangeEvt({newTime: ctrl.timeSet});
				}, 0);
			};

			$scope.closeDropdownExplicitly = function(){
				$scope.showDropDown = false;
				setFocusOnInputControl();
			};

			$scope.clickedOnModelsListItem = function(list, item){
				for(var i = 0; i< list.length; i++){
					list[i].itemSelected = false;
					if(item.labelVal == list[i].labelVal){
						list[i].itemSelected = true;
					}
				}
			};

			/**
			 * 
			 * @param {object} event key events
			 * @param {boolean} open true or false
			 */
			$scope.OpenDropDown = function(event, open){
				if(ctrl.readonly || ctrl.disabled){
					return;
				}
				if(ctrl.allowModal){
					if(open || (event.keyCode === KEYS.ENTER)){
						$scope.showDropDown = true;
						setModalsTimeValue();
						$timeout(function () {
							setPositionOfMOdal();
							setScrollPositionInModal('scrollHrWrapper');
							setScrollPositionInModal('scrollminWrapper');
						}, 10);
					}else{
						$scope.showDropDown = false;
					}
				}
			};

			$scope.onTimeChangeCallback = function () {
				if(ctrl.timeSet) {
					ctrl.timeSet = ctrl.timeSet.toUpperCase();
				}
				$timeout(function() {
					ctrl.timeChangeEvt({newTime: ctrl.timeSet});
				}, 0);
			};		
		}]
	});
});