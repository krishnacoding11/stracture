/**
 * InlineAttachment component.
 * This module will initialize the InlineAttachment component for angular application[ HTML5 forms ].
 * @module InlineAttachment
 */
 define(['angular', 'mainModule'], function(angular, mainModule) {

	'use strict';

	function inlineattachmentController($scope, $rootScope, $attrs, $http, $timeout, api, apiConfig, myConfig, attachmentApi, FileUploader, Notification, manageDataCenter, lang) {
		var ctrl = this;
		var INIT_FILE_TEXT = lang.get("click-to-select-a-file") ? lang.get("click-to-select-a-file") : "Click to select a file";
		var ATTACH_STR = "attchment_xdoc_";
		var XDOC_STR = "xdoc_";
		var IMG_ID_PREFIX = 'imgupload_';
		var ATTACHMENT_FIELD_ID = "attachment_fields";
		var THUMBNAIL = "thumbnail_";
		ctrl.fileValue = null;
		ctrl.revisionId = null;
		ctrl.initialized = false;
		ctrl.ignoreChangeEvent = false;
		ctrl.thumbnailSrc = null;
		if(myConfig.isOfflineMode) {	
			ctrl.offlineActualPath = '';	
		}
		var isOffLine = function() { 
			return (window.applicationId == 2 ? !qtObject.systemOnlineCallBack() : navigator.onLine === false);
		};

		ctrl.attachmentForIOS = false;
		ctrl.$onInit = function() {
			if(ctrl.generateThumbnail == undefined || ctrl.generateThumbnail == null) {
				ctrl.generateThumbnail = false;
			}
			attachmentApi.register($scope, ctrl);
			
			if(window.applicationId == 3 && (/iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform == 'MacIntel') && !window.MSStream) {
				ctrl.attachmentForIOS = true;
			}

			ctrl.readonly = $attrs.readonly=="" || $attrs.readonly=="readonly" || $attrs.readonly=="true" || !document.myform || false;
			ctrl.fileText = ctrl.labelText || INIT_FILE_TEXT;
			ctrl.fileRequiredText = lang.get("field-required") ? lang.get("field-required") : "This field is required";
			
			ctrl.isUploading = false;
			ctrl.isAttachmentUploaded = false;
			ctrl.removeFileIcon = false;
			ctrl.objName = $attrs.name;
			initAttachment();

			$timeout(function(){
				var inputTag = document.getElementById( IMG_ID_PREFIX + ctrl.elementId);
				angular.element( inputTag ).on('change' , function(event) {
					$timeout(function() {
						if(event && event.target.files[0] && event.target.files[0].name) {
							// will remove the old attached file from Form
							ctrl.revisionId && $rootScope.$broadcast('assocDelete', { deleted: [ctrl.revisionId], key: 'revisionId', type: 'attachments' });

							var fileName = event.target.files[0].name;
							var validationObj = attachmentApi.invalidFileName(fileName);
							if(!validationObj.valid) {
								removeAttachmentField();
								alert('Invalid File Name\n' + validationObj.error);
								return;
							}

							uploadFileNameValidation(fileName, function() {
								ctrl.fileText = fileName;
								ctrl.removeFileIcon = false;
								
								if(window.adoddleBaseUrl) {
									ctrl.UploadFile();
								} else if($scope.uploader) {
									$scope.uploader.addToQueue(event.target.files);
								}
							});
						}
					}, 10);
				});
			},500);

			$scope.$on('assocChange', function(event, extra) {
				if(ctrl.revisionId && ctrl.removeFileIcon && extra && extra.deleted && extra.deleted.length) {
					for (var i = 0; i < extra.deleted.length; i++) {
						var d = extra.deleted[i];
						if(d.revisionId.split('$$')[0] == ctrl.revisionId.split('$$')[0]) {
							removeAttachmentField();
							break;
						}
					}
				}
			});

			ctrl.initialized = true;
		};

		var initAttachment = function() {
			if(ctrl.fileSet && ctrl.fileSet.content){// Form Onload when component initialize
				var fileName = ctrl.fileSet.content;
				fileName = fileName && fileName.substr(fileName.indexOf('my_') + 3, fileName.length - 1);
				fileName = fileName.split('#')[0]
				ctrl.fileText = fileName;
				ctrl.removeFileIcon = true;
				var attachmentId = (ctrl.fileSet.content).split("#")[5];
				attachmentId = attachmentId ? attachmentId.split("$$")[0] : null;
				var plainRevisionId = "&attachmentId=" + attachmentId;
				var plainProjectId = myConfig.projectId && myConfig.projectId.split("$$")[0];
				var filetype = api.getFileExtImage(api.getExt(fileName));	
				if (myConfig.isOfflineMode) {	
					ctrl.thumbnailSrc = setOfflinePath(null,attachmentId,filetype,api.getExt(fileName));
					ctrl.offlineActualPath = ctrl.fileSet['OfflineContent'] ? ctrl.fileSet['OfflineContent'].upFilePath:myConfig.offlineAttachmentPath+'/' +attachmentId +'.'+ filetype;	
				} else {	
					ctrl.thumbnailSrc = myConfig.baseUrl + apiConfig.THUMBNAIL_VIEW_PATH + "?projectId=" + plainProjectId + plainRevisionId;
				}
			} else if(ctrl.fileSet && ctrl.fileSet['@inline']){ // When attachment done and Attachment cotrol re-initilize on hide/show
				ctrl.inputHiddenAttachObj = document.getElementById(ctrl.fileSet['@inline']);
				if(ctrl.inputHiddenAttachObj && ctrl.inputHiddenAttachObj.value){

					var fileName = ctrl.inputHiddenAttachObj.value
					fileName = fileName && fileName.replace('xdInlineFile:/','');
					ctrl.fileText = fileName;
					ctrl.removeFileIcon = true;
				}
				var thumnailObj;
				if(ctrl.fileSet && ctrl.fileSet['@inline']+ "_thumbnail"){
					thumnailObj = document.getElementById(ctrl.fileSet['@inline']+ "_thumbnail");
				}
				if(thumnailObj && thumnailObj.value){
					var thumbnailobj = {
						resp : {
							uploadedAttachmentFileDetails : (thumnailObj.value.split('$&%&$')[0] || '')
						},
						formData:[{
							attachTempFolderId : (thumnailObj.value.split('$&%&$')[1] || '')
						}]
					}
					ctrl.isAttachmentUploaded = true;
					insertThumbnail(fileName,thumbnailobj, false);
				}
			}

			var tmpInlineStr = ctrl.fileSet && ctrl.fileSet['@inline'];
			if(tmpInlineStr && tmpInlineStr.indexOf( $attrs.name ) > -1) {
				tmpInlineStr = tmpInlineStr.replace( XDOC_STR, '');
				ctrl.xdocId = tmpInlineStr.substr(0, tmpInlineStr.indexOf(':'));
				ctrl.elementId = tmpInlineStr;

				insertFieldWithHasData(true);

				var rev = ctrl.fileSet.content || "";
				if(document.myform && rev) {
					rev = rev && rev.substr(rev.indexOf('my_')+3 , rev.length-1);
					rev = rev.split('#')[1];
					ctrl.revisionId = rev;
					insertAttachmentField('#REV#' + rev);
				}
			} else {
				ctrl.xdocId = genXdocId();
				ctrl.elementId = ctrl.xdocId + ':' + ctrl.objName;
			}
			
			if(!ctrl.readonly && !window.adoddleBaseUrl) {
				initUploader();
			}
		};

		var initUploader = function() {
			var tmpName = ATTACH_STR + ctrl.xdocId;

			ctrl.isUploading = false;
			
			var param = {
				msgId: document.getElementById("msgId") && document.getElementById("msgId").value ,
				fieldId: tmpName,
				eOriDraftMsgId: document.getElementById("eOriDraftMsgId") && document.getElementById("eOriDraftMsgId").value,
				editORI: document.getElementById("editORI") && document.getElementById("editORI").value,
				save_draft: "0",
				fileType: apiConfig.UPLOAD_TYPE.INLINE_FORM,
				//generateThumbnail:ctrl.generateThumbnail
			};

			if(ctrl.generateThumbnail) {
				param.isThumbnailSupports = ctrl.generateThumbnail;
				param.autoPublishToFolder = myConfig.autoPublishToFolder;
				param.fileSize = '';
				param.uploadedAttachmentFileDetails = null;
			}
			
			var uploader = $scope.uploader = new FileUploader({
				url: (window.adoddleBaseUrl || "") + apiConfig.ADODDLE_UPLOAD_CONTROLLER + '?action_id=1203',
				alias: 'UploadFile',
				type: 'POST',
				formData: [param],
				autoUpload: true,
				removeAfterUpload: false,
				withCredentials: true,
				retries: 0,
				maxRetries : window.uploadMaxRetry || 1800,
				retryTimeout : window.uploadRetryTimeout || 500,
				chunkUpload: true,
				chunkSize: myConfig.uploadChunkSize
			});
			
			uploader.onAfterAddingAll = function(fileItems) {
				for (var i = 0; i < fileItems.length; i++) {
					var item = fileItems[i];
					var fileName = item.file && item.file.name;
					item.sortSize = api.getSortFileSize(item.file.size);
					item.icon = api.getFileExtImage(api.getExt(fileName));
				}

				$timeout(function() {
					ctrl.isUploading = uploader.isUploading;
				})
			};

			uploader.onBeforeUploadItem = function(item) {
				item.formData[0].attachTempFolderId = ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID;
				if(ctrl.generateThumbnail){
					item.formData[0].fileSize = item.file.size;                        
					myConfig.appTypeId && (item.formData[0].appTypeId = myConfig.appTypeId);
					ctrl.generateThumbnail && (item.formData[0].isThumbnailSupports = ctrl.generateThumbnail);
					item.formData[0].autoPublishToFolder = myConfig.autoPublishToFolder; 
				}
			};
			
			uploader.onSuccessItem = function(item, response, status, headers) {
				item.resp = response;
			};

			uploader.onCompleteItem = function onCompleteItem(item, response, status, headers) {
				uploadSuccess(item.file.name,item);
				validateFileType(item.file.type, item.file.name);
			};
			
			uploader.onDisconnect = function(item, success, error) {
				var obj = {
					action_id: 1204,
					fileType: apiConfig.UPLOAD_TYPE.INLINE_FORM,
					fileName: item._lastResp ? item._lastResp.fileName : item.file.name
				};

				var xhr = api.ajax({
					url: (window.adoddleBaseUrl || "") + apiConfig.ADODDLE_UPLOAD_CONTROLLER,
					data: obj
				});
				
				xhr.then(function(response) {
					var fileSize = 0;
					if(response.fileExists === "true") {
						fileSize = parseInt(response.fileSize);
					}
					success(fileSize);
				}, function(xhr) {
					error && error(xhr);
				});
			};
			
			uploader.onErrorItem = function(item, response, status, headers) {
				removeAttachmentField();
				ctrl.isUploading = false;	
			};
		};

		ctrl.$onChanges = function(changedProps) {
			if(changedProps && ctrl.initialized) {
				if(changedProps.inlineData != undefined) {
					if(ctrl.ignoreChangeEvent) {
						ctrl.ignoreChangeEvent = false;
					}else {
						if(changedProps.inlineData.currentValue) {
							initAttachment();
						} else {
							ctrl.removeUploadedFile(true);
						}
					}
				}
			}
		}

		ctrl.$onDestroy = function() {
			ctrl.ignoreChangeEvent = false;
			attachmentApi.unregister($scope, ctrl);
		}

		function validateFileType(fileType, fileName) {
			if(ctrl.fileType && ctrl.fileType != "false") {
				var unsupportedFormat = false;
				//If fileType ends with '/*'
				if(ctrl.fileType.indexOf('/*') != -1 && (ctrl.fileType.length - ctrl.fileType.indexOf('/*') == 2)) {
					unsupportedFormat = ctrl.fileType.split('/*')[0] != fileType.split('/')[0];
				}else {
					unsupportedFormat = ctrl.fileType.indexOf(api.getExt(fileName).toLocaleLowerCase()) == -1;
				}
				if(unsupportedFormat) {
					var msg = "Apologies! Files with only "+ctrl.fileType+" extension are supported."
					Notification.error({
						message: msg
					});
					ctrl.removeUploadedFile()
				}
			}
		}

		function uploadSuccess(fileName,item,isMobile) {				
			var xdName = XDOC_STR + ctrl.elementId;
			ctrl.fileText = fileName;
			ctrl.fileSet = {
				"@inline": xdName,
				content: "",	
			};
			if(myConfig.isOfflineMode) {
				ctrl.fileSet['OfflineContent'] = {	
			        "fileType": apiConfig.UPLOAD_TYPE.INLINE_FORM,	
			        "isThumbnailSupports": ctrl.generateThumbnail,	
			        "upFilePath": item.offlineAttachmentPath	
				}
			}
			if(isMobile) {
				ctrl.fileText =  item.fileName ? item.fileName.split('_my_')[1] : '';
				var formDataObj = {
					fieldId: ATTACH_STR + ctrl.xdocId,
					attachTempFolderId: ctrl.generateThumbnail ? ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID : undefined,
				}
				myConfig.appTypeId && (formDataObj['appTypeId'] = myConfig.appTypeId);
				if (ctrl.generateThumbnail) {
					formDataObj['fileSize'] = item.fileSize;
					myConfig.appTypeId && (formDataObj['appTypeId'] = myConfig.appTypeId);
					ctrl.generateThumbnail && (formDataObj['isThumbnailSupports'] = ctrl.generateThumbnail);
					formDataObj['autoPublishToFolder'] = myConfig.autoPublishToFolder;
				}
				var formData = [];
				formData.push(formDataObj);
				item['formData'] = formData;
			}
			insertAttachmentField();
			insertThumbnail(fileName,item,true);
			ctrl.isAttachmentUploaded = true;
			ctrl.isUploading = false;
			ctrl.removeFileIcon = true;
			ctrl.ignoreChangeEvent = true;
			$timeout(function() {
				ctrl.attachmentChange && ctrl.attachmentChange();
				$scope.$apply();
			}, 100);
		}

		/**
		 * To upload file in server using ajax call
		 * @param {Object} parms : Formdata param passed to upload file
		 * @param {String} fName : File name of uploaded file
		 */
		var sendHtml5InlineFile = function(parms, fileName) {			
			$http({
				method: "post",
				headers: {
					'Content-Type': undefined,				
					'hasattachment': true
				},
				withCredentials: true,
				url: (window.adoddleBaseUrl || "") + "/adoddle/apps?action_id=1730",
				transformRequest: angular.identity,
				data: parms				
			}).then(function () {				
				uploadSuccess(fileName,null);
			}, function myError(errors) {
				removeAttachmentField();
				ctrl.isUploading = false;				
			});
		}

		function downloadInlineAttachment() {
			var fieldStr = ctrl.fileSet.content;
			if( fieldStr ){
				var splitValue = fieldStr.split('#');
				var msgId = splitValue[2];
				var revId = splitValue[ splitValue.length-1 ];

				var tmpFieldVal = splitValue[3];
				var fieldName = tmpFieldVal.substr( tmpFieldVal.indexOf( '_xdoc_') , tmpFieldVal.length-1);
				var fileName = ctrl.fileText;


			    document.download.action_id.value = 200;
			    document.download.fileName.value = encodeURIComponent(fileName);
			    document.download.fieldName.value = fieldName;
			    document.download.paramComingFrom.value = "CformAttachment";
			    document.download.msgId.value = msgId;
			    document.download.revision_id.value = revId;
			    
			    var tempRev = revId.split("$$");
			    document.download.revisionidak.value = tempRev[0];
			    
			    var FORM_AUDIT_TRAIL_ACTION_DOWNLOADED = 30;

			    if(document.download.auditActionId){ //For classic audit entry not required
			    	document.download.auditActionId.value = FORM_AUDIT_TRAIL_ACTION_DOWNLOADED;
				}

				var apiUrl = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, myConfig.downloadServiceURL) + apiConfig.DOWNLOAD_CUSTOM_FORM_ATTACHMENT;

				if(myConfig.applicationId == 3){
					var formdata = angular.element(document.download).serializeArray();
					var data = {};
					for (var i = 0; i < formdata.length; i++) {
						data[formdata[i].name] = formdata[i].value;
					}
					sendEventToIpad("inlineAttachmentDownload:"+angular.toJson({
						"url": apiUrl,
						"data" : data
					}));
				} else {
					document.download.setAttribute('action', apiUrl);
					document.download.submit();
				}
			}
		}

		function insertFieldWithHasData(isOnLoad) {//These function add attachment_field with has separeted
			var tmpName = XDOC_STR + (Math.random() * 9 | 0) + '_' + (Math.random() * 9 | 0) + '_'+ ATTACHMENT_FIELD_ID;
			var tmpId = XDOC_STR+ATTACHMENT_FIELD_ID;
			if(!ctrl.readonly && isOnLoad){
				if( !document.getElementById(tmpId) ){
					var tmpInput = document.createElement('input');
					tmpInput.type = "hidden";
					tmpInput.name = tmpName;
					tmpInput.id = tmpId;

					document.myform.appendChild(tmpInput);
				}
				var tmpField = document.getElementById(tmpId);
				var tmpFieldVal = tmpField.value;

				var xdName = XDOC_STR + ctrl.elementId;
				if(!tmpFieldVal){
					tmpField.value = xdName;
				}else{
					tmpField.value = tmpFieldVal + '#' + xdName;
				}
			}
		}

		function insertAttachmentField(rev) {
			var tmpName = ATTACH_STR + ctrl.xdocId;
			var xdName = XDOC_STR + ctrl.elementId;

			var tmpInput = document.getElementById(tmpName);
			if(!tmpInput) {
				var tmpInput = document.createElement('input');
				tmpInput.type = "hidden";
				tmpInput.name = tmpName;
				tmpInput.id = tmpName;
			}

			tmpInput.value = rev || ("C:\/fakepath\/" + ctrl.fileText);

			var xdInput = document.getElementById( xdName );
			if(!xdInput) {
				xdInput = document.createElement('input');
				xdInput.type = "hidden";
				xdInput.name = xdName;
				xdInput.id = xdName;
			}

			xdInput.value = "xdInlineFile:/" + ctrl.fileText;

			document.myform.appendChild(tmpInput);
			document.myform.appendChild(xdInput);
			if(ctrl.generateThumbnail) {
				var thumbnailName = THUMBNAIL+ ctrl.generateThumbnail;
				var thumbnailInput = document.getElementById( thumbnailName );
				if(!thumbnailInput) {
					thumbnailInput = document.createElement('input');
					thumbnailInput.type = "hidden";
					thumbnailInput.name = thumbnailName;
					thumbnailInput.id = thumbnailName;
					thumbnailInput.value = ctrl.generateThumbnail;
					document.myform.appendChild(thumbnailInput);
				}
			}
			
		}

		function insertThumbnail(fileName, item, isThumbnailField) {
			if(item && ctrl.generateThumbnail ){
				if (!fileName) {
					return;
				}

				if (item && item.resp && item.resp.uploadedAttachmentFileDetails) {
					fileName = item.resp.uploadedAttachmentFileDetails.split('|')[0];
				}
				var filetype = api.getFileExtImage(api.getExt(fileName));	
				if (myConfig.isetThumbnailMetadatasOfflineMode) {	
					ctrl.thumbnailSrc = setOfflinePath(item,null,filetype,api.getExt(fileName));
					ctrl.offlineActualPath = item.offlineAttachmentPath;	
				} else {
					if(isThumbnailField){
						setThumbnailMetadata(item);
					}
					ctrl.thumbnailSrc = myConfig.baseUrl + apiConfig.THUMBNAIL_VIEW_TEMP_PATH + "?fileName=" + fileName +"&projectId=" + myConfig.projectId.split("$$")[0] +"&folderId=" + item.formData[0].attachTempFolderId+"&isInline=true";
				}
			}
		}

		/** Case No. : APPS-17346
		 * function used to Set Thumbnail Meta data. this data used to when the inline attachment component re-render after the thumbnail is generated
		 * This Thumbnail Meta data used to show Thumbnail, When Tab change or show/hide tab.
		 * @param {obj} item 
		 * where, item = {
						resp : {
							uploadedAttachmentFileDetails : ''
						},
						formData:[{
							attachTempFolderId : ''
						}]
					}
		 */
		function setThumbnailMetadata(item) {
			var newNodeId = ctrl.fileSet['@inline'] + "_thumbnail";
			var thumbnailId = document.getElementById(newNodeId);
			var fileVal,fordataID;
			if (item && item.resp && item.resp.uploadedAttachmentFileDetails) {
				fileVal = item.resp.uploadedAttachmentFileDetails.split('|')[0];
				fordataID = item.formData[0].attachTempFolderId;
			}
			var thumbnailval = fileVal && fordataID && (fileVal + '$&%&$' + fordataID );
			if (!thumbnailId && thumbnailval) {
				thumbnailId = document.createElement('input');
				thumbnailId.type = "hidden";
				thumbnailId.id = newNodeId;
				thumbnailId.value = thumbnailval
				document.myform.appendChild(thumbnailId);
			}
		}

		function setOfflinePath(item,attachmenId, filetype,thumbnailFileType) {
			var thumbSrc = './images/file-size-518.svg';
			if (apiConfig.OFFLINE_THUMBNAIL_SUPPORTED_EXTENSION	
				.indexOf(filetype.toUpperCase()) != -1) {	
				if(item && item != null && item.offlineAttachmentPath) {	
					thumbSrc = item.offlineAttachmentPath;	
				} else if(attachmenId && attachmenId != null) {
					ctrl.thumbnailSrc = myConfig.offlineAttachmentPath+'/' +attachmenId +'.'+ thumbnailFileType;
				} else {	
					thumbSrc = './images/Asite_file_type_icons/svg/'+ filetype + '_icon.svg';	
				}	
			} else {	
				thumbSrc = './images/Asite_file_type_icons/svg/'+ filetype + '_icon.svg';	
			}
			return thumbSrc
		}

		function removeAttachmentField() {
			ctrl.fileText = ctrl.labelText || INIT_FILE_TEXT;
			ctrl.fileSet = "";
			ctrl.removeFileIcon = false;
			ctrl.isAttachmentUploaded = false;

			var tmpName = ATTACH_STR + ctrl.xdocId;
			var xdName = XDOC_STR + ctrl.elementId;

			var formInput = document.myform[tmpName];
			var xdformInput = document.myform[xdName];
			var inputTag = document.getElementById('imgupload_'+ctrl.elementId);

			if (formInput) {
				formInput.remove();
			}

			if (xdformInput) {
				xdformInput.remove();
			}

			if (inputTag) {
				inputTag.value = "";
			}

			if(ctrl.generateThumbnail) {
				var thumbnailInput = document.getElementById(`${xdName}_thumbnail`);
				thumbnailInput && thumbnailInput.remove();
			}
		}

		function uploadFileNameValidation(fileName, callback) {
			if(!myConfig.autoPublishToFolder || !myConfig.projectId || !myConfig.autoPublishFolderId || myConfig.autoPublishFolderId == 'null') {
				callback && callback();
				return;
			}

			var xhr = api.ajax({
				url: (window.adoddleBaseUrl || "") + apiConfig.UPLOAD_CONTROLLER,
				data: {
					action_id: apiConfig.UPLOAD_FILE_VALIDATION_NEW,
					project_id: myConfig.projectId,
					folder_id: myConfig.autoPublishFolderId,
					validationType: apiConfig.VALIDATION_TYPE.VALIDATION_ON_ENTER_DOC_DETAILS,
					forPublishing: false,
					caller: 2,
					rowNumbers: 1,
					filename1: fileName
				}
			});
			
			xhr.then(function(data) {
				if (data.docNamingRuleValidation && data.docNamingRuleValidation !== "null") {
					removeAttachmentField();
					showFileNamingRuleValidationExceptions(data.docNamingRuleValidation);
					return;
				}
		
				var errors = data.fileNameValidation;
				if (errors && errors.length) {
					
					if(showFileValidationExceptions(errors)){
						removeAttachmentField();
						return;
					}
				}

				callback && callback();
			}, function(xhr) {
				removeAttachmentField();
				alert("Error while file validation!!");
			});
		}

		function showFileNamingRuleValidationExceptions(docrefExceptionList) {
			var msg = Language.get('doc-ref-duplication-error');
			if(docrefExceptionList.length) {
				msg = '<p>' + Language.get('doc-ref-duplication-error') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th></tr>';
				docrefExceptionList.forEach(function(docrefException, index) {
					msg += '<tr><th>' + docrefException[0] + '</th><th>' + docrefException[1] + '</th></tr>';
				});
				msg += '</table>';
			} else if(docrefExceptionList.maxLengthExceedList && docrefExceptionList.maxLengthExceedList.length) {
				msg = '<p>' + Language.get('exceeded-alloable-length') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th></tr>';
				docrefExceptionList.maxLengthExceedList.forEach(function(docrefException, index) {
					msg += '<tr><th>' + docrefException[0] + '</th><th>' + docrefException[1] + '</th></tr>';
				});
				msg += '</table>';
			} else if(docrefExceptionList.lableRuleViolationList && docrefExceptionList.lableRuleViolationList.length) { 
				msg = '<p>' + Language.get('exceeded-alloable-length') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th><th>' + Language.get('incorrect-naming-lables') + '</th><th>' + Language.get('suggested-naming-lables') + '</th></tr>';
				docrefExceptionList.lableRuleViolationList.forEach(function(docrefException, index) {
					msg += '<tr><th>' + docrefException.filename + '</th><th>' + docrefException.docref + '</th><th>' + docrefException.inCorrectNamingLable + '</th><th>' + docrefException.suggestedNamingLable + '</th></tr>';
				});
				msg += '</table>';
			}

			Notification.error({
				message: msg
			});
		}

		function showFileValidationExceptions(exceptionList) {
			for (var i = 0; i < exceptionList.length; i++) {
				var v = exceptionList[i];

				if(v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_VALID_EXISTING_FILES) {
					continue;
				}

				// Validating CODE_EXTENSION_LESS_FILENAME
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_EXTENSION_LESS_FILENAME) {
					if (v.uploadedDocRefNonIFC) {
						var msg = '<p>' + Language.get("already-uploaded-ifc-file") + "</p></br>";
						v.uploadedDocRefNonIFC.forEach(function(IFCRef, index) {
							msg += index + 1 + '.  ' + IFCRef + "</br>";
						});
						Notification.error({
							message: msg
						});
						return true;
					}
					
					if (v.fileNames) {
						continue;
					}
				}

				// Validating CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION && v.docRefs) {
					var msg = '<p>' + Language.get('you-do-not-have-incomplete-for-publish-for-docref') + "</p></br>";
					v.docRefs.forEach(function(docRef, index) {
						msg += index + 1 + '.  ' + docRef + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_LINKED_FILE
				if (v.linkedFileList && v.linkedFileList.length) {
					var msg = '<p>' + Language.get('already-linked-file') + "</p></br>";
					v.linkedFileList.forEach(function(linkedFile, index) {
						msg += index + 1 + '.  ' + linkedFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_FILE_CHECKED_OUT 
				if (v.checkedOutFileList && v.checkedOutFileList.length) {
					var msg = '<p>' + Language.get('already-checked-out-file') + "</p></br>";
					v.checkedOutFileList.forEach(function(checkedOutFile, index) {
						msg += index + 1 + '.  ' + checkedOutFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_DEACTIVATED_FILE
				if (v.deactivatedFileList && v.deactivatedFileList.length) {
					var msg = '<p>' + Language.get('alread-deactivated-file') + "</p></br>";
					v.deactivatedFileList.forEach(function(deactivatedFile, index) {
						msg += index + 1 + '.  ' + deactivatedFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_REVISION_UPLOAD_ACTIVITY_LOCK
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_REVISION_UPLOAD_ACTIVITY_LOCK && v.uploadlockFileList && v.uploadlockFileList.length) {
					var msg = '<p>' + Language.get('locked-files-msg') + "</p></br>";
					v.uploadlockFileList.forEach(function(uploadlockFile, index) {
						msg += index + 1 + '.  ' + uploadlockFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}
			}

			return false;
		}

		ctrl.UploadFile = function() {
			var inputTag = document.getElementById('imgupload_'+ctrl.elementId);
			var tmpName = ATTACH_STR + ctrl.xdocId;
			
			if(inputTag.files[0]) {
				ctrl.isUploading = true;

				var tmpFormData = new FormData();
				tmpFormData.append('action', "1730");
				tmpFormData.append('msgId',  document.getElementById("msgId").value );
				tmpFormData.append('fieldId', tmpName);
				tmpFormData.append('eOriDraftMsgId', document.getElementById("eOriDraftMsgId").value);
				tmpFormData.append('editORI', document.getElementById("editORI").value);
				tmpFormData.append('save_draft', "0");
				tmpFormData.append('UploadFile', inputTag.files[0]);
				sendHtml5InlineFile( tmpFormData, inputTag.files[0].name );
			} else {
				alert("Please attach file");
			}
		}

		ctrl.removeUploadedFile = function(silent) {
			ctrl.ignoreChangeEvent = !silent;
			removeAttachmentField();
			if(!silent) {
				$timeout(function() {
					ctrl.attachmentChange && ctrl.attachmentChange();
				}, 100);
			}

			// will remove the related attached file from Form
			ctrl.revisionId && $rootScope.$broadcast('assocDelete', { deleted: [ctrl.revisionId], key: 'revisionId', type: 'attachments' });
		}

		ctrl.openUploadDialog = function() {
			if(myConfig.isOfflineMode) {	
				var attachItem = {	
					'FileName' : ctrl.fileText || '',
					'OfflineAttachFilePath': ctrl.offlineActualPath || ctrl.thumbnailSrc	
				}	
				sendEventToIpad("viewCreateAttachment:"+JSON.stringify(attachItem));	
			} else {	
				ctrl.readonly = $attrs.readonly=="" || !document.myform || false;	
				ctrl.readonly && downloadInlineAttachment();
			}
		}

		var sendEventToIpad = function(strEvent){
			var iframe = document.createElement("IFRAME");
		    iframe.setAttribute("src", "js-frame:" + strEvent);
		    document.documentElement.appendChild(iframe);
		    iframe.parentNode.removeChild(iframe);
		    iframe = null;
		};

		ctrl.informNativeDevice = function () {
			if (ctrl.attachmentForIOS || (myConfig.isOfflineMode && (/Android|iPad|iPhone|iPod/.test(navigator.userAgent)))) {
				sendEventToIpad("uploadAttachment:" + angular.toJson({
					action: "1203",
					msgId: document.getElementById("msgId") && document.getElementById("msgId").value,
					fieldId: '',
					eOriDraftMsgId: document.getElementById("eOriDraftMsgId") && document.getElementById("eOriDraftMsgId").value,
					editORI: document.getElementById("editORI") && document.getElementById("editORI").value,
					save_draft: "0",
					fileType: (ctrl.fileType && ctrl.fileType != "false") ? ctrl.fileType : "",
					isForReply: myConfig.isForReply,
					isMultiple: myConfig.isOfflineMode ? false : undefined,
					isThumbnailSupports: ctrl.generateThumbnail ? ctrl.generateThumbnail : undefined,
					autoPublishToFolder: ctrl.generateThumbnail ? myConfig.autoPublishToFolder : undefined,
					fileSize: ctrl.generateThumbnail ? '' : undefined,
					uploadedAttachmentFileDetails: ctrl.generateThumbnail ? null : undefined,
					attachTempFolderId: ctrl.generateThumbnail ? ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID : undefined
				}));

				window.FieldAppInlineAttachmentUploadCallback = function (data) {
					if (data && typeof (data) == 'string') {
						data = JSON.parse(data);
					}
					var fileName = data.fileName ? data.fileName : '';
					ctrl.xdocId = data.fieldId ? data.fieldId.substr(15) : '';
					ctrl.elementId = ctrl.xdocId + ':' + ctrl.objName;
					try {
						$timeout(function () {
							uploadSuccess(fileName, data, true);
							$scope.$apply();
						}, 2000);

					} catch (e) { }
				}
			}
		}

		window.thumbnailInlineFailCallback = function (imgElem) {
				var thumbnailsrc = imgElem.src;
				imgElem.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAABCAQAAACx6dw/AAAAC0lEQVR42mNkAAMAAA4AAjOwv9wAAAAASUVORK5CYII=';   
				imgElem.errorCount = imgElem.errorCount || 1;
				if (imgElem.errorCount < 5) {
					imgElem.timer = $timeout(function(){
						imgElem.src = thumbnailsrc;
						try {
							$timeout(function(){
								$scope.$apply();
								imgElem.height = 151;
							}, 1000);
						} catch (e) { }
						imgElem.errorCount++;
					}, 7500);
				} else {
					delete imgElem.errorCount;
				}
				
		};

		function genXdocId() {
			return 'x_x_x_x'.replace(/[x]/g, function(c) {
				var r = Math.random() * 9 | 0,
					v = c == 'x' ? r : '0';
				return v;
			}) + "_my";
		}
	};

	mainModule.component('inlineattachment', {
		template: '<div class="inline-block-cls" data_id="{{$ctrl.elementId}}">' +
			'<a ng-if="$ctrl.readonly" href="javascript:void(0);" ng-click="$ctrl.openUploadDialog()">{{$ctrl.fileText}}</a>' +
			'<label ng-if="!$ctrl.readonly" for="imgupload_{{$ctrl.elementId}}" ng-click="$ctrl.informNativeDevice()">{{$ctrl.fileText}}</label> &nbsp;' +
			'<input ng-if="!$ctrl.attachmentForIOS" type="file" id="imgupload_{{$ctrl.elementId}}" class="hdnInlineFile" accept="{{$ctrl.fileType}}" />' +
			'<span ng-if="!$ctrl.readonly && $ctrl.removeFileIcon" ng-click="$ctrl.removeUploadedFile()" class="remove-attach">x</span>' +
			'<img src="/images/htmlform/CWR/smooth-loader.gif" class="waiting" ng-if="!$ctrl.readonly && $ctrl.isUploading" />' +
			'</div>'+
			'<div ng-if="($ctrl.generateThumbnail && $ctrl.isAttachmentUploaded) || ($ctrl.generateThumbnail && $ctrl.fileSet && $ctrl.fileSet.content)"><img  id="thumbnail_img_{{$ctrl.elementId}}" ng-src="{{$ctrl.thumbnailSrc}}" onerror="thumbnailInlineFailCallback(this);" width="220px" height="150px" alt=""></div>'+
			'<p class="error" style="font-size:12px;" ng-if="$ctrl.fileRequired && !$ctrl.fileSet">{{$ctrl.fileRequiredText}}</p>',
			bindings: {
			fileSet: '=',
			fileType: '@',
			disable: '<',
			inlineData: '<',
			attachmentChange: '&',
			fileRequired: '<',
			labelText: '<',
			generateThumbnail:'<'
		},
		controller: inlineattachmentController
	});
});