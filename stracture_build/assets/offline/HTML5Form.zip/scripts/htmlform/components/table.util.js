/**
 * Table util component.
 * This module will initialize the common utility like insert before/after, remove/remove all for the table component for angular application.
 * @module tableUtil
 */
define(['angular', 'mainModule'], function (angular, mainModule) {
    'use strict';

    /** @Attributes
     * parent: Array
     * currRow: Object || {}
     * settings: Object
     * ischecked: Boolean
     */

    /** @settings properties
     * tooltip: string [ for checkbox's tooltip ],
     * hasDefaultRecord : after remove all row, if require default one row , argument passed true/false
     * ADD_NEW_BEFORE_TIP: string [ to modify add New before row tooltip ],
     * ADD_NEW_AFTER_TIP: string [ to modify add New after row tooltip ],
     * deleteCurrRowMsg : string [ to modify remove curr row tooltip ],
     * deleteSelectedMsg : string [ to modify delte selected row tooltip ],
     * deleteAllRowTooltip: string [ to modify delte all row tooltip ]
     * checkboxModelKey: string [ require when multiple item remove option available ],
     * DELETE_ALL_CONFIRM_MSG: string [ to modify confirm message when user remove all recored ]
     * hideControlIcon:  {  // Manage Control in Drawer, mark 0 against mentioned key to hide control
     *     editRow : 0,
     *     insertBefore : 0,
     *     deleteSelected: 0,
     *     deleteAllRow: 0,
     *     insertAfter : 0,
     * },
     * editRowCallBack [ This function used when editRow flag enable and , except callback function]
     */

    mainModule.component('tableUtil', {
        template: '<div class="table-util" ng-mouseover="$ctrl.mouseOverEvent();" ng-mouseleave="$ctrl.mouseLeaveEvent($event);">' +
            '<input type="checkbox" class="checkbox" ng-model="$ctrl.ischecked" title="{{$ctrl.strMsg.tooltip}}" ng-change="$ctrl.checkBoxChange();">' +
            '</div>',
        controller: ['$scope', '$element', '$timeout', '$compile', function ($scope, $element, $timeout, $compile) {

            var LABELS_MSG = {
                TOOLTIP: 'select to remove/remove all/Insert new Record',
                ADD_NEW_BEFORE_TIP: 'Insert before row',
                ADD_NEW_AFTER_TIP: 'Insert after row',
                DELETE_ROW_TIP: 'Remove row',
                DELETE_SELECTED_TIP: 'Remove selected row',
                DELETE_ALL_ROW_TIP: 'Remove All row',
                DELETE_ALL_CONFIRM_MSG: 'Do you want to remove All row?',
                DEACTIVATE_MSG:'Deactivate selected row/rows',
                REACTIVATE_MSG:'Reactivate selected row/rows',
                EDIT_ROW_MSG: 'Edit row data'
            }

            var ctrl = this;

            var drawerPane = '<div class="table-util-drawer" id="{{tableUtilID}}" ng-if="$ctrl.isDrawerOpen" ng-mouseleave="$ctrl.mouseLeaveEvent($event);">' +
                '<ul>' +
                '<li ng-click="$ctrl.editRow();" title="{{$ctrl.strMsg.EDIT_ROW_MSG}}" ng-if="$ctrl.icon.editRow">' +
                '<i class="fa fa-edit bold" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.deactivateRow();" title="{{$ctrl.strMsg.DEACTIVATE_MSG}}" ng-if="$ctrl.icon.deactivateRow && !$ctrl.isRowDeactivated">' +
                '<i class="fa fa-ban bold" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.reactivateRow();" title="{{$ctrl.strMsg.REACTIVATE_MSG}}" ng-if="$ctrl.icon.reactivateRow && $ctrl.isRowDeactivated">' +
                '<i class="fa fa-check-circle bold" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.addNewRowBefore();" title="{{$ctrl.strMsg.addNewBeforeMsg}}" ng-if="$ctrl.icon.insertBefore">' +
                '<i class="fa fa-plus" aria-hidden="true"></i><i class="fa fa-level-up" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.addNewRowAfter();" title="{{$ctrl.strMsg.addNewAfterMsg}}" ng-if="$ctrl.icon.insertAfter">' +
                '<i class="fa fa-plus" aria-hidden="true"></i><i class="fa fa-level-down" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.deleteSelectedRow();" title="{{$ctrl.strMsg.deleteSelectedMsg}}" ng-if="$ctrl.icon.deleteSelected">' +
                '<i class="fa fa-trash" aria-hidden="true"></i>' +
                '</li>' +
                '<li ng-click="$ctrl.deleteAllRow();" title="{{$ctrl.strMsg.deleteAllTooltip}}" ng-if="$ctrl.icon.deleteAllRow">' +
                '<i class="fa fa-trash" aria-hidden="true"></i><i class="fa fa-trash delete-all" aria-hidden="true"></i>' +
                '</li>' +
                '</ul>' +
                '</div>';

            ctrl.isMenuIcon = false;
            ctrl.isDrawerOpen = false;
            ctrl.removedIndexList = [];
            ctrl.isRowDeactivated = false;
            ctrl.deactivateIndexList = [];
            ctrl.reactivateIndexList = [];

            $scope.tableUtilID = '';
            var objDrawerPanel = null;
            var thisInput = null;

            ctrl.$onInit = function () {
                initAndAppendTemplate();
                init();
                bindEvents();
            };

            function initAndAppendTemplate() {
                var strSelectorAppendTo = ctrl.appendTo || 'body';
                var selectorAppendTo = angular.element(document).find(strSelectorAppendTo);

                $scope.tableUtilID = 'table-util-id-' + (new Date().getTime() + (Math.floor(Math.random() * 6) + 8));
                selectorAppendTo.append($compile(angular.element(drawerPane))($scope,
                    function afterCompile(el) {
                        objDrawerPanel = angular.element(el)[0];
                    }));
            }

            function init() {
                ctrl.ischecked = false;
                ctrl.strMsg = {
                    tooltip: ctrl.settings.tooltip || LABELS_MSG.TOOLTIP,
                    addNewBeforeMsg: ctrl.settings.ADD_NEW_BEFORE_TIP || LABELS_MSG.ADD_NEW_BEFORE_TIP,
                    addNewAfterMsg: ctrl.settings.ADD_NEW_AFTER_TIP || LABELS_MSG.ADD_NEW_AFTER_TIP,
                    deleteCurrRowMsg: ctrl.settings.deleteCurrRowMsg || LABELS_MSG.DELETE_ROW_TIP,
                    deleteAllTooltip: ctrl.settings.deleteAllRowTooltip || LABELS_MSG.DELETE_ALL_ROW_TIP,
                    deleteSelectedMsg: ctrl.settings.deleteSelectedMsg || LABELS_MSG.DELETE_SELECTED_TIP,
                    DELETE_ALL_CONFIRM_MSG: ctrl.settings.DELETE_ALL_CONFIRM_MSG || LABELS_MSG.DELETE_ALL_CONFIRM_MSG,
                    EDIT_ROW_MSG: ctrl.settings.EDIT_ROW_MSG || LABELS_MSG.EDIT_ROW_MSG,
                    DEACTIVATE_MSG: ctrl.settings.DEACTIVATE_MSG || LABELS_MSG.DEACTIVATE_MSG,
                    REACTIVATE_MSG: ctrl.settings.REACTIVATE_MSG || LABELS_MSG.REACTIVATE_MSG
                }

                hideShowIconBasedOnSetting();
            };

            function bindEvents() {
                $(document).bind("mousedown keyup", closeDropdown);
            }

            function closeDropdown(e) {
                var flg = !$element.has(e.target).length && !angular.element(objDrawerPanel).has(e.target).length;
                if (flg) {
                    if (ctrl.isDrawerOpen) {
                        ctrl.isDrawerOpen = false;
                    }
                }
            }

            function closeDropdownOnLeave(e) {
                var flg = !$element.has(e.relatedTarget).length && !angular.element(objDrawerPanel).has(e.relatedTarget).length;
                if (flg) {
                    if (ctrl.isDrawerOpen) {
                        ctrl.isDrawerOpen = false;
                    }
                }
            }

            var uncheckPrevSelected = function () {
                for(var i=0; i< ctrl.parent.length; i++) {
                    if(!angular.equals(ctrl.currRow, ctrl.parent[i])) {
                        ctrl.parent[i][ctrl.settings.checkboxModelKey] = false;
                    }
                }
            };

            ctrl.mouseLeaveEvent = closeDropdownOnLeave;

            ctrl.mouseOverEvent = function () {
                if (ctrl.ischecked) {
                    ctrl.isDrawerOpen = true;                   
                    ctrl.isRowDeactivated = ctrl.currRow[ctrl.settings.disableRowKey];
                    $timeout(function () {
                        thisInput = $element.find('.table-util');
                        var body = document.body;
                        var docElement = document.documentElement;
                        var rect = thisInput[0].getBoundingClientRect();

                        var hDiff = body.scrollLeft || (docElement && docElement.scrollLeft) || 0;
                        var vDiff = body.scrollTop || (docElement && docElement.scrollTop) || 0;

                        var objLeft = (rect.left + hDiff - 30) + 'px';
                        var objTop = (rect.top + vDiff - 10) + 'px';

                        setCordinateOnDrawer(objLeft, objTop);
                    }, 50);
                }else{
                    ctrl.isDrawerOpen = false;
                }

                $timeout(function(){
                    hideEditIconIfMultipleCheckboxSelected();
                });
            }

            function setCordinateOnDrawer(left, top) {
                objDrawerPanel = document.getElementById($scope.tableUtilID);
                if (objDrawerPanel) {
                    objDrawerPanel.style.left = left;
                    objDrawerPanel.style.top = top;
                } else {
                    $timeout(function () {
                        setCordinateOnDrawer(left, top);
                    }, 50);
                }
            }

            ctrl.checkBoxChange = function () {
                ctrl.isSingleSelect && uncheckPrevSelected();
                ctrl.mouseOverEvent();
            }

            ctrl.editRow = function () {
                var paramJson = {
                    row: ctrl.currRow,
                    parent: ctrl.parent,
                    index: ctrl.parent.indexOf(ctrl.currRow)
                }
                if (ctrl.settings.editRowCallBack) {
                    ctrl.settings.editRowCallBack(paramJson);
                }
            }

            var setSelectedIndexes = function(listKey) {
                ctrl[listKey] = [];
                for (var i = 0; i < ctrl.parent.length; i++) {
                    if (ctrl.parent[i] && ctrl.parent[i][ctrl.settings.checkboxModelKey]) {
                        ctrl[listKey].push(i);
                    }
                }                
            };

            ctrl.deactivateRow = function () {
                setSelectedIndexes('deactivateIndexList');
                var paramJson = {                    
                    parent: ctrl.parent,
                    multipleList : ctrl.deactivateIndexList
                };

                for(var i=0; i<ctrl.deactivateIndexList.length; i++) {
                    ctrl.parent[ctrl.deactivateIndexList[i]][ctrl.settings.disableRowKey] = true;                       
                }

                if (ctrl.settings.deactivateRowCallBack) {                   
                    ctrl.settings.deactivateRowCallBack(paramJson);
                } 
                ctrl.mouseOverEvent();
            };

            ctrl.reactivateRow = function () {
                setSelectedIndexes('reactivateIndexList');
                var paramJson = {                    
                    parent: ctrl.parent,
                    multipleList : ctrl.reactivateIndexList
                };

                for(var i=0; i<ctrl.reactivateIndexList.length; i++) {
                    ctrl.parent[ctrl.reactivateIndexList[i]][ctrl.settings.disableRowKey] = false;
                }

                if (ctrl.settings.reactivateRowCallBack) {
                    ctrl.settings.reactivateRowCallBack(paramJson);
                } 
                ctrl.mouseOverEvent();
            };

            ctrl.addNewRowBefore = function () {
                var index = ctrl.parent.indexOf(ctrl.currRow);
                var newRowObject = angular.copy(ctrl.settings.newStaticObject || {});
                ctrl.parent.splice(index, 0, newRowObject);

                if (ctrl.settings.addItemCallBack) {
                    ctrl.settings.addItemCallBack();
                }
            }

            ctrl.addNewRowAfter = function () {
                var index = ctrl.parent.indexOf(ctrl.currRow);
                var newRowObject = angular.copy(ctrl.settings.newStaticObject || {});
                ctrl.parent.splice(index + 1, 0, newRowObject);

                if (ctrl.settings.addItemCallBack) {
                    ctrl.settings.addItemCallBack();
                }
            }

            ctrl.addNewRow = function () {
                var newRowObject = angular.copy(ctrl.settings.newStaticObject || {});
                ctrl.parent.push(newRowObject);

                if (ctrl.settings.addItemCallBack) {
                    ctrl.settings.addItemCallBack();
                }
            }

            ctrl.deleteCurrRow = function () {
                ctrl.isDrawerOpen = false;
                $timeout(function(){
                    var index = ctrl.parent.indexOf(ctrl.currRow);
                    ctrl.parent.splice(index, 1);
    
                    if (ctrl.settings.deleteItemCallBack) {
                        ctrl.settings.deleteItemCallBack([index]);
                    }
                });
            }

            ctrl.deleteAllRow = function () {
                var confirmFlag = confirm(ctrl.strMsg.DELETE_ALL_CONFIRM_MSG);

                if (confirmFlag) {
                    ctrl.isDrawerOpen = false;
                    $timeout(function(){
                        ctrl.parent = [];
    
                        if (ctrl.settings.hasDefaultRecord) {
                            var newRowObject = angular.copy(ctrl.settings.newStaticObject || {});
                            ctrl.parent.push(newRowObject);
                        }
    
                        if (ctrl.settings.deleteItemCallBack) {
                            ctrl.settings.deleteItemCallBack();
                        }
                    },50);
                }
            }

            ctrl.deleteSelectedRow = function () {
                var checkboxModelKey = ctrl.settings.checkboxModelKey;
                ctrl.removedIndexList = [];
                if (checkboxModelKey) {
                    ctrl.isDrawerOpen = false;
                    $timeout(function(){
                        removeSelectedRows();
    
                        if (ctrl.settings.hasDefaultRecord && ctrl.parent.length == 0) {
                            var newRowObject = angular.copy(ctrl.settings.newStaticObject || {});
                            ctrl.parent.push(newRowObject);
                        }
    
                        if (ctrl.settings.deleteItemCallBack) {
                            ctrl.settings.deleteItemCallBack(ctrl.removedIndexList);
                        }
                    },50);
                } else {
                    console.log("Need to define checkboxModelKey in settings")
                }
            }

            function hideShowIconBasedOnSetting() {
                var hideShowSetting = ctrl.settings.hideControlIcon || {};
                ctrl.icon = {
                    insertBefore: !(hideShowSetting.insertBefore == 0),
                    insertAfter: !(hideShowSetting.insertAfter == 0),
                    deleteSelected: !(hideShowSetting.deleteSelected == 0),
                    deleteAllRow: !(hideShowSetting.deleteAllRow == 0),
                    editRow: !(hideShowSetting.editRow == 0),
                    deactivateRow: (hideShowSetting.deactivateRow == 1),
                    reactivateRow: (hideShowSetting.reactivateRow == 1),
                }
            }

            function hideEditIconIfMultipleCheckboxSelected(){
                var checkboxModelKey = ctrl.settings.checkboxModelKey;
                var hideShowSetting = ctrl.settings.hideControlIcon;
                var counterCheck = 0;
                for (var index = 0; index < ctrl.parent.length; index++) {
                    if (ctrl.parent[index] && ctrl.parent[index][checkboxModelKey]) {
                        counterCheck++;
                    }
                }

                if(counterCheck > 1){
                    ctrl.icon.editRow = false;
                    ctrl.icon.insertBefore = false;
                    ctrl.icon.insertAfter = false;
                }else{
                    if( !(hideShowSetting && hideShowSetting.editRow == 0) ){
                        ctrl.icon.editRow = true;
                    }

                    if( !(hideShowSetting && hideShowSetting.insertBefore == 0) ){
                        ctrl.icon.insertBefore = true;
                    }

                    if( !(hideShowSetting && hideShowSetting.insertAfter == 0) ){
                        ctrl.icon.insertAfter = true;
                    }
                }
            }

            function removeSelectedRows() {
                var isRepeate = false;
                var checkboxModelKey = ctrl.settings.checkboxModelKey;                
                !isRepeate && (ctrl.removedIndexList = ctrl.parent.filter(function(itemObj) {
                    return itemObj[checkboxModelKey];
                })).map(function(obj, index){
					return index;
				});
                for (var index = 0; index < ctrl.parent.length; index++) {
                    if (ctrl.parent[index] && ctrl.parent[index][checkboxModelKey]) {
                        var index = ctrl.parent.indexOf(ctrl.parent[index]);
                        ctrl.parent.splice(index, 1);
                        isRepeate = true;
                        break;
                    }
                }

                if (isRepeate) {
                    removeSelectedRows();
                } else {
                    ctrl.isDrawerOpen = false;            
                }
            }
        }],
        bindings: {
            currRow: '=', // pass current row as object of table
            parent: '=', // pass parent table's array which contains object
            settings: '=', // configure setting for the componets
            ischecked: '=', // if checkbox checked or not, it expect true/false   
            isSingleSelect : '<', // restrict to select onle one row at a time.
            appendTo: '@' // append drawer util panel for specific element - need to pass selector
        }
    });
});

