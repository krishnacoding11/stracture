/**
 * InlineAttachment component.
 * This module will initialize the InlineAttachment component for angular application[ HTML5 forms ].
 * @module InlineAttachment
 */
define(['angular', 'mainModule'], function (angular, mainModule) {

	'use strict';

	function multipleInlineattachmentController($scope, $compile, $rootScope, $attrs, $http, $timeout, api, apiConfig, myConfig, attachmentApi, FileUploader, Notification, manageDataCenter, $uibModal) {
		var ctrl = this;
		var ATTACH_STR = "attchment_xdoc_";
		var XDOC_STR = "xdoc_";
		var IMG_ID_PREFIX = 'imgupload_';
		var ATTACHMENT_FIELD_ID = "attachment_fields";
		var THUMBNAIL = "thumbnail_"
		ctrl.fileValue = null;
		ctrl.removeFileIcon = false;
		ctrl.initialized = false;
		ctrl.ignoreChangeEvent = false;
		ctrl.files = [];
		ctrl.defaultMsg = "";
		var isOffLine = function () {
			return (window.applicationId == 2 ? !qtObject.systemOnlineCallBack() : navigator.onLine == false);
		};

		ctrl.attachmentForIOS = false;
		ctrl.$onInit = function () {

			if (ctrl.generateThumbnail == undefined || ctrl.generateThumbnail == null) {
				ctrl.generateThumbnail = false;
			}
			attachmentApi.register($scope, ctrl);

			if (window.applicationId == 3 && (/Android|iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform == 'MacIntel') && !window.MSStream) {
				ctrl.attachmentForIOS = true;
			}

			// set default select message...
			ctrl.defaultMsg = ctrl.labelText ? ctrl.labelText : Language.get('add-files');

//changes for readonly 
			ctrl.readonly = $attrs.readonly == "" || $attrs.readonly == "readonly" || $attrs.readonly == "true" || !document.myform || false;
			ctrl.objName = ctrl.name();
			initAttachment();

			$timeout(function () {
				var inputTag = document.getElementById(IMG_ID_PREFIX + ctrl.objName);
				angular.element(inputTag).on('change', function (event) {
					$timeout(function () {
						var uploadedFiles = event.target.files;
						if (event && uploadedFiles && uploadedFiles.length > 0) {
							for (var i = 0; i < uploadedFiles.length; i++) {
								var file = {};
								file.revisionId = '';
								file.isUploading = true;
								file.filename = uploadedFiles[i].name;
								file.xdocId = i+'_'+genXdocId();
								file.elementId = file.xdocId + ':' + ctrl.objName;
								file.removeFileIcon = false;
								// will remove the old attached file from Form
								var validationObj = attachmentApi.invalidFileName(file.filename);
								if (!validationObj.valid) {
									removeAttachmentField(file);
									alert('Invalid File Name\n' + validationObj.error);
									event.target.value = '';
									return;
								}

								uploadFileNameValidation(file.filename,uploadedFiles[i],file, function (targetFile,fileObj) {
									angular.element("#btnSaveForm")[0].disabled = true;
									if(angular.element("#btnSaveDraft")[0])
									angular.element("#btnSaveDraft")[0].disabled = true;
									ctrl.files.push(fileObj);
									if (window.adoddleBaseUrl) {
										ctrl.UploadFile(targetFile, fileObj);
									} else if ($scope.uploader) {
										if ($scope.uploader) {
											$scope.uploader.addToQueue(targetFile,fileObj)
										}
									}
								});
							}

						}
						//delete target value in order to trigger on change of file upload
						event.target.value = '';
					}, 10);
				});
			}, 500);

			$scope.$on('assocChange', function (event, extra) {
				if (extra && extra.deleted && extra.deleted.length) {
					for (var i = 0; i < extra.deleted.length; i++) {
						var d = extra.deleted[i];

						var curIndex = ctrl.files.findIndex(function (item) {
							return item.revisionId == d.revisionId;
						});
						if (curIndex && curIndex != -1 && ctrl.files[curIndex].revisionId && ctrl.files[curIndex].removeFileIcon) {
							if (d.revisionId.split('$$')[0] == ctrl.files[curIndex].revisionId.split('$$')[0]) {
								removeAttachmentField(ctrl.files[curIndex]);
								break;
							}
						}
					}
				}
			});

			ctrl.initialized = true;
		};

		var initAttachment = function () {
			if (ctrl.fileSet && typeof(ctrl.fileSet) == 'string') {
				try {
					var val = JSON.parse(ctrl.fileSet);
					ctrl.fileSet = val;
				} catch (e) {
					console.log(e);   
				}
			}
			if (ctrl.fileSet.length > 0) {
				for (var k = 0; k < ctrl.fileSet.length; k++) {
					var fileObj = ctrl.fileSet[k];
					var fileItem = {
						'filename': '',
						'removeFileIcon': true,
						'fileText': '',
						'fileSet': fileObj,
						'thumbnailSrc': null,
						'isUploading': false,
						'isAttachmentUploaded': false,
					}
					if (fileObj && fileObj.content) {// Form Onload when component initialize
						var fileName = fileObj.content;
						fileName = fileName && fileName.substr(fileName.indexOf('my_') + 3, fileName.length - 1);
						fileName = fileName.split('#')[0];
						fileItem.filename = fileName;
						fileItem.fileText = fileName;
						fileItem.removeFileIcon = true;
						ctrl.removeFileIcon = true;
						fileItem.caption = fileObj['@caption'] ? fileObj['@caption'] : fileName;
						var attachmentId = (fileObj.content).split("#")[5];
						attachmentId = attachmentId ? attachmentId.split("$$")[0] : null;
						var plainRevisionId = "&attachmentId=" + attachmentId;
						var plainProjectId = myConfig.projectId && myConfig.projectId.split("$$")[0];
						var filetype = api.getFileExtImage(api.getExt(fileName));	
						if(myConfig.isOfflineMode) {	
							fileItem.offlineActualPath = fileObj['OfflineContent'] ? fileObj['OfflineContent'].upFilePath:myConfig.offlineAttachmentPath+'/' +attachmentId +'.'+ filetype;	
						}	
						fileItem.thumbnailSrc = getThumbnailSrc(fileItem, fileName, plainRevisionId, plainProjectId,attachmentId);

					} else if (fileObj && fileObj['@inline']) { // When attachment done and Attachment cotrol re-initilize on hide/show
						fileItem['inputHiddenAttachObj'] = document.getElementById(fileObj['@inline']);
						if (fileItem['inputHiddenAttachObj'] && fileItem['inputHiddenAttachObj'].value) {

							var fileName = fileItem['inputHiddenAttachObj'].value
							fileName = fileName && fileName.replace('xdInlineFile:/', '');
							fileItem.fileText = fileName;
							fileItem.filename = fileName;
							fileItem.removeFileIcon = true;
							ctrl.removeFileIcon = true;
						}
					}

					var tmpInlineStr = fileObj && fileObj['@inline'];
					if (tmpInlineStr && tmpInlineStr.indexOf(ctrl.objName) > -1) {
						tmpInlineStr = tmpInlineStr.replace(XDOC_STR, '');
						fileItem.xdocId = tmpInlineStr.substr(0, tmpInlineStr.indexOf(':'));
						fileItem.elementId = tmpInlineStr;

						insertFieldWithHasData(true);

						var rev = fileObj.content || "";
						if (document.myform && rev) {
							rev = rev && rev.substr(rev.indexOf('my_') + 3, rev.length - 1);
							rev = rev.split('#')[1];
							fileItem.revisionId = rev;
							insertAttachmentField('#REV#' + rev, fileItem);
						}
					} else {
						fileItem.xdocId = k+'_'+genXdocId();
						fileItem.elementId = fileItem.xdocId + ':' + ctrl.objName;
					}
					if (fileItem.filename) {
						ctrl.files.push(fileItem);
					}
				}
			}

			if (!ctrl.readonly && !window.adoddleBaseUrl) {
				initUploader();
			}
		};

		var initUploader = function () {
			var tmpName = ATTACH_STR + ctrl.xdocId;
			ctrl.isUploading = false;
			var param = {
				msgId: document.getElementById("msgId") && document.getElementById("msgId").value,
				fieldId: tmpName,
				eOriDraftMsgId: document.getElementById("eOriDraftMsgId") && document.getElementById("eOriDraftMsgId").value,
				editORI: document.getElementById("editORI") && document.getElementById("editORI").value,
				save_draft: "0",
				fileType: apiConfig.UPLOAD_TYPE.INLINE_FORM,
			};

			if (ctrl.generateThumbnail) {
				param.isThumbnailSupports = ctrl.generateThumbnail;
				param.autoPublishToFolder = myConfig.autoPublishToFolder;
				param.fileSize = '';
				param.uploadedAttachmentFileDetails = null;
			}

			var uploader = $scope.uploader = new FileUploader({
				url: (window.adoddleBaseUrl || "") + apiConfig.ADODDLE_UPLOAD_CONTROLLER + '?action_id=1203',
				alias: 'UploadFile',
				type: 'POST',
				formData: [param],
				autoUpload: true,
				removeAfterUpload: false,
				withCredentials: true,
				retries: 0,
				maxRetries: window.uploadMaxRetry || 1800,
				retryTimeout: window.uploadRetryTimeout || 500,
				chunkUpload: true,
				chunkSize: myConfig.uploadChunkSize
			});

			uploader.onAfterAddingAll = function (fileItems) {
				for (var i = 0; i < fileItems.length; i++) {
					var item = fileItems[i];
					var fileName = item.file && item.file.name;
					item.sortSize = api.getSortFileSize(item.file.size);
					item.icon = api.getFileExtImage(api.getExt(fileName));
				}

				$timeout(function () {
					ctrl.isUploading = uploader.isUploading;
				})
			};

			uploader.onBeforeUploadItem = function (item) {
				var curIndex = ctrl.files.findIndex(function (i) {
					return i.elementId == item.elementId;
				});
				ctrl.files[curIndex].isUploading = true;
				ctrl.isUploading = true;
				item.formData[0].attachTempFolderId = ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID;
				item.formData[0].fieldId = ATTACH_STR + item.xdocId;
				if (ctrl.generateThumbnail) {
					item.formData[0].fileSize = item.file.size;
					myConfig.appTypeId && (item.formData[0].appTypeId = myConfig.appTypeId);
					ctrl.generateThumbnail && (item.formData[0].isThumbnailSupports = ctrl.generateThumbnail);
					item.formData[0].autoPublishToFolder = myConfig.autoPublishToFolder;
				}
			};

			uploader.onSuccessItem = function (item, response, status, headers) {
				item.resp = response;
			};

			uploader.onCompleteItem = function onCompleteItem(item, response, status, headers) {
				uploadSuccess(item.file.name, item);
				validateFileType(item.file.type, item.file.name);
			};

			uploader.onDisconnect = function (item, success, error) {
				var obj = {
					action_id: 1204,
					fileType: apiConfig.UPLOAD_TYPE.INLINE_FORM,
					fileName: item._lastResp ? item._lastResp.fileName : item.file.name
				};

				var xhr = api.ajax({
					url: (window.adoddleBaseUrl || "") + apiConfig.ADODDLE_UPLOAD_CONTROLLER,
					data: obj
				});

				xhr.then(function (response) {
					var fileSize = 0;
					if (response.fileExists == "true") {
						fileSize = parseInt(response.fileSize);
					}
					success(fileSize);
				}, function (xhr) {
					error && error(xhr);
				});
			};

			uploader.onErrorItem = function (item, response, status, headers) {
				var curIndex = ctrl.files.findIndex(function (i) {
					return i.elementId == item.elementId;
				});
				ctrl.files.splice(curIndex, 1);
			};
		};

		ctrl.$onChanges = function (changedProps) {
			if (changedProps && ctrl.initialized) {
				if (changedProps.inlineData != undefined) {
					if (ctrl.ignoreChangeEvent) {
						ctrl.ignoreChangeEvent = false;
					} else {
						if (changedProps.inlineData.currentValue) {
							initAttachment();
						} else {
							ctrl.removeUploadedFile(true);
						}
					}
				}
			}
		}

		ctrl.$onDestroy = function () {
			ctrl.ignoreChangeEvent = false;
			attachmentApi.unregister($scope, ctrl);
		}

			
		function getThumbnailSrc(item, fileName, plainRevisionId, plainProjectId,revId) {	
			var thumbSrc = './images/file-size-518.svg';	
			var filetype = api.getFileExtImage(api.getExt(item.filename));	
			if (myConfig.isOfflineMode) {	
				if (apiConfig.OFFLINE_THUMBNAIL_SUPPORTED_EXTENSION	
					.indexOf(filetype.toUpperCase()) != -1) {	
					if (item.offlineAttachmentPath) {	
						thumbSrc = item.offlineAttachmentPath;	
					}	
					else {	
						var oflinepath = myConfig.offlineAttachmentPath;	
						thumbSrc = oflinepath + '/' + revId + '.' + api.getExt(item.filename);	
					}	
				} else {	
					thumbSrc = './images/Asite_file_type_icons/svg/'+ filetype + '_icon.svg';	
				}	
			}	
			else {	
				if(item.filename) {	
				if (apiConfig.THUMBNAIL_SUPPORTED_EXTENSION	
					.indexOf(filetype.toUpperCase()) != -1) {	
					if (plainProjectId && plainRevisionId) {	
						thumbSrc = myConfig.baseUrl + apiConfig.THUMBNAIL_VIEW_PATH + "?projectId=" + plainProjectId + plainRevisionId;	
					} else {	
						thumbSrc = myConfig.baseUrl + apiConfig.THUMBNAIL_VIEW_TEMP_PATH + "?fileName=" + encodeURIComponent(fileName) + "&projectId=" + myConfig.projectId.split("$$")[0] + "&folderId=" + item.formData[0].attachTempFolderId + "&isInline=true";	
					}	
				} else {	
					thumbSrc = '/images/Asite_file_type_icons/svg/'+ filetype + '_icon.svg';	
				}	
			}	
			}	
			return thumbSrc;	
		}

		function validateFileType(fileType, fileName) {
			if (ctrl.fileType && ctrl.fileType != "false") {
				var unsupportedFormat = false;
				//If fileType ends with '/*'
				if (ctrl.fileType.indexOf('/*') != -1 && (ctrl.fileType.length - ctrl.fileType.indexOf('/*') == 2)) {
					unsupportedFormat = ctrl.fileType.split('/*')[0] != fileType.split('/')[0];
				} else {
					unsupportedFormat = ctrl.fileType.indexOf(api.getExt(fileName).toLocaleLowerCase()) == -1;
				}
				if (unsupportedFormat) {
					var msg = "Apologies! Files with only " + ctrl.fileType + " extension are supported.";
					Notification.error({
						message: msg
					});
					ctrl.removeUploadedFile(undefined, item)
				}
			}
		}

		function uploadSuccess(fileName, item, isMobile) {//changes
			ctrl.removeFileIcon = true;
			if (isMobile) {
				var formDataObj = {
					fieldId: ATTACH_STR + item.xdocId,
					attachTempFolderId: ctrl.generateThumbnail ? ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID : undefined,
				}
				myConfig.appTypeId && (formDataObj['appTypeId'] = myConfig.appTypeId);
				if (ctrl.generateThumbnail) {
					formDataObj['fileSize'] = item.fileSize;
					myConfig.appTypeId && (formDataObj['appTypeId'] = myConfig.appTypeId);
					ctrl.generateThumbnail && (formDataObj['isThumbnailSupports'] = ctrl.generateThumbnail);
					formDataObj['autoPublishToFolder'] = myConfig.autoPublishToFolder;
				}
				var formData = [];
				formData.push(formDataObj);
				item['formData'] = formData;
				ctrl.files.push(item);
			}
			var xdName = XDOC_STR + item.elementId;
			insertAttachmentField(null, item);
			insertThumbnail(fileName, item);
			var curIndex = ctrl.files.findIndex(function (i) {
				return i.elementId == item.elementId;
			});
			ctrl.files[curIndex].isUploading = false;
			ctrl.files[curIndex].isAttachmentUploaded = true;
			ctrl.files[curIndex].removeFileIcon = true;
			ctrl.files[curIndex]['fileText'] = item.filename;
			ctrl.files[curIndex]['caption'] = item.filename;
			ctrl.files[curIndex]['fileSet'] = {
				'@inline': xdName,
				'content': "",
				'@caption': item.filename,
			}
			if(myConfig.isOfflineMode) {
				ctrl.files[curIndex]['fileSet']['OfflineContent'] = {	
			        "fileType": apiConfig.UPLOAD_TYPE.INLINE_FORM,	
			        "isThumbnailSupports": ctrl.generateThumbnail,	
			        "upFilePath": item.offlineAttachmentPath	
				}
			}
			ctrl.fileSet.push(ctrl.files[curIndex].fileSet);
			ctrl.ignoreChangeEvent = true;
			$timeout(function () {
				function checkLength(fileItm) {
					return fileItm.isUploading == true;
				}
				if (ctrl.files.filter(checkLength).length > 0) {
					ctrl.isUploading = true;
					angular.element("#btnSaveForm")[0].disabled = true;
					if(angular.element("#btnSaveDraft")[0])
					angular.element("#btnSaveDraft")[0].disabled = true;
				} else {
					ctrl.isUploading = false;
					angular.element("#btnSaveForm")[0].disabled = false;
					if(angular.element("#btnSaveDraft")[0])
					angular.element("#btnSaveDraft")[0].disabled = false;
				}
				ctrl.attachmentChange && ctrl.attachmentChange();
			}, 100);
		}

		/**
		 * To upload file in server using ajax call
		 * @param {Object} parms : Formdata param passed to upload file
		 * @param {String} fName : File name of uploaded file
		 */
		var sendHtml5InlineFile = function (parms, fileName,file) {
			$http({
				method: "post",
				headers: {
					'Content-Type': undefined,
					'hasattachment': true
				},
				withCredentials: true,
				url: (window.adoddleBaseUrl || "") + "/adoddle/apps?action_id=1730",
				transformRequest: angular.identity,
				data: parms
			}).then(function () {
				uploadSuccess(fileName, file);
			}, function myError(errors) {
				removeAttachmentField(file);
				ctrl.isUploading = false;
				angular.element("#btnSaveForm")[0].disabled = false;
				if(angular.element("#btnSaveDraft")[0])
				angular.element("#btnSaveDraft")[0].disabled = false;
			});
		}

		function downloadInlineAttachment(file) {
			var fieldStr = file.fileSet.content;
			if (fieldStr) {
				var splitValue = fieldStr.split('#');
				var msgId = splitValue[2];
				var revId = splitValue[splitValue.length - 1];

				var tmpFieldVal = splitValue[3];
				var fieldName = tmpFieldVal.substr(tmpFieldVal.indexOf('_xdoc_'), tmpFieldVal.length - 1);
				var fileName = file.fileText;


				document.download.action_id.value = 200;
				document.download.fileName.value = encodeURIComponent(fileName);
				document.download.fieldName.value = fieldName;
				document.download.paramComingFrom.value = "CformAttachment";
				document.download.msgId.value = msgId;
				document.download.revision_id.value = revId;
				document.download.target = "_blank";

				var tempRev = revId.split("$$");
				document.download.revisionidak.value = tempRev[0];

				var FORM_AUDIT_TRAIL_ACTION_DOWNLOADED = 30;

				if (document.download.auditActionId) { //For classic audit entry not required
					document.download.auditActionId.value = FORM_AUDIT_TRAIL_ACTION_DOWNLOADED;
				}

				var apiUrl = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, myConfig.downloadServiceURL) + apiConfig.DOWNLOAD_CUSTOM_FORM_ATTACHMENT;

				if (myConfig.applicationId == 3) {
					var formdata = angular.element(document.download).serializeArray();
					var data = {};
					for (var i = 0; i < formdata.length; i++) {
						data[formdata[i].name] = formdata[i].value;
					}
					sendEventToIpad("inlineAttachmentDownload:" + angular.toJson({
						"url": apiUrl,
						"data": data
					}));
				} else {
					document.download.setAttribute('action', apiUrl);
					document.download.submit();
				}
			}
		}

		function insertFieldWithHasData(isOnLoad) {//These function add attachment_field with has separeted
			var tmpName = XDOC_STR + (Math.random() * 9 | 0) + '_' + (Math.random() * 9 | 0) + '_' + ATTACHMENT_FIELD_ID;
			var tmpId = XDOC_STR + ATTACHMENT_FIELD_ID;
			if (!ctrl.readonly && isOnLoad) {
				if (!document.getElementById(tmpId)) {
					var tmpInput = document.createElement('input');
					tmpInput.type = "hidden";
					tmpInput.name = tmpName;
					tmpInput.id = tmpId;

					document.myform.appendChild(tmpInput);
				}
				var tmpField = document.getElementById(tmpId);
				var tmpFieldVal = tmpField.value;

				var xdName = XDOC_STR + ctrl.elementId;
				if (!tmpFieldVal) {
					tmpField.value = xdName;
				} else {
					tmpField.value = tmpFieldVal + '#' + xdName;
				}
			}
		}

		function insertAttachmentField(rev, item) {
			var tmpName = ATTACH_STR + item.xdocId;
			var xdName = XDOC_STR + item.elementId;

			var tmpInput = document.getElementById(tmpName);
			if (!tmpInput) {
				var tmpInput = document.createElement('input');
				tmpInput.type = "hidden";
				tmpInput.name = tmpName;
				tmpInput.id = tmpName;
			}

			tmpInput.value = rev || ("C:\/fakepath\/" + item.filename);

			var xdInput = document.getElementById(xdName);
			if (!xdInput) {
				xdInput = document.createElement('input');
				xdInput.type = "hidden";
				xdInput.name = xdName;
				xdInput.id = xdName;
			}

			xdInput.value = "xdInlineFile:/" + item.filename;

			document.myform.appendChild(tmpInput);
			document.myform.appendChild(xdInput);
			if (ctrl.generateThumbnail) {
				var thumbnailName = THUMBNAIL + ctrl.generateThumbnail;
				var thumbnailInput = document.getElementById(thumbnailName);
				if (!thumbnailInput) {
					thumbnailInput = document.createElement('input');
					thumbnailInput.type = "hidden";
					thumbnailInput.name = thumbnailName;
					thumbnailInput.id = thumbnailName;
					thumbnailInput.value = ctrl.generateThumbnail;
					document.myform.appendChild(thumbnailInput);
				}
			}

		}

		function insertThumbnail(fileName, item) {
			if (item && ctrl.generateThumbnail) {
				if (!fileName) {
					return;
				}

				if (item && item.resp && item.resp.uploadedAttachmentFileDetails) {
					fileName = item.resp.uploadedAttachmentFileDetails.split('|')[0];
				}
				var curIndex = ctrl.files.findIndex(function (i) {
					return i.elementId == item.elementId;
				});
				if(myConfig.isOfflineMode) {	
					ctrl.files[curIndex]['offlineActualPath'] = item.offlineAttachmentPath	
				}	
				ctrl.files[curIndex].thumbnailSrc = getThumbnailSrc(item, fileName);
			}
		}

		function removeAttachmentField(file) {
			if (file) {
				var tmpName = ATTACH_STR + file.xdocId;
				var xdName = XDOC_STR + file.elementId;

				var formInput = document.myform[tmpName];
				var xdformInput = document.myform[xdName];

				if (formInput) {
					formInput.remove();
				}

				if (xdformInput) {
					xdformInput.remove();
				}

				var attachmentCont = document.getElementById(file.elementId);
				if (attachmentCont) {
					attachmentCont.remove();
				}
			}
		}

		function uploadFileNameValidation(fileName,targetFile,fileObj, callback) {
			if (!myConfig.autoPublishToFolder || !myConfig.projectId || !myConfig.autoPublishFolderId || myConfig.autoPublishFolderId == 'null') {
				callback && callback(targetFile,fileObj);
				return;
			}

			var xhr = api.ajax({
				url: (window.adoddleBaseUrl || "") + apiConfig.UPLOAD_CONTROLLER,
				data: {
					action_id: apiConfig.UPLOAD_FILE_VALIDATION_NEW,
					project_id: myConfig.projectId,
					folder_id: myConfig.autoPublishFolderId,
					validationType: apiConfig.VALIDATION_TYPE.VALIDATION_ON_ENTER_DOC_DETAILS,
					forPublishing: false,
					caller: 2,
					rowNumbers: 1,
					filename1: fileName
				}
			});

			xhr.then(function (data) {
				if (data.docNamingRuleValidation && data.docNamingRuleValidation !== "null") {
					removeAttachmentField(fileObj);
					showFileNamingRuleValidationExceptions(data.docNamingRuleValidation);
					return;
				}

				var errors = data.fileNameValidation;
				if (errors && errors.length) {
					removeAttachmentField(fileObj);
					if (showFileValidationExceptions(errors)) {
						return;
					}
				}

				callback && callback(targetFile,fileObj);
			}, function (xhr) {
				removeAttachmentField(fileObj);
				alert("Error while file validation!!");
			});
		}

		function showFileNamingRuleValidationExceptions(docrefExceptionList) {
			var msg = Language.get('doc-ref-duplication-error');
			if (docrefExceptionList.length) {
				msg = '<p>' + Language.get('doc-ref-duplication-error') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th></tr>';
				docrefExceptionList.forEach(function (docrefException, index) {
					msg += '<tr><th>' + docrefException[0] + '</th><th>' + docrefException[1] + '</th></tr>';
				});
				msg += '</table>';
			} else if (docrefExceptionList.maxLengthExceedList && docrefExceptionList.maxLengthExceedList.length) {
				msg = '<p>' + Language.get('exceeded-alloable-length') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th></tr>';
				docrefExceptionList.maxLengthExceedList.forEach(function (docrefException, index) {
					msg += '<tr><th>' + docrefException[0] + '</th><th>' + docrefException[1] + '</th></tr>';
				});
				msg += '</table>';
			} else if (docrefExceptionList.lableRuleViolationList && docrefExceptionList.lableRuleViolationList.length) {
				msg = '<p>' + Language.get('exceeded-alloable-length') + "</p></br>";
				msg += '<table><tr><th>' + Language.get('fileName') + '</th><th>' + Language.get('doc-ref') + '</th><th>' + Language.get('incorrect-naming-lables') + '</th><th>' + Language.get('suggested-naming-lables') + '</th></tr>';
				docrefExceptionList.lableRuleViolationList.forEach(function (docrefException, index) {
					msg += '<tr><th>' + docrefException.filename + '</th><th>' + docrefException.docref + '</th><th>' + docrefException.inCorrectNamingLable + '</th><th>' + docrefException.suggestedNamingLable + '</th></tr>';
				});
				msg += '</table>';
			}

			Notification.error({
				message: msg
			});
		}

		function showFileValidationExceptions(exceptionList) {
			for (var i = 0; i < exceptionList.length; i++) {
				var v = exceptionList[i];

				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_VALID_EXISTING_FILES) {
					continue;
				}

				// Validating CODE_EXTENSION_LESS_FILENAME
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_EXTENSION_LESS_FILENAME) {
					if (v.uploadedDocRefNonIFC) {
						var msg = '<p>' + Language.get("already-uploaded-ifc-file") + "</p></br>";
						v.uploadedDocRefNonIFC.forEach(function (IFCRef, index) {
							msg += index + 1 + '.  ' + IFCRef + "</br>";
						});
						Notification.error({
							message: msg
						});
						return true;
					}

					if (v.fileNames) {
						continue;
					}
				}

				// Validating CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION && v.docRefs) {
					var msg = '<p>' + Language.get('you-do-not-have-incomplete-for-publish-for-docref') + "</p></br>";
					v.docRefs.forEach(function (docRef, index) {
						msg += index + 1 + '.  ' + docRef + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_LINKED_FILE
				if (v.linkedFileList && v.linkedFileList.length) {
					var msg = '<p>' + Language.get('already-linked-file') + "</p></br>";
					v.linkedFileList.forEach(function (linkedFile, index) {
						msg += index + 1 + '.  ' + linkedFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_FILE_CHECKED_OUT 
				if (v.checkedOutFileList && v.checkedOutFileList.length) {
					var msg = '<p>' + Language.get('already-checked-out-file') + "</p></br>";
					v.checkedOutFileList.forEach(function (checkedOutFile, index) {
						msg += index + 1 + '.  ' + checkedOutFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_DEACTIVATED_FILE
				if (v.deactivatedFileList && v.deactivatedFileList.length) {
					var msg = '<p>' + Language.get('alread-deactivated-file') + "</p></br>";
					v.deactivatedFileList.forEach(function (deactivatedFile, index) {
						msg += index + 1 + '.  ' + deactivatedFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}

				// Validating CODE_REVISION_UPLOAD_ACTIVITY_LOCK
				if (v.messageCode == apiConfig.FILESATTRIBUTES_EXCEPTIONCODE.CODE_REVISION_UPLOAD_ACTIVITY_LOCK && v.uploadlockFileList && v.uploadlockFileList.length) {
					var msg = '<p>' + Language.get('locked-files-msg') + "</p></br>";
					v.uploadlockFileList.forEach(function (uploadlockFile, index) {
						msg += index + 1 + '.  ' + uploadlockFile + "</br>";
					});

					Notification.error({
						message: msg
					});
					return true;
				}
			}

			return false;
		}

		ctrl.UploadFile = function (file, fileProps) {
			var inputTag = document.getElementById('imgupload_' + ctrl.objName);
			var tmpName = ATTACH_STR + fileProps.xdocId;

			if (inputTag.files[0]) {
				ctrl.isUploading = true;
				var tmpFormData = new FormData();
				tmpFormData.append('action', "1730");
				tmpFormData.append('msgId', document.getElementById("msgId").value);
				tmpFormData.append('fieldId', tmpName);
				tmpFormData.append('eOriDraftMsgId', document.getElementById("eOriDraftMsgId").value);
				tmpFormData.append('editORI', document.getElementById("editORI").value);
				tmpFormData.append('save_draft', "0");
				tmpFormData.append('UploadFile', file);
				sendHtml5InlineFile(tmpFormData, fileProps.filename, fileProps);
			} else {
				alert("Please attach file");
			}
		}

		ctrl.removeUploadedFile = function (silent, file) {
			ctrl.ignoreChangeEvent = !silent;
			removeAttachmentField(file);
			if (!silent) {
				$timeout(function () {
					ctrl.attachmentChange && ctrl.attachmentChange();
				}, 100);
			}

			var curIndex = ctrl.files.findIndex(function (i) {
				return i.elementId == file.elementId;
			});
			// will remove the related attached file from Form
			ctrl.files[curIndex]['revisionId'] && $rootScope.$broadcast('assocDelete', { deleted: [ctrl.files[curIndex]['revisionId']], key: 'revisionId', type: 'attachments' });
			ctrl.files.splice(curIndex, 1);
			var xdName = XDOC_STR + file.elementId;
			var curIndexFileSet = ctrl.fileSet.findIndex(function (i) {
				if(file.fileSet && file.fileSet['@inline']) {
					return i['@inline'] == file.fileSet['@inline'];
				} else {
					return i['@inline'] == xdName;
				}
				
			});
			ctrl.fileSet.splice(curIndexFileSet, 1);
			$timeout(function () {
				if(!(ctrl.files.length > 0)) {
					ctrl.removeFileIcon = false;
				}
			}, 1000);
		}

		ctrl.openUploadDialog = function (file) {	
			if(myConfig.isOfflineMode) {	
				var attachItem = {	
					'FileName' : file.filename || '',
					'OfflineAttachFilePath':file['offlineActualPath'] || file.thumbnailSrc	
				}	
				sendEventToIpad("viewCreateAttachment:"+JSON.stringify(attachItem))	
			} else {	
				ctrl.readonly = $attrs.readonly == "" || !document.myform || false;	
				ctrl.readonly && downloadInlineAttachment(file);	
			}	
		}

		ctrl.showImagePreview = function (filename, elementId, file) {
			var attachmentCtrl = ctrl;
			var files = ctrl.files;
			var modalInstance = $uibModal.open({
				animation: true,
				ariaLabelledBy: 'modal-title',
				ariaDescribedBy: 'modal-body',
				windowTopClass: 'modal-preview',
				template: '<div"name="fileViewModal" >' +
					'<div class="modal-header">' +
					'<h4 class="modal-title" id="modal-title" style="display:inline-block;">' + Language.get('attachment-label') + '</h4>' +
					'<button type="button" class="close" ng-click="$ctrlModal.cancel()"><i class="fa fa-close"></i></button>' +
					'</div>' +
					'<div class="modal-body template-modal" id="modal-body">' +
					'<div>' +
					'<div style="margin-left: 14px;"><p ng-if="!' + attachmentCtrl.readonly + '" href="javascript:void(0);">{{$ctrlModal.filename}}</p>' +
					'<a ng-if="' + attachmentCtrl.readonly + '" href="javascript:void(0);" ng-click="$ctrlModal.downloadFile($ctrlModal.file)">{{$ctrlModal.filename}}</a></div>' +
					'<div style="display: flex;flex-direction: row;align-items: center;justify-content: center;"> ' +
					'<a ng-if="!$ctrlModal.isMobile" style="color:#757575;" role="button" href class="" ng-click="$ctrlModal.previous()">' +
					'<span style="font-size:1.2em;" class="glyphicon glyphicon-chevron-left"></span>' +
					'</a>' +
					'<div style="height: 350px;width: calc(100% - 50px);align-items: center;justify-content: center;display: flex;"><img name="{{$ctrlModal.filename}}" style="max-height:100%;max-width: 100%;object-fit: contain;" ng-src="{{$ctrlModal.filepath}}"  onerror="thumbnailInlineFailCallback(this);" onload="successCallback(this);"></img></div>' +
					'<a ng-if="!$ctrlModal.isMobile" style="color:#757575;" role="button" href class="" ng-click="$ctrlModal.next()">' +
					'<span style="font-size:1.2em;"class="glyphicon glyphicon-chevron-right"></span>' +
					'</a>' +
					'</div>' +
					'</div>' +
					'<div style="width:94%;margin:auto;" ng-if="$ctrlModal.isMobile">' +
					'<a style="color:#757575;float:left;" role="button" href class="" ng-click="$ctrlModal.previous()">' +
					'<span style="font-size:2.2em;" class="glyphicon glyphicon-chevron-left"></span>' +
					'</a>' +
					'<a style="color:#757575;float:right;" role="button" href class="" ng-click="$ctrlModal.next()">' +
					'<span style="font-size:2.2em;" class="glyphicon glyphicon-chevron-right"></span>' +
					'</a>' +
					'</div>' +
					'<div name="captionForm" class="form-group" style="margin-left:14px;clear:both;margin-top: 10px;">' +
					'<div ng-if="' + attachmentCtrl.isCaption + '"><label style="font-weight: initial;">' + Language.get('caption') + '</label></div>' +
					'<input ng-if="' + attachmentCtrl.isCaption + '" style="width:97%;" class="form-control" ng-change="$ctrlModal.updateCaption($ctrlModal.filename)" type= "text" placeholder="Add caption" maxlength="50" ng-model="$ctrlModal.caption" ng-disabled="' + attachmentCtrl.readonly + '" />' +
					'</div>' +
					'</div>' +
					'<div ng-hide="' + attachmentCtrl.readonly + '" class="modal-footer">' +
					'<button class="btn btn-default" type="button" ng-click="$ctrlModal.cancel()">' + Language.get('cancel') + '</button>' +
					'<button class="btn btn-danger" type="button" ng-click="$ctrlModal.ok()"  ng-dblclick="return">' + Language.get('save') + '</button>' +
					'</div>' +
					'</div>',
				backdrop: true,
				keyboard: false,
				controllerAs: '$ctrlModal',
				controller: function () {
					this.filename = filename;
					this.filepath = file.thumbnailSrc;
					this.curIndex = files.findIndex(function (i) {
						return i.elementId == elementId;
					});
					this.file = files[this.curIndex];
					if (this.curIndex >= 0) {
						this.filepath = files[this.curIndex].thumbnailSrc;
						this.caption = files[this.curIndex].fileSet ? files[this.curIndex].fileSet['@caption'] : this.filename;
					}
					this.isMobile = (function () {
						if (navigator.userAgent && window.innerWidth < window.innerHeight && (navigator.userAgent.match(/Android/i)
							|| navigator.userAgent.match(/webOS/i)
							|| navigator.userAgent.match(/iPhone/i)
							|| navigator.userAgent.match(/iPad/i)
							|| navigator.userAgent.match(/iPod/i)
							|| navigator.userAgent.match(/BlackBerry/i)
							|| navigator.userAgent.match(/Windows Phone/i)
						)) {
							return true;
						}
					})();

					this.ok = function () {
						modalInstance.dismiss('cancel');
					};
					this.downloadFile = function (file) {
						attachmentCtrl.openUploadDialog(file);
					}
					this.updateCaption = function () {
						ctrl.files[this.curIndex].fileSet['@caption'] = this.caption ? this.caption : this.filename;
						ctrl.files[this.curIndex].caption = this.caption ? this.caption : this.filename;
					}
					this.previous = function () {
						if (this.curIndex == 0) {
							this.curIndex = files.length - 1;
						} else {
							this.curIndex = this.curIndex - 1;
						}
						this.file = files[this.curIndex];
						this.filepath = files[this.curIndex].thumbnailSrc;
						this.filename = files[this.curIndex].filename;
						this.caption = files[this.curIndex].fileSet ? files[this.curIndex].fileSet['@caption'] : '';
					};
					this.next = function () {
						if (this.curIndex == (files.length - 1)) {
							this.curIndex = 0;
						} else {
							this.curIndex = this.curIndex + 1;
						}
						this.file = files[this.curIndex];
						this.filepath = files[this.curIndex].thumbnailSrc;
						this.filename = files[this.curIndex].filename;
						this.caption = files[this.curIndex].fileSet ? files[this.curIndex].fileSet['@caption'] : '';
					};
					this.cancel = function () {
						modalInstance.dismiss('cancel');
					};
				}
			});

			modalInstance.result.then(function (selectedItem) {

			}, function () {

			});
		}


		var sendEventToIpad = function (strEvent) {
			var iframe = document.createElement("IFRAME");
			iframe.setAttribute("src", "js-frame:" + strEvent);
			document.documentElement.appendChild(iframe);
			iframe.parentNode.removeChild(iframe);
			iframe = null;
		};

		ctrl.informNativeDevice = function () {
			if (ctrl.attachmentForIOS) {
				sendEventToIpad("uploadAttachment:" + angular.toJson({
					action: "1203",
					msgId: document.getElementById("msgId") && document.getElementById("msgId").value,
					fieldId: '',
					eOriDraftMsgId: document.getElementById("eOriDraftMsgId") && document.getElementById("eOriDraftMsgId").value,
					editORI: document.getElementById("editORI") && document.getElementById("editORI").value,
					save_draft: "0",
					fileType: (ctrl.fileType && ctrl.fileType != "false") ? ctrl.fileType : "",
					isMultiple: myConfig.isOfflineMode ? true : undefined,
					isForReply: myConfig.isForReply,
					isThumbnailSupports: ctrl.generateThumbnail? ctrl.generateThumbnail : undefined,
					autoPublishToFolder: ctrl.generateThumbnail? myConfig.autoPublishToFolder : undefined,
					fileSize:ctrl.generateThumbnail? '' : undefined,
					uploadedAttachmentFileDetails: ctrl.generateThumbnail? null : undefined,
					attachTempFolderId: ctrl.generateThumbnail? ctrl.folderId || myConfig.ATTACHTEMP_FOLDERID : undefined
				}));

				window.FieldAppInlineAttachmentUploadCallback = function (data) {
					if (data && typeof (data) == 'string') {
						data = JSON.parse(data);
					}
					var fileName = data.fileName ? data.fileName : '';
					data['xdocId'] = data.fieldId ? data.fieldId.substr(15) : '';
					data['elementId'] = data['xdocId'] + ':' + ctrl.objName;
					data['removeFileIcon'] = true,
					data['fileText']= '',
					data['thumbnailSrc']= null,
					data['isUploading'] =  false,
					data['isAttachmentUploaded'] =  true,
					data['filename'] = data.fileName ? data.fileName.split('_my_')[1] : '';
					data['offlineAttachmentPath'] = myConfig.isOfflineMode ? data.offlineAttachmentPath : null,
					uploadSuccess(fileName, data,true);
					try {
						$scope.$apply();
					} catch (e) { }
				}
			}
		}

		window.thumbnailInlineFailCallback = function (imgElem) {
			imgElem.parentElement.setAttribute('class', 'loading')
			var thumbnailsrc = imgElem.src;
			imgElem.errorCount = imgElem.errorCount || 1;
			if(myConfig.isOfflineMode) {	
				imgElem.src = './images/Asite_file_type_icons/svg/'+ api.getFileExtImage(api.getExt(imgElem.name)) + '_icon.svg';	
			} else {
				if (imgElem.errorCount < 7) {
					imgElem.timer = setTimeout(function () {
						imgElem.src = thumbnailsrc;
						imgElem.errorCount++;
					}, 5000);
				} else {
					imgElem.parentElement.removeAttribute('class', 'loading')
					delete imgElem.errorCount;
					if(imgElem.name) {
						imgElem.src = '/images/Asite_file_type_icons/svg/'+ api.getFileExtImage(api.getExt(imgElem.name)) + '_icon.svg';
					} else {
						imgElem.src = '/images/file-size-518.svg';
					}
				}
			}
			
		};

		window.successCallback = function (imgElem) {
			imgElem.parentElement.removeAttribute('class', 'loading')
		}

		function genXdocId() {
			return 'x_x_x_x'.replace(/[x]/g, function (c) {
				var r = Math.random() * 9 | 0,
					v = c == 'x' ? r : '0';
				return v;
			}) + "_my";
		}
	};

	mainModule.component('multipleinlineattachment', {
		template:
			'<div id="attached-files-container_{{$ctrl.objName}}" class="layout-flex" style="display: flex; flex-wrap: wrap; border-top: none; padding: 0px;">' +
			'<div ng-if="!$ctrl.readonly && !$ctrl.ngReadonly" class="layout-cell" style="padding-top: 0px;  min-width : 130px;">' +
			'<input multiple ng-if="!$ctrl.attachmentForIOS" type="file" id="imgupload_{{$ctrl.objName}}" class="hdnInlineFile" accept="{{$ctrl.fileType}}" />' +
			'<img ng-if="$ctrl.generateThumbnail" style="height:50px;width:50px;margin-top:20%" src="./images/image.png"/>' +
			'<div><label for="imgupload_{{$ctrl.objName}}" ng-click="$ctrl.informNativeDevice()"> {{$ctrl.defaultMsg}} </label></div>' +
			'</div>' +
			'<div id="{{file.elementId}}" ng-repeat="file in $ctrl.files track by $index" class="layout-cell" style="padding-top: 0px;  min-width : 130px; margin-right: 2%;" ng-style= "{\'width\': $ctrl.generateThumbnail ? \'auto\' : \'100%\'}">' +
			'<img src="./images/htmlform/CWR/smooth-loader.gif" class="waiting" ng-if="!$ctrl.readonly && file.isUploading" />' +
			'<div class="inline-block-cls">' +
			'<div ng-if="!$ctrl.generateThumbnail">' +
			'<a ng-if="$ctrl.readonly" href="javascript:void(0);" ng-click="$ctrl.openUploadDialog(file)">{{file.filename}}</a>' +
			'<a ng-if="file.fileSet &&  !$ctrl.readonly" href="javascript:void(0);">{{file.filename}}</a>' +
			'<span style="color: #A80000;" ng-if="!$ctrl.readonly && !file.isUploading" ng-click= $ctrl.removeUploadedFile(null,file) class="glyphicon glyphicon-remove-circle"></span>' +

			'</div>' +
			'<div ng-if="$ctrl.generateThumbnail" style="margin-top:5px;border:1px solid #DFDFDF;float:left;">' +
			'<div  style="text-overflow: ellipsis;height: 43px;overflow: hidden;-webkit-line-clamp: 2;display: -webkit-box;-webkit-box-orient: vertical;font-size: 13px;padding: 5px 10px 0px 10px;width:175px;word-break: break-word" ng-if="$ctrl.isCaption && $ctrl.captionPosition == \'top\' && file.fileSet">{{file.caption}}</div>' +
			'<div ng-if="!file.isUploading" ng-click="$ctrl.showImagePreview(file.filename,file.elementId,file)" style="height: 130px;width: 175px;align-items: center;justify-content: center;display: flex;"><img name="{{file.filename}}" style="max-height: 100%;max-width: 100%;object-fit: contain;padding: 6px;" ng-src="{{file.thumbnailSrc}}"  onerror="thumbnailInlineFailCallback(this);" onload="successCallback(this);"/></div>' +
			'<div style="text-overflow: ellipsis;height: 40px;overflow: hidden;-webkit-line-clamp: 2;display: -webkit-box;-webkit-box-orient: vertical;font-size: 13px;margin: 5px;width:150px;word-break: break-word"  ng-if="$ctrl.isCaption && $ctrl.captionPosition == \'bottom\' && file.fileSet">{{file.caption}}</div>' +
			'</div>' +
			'<span ng-if="!$ctrl.readonly && $ctrl.generateThumbnail && !file.isUploading" style="left: -7px;color: #9e9797;" ng-click= $ctrl.removeUploadedFile(null,file) class="glyphicon glyphicon-remove-circle"></span>' +
			'</div>' +
			'</div>' +
			'</div>',

		bindings: {
			fileSet: '=',
			fileType: '@',
			disable: '<',
			inlineData: '<',
			attachmentChange: '&',
			fileRequired: '<',
			labelText: '@', 			// need to pass default selection message as string like label-text="Please select image..."
			generateThumbnail: '<',
			multipleFiles: '<',
			isCaption: '<',
			captionPosition: '<',
			ngReadonly:'<',
			name:'&' 					// need to pass function that can take node name as parameter and function must be return that node name as string like name="getControlName('taskPhoto')"
		},
		controller: multipleInlineattachmentController
	});
});