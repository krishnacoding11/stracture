define(['angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	mainModule.directive('numbformat', ['$filter',
		function($filter) {
			return {
				require: '?ngModel',
				link: function(scope, elem, attrs, controller) {
					if (!controller) return;
					var DECIMAL_COUNT = 2;

					if (attrs.decimal) { //if require to change decimal value specify declimal value as attribute in HTML
						DECIMAL_COUNT = attrs.decimal;
					}

					controller.$formatters.unshift(function(a) {
						if (attrs.allowempty && controller.$modelValue == '') {
							return controller.$modelValue;
						} else {
							return $filter(attrs.numbformat)(controller.$modelValue, DECIMAL_COUNT);
						}
					});

					//For on Blur of Element manage Decimal and Format issuse
					elem.on('blur', function() {
						if (!controller.$modelValue && attrs.allowempty) {
							controller.$modelValue = "";
						}
						var actVal = controller.$modelValue
						if (actVal == "-" || isNaN(actVal) || (!attrs.allowempty && actVal == '')) {
							controller.$modelValue = "0";
						}
						if (!attrs.allowempty || actVal != '')
							actVal = $filter(attrs.numbformat)(controller.$modelValue, DECIMAL_COUNT);
						controller.$setViewValue(actVal);
						controller.$render();
						scope.$apply();
					});

					elem.on('keydown', function (event) {
						var strAsciiLength = event.key;
						var intAsciiCode = strAsciiLength.charCodeAt(0);

						/**
						* https://www.w3schools.com/charsets/ref_html_ascii.asp
						* range 33-43, 58-64, 91-96, 123-126, 45, 47 - disallow:!,",#,$,%,&,',(,),*,+,-,/,{,},|,~,[,],\,^,_,`,:,;,<,=,>,?,@...allowed , and .
						*/
						if (strAsciiLength.length > 1) {
							if ((intAsciiCode >= 33 && intAsciiCode <= 43) || (intAsciiCode >= 58 && intAsciiCode <= 64) || (intAsciiCode >= 91 && intAsciiCode <= 96) || (intAsciiCode >= 123 && intAsciiCode <= 126) || intAsciiCode == 45 || intAsciiCode == 47) {
								event.preventDefault();
							}
						}
						/**
						* allowed: Ctrl+A, Ctrl+C, Ctrl+X, Command+A, Ctrl+Z, Ctrl+Y, Ctrl+V, Ctrl+Del(Ctrl+D), Ctrl+Backspace(Ctrl+B), Ctrl+End(Ctrl+E), Ctrl+Home(Ctrl+H), Page up, page Down, All Arrow keys
						*/
						else if (event.ctrlKey === true && ([118, 86, 65, 67, 97, 99, 120, 121, 122, 88, 89, 90, 101, 104, 69, 72].indexOf(intAsciiCode) > -1)) { }
						/** 
						 *  range 33-43, 57-126,45,47 - disallow: A-Z, a-z, all special characters 
						*/
						else if ((intAsciiCode >= 33 && intAsciiCode <= 43) || (intAsciiCode >= 58 && intAsciiCode <= 126) || intAsciiCode == 47) {
							event.preventDefault();
						}
						else { }
					});

					//For on Focus of Element manage Decimal and Format issuse
					elem.on('focus', function() {
						var actVal = controller.$modelValue;
						if (!attrs.allowempty || actVal != '')
							actVal = $filter(attrs.numbformat)(controller.$modelValue, DECIMAL_COUNT)
						elem.val(actVal);
						elem[0].select();
					});

					controller.$parsers.unshift(function(viewValue) {
						var plainNumber = viewValue.replace(/[^\d|\-+|\.+]/g, '');
						var actVal = plainNumber.toString();

						if (actVal.indexOf('.') > -1 || actVal.indexOf('-') > -1) {
							return plainNumber;
						} else {
							if (attrs.allowempty && actVal == '') {
								elem.val(plainNumber);
							} else {
								elem.val($filter(attrs.numbformat)(plainNumber));
							}
						}

						return plainNumber;
					});
				}
			};
		}
	]);
})
