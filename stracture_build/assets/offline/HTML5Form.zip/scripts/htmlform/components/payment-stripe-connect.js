/**
 * Form payment component.
 * This module will initialize the payment component for apps
 * @module FormPayment
 */
define(['angular', 'mainModule', 'stripe'], function (angular, mainModule) {
	'use strict';

	mainModule.component('formPayment', {
		template: 
		'<div class="payment-wrapper">' +
			'<div class="panel-body text-left" ng-class="{hide: !$ctrl.orderData.ach}">'+
				'<div class="initialLoader" ng-if="showLoader"><i class="fa fa-spinner fa-spin"></i> Loading...</div>'+
				'<i class="fa fa-times closeIcon" ng-click="close()"></i>'+
				'<i class="fa fa-arrow-left backIcon" title="Back" ng-if="!payment.msg" ng-click="back()"></i>'+
				'<form method="POST" id="bank-form" name="bank-form" ng-if="!account_created && !showNotification && !accountVerified && !payment.msg && !showChooseAccount && showAddAcount">'+
					'<div class="headerTitle">Enter your bank details</div>'+
					'<div class="row">'+
						'<div class="col-md-6">'+
							'<div class="form-group">'+
								'<label>Bank Country</label>'+
								'<select class="form-control input-lg" id="country" name="country" ng-model="payment.country" data-stripe="country" disabled>'+
									'<option value="US">United States</option>'+
								'</select>'+
							'</div>'+
						'</div>'+
						'<div class="col-md-6">'+
							'<div class="form-group">'+
								'<label>Currency</label>'+
								'<select class="form-control input-lg" id="currency" name="currency" ng-model="payment.currency" data-stripe="currency" disabled>'+
									'<option value="usd">USD</option>'+
								'</select>'+
							'</div>'+
						'</div>'+
					'</div>'+
					'<div class="row">'+
						'<div class="col-md-6">'+
							'<div class="form-group">'+
								'<label>Account Holder Name</label>'+
								'<input class="form-control input-lg account_holder_name" name="account_holder_name" id="account_holder_name" type="text" data-stripe="account_holder_name" placeholder="Jane Doe" ng-model="payment.account_holder_name" autocomplete="off" required>'+
							'</div>'+
						'</div>'+
						'<div class="col-md-6">'+
							'<div class="form-group">'+
								'<label>Account Type</label>'+
								'<select class="form-control input-lg account_holder_type" name="account_holder_type" id="account_holder_type" data-stripe="account_holder_type" ng-model="payment.account_holder_type" required>'+
									'<option value="individual">Individual</option>'+
									'<option value="company">Company</option>'+
								'</select>'+
							'</div>'+
						'</div>'+
					'</div>'+
					'<div class="row">'+
						'<div class="col-md-6" id="routing_number_div">'+
							'<div class="form-group">'+
								'<label id="routing_number_label">Routing Number</label>'+
								'<input class="form-control input-lg bank_account" id="routing_number" name="routing_number"  type="tel" size="12" data-stripe="routing_number" placeholder="111000025" autocomplete="off" ng-model="payment.routing_number" required>'+
							'</div>'+
						'</div>'+
						'<div class="col-md-6">'+
							'<div class="form-group">'+
								'<label id="account_number_label">Account Number</label>'+
								'<input class="form-control input-lg bank_account" name="account_number" id="account_number" type="tel" size="20" data-stripe="account_number" placeholder="000123456789" autocomplete="off" ng-model="payment.account_number" required>'+
							'</div>'+
						'</div>'+
					'</div>'+
					'<div class="row">'+
						'<div class="col-md-12">'+
							'<div class="note">'+
								'<label>Please note it may take 4-5 business days to process this payment when using the “Bank Payment” method. Uploading documents for review and/or downloading a letter will not be possible until the payment is successful.</label>'+
							'</div>'+
						'</div>'+
                    '</div>'+
					'<div class="row">'+
						'<div class="col-md-12">'+
							'<button id="submit" type="submit" class="btn btn-lg btn-block btn-custom btn-primary submit" ng-disabled="addingAccount" ng-click="addAccount()">'+
								'<span ng-if="!addingAccount"><span class="fa fa-bank"></span> Add bank account</span>'+
								'<span ng-if="addingAccount"><i class="fa fa-spinner fa-spin"></i> Creating account...</span>'+
							'</button>'+
						'</div>'+
					'</div>'+
				'</form>'+
				'<div ng-if="account_created && !accountVerified && !payment.msg">'+
					'<div class="headerTitle" ng-if="!show_deposits">Verify your bank account</div>'+
					'<div class="alert alert-success" ng-if="!show_deposits">Your bank account has been connected.</div>'+
					'<div class="alert alert-info" ng-if="!show_deposits">Two micro deposits will be credited to your account <span>(XXXXXXX{{payment.currentAccount || bankAccountData.last4}})</span>. Please check your account for the amounts to continue your bank verification process. Please note : These deposits may take 1-2 business days to reflect in your account. Once credited you can complete the verification process from My Applications page.</div>'+
					'<div style="color: red;margin-bottom:20px" ng-if="!show_deposits">Please note : These deposits may take upto 1-2 business days to reflect in your account. You can complete the verification process from My Applications page later.</div>'+
				
					'<form id="verify-form" name="verify-form" ng-if="show_deposits">'+
						'<div class="headerTitle">Verify your bank account</div>'+
						'<div class="alert alert-success">Your bank account has been connected.</div>'+
						'<div class="alert alert-info">Stripe has transferred two micro deposits to your account <span>(XXXXXXX{{payment.currentAccount || bankAccountData.last4}})</span>. Please Login to your Bank website or Application and enter the amounts you see in the fields below.</div>'+
						'<div style="color: red;margin-bottom:20px">Please note : These microdeposit transfers can take 1-2 business days to appear in your bank account.</div>'+
						'<div class="row topspace">'+
							'<div class="col-md-6">'+
								'<div class="form-group">'+
									'<label>Deposit Amount 1</label>'+
									'<div class="input-group">'+
										'<span class="input-group-addon">$</span>'+
										'<input class="input-lg form-control amount" type="number" name="amount1" placeholder="32" ng-model="payment.amount1">'+
									'</div>'+
								'</div>'+
							'</div>'+
							'<div class="col-md-6">'+
								'<div class="form-group">'+
									'<label>Deposit Amount 2</label>'+
									'<div class="input-group">'+
										'<span class="input-group-addon">$</span>'+
										'<input class="input-lg form-control amount" type="number" name="amount2" placeholder="45" ng-model="payment.amount2">'+
									'</div>'+
								'</div>'+
							'</div>'+
						'</div>'+
						'<div class="row topspace">'+
							'<div class="col-md-12">'+
								'<button class="btn btn-lg btn-block btn-custom btn-primary" type="button" ng-disabled="showVerifyingLoader" ng-click="verifyUserDetails()">'+
									'<span ng-if="!showVerifyingLoader"><span class="fa fa-bank"></span> Verify bank account</span>'+
									'<span ng-if="showVerifyingLoader"><i class="fa fa-spinner fa-spin"></i> Verifying account...</span>'+
								'</button>'+
							'</div>'+
						'</div>'+
					'</form>'+
				'</div>'+
				'<div ng-if="accountVerified">'+
					'<div class="headerTitle">Make payment with your bank account</div>'+
					'<div class="alert alert-success">'+
						'<ul class="list-unstyled">'+
							'<li>Your bank account has been connected.</li>'+
						'</ul>'+
					'</div>'+
					'<form  id="payment-form" name="payment-form">'+
						'<div class="form-group text-left">'+
							'<label>Payment amount</label>'+
							'<div class="input-group">'+
							'<span class="input-group-addon">$</span>'+
							'<input class="form-control input-lg" type="text" ng-model="payment.totalAmt" name="amount" readonly>'+
							'</div>'+
						'</div>'+
						'<div class="row">'+
							'<div class="col-md-12">'+
								'<div class="note">'+
									'<label>Please note it may take 4-5 business days to process this payment when using the “Bank Payment” method. Uploading documents for review and/or downloading a letter will not be possible until the payment is successful.</label>'+
								'</div>'+
							'</div>'+
						'</div>'+
						'<hr>'+
						'<div class="topspace">'+
							'<button class="btn btn-lg btn-custom btn-primary btn-block submit" ng-disabled="showChargingLoader" ng-click="createACHPayment()">'+
								'<span ng-if="!showChargingLoader">Make payment</span>'+
								'<span ng-if="showChargingLoader"><i class="fa fa-spinner fa-spin"></i> Charging your bank account...</span>'+
							'</button>'+
						'</div>'+
						'<small style="margin-top: 10px;display: inline-block;">'+
							'By providing your bank information and using this service, you authorize Asite Marketplace to electronically debit your <strong>{{payment.bankName}}</strong> account ending in <strong>{{payment.currentAccount}}</strong> and, if necessary, electronically credit your account to correct erroneous debits.'+
						'</small>'+
					'</form>'+
				'</div>'+
				'<div class="after-msg" ng-if="payment.msg" ng-class="payment.status" style="padding: 20px 0;"> '+
					'<p style="padding: 0 10px;">{{payment.msg}}</p>'+
					'<p ng-if="payment.msg1" style="padding: 0 10px;">{{payment.msg1}}</p>'+
					'<p ng-if="payment.completeMsg" style="padding: 0 10px;">{{payment.completeMsg}}</p>'+
					'<button type="button" class="btn btn-default" ng-click="ok($event)" style="background: #fff !important;padding: 3px 10px;">Ok</button>'+
				'</div>'+
				'<div class="choose-payment-phase" ng-if="showChooseAccount">'+
					'<div class="headerTitle">Choose bank account to pay</div>'+
					'<div class="accountList" ng-class="{centerAligned: (!verificationPendingCustomers.length || !verifiedCustomers.length)}">'+
						'<div class="verified" ng-if="verifiedCustomers.length" ng-class="{fullWidth: !verificationPendingCustomers.length}">'+
							'<label style="padding:10px 0;font-size:15px" >Verified Account(s)</label>'+
							'<ul>' +
								'<li class="accountItem" ng-repeat="item in verifiedCustomers">'+
									'<div class="accountSelection" ng-click="selectPaymentPhase(item)">'+
										'<i class="fa fa-check-square-o" style="color: green;"></i>'+
										'XXXXXXX{{item.last4}}'+
										'<i class="fa fa-chevron-right" style="margin-left: 10px;font-size: 12px;"></i>'+
									'</div>'+
									'<i class="fa fa-trash" style="margin: 0 5px;cursor: pointer;" ng-click="toggleConfirmBox(true,item)"></i>'+
								'</li>' +
							'</ul>' +
						'</div><div class="verification-pending" ng-if="verificationPendingCustomers.length" ng-class="{fullWidth: !verifiedCustomers.length}">'+	
							'<label style="padding:10px 0;font-size:15px" >Account(s) Pending Verification</label>'+
							'<ul>' +
								'<li ng-repeat="item in verificationPendingCustomers">'+
									'<div class="accountSelection" ng-click="selectPaymentPhase(item)">'+
										'<i class="fa fa-exclamation-triangle" style="color: orange;"></i>'+
										'XXXXXXX{{item.last4}}'+
										'<i class="fa fa-chevron-right" style="margin-left: 10px;font-size: 12px;"></i>'+
									'</div>'+
									'<i class="fa fa-trash" style="margin-left:5px;cursor: pointer;" ng-click="toggleConfirmBox(true,item)"></i>'+
								'</li>' +
							'</ul>' +
						'</div>'+
					'</div>'+
					'<div class="separator">OR</div>'+
					'<button type="button" class="btn btn-lg btn-block btn-custom btn-primary"  ng-click="showAddAcountScreen()" style="padding:10px 13px;">Register New Account</button>'+
					'<div ng-if="showConfirmBox" class="confirm-box">'+
						'<div class="overlay"></div>'+
						'<div class="confirm-body">'+
							'<i class="fa fa-times closeIcon" ng-click="toggleConfirmBox()" style="top: 10px;right: 10px;"></i>'+
							'<p style="padding:20px 0 10px 0">Are you sure you want to remove this account?</p>'+
							'<button type="button" class="btn btn-danger card" ng-click="deleteAccount();" style="min-width: 50px;margin-right:10px">Ok</button>'+
							'<button type="button" class="btn btn-danger card" ng-click="toggleConfirmBox()" style="min-width: 50px;">Cancel</button>'+
						'</div>'+
					'</div>	'+
				'</div>'+
			'</div>'+
			'<form id="payment-form" ng-class="{loading: payment.xhr, hide: $ctrl.orderData.ach}" class="sr-payment-form checkout">'+
				'<div class="sr-form-row">'+
				  '<label for="card-element">Enter your card details</label>'+
				  '<div class="sr-input sr-card-element" id="card-element"></div>'+
				'</div>'+				
				'<div class="sr-form-row">'+
				  '<div class="sr-field-error" id="card-errors" role="alert"></div>'+
				  '<button id="submit" class="btn btn-danger" ng-disabled="payment.disabled">'+
					'<span id="button-text">Pay </span><span id="order-amount">{{$ctrl.orderData.currencySymbol}}{{ payment.totalAmt}}</span>'+
				  '</button>'+
				  ' <button type="button" class="btn btn-default" ng-if="!$ctrl.mandatory" ng-click="close($event)">Cancel</button>' +
				'</div>'+
				'<div class="after-msg" ng-if="payment.msg" ng-class="payment.status">' + 
				'<p ng-bind="payment.msg" style="padding:0"></p>' +
				'<p ng-bind="payment.completeMsg" style="padding:0"></p>' +
				'<button type="button" class="btn btn-default" ng-click="ok($event)">Ok</button>' +
				'</div>' +
			  '</form>'+
			'</div>',
		controller: ['$scope', '$http','Notification', function ($scope, $http,Notification) {
			var ctrl = this, stripe, elements, card, paymentForm;

			$scope.payment = {
				xhr: false,
				error: false,
				disabled: false,
				data: null,
				status: '',
				msg: '',
				msg1: '',
				completeMsg:'',
				totalAmt: '',
				country:'US',
				currency:'usd',
				account_holder_name:null,
				account_holder_type:'individual',
				routing_number:null,
				account_number:null,
				amount1:null,
				amount2:null,
				currentAccount : null,
				bankName: null
			};	
					
			$scope.account_created = false;
			$scope.show_deposits = false;
			$scope.showNotification = false;
			$scope.addingAccount = false;
			$scope.userVerified = false;
			$scope.accountVerified = false;
			$scope.showVerifyingLoader = false;
			$scope.showChargingLoader = false;
			$scope.showChooseAccount =false;
			$scope.fromChooseAccount =false;
			$scope.showAddAcount =false;
			$scope.showLoader =true;
			$scope.bankStatus;
			$scope.selectedItem;		
			$scope.verifiedCustomers = [];		
			$scope.verificationPendingCustomers = [];
			$scope.bankAccountData = null;
			$scope.showConfirmBox=false;
			// initialization
			// Custom styling can be passed to options when creating an Element.
			// (Note that this demo uses a wider set of styles than the guide below.)
			var paymentForm = document.getElementById("payment-form");			
			
			// Set up Stripe.js and Elements to use in checkout form
			var setupElements = function() {
				if(ctrl.orderData.ach){
					$scope.showAddAcount = false;
					$scope.showLoader = true;
					getUserDetails();
				}
				else{	
					var paymentIntentClientSecret = ctrl.orderData.client_secret;										
					stripe = Stripe(ctrl.orderData.stripePublishableKey, {
						stripeAccount: ctrl.orderData.connectedStripeId
					});
					elements = stripe.elements();
					var style = {
						base: {
						color: "#32325d",
						fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
						fontSmoothing: "antialiased",
						fontSize: "16px",
						"::placeholder": {
							color: "#aab7c4"
						}
						},
						invalid: {
						color: "#fa755a",
						iconColor: "#fa755a"
						}
					};
	
					card = elements.create("card", { style: style });
					card.mount("#card-element");	
					
					// Handle form submission.
					paymentForm.addEventListener("submit", function(event) {
					event.preventDefault();
					// Initiate payment when the submit button is clicked
					pay(stripe, card, paymentIntentClientSecret);
					});					
				}

			};
			ctrl.$onInit = function () {				
				setupElements();
				$scope.payment.totalAmt = formatMoney(ctrl.orderData.totalAmount + ctrl.orderData.applicationFees)
			};		
			var getUserDetails = function (){
				
				$http({
					method: "get",
					withCredentials: true,
				  	url: (window.adoddleShopBaseUrl || "") + "/shop/getCustomerDetails?email="+USP.email+"&currencyId="+ctrl.orderData.currencyId,
					// url: "http://192.168.101.201:3010/shop/getCustomerDetails?email="+USP.email+"&currencyId="+ctrl.orderData.currencyId,
		
				}).then(function (response) {					
					if(response && response.data && response.data.length){
						$scope.customerDetail = response.data;
						for(var c=0;c<$scope.customerDetail.length;c++){
							if($scope.customerDetail[c].status == "verified"){
								$scope.verifiedCustomers.push($scope.customerDetail[c]);
							}
							else{
								$scope.verificationPendingCustomers.push($scope.customerDetail[c]);
							}
						}
						$scope.account_created = false;
						$scope.showChooseAccount = true;          
						$scope.showLoader = false;
					}
					else{
						$scope.account_created = false;
						$scope.showAddAcount = true;
						$scope.showLoader = false;
					}
				}, function (errors) {
					$scope.showAddAcount = true;
					$scope.showLoader = false;
				});
			  }; 
			  $scope.addAccount = function () {						  
				var accountAlreadyExists = false,
				existingAccounts = $scope.customerDetail,
				lastFourDigits = $scope.payment.account_number.slice(-4),
				status, displayStatus;
								
				var msg = usRoutingNumber($scope.payment.routing_number);
				if(msg){
					Notification.error({
						message: msg
					});
					return;
				}

				if(existingAccounts && existingAccounts.length){
					for(var e=0;e<existingAccounts.length;e++){
						if(lastFourDigits == existingAccounts[e].last4 && $scope.payment.routing_number == existingAccounts[e].routing_number){
						accountAlreadyExists = true;
						status = existingAccounts[e].status;
						}
					}
				}
				
				if(accountAlreadyExists){
					if(status == "verified")
					displayStatus = "Verified Account";
					else
					displayStatus = "Verification Pending Accounts"

					var msg = "This account already exists and is listed under "+displayStatus+".";
					
					Notification.error({
						message: msg
					});
					return;
				}
				$scope.addingAccount = true;
				// Initialize Stripe with the same account that we created the PaymentIntent with.
				stripe = Stripe(ctrl.orderData.stripePublishableKey);

				stripe
				.createToken('bank_account', {
				  country: $scope.payment.country,
				  currency: $scope.payment.currency,
				  routing_number: $scope.payment.routing_number,
				  account_number: $scope.payment.account_number,
				  account_holder_name: $scope.payment.account_holder_name,
				  account_holder_type: $scope.payment.account_holder_type,
				})
				.then(function(result) {
				  	// Handle result.error or result.token
					var tokenData = result.token;
					if(tokenData){
						$scope.bankAccountData = tokenData.bank_account;
						$scope.addingAccount = false;
						$http({
							method: "post",
							withCredentials: true,
							// url: "http://192.168.101.201:3010/shop/createCustomer",
							url: (window.adoddleShopBaseUrl || "") + "/shop/createCustomer",
							headers : {
								'Content-Type': 'application/x-www-form-urlencoded'
							},
							data: "orderItems=" + encodeURIComponent(angular.toJson(ctrl.orderData)) + 
							"&tokenData=" + encodeURIComponent(angular.toJson(tokenData))
						}).then(function (response) {
							if(response.data){							
								$scope.account_created = true;
								$scope.show_deposits = false;
							}
						}, function (errors) {
							Notification.error({
								message: "Add account failed"
							});
						});
					}
					else if(result.error){
						$scope.addingAccount = false;
						$scope.account_created = false;
						Notification.error({
							message: result.error.message
						});
						return;
					}
				}, function (errors) {
					$scope.addingAccount = false;
					Notification.error({
						message: "Add account failed"
					});
				});
			};
			$scope.selectPaymentPhase = function (item){
				$scope.fromChooseAccount = true;
				$scope.payment.currentAccount = item.last4 || $scope.bankAccountData.last4;
				$scope.payment.bankName = item.bankName || $scope.bankAccountData.bank_name;

				$scope.showChooseAccount = false;
				$scope.show_deposits = true;
				$scope.selectedItem = item;
			
				if(item.status == "verified")
				$scope.accountVerified = true;
				else if(item.status == "new")
				$scope.account_created = true;
			};
			$scope.toggleConfirmBox = function(type,item){
				if(type){
					$scope.showConfirmBox = true;
					$scope.itemToDelete = item;
				}
				else
				$scope.showConfirmBox = false;
			}
			$scope.deleteAccount = function(){
				var item = $scope.itemToDelete;
				$http({
					method: "post",
					withCredentials: true,
				  	url: (window.adoddleShopBaseUrl || "") + "/shop/removeCustomerDetails?customerId="+item.customerId+"&currencyId="+ctrl.orderData.currencyId+"&bankId="+item.bank_id,
				  	// url: "http://192.168.101.201:3010/shop/removeCustomerDetails?customerId="+item.customerId+"&currencyId="+ctrl.orderData.currencyId+"&bankId="+item.bank_id,
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
					}
				}).then(function (response) {
					if(response && response.data){
						if(response.data.Status == "Success"){
							Notification.success('<div class="text-center">Account details removed successfully</div>');
							$scope.showConfirmBox = false;
							$scope.customerDetail = null;							
							$scope.showChooseAccount = false; 
							$scope.showLoader = true;
							$scope.verificationPendingCustomers = [];
							$scope.verifiedCustomers = [];
							getUserDetails();
						}
						else{
							Notification.error({
								message: response.data.Message
							});
							return;
						}
					}
					else{
						$scope.showVerifyingLoader = false;
						Notification.error({
							message: "Could not delete bank account."
						});
						return;
					}
				}, function (errors) {
					$scope.showVerifyingLoader = false;
					Notification.error({
						message: "Could not delete bank account."
					});
				});
			};

			$scope.verifyUserDetails = function (){
				var customerData = $scope.selectedItem;
				
				if(!$scope.payment.amount1 || !$scope.payment.amount2){
					Notification.error({
						message: "Please enter micro deposit amounts."
					});
					return;
				}
				var amount1 = ($scope.payment.amount1 % 1 != 0) ? $scope.payment.amount1 *100 : $scope.payment.amount1;
    			var amount2 = ($scope.payment.amount2 % 1 != 0) ? $scope.payment.amount2 *100 : $scope.payment.amount2;
				
				$scope.showVerifyingLoader = true;
				$http({
					method: "post",
					withCredentials: true,
				  	url: (window.adoddleShopBaseUrl || "") + "/shop/verifyBankAccount",
					data: "customerId="+customerData.customerId+
							"&currencyId="+ctrl.orderData.currencyId+
				  			"&bankId="+customerData.bank_id+
				  			"&amount1="+amount1+
				  			"&amount2="+amount2,
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
					}
				}).then(function (response) {
					if(response && response.data){
						if(response.data.Status == "Success"){
							$scope.accountVerified = true;
							$scope.showVerifyingLoader = false;
						}
						else{
							$scope.showVerifyingLoader = false;
							Notification.error({
								message: response.data.Message
							});
							return;
						}
					}
					else{
						$scope.showVerifyingLoader = false;
						Notification.error({
							message: "Bank verfication failed."
						});
						return;
					}
				}, function (errors) {
					$scope.showVerifyingLoader = false;
					Notification.error({
						message: "Bank verfication failed."
					});
				});
			};
			$scope.createACHPayment = function (){
				var customerData = $scope.selectedItem;

				$scope.showChargingLoader = true;
				$http({
					method: "post",
					withCredentials: true,
				  	// url: "http://192.168.101.201:3010/shop/createACHPayment",
				  	url: (window.adoddleShopBaseUrl || "") + "/shop/createACHPayment",
					data: "orderItems=" + encodeURIComponent(JSON.stringify(ctrl.orderData)) + 
						"&bankId=" + customerData.bank_id + 
						"&customerId=" + customerData.customerId+
						"&currency=" + ctrl.orderData.currencyId+
						"&country=" + $scope.payment.country,
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
					}
				}).then(function (response) {
					if(response && response.data){
						$scope.showChargingLoader = false;
						$scope.accountVerified = false;
						$scope.payment.status = response.data.Status;
						if(response.data.Status == "Success"){
						  $scope.payment.msg = 'Payment request submitted!';
						  $scope.payment.msg1 = 'Please Note : ACH payments can take up to 5 business days to receive acknowledgment of their success.';
						  $scope.payment.completeMsg = "Please go to My Applications to submit your relevant documents.";
						}
						else{
							if(response.data.Message == "Error :: Unknown"){
								$scope.payment.msg = "Payment has been done successfully but some issue occurred while updating the status in Asite."
							}
							else{
								$scope.payment.msg = response.data.Message;
							}
						}
					}
				}, function (errors) {
					$scope.showChargingLoader = false;
					$scope.payment.status = "Failed";
					$scope.payment.msg = "Payment Failed."
				});				   
			  };
			  $scope.showAddAcountScreen = function(){
				$scope.showChooseAccount = false;
				$scope.showAddAcount=true;
			  };
			var pay = function (stripe, card, clientSecret) {
				if(angular.element("#card-element").hasClass("StripeElement--invalid")){
					showError("Please enter valid card details!");
					return;
				}
				$scope.payment.xhr = true;
				document.querySelector("#payment-form").classList.add("loading");
				$http({
					method: "post",
					withCredentials: true,
					url: (window.location.origin || "") + "/commonapi/user/getUspBasedOnSessionID",
					// url: "http://192.168.101.201:3010/shop/commonapi/user/getUspBasedOnSessionID",
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
					}
				}).then(function (response) {
					if(response.data){
						if(typeof response.data == "string"){
							$scope.close();
						}
						else{
							// Initiate the payment.
						// If authentication is required, confirmCardPayment will automatically display a modal
						stripe
							.confirmCardPayment(clientSecret, {
							payment_method: {
								card: card
							}
							})
							.then(function(result) {
							if (result.error) {
								// Show error to your customer
								showError(result.error.message);
								$scope.payment.xhr = false;
								document.querySelector("#payment-form").classList.remove("loading");
							} else {
								// The payment has been processed!
								orderComplete(clientSecret);
							}
							});
						}
					}
					else
					$scope.close();
				}, function (errors) {
					$scope.close();
				});
			};		
			  
			/* ------- Post-payment helpers ------- */

			/* Shows a success / error message when the payment is complete */
			var orderComplete = function(clientSecret) {
			  // Just for the purpose of the sample, show the PaymentIntent response object
			  stripe.retrievePaymentIntent(clientSecret).then(function(result) {
				var paymentIntent = result.paymentIntent;
				ctrl.orderData.statusToChange = angular.element('#DS_FORMSTATUS').val();
								
				$http({
					method: "post",
					withCredentials: true,
					url: (window.adoddleShopBaseUrl || "") + "/shop/saveConnectedAccTransaction",
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
				   	},
					data: "orderItems=" + encodeURIComponent(angular.toJson(ctrl.orderData)) + 
					"&paymentIntent=" + encodeURIComponent(angular.toJson(paymentIntent))
				}).then(function (response) {
					$scope.payment.data = response.data || {};					
					$scope.payment.status = ($scope.payment.data.Status || 'Failed').toLowerCase();
					if($scope.payment.data.Status == 'Success'){
						$scope.payment.msg = 'Payment successful';
						$scope.payment.completeMsg = "Please go to My Applications to submit your relevant documents.";
					}
					else{
						$scope.payment.msg = $scope.payment.data.Message || 'Payment unsuccessful';
					}
					$scope.payment.xhr = false;
				}, function (errors) {
					$scope.payment.msg = 'Payment unsuccessful';
					$scope.payment.status = 'failed';
					$scope.payment.xhr = false;
				});
			  });
			};
			var usRoutingNumber = function(num) {
				var b, c, d, e, f, g, h;
				if (!/^\d{9}$/.test(num))
					return "Routing number must have 9 digits";
				for (f = 0,
				b = g = 0,
				h = num.length - 1; g <= h; b = g += 3)
					c = 3 * parseInt(num.charAt(b), 10),
					d = 7 * parseInt(num.charAt(b + 1), 10),
					e = parseInt(num.charAt(b + 2), 10),
					f += c + d + e;
				return 0 === f || f % 10 !== 0 ? "Invalid routing number" : void 0
			}
			var showError = function(errorMsgText) {
			  var errorMsg = document.querySelector(".sr-field-error");
			  errorMsg.textContent = errorMsgText;
			  setTimeout(function() {
				errorMsg.textContent = "";
			  }, 4000);
			};
			var formatMoney = function(number, decPlaces, decSep, thouSep) {
				decPlaces = isNaN(decPlaces = Math.abs(decPlaces)) ? 2 : decPlaces,
				decSep = typeof decSep === "undefined" ? "." : decSep;
				thouSep = typeof thouSep === "undefined" ? "," : thouSep;
				var sign = number < 0 ? "-" : "";
				var i = String(parseInt(number = Math.abs(Number(number) || 0).toFixed(decPlaces)));
				var j = (j = i.length) > 3 ? j % 3 : 0;
				
				return sign +
					(j ? i.substr(0, j) + thouSep : "") +
					i.substr(j).replace(/(\decSep{3})(?=\decSep)/g, "$1" + thouSep) +
					(decPlaces ? decSep + Math.abs(number - i).toFixed(decPlaces).slice(2) : "");
			}
			$scope.close = function (e) {
				ctrl.orderData.showInitialWindow = false;
				ctrl.onClose && ctrl.onClose({ e: e });
			};

			$scope.ok = function(data) {
				ctrl.orderData.showInitialWindow = false;
				ctrl.onComplete && ctrl.onComplete({ data: $scope.payment.data });
			};
			$scope.back = function() {
				ctrl.orderData.showInitialWindow = false;
				if($scope.accountVerified){
					$scope.accountVerified = false;
					if($scope.fromChooseAccount){
						$scope.showChooseAccount = true;
						$scope.account_created = false;
					}
				}
				else if($scope.account_created){
					$scope.account_created = false;
					$scope.showChooseAccount = true;
				}
				else if($scope.showChooseAccount){
					ctrl.orderData.showInitialWindow = true;
					ctrl.onClose();
				}
				else if($scope.showAddAcount){
					$scope.showAddAcount = false;
					if($scope.customerDetail && $scope.customerDetail.length){
						$scope.showChooseAccount = true;
					}
					else{
						ctrl.orderData.showInitialWindow = true;
						ctrl.onClose();
					}

				}
			};
		}],
		bindings: {
			orderData: '<',
			onClose: '&',
			onComplete: '&',
			mandatory: '<'
		}
	});
});
