/**
 * Folder selection component.
 * This module will initialize the Folder selection component for angular application.
 * @module FolderSelection
 */
define(['angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	mainModule.component('folderSelection', {
		template : '<script type="text/ng-template"  id="folder-selection-item.html">' +
					'<div href="javascript:void(0)" title="{{::item.folderTitle}}" ng-click="selectItem($event, item)" ng-class="{active: item.selected, noAccess: item.noAccess}">' +
						'<i class="toggle-item" ng-class="{down: item.open, hasfolders: item.has_subfolder}"></i>' +
						'<i class="folder-icon">' +
							'<svg ng-if="!item.open" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58" style="enable-background:new 0 0 58 58;" xml:space="preserve">' +
							'<path style="fill:#EFCE4A;" d="M55.981,54.5H2.019C0.904,54.5,0,53.596,0,52.481V20.5h58v31.981C58,53.596,57.096,54.5,55.981,54.5z"/>' +
							'<path style="fill:#EBBA16;" d="M26.019,11.5V5.519C26.019,4.404,25.115,3.5,24,3.5H2.019C0.904,3.5,0,4.404,0,5.519V10.5v10h58 v-6.981c0-1.115-0.904-2.019-2.019-2.019H26.019z"/></svg>' +
						
							'<svg ng-if="item.open" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58"' +
						 	'style="enable-background:new 0 0 58 58;" xml:space="preserve"><path style="fill:#EFCE4A;"' + 
							'd="M46.324,52.5H1.565c-1.03,0-1.779-0.978-1.51-1.973l10.166-27.871c0.184-0.682,0.803-1.156,1.51-1.156H56.49c1.03,0,1.51,0.984,1.51,1.973L47.834,51.344C47.65,52.026,47.031,52.5,46.324,52.5z"/>' +
							'<g><path style="fill:#EBBA16;" d="M50.268,12.5H25l-5-7H1.732C0.776,5.5,0,6.275,0,7.232V49.96c0.069,0.002,0.138,0.006,0.205,0.01l10.015-27.314c0.184-0.683,0.803-1.156,1.51-1.156H52v-7.268C52,13.275,51.224,12.5,50.268,12.5z"/></svg>' +
						'</i>' +
						'<i ng-if="::item.isFavourite" class="fa fa-star"></i>' +
						'<span ng-bind="::item.folderTitle"></span>' +
					'</div>' +
					'<ul ng-if="item.has_subfolder && item.open">' +
						'<li ng-repeat="item in ::item.childFolders track by item.folderId" ng-include="::\'folder-selection-item.html\'"></li>' +
					'</ul>' +
					'</script>' +
					'<div class="tree-holder" ng-class="{readOnly: $ctrl.readOnly}">' +
						'<ul>' +
							'<li ng-repeat="item in treeData track by item.folderId">' +
								'<div href="javascript:void(0)" title="{{::item.folderTitle}}" ng-click="selectItem($event, item)" ng-class="{active: item.selected, noAccess: item.noAccess}">' +
									'<i class="toggle-item" ng-class="{arrowRight: !item.open, arrowDown: item.open, hasfolders: item.has_subfolder}"></i>' +
									'<i class="folder-icon">' +
										'<svg ng-if="!item.open" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58" style="enable-background:new 0 0 58 58;" xml:space="preserve">' +
										'<path style="fill:#EFCE4A;" d="M55.981,54.5H2.019C0.904,54.5,0,53.596,0,52.481V20.5h58v31.981C58,53.596,57.096,54.5,55.981,54.5z"/>' +
										'<path style="fill:#EBBA16;" d="M26.019,11.5V5.519C26.019,4.404,25.115,3.5,24,3.5H2.019C0.904,3.5,0,4.404,0,5.519V10.5v10h58 v-6.981c0-1.115-0.904-2.019-2.019-2.019H26.019z"/></svg>' +
									
										'<svg ng-if="item.open" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 58 58"' +
									 	'style="enable-background:new 0 0 58 58;" xml:space="preserve"><path style="fill:#EFCE4A;"' + 
										'd="M46.324,52.5H1.565c-1.03,0-1.779-0.978-1.51-1.973l10.166-27.871c0.184-0.682,0.803-1.156,1.51-1.156H56.49c1.03,0,1.51,0.984,1.51,1.973L47.834,51.344C47.65,52.026,47.031,52.5,46.324,52.5z"/>' +
										'<g><path style="fill:#EBBA16;" d="M50.268,12.5H25l-5-7H1.732C0.776,5.5,0,6.275,0,7.232V49.96c0.069,0.002,0.138,0.006,0.205,0.01l10.015-27.314c0.184-0.683,0.803-1.156,1.51-1.156H52v-7.268C52,13.275,51.224,12.5,50.268,12.5z"/></svg>' +
									'</i>' +
									'<i ng-if="::item.isFavourite" class="fa fa-star"></i>' +
									'<span ng-bind="::item.folderTitle"></span>' +
								'</div>' +
								'<ul ng-if="item.has_subfolder && item.open">' +
									'<li ng-repeat="item in ::item.childFolders track by item.folderId" ng-include="::\'folder-selection-item.html\'"></li>' +
								'</ul>' +
							'</li>' +
						'</ul>' +
					'</div>',
		controller : ['$scope', '$element', '$timeout', function($scope, $element, $timeout) {
			var ctrl = this;
			
			// initialization
			ctrl.$onInit = function() {
				$scope.treeData = ctrl.treeData || [];
				allFolders = [];
				
				doRecursion($scope.treeData, iterator);
				setSelectedFolder();
			};
			
			ctrl.$onChanges = function() {
				if(ctrl.selection && $scope.treeData) {
					allFolders = [];
					doRecursion($scope.treeData, iterator);
					setSelectedFolder();
				}
			};
			
			var selected = undefined;
			var allFolders = []; 
			var doRecursion = function(list, callback) {
				if(!list || !list.length) {
					return;
				}
				
				for (var i = 0; i < list.length; i++) {
					var folder = list[i];
					allFolders.push(folder);
					
					callback && callback(folder);
					
					if(folder.childFolders && folder.childFolders.length) {
						doRecursion(folder.childFolders, callback);
					}
				}
			};
			
			var iterator = function(folder) {
				folder.selected = false;
				folder.open = false;
				
				if(ctrl.selection) {
					var targetFolderId = (ctrl.selection.folderId + "").split('$$')[0];
					var currentFolderId = (folder.folderId + "").split('$$')[0];
					if(targetFolderId == currentFolderId) {
						selected = folder;
					}
				}
			};
			
			var setSelectedFolder = function() {
				if(ctrl.selection && ctrl.selection.folderId && selected) {
					currentSelected = selected;
					ctrl.selection = angular.copy(selected);
					currentSelected.selected = true;
					
					expandToSelectedFolder(selected.parentFolderId);
				}
			};
			
			var expandToSelectedFolder = function(parentId) {
				if(!selected || !parentId || parentId == "0") {
					return;
				}
				
				parentId = parentId + "";
				var parentArray = [];
				for (var i = 0; i < allFolders.length; i++) {
					var folder = allFolders[i];
					var folderId = folder.folderId + "";
					if(folderId.split('$$')[0] == parentId.split('$$')[0]) {
						folder.open = true;
						expandToSelectedFolder(folder.parentFolderId);
						break;
					}
				}
			};
			
			var currentSelected = undefined;
			$scope.selectItem = function(e, item) {
				if(e && angular.element(e.target).hasClass('toggle-item')) {
					if(item.has_subfolder) {
						item.open = !item.open;
					}
					
					return;
				}
				
				if(ctrl.readOnly || item.noAccess) {
					return;
				}
				
				if(currentSelected) {
					if(currentSelected == item || currentSelected.folderId.split('$$')[0] == item.folderId.split('$$')[0]) {
						ctrl.onSelectionChange && ctrl.onSelectionChange({e: e, item: item});
						return;
					}
					
					currentSelected.selected = false;
				}
				
				currentSelected = item;
				item.selected = true;
				
				// perform callback action
				var copyItem = angular.copy(item);
				ctrl.selection = copyItem;
				ctrl.onSelectionChange && ctrl.onSelectionChange({e: e, item: copyItem});
			};
		}],
		bindings : {
			treeData: '<',
			selection: '=',
			readOnly: '<',
			onSelectionChange: '&'
		}
	});
});
