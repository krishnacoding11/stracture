/**
 * Modal component.
 * This module will initialize the Model component for angular application.
 * @module Modal
 */
define(['angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	var startX = 0,
		startY = 0,
		x = 0,
		y = 0;
	/**
	 * @constructor
	 * @alias module:Modal/ModalController
	 */
	function ModalController($scope, $element, $document) {
		var ctrl = this;

		var header = $element.find('header');
		header.on('mousedown', function(event) {
			// Prevent default dragging of selected content
			event.preventDefault();
			startX = event.screenX - x;
			startY = event.screenY - y;
			$document.on('mousemove', mousemove);
			$document.on('mouseup', mouseup);
		});

		var section = $element.find('section');

		function mousemove(event) {
			y = event.screenY - startY;
			x = event.screenX - startX;
			section.css({
				top: y + 'px',
				left: x + 'px'
			});
		}

		function mouseup() {
			$document.unbind('mousemove', mousemove);
			$document.unbind('mouseup', mouseup);
		}

		// close dialog on escape
		$document.bind('keyup', function(e) {
			if ((e.keyCode == 27 || e.which == 27) && !ctrl.busy) {
				ctrl.hideModal();
				$scope.$digest();
			}
		});

		/**
		 * reset modal position
		 */
		ctrl.resetModal = function() {
			// reset modal position
			section.css({
				top: '0px',
				left: '0px'
			});
			startX = 0;
			startY = 0;
			x = 0;
			y = 0;
		};
		
		ctrl.update = function() {
			ctrl.modelInfo.update();
			ctrl.resetModal();
		};

		ctrl.hideModal = function() {
			ctrl.modelInfo.hideModal();
			ctrl.resetModal();
		};
		
		// apply validation on submit
		var myform = $element.find('form')[0];
		if(myform) {			
			myform.onsubmit = function( event ) {
				this.checkValidity && !this.checkValidity();
				event.preventDefault();
			};
		}
	}

	mainModule.component('modal', {
		template: '<div class="m-wrap" id="{{$ctrl.modelInfo.modelId}}" ng-show="!!$ctrl.modelInfo.modelId">' +
			'<div class="m-content" name="form">' +
			'<section class="m-inner">' +
			'<header class="m-header shade4" ng-class="$ctrl.headerClass">' +
			'<a href="" class="m-close" ng-click="$ctrl.hideModal()">X</a>' +
			'<h3>{{$ctrl.modelTitle}}</h3>' +
			'</header>' +
			'<div class="m-body" ng-transclude></div>' +
			'<footer class="m-footer">' +
			'<button type="button" class="close-btn m-btn m-close btn btn-inverse" ng-click="$ctrl.hideModal()">Close</button>' +
			'<button type="button" ng-if="!$ctrl.modelInfo.readOnly && !$ctrl.readOnly" ng-disabled="$ctrl.disableBtn" ng-click="$ctrl.update()" ng-class="{disabled: form.$invalid || $ctrl.disableBtn}" class="btn btn-danger update-btn m-btn">{{$ctrl.btnTitle || "Update"}}</button>' +
			'</footer>' +
			'<div class="busy" ng-if="$ctrl.busy"></div>' +
			'</section>' +
			'</div>' +
			'</div>',
		controller: ModalController,
		transclude: true,
		bindings: {
			modelInfo: "<",
			modelTitle: "<",
			readOnly: "<",
			btnTitle: "<",
			busy: "<",
			disableBtn: "<",
			headerClass: "<"
		}
	});
});