/**
 * Form payment component.
 * This module will initialize the payment component for apps
 * @module FormPayment
 */
define(['angular', 'mainModule', 'stripe'], function (angular, mainModule) {
	'use strict';

	mainModule.component('formPayment', {
		template: '<div class="payment-wrapper">' +
			'<form ng-submit="pay($event)" ng-class="{loading: payment.xhr}" class="checkout">' +
			'<div class="form-row-stripe">' +
			'<label for="card-info">Card Info</label>' +
			'<div id="card-info"></div>' +
			'<div id="card-errors" role="alert"></div>' +
			'</div>' +
			'<button type="submit" class="btn btn-danger" ng-disabled="payment.disabled">Pay {{$ctrl.orderData.currencyCode}} {{ $ctrl.orderData.totalAmount }}</button>' +
			' <button type="button" class="btn btn-default" ng-if="!$ctrl.mandatory" ng-click="close($event)">Cancel</button>' +
			'<div class="after-msg" ng-if="payment.msg" ng-class="payment.status">' + 
			'<p ng-bind="payment.msg"></p>' +
			'<button type="button" class="btn btn-default" ng-click="ok($event)">Ok</button>' +
			'</div>' +
			'</form>' +
			'</div>',
		controller: ['$scope', '$http', function ($scope, $http) {
			var ctrl = this, stripe, elements, card;

			$scope.payment = {
				xhr: false,
				error: false,
				disabled: false,
				data: null,
				status: '',
				msg: ''
			};

			// initialization
			// Custom styling can be passed to options when creating an Element.
			// (Note that this demo uses a wider set of styles than the guide below.)
			var style = {
				base: {
					color: '#32325d',
					fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
					fontSmoothing: 'antialiased',
					fontSize: '16px',
					'::placeholder': {
						color: '#aab7c4'
					}
				},
				invalid: {
					color: '#fa755a',
					iconColor: '#fa755a'
				}
			};

			ctrl.$onInit = function () {
				// Create a Stripe client.
				stripe = Stripe(ctrl.orderData.stripePublishableKey);

				// Create an instance of Elements.
				elements = stripe.elements();

				// Create an instance of the card Element.
				card = elements.create('card', { style: style });

				listen();
			};

			function listen() {				
				// Add an instance of the card Element into the `card-element` <div>.
				card.mount('#card-info');

				// Handle real-time validation errors from the card Element.
				card.addEventListener('change', function (event) {
					var displayError = document.getElementById('card-errors');
					if(!displayError)
						return;

					$scope.payment.error = event.error;
					if (event.error) {
						displayError.textContent = event.error.message;
					} else {
						displayError.textContent = '';
					}
				});
			}

			function onSubmit(event) {
				event.preventDefault();

				$scope.payment.xhr = true;
				stripe.createToken(card).then(function (result) {
					if (result.error) {
						// Inform the user if there was an error.
						var errorElement = document.getElementById('card-errors');
						errorElement.textContent = result.error.message;
						$scope.payment.xhr = false;
					} else {
						// Send the token to your server.
						stripeTokenHandler(result.token);
					}
				});
			}

			// Submit the form with the token ID.
			function stripeTokenHandler(token) {
				// Insert the token ID into the form so it gets submitted to the server
				ctrl.orderData.stripeToken = token.id;
				
				$http({
					method: "post",
					withCredentials: true,
					url: (window.adoddleShopBaseUrl || "") + "/shop/payExternal",
					headers : {
						'Content-Type': 'application/x-www-form-urlencoded'
				   	},
					data: "orderItems=" + encodeURIComponent(angular.toJson(ctrl.orderData))
				}).then(function (response) {
					$scope.payment.data = response.data || {};
					$scope.payment.msg = $scope.payment.data.Message || 'Payment Failed';
					$scope.payment.status = ($scope.payment.data.Status || 'Failed').toLowerCase();
					$scope.payment.xhr = false;
				}, function (errors) {
					$scope.payment.msg = 'Payment Failed';
					$scope.payment.status = 'failed';
					$scope.payment.xhr = false;
				});
			}

			$scope.pay = function (e, item) {
				!$scope.payment.error && onSubmit(e);
			};

			$scope.close = function (e) {
				ctrl.onClose && ctrl.onClose({ e: e });
			};

			$scope.ok = function(data) {
				ctrl.onComplete && ctrl.onComplete({ data: $scope.payment.data });
			};
		}],
		bindings: {
			orderData: '<',
			onClose: '&',
			onComplete: '&',
			mandatory: '<'
		}
	});
});
