/**
 * header component.
 * This module will initialize the Stadard header component for angular application.
 * @module appHeader
 * Example: <app-header></app-header>
 * <app-header logo="" workspace="" showDate="" date=""></app-header>
 * <app-header logo="" hide-default-logo="true" workspace="" showDate="" date=""></app-header>
 * <app-header logo="" logo-custom-attr="" show-date="true" date="'13/05/2020'" form-name="'abc'"></app-header>
 */
define([ 'angular', 'mainModule'], function(angular, mainModule) {
	'use strict';

	mainModule.component('appHeader', {
		template : '<div class"form-app-header"><div class="h-logo-container" ng-if="$ctrl.logo"><img style="max-width:180px;max-height:70px;" src="{{$ctrl.logo}}" /></div>' +
				   '<div class="h-ws-date-cont"><div class="h-workpace-name">{{$ctrl.workspaceLabel}}: {{$ctrl.workspace}}</div><div class="h-date-container text-right" ng-if="$ctrl.showDate">{{$ctrl.dateLabel}}: {{$ctrl.date}}</div></div>'+
				   '<div class="primary-header-bg text-center h-form-name"><h4>{{$ctrl.formName}}</h4></div>'+  
				   '</div>',
		bindings : {
			logo : '<',
			model: '=', // To store custom Attribute logo in json field
			workspace : '<',
			workspaceLabel: '<', // workpace label if you want diffrent then 'workspace'
			formName : '<',
			showDate: '<', // show date or not
			date: '<',
			dateLabel: '<', // label for date
			hideDefaultLogo: '<', // set want to show only logo provided by input
			logoCustomAttr: '@' //Logo custom attribute name if the getting logo from custom attrubte and attribute name is diffrent then Logo
		},
		
		controller : ['$scope', 'commonApi', function($scope, commonApi) {
			var ctrl = this;
			var HEADER_CONSTANT = {
				defultlogo: 'images/asite.gif',
				workspacelbl: "Workspace",
				custLogoAttrName: "Logo"
			};

			ctrl.$onInit = function() {
				if(!ctrl.dateLabel){
					ctrl.dateLabel = 'Date';
				}
				if(!ctrl.workspace && document.getElementById('DS_PROJECTNAME') && document.getElementById('DS_PROJECTNAME').value){
					ctrl.workspace = document.getElementById('DS_PROJECTNAME').value;
				}
				if(!ctrl.formName && document.getElementById('DS_FORMNAME') && document.getElementById('DS_FORMNAME').value){
					ctrl.formName = document.getElementById('DS_FORMNAME').value;
				}
				if(!ctrl.logo && !ctrl.hideDefaultLogo){
					if(!ctrl.logoCustomAttr){
						ctrl.logoCustomAttr = HEADER_CONSTANT.custLogoAttrName;
					}

					var configLogoList = getConfigurableAttributeByType(ctrl.logoCustomAttr);
					if(configLogoList && configLogoList.length){
						ctrl.logo = configLogoList[0].Value8;
						if(typeof ctrl.model == 'string'){
							ctrl.model = configLogoList[0].Value8;
						}
					}else{
						ctrl.logo = HEADER_CONSTANT.defultlogo;
					}
				}
				if(!ctrl.workspaceLabel){
					ctrl.workspaceLabel = HEADER_CONSTANT.workspacelbl;
				}
			};

			/**
			 * return list for given attrubute list 
			 * @param {string} type: cutom attribute name 
			 */
			function getConfigurableAttributeByType(type){
				var customAttr = $scope.$parent.getValueOfOnLoadData('DS_ASI_Configurable_Attributes') || [];
				var AttributeByType = [];
				if(type){
					AttributeByType = commonApi._.where(customAttr, {
						Value3: type,
						Value11: "Active"
					});
				}
				return AttributeByType;
			}
		}]
	});
});