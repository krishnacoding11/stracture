/**
* DateTimePicker directive.
*/
define(['angular', 'mainModule'], function (angular, mainModule) {
	'use strict';
	mainModule.directive('datetimepicker', ['$timeout',
		function ($timeout) {

			return {
				require: '?ngModel',
				restrict: 'AE',
				scope   : {
					datetimepickerOptions: '&'
				},
				link: function (scope, elem, attrs, ngModelCtrl) {
					var passed_in_options = scope.datetimepickerOptions();
              		var options = jQuery.extend({}, {}, passed_in_options);

					elem.on('dp.show', function (e) {
						var datepicker = $('body').find('.bootstrap-datetimepicker-widget:last'),
							position = datepicker.offset(),
							parent = datepicker.parent(),
							parentPos = parent.offset(),
							width = datepicker.width(),
							parentWid = parent.width();

						// move datepicker to the exact same place it was but attached to body
						datepicker.appendTo('body');
						datepicker.css({
							position: 'absolute',
							top: position.top,
							bottom: 'auto',
							left: position.left,
							right: 'auto'
						});
						window.addEventListener('orientationchange', doOnOrientationChange);
						$(this).closest('.overflow-x').removeClass('overflow-x').addClass('overflow-visible');
					});
					
					function doOnOrientationChange() {
						setTimeout(() => {
							var datepicker = $('body').find('.bootstrap-datetimepicker-widget:last'),
							position = datepicker.offset();

							datepicker.appendTo('body');
							datepicker.css({
								position: 'absolute',
								top: position.top,
								bottom: 'auto',
								left: position.left,
								right: 'auto'
							});
						});
					}

					elem.on('dp.hide', function (e) {
						// window.removeEventListener('orientationchange', doOnOrientationChange);
						$(this).closest('.overflow-visible').addClass('overflow-x').removeClass('overflow-visible')
					});


					elem.on('dp.change', function (e) {
						if (ngModelCtrl) {
							// $timeout(function () {
							ngModelCtrl.$setViewValue(e.target.value);
							//});
						}
					});
					elem.datetimepicker(options);

					//Local event change
					elem.on('blur', function () {
						/*// returns moments.js format object
						scope.dateTime = new Date(elem.data("DateTimePicker").getDate().format());
						// Global change propagation
		  
						$rootScope.$broadcast("emit:dateTimePicker", {
							location: scope.location,
							action: 'changed',
							dateTime: scope.dateTime,
							example: scope.useCurrent
						});
						scope.$apply();*/
					})
				}
			};
		}
	]);
});