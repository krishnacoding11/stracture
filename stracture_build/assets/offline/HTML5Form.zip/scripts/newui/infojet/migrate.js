function ie_ver() {
    var iev = 0;
    var ieold = (/MSIE (\d+\.\d+);/.test(navigator.userAgent));
    var trident = !!navigator.userAgent.match(/Trident\/7.0/);
    var rv = navigator.userAgent.indexOf("rv:11.0");

    if (ieold)
        iev = new Number(RegExp.$1);
    if (navigator.appVersion.indexOf("MSIE 9") != -1)
        iev = 9;
    if (navigator.appVersion.indexOf("MSIE 10") != -1)
        iev = 10;
    if (trident && rv != -1)
        iev = 11;

    return iev;
}

/*
*	Following function is just alternate of ViewFormDWR.getCallbackData
*/
function getViewFormCallbackData(field, param , formId , projectId , userID , proxyUserID ,callback){
	if (ie_ver() > 0){
    	jQuery.support.cors = true;
    }
    $.ajax({
        data: {
            field: field,
            param: param,
            formId: formId,
            projectId: projectId,
            action_id: 173
        },
        dataType: 'text',
        url: '/adoddle/apps',
        type: 'POST',
        cache: false,
        crossDomain: true,
        xhrFields: {
            withCredentials: true
        },
        success: function (data) {
            callback(data);
        },
        error: function (xhr, textStatus, errorThrown) {
            
        }
    });
}

/* Infojet.js global variable start here */
Date.monthAbbreviations = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
/* Infojet.js global variable end here*/