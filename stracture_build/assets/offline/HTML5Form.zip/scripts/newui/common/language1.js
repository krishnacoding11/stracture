var Language = {
	/**
	 * here args is array[] which contain message placeholder values. args is optional parameter.  
	 */
	get: function (key, args) {
		if(key && key.trim().indexOf(' ') > -1) {
			return key;
		}

        var instance = this;
		var value = instance._cache[key];
		
		try {
			var parentWindow = window.opener || window.parent || window.top;
			if(!value && !instance._cache[key] && parentWindow.Language._cache[key]) {
				instance._cache[key] = parentWindow.Language._cache[key]; 
				value = instance._cache[key];
			}
		} catch(e) {}

		if(args) {
			value = Language.replacePlaceholder(value, args);
		}
		
        return value;
    },
    
    replacePlaceholder: function(value, args) {
    	 if(args) {
             for (var i in args) {
                 value = value.replace(new RegExp("\\{" + i + "\\}", "g"), args[i]);
             }
         }
    	 return value;
    },
	
	getLanguageKeyValuePair: function() {
		var instance = this;

		var uspKeyValuePair = jQuery.ajax({
			async: false,
			type: 'POST',
			dataType: 'json',
			processData: false,
			url: "/commonapi/user/getUspBasedOnSessionID"
		});

		try {
			window.USP = JSON.parse(uspKeyValuePair.responseText);
		} catch(e) {}

		var marketPlaceValuePair = jQuery.ajax({
			async: false,
			type: 'GET',
			dataType: 'json',
			processData: false,
			url: "/commonapi/dataObjectService/getPropertyValues"
		});

		try {
			var marketPlace = JSON.parse(marketPlaceValuePair.responseText);
			window.marketPlaceServiceURL = marketPlace.marketplaceServiceURI;
			window.marketPlaceApiKey = marketPlace.marketplaceApiKey;
	
			window.intercomSettings = {
				app_id: marketPlace.intercomeAppId,
				name: USP.firstName,
				email: USP.email,
				user_hash: marketPlace.userHash,
				created_at: "1611146676893"
			};
		} catch(e) {}

        try {
			var parentWindow = window.opener || window.parent || window.top;
			jQuery.extend(instance._cache, parentWindow.Language._cache);
		} catch(e) {}
        
		var languageId = window.USP ? window.USP.languageId : 'en_GB';
		var staticContentVersion = window.staticContentVersion || new Date().getTime();

		// Use in offline form
		if(window.isOfflineMode){
			// js-frame call
			instance.loading = true;
			var sendEventToIpad = function(strEvent){
				var iframe = document.createElement("IFRAME");
				iframe.setAttribute("src", "js-frame:" + strEvent);
				document.documentElement.appendChild(iframe);
				iframe.parentNode.removeChild(iframe);
				iframe = null;
			};	

			sendEventToIpad(JSON.stringify({
				"lan": languageId,
				"ver": staticContentVersion				
			}));

			//Offline callback function
			window.langResponseCallBack = function(data) {
				instance.loading = false;
				instance._cache = data;
				window.offlineBootstrapCallBack && window.offlineBootstrapCallBack();							
				if(instance.pendingCallbacks.length) {
					instance.pendingCallbacks.forEach(function(pendingCallback) {
						pendingCallback();
					});
					instance.pendingCallbacks.length = 0;
				}
			}
		} else {
			// Pass editionId if not null or undefined
			var url_passsed = window['INIT_JSP_GLOBAL'] && window['INIT_JSP_GLOBAL'].editionId ? "/commonapi/language/getLanguageKeyValues?lan="+languageId+"&ver="+staticContentVersion+"&eId="+window['INIT_JSP_GLOBAL'].editionId : "/commonapi/language/getLanguageKeyValues?lan="+languageId+"&ver="+staticContentVersion
			var xHR = jQuery.ajax({
				async: false,
				type: 'GET',
				dataType: 'json',
				url: url_passsed
			});
			
			instance._cache = JSON.parse(xHR.responseText);
		}
	},
	
	getLangObj: function() {
		return this._cache;
	},
	
	registerCallback: function(callback) {
		if(!callback){
			return;
		}
		if(window.isOfflineMode && this.loading) {
			this.pendingCallbacks.push(callback);
		}else {
			callback();
		}
	},
	
    _cache: {},

	loading: false,

	pendingCallbacks: []
};

Language.getLanguageKeyValuePair();
