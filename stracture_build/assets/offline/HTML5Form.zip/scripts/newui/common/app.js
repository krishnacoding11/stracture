angular.module("adoddle")
    .config(['$compileProvider', '$sceDelegateProvider', '$qProvider', 'NotificationProvider',
        function($compileProvider, $sceDelegateProvider, $qProvider, NotificationProvider) {
            // remove looking for css and comment directives
            $compileProvider.commentDirectivesEnabled(false);
            $compileProvider.cssClassDirectivesEnabled(false);

            $sceDelegateProvider.resourceUrlWhitelist([
                // Allow same origin resource loads.
                'self',
                // Allow loading from our assets domain.  Notice the difference between * and **.
                'https://*.asite.com/**',
                'http://*.asite.asitehq.com/**',
                'https://iotsb.asite.com/**',
                'https://iot.asite.com/**'
            ]);

            //configure the error handling behavior
            //set to false by default to prevent unwanted errors on ajax fail
            $qProvider.errorOnUnhandledRejections(false);

            // default notification settings
            NotificationProvider.setOptions({
                delay: 5000,
                startTop: 20,
                startRight: 10,
                verticalSpacing: 20,
                horizontalSpacing: 20,
                positionX: 'center',
                positionY: 'top'
            });
        }
    ])

.value('globalVar', {
    retainNoOfShow: 10
})

/**
 * language service.
 * This module will provide internationalization.
 * @module api
 */
.service('lang', ['$window', function($window) {
    this.get = function() {
        return $window.Language.get.apply($window.Language, arguments);
    };

    this.getLangObj = function() {
        return $window.Language.getLangObj();
    };
}])


/**
 * apiConfig constants.
 * This constants represents the ajax controllers, jsp urls, action ids, privileges, etc...
 * @module formApp
 */
.constant('apiConfig', {
    // controllers
    LANGUAGE_CONTROLLER: '/adoddle/language',
    DASHBOARD_CONTROLLER: '/adoddle/dashboard',
    HOME_CONTROLLER: '/adoddle/home',
    LISTING_CONTROLLER: '/adoddle/listing',
    COMMUNICATIONS_CONTROLLER: '/adoddle/communications',
    PUBLIC_VIEW_FORM: '/adoddlepublic/publicViewForm',
    DOCUMENT_CONTROLLER: '/adoddle/files',
    PROJECTS_CONTROLLER: '/adoddle/projects',
    ACTIONS_CONTROLLER: '/adoddle/actions',
    APPS_CONTROLLER: '/adoddle/apps',
    DOWNLOAD_CONTROLLER: '/adoddle/download',
    PUBLIC_DOWNLOAD_CONTROLLER: '/adoddlepublic/publicDownload',
    GET_FIELD_ENABLE_PROJECT: '/adoddlenavigatorapi/workspace/fieldEnabledSelectedProjects',
    DISTRIBUTION_CONTROLLER: '/adoddle/dist',
    UPLOAD_CONTROLLER: '/adoddle/upload',
    ADODDLE_UPLOAD_CONTROLLER: '/adoddle/adoddleUpload',
    PROCUREMENT_CONTROLLER: '/adoddle/procurement',
    MODELS_CONTROLLER: '/adoddle/models',
    HOOPS_MARKUP_CONTROLLER: '/adoddle/hoopsmarkup',
    HOOPS_CONTROLLER: '/adoddle/hoops',
    FEDERATED_MODELS_CONTROLLER: '/adoddle/objectManagerController',
    EXPORT_CONTROLLER: '/adoddle/export',
    ASITE_POPUP_CONTROLLER: '/adoddle/getPopupData',
    SEARCH_FILTER_CONTROLLER: '/adoddle/filter',
    BATCH_CONTROLLER: "/adoddle/batch",
    CREATE_COMMENT_CONTROLLER: '/adoddle/CreateComment',
    MODELS_COMMENTS_CONTROLLER: "/adoddle/ModelComment",
    SAVE_COMMENT_CONTROLLER: "/adoddle/SaveComment",
    SAVE_BATCH_COMMENT_CONTROLLER: "/adoddle/SaveBatchComment",
    SHARE_LINK_CONTROLLER: "/adoddle/sharelink",
    GET_USER_SHARE_PERMISSION: 'sharelink/getUserPermission',
    CONTACT_CONTROLLER: "/adoddle/contacts",
    DOWNLOAD_DOCUMENT_FROM_FORM: "/adoddle/downloadDocAssociations",
    DOWNLOAD_DOCUMENT_FROM_PUBLIC_FORM: "/adoddlepublic/publicDownload",
    USER_PREFERENCES_CONTROLLER: '/adoddle/preferences',
    PUBLISH_PDF_CONTROLLER: '/adoddle/PublishPdf',
    WOM_DIAGRAM_CONTROLLER: '/adoddle/wom/diagram-viewer',
    WOM_WORKFLOWS_CONTROLLER: '/adoddle/wom/workflow',

    // commonapi
    GET_CUSTOM_OBJECT_TEMPLATE_LIST: '/commonapi/adoddleCustomObject/getCustomObjectTemplateList',
    GET_CUSTOM_OBJECT_COMMENT_LIST: '/commonapi/adoddleCustomObject/getCustomObjectCommentList',
    CREATE_CUSTOM_OBJECT_COMMENT: '/commonapi/adoddleCustomObject/createCustomObjectComment',
    SAVE_CUSTOM_OBJECT_MODEL_VIEW: '/commonapi/adoddleCustomObject/saveCustomObjectView',
    SAVE_CUSTOM_OBJECT_COMMENT: '/commonapi/adoddleCustomObject/saveCustomObjectComment',
    UPDATE_CUSTOM_OBJECT_COMMENT_ACTION: '/commonapi/adoddleCustomObject/updateCustomObjectCommentAction',
    GET_CUSTOM_OBJECT_AUDIT_TRAIL_DETAIL_LIST: '/commonapi/adoddleCustomObject/getCustomObjectAuditTrailDetailList',
    GET_REVIEWS_FOR_COORDINATION_ACTION: '/commonapi/adoddleCustomObject/getReviewsForCoordinationAction',
    SAVE_CUSTOM_OBJECT_REVIEW_COORDINATION: '/commonapi/adoddleCustomObject/saveCustomObjectReviewCoordination',
    EXPORT_BCF_ISSUE: '/commonapi/issue/exportIssueBCF',
    PREPARE_EXPORT_BCF_ISSUE: '/commonapi/issue/prepareExportIssueBCF',
    LANGUAGE_CONTROLLER_KEY_VALUE: '/commonapi/language/getLanguageKeyValues',
    GET_LOCATION_TREE: '/commonapi/pflocationservice/getLocationTree',
    GET_XOD_FILE: '/commonapi/webviewerservice/downloadXOD',
    MARKUPS_LISTING_CONTROLLER: "/commonapi/markups/listing",
    SEARCH_RESOURCE_LIST: "/commonapi/share/getResources",
    FILL_SHARE_FILTER_RESOURCE_LIST: "/commonapi/share/getResourcesById",
    GET_WORKSPACE_SETTING: '/commonapi/workspace/getWorkspaceSetting',
    VIEW_MARKUP: '/commonapi/webviewerservice/viewMarkup',
    CHECK_USER_LATEST_REVISION_API: '/commonapi/document/checkUserLatestRevision',
    MARKUP_LIST: '/commonapi/markups/listing',
    GET_WORKSPACE_SETTING_MARKUP: '/commonapi/markups/getworkspacesetting',
    GET_MARKUPID_BYNAME: '/commonapi/markups/getMarkupIdByName',
    PRE_UPLOAD_VALIDATION_API_URL: '/commonapi/event/uploadEventValidation',
    GET_FILE_ATTRIBUTES_API: '/commonapi/document/getFileAttributes',
    UPDATE_FILE_ATTRIBUTES_API: '/commonapi/document/updateFileAttributes',
    ACTIVATE_USER_SESSION: '/commonapi/login/activateUserSession',
    GET_SESSION_TIMEOUT_DETAILS: '/commonapi/login/getSessionTimeoutDetails',
    MEDIA_COMPLETE_ACTION: 'commonapi/media/completeAction',
    GET_DIST_WISE_USER_LIST: 'commonapi/manageAdoddleObjectPrivacy/getUserListForGivenResource',
    GET_LOCATION_DETAILS_BY_LOCATION: 'commonapi/pflocationservice/getLocationDetailsByLocationIds',
    GET_OBSERVATION_LIST_BY_PLAN: 'commonapi/pfobservationservice/getObservationListByPlan',
	GET_ACTIVITY_LOCK_IDS: "/commonapi/lock/getObjectActivityLockedIds",
    GET_PROJECT_APPDETAIL_BY_FORM_TYPE_NAME: "/commonapi/form/getProjectAppTypeDetailsByFormTypeName",    
    THUMBNAIL_VIEW_TEMP_PATH: "/commonapi/thumbnail/viewTempThumb",
    THUMBNAIL_VIEW_PATH: "/commonapi/thumbnail/viewThumb",
    HELP_FILE_CONTENT: '/contexthelper/',
    VIEW_ELEARNING: "/adoddle/view/externalapp/elearning.jsp",
    HELP_FILE_FREEMIUM_CONTENT: "/Freemium_contexthelper/",
    GET_EXTRACTED_ZIP_FILE: '/commonapi/webviewerservice/getFilesWithInCompressedFile',
    
    // Download
    IS_DOCUMENT_DOWNLOAD_RESTRICTED: '/download/document/isDownloadRestricted',
    DOWNLOAD_SINGLE_DOCUMENT: '/download/document/single',
    CAN_DOWNLOAD_FOLDER_LEVEL: '/download/folder/canDownloadFolderLevel',
    DOWNLOAD_BATCH_DOCUMENT_CONTROLLER: '/download/document/batch',
    DOWNLOAD_BATCH_DOCUMENT_PAGE_CONTROLLER: '/download/document/downloadBatchDocumentPage',
    CHECK_DOCUMENT_DOWNLOAD_LIMIT: '/download/document/checkDownloadLimit',
    PROGRESS_ZIP_CREATION_CONTROLLER: '/download/document/getZipProgress',
    DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER: '/download/document/batchWithMarkup',
    PROGRESS_GENERATE_MARKUP_AS_PDF_CONTROLLER: '/download/document/markupPDFprogress',
    DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER: '/download/document/downloadTempZipFile',
    ASYNC_NOTIFICATION: '/commonapi/document/aSyncNotification', // send notification to aSync app
    REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK_CONTROLLER: '/download/document/checkValidForCheckOutOnRightClick',
    CHECKOUT_REVISION_CONTROLLER: '/download/checkout/checkoutRevision',
    GET_CHECKOUT_REVISION_DETAILS_CONTROLLER: '/download/checkout/getCheckoutRevisionDetails',
    CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT_CONTROLLER: '/download/document/checkAvailabilityOfDownloadDocument',
	DOWNLOAD_INTERNAL_ATTACHMENT_CONTROLLER: '/download/document/internalAttachment',
    DOWNLOAD_EXTRACTED_ZIP_FILE: '/download/document/extractedFile',
    MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER: '/download/document/multiDCBatch',
    UNDO_CHECKOUT_CONTROLLER: '/download/checkout/undoCheckout',
    DOWNLOAD_CUSTOM_FORM_ATTACHMENT: '/download/document/downloadCustomFormAttachment',
    DOWNLOAD_FORM_ASSOCIATION_BYPASS_SECURITY: '/download/document/downloadFormAssociationByPassSecurity',

    // jsp
    FILE_VIEW_MOBILE: "/adoddle/viewer/fileView.jsp",
    VIEW_FORM: "/adoddle/view/communications/viewForm.jsp",
    PRINT_VIEW_FORM: "/adoddle/view/communications/apps/printViewForm.jsp",
    BATCH_PRINT_FORM_PAGE: "/adoddle/view/communications/apps/batchPrintForm.jsp",
    FILE_VIEW_PAGE: "/adoddle/viewer/fileView.jsp",
    ATTACH_FILE_VIEWER_PREFERENCE: "/adoddle/viewer/attachFileopenViewerpreference.jsp",
    UPLOAD_REDIRECT_RESULT: "/adoddle/result.jsp",
    VIEW_MODEL_FOR_WEB: '/adoddle/viewer/modelView.jsp',
    CONIGURABLE_COLUMN_CONTROLLER: '/adoddle/configcontroller',
    ATTACH_FILE_VIEWER_PREFERENCE: '/adoddle/viewer/attachFileopenViewerpreference.jsp',
    HTML_COMPARE_DOC: '/adoddle/viewer/compareDocsHTMLViewer.jsp',
    ACTIVEX_COMPARE_DOC: '/adoddle/viewer/compare.jsp',
    VIEWER_PARENT_REFRESH: '/adoddle/viewer/viewerRefreshParent.jsp',
    START_STOP_WATCHER: '/commonapi/watch',
    UPDATE_DASHBOARD_NOTIFICATION: '/commonapi/watch/updaeDashboardNotificationsStatus',
    GET_DASHBOARD_NOTIFICATION: '/commonapi/watch/getDashboardNotifications',
    NOTICE_COMMONAPI_ALLNOTICE: '/commonapi/notice/activeNotice',
    NOTICE_COMMONAPI_DISMISS: '/commonapi/notice/dismiss',
    IMAGE_PATH: '/commonapi/user/userImg?userId=',
    WATCH_CHECK_PERMISSION: 'commonapi/watch/checkPermission',
    LOCAL_STORAGE: '/adoddle/view/common/localStorage.jsp',

    // action ids
    GET_DIST_GROUP_USERS: 840,
    LIST_WORKFLOWS: 1,
    ADODDLE_FOLDER_TREE: 2,
    WORKFLOW_PROGRESS: 4,
    ADODDLE_WORKSPACE_TREE: 5,
    ADODDLE_DISTRIBUTE_FILES: 10,
    DISTRIBUTE_FORM: 11,
    ADODDLE_WORKSPACE_AND_FOLDER_TREE_LEVEL: 14,
    ADODDLE_APP_TYPE_WORKSPACE_TREE: 16,
    ADODDLE_APP_TYPE_FORM_TREE: 17,
    COMMIT_DISTRIBUTION: 19,
    COMPLETE_FOR_ACKNOWLEDGEMENT_ACTION: 20,
    COMPLETE_FOR_ACTION: 21,
    FORM_DIST_VALIDATION: 26,
    PREVIOUSLY_FORM_DIST_USER_LIST: 27,
    ADODDLE_LISTING_ACTION: 100,
    SAVE_CONFIGURABLE_COLUMN_ACTION: 102,
    DOWNLOAD_SINGLE_DOCUMENT_ACTION: 103,
    DOWNLOAD_INTERNAL_ATTACHMENT: 197,
    GET_LIST_FOR_DISTRIBUTION: 107,
    VIEW_FORM_ACTION: 114,
    VIEW_FORM_MSG_DETAILS_ACTION: 115,
    GET_FILE_ATTRIBUTES_SET: 117,
    DISPLAY_APP_TEMPLATES_LIST: 118,
    DOWNLOAD_BATCH_DOCUMENT_PAGE: 119,
    DOWNLOAD_BATCH_DOCUMENT_ACTION: 120,
    GET_FILE_PREV_REVISION_DETAILS: 122,
    UPDATE_COMMENT_ACTION: 124,
    DOWNLOAD_TEMP_ZIP_FILE: 125,
    PROGRESS_ZIP_CREATION: 126,
    DISPLAY_PRINT_VIEW_FORM: 132,
    GET_FILE_NAME_FOR_REVISION: 136,
    GET_UPLOAD_SETTING: 137,
    UPLOAD_FILE_VALIDATION: 138,
    UPLOAD_FILE_RULES_VALIDATION: 139,
    FILE_DIST_VALIDATION: 140,
    VIEW_FILE_DISCUSSIONS: 148,
    VIEW_FILE_HISTORY: 149,
    VIEW_FORM_HISTORY: 150,
    GET_SELECTED_REV_ATTRIBUTE_VO: 162,
    ADODDLE_FORM_PERMISSIONS: 167,
    MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION: 168,
    MOVE_FILES_TO_TEMP_LOCATION: 172,
    CHECK_REV_RESTRICT_FOR_DOWNLOAD: 175,
    UPDATE_AUDIT_TRAIL_FORM_ATTACHMENT: 179,
    GET_FOLDER_PERMISSION_VALUE: 818,
    APPLET_UPLOAD_PAGE: 176,
    UPDATE_MSG_STATUS: 181,
    COPY_DISTRIBUTION_FROM_PREVIOUS_DISTRIBUTION: 182,
    COMMIT_UPLOAD_FILES_DETAIL: 184,
    DISPLAY_PRINT_VIEW_FORM_ALL: 185,
    GET_PUBLISHED_DOCS_FOR_PALCEHOLDER: 192,
    VIEW_FILE_ATTACHMENT_ASSOCIATION: 192,
    CHECK_FOR_AKAMAI_DOWNLOAD_LIMIT: 193,
    CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT: 198,
    GET_USER_APPLICATION_PRIVILEGES: 207,
    GET_USER_APPLICATION_PRIVILEGES_MULTI: 1342,
    GET_FORM_TYPE_PRIVILEGES: 210,
    DOCUMENT_COMPLETE_FOR_INFORMATION: 226,
    DEACTIVATE_FORM_ACTION_LIST: 316,
    DEACTIVATE_FORM_ACTION: 317,
    REACTIVATE_FORM_ACTION_LIST: 318,
    REACTIVATE_FORM_ACTION: 319,
    PROCUREMENT_GET_SKN_VALIDATION_CALL_OFF: 426,
    STATUS_CHANGE_ACTION: 501,
    STATUS_CHANGE_SINGLE_SUBMIT: 502,
    DISPLAY_FORM_CHANGE_STATUS: 571,
    SUBMIT_FORM_CHANGE_STATUS: 572,
    FORM_DISTRIBUTION_CLEAR_ACTION_LIST: 573,
    FORM_DIST_CLEAR_ACTION_SUBMIT: 574,
    FORM_DIST_DELEGATE_ACTION_LIST: 575,
    FORM_DIST_DELEGATE_ACTION_SUBMIT: 576,
    CHECK_INVENTOR_FILE_HAS_REQUIRED_ATTACHMENT: 579,
    SAVE_MODEL_ACTION: 607,
    SAVE_MODEL_ACTION_LATEST_REV_ZIP: 608,
    PUBLIC_SAVE_MODEL_ACTION_LATEST_REV_ZIP: 1901,
    GET_VIEWS_OF_MODEL: 625,
    GET_ASSOC_LISTS_MODEL: 627,
    GET_HWF_MODEL_FILE_STATUS: 631,
    VIEW_MODEL_HISTORY: 632,
    GET_USER_SEARCH_FILTERS_COLUMNS: 700,
    DELETE_USER_SEARCH_FILTER: 703,
    GET_USER_SEARCH_FILTERS: 701,
    EDIT_USER_SEARCH_FILTER: 702,
    SAVE_USER_SEARCH_FILTER: 704,
    UNSAVED_USER_SEARCH_FILTER: 705,
    SEARCH_FILTER_DATA: 706,
    GET_SEARCH_FIELD_VALUES: 707,
    SEARCH_DEFAULT_FIELDS_RESULT: 708,
    DOCUMENT_DISTRIBUTION_CLEAR_ACTION_LIST: 716,
    DOCUMENT_DISTRIBUTION_CLEAR_ACTION_SUBMIT: 717,
    DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_LIST: 718,
    DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_SUBMIT: 719,
    DEACTIVATE_FILE_ACTION_LIST: 823,
    DEACTIVATE_FILE_ACTION: 824,
    REACTIVATE_FILE_ACTION_LIST: 825,
    REACTIVATE_FILE_ACTION: 826,
    INITIATE_CREATE_ORI_MSG: 903,
    INITIATE_CREATE_FWD_MSG: 904,
    INITIATE_CREATE_RES_MSG: 905,
    BATCH_FILES_FOR_ACKNOWLEDGEMENT: 951,
    BATCH_FILES_FOR_COMMENT_INCORPORATION: 952,
    BATCH_FILES_FOR_ACTION: 953,
    INITIATE_EDIT_FORM_MSG_COMMITED: 953,
    BATCH_FILES_FOR_COMMENT_COORDINATION: 954,
    ACTION_COMMENT_COORDINATION_INVIEW: 955,
    INITIATE_IMPORT_FORM: 959,
    INITIATE_IMPORT_FORM_FOR_EDIT_ORI: 964,
    CHECK_CONCURRENCY_ISSUE: 965,
    CHECK_EDIT_ORI_DRAFT_MESSAGE: 966,
    CHECK_MAX_INSTANCE_CREATION: 967,
    GET_FOLDER_LIST_POPUP: 1002,
    SAVE_ATTACH_EXT_DOC: 1125,
    UPLOAD_CHUNK_FILE: 1201,
    BATCH_FILES_FOR_INFORMATION: 1301,
    GET_FILE_VIEW_ATTRIBUTES_DETAILS: 1305,
    GET_ADRIVE_FILE_VIEW_ATTRIBUTES_DETAILS: 1306,
    DASHBOARD_GET_USERS_TO_SHARE: 1331,
    CHECKOUT_REV: 1367,
    GET_CHECKOUT_REV_DETAILS: 1368,
    EXPORT_DOCUMENT_HISTORY: 1404,
    REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK: 1369,
    VALIDATE_DOC_NAMING_RULE: 1404,
    EXPORT_FORM_HISTORY: 1405,
    EXPORT_FILE_ASSOCIATIONS_LINK_INFO: 1408,
    SAVE_AS_PDF_AUDIT: 1501,
    SAVE_AS_TIFF_AUDIT: 1502,
    SAVE_AS_CSF_AUDIT: 1506,
    SAVE_FILE_VIEWER_USER_PREFERENCE_ID: 1507,
    COMPARE_FILES: 1508,
    GENERATE_LEGACY_MARKUP: 1509,
    GENERATE_LEGACY_MARKUP_CONSOLIDATED : 1510,
    RIGHT_CLICK_PRINT_VIEW_FORM_ALL: 1703,
    GET_CONTACTS: 1700,
    UPDATE_FLAG: 1710,
    GET_USER_FLAG: 1711,
    GET_ATTACHMENT_AND_ASSOCIATIONS: 1721,
    CHECK_CAN_DOWNLOAD_FOLDER_LEVEL: 256,
    GET_USER_SELECTED_COLUMNS: 1722,
    GET_ALL_LISTING_HEADER: 1734,
    SET_SELECTED_VIEW_TYPE: 1726,
    SAVE_COMMENT: 1728,
    SAVE_DRAFT_COMMENT: 1729,
    INSERT_MODEL_VIEW_HISTORY: 642,
    SAVE_ASSOCIATE_DOCS: 1015,
    GET_ASSOCIATE_DOC: 1013,
    SAVE_AUDIT_TRAIL_FOR_DOCUMENT_ASSOCIATION: 1016,
    GET_USERS_MODEL_DIST_LIST: 616,
    DOWNLOAD_MODEL_TILE: 640,
    SET_MODEL_TILE: 639,
    RENAME_MODEL_VIEW: 636,
    GET_VIEW_DATA: 780,
    SAVE_MODEL_VIEW: 630,
    GET_IFC_OBJECT_TYPE: 1004,
    GET_ALL_BIM_LIST: 1007,
    OBJECT_BASIC_SEARCH: 1006,
    GET_OBJECT_PROPERTIES: 1003,
    URI_OBJECT_ADVANCED_SEARCH: 1009,
    ADD_OBJECT_TO_LIST: 1011,
    SAVE_MODEL_LIST: 1005,
    URI_GET_BIM_LIST_DETAIL: 1008,
    UPDATE_BIM_OBJECT_LIST: 1014,
    GET_HOOPS_FILE_MARKUP: 635,
    CHECK_FILE_PERMISSION: 5,
    CHECK_FOLDER_PERMISSION: 4,
    CHECK_FOR_AKAMAI_UPLOAD_LIMIT: 199,
    DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION: 1731,
    PROGRESS_GENERATE_MARKUP_AS_PDF: 1732,
    GET_SEARCH_PROJECT_LIST_OFFLINE: 221,
	GET_PROJECT_LIST_OFFLINE: 222,
	GET_FOLDER_LIST_OFFLINE: 223,
    GET_SUBFOLDER_LIST_OFFLINE: 224,
    OFFLINE_GET_OBSERVATION_LIST_BY_PLAN_ACTIONID: 225,
    OFFLINE_GET_MARKUPS_LIST: 227,
    OFFLINE_SAVE_COMMENT: 228,
    OFFLINE_SAVE_DRAFT_COMMENT: 229,
    OFFLINE_GET_MARKUPID_BYNAME: 230,
    DELETE_THUMBNAIL_TEMP_FILES: 1206,
    GENERATE_LITE_PDF: 1902,
    
    // listing types
    FILE_LISTING: 1,
    COMMUNICATION_FORM_LISTING: 31,
    DISCUSSION_LISTING: 32,
    REVIEW_LISTING: 147,
    TRANSMITTALS: 21,
    APPS_TRANSMITTALS: 22,
    FIELD_TRANSMITTAL_LISTING: 23,
    CONTRACT_TRANSMITTAL_LISTING: 24,
    FM_TRANSMITTAL_LISTING: 25,
    FINANCE_TRANSMITTAL_LISTING: 26,
    PPM_TRANSMITTAL_LISTING: 27,
    HR_TRANSMITTAL_LISTING: 28,
    H_AND_S_TRANSMITTAL_LISTING: 29,
    PPMT_TRANSMITTAL_LISTING: 30,
    SEARCH_TYPE_CONTACTS_LISTING: 62,
    APP_GLOBAL_SEARCH_LISTING: 39,
    FIELD_FORM_LISTING: 51,
    CONTRACT_FORM_LISTING: 52,
    FM_FORM_LISTING: 53,
    FINANCE_FORM_LISTING: 54,
    PPM_FORM_LISTING: 55,
    HR_FORM_LISTING: 56,
    H_AND_S_FORM_LISTING: 57,
    MARKETPLACE_FORM_LISTING: 128,
    MARKETPLACE_TRANSMITTAL_LISTING: 129,
    SUSTAINABILITY_FORM_LISTING: 153,
    ADMIN_FETCH_RULE_LISTING: 45,
    PROJECT_LISTING_TYPE: 42,
    MODEL_LISTING_TYPE: 47,
    ADMIN_LISTING_TYPE: 44,
    MODEL_GLOBAL_SEARCH_LISTING: 8,
    COMMUNICATION_FORM_TEMPLATE_LISTING: 33,
    ALL_APP_TYPES_LISTING: 34,
    PROCUREMENT_CATALOGUE_DATA_LISTING: 35,
    PROCUREMENT_CATALOGUE_BASKET_LISTING: 36,
    DESCIPLINE_WISE_MODELREVISIONS_LISTING: 37,
    MODEL_PENDING_ACTIONS_DOCUMENT_LISTING: 38,
    ALL_APPS_AND_PROCUREMENT_MESSAGES_LISTING: 39,
    PRINT_OPTIONS_VALUE_ALL: 63,
    PROCUREMENT_LISTING: 4,
    NEW_PROCUREMENT_LISTING: 126,
    CATALOG_LISTING: 101,
    LEGACY_REPORT_LISTING: 60,
    SEARCH_TYPE_TEMPLATE_LISTING: 58,
    PPMT_FORM_LISTING: 59,
    SCHEDULING_REPORT_LISTING_TYPE: 61,
    ACL_MATRIX_REPORT: 90,
    MANAGE_DISTRIBUTION_GROUP: 91,
    MANAGE_APP_LISTING_TYPE: 49,
    CONTACT_LISTING_TYPE: 62,
    WORKFLOW_LISTING_TYPE: 64,
    WOM_INST_LISTING_TYPE: 66,
    WORKFLOWS_RULE_LISTING: 67,
    WORKFLOWS_ACTION_LISTING: 68,
    DIRECTORY_CATALOUGE_DATA_LISTING: 63,
    DOC_MAILBOX_LISTING: 46,
    FORM_MAILBOX_LISTING: 48,
    ASSIGNED_FORMTYPE_LISTING: 49,
    DOCUMENT_HISTORY_EXPORT: 92,
    PUBLIC_FOLDER_LISTING: 94,
    FORM_HISTORY_EXPORT: 93,
    EXPORT_FILE_ASSOCIATIONS_LINK_INFO_LISTING_TYPE: 97,
    NOTICE_LISTING: 69,
    MANAGE_USER_LISTING: 70,
    ASSOCIATION_MARKUP_LISTING: 102,
    ASSOCIATION_STATIC_LISTING: 103,
    ASSOCIATED_FORM_LISTING: 71,
    ATTACHMENT_LISTING: 72,
    ASSOCIATED_FILE_LISTING: 73,
    ASSOCIATED_DISCUSSION_LISTING: 74,
    ASSOCIATED_SELECTED_FILE_LISTING: 77,
    ASSOCIATED_SELECTED_DISCUSSION_LISTING: 78,
    ASSOCIATED_SELECTED_FORM_LISTING: 79,
    ASSOCIATED_SELECTED_REVIEW_LISTING: 148,
    ASSOCIATED_REVIEW_LISTING: 149,
    CREATE_FORM_ATTACHMENT_LISTING: 139,
    WORKSPACE_ACCESS_LOG_LISTING: 80,

    // APPLICATION PRIVILEGES
    PRIV_EDIT_USERS: 1,
    PRIV_EDIT_Organisations: 2,
    PRIV_MANAGE_SYSTEM_NOTICES: 3,
    PRIV_MANAGE_FORM_TEMPLATES: 4,
    PRIV_MANAGE_ROLE_TEMPLATES: 5,
    PRIV_MANAGE_DRAWING_SERIES_TEMPLATES: 6,
    PRIV_MANAGE_REPROGRAPHICS: 7,
    PRIV_CREATE_REPRO_ORDER: 8,

    // PROJECT PRIVILEGES
    PRIV_MANAGE_WORKSPACE_ROLES_USERS: 9,
    PRIV_MANAGE_PROJECT_ROLES: 10,
    PRIV_ASSIGN_USERS_PRIVILEGES: 11,
    PRIV_VIEW_USER_PRIVILEGES: 12,
    PRIV_MANAGE_NOTICES: 13,
    PRIV_ASSIGN_FORMS_TO_PROJECT: 14,
    PRIV_EDIT_PROJECT_FORM_SETTINGS: 15,
    PRIV_MANAGE_PROJECT_WORKPACKAGES: 16,
    PRIV_MANAGE_PROJECT_DOCUMENT_STATUS: 17,
    PRIV_MANAGE_PROJECT_DRAWING_SERIRES: 18,
    PRIV_CREATE_FOLDER: 19,
    PRIV_AMEND_FOLDER_PERMISSIONS: 20,
    PRIV_ASSIGN_DOCUMENT_ATTRIBUTES: 21,
    PRIV_DEACTIVATE_DOCUMENTS: 22,
    PRIV_DISTRIBUTE_DOCUMENTS: 23,
    PRIV_CREATE_COMMENTS: 24,
    PRIV_CAN_BE_ASSIGNED_ACTION_CHANGE_STATUS: 25,
    PRIV_CAN_BE_ASSIGNED_ACTION_DISTRIBUTE: 26,
    PRIV_CAN_BE_ASSIGNED_ACTION_INC_COMMENTS: 27,
    PRIV_MANAGE_PROJECT_DISTRIUBTIION_GROUPS: 28,
    PRIV_VIEW_REPORTS: 29,
    PRIV_FORM_PROJECT_PRIV_CREATE: 30,
    PRIV_FORM_PROJECT_PRIV_CONTROL: 31,
    PRIV_CREATE_PARENT_FOLDERS: 32,
    PRIV_FORM_PROJECT_PRIV_VIEW: 33,
    PRIV_CHANGE_STATUS: 34,
    PRIV_FORM_NO_ACCESS: 35,
    PRIV_FORM_VIEW_ALL_PRIVATE_FORMS: 36,
    PRIV_PURPOSEOF_DOC_ISSUE: 37,
    PRIV_MANAGE_ORGANIZATION_PLACEHOLDERS: 38,
    PRIV_MANAGE_PROJECT_PLACEHOLDERS: 39,
    PRIV_CAN_CLEAR_ACTIONS_ORG: 40,
    PRIV_CAN_CLEAR_ACTIONS_PROJECT: 41,
    PRIV_CAN_CLEAR_ACTIONS_OWN: 42,
    PRIV_CAN_DELEGATE_ACTIONS_ORG: 43,
    PRIV_CAN_DELEGATE_ACTIONS_PROJECT: 44,
    PRIV_CAN_DELEGATE_ACTIONS_OWN: 45,
    PRIV_CAN_CLEAR_COMMENTS: 46,
    PRIV_ACCESS_DEACTIVATED_DOCUMENTS: 47,
    PRIV_MANAGE_PROJECT_PAPER_DOCUMENTS: 48,
    PRIV_CAN_DEACTIVATE_USERS_FROM_PROJECT: 49,
    PRIV_CAN_ASSIGN_PROXY_USERS: 50,
    VALUE_ALLOW_CUSTOM_DISTRIBUTION_ALL_ORG: 51,
    PRIV_MANAGE_SPACES: 52,
    PRIV_MANAGE_USER_SUBSCRIPTIONS: 58,
    PRIV_MANAGE_PROJECTS_ALL_ORGS: 59,
    PRIV_MANAGE_PROJECT_MAILBOX: 60,
    PRIV_EDIT_PROJECT_DETAILS: 61,
    VALUE_ALLOW_CUSTOM_DISTRIBUTION_OWN_ORG: 62,
    PRIV_CAN_CREATE_FLAT_FEE_BASED_PROJECTS: 63,
    PRIV_CAN_CREATE_SUBSCRIPTION_PROJECTS: 64,
    PRIV_CAN_CONFIGURE_DOCUMENT_NAMING: 67,
    PRIV_CAN_ACESS_AUDIT_INFO: 69,
    PRIV_CAN_CREATE_COMMENT: 70,
    PRIV_ASSIGN_ROLE_MEMBERSHIP_ALL_ORG: 71,
    PRIV_ASSIGN_ROLE_MEMBERSHIP_OWN_ORG: 72,
    PRIV_CAN_SAVE_WORKSPACE_AS_TEMPLATE: 73,
    PRIV_CAN_MANAGE_FORM_STATUSES: 74,
    PRIV_FORM_VIEW_PRIVATE_OWN_ORG: 75,
    PRIV_CAN_MANAGE_USER_PREFERENCES: 76,
    PRIV_CAN_DEACTIVATE_OWN_FORMS: 77,
    PRIV_CAN_DEACTIVATE_ALL_FORMS: 78,
    PRIV_FORM_VIEW_DRAFT_OWN_ORG: 79,
    PRIV_FORM_VIEW_DRAFT_ALL_ORG: 80,
    PRIV_CAN_DOWNLOAD_DOCUMENTS: 81,
    PRIV_CAN_PRINT_DOCUMENTS: 82,
    PRIV_CAN_ACCESS_WORKSPACE_WITHOUT_SUBSCRIPTION: 83,
    PRIV_CAN_ACCESS_WORKSPACE_CALENDAR: 84,
    CAN_ACCESS_DISTRIBUTION_MODULE: 85,
    CAN_ACCESS_DESIGN_WORKFLOW: 86,
    CAN_ACCESS_PREQUALIFICATION_MODULE: 87,
    CAN_ACCESS_BIDDING_MODULE: 88,
    CAN_ACCESS_CONSTRUCTION_MODULE: 89,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PWF: 90,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PWS: 91,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_EWS: 92,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_SWS: 93,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_TWS: 94,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PMW: 95,
    PRIV_CAN_ACCESS_NAVIGATOR: 96,
    PRIV_MANAGE_APPS: 97,
    PRIV_MANAGE_APP_SETTINGS: 98,
    CAN_BATCH_CHANGE_STATUS_OF_OWN_FORM: 99,
    CAN_REOPEN_CLOSED_FORM: 100,
    CAN_ASSIGN_TO_WORKSPACE_WITHOUT_ACCEPTANCE: 101,
    CAN_AMEND_ALL_FOLDER_PERMISSIONS: 102,
    CAN_SHARE_SEARCH_VIEWS: 109,
    CAN_MANAGE_PROJECTS_MODELS: 110,
    CAN_BATCH_CHANGE_STATUS_OF_ALL_FORMS: 111,
    PRIV_CAN_MANAGE_PROJECTS_MODELS_VIEWS: 112,
    PRIV_CAN_CREATE_ADHOC_REPORT: 113,
    PRIV_MANAGE_WORKFLOW_RULES: 114,
    CAN_DEACTIVATE_FORM_ACTIONS_OWN_ORG: 115,
    CAN_DEACTIVATE_FORM_ACTIONS_ALL_ORG: 116,
    CAN_REACTIVATE_FORM_ACTIONS_OWN_ORG: 117,
    CAN_REACTIVATE_FORM_ACTIONS_ALL_ORG: 118,
    CAN_DEACTIVATE_DOCUMENT_ACTIONS_OWN_ORG: 119,
    CAN_DEACTIVATE_DOCUMENT_ACTIONS_ALL_ORG: 120,
    CAN_REACTIVATE_DOCUMENT_ACTIONS_OWN_ORG: 121,
    CAN_REACTIVATE_DOCUMENT_ACTIONS_ALL_ORG: 122,
    CAN_CREATE_USER_AND_ORGS: 123,
    PRIV_CAN_MANAGE_OBJECT_LISTS: 124,
    PRIV_CAN_MANAGE_CONFIGURABLE_ATTRIBUTES: 125,
    PRIV_CAN_MOVE_DOC: 126,
    CAN_CREATE_eINVOICE: 127,
    MANAGE_PUNCHOUT_CATALOGUE_RESTRICTION: 128,
    CAN_CREATE_PRIVATE_COMMENTS: 129,
    CAN_REOPEN_ALL_CLOSED_FORMS_ADMIN: 130,
    CAN_CONTROLL_LAYOUT_ALL_ORG: 131,
    PRIV_WORKSPACE_NO_ACCESS: 0,
    PRIV_WORKSPACE_ADMIN: 1023,
    CAN_MANAGE_PROJECTS_FIELD: 135,
    CAN_CREATE_NEW_USERS_AND_ORG_ALL_ORG: 136,
    SAVE_SORT_DETAILS_FOR_USER: 335,
    DOCUMENT_ASSOCIATED_COMMS_ACTION: 121,
    VIEW_MODEL_DISCUSSIONS: 152,
    UPLOAD_FILE_VALIDATION_NEW: 802,
    GET_PROJECT_LIST_POPUP: 1001,
    SAVE_USER_SEL_PROJECTS: 810,
    CAN_VIEW_HISTORIC_MARKUPS:163,
    MARK_REVIEW_PRIVATE:172,
    CAN_MANAGE_REVIEW_FLAGS: 173,
    CAN_CREATE_ISSUE: 166,
    CAN_CREATE_ISSUE_COMMENT: 167,
    CAN_CREATE_FILES_FROM_DOCUMENT_TEMPLATES: 179,

    // other common
    PRINT_OPTIONS_VALUE_ALL: 63,
    CALLER_APP: 10,
    OBJECT_TYPE_FILTER: 102,

    // Custom Object constants
    customObject: {
        DOCUMENT_CONTEXT_ID: 1,
        APP_CONTEXT_ID: 2,
        MODEL_CONTEXT_ID: 3,
        MODEL_VIEW_CLASS_NAME: 'modelView',
        DISTRIBUTION_CLASS_NAME: 'distribution',
        COMMENT_CLASS_NAME: 'comment'
    },

    //Folder permissions
    folderPermission: {
        VIEW_ONLY: 23,
        FOLDER_ADMIN_PERMISSION: 1023,
        FOLDER_PUBLISH_AND_LINK_PERMISSION: 239,
        FOLDER_PUBLISH_PERMISSION: 111
    },

    // app action id map
    appActionMap: {
        READ: 0,
        FOR_RESPOND: 3,
        FOR_DISTRIBUTION: 6,
        FOR_INFORMATION: 7,
        FOR_ACKNOWLEDGEMENT: 37,
        FOR_STATUS_CHANGE: 14,
        FOR_REVIEW_DRAFT: 34,
        FOR_ACTION: 36,
        FOR_ASSIGN_STATUS: 2,
        FOR_ATTACHED_DOC: 5,
        RELEASE_RESPONSE: 4
    },

    // document action id map
    docActionMap: {
        FOR_ACKNOWLEDGEMENT: 8,
        FOR_COMMENT: 9,
        FOR_COMMENT_COORDINATION: 10,
        FOR_COMMENT_INCORP: 11,
        FOR_DISTRIBUTION: 12,
        FOR_STATUS_CHANGE: 14,
        FOR_ACTION: 35,
        FOR_INFORMATION: 13,
        FOR_PUBLISHING: 28
    },

	SHARE_OBJECT_TYPE_ID: {
		WORKSPACE: 1,
		FOLDER: 2,
		FILE: 3
	},

	SHARE_PERMISSION: {
		NONE: 0,
		OWNER: 1,
		EDITOR: 2,
		VIEWER: 3
	},
    
    ADRIVE_FILE_PERMISSION: {
        VIEW_FILE: 5,
        CREATE_COMMENT: 11,
        DOWNLOAD_FILE: 4
    },

    // used mostly for create form area
    from: {
        MODEL_NEW_FORM: 4,
        VIEW_FORM: 3,
        ASSOC_FILE_FILETAB: 5,
        ASSOC_FILE_FILEVIEWER: 6,
        ASSOC_DISCUSSION_DISCUSSIONTAB: 7,
        ASSOC_DISCUSSION_FILEVIEWER: 8,
        ASSOC_APP_APPTAB: 9,
        ASSOC_APP_FORMVIEWER: 10,
        FILE_TAB_TREE: 11,
        CALL_OFF_FORM: 12,
        CREATE_NEW_BTN_APP_TAB: 13,
        ASSOC_FILE_DASHBOARD_TAB: 14,
        ASSOC_FILE_SEARCH_TAB: 15,
        ASSOC_APP_DASHBOARD_TAB: 16,
        ASSOC_APP_SEARCH_TAB: 17,
        ASSOC_DISCUSSION_DASHBOARD_TAB: 18,
        ASSOC_DISCUSSION_SEARCH_TAB: 19,
        CREATE_NEW_FORM_DASHBOARD_TAB: 20,
        CREATE_NEW_FORM_SEARCH_TAB: 21,
        FORM_VIEWER: 22,
        ASSOC_ALL_FORM_VIEWER: 23,
        EDIT_REPORT_TAB: 24,
        OPEN_ANY_DRAFT: 25,
        CANCEL_AFTER_AUTO_SAVED: 26,
        EDIT_NEW_ORI_VIEW_FORM: 27,
        DRAFT_DISCARDED: 28,
        EDIT_ORI_FROM_XSN_LINK: 29,
        RESPOND_ACTION_PROJECT_FORM: 30,
        CREATE_FROM_PRINTVIEW: 31,
        CHECK_FORM_CLOSE: 968,
        FEATURE_VISIBILITY: 1903,
    },

    ACTIVITY_CONSTANT: {
        ACTIVITY_REVISION_UPLOAD: 101,
        ACTIVITY_FILE_DISTRIBUTION: 102,
        ACTIVITY_EDIT_ATTRIBUTES: 103,
        ACTIVITY_UPDATE_STATUS: 104,
        ACTIVITY_ADD_COMMENT: 105,
        ACTIVITY_KEY_REVISION_UPLOAD: 1001,
        ACTIVITY_KEY_FILE_DISTRIBUTION: 1002,
        ACTIVITY_KEY_EDIT_ATTRIBUTES: 1003,
        ACTIVITY_KEY_UPDATE_STATUS: 1004,
        ACTIVITY_KEY_ADD_COMMENT: 1005,
    },

    entity: {
        APP: 1,
        FILE: 2,
        DISCUSSION: 4
    },

    appType: {
        CONTACTS: 0,
        COMMUNICATION: 1,
        FIELD: 2,
        CONTRACTS: 3,
        PROCUREMENT: 11,
        EXCHANGE: 4,
        FM: 5,
        FINANCE: 6,
        PPM: 7,
        HR: 8,
        H_AND_S: 9,
        PPMT: 10,
        FILES: 1,
        DISCUSSIONS: 0,
        TRANSMITTALS: 1,
        MARKETPLACE: 12,
        SUSTAINABILITY: 21
    },

    COMMENT_TYPE: {
        NORMAL: 1,
        NOCOMMENT: 2,
        REPLY: 4
    },

    USER_VIEWER_PREFERENCE: {
        HTML_VIEWER: 5,
        ACTIVEX_VIEWER: 6,
        PDFTRON_VIEWER: 7
    },

    UPLOAD_TYPE: {
        FILE: 1,
        ATTACHMENT: 2,
        COMMENT: 5,
        FORM: 4,
        INLINE_FORM: 6,
        MODEL_ATTACHMENT:11
    },

    FILESATTRIBUTES_EXCEPTIONCODE: {
        CODE_LINKED_FILE: 2019,
        CODE_DEACTIVATED_FILE: 2020,
        CODE_FILE_CHECKED_OUT: 2021,
        CODE_VALID_EXISTING_FILES: 2022,
        CODE_EXTENSION_LESS_FILENAME: 2023,
        CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION: 2013,
        CODE_DOCREF_ASSOC_WITH_DIFF_MODEL: 2033,
        CODE_REVISION_UPLOAD_ACTIVITY_LOCK: 1001
    },

    VALIDATION_TYPE: {
        VALIDATION_ON_ENTER_DOC_DETAILS: 1
    },

    initComponentMapObj: {
        "Apps": "app",
        "History": "history",
        "reply": "discussions",
        "discussions": "discussions",
        "createCommet": "create-comment",
        "coordination": "comment-coordination",
        "incorporation": "comment-incorporation",
        "distribution": "file-distribution",
        "publish": "attach-doc",
        "ASSIGN_STATUS": "status-change",
        "ASSOC_ATTACH": "assoc-attach",
        "fileInfo": "file-info"
    },

    attachAssocLabelMap: {
        'FILES': 'Files',
        'DISCUSSIONS': 'Discussions',
        'FORMS': 'Forms',
        'ATTACHMENTS': 'Attachments',
        'VIEWS': 'Views'
    },

    FORM_STATUS: {
        closed: 'Closed'
    },

    DOC_TYPE_ID: {
        'NORMAL': 1,
        'PLACEHOLDER': 2
    },
    //NOODLE-84014 solr data mapping in msg.detail.js global for xsn and html5 form launch mapping - generic for both types of apps - ptahiliani
    SOLR_DATA_MAPPING: {
        'controllerUserId': 'controller_user_id',
        'controllerUserTypeId': 'controller_user_type_id',
        'formCode': 'form_code_name',
        'formCreationDate': 'form_creation_date',
        'formId': 'form_id',
        'formNo': 'form_num',
        'formNoInt': 'form_num',
        'formStatusId': 'status_id',
        'formTitle': 'title',
        'formTypeId': 'form_type_id',
        'formTypeName': 'form_type_name',
        'form_status_name': 'status_name',
        'formcode_num': 'form_code',
        'hasAttachment': 'has_attachment',
        'msgCreationDate': 'msg_creation_date',
        'msgId': 'msg_id',
        'msgNo': 'msg_num',
        'msgStatusId': 'msg_status_id',
        'msgTypeId': 'msg_type_id',
        'msg_ori_user_name': 'originator_name',
        'originatorProxyUserId': 'originator_proxy_user_id',
        'originatorUserId': 'originator_user_id',
        'projectId': 'project_id',
        'status_name': 'status_name',
        'userRef': 'user_ref',
        'msgContent1': 'msg_content1',
        'msgContent2': 'msg_content2',
        'msgContent': 'msg_content',
        'msgContent3': 'msg_content3'
    },

    DISTRIBUTION_LEVEL: {
        "ROLES": 1,
        "ORGANISATIONS": 2,
        "USERS": 3,
        "USER_GROUPS": 4,
        "DISTRIBUTION_GROUPS": 5
    },

    PREFIX_DISTRIBUTION_LEVEL: {
        "1": "(R)",
        "2": "(O)",
        "3": "(U)",
        "4": "(UG)",
        "5": "(D)"
    },

    PDFTRON_SUPPORTED_EXTENSION: "DGN,DWF,DWG,DXF,PDF,XPS,XOD,HTM,HTML,XHTML,SVG,TXT,BMP,ICO,GIF,JPG,JPEG,PNG,TIF,TIFF,DOC,DOCM,DOCX,DOT,DOTM,DOTX,POT,POTX,PPA,PPS,PPSM,PPSX,PPT,PPTM,PPTX,PUB,XLS,XLSB,XLSM,XLSX,XLT,XLTM,XLTX,RTF",
    THUMBNAIL_SUPPORTED_EXTENSION : "JPG,JPEG,PNG,GIF,TIFF,PDF,BMP",
	OFFLINE_THUMBNAIL_SUPPORTED_EXTENSION : "JPG,JPEG,PNG,GIF,BMP",
    CBIM_PLUGINS:"naviswork|revit"
})

.filter('startFrom', function() {
    return function(input, start) {
        start = +start; //parse to int
        return input.slice(start);
    }
})

/**
 *  Invoke on offlineCreateForm.html and offlineViewForm.html page in offline html5 form.
 *  This filter will provide internationalization.
 */
.filter('offlineLang', function() {
    return function(input) {
        return Language.get(input);
    };
})

/**
 * Based Domain Service
 * This service is use for make dc specific url
 */
.service('manageDataCenter', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', function($window, $timeout, apiConfig, myConfig, lang) {
    var manageDataCenter = this;

    window.manageDataCenterGlobal = manageDataCenter;
    /*
     * Following function is used for initialize manage data center service
     */
    manageDataCenter.init = function() {
        manageDataCenter.manipulateDCJson();
        manageDataCenter.manipulateContentAccelerationJson();
        manageDataCenter.setRegEx();
    };

    /*
     * Following function is used for mapping obj based on dcId and its suffix
     */
    manageDataCenter.manipulateDCJson = function() {
        for (var i = 0; i < myConfig.USER_DC_JSON.length; i++) {
            myConfig.dcMapSuffix[myConfig.USER_DC_JSON[i].id] = myConfig.USER_DC_JSON[i].suffix
        }
    };

    /*
     * Following function is used for mapping obj with Content Acceleration Suffix
     */
    manageDataCenter.manipulateContentAccelerationJson = function() {
        for (var i = 0; i < myConfig.CONTENT_ACCELERATION_JSON.length; i++) {
            myConfig.caMapSuffix[myConfig.CONTENT_ACCELERATION_JSON[i].id] = myConfig.CONTENT_ACCELERATION_JSON[i].suffix
        }
    };

    /*
     * Following function is used for generate regular expression based on USER_DC_JSON & CONTENT_ACCLERATION_JSON
     */
    manageDataCenter.setRegEx = function() {
        var str = "";
        for (var i = 0; i <= Object.keys(myConfig.USER_DC_JSON).length - 1; i++) {
            var dcJsonData = myConfig.USER_DC_JSON[i];
            if (dcJsonData.suffix != "") {
                str += dcJsonData.suffix + "\\.|"
            }
            for (var j = 0; j <= Object.keys(myConfig.CONTENT_ACCELERATION_JSON).length - 1; j++) {
                var accelerationJsonData = myConfig.CONTENT_ACCELERATION_JSON[j];
                if (i == Object.keys(myConfig.USER_DC_JSON).length - 1 && j == Object.keys(myConfig.CONTENT_ACCELERATION_JSON).length - 1) {
                    str += dcJsonData.suffix + accelerationJsonData.suffix + "\\."
                } else {
                    str += dcJsonData.suffix + accelerationJsonData.suffix + "\\.|"
                }
            }
        }
        myConfig.dcRegEx = new RegExp(str, 'i');
    };

    manageDataCenter.domainReplace = function(returnUrl) {
        var dcExtExistedUrls = myConfig.dcExtnExistedList || "";
        var index = returnUrl.indexOf(".");
        var urlBeforeDot = returnUrl.substring(0, index + 1); //get the first part of URL where CDN/DC extension appended. like https://dmsak.
        if (dcExtExistedUrls) {
            var array = dcExtExistedUrls.split(",");
            for (var i = 0; i < array.length; i++) {
                var dcExistInUrl = array[i];
                var n = urlBeforeDot.indexOf(dcExistInUrl);
                if (n > -1) {
                    var urlDcExt = urlBeforeDot.substring(n, urlBeforeDot.length);
                    urlBeforeDot = urlBeforeDot.replace(urlDcExt, dcExistInUrl);
                    break;
                }
            }
        }
        return urlBeforeDot;
    };

    /*
     * Following function is used for return baseUrl/finalPath based on @dcId
     */
    manageDataCenter.getUrl = function(dcId, cdnUrl, nonEdgecast) {
        if (!dcId) {
            return "";
        }
        var dcSuffix = myConfig.dcMapSuffix[dcId];
        var contentAccelerationSuffix = "";
        if (!nonEdgecast && dcId == 1 && myConfig.USER_CDN_TYPE_ID == "1") {
            contentAccelerationSuffix = myConfig.caMapSuffix[dcId];
        }
        var finalPath = cdnUrl || myConfig.baseUrl;
        var splitPath = finalPath.split(".");
        splitPath[0] += ".";
        splitPath[0] = manageDataCenter.domainReplace(splitPath[0]);
        splitPath[0] = splitPath[0].replace(myConfig.dcRegEx, "") + dcSuffix + contentAccelerationSuffix;
        return splitPath.join(".")
    };

    manageDataCenter.init();
}])

/*
 * Download Service
 * This module will manage download functionality like below: 
 * 	-	Fetch ajax call for download setting
		-	pass download setting data to its callback fun
	
	-	Check download for single file or not	 
 */
.service('download', ['$window', '$timeout', 'Notification', 'lang', 'api', 'apiConfig', 'myConfig', '$uibModal', 'manageDataCenter', function($window, $timeout, Notification, lang, api, apiConfig, myConfig, $uibModal, manageDataCenter) {
    var download = this,
        projectIds = [],
        paramRev = {
            revisions: []
        },
        paramDcId = {},
        errorCode = [];

    download.init = function(data, callback) {
        Notification.clearAll();

        if (myConfig.applicationId != 2) {
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');
        }
        if (download.isSingleFile(data)) {
            download.file(data, data.projectId);
            callback && callback();
        } else if (download.hasMultpleProject(data)) {
            download.setProjectIds(data);

            if (data.downloadPref && (data.downloadPref.isIncludeMarkup || data.downloadPref.isEmbedQRCode)) {
                download.zip(data.selectedFiles, data.downloadPref, callback);
            } else {
                download.multipleProj(data, callback);
            }
        } else {
            download.zip(data.selectedFiles, data.downloadPref, callback);
        }
    };

    download.hasMultpleProject = function(data) {
        var projectId = data.selectedFiles[0].projectId;
        for (var i = 0; i < data.selectedFiles.length; i++) {
            if (projectId != data.selectedFiles[i].projectId) {
                return true;
            }
        }

        return false;
    };

    download.setProjectIds = function(data) {
        errorCode = projectIds = paramRev.revisions = [];
        paramDcId = {};

        var prdIds = [],
            revIds = [],
            obj = {};
        for (var i = 0; i < data.selectedFiles.length; i++) {
            obj = {
                dcId: data.selectedFiles[i].dcId,
                isLock: data.selectedFiles[i].isLock,
                revisionId: data.selectedFiles[i].revisionId,
                projectId: data.selectedFiles[i].projectId
            }
            revIds.push(obj);
            if (!paramDcId[data.selectedFiles[i].dcId]) {
                paramDcId[data.selectedFiles[i].dcId] = {
                    revisions: []
                };
            }
            paramDcId[data.selectedFiles[i].dcId].revisions.push(data.selectedFiles[i]);

            prdIds.push(data.selectedFiles[i].projectId);
        }
        paramRev.revisions = revIds;
        projectIds = prdIds;
    };

    download.multipleProj = function(data, callback) {
        data.revisionIds = paramRev;
        download.returnNonAkamaiURL(data, function(resData) {
            var cdnUrl;
            if (resData.isLimitExist) {
                cdnUrl = resData.nonCDNDownloadUrl;
            }
            var counter = 0;
            for (key in paramDcId) {
                paramDcId[key].dcId = key;
                paramDcId[key].cdnUrl = cdnUrl;
                download.checkAvailForDownload(paramDcId[key], function(resData) {
                    if (resData && resData.length) {
                        errorCode.push(resData);
                    }
                    counter++;
                    if (Object.keys(paramDcId).length === counter) {
                        download.startBatchFiles(data, callback);
                        if (data.error && errorCode.length) {
                            data.error(errorCode);
                        }
                    }
                })
            }
        });
    };

    download.checkRevRestriction = function(data, callback) {
        var paramObj ={
            projectId: data.projectId,
            revisionId: data.revisionId,
        }
        if(myConfig.formTypeId && myConfig.formTypeId !=="null" && myConfig.formTypeId.indexOf("$$") != -1)
        {
            paramObj.formTypeId = myConfig.formTypeId;
        }
        var xhr = api.ajax({
            url: apiConfig.IS_DOCUMENT_DOWNLOAD_RESTRICTED,
            _cdnUrl: myConfig.downloadServiceURL,
            data :paramObj
        });

        xhr.then(function(respData) {
            callback && callback(respData);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    }

    download.checkAvailForDownload = function(data, callback) {
        var xhr = api.ajax({
            url: apiConfig.CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT_CONTROLLER,
            data: {
                isMultiProject: true,
                extra: angular.toJson(data)
            },
            _dcId: data.dcId,
            _cdnUrl: data.cdnUrl || myConfig.downloadServiceURL
        });

        xhr.then(function(respData) {
            callback && callback(respData);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    };

    download.startBatchFiles = function(data, callback) {
        var url = apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER,
            projectId = data.projectId,
            selectMultiDCUKProjId = data.selectMultiDCUKProjId;
            isFromMultiDCBatch = data.isFromMultiDCBatch || false;

        var paramsObj = {
            extra: JSON.stringify(paramRev),
            projectIds: "",
            projectID: projectId,
            isFromMultiDCBatch:isFromMultiDCBatch

        };
        if (data.byPassParam) {
            paramsObj.adads = "true";
            paramsObj.hashedToken = data.byPassParam.allowDownloadToken
        }
        var xhr = api.ajax({
            url: url,
            data: paramsObj,
            _cdnUrl: myConfig.downloadServiceURL,
            _dcId: data.dcId
        });

        xhr.then(function(respData) {
            if (respData.validForDownload == false) {
                xhr.errorTitle = lang.get("disabled-enabled-download-button");
                api.showServerErrMsg(xhr);
                callback && callback();
            } else {
                respData.projectId = projectId;
                respData.isMultiDCUKProjId = true;
                respData.selectMultiDCUKProjId = selectMultiDCUKProjId;
                respData.isFromMultiDCBatch = isFromMultiDCBatch;
                if (data.downloadPref && (data.downloadPref.isIncludeMarkup || data.downloadPref.isEmbedQRCode)) {
                    Notification.clearAll();
                    Notification.warning({
                        message: '<div class="text-large">' + lang.get("please-wait-files-processd-while") + '</div>',
                        delay: false
                    });
                    download.downloadIncludeMarkups(data, undefined, callback);
                } else {
                    download.createZipFile(respData, callback);
                }
            }
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
            callback && callback();
        });
    };

    download.hasAnySettingApplied = function(data) {
        var pref = data;
        return pref.isParentDoc || pref.isIncludeMarkup || pref.isEmbedQRCode || pref.hasCommentAttachedDocs || pref.hasCommentAssocDocs || pref.isAssocFiles;
    };

    download.isSingleFile = function(data) {
        var flag = false,
            pref = data.downloadPref,
            selectedPref = this.isMultiPrefSelected(pref);

        if (data.selectedFiles.length === 1 && !pref.isIncludeMarkup && !pref.isEmbedQRCode && !pref.hasCommentAssocDocs && !pref.hasCommentAttachedDocs && !pref.isAssocFiles && !pref.isXREF) {
            flag = true;
        } else if (selectedPref === 1) {
            flag = true;

            if (pref.hasCommentAttachedDocs && pref.commentAttachedDocsCount > 1) {
                flag = false;
            }

            if (pref.hasCommentAssocDocs && pref.commentAssocDocsCount > 1) {
                flag = false;
            }

            if (pref.isAssocFiles && this.anyFileHasAttachment(data)) {
                flag = false;
            }

            if (pref.isIncludeMarkup && (pref.markUpDocsCount > 1 || (pref.markUpDocsCount === 1 && data.selectedFiles.length > 1))) {
                flag = false;
            }

            if (pref.isParentDoc && data.selectedFiles.length > 1) {
                flag = false;
            }
        }

        (pref.isIncludeMarkup || pref.isEmbedQRCode) && (flag = false);
        return flag;
    };

    download.anyFileHasAttachment = function(data) {
        var count = 0;

        for (var i = 0; i < data.selectedFiles.length; i++) {
            var fileObj = data.selectedFiles[i];
            if (fileObj.hasAttachment) {
                count += 1;
            }
        }

        return (count > 1);
    };

    download.isMultiPrefSelected = function(downloadPref) {
        var checkLength = 0;

        var array = [downloadPref.isParentDoc, downloadPref.isAssocFiles, downloadPref.isXREF,
            downloadPref.hasCommentAssocDocs, downloadPref.hasCommentAttachedDocs, downloadPref.isIncludeMarkup, downloadPref.isEmbedQRCode
        ];

        for (var i = 0; i < array.length; i++) {
            if (array[i]) {
                checkLength++;
            }
        }

        return checkLength;
    };

    download.returnNonAkamaiURL = function(param, callback) {
        if(!myConfig.downloadServiceURL){
            myConfig.downloadServiceURL = window.downloadServiceURL;
        }
        var xhr = api.ajax({
            url: apiConfig.CHECK_DOCUMENT_DOWNLOAD_LIMIT,
            _cdnUrl: myConfig.downloadServiceURL,
            data: {
                userId: myConfig.USP.userID,
                projectId: param.projectId,
                extra: JSON.stringify(param.revisionIds)
            }
        });

        xhr.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    };

    download.fetchPref = function(data, callback) {
        return api.ajax({
            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_PAGE_CONTROLLER,
            _cdnUrl: myConfig.downloadServiceURL,
            data: {
                extra: angular.toJson({ "revisions": data.selectedFiles }),
                isFromAttachment: ((data.currentEntityType === apiConfig.attachAssocLabelMap.ATTACHMENTS) ? "true" : undefined),
                projectID: data.projectId
            }
        });
    };

    download.file = function(file, projectId) {
        if (myConfig.applicationId == 2) {
            qtObject.downloadFile(JSON.stringify(file.downloadPref), file.selectedFiles[0].fileName);
            return;
        }

        var dataToSend = {
            projectID: file.projectId,
            isFromXrefRevisionDetails: false,
            extra: JSON.stringify(file.downloadPref)
        };

        if (file.selectedFiles[0].curFormByPassSetting && file.selectedFiles[0].curFormByPassSetting.viewAlwaysDocAssociation) {
            dataToSend.adads = true;
            dataToSend.hashedToken = file.selectedFiles[0].curFormByPassSetting.allowDownloadToken;
        }

        api.submitForm({
            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
            _cdnUrl: myConfig.downloadServiceURL,
            param: dataToSend,
            target: '_self'
        });
    };

    download.saveAsPdf = function(file){

        Notification.clearAll();

        if (myConfig.applicationId != 2) {
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');
        }
        
        var selectedFiles = [{
            fileName: file.fileName,
            revisionId: file.revisionId,
            isLock: file.isLock ? "true" : "",
            dcId: file.dcId,
            projectId: file.projectId,
            folderId: file.folderId,
            docId: file.documentId
        }];

        download.returnNonAkamaiURL({
            projectId: file.projectId,
            revisionIds: {
                revisions: selectedFiles
            }
        }, function(data) {
            var url = "";

            // Compute base url
            if (data.isLimitExist) {
                url = data.nonCDNDownloadUrl;
            } else {
                url = myConfig.downloadServiceURL;
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }

            var downloadPref = {
                isIncludeMarkup: true,
                isParentDoc: false,
                isXREF: false,
                isRenameWithDocRef: false,
                isAppenedRevNo: false,
                isAppendDocTitle: false,
                isAppenedIssNo: false,
                fromSaveAsPDF: true,
                revIds: [file.revisionId.split('$$')[0]]
            };

            /** also saveAsPDF from UWV project. */
            if(file.projectViewerId && file.projectViewerId == 7){
                downloadPref["projectViewerId"] = file.projectViewerId;
                downloadPref["comingFrom"] = 'saveAsPDF';
            }
           
            var dataToSend = {
                extra: JSON.stringify(downloadPref),
                userID: myConfig.USP.userID,
                saveAsPDF: true,
                projectID: file.projectId
            };

            api.submitForm({
                url: url + apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
                param: dataToSend,
                target: '_self'
            });
        });
    };
    download.zip = function(selectedItems, downloadPref, callback) {

        download.returnNonAkamaiURL({
            projectId: selectedItems[0].projectId,
            revisionIds: {
                'revisions': selectedItems
            }
        }, function(data) {
            var url = "";
            downloadPref = downloadPref || {};
            if (data.isLimitExist || downloadPref.isIncludeMarkup === true || downloadPref.isIncludeMarkup === "true" || downloadPref.isEmbedQRCode === true || downloadPref.isEmbedQRCode === "true") {
                url = data.nonCDNDownloadUrl;
            } else {
                url = myConfig.downloadServiceURL;
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }

            var paramsObj = {
                extra: JSON.stringify(downloadPref),
                projectID: selectedItems[0].projectId
            };

            var xhr = api.ajax({
                url: url + apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
                data: paramsObj
            });

            xhr.then(function(data) {
                if (!data) {
                    callback && callback();
                    return;
                }

                data.projectId = selectedItems[0].projectId;
                if (downloadPref && (downloadPref.isIncludeMarkup || downloadPref.isEmbedQRCode)) {
                    Notification.clearAll();
                    Notification.warning({
                        message: '<div class="text-large">' + lang.get("please-wait-files-processd-while") + '</div>',
                        delay: false
                    });
                    data.url = url + apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
                    download.downloadIncludeMarkups(data, undefined, callback, downloadPref.isEmbedQRCode);
                } else {
                    Notification.clearAll();
                    data.url = url + apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
                    download.createZipFile(data, callback);
                }
            }, function(xhr) {
                $window.alert(lang.get("something-went-wrong"));
                callback && callback();
            });
        });
    };
    download.getErrorMessage = function(errorFilesList) {
        var errorMessage = "";
        switch (errorFilesList.errorCode) {
            case 1:
                errorMessage = lang.get('system-task-not-configured');
                break;
            case 2:
                errorMessage = lang.get('folder-setting-enableqrcode-not-enabled');
                break;
            case 3:
                errorMessage = lang.get('file-format-not-supported-qrcode');
                break;
            case 4:
                errorMessage = lang.get('embedding-qrcode-file-try-support');
                break;
            default:
                errorMessage = "";
        }
        return errorMessage;
    };

    download.downloadIncludeMarkups = function(markUpData, data, callback, isEmbedQRCode) {
        var markupGenerated = "generated";
        var markupQRCode = "failed";
        var markupIncludeMarkup = "failed";
        var markupInvoke = data ? data.markupsProgress : "";
        var errorFilesList = data ? data.errorFiles : [];
        var c_number = data ? data.c_number : 0;
        if (markupInvoke == markupGenerated) {
            Notification.clearAll();
            if (isEmbedQRCode && errorFilesList && errorFilesList.length && c_number != 1) {
                var childController = function($scope, $uibModalInstance, errorFilesList) {
                    for (var i = 0; i < errorFilesList.length; i++) {
                        errorFilesList[i].errorCodeMessage = download.getErrorMessage(errorFilesList[i]);
                    }                    
                    $scope.errorFile = errorFilesList;
                    $scope.isContinueDownload = false;
                    $scope.allFilesFail = true;
                    $scope.continueDownload = function() {
                        $uibModalInstance.close({ my: 'data' });
                        var xhr = api.ajax({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            data: {
                                projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                                markUpsProgressKey: markUpData.publishMarkupsProgressKey
                            }
                        });
                        xhr.then(function(data) {
                            data.projectId = markUpData.projectId;
                            data.url = markUpData.url;
                            download.createZipFile(data, callback);
                        });
                    }
                    $scope.cancel = function() {
                        $uibModalInstance.dismiss();
                        callback && callback();
                    }
                }
                $uibModal.open({
                    animation: true,
                    templateUrl: 'myModalContent.html',
                    controller: childController,
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        errorFilesList: function() {
                            return errorFilesList;
                        }
                    }
                });

            } else {
                var dataJSON = {
                    action_id: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION,
                    projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                    markUpsProgressKey: markUpData.publishMarkupsProgressKey
                }
                if(errorFilesList && errorFilesList.length){                    
                    var childController = function($scope, $uibModalInstance, errorFilesList) {
                        for (var i = 0; i < errorFilesList.length; i++) {
                            var documentTypeId = errorFilesList[i].documentTypeId;
                            var type = documentTypeId == 12 ? lang.get('type-markup') : lang.get('type-parent');
                            errorFilesList[i].docType = type;
                        }                                            
                        $scope.errorFile = errorFilesList;
                        $scope.isContinueDownload = false;
                        $scope.allFilesFail = true;
                        $scope.continueDownload = function() {
                            $uibModalInstance.close({ my: 'data' });                            
                            if (c_number == 1 ) {
                                api.submitForm({
                                    url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                                    _cdnUrl: myConfig.downloadServiceURL,
                                    param: dataJSON,
                                    target: '_self'
                                });
                                callback && callback();
                            } else {
                                var xhr = api.ajax({
                                    url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                                    _cdnUrl: myConfig.downloadServiceURL,
                                    data: dataJSON
                                });
                                xhr.then(function(data) {
                                    data.projectId = markUpData.projectId;
                                    data.url = markUpData.url;
                                    download.createZipFile(data, callback);
                                });
                            }
                        }
                        $scope.cancel = function() {
                            $uibModalInstance.dismiss();
                            callback && callback();
                        }
                    }
                    $uibModal.open({
                        animation: true,
                        templateUrl: 'includeMarkupError.html',
                        controller: childController,
                        backdrop: 'static',
                        keyboard: false,
                        resolve: {
                            errorFilesList: function() {
                                return errorFilesList;
                            }
                        }
                    });
                } else {
                    if (c_number == 1 ) {
                        api.submitForm({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            param: dataJSON,
                            target: '_self'
                        });
                        callback && callback();
                    } else {
                        var xhr = api.ajax({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            data: dataJSON
                        });
                        xhr.then(function(data) {
                            data.projectId = markUpData.projectId;
                            data.url = markUpData.url;
                            download.createZipFile(data, callback);
                        });
                    }
                }
               
            }

        } else if (isEmbedQRCode && markupInvoke == markupQRCode) {
            Notification.clearAll();
            var childFailController = function($scope, $uibModalInstance, errorFilesList) {
                for (var i = 0; i < errorFilesList.length; i++) {
                    errorFilesList[i].errorCodeMessage = download.getErrorMessage(errorFilesList[i]);
                }
                $scope.errorFile = errorFilesList;
                $scope.isContinueDownload = true;
                $scope.allFilesFail = false;
                $scope.ok = function() {
                    $uibModalInstance.dismiss();
                    callback && callback();
                }
            }

            $uibModal.open({
                animation: true,
                templateUrl: 'myModalContent.html',
                controller: childFailController,
                backdrop: 'static',
                resolve: {
                    errorFilesList: function() {
                        return errorFilesList;
                    }
                }
            });
            callback && callback();
            return;
        } else {
            $timeout(function() {
                if(markupInvoke && markupInvoke.toLowerCase() == markupIncludeMarkup){
                    Notification.clearAll();
                    var childFailController = function($scope, $uibModalInstance) {                        
                        $scope.isContinueDownload = true;
                        $scope.allFilesFail = false;
                        $scope.ok = function() {
                            $uibModalInstance.dismiss();
                            callback && callback();
                        }
                    }        
                    $uibModal.open({
                        animation: true,
                        templateUrl: 'includeMarkupError.html',
                        controller: childFailController,
                        backdrop: 'static'
                    });
                    callback && callback();
                    return;
                } else {
                    var xhr = api.ajax({
                        url: apiConfig.PROGRESS_GENERATE_MARKUP_AS_PDF_CONTROLLER,
                        method: 'GET',
                        _cdnUrl: myConfig.downloadServiceURL,
                        params: {
                            projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                            markUpsProgressKey: markUpData.publishMarkupsProgressKey
                        }
                    });
                    xhr.then(function(data) {
                        $timeout(function() {
                            download.downloadIncludeMarkups(markUpData, { "markupsProgress": data.markupsProgress.toLowerCase(), "errorFiles": data.errorFiles, "c_number": data.c_number }, callback, isEmbedQRCode);
                        },3000);
                    });
                }                
            }, 500);
        }
    };
    var zipProgress = {};
    download.createZipFile = function(zipData, callback) {
        if (!zipProgress[zipData.fileName]) {
            zipProgress[zipData.fileName] = {};
            Notification.clearAll();
            // progreess bar made here with the same div used while viewing file and form.
            Notification({
                message: '<div id="notification-progress" class="page-progress" style="position:relative"><div class="progress"></div></div>',
                delay: false
            });
        }

        var paramObj = {
            action_id: apiConfig.PROGRESS_ZIP_CREATION,
            zipFile: zipData.fileName
        }

        !zipData.isMultiDCUKProjId && (paramObj.projectID = zipData.projectId);

        var apiOptions = {
            url: zipData.url || apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER,
            method: 'GET',
            _cdnUrl: myConfig.downloadServiceURL,
            params: paramObj
        };
        if(zipData.url && zipData.url.indexOf(apiConfig.PUBLIC_DOWNLOAD_CONTROLLER) === 0) {
            apiOptions = {
                url: zipData.url,
                data: paramObj
            };
        }
        var xhr = api.ajax(apiOptions);

        zipProgress[zipData.fileName].xhr = xhr;
        if (zipProgress[zipData.fileName].c_number === undefined) {
            zipProgress[zipData.fileName].progress = 0;
            zipProgress[zipData.fileName].c_number = 0;
        }

        xhr.then(function(data) {
            if (data.c_number == '-1') {
                var param = {
                    c_number: data.c_number,
                    project_id: zipData.isMultiDCUKProjId ? zipData.selectMultiDCUKProjId : zipData.projectId,
                    count: zipData.count,
                    destPath: zipData.destPath,
                    fileName: zipData.fileName,
                    isExtract: data.isExtract,
                    isForDirectLink: zipData.isFromDirectLink,
                    sourcePath: zipData.sourcePath,
                    isFromMultiDCBatch: zipData.isFromMultiDCBatch || false
                };

                Notification.clearAll();

                if (myConfig.applicationId == 2) {
                    param.action_id = apiConfig.DOWNLOAD_TEMP_ZIP_FILE;
                    qtObject.sameDcMultiFilesDownload(JSON.stringify(param), "");
                    callback && callback();
                    delete zipProgress[zipData.fileName];
                    return;
                }

                callback && callback();
                delete zipProgress[zipData.fileName];
                api.submitForm({
                    url: zipData.actionUrl || apiConfig.DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER,
                    param: param,
                    _cdnUrl: myConfig.downloadServiceURL,
                    target: '_self'
                });
            } else {
                zipProgress[zipData.fileName].c_number = data.c_number;
                if (data.c_number > 0) {
                    zipProgress[zipData.fileName].progress = data.c_number;
                }
                zipProgress[zipData.fileName].timeout = $timeout(function() {
                    download.createZipFile(zipData, callback);
                }, 2000);
            }
        }, function(xhr) {
            Notification.clearAll();
            if (xhr.status != -1) {
                zipProgress[zipData.fileName].status = lang.get("failed");
                $window.alert(lang.get("download-failed"));
                callback && callback();
            } else {
                zipProgress[zipData.fileName].xhr = false;
                zipProgress[zipData.fileName].status = lang.get("aborted");
            }
        });
    };

    download.cancelZipProgress = function(fileName) {
        // abort request
        var xhr = zipProgress[fileName].xhr;
        xhr && xhr.abort();

        // cancel timeout
        $timeout.cancel(zipProgress[fileName].timeout);
    };
}])


/**
 * api service.
 * This module will provide XMLHttpRequest service.
 * @module api
 */
.service('api', ['$http', '$window', '$q', '$timeout', 'lang', 'myConfig', 'apiConfig', 'Notification', 'manageDataCenter', '$uibModal', function($http, $window, $q, $timeout, lang, myConfig, apiConfig, Notification, manageDataCenter, $uibModal) {
    /**
     * For all the http calls.
     * @alias module:Api/Ajax
     */

    var api = this;

    api.linkify = function(msg) {
        if (!msg) return "";

        var replacedText = msg,
          replacePattern1,
          replacePattern2,
          replacePattern3;

        //Change email addresses to mailto:: links.
        replacePattern3 = /(([a-zA-Z0-9\-\_\.])+@[a-zA-Z\_]+?(\.[a-zA-Z]{2,6})+)/gim;
        replacedText = replacedText.replace(
          replacePattern3,
          '<a href="mailto:$1">$1</a>'
        );

        //URLs starting with http://, https://, or ftp://
        replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#$\/%?=~_|!:,.;]*[-A-Z0-9+&@#$\/%=~_|$])/gim;
        replacedText = replacedText.replace(
          replacePattern1,
          '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
    
        //URLs starting with "www." (without // before it, or it'd re-link the ones done above).
        replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
        replacedText = replacedText.replace(
          replacePattern2,
          '$1<a href="http://$2" target="_blank" rel="noopener noreferrer">$2</a>'
        );

        return replacedText;
    };

    api.isIE = function() {
        return ((navigator.userAgent.indexOf(".NET CLR") > -1) || (navigator.userAgent.indexOf("MSIE") > -1) ||
            !!navigator.userAgent.match(/Trident\//) || !!navigator.userAgent.match(/Edge\//));
    };

    api.isIE9 = function() {
        return (navigator.userAgent.indexOf('MSIE 9') > -1 || !$window.FormData);
    };

    api.escapeAmp = function(str) {
        if (!str || typeof str !== 'string') {
            return "";
        }
        return str.replace(/&/g, '&amp;');
    };

    api.isMobile = function() {
        var check = false;
        (function(a) {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
                check = true;
        })(navigator.userAgent || navigator.vendor || window.opera);
        if (myConfig.applicationId == 3 && navigator.platform == 'MacIntel') {
            check = true;
        }
        return check;
    };

    api.isNavigator = function() {
        return (myConfig.applicationId == 2);
    };

    api.openHelpPage = function(opt) {
        var isCustomTextApplied = window['INIT_JSP_GLOBAL']['isCustomTextApplied']
        var editionId = window['INIT_JSP_GLOBAL']['editionId']

        var strUrl = (opt.rootPath || "") + (opt.contentfolder || apiConfig.HELP_FILE_CONTENT) + myConfig.userLanguage + (isCustomTextApplied ? "_" + editionId : "") + "/" + opt.name + ".htm";
        var $helpContent = $('#help-content');
        $helpContent.load(strUrl, function() {
            $helpContent.removeClass("close").addClass("open");
            $helpContent.find('.elearning-url').attr('href', apiConfig.VIEW_ELEARNING);
        });
    };

    api.sendEventToIpad = function(strEvent) {
        var iframe = document.createElement("IFRAME");
        iframe.setAttribute("src", "js-frame:" + strEvent);
        document.documentElement.appendChild(iframe);
        iframe.parentNode.removeChild(iframe);
        iframe = null;
    };

    api.setScrollTopPos = function(elem, posVal) {
        elem.scrollTop = posVal;
    };

    api.sendMail = function(content) {
        if (api.isIE()) {
            var iframe = angular.element('<iframe id="iframeTempMailTo" src="' + content + '" width="0" height="0" >');
            angular.element("body").append(iframe);
            iframe.remove();
        } else {
            $window.location.href = content;
        }
    };

    api.getUrlByDcId = function(dcId) {
        return manageDataCenter.getUrl(dcId || apiConfig.LOCAL_DC_ID);
    };

    // Store action id wise resolve method.
    var offlineActionWiseResolveList = [];

    api.ajax = function(obj) {

        // Use in offline Html5 form.
        if (myConfig.isOfflineMode) {
            // use  js-frame in the offline html5Form.
            api.sendEventToIpad(angular.toJson(obj));

            var actionID = obj.data.action_id;

            // Unique action id pass.
            //Same actionid(1722) pass in files,discussions and apps column listing;
            if (actionID == apiConfig.GET_USER_SELECTED_COLUMNS) {
                //Pass id with type
                actionID = actionID + "_" + obj.data.type;
            } else if (actionID == apiConfig.GET_ATTACHMENT_AND_ASSOCIATIONS) {
                //Pass actionID with requestedEntityType(Views/Lists/All)
                actionID = actionID + "_" + obj.data.requestedEntityType;
            } else if(actionID == apiConfig.GET_USER_APPLICATION_PRIVILEGES){
                obj.data.type && (actionID = actionID + "_" +  obj.data.type);
            }
            return new Promise(function(resolve) {
                // Store action id wise resolve method.
                offlineActionWiseResolveList[actionID] = resolve;

                //Invoke on Mobile side callback method.
                window.offlineModeCallback = function(data) {
                    //Set response data
                    var resData = "";
                    var actionId = data.actionId;
                    var actionIds = [apiConfig.INITIATE_CREATE_ORI_MSG, apiConfig.CHECK_EDIT_ORI_DRAFT_MESSAGE, apiConfig.INITIATE_EDIT_FORM_MSG_COMMITED, apiConfig.INITIATE_CREATE_RES_MSG, apiConfig.INITIATE_CREATE_FWD_MSG, apiConfig.SUBMIT_FORM_CHANGE_STATUS, apiConfig.COMPLETE_FOR_ACTION, apiConfig.COMPLETE_FOR_ACKNOWLEDGEMENT_ACTION]; 
                    if (actionIds.indexOf(data.actionId) != -1 ) {
                        resData = data.responseData; //In response URL pass.
                    } else if (data.actionId == apiConfig.GET_USER_SELECTED_COLUMNS) {
                        actionId = data.actionId + "_" + data.type;
                        resData = data;
                    } else if (data.actionId == apiConfig.GET_ATTACHMENT_AND_ASSOCIATIONS) {
                        actionId = data.actionId + "_" + data.requestedEntityType;
                        resData = JSON.parse(data.responseData);
                    }else if (data.actionId == apiConfig.GET_USER_APPLICATION_PRIVILEGES) {
                        data.type && (actionId = data.actionId + "_" + data.type);
                        resData = JSON.parse(data.responseData);
                    } else {
                        resData = JSON.parse(data.responseData);
                    }

                    //Resolve method call
                    offlineActionWiseResolveList[actionId] && offlineActionWiseResolveList[actionId](resData);
                    $timeout(function() {
                        try{
                            $scope.$apply();
                        } catch(e){}                       
                    });
                }
            });
        } else {
            var deferred = $q.defer();

            if(obj.url.indexOf('http') !== 0) {
                if (obj._dcId) {
                    obj.url = manageDataCenter.getUrl(obj._dcId, obj._cdnUrl) + obj.url;
                    delete obj._dcId;
                    delete obj._cdnUrl;
                }

                if (obj._cdnUrl && !obj._dcId) {
                    obj.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, obj._cdnUrl) + obj.url;
                    delete obj._cdnUrl;
                }
            }

            if (obj.method && obj.method.toLowerCase() == 'get') {
                if (obj.url.indexOf('?') == -1) {
                    obj.url += '?t=' + Date.now();
                } else {
                    obj.url += '&t=' + Date.now();
                }
            }

            var defOptions = {
                method: 'POST',
                dataType: 'json',
                cache: false,
                withCredentials: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                transformRequest: function(obj) {
                    if (typeof obj === 'string') {
                        return obj;
                    }

                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));

                    return str.join("&");
                },
                timeout: deferred.promise
            };

            if(obj.responseType === 'text' || obj.dataType === 'text') {
                defOptions.transformResponse = function(data, headersGetter, status) {
                    return "" + data;
                }
            }

            if (obj.ApiKey) {
                defOptions.headers["ApiKey"] = obj.ApiKey;
            }

            if (obj.aSessionID) {
                defOptions.headers["ASessionID"] = obj.aSessionID;
            }
            obj = angular.extend(defOptions, obj);

            var unauthorisedRedirect = function(response) {
                if (!response || !angular.isString(response.data)) {
                    return;
                }
                response = response.data;
                if (response.indexOf('Unauthorised Access') > -1) {
                    angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "unauthorised";
                    return false;
                }
                if (response.indexOf('Session Timed Out') > -1) {
                    api.setSessionState('sessionState', 'Inactive');
                    api.openLoginModal();
                    /* angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "session-timed-out";			 */
                    return false;
                }
                if (response.indexOf('Session Overriden') > -1) {
                    angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "session-overriden";
                    return false;
                }
            };

            var request = $http(obj);

            var promise = request.then(
                function(response) {
                    unauthorisedRedirect(response);
                    if (obj.url.indexOf(apiConfig.GET_SESSION_TIMEOUT_DETAILS) == -1) {
                        api.setsessionTimoutTimer();
                    }
                    return (response.data);
                },
                function(response) {
                    unauthorisedRedirect(response);
                    if (obj.url.indexOf(apiConfig.GET_SESSION_TIMEOUT_DETAILS) == -1) {
                        api.setsessionTimoutTimer();
                    }
                    return ($q.reject(response));
                }
            );

            promise.abort = function() {
                deferred.resolve();
            };

            promise['finally'](function() {
                promise.abort = angular.noop;
                deferred = request = promise = null;
            });

            return promise;
        }




    };

    api.setLocalStorageIframs = function() {
        try {
            if (myConfig.isPagePublic) {
                return;
            }
            angular.element('body').find('.local-storage-iframe').remove();
            var urls = [];
            var userAccessibleDCIds = window['USP'] && window['USP'].userAccessibleDCIds || [];

            for (var i = userAccessibleDCIds.length - 1; i >= 0; i--) {
                urls.push({
                    pathNeeded: true,
                    url: manageDataCenter.getUrl(userAccessibleDCIds[i])
                });
                if (window['adoddleAppEngineURL'] && userAccessibleDCIds[i] != 1) {
                    urls.push({
                        pathNeeded: false,
                        url: manageDataCenter.getUrl(userAccessibleDCIds[i], window['adoddleAppEngineURL'].replace('.com/appbuilder', '.com/localStorage'))
                    });
                } else {
                    urls.push({
                        pathNeeded: false,
                        url: window['adoddleAppEngineURL'].replace('.com/appbuilder', '.com/localStorage')
                    });
                }
            }
            for (var i = 0; i < urls.length; i++) {
                var iframe = document.createElement('iframe');
                iframe.style.display = 'none';
                document.body.appendChild(iframe);
                iframe.classList.add('local-storage-iframe');
                iframe.src = urls[i].url + (urls[i].pathNeeded ? apiConfig.LOCAL_STORAGE : '');
            }
        } catch (e) {}
    }

    api.loadLocalStorageIFrame = function() {
        //This functionality is not supported in offline html5 form.
        if (!myConfig.isOfflineMode) {
            api.setLocalStorageIframs();
        }
    }

    api.setSessionState = function(name, value) {
        try {
            localStorage.setItem(name, value);
            var iframeEls = document.getElementsByClassName('local-storage-iframe');
            if (!iframeEls.length) {
                return;
            }
            for (var i = 0; i < iframeEls.length; i++) {
                iframeEls[i].contentWindow.postMessage(JSON.stringify({
                    name: name,
                    value: value,
                    sessionState: true
                }), '*');
            }
        } catch (e) {
            localStorage.setItem(name, value);
        }
    };

    window['setSessionState'] = function(name, value) {
        api.setSessionState(name, value);
    };

    var timer;
    api.setsessionTimoutTimer = function(duration) {
        if (myConfig.isPagePublic) {
            return;
        }
        var appId = myConfig.applicationId || window.applicationId || 1;
        if (appId != 1) {
            return;
        }
        // Return when SSO login
        if (window['USP'] && window['USP'].loginMethodType === 2) {
            return;
        }
        timer && clearTimeout(timer);
        if (duration && parseFloat(duration) > 0) {
            timer = setTimeout(api.checkSessionTimeout, parseFloat(duration) * 60000);
        } else if (parseFloat(myConfig.USP.sessionTimeoutDuration) > 0) {
            timer = setTimeout(api.checkSessionTimeout, parseFloat(myConfig.USP.sessionTimeoutDuration) * 60000);
        }
    };

    api.checkSessionTimeout = function() {
        api.ajax({
            url: apiConfig.GET_SESSION_TIMEOUT_DETAILS,
            data: {},
            method: 'GET'
        }).then(function(data) {
            api.setSessionState('sessionState', !data.timeout ? 'Active' : 'Inactive');
            if (data.timeout) {
                api.openLoginModal();
            } else {
                api.setsessionTimoutTimer(parseFloat(data.remainingMilliSecond) / 60000);
            }
        }, function(xhr) {
            if (!navigator.onLine) {
                api.setsessionTimoutTimer(parseFloat('10000') / 60000);
            }
        });
    };

    api.setsessionTimoutTimer();

    var loginPopup;
    api.openLoginModal = function() {
        if (loginPopup || window.top != window) {
            return;
        }
        // Return when SSO login
        if (window['USP'] && window['USP'].loginMethodType === 2) {
            return;
        }
        loginPopup = $uibModal.open({
            component: 'login',
            keyboard: false,
            backdrop: 'static',
            windowClass: 'login-modal',
            backdropClass: 'login-backdrop'
        });
        loginPopup.closed.then(function() {
            loginPopup = '';
        });
    };

    var confirmModel;
    api.openConfirmBox = function(options) {
        confirmModel = $uibModal.open({
            template: "<div class='dialog-ovelay'>" +
                "<div class='dialog'><header>" +
                " <h3> {{ $ctrlConfirmModel.options.title}} </h3> " +
                "</header>" +
                "<div class='dialog-msg'>" +
                " <p> {{ $ctrlConfirmModel.options.msg}} </p> " +
                "</div>" +
                "<footer>" +
                "<div class='controls'>" +
                " <button class='btn btn-danger' ng-click='$ctrlConfirmModel.callback()'>" + lang.get('ok') + "</button> " +
                " <button class='btn btn-default' ng-click='$ctrlConfirmModel.closePopup()'>" + lang.get('cancel') + "</button> " +
                "</div>" +
                "</footer>" +
                "</div>" +
                "</div>",
            controllerAs: '$ctrlConfirmModel',
            controller: function () {
                this.options = options;

                this.callback = function() {
                    confirmModel.dismiss('cancel');
                    if(this.options.callback) this.options.callback();
                }

                this.closePopup = function() {
                    confirmModel.dismiss('cancel');
                }
            },
            keyboard: false,
            backdrop: 'static',
        });
        confirmModel.closed.then(function() {
            confirmModel = '';
        });
    }

    window['openLoginModal'] = function() {
        api.openLoginModal();
    };

    api.uniqById = function(collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function(item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };

    api.parseStr = function(s, o, re) {
        var that = this;
        re = re || (/\{\s*([^\|\}]+?)\s*(?:\|([^\}]*))?\s*\}/g);
        return ((s.replace) ? s.replace(re, function(match, key) {
            return (o[key] !== undefined || o[key] !== null) ? o[key] : match;
        }) : s);
    };

    api.getParamObj = function(win) {
        win = win || $window;
        var href = win.location.href;
        var search = href.split('?')[1];
        var obj = {};

        if (!search) {
            return obj;
        }

        var paramArray = search.split('&');
        for (var i = 0; i < paramArray.length; i++) {
            var param = paramArray[i].split('=');
            obj[param[0]] = param[1];
        }

        return obj;
    };

    api.getLastModifiedProfileTime = function(imagepath) {
        if (!imagepath) {
            return '0';
        }
        var lastModiPicDate = imagepath.split('?')[1] || '';
        lastModiPicDate = lastModiPicDate.split('&')[0] || '';
        var lastModiPicDateArray = lastModiPicDate.split('=');
        if (lastModiPicDateArray[0] && lastModiPicDateArray[0] == 'v') {
            lastModiPicDate = lastModiPicDateArray[1] || '';
            lastModiPicDate = lastModiPicDate.split('#')[0] || '';
        } else {
            lastModiPicDate = '0';
        }

        return lastModiPicDate;
    };

    /**
     * language specific days and month names
     */
    api.getCalendarNames = function() {
        return {
            'DAY_NAMES_SHORTEST': lang.get("abbr-sort-day-name-array").split(','), // "Su,Mo,Tu,We,Th,Fr,Sa"
            'DAY_NAMES_SHORT': lang.get("abbr-day-name-array").split(','), // "Sun,Mon,Tue,Wed,Thu,Fri,Sat"
            'DAY_NAMES': lang.get("day-name-array").split(','), // "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday"
            'MONTH_NAMES_SHORT': lang.get("abbr-month-array").split(','), // "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec"
            'MONTH_NAMES': lang.get("month-array").split(',') // "January,February,March,April,May,June,July,August,September,October,November,December"
        };
    };

    /**
     * date utilities
     */
    var _ticksTo1970 = (((1970 - 1) * 365 + Math.floor(1970 / 4) - Math.floor(1970 / 100) + Math.floor(1970 / 400)) * 24 * 60 * 60 * 10000000);
    api.getDuration = function(date) {
        if (!date) {
            return '';
        }

        var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
        var now = new Date();
        var timezoneOffset = 19800000;
        var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        utcDate.setHours(parseInt(todayUTCSplit[0]) + (myConfig.timezoneOffset / (3600 * 1000)), todayUTCSplit[1], todayUTCSplit[2]);

        var dueDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        dueDate.setHours(23, 59, 00, 00);

        var dmili = dueDate.getTime();
        var tmili = utcDate.getTime();
        var diff = dmili - tmili;

        var diff_days = parseInt(diff / (24 * 60 * 60 * 1000)); // in days
        var diff_hours = parseInt(diff / (60 * 60 * 1000)); // in hours

        if (diff_hours > 23)
            return (diff_days + ' d');
        else
            return (diff_hours + ' h');
    };

    // Format a number, with leading zero if necessary
    api.addZero = function(value) {
        var num = "" + value;
        if (num.length < 10) {
            num = "0" + num;
        }
        return num;
    };

    api.formatDate = function(format, date) {
        if (!date) {
            return "";
        }

        var iFormat,
            nameMap = api.getCalendarNames(),
            dayNamesShort = nameMap.DAY_NAMES_SHORT,
            dayNames = nameMap.DAY_NAMES,
            monthNamesShort = nameMap.MONTH_NAMES_SHORT,
            monthNames = nameMap.MONTH_NAMES,

            // Check whether a format character is doubled
            lookAhead = function(match) {
                var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) === match);
                if (matches) {
                    iFormat++;
                }
                return matches;
            },
            formatNumber = function(match, value, len) {
                var num = "" + value;
                if (lookAhead(match)) {
                    while (num.length < len) {
                        num = "0" + num;
                    }
                }
                return num;
            },
            // Format a name, short or long as requested
            formatName = function(match, value, shortNames, longNames) {
                return (lookAhead(match) ? longNames[value] : shortNames[value]);
            },
            output = "",
            literal = false;

        if (date) {
            for (iFormat = 0; iFormat < format.length; iFormat++) {
                if (literal) {
                    if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
                        literal = false;
                    } else {
                        output += format.charAt(iFormat);
                    }
                } else {
                    switch (format.charAt(iFormat)) {
                        case "d":
                            output += formatNumber("d", date.getDate(), 2);
                            break;
                        case "D":
                            output += formatName("D", date.getDay(), dayNamesShort, dayNames);
                            break;
                        case "o":
                            output += formatNumber("o",
                                Math.round((new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000), 3);
                            break;
                        case "m":
                            output += formatNumber("m", date.getMonth() + 1, 2);
                            break;
                        case "M":
                            output += formatName("M", date.getMonth(), monthNamesShort, monthNames);
                            break;
                        case "y":
                            output += (lookAhead("y") ? date.getFullYear() :
                                (date.getYear() % 100 < 10 ? "0" : "") + date.getYear() % 100);
                            break;
                        case "t":
                            output += (date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
                            break;
                        case "p":
                            output += api.getDuration(date);
                            break;
                        case "@":
                            output += date.getTime();
                            break;
                        case "!":
                            output += date.getTime() * 10000 + _ticksTo1970;
                            break;
                        case "'":
                            if (lookAhead("'")) {
                                output += "'";
                            } else {
                                literal = true;
                            }
                            break;
                        default:
                            output += format.charAt(iFormat);
                    }
                }
            }
        }
        return output;
    };

    api.parseDate = function(format, value) {
        if (format == null || value == null) {
            throw lang.get("invalid-arguments");
        }

        value = (typeof value === "object" ? value.toString() : value + "");
        if (value === "") {
            return null;
        }

        var iFormat, dim, extra,
            iValue = 0,
            shortYearCutoff = 26,
            nameMap = api.getCalendarNames(),
            dayNamesShort = nameMap.DAY_NAMES_SHORT,
            dayNames = nameMap.DAY_NAMES,
            monthNamesShort = nameMap.MONTH_NAMES_SHORT,
            monthNames = nameMap.MONTH_NAMES,
            year = -1,
            time = -1,
            month = -1,
            day = -1,
            doy = -1,
            literal = false,
            date,
            // Check whether a format character is doubled
            lookAhead = function(match) {
                var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) === match);
                if (matches) {
                    iFormat++;
                }
                return matches;
            },
            // Extract a number from the string value
            getNumber = function(match) {
                var isDoubled = lookAhead(match),
                    size = (match === "@" ? 14 : (match === "!" ? 20 :
                        (match === "y" && isDoubled ? 4 : (match === "o" ? 3 : 2)))),
                    minSize = (match === "y" ? size : 1),
                    digits = new RegExp("^\\d{" + minSize + "," + size + "}");

                if (match === "t") {
                    num = value.substring(iValue).match(new RegExp("^\\d{1,2}:\\d{1,2}:\\d{1,2}"));
                } else {
                    num = value.substring(iValue).match(new RegExp("^\\d{" + minSize + "," + size + "}"));
                }
                if (!num) {
                    throw lang.get("missing-number-at-position") + iValue;
                }

                iValue += num[0].length;
                if (match === "t") {
                    return num[0];
                }

                return parseInt(num[0], 10);
            },
            // Extract a name from the string value and convert to an index
            getName = function(match, shortNames, longNames) {
                var index = -1,
                    names = $.map(lookAhead(match) ? longNames : shortNames, function(v, k) {
                        return [
                            [k, v]
                        ];
                    }).sort(function(a, b) {
                        return -(a[1].length - b[1].length);
                    });

                $.each(names, function(i, pair) {
                    var name = pair[1];
                    if (value.substr(iValue, name.length).toLowerCase() === name.toLowerCase()) {
                        index = pair[0];
                        iValue += name.length;
                        return false;
                    }
                });
                if (index !== -1) {
                    return index + 1;
                } else {
                    throw lang.get("unknown-name-at-position") + iValue;
                }
            },
            // Confirm that a literal character matches the string value
            checkLiteral = function() {
                if (value.charAt(iValue) !== format.charAt(iFormat)) {
                    throw lang.get("unexpected-literal-at-position") + iValue;
                }
                iValue++;
            };

        for (iFormat = 0; iFormat < format.length; iFormat++) {
            if (literal) {
                if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
                    literal = false;
                } else {
                    checkLiteral();
                }
            } else {
                switch (format.charAt(iFormat)) {
                    case "d":
                        day = getNumber("d");
                        break;
                    case "D":
                        getName("D", dayNamesShort, dayNames);
                        break;
                    case "o":
                        doy = getNumber("o");
                        break;
                    case "m":
                        month = getNumber("m");
                        break;
                    case "M":
                        month = getName("M", monthNamesShort, monthNames);
                        break;
                    case "y":
                        year = getNumber("y");
                        break;
                    case "t":
                        time = getNumber("t");
                        break;
                    case "@":
                        date = new Date(getNumber("@"));
                        year = date.getFullYear();
                        month = date.getMonth() + 1;
                        day = date.getDate();
                        break;
                    case "!":
                        date = new Date((getNumber("!") - _ticksTo1970) / 10000);
                        year = date.getFullYear();
                        month = date.getMonth() + 1;
                        day = date.getDate();
                        break;
                    case "'":
                        if (lookAhead("'")) {
                            checkLiteral();
                        } else {
                            literal = true;
                        }
                        break;
                    default:
                        checkLiteral();
                }
            }
        }

        if (iValue < value.length) {
            extra = value.substr(iValue);
            if (!/^\s+/.test(extra)) {
                throw lang.get("extra-unparsed-char-in-date") + extra;
            }
        }

        if (year === -1) {
            year = new Date().getFullYear();
        } else if (year < 100) {
            year += new Date().getFullYear() - new Date().getFullYear() % 100 +
                (year <= shortYearCutoff ? 0 : -100);
        }

        var _daylightSavingAdjust = function(date) {
            if (!date) {
                return null;
            }
            date.setHours(date.getHours() > 12 ? date.getHours() + 2 : 0);
            return date;
        };

        var _getDaysInMonth = function(year, month) {
            return 32 - _daylightSavingAdjust(new Date(year, month, 32)).getDate();
        };

        if (doy > -1) {
            month = 1;
            day = doy;
            do {
                dim = _getDaysInMonth(year, month - 1);
                if (day <= dim) {
                    break;
                }
                month++;
                day -= dim;
            } while (true);
        }

        date = _daylightSavingAdjust(new Date(year, month - 1, day));
        if (date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) {
            throw lang.get("invalid-date"); // E.g. 31/02/00
        }

        if (time !== -1) {
            var timeSplit = time.split(':');
            date.setHours(timeSplit[0]);
            date.setMinutes(timeSplit[1]);
            date.setSeconds(timeSplit[2]);
        }

        return date;
    };

    api.tryToParseDate = function(value, format) {
        var possibleFormat = ['yy-mm-dd', 'yy/mm/dd', 'dd/mm/yy', 'dd-mm-yy',
            'yy-m-d', 'yy/m/d', 'd/m/yy', 'd-m-yy',
            'y-mm-dd', 'y/mm/dd', 'dd/mm/y', 'dd-mm-y',
            'y/m/d', 'y/m/d', 'd/m/y', 'd-m-y'
        ];

        var date = undefined;
        for (var i = 0; i < possibleFormat.length; i++) {
            var dateFormat = possibleFormat[i];
            if (!format || dateFormat != format) {
                try {
                    date = api.parseDate(dateFormat, value);
                    return date;
                } catch (e) {
                    continue;
                }
            }
        }

        if (!date)
            return value;
    };

    /**
     * fallback function to copy the text for earlier browsers 
     */
    var language = lang.getLangObj();
    api.copyToClipboard = function(e, text) {
        $window.prompt(language["copy-to-clipboard"], text);
    };

    api.hasAccess = function(str, key) {
        if (!str) {
            return false;
        }

        return (str.indexOf("," + apiConfig[key] + ",") > -1)
    };

    api.hasFolderPermission = function(
        folderPermissionValues,
        folderId,
        key
    ){
        folderId = folderId.split("$$")[0];
        return folderPermissionValues[folderId] == apiConfig.folderPermission[key];
    }

    api.hasFolderUploadPermission = function(permissionData, folderId) {
        return (api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_ADMIN_PERMISSION') ||
        api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_PUBLISH_AND_LINK_PERMISSION') ||
        api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_PUBLISH_PERMISSION'));
    };

    api.hasPermissionToCheckoutFile = function(selectedRows, permissionsData) {
        var isEnableCheckout = true;

        selectedRows.some(function(row) {
            var permissionValue = permissionsData.folderPermissionValues[row.folderId.split("$$")[0]];
            if ( row.isLink || row.is_link || row.documentTypeId == apiConfig.DOC_TYPE_ID.PLACEHOLDER || row.checkOutStatus || permissionValue === apiConfig.folderPermission.VIEW_ONLY || !api.hasFolderUploadPermission(permissionsData, row.folderId)) {
                isEnableCheckout = false;
                return true;
            }
        });
        return isEnableCheckout;
    };

    api.isLocked = function(str, key) {
        if (!str) {
            return false;
        }
        return (str.indexOf(apiConfig.ACTIVITY_CONSTANT[key]) > -1)
    };

    api.submitDownloadForm = function(option) {
        
        $("#downloadFrame").remove();
        var $iframe = $('<iframe src="" id="downloadFrame" name="downloadFrame" style="width: 0px;height:0px;border: 0px;"></iframe>');
        var form = document.createElement('form');

        form.target = "downloadFrame";

        if (option.param)
            option.param.applicationId = myConfig.applicationId;

        if(option.url.indexOf('http') !== 0) {

            if (option._dcId) {
                option.url = manageDataCenter.getUrl(option._dcId, option._cdnUrl) + option.url;
                delete option._dcId;
                delete option._cdnUrl;
            }

            if (option._cdnUrl && !option._dcId) {
                option.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, option._cdnUrl) + option.url;
                delete option._cdnUrl;
            }
        }


        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }


        document.body.appendChild(form);
        document.body.appendChild($iframe);
        form.submit();
        angular.element(form).remove();
    };

    api.submitForm = function(option) {
        var form = document.createElement('form');

        var target = option.target || '_blank';
        if (api.isNavigator())
            target = '_self';

        form.target = target;

        if (option.param) {
            if (myConfig.applicationId) {
                option.param.applicationId = myConfig.applicationId;
            } else {
                option.param.applicationId = applicationId;
            }
        }

        if(option.url.indexOf('http') !== 0) {

            if (option._dcId) {
                option.url = manageDataCenter.getUrl(option._dcId, option._cdnUrl, option.non_edgeCast) + option.url;
                delete option._dcId;
                delete option._cdnUrl;
            }

            if (option._cdnUrl && !option._dcId) {
                option.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, option._cdnUrl) + option.url;
                delete option._cdnUrl;
            }
        }


        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
        angular.element(form).remove();
    };

    api.fileViewForMobile = function(option, headerHide) {

        if (myConfig.applicationId !== 3) {
            return;
        }

        try{
            localStorage.setItem('appStaticContentVersion', window.staticContentVersion);
        } catch(err){}

        if (option.param) {
            option.param.applicationId = 3;
            option.param.ios = true;
            option.param.isAndroid = true;
            option.param.isNewUI = true;
        }

        var $fileViewPort = angular.element("#fileViewPort");
        $fileViewPort.removeClass("close").addClass("open");


        $fileViewPort.find("button.close")[0].onclick = function(e) {
            $fileViewPort.removeClass("open").addClass("close");
        };

        $("#msgWindow").remove();
        var form = document.createElement('form');
        angular.element("#fileViewPortBody").append('<iframe id="msgWindow" name="msgWindow" style="width:100%; height:100%; border: none; background: white;" ></iframe>');
        form.target = "msgWindow";
        $fileViewPort.find("div.modal-header").hide();

        //form.target = option.target || '_blank';

        if (option._dcId) {
            option.url = manageDataCenter.getUrl(option._dcId) + option.url;
            delete option._dcId;
        }

        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
        angular.element(form).remove();
    };

    /**
     * Fetch custom object template list
     * @param {fn} callback
     * @param {string} projectId
     */
    api.getCustomObjectTemplateList = function(callback, customObjectContextId, projectId) {
        var customObjectTemplates = api.ajax({
            url: apiConfig.GET_CUSTOM_OBJECT_TEMPLATE_LIST,
            data: {
                customObject: JSON.stringify({
                    projectId: projectId || myConfig.projectId,
                    customObjectContextId: customObjectContextId,
                    description: "",
                    type: "text",
                    enabled: true
                })
            }
        });

        customObjectTemplates.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert('Error while fetching Custom templates!');
        });

        return customObjectTemplates;
    };

    /**
     * fetch the permission for view form
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var viewPermission = undefined;
    api.getViewPermission = function(callback, refresh, projectId, offlineType) {

        var then = function() {
            viewPermission.then(function(data) {
                viewPermission = data;
                callback && callback(data);
            }, function(xhr) {
                $window.alert(lang.get("permission-check-failed"));
            });
        }

        if (!refresh && viewPermission) {
            if (myConfig.isOfflineMode || viewPermission.abort) {
                then();
            } else {
                callback && callback(viewPermission);
            }
            return;
        }

        viewPermission = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_USER_APPLICATION_PRIVILEGES,
                projectId: projectId || myConfig.projectId,
                type: myConfig.isOfflineMode ? offlineType : undefined
            }
        });

        then();
    };

    api.getUserSharePermission = function(objectId, objectTypeId, callback) {
        var permissionChecker = api.ajax({
            url: window.asiteWorksServiceURL + apiConfig.GET_USER_SHARE_PERMISSION,
            aSessionID: window['USP']['aSessionId'],
            data: {
                projectId: myConfig.projectId,
                objectId: objectId,
                objectTypeId: objectTypeId
            }
        });

        permissionChecker.then(function(permissionData) {
            var filterForCommentAndViewFile = permissionData.asiteworksFeatureConfig.filter(
                function(data){
                    return data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE || 
                        data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT || 
                        data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.DOWNLOAD_FILE;
                }
            );
            
            //Set permission based on other parameter if asite works feature config is empty
            if(!filterForCommentAndViewFile.length) {
                filterForCommentAndViewFile.push({
                    operationId: apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE,
                    isAllowed: permissionData.isOwner || permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.NONE
                });
                filterForCommentAndViewFile.push({
                    operationId: apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT,
                    isAllowed: permissionData.isOwner || (permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.VIEWER && permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.NONE)
                });
            }
   
            callback && callback(filterForCommentAndViewFile);
        }, function(xhr) {
            callback && callback([{
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE,
                isAllowed: false
            }, {
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT,
                isAllowed: false
            }, {
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.DOWNLOAD_FILE,
                isAllowed: false
            }]);
            $window.alert(lang.get("permission-check-failed"));
        });
    }

    /**
     * fetch the permission for view form
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    api.getUserAccessForMultiProject = function(callback, projectIds) {
        var multiProjPermission = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_USER_APPLICATION_PRIVILEGES_MULTI,
                projectIds: projectIds
            }
        });

        multiProjPermission.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert(lang.get("permission-check-failed"));
        });

        return multiProjPermission;
    };

    var formSpecificPermission = {};
    // call to fetch specific form permission
    api.getFormSpecificPermission = function(param, callback, refresh) {
        var then = function() {
            formSpecificPermission[param.formTypeIds].then(function(data) {
                data = data[0] || data || {};
                formSpecificPermission[param.formTypeIds] = data;
                callback && callback(data);
            }, function(xhr) {
                $window.alert(lang.get("permission-check-failed"));
            });
        }

        if (!refresh && formSpecificPermission[param.formTypeIds]) {
            if (formSpecificPermission[param.formTypeIds].abort) {
                then();
            } else {
                callback && callback(formSpecificPermission[param.formTypeIds]);
            }
            return;
        }

        formSpecificPermission[param.formTypeIds] = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_FORM_TYPE_PRIVILEGES,
                formTypeIds: param.formTypeIds, //myConfig.hLatestFormType,
                paramProjectIds: param.paramProjectIds //myConfig.projectId
            }
        });

        then();
    };

    /**
     * fetch the workspace setting
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var workspaceSettings = {};
    api.getWorkspaceSettings = function(callback, refresh, projectId) {
        projectId = projectId || myConfig.projectId;
        var then = function() {
            workspaceSettings[projectId].then(function(data) {
                workspaceSettings[projectId] = data;
                callback && callback(workspaceSettings[projectId]);
            }, function(xhr) {
                $window.alert('Error while fetching Workspace Settings!');
            });
        }

        if (!refresh && workspaceSettings[projectId]) {
            if (workspaceSettings[projectId].abort) {
                then();
            } else {
                callback && callback(workspaceSettings[projectId]);
            }
            return;
        }

        workspaceSettings[projectId] = api.ajax({
            url: apiConfig.GET_WORKSPACE_SETTING,
            data: {
                projectId: projectId,
                userId: myConfig.USP.userID
            }
        });

        then();
    };

    /**
     * fetch the workspace setting
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var workspaceSettingsForMarkUps = {};
    api.getWorkspaceSettingsForMarkups = function(callback, refresh, projectId) {
        projectId = projectId || myConfig.projectId;
        var then = function() {
            workspaceSettingsForMarkUps[projectId].then(function(data) {
                var settings = {};
                var setting_option = {
                        displayProp: {
                            "0": "block",
                            "1": "block",
                            "2": "none"
                        },
                        "0": { "checked": false, "disabled": false },
                        "1": { "checked": true, "disabled": true },
                        "2": { "checked": false }
                    },
                    settingId = data.checkCreateCommentPref;
                settings.saveAsMarkupOptions = setting_option[settingId];
                settings.displayMarkupCheckBox = setting_option['displayProp'][settingId];
                settings.settingId = settingId;
                settings.checkPrintDocumentPoi = data.checkPrintDocumentPoi;
                settings.checkPrintDocumentStatus = data.checkPrintDocumentStatus;
                settings.checkViewDocumentPoi = data.checkViewDocumentPoi;
                settings.checkViewDocumentStatus = data.checkViewDocumentStatus;

                workspaceSettingsForMarkUps[projectId] = settings;
                callback && callback(workspaceSettingsForMarkUps[projectId]);
            }, function(xhr) {
                $window.alert('Error while fetching Workspace Settings!');
            });
        }

        if (!refresh && workspaceSettingsForMarkUps[projectId]) {
            if (workspaceSettingsForMarkUps[projectId].abort) {
                then();
            } else {
                callback && callback(workspaceSettingsForMarkUps[projectId]);
            }
            return;
        }

        workspaceSettingsForMarkUps[projectId] = api.ajax({
            url: apiConfig.GET_WORKSPACE_SETTING_MARKUP,
            data: {
                projectId: projectId,
                userId: myConfig.USP.userID
            }
        });

        then();
    };

    var informParentWinTimeout = undefined;
    api.informParentWin = function(updateDetail) {
        $timeout.cancel(informParentWinTimeout);
        informParentWinTimeout = $timeout(function() {
            try {
                if (typeof myConfig.isFromFileViewForDomain != undefined && myConfig.isFromFileViewForDomain == "true") {
                    angular.element('#ifrmRefreshParent').remove();
                    var updateDetailStr = [];
                    for (var key in updateDetail) {
                        updateDetailStr.push(key + "_" + updateDetail[key]);
                    }
                    updateDetailStr = updateDetailStr.join("--");
                    var iframe = angular.element('<iframe id="ifrmRefreshParent" src="' + baseUrl + apiConfig.VIEWER_PARENT_REFRESH + "?q=_" + new Date().getTime() + "&updateParam=" + updateDetailStr + '" width="0" height="0" style="position: absolute; border: none; margin: 0;">');
                    angular.element("body").append(iframe);
                } else if (api.isIE()) {
                    $window.opener.updateTableData.initUpdateByPrimaryKey(updateDetail);
                } else {
                    $window.opener.postMessage("updateData" + angular.toJson(updateDetail), "*");
                }
            } catch (e) {}
        }, 200);
    };

    api.returnNonAkamaiURL = function(param, callback) {
        var xhr = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                userId: myConfig.USP.userID,
                projectId: param.projectId,
                extra: JSON.stringify(param.revisionIds),
                action_id: apiConfig.CHECK_FOR_AKAMAI_DOWNLOAD_LIMIT
            }
        });
        xhr.then(function(data) {
            callback && callback(data)
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"))
        })
    };

    api.downloadFile = function(file, projectId, extra) {
        api.returnNonAkamaiURL({
            projectId: file.projectId,
            revisionIds: {
                revisions: [{
                    revisionId: file.revisionId,
                    dcId: file.dcId,
                    projectId: file.projectId,
                    isLock: ""
                }]
            }
        }, function(data) {
            var url = myConfig.downloadServiceURL;

            if (data.isLimitExist) {
                url = data.nonCDNDownloadUrl
            } else {
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }
            
            url += apiConfig.DOWNLOAD_SINGLE_DOCUMENT + "?revisionId=" + file.revisionId + "&projectId=" + file.projectId;
            if (extra) {
                for (var key in extra) {
                    if (extra.hasOwnProperty(key)) {
                        url += '&' + key + '=' + extra[key];
                    }
                }
            }
            jQuery.fileDownload(url, {
                preparingMessageHtml: lang.get("perparing-your-files-please-wait"),
                failMessageHtml: lang.get("problem-downloading-your-file-please-try-again")
            })
        });
    };

    api.downloadAttachmentFile = function(file, zipUrl) {
        var url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, myConfig.downloadServiceURL);
        url += zipUrl || apiConfig.DOWNLOAD_INTERNAL_ATTACHMENT_CONTROLLER + "?projectId=" + file.projectId + "&attachmentId=" + file.attachmentId;
        jQuery.fileDownload(url, {
            preparingMessageHtml: lang.get("perparing-your-files-please-wait"),
            failMessageHtml: lang.get("problem-downloading-your-file-please-try-again")
        });
    };

    api.viewFile = function(param, dcId, target) {
        if (myConfig.applicationId) {
            param.applicationId = myConfig.applicationId;
        }
        var target = target || '_FILE_VIEWER_' + param.revisionId
        api.submitForm({
            target: target,
            method: 'GET',
            url: apiConfig.FILE_VIEW_PAGE,
            param: param,
            _dcId: dcId
        });
    };
    api.getLockedActivitiesObject = function(str) {
        if (!str || str == -1) {
            str = '';
        }
        var lockedObjects = str.toString().split(',');
        return {
            attributes: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_EDIT_ATTRIBUTES.toString()) != -1),
            distribution: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_FILE_DISTRIBUTION.toString()) != -1),
            status: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_UPDATE_STATUS.toString()) != -1),
            comment: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_ADD_COMMENT.toString()) != -1),
            revisionUpload: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_REVISION_UPLOAD.toString()) != -1)
        }
    }
    api.openDiscussion = function(param, dcId) {
        param.callFor = "comments";

        api.submitForm({
            target: '_VIEWER_' + param.revisionId,
            method: 'GET',
            url: apiConfig.FILE_VIEW_PAGE,
            param: param,
            _dcId: dcId
        });
    };

    api.openApp = function(param, dcId) {
        var target = '_VIEW_FORM_' + param.commId;
        if (target == window.name) {
            target = '_blank';
        }

        api.submitForm({
            target: target,
            method: 'GET',
            url: apiConfig.VIEW_FORM,
            param: param,
            _dcId: dcId
        });
    };

    api.openAttachment = function(param, dcId) {
        var isMsgIdZero = (param.msgId && param.msgId.split('$$')[0] == '0');
        if (isMsgIdZero && param.commingFrom != "customObject") {
            param.commingFrom = "internalAttachment";
        }

        if (api.isMobile() && myConfig.applicationId == 3) {
            api.fileViewForMobile({
                target: '_self',
                url: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
                param: param,
                method: 'GET',
                _dcId: param.dcId || dcId
            }, true);
            return;
        }

        var method = param.method || 'GET';
        delete param.method;

        if(window['platformName']) {
            // Disabled attachment view temporary for external platforms i.e naviswork
            // window['openExternalUrl']({
            //     endPoint: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
            //     params: param
            // });
            return;
        }

        api.submitForm({
            target: '_FILE_VIEWER_' + (param.attachmentId || param.revisionId),
            url: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
            param: param,
            _dcId: dcId
        });
    };

    api.checkActionValidation = function(param) {
        var selData = null,
            isValidate = true;
        if (!param || !param.selectedList || !param.selectedList.length) {
            return;
        }
        for (var i = 0; i < param.selectedList.length; i++) {
            selData = param.selectedList[i];
            if (selData.actions && selData.actions.split('$$')[0] !== param.validateAction && !selData.date) {
                isValidate = false;
            }
        }
        return isValidate;
    };

    api.encodeHtml = function(value) {
        return value.replace(/'/g, "&apos;");
    };

    api.sanitizeHtml = function(html) {
        if(!html) {
            return html;
        }

        // Sanitize untrusted HTML (to prevent XSS) with a configuration specified by a Whitelist.
        return filterXSS(html, {
            stripIgnoreTagBody: ['script'],
            stripIgnoreTag: true, allowCommentTag: false
        })
    };

    api.sanitizeComments = function(comments) {
        if(!comments || !comments.length) {
            return comments;
        }

        for(var i = 0; i < comments.length; i++) {
            var msgVO = comments[i] && comments[i].messageVO;
            if(!msgVO) {
                continue;
            }
            
            for(var j = 0; j < msgVO.length; j++) {
                if(msgVO[j]) {
                    msgVO[j].comment_text = api.sanitizeHtml(msgVO[j].comment_text);
                }
            }
        }
        return comments;
    };

    api.returnErrorCode = function(xhr) {
        var div = angular.element("<div>");
        div.append(xhr.data);

        var errorDom = div.find("#errorCode");
        if (errorDom.length) {
            return errorDom.html().trim();
        }

        return "";
    };

    api.showServerErrMsg = function(xhr) {
        if (myConfig.applicationId == 2) {
            var isOnline = qtObject.systemOnlineCallBack();
            if (!isOnline) {
                api.showNetworkMsg();
            }
        }

        if (myConfig.applicationId != 2 && !navigator.onLine) {
            api.showNetworkMsg();
        }

        if (!xhr || xhr.status == -1) {
            return;
        }

        xhr.errorCode = api.returnErrorCode(xhr);
        Notification.error({
            title: lang.get("server-error") + ': ' + (xhr.errorTitle || ''),
            message: '<div class="text-large">' +
                lang.get('error-while-processing-your-request') + ': ' + xhr.errorCode +
                '</div>'
        });
    };
    api.showNetworkMsg = function() {
        Notification.clearAll();
        Notification.error({
            title: lang.get("network-error"),
            message: '<div class="text-large">' +
                lang.get('not-able-to-connect-server') +
                '</div>'
        });
    };
    api.showWarningMsg = function(opt) {
        Notification.warning({
            title: opt.title,
            message: '<div class="text-large">' + opt.msg + '</div>'
        });
    };

    api.sortArray = function(array, key, order) {
        order = (order) ? order : "asc";
        if (order == "asc") {
            return array.sort(function(a, b) {
                var x = a[key];
                var y = b[key];
                return ((x < y) ? -1 : ((x > y) ? 1 : 0))
            })
        } else {
            if (order == "desc") {
                return array.sort(function(a, b) {
                    var x = a[key];
                    var y = b[key];
                    return ((y < x) ? -1 : ((y > x) ? 1 : 0))
                })
            }
        }
    };

    var nativeNotification = $window.Notification;

    api.windowNotification = function(data, callback) {

        if (!nativeNotification) {
            return;
        } else if (nativeNotification.permission === 'denied') {
            return;
        } else if (nativeNotification.permission === 'default') {
            nativeNotification.requestPermission(function(permission) {
                return;
            });
        } else if (nativeNotification.permission === 'granted' && data) {
            var notificationObj = new nativeNotification(data.title, data.option);
            if (notificationObj) {
                notificationObj.onclick = function() {
                    callback(data.param);
                    this.close();
                };
            }
            return notificationObj;
        }
    }

    api.timeAgo = function(data) {
        var strings = {
                suffixAgo: "ago",
                seconds: "few seconds",
                minutes: "%d minutes",
                hours: "%d hours",
                days: "%d days",
                months: "%d months",
                years: "%d years"
            },
            dateDifference = (new Date().getTime()) - data.time,
            words,
            seconds = Math.abs(dateDifference) / 1000,
            minutes = seconds / 60,
            hours = minutes / 60,
            days = hours / 24,
            years = days / 365,
            suffix = strings.suffixAgo;

        var substitute = function(stringOrFunction, number, strings) {
            number = Math.floor(number);
            return stringOrFunction.replace(/%d/i, number);
        };
        words = seconds < 60 && substitute(strings.seconds, seconds, strings) ||
            minutes < 60 && substitute(strings.minutes, minutes, strings) ||
            hours < 24 && substitute(strings.hours, hours, strings) ||
            days < 30 && substitute(strings.days, days, strings) ||
            days < 365 && substitute(strings.months, (days / 30), strings) ||
            substitute(strings.years, years, strings);
        return (words + ' ' + suffix);
    }

    api.getExt = function(name) {
        return name.substr(name.lastIndexOf('.') + 1);
    };
    
    api.isZip = function(name) {
        if(!name || typeof name !== 'string') {
            return false;
        }
        var ext = api.getExt(name.toLowerCase());
        if(['zip', 'rar'].indexOf(ext) > -1) {
            return true;
        }
        return false;
    };

    api.getFileExtImage = function(type) {
        var map = {
            'pdf': 'pdf',
            '000': '000',
            '906': '906',
            '907': '906',
            'dwg': 'dwg',
            'dwg_mf': 'dwg_mf',
            'dxf': 'dxf',
            'dwf': 'dwf',
            'dx': 'dx',
            'dg': 'dg',
            'prt': 'prt',
            'rlc': 'rlc',
            'cgm': 'cgm',
            'edm': 'edm',
            'g3': 'ctx',
            'g4': 'ctx',
            'cg4': 'ctx',
            'rnl': 'rnl',
            'cmi': 'cmi',
            'mi': 'mi',
            'plt': 'plt',
            'igs': 'igs',
            'iges': 'igs',
            'dgn': 'dgn',
            'dgn_mf': 'dgn_mf',
            'cit': 'cit',
            'rle': 'rle',
            'mvs': 'mvs',
            'dsn': 'dsn',
            'slddrw': 'sld',
            'mot': 'mot',
            'cal': 'cal',
            'gp4': 'cal',
            'mil': 'cal',
            'dcx': 'dcx',
            'edc': 'edc',
            'ftk': 'ftk',
            'iso': 'iso',
            'jpg': 'jpg',
            'jpeg': 'jpg',
            'pcx': 'pcx',
            'dif': 'dif',
            'tif': 'tif',
            'tiff': 'tif',
            'bmp': 'bmp',
            'cdr': 'cdr',
            'shw': 'shw',
            'dbf': 'dbf',
            'xdw': 'xdw',
            'xls': 'xls',
            'fax': 'fax',
            'html': 'html',
            'htm': 'htm',
            'ini': 'ini',
            'pps': 'pps',
            'ppt': 'ppt',
            'mpp': 'mpp',
            'vsd': 'vsd',
            'doc': 'doc',
            'wdb': 'wdb',
            'p65': 'p65',
            'wb1': 'wb1',
            'wb2': 'wb2',
            'wq1': 'wq1',
            'rtf': 'rtf',
            'sam': 'sam',
            'wri': 'wri',
            'wp5': 'wp5',
            'wp6': 'wp6',
            'wpd': 'wpd',
            'wpf': 'wpf',
            'ws': 'ws',
            'gif': 'gif',
            'log': 'txt',
            'txt': 'txt',
            'dll': 'dll',
            'zip': 'zip',
            'bak': 'bak',
            'url': 'url',
            'ico': 'ico',
            'avi': 'avi',
            'cab': 'cab',
            'cdf': 'cdf',
            'chm': 'chm',
            'css': 'css',
            'js': 'js',
            'msg': 'msg',
            'dot': 'dot',
            'eml': 'eml',
            'docx': 'docx',
            'dotx': 'dotx',
            'ppsx': 'ppsx',
            'pptx': 'pptx',
            'xlsx': 'xlsx',
            'kml': 'kml',
            'kmz': 'kmz',
            'asx': 'asx',
            'wax': 'wax',
            'm3u': 'm3u',
            'wpl': 'wpl',
            'wvx': 'wvx',
            'wmx': 'wmx',
            'dvr': 'ms=dvr-ms',
            'mid': 'mid',
            'rmi': 'rmi',
            'midi': 'midi',
            'mpeg': 'mpeg',
            'mpg': 'mpg',
            'm1v': 'm1v',
            'mp2': 'mp2',
            'mpa': 'mpa',
            'mpe': 'mpe',
            'mpc': 'mpc',
            'mp': '=mp+',
            'ogg': 'ogg',
            'ogm': 'ogm',
            'spx': 'spx',
            'wav': 'wav',
            'snd': 'snd',
            'au': 'au',
            'aif': 'aif',
            'aifc': 'aifc',
            'aiff': 'aiff',
            'wma': 'wma',
            'mp3': 'mp3',
            'mp4': 'mp4',
            'asf': 'asf',
            'wm': 'wm',
            'wmd': 'wmd',
            'wmv': 'wmv',
            'divx': 'divx',
            'div': 'div',
            'dat': 'dat',
            'dv': 'dv',
            'vob': 'vob',
            'ra': 'ra',
            'ram': 'ram',
            'rm': 'rm',
            'rmvb': 'rmvb',
            'mov': 'mov',
            'qt': 'qt',
            '3gp': '3gp',
            'aac': 'aac',
            'ac3': 'ac3',
            'amr': 'amr',
            'exe': 'exe',
            'fla': 'fla',
            'flv': 'flv',
            'swf': 'swf',
            'p3': 'p3',
            'p3c': 'p3c',
            'prx': 'prx',
            'stx': 'stx',
            'mps': 'mps',
            'd': 'd',
            'nwc': 'nwc',
            'nwd': 'nwd',
            'nwf': 'nwf',
            'png': 'png',
            'skp': 'skp',
            'smc': 'smc',
            'mdb': 'mdb',
            '7z': '7z',
            'ace': 'ace',
            'arc': 'arc',
            'arj': 'arj',
            'b64': 'b64',
            'bhx': 'bhx',
            'bz2': 'bz2',
            'dar': 'dar',
            'gz': 'gz',
            'gzip': 'gzip',
            'hqx': 'hqx',
            'ice': 'ice',
            'jar': 'jar',
            'lzh': 'lzh',
            'mim': 'mim',
            'pkzip': 'pkzip',
            'rar': 'rar',
            'sfark': 'sfark',
            'shar': 'shar',
            'tar': 'tar',
            'tgz': 'tgz',
            'tz': 'tz',
            'uu': 'uu',
            'uue': 'uue',
            'wim': 'wim',
            'xar': 'xar',
            'xxe': 'xxe',
            'xsf': 'xsf',
            'xsn': 'xsn',
            'rvt': 'rvt',
            'pts': 'pts',
            'ptx': 'ptx',
            'pptm': 'pptm',
            'dwfx': 'dwfx',
            'asn': 'asn',
            'all': 'all',
            'wmf': 'wmf',
            'potx': 'potx',
            'dotm': 'dotm',
            'xps': 'xps',
            'pot': 'pot',
            'ppsm': 'ppsm',
            'svg': 'svg',
            'pub': 'pub',
            'ppa': 'ppa',
            'xhtml': 'xhtml',
            'xod': 'xod',
            'odt':'odt',
            'ods':'ods',
            'caf':'caf',
            'oga':'oga',
            'm4a':'m4a',
            'flac':'flac',
            'opus':'opus',
			'jfif':'jfif'
        };
       type = type || "";
        type = type.toLowerCase();
        return (map[type] || 'noicon');
    };

    /**
     * Return extension type wise Map
     */
    api.getFileExtesions = function (type) {
        var map = {
            image: ["jpeg", "jpg", "gif", "png", "bmp", "ppm", "pgm", "pbm", "pnm", "webp", "bpg", "ico", "img", "pgf", "xisf", "wmf", "emf", "vml", "xps", "dwg"],
            audio: ["aa	", "aac", "aax", "act", "aiff", "amr", "ape", "au	", "awb", "dct", "dss", "dvf", "flac", "gsm", "ikla", "ivs", "m4a", "m4b", "m4p", "mmf", "mp3", "mpc", "msv", "ogg", "opus", "ra,", "raw", "sln", "tta", "vox", "wav", "wma", "wv	", "webm", "8sv"],
            video: ["webm", "mkv", "flv", "vob", "ogv", "ogg", "drc", "mng", "mng", "avi", "mov", "qt", "rm", "yuv", "rmvb", "asf", "amv", "mp4", "m4p", "m4v", "mpg", "mp2", "mpeg", "mpe", "mpv", "m2v", "svi", "3gp", "3g2", "mxf", "roq", "nsv", "f4v", "f4p", "f4a", "f4b"],
            code: ["asp", "jsp", "js", "xml", "bat", "cmd", "class", "cpp", "def", "dll", "dtd", "exe", "font", "html", "htm", "java", "css", "ts", "json"],
            powerpoint: ["ppt", "pot", "pps", "pptx", "pptm", "potx", "potm", "ppam", "ppsx", "ppsm", "sldx", "sldm"],
            word: ["doc", "dot", "wbk", "docx", "docm", "dotx", "dotm", "docb"],
            zip: ["zip", "lib", "jar", "war", "ear", "iso", "rar", "7z"],
            excel: ["xls", "xlsm", "xlt", "xlm", "xltm", "xltx", "xlsx", "xlsb", "xla", "xlam", "xll", "xlw", "csv"],
            pdf: ["pdf"]
        }

        if (type && map[type]) {
            return map[type];
        }

        return map;
    };

    /**
		 * @description add file exension key in the data
		 * @param {*} attachment Data
		 * @memberof TableListingComponent
		 */
    api.setFileExtInAttach = function (data) {
        for (var i = 0; i < data.length; i++) {
            var attachment = data[i];
            var fileName = attachment.fileName || attachment.FileName || "";
            var fileSize = attachment.fileSize || attachment.FileSize;
            if (!fileName) {
                return;
            }
    
            if (typeof fileSize !== "string" || fileSize.indexOf('B') == -1) {
                attachment.fileSize = attachment.FileSize = (fileSize / 1024 / 1024).toFixed(2) + ' MB';
            }
    
            if (typeof attachment.attachedDate !== "string") {
                var userformat = window['INIT_JSP_GLOBAL'].formatsForJqueryCalender[window['USP'].languageId];
                attachment.attachedDate && (attachment.attachedDate = api.formatDate(userformat, new Date(attachment.attachedDate)));
            }           

            var splitArray = fileName.split('.');
            var ext = splitArray[splitArray.length - 1];
            var extClass = "text";

            var extObj = api.getFileExtesions();
            for (var key in extObj) {
                if (extObj.hasOwnProperty(key)) {
                    var extArray = extObj[key];
                    if (extArray.indexOf(ext) > -1) {
                        extClass = key;
                        break;
                    }
                }
            }
            attachment['fileExt'] = extClass;
        }
    };

    api.getSortFileSize = function(size) {
        size = size || 0;
        var s = Math.round(((size > (1024 * 1024)) ? (((size * 100) / (1024 * 1024)) / 100) : (((size * 100) / 1024) / 100)));
        s += (size > 1024 * 1024) ? ' MB' : ' KB';

        return s;
    };

    api.openReview = function(data, extra) {
        var url, param = {
			dcId: data.dcId,
			revisionId: data.revisionId,
			callFor: 'reviews',
			reviewInstanceId: data.customObjectInstanceId,
			reviewCommentId: data.customObjectCommentId,
			documentTypeId: data.docTypeId || data.documentTypeId,
			hasOnlineViewerSupport: data.hasOnlineViewerSupport,
			isFromFileViewForDomain: 'true',
			isFromFileListing: 'true',
			projectId: data.projectId,
			isDraft: false
		};

		url = apiConfig.FILE_VIEW_PAGE;
		param['folderId'] = data.folderId;
		param['documentId'] = data.documentId || 0;
		param['viewerId'] = data.viewerId || 0;

		if(api.isMobile() && myConfig.applicationId == 3){
			if(myConfig.isOfflineMode){
				api.sendEventToIpad("offlineCommentAssociationClick:"+JSON.stringify(param));
				return;
			}
			api.fileViewForMobile({
				target: '_self',
				url: apiConfig.FILE_VIEW_MOBILE,
				param: param,
				method: 'GET',
				_dcId: data.dcId
			});
			return;
		}

		if (extra) {
			for (var key in extra) {
				param[key] = extra[key];
			}
		}

		api.submitForm({
			target: '_VIEWER_' + data.revisionId,
			url: url,
			param: param,
			method: 'GET',
			_dcId: data.dcId
		});
    }
}])

.service('downloadAssocDoc', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'download', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, download, api, Notification) {
    var downloadAssocDoc = this;
    var downloadXhr = false;
    var resData = null;
    downloadAssocDoc.init = function(opt, callback) {
        downloadAssocDoc.directLink(opt, callback);
    };

    downloadAssocDoc.directLink = function(opt, callback) {
        resData = opt;
        var param = {
                revIds: [],
                revisions: [],
                isFromDirectLink: true,
                isDiffProject: false,
                projectIds: []
            },
            selectedRowsData = JSON.parse(opt.downloadRevDocListJSON),
            docData = null;

        if (selectedRowsData.length == 0) {
            Notification.error({ title: lang.get("adoddle"), message: lang.get("no-document-associations-found") });
            callback && callback();
            return false;
        } else {
            for (var i = 0; i < selectedRowsData.length; i++) {
                docData = selectedRowsData[i];
                param.revisions.push({
                    revisionId: docData.revisionId,
                    isLock: docData.isLock,
                    dcId: docData.dcId,
                    projectId: docData.projectId,
                    hasMarkup: docData.hasMarkup,
                    hasAttachment: docData.hasAttachment,
                    zipFileName: docData.zipFileName
                });
                param.revIds.push(docData.revisionId);
                if (param.projectIds.indexOf(docData.projectId) == -1) {
                    param.projectIds.push(docData.projectId);
                }
            }

            if (param.revisions.length) {
                param.isDiffProject = param.projectIds.length > 1;
                param.callForm = param.isDiffProject ? "MultiProjectDownload" : "DownloadBtn";
                downloadAssocDoc.displayDownloadPage(param, callback);
            } else {
                callback && callback();
            }
        }
    };

    downloadAssocDoc.displayDownloadPage = function(param, callback) {
        var revData = param.revisions[0];
        var isFromDirectLink = param.isFromDirectLink;
        if (!isFromDirectLink) {
            callback && callback();
            return;
        }

        if (downloadXhr) {
            return;
        }

        if (myConfig.applicationId != 2)
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');

        var strUrl = "";
        if (resData.isLimitExist) {
            strUrl = resData.nonCDNDownloadUrl;
        }
        var urlController = apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER;
        if (resData.isFromPublicDomain) {
            urlController = apiConfig.PUBLIC_DOWNLOAD_CONTROLLER;
        }
        else {
            if(!strUrl) {
                strUrl = myConfig.downloadServiceURL;
            }
        }
        downloadXhr = api.ajax({
            url: urlController,
            data: {
                extra: JSON.stringify(param),
                projectID: revData.projectId,
                isFromDirectLink: isFromDirectLink,
                includeInternalAttachment: resData.downloadSecondaryFile,
                action_id: apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION,
                downloadWithSimplePath: myConfig.downloadWithSimplePath
            },
            _dcId: revData.dcId,
            _cdnUrl: strUrl
        });

        downloadXhr.then(function(data) {
            downloadXhr = false;
            data.url = apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
            if (resData.isFromPublicDomain) {
                data.url = apiConfig.PUBLIC_DOWNLOAD_CONTROLLER;
            }
            data.actionUrl = data.sourcePath;
            data.projectId = revData.projectId;
            data.isFromDirectLink = isFromDirectLink;
            download.createZipFile(data, callback);
        }, function(xhr) {
            callback && callback();
            downloadXhr = false;
            xhr.errorTitle = lang.get("server-error");
            api.showServerErrMsg(xhr);
        });
    };
}])

.service('validate', ['api', 'lang', function(api, lang) {
    var validation = this;

    var invalidHtmlArray = ['javas&#99;ript', 'javascript:', '<script', '</script>', 'vbscript:', 'livescript:', '<s&#99;ript>', '<img', 'onload=',
        '<input', '<select', '<textarea', '<form', '<head', '<body', '<html', 'datasrc=', '<iframe', 'text/javascript', 'eval(', 'expression(',
        'url(', '&{[', 'alert(', 'alert=', 'alert`', '\x3cscript', 'javascript#', '<meta', '%3cscript', 'document.cookie', 'window.location', '<EMBED', '</EMBED>', 'onerror=', 'window.open(', 'onclick=', 
        'prompt=', 'prompt`', 'prompt(', 'oncopy=', 'oncut=', 'onpaste=', 'ondbllclick=', 'onmouseover=', 'onmousedown=', 'onmouseenter=', 'onmouseleave=', 'onmousemove=', 'onmouseout=', 'onmouseup=', 'onscroll=', 
        'ontouchcancel=', 'ontouchend=', 'ontouchmove=', 'ontouchstart=', 'confirm`', 'confirm(', 'confirm=', 'oninput=',  '=javascript',
        '=&#34;javascript', '=(javascript', '=`javascript', '=data:', '=&#34;data:', '=(data', '=`data', 'xlink:href', '<button' 
    ];

    var richTextExceptionTags = ['<img'];

    validation.required = function(value) {
        var isValid = true;

        if (typeof value === "string") {
            value = value.trim();
        }

        if (!value || !value.length) {
            isValid = false;
        }

        return {
            valid: isValid,
            error: lang.get("field-required")
        };
    };

    validation.maxLength = function(value, length) {
        var isValid = true;

        if (value && value.length > length) {
            isValid = false;
        }

        return {
            valid: isValid,
            error: lang.get("workflow-description-too-loang").replace("{0}", length)
        };
    };

    validation.number = function(value) {
        var isValidNum = true;

        if (value) {
            // Accept Regular Number or float Number only
            var regIsNum = /^\d+(\.\d+)*$/;
            isValidNum = regIsNum.test(value);
        }

        return {
            valid: isValidNum,
            error: lang.get("invalid-decimal")
        };
    };

    validation.integer = function(value) {
        var isValidInt = true;

        if (value) {
            // Accept positive or Negative Number only
            var regIsInt = /^(\-{0,1})\d+$/;
            isValidInt = regIsInt.test(value);

            var MAX_INT = 2147483647;
            var MIN_INT = -2147483647;
            var intValue = parseInt(value);

            if (intValue >= MAX_INT || intValue <= MIN_INT) {
                isValidInt = false;
            }
        }

        return {
            valid: isValidInt,
            error: lang.get("invalid-integer")
        };
    };

    validation.decimal = function(value) {
        var isValid = true;

        if (value) {
            isValid = !isNaN(parseFloat(value)) && isFinite(value);
        }

        return {
            valid: isValid,
            error: lang.get("invalid-decimal")
        };
    };

    validation.email = function(value) {
        var isValidEmailAdd = true;

        if (value) {
            // Accept Email Format with or without underscore
            var regIsEmailFormat = /^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+){0,1}\@[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+){0,3}$/;
            isValidEmailAdd = regIsEmailFormat.test(value);
        }

        return {
            valid: isValidEmailAdd,
            error: lang.get("invalid-emailAddress")
        };
    };

    validation.date = function(value) {
        var isValid = true;

        if (value) {
            var split = value.split('::');
            try {
                api.parseDate(split[1], split[0]);
            } catch (e) {
                isValid = false;
            }
        }

        return {
            valid: isValid,
            error: lang.get("invalid-date")
        };
    };

    validation.alphaWithSpace = function(value) {
        var isValidString = true;

        if (value) {
            var regIsAlpha = /^\s*[a-zA-Z\s]+\s*$/;
            isValidString = regIsAlpha.test(value);
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-letters")
        };
    };

    //It check string contain HTML tag or not.
    validation.invalidHTMLtag = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                var codeAt = value.charCodeAt(i);
                if (codeAt < 32 || codeAt == 35) {
                    isValidString = false;
                    break;
                }
            }

            if (isValidString) {
                isValidString = validation.hasCodeContent(value).valid;
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-character-entered")
        };
    };

    //It check string contain HTML tag or not.
    validation.hasCodeContent = function(value, richText) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").replace(/\s/g, "").toLowerCase();
        value = value.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
        var isValidString = true;

        if (value) {
            for (var i = 0; i < invalidHtmlArray.length; i++) {
                if (richText && richTextExceptionTags.indexOf(invalidHtmlArray[i]) != -1) {
                    continue;
                }
                if (value.indexOf(invalidHtmlArray[i]) > -1) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalidCharForCommentRichbox")
        };
    };

    //It check string contain HTML tag or not.
    validation.hasInvalidChar = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        value = value.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                var codeAt = value.charCodeAt(i);
                if (codeAt < 32) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalidCharForCommentRichbox")
        };
    };

    validation.invalidchars = function(value) {
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32 || value.charCodeAt(i) == 63) {
                    isValidString = false;
                    break;
                }
            }
            if (value) {
                var nospecial = /^[^\/'\/\\:*?<>|;%#~\"]+$/;
                isValidString = nospecial.test(value);
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };

    validation.letterAndNumber = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32) {
                    isValidString = false;
                    break;
                }
            }

            var invalidStringArray = ['#', '|', '"', '/', '\\', ':', '*', '?', '<', '>', '|', ';', '%', '#', '~', '&'];
            invalidStringArray = invalidStringArray.concat(invalidHtmlArray);

            for (var i = 0; i < invalidStringArray.length; i++) {
                if (value.indexOf(invalidStringArray[i]) != -1) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-characters-entered")
        };
    };

    validation.docrefInvalidChars = function(value) {
        var isValidString = true;

        if (value) {
            var nospecial = /"|#|:|;|\x3F|\x7C|<|>|%|\\|\/|~|\*|—/;
            var matches = value.match(nospecial);

            if (matches && matches.length > 0) {
                isValidString = false;
            } else {
                for (var i = 0; i < value.length; i++) {
                    if (value.charCodeAt(i) < 32) {
                        isValidString = false;
                        break;
                    }
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };

    validation.invalidFileName = function(value) {
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32 || value.charCodeAt(i) == 63) {
                    isValidString = false;
                    break;
                }
            }

            if (value) {
                var nospecial = /^[^\\:*?<>|;%#~\"]+$/;
                isValidString = nospecial.test(value);
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };
}])

.service('ddchild', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    var loadedChilds = [];
    var callbacks = {};
    var childsMap = {};

    this.register = function(childScope, name) {
        loadedChilds.push({
            name: name,
            scope: childScope
        });
        childsMap[name] = childScope;

        if (callbacks[name] && callbacks[name].length) {
            for (var i = 0; i < callbacks[name].length; i++) {
                var cb = callbacks[name][i];
                cb();
            }

            callbacks[name] = [];
        }
    }

    this.getChildScope = function(name) {
        return childsMap[name];
    };

    this.isLoaded = function(name) {
        for (var i = 0; i < loadedChilds.length; i++) {
            var s = loadedChilds[i];
            if (s.name == name) {
                return true;
            }
        }
        return false;
    }

    this.onLoad = function(name, callback) {
        if (!callbacks[name]) {
            callbacks[name] = [];
        }

        callbacks[name].push(callback);
    }
}])

.service('attachmentApi', ['lang', 'validate', function(lang, validate) {
    this.inlineAttachments = [];

    this.register = function(scope, ctrl) {
        this.inlineAttachments.push([scope, ctrl]);
    };

    this.unregister = function(scope, ctrl) {
        for (var i = 0; i < this.inlineAttachments.length; i++) {
            var inst = this.inlineAttachments[i];
            if (inst[0] === scope && inst[1] === ctrl) {
                this.inlineAttachments.splice(i, 1);
                break;
            }
        }
    }

    this.invalidFileName = function(filename) {
        return validate.invalidFileName(filename);
    };

    this.validate = function() {
        var obj = { valid: true, type: 'alert' };
        var inlineAttachments = this.inlineAttachments;
        if (!inlineAttachments.length) {
            return obj;
        }

        for (var i = 0; i < inlineAttachments.length; i++) {
            var inst = inlineAttachments[i];
            var ctrl = inst[1];
            if (ctrl.fileRequired) {
                if (ctrl.isUploading) {
                    obj.valid = false;
                    obj.msg = lang.get("please-wait-your-file-is-uploading");
                    return obj;
                } else if (!ctrl.removeFileIcon) {
                    obj.valid = false;
                    obj.msg = lang.get("form-submit-validation-msg");
                    return obj;
                }
            }
        }

        for (var i = 0; i < inlineAttachments.length; i++) {
            var inst = inlineAttachments[i];
            var ctrl = inst[1];
            if (ctrl.isUploading) {
                obj.valid = false;
                obj.type = "confirm";
                obj.msg = "Warning:\nPlease wait while your file(s) is being uploaded" +
                    "\nClick on 'OK' If you wish to submit form without the pending attachment(s), or click 'Cancel' to return and complete attaching the file(s).";
                return obj;
            }
        }

        return obj;
    };
}])

.service('asyncService', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, api, Notification) {
    var asyncService = this;

    /**
     * Rets which os
     * @returns  
     * This script sets OSName variable as follows:
     * "Windows"    for all versions of Windows
     * "MacOS"      for all versions of Macintosh OS
     * "Linux"      for all versions of Linux
     * "UNIX"       for all other UNIX flavors 
     * "Unknown OS" indicates failure to detect the OS
     */
    asyncService.retWhichOS = function() {
        var nu = navigator.userAgent;
        var OSName="Unknown OS";
        if (nu.indexOf("Win")!=-1) OSName="Windows";
        if (nu.indexOf("Mac")!=-1) OSName="MacOS";
        if (nu.indexOf("X11")!=-1) OSName="UNIX";
        if (nu.indexOf("Linux")!=-1) OSName="Linux";
        return OSName;
    };

    asyncService.editFileAsync = function(data, callBackFn) {
        var editXhr = api.ajax({
            url: apiConfig.ASYNC_NOTIFICATION,
            _dcId: (data || {}).dcId,
            method: 'POST',
            data: JSON.stringify({
                calledFrom: 'form-association',
                osType : asyncService.retWhichOS(),
                documentFolderPath: data.documentFolderPath || data.filePath,
                filename: data.fileName,
                docRef: data.docRef,
                uploadFilename: data.uploadFilename,
                documentId: data.documentId || data.docId,
                folderId: data.folderId,
                projectId: data.projectId,
                revisionId: data.revisionId,
                totalFileSize: parseInt(data.fileSize.replace(' KB', ''), 10),
                description: data.description,
                purposeOfIssue: data.purposeOfIssue,
                revisionNum: data.revisionNum,
                status: data.status,
                title: data.title
            }),
            headers: { 
                'Content-Type': 'application/json', 
            },
            responseType: 'text',
        }).then(function(response) {
            editXhr = false;
            if (!response) {
                return;
            }
            
            callBackFn(response);
        }, function(err) {
            editXhr = false;
            callBackFn('');
            Notification.error({
                title: lang.get("server-error"),
                message: ''
            });
        });
    };
    
    asyncService.checkOutOnly = function(proid, selectedFileData, succFn) {
        selectedFileData = selectedFileData;
        var checkOutRevIds = [],checkOutDocIds = [];

        for (var i = 0; i < selectedFileData.length; i++) {
            checkOutRevIds.push(selectedFileData[i].revisionId);
            checkOutDocIds.push(selectedFileData[i].documentId);
        }

        var paramsObj = {
            useDirectUrl: true, 
            projectId: proid, 
            revisionId: checkOutRevIds.join(','), 
            action_id: apiConfig.REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK 
        };
    
        var cvXhr = api.ajax({
            url: apiConfig.REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK_CONTROLLER,
            _dcId: (selectedFileData[0] || {}).dcId,
            _cdnUrl: myConfig.downloadServiceURL,
            method: 'POST',
            data: paramsObj,
            contentType: 'application/json'			
        }).then(function(data) {
            if (data.validRevisionsForCheckout) {
                cvXhr = false;
                paramsObj.revisionId = data.validRevisionsForCheckout;
                paramsObj.action_id = apiConfig.CHECKOUT_REV;
                asyncService.editFileAsync(selectedFileData[0], function(editFileResp) {
                    if (editFileResp != "successful") {
                        window['openAsyncAppPopup']({
                            data : data,
                            asyncAppUrl : editFileResp.match(/href="([^"]*)/)[1] || ''
                        } , function() {
                        
                        });
                        succFn && succFn(selectedFileData);
                    } else if(!editFileResp){
                       
                    }
                });
            } else { 
                var crdXhr = api.ajax({
                    url: apiConfig.GET_CHECKOUT_REVISION_DETAILS_CONTROLLER,
                    _dcId: (selectedFileData[0] || {}).dcId,
                    _cdnUrl: myConfig.downloadServiceURL,
                    method: 'POST',
                    data: {
                        useDirectUrl: true, 
                        projectID: proid, 
                        revisionId: checkOutRevIds.join(','), 
                        action_id: apiConfig.GET_CHECKOUT_REV_DETAILS 
                    },
                    contentType: 'application/json'			
                }).then(function(data) {
                    crdXhr = false;
                    cvXhr = false;

                    var rowHtml = '';
                    if (data.alreadyCheckedOutRevisionList && data.alreadyCheckedOutRevisionList.length) { 
                        rowHtml += lang.get('document-is-already-checked-out') + ". <br/>" 
                    }

                    if (data.linkedRevisionList && data.linkedRevisionList.length) { 
                        rowHtml += lang.get('selected-document-is-link') + ". <br/>" 
                    }

                    if (data.noAccessRevisionList && data.noAccessRevisionList.length) { 
                        rowHtml += lang.get('publish-permission-not-available') + ".<br/>" 
                    }

                    if (data.notLatestRevisionList && data.notLatestRevisionList.length) { 
                        rowHtml += lang.get('document-not-access-latest-revsion-desc') + ".<br/>" 
                    }

                    if (data.paperlessRevisionList && data.paperlessRevisionList.length) { 
                        rowHtml += lang.get('document-is-paper-document-placeholder') 
                    }
                    
                    if (rowHtml.length) {
                        Notification.warning({
                            title: lang.get("adoddle"),
                            message: rowHtml
                        });
                    }
                }, function(err) {
                    crdXhr = false;
                    cvXhr = false;
                });
            }            
        }, function(err) {
            cvXhr = false;
        });

        return cvXhr;
    };

    asyncService.Notification = function() {
        
    };
}])

.service('socketService', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, api, Notification) {
    var socketService = this;
    var websocketInsts = {};
        
    socketService.connect = function(url, handleFnObj) {
        var socket = websocketInsts[url];
        if(!socket || socket.readyState === WebSocket.CLOSED) {
            socket = new WebSocket(url);
            websocketInsts[url] = socket;
        }

        socket.onopen = function(event){
            handleFnObj.onopen && handleFnObj.onopen(event);
        };
        
        socket.onmessage = function(event) {
            handleFnObj.onmessage && handleFnObj.onmessage(event);
        };

        socket.onclose = function(event) {
            socket.keepAlive();
            // handleFnObj.onclose && onclose.onclose(event);
        };

        socket.onerror = function(event) {
            socket.keepAlive();
            // handleFnObj.onerror && handleFnObj.onerror(event);
        };

        socket.keepAlive = function () {
            setTimeout(function() {
                var sessionState = localStorage.getItem('sessionState');
                if (sessionState != 'Inactive') {
                    socketService.connect(url, handleFnObj);
                }
            }, 5000);
        };

        return socket;
    }
}])

/**
 * Dropdown communication service.
 * This module will provide communication between two dropdown as service.
 * @module ddService
 */
.service('ddService', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    var openScope = null;
    var dockScope = null;

    this.getOpened = function() {
        return openScope;
    };

    this.open = function(dropdownScope, element) {
        if (!openScope && dockScope) {
            openScope = dockScope;
        }

        if (openScope && openScope !== dropdownScope && (dropdownScope.dockable || !openScope.isDock)) {
            openScope.isOpen = false;
            if (dockScope && dockScope.isDock) {
                dockScope.isOpen = false;

                $rootScope.$broadcast("dd:changed", { name: dockScope.name, visible: dockScope.isOpen, event: 'visibility' });
            }
        }

        var isDock = false;
        try {
            isDock = localStorage.getItem('dock');
            if (isDock === "true")
                isDock = true;
            else if (isDock === "false")
                isDock = false;
        } catch (e) {}

        if (dropdownScope.dockable) {
            dropdownScope.isDock = isDock;
            if (isDock) {
                dockScope = dropdownScope;
                angular.element(window).scrollTop(0);
            }
        }

        openScope = dropdownScope;

        $document.off('click', closeDropdown);
        $document.on('click', closeDropdown);
        $document.off('keydown', this.keybindFilter);
        $document.on('keydown', this.keybindFilter);
    };

    this.close = function(dropdownScope, element) {
        if (openScope === dropdownScope) {
            if (dockScope === openScope) {
                //				dockScope.isDock = false;
                dockScope = null;
            }
            openScope = null;
            $document.off('click', closeDropdown);
            $document.off('keydown', this.keybindFilter);
        }
    };

    this.closeOpenDropdown = function(dropdownScope) {
        if (openScope) {
            
            openScope.isOpen = false;
            openScope.expanded = false;
            openScope.focusToggleElement();

            if (!$rootScope.$$phase) {
                openScope.$apply();
            }
            openScope = null;
            
            if (dockScope === openScope) {
                dockScope = null;
            }
            openScope = null;
            $document.off('click', closeDropdown);
            $document.off('keydown', this.keybindFilter);
        }
    }

    this.dock = function(dropdownScope, element) {
        if (dockScope && dockScope !== dropdownScope) {
            //			dockScope.isDock = false;
            dockScope.isOpen = false;
        }
        dockScope = dropdownScope;
        $timeout(function() {
            if (!dockScope.isDock && dockScope.isOpen) {
                openScope = dropdownScope;
            }
        });

        if (dropdownScope.isDock) {
            angular.element(window).scrollTop(0);
        }
    };

    var closeDropdown = function(evt) {
        // This method may still be called during the same mouse
        // event that
        // unbound this event handler. So check openScope before
        // proceeding.
        if (!openScope || openScope.isDock || openScope.expanded) {
            return;
        }

        if (evt && openScope.getAutoClose() === 'disabled') {
            return;
        }

        if (evt && evt.which === 3) {
            return;
        }

        var toggleElement = openScope.getToggleElement();
        if (evt && toggleElement &&
            toggleElement[0].contains(evt.target)) {
            return;
        }

        var dropdownElement = openScope.getDropdownElement();
        if (evt && openScope.getAutoClose() === 'outsideClick' &&
            dropdownElement &&
            dropdownElement[0].contains(evt.target)) {
            return;
        }

        if (evt && openScope.getAutoClose() === 'outsideClick' &&
        
            $(evt.target).closest('mat-option,ngb-datepicker,mat-datepicker-content, .context-menu-list, .no-auto-close').length) {
            return;
        }

        openScope.isOpen = false;
        openScope.expanded = false;
        openScope.focusToggleElement();

        if (!$rootScope.$$phase) {
            openScope.$apply();
        }

        $rootScope.$broadcast("dd:changed", { name: openScope.name, visible: openScope.isOpen, event: 'visibility' });
        openScope = null;
    };

    this.keybindFilter = function(evt) {
        if (!openScope || openScope.isDock)
            return;
        if (evt.which === 27) {
            evt.stopPropagation();
            openScope.focusToggleElement();
            closeDropdown();
        } else if (openScope.isKeynavEnabled() && [38, 40].indexOf(evt.which) !== -1 &&
            openScope.isOpen && !openScope.isDock) {
            evt.preventDefault();
            evt.stopPropagation();
            openScope.focusDropdownEntry && openScope.focusDropdownEntry(evt.which);
        }
    };
}])

/**
 * htmlformservice service.
 * This module will provide distribution to html apps as service.
 * @module htmlformservice
 */
.service('htmlformservice', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    this.distSelect;
    this.associateCloseCompleate;
    this.associateLocationComplete;
    this.associateDeleteCompleate;
    this.assocFileService;
    
    this.registerDistSelectScope = function(scope) {
        this.distSelect = scope;
    }

    /**
     * To get associatedLocation data in HTML5 form.
     * This callback function called after Location associted completed
     * Which returns newly associated object and association scope 
     * this.associateLocationComplete need to define in Custom HTML5 form's js. i.e weekly.checklist.js
     */
    this.associateLocationCallback = function(args) {
        this.associateLocationComplete && this.associateLocationComplete(args);
    }

    /**
     * To get associated data in HTML5 form.
     * This callback function called after associted completed
     * Which returns newly associated object and association scope 
     * this.associateCloseCompleate need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.associateAndCloseCallback = function(args) {
        this.associateCloseCompleate && this.associateCloseCompleate(args);
    }

    /**
     * Handle remove associate callback.
     * Which returns removed object and listing scope 
     * this.associateDeleteCompleate need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.associateDeleteCallback = function(args) {
        this.associateDeleteCompleate && this.associateDeleteCompleate(args);
    }

    /**
     * Handler used to get association's scope and ctrl object from assoc.data.tab.js
     * this.assocFileService need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.assocFileHandler = function(scope, ctrl){
        this.assocFileService = {
            scope: scope, ctrl: ctrl
        };
    }
}])