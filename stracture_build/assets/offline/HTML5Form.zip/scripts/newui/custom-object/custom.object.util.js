/**
 * Custom object common utility services
 */
angular.module("adoddle").service('customObjectUtil', ['$window', '$rootScope', '$timeout', 'Notification', 'apiConfig', 'myConfig', 'api', 'lang', 'ddchild',
function($window, $rootScope, $timeout, Notification, apiConfig, myConfig, api, lang, ddchild) {
    var customObjectUtil = this;
    var customObjectTypeMap = {
        MODEL_BCF_ISSUE: {
            customObjectTemplateGroupId: 1,
            getTemplateDetails : 'getBCFIssueTemplateDetails',
            fetchAndGetTemplateDetails: 'fetchAndGetBCFIssueTemplateDetails',
        }
    };
    var templateLanguageKeys = ['customObjectTitle', 'customObjectDesc', 'customObjectCreateTitle',
        'customObjectCreateButtonText', 'customObjectEditTitle'];

    function compareId(hashId1, hashId2) {
        var id1 = (hashId1 || '').toString().split('$$')[0];
        var id2 = (hashId2 || '').toString().split('$$')[0];
        return id1 == id2;
    }

    customObjectUtil.findTemplate = function(type, data) {
        if(!data || !data.templates || !data.templates.length) {
            return;
        }
        var customObjectTemplate;
        var customObjectTemplateGroupId = customObjectTypeMap[type].customObjectTemplateGroupId;
        data.templates.some(function(template){
            if(compareId(template.customObjectTemplateGroupId, customObjectTemplateGroupId)) {
                customObjectTemplate = template;
                return true;
            }
        });
        return customObjectTemplate;
    };

    function parseTemplateLanguageDetails(details){
        var parsedDetails = {};

        for(var i = 0; i < templateLanguageKeys.length; i++) {
            var key = templateLanguageKeys[i];
            var langKey = details[key];
            if(langKey) {
                parsedDetails[key] = lang.get(langKey) || langKey;
            }
        }

        return parsedDetails;
    }

    function exportBCFIssues(action, selectedItems, templateDetails){
        var requestData = {
            customObject: JSON.stringify({
                customObjectTemplateId: templateDetails.customObjectTemplateId,
                customObjectTemplateGroupId: templateDetails.customObjectTemplateGroupId,
                customObjectTemplateTypeId: templateDetails.customObjectTemplateTypeId,
                projectId: myConfig.projectId,
                entityId: myConfig.model_id,
                customObjectContextId: apiConfig.customObject.MODEL_CONTEXT_ID
            })
        };

        if(action.enableOnRowSelection && selectedItems) {
            requestData.selectedIssueIds = selectedItems.map(function(item){
                return item.customObjectInstanceId;
            }).join(',');
        }

        Notification.clearAll();
        Notification.success({
            message: '<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>',
            delay: 'no'
        });

        var xhr = api.ajax({
            url: apiConfig.PREPARE_EXPORT_BCF_ISSUE,
            data: requestData
        });

        xhr.then(function(data) {
            xhr.downloadFailed = false;
            window.setTimeout(function(){
                if(!xhr.downloadFailed) {
                    Notification.clearAll();
                }
            }, 2000);
            jQuery.fileDownload(apiConfig.EXPORT_BCF_ISSUE, {
                httpMethod: 'POST',
                data: data,
                failCallback: function(){
                    xhr.downloadFailed = true;
                    Notification.clearAll();
                    Notification.error('<div class="bold-msg text-center">' + 'Export failed.  Please try again later.' + '</div>');
                }
            });
        }, function(xhr) {
            Notification.clearAll();
            Notification.error('<div class="bold-msg text-center">' + 'Export failed.  Please try again later.' + '</div>');
        });

    }

    customObjectUtil.getBCFIssueTemplateDetails = function(type, customObjectTemplate){
        var defaultDetails = {
            type: type,
            canAccess: false,
            disabled: false,
            viewOnly: true,
            viewIssueFilter: true,
            errorMsg: lang.get('no-access'),
            customObjectTemplateId: '',
            customObjectTemplateGroupId: '',
            customObjectTemplateTypeId: '',
            config: {
                entityId: ''
            }
        };

        if(!customObjectTemplate) {
            return defaultDetails;
        }
        /**
         * use when revit and ifc both are handled for issue manager
         * var isDisabled = myConfig.fileExt.toLowerCase() != "ifc" && myConfig.fileExt.toLowerCase() != "rvt"; 
         */
         var isDisabled = true;
        var viewOnly = true;
        if($window.SYSTEMPRIVILEGES && $window.viewerProjectId) {
            var privileges = $window.SYSTEMPRIVILEGES.userPrivileges[$window.viewerProjectId];
            if(api.hasAccess(privileges, 'CAN_CREATE_ISSUE')) {
                viewOnly = false;
            }
        }

        var templateDetails = {
            type: type,
            canAccess: true,
            disabled: isDisabled,
            viewOnly: viewOnly,
            viewIssueFilter: true,
            errorMsg: lang.get('fileTypeNotAllowed'),
            templateLanguageDetails: parseTemplateLanguageDetails(customObjectTemplate.templateLanguageDetails),
            customObjectTemplateId: customObjectTemplate.customObjectTemplateId,
            customObjectTemplateGroupId: customObjectTemplate.customObjectTemplateGroupId,
            customObjectTemplateTypeId: customObjectTemplate.customObjectTemplateTypeId,
            config: {
                entityId: myConfig.model_id
            }
        };

        var actionHandler = function(action, selectedItems) {
            exportBCFIssues(action, selectedItems, templateDetails);
        };

        if(!viewOnly) {
            templateDetails.config.vertMoreActions = [{
                name: 'export-selected',
                label: 'Export Selected',
                enableOnRowSelection: true,
                actionHandler: actionHandler
            }, {
                name: 'export-all',
                label: 'Export All',
                enableOnRowSelection: false,
                actionHandler: actionHandler
            }];
        }
        return templateDetails;
    };

    customObjectUtil.fetchAndGetBCFIssueTemplateDetails = function(type, callback){
        // 3 MODEL context
        api.getCustomObjectTemplateList(function(data){
            var customObjectTemplate = customObjectUtil.findTemplate(type, data);
            callback(customObjectUtil.getBCFIssueTemplateDetails(type, customObjectTemplate));
        }, apiConfig.customObject.MODEL_CONTEXT_ID);
    };

    customObjectUtil.getTemplateDetails = function(type, customObjectTemplate){
        var mapValue = customObjectTypeMap[type];
        if(!mapValue) {
            return {
                type: type,
                canAccess: false,
            };
        }

        return customObjectUtil[mapValue.getTemplateDetails](type, customObjectTemplate);
    };

    customObjectUtil.fetchAndGetTemplateDetails = function(type, callback){
        var mapValue = customObjectTypeMap[type];
        if(!mapValue) {
            callback(customObjectUtil.getTemplateDetails(type));
            return;
        }

        return customObjectUtil[mapValue.fetchAndGetTemplateDetails](type, callback);
    };

    customObjectUtil.navigateToCustomObjectInstance = function(details, delay){
        var navigate = function(){
            $rootScope.$broadcast('dd:open', {
                name: 'custom-object-view',
                type: details.type,
                templateLanguageDetails: details.templateLanguageDetails,
                customObjectTemplateId: details.customObjectTemplateId,
                customObjectTemplateGroupId: details.customObjectTemplateGroupId,
                customObjectTemplateTypeId: details.customObjectTemplateTypeId,
                customObjectInstanceId: $window.customObjectInstanceId,
                urlNavigation: true,
                dockTitle: details.templateLanguageDetails.customObjectTitle
            });
        };

        var checkAndNavigate = function(){
            if(ddchild.isLoaded('custom-object-view')) {
                navigate();
                return;
            }

            ddchild.onLoad('custom-object-view', function(){
                navigate();
            });
        };

        // On page load navigation
        if(details.canAccess && $window.customObjectTemplateGroupId && $window.customObjectInstanceId
            && compareId(details.customObjectTemplateGroupId, $window.customObjectTemplateGroupId)) {
                if(!delay) {
                    checkAndNavigate();
                    return;
                }
                $timeout(checkAndNavigate, delay);
        }
    };
    
}])