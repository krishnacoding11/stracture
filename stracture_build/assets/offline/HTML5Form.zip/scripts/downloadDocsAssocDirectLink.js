/*
 * downloadZipFile with Status check on interval is started from here.
 * with downloadWithStatusOnInterval.start() method.
 * @param needed in Fun : 
 *
 * "projectId", "nonCDNDownloadUrl", "isLimitExist", "sourcePath", "fileName", "count", "baseUrl" further.
 *
 * Author : Himesh Aadeshara. 
 *
 */

var downloadWithStatusOnInterval = (function(obj){

	var _base = {

		// /*
		//  * _CONSTANTS object's constants are same as available in adoddle_global_constant.js
		//  */
		//
		// _CONSTANTS : {
		//
		// 	DOWNLOAD_CONTROLLER : "/adoddle/download",
		//	CHECK_FOR_AKAMAI_DOWNLOAD_LIMIT: 193, 
		//	CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT:198,
		//  MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION: 168,
		// 	PROGRESS_ZIP_CREATION : 126,
		// 	DOWNLOAD_TEMP_ZIP_FILE: 125,
		//
		//
		// },

		/*
		 * _init : function will start from here.
		 */

		_init : function(obj){	

			var that = this;	

			//that.checkStatusAndDownloadZip();	
			that.neededParams = obj;  
			that.downloadDocsAssocDirectLink(obj.downloadRevDocListJSON);

		},

		neededParams:{},

		downloadDocsAssocDirectLink : function(downloadRevDocListJSON){			
			var param = { revisions: [] }, 
				selectedRowsData=JSON.parse(downloadRevDocListJSON),
				selectedRowsProjIds = '',
				docData = null,
				isFromDirectLink = true;

			loadingImageBar(true, jQuery('body'), true, 1);

			jQuery(".loading").css({
				opacity: 0.45,
				background: "#333"
			});
			
			if(selectedRowsData.length == 0){
				loadingImageBar(false, jQuery("body"), false, 1);
				ADODDLE.alert({ 
					title:Language.get("adoddle"),
					msg: Language.get("no-document-associations-found") 
				});
				return false;
			}else {
				for(var i=0;i<selectedRowsData.length;i++) {
					docData = selectedRowsData[i];					
					param.revisions.push({
						revisionId: docData.revisionId, 
						isLock: docData.isLock, 
						dcId: docData.dcId, 
						projectId: docData.projectId,
						hasMarkup: docData.hasMarkup,
						hasAttachment: docData.hasAttachment,
						zipFileName: docData.zipFileName
					});
					if(selectedRowsProjIds.indexOf(docData.projectId) === -1){
						selectedRowsProjIds += docData.projectId + ',';							
					}					
				}
				if(param.revisions.length > 0 || downloadAllFiles){
					this.neededParams.selectedProjIds = selectedRowsProjIds;
					this.identifyDownloadType(param, "", "", isFromDirectLink);	
				}
			}
		},

		identifyDownloadType : function(param,byPassParam,isFromAttachment, isFromDirectLink){
			param.revisions[0] = param.revisions[0] || {};
			var projectId = param.revisions[0].projectId,
				downloadDocDcId = param.revisions[0].dcId,
				callForm,
				isDiffProject = false,
				selParam = {
					revisions:[]
				};
			fileBasicDetail = param.revisions;
			for(var key in param.revisions){
				var allData = param.revisions[key];
				if(!isDiffProject && projectId != allData.projectId){
					isDiffProject = true;
				}
				selParam.revisions.push({
					revisionId: allData.revisionId, 
					isLock: allData.isLock, 
					dcId: allData.dcId, 
					projectId: allData.projectId
				});
			}
			callForm = isDiffProject ? "MultiProjectDownload" : "DownloadBtn";
			this.revisionForNonAkamai=selParam;			
			if(selParam.revisions.length > 0){
				this.displayDownloadPage(selParam,projectId,downloadDocDcId,callForm,byPassParam,isFromAttachment, isFromDirectLink);
			}
		},

		displayDownloadPage : function(param,projectId,downloadDocDcId,callForm,byPassParam,isFromAttachment,isFromDirectLink){
			var that=this;
			this.downloadDocProjectId=projectId;
			this.downloadDocDcId=parseInt(downloadDocDcId);
			this.byPassParam=( byPassParam?byPassParam:{} );
			this.isMultiProject=false;
			this.revisionIds="";/* it use for clearing For Information action when file from same project*/
			for(var i=0,len=param.revisions.length,obj;i<len;i++){
				obj=param.revisions[i];
				this.revisionIds+=obj.revisionId + ",";
			}

			if(isFromDirectLink){
				updateBasedDomain(this.downloadDocDcId);
				var paramsObj= {
					extra: JSON.stringify(param),
					//projectIds: this.neededParams.selectedProjIds,
					projectID: this.downloadDocProjectId,
					isFromDirectLink : isFromDirectLink,
					includeInternalAttachment : this.neededParams.downloadSecondaryFile,
					useDirectUrl: true
				};

				var oldURL=globalBasedDomain;

				if(that.neededParams.isLimitExist){
					globalBasedDomain = that.neededParams.nonCDNDownloadUrl;
				}

				$(".loading").css({
					opacity: 0.45,
					background: "#333"
				});

				var obj = {};

				var SelectedData = JSON.parse(paramsObj.extra);
				filesSelectedRowsData = SelectedData.revisions;
				
				var Errorcode = [];
				for ( var i = 0; i < filesSelectedRowsData.length; i++) {
						var file = filesSelectedRowsData[i];
						if( !obj[file.dcId] ) {
							obj[file.dcId] = {};
							if( !obj[file.dcId].revisions ) {
								obj[file.dcId].revisions = [];
							}
						}	
						var projectObj = {
							"projectId": file.projectId,
							"revisionId": file.revisionId,
							"dcId" : file.dcId,
							"isLock":file.isLock,
						};
						obj[file.dcId].revisions.push(projectObj);
				}

				var apiUrl = computeDcWiseBaseUrl(window.downloadServiceURL) + ADODDLE.CONSTANT.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER;

			 	makeAsyncAjaxCall(paramsObj,apiUrl,'POST', 'json', null, function(data){			
			 		loadingImageBar(false, jQuery('body'), false, 1);
			 		that.checkStatusAndDownloadZip(data, isFromDirectLink);	
			 	}, function(xhr, textStatus, errorThrown){
					loadingImageBar(false, jQuery('body'), false, 1);
					ADODDLE.alert({ 
						title:"Server Error", 
						msg: Language.get("error-while-processing-your-request") 
					});
				});


			    globalBasedDomain=oldURL;
			
			}			
		},


		/*
		 * checkStatusAndDownloadZip function will check status to download zip file until c_number with -1 with 1000 Time Interval.
		 * will need a @param : 
		 * form for downloadZipFile will continuer.
		 */

		checkStatusAndDownloadZip : function(data, isFromDirectLink){			
			var that=this;
			var isErrorOcccured = false;
			var $downloadProgressBarModal = jQuery("#myModal-downloadProgressBar");
			$downloadProgressBarModal.modal('show');
			var counter = 0;
			var progress = setInterval(function() {							
				var $bar = $downloadProgressBarModal.find('.bar');
				if (counter == -100) {
					clearInterval(progress);

					var dataToSend = {
						project_id : projectId,
						count: data.c_number,
						fileName : data.fileName,
						isForDirectLink : isFromDirectLink,
						sourcePath : data.sourcePath
					};

					that.getAndDownloadZip(dataToSend);							

				} else {

					var paramsObj= {
						zipFile: data.fileName,									
						projectID: projectId,
						useDirectUrl: true
					};	

					var apiUrl = computeDcWiseBaseUrl(window.downloadServiceURL) + ADODDLE.CONSTANT.PROGRESS_ZIP_CREATION_CONTROLLER;

					makeAsyncAjaxCall(paramsObj,apiUrl,'GET', 'json', null, function(data){
						if(!isErrorOcccured){								
							if(data.c_number == '-1'){
								counter = -100;
								var comWidth = $downloadProgressBarModal.find('.progress').width(); 
								$bar.width(comWidth);
								$bar.text(100 + "%");
							}else if(counter<90 && data.c_number != '-1'){										
								counter = data.c_number;
								$bar.width(counter*5.33);
								$bar.text(counter + "%");
							}
						}
					}, function(xhr, textStatus, errorThrown){
						isErrorOcccured = true; 
						clearInterval(progress);
						ADODDLE.alert({ 
							title:"Server Error", 
							msg: Language.get("error-while-processing-your-request") 
						});
					});

				}
			}, 1000);		
		},

		/*
		 * getAndDownloadZip will submit a form for the content with having urlAction and dataToSend parameters from where it called.
		 * will need 
		 * @param : urlAction 	(url to submit form)
		 			dataToSend	(having data append with form like "action_id", "projectId", "count", "fileName", "sourcePath" ).
		 *					 
		 */

		getAndDownloadZip: function(dataToSend){				
			var that = this;
			var apiUrl = computeDcWiseBaseUrl(window.downloadServiceURL) + ADODDLE.CONSTANT.DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER;

			var $iFrame = jQuery('<iframe class="hide" style="display:none;" name="docAssocDirectLinkIFrame" src="" id="docAssocDirectLinkIFrame"></iframe>'),
				$form = jQuery('<form target="docAssocDirectLinkIFrame" method="GET" action="' + apiUrl + '">');
			jQuery.each(dataToSend, function(k,v){
				$form.append('<input type="hidden" name="' + k + '" value="' + v + '">');
			});


			jQuery('body').append($iFrame);
			jQuery('body').append($form);

			var nonCDNDownloadUrl = that.neededParams.nonCDNDownloadUrl; 
			if(that.neededParams.isLimitExist){
				$form.attr('action',nonCDNDownloadUrl+ADODDLE.CONSTANT.DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER);
			}

			// to remove the loading bar for download.
			var $downloadProgressBarModal = jQuery("#myModal-downloadProgressBar");
			var $bar = $downloadProgressBarModal.find('.bar');

			$downloadProgressBarModal.modal('show');
			$downloadProgressBarModal.find('.progress').removeClass('active');
			$downloadProgressBarModal.modal('hide');

			$bar.width(0);
			$bar.text("");
			
			$form.submit();

			//.remove();			
			// setTimeout(function() {
			// 	window.close();
			// }, 500)			

		}
	};

	return{

		start : function(obj){
			_base._init(obj);
		}

	}

})();

