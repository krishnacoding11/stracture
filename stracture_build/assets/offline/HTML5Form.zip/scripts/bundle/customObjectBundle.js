/**
 * Custom object common utility services
 */
angular.module("adoddle").service('customObjectUtil', ['$window', '$rootScope', '$timeout', 'Notification', 'apiConfig', 'myConfig', 'api', 'lang', 'ddchild',
function($window, $rootScope, $timeout, Notification, apiConfig, myConfig, api, lang, ddchild) {
    var customObjectUtil = this;
    var customObjectTypeMap = {
        MODEL_BCF_ISSUE: {
            customObjectTemplateGroupId: 1,
            getTemplateDetails : 'getBCFIssueTemplateDetails',
            fetchAndGetTemplateDetails: 'fetchAndGetBCFIssueTemplateDetails',
        }
    };
    var templateLanguageKeys = ['customObjectTitle', 'customObjectDesc', 'customObjectCreateTitle',
        'customObjectCreateButtonText', 'customObjectEditTitle'];

    function compareId(hashId1, hashId2) {
        var id1 = (hashId1 || '').toString().split('$$')[0];
        var id2 = (hashId2 || '').toString().split('$$')[0];
        return id1 == id2;
    }

    customObjectUtil.findTemplate = function(type, data) {
        if(!data || !data.templates || !data.templates.length) {
            return;
        }
        var customObjectTemplate;
        var customObjectTemplateGroupId = customObjectTypeMap[type].customObjectTemplateGroupId;
        data.templates.some(function(template){
            if(compareId(template.customObjectTemplateGroupId, customObjectTemplateGroupId)) {
                customObjectTemplate = template;
                return true;
            }
        });
        return customObjectTemplate;
    };

    function parseTemplateLanguageDetails(details){
        var parsedDetails = {};

        for(var i = 0; i < templateLanguageKeys.length; i++) {
            var key = templateLanguageKeys[i];
            var langKey = details[key];
            if(langKey) {
                parsedDetails[key] = lang.get(langKey) || langKey;
            }
        }

        return parsedDetails;
    }

    function exportBCFIssues(action, selectedItems, templateDetails){
        var requestData = {
            customObject: JSON.stringify({
                customObjectTemplateId: templateDetails.customObjectTemplateId,
                customObjectTemplateGroupId: templateDetails.customObjectTemplateGroupId,
                customObjectTemplateTypeId: templateDetails.customObjectTemplateTypeId,
                projectId: myConfig.projectId,
                entityId: myConfig.model_id,
                customObjectContextId: apiConfig.customObject.MODEL_CONTEXT_ID
            })
        };

        if(action.enableOnRowSelection && selectedItems) {
            requestData.selectedIssueIds = selectedItems.map(function(item){
                return item.customObjectInstanceId;
            }).join(',');
        }

        Notification.clearAll();
        Notification.success({
            message: '<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>',
            delay: 'no'
        });

        var xhr = api.ajax({
            url: apiConfig.PREPARE_EXPORT_BCF_ISSUE,
            data: requestData
        });

        xhr.then(function(data) {
            xhr.downloadFailed = false;
            window.setTimeout(function(){
                if(!xhr.downloadFailed) {
                    Notification.clearAll();
                }
            }, 2000);
            jQuery.fileDownload(apiConfig.EXPORT_BCF_ISSUE, {
                httpMethod: 'POST',
                data: data,
                failCallback: function(){
                    xhr.downloadFailed = true;
                    Notification.clearAll();
                    Notification.error('<div class="bold-msg text-center">' + 'Export failed.  Please try again later.' + '</div>');
                }
            });
        }, function(xhr) {
            Notification.clearAll();
            Notification.error('<div class="bold-msg text-center">' + 'Export failed.  Please try again later.' + '</div>');
        });

    }

    customObjectUtil.getBCFIssueTemplateDetails = function(type, customObjectTemplate){
        var defaultDetails = {
            type: type,
            canAccess: false,
            disabled: false,
            viewOnly: true,
            viewIssueFilter: true,
            errorMsg: lang.get('no-access'),
            customObjectTemplateId: '',
            customObjectTemplateGroupId: '',
            customObjectTemplateTypeId: '',
            config: {
                entityId: ''
            }
        };

        if(!customObjectTemplate) {
            return defaultDetails;
        }
        /**
         * use when revit and ifc both are handled for issue manager
         * var isDisabled = myConfig.fileExt.toLowerCase() != "ifc" && myConfig.fileExt.toLowerCase() != "rvt"; 
         */
         var isDisabled = true;
        var viewOnly = true;
        if($window.SYSTEMPRIVILEGES && $window.viewerProjectId) {
            var privileges = $window.SYSTEMPRIVILEGES.userPrivileges[$window.viewerProjectId];
            if(api.hasAccess(privileges, 'CAN_CREATE_ISSUE')) {
                viewOnly = false;
            }
        }

        var templateDetails = {
            type: type,
            canAccess: true,
            disabled: isDisabled,
            viewOnly: viewOnly,
            viewIssueFilter: true,
            errorMsg: lang.get('fileTypeNotAllowed'),
            templateLanguageDetails: parseTemplateLanguageDetails(customObjectTemplate.templateLanguageDetails),
            customObjectTemplateId: customObjectTemplate.customObjectTemplateId,
            customObjectTemplateGroupId: customObjectTemplate.customObjectTemplateGroupId,
            customObjectTemplateTypeId: customObjectTemplate.customObjectTemplateTypeId,
            config: {
                entityId: myConfig.model_id
            }
        };

        var actionHandler = function(action, selectedItems) {
            exportBCFIssues(action, selectedItems, templateDetails);
        };

        if(!viewOnly) {
            templateDetails.config.vertMoreActions = [{
                name: 'export-selected',
                label: 'Export Selected',
                enableOnRowSelection: true,
                actionHandler: actionHandler
            }, {
                name: 'export-all',
                label: 'Export All',
                enableOnRowSelection: false,
                actionHandler: actionHandler
            }];
        }
        return templateDetails;
    };

    customObjectUtil.fetchAndGetBCFIssueTemplateDetails = function(type, callback){
        // 3 MODEL context
        api.getCustomObjectTemplateList(function(data){
            var customObjectTemplate = customObjectUtil.findTemplate(type, data);
            callback(customObjectUtil.getBCFIssueTemplateDetails(type, customObjectTemplate));
        }, apiConfig.customObject.MODEL_CONTEXT_ID);
    };

    customObjectUtil.getTemplateDetails = function(type, customObjectTemplate){
        var mapValue = customObjectTypeMap[type];
        if(!mapValue) {
            return {
                type: type,
                canAccess: false,
            };
        }

        return customObjectUtil[mapValue.getTemplateDetails](type, customObjectTemplate);
    };

    customObjectUtil.fetchAndGetTemplateDetails = function(type, callback){
        var mapValue = customObjectTypeMap[type];
        if(!mapValue) {
            callback(customObjectUtil.getTemplateDetails(type));
            return;
        }

        return customObjectUtil[mapValue.fetchAndGetTemplateDetails](type, callback);
    };

    customObjectUtil.navigateToCustomObjectInstance = function(details, delay){
        var navigate = function(){
            $rootScope.$broadcast('dd:open', {
                name: 'custom-object-view',
                type: details.type,
                templateLanguageDetails: details.templateLanguageDetails,
                customObjectTemplateId: details.customObjectTemplateId,
                customObjectTemplateGroupId: details.customObjectTemplateGroupId,
                customObjectTemplateTypeId: details.customObjectTemplateTypeId,
                customObjectInstanceId: $window.customObjectInstanceId,
                urlNavigation: true,
                dockTitle: details.templateLanguageDetails.customObjectTitle
            });
        };

        var checkAndNavigate = function(){
            if(ddchild.isLoaded('custom-object-view')) {
                navigate();
                return;
            }

            ddchild.onLoad('custom-object-view', function(){
                navigate();
            });
        };

        // On page load navigation
        if(details.canAccess && $window.customObjectTemplateGroupId && $window.customObjectInstanceId
            && compareId(details.customObjectTemplateGroupId, $window.customObjectTemplateGroupId)) {
                if(!delay) {
                    checkAndNavigate();
                    return;
                }
                $timeout(checkAndNavigate, delay);
        }
    };
    
}])
angular.module("adoddle").component('customObjectView', {
	templateUrl: '/adoddle/view/newui/custom-object/custom.object.view.jsp',
	controller: ['$rootScope', '$scope', '$timeout', 'Notification', 'lang', 'api', 'apiConfig', 'myConfig', '$window', '$element', 'ddchild',
	function ($rootScope, $scope, $timeout, Notification, lang, api, apiConfig, myConfig, $window, $element, ddchild) {
		var ctrl = this;
		var added = false;
		var customObjectViewComponent;

		var commentCreateTitleActionsContainerEl;
		var modelCommentTitleActionsContainerEl;
		var fileHistoryTitleActionsContainerEl;
		var workflowTitleActionsContainerEl;
		var customObjectInstanceId = '';
		var clearPendingSelectModelView = null;
		var defaultOpenedTab = null;
		var dataEditedAfterOpen = false;

		$scope.expanded = false;
		$scope.loading = true;
		$scope.refreshing = false;
		$scope.statusClosed = false;
		$scope.showCommentCreate = false;
		$scope.workflowParam = {};
		$scope.activeTab = '';
		$scope.tabs = {};
		$scope.priv = {
			canCreateComment: false,
			canDownloadFile: false,
			canManageObjectList: true
		};
		$scope.captureModelViewOnComment = false;
		$scope.modelData = angular.extend({}, myConfig.modelData);
		$scope.modelData.commentParam = {
			controller: apiConfig.CREATE_CUSTOM_OBJECT_COMMENT,
			isTemplateDetailReq: false
		};
		$scope.historyData = {
			param: {}
		};

		ctrl.$onInit = function () {
			setDefaults();
			listen();
			ddchild.register($scope, 'custom-object-view');
		};

		$scope.backToList = function() {
			navigateToList();
		};

		ctrl.refresh = function() {
			if(customObjectViewComponent) {
				$scope.refreshing = true;
				customObjectViewComponent.instance.refresh();
			}
		};

		$scope.openTab = function(tabName, refreshView) {
			defaultOpenedTab = null;

			if($scope.activeTab == tabName) {
				return;
			}

			$scope.activeTab = tabName;

			if(refreshView) {
				ctrl.refresh();
			}

			if($scope.activeTab == 'comments') {
				$scope.showCommentCreate = false;
				putTitleActions(modelCommentTitleActionsContainerEl, '#modelComment .title-sub-actions');
				return;
			}
			if($scope.activeTab == 'workflows') {
				putTitleActions(workflowTitleActionsContainerEl, '#workflowList .title-sub-actions');
				return;
			}
			if($scope.activeTab == 'history') {
				putTitleActions(fileHistoryTitleActionsContainerEl, '#fileHistory .title-sub-actions');
				return;
			}
		};

		$scope.openCommentCreate = function() {
			$rootScope.$broadcast("custom-object:comment:opencreate");
			$scope.showCommentCreate = true;
			putTitleActions(commentCreateTitleActionsContainerEl, '#createComment .title-sub-actions');
		};

		$scope.commentCreationClosed = function() {
			$scope.showCommentCreate = false;
		};

		$scope.commentCreatedSuccess = function() {
			$scope.showCommentCreate = false;
			$rootScope.$broadcast('custom-object:comment:refresh');
		};

		var listen = function () {
			$scope.$on('dd:changed', onDDOpenClose);
			$scope.$on('custom-object:view:refresh', function() {
				ctrl.refresh();
			});
		};

		var setDefaults = function() {
			$scope.tabs = {
				comments: false,
				workflows: false,
				history: false,
				attachments: false,
				views: false,
				links: false
			};
			var defaultsData = {
				title: '',
				open: true,
				view: '',
				treeSelection: "",
				listSelection: [],
				modelName: "",
				listXhr: false,
				list: undefined,
			};

			ctrl.assocViewsData = angular.extend({}, defaultsData, {
				active: 4,
				views: {
					data: [],
					hasDetails: true,
					noDeleteAction: true,
					deleteNotAllowed: true,
					index: 4
				},
			});

			ctrl.assocAttachmentsData = angular.extend({}, defaultsData, {
				active: 8,
				customObjectAttachments: {
					data: [],
					noDeleteAction: true,
					deleteDisabled: true,
					index: 8
				},
			});

			ctrl.assocLinksData = angular.extend({}, defaultsData, {
				active: 9,
				links: {
					data: [],
					noDeleteAction: true,
					deleteDisabled: true,
					index: 9
				},
			});
		};

		// invoke on dropdown open / close
		var closeTimeout = undefined;
		var prevVisible = undefined;
		var onDDOpenClose = function (event, dd) {
			if(!dd || dd.name == "custom-object-list") {
				return;
			}

			if(dd && dd.name == 'custom-object-view') {
				$scope.expanded = dd.expanded || false;
			}

			if(dd.name == 'custom-object-view' && (dd.event == 'size' || dd.event == 'dock')) {
				setTimeout(function() {
					if(customObjectViewComponent) {
						customObjectViewComponent.instance.resize();
					}
				}, 300);
			}

			if(dd.name == 'custom-object-view' && dd.event == 'visibility') {
				if(prevVisible == dd.visible) {
					return;
				}
				if(dd.visible) {
					$timeout.cancel(closeTimeout);
					render(dd);
				} else {
					$timeout.cancel(closeTimeout);
					closeTimeout = $timeout(function() {
						destroy();
					}, 500);
				}
				prevVisible = dd.visible;
			} else if(dd.name != "custom-object-view") {
				$timeout.cancel(closeTimeout);
			}
		};

		var destroy = function() {
			if(!added) {
				return;
			}

			$scope.loading = true;
			$scope.statusClosed = false;
			$scope.showCommentCreate = false;
			$scope.captureModelViewOnComment = false;
			$scope.activeTab = '';
			added = false;
			customObjectInstanceId = '';
			$scope.workflowTargetObjectId = {};

			if(customObjectViewComponent) {
				customObjectViewComponent.destroy();
				customObjectViewComponent = null;
			}

			setDefaults();
			if(clearPendingSelectModelView) {
				clearPendingSelectModelView();
				clearPendingSelectModelView = null;
			}
			$scope.$apply();
		};

		var openTabIfNoActiveTab = function(tabName){
			if((!defaultOpenedTab || defaultOpenedTab == tabName) && !$scope.activeTab) {
				$scope.openTab(tabName);
			}
		};

		var setPrivileges = function() {
			$scope.priv.canCreateComment = false;

			if($window.SYSTEMPRIVILEGES && myConfig.projectId) {
				var privileges = $window.SYSTEMPRIVILEGES.userPrivileges[myConfig.projectId];
				if(api.hasAccess(privileges, 'CAN_CREATE_ISSUE_COMMENT')) {
					$scope.priv.canCreateComment = true;
				}
			}
		};

		var render = function (dd) {
			destroy();

			if(dd.isFromForm) {
				if(dd.dataChanged) {
					dataEditedAfterOpen = true;
				}
			}
			else {
				dataEditedAfterOpen = false;
			}
			
			defaultOpenedTab = dd.defaultOpenedTab || null;
			customObjectInstanceId = dd.customObjectInstanceId || '';
			setPrivileges();

			if(added) {
				$scope.$apply();
				return;
			}

			if(!commentCreateTitleActionsContainerEl) {
				commentCreateTitleActionsContainerEl = $element.find('#commentCreateTitleActions');
			}
			if(!modelCommentTitleActionsContainerEl) {
				modelCommentTitleActionsContainerEl = $element.find('#modelCommentTitleActions');
			}
			if(!fileHistoryTitleActionsContainerEl) {
				fileHistoryTitleActionsContainerEl = $element.find('#fileHistoryTitleActions');
			}
			if(!workflowTitleActionsContainerEl) {
				workflowTitleActionsContainerEl = $element.find('#workflowTitleActions');
			}
			added = true;

			appendCustomObjectForm(dd);
		};

		var editCustomObject = function(item) {
			$rootScope.$broadcast('dd:close', { name: 'custom-object-view', expanded: $scope.expanded, force: true });
			$rootScope.$broadcast('dd:open', {
				name: 'custom-object-form',
				expanded: $scope.expanded,
				type: ctrl.type,
				isFromView: true,
				fromViewActiveTab: $scope.activeTab,
				viewOnly: ctrl.viewOnly,
				templateLanguageDetails: ctrl.templateLanguageDetails,
				templateId: ctrl.templateId,
				templateGroupId: ctrl.templateGroupId,
				templateTypeId: ctrl.templateTypeId,
				config: ctrl.config,
				customObjectInstanceId: item.customObjectInstanceId,
				dockTitle: ctrl.templateLanguageDetails.customObjectEditTitle
			});
		};

		var navigateToList = function(){
			$rootScope.$broadcast('dd:close', { name: 'custom-object-view', expanded: $scope.expanded, force: true });
			$rootScope.$broadcast('dd:open', {
				name: 'custom-object-list',
				expanded: $scope.expanded,
				'type': ctrl.type,
				'isFromView': true,
				'dataChanged': dataEditedAfterOpen || false,
				'viewOnly': ctrl.viewOnly,
				'templateLanguageDetails': ctrl.templateLanguageDetails,
				'templateId': ctrl.templateId,
				'templateGroupId': ctrl.templateGroupId,
				'templateTypeId': ctrl.templateTypeId,
				'config': ctrl.config
			});
		};

		var appendCustomObjectForm = function(dd) {
			var $el = $element.find('#customObjectView');
			var component = window.createDynamicAngularComponent('adoddle-custom-object-view', {
				projectId: myConfig.projectId,
				entityId: ctrl.config.entityId,
				dcId: myConfig.LOCAL_DC_ID,
				type: ctrl.type,
				viewOnly: ctrl.viewOnly,
				templateLanguageDetails: ctrl.templateLanguageDetails,
				templateId: ctrl.templateId,
				templateGroupId: ctrl.templateGroupId,
				templateTypeId: ctrl.templateTypeId,
				objectInstanceId: customObjectInstanceId
			}, $el[0]);
			customObjectViewComponent = component;

			component.instance.onLoaded.subscribe(function(data) {
				$scope.refreshing = false;
				onCustomObjectFormLoaded(data);

				// Select model view when custom object edit is opened by default on page load
				if(dd.urlNavigation) {
					dd.urlNavigation = false;
					selectModelView(data);
				}
			});

			component.instance.onLoadFailed.subscribe(function() {
				$scope.loading = false;
				$scope.refreshing = false;
				$scope.$apply();
			});

			component.instance.onEdit.subscribe(function(item) {
				editCustomObject(item);
			});

		};

		var configureWorkflowParam = function(){
			$scope.workflowParam = {
				targetObjectId: customObjectInstanceId
			};
			openTabIfNoActiveTab('workflows');
		};

		var configureHistoryParam = function(){
			$scope.historyData.param = {
				customObjectInstanceId: customObjectInstanceId
			};
			openTabIfNoActiveTab('history');
		};

		var configureCommentParam = function(data){
			$scope.captureModelViewOnComment = data.commentOptions.captureModelViewOnComment;
			$scope.modelData.commentParam.customObject = {
				customObjectContextId: apiConfig.customObject.MODEL_CONTEXT_ID,
				customObjectTemplateId: ctrl.templateId,
				customObjectTemplateGroupId: ctrl.templateGroupId,
				customObjectTemplateTypeId: ctrl.templateTypeId,
				customObjectCommentTypeId: data.commentOptions.customObjectCommentTypeId,
				customObjectInstanceId: customObjectInstanceId,
				projectId: myConfig.projectId,
				entityId: ctrl.config.entityId
			};
			openTabIfNoActiveTab('comments');
		};

		var onCustomObjectFormLoaded = function(data){
			$scope.statusClosed = data.statusClosed || false;

			if(data.commentOptions && data.commentOptions.hasComments) {
				$scope.tabs.comments = true;
				configureCommentParam(data);
			} else {
				$scope.tabs.comments = false;
			}

			$scope.tabs.workflows = true;
			configureWorkflowParam(data);
			$scope.tabs.history = true;
			configureHistoryParam(data);

			if(data.modelViewOptions && data.modelViewOptions.captureModelView) {
				$scope.tabs.views = true;
				insertView(data.modelViewOptions.modelViews, data.modelViewOptions.modelViewData);
				openTabIfNoActiveTab('views');
			} else {
				$scope.tabs.views = false;
			}

			if(data.attachmentOptions && data.attachmentOptions.attachmentAllowed) {
				$scope.tabs.attachments = true;
				openTabIfNoActiveTab('attachments');
				if(data.attachmentOptions.config) {
					appendAttachmentList(data.attachmentOptions.config.attachments);
				}
			} else {
				$scope.tabs.attachments = false;
			}

			if(data.linkOptions && data.linkOptions.linksAllowed) {
				$scope.tabs.links = true;
				openTabIfNoActiveTab('links');
				if(data.linkOptions.links) {
					appendLinks(data.linkOptions.links);
				}
			} else {
				$scope.tabs.links = false;
			}


			$scope.loading = false;
			$scope.$apply();
		};

		var selectModelView = function(data){
			if(data.modelViewOptions && data.modelViewOptions.modelViewData &&
				data.modelViewOptions.modelViewData.viewId) {
				if(window['selectView']) {
					clearPendingSelectModelView = window['selectView'](data.modelViewOptions.modelViewData.viewId, true);
				}
			}
		}

		var appendAttachmentList = function(attachments) {
			if(!attachments || !attachments.length) {
				ctrl.assocAttachmentsData.customObjectAttachments.data = [];
				ctrl.assocAttachmentsData.hasData = false;
				return;
			}

			ctrl.assocAttachmentsData.customObjectAttachments.data = [];

			for(var i = 0; i < attachments.length; i++) {
				var attachment = attachments[i];
				ctrl.assocAttachmentsData.customObjectAttachments.data = ctrl.assocAttachmentsData.customObjectAttachments.data.concat([{
					deleteDisabled: true,
					canDelete: true,
					canOpen: window['platformName'] ? false : true, // Disabled attachment view temporary for external platforms i.e naviswork
					canDownloadFile: true,
					item: attachment,
					revisionId: attachment.revisionId,
					FileName: attachment.fileName,
					FileType: api.getFileExtImage(api.getExt(attachment.fileName)),
					PublisherUserId: attachment.publisherUserId,
					FileSize: attachment.fileSize,
					attachedBy: attachment.attachedBy,
					attachedByName: attachment.attachedByName,
					attachedDate: attachment.attachedDate
				}]);
			}
			ctrl.assocAttachmentsData.hasData = true;
		};

		var appendLinks = function(links) {
			ctrl.assocLinksData.links.data = [];

			for(var i = 0; i < links.length; i++) {
				var link = links[i];
				insertLink({
					id: link.linkId,
					name: link.linkName,
					link: link.linkUrl,
					deleteDisabled: true,
					createdByImages: link.createdByImages,
					createdDisplayDateTime: link.createdDisplayDateTime,
					createdByFirstName: link.createdByFirstName,
				});
			}

			if(links.length) {
				ctrl.assocLinksData.hasData = true;
			} else {
				ctrl.assocLinksData.hasData = false;
			}
		};


		var insertLink = function(item) {
			ctrl.assocLinksData.links.data = ctrl.assocLinksData.links.data.concat([{
				id: item.id,
				deleteDisabled: true,
				name: item.name,
	    	    link: item.link,
				createdByImages: item.createdByImages || '',
				createdDisplayDateTime: item.createdDisplayDateTime || '',
				createdByFirstName: item.createdByFirstName || '',
	    	    href: /^[a-zA-Z]+:\/\//.test(item.link) ? item.link : ('http://' + item.link)
			}]);
		};

		var insertView = function(modelViews, modelViewData) {
			if(!modelViews || !modelViews.length) {
				ctrl.assocViewsData.views.data = [];
				ctrl.assocViewsData.hasData = false;
				return;
			}

			ctrl.assocViewsData.views.data = [];
			for(var i = 0; i < modelViews.length; i++) {
				var viewData = modelViews[i];

				ctrl.assocViewsData.views.data.push({
					bimModelName: myConfig.modelData.name,
					canView: true,
					viewId: viewData.viewId,
					createdDate: viewData.createdDate,
					viewName: viewData.viewName,
					creatorUserName: viewData.creatorUserName,
					modelTypeImage: viewData.modelTypeImage,
					modelTypeName: viewData.modelTypeName,
					hasMarkup: viewData.hasMarkup,
					modelName: viewData.modelName,
					projectName: viewData.projectName,
					creatorByImages: viewData.creatorByImages
				});
			}
			
			ctrl.assocViewsData.hasData = true;
		};

		var putTitleActions = function(containerEl, selector) {
			containerEl.html('');

			// take actions in header
			var appendTitleActions = function() {
				var $actions = $element.find(selector);
				if($actions.length) {
					containerEl.html('');
					containerEl.append($actions);
					return true;
				}
				
				return false;
			};
			
			var found = appendTitleActions();
			if(!found) {
				setTimeout(function() {
					var found = appendTitleActions();
					if(!found) {
						setTimeout(function() {
							appendTitleActions();
						}, 2000);
					}
				}, 1000);
			}
		};

	}],
	bindings: {
		type: '<',
		viewOnly: '=',
		templateLanguageDetails: '<',
		templateId: '<',
		templateGroupId: '<',
		templateTypeId: '<',
		config: '<'
	}
});
angular.module("adoddle").component('customObjectForm', {
	templateUrl: '/adoddle/view/newui/custom-object/custom.object-form.jsp',
	controller: ['$rootScope', '$scope', '$timeout', 'Notification', 'lang', 'api', 'apiConfig', 'myConfig', '$window', '$element', 'ddchild',
	function ($rootScope, $scope, $timeout, Notification, lang, api, apiConfig, myConfig, $window, $element, ddchild) {
		var ctrl = this;
		var added = false;
		var currentTimeStamp = new Date().getTime();
		var customObjectFormComponent;
		var attachmentComponent;
		var linksComponent;
		var attachmentContainerEl;
		var linksContainerEl;

		var customObjectInstanceId = '';
		var isFromView = false;
		var fromViewActiveTab = '';
		var clearPendingSelectModelView = null;
		var cancelPromptContinueFn;
		var cancelPromptCancelFn;

		$scope.expanded = false;
		$scope.editMode = false;
		$scope.showCancelPrompt = false;
		$scope.loading = true;
		$scope.statusClosed = false;
		$scope.modelData = angular.extend({}, myConfig.modelData);
		$scope.saveErrorMessage = '';
		$scope.showSaveErrorDialog = false;

		ctrl.$onInit = function () {
			setDefaults();
			listen();
			watch();
			$scope.hasCancelPrompt = true;
			ddchild.register($scope, 'custom-object-form');
		};


		var watch = function() {
			$rootScope.$on('assocChange', onAssocChange);
		};

		var listen = function () {
			$scope.$on('dd:changed', onDDOpenClose);
		};

		$scope.openCancelPrompt = function(onContinue, onCancel) {
			cancelPromptContinueFn = onContinue;
			cancelPromptCancelFn = onCancel;
			$scope.showCancelPrompt = true;
			$scope.$apply();
		};

		$scope.closeCancelPrompt = function() {
			cancelPromptContinueFn = null;
			cancelPromptCancelFn = null;
			$scope.showCancelPrompt = false;
		};

		ctrl.onCancelPromptContinue = function() {
			if(cancelPromptContinueFn) {
				cancelPromptContinueFn();
			}
			$scope.closeCancelPrompt();
		};

		ctrl.onCancelPromptCancel = function() {
			if(cancelPromptCancelFn) {
				cancelPromptCancelFn();
			}
			$scope.closeCancelPrompt();
		};
		$scope.openSaveErrorDialog = function(errorMessage) {
			$scope.saveErrorMessage = errorMessage;
			$scope.showSaveErrorDialog = true;
			$scope.$apply();
		};

		ctrl.cancelSaveErrorDailog = function() {
			$scope.saveErrorMessage = '';
			$scope.showSaveErrorDialog = false;
		};
		var setDefaults = function() {
			ctrl.titleActions = {
				attachments: false,
				links: false
			};
	
			ctrl.assocData = {
				title: '',
				open: true,
				view: '',
				treeSelection: "",
				listSelection: [],
				active: 4,			// represent active tab
				modelName: "",
				listXhr: false,
				list: undefined,
				customObjectAttachments: {
					data: [],
					deleteDisabled: false,
					index: 8
				},
				views: {
					data: [],
					deleteNotAllowed: true,
					hasDetails: false,
					index: 4
				},
				links: {
					data: [],
					deleteDisabled: false,
					index: 9
				}
			};
		};

		// invoke on dropdown open / close
		var closeTimeout = undefined;
		var prevVisible = undefined;
		
		var onDDOpenClose = function (event, dd) {
			if(!dd || dd.name == "custom-object-list") {
				return;
			}

			if(dd && dd.name == 'custom-object-form') {
				$scope.expanded = dd.expanded || false;
			}

			if(dd.name == 'custom-object-form' && dd.event == 'visibility') {
				if(prevVisible == dd.visible) {
					return;
				}
				if(dd.visible) {
					$timeout.cancel(closeTimeout);
					render(dd);
				} else {
					$timeout.cancel(closeTimeout);
					closeTimeout = $timeout(function() {
						destroy();
					}, 500);
				}
				prevVisible = dd.visible;
			} else if(dd.name != "custom-object-form") {
				$timeout.cancel(closeTimeout);
			}
		};

		var destroy = function() {
			if(!added) {
				return;
			}

			$scope.loading = true;
			$scope.statusClosed = false;
			added = false;
			customObjectInstanceId = '';
			cancelPromptContinueFn = null;
			cancelPromptCancelFn = null;
			$scope.showCancelPrompt = false;
			$scope.saveErrorMessage = '';
			$scope.showSaveErrorDialog = false;

			if(customObjectFormComponent) {
				customObjectFormComponent.destroy();
				customObjectFormComponent = null;
			}

			if(attachmentComponent) {
				attachmentComponent.destroy();
				attachmentComponent = null;
			}

			if(linksComponent) {
				linksComponent.destroy();
				linksComponent = null;
			}
			setDefaults();
			if(clearPendingSelectModelView) {
				clearPendingSelectModelView();
				clearPendingSelectModelView = null;
			}
			try{
				$scope.$apply();
			} catch(e){}
		};

		var onAssocChange = function() {
			setAssignments();
			setLinks();
		};

		var setAssignments = function() {
			if(customObjectFormComponent) {
				customObjectFormComponent.instance.attachments = ctrl.assocData.customObjectAttachments.data;
			}
		};

		var setLinks = function() {
			if(customObjectFormComponent) {
				customObjectFormComponent.instance.links = ctrl.assocData.links.data;
			}
		};

		var render = function (dd) {
			destroy();

			isFromView = dd.isFromView;
			fromViewActiveTab = dd.fromViewActiveTab;
			customObjectInstanceId = dd.customObjectInstanceId || '';
			$scope.editMode = customObjectInstanceId ? true : false;

			if(added) {
				$scope.$apply();
				return;
			}

			if(!attachmentContainerEl) {
				attachmentContainerEl = $element.find('#attachmentContainer');
			}
			if(!linksContainerEl) {
				linksContainerEl = $element.find('#linksContainer');
			}
			added = true;

			appendCustomObjectForm(dd);
		};

		var navigateToListOrView = function(dataChanged){
			$rootScope.$broadcast('dd:close', { name: 'custom-object-form', expanded: $scope.expanded, force: true });
			
			if(isFromView) {
				$rootScope.$broadcast('dd:open', {
					name: 'custom-object-view',
					expanded: $scope.expanded,
					type: ctrl.type,
					dataChanged: dataChanged || false,
					isFromForm: true,
					viewOnly: ctrl.viewOnly,
					defaultOpenedTab: fromViewActiveTab,
					templateLanguageDetails: ctrl.templateLanguageDetails,
					templateId: ctrl.templateId,
					templateGroupId: ctrl.templateGroupId,
					templateTypeId: ctrl.templateTypeId,
					config: ctrl.config,
					customObjectInstanceId: customObjectInstanceId,
					dockTitle: ctrl.templateLanguageDetails.customObjectTitle
				});
				return;
			}

			$rootScope.$broadcast('dd:open', {
				name: 'custom-object-list',
				expanded: $scope.expanded,
				'type': ctrl.type,
				'dataChanged': dataChanged || false,
				'isFromForm': true,
				'viewOnly': ctrl.viewOnly,
				'templateLanguageDetails': ctrl.templateLanguageDetails,
				'templateId': ctrl.templateId,
				'templateGroupId': ctrl.templateGroupId,
				'templateTypeId': ctrl.templateTypeId,
				'config': ctrl.config
			});
		};

		var appendCustomObjectForm = function(dd) {
			// dd.urlNavigation
			var $el = $element.find('#customObjectForm');
			var component = window.createDynamicAngularComponent('adoddle-custom-object-form', {
				projectId: myConfig.projectId,
				entityId: ctrl.config.entityId,
				dcId: myConfig.LOCAL_DC_ID,
				type: ctrl.type,
				viewOnly: ctrl.viewOnly,
				templateLanguageDetails: ctrl.templateLanguageDetails,
				templateId: ctrl.templateId,
				templateGroupId: ctrl.templateGroupId,
				templateTypeId: ctrl.templateTypeId,
				editMode: $scope.editMode,
				objectInstanceId: customObjectInstanceId
			}, $el[0]);
			customObjectFormComponent = component;

			component.instance.onLoaded.subscribe(function(data) {
				onCustomObjectFormLoaded(data);

				// Select model view when custom object edit is opened by default on page load
				if($scope.editMode && dd.urlNavigation) {
					selectModelView(data);
				}
			});

			component.instance.onLoadFailed.subscribe(function() {
				$scope.loading = false;
				$scope.$apply();
			});

			component.instance.onCancel.subscribe(function() {
				$scope.openCancelPrompt(function(){
					navigateToListOrView();
					destroy();
				});
			});

			component.instance.onSaved.subscribe(function(data) {
				navigateToListOrView(true);
				destroy();
			});

			component.instance.onSaveError.subscribe(function(errorMessage) {
				$scope.openSaveErrorDialog(errorMessage);
			});
		};


		var onCustomObjectFormLoaded = function(data){
			if(data.attachmentOptions && data.attachmentOptions.attachmentAllowed) {
				ctrl.titleActions.attachment = !data.readonly ? true : false;
				appendAttachment(data.attachmentOptions);

				if(data.attachmentOptions.config) {
					appendAttachmentList(data.attachmentOptions.config.attachments);
				}
			} else {
				ctrl.titleActions.attachment = false;
			}

			if(data.linkOptions && data.linkOptions.linksAllowed) {
				ctrl.titleActions.links = !data.readonly ? true : false;
				appendLinkCreate();

				if(data.linkOptions.links) {
					appendLinks(data.linkOptions.links);
				}
			} else {
				ctrl.titleActions.links = false;
			}

			$scope.statusClosed = data.statusClosed || false;

			if(data.modelViewOptions && data.modelViewOptions.captureModelView) {
				insertView(data.modelViewOptions.modelViews, data.modelViewOptions.modelViewData);
			}

			$scope.loading = false;
			$scope.$apply();
		};

		var selectModelView = function(data){
			if(data.modelViewOptions && data.modelViewOptions.modelViewData &&
				data.modelViewOptions.modelViewData.viewId) {
				if(window['selectView']) {
					clearPendingSelectModelView = window['selectView'](data.modelViewOptions.modelViewData.viewId, true);
				}
			}
		}

		var appendAttachment = function(attachmentOptions) {
			var $el = attachmentContainerEl;
			var component = window.createDynamicAngularComponent('adoddle-file-upload', {
				options: {
					params: {
						projectId: myConfig.projectId,
						attachTempFolderId: attachmentOptions.config.attachTempFolderId,
						dcId: myConfig.LOCAL_DC_ID,
						fileType: attachmentOptions.config.type
					},
					attachment: true,
					popover: true,
					disableMove: true,
					title: lang.get('attachments'),
					onComplete: function(o) {
			
						for(var i = 0; i < o.items.length; i++) {
							insertAttachment(o.items[i]);
						}
						
						if(o.items.length) {
							setAssignments();
							$timeout(function() {
								ctrl.assocData.active = ctrl.assocData.customObjectAttachments.index;
								ctrl.assocData.hasData = true;
								$scope.$apply();
							},500);
						}
					},
					onClose: function() {
						ctrl.customObject.isAttachOpen = false;
						$scope.$apply();
					}
				}
			}, $el[0]);
			attachmentComponent = component;
			$el.find('adoddle-file-upload').addClass('d');
		};

		var appendAttachmentList = function(attachments) {
			if(!attachments || !attachments.length) {
				ctrl.assocData.customObjectAttachments.deleteDisabled = false;
				return;
			}

			ctrl.assocData.customObjectAttachments.deleteDisabled = true;

			for(var i = 0; i < attachments.length; i++) {
				var attachment = attachments[i];
				ctrl.assocData.customObjectAttachments.data = ctrl.assocData.customObjectAttachments.data.concat([{
					deleteDisabled: true,
					canDelete: true,
					canOpen: window['platformName'] ? false : true, // Disabled attachment view temporary for external platforms i.e naviswork
					canDownloadFile: true,
					item: attachment,
					revisionId: attachment.revisionId,
					FileName: attachment.fileName,
					FileType: api.getFileExtImage(api.getExt(attachment.fileName)),
					PublisherUserId: attachment.publisherUserId,
					FileSize: attachment.fileSize,
					attachedBy: attachment.attachedBy,
					attachedByName: attachment.attachedByName,
					attachedDate: attachment.attachedDate
				}]);
			}
			ctrl.assocData.hasData = true;
		};

		var appendLinks = function(links) {
			ctrl.assocData.links.deleteDisabled = false;

			for(var i = 0; i < links.length; i++) {
				var link = links[i];
				insertLink({
					id: link.linkId,
					name: link.linkName,
					link: link.linkUrl,
					createdByImages: link.createdByImages,
					createdDisplayDateTime: link.createdDisplayDateTime,
					createdByFirstName: link.createdByFirstName,
				});
				if(link.linkId) {
					ctrl.assocData.links.deleteDisabled = true;
				}
			}

			if(links.length) {
				setLinks();
				ctrl.assocData.hasData = true;
			}
		};

		var appendLinkCreate = function() {
			var $el = linksContainerEl;
			var component = window.createDynamicAngularComponent('adoddle-custom-object-link', {
				options: {		
					onComplete: function(links) {

						var userformat = window['INIT_JSP_GLOBAL'].formatsForJqueryCalender[window['USP'].languageId];

						for(var i = 0; i < links.length; i++) {
							var item = links[i];
							item.createdByImages = apiConfig.IMAGE_PATH + myConfig.USP.userID + "&v=" + currentTimeStamp;
							item.createdDisplayDateTime = api.formatDate(userformat, new Date()),
							item.createdByFirstName = myConfig.USP.firstName || myConfig.USP.tpdUserName;
							insertLink(item);
						}

						if(links.length) {
							setLinks();
							$timeout(function() {
								ctrl.assocData.active = ctrl.assocData.links.index;
								ctrl.assocData.hasData = true;
								$scope.$apply();
							},500);
						}
					},
					onClose: function() {
						ctrl.customObject.isLinkOpen = false;
						$scope.$apply();
					}
				}
			}, $el[0]);
			linksComponent = component;
		};

		var insertLink = function(item) {
			ctrl.assocData.links.data = ctrl.assocData.links.data.concat([{
				id: item.id,
				deleteDisabled: item.id ? true : false,
				name: item.name,
	    	    link: item.link,
				createdByImages: item.createdByImages || '',
				createdDisplayDateTime: item.createdDisplayDateTime || '',
				createdByFirstName: item.createdByFirstName || '',
	    	    href: /^[a-zA-Z]+:\/\//.test(item.link) ? item.link : ('http://' + item.link)
			}]);
		};

		var insertAttachment = function(item) {
			var fileDetails = item.fileDetails.uploadedAttachmentFileDetails.split("|");
			var userformat = window['INIT_JSP_GLOBAL'].formatsForJqueryCalender[window['USP'].languageId];

			ctrl.assocData.customObjectAttachments.data = ctrl.assocData.customObjectAttachments.data.concat([{
				item: item,
				canDelete: false,
				canOpen: false,
				canDownloadFile: false,
	    	    FileType: item.file.icon,
	    	    FileName: item.file.name,
	    	    PublisherUserId: fileDetails[3],
	    	    FileSize: item.file.sortSize,
				attachedBy: apiConfig.IMAGE_PATH + myConfig.USP.userID + "&v=" + currentTimeStamp,
	    	    attachedByName: myConfig.USP.firstName || myConfig.USP.tpdUserName,
	    	    attachedDate: api.formatDate(userformat, new Date())
			}]);
		};

		var insertView = function(modelViews, modelViewData) {
			if(!modelViews || !modelViews.length) {
				return;
			}

			ctrl.assocData.views.data = [];
			ctrl.assocData.views.hasDetails = true;
			for(var i = 0; i < modelViews.length; i++) {
				var viewData = modelViews[i];

				ctrl.assocData.views.data.push({
					bimModelName: myConfig.modelData.name,
					canView: true,
					viewId: viewData.viewId,
					createdDate: viewData.createdDate,
					viewName: viewData.viewName,
					creatorUserName: viewData.creatorUserName,
					modelTypeImage: viewData.modelTypeImage,
					modelTypeName: viewData.modelTypeName,
					hasMarkup: viewData.hasMarkup,
					modelName: viewData.modelName,
					projectName: viewData.projectName,
					creatorByImages: viewData.creatorByImages
				});
			}
			
			ctrl.assocData.active = ctrl.assocData.views.index;
			ctrl.assocData.hasData = true;
		};

	}],
	bindings: {
		type: '<',
		viewOnly: '=',
		templateLanguageDetails: '<',
		templateId: '<',
		templateGroupId: '<',
		templateTypeId: '<',
		config: '<'
	}
});
angular.module('adoddle').component('customObjectList', {
    templateUrl: '/adoddle/view/newui/custom-object/custom.object.list.jsp',
    controller: [
        '$rootScope',
        '$scope',
        '$timeout',
        'Notification',
        'lang',
        'api',
        'apiConfig',
        'myConfig',
        '$window',
        '$element',
        function ($rootScope, $scope, $timeout, Notification, lang, api, apiConfig, myConfig, $window, $element) {
            var ctrl = this;
            var added = false;
            var customObjectListComponent;
            $scope.expanded = false;
            $scope.loading = true;
            $scope.refreshing = false;
            $scope.hasSelectedRow = false;
            $scope.bcfImport = {
                showPrompt : false,
                showLoaderPrompt : false
            }
            $scope.title;
            $window.bcfIssueImport = '';
            $scope.isForAdoddlePlugin = apiConfig.CBIM_PLUGINS.split('|').indexOf($window.platformName) > -1;

            ctrl.$onInit = function () {
                init();
            };

            ctrl.refresh = function () {
                if (customObjectListComponent) {
                    $scope.refreshing = true;
                    customObjectListComponent.instance.refresh();
                }
            };

            //Function for continue button from prompt
            ctrl.onContinuePromptClick = function () {
                window.bcfIssueImport && window.bcfIssueImport.onContinuePromptClick();
            };

            //Function for cancel button from prompt
            ctrl.onCancelPromptClick = function () {
                window.bcfIssueImport && window.bcfIssueImport.onCancelPromptClick();
            };

            var init = function () {
                listen();
                if (ctrl.type === 'MODEL_BCF_ISSUE' && !$scope.isForAdoddlePlugin) {
                    importBcfIssue();
                    window.bcfIssueImport && window.bcfIssueImport.getCustomObjectTemplateData();
                }
                if (myConfig.isFromCustomObjectRenderer) {
                    $rootScope.$broadcast('dd:open', {
                        name: 'custom-object-list',
                        expanded: $scope.expanded,
                        type: ctrl.type,
                        viewOnly: ctrl.viewOnly,
                        templateLanguageDetails: ctrl.templateLanguageDetails,
                        templateId: ctrl.templateId,
                        templateGroupId: ctrl.templateGroupId,
                        templateTypeId: ctrl.templateTypeId,
                        config: ctrl.config
                    });
                }
            };

            // Used to create dynamic angular componnet - import-bcf-issue comp.
            var importBcfIssue = function () {
                const options = {
                    customObjectTemplateId: ctrl.templateId,
                    customObjectTemplateGroupId: ctrl.templateGroupId,
                    customObjectTemplateTypeId: ctrl.templateTypeId,
                    projectId: myConfig.projectId,
                    dcId: myConfig.dcId,
                    entityId: ctrl.config.entityId,
                    action_id: apiConfig.SAVE_MODEL_VIEW,
                    apiConfig: apiConfig,
                    urlForSpecificDc: getBasedDomain(myConfig.dcId),
                    lang: lang
                }
                $window.bcfIssueImport = new ImportBcfFile({
                    data : options,
                    notification : Notification,
                    promptValues : $scope.bcfImport,
                    apply :function() {
                        $scope.$apply();
                    },
                    refresh : function() {
                        ctrl.refresh();
                    }
                });
            };

            var listen = function () {
                $scope.$on('dd:changed', onDDOpenClose);
            };

            // invoke on dropdown open / close
            var onDDOpenClose = function (event, dd) {
                if (dd && dd.name == 'custom-object-list') {
                    $scope.expanded = dd.expanded;

                    if (dd.visible) {
                        if (dd.isFromForm || dd.isFromView) {
                            render(dd.dataChanged);
                        } else {
                            render();
                        }
                    }
                }
            };

            var createCustomObject = function () {
                $rootScope.$broadcast('dd:close', { name: 'custom-object-list', expanded: $scope.expanded, force: true });
                $rootScope.$broadcast('dd:open', {
                    name: 'custom-object-form',
                    expanded: $scope.expanded,
                    type: ctrl.type,
                    viewOnly: ctrl.viewOnly,
                    templateLanguageDetails: ctrl.templateLanguageDetails,
                    templateId: ctrl.templateId,
                    templateGroupId: ctrl.templateGroupId,
                    templateTypeId: ctrl.templateTypeId,
                    config: ctrl.config
                });
            };

            var viewCustomObject = function (item) {
                $rootScope.$broadcast('dd:close', { name: 'custom-object-list', expanded: $scope.expanded, force: true });
                $rootScope.$broadcast('dd:open', {
                    name: 'custom-object-view',
                    expanded: $scope.expanded,
                    type: ctrl.type,
                    viewOnly: ctrl.viewOnly,
                    templateLanguageDetails: ctrl.templateLanguageDetails,
                    templateId: ctrl.templateId,
                    templateGroupId: ctrl.templateGroupId,
                    templateTypeId: ctrl.templateTypeId,
                    config: ctrl.config,
                    customObjectInstanceId: item.customObjectInstanceId,
                    dockTitle: ctrl.templateLanguageDetails.customObjectTitle
                });
            };

            var editCustomObject = function (item) {
                $rootScope.$broadcast('dd:close', { name: 'custom-object-list', expanded: $scope.expanded, force: true });
                $rootScope.$broadcast('dd:open', {
                    name: 'custom-object-form',
                    expanded: $scope.expanded,
                    type: ctrl.type,
                    viewOnly: ctrl.viewOnly,
                    templateLanguageDetails: ctrl.templateLanguageDetails,
                    templateId: ctrl.templateId,
                    templateGroupId: ctrl.templateGroupId,
                    templateTypeId: ctrl.templateTypeId,
                    config: ctrl.config,
                    customObjectInstanceId: item.customObjectInstanceId,
                    dockTitle: ctrl.templateLanguageDetails.customObjectEditTitle
                });
            };

            $scope.vertMoreClicked = function () {
                if (!customObjectListComponent) {
                    return false;
                }
                var selectedItems = customObjectListComponent.instance.getSelectedItems();
                $scope.hasSelectedRow = selectedItems.length > 0;

                var x = customObjectListComponent.instance.hasRecords;
                $scope.hasRecords = x;
            };

            $scope.vertMoreActionClicked = function (event, action) {
                // For row selection enabled action, return if no row is selected
                if (action.enableOnRowSelection && !$scope.hasSelectedRow) {
                    event.stopPropagation();
                    return;
                }

                action.actionHandler(action, customObjectListComponent.instance.getSelectedItems());
            };

            var render = function (reload) {
                if (added) {
                    if (reload) {
                        ctrl.refresh();
                    }
                    return;
                }
                added = true;

                appendCustomObjectList();
            };

            var canSelectListItems = function () {
                var canSelectItems = false;

                if (ctrl.config && ctrl.config.vertMoreActions) {
                    for (var i = 0; i < ctrl.config.vertMoreActions.length; i++) {
                        if (ctrl.config.vertMoreActions[i].enableOnRowSelection) {
                            canSelectItems = true;
                            break;
                        }
                    }
                }

                return canSelectItems;
            };
            var component;
            var appendCustomObjectList = function () {
                var $el = $element.find('#customObjectList');
                component = window.createDynamicAngularComponent(
                    'adoddle-custom-object-list',
                    {
                        projectId: myConfig.projectId,
                        entityId: ctrl.config.entityId,
                        dcId: myConfig.LOCAL_DC_ID,
                        type: ctrl.type,
                        viewOnly: ctrl.viewOnly,
                        templateLanguageDetails: ctrl.templateLanguageDetails,
                        templateId: ctrl.templateId,
                        templateGroupId: ctrl.templateGroupId,
                        templateTypeId: ctrl.templateTypeId,
                        canSelectItems: canSelectListItems(),
                        viewIssueFilter: ctrl.viewIssueFilter
                    },
                    $el[0]
                );
                customObjectListComponent = component;

                component.instance.onLoaded.subscribe(function (data) {
                    $scope.loading = false;
                    $scope.refreshing = false;
                    $scope.$apply();
                });

                component.instance.onLoadFailed.subscribe(function () {
                    $scope.loading = false;
                    $scope.refreshing = false;
                    $scope.$apply();
                });

                component.instance.onCreate.subscribe(function () {
                    createCustomObject();
                });

                component.instance.onEdit.subscribe(function (item) {
                    editCustomObject(item);
                });

                component.instance.onView.subscribe(function (item) {
                    viewCustomObject(item);
                });

                component.instance.onFilter.subscribe(function (item) {
                    component.instance.constants = {
                        view: 'issueFilter',
                        icons: {
                            createBtn: {
                                type: 'image',
                                value: '/images/icons/new-issue-icon.svg',
                            },
                            filterBtn: {
                                type: 'image',
                                value: '<i class="fa fa-sliders"></i>',
                            }
                        }
                    };
                });
            };
        }
    ],
    bindings: {
        createBtnTitle: '@',
        type: '<',
        viewOnly: '=',
        viewIssueFilter: '<',
        templateLanguageDetails: '<',
        templateId: '<',
        templateGroupId: '<',
        templateTypeId: '<',
        config: '<'
    }
});
angular.module("adoddle").filter('filehistoryFilter', function($filter) {
	var filterText = function(filterArray, query, obj) {
		if(!query.text) {
			filterArray.push(obj);
			return;
    	}
		var map = [];
		switch(query.actionId){
			case "11":
			case "1":	
				map = ["instant_email_notif", "revisionNum", "revisionCounter", "user_name", "user_org_name", "orgName", "action_name", "action_status", "username", "actionDate", 
				           "action_due_by_date", "action_complete_date", "view_date", "revisionStatusName", "purposeOfIssue", "statusName", "oldStatusName", "actionName", "fileName", 
				           "fileDescription", "action_notes", "transmittal_no", "remark", "remarks", "revisionNotes", "revisionStatusName", "description"];
			break;			
			case "6":
				map = [ "instant_email_notif", "user_name", "user_org_name", "orgName", "action_status", "username", "actionDate", 
				           "action_due_by_date", "action_complete_date", "view_date", "statusName", "oldStatusName","remark", "remarks","description"]
			break;
			case "5":
				map = [ "instant_email_notif", "user_name", "user_org_name", "orgName", "action_status", "username", "actionDate", 
				           "action_due_by_date", "action_complete_date", "view_date", "statusName", "oldStatusName","remark", "remarks","description"]
			break;
			default:
				map = ["instant_email_notif", "revisionNum",  "revisionCounter", "user_name", "user_org_name", "orgName", "action_name", "action_status", "username", "actionDate","actionName","description"]		
			break;
		}
		
		for (var i = 0; i < map.length; i++) {
			var key = map[i];
			
			if(obj.hasOwnProperty(key) && obj[key] && typeof obj[key] !== "object") {
				var value = obj[key] + "";
				if(value.toLowerCase().indexOf(query.text.toLowerCase()) > -1) {
					filterArray.push(obj);
					break;
				}
			}
		}
	};
	
    return function(appList, query) {
    	var array = [];
    	
    	if(appList) {
			for (var i = 0; i < appList.length; i++) {
				var app = appList[i];
				var actionId = parseInt(query.actionId) || '';
				if(!actionId) {
					if(!query.revisionId || !app.revisionId || query.revisionId == app.revisionId) {
						filterText(array, query, app);
					}
				} else if((actionId == app.actionId || (actionId == 1 && 7 == app.actionId)) && (!query.revisionId || query.revisionId == app.revisionId)) {
					filterText(array, query, app);
				}
			}
    	}
    	
    	return array;
    };
});

angular.module("adoddle").component('fileHistory', {
	templateUrl: '/adoddle/view/newui/view-file/file.history.jsp',
	controller: ['$scope', '$rootScope','$document', '$window', '$timeout', 'Notification', 'lang', 'api', 'apiConfig', 'myConfig', 'ddchild',
	function($scope, $rootScope, $document, $window, $timeout, Notification, lang, api, apiConfig, myConfig, ddchild) {
		var ctrl = this,
		    formProjectPriv = ",",
		    revStr = "", 
		    lastIndex = 0;
		
		// map for selected item type
		var typeMap = {
			distribution: "11",
			revisions: "1",
			status: "6",
			customObjectStatus: "5",
			migration:"75",
			all: ""
		};
		$scope.viewerPreference = myConfig.viewerPreference;
		$scope.isMobile = api.isMobile();
		
	    $scope.search = {
	    	actionId: typeMap.distribution,
	    	revisionId: ""
	    };
	    
	    $scope.history = {
	    	checkAll: false,
	    	expanded: false,
			selection: [],
			canAccessDeactivatedDocs: false,
			canDownloadFile: false
	    };
	    
	    $scope.action = {};
		$scope.historyList = [];
		$scope.distTypeWiseUserList = [];
	    $scope.distStatus = undefined;
	    $scope.confirmOpen = false;
		$scope.actionParam = {};

	    $scope.xhr = {
	    	history: false,
	    	delegate: false,
	    	clear: false,
	    	activate: false,
	    	dist: false
	    };

		$scope.isForAdoddlePlugin = $window.platformName && (apiConfig.CBIM_PLUGINS.split('|').indexOf($window.platformName) > -1 );
		$scope.hasHoopsViewerSupport = myConfig.hasHoopsViewerSupport

		ctrl.$onInit = function() {
			api.getViewPermission(function(data) {
				formProjectPriv = data.privileges;
				$scope.history.canAccessDeactivatedDocs = api.hasAccess(formProjectPriv, 'PRIV_ACCESS_DEACTIVATED_DOCUMENTS');
				$scope.canViewHistoricMarkups = api.hasAccess(formProjectPriv, 'CAN_VIEW_HISTORIC_MARKUPS');
				$scope.history.canDownloadFile = api.hasAccess(formProjectPriv, "PRIV_CAN_DOWNLOAD_DOCUMENTS") && myConfig.userFolderPermission != apiConfig.folderPermission.VIEW_ONLY;
			});

			resetSortingField();
			
			listen();
			if(ctrl.forCustomObject) {
				fetch();
			}

			ddchild.register($scope, 'history');
		};
		
		var resetSortingField = function(){
	    	$scope.orderByField = 'actionDate';
			$scope.sortOrder = true;
	    };
		
		var listen = function() {
			if(ctrl.forCustomObject) {
				$scope.$on('custom-object:history:fetch', function($event, data) {
					fetch();
				});
				$scope.$watch('$ctrl.parentExpanded', onParentExpandedChanged);
				return;
			}

			$scope.$on('dd:changed', onDDOpenClose);
			
			$scope.$on('status:changed', function(event, status) {
				ctrl.refresh(true);
			});

			$scope.$on('sharelink:changed', function(event, status) {
				ctrl.refresh(true);
			});
			  
			$scope.$on('action:completed', function(event, action) {
				ctrl.refresh(true);
			});
			  
			$scope.$on('distribution:completed', function(event, status) {
				ctrl.refresh(true);
			});
			  
			$scope.$on('msg:load', function(event, msg) {
				ctrl.refresh(true);
			});
		};

		var onParentExpandedChanged = function() {
			$scope.history.expanded = ctrl.parentExpanded;
		}
		/**
		 * @description open markup file.
		 */
		$scope.loadLegacyMarkup = function(name,revId,projectId) {
			var markup_revisionId = revId.split("$$")[0];
			var markup_projectId = projectId.split("$$")[0];
			if(myConfig.applicationId == 2 && qtObject){
                var currentTime = new Date().getTime();
                var qtFileName = name + '_' + currentTime + '.pdf';
                var qtURL = window.location.origin + apiConfig.PUBLISH_PDF_CONTROLLER + '?markupName='+ encodeURIComponent(name) + '&lm_projectId='+markup_projectId + '&lm_revisionId=' + markup_revisionId + '&action_id=' + apiConfig.GENERATE_LEGACY_MARKUP;
                qtObject.loadLegacyMarkup(qtURL, qtFileName);
                return;
            }
			if(myConfig.applicationId == 3){
				var param ={
					markupName : name,
					fileName : myConfig.fileName,
					lm_projectId : markup_projectId,
					lm_revisionId : markup_revisionId,
					action_id : apiConfig.GENERATE_LEGACY_MARKUP
				}
				api.sendEventToIpad("legacyMarkup:"+JSON.stringify(param));
                return;
            }
			api.submitForm({
				url: apiConfig.PUBLISH_PDF_CONTROLLER,
				param: {
					markupName : name,
					lm_projectId : markup_projectId,
					lm_revisionId : markup_revisionId,
					action_id : apiConfig.GENERATE_LEGACY_MARKUP
				},
				target: '_blank'
			});
		};

		// invoke on dropdown open / close
		var onDDOpenClose = function(event, dd) {
			if(dd && dd.name == 'history') {
				$scope.history.expanded = dd.expanded;
				
				if(dd.event == 'visibility' && dd.visible) {
					var findData = true;
					if(dd.data) {
						dd.data.actionId = (dd.data.actionId == -1) ? "" : dd.data.actionId;
						$scope.search.actionId = dd.data.actionId;
						$scope.search.revisionId = dd.data.revisionId || "";
						findData = false;
					}
					
					if(!$scope.historyList || !$scope.historyList.length) {
						fetch(false, findData);
					}
				}
			}
		};

		var fetch = function(silent, findData) {
			if(!silent && $scope.xhr.history && $scope.xhr.history.abort) {
				return;
			}
			
			var url = apiConfig.DOCUMENT_CONTROLLER;
			var obj = {
				action_id: apiConfig.VIEW_FILE_HISTORY,
				documentId: myConfig.documentId,
				projectId: myConfig.projectId,
				folderId: myConfig.folderId,
				historyType: -1
			};
			
			if(revStr) {
				obj.revisionId = revStr;
			}

			if(ctrl.forCustomObject) {
				url = apiConfig.GET_CUSTOM_OBJECT_AUDIT_TRAIL_DETAIL_LIST,
				obj = {
					customObject: JSON.stringify({
						projectId: myConfig.projectId,
						customObjectInstanceId: ctrl.customObjectParam.customObjectInstanceId
					}),
					action_id: -1
				}
			}
			
			var xhr = api.ajax({
				url: url,
				data: obj
			});
			
			if(!silent) {
				$scope.xhr.history = xhr;
			}
			
			xhr.then(function(response) {
				$scope.xhr.history = false;
				if(ctrl.forCustomObject) {
					response.forEach(function(item){
						item.actions = item.distData;
					});
					$scope.historyList = response;
				} else {
					$scope.historyList = response.historyVoList;
				}
				
				findData && setSearch();
				
				var revList = response.revisionList;
				if(revList && revList.elementVOList) {
					$scope.revList = revList.elementVOList;
					
					var msgArray = [];
					for (var i = 0; i < $scope.revList.length; i++) {
						msgArray.push($scope.revList[i].revisionId);
					}
					
					revStr = msgArray.join(',');
				}
				
				setDistActionList();
			}, function(xhr) {
				if(xhr.status == -1) {
					$scope.xhr.history = false;
				} else {
					$scope.xhr.history = xhr;
				}
				xhr.errorTitle = lang.get("form-history-error-msg");
				api.showServerErrMsg(xhr);
			});
		};
		
		var setSearch = function() {
			for ( var key in typeMap) {
				if(!typeMap.hasOwnProperty(key)) {
					continue;
				}
				
				for (var i = 0; i < $scope.historyList.length; i++) {
					var h = $scope.historyList[i];
					if(h.actionId == typeMap[key]) {
						$scope.search.actionId = typeMap[key];
						return;
					}
				}
			}
		};
		
		var setDistActionList = function() {
			var rowData = null, actionData = null, distList = [];
			var hList = $scope.historyList;
			for(var i = 0; i < hList.length; i++) {
				rowData = hList[i];

				rowData.proxy = angular.toJson({
					userID: rowData.userID,
					hProxyUserId: rowData.hProxyUserId,
					proxyUserName: rowData.proxyUserName,
					proxyOrgName: rowData.proxyOrgName,
					userTypeId: rowData.userTypeId
				});

				if(!rowData.username) {
					rowData.username = rowData.fname + ' ' + (rowData.lname || '')
				}
				if(rowData.userImage){					
					var plainUserID = rowData.userID.split("$$")[0],
						plainProxyID = rowData.hProxyUserId.split("$$")[0],
						currUserImgID = (plainUserID != plainProxyID ? plainUserID : plainProxyID)
						rowData.userImage =  rowData.userImage.replace(plainProxyID, currUserImgID);
				}

				rowData.userPhoto = apiConfig.IMAGE_PATH + rowData.userID.split('$$')[0];
				rowData.userPhoto += '&v=' + api.getLastModifiedProfileTime(rowData.userImage);
				
				if(rowData.actions) {
					for(var j = 0; j < rowData.actions.length; j++) {						
						actionData = rowData.actions[j];
						var preFixDistName = actionData.distributionLevel ? apiConfig.PREFIX_DISTRIBUTION_LEVEL[actionData.distributionLevel] + " : " : "";
						actionData.revisionId = rowData.revisionId;
						actionData.actionDate = rowData.actionDate;
						actionData.item = rowData;
						actionData.userID = rowData.userID;
						actionData.prefix=apiConfig.PREFIX_DISTRIBUTION_LEVEL[actionData.distributionLevel];
						actionData.hProxyUserId = rowData.hProxyUserId;
						actionData.userImage = rowData.userImage;
						actionData.userTypeId = rowData.userTypeId;
						actionData.username = rowData.username;
						actionData.orgName = rowData.orgName;
						actionData.user_org_id = parseInt(rowData.actions[j].user_org_id);
						actionData.actionId = typeMap.distribution;
						actionData.revisionNum = rowData.revisionNum;
						actionData.revisionCounter = rowData.revisionCounter;
						actionData.proxy = rowData.proxy;
						actionData.userPhoto = rowData.userPhoto;
						actionData.recipientPhoto = apiConfig.IMAGE_PATH + actionData.recipient_user_id.split('$$')[0];
						actionData.recipientPhoto += '&v=' + api.getLastModifiedProfileTime(actionData.user_image);
						actionData.objectName = (preFixDistName + actionData.objectName) || "";
						actionData.isOpenUserList = false;
						distList.push(actionData);
					}
				}
			}
			
			$scope.distActionList = distList;
		};
		
		var selectAllItems = function() {
			if(!$scope.filterList || !$scope.filterList.length) {
				return;
			}
			
			for(var i = 0; i < $scope.filterList.length; i++) {
				var actions = $scope.filterList[i].checked = $scope.history.checkAll;
			}
		};
		
		var deselectAllItems = function() {
			$scope.history.checkAll = false;
			$scope.history.selection = [];
			
			if(!$scope.historyList || !$scope.historyList.length) {
				return;
			}
			
			for(var i = 0; i < $scope.filterList.length; i++) {
				var actions = $scope.filterList[i].checked = false;
			}
		};
		
		var clearDuedates = function() {
			if(!$scope.filterList || !$scope.filterList.length) {
				return;
			}
			
			for(var i = 0; i < $scope.filterList.length; i++) {
				var actions = $scope.filterList[i].duedate = "";
			}
		};
		
		var selectItemsInRange = function(currentIndex, lastIndex) {
			if(!$scope.filterList || !$scope.filterList.length) {
				return;
			}
			
			var startIndex, endIndex;
			if(currentIndex < lastIndex) {
				startIndex = currentIndex;
				endIndex = lastIndex;
			} else {
				startIndex = lastIndex;
				endIndex = currentIndex;
			}
			
			var count = 0;
			for(var i = 0; i < $scope.filterList.length; i++) {
				$scope.filterList[i].checked = (count >= startIndex && count <= endIndex);
				count++;
			}
		};
		
		// sync selected all checkbox according to selected items below it.
		var updateCheckAll = function() {
			if(!$scope.filterList || !$scope.filterList.length) {
				return;
			}			
			var i, item, isAllSelected = true;
			for(i = 0; i < $scope.filterList.length; i++) {
				var actions = $scope.filterList[i];
				if(!actions.checked) {
					isAllSelected = false;
					break;
				}				
				if(!isAllSelected) {
					break;
				}				
			}			
			$scope.history.checkAll = isAllSelected;
		};
		
		var setSelectedItems = function() {
			var selectedItems = [],
				selectedUniqItems = {};
				
			$scope.history.selection = selectedItems = [];

			if(!$scope.historyList || !$scope.historyList.length) {
				return;
			}
			
			var i, item;
			for(i = 0; i < $scope.filterList.length; i++) {
				var actions = $scope.filterList[i];
				if(actions.checked) {
					selectedUniqItems[actions.user_id+'_'+actions.action_name+'_'+actions.actionDate] = actions;
				}
			}

			for ( var uniqueKey in selectedUniqItems )
				selectedItems.push(selectedUniqItems[uniqueKey]);

			$scope.history.selection = selectedItems;
		};
		
		var hasAction = function(paramObj) {
			if(!$scope.history.selection || !$scope.history.selection.length) {
				return false;
			}
			
			var hasAct = false,
				status = paramObj.status,
				hasPriv = false, 
				orgPriv = paramObj.allOrg,
				projectPriv = paramObj.projOrg,
				ownPriv = paramObj.ownOrg, 
				privValueArray = [];

			for(var i = 0; i < $scope.history.selection.length; i++) {
				var data = $scope.history.selection[i];
				var condition = data.action_status == status;
				
				if(condition) {
					hasAct = true;
				}

				if(hasAct){
		        	 //Can Clear/Delegate Own Actions only. i.e. for login Organisations and Project.
		            var plainUserId = USP.userID;
		            if(ownPriv && plainUserId && data.recipient_user_id == plainUserId){
		            	hasPriv = true;
		            }
		            //Can Clear/Delegate Actions for all users (except own) across all organisation of the Project
		            if(hasPriv == false && projectPriv  &&!(data.recipient_user_id == plainUserId)){
		            	hasPriv = true;
		            }
		            // Can Clear/Delegate Actions for all users (except own) of the login organisation only
		            if(hasPriv == false && orgPriv && (data.user_org_id == USP.orgID ) && !(data.recipient_user_id == plainUserId) ){
		            	hasPriv = true;
		            }
		            if(!hasPriv){
		            	hasAct = hasPriv;
		            }
        		}        
        		privValueArray.push(hasAct);
    		}

    		for(var j=0; j<=privValueArray.length; j++){
    			if(privValueArray[j]){
    				return true
    			}
    		}
    		return false
    		// return  $.inArray( true, privValueArray ) == -1 ? false : true; 
		};

		var hasActionDeactiveReactive = function(paramObj){
			var hasAct = false, 
		    	hasPriv = false, 
		    	allOrgPrivilege = paramObj.allOrg,
		    	ownOrgPrivilege = paramObj.ownOrg, 
		    	privValueArray = [];

	        if(!$scope.history.selection || !$scope.history.selection.length) {
				return false;
			}
		    
		    for(i = 0; i < $scope.history.selection.length; i++) {
		        var data = $scope.history.selection[i];
				var condition = data.action_status == paramObj.status;
		        if (paramObj.invert) { // "invert = true" for Deactivation
		            condition = !condition
		        }
		        if (condition) {
		            hasAct = true
		        }
		        
		        if(hasAct){        	
		            if(allOrgPrivilege){ //Can Deactivate/Reactivate All Org Actions.
		            	hasPriv = true;
		            } else if(ownOrgPrivilege && data.user_org_id == USP.orgID){ //Can Deactivate/Reactivate Own Org Actions only.
		            	hasPriv = true;
		            }            
		            if(!hasPriv){
		            	hasAct = hasPriv;
		            }
		        }        
		        privValueArray.push(hasAct);
		    }

		    for(var j=0; j<=privValueArray.length; j++){
    			if(privValueArray[j]){
    				return true;
    			}
    		}
    		return false;
    		// return  $.inArray( true, privValueArray ) == -1 ? false : true; 
		}
		
		var getActions = function(status, invert) {
			if(!$scope.history.selection || !$scope.history.selection.length) {
				return false;
			}
			
			var actions = [];
			for(i = 0; i < $scope.history.selection.length; i++) {
				var data = $scope.history.selection[i];
				var condition = data.action_status == status;
				if(invert) {
					condition = !condition;
				}
				
				if(condition) {
					actions.push(data);
				}
			}
			
			return actions;
		};
		
		var getIdString = function(actions, isForReport) {
			actions = actions || $scope.history.selection;
			if(!actions || !actions.length) {
				return;
			}
			
			var drIds = [];
			for(i = 0; i < actions.length; i++) {
				var data = actions[i];
				if(data.checked) {
					if(isForReport) {
						drIds.push(data.dist_list_id + "|" + data.action_id + "|" + data.user_id + "|" + data.revisionId);
					} else {
						drIds.push(data.dist_list_id + "|" + data.user_id + "|" + data.action_id);
					}
				}
			}
			
			return drIds.join(',');
		};
		/**
		 * Return visibility object
		 */
		var returnVisibilityData = function (actionData) {
			var visibilityData = [];
			for (i = 0; i < actionData.length; i++) {
				var data = actionData[i];
				if(data.distributionLevel != apiConfig.DISTRIBUTION_LEVEL.USERS){
					var permissionLevelId = data.distributionLevelId;
					if(data.distributionLevel == apiConfig.DISTRIBUTION_LEVEL.DISTRIBUTION_GROUPS){
						permissionLevelId = data.distributionLevelId && data.distributionLevelId.split("$$")[0];
					}					
					visibilityData.push({
						"hProjectId": myConfig.projectId,
						"resourceTypeId": 2,
						"hResourceId": data.revisionId,
						"adoddleObjectPermissionVOList": [{
							"hPermissionLevelId": permissionLevelId,
							"hashLevelId": data.distributionLevelId,
							"permissionLevel": data.distributionLevel
						}]
					});					
				}			
			}
			var uniqueSelectedDistData = [];
			if (visibilityData && visibilityData.length) {
			  var uniqueKeyMap = {}, uniqueKeyVisiMap = {}, currObj, curPermissionVo;
			  for (var i = 0; i < visibilityData.length; i++) {
				currObj = visibilityData[i]
				curPermissionVo = visibilityData[i].adoddleObjectPermissionVOList[0];
				if (Object.keys(uniqueKeyMap).length == 0) {
					uniqueKeyMap[currObj.hResourceId + "#" + curPermissionVo.hashLevelId] = currObj;
					uniqueSelectedDistData.push(currObj);
				  } else {
					if (!uniqueKeyMap[currObj.hResourceId + "#" + curPermissionVo.hashLevelId]){
						uniqueKeyMap[currObj.hResourceId + "#" + curPermissionVo.hashLevelId] = currObj;
						uniqueSelectedDistData.push(currObj); 
					}
				}
			  }
			}
			return uniqueSelectedDistData;
		};
		var reactiveDeactiveList = function(action, listingActionID, selectedActions) {
					
			$scope.xhr.activate = api.ajax({
				url  : apiConfig.DOCUMENT_CONTROLLER,
				data : {
					action_id: listingActionID,
					project_id: myConfig.projectId,
					drId: getIdString(selectedActions)					
				}
			});
				
			$scope.xhr.activate.then(function(response) {
				if(response.data && response.data.length > 0){
					var actionID = "";
					if(action == 'deactive'){
						actionID = apiConfig.DEACTIVATE_FILE_ACTION;
					} else if (action == 'reactive'){
						actionID = apiConfig.REACTIVATE_FILE_ACTION;
					}
					
					var drIds = getIdString($scope.filterList);//getIdString($scope.history.selection);
					var drIdsArr = drIds.split(",") || [];
					var filteredActionDrIds = [], listActionData = [],  visibilityDistListId = [];
					var filtrDataRes = response.data
					for(i = 0; i < filtrDataRes.length; i++) {
						var thisResObj = filtrDataRes[i];
						var thisId = thisResObj.revisionDistListId + "|" + thisResObj.recipient_user_id.split('$$')[0] + "|" + thisResObj.actionId
						for(var j=0; j<drIdsArr.length; j++){
							if(thisId == drIdsArr[j]){								
								filteredActionDrIds.push(drIdsArr[j]);
							}
						}
						if(thisResObj.askForRemoveVisibility){
							visibilityDistListId.push(thisResObj.revisionDistListId);							
						}
					}
					if (action == 'deactive' && visibilityDistListId.length) {
						var visibilityFilteredArray = visibilityDistListId.filter(function (item, pos) {
							return visibilityDistListId.indexOf(item) == pos;
						});

						listActionData = selectedActions.filter(function (val, i) {
							for (var i = 0; i < visibilityFilteredArray.length; i++) {
								var distListId = visibilityFilteredArray[i];
								if (val.dist_list_id.split("$$")[0] == distListId.split("$$")[0]) {
									return val;
								}
							}
						});
					}
				
					if(actionID!="" && filteredActionDrIds.length){
						if(action == 'deactive' && listActionData && listActionData.length > 0){
							$scope.confirmOpen = true;
							$scope.actionParam = {
								"action": action, 
								"actionID": actionID,
								"filteredActionDrIds": filteredActionDrIds.join(), 
								"filtrDataRes": filtrDataRes,
								"selectedActions": selectedActions,
								"listActionData": listActionData
							};																			
						} else {
							reactiveDeactive(action, actionID, filteredActionDrIds.join(), filtrDataRes, selectedActions);
						}
					}
				} else {
					//Does not have any permission.
					$scope.xhr.clear = false;
					$scope.history.checkAll = false;
					$scope.history.selection = [];
					// Notification.error('<div class="bold-msg">There are no pending actions to clear or you do not have the permission to update other users actions!</div>');
					var isDeactivated = "";
					if(action == 'deactive'){
						Notification.warning('<div class="bold-msg">Task(s) deactivated for 0 / ' + selectedActions.length + ' record(s).<br>'
						 + selectedActions.length + ' record(s) were not deactivated due to one/all of the below reasons: <br>'
						 + ' a) You do not have privilege to deactivate task on selected record <br>'
						 + ' b) Task for selected record was already deactivated</div>');
					} else{
						Notification.warning('<div class="bold-msg">Task(s) reactivated for 0 / ' + selectedActions.length + ' record(s).<br>'
						 + selectedActions.length + ' record(s) were not reactivated due to one/all of the below reasons: <br>'
						 + ' a) You do not have privilege to reactivate task on selected record <br>'
						 + ' b) Task for selected record was already reactivated</div>');
					}
				}				
			}, function(xhr) {
				$scope.xhr.activate = false;
				$scope.history.checkAll = false;
				//if(xhr.status != -1)
					//Notification.error('<div class="bold-msg text-center">Error while updating!</div>');
				xhr.errorTitle = lang.get("reactivate-deactive-error-msg");
				api.showServerErrMsg(xhr);
			});
		};

		var reactiveDeactive = function(action, actionID, filteredActionDrIds, actions, selectedActions, listData){

			var paramsObj = {
				action_id: actionID,
				project_id: myConfig.projectId,
				drId: filteredActionDrIds //getIdString(actions)
			}

			if (listData && listData.length > 0) {
				var visibilityData = returnVisibilityData(listData);
				if (visibilityData.length) {
					paramsObj.visibilityVOList = JSON.stringify(visibilityData);
				}
			}

			$scope.xhr.activate = api.ajax({
				url  : apiConfig.DOCUMENT_CONTROLLER,
				data : paramsObj
			});

			$scope.xhr.activate.then(function(response) {
				var totalSelectedRecords = selectedActions.length;
				var updatedRecordsCnt = filteredActionDrIds.split(",").length;
				$scope.xhr.activate = false;
				$scope.history.checkAll = false;
				$scope.history.selection = [];
				fetch();
				$timeout(function() {
					var updateDetail = {};
					updateDetail[apiConfig.entity.FILE] = actions[0].revisionId;
					api.informParentWin(updateDetail);
				}, 2000);
				// Notification.success('<div class="bold-msg text-center">' + filteredActionDrIds.split(",").length + ' ' + (actionID == apiConfig.DEACTIVATE_FILE_ACTION ? lang.get('deactiveConfirmMsg') : lang.get('activeConfirmMsg')) + '</div>');

				if(action == 'deactive'){
					//For Deactivate
					if(updatedRecordsCnt < totalSelectedRecords){
						Notification.warning('<div class="bold-msg">Task(s) deactivated for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s).<br>'
						 + (totalSelectedRecords - updatedRecordsCnt) + ' record(s) were not deactivated due to one/all of the below reasons: <br>'
						 + ' a) You do not have privilege to deactivate task on selected record <br>'
						 + ' b) Task for selected record was already deactivated</div>');
					} else {
						Notification.success('<div class="bold-msg text-center">Task(s) deactivated for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s)</div>');
					}
				} else {
					//For Reactivate
					if(updatedRecordsCnt < totalSelectedRecords){
						Notification.warning('<div class="bold-msg">Task(s) reactivated for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s).<br>'
						 + (totalSelectedRecords - updatedRecordsCnt) + ' record(s) were not reactivated due to one/all of the below reasons: <br>'
						 + ' a) You do not have privilege to reactivate task on selected record <br>'
						 + ' b) Task for selected record was already reactivated</div>');
					} else {
						Notification.success('<div class="bold-msg text-center">Task(s) reactivated for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s)</div>');
					}
				}

			}, function(xhr) {
				$scope.xhr.activate = false;
				$scope.history.checkAll = false;
				//if(xhr.status != -1)
				//Notification.error('<div class="bold-msg text-center">Error while updating!</div>');
				xhr.errorTitle = lang.get("reactivate-deactive-error-msg");
				api.showServerErrMsg(xhr);
			});


		}
		
		var fetchDistData = function() {
			if($scope.xhr.dist && $scope.xhr.dist.abort) {
				return;
			}
			
			$scope.xhr.dist = api.ajax({
				url : apiConfig.DOCUMENT_CONTROLLER,
				data : {
					action_id : apiConfig.DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_LIST,
					projectId: myConfig.projectId,
					drId: getIdString($scope.filterList)//getIdString(getActions('Incomplete'))
				}
			});
			
			$scope.xhr.dist.then(function(resp) {
				var totalSelectedRecords = getIdString($scope.filterList).split(",").length;
				$scope.xhr.dist = false;
				$scope.history.checkAll = false;
				$scope.delegate.incompleteActions = resp;
				
				var validUserList = resp.data[0] || [];
				if(validUserList.length) {
					var list = resp.data[1] || [];
					if(list.length) {
						for (var i = 0; i < list.length; i++) {
							var u = list[i];
							u.emailId = u.email;
							u.userName = u.username;
						}
					}					
					$scope.delegate.userList = { userList: list };
					$scope.delegate.validUsersList = validUserList;
				} else {
					Notification.warning('<div class="bold-msg">Task(s) delegated for 0 / ' + totalSelectedRecords + ' record(s).<br>'
					 + totalSelectedRecords + ' record(s) were not delegated due to one/all of the below reasons: <br>'
					 + ' a) You do not have privilege to delegate task on selected record <br>'
					 + ' b) Task for selected record was already delegated</div>');
					$scope.delegate.validUsersList = []
					$scope.cancelDelegate();
					deselectAllItems();
				}
			}, function(xhr) {
				if (xhr.status != -1)
					$scope.xhr.dist = xhr;
				else
					$scope.xhr.dist = false;
				$scope.history.checkAll = false;
				xhr.errorTitle = lang.get("distribution-data-error-msg");
				api.showServerErrMsg(xhr);
			});
		};
		
		ctrl.refresh = function(silent) {
			$scope.cancelDelegate();
			deselectAllItems();
			resetSortingField();
			fetch(silent);

			if(ctrl.forCustomObject) {
				$rootScope.$broadcast("custom-object:view:refresh");
			}
		};
		
		ctrl.exportH = function(event) {
			var exportObj = {
				historyType: $scope.search.actionId || '-1',
				action_id: apiConfig.EXPORT_DOCUMENT_HISTORY,
				controller: apiConfig.EXPORT_CONTROLLER,
				listingType: apiConfig.DOCUMENT_HISTORY_EXPORT,
				projectId: myConfig.projectId,
				folderId: myConfig.folderId,
				docTypeId: myConfig.documentTypeId,
				revisionId: revStr,
				latestRevId: myConfig.revisionId
			};
			
			if(myConfig.applicationId == 2){
				window.qtObject && window.qtObject.slot_exportClicked(exportObj);
				return;
			}

			api.submitForm({
				  param: exportObj,
				  url: exportObj.controller,
				  target:'_self'
			});
		};
		
		$scope.headerCellClick = function($event, column) {
			if($scope.orderByField == column){
				$scope.sortOrder = !$scope.sortOrder;
			} else {
				$scope.orderByField = column;
				$scope.sortOrder = false;
			}
		};
		
		$scope.sorting = function(item) {
			var itemType = $scope.orderByField;
			var value = item[itemType] || "";
			var date = "";
			switch(itemType) {
				case 'actionDate':
				case 'action_due_by_date':
				case 'action_complete_date':
				case 'view_date':
					if(value) {
						try {
							value = value.split("#");
							date = value[1];
							value = api.parseDate(myConfig.userDateFormat, value[0]);
							if(date) {
								date = date.split(' ')[0] || "";
								date = date.split(':');
								if(date.length) {
									date[0] && value.setHours(parseInt(date[0]));
									date[1] && value.setMinutes(parseInt(date[1]));
									date[2] && value.setSeconds(parseInt(date[2]));
								}
							}
							return value.getTime();
						} catch(e) {
							return value;
						}
					} else {
						return value;
					}
					break;
				default:
					return value;
			}
		};
		
		$scope.typeChange = function() {
			$scope.cancelDelegate();
			deselectAllItems();
		};
		
		$scope.revisionChange = function() {
			$scope.cancelDelegate();
			deselectAllItems();
		};
		
		$scope.selectionChange = function(e, idx, isAll) {
			if(isAll) {
				selectAllItems();
				lastIndex = 0;
			} else {
				var index = idx;
				if(!e.shiftKey) {
					lastIndex = index;
				} else {
					selectItemsInRange(index, lastIndex);
				}				
				updateCheckAll();
			}			
			setSelectedItems();
		};
					
		
		/** Holds the last clicked item */
		var lastClicked = undefined;

		/**
		 * Invokes on selection object click
		 * Open the relative detail of selected type.
		 * Get users in Role, Organisation and Distribute group type.
		 * @param {*} action
		 */
		$scope.getDistTypeWiseUserList = function(evt,action){		
			action.isOpenUserList = !action.isOpenUserList;	
			$document.off('mousedown.distUserList');	
			if(action.isOpenUserList) {				
				lastClicked = action;				
				  /** bind outside click of popup detail */
				$document.on('mousedown.distUserList', function(e) {
					if((evt.target != e.target || !angular.element(e.target).closest('.gDistList').length) && !e.target.closest('.dist-type-userlist')) {
						if(lastClicked) {
							lastClicked.isOpenUserList = false;
							$scope.distTypeWiseUserList = [];
							$document.off('mousedown.distUserList');
							try {
								$scope.$digest();
							} catch(e) {}
						}
					}
				});
			}

			//  Users type are not allow to get users list.
			if(action.distributionLevel == apiConfig.DISTRIBUTION_LEVEL.USERS){
				action.isOpenUserList = false;
				return;
			}

			//ajax call GET_DIST_WISE_USER_LIST
			//pass Type, id and project id and return list of users.
			var xhr = api.ajax({
				url: apiConfig.GET_DIST_WISE_USER_LIST + "?entityType=" +  action.distributionLevel + "&distributionLevelId=" + action.distributionLevelId + "&projectID=" + myConfig.projectId, ///manageAdoddleObjectPrivacy/getUserListForGivenResource
				method: "GET"
			});
			
			xhr.then(function(response) {
				for(var i=0; i < response.length; i++ ){
					response[i].userImg = apiConfig.IMAGE_PATH + response[i].userID.toString().split('$$')[0];
					response[i].userImg += '&v=' + api.getLastModifiedProfileTime(response[i].userImageName);
				}
				$scope.distTypeWiseUserList = response;	
			}, function(xhr) {

			});						
		};

		$scope.disabledSubitem = function() {
			$scope.action.deactive = false;
			$scope.action.reactive = false;
			$scope.action.clearAction = false;
			$scope.action.delagateAction = false;
			
			if(!$scope.history.selection || !$scope.history.selection.length) {
				return false;
			}
			
		    //Deactive Action
		    var deactiveParamObj = {
		    	"ownOrg": api.hasAccess(formProjectPriv, 'CAN_DEACTIVATE_DOCUMENT_ACTIONS_OWN_ORG'), 
		    	"allOrg": api.hasAccess(formProjectPriv, 'CAN_DEACTIVATE_DOCUMENT_ACTIONS_ALL_ORG'), 
		    	"status": "Inactive", 
		    	"invert": true
		    }
		    if(hasActionDeactiveReactive(deactiveParamObj)){
                $scope.action.deactive = true;
            }

           //Reactivate Action
           var reactiveParamObj = {
           		"ownOrg": api.hasAccess(formProjectPriv, 'CAN_REACTIVATE_DOCUMENT_ACTIONS_OWN_ORG'), 
 		   		"allOrg": api.hasAccess(formProjectPriv, 'CAN_REACTIVATE_DOCUMENT_ACTIONS_ALL_ORG'), 
 		   		"status": "Inactive"
 		   	}
 		   if(hasActionDeactiveReactive(reactiveParamObj)){
		        $scope.action.reactive = true;
            }
			
			//Clear Action
			var clearParamObj = {
				"ownOrg" : api.hasAccess(formProjectPriv, 'PRIV_CAN_CLEAR_ACTIONS_OWN'),
				"projOrg": api.hasAccess(formProjectPriv, 'PRIV_CAN_CLEAR_ACTIONS_PROJECT'),
				"allOrg" : api.hasAccess(formProjectPriv, 'PRIV_CAN_CLEAR_ACTIONS_ORG'),
				"status": "Incomplete"
			}            
		    if(hasAction(clearParamObj)) {
                $scope.action.clearAction = true;
            }

             //Delegate Action
             var delegateParamObj = {
				"ownOrg" : api.hasAccess(formProjectPriv, 'PRIV_CAN_DELEGATE_ACTIONS_OWN'),
				"projOrg": api.hasAccess(formProjectPriv, 'PRIV_CAN_DELEGATE_ACTIONS_PROJECT'),
				"allOrg" : api.hasAccess(formProjectPriv, 'PRIV_CAN_DELEGATE_ACTIONS_ORG'),
				"status": "Incomplete"
			}            
		    if(hasAction(delegateParamObj)) {		    	
                $scope.action.delagateAction = true;
            }
		};

		$scope.deactiveAction = function() {
			if(!$scope.action.deactive) {
				return;
			}			

			var selectedCheckedList = $scope.filterList.filter(function(item, index, array){            
				return item.checked
			});

			reactiveDeactiveList('deactive', apiConfig.DEACTIVATE_FILE_ACTION_LIST, selectedCheckedList);
		};

		$scope.reactiveAction = function() {
			if(!$scope.action.reactive) {
				return;
			}			

			var selectedCheckedList = $scope.filterList.filter(function(item, index, array){            
				return item.checked
			});

			reactiveDeactiveList('reactive', apiConfig.REACTIVATE_FILE_ACTION_LIST, selectedCheckedList);
		};

		$scope.clearAction = function() {
			if(!$scope.action.clearAction) {
				return;
			}
			var selectedCheckedList = $scope.filterList.filter(function(item, index, array){            
				return item.checked
			});

			var paramsObj= {
				action_id : apiConfig.DOCUMENT_DISTRIBUTION_CLEAR_ACTION_LIST, 
				drId : getIdString($scope.filterList), 
				project_id : myConfig.projectId
			};
			$scope.xhr.clear = api.ajax({
				url  : apiConfig.DOCUMENT_CONTROLLER,
				data : paramsObj
			});
			
			$scope.xhr.clear.then(function(response) {
				var totalSelectedRecords = getIdString($scope.filterList).split(",").length;
				if(response.data && response.data.length > 0){
					var drIds = getIdString($scope.filterList);
					var drIdsArr = drIds.split(",") || [];
					var distributionListIds = [], listActionData = [], visibilityDistListId = [];
					for(i = 0; i < response.data.length; i++) {
						var thisResObj = response.data[i];
						var thisId = thisResObj.revisionDistListId + "|" + thisResObj.recipient_user_id.split('$$')[0] + "|" + thisResObj.actionId
						for(var j=0; j<drIdsArr.length; j++){
							if(thisId == drIdsArr[j]){								
								distributionListIds.push(drIdsArr[j]);
							}
						}
						if(thisResObj.askForRemoveVisibility){
							visibilityDistListId.push(thisResObj.revisionDistListId);							
						}					
					}

					if(visibilityDistListId.length){
						var visibilityFilteredArray = visibilityDistListId.filter(function (item, pos) {
							return visibilityDistListId.indexOf(item) == pos;
						});
	
						listActionData = selectedCheckedList.filter(function (val, i) {
							for (var i = 0; i < visibilityFilteredArray.length; i++) {
								var distListId = visibilityFilteredArray[i];
								if (val.dist_list_id.split("$$")[0] == distListId.split("$$")[0]) {
									return val;
								}
							}
						});
					}
					
					if(distributionListIds.length){
						$scope.confirmClearAction(distributionListIds.join(), totalSelectedRecords, listActionData);
					}
				} else {
					//Does not have any permission.
					$scope.xhr.clear = false;
					$scope.history.checkAll = false;
					$scope.history.selection = [];
					Notification.warning('<div class="bold-msg">Task(s) cleared for 0 / ' + totalSelectedRecords + ' record(s).<br>'
					 + totalSelectedRecords + ' record(s) were not cleared due to one/all of the reasons mentioned below: <br>'
					 + ' a) You do not have privilege to clear task on selected record <br>'
					 + ' b) Task for selected record was already completed</div>');

				}				
			}, function(xhr) {
				$scope.xhr.clear = false;
				$scope.history.checkAll = false;
				xhr.errorTitle = lang.get("clear-action-error-msg");
				api.showServerErrMsg(xhr);				
			});			
		};

		$scope.confirmClearAction = function(distributionListIds, totalSelectedRecords, listData){	
			if(listData && listData.length > 0){
				$scope.confirmOpen = true;
                $scope.actionParam = {
                  "distributionListIds": distributionListIds, 
                  "totalSelectedRecords": totalSelectedRecords, 
                  "listData": listData
				};
			} else {
				$scope.continueClearAction(distributionListIds, totalSelectedRecords)
			}
		};
		
		$scope.continueClearAction = function(distributionListIds, totalSelectedRecords, listData){
			
			var actions = getActions('Incomplete');
			var distributionListIds = distributionListIds;
			var params = {
				"action_id": apiConfig.DOCUMENT_DISTRIBUTION_CLEAR_ACTION_SUBMIT,
				"UserSessionProfile.proxyOrgName": actions[0].proxyUserOrg,
				"UserSessionProfile.proxyUserName": actions[0].proxyUserName,
				"UserSessionProfile.tpdOrgName": actions[0].user_org_name,
				"UserSessionProfile.tpdUserName": actions[0].user_name,
				"docRevisionId": actions[0].revisionId,
				"drReportId": getIdString(actions, true),
				"project_id": myConfig.projectId,
				"drId": distributionListIds, //getIdString($scope.filterList), //getIdString(actions),
				"isFromRemoveUser": 'null',
				"isForAllUsers": 'null'
			};			

			if (listData && listData.length > 0) {
				var visibilityData = returnVisibilityData(listData);
				if (visibilityData.length) {
					params.visibilityVOList = JSON.stringify(visibilityData);
				}
			}

			$scope.xhr.clear = api.ajax({
				url  : apiConfig.DOCUMENT_CONTROLLER,
				data : params
			});
			
			$scope.xhr.clear.then(function(response) {
				var updatedRecordsCnt = distributionListIds.split(",").length;
				$scope.xhr.clear = false;
				$scope.history.checkAll = false;
				$scope.history.selection = [];
				fetch();
				$timeout(function() {
					var updateDetail = {};
					updateDetail[apiConfig.entity.FILE] = actions[0].revisionId;
					api.informParentWin(updateDetail);
				}, 2000);
				if(updatedRecordsCnt < totalSelectedRecords){
					Notification.warning('<div class="bold-msg">Task(s) cleared for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s).<br>'
					 + (totalSelectedRecords - updatedRecordsCnt) + ' record(s) were not cleared due to one/all of the below reasons: <br>'
					 + ' a) You do not have privilege to clear task on selected record <br>'
					 + ' b) Task for selected record was already completed</div>');
				} else {
					Notification.success('<div class="bold-msg text-center">Task(s) cleared for ' + updatedRecordsCnt + ' / ' + totalSelectedRecords + ' record(s)</div>');
				}
			}, function(xhr) {
				$scope.xhr.clear = false;
				$scope.history.checkAll = false;
				xhr.errorTitle = lang.get("clear-action-error-msg");
				api.showServerErrMsg(xhr);
			});
		};

		/**
		 * @description In confirmation box. Click on YES button. 
		 * @param {*} parm pass deactive and clear action.
		 */

		$scope.continueConfirmMessage = function (param) {
			if (param.action == "deactive") {
				reactiveDeactive(param.action, param.actionID, param.filteredActionDrIds, param.filtrDataRes, param.selectedActions, param.listActionData);
			} else {
				$scope.continueClearAction(param.distributionListIds, param.totalSelectedRecords, param.listData);
			}
			$scope.confirmOpen = false;
		};

		/**
		 * @description In confirmation box. Click on NO button. 
		 * @param {*} parm pass deactive and clear action.
		 */
		$scope.closeConfirmMessage = function (param) {
			if (param.action == "deactive") {
				reactiveDeactive(param.action, param.actionID, param.filteredActionDrIds, param.filtrDataRes, param.selectedActions);
			} else {
				$scope.continueClearAction(param.distributionListIds, param.totalSelectedRecords);
			}
			$scope.confirmOpen = false;
		};
		
		$scope.applyDateToAll = function(bulk) {
			if(!$scope.filterList || !$scope.filterList.length) {
				return;
			}
			
			for(i = 0; i < $scope.filterList.length; i++) {
				$scope.filterList[i].duedate = $scope.delegate.bulkdate;					
			}
		};

		$scope.delegate = {
			dueType: "0",
			userList: [],
			incompleteActions: {},
			user: [],
			active: false,
			bulkdate: ""
		};
		
		$scope.delegateAction = function(data) {
			if(!$scope.action.delagateAction) {
				return;
			}
			
			$scope.delegate.active = true;
			fetchDistData();
		};
		
		$scope.cancelDelegate = function() {
			$scope.delegate.userList = [];
			$scope.delegate.incompleteActions = {};
			$scope.delegate.user = [];
			$scope.delegate.active = false;
			$scope.delegate.bulkdate = "";
			$scope.delegate.dueType = "0";
			clearDuedates();
		};
		
		$scope.isDelegateValid = function() {
			if(!$scope.delegate.user || !$scope.delegate.user.length) {
				return false;
			}
			
			if(!$scope.history.selection || !$scope.history.selection.length) {
				return false;
			}
			
			for(i = 0; i < $scope.history.selection.length; i++) {
				var data = $scope.history.selection[i];
				if($scope.delegate.dueType == 2 && data.action_status == "Incomplete" && !data.duedate) {
					return false;
				}
			}
			
			return true;
		};
		
		$scope.continueDelegate = function() {
			if($scope.xhr.dist || $scope.xhr.delegate) {
				return;
			}
			
			if(!$scope.isDelegateValid()) {
				return;
			}
			
			var user = $scope.delegate.user[0].item;
			var actions = getActions('Incomplete');
			var validActions = [];

			for(var i = 0; i < $scope.delegate.validUsersList.length; i++) {
				var userList = $scope.delegate.validUsersList[i];
				for(var j = 0; j < actions.length; j++){
					var incompleteAction = actions[j];
					if(incompleteAction.dist_list_id.split("$$")[0] == userList.revisionDistListId.split("$$")[0]
						&& incompleteAction.action_id == userList.actionId
						&& incompleteAction.user_id == userList.recipient_user_id.split("$$")[0]) {
							validActions.push(incompleteAction);
					}
				}		
			}
			var param = {
				action_id: apiConfig.DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_SUBMIT,
				project_id: myConfig.projectId,
				drId: getIdString(validActions),
				drReportId: getIdString(validActions, true),
				distlistcount : $scope.delegate.incompleteActions.totalDocs || 0,
				"UserSessionProfile.proxyOrgName": validActions[0].proxyUserOrg,
				"UserSessionProfile.proxyUserName": validActions[0].proxyUserName,
				"UserSessionProfile.tpdOrgName": validActions[0].user_org_name,
				"UserSessionProfile.tpdUserName": validActions[0].user_name,
				actionDueDateType: $scope.delegate.dueType,
				selected_user_type: user.user_type,
				selected_username: user.username,
				userId: user.userID,
				selected_orgname: user.orgName,
				orgId: user.hashedOrgID,
				isFromRemoveUser : 'null',
			};
			
			var incompleteActions = $scope.delegate.incompleteActions.data[0];
			if(incompleteActions && incompleteActions.length) {
				for (var i = 0; i < incompleteActions.length; i++) {
					var index = i + 1;
					var obj = incompleteActions[i];
					param['revision-id' + index] = obj.revisionId;
					param['recipient-user-id' + index] = obj.recipient_user_id;
					param['folder-id' + index] = obj.folder_id;
					param['revision-dist-list-id' + index] = obj.revisionDistListId;
					param['delegated' + index] = false;
					param['action-id' + index] = obj.actionId;
					param['action-name' + index] = obj.recipientFullActioName;
				}
			}
			
			if($scope.delegate.dueType == 2) {
				for (var i = 0; i < validActions.length; i++) {
					var action = validActions[i];
					param['NewActionDueDate' + (i + 1)] = action.duedate;
				}
			}
			
			$scope.distStatus = { status: 'distributing' };
			
			$scope.xhr.delegate = api.ajax({
				url  : apiConfig.DOCUMENT_CONTROLLER,
				data : param
			});
			
			$scope.xhr.delegate.then(function(response) {
				var totalSelectedRecords =  getActions('Incomplete').length;
				$scope.distStatus = { status: 'distributed' };
				$scope.xhr.delegate = false;
				$scope.history.selection = [];
				$scope.cancelDelegate();
				fetch();
				$timeout(function() {
					var updateDetail = {};
					updateDetail[apiConfig.entity.FILE] = validActions[0].revisionId;
					api.informParentWin(updateDetail);
				}, 2000);
				if(response.notDelegated > 0 ||response.notDelegatedForStatusChange > 0 )  {
					Notification.warning('<div class="bold-msg">Task(s) delegated for ' + response.delegated + ' / ' + totalSelectedRecords + ' record(s).<br>'
					+ (response.notDelegated + response.notDelegatedForStatusChange) + ' record(s) were not delegated due to one/all of the reasons mentioned below: <br>'
					+ ' a) You do not have privilege to delegate task on selected record <br>'
					+ ' b) Recipient user does not have privilege to be assigned the selected task<br>'
					+ ' c) Task(s) are either cleared/delegated for selected records </div>');
				}
				else if(validActions.length < totalSelectedRecords) {
					Notification.warning('<div class="bold-msg">Task(s) delegated for ' + validActions.length + ' / ' + totalSelectedRecords + ' record(s).<br>'
					 + (totalSelectedRecords - validActions.length) + ' record(s) were not delegated due to one/all of the reasons mentioned below: <br>'
					 + ' a) You do not have privilege to delegate task on selected record <br>'
					 + ' b) Recipient user does not have privilege to be assigned the selected task<br>'
					 + ' c) Task(s) are either cleared/delegated for selected records </div>');
				} else {
					Notification.success('<div class="bold-msg text-center">' + validActions.length + ' ' + lang.get('delegateConfirmMsg') + '</div>');
				}
			}, function(xhr) {
				$scope.xhr.delegate = false;
				$scope.distStatus = { status: 'Failed' };
				//Notification.error('<div class="bold-msg text-center">Error while updating!</div>');
				xhr.errorTitle = lang.get("delegate-action-error-msg");
				api.showServerErrMsg(xhr);
			});
		};

		$scope.openRevision = function(revData) {
			for (var i = 0; i < $scope.revList.length; i++) {
				if(revData.revisionId == $scope.revList[i].revisionId) {
					revData = $scope.revList[i];
					break;
				}
			}
			
			var data = {
		        projectId: revData.projectId,
		        revisionId: revData.revisionId,
		        documentId: revData.documentId, //
		        folderId: revData.folderId,
		        hasOnlineViewerSupport: revData.hasOnlineViewerSupport, //
		        toOpen: "FromFile",
		        dcId: revData.dcId, //
		        documentTypeId: revData.documentTypeId,
		        viewerId: revData.viewerId, //
		        isFromFileViewForDomain: "true",
		        isActive: revData.isActive
		    };
			
			api.viewFile(data);
		};

		$scope.openAttachment = function(item) {	
			var hasOnlineViewerSupport = item.hasOnlineViewerSupportForAttachment;
			if(!hasOnlineViewerSupport && myConfig.viewerPreference == '7') {
				item.hasOnlineViewerSupportForAttachment = api.isZip(item.fileName);
			}		
			if(!item.hasOnlineViewerSupportForAttachment) {
				if($scope.history.canDownloadFile) {
					api.downloadAttachmentFile(item);
				} else {
					Notification.error(lang.get("disabled-enabled-download-button"));
				}
				return;
			}
			
			api.openAttachment({
				projectId: item.projectId,
				fileName: item.attachImgName,
				revisionId: item.revisionId,
				commingFrom: 'File',
				isFromFileViewForDomain: true,
				commingFrom: "internalAttachment",
				attachmentId: item.attachmentId,
				method: 'POST'
			}, item.dcId);
		};
		
		$scope.openReview = function(item) {
			api.openReview(item);
		}
		
		$scope.editShareLink = function(item) {
			item.isEdit = true;
			item.documentFolderPath = item.documentFolderPath || myConfig.documentFolderPath;
			item.documentFolderPath = decodeURI(item.documentFolderPath).replace(/\+/g, ' ');
			item.uploadFilename = item.uploadFilename || item.fileName || myConfig.fileName;
			item.documentId = item.documentId || myConfig.documentId;
			item.dcId = item.dcId || myConfig.dcId;
			$rootScope.$broadcast('dd:close', { name: 'history', force: true});
			$rootScope.$broadcast('dd:open', { name: 'share-link', data: item});
		};
	}],
	bindings: {
		parentExpanded: '=',
		forCustomObject: '=',
		customObjectParam: '<'
	}
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbS5vYmplY3QudXRpbC5qcyIsImN1c3RvbS5vYmplY3Qudmlldy5qcyIsImN1c3RvbS5vYmplY3QuZm9ybS5qcyIsImN1c3RvbS5vYmplY3QubGlzdC5qcyIsImZpbGUuaGlzdG9yeS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDOU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDaGtCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUM3aUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDaFNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiY3VzdG9tT2JqZWN0QnVuZGxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEN1c3RvbSBvYmplY3QgY29tbW9uIHV0aWxpdHkgc2VydmljZXNcclxuICovXHJcbmFuZ3VsYXIubW9kdWxlKFwiYWRvZGRsZVwiKS5zZXJ2aWNlKCdjdXN0b21PYmplY3RVdGlsJywgWyckd2luZG93JywgJyRyb290U2NvcGUnLCAnJHRpbWVvdXQnLCAnTm90aWZpY2F0aW9uJywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICdhcGknLCAnbGFuZycsICdkZGNoaWxkJyxcclxuZnVuY3Rpb24oJHdpbmRvdywgJHJvb3RTY29wZSwgJHRpbWVvdXQsIE5vdGlmaWNhdGlvbiwgYXBpQ29uZmlnLCBteUNvbmZpZywgYXBpLCBsYW5nLCBkZGNoaWxkKSB7XHJcbiAgICB2YXIgY3VzdG9tT2JqZWN0VXRpbCA9IHRoaXM7XHJcbiAgICB2YXIgY3VzdG9tT2JqZWN0VHlwZU1hcCA9IHtcclxuICAgICAgICBNT0RFTF9CQ0ZfSVNTVUU6IHtcclxuICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkOiAxLFxyXG4gICAgICAgICAgICBnZXRUZW1wbGF0ZURldGFpbHMgOiAnZ2V0QkNGSXNzdWVUZW1wbGF0ZURldGFpbHMnLFxyXG4gICAgICAgICAgICBmZXRjaEFuZEdldFRlbXBsYXRlRGV0YWlsczogJ2ZldGNoQW5kR2V0QkNGSXNzdWVUZW1wbGF0ZURldGFpbHMnLFxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICB2YXIgdGVtcGxhdGVMYW5ndWFnZUtleXMgPSBbJ2N1c3RvbU9iamVjdFRpdGxlJywgJ2N1c3RvbU9iamVjdERlc2MnLCAnY3VzdG9tT2JqZWN0Q3JlYXRlVGl0bGUnLFxyXG4gICAgICAgICdjdXN0b21PYmplY3RDcmVhdGVCdXR0b25UZXh0JywgJ2N1c3RvbU9iamVjdEVkaXRUaXRsZSddO1xyXG5cclxuICAgIGZ1bmN0aW9uIGNvbXBhcmVJZChoYXNoSWQxLCBoYXNoSWQyKSB7XHJcbiAgICAgICAgdmFyIGlkMSA9IChoYXNoSWQxIHx8ICcnKS50b1N0cmluZygpLnNwbGl0KCckJCcpWzBdO1xyXG4gICAgICAgIHZhciBpZDIgPSAoaGFzaElkMiB8fCAnJykudG9TdHJpbmcoKS5zcGxpdCgnJCQnKVswXTtcclxuICAgICAgICByZXR1cm4gaWQxID09IGlkMjtcclxuICAgIH1cclxuXHJcbiAgICBjdXN0b21PYmplY3RVdGlsLmZpbmRUZW1wbGF0ZSA9IGZ1bmN0aW9uKHR5cGUsIGRhdGEpIHtcclxuICAgICAgICBpZighZGF0YSB8fCAhZGF0YS50ZW1wbGF0ZXMgfHwgIWRhdGEudGVtcGxhdGVzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBjdXN0b21PYmplY3RUZW1wbGF0ZTtcclxuICAgICAgICB2YXIgY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkID0gY3VzdG9tT2JqZWN0VHlwZU1hcFt0eXBlXS5jdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQ7XHJcbiAgICAgICAgZGF0YS50ZW1wbGF0ZXMuc29tZShmdW5jdGlvbih0ZW1wbGF0ZSl7XHJcbiAgICAgICAgICAgIGlmKGNvbXBhcmVJZCh0ZW1wbGF0ZS5jdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQsIGN1c3RvbU9iamVjdFRlbXBsYXRlR3JvdXBJZCkpIHtcclxuICAgICAgICAgICAgICAgIGN1c3RvbU9iamVjdFRlbXBsYXRlID0gdGVtcGxhdGU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBjdXN0b21PYmplY3RUZW1wbGF0ZTtcclxuICAgIH07XHJcblxyXG4gICAgZnVuY3Rpb24gcGFyc2VUZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyhkZXRhaWxzKXtcclxuICAgICAgICB2YXIgcGFyc2VkRGV0YWlscyA9IHt9O1xyXG5cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGVtcGxhdGVMYW5ndWFnZUtleXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdmFyIGtleSA9IHRlbXBsYXRlTGFuZ3VhZ2VLZXlzW2ldO1xyXG4gICAgICAgICAgICB2YXIgbGFuZ0tleSA9IGRldGFpbHNba2V5XTtcclxuICAgICAgICAgICAgaWYobGFuZ0tleSkge1xyXG4gICAgICAgICAgICAgICAgcGFyc2VkRGV0YWlsc1trZXldID0gbGFuZy5nZXQobGFuZ0tleSkgfHwgbGFuZ0tleTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHBhcnNlZERldGFpbHM7XHJcbiAgICB9XHJcblxyXG4gICAgZnVuY3Rpb24gZXhwb3J0QkNGSXNzdWVzKGFjdGlvbiwgc2VsZWN0ZWRJdGVtcywgdGVtcGxhdGVEZXRhaWxzKXtcclxuICAgICAgICB2YXIgcmVxdWVzdERhdGEgPSB7XHJcbiAgICAgICAgICAgIGN1c3RvbU9iamVjdDogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVJZDogdGVtcGxhdGVEZXRhaWxzLmN1c3RvbU9iamVjdFRlbXBsYXRlSWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQ6IHRlbXBsYXRlRGV0YWlscy5jdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZVR5cGVJZDogdGVtcGxhdGVEZXRhaWxzLmN1c3RvbU9iamVjdFRlbXBsYXRlVHlwZUlkLFxyXG4gICAgICAgICAgICAgICAgcHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICBlbnRpdHlJZDogbXlDb25maWcubW9kZWxfaWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RDb250ZXh0SWQ6IGFwaUNvbmZpZy5jdXN0b21PYmplY3QuTU9ERUxfQ09OVEVYVF9JRFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmKGFjdGlvbi5lbmFibGVPblJvd1NlbGVjdGlvbiAmJiBzZWxlY3RlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgIHJlcXVlc3REYXRhLnNlbGVjdGVkSXNzdWVJZHMgPSBzZWxlY3RlZEl0ZW1zLm1hcChmdW5jdGlvbihpdGVtKXtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpdGVtLmN1c3RvbU9iamVjdEluc3RhbmNlSWQ7XHJcbiAgICAgICAgICAgIH0pLmpvaW4oJywnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG4gICAgICAgIE5vdGlmaWNhdGlvbi5zdWNjZXNzKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogJzxkaXYgY2xhc3M9XCJib2xkLW1zZyB0ZXh0LWNlbnRlclwiPicgKyBsYW5nLmdldChcImRvd25sb2FkLWhhcy1iZWVuLXN0YXJ0ZWRcIikgKyAnPC9kaXY+JyxcclxuICAgICAgICAgICAgZGVsYXk6ICdubydcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdmFyIHhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuUFJFUEFSRV9FWFBPUlRfQkNGX0lTU1VFLFxyXG4gICAgICAgICAgICBkYXRhOiByZXF1ZXN0RGF0YVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB4aHIudGhlbihmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgIHhoci5kb3dubG9hZEZhaWxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB3aW5kb3cuc2V0VGltZW91dChmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgaWYoIXhoci5kb3dubG9hZEZhaWxlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LCAyMDAwKTtcclxuICAgICAgICAgICAgalF1ZXJ5LmZpbGVEb3dubG9hZChhcGlDb25maWcuRVhQT1JUX0JDRl9JU1NVRSwge1xyXG4gICAgICAgICAgICAgICAgaHR0cE1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICAgICAgZGF0YTogZGF0YSxcclxuICAgICAgICAgICAgICAgIGZhaWxDYWxsYmFjazogZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICB4aHIuZG93bmxvYWRGYWlsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5lcnJvcignPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+JyArICdFeHBvcnQgZmFpbGVkLiAgUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci4nICsgJzwvZGl2PicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9LCBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICAgICAgTm90aWZpY2F0aW9uLmNsZWFyQWxsKCk7XHJcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5lcnJvcignPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+JyArICdFeHBvcnQgZmFpbGVkLiAgUGxlYXNlIHRyeSBhZ2FpbiBsYXRlci4nICsgJzwvZGl2PicpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBjdXN0b21PYmplY3RVdGlsLmdldEJDRklzc3VlVGVtcGxhdGVEZXRhaWxzID0gZnVuY3Rpb24odHlwZSwgY3VzdG9tT2JqZWN0VGVtcGxhdGUpe1xyXG4gICAgICAgIHZhciBkZWZhdWx0RGV0YWlscyA9IHtcclxuICAgICAgICAgICAgdHlwZTogdHlwZSxcclxuICAgICAgICAgICAgY2FuQWNjZXNzOiBmYWxzZSxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICB2aWV3T25seTogdHJ1ZSxcclxuICAgICAgICAgICAgdmlld0lzc3VlRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBlcnJvck1zZzogbGFuZy5nZXQoJ25vLWFjY2VzcycpLFxyXG4gICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZUlkOiAnJyxcclxuICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkOiAnJyxcclxuICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVUeXBlSWQ6ICcnLFxyXG4gICAgICAgICAgICBjb25maWc6IHtcclxuICAgICAgICAgICAgICAgIGVudGl0eUlkOiAnJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYoIWN1c3RvbU9iamVjdFRlbXBsYXRlKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0RGV0YWlscztcclxuICAgICAgICB9XHJcbiAgICAgICAgLyoqXHJcbiAgICAgICAgICogdXNlIHdoZW4gcmV2aXQgYW5kIGlmYyBib3RoIGFyZSBoYW5kbGVkIGZvciBpc3N1ZSBtYW5hZ2VyXHJcbiAgICAgICAgICogdmFyIGlzRGlzYWJsZWQgPSBteUNvbmZpZy5maWxlRXh0LnRvTG93ZXJDYXNlKCkgIT0gXCJpZmNcIiAmJiBteUNvbmZpZy5maWxlRXh0LnRvTG93ZXJDYXNlKCkgIT0gXCJydnRcIjsgXHJcbiAgICAgICAgICovXHJcbiAgICAgICAgIHZhciBpc0Rpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICB2YXIgdmlld09ubHkgPSB0cnVlO1xyXG4gICAgICAgIGlmKCR3aW5kb3cuU1lTVEVNUFJJVklMRUdFUyAmJiAkd2luZG93LnZpZXdlclByb2plY3RJZCkge1xyXG4gICAgICAgICAgICB2YXIgcHJpdmlsZWdlcyA9ICR3aW5kb3cuU1lTVEVNUFJJVklMRUdFUy51c2VyUHJpdmlsZWdlc1skd2luZG93LnZpZXdlclByb2plY3RJZF07XHJcbiAgICAgICAgICAgIGlmKGFwaS5oYXNBY2Nlc3MocHJpdmlsZWdlcywgJ0NBTl9DUkVBVEVfSVNTVUUnKSkge1xyXG4gICAgICAgICAgICAgICAgdmlld09ubHkgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHRlbXBsYXRlRGV0YWlscyA9IHtcclxuICAgICAgICAgICAgdHlwZTogdHlwZSxcclxuICAgICAgICAgICAgY2FuQWNjZXNzOiB0cnVlLFxyXG4gICAgICAgICAgICBkaXNhYmxlZDogaXNEaXNhYmxlZCxcclxuICAgICAgICAgICAgdmlld09ubHk6IHZpZXdPbmx5LFxyXG4gICAgICAgICAgICB2aWV3SXNzdWVGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIGVycm9yTXNnOiBsYW5nLmdldCgnZmlsZVR5cGVOb3RBbGxvd2VkJyksXHJcbiAgICAgICAgICAgIHRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzOiBwYXJzZVRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzKGN1c3RvbU9iamVjdFRlbXBsYXRlLnRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzKSxcclxuICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVJZDogY3VzdG9tT2JqZWN0VGVtcGxhdGUuY3VzdG9tT2JqZWN0VGVtcGxhdGVJZCxcclxuICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkOiBjdXN0b21PYmplY3RUZW1wbGF0ZS5jdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQsXHJcbiAgICAgICAgICAgIGN1c3RvbU9iamVjdFRlbXBsYXRlVHlwZUlkOiBjdXN0b21PYmplY3RUZW1wbGF0ZS5jdXN0b21PYmplY3RUZW1wbGF0ZVR5cGVJZCxcclxuICAgICAgICAgICAgY29uZmlnOiB7XHJcbiAgICAgICAgICAgICAgICBlbnRpdHlJZDogbXlDb25maWcubW9kZWxfaWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHZhciBhY3Rpb25IYW5kbGVyID0gZnVuY3Rpb24oYWN0aW9uLCBzZWxlY3RlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgIGV4cG9ydEJDRklzc3VlcyhhY3Rpb24sIHNlbGVjdGVkSXRlbXMsIHRlbXBsYXRlRGV0YWlscyk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYoIXZpZXdPbmx5KSB7XHJcbiAgICAgICAgICAgIHRlbXBsYXRlRGV0YWlscy5jb25maWcudmVydE1vcmVBY3Rpb25zID0gW3tcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdleHBvcnQtc2VsZWN0ZWQnLFxyXG4gICAgICAgICAgICAgICAgbGFiZWw6ICdFeHBvcnQgU2VsZWN0ZWQnLFxyXG4gICAgICAgICAgICAgICAgZW5hYmxlT25Sb3dTZWxlY3Rpb246IHRydWUsXHJcbiAgICAgICAgICAgICAgICBhY3Rpb25IYW5kbGVyOiBhY3Rpb25IYW5kbGVyXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdleHBvcnQtYWxsJyxcclxuICAgICAgICAgICAgICAgIGxhYmVsOiAnRXhwb3J0IEFsbCcsXHJcbiAgICAgICAgICAgICAgICBlbmFibGVPblJvd1NlbGVjdGlvbjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBhY3Rpb25IYW5kbGVyOiBhY3Rpb25IYW5kbGVyXHJcbiAgICAgICAgICAgIH1dO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGVtcGxhdGVEZXRhaWxzO1xyXG4gICAgfTtcclxuXHJcbiAgICBjdXN0b21PYmplY3RVdGlsLmZldGNoQW5kR2V0QkNGSXNzdWVUZW1wbGF0ZURldGFpbHMgPSBmdW5jdGlvbih0eXBlLCBjYWxsYmFjayl7XHJcbiAgICAgICAgLy8gMyBNT0RFTCBjb250ZXh0XHJcbiAgICAgICAgYXBpLmdldEN1c3RvbU9iamVjdFRlbXBsYXRlTGlzdChmdW5jdGlvbihkYXRhKXtcclxuICAgICAgICAgICAgdmFyIGN1c3RvbU9iamVjdFRlbXBsYXRlID0gY3VzdG9tT2JqZWN0VXRpbC5maW5kVGVtcGxhdGUodHlwZSwgZGF0YSk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrKGN1c3RvbU9iamVjdFV0aWwuZ2V0QkNGSXNzdWVUZW1wbGF0ZURldGFpbHModHlwZSwgY3VzdG9tT2JqZWN0VGVtcGxhdGUpKTtcclxuICAgICAgICB9LCBhcGlDb25maWcuY3VzdG9tT2JqZWN0Lk1PREVMX0NPTlRFWFRfSUQpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjdXN0b21PYmplY3RVdGlsLmdldFRlbXBsYXRlRGV0YWlscyA9IGZ1bmN0aW9uKHR5cGUsIGN1c3RvbU9iamVjdFRlbXBsYXRlKXtcclxuICAgICAgICB2YXIgbWFwVmFsdWUgPSBjdXN0b21PYmplY3RUeXBlTWFwW3R5cGVdO1xyXG4gICAgICAgIGlmKCFtYXBWYWx1ZSkge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogdHlwZSxcclxuICAgICAgICAgICAgICAgIGNhbkFjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY3VzdG9tT2JqZWN0VXRpbFttYXBWYWx1ZS5nZXRUZW1wbGF0ZURldGFpbHNdKHR5cGUsIGN1c3RvbU9iamVjdFRlbXBsYXRlKTtcclxuICAgIH07XHJcblxyXG4gICAgY3VzdG9tT2JqZWN0VXRpbC5mZXRjaEFuZEdldFRlbXBsYXRlRGV0YWlscyA9IGZ1bmN0aW9uKHR5cGUsIGNhbGxiYWNrKXtcclxuICAgICAgICB2YXIgbWFwVmFsdWUgPSBjdXN0b21PYmplY3RUeXBlTWFwW3R5cGVdO1xyXG4gICAgICAgIGlmKCFtYXBWYWx1ZSkge1xyXG4gICAgICAgICAgICBjYWxsYmFjayhjdXN0b21PYmplY3RVdGlsLmdldFRlbXBsYXRlRGV0YWlscyh0eXBlKSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjdXN0b21PYmplY3RVdGlsW21hcFZhbHVlLmZldGNoQW5kR2V0VGVtcGxhdGVEZXRhaWxzXSh0eXBlLCBjYWxsYmFjayk7XHJcbiAgICB9O1xyXG5cclxuICAgIGN1c3RvbU9iamVjdFV0aWwubmF2aWdhdGVUb0N1c3RvbU9iamVjdEluc3RhbmNlID0gZnVuY3Rpb24oZGV0YWlscywgZGVsYXkpe1xyXG4gICAgICAgIHZhciBuYXZpZ2F0ZSA9IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6b3BlbicsIHtcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdjdXN0b20tb2JqZWN0LXZpZXcnLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogZGV0YWlscy50eXBlLFxyXG4gICAgICAgICAgICAgICAgdGVtcGxhdGVMYW5ndWFnZURldGFpbHM6IGRldGFpbHMudGVtcGxhdGVMYW5ndWFnZURldGFpbHMsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZUlkOiBkZXRhaWxzLmN1c3RvbU9iamVjdFRlbXBsYXRlSWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZUdyb3VwSWQ6IGRldGFpbHMuY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVUeXBlSWQ6IGRldGFpbHMuY3VzdG9tT2JqZWN0VGVtcGxhdGVUeXBlSWQsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RJbnN0YW5jZUlkOiAkd2luZG93LmN1c3RvbU9iamVjdEluc3RhbmNlSWQsXHJcbiAgICAgICAgICAgICAgICB1cmxOYXZpZ2F0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgZG9ja1RpdGxlOiBkZXRhaWxzLnRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzLmN1c3RvbU9iamVjdFRpdGxlXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHZhciBjaGVja0FuZE5hdmlnYXRlID0gZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgaWYoZGRjaGlsZC5pc0xvYWRlZCgnY3VzdG9tLW9iamVjdC12aWV3JykpIHtcclxuICAgICAgICAgICAgICAgIG5hdmlnYXRlKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGRkY2hpbGQub25Mb2FkKCdjdXN0b20tb2JqZWN0LXZpZXcnLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgbmF2aWdhdGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgLy8gT24gcGFnZSBsb2FkIG5hdmlnYXRpb25cclxuICAgICAgICBpZihkZXRhaWxzLmNhbkFjY2VzcyAmJiAkd2luZG93LmN1c3RvbU9iamVjdFRlbXBsYXRlR3JvdXBJZCAmJiAkd2luZG93LmN1c3RvbU9iamVjdEluc3RhbmNlSWRcclxuICAgICAgICAgICAgJiYgY29tcGFyZUlkKGRldGFpbHMuY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkLCAkd2luZG93LmN1c3RvbU9iamVjdFRlbXBsYXRlR3JvdXBJZCkpIHtcclxuICAgICAgICAgICAgICAgIGlmKCFkZWxheSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrQW5kTmF2aWdhdGUoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAkdGltZW91dChjaGVja0FuZE5hdmlnYXRlLCBkZWxheSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIFxyXG59XSkiLCJhbmd1bGFyLm1vZHVsZShcImFkb2RkbGVcIikuY29tcG9uZW50KCdjdXN0b21PYmplY3RWaWV3Jywge1xyXG5cdHRlbXBsYXRlVXJsOiAnL2Fkb2RkbGUvdmlldy9uZXd1aS9jdXN0b20tb2JqZWN0L2N1c3RvbS5vYmplY3Qudmlldy5qc3AnLFxyXG5cdGNvbnRyb2xsZXI6IFsnJHJvb3RTY29wZScsICckc2NvcGUnLCAnJHRpbWVvdXQnLCAnTm90aWZpY2F0aW9uJywgJ2xhbmcnLCAnYXBpJywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICckd2luZG93JywgJyRlbGVtZW50JywgJ2RkY2hpbGQnLFxyXG5cdGZ1bmN0aW9uICgkcm9vdFNjb3BlLCAkc2NvcGUsICR0aW1lb3V0LCBOb3RpZmljYXRpb24sIGxhbmcsIGFwaSwgYXBpQ29uZmlnLCBteUNvbmZpZywgJHdpbmRvdywgJGVsZW1lbnQsIGRkY2hpbGQpIHtcclxuXHRcdHZhciBjdHJsID0gdGhpcztcclxuXHRcdHZhciBhZGRlZCA9IGZhbHNlO1xyXG5cdFx0dmFyIGN1c3RvbU9iamVjdFZpZXdDb21wb25lbnQ7XHJcblxyXG5cdFx0dmFyIGNvbW1lbnRDcmVhdGVUaXRsZUFjdGlvbnNDb250YWluZXJFbDtcclxuXHRcdHZhciBtb2RlbENvbW1lbnRUaXRsZUFjdGlvbnNDb250YWluZXJFbDtcclxuXHRcdHZhciBmaWxlSGlzdG9yeVRpdGxlQWN0aW9uc0NvbnRhaW5lckVsO1xyXG5cdFx0dmFyIHdvcmtmbG93VGl0bGVBY3Rpb25zQ29udGFpbmVyRWw7XHJcblx0XHR2YXIgY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCA9ICcnO1xyXG5cdFx0dmFyIGNsZWFyUGVuZGluZ1NlbGVjdE1vZGVsVmlldyA9IG51bGw7XHJcblx0XHR2YXIgZGVmYXVsdE9wZW5lZFRhYiA9IG51bGw7XHJcblx0XHR2YXIgZGF0YUVkaXRlZEFmdGVyT3BlbiA9IGZhbHNlO1xyXG5cclxuXHRcdCRzY29wZS5leHBhbmRlZCA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLmxvYWRpbmcgPSB0cnVlO1xyXG5cdFx0JHNjb3BlLnJlZnJlc2hpbmcgPSBmYWxzZTtcclxuXHRcdCRzY29wZS5zdGF0dXNDbG9zZWQgPSBmYWxzZTtcclxuXHRcdCRzY29wZS5zaG93Q29tbWVudENyZWF0ZSA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLndvcmtmbG93UGFyYW0gPSB7fTtcclxuXHRcdCRzY29wZS5hY3RpdmVUYWIgPSAnJztcclxuXHRcdCRzY29wZS50YWJzID0ge307XHJcblx0XHQkc2NvcGUucHJpdiA9IHtcclxuXHRcdFx0Y2FuQ3JlYXRlQ29tbWVudDogZmFsc2UsXHJcblx0XHRcdGNhbkRvd25sb2FkRmlsZTogZmFsc2UsXHJcblx0XHRcdGNhbk1hbmFnZU9iamVjdExpc3Q6IHRydWVcclxuXHRcdH07XHJcblx0XHQkc2NvcGUuY2FwdHVyZU1vZGVsVmlld09uQ29tbWVudCA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLm1vZGVsRGF0YSA9IGFuZ3VsYXIuZXh0ZW5kKHt9LCBteUNvbmZpZy5tb2RlbERhdGEpO1xyXG5cdFx0JHNjb3BlLm1vZGVsRGF0YS5jb21tZW50UGFyYW0gPSB7XHJcblx0XHRcdGNvbnRyb2xsZXI6IGFwaUNvbmZpZy5DUkVBVEVfQ1VTVE9NX09CSkVDVF9DT01NRU5ULFxyXG5cdFx0XHRpc1RlbXBsYXRlRGV0YWlsUmVxOiBmYWxzZVxyXG5cdFx0fTtcclxuXHRcdCRzY29wZS5oaXN0b3J5RGF0YSA9IHtcclxuXHRcdFx0cGFyYW06IHt9XHJcblx0XHR9O1xyXG5cclxuXHRcdGN0cmwuJG9uSW5pdCA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0c2V0RGVmYXVsdHMoKTtcclxuXHRcdFx0bGlzdGVuKCk7XHJcblx0XHRcdGRkY2hpbGQucmVnaXN0ZXIoJHNjb3BlLCAnY3VzdG9tLW9iamVjdC12aWV3Jyk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5iYWNrVG9MaXN0ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdG5hdmlnYXRlVG9MaXN0KCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdGN0cmwucmVmcmVzaCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZihjdXN0b21PYmplY3RWaWV3Q29tcG9uZW50KSB7XHJcblx0XHRcdFx0JHNjb3BlLnJlZnJlc2hpbmcgPSB0cnVlO1xyXG5cdFx0XHRcdGN1c3RvbU9iamVjdFZpZXdDb21wb25lbnQuaW5zdGFuY2UucmVmcmVzaCgpO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5vcGVuVGFiID0gZnVuY3Rpb24odGFiTmFtZSwgcmVmcmVzaFZpZXcpIHtcclxuXHRcdFx0ZGVmYXVsdE9wZW5lZFRhYiA9IG51bGw7XHJcblxyXG5cdFx0XHRpZigkc2NvcGUuYWN0aXZlVGFiID09IHRhYk5hbWUpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCRzY29wZS5hY3RpdmVUYWIgPSB0YWJOYW1lO1xyXG5cclxuXHRcdFx0aWYocmVmcmVzaFZpZXcpIHtcclxuXHRcdFx0XHRjdHJsLnJlZnJlc2goKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYoJHNjb3BlLmFjdGl2ZVRhYiA9PSAnY29tbWVudHMnKSB7XHJcblx0XHRcdFx0JHNjb3BlLnNob3dDb21tZW50Q3JlYXRlID0gZmFsc2U7XHJcblx0XHRcdFx0cHV0VGl0bGVBY3Rpb25zKG1vZGVsQ29tbWVudFRpdGxlQWN0aW9uc0NvbnRhaW5lckVsLCAnI21vZGVsQ29tbWVudCAudGl0bGUtc3ViLWFjdGlvbnMnKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0aWYoJHNjb3BlLmFjdGl2ZVRhYiA9PSAnd29ya2Zsb3dzJykge1xyXG5cdFx0XHRcdHB1dFRpdGxlQWN0aW9ucyh3b3JrZmxvd1RpdGxlQWN0aW9uc0NvbnRhaW5lckVsLCAnI3dvcmtmbG93TGlzdCAudGl0bGUtc3ViLWFjdGlvbnMnKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0aWYoJHNjb3BlLmFjdGl2ZVRhYiA9PSAnaGlzdG9yeScpIHtcclxuXHRcdFx0XHRwdXRUaXRsZUFjdGlvbnMoZmlsZUhpc3RvcnlUaXRsZUFjdGlvbnNDb250YWluZXJFbCwgJyNmaWxlSGlzdG9yeSAudGl0bGUtc3ViLWFjdGlvbnMnKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblxyXG5cdFx0JHNjb3BlLm9wZW5Db21tZW50Q3JlYXRlID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdChcImN1c3RvbS1vYmplY3Q6Y29tbWVudDpvcGVuY3JlYXRlXCIpO1xyXG5cdFx0XHQkc2NvcGUuc2hvd0NvbW1lbnRDcmVhdGUgPSB0cnVlO1xyXG5cdFx0XHRwdXRUaXRsZUFjdGlvbnMoY29tbWVudENyZWF0ZVRpdGxlQWN0aW9uc0NvbnRhaW5lckVsLCAnI2NyZWF0ZUNvbW1lbnQgLnRpdGxlLXN1Yi1hY3Rpb25zJyk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5jb21tZW50Q3JlYXRpb25DbG9zZWQgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0JHNjb3BlLnNob3dDb21tZW50Q3JlYXRlID0gZmFsc2U7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5jb21tZW50Q3JlYXRlZFN1Y2Nlc3MgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0JHNjb3BlLnNob3dDb21tZW50Q3JlYXRlID0gZmFsc2U7XHJcblx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdCgnY3VzdG9tLW9iamVjdDpjb21tZW50OnJlZnJlc2gnKTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIGxpc3RlbiA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0JHNjb3BlLiRvbignZGQ6Y2hhbmdlZCcsIG9uRERPcGVuQ2xvc2UpO1xyXG5cdFx0XHQkc2NvcGUuJG9uKCdjdXN0b20tb2JqZWN0OnZpZXc6cmVmcmVzaCcsIGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdGN0cmwucmVmcmVzaCgpO1xyXG5cdFx0XHR9KTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHNldERlZmF1bHRzID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRzY29wZS50YWJzID0ge1xyXG5cdFx0XHRcdGNvbW1lbnRzOiBmYWxzZSxcclxuXHRcdFx0XHR3b3JrZmxvd3M6IGZhbHNlLFxyXG5cdFx0XHRcdGhpc3Rvcnk6IGZhbHNlLFxyXG5cdFx0XHRcdGF0dGFjaG1lbnRzOiBmYWxzZSxcclxuXHRcdFx0XHR2aWV3czogZmFsc2UsXHJcblx0XHRcdFx0bGlua3M6IGZhbHNlXHJcblx0XHRcdH07XHJcblx0XHRcdHZhciBkZWZhdWx0c0RhdGEgPSB7XHJcblx0XHRcdFx0dGl0bGU6ICcnLFxyXG5cdFx0XHRcdG9wZW46IHRydWUsXHJcblx0XHRcdFx0dmlldzogJycsXHJcblx0XHRcdFx0dHJlZVNlbGVjdGlvbjogXCJcIixcclxuXHRcdFx0XHRsaXN0U2VsZWN0aW9uOiBbXSxcclxuXHRcdFx0XHRtb2RlbE5hbWU6IFwiXCIsXHJcblx0XHRcdFx0bGlzdFhocjogZmFsc2UsXHJcblx0XHRcdFx0bGlzdDogdW5kZWZpbmVkLFxyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0Y3RybC5hc3NvY1ZpZXdzRGF0YSA9IGFuZ3VsYXIuZXh0ZW5kKHt9LCBkZWZhdWx0c0RhdGEsIHtcclxuXHRcdFx0XHRhY3RpdmU6IDQsXHJcblx0XHRcdFx0dmlld3M6IHtcclxuXHRcdFx0XHRcdGRhdGE6IFtdLFxyXG5cdFx0XHRcdFx0aGFzRGV0YWlsczogdHJ1ZSxcclxuXHRcdFx0XHRcdG5vRGVsZXRlQWN0aW9uOiB0cnVlLFxyXG5cdFx0XHRcdFx0ZGVsZXRlTm90QWxsb3dlZDogdHJ1ZSxcclxuXHRcdFx0XHRcdGluZGV4OiA0XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0XHRjdHJsLmFzc29jQXR0YWNobWVudHNEYXRhID0gYW5ndWxhci5leHRlbmQoe30sIGRlZmF1bHRzRGF0YSwge1xyXG5cdFx0XHRcdGFjdGl2ZTogOCxcclxuXHRcdFx0XHRjdXN0b21PYmplY3RBdHRhY2htZW50czoge1xyXG5cdFx0XHRcdFx0ZGF0YTogW10sXHJcblx0XHRcdFx0XHRub0RlbGV0ZUFjdGlvbjogdHJ1ZSxcclxuXHRcdFx0XHRcdGRlbGV0ZURpc2FibGVkOiB0cnVlLFxyXG5cdFx0XHRcdFx0aW5kZXg6IDhcclxuXHRcdFx0XHR9LFxyXG5cdFx0XHR9KTtcclxuXHJcblx0XHRcdGN0cmwuYXNzb2NMaW5rc0RhdGEgPSBhbmd1bGFyLmV4dGVuZCh7fSwgZGVmYXVsdHNEYXRhLCB7XHJcblx0XHRcdFx0YWN0aXZlOiA5LFxyXG5cdFx0XHRcdGxpbmtzOiB7XHJcblx0XHRcdFx0XHRkYXRhOiBbXSxcclxuXHRcdFx0XHRcdG5vRGVsZXRlQWN0aW9uOiB0cnVlLFxyXG5cdFx0XHRcdFx0ZGVsZXRlRGlzYWJsZWQ6IHRydWUsXHJcblx0XHRcdFx0XHRpbmRleDogOVxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdH0pO1xyXG5cdFx0fTtcclxuXHJcblx0XHQvLyBpbnZva2Ugb24gZHJvcGRvd24gb3BlbiAvIGNsb3NlXHJcblx0XHR2YXIgY2xvc2VUaW1lb3V0ID0gdW5kZWZpbmVkO1xyXG5cdFx0dmFyIHByZXZWaXNpYmxlID0gdW5kZWZpbmVkO1xyXG5cdFx0dmFyIG9uRERPcGVuQ2xvc2UgPSBmdW5jdGlvbiAoZXZlbnQsIGRkKSB7XHJcblx0XHRcdGlmKCFkZCB8fCBkZC5uYW1lID09IFwiY3VzdG9tLW9iamVjdC1saXN0XCIpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmKGRkICYmIGRkLm5hbWUgPT0gJ2N1c3RvbS1vYmplY3QtdmlldycpIHtcclxuXHRcdFx0XHQkc2NvcGUuZXhwYW5kZWQgPSBkZC5leHBhbmRlZCB8fCBmYWxzZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYoZGQubmFtZSA9PSAnY3VzdG9tLW9iamVjdC12aWV3JyAmJiAoZGQuZXZlbnQgPT0gJ3NpemUnIHx8IGRkLmV2ZW50ID09ICdkb2NrJykpIHtcclxuXHRcdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0aWYoY3VzdG9tT2JqZWN0Vmlld0NvbXBvbmVudCkge1xyXG5cdFx0XHRcdFx0XHRjdXN0b21PYmplY3RWaWV3Q29tcG9uZW50Lmluc3RhbmNlLnJlc2l6ZSgpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sIDMwMCk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmKGRkLm5hbWUgPT0gJ2N1c3RvbS1vYmplY3QtdmlldycgJiYgZGQuZXZlbnQgPT0gJ3Zpc2liaWxpdHknKSB7XHJcblx0XHRcdFx0aWYocHJldlZpc2libGUgPT0gZGQudmlzaWJsZSkge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZihkZC52aXNpYmxlKSB7XHJcblx0XHRcdFx0XHQkdGltZW91dC5jYW5jZWwoY2xvc2VUaW1lb3V0KTtcclxuXHRcdFx0XHRcdHJlbmRlcihkZCk7XHJcblx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdCR0aW1lb3V0LmNhbmNlbChjbG9zZVRpbWVvdXQpO1xyXG5cdFx0XHRcdFx0Y2xvc2VUaW1lb3V0ID0gJHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHRcdGRlc3Ryb3koKTtcclxuXHRcdFx0XHRcdH0sIDUwMCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHByZXZWaXNpYmxlID0gZGQudmlzaWJsZTtcclxuXHRcdFx0fSBlbHNlIGlmKGRkLm5hbWUgIT0gXCJjdXN0b20tb2JqZWN0LXZpZXdcIikge1xyXG5cdFx0XHRcdCR0aW1lb3V0LmNhbmNlbChjbG9zZVRpbWVvdXQpO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBkZXN0cm95ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdGlmKCFhZGRlZCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0JHNjb3BlLmxvYWRpbmcgPSB0cnVlO1xyXG5cdFx0XHQkc2NvcGUuc3RhdHVzQ2xvc2VkID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS5zaG93Q29tbWVudENyZWF0ZSA9IGZhbHNlO1xyXG5cdFx0XHQkc2NvcGUuY2FwdHVyZU1vZGVsVmlld09uQ29tbWVudCA9IGZhbHNlO1xyXG5cdFx0XHQkc2NvcGUuYWN0aXZlVGFiID0gJyc7XHJcblx0XHRcdGFkZGVkID0gZmFsc2U7XHJcblx0XHRcdGN1c3RvbU9iamVjdEluc3RhbmNlSWQgPSAnJztcclxuXHRcdFx0JHNjb3BlLndvcmtmbG93VGFyZ2V0T2JqZWN0SWQgPSB7fTtcclxuXHJcblx0XHRcdGlmKGN1c3RvbU9iamVjdFZpZXdDb21wb25lbnQpIHtcclxuXHRcdFx0XHRjdXN0b21PYmplY3RWaWV3Q29tcG9uZW50LmRlc3Ryb3koKTtcclxuXHRcdFx0XHRjdXN0b21PYmplY3RWaWV3Q29tcG9uZW50ID0gbnVsbDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0c2V0RGVmYXVsdHMoKTtcclxuXHRcdFx0aWYoY2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3KSB7XHJcblx0XHRcdFx0Y2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3KCk7XHJcblx0XHRcdFx0Y2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3ID0gbnVsbDtcclxuXHRcdFx0fVxyXG5cdFx0XHQkc2NvcGUuJGFwcGx5KCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBvcGVuVGFiSWZOb0FjdGl2ZVRhYiA9IGZ1bmN0aW9uKHRhYk5hbWUpe1xyXG5cdFx0XHRpZigoIWRlZmF1bHRPcGVuZWRUYWIgfHwgZGVmYXVsdE9wZW5lZFRhYiA9PSB0YWJOYW1lKSAmJiAhJHNjb3BlLmFjdGl2ZVRhYikge1xyXG5cdFx0XHRcdCRzY29wZS5vcGVuVGFiKHRhYk5hbWUpO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBzZXRQcml2aWxlZ2VzID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRzY29wZS5wcml2LmNhbkNyZWF0ZUNvbW1lbnQgPSBmYWxzZTtcclxuXHJcblx0XHRcdGlmKCR3aW5kb3cuU1lTVEVNUFJJVklMRUdFUyAmJiBteUNvbmZpZy5wcm9qZWN0SWQpIHtcclxuXHRcdFx0XHR2YXIgcHJpdmlsZWdlcyA9ICR3aW5kb3cuU1lTVEVNUFJJVklMRUdFUy51c2VyUHJpdmlsZWdlc1tteUNvbmZpZy5wcm9qZWN0SWRdO1xyXG5cdFx0XHRcdGlmKGFwaS5oYXNBY2Nlc3MocHJpdmlsZWdlcywgJ0NBTl9DUkVBVEVfSVNTVUVfQ09NTUVOVCcpKSB7XHJcblx0XHRcdFx0XHQkc2NvcGUucHJpdi5jYW5DcmVhdGVDb21tZW50ID0gdHJ1ZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHJlbmRlciA9IGZ1bmN0aW9uIChkZCkge1xyXG5cdFx0XHRkZXN0cm95KCk7XHJcblxyXG5cdFx0XHRpZihkZC5pc0Zyb21Gb3JtKSB7XHJcblx0XHRcdFx0aWYoZGQuZGF0YUNoYW5nZWQpIHtcclxuXHRcdFx0XHRcdGRhdGFFZGl0ZWRBZnRlck9wZW4gPSB0cnVlO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRlbHNlIHtcclxuXHRcdFx0XHRkYXRhRWRpdGVkQWZ0ZXJPcGVuID0gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGRlZmF1bHRPcGVuZWRUYWIgPSBkZC5kZWZhdWx0T3BlbmVkVGFiIHx8IG51bGw7XHJcblx0XHRcdGN1c3RvbU9iamVjdEluc3RhbmNlSWQgPSBkZC5jdXN0b21PYmplY3RJbnN0YW5jZUlkIHx8ICcnO1xyXG5cdFx0XHRzZXRQcml2aWxlZ2VzKCk7XHJcblxyXG5cdFx0XHRpZihhZGRlZCkge1xyXG5cdFx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmKCFjb21tZW50Q3JlYXRlVGl0bGVBY3Rpb25zQ29udGFpbmVyRWwpIHtcclxuXHRcdFx0XHRjb21tZW50Q3JlYXRlVGl0bGVBY3Rpb25zQ29udGFpbmVyRWwgPSAkZWxlbWVudC5maW5kKCcjY29tbWVudENyZWF0ZVRpdGxlQWN0aW9ucycpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmKCFtb2RlbENvbW1lbnRUaXRsZUFjdGlvbnNDb250YWluZXJFbCkge1xyXG5cdFx0XHRcdG1vZGVsQ29tbWVudFRpdGxlQWN0aW9uc0NvbnRhaW5lckVsID0gJGVsZW1lbnQuZmluZCgnI21vZGVsQ29tbWVudFRpdGxlQWN0aW9ucycpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmKCFmaWxlSGlzdG9yeVRpdGxlQWN0aW9uc0NvbnRhaW5lckVsKSB7XHJcblx0XHRcdFx0ZmlsZUhpc3RvcnlUaXRsZUFjdGlvbnNDb250YWluZXJFbCA9ICRlbGVtZW50LmZpbmQoJyNmaWxlSGlzdG9yeVRpdGxlQWN0aW9ucycpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmKCF3b3JrZmxvd1RpdGxlQWN0aW9uc0NvbnRhaW5lckVsKSB7XHJcblx0XHRcdFx0d29ya2Zsb3dUaXRsZUFjdGlvbnNDb250YWluZXJFbCA9ICRlbGVtZW50LmZpbmQoJyN3b3JrZmxvd1RpdGxlQWN0aW9ucycpO1xyXG5cdFx0XHR9XHJcblx0XHRcdGFkZGVkID0gdHJ1ZTtcclxuXHJcblx0XHRcdGFwcGVuZEN1c3RvbU9iamVjdEZvcm0oZGQpO1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgZWRpdEN1c3RvbU9iamVjdCA9IGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KCdkZDpjbG9zZScsIHsgbmFtZTogJ2N1c3RvbS1vYmplY3QtdmlldycsIGV4cGFuZGVkOiAkc2NvcGUuZXhwYW5kZWQsIGZvcmNlOiB0cnVlIH0pO1xyXG5cdFx0XHQkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOm9wZW4nLCB7XHJcblx0XHRcdFx0bmFtZTogJ2N1c3RvbS1vYmplY3QtZm9ybScsXHJcblx0XHRcdFx0ZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCxcclxuXHRcdFx0XHR0eXBlOiBjdHJsLnR5cGUsXHJcblx0XHRcdFx0aXNGcm9tVmlldzogdHJ1ZSxcclxuXHRcdFx0XHRmcm9tVmlld0FjdGl2ZVRhYjogJHNjb3BlLmFjdGl2ZVRhYixcclxuXHRcdFx0XHR2aWV3T25seTogY3RybC52aWV3T25seSxcclxuXHRcdFx0XHR0ZW1wbGF0ZUxhbmd1YWdlRGV0YWlsczogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuXHRcdFx0XHR0ZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcblx0XHRcdFx0dGVtcGxhdGVHcm91cElkOiBjdHJsLnRlbXBsYXRlR3JvdXBJZCxcclxuXHRcdFx0XHR0ZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuXHRcdFx0XHRjb25maWc6IGN0cmwuY29uZmlnLFxyXG5cdFx0XHRcdGN1c3RvbU9iamVjdEluc3RhbmNlSWQ6IGl0ZW0uY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCxcclxuXHRcdFx0XHRkb2NrVGl0bGU6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMuY3VzdG9tT2JqZWN0RWRpdFRpdGxlXHJcblx0XHRcdH0pO1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgbmF2aWdhdGVUb0xpc3QgPSBmdW5jdGlvbigpe1xyXG5cdFx0XHQkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOmNsb3NlJywgeyBuYW1lOiAnY3VzdG9tLW9iamVjdC12aWV3JywgZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCwgZm9yY2U6IHRydWUgfSk7XHJcblx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6b3BlbicsIHtcclxuXHRcdFx0XHRuYW1lOiAnY3VzdG9tLW9iamVjdC1saXN0JyxcclxuXHRcdFx0XHRleHBhbmRlZDogJHNjb3BlLmV4cGFuZGVkLFxyXG5cdFx0XHRcdCd0eXBlJzogY3RybC50eXBlLFxyXG5cdFx0XHRcdCdpc0Zyb21WaWV3JzogdHJ1ZSxcclxuXHRcdFx0XHQnZGF0YUNoYW5nZWQnOiBkYXRhRWRpdGVkQWZ0ZXJPcGVuIHx8IGZhbHNlLFxyXG5cdFx0XHRcdCd2aWV3T25seSc6IGN0cmwudmlld09ubHksXHJcblx0XHRcdFx0J3RlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzJzogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuXHRcdFx0XHQndGVtcGxhdGVJZCc6IGN0cmwudGVtcGxhdGVJZCxcclxuXHRcdFx0XHQndGVtcGxhdGVHcm91cElkJzogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcblx0XHRcdFx0J3RlbXBsYXRlVHlwZUlkJzogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuXHRcdFx0XHQnY29uZmlnJzogY3RybC5jb25maWdcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBlbmRDdXN0b21PYmplY3RGb3JtID0gZnVuY3Rpb24oZGQpIHtcclxuXHRcdFx0dmFyICRlbCA9ICRlbGVtZW50LmZpbmQoJyNjdXN0b21PYmplY3RWaWV3Jyk7XHJcblx0XHRcdHZhciBjb21wb25lbnQgPSB3aW5kb3cuY3JlYXRlRHluYW1pY0FuZ3VsYXJDb21wb25lbnQoJ2Fkb2RkbGUtY3VzdG9tLW9iamVjdC12aWV3Jywge1xyXG5cdFx0XHRcdHByb2plY3RJZDogbXlDb25maWcucHJvamVjdElkLFxyXG5cdFx0XHRcdGVudGl0eUlkOiBjdHJsLmNvbmZpZy5lbnRpdHlJZCxcclxuXHRcdFx0XHRkY0lkOiBteUNvbmZpZy5MT0NBTF9EQ19JRCxcclxuXHRcdFx0XHR0eXBlOiBjdHJsLnR5cGUsXHJcblx0XHRcdFx0dmlld09ubHk6IGN0cmwudmlld09ubHksXHJcblx0XHRcdFx0dGVtcGxhdGVMYW5ndWFnZURldGFpbHM6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMsXHJcblx0XHRcdFx0dGVtcGxhdGVJZDogY3RybC50ZW1wbGF0ZUlkLFxyXG5cdFx0XHRcdHRlbXBsYXRlR3JvdXBJZDogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcblx0XHRcdFx0dGVtcGxhdGVUeXBlSWQ6IGN0cmwudGVtcGxhdGVUeXBlSWQsXHJcblx0XHRcdFx0b2JqZWN0SW5zdGFuY2VJZDogY3VzdG9tT2JqZWN0SW5zdGFuY2VJZFxyXG5cdFx0XHR9LCAkZWxbMF0pO1xyXG5cdFx0XHRjdXN0b21PYmplY3RWaWV3Q29tcG9uZW50ID0gY29tcG9uZW50O1xyXG5cclxuXHRcdFx0Y29tcG9uZW50Lmluc3RhbmNlLm9uTG9hZGVkLnN1YnNjcmliZShmdW5jdGlvbihkYXRhKSB7XHJcblx0XHRcdFx0JHNjb3BlLnJlZnJlc2hpbmcgPSBmYWxzZTtcclxuXHRcdFx0XHRvbkN1c3RvbU9iamVjdEZvcm1Mb2FkZWQoZGF0YSk7XHJcblxyXG5cdFx0XHRcdC8vIFNlbGVjdCBtb2RlbCB2aWV3IHdoZW4gY3VzdG9tIG9iamVjdCBlZGl0IGlzIG9wZW5lZCBieSBkZWZhdWx0IG9uIHBhZ2UgbG9hZFxyXG5cdFx0XHRcdGlmKGRkLnVybE5hdmlnYXRpb24pIHtcclxuXHRcdFx0XHRcdGRkLnVybE5hdmlnYXRpb24gPSBmYWxzZTtcclxuXHRcdFx0XHRcdHNlbGVjdE1vZGVsVmlldyhkYXRhKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0Y29tcG9uZW50Lmluc3RhbmNlLm9uTG9hZEZhaWxlZC5zdWJzY3JpYmUoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0JHNjb3BlLmxvYWRpbmcgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUucmVmcmVzaGluZyA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0XHRjb21wb25lbnQuaW5zdGFuY2Uub25FZGl0LnN1YnNjcmliZShmdW5jdGlvbihpdGVtKSB7XHJcblx0XHRcdFx0ZWRpdEN1c3RvbU9iamVjdChpdGVtKTtcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgY29uZmlndXJlV29ya2Zsb3dQYXJhbSA9IGZ1bmN0aW9uKCl7XHJcblx0XHRcdCRzY29wZS53b3JrZmxvd1BhcmFtID0ge1xyXG5cdFx0XHRcdHRhcmdldE9iamVjdElkOiBjdXN0b21PYmplY3RJbnN0YW5jZUlkXHJcblx0XHRcdH07XHJcblx0XHRcdG9wZW5UYWJJZk5vQWN0aXZlVGFiKCd3b3JrZmxvd3MnKTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIGNvbmZpZ3VyZUhpc3RvcnlQYXJhbSA9IGZ1bmN0aW9uKCl7XHJcblx0XHRcdCRzY29wZS5oaXN0b3J5RGF0YS5wYXJhbSA9IHtcclxuXHRcdFx0XHRjdXN0b21PYmplY3RJbnN0YW5jZUlkOiBjdXN0b21PYmplY3RJbnN0YW5jZUlkXHJcblx0XHRcdH07XHJcblx0XHRcdG9wZW5UYWJJZk5vQWN0aXZlVGFiKCdoaXN0b3J5Jyk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBjb25maWd1cmVDb21tZW50UGFyYW0gPSBmdW5jdGlvbihkYXRhKXtcclxuXHRcdFx0JHNjb3BlLmNhcHR1cmVNb2RlbFZpZXdPbkNvbW1lbnQgPSBkYXRhLmNvbW1lbnRPcHRpb25zLmNhcHR1cmVNb2RlbFZpZXdPbkNvbW1lbnQ7XHJcblx0XHRcdCRzY29wZS5tb2RlbERhdGEuY29tbWVudFBhcmFtLmN1c3RvbU9iamVjdCA9IHtcclxuXHRcdFx0XHRjdXN0b21PYmplY3RDb250ZXh0SWQ6IGFwaUNvbmZpZy5jdXN0b21PYmplY3QuTU9ERUxfQ09OVEVYVF9JRCxcclxuXHRcdFx0XHRjdXN0b21PYmplY3RUZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcblx0XHRcdFx0Y3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkOiBjdHJsLnRlbXBsYXRlR3JvdXBJZCxcclxuXHRcdFx0XHRjdXN0b21PYmplY3RUZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuXHRcdFx0XHRjdXN0b21PYmplY3RDb21tZW50VHlwZUlkOiBkYXRhLmNvbW1lbnRPcHRpb25zLmN1c3RvbU9iamVjdENvbW1lbnRUeXBlSWQsXHJcblx0XHRcdFx0Y3VzdG9tT2JqZWN0SW5zdGFuY2VJZDogY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCxcclxuXHRcdFx0XHRwcm9qZWN0SWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRlbnRpdHlJZDogY3RybC5jb25maWcuZW50aXR5SWRcclxuXHRcdFx0fTtcclxuXHRcdFx0b3BlblRhYklmTm9BY3RpdmVUYWIoJ2NvbW1lbnRzJyk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBvbkN1c3RvbU9iamVjdEZvcm1Mb2FkZWQgPSBmdW5jdGlvbihkYXRhKXtcclxuXHRcdFx0JHNjb3BlLnN0YXR1c0Nsb3NlZCA9IGRhdGEuc3RhdHVzQ2xvc2VkIHx8IGZhbHNlO1xyXG5cclxuXHRcdFx0aWYoZGF0YS5jb21tZW50T3B0aW9ucyAmJiBkYXRhLmNvbW1lbnRPcHRpb25zLmhhc0NvbW1lbnRzKSB7XHJcblx0XHRcdFx0JHNjb3BlLnRhYnMuY29tbWVudHMgPSB0cnVlO1xyXG5cdFx0XHRcdGNvbmZpZ3VyZUNvbW1lbnRQYXJhbShkYXRhKTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQkc2NvcGUudGFicy5jb21tZW50cyA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQkc2NvcGUudGFicy53b3JrZmxvd3MgPSB0cnVlO1xyXG5cdFx0XHRjb25maWd1cmVXb3JrZmxvd1BhcmFtKGRhdGEpO1xyXG5cdFx0XHQkc2NvcGUudGFicy5oaXN0b3J5ID0gdHJ1ZTtcclxuXHRcdFx0Y29uZmlndXJlSGlzdG9yeVBhcmFtKGRhdGEpO1xyXG5cclxuXHRcdFx0aWYoZGF0YS5tb2RlbFZpZXdPcHRpb25zICYmIGRhdGEubW9kZWxWaWV3T3B0aW9ucy5jYXB0dXJlTW9kZWxWaWV3KSB7XHJcblx0XHRcdFx0JHNjb3BlLnRhYnMudmlld3MgPSB0cnVlO1xyXG5cdFx0XHRcdGluc2VydFZpZXcoZGF0YS5tb2RlbFZpZXdPcHRpb25zLm1vZGVsVmlld3MsIGRhdGEubW9kZWxWaWV3T3B0aW9ucy5tb2RlbFZpZXdEYXRhKTtcclxuXHRcdFx0XHRvcGVuVGFiSWZOb0FjdGl2ZVRhYigndmlld3MnKTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQkc2NvcGUudGFicy52aWV3cyA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihkYXRhLmF0dGFjaG1lbnRPcHRpb25zICYmIGRhdGEuYXR0YWNobWVudE9wdGlvbnMuYXR0YWNobWVudEFsbG93ZWQpIHtcclxuXHRcdFx0XHQkc2NvcGUudGFicy5hdHRhY2htZW50cyA9IHRydWU7XHJcblx0XHRcdFx0b3BlblRhYklmTm9BY3RpdmVUYWIoJ2F0dGFjaG1lbnRzJyk7XHJcblx0XHRcdFx0aWYoZGF0YS5hdHRhY2htZW50T3B0aW9ucy5jb25maWcpIHtcclxuXHRcdFx0XHRcdGFwcGVuZEF0dGFjaG1lbnRMaXN0KGRhdGEuYXR0YWNobWVudE9wdGlvbnMuY29uZmlnLmF0dGFjaG1lbnRzKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0JHNjb3BlLnRhYnMuYXR0YWNobWVudHMgPSBmYWxzZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYoZGF0YS5saW5rT3B0aW9ucyAmJiBkYXRhLmxpbmtPcHRpb25zLmxpbmtzQWxsb3dlZCkge1xyXG5cdFx0XHRcdCRzY29wZS50YWJzLmxpbmtzID0gdHJ1ZTtcclxuXHRcdFx0XHRvcGVuVGFiSWZOb0FjdGl2ZVRhYignbGlua3MnKTtcclxuXHRcdFx0XHRpZihkYXRhLmxpbmtPcHRpb25zLmxpbmtzKSB7XHJcblx0XHRcdFx0XHRhcHBlbmRMaW5rcyhkYXRhLmxpbmtPcHRpb25zLmxpbmtzKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0JHNjb3BlLnRhYnMubGlua3MgPSBmYWxzZTtcclxuXHRcdFx0fVxyXG5cclxuXHJcblx0XHRcdCRzY29wZS5sb2FkaW5nID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHNlbGVjdE1vZGVsVmlldyA9IGZ1bmN0aW9uKGRhdGEpe1xyXG5cdFx0XHRpZihkYXRhLm1vZGVsVmlld09wdGlvbnMgJiYgZGF0YS5tb2RlbFZpZXdPcHRpb25zLm1vZGVsVmlld0RhdGEgJiZcclxuXHRcdFx0XHRkYXRhLm1vZGVsVmlld09wdGlvbnMubW9kZWxWaWV3RGF0YS52aWV3SWQpIHtcclxuXHRcdFx0XHRpZih3aW5kb3dbJ3NlbGVjdFZpZXcnXSkge1xyXG5cdFx0XHRcdFx0Y2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3ID0gd2luZG93WydzZWxlY3RWaWV3J10oZGF0YS5tb2RlbFZpZXdPcHRpb25zLm1vZGVsVmlld0RhdGEudmlld0lkLCB0cnVlKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHJcblx0XHR2YXIgYXBwZW5kQXR0YWNobWVudExpc3QgPSBmdW5jdGlvbihhdHRhY2htZW50cykge1xyXG5cdFx0XHRpZighYXR0YWNobWVudHMgfHwgIWF0dGFjaG1lbnRzLmxlbmd0aCkge1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NBdHRhY2htZW50c0RhdGEuY3VzdG9tT2JqZWN0QXR0YWNobWVudHMuZGF0YSA9IFtdO1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NBdHRhY2htZW50c0RhdGEuaGFzRGF0YSA9IGZhbHNlO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Y3RybC5hc3NvY0F0dGFjaG1lbnRzRGF0YS5jdXN0b21PYmplY3RBdHRhY2htZW50cy5kYXRhID0gW107XHJcblxyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgYXR0YWNobWVudHMubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgYXR0YWNobWVudCA9IGF0dGFjaG1lbnRzW2ldO1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NBdHRhY2htZW50c0RhdGEuY3VzdG9tT2JqZWN0QXR0YWNobWVudHMuZGF0YSA9IGN0cmwuYXNzb2NBdHRhY2htZW50c0RhdGEuY3VzdG9tT2JqZWN0QXR0YWNobWVudHMuZGF0YS5jb25jYXQoW3tcclxuXHRcdFx0XHRcdGRlbGV0ZURpc2FibGVkOiB0cnVlLFxyXG5cdFx0XHRcdFx0Y2FuRGVsZXRlOiB0cnVlLFxyXG5cdFx0XHRcdFx0Y2FuT3Blbjogd2luZG93WydwbGF0Zm9ybU5hbWUnXSA/IGZhbHNlIDogdHJ1ZSwgLy8gRGlzYWJsZWQgYXR0YWNobWVudCB2aWV3IHRlbXBvcmFyeSBmb3IgZXh0ZXJuYWwgcGxhdGZvcm1zIGkuZSBuYXZpc3dvcmtcclxuXHRcdFx0XHRcdGNhbkRvd25sb2FkRmlsZTogdHJ1ZSxcclxuXHRcdFx0XHRcdGl0ZW06IGF0dGFjaG1lbnQsXHJcblx0XHRcdFx0XHRyZXZpc2lvbklkOiBhdHRhY2htZW50LnJldmlzaW9uSWQsXHJcblx0XHRcdFx0XHRGaWxlTmFtZTogYXR0YWNobWVudC5maWxlTmFtZSxcclxuXHRcdFx0XHRcdEZpbGVUeXBlOiBhcGkuZ2V0RmlsZUV4dEltYWdlKGFwaS5nZXRFeHQoYXR0YWNobWVudC5maWxlTmFtZSkpLFxyXG5cdFx0XHRcdFx0UHVibGlzaGVyVXNlcklkOiBhdHRhY2htZW50LnB1Ymxpc2hlclVzZXJJZCxcclxuXHRcdFx0XHRcdEZpbGVTaXplOiBhdHRhY2htZW50LmZpbGVTaXplLFxyXG5cdFx0XHRcdFx0YXR0YWNoZWRCeTogYXR0YWNobWVudC5hdHRhY2hlZEJ5LFxyXG5cdFx0XHRcdFx0YXR0YWNoZWRCeU5hbWU6IGF0dGFjaG1lbnQuYXR0YWNoZWRCeU5hbWUsXHJcblx0XHRcdFx0XHRhdHRhY2hlZERhdGU6IGF0dGFjaG1lbnQuYXR0YWNoZWREYXRlXHJcblx0XHRcdFx0fV0pO1xyXG5cdFx0XHR9XHJcblx0XHRcdGN0cmwuYXNzb2NBdHRhY2htZW50c0RhdGEuaGFzRGF0YSA9IHRydWU7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBlbmRMaW5rcyA9IGZ1bmN0aW9uKGxpbmtzKSB7XHJcblx0XHRcdGN0cmwuYXNzb2NMaW5rc0RhdGEubGlua3MuZGF0YSA9IFtdO1xyXG5cclxuXHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8IGxpbmtzLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dmFyIGxpbmsgPSBsaW5rc1tpXTtcclxuXHRcdFx0XHRpbnNlcnRMaW5rKHtcclxuXHRcdFx0XHRcdGlkOiBsaW5rLmxpbmtJZCxcclxuXHRcdFx0XHRcdG5hbWU6IGxpbmsubGlua05hbWUsXHJcblx0XHRcdFx0XHRsaW5rOiBsaW5rLmxpbmtVcmwsXHJcblx0XHRcdFx0XHRkZWxldGVEaXNhYmxlZDogdHJ1ZSxcclxuXHRcdFx0XHRcdGNyZWF0ZWRCeUltYWdlczogbGluay5jcmVhdGVkQnlJbWFnZXMsXHJcblx0XHRcdFx0XHRjcmVhdGVkRGlzcGxheURhdGVUaW1lOiBsaW5rLmNyZWF0ZWREaXNwbGF5RGF0ZVRpbWUsXHJcblx0XHRcdFx0XHRjcmVhdGVkQnlGaXJzdE5hbWU6IGxpbmsuY3JlYXRlZEJ5Rmlyc3ROYW1lLFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihsaW5rcy5sZW5ndGgpIHtcclxuXHRcdFx0XHRjdHJsLmFzc29jTGlua3NEYXRhLmhhc0RhdGEgPSB0cnVlO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NMaW5rc0RhdGEuaGFzRGF0YSA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHJcblx0XHR2YXIgaW5zZXJ0TGluayA9IGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdFx0Y3RybC5hc3NvY0xpbmtzRGF0YS5saW5rcy5kYXRhID0gY3RybC5hc3NvY0xpbmtzRGF0YS5saW5rcy5kYXRhLmNvbmNhdChbe1xyXG5cdFx0XHRcdGlkOiBpdGVtLmlkLFxyXG5cdFx0XHRcdGRlbGV0ZURpc2FibGVkOiB0cnVlLFxyXG5cdFx0XHRcdG5hbWU6IGl0ZW0ubmFtZSxcclxuXHQgICAgXHQgICAgbGluazogaXRlbS5saW5rLFxyXG5cdFx0XHRcdGNyZWF0ZWRCeUltYWdlczogaXRlbS5jcmVhdGVkQnlJbWFnZXMgfHwgJycsXHJcblx0XHRcdFx0Y3JlYXRlZERpc3BsYXlEYXRlVGltZTogaXRlbS5jcmVhdGVkRGlzcGxheURhdGVUaW1lIHx8ICcnLFxyXG5cdFx0XHRcdGNyZWF0ZWRCeUZpcnN0TmFtZTogaXRlbS5jcmVhdGVkQnlGaXJzdE5hbWUgfHwgJycsXHJcblx0ICAgIFx0ICAgIGhyZWY6IC9eW2EtekEtWl0rOlxcL1xcLy8udGVzdChpdGVtLmxpbmspID8gaXRlbS5saW5rIDogKCdodHRwOi8vJyArIGl0ZW0ubGluaylcclxuXHRcdFx0fV0pO1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgaW5zZXJ0VmlldyA9IGZ1bmN0aW9uKG1vZGVsVmlld3MsIG1vZGVsVmlld0RhdGEpIHtcclxuXHRcdFx0aWYoIW1vZGVsVmlld3MgfHwgIW1vZGVsVmlld3MubGVuZ3RoKSB7XHJcblx0XHRcdFx0Y3RybC5hc3NvY1ZpZXdzRGF0YS52aWV3cy5kYXRhID0gW107XHJcblx0XHRcdFx0Y3RybC5hc3NvY1ZpZXdzRGF0YS5oYXNEYXRhID0gZmFsc2U7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRjdHJsLmFzc29jVmlld3NEYXRhLnZpZXdzLmRhdGEgPSBbXTtcclxuXHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8IG1vZGVsVmlld3MubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgdmlld0RhdGEgPSBtb2RlbFZpZXdzW2ldO1xyXG5cclxuXHRcdFx0XHRjdHJsLmFzc29jVmlld3NEYXRhLnZpZXdzLmRhdGEucHVzaCh7XHJcblx0XHRcdFx0XHRiaW1Nb2RlbE5hbWU6IG15Q29uZmlnLm1vZGVsRGF0YS5uYW1lLFxyXG5cdFx0XHRcdFx0Y2FuVmlldzogdHJ1ZSxcclxuXHRcdFx0XHRcdHZpZXdJZDogdmlld0RhdGEudmlld0lkLFxyXG5cdFx0XHRcdFx0Y3JlYXRlZERhdGU6IHZpZXdEYXRhLmNyZWF0ZWREYXRlLFxyXG5cdFx0XHRcdFx0dmlld05hbWU6IHZpZXdEYXRhLnZpZXdOYW1lLFxyXG5cdFx0XHRcdFx0Y3JlYXRvclVzZXJOYW1lOiB2aWV3RGF0YS5jcmVhdG9yVXNlck5hbWUsXHJcblx0XHRcdFx0XHRtb2RlbFR5cGVJbWFnZTogdmlld0RhdGEubW9kZWxUeXBlSW1hZ2UsXHJcblx0XHRcdFx0XHRtb2RlbFR5cGVOYW1lOiB2aWV3RGF0YS5tb2RlbFR5cGVOYW1lLFxyXG5cdFx0XHRcdFx0aGFzTWFya3VwOiB2aWV3RGF0YS5oYXNNYXJrdXAsXHJcblx0XHRcdFx0XHRtb2RlbE5hbWU6IHZpZXdEYXRhLm1vZGVsTmFtZSxcclxuXHRcdFx0XHRcdHByb2plY3ROYW1lOiB2aWV3RGF0YS5wcm9qZWN0TmFtZSxcclxuXHRcdFx0XHRcdGNyZWF0b3JCeUltYWdlczogdmlld0RhdGEuY3JlYXRvckJ5SW1hZ2VzXHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGN0cmwuYXNzb2NWaWV3c0RhdGEuaGFzRGF0YSA9IHRydWU7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBwdXRUaXRsZUFjdGlvbnMgPSBmdW5jdGlvbihjb250YWluZXJFbCwgc2VsZWN0b3IpIHtcclxuXHRcdFx0Y29udGFpbmVyRWwuaHRtbCgnJyk7XHJcblxyXG5cdFx0XHQvLyB0YWtlIGFjdGlvbnMgaW4gaGVhZGVyXHJcblx0XHRcdHZhciBhcHBlbmRUaXRsZUFjdGlvbnMgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0XHR2YXIgJGFjdGlvbnMgPSAkZWxlbWVudC5maW5kKHNlbGVjdG9yKTtcclxuXHRcdFx0XHRpZigkYWN0aW9ucy5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdGNvbnRhaW5lckVsLmh0bWwoJycpO1xyXG5cdFx0XHRcdFx0Y29udGFpbmVyRWwuYXBwZW5kKCRhY3Rpb25zKTtcclxuXHRcdFx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH07XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgZm91bmQgPSBhcHBlbmRUaXRsZUFjdGlvbnMoKTtcclxuXHRcdFx0aWYoIWZvdW5kKSB7XHJcblx0XHRcdFx0c2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuXHRcdFx0XHRcdHZhciBmb3VuZCA9IGFwcGVuZFRpdGxlQWN0aW9ucygpO1xyXG5cdFx0XHRcdFx0aWYoIWZvdW5kKSB7XHJcblx0XHRcdFx0XHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHRcdFx0YXBwZW5kVGl0bGVBY3Rpb25zKCk7XHJcblx0XHRcdFx0XHRcdH0sIDIwMDApO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0sIDEwMDApO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHR9XSxcclxuXHRiaW5kaW5nczoge1xyXG5cdFx0dHlwZTogJzwnLFxyXG5cdFx0dmlld09ubHk6ICc9JyxcclxuXHRcdHRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzOiAnPCcsXHJcblx0XHR0ZW1wbGF0ZUlkOiAnPCcsXHJcblx0XHR0ZW1wbGF0ZUdyb3VwSWQ6ICc8JyxcclxuXHRcdHRlbXBsYXRlVHlwZUlkOiAnPCcsXHJcblx0XHRjb25maWc6ICc8J1xyXG5cdH1cclxufSk7IiwiYW5ndWxhci5tb2R1bGUoXCJhZG9kZGxlXCIpLmNvbXBvbmVudCgnY3VzdG9tT2JqZWN0Rm9ybScsIHtcclxuXHR0ZW1wbGF0ZVVybDogJy9hZG9kZGxlL3ZpZXcvbmV3dWkvY3VzdG9tLW9iamVjdC9jdXN0b20ub2JqZWN0LWZvcm0uanNwJyxcclxuXHRjb250cm9sbGVyOiBbJyRyb290U2NvcGUnLCAnJHNjb3BlJywgJyR0aW1lb3V0JywgJ05vdGlmaWNhdGlvbicsICdsYW5nJywgJ2FwaScsICdhcGlDb25maWcnLCAnbXlDb25maWcnLCAnJHdpbmRvdycsICckZWxlbWVudCcsICdkZGNoaWxkJyxcclxuXHRmdW5jdGlvbiAoJHJvb3RTY29wZSwgJHNjb3BlLCAkdGltZW91dCwgTm90aWZpY2F0aW9uLCBsYW5nLCBhcGksIGFwaUNvbmZpZywgbXlDb25maWcsICR3aW5kb3csICRlbGVtZW50LCBkZGNoaWxkKSB7XHJcblx0XHR2YXIgY3RybCA9IHRoaXM7XHJcblx0XHR2YXIgYWRkZWQgPSBmYWxzZTtcclxuXHRcdHZhciBjdXJyZW50VGltZVN0YW1wID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcblx0XHR2YXIgY3VzdG9tT2JqZWN0Rm9ybUNvbXBvbmVudDtcclxuXHRcdHZhciBhdHRhY2htZW50Q29tcG9uZW50O1xyXG5cdFx0dmFyIGxpbmtzQ29tcG9uZW50O1xyXG5cdFx0dmFyIGF0dGFjaG1lbnRDb250YWluZXJFbDtcclxuXHRcdHZhciBsaW5rc0NvbnRhaW5lckVsO1xyXG5cclxuXHRcdHZhciBjdXN0b21PYmplY3RJbnN0YW5jZUlkID0gJyc7XHJcblx0XHR2YXIgaXNGcm9tVmlldyA9IGZhbHNlO1xyXG5cdFx0dmFyIGZyb21WaWV3QWN0aXZlVGFiID0gJyc7XHJcblx0XHR2YXIgY2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3ID0gbnVsbDtcclxuXHRcdHZhciBjYW5jZWxQcm9tcHRDb250aW51ZUZuO1xyXG5cdFx0dmFyIGNhbmNlbFByb21wdENhbmNlbEZuO1xyXG5cclxuXHRcdCRzY29wZS5leHBhbmRlZCA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLmVkaXRNb2RlID0gZmFsc2U7XHJcblx0XHQkc2NvcGUuc2hvd0NhbmNlbFByb21wdCA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLmxvYWRpbmcgPSB0cnVlO1xyXG5cdFx0JHNjb3BlLnN0YXR1c0Nsb3NlZCA9IGZhbHNlO1xyXG5cdFx0JHNjb3BlLm1vZGVsRGF0YSA9IGFuZ3VsYXIuZXh0ZW5kKHt9LCBteUNvbmZpZy5tb2RlbERhdGEpO1xyXG5cdFx0JHNjb3BlLnNhdmVFcnJvck1lc3NhZ2UgPSAnJztcclxuXHRcdCRzY29wZS5zaG93U2F2ZUVycm9yRGlhbG9nID0gZmFsc2U7XHJcblxyXG5cdFx0Y3RybC4kb25Jbml0ID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRzZXREZWZhdWx0cygpO1xyXG5cdFx0XHRsaXN0ZW4oKTtcclxuXHRcdFx0d2F0Y2goKTtcclxuXHRcdFx0JHNjb3BlLmhhc0NhbmNlbFByb21wdCA9IHRydWU7XHJcblx0XHRcdGRkY2hpbGQucmVnaXN0ZXIoJHNjb3BlLCAnY3VzdG9tLW9iamVjdC1mb3JtJyk7XHJcblx0XHR9O1xyXG5cclxuXHJcblx0XHR2YXIgd2F0Y2ggPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0JHJvb3RTY29wZS4kb24oJ2Fzc29jQ2hhbmdlJywgb25Bc3NvY0NoYW5nZSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBsaXN0ZW4gPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdCRzY29wZS4kb24oJ2RkOmNoYW5nZWQnLCBvbkRET3BlbkNsb3NlKTtcclxuXHRcdH07XHJcblxyXG5cdFx0JHNjb3BlLm9wZW5DYW5jZWxQcm9tcHQgPSBmdW5jdGlvbihvbkNvbnRpbnVlLCBvbkNhbmNlbCkge1xyXG5cdFx0XHRjYW5jZWxQcm9tcHRDb250aW51ZUZuID0gb25Db250aW51ZTtcclxuXHRcdFx0Y2FuY2VsUHJvbXB0Q2FuY2VsRm4gPSBvbkNhbmNlbDtcclxuXHRcdFx0JHNjb3BlLnNob3dDYW5jZWxQcm9tcHQgPSB0cnVlO1xyXG5cdFx0XHQkc2NvcGUuJGFwcGx5KCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5jbG9zZUNhbmNlbFByb21wdCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRjYW5jZWxQcm9tcHRDb250aW51ZUZuID0gbnVsbDtcclxuXHRcdFx0Y2FuY2VsUHJvbXB0Q2FuY2VsRm4gPSBudWxsO1xyXG5cdFx0XHQkc2NvcGUuc2hvd0NhbmNlbFByb21wdCA9IGZhbHNlO1xyXG5cdFx0fTtcclxuXHJcblx0XHRjdHJsLm9uQ2FuY2VsUHJvbXB0Q29udGludWUgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYoY2FuY2VsUHJvbXB0Q29udGludWVGbikge1xyXG5cdFx0XHRcdGNhbmNlbFByb21wdENvbnRpbnVlRm4oKTtcclxuXHRcdFx0fVxyXG5cdFx0XHQkc2NvcGUuY2xvc2VDYW5jZWxQcm9tcHQoKTtcclxuXHRcdH07XHJcblxyXG5cdFx0Y3RybC5vbkNhbmNlbFByb21wdENhbmNlbCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZihjYW5jZWxQcm9tcHRDYW5jZWxGbikge1xyXG5cdFx0XHRcdGNhbmNlbFByb21wdENhbmNlbEZuKCk7XHJcblx0XHRcdH1cclxuXHRcdFx0JHNjb3BlLmNsb3NlQ2FuY2VsUHJvbXB0KCk7XHJcblx0XHR9O1xyXG5cdFx0JHNjb3BlLm9wZW5TYXZlRXJyb3JEaWFsb2cgPSBmdW5jdGlvbihlcnJvck1lc3NhZ2UpIHtcclxuXHRcdFx0JHNjb3BlLnNhdmVFcnJvck1lc3NhZ2UgPSBlcnJvck1lc3NhZ2U7XHJcblx0XHRcdCRzY29wZS5zaG93U2F2ZUVycm9yRGlhbG9nID0gdHJ1ZTtcclxuXHRcdFx0JHNjb3BlLiRhcHBseSgpO1xyXG5cdFx0fTtcclxuXHJcblx0XHRjdHJsLmNhbmNlbFNhdmVFcnJvckRhaWxvZyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHQkc2NvcGUuc2F2ZUVycm9yTWVzc2FnZSA9ICcnO1xyXG5cdFx0XHQkc2NvcGUuc2hvd1NhdmVFcnJvckRpYWxvZyA9IGZhbHNlO1xyXG5cdFx0fTtcclxuXHRcdHZhciBzZXREZWZhdWx0cyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRjdHJsLnRpdGxlQWN0aW9ucyA9IHtcclxuXHRcdFx0XHRhdHRhY2htZW50czogZmFsc2UsXHJcblx0XHRcdFx0bGlua3M6IGZhbHNlXHJcblx0XHRcdH07XHJcblx0XHJcblx0XHRcdGN0cmwuYXNzb2NEYXRhID0ge1xyXG5cdFx0XHRcdHRpdGxlOiAnJyxcclxuXHRcdFx0XHRvcGVuOiB0cnVlLFxyXG5cdFx0XHRcdHZpZXc6ICcnLFxyXG5cdFx0XHRcdHRyZWVTZWxlY3Rpb246IFwiXCIsXHJcblx0XHRcdFx0bGlzdFNlbGVjdGlvbjogW10sXHJcblx0XHRcdFx0YWN0aXZlOiA0LFx0XHRcdC8vIHJlcHJlc2VudCBhY3RpdmUgdGFiXHJcblx0XHRcdFx0bW9kZWxOYW1lOiBcIlwiLFxyXG5cdFx0XHRcdGxpc3RYaHI6IGZhbHNlLFxyXG5cdFx0XHRcdGxpc3Q6IHVuZGVmaW5lZCxcclxuXHRcdFx0XHRjdXN0b21PYmplY3RBdHRhY2htZW50czoge1xyXG5cdFx0XHRcdFx0ZGF0YTogW10sXHJcblx0XHRcdFx0XHRkZWxldGVEaXNhYmxlZDogZmFsc2UsXHJcblx0XHRcdFx0XHRpbmRleDogOFxyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0dmlld3M6IHtcclxuXHRcdFx0XHRcdGRhdGE6IFtdLFxyXG5cdFx0XHRcdFx0ZGVsZXRlTm90QWxsb3dlZDogdHJ1ZSxcclxuXHRcdFx0XHRcdGhhc0RldGFpbHM6IGZhbHNlLFxyXG5cdFx0XHRcdFx0aW5kZXg6IDRcclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdGxpbmtzOiB7XHJcblx0XHRcdFx0XHRkYXRhOiBbXSxcclxuXHRcdFx0XHRcdGRlbGV0ZURpc2FibGVkOiBmYWxzZSxcclxuXHRcdFx0XHRcdGluZGV4OiA5XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9O1xyXG5cdFx0fTtcclxuXHJcblx0XHQvLyBpbnZva2Ugb24gZHJvcGRvd24gb3BlbiAvIGNsb3NlXHJcblx0XHR2YXIgY2xvc2VUaW1lb3V0ID0gdW5kZWZpbmVkO1xyXG5cdFx0dmFyIHByZXZWaXNpYmxlID0gdW5kZWZpbmVkO1xyXG5cdFx0XHJcblx0XHR2YXIgb25ERE9wZW5DbG9zZSA9IGZ1bmN0aW9uIChldmVudCwgZGQpIHtcclxuXHRcdFx0aWYoIWRkIHx8IGRkLm5hbWUgPT0gXCJjdXN0b20tb2JqZWN0LWxpc3RcIikge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYoZGQgJiYgZGQubmFtZSA9PSAnY3VzdG9tLW9iamVjdC1mb3JtJykge1xyXG5cdFx0XHRcdCRzY29wZS5leHBhbmRlZCA9IGRkLmV4cGFuZGVkIHx8IGZhbHNlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihkZC5uYW1lID09ICdjdXN0b20tb2JqZWN0LWZvcm0nICYmIGRkLmV2ZW50ID09ICd2aXNpYmlsaXR5Jykge1xyXG5cdFx0XHRcdGlmKHByZXZWaXNpYmxlID09IGRkLnZpc2libGUpIHtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0aWYoZGQudmlzaWJsZSkge1xyXG5cdFx0XHRcdFx0JHRpbWVvdXQuY2FuY2VsKGNsb3NlVGltZW91dCk7XHJcblx0XHRcdFx0XHRyZW5kZXIoZGQpO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHQkdGltZW91dC5jYW5jZWwoY2xvc2VUaW1lb3V0KTtcclxuXHRcdFx0XHRcdGNsb3NlVGltZW91dCA9ICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0XHRkZXN0cm95KCk7XHJcblx0XHRcdFx0XHR9LCA1MDApO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRwcmV2VmlzaWJsZSA9IGRkLnZpc2libGU7XHJcblx0XHRcdH0gZWxzZSBpZihkZC5uYW1lICE9IFwiY3VzdG9tLW9iamVjdC1mb3JtXCIpIHtcclxuXHRcdFx0XHQkdGltZW91dC5jYW5jZWwoY2xvc2VUaW1lb3V0KTtcclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgZGVzdHJveSA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighYWRkZWQpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCRzY29wZS5sb2FkaW5nID0gdHJ1ZTtcclxuXHRcdFx0JHNjb3BlLnN0YXR1c0Nsb3NlZCA9IGZhbHNlO1xyXG5cdFx0XHRhZGRlZCA9IGZhbHNlO1xyXG5cdFx0XHRjdXN0b21PYmplY3RJbnN0YW5jZUlkID0gJyc7XHJcblx0XHRcdGNhbmNlbFByb21wdENvbnRpbnVlRm4gPSBudWxsO1xyXG5cdFx0XHRjYW5jZWxQcm9tcHRDYW5jZWxGbiA9IG51bGw7XHJcblx0XHRcdCRzY29wZS5zaG93Q2FuY2VsUHJvbXB0ID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS5zYXZlRXJyb3JNZXNzYWdlID0gJyc7XHJcblx0XHRcdCRzY29wZS5zaG93U2F2ZUVycm9yRGlhbG9nID0gZmFsc2U7XHJcblxyXG5cdFx0XHRpZihjdXN0b21PYmplY3RGb3JtQ29tcG9uZW50KSB7XHJcblx0XHRcdFx0Y3VzdG9tT2JqZWN0Rm9ybUNvbXBvbmVudC5kZXN0cm95KCk7XHJcblx0XHRcdFx0Y3VzdG9tT2JqZWN0Rm9ybUNvbXBvbmVudCA9IG51bGw7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmKGF0dGFjaG1lbnRDb21wb25lbnQpIHtcclxuXHRcdFx0XHRhdHRhY2htZW50Q29tcG9uZW50LmRlc3Ryb3koKTtcclxuXHRcdFx0XHRhdHRhY2htZW50Q29tcG9uZW50ID0gbnVsbDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYobGlua3NDb21wb25lbnQpIHtcclxuXHRcdFx0XHRsaW5rc0NvbXBvbmVudC5kZXN0cm95KCk7XHJcblx0XHRcdFx0bGlua3NDb21wb25lbnQgPSBudWxsO1xyXG5cdFx0XHR9XHJcblx0XHRcdHNldERlZmF1bHRzKCk7XHJcblx0XHRcdGlmKGNsZWFyUGVuZGluZ1NlbGVjdE1vZGVsVmlldykge1xyXG5cdFx0XHRcdGNsZWFyUGVuZGluZ1NlbGVjdE1vZGVsVmlldygpO1xyXG5cdFx0XHRcdGNsZWFyUGVuZGluZ1NlbGVjdE1vZGVsVmlldyA9IG51bGw7XHJcblx0XHRcdH1cclxuXHRcdFx0dHJ5e1xyXG5cdFx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdFx0fSBjYXRjaChlKXt9XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBvbkFzc29jQ2hhbmdlID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdHNldEFzc2lnbm1lbnRzKCk7XHJcblx0XHRcdHNldExpbmtzKCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBzZXRBc3NpZ25tZW50cyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZihjdXN0b21PYmplY3RGb3JtQ29tcG9uZW50KSB7XHJcblx0XHRcdFx0Y3VzdG9tT2JqZWN0Rm9ybUNvbXBvbmVudC5pbnN0YW5jZS5hdHRhY2htZW50cyA9IGN0cmwuYXNzb2NEYXRhLmN1c3RvbU9iamVjdEF0dGFjaG1lbnRzLmRhdGE7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHNldExpbmtzID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdGlmKGN1c3RvbU9iamVjdEZvcm1Db21wb25lbnQpIHtcclxuXHRcdFx0XHRjdXN0b21PYmplY3RGb3JtQ29tcG9uZW50Lmluc3RhbmNlLmxpbmtzID0gY3RybC5hc3NvY0RhdGEubGlua3MuZGF0YTtcclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgcmVuZGVyID0gZnVuY3Rpb24gKGRkKSB7XHJcblx0XHRcdGRlc3Ryb3koKTtcclxuXHJcblx0XHRcdGlzRnJvbVZpZXcgPSBkZC5pc0Zyb21WaWV3O1xyXG5cdFx0XHRmcm9tVmlld0FjdGl2ZVRhYiA9IGRkLmZyb21WaWV3QWN0aXZlVGFiO1xyXG5cdFx0XHRjdXN0b21PYmplY3RJbnN0YW5jZUlkID0gZGQuY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCB8fCAnJztcclxuXHRcdFx0JHNjb3BlLmVkaXRNb2RlID0gY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCA/IHRydWUgOiBmYWxzZTtcclxuXHJcblx0XHRcdGlmKGFkZGVkKSB7XHJcblx0XHRcdFx0JHNjb3BlLiRhcHBseSgpO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYoIWF0dGFjaG1lbnRDb250YWluZXJFbCkge1xyXG5cdFx0XHRcdGF0dGFjaG1lbnRDb250YWluZXJFbCA9ICRlbGVtZW50LmZpbmQoJyNhdHRhY2htZW50Q29udGFpbmVyJyk7XHJcblx0XHRcdH1cclxuXHRcdFx0aWYoIWxpbmtzQ29udGFpbmVyRWwpIHtcclxuXHRcdFx0XHRsaW5rc0NvbnRhaW5lckVsID0gJGVsZW1lbnQuZmluZCgnI2xpbmtzQ29udGFpbmVyJyk7XHJcblx0XHRcdH1cclxuXHRcdFx0YWRkZWQgPSB0cnVlO1xyXG5cclxuXHRcdFx0YXBwZW5kQ3VzdG9tT2JqZWN0Rm9ybShkZCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBuYXZpZ2F0ZVRvTGlzdE9yVmlldyA9IGZ1bmN0aW9uKGRhdGFDaGFuZ2VkKXtcclxuXHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KCdkZDpjbG9zZScsIHsgbmFtZTogJ2N1c3RvbS1vYmplY3QtZm9ybScsIGV4cGFuZGVkOiAkc2NvcGUuZXhwYW5kZWQsIGZvcmNlOiB0cnVlIH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0aWYoaXNGcm9tVmlldykge1xyXG5cdFx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6b3BlbicsIHtcclxuXHRcdFx0XHRcdG5hbWU6ICdjdXN0b20tb2JqZWN0LXZpZXcnLFxyXG5cdFx0XHRcdFx0ZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCxcclxuXHRcdFx0XHRcdHR5cGU6IGN0cmwudHlwZSxcclxuXHRcdFx0XHRcdGRhdGFDaGFuZ2VkOiBkYXRhQ2hhbmdlZCB8fCBmYWxzZSxcclxuXHRcdFx0XHRcdGlzRnJvbUZvcm06IHRydWUsXHJcblx0XHRcdFx0XHR2aWV3T25seTogY3RybC52aWV3T25seSxcclxuXHRcdFx0XHRcdGRlZmF1bHRPcGVuZWRUYWI6IGZyb21WaWV3QWN0aXZlVGFiLFxyXG5cdFx0XHRcdFx0dGVtcGxhdGVMYW5ndWFnZURldGFpbHM6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMsXHJcblx0XHRcdFx0XHR0ZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcblx0XHRcdFx0XHR0ZW1wbGF0ZUdyb3VwSWQ6IGN0cmwudGVtcGxhdGVHcm91cElkLFxyXG5cdFx0XHRcdFx0dGVtcGxhdGVUeXBlSWQ6IGN0cmwudGVtcGxhdGVUeXBlSWQsXHJcblx0XHRcdFx0XHRjb25maWc6IGN0cmwuY29uZmlnLFxyXG5cdFx0XHRcdFx0Y3VzdG9tT2JqZWN0SW5zdGFuY2VJZDogY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCxcclxuXHRcdFx0XHRcdGRvY2tUaXRsZTogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscy5jdXN0b21PYmplY3RUaXRsZVxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KCdkZDpvcGVuJywge1xyXG5cdFx0XHRcdG5hbWU6ICdjdXN0b20tb2JqZWN0LWxpc3QnLFxyXG5cdFx0XHRcdGV4cGFuZGVkOiAkc2NvcGUuZXhwYW5kZWQsXHJcblx0XHRcdFx0J3R5cGUnOiBjdHJsLnR5cGUsXHJcblx0XHRcdFx0J2RhdGFDaGFuZ2VkJzogZGF0YUNoYW5nZWQgfHwgZmFsc2UsXHJcblx0XHRcdFx0J2lzRnJvbUZvcm0nOiB0cnVlLFxyXG5cdFx0XHRcdCd2aWV3T25seSc6IGN0cmwudmlld09ubHksXHJcblx0XHRcdFx0J3RlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzJzogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuXHRcdFx0XHQndGVtcGxhdGVJZCc6IGN0cmwudGVtcGxhdGVJZCxcclxuXHRcdFx0XHQndGVtcGxhdGVHcm91cElkJzogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcblx0XHRcdFx0J3RlbXBsYXRlVHlwZUlkJzogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuXHRcdFx0XHQnY29uZmlnJzogY3RybC5jb25maWdcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBlbmRDdXN0b21PYmplY3RGb3JtID0gZnVuY3Rpb24oZGQpIHtcclxuXHRcdFx0Ly8gZGQudXJsTmF2aWdhdGlvblxyXG5cdFx0XHR2YXIgJGVsID0gJGVsZW1lbnQuZmluZCgnI2N1c3RvbU9iamVjdEZvcm0nKTtcclxuXHRcdFx0dmFyIGNvbXBvbmVudCA9IHdpbmRvdy5jcmVhdGVEeW5hbWljQW5ndWxhckNvbXBvbmVudCgnYWRvZGRsZS1jdXN0b20tb2JqZWN0LWZvcm0nLCB7XHJcblx0XHRcdFx0cHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcblx0XHRcdFx0ZW50aXR5SWQ6IGN0cmwuY29uZmlnLmVudGl0eUlkLFxyXG5cdFx0XHRcdGRjSWQ6IG15Q29uZmlnLkxPQ0FMX0RDX0lELFxyXG5cdFx0XHRcdHR5cGU6IGN0cmwudHlwZSxcclxuXHRcdFx0XHR2aWV3T25seTogY3RybC52aWV3T25seSxcclxuXHRcdFx0XHR0ZW1wbGF0ZUxhbmd1YWdlRGV0YWlsczogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuXHRcdFx0XHR0ZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcblx0XHRcdFx0dGVtcGxhdGVHcm91cElkOiBjdHJsLnRlbXBsYXRlR3JvdXBJZCxcclxuXHRcdFx0XHR0ZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuXHRcdFx0XHRlZGl0TW9kZTogJHNjb3BlLmVkaXRNb2RlLFxyXG5cdFx0XHRcdG9iamVjdEluc3RhbmNlSWQ6IGN1c3RvbU9iamVjdEluc3RhbmNlSWRcclxuXHRcdFx0fSwgJGVsWzBdKTtcclxuXHRcdFx0Y3VzdG9tT2JqZWN0Rm9ybUNvbXBvbmVudCA9IGNvbXBvbmVudDtcclxuXHJcblx0XHRcdGNvbXBvbmVudC5pbnN0YW5jZS5vbkxvYWRlZC5zdWJzY3JpYmUoZnVuY3Rpb24oZGF0YSkge1xyXG5cdFx0XHRcdG9uQ3VzdG9tT2JqZWN0Rm9ybUxvYWRlZChkYXRhKTtcclxuXHJcblx0XHRcdFx0Ly8gU2VsZWN0IG1vZGVsIHZpZXcgd2hlbiBjdXN0b20gb2JqZWN0IGVkaXQgaXMgb3BlbmVkIGJ5IGRlZmF1bHQgb24gcGFnZSBsb2FkXHJcblx0XHRcdFx0aWYoJHNjb3BlLmVkaXRNb2RlICYmIGRkLnVybE5hdmlnYXRpb24pIHtcclxuXHRcdFx0XHRcdHNlbGVjdE1vZGVsVmlldyhkYXRhKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0Y29tcG9uZW50Lmluc3RhbmNlLm9uTG9hZEZhaWxlZC5zdWJzY3JpYmUoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0JHNjb3BlLmxvYWRpbmcgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuJGFwcGx5KCk7XHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0Y29tcG9uZW50Lmluc3RhbmNlLm9uQ2FuY2VsLnN1YnNjcmliZShmdW5jdGlvbigpIHtcclxuXHRcdFx0XHQkc2NvcGUub3BlbkNhbmNlbFByb21wdChmdW5jdGlvbigpe1xyXG5cdFx0XHRcdFx0bmF2aWdhdGVUb0xpc3RPclZpZXcoKTtcclxuXHRcdFx0XHRcdGRlc3Ryb3koKTtcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0XHRjb21wb25lbnQuaW5zdGFuY2Uub25TYXZlZC5zdWJzY3JpYmUoZnVuY3Rpb24oZGF0YSkge1xyXG5cdFx0XHRcdG5hdmlnYXRlVG9MaXN0T3JWaWV3KHRydWUpO1xyXG5cdFx0XHRcdGRlc3Ryb3koKTtcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0XHRjb21wb25lbnQuaW5zdGFuY2Uub25TYXZlRXJyb3Iuc3Vic2NyaWJlKGZ1bmN0aW9uKGVycm9yTWVzc2FnZSkge1xyXG5cdFx0XHRcdCRzY29wZS5vcGVuU2F2ZUVycm9yRGlhbG9nKGVycm9yTWVzc2FnZSk7XHJcblx0XHRcdH0pO1xyXG5cdFx0fTtcclxuXHJcblxyXG5cdFx0dmFyIG9uQ3VzdG9tT2JqZWN0Rm9ybUxvYWRlZCA9IGZ1bmN0aW9uKGRhdGEpe1xyXG5cdFx0XHRpZihkYXRhLmF0dGFjaG1lbnRPcHRpb25zICYmIGRhdGEuYXR0YWNobWVudE9wdGlvbnMuYXR0YWNobWVudEFsbG93ZWQpIHtcclxuXHRcdFx0XHRjdHJsLnRpdGxlQWN0aW9ucy5hdHRhY2htZW50ID0gIWRhdGEucmVhZG9ubHkgPyB0cnVlIDogZmFsc2U7XHJcblx0XHRcdFx0YXBwZW5kQXR0YWNobWVudChkYXRhLmF0dGFjaG1lbnRPcHRpb25zKTtcclxuXHJcblx0XHRcdFx0aWYoZGF0YS5hdHRhY2htZW50T3B0aW9ucy5jb25maWcpIHtcclxuXHRcdFx0XHRcdGFwcGVuZEF0dGFjaG1lbnRMaXN0KGRhdGEuYXR0YWNobWVudE9wdGlvbnMuY29uZmlnLmF0dGFjaG1lbnRzKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0Y3RybC50aXRsZUFjdGlvbnMuYXR0YWNobWVudCA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihkYXRhLmxpbmtPcHRpb25zICYmIGRhdGEubGlua09wdGlvbnMubGlua3NBbGxvd2VkKSB7XHJcblx0XHRcdFx0Y3RybC50aXRsZUFjdGlvbnMubGlua3MgPSAhZGF0YS5yZWFkb25seSA/IHRydWUgOiBmYWxzZTtcclxuXHRcdFx0XHRhcHBlbmRMaW5rQ3JlYXRlKCk7XHJcblxyXG5cdFx0XHRcdGlmKGRhdGEubGlua09wdGlvbnMubGlua3MpIHtcclxuXHRcdFx0XHRcdGFwcGVuZExpbmtzKGRhdGEubGlua09wdGlvbnMubGlua3MpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRjdHJsLnRpdGxlQWN0aW9ucy5saW5rcyA9IGZhbHNlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQkc2NvcGUuc3RhdHVzQ2xvc2VkID0gZGF0YS5zdGF0dXNDbG9zZWQgfHwgZmFsc2U7XHJcblxyXG5cdFx0XHRpZihkYXRhLm1vZGVsVmlld09wdGlvbnMgJiYgZGF0YS5tb2RlbFZpZXdPcHRpb25zLmNhcHR1cmVNb2RlbFZpZXcpIHtcclxuXHRcdFx0XHRpbnNlcnRWaWV3KGRhdGEubW9kZWxWaWV3T3B0aW9ucy5tb2RlbFZpZXdzLCBkYXRhLm1vZGVsVmlld09wdGlvbnMubW9kZWxWaWV3RGF0YSk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCRzY29wZS5sb2FkaW5nID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHNlbGVjdE1vZGVsVmlldyA9IGZ1bmN0aW9uKGRhdGEpe1xyXG5cdFx0XHRpZihkYXRhLm1vZGVsVmlld09wdGlvbnMgJiYgZGF0YS5tb2RlbFZpZXdPcHRpb25zLm1vZGVsVmlld0RhdGEgJiZcclxuXHRcdFx0XHRkYXRhLm1vZGVsVmlld09wdGlvbnMubW9kZWxWaWV3RGF0YS52aWV3SWQpIHtcclxuXHRcdFx0XHRpZih3aW5kb3dbJ3NlbGVjdFZpZXcnXSkge1xyXG5cdFx0XHRcdFx0Y2xlYXJQZW5kaW5nU2VsZWN0TW9kZWxWaWV3ID0gd2luZG93WydzZWxlY3RWaWV3J10oZGF0YS5tb2RlbFZpZXdPcHRpb25zLm1vZGVsVmlld0RhdGEudmlld0lkLCB0cnVlKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHJcblx0XHR2YXIgYXBwZW5kQXR0YWNobWVudCA9IGZ1bmN0aW9uKGF0dGFjaG1lbnRPcHRpb25zKSB7XHJcblx0XHRcdHZhciAkZWwgPSBhdHRhY2htZW50Q29udGFpbmVyRWw7XHJcblx0XHRcdHZhciBjb21wb25lbnQgPSB3aW5kb3cuY3JlYXRlRHluYW1pY0FuZ3VsYXJDb21wb25lbnQoJ2Fkb2RkbGUtZmlsZS11cGxvYWQnLCB7XHJcblx0XHRcdFx0b3B0aW9uczoge1xyXG5cdFx0XHRcdFx0cGFyYW1zOiB7XHJcblx0XHRcdFx0XHRcdHByb2plY3RJZDogbXlDb25maWcucHJvamVjdElkLFxyXG5cdFx0XHRcdFx0XHRhdHRhY2hUZW1wRm9sZGVySWQ6IGF0dGFjaG1lbnRPcHRpb25zLmNvbmZpZy5hdHRhY2hUZW1wRm9sZGVySWQsXHJcblx0XHRcdFx0XHRcdGRjSWQ6IG15Q29uZmlnLkxPQ0FMX0RDX0lELFxyXG5cdFx0XHRcdFx0XHRmaWxlVHlwZTogYXR0YWNobWVudE9wdGlvbnMuY29uZmlnLnR5cGVcclxuXHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRhdHRhY2htZW50OiB0cnVlLFxyXG5cdFx0XHRcdFx0cG9wb3ZlcjogdHJ1ZSxcclxuXHRcdFx0XHRcdGRpc2FibGVNb3ZlOiB0cnVlLFxyXG5cdFx0XHRcdFx0dGl0bGU6IGxhbmcuZ2V0KCdhdHRhY2htZW50cycpLFxyXG5cdFx0XHRcdFx0b25Db21wbGV0ZTogZnVuY3Rpb24obykge1xyXG5cdFx0XHRcclxuXHRcdFx0XHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8IG8uaXRlbXMubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdFx0XHRpbnNlcnRBdHRhY2htZW50KG8uaXRlbXNbaV0pO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRpZihvLml0ZW1zLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHRcdHNldEFzc2lnbm1lbnRzKCk7XHJcblx0XHRcdFx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHRcdFx0XHRjdHJsLmFzc29jRGF0YS5hY3RpdmUgPSBjdHJsLmFzc29jRGF0YS5jdXN0b21PYmplY3RBdHRhY2htZW50cy5pbmRleDtcclxuXHRcdFx0XHRcdFx0XHRcdGN0cmwuYXNzb2NEYXRhLmhhc0RhdGEgPSB0cnVlO1xyXG5cdFx0XHRcdFx0XHRcdFx0JHNjb3BlLiRhcHBseSgpO1xyXG5cdFx0XHRcdFx0XHRcdH0sNTAwKTtcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdG9uQ2xvc2U6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0XHRjdHJsLmN1c3RvbU9iamVjdC5pc0F0dGFjaE9wZW4gPSBmYWxzZTtcclxuXHRcdFx0XHRcdFx0JHNjb3BlLiRhcHBseSgpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSwgJGVsWzBdKTtcclxuXHRcdFx0YXR0YWNobWVudENvbXBvbmVudCA9IGNvbXBvbmVudDtcclxuXHRcdFx0JGVsLmZpbmQoJ2Fkb2RkbGUtZmlsZS11cGxvYWQnKS5hZGRDbGFzcygnZCcpO1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgYXBwZW5kQXR0YWNobWVudExpc3QgPSBmdW5jdGlvbihhdHRhY2htZW50cykge1xyXG5cdFx0XHRpZighYXR0YWNobWVudHMgfHwgIWF0dGFjaG1lbnRzLmxlbmd0aCkge1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NEYXRhLmN1c3RvbU9iamVjdEF0dGFjaG1lbnRzLmRlbGV0ZURpc2FibGVkID0gZmFsc2U7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRjdHJsLmFzc29jRGF0YS5jdXN0b21PYmplY3RBdHRhY2htZW50cy5kZWxldGVEaXNhYmxlZCA9IHRydWU7XHJcblxyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgYXR0YWNobWVudHMubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgYXR0YWNobWVudCA9IGF0dGFjaG1lbnRzW2ldO1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NEYXRhLmN1c3RvbU9iamVjdEF0dGFjaG1lbnRzLmRhdGEgPSBjdHJsLmFzc29jRGF0YS5jdXN0b21PYmplY3RBdHRhY2htZW50cy5kYXRhLmNvbmNhdChbe1xyXG5cdFx0XHRcdFx0ZGVsZXRlRGlzYWJsZWQ6IHRydWUsXHJcblx0XHRcdFx0XHRjYW5EZWxldGU6IHRydWUsXHJcblx0XHRcdFx0XHRjYW5PcGVuOiB3aW5kb3dbJ3BsYXRmb3JtTmFtZSddID8gZmFsc2UgOiB0cnVlLCAvLyBEaXNhYmxlZCBhdHRhY2htZW50IHZpZXcgdGVtcG9yYXJ5IGZvciBleHRlcm5hbCBwbGF0Zm9ybXMgaS5lIG5hdmlzd29ya1xyXG5cdFx0XHRcdFx0Y2FuRG93bmxvYWRGaWxlOiB0cnVlLFxyXG5cdFx0XHRcdFx0aXRlbTogYXR0YWNobWVudCxcclxuXHRcdFx0XHRcdHJldmlzaW9uSWQ6IGF0dGFjaG1lbnQucmV2aXNpb25JZCxcclxuXHRcdFx0XHRcdEZpbGVOYW1lOiBhdHRhY2htZW50LmZpbGVOYW1lLFxyXG5cdFx0XHRcdFx0RmlsZVR5cGU6IGFwaS5nZXRGaWxlRXh0SW1hZ2UoYXBpLmdldEV4dChhdHRhY2htZW50LmZpbGVOYW1lKSksXHJcblx0XHRcdFx0XHRQdWJsaXNoZXJVc2VySWQ6IGF0dGFjaG1lbnQucHVibGlzaGVyVXNlcklkLFxyXG5cdFx0XHRcdFx0RmlsZVNpemU6IGF0dGFjaG1lbnQuZmlsZVNpemUsXHJcblx0XHRcdFx0XHRhdHRhY2hlZEJ5OiBhdHRhY2htZW50LmF0dGFjaGVkQnksXHJcblx0XHRcdFx0XHRhdHRhY2hlZEJ5TmFtZTogYXR0YWNobWVudC5hdHRhY2hlZEJ5TmFtZSxcclxuXHRcdFx0XHRcdGF0dGFjaGVkRGF0ZTogYXR0YWNobWVudC5hdHRhY2hlZERhdGVcclxuXHRcdFx0XHR9XSk7XHJcblx0XHRcdH1cclxuXHRcdFx0Y3RybC5hc3NvY0RhdGEuaGFzRGF0YSA9IHRydWU7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBlbmRMaW5rcyA9IGZ1bmN0aW9uKGxpbmtzKSB7XHJcblx0XHRcdGN0cmwuYXNzb2NEYXRhLmxpbmtzLmRlbGV0ZURpc2FibGVkID0gZmFsc2U7XHJcblxyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgbGlua3MubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgbGluayA9IGxpbmtzW2ldO1xyXG5cdFx0XHRcdGluc2VydExpbmsoe1xyXG5cdFx0XHRcdFx0aWQ6IGxpbmsubGlua0lkLFxyXG5cdFx0XHRcdFx0bmFtZTogbGluay5saW5rTmFtZSxcclxuXHRcdFx0XHRcdGxpbms6IGxpbmsubGlua1VybCxcclxuXHRcdFx0XHRcdGNyZWF0ZWRCeUltYWdlczogbGluay5jcmVhdGVkQnlJbWFnZXMsXHJcblx0XHRcdFx0XHRjcmVhdGVkRGlzcGxheURhdGVUaW1lOiBsaW5rLmNyZWF0ZWREaXNwbGF5RGF0ZVRpbWUsXHJcblx0XHRcdFx0XHRjcmVhdGVkQnlGaXJzdE5hbWU6IGxpbmsuY3JlYXRlZEJ5Rmlyc3ROYW1lLFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHRcdGlmKGxpbmsubGlua0lkKSB7XHJcblx0XHRcdFx0XHRjdHJsLmFzc29jRGF0YS5saW5rcy5kZWxldGVEaXNhYmxlZCA9IHRydWU7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihsaW5rcy5sZW5ndGgpIHtcclxuXHRcdFx0XHRzZXRMaW5rcygpO1xyXG5cdFx0XHRcdGN0cmwuYXNzb2NEYXRhLmhhc0RhdGEgPSB0cnVlO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBlbmRMaW5rQ3JlYXRlID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdHZhciAkZWwgPSBsaW5rc0NvbnRhaW5lckVsO1xyXG5cdFx0XHR2YXIgY29tcG9uZW50ID0gd2luZG93LmNyZWF0ZUR5bmFtaWNBbmd1bGFyQ29tcG9uZW50KCdhZG9kZGxlLWN1c3RvbS1vYmplY3QtbGluaycsIHtcclxuXHRcdFx0XHRvcHRpb25zOiB7XHRcdFxyXG5cdFx0XHRcdFx0b25Db21wbGV0ZTogZnVuY3Rpb24obGlua3MpIHtcclxuXHJcblx0XHRcdFx0XHRcdHZhciB1c2VyZm9ybWF0ID0gd2luZG93WydJTklUX0pTUF9HTE9CQUwnXS5mb3JtYXRzRm9ySnF1ZXJ5Q2FsZW5kZXJbd2luZG93WydVU1AnXS5sYW5ndWFnZUlkXTtcclxuXHJcblx0XHRcdFx0XHRcdGZvcih2YXIgaSA9IDA7IGkgPCBsaW5rcy5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0XHRcdHZhciBpdGVtID0gbGlua3NbaV07XHJcblx0XHRcdFx0XHRcdFx0aXRlbS5jcmVhdGVkQnlJbWFnZXMgPSBhcGlDb25maWcuSU1BR0VfUEFUSCArIG15Q29uZmlnLlVTUC51c2VySUQgKyBcIiZ2PVwiICsgY3VycmVudFRpbWVTdGFtcDtcclxuXHRcdFx0XHRcdFx0XHRpdGVtLmNyZWF0ZWREaXNwbGF5RGF0ZVRpbWUgPSBhcGkuZm9ybWF0RGF0ZSh1c2VyZm9ybWF0LCBuZXcgRGF0ZSgpKSxcclxuXHRcdFx0XHRcdFx0XHRpdGVtLmNyZWF0ZWRCeUZpcnN0TmFtZSA9IG15Q29uZmlnLlVTUC5maXJzdE5hbWUgfHwgbXlDb25maWcuVVNQLnRwZFVzZXJOYW1lO1xyXG5cdFx0XHRcdFx0XHRcdGluc2VydExpbmsoaXRlbSk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0XHRcdGlmKGxpbmtzLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHRcdHNldExpbmtzKCk7XHJcblx0XHRcdFx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHRcdFx0XHRjdHJsLmFzc29jRGF0YS5hY3RpdmUgPSBjdHJsLmFzc29jRGF0YS5saW5rcy5pbmRleDtcclxuXHRcdFx0XHRcdFx0XHRcdGN0cmwuYXNzb2NEYXRhLmhhc0RhdGEgPSB0cnVlO1xyXG5cdFx0XHRcdFx0XHRcdFx0JHNjb3BlLiRhcHBseSgpO1xyXG5cdFx0XHRcdFx0XHRcdH0sNTAwKTtcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdG9uQ2xvc2U6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0XHRjdHJsLmN1c3RvbU9iamVjdC5pc0xpbmtPcGVuID0gZmFsc2U7XHJcblx0XHRcdFx0XHRcdCRzY29wZS4kYXBwbHkoKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sICRlbFswXSk7XHJcblx0XHRcdGxpbmtzQ29tcG9uZW50ID0gY29tcG9uZW50O1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgaW5zZXJ0TGluayA9IGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdFx0Y3RybC5hc3NvY0RhdGEubGlua3MuZGF0YSA9IGN0cmwuYXNzb2NEYXRhLmxpbmtzLmRhdGEuY29uY2F0KFt7XHJcblx0XHRcdFx0aWQ6IGl0ZW0uaWQsXHJcblx0XHRcdFx0ZGVsZXRlRGlzYWJsZWQ6IGl0ZW0uaWQgPyB0cnVlIDogZmFsc2UsXHJcblx0XHRcdFx0bmFtZTogaXRlbS5uYW1lLFxyXG5cdCAgICBcdCAgICBsaW5rOiBpdGVtLmxpbmssXHJcblx0XHRcdFx0Y3JlYXRlZEJ5SW1hZ2VzOiBpdGVtLmNyZWF0ZWRCeUltYWdlcyB8fCAnJyxcclxuXHRcdFx0XHRjcmVhdGVkRGlzcGxheURhdGVUaW1lOiBpdGVtLmNyZWF0ZWREaXNwbGF5RGF0ZVRpbWUgfHwgJycsXHJcblx0XHRcdFx0Y3JlYXRlZEJ5Rmlyc3ROYW1lOiBpdGVtLmNyZWF0ZWRCeUZpcnN0TmFtZSB8fCAnJyxcclxuXHQgICAgXHQgICAgaHJlZjogL15bYS16QS1aXSs6XFwvXFwvLy50ZXN0KGl0ZW0ubGluaykgPyBpdGVtLmxpbmsgOiAoJ2h0dHA6Ly8nICsgaXRlbS5saW5rKVxyXG5cdFx0XHR9XSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBpbnNlcnRBdHRhY2htZW50ID0gZnVuY3Rpb24oaXRlbSkge1xyXG5cdFx0XHR2YXIgZmlsZURldGFpbHMgPSBpdGVtLmZpbGVEZXRhaWxzLnVwbG9hZGVkQXR0YWNobWVudEZpbGVEZXRhaWxzLnNwbGl0KFwifFwiKTtcclxuXHRcdFx0dmFyIHVzZXJmb3JtYXQgPSB3aW5kb3dbJ0lOSVRfSlNQX0dMT0JBTCddLmZvcm1hdHNGb3JKcXVlcnlDYWxlbmRlclt3aW5kb3dbJ1VTUCddLmxhbmd1YWdlSWRdO1xyXG5cclxuXHRcdFx0Y3RybC5hc3NvY0RhdGEuY3VzdG9tT2JqZWN0QXR0YWNobWVudHMuZGF0YSA9IGN0cmwuYXNzb2NEYXRhLmN1c3RvbU9iamVjdEF0dGFjaG1lbnRzLmRhdGEuY29uY2F0KFt7XHJcblx0XHRcdFx0aXRlbTogaXRlbSxcclxuXHRcdFx0XHRjYW5EZWxldGU6IGZhbHNlLFxyXG5cdFx0XHRcdGNhbk9wZW46IGZhbHNlLFxyXG5cdFx0XHRcdGNhbkRvd25sb2FkRmlsZTogZmFsc2UsXHJcblx0ICAgIFx0ICAgIEZpbGVUeXBlOiBpdGVtLmZpbGUuaWNvbixcclxuXHQgICAgXHQgICAgRmlsZU5hbWU6IGl0ZW0uZmlsZS5uYW1lLFxyXG5cdCAgICBcdCAgICBQdWJsaXNoZXJVc2VySWQ6IGZpbGVEZXRhaWxzWzNdLFxyXG5cdCAgICBcdCAgICBGaWxlU2l6ZTogaXRlbS5maWxlLnNvcnRTaXplLFxyXG5cdFx0XHRcdGF0dGFjaGVkQnk6IGFwaUNvbmZpZy5JTUFHRV9QQVRIICsgbXlDb25maWcuVVNQLnVzZXJJRCArIFwiJnY9XCIgKyBjdXJyZW50VGltZVN0YW1wLFxyXG5cdCAgICBcdCAgICBhdHRhY2hlZEJ5TmFtZTogbXlDb25maWcuVVNQLmZpcnN0TmFtZSB8fCBteUNvbmZpZy5VU1AudHBkVXNlck5hbWUsXHJcblx0ICAgIFx0ICAgIGF0dGFjaGVkRGF0ZTogYXBpLmZvcm1hdERhdGUodXNlcmZvcm1hdCwgbmV3IERhdGUoKSlcclxuXHRcdFx0fV0pO1xyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgaW5zZXJ0VmlldyA9IGZ1bmN0aW9uKG1vZGVsVmlld3MsIG1vZGVsVmlld0RhdGEpIHtcclxuXHRcdFx0aWYoIW1vZGVsVmlld3MgfHwgIW1vZGVsVmlld3MubGVuZ3RoKSB7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRjdHJsLmFzc29jRGF0YS52aWV3cy5kYXRhID0gW107XHJcblx0XHRcdGN0cmwuYXNzb2NEYXRhLnZpZXdzLmhhc0RldGFpbHMgPSB0cnVlO1xyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgbW9kZWxWaWV3cy5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdHZhciB2aWV3RGF0YSA9IG1vZGVsVmlld3NbaV07XHJcblxyXG5cdFx0XHRcdGN0cmwuYXNzb2NEYXRhLnZpZXdzLmRhdGEucHVzaCh7XHJcblx0XHRcdFx0XHRiaW1Nb2RlbE5hbWU6IG15Q29uZmlnLm1vZGVsRGF0YS5uYW1lLFxyXG5cdFx0XHRcdFx0Y2FuVmlldzogdHJ1ZSxcclxuXHRcdFx0XHRcdHZpZXdJZDogdmlld0RhdGEudmlld0lkLFxyXG5cdFx0XHRcdFx0Y3JlYXRlZERhdGU6IHZpZXdEYXRhLmNyZWF0ZWREYXRlLFxyXG5cdFx0XHRcdFx0dmlld05hbWU6IHZpZXdEYXRhLnZpZXdOYW1lLFxyXG5cdFx0XHRcdFx0Y3JlYXRvclVzZXJOYW1lOiB2aWV3RGF0YS5jcmVhdG9yVXNlck5hbWUsXHJcblx0XHRcdFx0XHRtb2RlbFR5cGVJbWFnZTogdmlld0RhdGEubW9kZWxUeXBlSW1hZ2UsXHJcblx0XHRcdFx0XHRtb2RlbFR5cGVOYW1lOiB2aWV3RGF0YS5tb2RlbFR5cGVOYW1lLFxyXG5cdFx0XHRcdFx0aGFzTWFya3VwOiB2aWV3RGF0YS5oYXNNYXJrdXAsXHJcblx0XHRcdFx0XHRtb2RlbE5hbWU6IHZpZXdEYXRhLm1vZGVsTmFtZSxcclxuXHRcdFx0XHRcdHByb2plY3ROYW1lOiB2aWV3RGF0YS5wcm9qZWN0TmFtZSxcclxuXHRcdFx0XHRcdGNyZWF0b3JCeUltYWdlczogdmlld0RhdGEuY3JlYXRvckJ5SW1hZ2VzXHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGN0cmwuYXNzb2NEYXRhLmFjdGl2ZSA9IGN0cmwuYXNzb2NEYXRhLnZpZXdzLmluZGV4O1xyXG5cdFx0XHRjdHJsLmFzc29jRGF0YS5oYXNEYXRhID0gdHJ1ZTtcclxuXHRcdH07XHJcblxyXG5cdH1dLFxyXG5cdGJpbmRpbmdzOiB7XHJcblx0XHR0eXBlOiAnPCcsXHJcblx0XHR2aWV3T25seTogJz0nLFxyXG5cdFx0dGVtcGxhdGVMYW5ndWFnZURldGFpbHM6ICc8JyxcclxuXHRcdHRlbXBsYXRlSWQ6ICc8JyxcclxuXHRcdHRlbXBsYXRlR3JvdXBJZDogJzwnLFxyXG5cdFx0dGVtcGxhdGVUeXBlSWQ6ICc8JyxcclxuXHRcdGNvbmZpZzogJzwnXHJcblx0fVxyXG59KTsiLCJhbmd1bGFyLm1vZHVsZSgnYWRvZGRsZScpLmNvbXBvbmVudCgnY3VzdG9tT2JqZWN0TGlzdCcsIHtcclxuICAgIHRlbXBsYXRlVXJsOiAnL2Fkb2RkbGUvdmlldy9uZXd1aS9jdXN0b20tb2JqZWN0L2N1c3RvbS5vYmplY3QubGlzdC5qc3AnLFxyXG4gICAgY29udHJvbGxlcjogW1xyXG4gICAgICAgICckcm9vdFNjb3BlJyxcclxuICAgICAgICAnJHNjb3BlJyxcclxuICAgICAgICAnJHRpbWVvdXQnLFxyXG4gICAgICAgICdOb3RpZmljYXRpb24nLFxyXG4gICAgICAgICdsYW5nJyxcclxuICAgICAgICAnYXBpJyxcclxuICAgICAgICAnYXBpQ29uZmlnJyxcclxuICAgICAgICAnbXlDb25maWcnLFxyXG4gICAgICAgICckd2luZG93JyxcclxuICAgICAgICAnJGVsZW1lbnQnLFxyXG4gICAgICAgIGZ1bmN0aW9uICgkcm9vdFNjb3BlLCAkc2NvcGUsICR0aW1lb3V0LCBOb3RpZmljYXRpb24sIGxhbmcsIGFwaSwgYXBpQ29uZmlnLCBteUNvbmZpZywgJHdpbmRvdywgJGVsZW1lbnQpIHtcclxuICAgICAgICAgICAgdmFyIGN0cmwgPSB0aGlzO1xyXG4gICAgICAgICAgICB2YXIgYWRkZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgdmFyIGN1c3RvbU9iamVjdExpc3RDb21wb25lbnQ7XHJcbiAgICAgICAgICAgICRzY29wZS5leHBhbmRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAkc2NvcGUubG9hZGluZyA9IHRydWU7XHJcbiAgICAgICAgICAgICRzY29wZS5yZWZyZXNoaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICRzY29wZS5oYXNTZWxlY3RlZFJvdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAkc2NvcGUuYmNmSW1wb3J0ID0ge1xyXG4gICAgICAgICAgICAgICAgc2hvd1Byb21wdCA6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgc2hvd0xvYWRlclByb21wdCA6IGZhbHNlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgJHNjb3BlLnRpdGxlO1xyXG4gICAgICAgICAgICAkd2luZG93LmJjZklzc3VlSW1wb3J0ID0gJyc7XHJcbiAgICAgICAgICAgICRzY29wZS5pc0ZvckFkb2RkbGVQbHVnaW4gPSBhcGlDb25maWcuQ0JJTV9QTFVHSU5TLnNwbGl0KCd8JykuaW5kZXhPZigkd2luZG93LnBsYXRmb3JtTmFtZSkgPiAtMTtcclxuXHJcbiAgICAgICAgICAgIGN0cmwuJG9uSW5pdCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGluaXQoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGN0cmwucmVmcmVzaCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjdXN0b21PYmplY3RMaXN0Q29tcG9uZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnJlZnJlc2hpbmcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbU9iamVjdExpc3RDb21wb25lbnQuaW5zdGFuY2UucmVmcmVzaCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLy9GdW5jdGlvbiBmb3IgY29udGludWUgYnV0dG9uIGZyb20gcHJvbXB0XHJcbiAgICAgICAgICAgIGN0cmwub25Db250aW51ZVByb21wdENsaWNrID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgd2luZG93LmJjZklzc3VlSW1wb3J0ICYmIHdpbmRvdy5iY2ZJc3N1ZUltcG9ydC5vbkNvbnRpbnVlUHJvbXB0Q2xpY2soKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8vRnVuY3Rpb24gZm9yIGNhbmNlbCBidXR0b24gZnJvbSBwcm9tcHRcclxuICAgICAgICAgICAgY3RybC5vbkNhbmNlbFByb21wdENsaWNrID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgd2luZG93LmJjZklzc3VlSW1wb3J0ICYmIHdpbmRvdy5iY2ZJc3N1ZUltcG9ydC5vbkNhbmNlbFByb21wdENsaWNrKCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB2YXIgaW5pdCA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIGxpc3RlbigpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGN0cmwudHlwZSA9PT0gJ01PREVMX0JDRl9JU1NVRScgJiYgISRzY29wZS5pc0ZvckFkb2RkbGVQbHVnaW4pIHtcclxuICAgICAgICAgICAgICAgICAgICBpbXBvcnRCY2ZJc3N1ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5iY2ZJc3N1ZUltcG9ydCAmJiB3aW5kb3cuYmNmSXNzdWVJbXBvcnQuZ2V0Q3VzdG9tT2JqZWN0VGVtcGxhdGVEYXRhKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAobXlDb25maWcuaXNGcm9tQ3VzdG9tT2JqZWN0UmVuZGVyZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOm9wZW4nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdjdXN0b20tb2JqZWN0LWxpc3QnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBhbmRlZDogJHNjb3BlLmV4cGFuZGVkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBjdHJsLnR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdPbmx5OiBjdHJsLnZpZXdPbmx5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZUxhbmd1YWdlRGV0YWlsczogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVJZDogY3RybC50ZW1wbGF0ZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZUdyb3VwSWQ6IGN0cmwudGVtcGxhdGVHcm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlnOiBjdHJsLmNvbmZpZ1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLy8gVXNlZCB0byBjcmVhdGUgZHluYW1pYyBhbmd1bGFyIGNvbXBvbm5ldCAtIGltcG9ydC1iY2YtaXNzdWUgY29tcC5cclxuICAgICAgICAgICAgdmFyIGltcG9ydEJjZklzc3VlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tT2JqZWN0VGVtcGxhdGVHcm91cElkOiBjdHJsLnRlbXBsYXRlR3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RUZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgICAgICBkY0lkOiBteUNvbmZpZy5kY0lkLFxyXG4gICAgICAgICAgICAgICAgICAgIGVudGl0eUlkOiBjdHJsLmNvbmZpZy5lbnRpdHlJZCxcclxuICAgICAgICAgICAgICAgICAgICBhY3Rpb25faWQ6IGFwaUNvbmZpZy5TQVZFX01PREVMX1ZJRVcsXHJcbiAgICAgICAgICAgICAgICAgICAgYXBpQ29uZmlnOiBhcGlDb25maWcsXHJcbiAgICAgICAgICAgICAgICAgICAgdXJsRm9yU3BlY2lmaWNEYzogZ2V0QmFzZWREb21haW4obXlDb25maWcuZGNJZCksXHJcbiAgICAgICAgICAgICAgICAgICAgbGFuZzogbGFuZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgJHdpbmRvdy5iY2ZJc3N1ZUltcG9ydCA9IG5ldyBJbXBvcnRCY2ZGaWxlKHtcclxuICAgICAgICAgICAgICAgICAgICBkYXRhIDogb3B0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICBub3RpZmljYXRpb24gOiBOb3RpZmljYXRpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgcHJvbXB0VmFsdWVzIDogJHNjb3BlLmJjZkltcG9ydCxcclxuICAgICAgICAgICAgICAgICAgICBhcHBseSA6ZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHJlZnJlc2ggOiBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3RybC5yZWZyZXNoKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB2YXIgbGlzdGVuID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgJHNjb3BlLiRvbignZGQ6Y2hhbmdlZCcsIG9uRERPcGVuQ2xvc2UpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLy8gaW52b2tlIG9uIGRyb3Bkb3duIG9wZW4gLyBjbG9zZVxyXG4gICAgICAgICAgICB2YXIgb25ERE9wZW5DbG9zZSA9IGZ1bmN0aW9uIChldmVudCwgZGQpIHtcclxuICAgICAgICAgICAgICAgIGlmIChkZCAmJiBkZC5uYW1lID09ICdjdXN0b20tb2JqZWN0LWxpc3QnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmV4cGFuZGVkID0gZGQuZXhwYW5kZWQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkZC52aXNpYmxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkZC5pc0Zyb21Gb3JtIHx8IGRkLmlzRnJvbVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbmRlcihkZC5kYXRhQ2hhbmdlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW5kZXIoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHZhciBjcmVhdGVDdXN0b21PYmplY3QgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOmNsb3NlJywgeyBuYW1lOiAnY3VzdG9tLW9iamVjdC1saXN0JywgZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCwgZm9yY2U6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOm9wZW4nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2N1c3RvbS1vYmplY3QtZm9ybScsXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBjdHJsLnR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld09ubHk6IGN0cmwudmlld09ubHksXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVMYW5ndWFnZURldGFpbHM6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVJZDogY3RybC50ZW1wbGF0ZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlR3JvdXBJZDogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVUeXBlSWQ6IGN0cmwudGVtcGxhdGVUeXBlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnOiBjdHJsLmNvbmZpZ1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB2YXIgdmlld0N1c3RvbU9iamVjdCA9IGZ1bmN0aW9uIChpdGVtKSB7XHJcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOmNsb3NlJywgeyBuYW1lOiAnY3VzdG9tLW9iamVjdC1saXN0JywgZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCwgZm9yY2U6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOm9wZW4nLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ2N1c3RvbS1vYmplY3QtdmlldycsXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwYW5kZWQ6ICRzY29wZS5leHBhbmRlZCxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBjdHJsLnR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld09ubHk6IGN0cmwudmlld09ubHksXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVMYW5ndWFnZURldGFpbHM6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVJZDogY3RybC50ZW1wbGF0ZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlR3JvdXBJZDogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVUeXBlSWQ6IGN0cmwudGVtcGxhdGVUeXBlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnOiBjdHJsLmNvbmZpZyxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RJbnN0YW5jZUlkOiBpdGVtLmN1c3RvbU9iamVjdEluc3RhbmNlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgZG9ja1RpdGxlOiBjdHJsLnRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzLmN1c3RvbU9iamVjdFRpdGxlXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHZhciBlZGl0Q3VzdG9tT2JqZWN0ID0gZnVuY3Rpb24gKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6Y2xvc2UnLCB7IG5hbWU6ICdjdXN0b20tb2JqZWN0LWxpc3QnLCBleHBhbmRlZDogJHNjb3BlLmV4cGFuZGVkLCBmb3JjZTogdHJ1ZSB9KTtcclxuICAgICAgICAgICAgICAgICRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6b3BlbicsIHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnY3VzdG9tLW9iamVjdC1mb3JtJyxcclxuICAgICAgICAgICAgICAgICAgICBleHBhbmRlZDogJHNjb3BlLmV4cGFuZGVkLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IGN0cmwudHlwZSxcclxuICAgICAgICAgICAgICAgICAgICB2aWV3T25seTogY3RybC52aWV3T25seSxcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZUxhbmd1YWdlRGV0YWlsczogY3RybC50ZW1wbGF0ZUxhbmd1YWdlRGV0YWlscyxcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVHcm91cElkOiBjdHJsLnRlbXBsYXRlR3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVR5cGVJZDogY3RybC50ZW1wbGF0ZVR5cGVJZCxcclxuICAgICAgICAgICAgICAgICAgICBjb25maWc6IGN0cmwuY29uZmlnLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbU9iamVjdEluc3RhbmNlSWQ6IGl0ZW0uY3VzdG9tT2JqZWN0SW5zdGFuY2VJZCxcclxuICAgICAgICAgICAgICAgICAgICBkb2NrVGl0bGU6IGN0cmwudGVtcGxhdGVMYW5ndWFnZURldGFpbHMuY3VzdG9tT2JqZWN0RWRpdFRpdGxlXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICRzY29wZS52ZXJ0TW9yZUNsaWNrZWQgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWN1c3RvbU9iamVjdExpc3RDb21wb25lbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB2YXIgc2VsZWN0ZWRJdGVtcyA9IGN1c3RvbU9iamVjdExpc3RDb21wb25lbnQuaW5zdGFuY2UuZ2V0U2VsZWN0ZWRJdGVtcygpO1xyXG4gICAgICAgICAgICAgICAgJHNjb3BlLmhhc1NlbGVjdGVkUm93ID0gc2VsZWN0ZWRJdGVtcy5sZW5ndGggPiAwO1xyXG5cclxuICAgICAgICAgICAgICAgIHZhciB4ID0gY3VzdG9tT2JqZWN0TGlzdENvbXBvbmVudC5pbnN0YW5jZS5oYXNSZWNvcmRzO1xyXG4gICAgICAgICAgICAgICAgJHNjb3BlLmhhc1JlY29yZHMgPSB4O1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgJHNjb3BlLnZlcnRNb3JlQWN0aW9uQ2xpY2tlZCA9IGZ1bmN0aW9uIChldmVudCwgYWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBGb3Igcm93IHNlbGVjdGlvbiBlbmFibGVkIGFjdGlvbiwgcmV0dXJuIGlmIG5vIHJvdyBpcyBzZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgaWYgKGFjdGlvbi5lbmFibGVPblJvd1NlbGVjdGlvbiAmJiAhJHNjb3BlLmhhc1NlbGVjdGVkUm93KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGFjdGlvbi5hY3Rpb25IYW5kbGVyKGFjdGlvbiwgY3VzdG9tT2JqZWN0TGlzdENvbXBvbmVudC5pbnN0YW5jZS5nZXRTZWxlY3RlZEl0ZW1zKCkpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdmFyIHJlbmRlciA9IGZ1bmN0aW9uIChyZWxvYWQpIHtcclxuICAgICAgICAgICAgICAgIGlmIChhZGRlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZWxvYWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3RybC5yZWZyZXNoKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGFkZGVkID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICBhcHBlbmRDdXN0b21PYmplY3RMaXN0KCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB2YXIgY2FuU2VsZWN0TGlzdEl0ZW1zID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIGNhblNlbGVjdEl0ZW1zID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGN0cmwuY29uZmlnICYmIGN0cmwuY29uZmlnLnZlcnRNb3JlQWN0aW9ucykge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY3RybC5jb25maWcudmVydE1vcmVBY3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjdHJsLmNvbmZpZy52ZXJ0TW9yZUFjdGlvbnNbaV0uZW5hYmxlT25Sb3dTZWxlY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhblNlbGVjdEl0ZW1zID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiBjYW5TZWxlY3RJdGVtcztcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdmFyIGNvbXBvbmVudDtcclxuICAgICAgICAgICAgdmFyIGFwcGVuZEN1c3RvbU9iamVjdExpc3QgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgJGVsID0gJGVsZW1lbnQuZmluZCgnI2N1c3RvbU9iamVjdExpc3QnKTtcclxuICAgICAgICAgICAgICAgIGNvbXBvbmVudCA9IHdpbmRvdy5jcmVhdGVEeW5hbWljQW5ndWxhckNvbXBvbmVudChcclxuICAgICAgICAgICAgICAgICAgICAnYWRvZGRsZS1jdXN0b20tb2JqZWN0LWxpc3QnLFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkOiBjdHJsLmNvbmZpZy5lbnRpdHlJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGNJZDogbXlDb25maWcuTE9DQUxfRENfSUQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGN0cmwudHlwZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlld09ubHk6IGN0cmwudmlld09ubHksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzOiBjdHJsLnRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZUlkOiBjdHJsLnRlbXBsYXRlSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlR3JvdXBJZDogY3RybC50ZW1wbGF0ZUdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVHlwZUlkOiBjdHJsLnRlbXBsYXRlVHlwZUlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYW5TZWxlY3RJdGVtczogY2FuU2VsZWN0TGlzdEl0ZW1zKCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdJc3N1ZUZpbHRlcjogY3RybC52aWV3SXNzdWVGaWx0ZXJcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICRlbFswXVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIGN1c3RvbU9iamVjdExpc3RDb21wb25lbnQgPSBjb21wb25lbnQ7XHJcblxyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50Lmluc3RhbmNlLm9uTG9hZGVkLnN1YnNjcmliZShmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5sb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnJlZnJlc2hpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb21wb25lbnQuaW5zdGFuY2Uub25Mb2FkRmFpbGVkLnN1YnNjcmliZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmxvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUucmVmcmVzaGluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS4kYXBwbHkoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbXBvbmVudC5pbnN0YW5jZS5vbkNyZWF0ZS5zdWJzY3JpYmUoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZUN1c3RvbU9iamVjdCgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50Lmluc3RhbmNlLm9uRWRpdC5zdWJzY3JpYmUoZnVuY3Rpb24gKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICBlZGl0Q3VzdG9tT2JqZWN0KGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50Lmluc3RhbmNlLm9uVmlldy5zdWJzY3JpYmUoZnVuY3Rpb24gKGl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Q3VzdG9tT2JqZWN0KGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50Lmluc3RhbmNlLm9uRmlsdGVyLnN1YnNjcmliZShmdW5jdGlvbiAoaXRlbSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudC5pbnN0YW5jZS5jb25zdGFudHMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXc6ICdpc3N1ZUZpbHRlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGljb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcmVhdGVCdG46IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaW1hZ2UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiAnL2ltYWdlcy9pY29ucy9uZXctaXNzdWUtaWNvbi5zdmcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlckJ0bjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdpbWFnZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICc8aSBjbGFzcz1cImZhIGZhLXNsaWRlcnNcIj48L2k+JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICBdLFxyXG4gICAgYmluZGluZ3M6IHtcclxuICAgICAgICBjcmVhdGVCdG5UaXRsZTogJ0AnLFxyXG4gICAgICAgIHR5cGU6ICc8JyxcclxuICAgICAgICB2aWV3T25seTogJz0nLFxyXG4gICAgICAgIHZpZXdJc3N1ZUZpbHRlcjogJzwnLFxyXG4gICAgICAgIHRlbXBsYXRlTGFuZ3VhZ2VEZXRhaWxzOiAnPCcsXHJcbiAgICAgICAgdGVtcGxhdGVJZDogJzwnLFxyXG4gICAgICAgIHRlbXBsYXRlR3JvdXBJZDogJzwnLFxyXG4gICAgICAgIHRlbXBsYXRlVHlwZUlkOiAnPCcsXHJcbiAgICAgICAgY29uZmlnOiAnPCdcclxuICAgIH1cclxufSk7IiwiYW5ndWxhci5tb2R1bGUoXCJhZG9kZGxlXCIpLmZpbHRlcignZmlsZWhpc3RvcnlGaWx0ZXInLCBmdW5jdGlvbigkZmlsdGVyKSB7XHJcblx0dmFyIGZpbHRlclRleHQgPSBmdW5jdGlvbihmaWx0ZXJBcnJheSwgcXVlcnksIG9iaikge1xyXG5cdFx0aWYoIXF1ZXJ5LnRleHQpIHtcclxuXHRcdFx0ZmlsdGVyQXJyYXkucHVzaChvYmopO1xyXG5cdFx0XHRyZXR1cm47XHJcbiAgICBcdH1cclxuXHRcdHZhciBtYXAgPSBbXTtcclxuXHRcdHN3aXRjaChxdWVyeS5hY3Rpb25JZCl7XHJcblx0XHRcdGNhc2UgXCIxMVwiOlxyXG5cdFx0XHRjYXNlIFwiMVwiOlx0XHJcblx0XHRcdFx0bWFwID0gW1wiaW5zdGFudF9lbWFpbF9ub3RpZlwiLCBcInJldmlzaW9uTnVtXCIsIFwicmV2aXNpb25Db3VudGVyXCIsIFwidXNlcl9uYW1lXCIsIFwidXNlcl9vcmdfbmFtZVwiLCBcIm9yZ05hbWVcIiwgXCJhY3Rpb25fbmFtZVwiLCBcImFjdGlvbl9zdGF0dXNcIiwgXCJ1c2VybmFtZVwiLCBcImFjdGlvbkRhdGVcIiwgXHJcblx0XHRcdFx0ICAgICAgICAgICBcImFjdGlvbl9kdWVfYnlfZGF0ZVwiLCBcImFjdGlvbl9jb21wbGV0ZV9kYXRlXCIsIFwidmlld19kYXRlXCIsIFwicmV2aXNpb25TdGF0dXNOYW1lXCIsIFwicHVycG9zZU9mSXNzdWVcIiwgXCJzdGF0dXNOYW1lXCIsIFwib2xkU3RhdHVzTmFtZVwiLCBcImFjdGlvbk5hbWVcIiwgXCJmaWxlTmFtZVwiLCBcclxuXHRcdFx0XHQgICAgICAgICAgIFwiZmlsZURlc2NyaXB0aW9uXCIsIFwiYWN0aW9uX25vdGVzXCIsIFwidHJhbnNtaXR0YWxfbm9cIiwgXCJyZW1hcmtcIiwgXCJyZW1hcmtzXCIsIFwicmV2aXNpb25Ob3Rlc1wiLCBcInJldmlzaW9uU3RhdHVzTmFtZVwiLCBcImRlc2NyaXB0aW9uXCJdO1xyXG5cdFx0XHRicmVhaztcdFx0XHRcclxuXHRcdFx0Y2FzZSBcIjZcIjpcclxuXHRcdFx0XHRtYXAgPSBbIFwiaW5zdGFudF9lbWFpbF9ub3RpZlwiLCBcInVzZXJfbmFtZVwiLCBcInVzZXJfb3JnX25hbWVcIiwgXCJvcmdOYW1lXCIsIFwiYWN0aW9uX3N0YXR1c1wiLCBcInVzZXJuYW1lXCIsIFwiYWN0aW9uRGF0ZVwiLCBcclxuXHRcdFx0XHQgICAgICAgICAgIFwiYWN0aW9uX2R1ZV9ieV9kYXRlXCIsIFwiYWN0aW9uX2NvbXBsZXRlX2RhdGVcIiwgXCJ2aWV3X2RhdGVcIiwgXCJzdGF0dXNOYW1lXCIsIFwib2xkU3RhdHVzTmFtZVwiLFwicmVtYXJrXCIsIFwicmVtYXJrc1wiLFwiZGVzY3JpcHRpb25cIl1cclxuXHRcdFx0YnJlYWs7XHJcblx0XHRcdGNhc2UgXCI1XCI6XHJcblx0XHRcdFx0bWFwID0gWyBcImluc3RhbnRfZW1haWxfbm90aWZcIiwgXCJ1c2VyX25hbWVcIiwgXCJ1c2VyX29yZ19uYW1lXCIsIFwib3JnTmFtZVwiLCBcImFjdGlvbl9zdGF0dXNcIiwgXCJ1c2VybmFtZVwiLCBcImFjdGlvbkRhdGVcIiwgXHJcblx0XHRcdFx0ICAgICAgICAgICBcImFjdGlvbl9kdWVfYnlfZGF0ZVwiLCBcImFjdGlvbl9jb21wbGV0ZV9kYXRlXCIsIFwidmlld19kYXRlXCIsIFwic3RhdHVzTmFtZVwiLCBcIm9sZFN0YXR1c05hbWVcIixcInJlbWFya1wiLCBcInJlbWFya3NcIixcImRlc2NyaXB0aW9uXCJdXHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0XHRkZWZhdWx0OlxyXG5cdFx0XHRcdG1hcCA9IFtcImluc3RhbnRfZW1haWxfbm90aWZcIiwgXCJyZXZpc2lvbk51bVwiLCAgXCJyZXZpc2lvbkNvdW50ZXJcIiwgXCJ1c2VyX25hbWVcIiwgXCJ1c2VyX29yZ19uYW1lXCIsIFwib3JnTmFtZVwiLCBcImFjdGlvbl9uYW1lXCIsIFwiYWN0aW9uX3N0YXR1c1wiLCBcInVzZXJuYW1lXCIsIFwiYWN0aW9uRGF0ZVwiLFwiYWN0aW9uTmFtZVwiLFwiZGVzY3JpcHRpb25cIl1cdFx0XHJcblx0XHRcdGJyZWFrO1xyXG5cdFx0fVxyXG5cdFx0XHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IG1hcC5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHR2YXIga2V5ID0gbWFwW2ldO1xyXG5cdFx0XHRcclxuXHRcdFx0aWYob2JqLmhhc093blByb3BlcnR5KGtleSkgJiYgb2JqW2tleV0gJiYgdHlwZW9mIG9ialtrZXldICE9PSBcIm9iamVjdFwiKSB7XHJcblx0XHRcdFx0dmFyIHZhbHVlID0gb2JqW2tleV0gKyBcIlwiO1xyXG5cdFx0XHRcdGlmKHZhbHVlLnRvTG93ZXJDYXNlKCkuaW5kZXhPZihxdWVyeS50ZXh0LnRvTG93ZXJDYXNlKCkpID4gLTEpIHtcclxuXHRcdFx0XHRcdGZpbHRlckFycmF5LnB1c2gob2JqKTtcclxuXHRcdFx0XHRcdGJyZWFrO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH07XHJcblx0XHJcbiAgICByZXR1cm4gZnVuY3Rpb24oYXBwTGlzdCwgcXVlcnkpIHtcclxuICAgIFx0dmFyIGFycmF5ID0gW107XHJcbiAgICBcdFxyXG4gICAgXHRpZihhcHBMaXN0KSB7XHJcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgYXBwTGlzdC5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdHZhciBhcHAgPSBhcHBMaXN0W2ldO1xyXG5cdFx0XHRcdHZhciBhY3Rpb25JZCA9IHBhcnNlSW50KHF1ZXJ5LmFjdGlvbklkKSB8fCAnJztcclxuXHRcdFx0XHRpZighYWN0aW9uSWQpIHtcclxuXHRcdFx0XHRcdGlmKCFxdWVyeS5yZXZpc2lvbklkIHx8ICFhcHAucmV2aXNpb25JZCB8fCBxdWVyeS5yZXZpc2lvbklkID09IGFwcC5yZXZpc2lvbklkKSB7XHJcblx0XHRcdFx0XHRcdGZpbHRlclRleHQoYXJyYXksIHF1ZXJ5LCBhcHApO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0gZWxzZSBpZigoYWN0aW9uSWQgPT0gYXBwLmFjdGlvbklkIHx8IChhY3Rpb25JZCA9PSAxICYmIDcgPT0gYXBwLmFjdGlvbklkKSkgJiYgKCFxdWVyeS5yZXZpc2lvbklkIHx8IHF1ZXJ5LnJldmlzaW9uSWQgPT0gYXBwLnJldmlzaW9uSWQpKSB7XHJcblx0XHRcdFx0XHRmaWx0ZXJUZXh0KGFycmF5LCBxdWVyeSwgYXBwKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuICAgIFx0fVxyXG4gICAgXHRcclxuICAgIFx0cmV0dXJuIGFycmF5O1xyXG4gICAgfTtcclxufSk7XHJcblxyXG5hbmd1bGFyLm1vZHVsZShcImFkb2RkbGVcIikuY29tcG9uZW50KCdmaWxlSGlzdG9yeScsIHtcclxuXHR0ZW1wbGF0ZVVybDogJy9hZG9kZGxlL3ZpZXcvbmV3dWkvdmlldy1maWxlL2ZpbGUuaGlzdG9yeS5qc3AnLFxyXG5cdGNvbnRyb2xsZXI6IFsnJHNjb3BlJywgJyRyb290U2NvcGUnLCckZG9jdW1lbnQnLCAnJHdpbmRvdycsICckdGltZW91dCcsICdOb3RpZmljYXRpb24nLCAnbGFuZycsICdhcGknLCAnYXBpQ29uZmlnJywgJ215Q29uZmlnJywgJ2RkY2hpbGQnLFxyXG5cdGZ1bmN0aW9uKCRzY29wZSwgJHJvb3RTY29wZSwgJGRvY3VtZW50LCAkd2luZG93LCAkdGltZW91dCwgTm90aWZpY2F0aW9uLCBsYW5nLCBhcGksIGFwaUNvbmZpZywgbXlDb25maWcsIGRkY2hpbGQpIHtcclxuXHRcdHZhciBjdHJsID0gdGhpcyxcclxuXHRcdCAgICBmb3JtUHJvamVjdFByaXYgPSBcIixcIixcclxuXHRcdCAgICByZXZTdHIgPSBcIlwiLCBcclxuXHRcdCAgICBsYXN0SW5kZXggPSAwO1xyXG5cdFx0XHJcblx0XHQvLyBtYXAgZm9yIHNlbGVjdGVkIGl0ZW0gdHlwZVxyXG5cdFx0dmFyIHR5cGVNYXAgPSB7XHJcblx0XHRcdGRpc3RyaWJ1dGlvbjogXCIxMVwiLFxyXG5cdFx0XHRyZXZpc2lvbnM6IFwiMVwiLFxyXG5cdFx0XHRzdGF0dXM6IFwiNlwiLFxyXG5cdFx0XHRjdXN0b21PYmplY3RTdGF0dXM6IFwiNVwiLFxyXG5cdFx0XHRtaWdyYXRpb246XCI3NVwiLFxyXG5cdFx0XHRhbGw6IFwiXCJcclxuXHRcdH07XHJcblx0XHQkc2NvcGUudmlld2VyUHJlZmVyZW5jZSA9IG15Q29uZmlnLnZpZXdlclByZWZlcmVuY2U7XHJcblx0XHQkc2NvcGUuaXNNb2JpbGUgPSBhcGkuaXNNb2JpbGUoKTtcclxuXHRcdFxyXG5cdCAgICAkc2NvcGUuc2VhcmNoID0ge1xyXG5cdCAgICBcdGFjdGlvbklkOiB0eXBlTWFwLmRpc3RyaWJ1dGlvbixcclxuXHQgICAgXHRyZXZpc2lvbklkOiBcIlwiXHJcblx0ICAgIH07XHJcblx0ICAgIFxyXG5cdCAgICAkc2NvcGUuaGlzdG9yeSA9IHtcclxuXHQgICAgXHRjaGVja0FsbDogZmFsc2UsXHJcblx0ICAgIFx0ZXhwYW5kZWQ6IGZhbHNlLFxyXG5cdFx0XHRzZWxlY3Rpb246IFtdLFxyXG5cdFx0XHRjYW5BY2Nlc3NEZWFjdGl2YXRlZERvY3M6IGZhbHNlLFxyXG5cdFx0XHRjYW5Eb3dubG9hZEZpbGU6IGZhbHNlXHJcblx0ICAgIH07XHJcblx0ICAgIFxyXG5cdCAgICAkc2NvcGUuYWN0aW9uID0ge307XHJcblx0XHQkc2NvcGUuaGlzdG9yeUxpc3QgPSBbXTtcclxuXHRcdCRzY29wZS5kaXN0VHlwZVdpc2VVc2VyTGlzdCA9IFtdO1xyXG5cdCAgICAkc2NvcGUuZGlzdFN0YXR1cyA9IHVuZGVmaW5lZDtcclxuXHQgICAgJHNjb3BlLmNvbmZpcm1PcGVuID0gZmFsc2U7XHJcblx0XHQkc2NvcGUuYWN0aW9uUGFyYW0gPSB7fTtcclxuXHJcblx0ICAgICRzY29wZS54aHIgPSB7XHJcblx0ICAgIFx0aGlzdG9yeTogZmFsc2UsXHJcblx0ICAgIFx0ZGVsZWdhdGU6IGZhbHNlLFxyXG5cdCAgICBcdGNsZWFyOiBmYWxzZSxcclxuXHQgICAgXHRhY3RpdmF0ZTogZmFsc2UsXHJcblx0ICAgIFx0ZGlzdDogZmFsc2VcclxuXHQgICAgfTtcclxuXHJcblx0XHQkc2NvcGUuaXNGb3JBZG9kZGxlUGx1Z2luID0gJHdpbmRvdy5wbGF0Zm9ybU5hbWUgJiYgKGFwaUNvbmZpZy5DQklNX1BMVUdJTlMuc3BsaXQoJ3wnKS5pbmRleE9mKCR3aW5kb3cucGxhdGZvcm1OYW1lKSA+IC0xICk7XHJcblx0XHQkc2NvcGUuaGFzSG9vcHNWaWV3ZXJTdXBwb3J0ID0gbXlDb25maWcuaGFzSG9vcHNWaWV3ZXJTdXBwb3J0XHJcblxyXG5cdFx0Y3RybC4kb25Jbml0ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdGFwaS5nZXRWaWV3UGVybWlzc2lvbihmdW5jdGlvbihkYXRhKSB7XHJcblx0XHRcdFx0Zm9ybVByb2plY3RQcml2ID0gZGF0YS5wcml2aWxlZ2VzO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LmNhbkFjY2Vzc0RlYWN0aXZhdGVkRG9jcyA9IGFwaS5oYXNBY2Nlc3MoZm9ybVByb2plY3RQcml2LCAnUFJJVl9BQ0NFU1NfREVBQ1RJVkFURURfRE9DVU1FTlRTJyk7XHJcblx0XHRcdFx0JHNjb3BlLmNhblZpZXdIaXN0b3JpY01hcmt1cHMgPSBhcGkuaGFzQWNjZXNzKGZvcm1Qcm9qZWN0UHJpdiwgJ0NBTl9WSUVXX0hJU1RPUklDX01BUktVUFMnKTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5jYW5Eb3dubG9hZEZpbGUgPSBhcGkuaGFzQWNjZXNzKGZvcm1Qcm9qZWN0UHJpdiwgXCJQUklWX0NBTl9ET1dOTE9BRF9ET0NVTUVOVFNcIikgJiYgbXlDb25maWcudXNlckZvbGRlclBlcm1pc3Npb24gIT0gYXBpQ29uZmlnLmZvbGRlclBlcm1pc3Npb24uVklFV19PTkxZO1xyXG5cdFx0XHR9KTtcclxuXHJcblx0XHRcdHJlc2V0U29ydGluZ0ZpZWxkKCk7XHJcblx0XHRcdFxyXG5cdFx0XHRsaXN0ZW4oKTtcclxuXHRcdFx0aWYoY3RybC5mb3JDdXN0b21PYmplY3QpIHtcclxuXHRcdFx0XHRmZXRjaCgpO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRkZGNoaWxkLnJlZ2lzdGVyKCRzY29wZSwgJ2hpc3RvcnknKTtcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciByZXNldFNvcnRpbmdGaWVsZCA9IGZ1bmN0aW9uKCl7XHJcblx0ICAgIFx0JHNjb3BlLm9yZGVyQnlGaWVsZCA9ICdhY3Rpb25EYXRlJztcclxuXHRcdFx0JHNjb3BlLnNvcnRPcmRlciA9IHRydWU7XHJcblx0ICAgIH07XHJcblx0XHRcclxuXHRcdHZhciBsaXN0ZW4gPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYoY3RybC5mb3JDdXN0b21PYmplY3QpIHtcclxuXHRcdFx0XHQkc2NvcGUuJG9uKCdjdXN0b20tb2JqZWN0Omhpc3Rvcnk6ZmV0Y2gnLCBmdW5jdGlvbigkZXZlbnQsIGRhdGEpIHtcclxuXHRcdFx0XHRcdGZldGNoKCk7XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdFx0JHNjb3BlLiR3YXRjaCgnJGN0cmwucGFyZW50RXhwYW5kZWQnLCBvblBhcmVudEV4cGFuZGVkQ2hhbmdlZCk7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQkc2NvcGUuJG9uKCdkZDpjaGFuZ2VkJywgb25ERE9wZW5DbG9zZSk7XHJcblx0XHRcdFxyXG5cdFx0XHQkc2NvcGUuJG9uKCdzdGF0dXM6Y2hhbmdlZCcsIGZ1bmN0aW9uKGV2ZW50LCBzdGF0dXMpIHtcclxuXHRcdFx0XHRjdHJsLnJlZnJlc2godHJ1ZSk7XHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0JHNjb3BlLiRvbignc2hhcmVsaW5rOmNoYW5nZWQnLCBmdW5jdGlvbihldmVudCwgc3RhdHVzKSB7XHJcblx0XHRcdFx0Y3RybC5yZWZyZXNoKHRydWUpO1xyXG5cdFx0XHR9KTtcclxuXHRcdFx0ICBcclxuXHRcdFx0JHNjb3BlLiRvbignYWN0aW9uOmNvbXBsZXRlZCcsIGZ1bmN0aW9uKGV2ZW50LCBhY3Rpb24pIHtcclxuXHRcdFx0XHRjdHJsLnJlZnJlc2godHJ1ZSk7XHJcblx0XHRcdH0pO1xyXG5cdFx0XHQgIFxyXG5cdFx0XHQkc2NvcGUuJG9uKCdkaXN0cmlidXRpb246Y29tcGxldGVkJywgZnVuY3Rpb24oZXZlbnQsIHN0YXR1cykge1xyXG5cdFx0XHRcdGN0cmwucmVmcmVzaCh0cnVlKTtcclxuXHRcdFx0fSk7XHJcblx0XHRcdCAgXHJcblx0XHRcdCRzY29wZS4kb24oJ21zZzpsb2FkJywgZnVuY3Rpb24oZXZlbnQsIG1zZykge1xyXG5cdFx0XHRcdGN0cmwucmVmcmVzaCh0cnVlKTtcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBvblBhcmVudEV4cGFuZGVkQ2hhbmdlZCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHQkc2NvcGUuaGlzdG9yeS5leHBhbmRlZCA9IGN0cmwucGFyZW50RXhwYW5kZWQ7XHJcblx0XHR9XHJcblx0XHQvKipcclxuXHRcdCAqIEBkZXNjcmlwdGlvbiBvcGVuIG1hcmt1cCBmaWxlLlxyXG5cdFx0ICovXHJcblx0XHQkc2NvcGUubG9hZExlZ2FjeU1hcmt1cCA9IGZ1bmN0aW9uKG5hbWUscmV2SWQscHJvamVjdElkKSB7XHJcblx0XHRcdHZhciBtYXJrdXBfcmV2aXNpb25JZCA9IHJldklkLnNwbGl0KFwiJCRcIilbMF07XHJcblx0XHRcdHZhciBtYXJrdXBfcHJvamVjdElkID0gcHJvamVjdElkLnNwbGl0KFwiJCRcIilbMF07XHJcblx0XHRcdGlmKG15Q29uZmlnLmFwcGxpY2F0aW9uSWQgPT0gMiAmJiBxdE9iamVjdCl7XHJcbiAgICAgICAgICAgICAgICB2YXIgY3VycmVudFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcclxuICAgICAgICAgICAgICAgIHZhciBxdEZpbGVOYW1lID0gbmFtZSArICdfJyArIGN1cnJlbnRUaW1lICsgJy5wZGYnO1xyXG4gICAgICAgICAgICAgICAgdmFyIHF0VVJMID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbiArIGFwaUNvbmZpZy5QVUJMSVNIX1BERl9DT05UUk9MTEVSICsgJz9tYXJrdXBOYW1lPScrIGVuY29kZVVSSUNvbXBvbmVudChuYW1lKSArICcmbG1fcHJvamVjdElkPScrbWFya3VwX3Byb2plY3RJZCArICcmbG1fcmV2aXNpb25JZD0nICsgbWFya3VwX3JldmlzaW9uSWQgKyAnJmFjdGlvbl9pZD0nICsgYXBpQ29uZmlnLkdFTkVSQVRFX0xFR0FDWV9NQVJLVVA7XHJcbiAgICAgICAgICAgICAgICBxdE9iamVjdC5sb2FkTGVnYWN5TWFya3VwKHF0VVJMLCBxdEZpbGVOYW1lKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cdFx0XHRpZihteUNvbmZpZy5hcHBsaWNhdGlvbklkID09IDMpe1xyXG5cdFx0XHRcdHZhciBwYXJhbSA9e1xyXG5cdFx0XHRcdFx0bWFya3VwTmFtZSA6IG5hbWUsXHJcblx0XHRcdFx0XHRmaWxlTmFtZSA6IG15Q29uZmlnLmZpbGVOYW1lLFxyXG5cdFx0XHRcdFx0bG1fcHJvamVjdElkIDogbWFya3VwX3Byb2plY3RJZCxcclxuXHRcdFx0XHRcdGxtX3JldmlzaW9uSWQgOiBtYXJrdXBfcmV2aXNpb25JZCxcclxuXHRcdFx0XHRcdGFjdGlvbl9pZCA6IGFwaUNvbmZpZy5HRU5FUkFURV9MRUdBQ1lfTUFSS1VQXHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGFwaS5zZW5kRXZlbnRUb0lwYWQoXCJsZWdhY3lNYXJrdXA6XCIrSlNPTi5zdHJpbmdpZnkocGFyYW0pKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cdFx0XHRhcGkuc3VibWl0Rm9ybSh7XHJcblx0XHRcdFx0dXJsOiBhcGlDb25maWcuUFVCTElTSF9QREZfQ09OVFJPTExFUixcclxuXHRcdFx0XHRwYXJhbToge1xyXG5cdFx0XHRcdFx0bWFya3VwTmFtZSA6IG5hbWUsXHJcblx0XHRcdFx0XHRsbV9wcm9qZWN0SWQgOiBtYXJrdXBfcHJvamVjdElkLFxyXG5cdFx0XHRcdFx0bG1fcmV2aXNpb25JZCA6IG1hcmt1cF9yZXZpc2lvbklkLFxyXG5cdFx0XHRcdFx0YWN0aW9uX2lkIDogYXBpQ29uZmlnLkdFTkVSQVRFX0xFR0FDWV9NQVJLVVBcclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdHRhcmdldDogJ19ibGFuaydcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdC8vIGludm9rZSBvbiBkcm9wZG93biBvcGVuIC8gY2xvc2VcclxuXHRcdHZhciBvbkRET3BlbkNsb3NlID0gZnVuY3Rpb24oZXZlbnQsIGRkKSB7XHJcblx0XHRcdGlmKGRkICYmIGRkLm5hbWUgPT0gJ2hpc3RvcnknKSB7XHJcblx0XHRcdFx0JHNjb3BlLmhpc3RvcnkuZXhwYW5kZWQgPSBkZC5leHBhbmRlZDtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHRpZihkZC5ldmVudCA9PSAndmlzaWJpbGl0eScgJiYgZGQudmlzaWJsZSkge1xyXG5cdFx0XHRcdFx0dmFyIGZpbmREYXRhID0gdHJ1ZTtcclxuXHRcdFx0XHRcdGlmKGRkLmRhdGEpIHtcclxuXHRcdFx0XHRcdFx0ZGQuZGF0YS5hY3Rpb25JZCA9IChkZC5kYXRhLmFjdGlvbklkID09IC0xKSA/IFwiXCIgOiBkZC5kYXRhLmFjdGlvbklkO1xyXG5cdFx0XHRcdFx0XHQkc2NvcGUuc2VhcmNoLmFjdGlvbklkID0gZGQuZGF0YS5hY3Rpb25JZDtcclxuXHRcdFx0XHRcdFx0JHNjb3BlLnNlYXJjaC5yZXZpc2lvbklkID0gZGQuZGF0YS5yZXZpc2lvbklkIHx8IFwiXCI7XHJcblx0XHRcdFx0XHRcdGZpbmREYXRhID0gZmFsc2U7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdGlmKCEkc2NvcGUuaGlzdG9yeUxpc3QgfHwgISRzY29wZS5oaXN0b3J5TGlzdC5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdFx0ZmV0Y2goZmFsc2UsIGZpbmREYXRhKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIGZldGNoID0gZnVuY3Rpb24oc2lsZW50LCBmaW5kRGF0YSkge1xyXG5cdFx0XHRpZighc2lsZW50ICYmICRzY29wZS54aHIuaGlzdG9yeSAmJiAkc2NvcGUueGhyLmhpc3RvcnkuYWJvcnQpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdHZhciB1cmwgPSBhcGlDb25maWcuRE9DVU1FTlRfQ09OVFJPTExFUjtcclxuXHRcdFx0dmFyIG9iaiA9IHtcclxuXHRcdFx0XHRhY3Rpb25faWQ6IGFwaUNvbmZpZy5WSUVXX0ZJTEVfSElTVE9SWSxcclxuXHRcdFx0XHRkb2N1bWVudElkOiBteUNvbmZpZy5kb2N1bWVudElkLFxyXG5cdFx0XHRcdHByb2plY3RJZDogbXlDb25maWcucHJvamVjdElkLFxyXG5cdFx0XHRcdGZvbGRlcklkOiBteUNvbmZpZy5mb2xkZXJJZCxcclxuXHRcdFx0XHRoaXN0b3J5VHlwZTogLTFcclxuXHRcdFx0fTtcclxuXHRcdFx0XHJcblx0XHRcdGlmKHJldlN0cikge1xyXG5cdFx0XHRcdG9iai5yZXZpc2lvbklkID0gcmV2U3RyO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZihjdHJsLmZvckN1c3RvbU9iamVjdCkge1xyXG5cdFx0XHRcdHVybCA9IGFwaUNvbmZpZy5HRVRfQ1VTVE9NX09CSkVDVF9BVURJVF9UUkFJTF9ERVRBSUxfTElTVCxcclxuXHRcdFx0XHRvYmogPSB7XHJcblx0XHRcdFx0XHRjdXN0b21PYmplY3Q6IEpTT04uc3RyaW5naWZ5KHtcclxuXHRcdFx0XHRcdFx0cHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcblx0XHRcdFx0XHRcdGN1c3RvbU9iamVjdEluc3RhbmNlSWQ6IGN0cmwuY3VzdG9tT2JqZWN0UGFyYW0uY3VzdG9tT2JqZWN0SW5zdGFuY2VJZFxyXG5cdFx0XHRcdFx0fSksXHJcblx0XHRcdFx0XHRhY3Rpb25faWQ6IC0xXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdHVybDogdXJsLFxyXG5cdFx0XHRcdGRhdGE6IG9ialxyXG5cdFx0XHR9KTtcclxuXHRcdFx0XHJcblx0XHRcdGlmKCFzaWxlbnQpIHtcclxuXHRcdFx0XHQkc2NvcGUueGhyLmhpc3RvcnkgPSB4aHI7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdHhoci50aGVuKGZ1bmN0aW9uKHJlc3BvbnNlKSB7XHJcblx0XHRcdFx0JHNjb3BlLnhoci5oaXN0b3J5ID0gZmFsc2U7XHJcblx0XHRcdFx0aWYoY3RybC5mb3JDdXN0b21PYmplY3QpIHtcclxuXHRcdFx0XHRcdHJlc3BvbnNlLmZvckVhY2goZnVuY3Rpb24oaXRlbSl7XHJcblx0XHRcdFx0XHRcdGl0ZW0uYWN0aW9ucyA9IGl0ZW0uZGlzdERhdGE7XHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdCRzY29wZS5oaXN0b3J5TGlzdCA9IHJlc3BvbnNlO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHQkc2NvcGUuaGlzdG9yeUxpc3QgPSByZXNwb25zZS5oaXN0b3J5Vm9MaXN0O1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdFx0XHRmaW5kRGF0YSAmJiBzZXRTZWFyY2goKTtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHR2YXIgcmV2TGlzdCA9IHJlc3BvbnNlLnJldmlzaW9uTGlzdDtcclxuXHRcdFx0XHRpZihyZXZMaXN0ICYmIHJldkxpc3QuZWxlbWVudFZPTGlzdCkge1xyXG5cdFx0XHRcdFx0JHNjb3BlLnJldkxpc3QgPSByZXZMaXN0LmVsZW1lbnRWT0xpc3Q7XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHZhciBtc2dBcnJheSA9IFtdO1xyXG5cdFx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCAkc2NvcGUucmV2TGlzdC5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0XHRtc2dBcnJheS5wdXNoKCRzY29wZS5yZXZMaXN0W2ldLnJldmlzaW9uSWQpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRyZXZTdHIgPSBtc2dBcnJheS5qb2luKCcsJyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHNldERpc3RBY3Rpb25MaXN0KCk7XHJcblx0XHRcdH0sIGZ1bmN0aW9uKHhocikge1xyXG5cdFx0XHRcdGlmKHhoci5zdGF0dXMgPT0gLTEpIHtcclxuXHRcdFx0XHRcdCRzY29wZS54aHIuaGlzdG9yeSA9IGZhbHNlO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHQkc2NvcGUueGhyLmhpc3RvcnkgPSB4aHI7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJmb3JtLWhpc3RvcnktZXJyb3ItbXNnXCIpO1xyXG5cdFx0XHRcdGFwaS5zaG93U2VydmVyRXJyTXNnKHhocik7XHJcblx0XHRcdH0pO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0dmFyIHNldFNlYXJjaCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRmb3IgKCB2YXIga2V5IGluIHR5cGVNYXApIHtcclxuXHRcdFx0XHRpZighdHlwZU1hcC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcblx0XHRcdFx0XHRjb250aW51ZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCAkc2NvcGUuaGlzdG9yeUxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdHZhciBoID0gJHNjb3BlLmhpc3RvcnlMaXN0W2ldO1xyXG5cdFx0XHRcdFx0aWYoaC5hY3Rpb25JZCA9PSB0eXBlTWFwW2tleV0pIHtcclxuXHRcdFx0XHRcdFx0JHNjb3BlLnNlYXJjaC5hY3Rpb25JZCA9IHR5cGVNYXBba2V5XTtcclxuXHRcdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0dmFyIHNldERpc3RBY3Rpb25MaXN0ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdHZhciByb3dEYXRhID0gbnVsbCwgYWN0aW9uRGF0YSA9IG51bGwsIGRpc3RMaXN0ID0gW107XHJcblx0XHRcdHZhciBoTGlzdCA9ICRzY29wZS5oaXN0b3J5TGlzdDtcclxuXHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8IGhMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0cm93RGF0YSA9IGhMaXN0W2ldO1xyXG5cclxuXHRcdFx0XHRyb3dEYXRhLnByb3h5ID0gYW5ndWxhci50b0pzb24oe1xyXG5cdFx0XHRcdFx0dXNlcklEOiByb3dEYXRhLnVzZXJJRCxcclxuXHRcdFx0XHRcdGhQcm94eVVzZXJJZDogcm93RGF0YS5oUHJveHlVc2VySWQsXHJcblx0XHRcdFx0XHRwcm94eVVzZXJOYW1lOiByb3dEYXRhLnByb3h5VXNlck5hbWUsXHJcblx0XHRcdFx0XHRwcm94eU9yZ05hbWU6IHJvd0RhdGEucHJveHlPcmdOYW1lLFxyXG5cdFx0XHRcdFx0dXNlclR5cGVJZDogcm93RGF0YS51c2VyVHlwZUlkXHJcblx0XHRcdFx0fSk7XHJcblxyXG5cdFx0XHRcdGlmKCFyb3dEYXRhLnVzZXJuYW1lKSB7XHJcblx0XHRcdFx0XHRyb3dEYXRhLnVzZXJuYW1lID0gcm93RGF0YS5mbmFtZSArICcgJyArIChyb3dEYXRhLmxuYW1lIHx8ICcnKVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpZihyb3dEYXRhLnVzZXJJbWFnZSl7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0dmFyIHBsYWluVXNlcklEID0gcm93RGF0YS51c2VySUQuc3BsaXQoXCIkJFwiKVswXSxcclxuXHRcdFx0XHRcdFx0cGxhaW5Qcm94eUlEID0gcm93RGF0YS5oUHJveHlVc2VySWQuc3BsaXQoXCIkJFwiKVswXSxcclxuXHRcdFx0XHRcdFx0Y3VyclVzZXJJbWdJRCA9IChwbGFpblVzZXJJRCAhPSBwbGFpblByb3h5SUQgPyBwbGFpblVzZXJJRCA6IHBsYWluUHJveHlJRClcclxuXHRcdFx0XHRcdFx0cm93RGF0YS51c2VySW1hZ2UgPSAgcm93RGF0YS51c2VySW1hZ2UucmVwbGFjZShwbGFpblByb3h5SUQsIGN1cnJVc2VySW1nSUQpO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0cm93RGF0YS51c2VyUGhvdG8gPSBhcGlDb25maWcuSU1BR0VfUEFUSCArIHJvd0RhdGEudXNlcklELnNwbGl0KCckJCcpWzBdO1xyXG5cdFx0XHRcdHJvd0RhdGEudXNlclBob3RvICs9ICcmdj0nICsgYXBpLmdldExhc3RNb2RpZmllZFByb2ZpbGVUaW1lKHJvd0RhdGEudXNlckltYWdlKTtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHRpZihyb3dEYXRhLmFjdGlvbnMpIHtcclxuXHRcdFx0XHRcdGZvcih2YXIgaiA9IDA7IGogPCByb3dEYXRhLmFjdGlvbnMubGVuZ3RoOyBqKyspIHtcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YSA9IHJvd0RhdGEuYWN0aW9uc1tqXTtcclxuXHRcdFx0XHRcdFx0dmFyIHByZUZpeERpc3ROYW1lID0gYWN0aW9uRGF0YS5kaXN0cmlidXRpb25MZXZlbCA/IGFwaUNvbmZpZy5QUkVGSVhfRElTVFJJQlVUSU9OX0xFVkVMW2FjdGlvbkRhdGEuZGlzdHJpYnV0aW9uTGV2ZWxdICsgXCIgOiBcIiA6IFwiXCI7XHJcblx0XHRcdFx0XHRcdGFjdGlvbkRhdGEucmV2aXNpb25JZCA9IHJvd0RhdGEucmV2aXNpb25JZDtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5hY3Rpb25EYXRlID0gcm93RGF0YS5hY3Rpb25EYXRlO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLml0ZW0gPSByb3dEYXRhO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLnVzZXJJRCA9IHJvd0RhdGEudXNlcklEO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLnByZWZpeD1hcGlDb25maWcuUFJFRklYX0RJU1RSSUJVVElPTl9MRVZFTFthY3Rpb25EYXRhLmRpc3RyaWJ1dGlvbkxldmVsXTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5oUHJveHlVc2VySWQgPSByb3dEYXRhLmhQcm94eVVzZXJJZDtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS51c2VySW1hZ2UgPSByb3dEYXRhLnVzZXJJbWFnZTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS51c2VyVHlwZUlkID0gcm93RGF0YS51c2VyVHlwZUlkO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLnVzZXJuYW1lID0gcm93RGF0YS51c2VybmFtZTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5vcmdOYW1lID0gcm93RGF0YS5vcmdOYW1lO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLnVzZXJfb3JnX2lkID0gcGFyc2VJbnQocm93RGF0YS5hY3Rpb25zW2pdLnVzZXJfb3JnX2lkKTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5hY3Rpb25JZCA9IHR5cGVNYXAuZGlzdHJpYnV0aW9uO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLnJldmlzaW9uTnVtID0gcm93RGF0YS5yZXZpc2lvbk51bTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5yZXZpc2lvbkNvdW50ZXIgPSByb3dEYXRhLnJldmlzaW9uQ291bnRlcjtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5wcm94eSA9IHJvd0RhdGEucHJveHk7XHJcblx0XHRcdFx0XHRcdGFjdGlvbkRhdGEudXNlclBob3RvID0gcm93RGF0YS51c2VyUGhvdG87XHJcblx0XHRcdFx0XHRcdGFjdGlvbkRhdGEucmVjaXBpZW50UGhvdG8gPSBhcGlDb25maWcuSU1BR0VfUEFUSCArIGFjdGlvbkRhdGEucmVjaXBpZW50X3VzZXJfaWQuc3BsaXQoJyQkJylbMF07XHJcblx0XHRcdFx0XHRcdGFjdGlvbkRhdGEucmVjaXBpZW50UGhvdG8gKz0gJyZ2PScgKyBhcGkuZ2V0TGFzdE1vZGlmaWVkUHJvZmlsZVRpbWUoYWN0aW9uRGF0YS51c2VyX2ltYWdlKTtcclxuXHRcdFx0XHRcdFx0YWN0aW9uRGF0YS5vYmplY3ROYW1lID0gKHByZUZpeERpc3ROYW1lICsgYWN0aW9uRGF0YS5vYmplY3ROYW1lKSB8fCBcIlwiO1xyXG5cdFx0XHRcdFx0XHRhY3Rpb25EYXRhLmlzT3BlblVzZXJMaXN0ID0gZmFsc2U7XHJcblx0XHRcdFx0XHRcdGRpc3RMaXN0LnB1c2goYWN0aW9uRGF0YSk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHQkc2NvcGUuZGlzdEFjdGlvbkxpc3QgPSBkaXN0TGlzdDtcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciBzZWxlY3RBbGxJdGVtcyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmZpbHRlckxpc3QgfHwgISRzY29wZS5maWx0ZXJMaXN0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8ICRzY29wZS5maWx0ZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dmFyIGFjdGlvbnMgPSAkc2NvcGUuZmlsdGVyTGlzdFtpXS5jaGVja2VkID0gJHNjb3BlLmhpc3RvcnkuY2hlY2tBbGw7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciBkZXNlbGVjdEFsbEl0ZW1zID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRzY29wZS5oaXN0b3J5LmNoZWNrQWxsID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiA9IFtdO1xyXG5cdFx0XHRcclxuXHRcdFx0aWYoISRzY29wZS5oaXN0b3J5TGlzdCB8fCAhJHNjb3BlLmhpc3RvcnlMaXN0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0Zm9yKHZhciBpID0gMDsgaSA8ICRzY29wZS5maWx0ZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dmFyIGFjdGlvbnMgPSAkc2NvcGUuZmlsdGVyTGlzdFtpXS5jaGVja2VkID0gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciBjbGVhckR1ZWRhdGVzID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdGlmKCEkc2NvcGUuZmlsdGVyTGlzdCB8fCAhJHNjb3BlLmZpbHRlckxpc3QubGVuZ3RoKSB7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgJHNjb3BlLmZpbHRlckxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgYWN0aW9ucyA9ICRzY29wZS5maWx0ZXJMaXN0W2ldLmR1ZWRhdGUgPSBcIlwiO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHR2YXIgc2VsZWN0SXRlbXNJblJhbmdlID0gZnVuY3Rpb24oY3VycmVudEluZGV4LCBsYXN0SW5kZXgpIHtcclxuXHRcdFx0aWYoISRzY29wZS5maWx0ZXJMaXN0IHx8ICEkc2NvcGUuZmlsdGVyTGlzdC5sZW5ndGgpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdHZhciBzdGFydEluZGV4LCBlbmRJbmRleDtcclxuXHRcdFx0aWYoY3VycmVudEluZGV4IDwgbGFzdEluZGV4KSB7XHJcblx0XHRcdFx0c3RhcnRJbmRleCA9IGN1cnJlbnRJbmRleDtcclxuXHRcdFx0XHRlbmRJbmRleCA9IGxhc3RJbmRleDtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRzdGFydEluZGV4ID0gbGFzdEluZGV4O1xyXG5cdFx0XHRcdGVuZEluZGV4ID0gY3VycmVudEluZGV4O1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgY291bnQgPSAwO1xyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgJHNjb3BlLmZpbHRlckxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHQkc2NvcGUuZmlsdGVyTGlzdFtpXS5jaGVja2VkID0gKGNvdW50ID49IHN0YXJ0SW5kZXggJiYgY291bnQgPD0gZW5kSW5kZXgpO1xyXG5cdFx0XHRcdGNvdW50Kys7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRcclxuXHRcdC8vIHN5bmMgc2VsZWN0ZWQgYWxsIGNoZWNrYm94IGFjY29yZGluZyB0byBzZWxlY3RlZCBpdGVtcyBiZWxvdyBpdC5cclxuXHRcdHZhciB1cGRhdGVDaGVja0FsbCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmZpbHRlckxpc3QgfHwgISRzY29wZS5maWx0ZXJMaXN0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVx0XHRcdFxyXG5cdFx0XHR2YXIgaSwgaXRlbSwgaXNBbGxTZWxlY3RlZCA9IHRydWU7XHJcblx0XHRcdGZvcihpID0gMDsgaSA8ICRzY29wZS5maWx0ZXJMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dmFyIGFjdGlvbnMgPSAkc2NvcGUuZmlsdGVyTGlzdFtpXTtcclxuXHRcdFx0XHRpZighYWN0aW9ucy5jaGVja2VkKSB7XHJcblx0XHRcdFx0XHRpc0FsbFNlbGVjdGVkID0gZmFsc2U7XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHRcdFx0XHRcclxuXHRcdFx0XHRpZighaXNBbGxTZWxlY3RlZCkge1xyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVx0XHRcdFx0XHJcblx0XHRcdH1cdFx0XHRcclxuXHRcdFx0JHNjb3BlLmhpc3RvcnkuY2hlY2tBbGwgPSBpc0FsbFNlbGVjdGVkO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0dmFyIHNldFNlbGVjdGVkSXRlbXMgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0dmFyIHNlbGVjdGVkSXRlbXMgPSBbXSxcclxuXHRcdFx0XHRzZWxlY3RlZFVuaXFJdGVtcyA9IHt9O1xyXG5cdFx0XHRcdFxyXG5cdFx0XHQkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24gPSBzZWxlY3RlZEl0ZW1zID0gW107XHJcblxyXG5cdFx0XHRpZighJHNjb3BlLmhpc3RvcnlMaXN0IHx8ICEkc2NvcGUuaGlzdG9yeUxpc3QubGVuZ3RoKSB7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgaSwgaXRlbTtcclxuXHRcdFx0Zm9yKGkgPSAwOyBpIDwgJHNjb3BlLmZpbHRlckxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgYWN0aW9ucyA9ICRzY29wZS5maWx0ZXJMaXN0W2ldO1xyXG5cdFx0XHRcdGlmKGFjdGlvbnMuY2hlY2tlZCkge1xyXG5cdFx0XHRcdFx0c2VsZWN0ZWRVbmlxSXRlbXNbYWN0aW9ucy51c2VyX2lkKydfJythY3Rpb25zLmFjdGlvbl9uYW1lKydfJythY3Rpb25zLmFjdGlvbkRhdGVdID0gYWN0aW9ucztcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGZvciAoIHZhciB1bmlxdWVLZXkgaW4gc2VsZWN0ZWRVbmlxSXRlbXMgKVxyXG5cdFx0XHRcdHNlbGVjdGVkSXRlbXMucHVzaChzZWxlY3RlZFVuaXFJdGVtc1t1bmlxdWVLZXldKTtcclxuXHJcblx0XHRcdCRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiA9IHNlbGVjdGVkSXRlbXM7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHR2YXIgaGFzQWN0aW9uID0gZnVuY3Rpb24ocGFyYW1PYmopIHtcclxuXHRcdFx0aWYoISRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiB8fCAhJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uLmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0dmFyIGhhc0FjdCA9IGZhbHNlLFxyXG5cdFx0XHRcdHN0YXR1cyA9IHBhcmFtT2JqLnN0YXR1cyxcclxuXHRcdFx0XHRoYXNQcml2ID0gZmFsc2UsIFxyXG5cdFx0XHRcdG9yZ1ByaXYgPSBwYXJhbU9iai5hbGxPcmcsXHJcblx0XHRcdFx0cHJvamVjdFByaXYgPSBwYXJhbU9iai5wcm9qT3JnLFxyXG5cdFx0XHRcdG93blByaXYgPSBwYXJhbU9iai5vd25PcmcsIFxyXG5cdFx0XHRcdHByaXZWYWx1ZUFycmF5ID0gW107XHJcblxyXG5cdFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dmFyIGRhdGEgPSAkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb25baV07XHJcblx0XHRcdFx0dmFyIGNvbmRpdGlvbiA9IGRhdGEuYWN0aW9uX3N0YXR1cyA9PSBzdGF0dXM7XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0aWYoY29uZGl0aW9uKSB7XHJcblx0XHRcdFx0XHRoYXNBY3QgPSB0cnVlO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0aWYoaGFzQWN0KXtcclxuXHRcdCAgICAgICAgXHQgLy9DYW4gQ2xlYXIvRGVsZWdhdGUgT3duIEFjdGlvbnMgb25seS4gaS5lLiBmb3IgbG9naW4gT3JnYW5pc2F0aW9ucyBhbmQgUHJvamVjdC5cclxuXHRcdCAgICAgICAgICAgIHZhciBwbGFpblVzZXJJZCA9IFVTUC51c2VySUQ7XHJcblx0XHQgICAgICAgICAgICBpZihvd25Qcml2ICYmIHBsYWluVXNlcklkICYmIGRhdGEucmVjaXBpZW50X3VzZXJfaWQgPT0gcGxhaW5Vc2VySWQpe1xyXG5cdFx0ICAgICAgICAgICAgXHRoYXNQcml2ID0gdHJ1ZTtcclxuXHRcdCAgICAgICAgICAgIH1cclxuXHRcdCAgICAgICAgICAgIC8vQ2FuIENsZWFyL0RlbGVnYXRlIEFjdGlvbnMgZm9yIGFsbCB1c2VycyAoZXhjZXB0IG93bikgYWNyb3NzIGFsbCBvcmdhbmlzYXRpb24gb2YgdGhlIFByb2plY3RcclxuXHRcdCAgICAgICAgICAgIGlmKGhhc1ByaXYgPT0gZmFsc2UgJiYgcHJvamVjdFByaXYgICYmIShkYXRhLnJlY2lwaWVudF91c2VyX2lkID09IHBsYWluVXNlcklkKSl7XHJcblx0XHQgICAgICAgICAgICBcdGhhc1ByaXYgPSB0cnVlO1xyXG5cdFx0ICAgICAgICAgICAgfVxyXG5cdFx0ICAgICAgICAgICAgLy8gQ2FuIENsZWFyL0RlbGVnYXRlIEFjdGlvbnMgZm9yIGFsbCB1c2VycyAoZXhjZXB0IG93bikgb2YgdGhlIGxvZ2luIG9yZ2FuaXNhdGlvbiBvbmx5XHJcblx0XHQgICAgICAgICAgICBpZihoYXNQcml2ID09IGZhbHNlICYmIG9yZ1ByaXYgJiYgKGRhdGEudXNlcl9vcmdfaWQgPT0gVVNQLm9yZ0lEICkgJiYgIShkYXRhLnJlY2lwaWVudF91c2VyX2lkID09IHBsYWluVXNlcklkKSApe1xyXG5cdFx0ICAgICAgICAgICAgXHRoYXNQcml2ID0gdHJ1ZTtcclxuXHRcdCAgICAgICAgICAgIH1cclxuXHRcdCAgICAgICAgICAgIGlmKCFoYXNQcml2KXtcclxuXHRcdCAgICAgICAgICAgIFx0aGFzQWN0ID0gaGFzUHJpdjtcclxuXHRcdCAgICAgICAgICAgIH1cclxuICAgICAgICBcdFx0fSAgICAgICAgXHJcbiAgICAgICAgXHRcdHByaXZWYWx1ZUFycmF5LnB1c2goaGFzQWN0KTtcclxuICAgIFx0XHR9XHJcblxyXG4gICAgXHRcdGZvcih2YXIgaj0wOyBqPD1wcml2VmFsdWVBcnJheS5sZW5ndGg7IGorKyl7XHJcbiAgICBcdFx0XHRpZihwcml2VmFsdWVBcnJheVtqXSl7XHJcbiAgICBcdFx0XHRcdHJldHVybiB0cnVlXHJcbiAgICBcdFx0XHR9XHJcbiAgICBcdFx0fVxyXG4gICAgXHRcdHJldHVybiBmYWxzZVxyXG4gICAgXHRcdC8vIHJldHVybiAgJC5pbkFycmF5KCB0cnVlLCBwcml2VmFsdWVBcnJheSApID09IC0xID8gZmFsc2UgOiB0cnVlOyBcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIGhhc0FjdGlvbkRlYWN0aXZlUmVhY3RpdmUgPSBmdW5jdGlvbihwYXJhbU9iail7XHJcblx0XHRcdHZhciBoYXNBY3QgPSBmYWxzZSwgXHJcblx0XHQgICAgXHRoYXNQcml2ID0gZmFsc2UsIFxyXG5cdFx0ICAgIFx0YWxsT3JnUHJpdmlsZWdlID0gcGFyYW1PYmouYWxsT3JnLFxyXG5cdFx0ICAgIFx0b3duT3JnUHJpdmlsZWdlID0gcGFyYW1PYmoub3duT3JnLCBcclxuXHRcdCAgICBcdHByaXZWYWx1ZUFycmF5ID0gW107XHJcblxyXG5cdCAgICAgICAgaWYoISRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiB8fCAhJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uLmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdFx0fVxyXG5cdFx0ICAgIFxyXG5cdFx0ICAgIGZvcihpID0gMDsgaSA8ICRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbi5sZW5ndGg7IGkrKykge1xyXG5cdFx0ICAgICAgICB2YXIgZGF0YSA9ICRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbltpXTtcclxuXHRcdFx0XHR2YXIgY29uZGl0aW9uID0gZGF0YS5hY3Rpb25fc3RhdHVzID09IHBhcmFtT2JqLnN0YXR1cztcclxuXHRcdCAgICAgICAgaWYgKHBhcmFtT2JqLmludmVydCkgeyAvLyBcImludmVydCA9IHRydWVcIiBmb3IgRGVhY3RpdmF0aW9uXHJcblx0XHQgICAgICAgICAgICBjb25kaXRpb24gPSAhY29uZGl0aW9uXHJcblx0XHQgICAgICAgIH1cclxuXHRcdCAgICAgICAgaWYgKGNvbmRpdGlvbikge1xyXG5cdFx0ICAgICAgICAgICAgaGFzQWN0ID0gdHJ1ZVxyXG5cdFx0ICAgICAgICB9XHJcblx0XHQgICAgICAgIFxyXG5cdFx0ICAgICAgICBpZihoYXNBY3QpeyAgICAgICAgXHRcclxuXHRcdCAgICAgICAgICAgIGlmKGFsbE9yZ1ByaXZpbGVnZSl7IC8vQ2FuIERlYWN0aXZhdGUvUmVhY3RpdmF0ZSBBbGwgT3JnIEFjdGlvbnMuXHJcblx0XHQgICAgICAgICAgICBcdGhhc1ByaXYgPSB0cnVlO1xyXG5cdFx0ICAgICAgICAgICAgfSBlbHNlIGlmKG93bk9yZ1ByaXZpbGVnZSAmJiBkYXRhLnVzZXJfb3JnX2lkID09IFVTUC5vcmdJRCl7IC8vQ2FuIERlYWN0aXZhdGUvUmVhY3RpdmF0ZSBPd24gT3JnIEFjdGlvbnMgb25seS5cclxuXHRcdCAgICAgICAgICAgIFx0aGFzUHJpdiA9IHRydWU7XHJcblx0XHQgICAgICAgICAgICB9ICAgICAgICAgICAgXHJcblx0XHQgICAgICAgICAgICBpZighaGFzUHJpdil7XHJcblx0XHQgICAgICAgICAgICBcdGhhc0FjdCA9IGhhc1ByaXY7XHJcblx0XHQgICAgICAgICAgICB9XHJcblx0XHQgICAgICAgIH0gICAgICAgIFxyXG5cdFx0ICAgICAgICBwcml2VmFsdWVBcnJheS5wdXNoKGhhc0FjdCk7XHJcblx0XHQgICAgfVxyXG5cclxuXHRcdCAgICBmb3IodmFyIGo9MDsgajw9cHJpdlZhbHVlQXJyYXkubGVuZ3RoOyBqKyspe1xyXG4gICAgXHRcdFx0aWYocHJpdlZhbHVlQXJyYXlbal0pe1xyXG4gICAgXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcclxuICAgIFx0XHRcdH1cclxuICAgIFx0XHR9XHJcbiAgICBcdFx0cmV0dXJuIGZhbHNlO1xyXG4gICAgXHRcdC8vIHJldHVybiAgJC5pbkFycmF5KCB0cnVlLCBwcml2VmFsdWVBcnJheSApID09IC0xID8gZmFsc2UgOiB0cnVlOyBcclxuXHRcdH1cclxuXHRcdFxyXG5cdFx0dmFyIGdldEFjdGlvbnMgPSBmdW5jdGlvbihzdGF0dXMsIGludmVydCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uIHx8ICEkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24ubGVuZ3RoKSB7XHJcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgYWN0aW9ucyA9IFtdO1xyXG5cdFx0XHRmb3IoaSA9IDA7IGkgPCAkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24ubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgZGF0YSA9ICRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbltpXTtcclxuXHRcdFx0XHR2YXIgY29uZGl0aW9uID0gZGF0YS5hY3Rpb25fc3RhdHVzID09IHN0YXR1cztcclxuXHRcdFx0XHRpZihpbnZlcnQpIHtcclxuXHRcdFx0XHRcdGNvbmRpdGlvbiA9ICFjb25kaXRpb247XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdGlmKGNvbmRpdGlvbikge1xyXG5cdFx0XHRcdFx0YWN0aW9ucy5wdXNoKGRhdGEpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0cmV0dXJuIGFjdGlvbnM7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHR2YXIgZ2V0SWRTdHJpbmcgPSBmdW5jdGlvbihhY3Rpb25zLCBpc0ZvclJlcG9ydCkge1xyXG5cdFx0XHRhY3Rpb25zID0gYWN0aW9ucyB8fCAkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb247XHJcblx0XHRcdGlmKCFhY3Rpb25zIHx8ICFhY3Rpb25zLmxlbmd0aCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0dmFyIGRySWRzID0gW107XHJcblx0XHRcdGZvcihpID0gMDsgaSA8IGFjdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgZGF0YSA9IGFjdGlvbnNbaV07XHJcblx0XHRcdFx0aWYoZGF0YS5jaGVja2VkKSB7XHJcblx0XHRcdFx0XHRpZihpc0ZvclJlcG9ydCkge1xyXG5cdFx0XHRcdFx0XHRkcklkcy5wdXNoKGRhdGEuZGlzdF9saXN0X2lkICsgXCJ8XCIgKyBkYXRhLmFjdGlvbl9pZCArIFwifFwiICsgZGF0YS51c2VyX2lkICsgXCJ8XCIgKyBkYXRhLnJldmlzaW9uSWQpO1xyXG5cdFx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdFx0ZHJJZHMucHVzaChkYXRhLmRpc3RfbGlzdF9pZCArIFwifFwiICsgZGF0YS51c2VyX2lkICsgXCJ8XCIgKyBkYXRhLmFjdGlvbl9pZCk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRyZXR1cm4gZHJJZHMuam9pbignLCcpO1xyXG5cdFx0fTtcclxuXHRcdC8qKlxyXG5cdFx0ICogUmV0dXJuIHZpc2liaWxpdHkgb2JqZWN0XHJcblx0XHQgKi9cclxuXHRcdHZhciByZXR1cm5WaXNpYmlsaXR5RGF0YSA9IGZ1bmN0aW9uIChhY3Rpb25EYXRhKSB7XHJcblx0XHRcdHZhciB2aXNpYmlsaXR5RGF0YSA9IFtdO1xyXG5cdFx0XHRmb3IgKGkgPSAwOyBpIDwgYWN0aW9uRGF0YS5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdHZhciBkYXRhID0gYWN0aW9uRGF0YVtpXTtcclxuXHRcdFx0XHRpZihkYXRhLmRpc3RyaWJ1dGlvbkxldmVsICE9IGFwaUNvbmZpZy5ESVNUUklCVVRJT05fTEVWRUwuVVNFUlMpe1xyXG5cdFx0XHRcdFx0dmFyIHBlcm1pc3Npb25MZXZlbElkID0gZGF0YS5kaXN0cmlidXRpb25MZXZlbElkO1xyXG5cdFx0XHRcdFx0aWYoZGF0YS5kaXN0cmlidXRpb25MZXZlbCA9PSBhcGlDb25maWcuRElTVFJJQlVUSU9OX0xFVkVMLkRJU1RSSUJVVElPTl9HUk9VUFMpe1xyXG5cdFx0XHRcdFx0XHRwZXJtaXNzaW9uTGV2ZWxJZCA9IGRhdGEuZGlzdHJpYnV0aW9uTGV2ZWxJZCAmJiBkYXRhLmRpc3RyaWJ1dGlvbkxldmVsSWQuc3BsaXQoXCIkJFwiKVswXTtcclxuXHRcdFx0XHRcdH1cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHR2aXNpYmlsaXR5RGF0YS5wdXNoKHtcclxuXHRcdFx0XHRcdFx0XCJoUHJvamVjdElkXCI6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRcdFx0XCJyZXNvdXJjZVR5cGVJZFwiOiAyLFxyXG5cdFx0XHRcdFx0XHRcImhSZXNvdXJjZUlkXCI6IGRhdGEucmV2aXNpb25JZCxcclxuXHRcdFx0XHRcdFx0XCJhZG9kZGxlT2JqZWN0UGVybWlzc2lvblZPTGlzdFwiOiBbe1xyXG5cdFx0XHRcdFx0XHRcdFwiaFBlcm1pc3Npb25MZXZlbElkXCI6IHBlcm1pc3Npb25MZXZlbElkLFxyXG5cdFx0XHRcdFx0XHRcdFwiaGFzaExldmVsSWRcIjogZGF0YS5kaXN0cmlidXRpb25MZXZlbElkLFxyXG5cdFx0XHRcdFx0XHRcdFwicGVybWlzc2lvbkxldmVsXCI6IGRhdGEuZGlzdHJpYnV0aW9uTGV2ZWxcclxuXHRcdFx0XHRcdFx0fV1cclxuXHRcdFx0XHRcdH0pO1x0XHRcdFx0XHRcclxuXHRcdFx0XHR9XHRcdFx0XHJcblx0XHRcdH1cclxuXHRcdFx0dmFyIHVuaXF1ZVNlbGVjdGVkRGlzdERhdGEgPSBbXTtcclxuXHRcdFx0aWYgKHZpc2liaWxpdHlEYXRhICYmIHZpc2liaWxpdHlEYXRhLmxlbmd0aCkge1xyXG5cdFx0XHQgIHZhciB1bmlxdWVLZXlNYXAgPSB7fSwgdW5pcXVlS2V5VmlzaU1hcCA9IHt9LCBjdXJyT2JqLCBjdXJQZXJtaXNzaW9uVm87XHJcblx0XHRcdCAgZm9yICh2YXIgaSA9IDA7IGkgPCB2aXNpYmlsaXR5RGF0YS5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdGN1cnJPYmogPSB2aXNpYmlsaXR5RGF0YVtpXVxyXG5cdFx0XHRcdGN1clBlcm1pc3Npb25WbyA9IHZpc2liaWxpdHlEYXRhW2ldLmFkb2RkbGVPYmplY3RQZXJtaXNzaW9uVk9MaXN0WzBdO1xyXG5cdFx0XHRcdGlmIChPYmplY3Qua2V5cyh1bmlxdWVLZXlNYXApLmxlbmd0aCA9PSAwKSB7XHJcblx0XHRcdFx0XHR1bmlxdWVLZXlNYXBbY3Vyck9iai5oUmVzb3VyY2VJZCArIFwiI1wiICsgY3VyUGVybWlzc2lvblZvLmhhc2hMZXZlbElkXSA9IGN1cnJPYmo7XHJcblx0XHRcdFx0XHR1bmlxdWVTZWxlY3RlZERpc3REYXRhLnB1c2goY3Vyck9iaik7XHJcblx0XHRcdFx0ICB9IGVsc2Uge1xyXG5cdFx0XHRcdFx0aWYgKCF1bmlxdWVLZXlNYXBbY3Vyck9iai5oUmVzb3VyY2VJZCArIFwiI1wiICsgY3VyUGVybWlzc2lvblZvLmhhc2hMZXZlbElkXSl7XHJcblx0XHRcdFx0XHRcdHVuaXF1ZUtleU1hcFtjdXJyT2JqLmhSZXNvdXJjZUlkICsgXCIjXCIgKyBjdXJQZXJtaXNzaW9uVm8uaGFzaExldmVsSWRdID0gY3Vyck9iajtcclxuXHRcdFx0XHRcdFx0dW5pcXVlU2VsZWN0ZWREaXN0RGF0YS5wdXNoKGN1cnJPYmopOyBcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdCAgfVxyXG5cdFx0XHR9XHJcblx0XHRcdHJldHVybiB1bmlxdWVTZWxlY3RlZERpc3REYXRhO1xyXG5cdFx0fTtcclxuXHRcdHZhciByZWFjdGl2ZURlYWN0aXZlTGlzdCA9IGZ1bmN0aW9uKGFjdGlvbiwgbGlzdGluZ0FjdGlvbklELCBzZWxlY3RlZEFjdGlvbnMpIHtcclxuXHRcdFx0XHRcdFxyXG5cdFx0XHQkc2NvcGUueGhyLmFjdGl2YXRlID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdHVybCAgOiBhcGlDb25maWcuRE9DVU1FTlRfQ09OVFJPTExFUixcclxuXHRcdFx0XHRkYXRhIDoge1xyXG5cdFx0XHRcdFx0YWN0aW9uX2lkOiBsaXN0aW5nQWN0aW9uSUQsXHJcblx0XHRcdFx0XHRwcm9qZWN0X2lkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcblx0XHRcdFx0XHRkcklkOiBnZXRJZFN0cmluZyhzZWxlY3RlZEFjdGlvbnMpXHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHRcdFx0XHJcblx0XHRcdCRzY29wZS54aHIuYWN0aXZhdGUudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xyXG5cdFx0XHRcdGlmKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKXtcclxuXHRcdFx0XHRcdHZhciBhY3Rpb25JRCA9IFwiXCI7XHJcblx0XHRcdFx0XHRpZihhY3Rpb24gPT0gJ2RlYWN0aXZlJyl7XHJcblx0XHRcdFx0XHRcdGFjdGlvbklEID0gYXBpQ29uZmlnLkRFQUNUSVZBVEVfRklMRV9BQ1RJT047XHJcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGFjdGlvbiA9PSAncmVhY3RpdmUnKXtcclxuXHRcdFx0XHRcdFx0YWN0aW9uSUQgPSBhcGlDb25maWcuUkVBQ1RJVkFURV9GSUxFX0FDVElPTjtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0dmFyIGRySWRzID0gZ2V0SWRTdHJpbmcoJHNjb3BlLmZpbHRlckxpc3QpOy8vZ2V0SWRTdHJpbmcoJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uKTtcclxuXHRcdFx0XHRcdHZhciBkcklkc0FyciA9IGRySWRzLnNwbGl0KFwiLFwiKSB8fCBbXTtcclxuXHRcdFx0XHRcdHZhciBmaWx0ZXJlZEFjdGlvbkRySWRzID0gW10sIGxpc3RBY3Rpb25EYXRhID0gW10sICB2aXNpYmlsaXR5RGlzdExpc3RJZCA9IFtdO1xyXG5cdFx0XHRcdFx0dmFyIGZpbHRyRGF0YVJlcyA9IHJlc3BvbnNlLmRhdGFcclxuXHRcdFx0XHRcdGZvcihpID0gMDsgaSA8IGZpbHRyRGF0YVJlcy5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0XHR2YXIgdGhpc1Jlc09iaiA9IGZpbHRyRGF0YVJlc1tpXTtcclxuXHRcdFx0XHRcdFx0dmFyIHRoaXNJZCA9IHRoaXNSZXNPYmoucmV2aXNpb25EaXN0TGlzdElkICsgXCJ8XCIgKyB0aGlzUmVzT2JqLnJlY2lwaWVudF91c2VyX2lkLnNwbGl0KCckJCcpWzBdICsgXCJ8XCIgKyB0aGlzUmVzT2JqLmFjdGlvbklkXHJcblx0XHRcdFx0XHRcdGZvcih2YXIgaj0wOyBqPGRySWRzQXJyLmxlbmd0aDsgaisrKXtcclxuXHRcdFx0XHRcdFx0XHRpZih0aGlzSWQgPT0gZHJJZHNBcnJbal0pe1x0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0XHRcdGZpbHRlcmVkQWN0aW9uRHJJZHMucHVzaChkcklkc0FycltqXSk7XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdGlmKHRoaXNSZXNPYmouYXNrRm9yUmVtb3ZlVmlzaWJpbGl0eSl7XHJcblx0XHRcdFx0XHRcdFx0dmlzaWJpbGl0eURpc3RMaXN0SWQucHVzaCh0aGlzUmVzT2JqLnJldmlzaW9uRGlzdExpc3RJZCk7XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0aWYgKGFjdGlvbiA9PSAnZGVhY3RpdmUnICYmIHZpc2liaWxpdHlEaXN0TGlzdElkLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHR2YXIgdmlzaWJpbGl0eUZpbHRlcmVkQXJyYXkgPSB2aXNpYmlsaXR5RGlzdExpc3RJZC5maWx0ZXIoZnVuY3Rpb24gKGl0ZW0sIHBvcykge1xyXG5cdFx0XHRcdFx0XHRcdHJldHVybiB2aXNpYmlsaXR5RGlzdExpc3RJZC5pbmRleE9mKGl0ZW0pID09IHBvcztcclxuXHRcdFx0XHRcdFx0fSk7XHJcblxyXG5cdFx0XHRcdFx0XHRsaXN0QWN0aW9uRGF0YSA9IHNlbGVjdGVkQWN0aW9ucy5maWx0ZXIoZnVuY3Rpb24gKHZhbCwgaSkge1xyXG5cdFx0XHRcdFx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgdmlzaWJpbGl0eUZpbHRlcmVkQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdFx0XHRcdHZhciBkaXN0TGlzdElkID0gdmlzaWJpbGl0eUZpbHRlcmVkQXJyYXlbaV07XHJcblx0XHRcdFx0XHRcdFx0XHRpZiAodmFsLmRpc3RfbGlzdF9pZC5zcGxpdChcIiQkXCIpWzBdID09IGRpc3RMaXN0SWQuc3BsaXQoXCIkJFwiKVswXSkge1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gdmFsO1xyXG5cdFx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0XHRpZihhY3Rpb25JRCE9XCJcIiAmJiBmaWx0ZXJlZEFjdGlvbkRySWRzLmxlbmd0aCl7XHJcblx0XHRcdFx0XHRcdGlmKGFjdGlvbiA9PSAnZGVhY3RpdmUnICYmIGxpc3RBY3Rpb25EYXRhICYmIGxpc3RBY3Rpb25EYXRhLmxlbmd0aCA+IDApe1xyXG5cdFx0XHRcdFx0XHRcdCRzY29wZS5jb25maXJtT3BlbiA9IHRydWU7XHJcblx0XHRcdFx0XHRcdFx0JHNjb3BlLmFjdGlvblBhcmFtID0ge1xyXG5cdFx0XHRcdFx0XHRcdFx0XCJhY3Rpb25cIjogYWN0aW9uLCBcclxuXHRcdFx0XHRcdFx0XHRcdFwiYWN0aW9uSURcIjogYWN0aW9uSUQsXHJcblx0XHRcdFx0XHRcdFx0XHRcImZpbHRlcmVkQWN0aW9uRHJJZHNcIjogZmlsdGVyZWRBY3Rpb25Ecklkcy5qb2luKCksIFxyXG5cdFx0XHRcdFx0XHRcdFx0XCJmaWx0ckRhdGFSZXNcIjogZmlsdHJEYXRhUmVzLFxyXG5cdFx0XHRcdFx0XHRcdFx0XCJzZWxlY3RlZEFjdGlvbnNcIjogc2VsZWN0ZWRBY3Rpb25zLFxyXG5cdFx0XHRcdFx0XHRcdFx0XCJsaXN0QWN0aW9uRGF0YVwiOiBsaXN0QWN0aW9uRGF0YVxyXG5cdFx0XHRcdFx0XHRcdH07XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdFx0XHRyZWFjdGl2ZURlYWN0aXZlKGFjdGlvbiwgYWN0aW9uSUQsIGZpbHRlcmVkQWN0aW9uRHJJZHMuam9pbigpLCBmaWx0ckRhdGFSZXMsIHNlbGVjdGVkQWN0aW9ucyk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0Ly9Eb2VzIG5vdCBoYXZlIGFueSBwZXJtaXNzaW9uLlxyXG5cdFx0XHRcdFx0JHNjb3BlLnhoci5jbGVhciA9IGZhbHNlO1xyXG5cdFx0XHRcdFx0JHNjb3BlLmhpc3RvcnkuY2hlY2tBbGwgPSBmYWxzZTtcclxuXHRcdFx0XHRcdCRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiA9IFtdO1xyXG5cdFx0XHRcdFx0Ly8gTm90aWZpY2F0aW9uLmVycm9yKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2dcIj5UaGVyZSBhcmUgbm8gcGVuZGluZyBhY3Rpb25zIHRvIGNsZWFyIG9yIHlvdSBkbyBub3QgaGF2ZSB0aGUgcGVybWlzc2lvbiB0byB1cGRhdGUgb3RoZXIgdXNlcnMgYWN0aW9ucyE8L2Rpdj4nKTtcclxuXHRcdFx0XHRcdHZhciBpc0RlYWN0aXZhdGVkID0gXCJcIjtcclxuXHRcdFx0XHRcdGlmKGFjdGlvbiA9PSAnZGVhY3RpdmUnKXtcclxuXHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLndhcm5pbmcoJzxkaXYgY2xhc3M9XCJib2xkLW1zZ1wiPlRhc2socykgZGVhY3RpdmF0ZWQgZm9yIDAgLyAnICsgc2VsZWN0ZWRBY3Rpb25zLmxlbmd0aCArICcgcmVjb3JkKHMpLjxicj4nXHJcblx0XHRcdFx0XHRcdCArIHNlbGVjdGVkQWN0aW9ucy5sZW5ndGggKyAnIHJlY29yZChzKSB3ZXJlIG5vdCBkZWFjdGl2YXRlZCBkdWUgdG8gb25lL2FsbCBvZiB0aGUgYmVsb3cgcmVhc29uczogPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBhKSBZb3UgZG8gbm90IGhhdmUgcHJpdmlsZWdlIHRvIGRlYWN0aXZhdGUgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBiKSBUYXNrIGZvciBzZWxlY3RlZCByZWNvcmQgd2FzIGFscmVhZHkgZGVhY3RpdmF0ZWQ8L2Rpdj4nKTtcclxuXHRcdFx0XHRcdH0gZWxzZXtcclxuXHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLndhcm5pbmcoJzxkaXYgY2xhc3M9XCJib2xkLW1zZ1wiPlRhc2socykgcmVhY3RpdmF0ZWQgZm9yIDAgLyAnICsgc2VsZWN0ZWRBY3Rpb25zLmxlbmd0aCArICcgcmVjb3JkKHMpLjxicj4nXHJcblx0XHRcdFx0XHRcdCArIHNlbGVjdGVkQWN0aW9ucy5sZW5ndGggKyAnIHJlY29yZChzKSB3ZXJlIG5vdCByZWFjdGl2YXRlZCBkdWUgdG8gb25lL2FsbCBvZiB0aGUgYmVsb3cgcmVhc29uczogPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBhKSBZb3UgZG8gbm90IGhhdmUgcHJpdmlsZWdlIHRvIHJlYWN0aXZhdGUgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBiKSBUYXNrIGZvciBzZWxlY3RlZCByZWNvcmQgd2FzIGFscmVhZHkgcmVhY3RpdmF0ZWQ8L2Rpdj4nKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHRcdFx0XHRcclxuXHRcdFx0fSwgZnVuY3Rpb24oeGhyKSB7XHJcblx0XHRcdFx0JHNjb3BlLnhoci5hY3RpdmF0ZSA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LmNoZWNrQWxsID0gZmFsc2U7XHJcblx0XHRcdFx0Ly9pZih4aHIuc3RhdHVzICE9IC0xKVxyXG5cdFx0XHRcdFx0Ly9Ob3RpZmljYXRpb24uZXJyb3IoJzxkaXYgY2xhc3M9XCJib2xkLW1zZyB0ZXh0LWNlbnRlclwiPkVycm9yIHdoaWxlIHVwZGF0aW5nITwvZGl2PicpO1xyXG5cdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJyZWFjdGl2YXRlLWRlYWN0aXZlLWVycm9yLW1zZ1wiKTtcclxuXHRcdFx0XHRhcGkuc2hvd1NlcnZlckVyck1zZyh4aHIpO1xyXG5cdFx0XHR9KTtcclxuXHRcdH07XHJcblxyXG5cdFx0dmFyIHJlYWN0aXZlRGVhY3RpdmUgPSBmdW5jdGlvbihhY3Rpb24sIGFjdGlvbklELCBmaWx0ZXJlZEFjdGlvbkRySWRzLCBhY3Rpb25zLCBzZWxlY3RlZEFjdGlvbnMsIGxpc3REYXRhKXtcclxuXHJcblx0XHRcdHZhciBwYXJhbXNPYmogPSB7XHJcblx0XHRcdFx0YWN0aW9uX2lkOiBhY3Rpb25JRCxcclxuXHRcdFx0XHRwcm9qZWN0X2lkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcblx0XHRcdFx0ZHJJZDogZmlsdGVyZWRBY3Rpb25EcklkcyAvL2dldElkU3RyaW5nKGFjdGlvbnMpXHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmIChsaXN0RGF0YSAmJiBsaXN0RGF0YS5sZW5ndGggPiAwKSB7XHJcblx0XHRcdFx0dmFyIHZpc2liaWxpdHlEYXRhID0gcmV0dXJuVmlzaWJpbGl0eURhdGEobGlzdERhdGEpO1xyXG5cdFx0XHRcdGlmICh2aXNpYmlsaXR5RGF0YS5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdHBhcmFtc09iai52aXNpYmlsaXR5Vk9MaXN0ID0gSlNPTi5zdHJpbmdpZnkodmlzaWJpbGl0eURhdGEpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0JHNjb3BlLnhoci5hY3RpdmF0ZSA9IGFwaS5hamF4KHtcclxuXHRcdFx0XHR1cmwgIDogYXBpQ29uZmlnLkRPQ1VNRU5UX0NPTlRST0xMRVIsXHJcblx0XHRcdFx0ZGF0YSA6IHBhcmFtc09ialxyXG5cdFx0XHR9KTtcclxuXHJcblx0XHRcdCRzY29wZS54aHIuYWN0aXZhdGUudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xyXG5cdFx0XHRcdHZhciB0b3RhbFNlbGVjdGVkUmVjb3JkcyA9IHNlbGVjdGVkQWN0aW9ucy5sZW5ndGg7XHJcblx0XHRcdFx0dmFyIHVwZGF0ZWRSZWNvcmRzQ250ID0gZmlsdGVyZWRBY3Rpb25Ecklkcy5zcGxpdChcIixcIikubGVuZ3RoO1xyXG5cdFx0XHRcdCRzY29wZS54aHIuYWN0aXZhdGUgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5jaGVja0FsbCA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbiA9IFtdO1xyXG5cdFx0XHRcdGZldGNoKCk7XHJcblx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHR2YXIgdXBkYXRlRGV0YWlsID0ge307XHJcblx0XHRcdFx0XHR1cGRhdGVEZXRhaWxbYXBpQ29uZmlnLmVudGl0eS5GSUxFXSA9IGFjdGlvbnNbMF0ucmV2aXNpb25JZDtcclxuXHRcdFx0XHRcdGFwaS5pbmZvcm1QYXJlbnRXaW4odXBkYXRlRGV0YWlsKTtcclxuXHRcdFx0XHR9LCAyMDAwKTtcclxuXHRcdFx0XHQvLyBOb3RpZmljYXRpb24uc3VjY2VzcygnPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+JyArIGZpbHRlcmVkQWN0aW9uRHJJZHMuc3BsaXQoXCIsXCIpLmxlbmd0aCArICcgJyArIChhY3Rpb25JRCA9PSBhcGlDb25maWcuREVBQ1RJVkFURV9GSUxFX0FDVElPTiA/IGxhbmcuZ2V0KCdkZWFjdGl2ZUNvbmZpcm1Nc2cnKSA6IGxhbmcuZ2V0KCdhY3RpdmVDb25maXJtTXNnJykpICsgJzwvZGl2PicpO1xyXG5cclxuXHRcdFx0XHRpZihhY3Rpb24gPT0gJ2RlYWN0aXZlJyl7XHJcblx0XHRcdFx0XHQvL0ZvciBEZWFjdGl2YXRlXHJcblx0XHRcdFx0XHRpZih1cGRhdGVkUmVjb3Jkc0NudCA8IHRvdGFsU2VsZWN0ZWRSZWNvcmRzKXtcclxuXHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLndhcm5pbmcoJzxkaXYgY2xhc3M9XCJib2xkLW1zZ1wiPlRhc2socykgZGVhY3RpdmF0ZWQgZm9yICcgKyB1cGRhdGVkUmVjb3Jkc0NudCArICcgLyAnICsgdG90YWxTZWxlY3RlZFJlY29yZHMgKyAnIHJlY29yZChzKS48YnI+J1xyXG5cdFx0XHRcdFx0XHQgKyAodG90YWxTZWxlY3RlZFJlY29yZHMgLSB1cGRhdGVkUmVjb3Jkc0NudCkgKyAnIHJlY29yZChzKSB3ZXJlIG5vdCBkZWFjdGl2YXRlZCBkdWUgdG8gb25lL2FsbCBvZiB0aGUgYmVsb3cgcmVhc29uczogPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBhKSBZb3UgZG8gbm90IGhhdmUgcHJpdmlsZWdlIHRvIGRlYWN0aXZhdGUgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgJyBiKSBUYXNrIGZvciBzZWxlY3RlZCByZWNvcmQgd2FzIGFscmVhZHkgZGVhY3RpdmF0ZWQ8L2Rpdj4nKTtcclxuXHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdE5vdGlmaWNhdGlvbi5zdWNjZXNzKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2cgdGV4dC1jZW50ZXJcIj5UYXNrKHMpIGRlYWN0aXZhdGVkIGZvciAnICsgdXBkYXRlZFJlY29yZHNDbnQgKyAnIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocyk8L2Rpdj4nKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0Ly9Gb3IgUmVhY3RpdmF0ZVxyXG5cdFx0XHRcdFx0aWYodXBkYXRlZFJlY29yZHNDbnQgPCB0b3RhbFNlbGVjdGVkUmVjb3Jkcyl7XHJcblx0XHRcdFx0XHRcdE5vdGlmaWNhdGlvbi53YXJuaW5nKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2dcIj5UYXNrKHMpIHJlYWN0aXZhdGVkIGZvciAnICsgdXBkYXRlZFJlY29yZHNDbnQgKyAnIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocykuPGJyPidcclxuXHRcdFx0XHRcdFx0ICsgKHRvdGFsU2VsZWN0ZWRSZWNvcmRzIC0gdXBkYXRlZFJlY29yZHNDbnQpICsgJyByZWNvcmQocykgd2VyZSBub3QgcmVhY3RpdmF0ZWQgZHVlIHRvIG9uZS9hbGwgb2YgdGhlIGJlbG93IHJlYXNvbnM6IDxicj4nXHJcblx0XHRcdFx0XHRcdCArICcgYSkgWW91IGRvIG5vdCBoYXZlIHByaXZpbGVnZSB0byByZWFjdGl2YXRlIHRhc2sgb24gc2VsZWN0ZWQgcmVjb3JkIDxicj4nXHJcblx0XHRcdFx0XHRcdCArICcgYikgVGFzayBmb3Igc2VsZWN0ZWQgcmVjb3JkIHdhcyBhbHJlYWR5IHJlYWN0aXZhdGVkPC9kaXY+Jyk7XHJcblx0XHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0XHROb3RpZmljYXRpb24uc3VjY2VzcygnPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+VGFzayhzKSByZWFjdGl2YXRlZCBmb3IgJyArIHVwZGF0ZWRSZWNvcmRzQ250ICsgJyAvICcgKyB0b3RhbFNlbGVjdGVkUmVjb3JkcyArICcgcmVjb3JkKHMpPC9kaXY+Jyk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0fSwgZnVuY3Rpb24oeGhyKSB7XHJcblx0XHRcdFx0JHNjb3BlLnhoci5hY3RpdmF0ZSA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LmNoZWNrQWxsID0gZmFsc2U7XHJcblx0XHRcdFx0Ly9pZih4aHIuc3RhdHVzICE9IC0xKVxyXG5cdFx0XHRcdC8vTm90aWZpY2F0aW9uLmVycm9yKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2cgdGV4dC1jZW50ZXJcIj5FcnJvciB3aGlsZSB1cGRhdGluZyE8L2Rpdj4nKTtcclxuXHRcdFx0XHR4aHIuZXJyb3JUaXRsZSA9IGxhbmcuZ2V0KFwicmVhY3RpdmF0ZS1kZWFjdGl2ZS1lcnJvci1tc2dcIik7XHJcblx0XHRcdFx0YXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcclxuXHRcdFx0fSk7XHJcblxyXG5cclxuXHRcdH1cclxuXHRcdFxyXG5cdFx0dmFyIGZldGNoRGlzdERhdGEgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYoJHNjb3BlLnhoci5kaXN0ICYmICRzY29wZS54aHIuZGlzdC5hYm9ydCkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLnhoci5kaXN0ID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdHVybCA6IGFwaUNvbmZpZy5ET0NVTUVOVF9DT05UUk9MTEVSLFxyXG5cdFx0XHRcdGRhdGEgOiB7XHJcblx0XHRcdFx0XHRhY3Rpb25faWQgOiBhcGlDb25maWcuRE9DVU1FTlRfRElTVFJJQlVUSU9OX0RFTEVHQVRFX0FDVElPTl9MSVNULFxyXG5cdFx0XHRcdFx0cHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcblx0XHRcdFx0XHRkcklkOiBnZXRJZFN0cmluZygkc2NvcGUuZmlsdGVyTGlzdCkvL2dldElkU3RyaW5nKGdldEFjdGlvbnMoJ0luY29tcGxldGUnKSlcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLnhoci5kaXN0LnRoZW4oZnVuY3Rpb24ocmVzcCkge1xyXG5cdFx0XHRcdHZhciB0b3RhbFNlbGVjdGVkUmVjb3JkcyA9IGdldElkU3RyaW5nKCRzY29wZS5maWx0ZXJMaXN0KS5zcGxpdChcIixcIikubGVuZ3RoO1xyXG5cdFx0XHRcdCRzY29wZS54aHIuZGlzdCA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LmNoZWNrQWxsID0gZmFsc2U7XHJcblx0XHRcdFx0JHNjb3BlLmRlbGVnYXRlLmluY29tcGxldGVBY3Rpb25zID0gcmVzcDtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHR2YXIgdmFsaWRVc2VyTGlzdCA9IHJlc3AuZGF0YVswXSB8fCBbXTtcclxuXHRcdFx0XHRpZih2YWxpZFVzZXJMaXN0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0dmFyIGxpc3QgPSByZXNwLmRhdGFbMV0gfHwgW107XHJcblx0XHRcdFx0XHRpZihsaXN0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdFx0XHR2YXIgdSA9IGxpc3RbaV07XHJcblx0XHRcdFx0XHRcdFx0dS5lbWFpbElkID0gdS5lbWFpbDtcclxuXHRcdFx0XHRcdFx0XHR1LnVzZXJOYW1lID0gdS51c2VybmFtZTtcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fVx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdCRzY29wZS5kZWxlZ2F0ZS51c2VyTGlzdCA9IHsgdXNlckxpc3Q6IGxpc3QgfTtcclxuXHRcdFx0XHRcdCRzY29wZS5kZWxlZ2F0ZS52YWxpZFVzZXJzTGlzdCA9IHZhbGlkVXNlckxpc3Q7XHJcblx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdE5vdGlmaWNhdGlvbi53YXJuaW5nKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2dcIj5UYXNrKHMpIGRlbGVnYXRlZCBmb3IgMCAvICcgKyB0b3RhbFNlbGVjdGVkUmVjb3JkcyArICcgcmVjb3JkKHMpLjxicj4nXHJcblx0XHRcdFx0XHQgKyB0b3RhbFNlbGVjdGVkUmVjb3JkcyArICcgcmVjb3JkKHMpIHdlcmUgbm90IGRlbGVnYXRlZCBkdWUgdG8gb25lL2FsbCBvZiB0aGUgYmVsb3cgcmVhc29uczogPGJyPidcclxuXHRcdFx0XHRcdCArICcgYSkgWW91IGRvIG5vdCBoYXZlIHByaXZpbGVnZSB0byBkZWxlZ2F0ZSB0YXNrIG9uIHNlbGVjdGVkIHJlY29yZCA8YnI+J1xyXG5cdFx0XHRcdFx0ICsgJyBiKSBUYXNrIGZvciBzZWxlY3RlZCByZWNvcmQgd2FzIGFscmVhZHkgZGVsZWdhdGVkPC9kaXY+Jyk7XHJcblx0XHRcdFx0XHQkc2NvcGUuZGVsZWdhdGUudmFsaWRVc2Vyc0xpc3QgPSBbXVxyXG5cdFx0XHRcdFx0JHNjb3BlLmNhbmNlbERlbGVnYXRlKCk7XHJcblx0XHRcdFx0XHRkZXNlbGVjdEFsbEl0ZW1zKCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9LCBmdW5jdGlvbih4aHIpIHtcclxuXHRcdFx0XHRpZiAoeGhyLnN0YXR1cyAhPSAtMSlcclxuXHRcdFx0XHRcdCRzY29wZS54aHIuZGlzdCA9IHhocjtcclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHQkc2NvcGUueGhyLmRpc3QgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5jaGVja0FsbCA9IGZhbHNlO1xyXG5cdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJkaXN0cmlidXRpb24tZGF0YS1lcnJvci1tc2dcIik7XHJcblx0XHRcdFx0YXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHRjdHJsLnJlZnJlc2ggPSBmdW5jdGlvbihzaWxlbnQpIHtcclxuXHRcdFx0JHNjb3BlLmNhbmNlbERlbGVnYXRlKCk7XHJcblx0XHRcdGRlc2VsZWN0QWxsSXRlbXMoKTtcclxuXHRcdFx0cmVzZXRTb3J0aW5nRmllbGQoKTtcclxuXHRcdFx0ZmV0Y2goc2lsZW50KTtcclxuXHJcblx0XHRcdGlmKGN0cmwuZm9yQ3VzdG9tT2JqZWN0KSB7XHJcblx0XHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KFwiY3VzdG9tLW9iamVjdDp2aWV3OnJlZnJlc2hcIik7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRcclxuXHRcdGN0cmwuZXhwb3J0SCA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcblx0XHRcdHZhciBleHBvcnRPYmogPSB7XHJcblx0XHRcdFx0aGlzdG9yeVR5cGU6ICRzY29wZS5zZWFyY2guYWN0aW9uSWQgfHwgJy0xJyxcclxuXHRcdFx0XHRhY3Rpb25faWQ6IGFwaUNvbmZpZy5FWFBPUlRfRE9DVU1FTlRfSElTVE9SWSxcclxuXHRcdFx0XHRjb250cm9sbGVyOiBhcGlDb25maWcuRVhQT1JUX0NPTlRST0xMRVIsXHJcblx0XHRcdFx0bGlzdGluZ1R5cGU6IGFwaUNvbmZpZy5ET0NVTUVOVF9ISVNUT1JZX0VYUE9SVCxcclxuXHRcdFx0XHRwcm9qZWN0SWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRmb2xkZXJJZDogbXlDb25maWcuZm9sZGVySWQsXHJcblx0XHRcdFx0ZG9jVHlwZUlkOiBteUNvbmZpZy5kb2N1bWVudFR5cGVJZCxcclxuXHRcdFx0XHRyZXZpc2lvbklkOiByZXZTdHIsXHJcblx0XHRcdFx0bGF0ZXN0UmV2SWQ6IG15Q29uZmlnLnJldmlzaW9uSWRcclxuXHRcdFx0fTtcclxuXHRcdFx0XHJcblx0XHRcdGlmKG15Q29uZmlnLmFwcGxpY2F0aW9uSWQgPT0gMil7XHJcblx0XHRcdFx0d2luZG93LnF0T2JqZWN0ICYmIHdpbmRvdy5xdE9iamVjdC5zbG90X2V4cG9ydENsaWNrZWQoZXhwb3J0T2JqKTtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGFwaS5zdWJtaXRGb3JtKHtcclxuXHRcdFx0XHQgIHBhcmFtOiBleHBvcnRPYmosXHJcblx0XHRcdFx0ICB1cmw6IGV4cG9ydE9iai5jb250cm9sbGVyLFxyXG5cdFx0XHRcdCAgdGFyZ2V0Oidfc2VsZidcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHQkc2NvcGUuaGVhZGVyQ2VsbENsaWNrID0gZnVuY3Rpb24oJGV2ZW50LCBjb2x1bW4pIHtcclxuXHRcdFx0aWYoJHNjb3BlLm9yZGVyQnlGaWVsZCA9PSBjb2x1bW4pe1xyXG5cdFx0XHRcdCRzY29wZS5zb3J0T3JkZXIgPSAhJHNjb3BlLnNvcnRPcmRlcjtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQkc2NvcGUub3JkZXJCeUZpZWxkID0gY29sdW1uO1xyXG5cdFx0XHRcdCRzY29wZS5zb3J0T3JkZXIgPSBmYWxzZTtcclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0JHNjb3BlLnNvcnRpbmcgPSBmdW5jdGlvbihpdGVtKSB7XHJcblx0XHRcdHZhciBpdGVtVHlwZSA9ICRzY29wZS5vcmRlckJ5RmllbGQ7XHJcblx0XHRcdHZhciB2YWx1ZSA9IGl0ZW1baXRlbVR5cGVdIHx8IFwiXCI7XHJcblx0XHRcdHZhciBkYXRlID0gXCJcIjtcclxuXHRcdFx0c3dpdGNoKGl0ZW1UeXBlKSB7XHJcblx0XHRcdFx0Y2FzZSAnYWN0aW9uRGF0ZSc6XHJcblx0XHRcdFx0Y2FzZSAnYWN0aW9uX2R1ZV9ieV9kYXRlJzpcclxuXHRcdFx0XHRjYXNlICdhY3Rpb25fY29tcGxldGVfZGF0ZSc6XHJcblx0XHRcdFx0Y2FzZSAndmlld19kYXRlJzpcclxuXHRcdFx0XHRcdGlmKHZhbHVlKSB7XHJcblx0XHRcdFx0XHRcdHRyeSB7XHJcblx0XHRcdFx0XHRcdFx0dmFsdWUgPSB2YWx1ZS5zcGxpdChcIiNcIik7XHJcblx0XHRcdFx0XHRcdFx0ZGF0ZSA9IHZhbHVlWzFdO1xyXG5cdFx0XHRcdFx0XHRcdHZhbHVlID0gYXBpLnBhcnNlRGF0ZShteUNvbmZpZy51c2VyRGF0ZUZvcm1hdCwgdmFsdWVbMF0pO1xyXG5cdFx0XHRcdFx0XHRcdGlmKGRhdGUpIHtcclxuXHRcdFx0XHRcdFx0XHRcdGRhdGUgPSBkYXRlLnNwbGl0KCcgJylbMF0gfHwgXCJcIjtcclxuXHRcdFx0XHRcdFx0XHRcdGRhdGUgPSBkYXRlLnNwbGl0KCc6Jyk7XHJcblx0XHRcdFx0XHRcdFx0XHRpZihkYXRlLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRkYXRlWzBdICYmIHZhbHVlLnNldEhvdXJzKHBhcnNlSW50KGRhdGVbMF0pKTtcclxuXHRcdFx0XHRcdFx0XHRcdFx0ZGF0ZVsxXSAmJiB2YWx1ZS5zZXRNaW51dGVzKHBhcnNlSW50KGRhdGVbMV0pKTtcclxuXHRcdFx0XHRcdFx0XHRcdFx0ZGF0ZVsyXSAmJiB2YWx1ZS5zZXRTZWNvbmRzKHBhcnNlSW50KGRhdGVbMl0pKTtcclxuXHRcdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHZhbHVlLmdldFRpbWUoKTtcclxuXHRcdFx0XHRcdFx0fSBjYXRjaChlKSB7XHJcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHZhbHVlO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0XHRyZXR1cm4gdmFsdWU7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHRkZWZhdWx0OlxyXG5cdFx0XHRcdFx0cmV0dXJuIHZhbHVlO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHQkc2NvcGUudHlwZUNoYW5nZSA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHQkc2NvcGUuY2FuY2VsRGVsZWdhdGUoKTtcclxuXHRcdFx0ZGVzZWxlY3RBbGxJdGVtcygpO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0JHNjb3BlLnJldmlzaW9uQ2hhbmdlID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRzY29wZS5jYW5jZWxEZWxlZ2F0ZSgpO1xyXG5cdFx0XHRkZXNlbGVjdEFsbEl0ZW1zKCk7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHQkc2NvcGUuc2VsZWN0aW9uQ2hhbmdlID0gZnVuY3Rpb24oZSwgaWR4LCBpc0FsbCkge1xyXG5cdFx0XHRpZihpc0FsbCkge1xyXG5cdFx0XHRcdHNlbGVjdEFsbEl0ZW1zKCk7XHJcblx0XHRcdFx0bGFzdEluZGV4ID0gMDtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHR2YXIgaW5kZXggPSBpZHg7XHJcblx0XHRcdFx0aWYoIWUuc2hpZnRLZXkpIHtcclxuXHRcdFx0XHRcdGxhc3RJbmRleCA9IGluZGV4O1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRzZWxlY3RJdGVtc0luUmFuZ2UoaW5kZXgsIGxhc3RJbmRleCk7XHJcblx0XHRcdFx0fVx0XHRcdFx0XHJcblx0XHRcdFx0dXBkYXRlQ2hlY2tBbGwoKTtcclxuXHRcdFx0fVx0XHRcdFxyXG5cdFx0XHRzZXRTZWxlY3RlZEl0ZW1zKCk7XHJcblx0XHR9O1xyXG5cdFx0XHRcdFx0XHJcblx0XHRcclxuXHRcdC8qKiBIb2xkcyB0aGUgbGFzdCBjbGlja2VkIGl0ZW0gKi9cclxuXHRcdHZhciBsYXN0Q2xpY2tlZCA9IHVuZGVmaW5lZDtcclxuXHJcblx0XHQvKipcclxuXHRcdCAqIEludm9rZXMgb24gc2VsZWN0aW9uIG9iamVjdCBjbGlja1xyXG5cdFx0ICogT3BlbiB0aGUgcmVsYXRpdmUgZGV0YWlsIG9mIHNlbGVjdGVkIHR5cGUuXHJcblx0XHQgKiBHZXQgdXNlcnMgaW4gUm9sZSwgT3JnYW5pc2F0aW9uIGFuZCBEaXN0cmlidXRlIGdyb3VwIHR5cGUuXHJcblx0XHQgKiBAcGFyYW0geyp9IGFjdGlvblxyXG5cdFx0ICovXHJcblx0XHQkc2NvcGUuZ2V0RGlzdFR5cGVXaXNlVXNlckxpc3QgPSBmdW5jdGlvbihldnQsYWN0aW9uKXtcdFx0XHJcblx0XHRcdGFjdGlvbi5pc09wZW5Vc2VyTGlzdCA9ICFhY3Rpb24uaXNPcGVuVXNlckxpc3Q7XHRcclxuXHRcdFx0JGRvY3VtZW50Lm9mZignbW91c2Vkb3duLmRpc3RVc2VyTGlzdCcpO1x0XHJcblx0XHRcdGlmKGFjdGlvbi5pc09wZW5Vc2VyTGlzdCkge1x0XHRcdFx0XHJcblx0XHRcdFx0bGFzdENsaWNrZWQgPSBhY3Rpb247XHRcdFx0XHRcclxuXHRcdFx0XHQgIC8qKiBiaW5kIG91dHNpZGUgY2xpY2sgb2YgcG9wdXAgZGV0YWlsICovXHJcblx0XHRcdFx0JGRvY3VtZW50Lm9uKCdtb3VzZWRvd24uZGlzdFVzZXJMaXN0JywgZnVuY3Rpb24oZSkge1xyXG5cdFx0XHRcdFx0aWYoKGV2dC50YXJnZXQgIT0gZS50YXJnZXQgfHwgIWFuZ3VsYXIuZWxlbWVudChlLnRhcmdldCkuY2xvc2VzdCgnLmdEaXN0TGlzdCcpLmxlbmd0aCkgJiYgIWUudGFyZ2V0LmNsb3Nlc3QoJy5kaXN0LXR5cGUtdXNlcmxpc3QnKSkge1xyXG5cdFx0XHRcdFx0XHRpZihsYXN0Q2xpY2tlZCkge1xyXG5cdFx0XHRcdFx0XHRcdGxhc3RDbGlja2VkLmlzT3BlblVzZXJMaXN0ID0gZmFsc2U7XHJcblx0XHRcdFx0XHRcdFx0JHNjb3BlLmRpc3RUeXBlV2lzZVVzZXJMaXN0ID0gW107XHJcblx0XHRcdFx0XHRcdFx0JGRvY3VtZW50Lm9mZignbW91c2Vkb3duLmRpc3RVc2VyTGlzdCcpO1xyXG5cdFx0XHRcdFx0XHRcdHRyeSB7XHJcblx0XHRcdFx0XHRcdFx0XHQkc2NvcGUuJGRpZ2VzdCgpO1xyXG5cdFx0XHRcdFx0XHRcdH0gY2F0Y2goZSkge31cclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvLyAgVXNlcnMgdHlwZSBhcmUgbm90IGFsbG93IHRvIGdldCB1c2VycyBsaXN0LlxyXG5cdFx0XHRpZihhY3Rpb24uZGlzdHJpYnV0aW9uTGV2ZWwgPT0gYXBpQ29uZmlnLkRJU1RSSUJVVElPTl9MRVZFTC5VU0VSUyl7XHJcblx0XHRcdFx0YWN0aW9uLmlzT3BlblVzZXJMaXN0ID0gZmFsc2U7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvL2FqYXggY2FsbCBHRVRfRElTVF9XSVNFX1VTRVJfTElTVFxyXG5cdFx0XHQvL3Bhc3MgVHlwZSwgaWQgYW5kIHByb2plY3QgaWQgYW5kIHJldHVybiBsaXN0IG9mIHVzZXJzLlxyXG5cdFx0XHR2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdHVybDogYXBpQ29uZmlnLkdFVF9ESVNUX1dJU0VfVVNFUl9MSVNUICsgXCI/ZW50aXR5VHlwZT1cIiArICBhY3Rpb24uZGlzdHJpYnV0aW9uTGV2ZWwgKyBcIiZkaXN0cmlidXRpb25MZXZlbElkPVwiICsgYWN0aW9uLmRpc3RyaWJ1dGlvbkxldmVsSWQgKyBcIiZwcm9qZWN0SUQ9XCIgKyBteUNvbmZpZy5wcm9qZWN0SWQsIC8vL21hbmFnZUFkb2RkbGVPYmplY3RQcml2YWN5L2dldFVzZXJMaXN0Rm9yR2l2ZW5SZXNvdXJjZVxyXG5cdFx0XHRcdG1ldGhvZDogXCJHRVRcIlxyXG5cdFx0XHR9KTtcclxuXHRcdFx0XHJcblx0XHRcdHhoci50aGVuKGZ1bmN0aW9uKHJlc3BvbnNlKSB7XHJcblx0XHRcdFx0Zm9yKHZhciBpPTA7IGkgPCByZXNwb25zZS5sZW5ndGg7IGkrKyApe1xyXG5cdFx0XHRcdFx0cmVzcG9uc2VbaV0udXNlckltZyA9IGFwaUNvbmZpZy5JTUFHRV9QQVRIICsgcmVzcG9uc2VbaV0udXNlcklELnRvU3RyaW5nKCkuc3BsaXQoJyQkJylbMF07XHJcblx0XHRcdFx0XHRyZXNwb25zZVtpXS51c2VySW1nICs9ICcmdj0nICsgYXBpLmdldExhc3RNb2RpZmllZFByb2ZpbGVUaW1lKHJlc3BvbnNlW2ldLnVzZXJJbWFnZU5hbWUpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHQkc2NvcGUuZGlzdFR5cGVXaXNlVXNlckxpc3QgPSByZXNwb25zZTtcdFxyXG5cdFx0XHR9LCBmdW5jdGlvbih4aHIpIHtcclxuXHJcblx0XHRcdH0pO1x0XHRcdFx0XHRcdFxyXG5cdFx0fTtcclxuXHJcblx0XHQkc2NvcGUuZGlzYWJsZWRTdWJpdGVtID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdCRzY29wZS5hY3Rpb24uZGVhY3RpdmUgPSBmYWxzZTtcclxuXHRcdFx0JHNjb3BlLmFjdGlvbi5yZWFjdGl2ZSA9IGZhbHNlO1xyXG5cdFx0XHQkc2NvcGUuYWN0aW9uLmNsZWFyQWN0aW9uID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS5hY3Rpb24uZGVsYWdhdGVBY3Rpb24gPSBmYWxzZTtcclxuXHRcdFx0XHJcblx0XHRcdGlmKCEkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24gfHwgISRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbi5sZW5ndGgpIHtcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHQgICAgLy9EZWFjdGl2ZSBBY3Rpb25cclxuXHRcdCAgICB2YXIgZGVhY3RpdmVQYXJhbU9iaiA9IHtcclxuXHRcdCAgICBcdFwib3duT3JnXCI6IGFwaS5oYXNBY2Nlc3MoZm9ybVByb2plY3RQcml2LCAnQ0FOX0RFQUNUSVZBVEVfRE9DVU1FTlRfQUNUSU9OU19PV05fT1JHJyksIFxyXG5cdFx0ICAgIFx0XCJhbGxPcmdcIjogYXBpLmhhc0FjY2Vzcyhmb3JtUHJvamVjdFByaXYsICdDQU5fREVBQ1RJVkFURV9ET0NVTUVOVF9BQ1RJT05TX0FMTF9PUkcnKSwgXHJcblx0XHQgICAgXHRcInN0YXR1c1wiOiBcIkluYWN0aXZlXCIsIFxyXG5cdFx0ICAgIFx0XCJpbnZlcnRcIjogdHJ1ZVxyXG5cdFx0ICAgIH1cclxuXHRcdCAgICBpZihoYXNBY3Rpb25EZWFjdGl2ZVJlYWN0aXZlKGRlYWN0aXZlUGFyYW1PYmopKXtcclxuICAgICAgICAgICAgICAgICRzY29wZS5hY3Rpb24uZGVhY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgIC8vUmVhY3RpdmF0ZSBBY3Rpb25cclxuICAgICAgICAgICB2YXIgcmVhY3RpdmVQYXJhbU9iaiA9IHtcclxuICAgICAgICAgICBcdFx0XCJvd25PcmdcIjogYXBpLmhhc0FjY2Vzcyhmb3JtUHJvamVjdFByaXYsICdDQU5fUkVBQ1RJVkFURV9ET0NVTUVOVF9BQ1RJT05TX09XTl9PUkcnKSwgXHJcbiBcdFx0ICAgXHRcdFwiYWxsT3JnXCI6IGFwaS5oYXNBY2Nlc3MoZm9ybVByb2plY3RQcml2LCAnQ0FOX1JFQUNUSVZBVEVfRE9DVU1FTlRfQUNUSU9OU19BTExfT1JHJyksIFxyXG4gXHRcdCAgIFx0XHRcInN0YXR1c1wiOiBcIkluYWN0aXZlXCJcclxuIFx0XHQgICBcdH1cclxuIFx0XHQgICBpZihoYXNBY3Rpb25EZWFjdGl2ZVJlYWN0aXZlKHJlYWN0aXZlUGFyYW1PYmopKXtcclxuXHRcdCAgICAgICAgJHNjb3BlLmFjdGlvbi5yZWFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuXHRcdFx0XHJcblx0XHRcdC8vQ2xlYXIgQWN0aW9uXHJcblx0XHRcdHZhciBjbGVhclBhcmFtT2JqID0ge1xyXG5cdFx0XHRcdFwib3duT3JnXCIgOiBhcGkuaGFzQWNjZXNzKGZvcm1Qcm9qZWN0UHJpdiwgJ1BSSVZfQ0FOX0NMRUFSX0FDVElPTlNfT1dOJyksXHJcblx0XHRcdFx0XCJwcm9qT3JnXCI6IGFwaS5oYXNBY2Nlc3MoZm9ybVByb2plY3RQcml2LCAnUFJJVl9DQU5fQ0xFQVJfQUNUSU9OU19QUk9KRUNUJyksXHJcblx0XHRcdFx0XCJhbGxPcmdcIiA6IGFwaS5oYXNBY2Nlc3MoZm9ybVByb2plY3RQcml2LCAnUFJJVl9DQU5fQ0xFQVJfQUNUSU9OU19PUkcnKSxcclxuXHRcdFx0XHRcInN0YXR1c1wiOiBcIkluY29tcGxldGVcIlxyXG5cdFx0XHR9ICAgICAgICAgICAgXHJcblx0XHQgICAgaWYoaGFzQWN0aW9uKGNsZWFyUGFyYW1PYmopKSB7XHJcbiAgICAgICAgICAgICAgICAkc2NvcGUuYWN0aW9uLmNsZWFyQWN0aW9uID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgIC8vRGVsZWdhdGUgQWN0aW9uXHJcbiAgICAgICAgICAgICB2YXIgZGVsZWdhdGVQYXJhbU9iaiA9IHtcclxuXHRcdFx0XHRcIm93bk9yZ1wiIDogYXBpLmhhc0FjY2Vzcyhmb3JtUHJvamVjdFByaXYsICdQUklWX0NBTl9ERUxFR0FURV9BQ1RJT05TX09XTicpLFxyXG5cdFx0XHRcdFwicHJvak9yZ1wiOiBhcGkuaGFzQWNjZXNzKGZvcm1Qcm9qZWN0UHJpdiwgJ1BSSVZfQ0FOX0RFTEVHQVRFX0FDVElPTlNfUFJPSkVDVCcpLFxyXG5cdFx0XHRcdFwiYWxsT3JnXCIgOiBhcGkuaGFzQWNjZXNzKGZvcm1Qcm9qZWN0UHJpdiwgJ1BSSVZfQ0FOX0RFTEVHQVRFX0FDVElPTlNfT1JHJyksXHJcblx0XHRcdFx0XCJzdGF0dXNcIjogXCJJbmNvbXBsZXRlXCJcclxuXHRcdFx0fSAgICAgICAgICAgIFxyXG5cdFx0ICAgIGlmKGhhc0FjdGlvbihkZWxlZ2F0ZVBhcmFtT2JqKSkge1x0XHQgICAgXHRcclxuICAgICAgICAgICAgICAgICRzY29wZS5hY3Rpb24uZGVsYWdhdGVBY3Rpb24gPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5kZWFjdGl2ZUFjdGlvbiA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmFjdGlvbi5kZWFjdGl2ZSkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVx0XHRcdFxyXG5cclxuXHRcdFx0dmFyIHNlbGVjdGVkQ2hlY2tlZExpc3QgPSAkc2NvcGUuZmlsdGVyTGlzdC5maWx0ZXIoZnVuY3Rpb24oaXRlbSwgaW5kZXgsIGFycmF5KXsgICAgICAgICAgICBcclxuXHRcdFx0XHRyZXR1cm4gaXRlbS5jaGVja2VkXHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0cmVhY3RpdmVEZWFjdGl2ZUxpc3QoJ2RlYWN0aXZlJywgYXBpQ29uZmlnLkRFQUNUSVZBVEVfRklMRV9BQ1RJT05fTElTVCwgc2VsZWN0ZWRDaGVja2VkTGlzdCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5yZWFjdGl2ZUFjdGlvbiA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmFjdGlvbi5yZWFjdGl2ZSkge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVx0XHRcdFxyXG5cclxuXHRcdFx0dmFyIHNlbGVjdGVkQ2hlY2tlZExpc3QgPSAkc2NvcGUuZmlsdGVyTGlzdC5maWx0ZXIoZnVuY3Rpb24oaXRlbSwgaW5kZXgsIGFycmF5KXsgICAgICAgICAgICBcclxuXHRcdFx0XHRyZXR1cm4gaXRlbS5jaGVja2VkXHJcblx0XHRcdH0pO1xyXG5cclxuXHRcdFx0cmVhY3RpdmVEZWFjdGl2ZUxpc3QoJ3JlYWN0aXZlJywgYXBpQ29uZmlnLlJFQUNUSVZBVEVfRklMRV9BQ1RJT05fTElTVCwgc2VsZWN0ZWRDaGVja2VkTGlzdCk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5jbGVhckFjdGlvbiA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighJHNjb3BlLmFjdGlvbi5jbGVhckFjdGlvbikge1xyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHR2YXIgc2VsZWN0ZWRDaGVja2VkTGlzdCA9ICRzY29wZS5maWx0ZXJMaXN0LmZpbHRlcihmdW5jdGlvbihpdGVtLCBpbmRleCwgYXJyYXkpeyAgICAgICAgICAgIFxyXG5cdFx0XHRcdHJldHVybiBpdGVtLmNoZWNrZWRcclxuXHRcdFx0fSk7XHJcblxyXG5cdFx0XHR2YXIgcGFyYW1zT2JqPSB7XHJcblx0XHRcdFx0YWN0aW9uX2lkIDogYXBpQ29uZmlnLkRPQ1VNRU5UX0RJU1RSSUJVVElPTl9DTEVBUl9BQ1RJT05fTElTVCwgXHJcblx0XHRcdFx0ZHJJZCA6IGdldElkU3RyaW5nKCRzY29wZS5maWx0ZXJMaXN0KSwgXHJcblx0XHRcdFx0cHJvamVjdF9pZCA6IG15Q29uZmlnLnByb2plY3RJZFxyXG5cdFx0XHR9O1xyXG5cdFx0XHQkc2NvcGUueGhyLmNsZWFyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdHVybCAgOiBhcGlDb25maWcuRE9DVU1FTlRfQ09OVFJPTExFUixcclxuXHRcdFx0XHRkYXRhIDogcGFyYW1zT2JqXHJcblx0XHRcdH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLnhoci5jbGVhci50aGVuKGZ1bmN0aW9uKHJlc3BvbnNlKSB7XHJcblx0XHRcdFx0dmFyIHRvdGFsU2VsZWN0ZWRSZWNvcmRzID0gZ2V0SWRTdHJpbmcoJHNjb3BlLmZpbHRlckxpc3QpLnNwbGl0KFwiLFwiKS5sZW5ndGg7XHJcblx0XHRcdFx0aWYocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApe1xyXG5cdFx0XHRcdFx0dmFyIGRySWRzID0gZ2V0SWRTdHJpbmcoJHNjb3BlLmZpbHRlckxpc3QpO1xyXG5cdFx0XHRcdFx0dmFyIGRySWRzQXJyID0gZHJJZHMuc3BsaXQoXCIsXCIpIHx8IFtdO1xyXG5cdFx0XHRcdFx0dmFyIGRpc3RyaWJ1dGlvbkxpc3RJZHMgPSBbXSwgbGlzdEFjdGlvbkRhdGEgPSBbXSwgdmlzaWJpbGl0eURpc3RMaXN0SWQgPSBbXTtcclxuXHRcdFx0XHRcdGZvcihpID0gMDsgaSA8IHJlc3BvbnNlLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdFx0dmFyIHRoaXNSZXNPYmogPSByZXNwb25zZS5kYXRhW2ldO1xyXG5cdFx0XHRcdFx0XHR2YXIgdGhpc0lkID0gdGhpc1Jlc09iai5yZXZpc2lvbkRpc3RMaXN0SWQgKyBcInxcIiArIHRoaXNSZXNPYmoucmVjaXBpZW50X3VzZXJfaWQuc3BsaXQoJyQkJylbMF0gKyBcInxcIiArIHRoaXNSZXNPYmouYWN0aW9uSWRcclxuXHRcdFx0XHRcdFx0Zm9yKHZhciBqPTA7IGo8ZHJJZHNBcnIubGVuZ3RoOyBqKyspe1xyXG5cdFx0XHRcdFx0XHRcdGlmKHRoaXNJZCA9PSBkcklkc0FycltqXSl7XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0ZGlzdHJpYnV0aW9uTGlzdElkcy5wdXNoKGRySWRzQXJyW2pdKTtcclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0aWYodGhpc1Jlc09iai5hc2tGb3JSZW1vdmVWaXNpYmlsaXR5KXtcclxuXHRcdFx0XHRcdFx0XHR2aXNpYmlsaXR5RGlzdExpc3RJZC5wdXNoKHRoaXNSZXNPYmoucmV2aXNpb25EaXN0TGlzdElkKTtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR9XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRcdGlmKHZpc2liaWxpdHlEaXN0TGlzdElkLmxlbmd0aCl7XHJcblx0XHRcdFx0XHRcdHZhciB2aXNpYmlsaXR5RmlsdGVyZWRBcnJheSA9IHZpc2liaWxpdHlEaXN0TGlzdElkLmZpbHRlcihmdW5jdGlvbiAoaXRlbSwgcG9zKSB7XHJcblx0XHRcdFx0XHRcdFx0cmV0dXJuIHZpc2liaWxpdHlEaXN0TGlzdElkLmluZGV4T2YoaXRlbSkgPT0gcG9zO1xyXG5cdFx0XHRcdFx0XHR9KTtcclxuXHRcclxuXHRcdFx0XHRcdFx0bGlzdEFjdGlvbkRhdGEgPSBzZWxlY3RlZENoZWNrZWRMaXN0LmZpbHRlcihmdW5jdGlvbiAodmFsLCBpKSB7XHJcblx0XHRcdFx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCB2aXNpYmlsaXR5RmlsdGVyZWRBcnJheS5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0XHRcdFx0dmFyIGRpc3RMaXN0SWQgPSB2aXNpYmlsaXR5RmlsdGVyZWRBcnJheVtpXTtcclxuXHRcdFx0XHRcdFx0XHRcdGlmICh2YWwuZGlzdF9saXN0X2lkLnNwbGl0KFwiJCRcIilbMF0gPT0gZGlzdExpc3RJZC5zcGxpdChcIiQkXCIpWzBdKSB7XHJcblx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiB2YWw7XHJcblx0XHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0aWYoZGlzdHJpYnV0aW9uTGlzdElkcy5sZW5ndGgpe1xyXG5cdFx0XHRcdFx0XHQkc2NvcGUuY29uZmlybUNsZWFyQWN0aW9uKGRpc3RyaWJ1dGlvbkxpc3RJZHMuam9pbigpLCB0b3RhbFNlbGVjdGVkUmVjb3JkcywgbGlzdEFjdGlvbkRhdGEpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHQvL0RvZXMgbm90IGhhdmUgYW55IHBlcm1pc3Npb24uXHJcblx0XHRcdFx0XHQkc2NvcGUueGhyLmNsZWFyID0gZmFsc2U7XHJcblx0XHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5jaGVja0FsbCA9IGZhbHNlO1xyXG5cdFx0XHRcdFx0JHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uID0gW107XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24ud2FybmluZygnPGRpdiBjbGFzcz1cImJvbGQtbXNnXCI+VGFzayhzKSBjbGVhcmVkIGZvciAwIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocykuPGJyPidcclxuXHRcdFx0XHRcdCArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocykgd2VyZSBub3QgY2xlYXJlZCBkdWUgdG8gb25lL2FsbCBvZiB0aGUgcmVhc29ucyBtZW50aW9uZWQgYmVsb3c6IDxicj4nXHJcblx0XHRcdFx0XHQgKyAnIGEpIFlvdSBkbyBub3QgaGF2ZSBwcml2aWxlZ2UgdG8gY2xlYXIgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdCArICcgYikgVGFzayBmb3Igc2VsZWN0ZWQgcmVjb3JkIHdhcyBhbHJlYWR5IGNvbXBsZXRlZDwvZGl2PicpO1xyXG5cclxuXHRcdFx0XHR9XHRcdFx0XHRcclxuXHRcdFx0fSwgZnVuY3Rpb24oeGhyKSB7XHJcblx0XHRcdFx0JHNjb3BlLnhoci5jbGVhciA9IGZhbHNlO1xyXG5cdFx0XHRcdCRzY29wZS5oaXN0b3J5LmNoZWNrQWxsID0gZmFsc2U7XHJcblx0XHRcdFx0eGhyLmVycm9yVGl0bGUgPSBsYW5nLmdldChcImNsZWFyLWFjdGlvbi1lcnJvci1tc2dcIik7XHJcblx0XHRcdFx0YXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcdFx0XHRcdFxyXG5cdFx0XHR9KTtcdFx0XHRcclxuXHRcdH07XHJcblxyXG5cdFx0JHNjb3BlLmNvbmZpcm1DbGVhckFjdGlvbiA9IGZ1bmN0aW9uKGRpc3RyaWJ1dGlvbkxpc3RJZHMsIHRvdGFsU2VsZWN0ZWRSZWNvcmRzLCBsaXN0RGF0YSl7XHRcclxuXHRcdFx0aWYobGlzdERhdGEgJiYgbGlzdERhdGEubGVuZ3RoID4gMCl7XHJcblx0XHRcdFx0JHNjb3BlLmNvbmZpcm1PcGVuID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICRzY29wZS5hY3Rpb25QYXJhbSA9IHtcclxuICAgICAgICAgICAgICAgICAgXCJkaXN0cmlidXRpb25MaXN0SWRzXCI6IGRpc3RyaWJ1dGlvbkxpc3RJZHMsIFxyXG4gICAgICAgICAgICAgICAgICBcInRvdGFsU2VsZWN0ZWRSZWNvcmRzXCI6IHRvdGFsU2VsZWN0ZWRSZWNvcmRzLCBcclxuICAgICAgICAgICAgICAgICAgXCJsaXN0RGF0YVwiOiBsaXN0RGF0YVxyXG5cdFx0XHRcdH07XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0JHNjb3BlLmNvbnRpbnVlQ2xlYXJBY3Rpb24oZGlzdHJpYnV0aW9uTGlzdElkcywgdG90YWxTZWxlY3RlZFJlY29yZHMpXHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRcclxuXHRcdCRzY29wZS5jb250aW51ZUNsZWFyQWN0aW9uID0gZnVuY3Rpb24oZGlzdHJpYnV0aW9uTGlzdElkcywgdG90YWxTZWxlY3RlZFJlY29yZHMsIGxpc3REYXRhKXtcclxuXHRcdFx0XHJcblx0XHRcdHZhciBhY3Rpb25zID0gZ2V0QWN0aW9ucygnSW5jb21wbGV0ZScpO1xyXG5cdFx0XHR2YXIgZGlzdHJpYnV0aW9uTGlzdElkcyA9IGRpc3RyaWJ1dGlvbkxpc3RJZHM7XHJcblx0XHRcdHZhciBwYXJhbXMgPSB7XHJcblx0XHRcdFx0XCJhY3Rpb25faWRcIjogYXBpQ29uZmlnLkRPQ1VNRU5UX0RJU1RSSUJVVElPTl9DTEVBUl9BQ1RJT05fU1VCTUlULFxyXG5cdFx0XHRcdFwiVXNlclNlc3Npb25Qcm9maWxlLnByb3h5T3JnTmFtZVwiOiBhY3Rpb25zWzBdLnByb3h5VXNlck9yZyxcclxuXHRcdFx0XHRcIlVzZXJTZXNzaW9uUHJvZmlsZS5wcm94eVVzZXJOYW1lXCI6IGFjdGlvbnNbMF0ucHJveHlVc2VyTmFtZSxcclxuXHRcdFx0XHRcIlVzZXJTZXNzaW9uUHJvZmlsZS50cGRPcmdOYW1lXCI6IGFjdGlvbnNbMF0udXNlcl9vcmdfbmFtZSxcclxuXHRcdFx0XHRcIlVzZXJTZXNzaW9uUHJvZmlsZS50cGRVc2VyTmFtZVwiOiBhY3Rpb25zWzBdLnVzZXJfbmFtZSxcclxuXHRcdFx0XHRcImRvY1JldmlzaW9uSWRcIjogYWN0aW9uc1swXS5yZXZpc2lvbklkLFxyXG5cdFx0XHRcdFwiZHJSZXBvcnRJZFwiOiBnZXRJZFN0cmluZyhhY3Rpb25zLCB0cnVlKSxcclxuXHRcdFx0XHRcInByb2plY3RfaWRcIjogbXlDb25maWcucHJvamVjdElkLFxyXG5cdFx0XHRcdFwiZHJJZFwiOiBkaXN0cmlidXRpb25MaXN0SWRzLCAvL2dldElkU3RyaW5nKCRzY29wZS5maWx0ZXJMaXN0KSwgLy9nZXRJZFN0cmluZyhhY3Rpb25zKSxcclxuXHRcdFx0XHRcImlzRnJvbVJlbW92ZVVzZXJcIjogJ251bGwnLFxyXG5cdFx0XHRcdFwiaXNGb3JBbGxVc2Vyc1wiOiAnbnVsbCdcclxuXHRcdFx0fTtcdFx0XHRcclxuXHJcblx0XHRcdGlmIChsaXN0RGF0YSAmJiBsaXN0RGF0YS5sZW5ndGggPiAwKSB7XHJcblx0XHRcdFx0dmFyIHZpc2liaWxpdHlEYXRhID0gcmV0dXJuVmlzaWJpbGl0eURhdGEobGlzdERhdGEpO1xyXG5cdFx0XHRcdGlmICh2aXNpYmlsaXR5RGF0YS5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdHBhcmFtcy52aXNpYmlsaXR5Vk9MaXN0ID0gSlNPTi5zdHJpbmdpZnkodmlzaWJpbGl0eURhdGEpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0JHNjb3BlLnhoci5jbGVhciA9IGFwaS5hamF4KHtcclxuXHRcdFx0XHR1cmwgIDogYXBpQ29uZmlnLkRPQ1VNRU5UX0NPTlRST0xMRVIsXHJcblx0XHRcdFx0ZGF0YSA6IHBhcmFtc1xyXG5cdFx0XHR9KTtcclxuXHRcdFx0XHJcblx0XHRcdCRzY29wZS54aHIuY2xlYXIudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xyXG5cdFx0XHRcdHZhciB1cGRhdGVkUmVjb3Jkc0NudCA9IGRpc3RyaWJ1dGlvbkxpc3RJZHMuc3BsaXQoXCIsXCIpLmxlbmd0aDtcclxuXHRcdFx0XHQkc2NvcGUueGhyLmNsZWFyID0gZmFsc2U7XHJcblx0XHRcdFx0JHNjb3BlLmhpc3RvcnkuY2hlY2tBbGwgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24gPSBbXTtcclxuXHRcdFx0XHRmZXRjaCgpO1xyXG5cdFx0XHRcdCR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0dmFyIHVwZGF0ZURldGFpbCA9IHt9O1xyXG5cdFx0XHRcdFx0dXBkYXRlRGV0YWlsW2FwaUNvbmZpZy5lbnRpdHkuRklMRV0gPSBhY3Rpb25zWzBdLnJldmlzaW9uSWQ7XHJcblx0XHRcdFx0XHRhcGkuaW5mb3JtUGFyZW50V2luKHVwZGF0ZURldGFpbCk7XHJcblx0XHRcdFx0fSwgMjAwMCk7XHJcblx0XHRcdFx0aWYodXBkYXRlZFJlY29yZHNDbnQgPCB0b3RhbFNlbGVjdGVkUmVjb3Jkcyl7XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24ud2FybmluZygnPGRpdiBjbGFzcz1cImJvbGQtbXNnXCI+VGFzayhzKSBjbGVhcmVkIGZvciAnICsgdXBkYXRlZFJlY29yZHNDbnQgKyAnIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocykuPGJyPidcclxuXHRcdFx0XHRcdCArICh0b3RhbFNlbGVjdGVkUmVjb3JkcyAtIHVwZGF0ZWRSZWNvcmRzQ250KSArICcgcmVjb3JkKHMpIHdlcmUgbm90IGNsZWFyZWQgZHVlIHRvIG9uZS9hbGwgb2YgdGhlIGJlbG93IHJlYXNvbnM6IDxicj4nXHJcblx0XHRcdFx0XHQgKyAnIGEpIFlvdSBkbyBub3QgaGF2ZSBwcml2aWxlZ2UgdG8gY2xlYXIgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdCArICcgYikgVGFzayBmb3Igc2VsZWN0ZWQgcmVjb3JkIHdhcyBhbHJlYWR5IGNvbXBsZXRlZDwvZGl2PicpO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24uc3VjY2VzcygnPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+VGFzayhzKSBjbGVhcmVkIGZvciAnICsgdXBkYXRlZFJlY29yZHNDbnQgKyAnIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocyk8L2Rpdj4nKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sIGZ1bmN0aW9uKHhocikge1xyXG5cdFx0XHRcdCRzY29wZS54aHIuY2xlYXIgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5jaGVja0FsbCA9IGZhbHNlO1xyXG5cdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJjbGVhci1hY3Rpb24tZXJyb3ItbXNnXCIpO1xyXG5cdFx0XHRcdGFwaS5zaG93U2VydmVyRXJyTXNnKHhocik7XHJcblx0XHRcdH0pO1xyXG5cdFx0fTtcclxuXHJcblx0XHQvKipcclxuXHRcdCAqIEBkZXNjcmlwdGlvbiBJbiBjb25maXJtYXRpb24gYm94LiBDbGljayBvbiBZRVMgYnV0dG9uLiBcclxuXHRcdCAqIEBwYXJhbSB7Kn0gcGFybSBwYXNzIGRlYWN0aXZlIGFuZCBjbGVhciBhY3Rpb24uXHJcblx0XHQgKi9cclxuXHJcblx0XHQkc2NvcGUuY29udGludWVDb25maXJtTWVzc2FnZSA9IGZ1bmN0aW9uIChwYXJhbSkge1xyXG5cdFx0XHRpZiAocGFyYW0uYWN0aW9uID09IFwiZGVhY3RpdmVcIikge1xyXG5cdFx0XHRcdHJlYWN0aXZlRGVhY3RpdmUocGFyYW0uYWN0aW9uLCBwYXJhbS5hY3Rpb25JRCwgcGFyYW0uZmlsdGVyZWRBY3Rpb25EcklkcywgcGFyYW0uZmlsdHJEYXRhUmVzLCBwYXJhbS5zZWxlY3RlZEFjdGlvbnMsIHBhcmFtLmxpc3RBY3Rpb25EYXRhKTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQkc2NvcGUuY29udGludWVDbGVhckFjdGlvbihwYXJhbS5kaXN0cmlidXRpb25MaXN0SWRzLCBwYXJhbS50b3RhbFNlbGVjdGVkUmVjb3JkcywgcGFyYW0ubGlzdERhdGEpO1xyXG5cdFx0XHR9XHJcblx0XHRcdCRzY29wZS5jb25maXJtT3BlbiA9IGZhbHNlO1xyXG5cdFx0fTtcclxuXHJcblx0XHQvKipcclxuXHRcdCAqIEBkZXNjcmlwdGlvbiBJbiBjb25maXJtYXRpb24gYm94LiBDbGljayBvbiBOTyBidXR0b24uIFxyXG5cdFx0ICogQHBhcmFtIHsqfSBwYXJtIHBhc3MgZGVhY3RpdmUgYW5kIGNsZWFyIGFjdGlvbi5cclxuXHRcdCAqL1xyXG5cdFx0JHNjb3BlLmNsb3NlQ29uZmlybU1lc3NhZ2UgPSBmdW5jdGlvbiAocGFyYW0pIHtcclxuXHRcdFx0aWYgKHBhcmFtLmFjdGlvbiA9PSBcImRlYWN0aXZlXCIpIHtcclxuXHRcdFx0XHRyZWFjdGl2ZURlYWN0aXZlKHBhcmFtLmFjdGlvbiwgcGFyYW0uYWN0aW9uSUQsIHBhcmFtLmZpbHRlcmVkQWN0aW9uRHJJZHMsIHBhcmFtLmZpbHRyRGF0YVJlcywgcGFyYW0uc2VsZWN0ZWRBY3Rpb25zKTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHQkc2NvcGUuY29udGludWVDbGVhckFjdGlvbihwYXJhbS5kaXN0cmlidXRpb25MaXN0SWRzLCBwYXJhbS50b3RhbFNlbGVjdGVkUmVjb3Jkcyk7XHJcblx0XHRcdH1cclxuXHRcdFx0JHNjb3BlLmNvbmZpcm1PcGVuID0gZmFsc2U7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHQkc2NvcGUuYXBwbHlEYXRlVG9BbGwgPSBmdW5jdGlvbihidWxrKSB7XHJcblx0XHRcdGlmKCEkc2NvcGUuZmlsdGVyTGlzdCB8fCAhJHNjb3BlLmZpbHRlckxpc3QubGVuZ3RoKSB7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRmb3IoaSA9IDA7IGkgPCAkc2NvcGUuZmlsdGVyTGlzdC5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdCRzY29wZS5maWx0ZXJMaXN0W2ldLmR1ZWRhdGUgPSAkc2NvcGUuZGVsZWdhdGUuYnVsa2RhdGU7XHRcdFx0XHRcdFxyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5kZWxlZ2F0ZSA9IHtcclxuXHRcdFx0ZHVlVHlwZTogXCIwXCIsXHJcblx0XHRcdHVzZXJMaXN0OiBbXSxcclxuXHRcdFx0aW5jb21wbGV0ZUFjdGlvbnM6IHt9LFxyXG5cdFx0XHR1c2VyOiBbXSxcclxuXHRcdFx0YWN0aXZlOiBmYWxzZSxcclxuXHRcdFx0YnVsa2RhdGU6IFwiXCJcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdCRzY29wZS5kZWxlZ2F0ZUFjdGlvbiA9IGZ1bmN0aW9uKGRhdGEpIHtcclxuXHRcdFx0aWYoISRzY29wZS5hY3Rpb24uZGVsYWdhdGVBY3Rpb24pIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdCRzY29wZS5kZWxlZ2F0ZS5hY3RpdmUgPSB0cnVlO1xyXG5cdFx0XHRmZXRjaERpc3REYXRhKCk7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHQkc2NvcGUuY2FuY2VsRGVsZWdhdGUgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0JHNjb3BlLmRlbGVnYXRlLnVzZXJMaXN0ID0gW107XHJcblx0XHRcdCRzY29wZS5kZWxlZ2F0ZS5pbmNvbXBsZXRlQWN0aW9ucyA9IHt9O1xyXG5cdFx0XHQkc2NvcGUuZGVsZWdhdGUudXNlciA9IFtdO1xyXG5cdFx0XHQkc2NvcGUuZGVsZWdhdGUuYWN0aXZlID0gZmFsc2U7XHJcblx0XHRcdCRzY29wZS5kZWxlZ2F0ZS5idWxrZGF0ZSA9IFwiXCI7XHJcblx0XHRcdCRzY29wZS5kZWxlZ2F0ZS5kdWVUeXBlID0gXCIwXCI7XHJcblx0XHRcdGNsZWFyRHVlZGF0ZXMoKTtcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdCRzY29wZS5pc0RlbGVnYXRlVmFsaWQgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYoISRzY29wZS5kZWxlZ2F0ZS51c2VyIHx8ICEkc2NvcGUuZGVsZWdhdGUudXNlci5sZW5ndGgpIHtcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGlmKCEkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24gfHwgISRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbi5sZW5ndGgpIHtcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGZvcihpID0gMDsgaSA8ICRzY29wZS5oaXN0b3J5LnNlbGVjdGlvbi5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdHZhciBkYXRhID0gJHNjb3BlLmhpc3Rvcnkuc2VsZWN0aW9uW2ldO1xyXG5cdFx0XHRcdGlmKCRzY29wZS5kZWxlZ2F0ZS5kdWVUeXBlID09IDIgJiYgZGF0YS5hY3Rpb25fc3RhdHVzID09IFwiSW5jb21wbGV0ZVwiICYmICFkYXRhLmR1ZWRhdGUpIHtcclxuXHRcdFx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0JHNjb3BlLmNvbnRpbnVlRGVsZWdhdGUgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYoJHNjb3BlLnhoci5kaXN0IHx8ICRzY29wZS54aHIuZGVsZWdhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGlmKCEkc2NvcGUuaXNEZWxlZ2F0ZVZhbGlkKCkpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdHZhciB1c2VyID0gJHNjb3BlLmRlbGVnYXRlLnVzZXJbMF0uaXRlbTtcclxuXHRcdFx0dmFyIGFjdGlvbnMgPSBnZXRBY3Rpb25zKCdJbmNvbXBsZXRlJyk7XHJcblx0XHRcdHZhciB2YWxpZEFjdGlvbnMgPSBbXTtcclxuXHJcblx0XHRcdGZvcih2YXIgaSA9IDA7IGkgPCAkc2NvcGUuZGVsZWdhdGUudmFsaWRVc2Vyc0xpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHR2YXIgdXNlckxpc3QgPSAkc2NvcGUuZGVsZWdhdGUudmFsaWRVc2Vyc0xpc3RbaV07XHJcblx0XHRcdFx0Zm9yKHZhciBqID0gMDsgaiA8IGFjdGlvbnMubGVuZ3RoOyBqKyspe1xyXG5cdFx0XHRcdFx0dmFyIGluY29tcGxldGVBY3Rpb24gPSBhY3Rpb25zW2pdO1xyXG5cdFx0XHRcdFx0aWYoaW5jb21wbGV0ZUFjdGlvbi5kaXN0X2xpc3RfaWQuc3BsaXQoXCIkJFwiKVswXSA9PSB1c2VyTGlzdC5yZXZpc2lvbkRpc3RMaXN0SWQuc3BsaXQoXCIkJFwiKVswXVxyXG5cdFx0XHRcdFx0XHQmJiBpbmNvbXBsZXRlQWN0aW9uLmFjdGlvbl9pZCA9PSB1c2VyTGlzdC5hY3Rpb25JZFxyXG5cdFx0XHRcdFx0XHQmJiBpbmNvbXBsZXRlQWN0aW9uLnVzZXJfaWQgPT0gdXNlckxpc3QucmVjaXBpZW50X3VzZXJfaWQuc3BsaXQoXCIkJFwiKVswXSkge1xyXG5cdFx0XHRcdFx0XHRcdHZhbGlkQWN0aW9ucy5wdXNoKGluY29tcGxldGVBY3Rpb24pO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH1cdFx0XHJcblx0XHRcdH1cclxuXHRcdFx0dmFyIHBhcmFtID0ge1xyXG5cdFx0XHRcdGFjdGlvbl9pZDogYXBpQ29uZmlnLkRPQ1VNRU5UX0RJU1RSSUJVVElPTl9ERUxFR0FURV9BQ1RJT05fU1VCTUlULFxyXG5cdFx0XHRcdHByb2plY3RfaWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRkcklkOiBnZXRJZFN0cmluZyh2YWxpZEFjdGlvbnMpLFxyXG5cdFx0XHRcdGRyUmVwb3J0SWQ6IGdldElkU3RyaW5nKHZhbGlkQWN0aW9ucywgdHJ1ZSksXHJcblx0XHRcdFx0ZGlzdGxpc3Rjb3VudCA6ICRzY29wZS5kZWxlZ2F0ZS5pbmNvbXBsZXRlQWN0aW9ucy50b3RhbERvY3MgfHwgMCxcclxuXHRcdFx0XHRcIlVzZXJTZXNzaW9uUHJvZmlsZS5wcm94eU9yZ05hbWVcIjogdmFsaWRBY3Rpb25zWzBdLnByb3h5VXNlck9yZyxcclxuXHRcdFx0XHRcIlVzZXJTZXNzaW9uUHJvZmlsZS5wcm94eVVzZXJOYW1lXCI6IHZhbGlkQWN0aW9uc1swXS5wcm94eVVzZXJOYW1lLFxyXG5cdFx0XHRcdFwiVXNlclNlc3Npb25Qcm9maWxlLnRwZE9yZ05hbWVcIjogdmFsaWRBY3Rpb25zWzBdLnVzZXJfb3JnX25hbWUsXHJcblx0XHRcdFx0XCJVc2VyU2Vzc2lvblByb2ZpbGUudHBkVXNlck5hbWVcIjogdmFsaWRBY3Rpb25zWzBdLnVzZXJfbmFtZSxcclxuXHRcdFx0XHRhY3Rpb25EdWVEYXRlVHlwZTogJHNjb3BlLmRlbGVnYXRlLmR1ZVR5cGUsXHJcblx0XHRcdFx0c2VsZWN0ZWRfdXNlcl90eXBlOiB1c2VyLnVzZXJfdHlwZSxcclxuXHRcdFx0XHRzZWxlY3RlZF91c2VybmFtZTogdXNlci51c2VybmFtZSxcclxuXHRcdFx0XHR1c2VySWQ6IHVzZXIudXNlcklELFxyXG5cdFx0XHRcdHNlbGVjdGVkX29yZ25hbWU6IHVzZXIub3JnTmFtZSxcclxuXHRcdFx0XHRvcmdJZDogdXNlci5oYXNoZWRPcmdJRCxcclxuXHRcdFx0XHRpc0Zyb21SZW1vdmVVc2VyIDogJ251bGwnLFxyXG5cdFx0XHR9O1xyXG5cdFx0XHRcclxuXHRcdFx0dmFyIGluY29tcGxldGVBY3Rpb25zID0gJHNjb3BlLmRlbGVnYXRlLmluY29tcGxldGVBY3Rpb25zLmRhdGFbMF07XHJcblx0XHRcdGlmKGluY29tcGxldGVBY3Rpb25zICYmIGluY29tcGxldGVBY3Rpb25zLmxlbmd0aCkge1xyXG5cdFx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgaW5jb21wbGV0ZUFjdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdHZhciBpbmRleCA9IGkgKyAxO1xyXG5cdFx0XHRcdFx0dmFyIG9iaiA9IGluY29tcGxldGVBY3Rpb25zW2ldO1xyXG5cdFx0XHRcdFx0cGFyYW1bJ3JldmlzaW9uLWlkJyArIGluZGV4XSA9IG9iai5yZXZpc2lvbklkO1xyXG5cdFx0XHRcdFx0cGFyYW1bJ3JlY2lwaWVudC11c2VyLWlkJyArIGluZGV4XSA9IG9iai5yZWNpcGllbnRfdXNlcl9pZDtcclxuXHRcdFx0XHRcdHBhcmFtWydmb2xkZXItaWQnICsgaW5kZXhdID0gb2JqLmZvbGRlcl9pZDtcclxuXHRcdFx0XHRcdHBhcmFtWydyZXZpc2lvbi1kaXN0LWxpc3QtaWQnICsgaW5kZXhdID0gb2JqLnJldmlzaW9uRGlzdExpc3RJZDtcclxuXHRcdFx0XHRcdHBhcmFtWydkZWxlZ2F0ZWQnICsgaW5kZXhdID0gZmFsc2U7XHJcblx0XHRcdFx0XHRwYXJhbVsnYWN0aW9uLWlkJyArIGluZGV4XSA9IG9iai5hY3Rpb25JZDtcclxuXHRcdFx0XHRcdHBhcmFtWydhY3Rpb24tbmFtZScgKyBpbmRleF0gPSBvYmoucmVjaXBpZW50RnVsbEFjdGlvTmFtZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGlmKCRzY29wZS5kZWxlZ2F0ZS5kdWVUeXBlID09IDIpIHtcclxuXHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHZhbGlkQWN0aW9ucy5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0dmFyIGFjdGlvbiA9IHZhbGlkQWN0aW9uc1tpXTtcclxuXHRcdFx0XHRcdHBhcmFtWydOZXdBY3Rpb25EdWVEYXRlJyArIChpICsgMSldID0gYWN0aW9uLmR1ZWRhdGU7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHQkc2NvcGUuZGlzdFN0YXR1cyA9IHsgc3RhdHVzOiAnZGlzdHJpYnV0aW5nJyB9O1xyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLnhoci5kZWxlZ2F0ZSA9IGFwaS5hamF4KHtcclxuXHRcdFx0XHR1cmwgIDogYXBpQ29uZmlnLkRPQ1VNRU5UX0NPTlRST0xMRVIsXHJcblx0XHRcdFx0ZGF0YSA6IHBhcmFtXHJcblx0XHRcdH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLnhoci5kZWxlZ2F0ZS50aGVuKGZ1bmN0aW9uKHJlc3BvbnNlKSB7XHJcblx0XHRcdFx0dmFyIHRvdGFsU2VsZWN0ZWRSZWNvcmRzID0gIGdldEFjdGlvbnMoJ0luY29tcGxldGUnKS5sZW5ndGg7XHJcblx0XHRcdFx0JHNjb3BlLmRpc3RTdGF0dXMgPSB7IHN0YXR1czogJ2Rpc3RyaWJ1dGVkJyB9O1xyXG5cdFx0XHRcdCRzY29wZS54aHIuZGVsZWdhdGUgPSBmYWxzZTtcclxuXHRcdFx0XHQkc2NvcGUuaGlzdG9yeS5zZWxlY3Rpb24gPSBbXTtcclxuXHRcdFx0XHQkc2NvcGUuY2FuY2VsRGVsZWdhdGUoKTtcclxuXHRcdFx0XHRmZXRjaCgpO1xyXG5cdFx0XHRcdCR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0dmFyIHVwZGF0ZURldGFpbCA9IHt9O1xyXG5cdFx0XHRcdFx0dXBkYXRlRGV0YWlsW2FwaUNvbmZpZy5lbnRpdHkuRklMRV0gPSB2YWxpZEFjdGlvbnNbMF0ucmV2aXNpb25JZDtcclxuXHRcdFx0XHRcdGFwaS5pbmZvcm1QYXJlbnRXaW4odXBkYXRlRGV0YWlsKTtcclxuXHRcdFx0XHR9LCAyMDAwKTtcclxuXHRcdFx0XHRpZihyZXNwb25zZS5ub3REZWxlZ2F0ZWQgPiAwIHx8cmVzcG9uc2Uubm90RGVsZWdhdGVkRm9yU3RhdHVzQ2hhbmdlID4gMCApICB7XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24ud2FybmluZygnPGRpdiBjbGFzcz1cImJvbGQtbXNnXCI+VGFzayhzKSBkZWxlZ2F0ZWQgZm9yICcgKyByZXNwb25zZS5kZWxlZ2F0ZWQgKyAnIC8gJyArIHRvdGFsU2VsZWN0ZWRSZWNvcmRzICsgJyByZWNvcmQocykuPGJyPidcclxuXHRcdFx0XHRcdCsgKHJlc3BvbnNlLm5vdERlbGVnYXRlZCArIHJlc3BvbnNlLm5vdERlbGVnYXRlZEZvclN0YXR1c0NoYW5nZSkgKyAnIHJlY29yZChzKSB3ZXJlIG5vdCBkZWxlZ2F0ZWQgZHVlIHRvIG9uZS9hbGwgb2YgdGhlIHJlYXNvbnMgbWVudGlvbmVkIGJlbG93OiA8YnI+J1xyXG5cdFx0XHRcdFx0KyAnIGEpIFlvdSBkbyBub3QgaGF2ZSBwcml2aWxlZ2UgdG8gZGVsZWdhdGUgdGFzayBvbiBzZWxlY3RlZCByZWNvcmQgPGJyPidcclxuXHRcdFx0XHRcdCsgJyBiKSBSZWNpcGllbnQgdXNlciBkb2VzIG5vdCBoYXZlIHByaXZpbGVnZSB0byBiZSBhc3NpZ25lZCB0aGUgc2VsZWN0ZWQgdGFzazxicj4nXHJcblx0XHRcdFx0XHQrICcgYykgVGFzayhzKSBhcmUgZWl0aGVyIGNsZWFyZWQvZGVsZWdhdGVkIGZvciBzZWxlY3RlZCByZWNvcmRzIDwvZGl2PicpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRlbHNlIGlmKHZhbGlkQWN0aW9ucy5sZW5ndGggPCB0b3RhbFNlbGVjdGVkUmVjb3Jkcykge1xyXG5cdFx0XHRcdFx0Tm90aWZpY2F0aW9uLndhcm5pbmcoJzxkaXYgY2xhc3M9XCJib2xkLW1zZ1wiPlRhc2socykgZGVsZWdhdGVkIGZvciAnICsgdmFsaWRBY3Rpb25zLmxlbmd0aCArICcgLyAnICsgdG90YWxTZWxlY3RlZFJlY29yZHMgKyAnIHJlY29yZChzKS48YnI+J1xyXG5cdFx0XHRcdFx0ICsgKHRvdGFsU2VsZWN0ZWRSZWNvcmRzIC0gdmFsaWRBY3Rpb25zLmxlbmd0aCkgKyAnIHJlY29yZChzKSB3ZXJlIG5vdCBkZWxlZ2F0ZWQgZHVlIHRvIG9uZS9hbGwgb2YgdGhlIHJlYXNvbnMgbWVudGlvbmVkIGJlbG93OiA8YnI+J1xyXG5cdFx0XHRcdFx0ICsgJyBhKSBZb3UgZG8gbm90IGhhdmUgcHJpdmlsZWdlIHRvIGRlbGVnYXRlIHRhc2sgb24gc2VsZWN0ZWQgcmVjb3JkIDxicj4nXHJcblx0XHRcdFx0XHQgKyAnIGIpIFJlY2lwaWVudCB1c2VyIGRvZXMgbm90IGhhdmUgcHJpdmlsZWdlIHRvIGJlIGFzc2lnbmVkIHRoZSBzZWxlY3RlZCB0YXNrPGJyPidcclxuXHRcdFx0XHRcdCArICcgYykgVGFzayhzKSBhcmUgZWl0aGVyIGNsZWFyZWQvZGVsZWdhdGVkIGZvciBzZWxlY3RlZCByZWNvcmRzIDwvZGl2PicpO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24uc3VjY2VzcygnPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+JyArIHZhbGlkQWN0aW9ucy5sZW5ndGggKyAnICcgKyBsYW5nLmdldCgnZGVsZWdhdGVDb25maXJtTXNnJykgKyAnPC9kaXY+Jyk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9LCBmdW5jdGlvbih4aHIpIHtcclxuXHRcdFx0XHQkc2NvcGUueGhyLmRlbGVnYXRlID0gZmFsc2U7XHJcblx0XHRcdFx0JHNjb3BlLmRpc3RTdGF0dXMgPSB7IHN0YXR1czogJ0ZhaWxlZCcgfTtcclxuXHRcdFx0XHQvL05vdGlmaWNhdGlvbi5lcnJvcignPGRpdiBjbGFzcz1cImJvbGQtbXNnIHRleHQtY2VudGVyXCI+RXJyb3Igd2hpbGUgdXBkYXRpbmchPC9kaXY+Jyk7XHJcblx0XHRcdFx0eGhyLmVycm9yVGl0bGUgPSBsYW5nLmdldChcImRlbGVnYXRlLWFjdGlvbi1lcnJvci1tc2dcIik7XHJcblx0XHRcdFx0YXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5vcGVuUmV2aXNpb24gPSBmdW5jdGlvbihyZXZEYXRhKSB7XHJcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgJHNjb3BlLnJldkxpc3QubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRpZihyZXZEYXRhLnJldmlzaW9uSWQgPT0gJHNjb3BlLnJldkxpc3RbaV0ucmV2aXNpb25JZCkge1xyXG5cdFx0XHRcdFx0cmV2RGF0YSA9ICRzY29wZS5yZXZMaXN0W2ldO1xyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgZGF0YSA9IHtcclxuXHRcdCAgICAgICAgcHJvamVjdElkOiByZXZEYXRhLnByb2plY3RJZCxcclxuXHRcdCAgICAgICAgcmV2aXNpb25JZDogcmV2RGF0YS5yZXZpc2lvbklkLFxyXG5cdFx0ICAgICAgICBkb2N1bWVudElkOiByZXZEYXRhLmRvY3VtZW50SWQsIC8vXHJcblx0XHQgICAgICAgIGZvbGRlcklkOiByZXZEYXRhLmZvbGRlcklkLFxyXG5cdFx0ICAgICAgICBoYXNPbmxpbmVWaWV3ZXJTdXBwb3J0OiByZXZEYXRhLmhhc09ubGluZVZpZXdlclN1cHBvcnQsIC8vXHJcblx0XHQgICAgICAgIHRvT3BlbjogXCJGcm9tRmlsZVwiLFxyXG5cdFx0ICAgICAgICBkY0lkOiByZXZEYXRhLmRjSWQsIC8vXHJcblx0XHQgICAgICAgIGRvY3VtZW50VHlwZUlkOiByZXZEYXRhLmRvY3VtZW50VHlwZUlkLFxyXG5cdFx0ICAgICAgICB2aWV3ZXJJZDogcmV2RGF0YS52aWV3ZXJJZCwgLy9cclxuXHRcdCAgICAgICAgaXNGcm9tRmlsZVZpZXdGb3JEb21haW46IFwidHJ1ZVwiLFxyXG5cdFx0ICAgICAgICBpc0FjdGl2ZTogcmV2RGF0YS5pc0FjdGl2ZVxyXG5cdFx0ICAgIH07XHJcblx0XHRcdFxyXG5cdFx0XHRhcGkudmlld0ZpbGUoZGF0YSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5vcGVuQXR0YWNobWVudCA9IGZ1bmN0aW9uKGl0ZW0pIHtcdFxyXG5cdFx0XHR2YXIgaGFzT25saW5lVmlld2VyU3VwcG9ydCA9IGl0ZW0uaGFzT25saW5lVmlld2VyU3VwcG9ydEZvckF0dGFjaG1lbnQ7XHJcblx0XHRcdGlmKCFoYXNPbmxpbmVWaWV3ZXJTdXBwb3J0ICYmIG15Q29uZmlnLnZpZXdlclByZWZlcmVuY2UgPT0gJzcnKSB7XHJcblx0XHRcdFx0aXRlbS5oYXNPbmxpbmVWaWV3ZXJTdXBwb3J0Rm9yQXR0YWNobWVudCA9IGFwaS5pc1ppcChpdGVtLmZpbGVOYW1lKTtcclxuXHRcdFx0fVx0XHRcclxuXHRcdFx0aWYoIWl0ZW0uaGFzT25saW5lVmlld2VyU3VwcG9ydEZvckF0dGFjaG1lbnQpIHtcclxuXHRcdFx0XHRpZigkc2NvcGUuaGlzdG9yeS5jYW5Eb3dubG9hZEZpbGUpIHtcclxuXHRcdFx0XHRcdGFwaS5kb3dubG9hZEF0dGFjaG1lbnRGaWxlKGl0ZW0pO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHROb3RpZmljYXRpb24uZXJyb3IobGFuZy5nZXQoXCJkaXNhYmxlZC1lbmFibGVkLWRvd25sb2FkLWJ1dHRvblwiKSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHJldHVybjtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0YXBpLm9wZW5BdHRhY2htZW50KHtcclxuXHRcdFx0XHRwcm9qZWN0SWQ6IGl0ZW0ucHJvamVjdElkLFxyXG5cdFx0XHRcdGZpbGVOYW1lOiBpdGVtLmF0dGFjaEltZ05hbWUsXHJcblx0XHRcdFx0cmV2aXNpb25JZDogaXRlbS5yZXZpc2lvbklkLFxyXG5cdFx0XHRcdGNvbW1pbmdGcm9tOiAnRmlsZScsXHJcblx0XHRcdFx0aXNGcm9tRmlsZVZpZXdGb3JEb21haW46IHRydWUsXHJcblx0XHRcdFx0Y29tbWluZ0Zyb206IFwiaW50ZXJuYWxBdHRhY2htZW50XCIsXHJcblx0XHRcdFx0YXR0YWNobWVudElkOiBpdGVtLmF0dGFjaG1lbnRJZCxcclxuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJ1xyXG5cdFx0XHR9LCBpdGVtLmRjSWQpO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0JHNjb3BlLm9wZW5SZXZpZXcgPSBmdW5jdGlvbihpdGVtKSB7XHJcblx0XHRcdGFwaS5vcGVuUmV2aWV3KGl0ZW0pO1xyXG5cdFx0fVxyXG5cdFx0XHJcblx0XHQkc2NvcGUuZWRpdFNoYXJlTGluayA9IGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdFx0aXRlbS5pc0VkaXQgPSB0cnVlO1xyXG5cdFx0XHRpdGVtLmRvY3VtZW50Rm9sZGVyUGF0aCA9IGl0ZW0uZG9jdW1lbnRGb2xkZXJQYXRoIHx8IG15Q29uZmlnLmRvY3VtZW50Rm9sZGVyUGF0aDtcclxuXHRcdFx0aXRlbS5kb2N1bWVudEZvbGRlclBhdGggPSBkZWNvZGVVUkkoaXRlbS5kb2N1bWVudEZvbGRlclBhdGgpLnJlcGxhY2UoL1xcKy9nLCAnICcpO1xyXG5cdFx0XHRpdGVtLnVwbG9hZEZpbGVuYW1lID0gaXRlbS51cGxvYWRGaWxlbmFtZSB8fCBpdGVtLmZpbGVOYW1lIHx8IG15Q29uZmlnLmZpbGVOYW1lO1xyXG5cdFx0XHRpdGVtLmRvY3VtZW50SWQgPSBpdGVtLmRvY3VtZW50SWQgfHwgbXlDb25maWcuZG9jdW1lbnRJZDtcclxuXHRcdFx0aXRlbS5kY0lkID0gaXRlbS5kY0lkIHx8IG15Q29uZmlnLmRjSWQ7XHJcblx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdCgnZGQ6Y2xvc2UnLCB7IG5hbWU6ICdoaXN0b3J5JywgZm9yY2U6IHRydWV9KTtcclxuXHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KCdkZDpvcGVuJywgeyBuYW1lOiAnc2hhcmUtbGluaycsIGRhdGE6IGl0ZW19KTtcclxuXHRcdH07XHJcblx0fV0sXHJcblx0YmluZGluZ3M6IHtcclxuXHRcdHBhcmVudEV4cGFuZGVkOiAnPScsXHJcblx0XHRmb3JDdXN0b21PYmplY3Q6ICc9JyxcclxuXHRcdGN1c3RvbU9iamVjdFBhcmFtOiAnPCdcclxuXHR9XHJcbn0pO1xyXG4iXX0=
