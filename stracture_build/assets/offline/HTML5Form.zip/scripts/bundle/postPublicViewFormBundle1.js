angular.module("adoddle")
    .config(['$compileProvider', '$sceDelegateProvider', '$qProvider', 'NotificationProvider',
        function($compileProvider, $sceDelegateProvider, $qProvider, NotificationProvider) {
            // remove looking for css and comment directives
            $compileProvider.commentDirectivesEnabled(false);
            $compileProvider.cssClassDirectivesEnabled(false);

            $sceDelegateProvider.resourceUrlWhitelist([
                // Allow same origin resource loads.
                'self',
                // Allow loading from our assets domain.  Notice the difference between * and **.
                'https://*.asite.com/**',
                'http://*.asite.asitehq.com/**',
                'https://iotsb.asite.com/**',
                'https://iot.asite.com/**'
            ]);

            //configure the error handling behavior
            //set to false by default to prevent unwanted errors on ajax fail
            $qProvider.errorOnUnhandledRejections(false);

            // default notification settings
            NotificationProvider.setOptions({
                delay: 5000,
                startTop: 20,
                startRight: 10,
                verticalSpacing: 20,
                horizontalSpacing: 20,
                positionX: 'center',
                positionY: 'top'
            });
        }
    ])

.value('globalVar', {
    retainNoOfShow: 10
})

/**
 * language service.
 * This module will provide internationalization.
 * @module api
 */
.service('lang', ['$window', function($window) {
    this.get = function() {
        return $window.Language.get.apply($window.Language, arguments);
    };

    this.getLangObj = function() {
        return $window.Language.getLangObj();
    };
}])


/**
 * apiConfig constants.
 * This constants represents the ajax controllers, jsp urls, action ids, privileges, etc...
 * @module formApp
 */
.constant('apiConfig', {
    // controllers
    LANGUAGE_CONTROLLER: '/adoddle/language',
    DASHBOARD_CONTROLLER: '/adoddle/dashboard',
    HOME_CONTROLLER: '/adoddle/home',
    LISTING_CONTROLLER: '/adoddle/listing',
    COMMUNICATIONS_CONTROLLER: '/adoddle/communications',
    PUBLIC_VIEW_FORM: '/adoddlepublic/publicViewForm',
    DOCUMENT_CONTROLLER: '/adoddle/files',
    PROJECTS_CONTROLLER: '/adoddle/projects',
    ACTIONS_CONTROLLER: '/adoddle/actions',
    APPS_CONTROLLER: '/adoddle/apps',
    DOWNLOAD_CONTROLLER: '/adoddle/download',
    PUBLIC_DOWNLOAD_CONTROLLER: '/adoddlepublic/publicDownload',
    GET_FIELD_ENABLE_PROJECT: '/adoddlenavigatorapi/workspace/fieldEnabledSelectedProjects',
    DISTRIBUTION_CONTROLLER: '/adoddle/dist',
    UPLOAD_CONTROLLER: '/adoddle/upload',
    ADODDLE_UPLOAD_CONTROLLER: '/adoddle/adoddleUpload',
    PROCUREMENT_CONTROLLER: '/adoddle/procurement',
    MODELS_CONTROLLER: '/adoddle/models',
    HOOPS_MARKUP_CONTROLLER: '/adoddle/hoopsmarkup',
    HOOPS_CONTROLLER: '/adoddle/hoops',
    FEDERATED_MODELS_CONTROLLER: '/adoddle/objectManagerController',
    EXPORT_CONTROLLER: '/adoddle/export',
    ASITE_POPUP_CONTROLLER: '/adoddle/getPopupData',
    SEARCH_FILTER_CONTROLLER: '/adoddle/filter',
    BATCH_CONTROLLER: "/adoddle/batch",
    CREATE_COMMENT_CONTROLLER: '/adoddle/CreateComment',
    MODELS_COMMENTS_CONTROLLER: "/adoddle/ModelComment",
    SAVE_COMMENT_CONTROLLER: "/adoddle/SaveComment",
    SAVE_BATCH_COMMENT_CONTROLLER: "/adoddle/SaveBatchComment",
    SHARE_LINK_CONTROLLER: "/adoddle/sharelink",
    GET_USER_SHARE_PERMISSION: 'sharelink/getUserPermission',
    CONTACT_CONTROLLER: "/adoddle/contacts",
    DOWNLOAD_DOCUMENT_FROM_FORM: "/adoddle/downloadDocAssociations",
    DOWNLOAD_DOCUMENT_FROM_PUBLIC_FORM: "/adoddlepublic/publicDownload",
    USER_PREFERENCES_CONTROLLER: '/adoddle/preferences',
    PUBLISH_PDF_CONTROLLER: '/adoddle/PublishPdf',
    WOM_DIAGRAM_CONTROLLER: '/adoddle/wom/diagram-viewer',
    WOM_WORKFLOWS_CONTROLLER: '/adoddle/wom/workflow',

    // commonapi
    GET_CUSTOM_OBJECT_TEMPLATE_LIST: '/commonapi/adoddleCustomObject/getCustomObjectTemplateList',
    GET_CUSTOM_OBJECT_COMMENT_LIST: '/commonapi/adoddleCustomObject/getCustomObjectCommentList',
    CREATE_CUSTOM_OBJECT_COMMENT: '/commonapi/adoddleCustomObject/createCustomObjectComment',
    SAVE_CUSTOM_OBJECT_MODEL_VIEW: '/commonapi/adoddleCustomObject/saveCustomObjectView',
    SAVE_CUSTOM_OBJECT_COMMENT: '/commonapi/adoddleCustomObject/saveCustomObjectComment',
    UPDATE_CUSTOM_OBJECT_COMMENT_ACTION: '/commonapi/adoddleCustomObject/updateCustomObjectCommentAction',
    GET_CUSTOM_OBJECT_AUDIT_TRAIL_DETAIL_LIST: '/commonapi/adoddleCustomObject/getCustomObjectAuditTrailDetailList',
    GET_REVIEWS_FOR_COORDINATION_ACTION: '/commonapi/adoddleCustomObject/getReviewsForCoordinationAction',
    SAVE_CUSTOM_OBJECT_REVIEW_COORDINATION: '/commonapi/adoddleCustomObject/saveCustomObjectReviewCoordination',
    EXPORT_BCF_ISSUE: '/commonapi/issue/exportIssueBCF',
    PREPARE_EXPORT_BCF_ISSUE: '/commonapi/issue/prepareExportIssueBCF',
    LANGUAGE_CONTROLLER_KEY_VALUE: '/commonapi/language/getLanguageKeyValues',
    GET_LOCATION_TREE: '/commonapi/pflocationservice/getLocationTree',
    GET_XOD_FILE: '/commonapi/webviewerservice/downloadXOD',
    MARKUPS_LISTING_CONTROLLER: "/commonapi/markups/listing",
    SEARCH_RESOURCE_LIST: "/commonapi/share/getResources",
    FILL_SHARE_FILTER_RESOURCE_LIST: "/commonapi/share/getResourcesById",
    GET_WORKSPACE_SETTING: '/commonapi/workspace/getWorkspaceSetting',
    VIEW_MARKUP: '/commonapi/webviewerservice/viewMarkup',
    CHECK_USER_LATEST_REVISION_API: '/commonapi/document/checkUserLatestRevision',
    MARKUP_LIST: '/commonapi/markups/listing',
    GET_WORKSPACE_SETTING_MARKUP: '/commonapi/markups/getworkspacesetting',
    GET_MARKUPID_BYNAME: '/commonapi/markups/getMarkupIdByName',
    PRE_UPLOAD_VALIDATION_API_URL: '/commonapi/event/uploadEventValidation',
    GET_FILE_ATTRIBUTES_API: '/commonapi/document/getFileAttributes',
    UPDATE_FILE_ATTRIBUTES_API: '/commonapi/document/updateFileAttributes',
    ACTIVATE_USER_SESSION: '/commonapi/login/activateUserSession',
    GET_SESSION_TIMEOUT_DETAILS: '/commonapi/login/getSessionTimeoutDetails',
    MEDIA_COMPLETE_ACTION: 'commonapi/media/completeAction',
    GET_DIST_WISE_USER_LIST: 'commonapi/manageAdoddleObjectPrivacy/getUserListForGivenResource',
    GET_LOCATION_DETAILS_BY_LOCATION: 'commonapi/pflocationservice/getLocationDetailsByLocationIds',
    GET_OBSERVATION_LIST_BY_PLAN: 'commonapi/pfobservationservice/getObservationListByPlan',
	GET_ACTIVITY_LOCK_IDS: "/commonapi/lock/getObjectActivityLockedIds",
    GET_PROJECT_APPDETAIL_BY_FORM_TYPE_NAME: "/commonapi/form/getProjectAppTypeDetailsByFormTypeName",    
    THUMBNAIL_VIEW_TEMP_PATH: "/commonapi/thumbnail/viewTempThumb",
    THUMBNAIL_VIEW_PATH: "/commonapi/thumbnail/viewThumb",
    HELP_FILE_CONTENT: '/contexthelper/',
    VIEW_ELEARNING: "/adoddle/view/externalapp/elearning.jsp",
    HELP_FILE_FREEMIUM_CONTENT: "/Freemium_contexthelper/",
    GET_EXTRACTED_ZIP_FILE: '/commonapi/webviewerservice/getFilesWithInCompressedFile',
    SAVE_CUSTOM_OBJECT : '/commonapi/adoddleCustomObject/saveCustomObject',
    UPDATE_CUSTOM_OBJECT : '/commonapi/adoddleCustomObject/updateCustomObject',
    GET_CUSTOM_OBJECT_TEMPLATE : '/commonapi/adoddleCustomObject/getCustomObjectTemplate',
    SAVE_CUSTOM_OBJECT_COMMENT: '/commonapi/adoddleCustomObject/saveCustomObjectComment',
    
    //For PDFTron calibration data
    CALIBRATION_2D_3D_API : '/commonapi/2d3dcalibration',

    // Download
    IS_DOCUMENT_DOWNLOAD_RESTRICTED: '/download/document/isDownloadRestricted',
    DOWNLOAD_SINGLE_DOCUMENT: '/download/document/single',
    CAN_DOWNLOAD_FOLDER_LEVEL: '/download/folder/canDownloadFolderLevel',
    DOWNLOAD_BATCH_DOCUMENT_CONTROLLER: '/download/document/batch',
    DOWNLOAD_BATCH_DOCUMENT_PAGE_CONTROLLER: '/download/document/downloadBatchDocumentPage',
    CHECK_DOCUMENT_DOWNLOAD_LIMIT: '/download/document/checkDownloadLimit',
    PROGRESS_ZIP_CREATION_CONTROLLER: '/download/document/getZipProgress',
    DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER: '/download/document/batchWithMarkup',
    PROGRESS_GENERATE_MARKUP_AS_PDF_CONTROLLER: '/download/document/markupPDFprogress',
    DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER: '/download/document/downloadTempZipFile',
    ASYNC_NOTIFICATION: '/commonapi/document/aSyncNotification', // send notification to aSync app
    REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK_CONTROLLER: '/download/document/checkValidForCheckOutOnRightClick',
    CHECKOUT_REVISION_CONTROLLER: '/download/checkout/checkoutRevision',
    GET_CHECKOUT_REVISION_DETAILS_CONTROLLER: '/download/checkout/getCheckoutRevisionDetails',
    CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT_CONTROLLER: '/download/document/checkAvailabilityOfDownloadDocument',
	DOWNLOAD_INTERNAL_ATTACHMENT_CONTROLLER: '/download/document/internalAttachment',
    DOWNLOAD_EXTRACTED_ZIP_FILE: '/download/document/extractedFile',
    MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER: '/download/document/multiDCBatch',
    UNDO_CHECKOUT_CONTROLLER: '/download/checkout/undoCheckout',
    DOWNLOAD_CUSTOM_FORM_ATTACHMENT: '/download/document/downloadCustomFormAttachment',
    DOWNLOAD_FORM_ASSOCIATION_BYPASS_SECURITY: '/download/document/downloadFormAssociationByPassSecurity',

    // jsp
    FILE_VIEW_MOBILE: "/adoddle/viewer/fileView.jsp",
    VIEW_FORM: "/adoddle/view/communications/viewForm.jsp",
    PRINT_VIEW_FORM: "/adoddle/view/communications/apps/printViewForm.jsp",
    BATCH_PRINT_FORM_PAGE: "/adoddle/view/communications/apps/batchPrintForm.jsp",
    FILE_VIEW_PAGE: "/adoddle/viewer/fileView.jsp",
    ATTACH_FILE_VIEWER_PREFERENCE: "/adoddle/viewer/attachFileopenViewerpreference.jsp",
    UPLOAD_REDIRECT_RESULT: "/adoddle/result.jsp",
    VIEW_MODEL_FOR_WEB: '/adoddle/viewer/modelView.jsp',
    CONIGURABLE_COLUMN_CONTROLLER: '/adoddle/configcontroller',
    ATTACH_FILE_VIEWER_PREFERENCE: '/adoddle/viewer/attachFileopenViewerpreference.jsp',
    HTML_COMPARE_DOC: '/adoddle/viewer/compareDocsHTMLViewer.jsp',
    ACTIVEX_COMPARE_DOC: '/adoddle/viewer/compare.jsp',
    VIEWER_PARENT_REFRESH: '/adoddle/viewer/viewerRefreshParent.jsp',
    START_STOP_WATCHER: '/commonapi/watch',
    UPDATE_DASHBOARD_NOTIFICATION: '/commonapi/watch/updaeDashboardNotificationsStatus',
    GET_DASHBOARD_NOTIFICATION: '/commonapi/watch/getDashboardNotifications',
    NOTICE_COMMONAPI_ALLNOTICE: '/commonapi/notice/activeNotice',
    NOTICE_COMMONAPI_DISMISS: '/commonapi/notice/dismiss',
    IMAGE_PATH: '/commonapi/user/userImg?userId=',
    WATCH_CHECK_PERMISSION: 'commonapi/watch/checkPermission',
    LOCAL_STORAGE: '/adoddle/view/common/localStorage.jsp',
    GET_EXTERNAL_OBJECT_MAPPING: '/commonapi/model/getModelObjectExternalMapping',
    GET_DATA_INSIGHT_DASHBOARD_URL:'/commonapi/model/getModelDataInsightDashboardURLMapping',

    // action ids
    GET_DIST_GROUP_USERS: 840,
    LIST_WORKFLOWS: 1,
    ADODDLE_FOLDER_TREE: 2,
    WORKFLOW_PROGRESS: 4,
    ADODDLE_WORKSPACE_TREE: 5,
    ADODDLE_DISTRIBUTE_FILES: 10,
    DISTRIBUTE_FORM: 11,
    ADODDLE_WORKSPACE_AND_FOLDER_TREE_LEVEL: 14,
    ADODDLE_APP_TYPE_WORKSPACE_TREE: 16,
    ADODDLE_APP_TYPE_FORM_TREE: 17,
    COMMIT_DISTRIBUTION: 19,
    COMPLETE_FOR_ACKNOWLEDGEMENT_ACTION: 20,
    COMPLETE_FOR_ACTION: 21,
    FORM_DIST_VALIDATION: 26,
    PREVIOUSLY_FORM_DIST_USER_LIST: 27,
    ADODDLE_LISTING_ACTION: 100,
    SAVE_CONFIGURABLE_COLUMN_ACTION: 102,
    DOWNLOAD_SINGLE_DOCUMENT_ACTION: 103,
    DOWNLOAD_INTERNAL_ATTACHMENT: 197,
    GET_LIST_FOR_DISTRIBUTION: 107,
    VIEW_FORM_ACTION: 114,
    VIEW_FORM_MSG_DETAILS_ACTION: 115,
    GET_FILE_ATTRIBUTES_SET: 117,
    DISPLAY_APP_TEMPLATES_LIST: 118,
    DOWNLOAD_BATCH_DOCUMENT_PAGE: 119,
    DOWNLOAD_BATCH_DOCUMENT_ACTION: 120,
    GET_FILE_PREV_REVISION_DETAILS: 122,
    UPDATE_COMMENT_ACTION: 124,
    DOWNLOAD_TEMP_ZIP_FILE: 125,
    PROGRESS_ZIP_CREATION: 126,
    DISPLAY_PRINT_VIEW_FORM: 132,
    GET_FILE_NAME_FOR_REVISION: 136,
    GET_UPLOAD_SETTING: 137,
    UPLOAD_FILE_VALIDATION: 138,
    UPLOAD_FILE_RULES_VALIDATION: 139,
    FILE_DIST_VALIDATION: 140,
    VIEW_FILE_DISCUSSIONS: 148,
    VIEW_FILE_HISTORY: 149,
    VIEW_FORM_HISTORY: 150,
    GET_SELECTED_REV_ATTRIBUTE_VO: 162,
    ADODDLE_FORM_PERMISSIONS: 167,
    MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION: 168,
    MOVE_FILES_TO_TEMP_LOCATION: 172,
    CHECK_REV_RESTRICT_FOR_DOWNLOAD: 175,
    UPDATE_AUDIT_TRAIL_FORM_ATTACHMENT: 179,
    GET_FOLDER_PERMISSION_VALUE: 818,
    APPLET_UPLOAD_PAGE: 176,
    UPDATE_MSG_STATUS: 181,
    COPY_DISTRIBUTION_FROM_PREVIOUS_DISTRIBUTION: 182,
    COMMIT_UPLOAD_FILES_DETAIL: 184,
    DISPLAY_PRINT_VIEW_FORM_ALL: 185,
    GET_PUBLISHED_DOCS_FOR_PALCEHOLDER: 192,
    VIEW_FILE_ATTACHMENT_ASSOCIATION: 192,
    CHECK_FOR_AKAMAI_DOWNLOAD_LIMIT: 193,
    CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT: 198,
    GET_USER_APPLICATION_PRIVILEGES: 207,
    GET_USER_APPLICATION_PRIVILEGES_MULTI: 1342,
    GET_FORM_TYPE_PRIVILEGES: 210,
    DOCUMENT_COMPLETE_FOR_INFORMATION: 226,
    DEACTIVATE_FORM_ACTION_LIST: 316,
    DEACTIVATE_FORM_ACTION: 317,
    REACTIVATE_FORM_ACTION_LIST: 318,
    REACTIVATE_FORM_ACTION: 319,
    PROCUREMENT_GET_SKN_VALIDATION_CALL_OFF: 426,
    STATUS_CHANGE_ACTION: 501,
    STATUS_CHANGE_SINGLE_SUBMIT: 502,
    DISPLAY_FORM_CHANGE_STATUS: 571,
    SUBMIT_FORM_CHANGE_STATUS: 572,
    FORM_DISTRIBUTION_CLEAR_ACTION_LIST: 573,
    FORM_DIST_CLEAR_ACTION_SUBMIT: 574,
    FORM_DIST_DELEGATE_ACTION_LIST: 575,
    FORM_DIST_DELEGATE_ACTION_SUBMIT: 576,
    CHECK_INVENTOR_FILE_HAS_REQUIRED_ATTACHMENT: 579,
    SAVE_MODEL_ACTION: 607,
    SAVE_MODEL_ACTION_LATEST_REV_ZIP: 608,
    PUBLIC_SAVE_MODEL_ACTION_LATEST_REV_ZIP: 1901,
    GET_VIEWS_OF_MODEL: 625,
    GET_ASSOC_LISTS_MODEL: 627,
    GET_HWF_MODEL_FILE_STATUS: 631,
    VIEW_MODEL_HISTORY: 632,
    GET_USER_SEARCH_FILTERS_COLUMNS: 700,
    DELETE_USER_SEARCH_FILTER: 703,
    GET_USER_SEARCH_FILTERS: 701,
    EDIT_USER_SEARCH_FILTER: 702,
    SAVE_USER_SEARCH_FILTER: 704,
    UNSAVED_USER_SEARCH_FILTER: 705,
    SEARCH_FILTER_DATA: 706,
    GET_SEARCH_FIELD_VALUES: 707,
    SEARCH_DEFAULT_FIELDS_RESULT: 708,
    DOCUMENT_DISTRIBUTION_CLEAR_ACTION_LIST: 716,
    DOCUMENT_DISTRIBUTION_CLEAR_ACTION_SUBMIT: 717,
    DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_LIST: 718,
    DOCUMENT_DISTRIBUTION_DELEGATE_ACTION_SUBMIT: 719,
    DEACTIVATE_FILE_ACTION_LIST: 823,
    DEACTIVATE_FILE_ACTION: 824,
    REACTIVATE_FILE_ACTION_LIST: 825,
    REACTIVATE_FILE_ACTION: 826,
    INITIATE_CREATE_ORI_MSG: 903,
    INITIATE_CREATE_FWD_MSG: 904,
    INITIATE_CREATE_RES_MSG: 905,
    BATCH_FILES_FOR_ACKNOWLEDGEMENT: 951,
    BATCH_FILES_FOR_COMMENT_INCORPORATION: 952,
    BATCH_FILES_FOR_ACTION: 953,
    INITIATE_EDIT_FORM_MSG_COMMITED: 953,
    BATCH_FILES_FOR_COMMENT_COORDINATION: 954,
    ACTION_COMMENT_COORDINATION_INVIEW: 955,
    INITIATE_IMPORT_FORM: 959,
    INITIATE_IMPORT_FORM_FOR_EDIT_ORI: 964,
    CHECK_CONCURRENCY_ISSUE: 965,
    CHECK_EDIT_ORI_DRAFT_MESSAGE: 966,
    CHECK_MAX_INSTANCE_CREATION: 967,
    GET_FOLDER_LIST_POPUP: 1002,
    SAVE_ATTACH_EXT_DOC: 1125,
    UPLOAD_CHUNK_FILE: 1201,
    BATCH_FILES_FOR_INFORMATION: 1301,
    GET_FILE_VIEW_ATTRIBUTES_DETAILS: 1305,
    GET_ADRIVE_FILE_VIEW_ATTRIBUTES_DETAILS: 1306,
    DASHBOARD_GET_USERS_TO_SHARE: 1331,
    CHECKOUT_REV: 1367,
    GET_CHECKOUT_REV_DETAILS: 1368,
    EXPORT_DOCUMENT_HISTORY: 1404,
    REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK: 1369,
    VALIDATE_DOC_NAMING_RULE: 1404,
    EXPORT_FORM_HISTORY: 1405,
    EXPORT_FILE_ASSOCIATIONS_LINK_INFO: 1408,
    SAVE_AS_PDF_AUDIT: 1501,
    SAVE_AS_TIFF_AUDIT: 1502,
    SAVE_AS_CSF_AUDIT: 1506,
    SAVE_FILE_VIEWER_USER_PREFERENCE_ID: 1507,
    COMPARE_FILES: 1508,
    GENERATE_LEGACY_MARKUP: 1509,
    GENERATE_LEGACY_MARKUP_CONSOLIDATED : 1510,
    RIGHT_CLICK_PRINT_VIEW_FORM_ALL: 1703,
    GET_CONTACTS: 1700,
    UPDATE_FLAG: 1710,
    GET_USER_FLAG: 1711,
    GET_ATTACHMENT_AND_ASSOCIATIONS: 1721,
    CHECK_CAN_DOWNLOAD_FOLDER_LEVEL: 256,
    GET_USER_SELECTED_COLUMNS: 1722,
    GET_ALL_LISTING_HEADER: 1734,
    SET_SELECTED_VIEW_TYPE: 1726,
    SAVE_COMMENT: 1728,
    SAVE_DRAFT_COMMENT: 1729,
    INSERT_MODEL_VIEW_HISTORY: 642,
    SAVE_ASSOCIATE_DOCS: 1015,
    GET_ASSOCIATE_DOC: 1013,
    SAVE_AUDIT_TRAIL_FOR_DOCUMENT_ASSOCIATION: 1016,
    GET_USERS_MODEL_DIST_LIST: 616,
    DOWNLOAD_MODEL_TILE: 640,
    SET_MODEL_TILE: 639,
    RENAME_MODEL_VIEW: 636,
    GET_VIEW_DATA: 780,
    SAVE_MODEL_VIEW: 630,
    GET_IFC_OBJECT_TYPE: 1004,
    GET_ALL_BIM_LIST: 1007,
    OBJECT_BASIC_SEARCH: 1006,
    GET_OBJECT_PROPERTIES: 1003,
    URI_OBJECT_ADVANCED_SEARCH: 1009,
    ADD_OBJECT_TO_LIST: 1011,
    SAVE_MODEL_LIST: 1005,
    URI_GET_BIM_LIST_DETAIL: 1008,
    UPDATE_BIM_OBJECT_LIST: 1014,
    GET_HOOPS_FILE_MARKUP: 635,
    CHECK_FILE_PERMISSION: 5,
    CHECK_FOLDER_PERMISSION: 4,
    CHECK_FOR_AKAMAI_UPLOAD_LIMIT: 199,
    DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION: 1731,
    PROGRESS_GENERATE_MARKUP_AS_PDF: 1732,
    GET_SEARCH_PROJECT_LIST_OFFLINE: 221,
	GET_PROJECT_LIST_OFFLINE: 222,
	GET_FOLDER_LIST_OFFLINE: 223,
    GET_SUBFOLDER_LIST_OFFLINE: 224,
    OFFLINE_GET_OBSERVATION_LIST_BY_PLAN_ACTIONID: 225,
    OFFLINE_GET_MARKUPS_LIST: 227,
    OFFLINE_SAVE_COMMENT: 228,
    OFFLINE_SAVE_DRAFT_COMMENT: 229,
    OFFLINE_GET_MARKUPID_BYNAME: 230,
    DELETE_THUMBNAIL_TEMP_FILES: 1206,
    GENERATE_LITE_PDF: 1902,
    
    // listing types
    FILE_LISTING: 1,
    COMMUNICATION_FORM_LISTING: 31,
    DISCUSSION_LISTING: 32,
    REVIEW_LISTING: 147,
    TRANSMITTALS: 21,
    APPS_TRANSMITTALS: 22,
    FIELD_TRANSMITTAL_LISTING: 23,
    TRANSMITTALS_TRANSMITTAL_LISTING: 159,
    CONTRACT_TRANSMITTAL_LISTING: 24,
    FM_TRANSMITTAL_LISTING: 25,
    FINANCE_TRANSMITTAL_LISTING: 26,
    PPM_TRANSMITTAL_LISTING: 27,
    HR_TRANSMITTAL_LISTING: 28,
    H_AND_S_TRANSMITTAL_LISTING: 29,
    PPMT_TRANSMITTAL_LISTING: 30,
    SEARCH_TYPE_CONTACTS_LISTING: 62,
    APP_GLOBAL_SEARCH_LISTING: 39,
    FIELD_FORM_LISTING: 51,
    CONTRACT_FORM_LISTING: 52,
    FM_FORM_LISTING: 53,
    FINANCE_FORM_LISTING: 54,
    PPM_FORM_LISTING: 55,
    HR_FORM_LISTING: 56,
    H_AND_S_FORM_LISTING: 57,
    MARKETPLACE_FORM_LISTING: 128,
    MARKETPLACE_TRANSMITTAL_LISTING: 129,
    SUSTAINABILITY_FORM_LISTING: 153,
    APPS_TRANSMITTAL_FORM_LISTING: 158,
    ADMIN_FETCH_RULE_LISTING: 45,
    PROJECT_LISTING_TYPE: 42,
    MODEL_LISTING_TYPE: 47,
    ADMIN_LISTING_TYPE: 44,
    MODEL_GLOBAL_SEARCH_LISTING: 8,
    COMMUNICATION_FORM_TEMPLATE_LISTING: 33,
    ALL_APP_TYPES_LISTING: 34,
    PROCUREMENT_CATALOGUE_DATA_LISTING: 35,
    PROCUREMENT_CATALOGUE_BASKET_LISTING: 36,
    DESCIPLINE_WISE_MODELREVISIONS_LISTING: 37,
    MODEL_PENDING_ACTIONS_DOCUMENT_LISTING: 38,
    ALL_APPS_AND_PROCUREMENT_MESSAGES_LISTING: 39,
    PRINT_OPTIONS_VALUE_ALL: 63,
    PROCUREMENT_LISTING: 4,
    NEW_PROCUREMENT_LISTING: 126,
    CATALOG_LISTING: 101,
    LEGACY_REPORT_LISTING: 60,
    SEARCH_TYPE_TEMPLATE_LISTING: 58,
    PPMT_FORM_LISTING: 59,
    SCHEDULING_REPORT_LISTING_TYPE: 61,
    ACL_MATRIX_REPORT: 90,
    MANAGE_DISTRIBUTION_GROUP: 91,
    MANAGE_APP_LISTING_TYPE: 49,
    CONTACT_LISTING_TYPE: 62,
    WORKFLOW_LISTING_TYPE: 64,
    WOM_INST_LISTING_TYPE: 66,
    WORKFLOWS_RULE_LISTING: 67,
    WORKFLOWS_ACTION_LISTING: 68,
    DIRECTORY_CATALOUGE_DATA_LISTING: 63,
    DOC_MAILBOX_LISTING: 46,
    FORM_MAILBOX_LISTING: 48,
    ASSIGNED_FORMTYPE_LISTING: 49,
    DOCUMENT_HISTORY_EXPORT: 92,
    PUBLIC_FOLDER_LISTING: 94,
    FORM_HISTORY_EXPORT: 93,
    EXPORT_FILE_ASSOCIATIONS_LINK_INFO_LISTING_TYPE: 97,
    NOTICE_LISTING: 69,
    MANAGE_USER_LISTING: 70,
    ASSOCIATION_MARKUP_LISTING: 102,
    ASSOCIATION_STATIC_LISTING: 103,
    ASSOCIATED_FORM_LISTING: 71,
    ATTACHMENT_LISTING: 72,
    ASSOCIATED_FILE_LISTING: 73,
    ASSOCIATED_DISCUSSION_LISTING: 74,
    ASSOCIATED_SELECTED_FILE_LISTING: 77,
    ASSOCIATED_SELECTED_DISCUSSION_LISTING: 78,
    ASSOCIATED_SELECTED_FORM_LISTING: 79,
    ASSOCIATED_SELECTED_REVIEW_LISTING: 148,
    ASSOCIATED_REVIEW_LISTING: 149,
    CREATE_FORM_ATTACHMENT_LISTING: 139,
    WORKSPACE_ACCESS_LOG_LISTING: 80,

    // APPLICATION PRIVILEGES
    PRIV_EDIT_USERS: 1,
    PRIV_EDIT_Organisations: 2,
    PRIV_MANAGE_SYSTEM_NOTICES: 3,
    PRIV_MANAGE_FORM_TEMPLATES: 4,
    PRIV_MANAGE_ROLE_TEMPLATES: 5,
    PRIV_MANAGE_DRAWING_SERIES_TEMPLATES: 6,
    PRIV_MANAGE_REPROGRAPHICS: 7,
    PRIV_CREATE_REPRO_ORDER: 8,

    // PROJECT PRIVILEGES
    PRIV_MANAGE_WORKSPACE_ROLES_USERS: 9,
    PRIV_MANAGE_PROJECT_ROLES: 10,
    PRIV_ASSIGN_USERS_PRIVILEGES: 11,
    PRIV_VIEW_USER_PRIVILEGES: 12,
    PRIV_MANAGE_NOTICES: 13,
    PRIV_ASSIGN_FORMS_TO_PROJECT: 14,
    PRIV_EDIT_PROJECT_FORM_SETTINGS: 15,
    PRIV_MANAGE_PROJECT_WORKPACKAGES: 16,
    PRIV_MANAGE_PROJECT_DOCUMENT_STATUS: 17,
    PRIV_MANAGE_PROJECT_DRAWING_SERIRES: 18,
    PRIV_CREATE_FOLDER: 19,
    PRIV_AMEND_FOLDER_PERMISSIONS: 20,
    PRIV_ASSIGN_DOCUMENT_ATTRIBUTES: 21,
    PRIV_DEACTIVATE_DOCUMENTS: 22,
    PRIV_DISTRIBUTE_DOCUMENTS: 23,
    PRIV_CREATE_COMMENTS: 24,
    PRIV_CAN_BE_ASSIGNED_ACTION_CHANGE_STATUS: 25,
    PRIV_CAN_BE_ASSIGNED_ACTION_DISTRIBUTE: 26,
    PRIV_CAN_BE_ASSIGNED_ACTION_INC_COMMENTS: 27,
    PRIV_MANAGE_PROJECT_DISTRIUBTIION_GROUPS: 28,
    PRIV_VIEW_REPORTS: 29,
    PRIV_FORM_PROJECT_PRIV_CREATE: 30,
    PRIV_FORM_PROJECT_PRIV_CONTROL: 31,
    PRIV_CREATE_PARENT_FOLDERS: 32,
    PRIV_FORM_PROJECT_PRIV_VIEW: 33,
    PRIV_CHANGE_STATUS: 34,
    PRIV_FORM_NO_ACCESS: 35,
    PRIV_FORM_VIEW_ALL_PRIVATE_FORMS: 36,
    PRIV_PURPOSEOF_DOC_ISSUE: 37,
    PRIV_MANAGE_ORGANIZATION_PLACEHOLDERS: 38,
    PRIV_MANAGE_PROJECT_PLACEHOLDERS: 39,
    PRIV_CAN_CLEAR_ACTIONS_ORG: 40,
    PRIV_CAN_CLEAR_ACTIONS_PROJECT: 41,
    PRIV_CAN_CLEAR_ACTIONS_OWN: 42,
    PRIV_CAN_DELEGATE_ACTIONS_ORG: 43,
    PRIV_CAN_DELEGATE_ACTIONS_PROJECT: 44,
    PRIV_CAN_DELEGATE_ACTIONS_OWN: 45,
    PRIV_CAN_CLEAR_COMMENTS: 46,
    PRIV_ACCESS_DEACTIVATED_DOCUMENTS: 47,
    PRIV_MANAGE_PROJECT_PAPER_DOCUMENTS: 48,
    PRIV_CAN_DEACTIVATE_USERS_FROM_PROJECT: 49,
    PRIV_CAN_ASSIGN_PROXY_USERS: 50,
    VALUE_ALLOW_CUSTOM_DISTRIBUTION_ALL_ORG: 51,
    PRIV_MANAGE_SPACES: 52,
    PRIV_MANAGE_USER_SUBSCRIPTIONS: 58,
    PRIV_MANAGE_PROJECTS_ALL_ORGS: 59,
    PRIV_MANAGE_PROJECT_MAILBOX: 60,
    PRIV_EDIT_PROJECT_DETAILS: 61,
    VALUE_ALLOW_CUSTOM_DISTRIBUTION_OWN_ORG: 62,
    PRIV_CAN_CREATE_FLAT_FEE_BASED_PROJECTS: 63,
    PRIV_CAN_CREATE_SUBSCRIPTION_PROJECTS: 64,
    PRIV_CAN_CONFIGURE_DOCUMENT_NAMING: 67,
    PRIV_CAN_ACESS_AUDIT_INFO: 69,
    PRIV_CAN_CREATE_COMMENT: 70,
    PRIV_ASSIGN_ROLE_MEMBERSHIP_ALL_ORG: 71,
    PRIV_ASSIGN_ROLE_MEMBERSHIP_OWN_ORG: 72,
    PRIV_CAN_SAVE_WORKSPACE_AS_TEMPLATE: 73,
    PRIV_CAN_MANAGE_FORM_STATUSES: 74,
    PRIV_FORM_VIEW_PRIVATE_OWN_ORG: 75,
    PRIV_CAN_MANAGE_USER_PREFERENCES: 76,
    PRIV_CAN_DEACTIVATE_OWN_FORMS: 77,
    PRIV_CAN_DEACTIVATE_ALL_FORMS: 78,
    PRIV_FORM_VIEW_DRAFT_OWN_ORG: 79,
    PRIV_FORM_VIEW_DRAFT_ALL_ORG: 80,
    PRIV_CAN_DOWNLOAD_DOCUMENTS: 81,
    PRIV_CAN_PRINT_DOCUMENTS: 82,
    PRIV_CAN_ACCESS_WORKSPACE_WITHOUT_SUBSCRIPTION: 83,
    PRIV_CAN_ACCESS_WORKSPACE_CALENDAR: 84,
    CAN_ACCESS_DISTRIBUTION_MODULE: 85,
    CAN_ACCESS_DESIGN_WORKFLOW: 86,
    CAN_ACCESS_PREQUALIFICATION_MODULE: 87,
    CAN_ACCESS_BIDDING_MODULE: 88,
    CAN_ACCESS_CONSTRUCTION_MODULE: 89,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PWF: 90,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PWS: 91,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_EWS: 92,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_SWS: 93,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_TWS: 94,
    PRIV_CAN_CREATE_DOCUMENT_MANAGER_PMW: 95,
    PRIV_CAN_ACCESS_NAVIGATOR: 96,
    PRIV_MANAGE_APPS: 97,
    PRIV_MANAGE_APP_SETTINGS: 98,
    CAN_BATCH_CHANGE_STATUS_OF_OWN_FORM: 99,
    CAN_REOPEN_CLOSED_FORM: 100,
    CAN_ASSIGN_TO_WORKSPACE_WITHOUT_ACCEPTANCE: 101,
    CAN_AMEND_ALL_FOLDER_PERMISSIONS: 102,
    CAN_SHARE_SEARCH_VIEWS: 109,
    CAN_MANAGE_PROJECTS_MODELS: 110,
    CAN_BATCH_CHANGE_STATUS_OF_ALL_FORMS: 111,
    PRIV_CAN_MANAGE_PROJECTS_MODELS_VIEWS: 112,
    PRIV_CAN_CREATE_ADHOC_REPORT: 113,
    PRIV_MANAGE_WORKFLOW_RULES: 114,
    CAN_DEACTIVATE_FORM_ACTIONS_OWN_ORG: 115,
    CAN_DEACTIVATE_FORM_ACTIONS_ALL_ORG: 116,
    CAN_REACTIVATE_FORM_ACTIONS_OWN_ORG: 117,
    CAN_REACTIVATE_FORM_ACTIONS_ALL_ORG: 118,
    CAN_DEACTIVATE_DOCUMENT_ACTIONS_OWN_ORG: 119,
    CAN_DEACTIVATE_DOCUMENT_ACTIONS_ALL_ORG: 120,
    CAN_REACTIVATE_DOCUMENT_ACTIONS_OWN_ORG: 121,
    CAN_REACTIVATE_DOCUMENT_ACTIONS_ALL_ORG: 122,
    CAN_CREATE_USER_AND_ORGS: 123,
    PRIV_CAN_MANAGE_OBJECT_LISTS: 124,
    PRIV_CAN_MANAGE_CONFIGURABLE_ATTRIBUTES: 125,
    PRIV_CAN_MOVE_DOC: 126,
    CAN_CREATE_eINVOICE: 127,
    MANAGE_PUNCHOUT_CATALOGUE_RESTRICTION: 128,
    CAN_CREATE_PRIVATE_COMMENTS: 129,
    CAN_REOPEN_ALL_CLOSED_FORMS_ADMIN: 130,
    CAN_CONTROLL_LAYOUT_ALL_ORG: 131,
    PRIV_WORKSPACE_NO_ACCESS: 0,
    PRIV_WORKSPACE_ADMIN: 1023,
    CAN_MANAGE_PROJECTS_FIELD: 135,
    CAN_CREATE_NEW_USERS_AND_ORG_ALL_ORG: 136,
    SAVE_SORT_DETAILS_FOR_USER: 335,
    DOCUMENT_ASSOCIATED_COMMS_ACTION: 121,
    VIEW_MODEL_DISCUSSIONS: 152,
    UPLOAD_FILE_VALIDATION_NEW: 802,
    GET_PROJECT_LIST_POPUP: 1001,
    SAVE_USER_SEL_PROJECTS: 810,
    CAN_VIEW_HISTORIC_MARKUPS:163,
    MARK_REVIEW_PRIVATE:172,
    CAN_MANAGE_REVIEW_FLAGS: 173,
    CAN_CREATE_ISSUE: 166,
    CAN_CREATE_ISSUE_COMMENT: 167,
    CAN_CREATE_FILES_FROM_DOCUMENT_TEMPLATES: 179,

    // other common
    PRINT_OPTIONS_VALUE_ALL: 63,
    CALLER_APP: 10,
    OBJECT_TYPE_FILTER: 102,

    // Custom Object constants
    customObject: {
        DOCUMENT_CONTEXT_ID: 1,
        APP_CONTEXT_ID: 2,
        MODEL_CONTEXT_ID: 3,
        MODEL_VIEW_CLASS_NAME: 'modelView',
        DISTRIBUTION_CLASS_NAME: 'distribution',
        COMMENT_CLASS_NAME: 'comment'
    },

    //Folder permissions
    folderPermission: {
        VIEW_ONLY: 23,
        FOLDER_ADMIN_PERMISSION: 1023,
        FOLDER_PUBLISH_AND_LINK_PERMISSION: 239,
        FOLDER_PUBLISH_PERMISSION: 111
    },

    // app action id map
    appActionMap: {
        READ: 0,
        FOR_RESPOND: 3,
        FOR_DISTRIBUTION: 6,
        FOR_INFORMATION: 7,
        FOR_ACKNOWLEDGEMENT: 37,
        FOR_STATUS_CHANGE: 14,
        FOR_REVIEW_DRAFT: 34,
        FOR_ACTION: 36,
        FOR_ASSIGN_STATUS: 2,
        FOR_ATTACHED_DOC: 5,
        RELEASE_RESPONSE: 4
    },

    // document action id map
    docActionMap: {
        FOR_ACKNOWLEDGEMENT: 8,
        FOR_COMMENT: 9,
        FOR_COMMENT_COORDINATION: 10,
        FOR_COMMENT_INCORP: 11,
        FOR_DISTRIBUTION: 12,
        FOR_STATUS_CHANGE: 14,
        FOR_ACTION: 35,
        FOR_INFORMATION: 13,
        FOR_PUBLISHING: 28
    },

	SHARE_OBJECT_TYPE_ID: {
		WORKSPACE: 1,
		FOLDER: 2,
		FILE: 3
	},

	SHARE_PERMISSION: {
		NONE: 0,
		OWNER: 1,
		EDITOR: 2,
		VIEWER: 3
	},
    
    ADRIVE_FILE_PERMISSION: {
        VIEW_FILE: 5,
        CREATE_COMMENT: 11,
        DOWNLOAD_FILE: 4
    },

    // used mostly for create form area
    from: {
        MODEL_NEW_FORM: 4,
        VIEW_FORM: 3,
        ASSOC_FILE_FILETAB: 5,
        ASSOC_FILE_FILEVIEWER: 6,
        ASSOC_DISCUSSION_DISCUSSIONTAB: 7,
        ASSOC_DISCUSSION_FILEVIEWER: 8,
        ASSOC_APP_APPTAB: 9,
        ASSOC_APP_FORMVIEWER: 10,
        FILE_TAB_TREE: 11,
        CALL_OFF_FORM: 12,
        CREATE_NEW_BTN_APP_TAB: 13,
        ASSOC_FILE_DASHBOARD_TAB: 14,
        ASSOC_FILE_SEARCH_TAB: 15,
        ASSOC_APP_DASHBOARD_TAB: 16,
        ASSOC_APP_SEARCH_TAB: 17,
        ASSOC_DISCUSSION_DASHBOARD_TAB: 18,
        ASSOC_DISCUSSION_SEARCH_TAB: 19,
        CREATE_NEW_FORM_DASHBOARD_TAB: 20,
        CREATE_NEW_FORM_SEARCH_TAB: 21,
        FORM_VIEWER: 22,
        ASSOC_ALL_FORM_VIEWER: 23,
        EDIT_REPORT_TAB: 24,
        OPEN_ANY_DRAFT: 25,
        CANCEL_AFTER_AUTO_SAVED: 26,
        EDIT_NEW_ORI_VIEW_FORM: 27,
        DRAFT_DISCARDED: 28,
        EDIT_ORI_FROM_XSN_LINK: 29,
        RESPOND_ACTION_PROJECT_FORM: 30,
        CREATE_FROM_PRINTVIEW: 31,
        CHECK_FORM_CLOSE: 968
    },

    ACTIVITY_CONSTANT: {
        ACTIVITY_REVISION_UPLOAD: 101,
        ACTIVITY_FILE_DISTRIBUTION: 102,
        ACTIVITY_EDIT_ATTRIBUTES: 103,
        ACTIVITY_UPDATE_STATUS: 104,
        ACTIVITY_ADD_COMMENT: 105,
        ACTIVITY_KEY_REVISION_UPLOAD: 1001,
        ACTIVITY_KEY_FILE_DISTRIBUTION: 1002,
        ACTIVITY_KEY_EDIT_ATTRIBUTES: 1003,
        ACTIVITY_KEY_UPDATE_STATUS: 1004,
        ACTIVITY_KEY_ADD_COMMENT: 1005,
    },

    entity: {
        APP: 1,
        FILE: 2,
        DISCUSSION: 4
    },

    appType: {
        CONTACTS: 0,
        COMMUNICATION: 1,
        FIELD: 2,
        CONTRACTS: 3,
        PROCUREMENT: 11,
        EXCHANGE: 4,
        FM: 5,
        FINANCE: 6,
        PPM: 7,
        HR: 8,
        H_AND_S: 9,
        PPMT: 10,
        FILES: 1,
        DISCUSSIONS: 0,
        TRANSMITTALS: 1,
        MARKETPLACE: 12,
        SUSTAINABILITY: 21,
        APPS_TRANSMITTALS: 22,
    },

    COMMENT_TYPE: {
        NORMAL: 1,
        NOCOMMENT: 2,
        REPLY: 4
    },

    USER_VIEWER_PREFERENCE: {
        HTML_VIEWER: 5,
        ACTIVEX_VIEWER: 6,
        PDFTRON_VIEWER: 7
    },

    UPLOAD_TYPE: {
        FILE: 1,
        ATTACHMENT: 2,
        COMMENT: 5,
        FORM: 4,
        INLINE_FORM: 6,
        MODEL_ATTACHMENT:11
    },

    FILESATTRIBUTES_EXCEPTIONCODE: {
        CODE_LINKED_FILE: 2019,
        CODE_DEACTIVATED_FILE: 2020,
        CODE_FILE_CHECKED_OUT: 2021,
        CODE_VALID_EXISTING_FILES: 2022,
        CODE_EXTENSION_LESS_FILENAME: 2023,
        CODE_PH_ALREADY_UPLOADED_NOT_PUBLISH_ACTION: 2013,
        CODE_DOCREF_ASSOC_WITH_DIFF_MODEL: 2033,
        CODE_REVISION_UPLOAD_ACTIVITY_LOCK: 1001
    },

    VALIDATION_TYPE: {
        VALIDATION_ON_ENTER_DOC_DETAILS: 1
    },

    initComponentMapObj: {
        "Apps": "app",
        "History": "history",
        "reply": "discussions",
        "discussions": "discussions",
        "createCommet": "create-comment",
        "coordination": "comment-coordination",
        "incorporation": "comment-incorporation",
        "distribution": "file-distribution",
        "publish": "attach-doc",
        "ASSIGN_STATUS": "status-change",
        "ASSOC_ATTACH": "assoc-attach",
        "fileInfo": "file-info"
    },

    attachAssocLabelMap: {
        'FILES': 'Files',
        'DISCUSSIONS': 'Discussions',
        'FORMS': 'Forms',
        'ATTACHMENTS': 'Attachments',
        'VIEWS': 'Views'
    },

    FORM_STATUS: {
        closed: 'Closed'
    },

    DOC_TYPE_ID: {
        'NORMAL': 1,
        'PLACEHOLDER': 2
    },
    //NOODLE-84014 solr data mapping in msg.detail.js global for xsn and html5 form launch mapping - generic for both types of apps - ptahiliani
    SOLR_DATA_MAPPING: {
        'controllerUserId': 'controller_user_id',
        'controllerUserTypeId': 'controller_user_type_id',
        'formCode': 'form_code_name',
        'formCreationDate': 'form_creation_date',
        'formId': 'form_id',
        'formNo': 'form_num',
        'formNoInt': 'form_num',
        'formStatusId': 'status_id',
        'formTitle': 'title',
        'formTypeId': 'form_type_id',
        'formTypeName': 'form_type_name',
        'form_status_name': 'status_name',
        'formcode_num': 'form_code',
        'hasAttachment': 'has_attachment',
        'msgCreationDate': 'msg_creation_date',
        'msgId': 'msg_id',
        'msgNo': 'msg_num',
        'msgStatusId': 'msg_status_id',
        'msgTypeId': 'msg_type_id',
        'msg_ori_user_name': 'originator_name',
        'originatorProxyUserId': 'originator_proxy_user_id',
        'originatorUserId': 'originator_user_id',
        'projectId': 'project_id',
        'status_name': 'status_name',
        'userRef': 'user_ref',
        'msgContent1': 'msg_content1',
        'msgContent2': 'msg_content2',
        'msgContent': 'msg_content',
        'msgContent3': 'msg_content3'
    },

    DISTRIBUTION_LEVEL: {
        "ROLES": 1,
        "ORGANISATIONS": 2,
        "USERS": 3,
        "USER_GROUPS": 4,
        "DISTRIBUTION_GROUPS": 5
    },

    PREFIX_DISTRIBUTION_LEVEL: {
        "1": "(R)",
        "2": "(O)",
        "3": "(U)",
        "4": "(UG)",
        "5": "(D)"
    },

    PDFTRON_SUPPORTED_EXTENSION: "DGN,DWF,DWG,DXF,PDF,XPS,XOD,HTM,HTML,XHTML,SVG,TXT,BMP,ICO,GIF,JPG,JPEG,PNG,TIF,TIFF,DOC,DOCM,DOCX,DOT,DOTM,DOTX,POT,POTX,PPA,PPS,PPSM,PPSX,PPT,PPTM,PPTX,PUB,XLS,XLSB,XLSM,XLSX,XLT,XLTM,XLTX,RTF",
    THUMBNAIL_SUPPORTED_EXTENSION : "JPG,JPEG,PNG,GIF,TIFF,PDF,BMP",
    OFFLINE_THUMBNAIL_SUPPORTED_EXTENSION : "JPG,JPEG,PNG",
    CBIM_PLUGINS: "naviswork|revit",

    // Add subscription ids
    AVAILABLE_USER_TABS: [
        '3',
        '5',
        '11',
        '30',
        '31',
        '32',
        '33',
        '34',
        '35',
        '36',
        '37'
    ]
})

.filter('startFrom', function() {
    return function(input, start) {
        start = +start; //parse to int
        return input.slice(start);
    }
})

/**
 *  Invoke on offlineCreateForm.html and offlineViewForm.html page in offline html5 form.
 *  This filter will provide internationalization.
 */
.filter('offlineLang', function() {
    return function(input) {
        return Language.get(input);
    };
})

/**
 * Based Domain Service
 * This service is use for make dc specific url
 */
.service('manageDataCenter', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', function($window, $timeout, apiConfig, myConfig, lang) {
    var manageDataCenter = this;

    window.manageDataCenterGlobal = manageDataCenter;
    /*
     * Following function is used for initialize manage data center service
     */
    manageDataCenter.init = function() {
        manageDataCenter.manipulateDCJson();
        manageDataCenter.manipulateContentAccelerationJson();
        manageDataCenter.setRegEx();
    };

    /*
     * Following function is used for mapping obj based on dcId and its suffix
     */
    manageDataCenter.manipulateDCJson = function() {
        for (var i = 0; i < myConfig.USER_DC_JSON.length; i++) {
            myConfig.dcMapSuffix[myConfig.USER_DC_JSON[i].id] = myConfig.USER_DC_JSON[i].suffix
        }
    };

    /*
     * Following function is used for mapping obj with Content Acceleration Suffix
     */
    manageDataCenter.manipulateContentAccelerationJson = function() {
        for (var i = 0; i < myConfig.CONTENT_ACCELERATION_JSON.length; i++) {
            myConfig.caMapSuffix[myConfig.CONTENT_ACCELERATION_JSON[i].id] = myConfig.CONTENT_ACCELERATION_JSON[i].suffix
        }
    };

    /*
     * Following function is used for generate regular expression based on USER_DC_JSON & CONTENT_ACCLERATION_JSON
     */
    manageDataCenter.setRegEx = function() {
        var str = "";
        for (var i = 0; i <= Object.keys(myConfig.USER_DC_JSON).length - 1; i++) {
            var dcJsonData = myConfig.USER_DC_JSON[i];
            if (dcJsonData.suffix != "") {
                str += dcJsonData.suffix + "\\.|"
            }
            for (var j = 0; j <= Object.keys(myConfig.CONTENT_ACCELERATION_JSON).length - 1; j++) {
                var accelerationJsonData = myConfig.CONTENT_ACCELERATION_JSON[j];
                if (i == Object.keys(myConfig.USER_DC_JSON).length - 1 && j == Object.keys(myConfig.CONTENT_ACCELERATION_JSON).length - 1) {
                    str += dcJsonData.suffix + accelerationJsonData.suffix + "\\."
                } else {
                    str += dcJsonData.suffix + accelerationJsonData.suffix + "\\.|"
                }
            }
        }
        myConfig.dcRegEx = new RegExp(str, 'i');
    };

    manageDataCenter.domainReplace = function(returnUrl) {
        var dcExtExistedUrls = myConfig.dcExtnExistedList || "";
        var index = returnUrl.indexOf(".");
        var urlBeforeDot = returnUrl.substring(0, index + 1); //get the first part of URL where CDN/DC extension appended. like https://dmsak.
        if (dcExtExistedUrls) {
            var array = dcExtExistedUrls.split(",");
            for (var i = 0; i < array.length; i++) {
                var dcExistInUrl = array[i];
                var n = urlBeforeDot.indexOf(dcExistInUrl);
                if (n > -1) {
                    var urlDcExt = urlBeforeDot.substring(n, urlBeforeDot.length);
                    urlBeforeDot = urlBeforeDot.replace(urlDcExt, dcExistInUrl);
                    break;
                }
            }
        }
        return urlBeforeDot;
    };

    /*
     * Following function is used for return baseUrl/finalPath based on @dcId
     */
    manageDataCenter.getUrl = function(dcId, cdnUrl, nonEdgecast) {
        if (!dcId) {
            return "";
        }
        var dcSuffix = myConfig.dcMapSuffix[dcId];
        var contentAccelerationSuffix = "";
        if (!nonEdgecast && dcId == 1 && myConfig.USER_CDN_TYPE_ID == "1") {
            contentAccelerationSuffix = myConfig.caMapSuffix[dcId];
        }
        var finalPath = cdnUrl || myConfig.baseUrl;
        var splitPath = finalPath.split(".");
        splitPath[0] += ".";
        splitPath[0] = manageDataCenter.domainReplace(splitPath[0]);
        splitPath[0] = splitPath[0].replace(myConfig.dcRegEx, "") + dcSuffix + contentAccelerationSuffix;
        return splitPath.join(".")
    };

    manageDataCenter.init();
}])

/*
 * Download Service
 * This module will manage download functionality like below: 
 * 	-	Fetch ajax call for download setting
		-	pass download setting data to its callback fun
	
	-	Check download for single file or not	 
 */
.service('download', ['$window', '$timeout', 'Notification', 'lang', 'api', 'apiConfig', 'myConfig', '$uibModal', 'manageDataCenter', function($window, $timeout, Notification, lang, api, apiConfig, myConfig, $uibModal, manageDataCenter) {
    var download = this,
        projectIds = [],
        paramRev = {
            revisions: []
        },
        paramDcId = {},
        errorCode = [];

    download.init = function(data, callback) {
        Notification.clearAll();

        if (myConfig.applicationId != 2) {
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');
        }
        if (download.isSingleFile(data)) {
            download.file(data, data.projectId);
            callback && callback();
        } else if (download.hasMultpleProject(data)) {
            download.setProjectIds(data);

            if (data.downloadPref && (data.downloadPref.isIncludeMarkup || data.downloadPref.isEmbedQRCode)) {
                download.zip(data.selectedFiles, data.downloadPref, callback);
            } else {
                download.multipleProj(data, callback);
            }
        } else {
            download.zip(data.selectedFiles, data.downloadPref, callback);
        }
    };

    download.hasMultpleProject = function(data) {
        var projectId = data.selectedFiles[0].projectId;
        for (var i = 0; i < data.selectedFiles.length; i++) {
            if (projectId != data.selectedFiles[i].projectId) {
                return true;
            }
        }

        return false;
    };

    download.setProjectIds = function(data) {
        errorCode = projectIds = paramRev.revisions = [];
        paramDcId = {};

        var prdIds = [],
            revIds = [],
            obj = {};
        for (var i = 0; i < data.selectedFiles.length; i++) {
            obj = {
                dcId: data.selectedFiles[i].dcId,
                isLock: data.selectedFiles[i].isLock,
                revisionId: data.selectedFiles[i].revisionId,
                projectId: data.selectedFiles[i].projectId
            }
            revIds.push(obj);
            if (!paramDcId[data.selectedFiles[i].dcId]) {
                paramDcId[data.selectedFiles[i].dcId] = {
                    revisions: []
                };
            }
            paramDcId[data.selectedFiles[i].dcId].revisions.push(data.selectedFiles[i]);

            prdIds.push(data.selectedFiles[i].projectId);
        }
        paramRev.revisions = revIds;
        projectIds = prdIds;
    };

    download.multipleProj = function(data, callback) {
        data.revisionIds = paramRev;
        download.returnNonAkamaiURL(data, function(resData) {
            var cdnUrl;
            if (resData.isLimitExist) {
                cdnUrl = resData.nonCDNDownloadUrl;
            }
            var counter = 0;
            for (key in paramDcId) {
                paramDcId[key].dcId = key;
                paramDcId[key].cdnUrl = cdnUrl;
                download.checkAvailForDownload(paramDcId[key], function(resData) {
                    if (resData && resData.length) {
                        errorCode.push(resData);
                    }
                    counter++;
                    if (Object.keys(paramDcId).length === counter) {
                        download.startBatchFiles(data, callback);
                        if (data.error && errorCode.length) {
                            data.error(errorCode);
                        }
                    }
                })
            }
        });
    };

    download.checkRevRestriction = function(data, callback) {
        var paramObj ={
            projectId: data.projectId,
            revisionId: data.revisionId,
            formProjectId: myConfig.projectId
        }
        if(myConfig.formTypeId && myConfig.formTypeId !=="null" && myConfig.formTypeId.indexOf("$$") != -1)
        {
            paramObj.formTypeId = myConfig.formTypeId;
        }
        var xhr = api.ajax({
            url: apiConfig.IS_DOCUMENT_DOWNLOAD_RESTRICTED,
            _cdnUrl: myConfig.downloadServiceURL,
            data :paramObj
        });

        xhr.then(function(respData) {
            callback && callback(respData);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    }

    download.checkAvailForDownload = function(data, callback) {
        var xhr = api.ajax({
            url: apiConfig.CHECK_AVAILABILITY_OF_DOWNLOAD_DOCUMENT_CONTROLLER,
            data: {
                isMultiProject: true,
                extra: angular.toJson(data)
            },
            _dcId: data.dcId,
            _cdnUrl: data.cdnUrl || myConfig.downloadServiceURL
        });

        xhr.then(function(respData) {
            callback && callback(respData);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    };

    download.startBatchFiles = function(data, callback) {
        var url = apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER,
            projectId = data.projectId,
            selectMultiDCUKProjId = data.selectMultiDCUKProjId;
            isFromMultiDCBatch = data.isFromMultiDCBatch || false;

        var paramsObj = {
            extra: JSON.stringify(paramRev),
            projectIds: "",
            projectID: projectId,
            isFromMultiDCBatch:isFromMultiDCBatch

        };
        if (data.byPassParam) {
            paramsObj.adads = "true";
            paramsObj.hashedToken = data.byPassParam.allowDownloadToken
        }
        var xhr = api.ajax({
            url: url,
            data: paramsObj,
            _cdnUrl: myConfig.downloadServiceURL,
            _dcId: data.dcId
        });

        xhr.then(function(respData) {
            if (respData.validForDownload == false) {
                xhr.errorTitle = lang.get("disabled-enabled-download-button");
                api.showServerErrMsg(xhr);
                callback && callback();
            } else {
                respData.projectId = projectId;
                respData.isMultiDCUKProjId = true;
                respData.selectMultiDCUKProjId = selectMultiDCUKProjId;
                respData.isFromMultiDCBatch = isFromMultiDCBatch;
                if (data.downloadPref && (data.downloadPref.isIncludeMarkup || data.downloadPref.isEmbedQRCode)) {
                    Notification.clearAll();
                    Notification.warning({
                        message: '<div class="text-large">' + lang.get("please-wait-files-processd-while") + '</div>',
                        delay: false
                    });
                    download.downloadIncludeMarkups(data, undefined, callback);
                } else {
                    download.createZipFile(respData, callback);
                }
            }
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
            callback && callback();
        });
    };

    download.hasAnySettingApplied = function(data) {
        var pref = data;
        return pref.isParentDoc || pref.isIncludeMarkup || pref.isEmbedQRCode || pref.hasCommentAttachedDocs || pref.hasCommentAssocDocs || pref.isAssocFiles;
    };

    download.isSingleFile = function(data) {
        var flag = false,
            pref = data.downloadPref,
            selectedPref = this.isMultiPrefSelected(pref);

        if (data.selectedFiles.length === 1 && !pref.isIncludeMarkup && !pref.isEmbedQRCode && !pref.hasCommentAssocDocs && !pref.hasCommentAttachedDocs && !pref.isAssocFiles && !pref.isXREF) {
            flag = true;
        } else if (selectedPref === 1) {
            flag = true;

            if (pref.hasCommentAttachedDocs && pref.commentAttachedDocsCount > 1) {
                flag = false;
            }

            if (pref.hasCommentAssocDocs && pref.commentAssocDocsCount > 1) {
                flag = false;
            }

            if (pref.isAssocFiles && this.anyFileHasAttachment(data)) {
                flag = false;
            }

            if (pref.isIncludeMarkup && (pref.markUpDocsCount > 1 || (pref.markUpDocsCount === 1 && data.selectedFiles.length > 1))) {
                flag = false;
            }

            if (pref.isParentDoc && data.selectedFiles.length > 1) {
                flag = false;
            }
        }

        (pref.isIncludeMarkup || pref.isEmbedQRCode) && (flag = false);
        return flag;
    };

    download.anyFileHasAttachment = function(data) {
        var count = 0;

        for (var i = 0; i < data.selectedFiles.length; i++) {
            var fileObj = data.selectedFiles[i];
            if (fileObj.hasAttachment) {
                count += 1;
            }
        }

        return (count > 1);
    };

    download.isMultiPrefSelected = function(downloadPref) {
        var checkLength = 0;

        var array = [downloadPref.isParentDoc, downloadPref.isAssocFiles, downloadPref.isXREF,
            downloadPref.hasCommentAssocDocs, downloadPref.hasCommentAttachedDocs, downloadPref.isIncludeMarkup, downloadPref.isEmbedQRCode
        ];

        for (var i = 0; i < array.length; i++) {
            if (array[i]) {
                checkLength++;
            }
        }

        return checkLength;
    };

    download.returnNonAkamaiURL = function(param, callback) {
        if(!myConfig.downloadServiceURL){
            myConfig.downloadServiceURL = window.downloadServiceURL;
        }
        var xhr = api.ajax({
            url: apiConfig.CHECK_DOCUMENT_DOWNLOAD_LIMIT,
            _cdnUrl: myConfig.downloadServiceURL,
            data: {
                userId: myConfig.USP.userID,
                projectId: param.projectId,
                extra: JSON.stringify(param.revisionIds)
            }
        });

        xhr.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"));
        });
    };

    download.fetchPref = function(data, callback) {
        return api.ajax({
            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_PAGE_CONTROLLER,
            _cdnUrl: myConfig.downloadServiceURL,
            data: {
                extra: angular.toJson({ "revisions": data.selectedFiles }),
                isFromAttachment: ((data.currentEntityType === apiConfig.attachAssocLabelMap.ATTACHMENTS) ? "true" : undefined),
                projectID: data.projectId
            }
        });
    };

    download.file = function(file, projectId) {
        if (myConfig.applicationId == 2) {
            qtObject.downloadFile(JSON.stringify(file.downloadPref), file.selectedFiles[0].fileName);
            return;
        }

        var dataToSend = {
            projectID: file.projectId,
            isFromXrefRevisionDetails: false,
            extra: JSON.stringify(file.downloadPref)
        };

        if (file.selectedFiles[0].curFormByPassSetting && file.selectedFiles[0].curFormByPassSetting.viewAlwaysDocAssociation) {
            dataToSend.adads = true;
            dataToSend.hashedToken = file.selectedFiles[0].curFormByPassSetting.allowDownloadToken;
        }

        api.submitForm({
            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
            _cdnUrl: myConfig.downloadServiceURL,
            param: dataToSend,
            target: '_self'
        });
    };

    download.saveAsPdf = function(file){

        Notification.clearAll();

        if (myConfig.applicationId != 2) {
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');
        }
        
        var selectedFiles = [{
            fileName: file.fileName,
            revisionId: file.revisionId,
            isLock: file.isLock ? "true" : "",
            dcId: file.dcId,
            projectId: file.projectId,
            folderId: file.folderId,
            docId: file.documentId
        }];

        download.returnNonAkamaiURL({
            projectId: file.projectId,
            revisionIds: {
                revisions: selectedFiles
            }
        }, function(data) {
            var url = "";

            // Compute base url
            if (data.isLimitExist) {
                url = data.nonCDNDownloadUrl;
            } else {
                url = myConfig.downloadServiceURL;
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }

            var downloadPref = {
                isIncludeMarkup: true,
                isParentDoc: false,
                isXREF: false,
                isRenameWithDocRef: false,
                isAppenedRevNo: false,
                isAppendDocTitle: false,
                isAppenedIssNo: false,
                fromSaveAsPDF: true,
                revIds: [file.revisionId.split('$$')[0]]
            };

            /** also saveAsPDF from UWV project. */
            if(file.projectViewerId && file.projectViewerId == 7){
                downloadPref["projectViewerId"] = file.projectViewerId;
                if (file && file.isAttachmentForm) {
                    downloadPref["comingFrom"] = 'attachment';
                    downloadPref["msgId"] = msgId;
                } else {
                    downloadPref["comingFrom"] = 'saveAsPDF';
                }
            }
           
            var dataToSend = {
                extra: JSON.stringify(downloadPref),
                userID: myConfig.USP.userID,
                saveAsPDF: true,
                projectID: file.projectId
            };

            api.submitForm({
                url: url + apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
                param: dataToSend,
                target: '_self'
            });
        });
    };
    download.zip = function(selectedItems, downloadPref, callback) {

        download.returnNonAkamaiURL({
            projectId: selectedItems[0].projectId,
            revisionIds: {
                'revisions': selectedItems
            }
        }, function(data) {
            var url = "";
            downloadPref = downloadPref || {};
            if (data.isLimitExist || downloadPref.isIncludeMarkup === true || downloadPref.isIncludeMarkup === "true" || downloadPref.isEmbedQRCode === true || downloadPref.isEmbedQRCode === "true") {
                url = data.nonCDNDownloadUrl;
            } else {
                url = myConfig.downloadServiceURL;
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }

            var paramsObj = {
                extra: JSON.stringify(downloadPref),
                projectID: selectedItems[0].projectId
            };

            var xhr = api.ajax({
                url: url + apiConfig.DOWNLOAD_BATCH_DOCUMENT_CONTROLLER,
                data: paramsObj
            });

            xhr.then(function(data) {
                if (!data) {
                    callback && callback();
                    return;
                }

                data.projectId = selectedItems[0].projectId;
                if (downloadPref && (downloadPref.isIncludeMarkup || downloadPref.isEmbedQRCode)) {
                    Notification.clearAll();
                    Notification.warning({
                        message: '<div class="text-large">' + lang.get("please-wait-files-processd-while") + '</div>',
                        delay: false
                    });
                    data.url = url + apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
                    download.downloadIncludeMarkups(data, undefined, callback, downloadPref.isEmbedQRCode);
                } else {
                    Notification.clearAll();
                    data.url = url + apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
                    download.createZipFile(data, callback);
                }
            }, function(xhr) {
                $window.alert(lang.get("something-went-wrong"));
                callback && callback();
            });
        });
    };
    download.getErrorMessage = function(errorFilesList) {
        var errorMessage = "";
        switch (errorFilesList.errorCode) {
            case 1:
                errorMessage = lang.get('system-task-not-configured');
                break;
            case 2:
                errorMessage = lang.get('folder-setting-enableqrcode-not-enabled');
                break;
            case 3:
                errorMessage = lang.get('file-format-not-supported-qrcode');
                break;
            case 4:
                errorMessage = lang.get('embedding-qrcode-file-try-support');
                break;
            default:
                errorMessage = "";
        }
        return errorMessage;
    };

    download.downloadIncludeMarkups = function(markUpData, data, callback, isEmbedQRCode) {
        var markupGenerated = "generated";
        var markupQRCode = "failed";
        var markupIncludeMarkup = "failed";
        var markupInvoke = data ? data.markupsProgress : "";
        var errorFilesList = data ? data.errorFiles : [];
        var c_number = data ? data.c_number : 0;
        if (markupInvoke == markupGenerated) {
            Notification.clearAll();
            if (isEmbedQRCode && errorFilesList && errorFilesList.length && c_number != 1) {
                var childController = function($scope, $uibModalInstance, errorFilesList) {
                    for (var i = 0; i < errorFilesList.length; i++) {
                        errorFilesList[i].errorCodeMessage = download.getErrorMessage(errorFilesList[i]);
                    }                    
                    $scope.errorFile = errorFilesList;
                    $scope.isContinueDownload = false;
                    $scope.allFilesFail = true;
                    $scope.continueDownload = function() {
                        $uibModalInstance.close({ my: 'data' });
                        var xhr = api.ajax({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            data: {
                                projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                                markUpsProgressKey: markUpData.publishMarkupsProgressKey
                            }
                        });
                        xhr.then(function(data) {
                            data.projectId = markUpData.projectId;
                            data.url = markUpData.url;
                            download.createZipFile(data, callback);
                        });
                    }
                    $scope.cancel = function() {
                        $uibModalInstance.dismiss();
                        callback && callback();
                    }
                }
                $uibModal.open({
                    animation: true,
                    templateUrl: 'myModalContent.html',
                    controller: childController,
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        errorFilesList: function() {
                            return errorFilesList;
                        }
                    }
                });

            } else {
                var dataJSON = {
                    action_id: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION,
                    projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                    markUpsProgressKey: markUpData.publishMarkupsProgressKey
                }
                if(errorFilesList && errorFilesList.length){                    
                    var childController = function($scope, $uibModalInstance, errorFilesList) {
                        for (var i = 0; i < errorFilesList.length; i++) {
                            var documentTypeId = errorFilesList[i].documentTypeId;
                            var type = documentTypeId == 12 ? lang.get('type-markup') : lang.get('type-parent');
                            errorFilesList[i].docType = type;
                        }                                            
                        $scope.errorFile = errorFilesList;
                        $scope.isContinueDownload = false;
                        $scope.allFilesFail = true;
                        $scope.continueDownload = function() {
                            $uibModalInstance.close({ my: 'data' });                            
                            if (c_number == 1 ) {
                                api.submitForm({
                                    url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                                    _cdnUrl: myConfig.downloadServiceURL,
                                    param: dataJSON,
                                    target: '_self'
                                });
                                callback && callback();
                            } else {
                                var xhr = api.ajax({
                                    url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                                    _cdnUrl: myConfig.downloadServiceURL,
                                    data: dataJSON
                                });
                                xhr.then(function(data) {
                                    data.projectId = markUpData.projectId;
                                    data.url = markUpData.url;
                                    download.createZipFile(data, callback);
                                });
                            }
                        }
                        $scope.cancel = function() {
                            $uibModalInstance.dismiss();
                            callback && callback();
                        }
                    }
                    $uibModal.open({
                        animation: true,
                        templateUrl: 'includeMarkupError.html',
                        controller: childController,
                        backdrop: 'static',
                        keyboard: false,
                        resolve: {
                            errorFilesList: function() {
                                return errorFilesList;
                            }
                        }
                    });
                } else {
                    if (c_number == 1 ) {
                        api.submitForm({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            param: dataJSON,
                            target: '_self'
                        });
                        callback && callback();
                    } else {
                        var xhr = api.ajax({
                            url: apiConfig.DOWNLOAD_BATCH_DOCUMENT_WITH_MARKUPS_ACTION_CONTROLLER,
                            _cdnUrl: myConfig.downloadServiceURL,
                            data: dataJSON
                        });
                        xhr.then(function(data) {
                            data.projectId = markUpData.projectId;
                            data.url = markUpData.url;
                            download.createZipFile(data, callback);
                        });
                    }
                }
               
            }

        } else if (isEmbedQRCode && markupInvoke == markupQRCode) {
            Notification.clearAll();
            var childFailController = function($scope, $uibModalInstance, errorFilesList) {
                for (var i = 0; i < errorFilesList.length; i++) {
                    errorFilesList[i].errorCodeMessage = download.getErrorMessage(errorFilesList[i]);
                }
                $scope.errorFile = errorFilesList;
                $scope.isContinueDownload = true;
                $scope.allFilesFail = false;
                $scope.ok = function() {
                    $uibModalInstance.dismiss();
                    callback && callback();
                }
            }

            $uibModal.open({
                animation: true,
                templateUrl: 'myModalContent.html',
                controller: childFailController,
                backdrop: 'static',
                resolve: {
                    errorFilesList: function() {
                        return errorFilesList;
                    }
                }
            });
            callback && callback();
            return;
        } else {
            $timeout(function() {
                if(markupInvoke && markupInvoke.toLowerCase() == markupIncludeMarkup){
                    Notification.clearAll();
                    var childFailController = function($scope, $uibModalInstance) {                        
                        $scope.isContinueDownload = true;
                        $scope.allFilesFail = false;
                        $scope.ok = function() {
                            $uibModalInstance.dismiss();
                            callback && callback();
                        }
                    }        
                    $uibModal.open({
                        animation: true,
                        templateUrl: 'includeMarkupError.html',
                        controller: childFailController,
                        backdrop: 'static'
                    });
                    callback && callback();
                    return;
                } else {
                    var xhr = api.ajax({
                        url: apiConfig.PROGRESS_GENERATE_MARKUP_AS_PDF_CONTROLLER,
                        method: 'GET',
                        _cdnUrl: myConfig.downloadServiceURL,
                        params: {
                            projectID: markUpData.isMultiDCUKProjId ? markUpData.selectMultiDCUKProjId : markUpData.projectId,
                            markUpsProgressKey: markUpData.publishMarkupsProgressKey
                        }
                    });
                    xhr.then(function(data) {
                        $timeout(function() {
                            download.downloadIncludeMarkups(markUpData, { "markupsProgress": data.markupsProgress.toLowerCase(), "errorFiles": data.errorFiles, "c_number": data.c_number }, callback, isEmbedQRCode);
                        },3000);
                    });
                }                
            }, 500);
        }
    };
    var zipProgress = {};
    download.createZipFile = function(zipData, callback) {
        if (!zipProgress[zipData.fileName]) {
            zipProgress[zipData.fileName] = {};
            Notification.clearAll();
            // progreess bar made here with the same div used while viewing file and form.
            Notification({
                message: '<div id="notification-progress" class="page-progress" style="position:relative"><div class="progress"></div></div>',
                delay: false
            });
        }

        var paramObj = {
            action_id: apiConfig.PROGRESS_ZIP_CREATION,
            zipFile: zipData.fileName
        }

        !zipData.isMultiDCUKProjId && (paramObj.projectID = zipData.projectId);

        var apiOptions = {
            url: zipData.url || apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER,
            method: 'GET',
            _cdnUrl: myConfig.downloadServiceURL,
            params: paramObj
        };
        if(zipData.url && zipData.url.indexOf(apiConfig.PUBLIC_DOWNLOAD_CONTROLLER) === 0) {
            apiOptions = {
                url: zipData.url,
                data: paramObj
            };
        }
        var xhr = api.ajax(apiOptions);

        zipProgress[zipData.fileName].xhr = xhr;
        if (zipProgress[zipData.fileName].c_number === undefined) {
            zipProgress[zipData.fileName].progress = 0;
            zipProgress[zipData.fileName].c_number = 0;
        }

        xhr.then(function(data) {
            if (data.c_number == '-1') {
                var param = {
                    c_number: data.c_number,
                    project_id: zipData.isMultiDCUKProjId ? zipData.selectMultiDCUKProjId : zipData.projectId,
                    count: zipData.count,
                    destPath: zipData.destPath,
                    fileName: zipData.fileName,
                    isExtract: data.isExtract,
                    isForDirectLink: zipData.isFromDirectLink,
                    isFromMultiDCBatch: zipData.isFromMultiDCBatch || false
                };

                Notification.clearAll();

                if (myConfig.applicationId == 2) {
                    param.action_id = apiConfig.DOWNLOAD_TEMP_ZIP_FILE;
                    qtObject.sameDcMultiFilesDownload(JSON.stringify(param), "");
                    callback && callback();
                    delete zipProgress[zipData.fileName];
                    return;
                }

                callback && callback();
                delete zipProgress[zipData.fileName];
                api.submitForm({
                    url: zipData.actionUrl || apiConfig.DOWNLOAD_TEMP_ZIP_FILE_CONTROLLER,
                    param: param,
                    method: 'GET',
                    _cdnUrl: myConfig.downloadServiceURL,
                    target: '_self'
                });
            } else {
                zipProgress[zipData.fileName].c_number = data.c_number;
                if (data.c_number > 0) {
                    zipProgress[zipData.fileName].progress = data.c_number;
                }
                zipProgress[zipData.fileName].timeout = $timeout(function() {
                    download.createZipFile(zipData, callback);
                }, 2000);
            }
        }, function(xhr) {
            Notification.clearAll();
            if (xhr.status != -1) {
                zipProgress[zipData.fileName].status = lang.get("failed");
                $window.alert(lang.get("download-failed"));
                callback && callback();
            } else {
                zipProgress[zipData.fileName].xhr = false;
                zipProgress[zipData.fileName].status = lang.get("aborted");
            }
        });
    };

    download.cancelZipProgress = function(fileName) {
        // abort request
        var xhr = zipProgress[fileName].xhr;
        xhr && xhr.abort();

        // cancel timeout
        $timeout.cancel(zipProgress[fileName].timeout);
    };
}])


/**
 * api service.
 * This module will provide XMLHttpRequest service.
 * @module api
 */
.service('api', ['$http', '$window', '$q', '$timeout', 'lang', 'myConfig', 'apiConfig', 'Notification', 'manageDataCenter', '$uibModal', function($http, $window, $q, $timeout, lang, myConfig, apiConfig, Notification, manageDataCenter, $uibModal) {
    /**
     * For all the http calls.
     * @alias module:Api/Ajax
     */

    var api = this;

    api.linkify = function(msg) {
        if (!msg) return "";

        var replacedText = msg,
          replacePattern1,
          replacePattern2,
          replacePattern3;

        //Change email addresses to mailto:: links.
        replacePattern3 = /(([a-zA-Z0-9\-\_\.])+@[a-zA-Z\_]+?(\.[a-zA-Z]{2,6})+)/gim;
        replacedText = replacedText.replace(
          replacePattern3,
          '<a href="mailto:$1">$1</a>'
        );

        //URLs starting with http://, https://, or ftp://
        replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#$\/%?=~_|!:,.;]*[-A-Z0-9+&@#$\/%=~_|$])/gim;
        replacedText = replacedText.replace(
          replacePattern1,
          '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
    
        //URLs starting with "www." (without // before it, or it'd re-link the ones done above).
        replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
        replacedText = replacedText.replace(
          replacePattern2,
          '$1<a href="http://$2" target="_blank" rel="noopener noreferrer">$2</a>'
        );

        return replacedText;
    };

    api.isIE = function() {
        return ((navigator.userAgent.indexOf(".NET CLR") > -1) || (navigator.userAgent.indexOf("MSIE") > -1) ||
            !!navigator.userAgent.match(/Trident\//) || !!navigator.userAgent.match(/Edge\//));
    };

    api.isIE9 = function() {
        return (navigator.userAgent.indexOf('MSIE 9') > -1 || !$window.FormData);
    };

    api.escapeAmp = function(str) {
        if (!str || typeof str !== 'string') {
            return "";
        }
        return str.replace(/&/g, '&amp;');
    };

    api.isMobile = function() {
        var check = false;
        (function(a) {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
                check = true;
        })(navigator.userAgent || navigator.vendor || window.opera);
        if (myConfig.applicationId == 3 && navigator.platform == 'MacIntel') {
            check = true;
        }
        return check;
    };

    api.isNavigator = function() {
        return (myConfig.applicationId == 2);
    };

    api.openHelpPage = function(opt) {
        var isCustomTextApplied = window['INIT_JSP_GLOBAL']['isCustomTextApplied']
        var editionId = window['INIT_JSP_GLOBAL']['editionId']

        var strUrl = (opt.rootPath || "") + (opt.contentfolder || apiConfig.HELP_FILE_CONTENT) + myConfig.userLanguage + (isCustomTextApplied ? "_" + editionId : "") + "/" + opt.name + ".htm";
        var $helpContent = $('#help-content');
        $helpContent.load(strUrl, function() {
            $helpContent.removeClass("close").addClass("open");
            $helpContent.find('.elearning-url').attr('href', apiConfig.VIEW_ELEARNING);
        });
    };

    api.sendEventToIpad = function(strEvent) {
        var iframe = document.createElement("IFRAME");
        iframe.setAttribute("src", "js-frame:" + strEvent);
        document.documentElement.appendChild(iframe);
        iframe.parentNode.removeChild(iframe);
        iframe = null;
    };

    api.setScrollTopPos = function(elem, posVal) {
        elem.scrollTop = posVal;
    };

    api.sendMail = function(content) {
        if (api.isIE()) {
            var iframe = angular.element('<iframe id="iframeTempMailTo" src="' + content + '" width="0" height="0" >');
            angular.element("body").append(iframe);
            iframe.remove();
        } else {
            $window.location.href = content;
        }
    };

    api.getUrlByDcId = function(dcId) {
        return manageDataCenter.getUrl(dcId || apiConfig.LOCAL_DC_ID);
    };

    // Store action id wise resolve method.
    var offlineActionWiseResolveList = [];

    api.ajax = function(obj) {

        // Use in offline Html5 form.
        if (myConfig.isOfflineMode) {
            // use  js-frame in the offline html5Form.
            api.sendEventToIpad(angular.toJson(obj));

            var actionID = obj.data.action_id;

            // Unique action id pass.
            //Same actionid(1722) pass in files,discussions and apps column listing;
            if (actionID == apiConfig.GET_USER_SELECTED_COLUMNS) {
                //Pass id with type
                actionID = actionID + "_" + obj.data.type;
            } else if (actionID == apiConfig.GET_ATTACHMENT_AND_ASSOCIATIONS) {
                //Pass actionID with requestedEntityType(Views/Lists/All)
                actionID = actionID + "_" + obj.data.requestedEntityType;
            } else if(actionID == apiConfig.GET_USER_APPLICATION_PRIVILEGES){
                obj.data.type && (actionID = actionID + "_" +  obj.data.type);
            }
            return new Promise(function(resolve) {
                // Store action id wise resolve method.
                offlineActionWiseResolveList[actionID] = resolve;

                //Invoke on Mobile side callback method.
                window.offlineModeCallback = function(data) {
                    //Set response data
                    var resData = "";
                    var actionId = data.actionId;
                    var actionIds = [apiConfig.INITIATE_CREATE_ORI_MSG, apiConfig.CHECK_EDIT_ORI_DRAFT_MESSAGE, apiConfig.INITIATE_EDIT_FORM_MSG_COMMITED, apiConfig.INITIATE_CREATE_RES_MSG, apiConfig.INITIATE_CREATE_FWD_MSG, apiConfig.SUBMIT_FORM_CHANGE_STATUS, apiConfig.COMPLETE_FOR_ACTION, apiConfig.COMPLETE_FOR_ACKNOWLEDGEMENT_ACTION]; 
                    if (actionIds.indexOf(data.actionId) != -1 ) {
                        resData = data.responseData; //In response URL pass.
                    } else if (data.actionId == apiConfig.GET_USER_SELECTED_COLUMNS) {
                        actionId = data.actionId + "_" + data.type;
                        resData = data;
                    } else if (data.actionId == apiConfig.GET_ATTACHMENT_AND_ASSOCIATIONS) {
                        actionId = data.actionId + "_" + data.requestedEntityType;
                        resData = JSON.parse(data.responseData);
                    }else if (data.actionId == apiConfig.GET_USER_APPLICATION_PRIVILEGES) {
                        data.type && (actionId = data.actionId + "_" + data.type);
                        resData = JSON.parse(data.responseData);
                    } else {
                        resData = JSON.parse(data.responseData);
                    }

                    //Resolve method call
                    offlineActionWiseResolveList[actionId] && offlineActionWiseResolveList[actionId](resData);
                    $timeout(function() {
                        try{
                            $scope.$apply();
                        } catch(e){}                       
                    });
                }
            });
        } else {
            var deferred = $q.defer();

            if(obj.url.indexOf('http') !== 0) {
                if (obj._dcId) {
                    obj.url = manageDataCenter.getUrl(obj._dcId, obj._cdnUrl) + obj.url;
                    delete obj._dcId;
                    delete obj._cdnUrl;
                }

                if (obj._cdnUrl && !obj._dcId) {
                    obj.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, obj._cdnUrl) + obj.url;
                    delete obj._cdnUrl;
                }
            }

            if (obj.method && obj.method.toLowerCase() == 'get') {
                if (obj.url.indexOf('?') == -1) {
                    obj.url += '?t=' + Date.now();
                } else {
                    obj.url += '&t=' + Date.now();
                }
            }

            var defOptions = {
                method: 'POST',
                dataType: 'json',
                cache: false,
                withCredentials: true,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                transformRequest: function(obj) {
                    if (typeof obj === 'string') {
                        return obj;
                    }

                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));

                    return str.join("&");
                },
                timeout: deferred.promise
            };

            if(obj.responseType === 'text' || obj.dataType === 'text') {
                defOptions.transformResponse = function(data, headersGetter, status) {
                    return "" + data;
                }
            }

            if (obj.ApiKey) {
                defOptions.headers["ApiKey"] = obj.ApiKey;
            }

            if (obj.aSessionID) {
                defOptions.headers["ASessionID"] = obj.aSessionID;
            }
            obj = angular.extend(defOptions, obj);

            var unauthorisedRedirect = function(response) {
                if (!response || !angular.isString(response.data)) {
                    return;
                }
                response = response.data;
                if (response.indexOf('Unauthorised Access') > -1) {
                    angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "unauthorised";
                    return false;
                }
                if (response.indexOf('Session Timed Out') > -1) {
                    api.setSessionState('sessionState', 'Inactive');
                    api.openLoginModal();
                    /* angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "session-timed-out";			 */
                    return false;
                }
                if (response.indexOf('Session Overriden') > -1) {
                    angular.element('body').hide();
                    top.location.href = myConfig.adoddleSystemWebURL + "session-overriden";
                    return false;
                }
            };

            var request = $http(obj);

            var promise = request.then(
                function(response) {
                    unauthorisedRedirect(response);
                    if (obj.url.indexOf(apiConfig.GET_SESSION_TIMEOUT_DETAILS) == -1) {
                        api.setsessionTimoutTimer();
                    }
                    return (response.data);
                },
                function(response) {
                    unauthorisedRedirect(response);
                    if (obj.url.indexOf(apiConfig.GET_SESSION_TIMEOUT_DETAILS) == -1) {
                        api.setsessionTimoutTimer();
                    }
                    api.showServerErrorCode(response)
                    return ($q.reject(response));
                }
            );

            promise.abort = function() {
                deferred.resolve();
            };

            promise['finally'](function() {
                promise.abort = angular.noop;
                deferred = request = promise = null;
            });

            return promise;
        }




    };

    api.showServerErrorCode = function(err) {
        let contentType = err.headers('Content-Type');
        if (!contentType || !err.data){
            return;
        }
        let errorCode;
        if (contentType.startsWith('text/html')) {
          errorCode = window['$'](err.data).find("#errorCode").text().replace(/[\n\r\s]+/g, '')
        } else {
          errorCode = err.data.errorCode;
        }
        if (!errorCode){
         return;
        }
        
        Notification.error({
            title: 'Technical Information (for support personnel)',
            message: '<div class="text-large">' + 'Error code: '+ errorCode + '<a href="javascript:;"'+' style="color: #fff; text-decoration: underline; margin-left: 20px;" onclick="copyErrorCodeClicked()" '+'">' +'Copy'+
            '</a></div>',
            delay: 150000
        });

        window['copyErrorCodeClicked']= function() {
            window.prompt(Language.get("copy-to-clipboard"), errorCode);
        }
    };

    api.setLocalStorageIframs = function() {
        try {
            if (myConfig.isPagePublic) {
                return;
            }
            angular.element('body').find('.local-storage-iframe').remove();
            var urls = [];
            var userAccessibleDCIds = window['USP'] && window['USP'].userAccessibleDCIds || [];

            for (var i = userAccessibleDCIds.length - 1; i >= 0; i--) {
                urls.push({
                    pathNeeded: true,
                    url: manageDataCenter.getUrl(userAccessibleDCIds[i])
                });
                if (window['adoddleAppEngineURL'] && userAccessibleDCIds[i] != 1) {
                    urls.push({
                        pathNeeded: false,
                        url: manageDataCenter.getUrl(userAccessibleDCIds[i], window['adoddleAppEngineURL'].replace('.com/appbuilder', '.com/localStorage'))
                    });
                } else {
                    urls.push({
                        pathNeeded: false,
                        url: window['adoddleAppEngineURL'].replace('.com/appbuilder', '.com/localStorage')
                    });
                }
            }
            for (var i = 0; i < urls.length; i++) {
                var iframe = document.createElement('iframe');
                iframe.style.display = 'none';
                document.body.appendChild(iframe);
                iframe.classList.add('local-storage-iframe');
                iframe.src = urls[i].url + (urls[i].pathNeeded ? apiConfig.LOCAL_STORAGE : '');
            }
        } catch (e) {}
    }

    api.loadLocalStorageIFrame = function() {
        //This functionality is not supported in offline html5 form.
        if (!myConfig.isOfflineMode) {
            api.setLocalStorageIframs();
        }
    }

    api.setSessionState = function(name, value) {
        try {
            localStorage.setItem(name, value);
            var iframeEls = document.getElementsByClassName('local-storage-iframe');
            if (!iframeEls.length) {
                return;
            }
            for (var i = 0; i < iframeEls.length; i++) {
                iframeEls[i].contentWindow.postMessage(JSON.stringify({
                    name: name,
                    value: value,
                    sessionState: true
                }), '*');
            }
        } catch (e) {
            localStorage.setItem(name, value);
        }
    };

    window['setSessionState'] = function(name, value) {
        api.setSessionState(name, value);
    };

    var timer;
    api.setsessionTimoutTimer = function(duration) {
        if (myConfig.isPagePublic) {
            return;
        }
        var appId = myConfig.applicationId || window.applicationId || 1;
        if (appId != 1) {
            return;
        }
        // Return when SSO login
        if (window['USP'] && window['USP'].loginMethodType === 2) {
            return;
        }
        timer && clearTimeout(timer);
        if (duration && parseFloat(duration) > 0) {
            timer = setTimeout(api.checkSessionTimeout, parseFloat(duration) * 60000);
        } else if (parseFloat(myConfig.USP.sessionTimeoutDuration) > 0) {
            timer = setTimeout(api.checkSessionTimeout, parseFloat(myConfig.USP.sessionTimeoutDuration) * 60000);
        }
    };

    api.checkSessionTimeout = function() {
        api.ajax({
            url: apiConfig.GET_SESSION_TIMEOUT_DETAILS,
            data: {},
            method: 'GET'
        }).then(function(data) {
            api.setSessionState('sessionState', !data.timeout ? 'Active' : 'Inactive');
            if (data.timeout) {
                api.openLoginModal();
            } else {
                api.setsessionTimoutTimer(parseFloat(data.remainingMilliSecond) / 60000);
            }
        }, function(xhr) {
            if (!navigator.onLine) {
                api.setsessionTimoutTimer(parseFloat('10000') / 60000);
            }
        });
    };

    api.setsessionTimoutTimer();

    var loginPopup;
    api.openLoginModal = function() {
        if (loginPopup || window.top != window) {
            return;
        }
        // Return when SSO login
        if (window['USP'] && window['USP'].loginMethodType === 2) {
            return;
        }
        loginPopup = $uibModal.open({
            component: 'login',
            keyboard: false,
            backdrop: 'static',
            windowClass: 'login-modal',
            backdropClass: 'login-backdrop'
        });
        loginPopup.closed.then(function() {
            loginPopup = '';
        });
    };

    var confirmModel;
    api.openConfirmBox = function(options) {
        confirmModel = $uibModal.open({
            windowClass: "confirm-popup",
            backdropClass: 'confirm-backdrop',
            template: "<div class='dialog-ovelay'>" +
                "<div class='dialog'><header>" +
                " <h3> {{ $ctrlConfirmModel.options.title}} </h3> " +
                "</header>" +
                "<div class='dialog-msg'>" +
                " <p> {{ $ctrlConfirmModel.options.msg}} </p> " +
                "</div>" +
                "<footer>" +
                "<div class='controls'>" +
                " <button class='btn btn-danger' ng-click='$ctrlConfirmModel.callback()'>" + lang.get('ok') + "</button> " +
                " <button class='btn btn-default' ng-click='$ctrlConfirmModel.closePopup()'>" + lang.get('cancel') + "</button> " +
                "</div>" +
                "</footer>" +
                "</div>" +
                "</div>",
            controllerAs: '$ctrlConfirmModel',
            controller: function () {
                this.options = options;

                this.callback = function() {
                    confirmModel.dismiss('cancel');
                    if(this.options.callback) {
                        this.options.callback();
                    } else if (this.options.targetFrame) {
                        this.options.targetFrame.postMessage('openConfirmation:confirmed');
                    }
                }

                this.closePopup = function() {
                    confirmModel.dismiss('cancel');
                }
            },
            keyboard: false,
            backdrop: 'static',
        });
        confirmModel.closed.then(function() {
            confirmModel = '';
        });
    }

    window['openLoginModal'] = function() {
        api.openLoginModal();
    };

    api.uniqById = function(collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function(item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };

    api.parseStr = function(s, o, re) {
        var that = this;
        re = re || (/\{\s*([^\|\}]+?)\s*(?:\|([^\}]*))?\s*\}/g);
        return ((s.replace) ? s.replace(re, function(match, key) {
            return (o[key] !== undefined || o[key] !== null) ? o[key] : match;
        }) : s);
    };

    api.getParamObj = function(win) {
        win = win || $window;
        var href = win.location.href;
        var search = href.split('?')[1];
        var obj = {};

        if (!search) {
            return obj;
        }

        var paramArray = search.split('&');
        for (var i = 0; i < paramArray.length; i++) {
            var param = paramArray[i].split('=');
            obj[param[0]] = param[1];
        }

        return obj;
    };

    api.getLastModifiedProfileTime = function(imagepath) {
        if (!imagepath) {
            return '0';
        }
        var lastModiPicDate = imagepath.split('?')[1] || '';
        lastModiPicDate = lastModiPicDate.split('&')[0] || '';
        var lastModiPicDateArray = lastModiPicDate.split('=');
        if (lastModiPicDateArray[0] && lastModiPicDateArray[0] == 'v') {
            lastModiPicDate = lastModiPicDateArray[1] || '';
            lastModiPicDate = lastModiPicDate.split('#')[0] || '';
        } else {
            lastModiPicDate = '0';
        }

        return lastModiPicDate;
    };

    /**
     * language specific days and month names
     */
    api.getCalendarNames = function() {
        return {
            'DAY_NAMES_SHORTEST': lang.get("abbr-sort-day-name-array").split(','), // "Su,Mo,Tu,We,Th,Fr,Sa"
            'DAY_NAMES_SHORT': lang.get("abbr-day-name-array").split(','), // "Sun,Mon,Tue,Wed,Thu,Fri,Sat"
            'DAY_NAMES': lang.get("day-name-array").split(','), // "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday"
            'MONTH_NAMES_SHORT': lang.get("abbr-month-array").split(','), // "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec"
            'MONTH_NAMES': lang.get("month-array").split(',') // "January,February,March,April,May,June,July,August,September,October,November,December"
        };
    };

    /**
     * date utilities
     */
    var _ticksTo1970 = (((1970 - 1) * 365 + Math.floor(1970 / 4) - Math.floor(1970 / 100) + Math.floor(1970 / 400)) * 24 * 60 * 60 * 10000000);
    api.getDuration = function(date) {
        if (!date) {
            return '';
        }

        var todayUTCSplit = new Date().toUTCString().split(" ")[4].split(":");
        var now = new Date();
        var timezoneOffset = 19800000;
        var utcDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        utcDate.setHours(parseInt(todayUTCSplit[0]) + (myConfig.timezoneOffset / (3600 * 1000)), todayUTCSplit[1], todayUTCSplit[2]);

        var dueDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        dueDate.setHours(23, 59, 00, 00);

        var dmili = dueDate.getTime();
        var tmili = utcDate.getTime();
        var diff = dmili - tmili;

        var diff_days = parseInt(diff / (24 * 60 * 60 * 1000)); // in days
        var diff_hours = parseInt(diff / (60 * 60 * 1000)); // in hours

        if (diff_hours > 23)
            return (diff_days + ' d');
        else
            return (diff_hours + ' h');
    };

    // Format a number, with leading zero if necessary
    api.addZero = function(value) {
        var num = "" + value;
        if (num.length < 10) {
            num = "0" + num;
        }
        return num;
    };

    api.formatDate = function(format, date) {
        if (!date) {
            return "";
        }

        var iFormat,
            nameMap = api.getCalendarNames(),
            dayNamesShort = nameMap.DAY_NAMES_SHORT,
            dayNames = nameMap.DAY_NAMES,
            monthNamesShort = nameMap.MONTH_NAMES_SHORT,
            monthNames = nameMap.MONTH_NAMES,

            // Check whether a format character is doubled
            lookAhead = function(match) {
                var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) === match);
                if (matches) {
                    iFormat++;
                }
                return matches;
            },
            formatNumber = function(match, value, len) {
                var num = "" + value;
                if (lookAhead(match)) {
                    while (num.length < len) {
                        num = "0" + num;
                    }
                }
                return num;
            },
            // Format a name, short or long as requested
            formatName = function(match, value, shortNames, longNames) {
                return (lookAhead(match) ? longNames[value] : shortNames[value]);
            },
            output = "",
            literal = false;

        if (date) {
            for (iFormat = 0; iFormat < format.length; iFormat++) {
                if (literal) {
                    if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
                        literal = false;
                    } else {
                        output += format.charAt(iFormat);
                    }
                } else {
                    switch (format.charAt(iFormat)) {
                        case "d":
                            output += formatNumber("d", date.getDate(), 2);
                            break;
                        case "D":
                            output += formatName("D", date.getDay(), dayNamesShort, dayNames);
                            break;
                        case "o":
                            output += formatNumber("o",
                                Math.round((new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000), 3);
                            break;
                        case "m":
                            output += formatNumber("m", date.getMonth() + 1, 2);
                            break;
                        case "M":
                            output += formatName("M", date.getMonth(), monthNamesShort, monthNames);
                            break;
                        case "y":
                            output += (lookAhead("y") ? date.getFullYear() :
                                (date.getYear() % 100 < 10 ? "0" : "") + date.getYear() % 100);
                            break;
                        case "t":
                            output += (date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
                            break;
                        case "p":
                            output += api.getDuration(date);
                            break;
                        case "@":
                            output += date.getTime();
                            break;
                        case "!":
                            output += date.getTime() * 10000 + _ticksTo1970;
                            break;
                        case "'":
                            if (lookAhead("'")) {
                                output += "'";
                            } else {
                                literal = true;
                            }
                            break;
                        default:
                            output += format.charAt(iFormat);
                    }
                }
            }
        }
        return output;
    };

    api.parseDate = function(format, value) {
        if (format == null || value == null) {
            throw lang.get("invalid-arguments");
        }

        value = (typeof value === "object" ? value.toString() : value + "");
        if (value === "") {
            return null;
        }

        var iFormat, dim, extra,
            iValue = 0,
            shortYearCutoff = 26,
            nameMap = api.getCalendarNames(),
            dayNamesShort = nameMap.DAY_NAMES_SHORT,
            dayNames = nameMap.DAY_NAMES,
            monthNamesShort = nameMap.MONTH_NAMES_SHORT,
            monthNames = nameMap.MONTH_NAMES,
            year = -1,
            time = -1,
            month = -1,
            day = -1,
            doy = -1,
            literal = false,
            date,
            // Check whether a format character is doubled
            lookAhead = function(match) {
                var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) === match);
                if (matches) {
                    iFormat++;
                }
                return matches;
            },
            // Extract a number from the string value
            getNumber = function(match) {
                var isDoubled = lookAhead(match),
                    size = (match === "@" ? 14 : (match === "!" ? 20 :
                        (match === "y" && isDoubled ? 4 : (match === "o" ? 3 : 2)))),
                    minSize = (match === "y" ? size : 1),
                    digits = new RegExp("^\\d{" + minSize + "," + size + "}");

                if (match === "t") {
                    num = value.substring(iValue).match(new RegExp("^\\d{1,2}:\\d{1,2}:\\d{1,2}"));
                } else {
                    num = value.substring(iValue).match(new RegExp("^\\d{" + minSize + "," + size + "}"));
                }
                if (!num) {
                    throw lang.get("missing-number-at-position") + iValue;
                }

                iValue += num[0].length;
                if (match === "t") {
                    return num[0];
                }

                return parseInt(num[0], 10);
            },
            // Extract a name from the string value and convert to an index
            getName = function(match, shortNames, longNames) {
                var index = -1,
                    names = $.map(lookAhead(match) ? longNames : shortNames, function(v, k) {
                        return [
                            [k, v]
                        ];
                    }).sort(function(a, b) {
                        return -(a[1].length - b[1].length);
                    });

                $.each(names, function(i, pair) {
                    var name = pair[1];
                    if (value.substr(iValue, name.length).toLowerCase() === name.toLowerCase()) {
                        index = pair[0];
                        iValue += name.length;
                        return false;
                    }
                });
                if (index !== -1) {
                    return index + 1;
                } else {
                    throw lang.get("unknown-name-at-position") + iValue;
                }
            },
            // Confirm that a literal character matches the string value
            checkLiteral = function() {
                if (value.charAt(iValue) !== format.charAt(iFormat)) {
                    throw lang.get("unexpected-literal-at-position") + iValue;
                }
                iValue++;
            };

        for (iFormat = 0; iFormat < format.length; iFormat++) {
            if (literal) {
                if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
                    literal = false;
                } else {
                    checkLiteral();
                }
            } else {
                switch (format.charAt(iFormat)) {
                    case "d":
                        day = getNumber("d");
                        break;
                    case "D":
                        getName("D", dayNamesShort, dayNames);
                        break;
                    case "o":
                        doy = getNumber("o");
                        break;
                    case "m":
                        month = getNumber("m");
                        break;
                    case "M":
                        month = getName("M", monthNamesShort, monthNames);
                        break;
                    case "y":
                        year = getNumber("y");
                        break;
                    case "t":
                        time = getNumber("t");
                        break;
                    case "@":
                        date = new Date(getNumber("@"));
                        year = date.getFullYear();
                        month = date.getMonth() + 1;
                        day = date.getDate();
                        break;
                    case "!":
                        date = new Date((getNumber("!") - _ticksTo1970) / 10000);
                        year = date.getFullYear();
                        month = date.getMonth() + 1;
                        day = date.getDate();
                        break;
                    case "'":
                        if (lookAhead("'")) {
                            checkLiteral();
                        } else {
                            literal = true;
                        }
                        break;
                    default:
                        checkLiteral();
                }
            }
        }

        if (iValue < value.length) {
            extra = value.substr(iValue);
            if (!/^\s+/.test(extra)) {
                throw lang.get("extra-unparsed-char-in-date") + extra;
            }
        }

        if (year === -1) {
            year = new Date().getFullYear();
        } else if (year < 100) {
            year += new Date().getFullYear() - new Date().getFullYear() % 100 +
                (year <= shortYearCutoff ? 0 : -100);
        }

        var _daylightSavingAdjust = function(date) {
            if (!date) {
                return null;
            }
            date.setHours(date.getHours() > 12 ? date.getHours() + 2 : 0);
            return date;
        };

        var _getDaysInMonth = function(year, month) {
            return 32 - _daylightSavingAdjust(new Date(year, month, 32)).getDate();
        };

        if (doy > -1) {
            month = 1;
            day = doy;
            do {
                dim = _getDaysInMonth(year, month - 1);
                if (day <= dim) {
                    break;
                }
                month++;
                day -= dim;
            } while (true);
        }

        date = _daylightSavingAdjust(new Date(year, month - 1, day));
        if (date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) {
            throw lang.get("invalid-date"); // E.g. 31/02/00
        }

        if (time !== -1) {
            var timeSplit = time.split(':');
            date.setHours(timeSplit[0]);
            date.setMinutes(timeSplit[1]);
            date.setSeconds(timeSplit[2]);
        }

        return date;
    };

    api.tryToParseDate = function(value, format) {
        var possibleFormat = ['yy-mm-dd', 'yy/mm/dd', 'dd/mm/yy', 'dd-mm-yy',
            'yy-m-d', 'yy/m/d', 'd/m/yy', 'd-m-yy',
            'y-mm-dd', 'y/mm/dd', 'dd/mm/y', 'dd-mm-y',
            'y/m/d', 'y/m/d', 'd/m/y', 'd-m-y'
        ];

        var date = undefined;
        for (var i = 0; i < possibleFormat.length; i++) {
            var dateFormat = possibleFormat[i];
            if (!format || dateFormat != format) {
                try {
                    date = api.parseDate(dateFormat, value);
                    return date;
                } catch (e) {
                    continue;
                }
            }
        }

        if (!date)
            return value;
    };

    /**
     * fallback function to copy the text for earlier browsers 
     */
    var language = lang.getLangObj();
    api.copyToClipboard = function(e, text) {
        $window.prompt(language["copy-to-clipboard"], text);
    };

    api.hasAccess = function(str, key) {
        if (!str) {
            return false;
        }

        return (str.indexOf("," + apiConfig[key] + ",") > -1)
    };

    api.hasFolderPermission = function(
        folderPermissionValues,
        folderId,
        key
    ){
        folderId = folderId.split("$$")[0];
        return folderPermissionValues[folderId] == apiConfig.folderPermission[key];
    }

    api.hasFolderUploadPermission = function(permissionData, folderId) {
        return (api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_ADMIN_PERMISSION') ||
        api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_PUBLISH_AND_LINK_PERMISSION') ||
        api.hasFolderPermission(permissionData.folderPermissionValues, folderId, 'FOLDER_PUBLISH_PERMISSION'));
    };

    api.hasPermissionToCheckoutFile = function(selectedRows, permissionsData) {
        var isEnableCheckout = true;

        selectedRows.some(function(row) {
            var permissionValue = permissionsData.folderPermissionValues[row.folderId.split("$$")[0]];
            if ( row.isLink || row.is_link || row.documentTypeId == apiConfig.DOC_TYPE_ID.PLACEHOLDER || row.checkOutStatus || permissionValue === apiConfig.folderPermission.VIEW_ONLY || !api.hasFolderUploadPermission(permissionsData, row.folderId)) {
                isEnableCheckout = false;
                return true;
            }
        });
        return isEnableCheckout;
    };

    api.isLocked = function(str, key) {
        if (!str) {
            return false;
        }
        return (str.indexOf(apiConfig.ACTIVITY_CONSTANT[key]) > -1)
    };

    api.submitDownloadForm = function(option) {
        
        $("#downloadFrame").remove();
        var $iframe = $('<iframe src="" id="downloadFrame" name="downloadFrame" style="width: 0px;height:0px;border: 0px;"></iframe>');
        var form = document.createElement('form');

        form.target = "downloadFrame";

        if (option.param)
            option.param.applicationId = myConfig.applicationId;

        if(option.url.indexOf('http') !== 0) {

            if (option._dcId) {
                option.url = manageDataCenter.getUrl(option._dcId, option._cdnUrl) + option.url;
                delete option._dcId;
                delete option._cdnUrl;
            }

            if (option._cdnUrl && !option._dcId) {
                option.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, option._cdnUrl) + option.url;
                delete option._cdnUrl;
            }
        }


        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }


        document.body.appendChild(form);
        document.body.appendChild($iframe);
        form.submit();
        angular.element(form).remove();
    };

    api.submitForm = function(option) {
        var form = document.createElement('form');

        var target = option.target || '_blank';
        if (api.isNavigator())
            target = '_self';

        form.target = target;

        if (option.param) {
            if (myConfig.applicationId) {
                option.param.applicationId = myConfig.applicationId;
            } else {
                option.param.applicationId = applicationId;
            }
        }

        if(option.url.indexOf('http') !== 0) {

            if (option._dcId) {
                option.url = manageDataCenter.getUrl(option._dcId, option._cdnUrl, option.non_edgeCast) + option.url;
                delete option._dcId;
                delete option._cdnUrl;
            }

            if (option._cdnUrl && !option._dcId) {
                option.url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, option._cdnUrl) + option.url;
                delete option._cdnUrl;
            }
        }


        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
        angular.element(form).remove();
    };

    api.fileViewForMobile = function(option, headerHide) {

        if (myConfig.applicationId !== 3) {
            return;
        }

        try{
            localStorage.setItem('appStaticContentVersion', window.staticContentVersion);
        } catch(err){}

        if (option.param) {
            option.param.applicationId = 3;
            option.param.ios = true;
            option.param.isAndroid = true;
            option.param.isNewUI = true;
        }

        var $fileViewPort = angular.element("#fileViewPort");
        $fileViewPort.removeClass("close").addClass("open");


        $fileViewPort.find("button.close")[0].onclick = function(e) {
            $fileViewPort.removeClass("open").addClass("close");
        };

        $("#msgWindow").remove();
        var form = document.createElement('form');
        angular.element("#fileViewPortBody").append('<iframe id="msgWindow" name="msgWindow" style="width:100%; height:100%; border: none; background: white;" ></iframe>');
        form.target = "msgWindow";
        $fileViewPort.find("div.modal-header").hide();

        //form.target = option.target || '_blank';

        if (option._dcId) {
            option.url = manageDataCenter.getUrl(option._dcId) + option.url;
            delete option._dcId;
        }

        form.action = option.url;
        form.method = option.method || 'POST';

        for (var name in option.param) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = option.param[name];
            form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
        angular.element(form).remove();
    };

    /**
     * Fetch custom object template list
     * @param {fn} callback
     * @param {string} projectId
     */
    api.getCustomObjectTemplateList = function(callback, customObjectContextId, projectId) {
        var customObjectTemplates = api.ajax({
            url: apiConfig.GET_CUSTOM_OBJECT_TEMPLATE_LIST,
            data: {
                customObject: JSON.stringify({
                    projectId: projectId || myConfig.projectId,
                    customObjectContextId: customObjectContextId,
                    description: "",
                    type: "text",
                    enabled: true
                })
            }
        });

        customObjectTemplates.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert('Error while fetching Custom templates!');
        });

        return customObjectTemplates;
    };

    /**
     * fetch the permission for view form
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var viewPermission = undefined;
    api.getViewPermission = function(callback, refresh, projectId, offlineType) {

        var then = function() {
            viewPermission.then(function(data) {
                viewPermission = data;
                callback && callback(data);
            }, function(xhr) {
                $window.alert(lang.get("permission-check-failed"));
            });
        }

        if (!refresh && viewPermission) {
            if (myConfig.isOfflineMode || viewPermission.abort) {
                then();
            } else {
                callback && callback(viewPermission);
            }
            return;
        }

        viewPermission = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_USER_APPLICATION_PRIVILEGES,
                projectId: projectId || myConfig.projectId,
                type: myConfig.isOfflineMode ? offlineType : undefined
            }
        });

        then();
    };

    api.getUserSharePermission = function(objectId, objectTypeId, callback) {
        var permissionChecker = api.ajax({
            url: window.asiteWorksServiceURL + apiConfig.GET_USER_SHARE_PERMISSION,
            aSessionID: window['USP']['aSessionId'],
            data: {
                projectId: myConfig.projectId,
                objectId: objectId,
                objectTypeId: objectTypeId
            }
        });

        permissionChecker.then(function(permissionData) {
            var filterForCommentAndViewFile = permissionData.asiteworksFeatureConfig.filter(
                function(data){
                    return data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE || 
                        data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT || 
                        data.operationId === apiConfig.ADRIVE_FILE_PERMISSION.DOWNLOAD_FILE;
                }
            );
            
            //Set permission based on other parameter if asite works feature config is empty
            if(!filterForCommentAndViewFile.length) {
                filterForCommentAndViewFile.push({
                    operationId: apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE,
                    isAllowed: permissionData.isOwner || permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.NONE
                });
                filterForCommentAndViewFile.push({
                    operationId: apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT,
                    isAllowed: permissionData.isOwner || (permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.VIEWER && permissionData.permissionTypeId != apiConfig.SHARE_PERMISSION.NONE)
                });
            }
   
            callback && callback(filterForCommentAndViewFile);
        }, function(xhr) {
            callback && callback([{
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.VIEW_FILE,
                isAllowed: false
            }, {
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.CREATE_COMMENT,
                isAllowed: false
            }, {
                operationId: apiConfig.ADRIVE_FILE_PERMISSION.DOWNLOAD_FILE,
                isAllowed: false
            }]);
            $window.alert(lang.get("permission-check-failed"));
        });
    }

    /**
     * fetch the permission for view form
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    api.getUserAccessForMultiProject = function(callback, projectIds) {
        var multiProjPermission = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_USER_APPLICATION_PRIVILEGES_MULTI,
                projectIds: projectIds
            }
        });

        multiProjPermission.then(function(data) {
            callback && callback(data);
        }, function(xhr) {
            $window.alert(lang.get("permission-check-failed"));
        });

        return multiProjPermission;
    };

    var formSpecificPermission = {};
    // call to fetch specific form permission
    api.getFormSpecificPermission = function(param, callback, refresh) {
        var then = function() {
            formSpecificPermission[param.formTypeIds].then(function(data) {
                data = data[0] || data || {};
                formSpecificPermission[param.formTypeIds] = data;
                callback && callback(data);
            }, function(xhr) {
                $window.alert(lang.get("permission-check-failed"));
            });
        }

        if (!refresh && formSpecificPermission[param.formTypeIds]) {
            if (formSpecificPermission[param.formTypeIds].abort) {
                then();
            } else {
                callback && callback(formSpecificPermission[param.formTypeIds]);
            }
            return;
        }

        formSpecificPermission[param.formTypeIds] = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                action_id: apiConfig.GET_FORM_TYPE_PRIVILEGES,
                formTypeIds: param.formTypeIds, //myConfig.hLatestFormType,
                paramProjectIds: param.paramProjectIds //myConfig.projectId
            }
        });

        then();
    };

    /**
     * fetch the workspace setting
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var workspaceSettings = {};
    api.getWorkspaceSettings = function(callback, refresh, projectId) {
        projectId = projectId || myConfig.projectId;
        var then = function() {
            workspaceSettings[projectId].then(function(data) {
                workspaceSettings[projectId] = data;
                callback && callback(workspaceSettings[projectId]);
            }, function(xhr) {
                $window.alert('Error while fetching Workspace Settings!');
            });
        }

        if (!refresh && workspaceSettings[projectId]) {
            if (workspaceSettings[projectId].abort) {
                then();
            } else {
                callback && callback(workspaceSettings[projectId]);
            }
            return;
        }

        workspaceSettings[projectId] = api.ajax({
            url: apiConfig.GET_WORKSPACE_SETTING,
            data: {
                projectId: projectId,
                userId: myConfig.USP.userID
            }
        });

        then();
    };

    /**
     * fetch the workspace setting
     * @param {fn} callback
     * @param {bolean} refresh
     * @param {string} projectId
     */
    var workspaceSettingsForMarkUps = {};
    api.getWorkspaceSettingsForMarkups = function(callback, refresh, projectId) {
        projectId = projectId || myConfig.projectId;
        var then = function() {
            workspaceSettingsForMarkUps[projectId].then(function(data) {
                var settings = {};
                var setting_option = {
                        displayProp: {
                            "0": "block",
                            "1": "block",
                            "2": "none"
                        },
                        "0": { "checked": false, "disabled": false },
                        "1": { "checked": true, "disabled": true },
                        "2": { "checked": false }
                    },
                    settingId = data.checkCreateCommentPref;
                settings.saveAsMarkupOptions = setting_option[settingId];
                settings.displayMarkupCheckBox = setting_option['displayProp'][settingId];
                settings.settingId = settingId;
                settings.checkPrintDocumentPoi = data.checkPrintDocumentPoi;
                settings.checkPrintDocumentStatus = data.checkPrintDocumentStatus;
                settings.checkViewDocumentPoi = data.checkViewDocumentPoi;
                settings.checkViewDocumentStatus = data.checkViewDocumentStatus;

                workspaceSettingsForMarkUps[projectId] = settings;
                callback && callback(workspaceSettingsForMarkUps[projectId]);
            }, function(xhr) {
                $window.alert('Error while fetching Workspace Settings!');
            });
        }

        if (!refresh && workspaceSettingsForMarkUps[projectId]) {
            if (workspaceSettingsForMarkUps[projectId].abort) {
                then();
            } else {
                callback && callback(workspaceSettingsForMarkUps[projectId]);
            }
            return;
        }

        workspaceSettingsForMarkUps[projectId] = api.ajax({
            url: apiConfig.GET_WORKSPACE_SETTING_MARKUP,
            data: {
                projectId: projectId,
                userId: myConfig.USP.userID
            }
        });

        then();
    };

    var informParentWinTimeout = undefined;
    api.informParentWin = function(updateDetail) {
        $timeout.cancel(informParentWinTimeout);
        informParentWinTimeout = $timeout(function() {
            try {
                if (typeof myConfig.isFromFileViewForDomain != undefined && myConfig.isFromFileViewForDomain == "true") {
                    angular.element('#ifrmRefreshParent').remove();
                    var updateDetailStr = [];
                    for (var key in updateDetail) {
                        updateDetailStr.push(key + "_" + updateDetail[key]);
                    }
                    updateDetailStr = updateDetailStr.join("--");
                    var iframe = angular.element('<iframe id="ifrmRefreshParent" src="' + baseUrl + apiConfig.VIEWER_PARENT_REFRESH + "?q=_" + new Date().getTime() + "&updateParam=" + updateDetailStr + '" width="0" height="0" style="position: absolute; border: none; margin: 0;">');
                    angular.element("body").append(iframe);
                } else if (api.isIE()) {
                    $window.opener.updateTableData.initUpdateByPrimaryKey(updateDetail);
                } else {
                    $window.opener.postMessage("updateData" + angular.toJson(updateDetail), "*");
                }
            } catch (e) {}
        }, 200);
    };

    api.returnNonAkamaiURL = function(param, callback) {
        var xhr = api.ajax({
            url: apiConfig.DASHBOARD_CONTROLLER,
            data: {
                userId: myConfig.USP.userID,
                projectId: param.projectId,
                extra: JSON.stringify(param.revisionIds),
                action_id: apiConfig.CHECK_FOR_AKAMAI_DOWNLOAD_LIMIT
            }
        });
        xhr.then(function(data) {
            callback && callback(data)
        }, function(xhr) {
            $window.alert(lang.get("something-went-wrong"))
        })
    };

    api.downloadFile = function(file, projectId, extra) {
        api.returnNonAkamaiURL({
            projectId: file.projectId,
            revisionIds: {
                revisions: [{
                    revisionId: file.revisionId,
                    dcId: file.dcId,
                    projectId: file.projectId,
                    isLock: ""
                }]
            }
        }, function(data) {
            var url = myConfig.downloadServiceURL;

            if (data.isLimitExist) {
                url = data.nonCDNDownloadUrl
            } else {
                url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, url);
            }
            
            url += apiConfig.DOWNLOAD_SINGLE_DOCUMENT + "?revisionId=" + file.revisionId + "&projectId=" + file.projectId;
            if (extra) {
                for (var key in extra) {
                    if (extra.hasOwnProperty(key)) {
                        url += '&' + key + '=' + extra[key];
                    }
                }
            }
            jQuery.fileDownload(url, {
                preparingMessageHtml: lang.get("perparing-your-files-please-wait"),
                failMessageHtml: lang.get("problem-downloading-your-file-please-try-again")
            })
        });
    };

    api.downloadAttachmentFile = function(file, zipUrl) {
        var url = manageDataCenter.getUrl(myConfig.LOCAL_DC_ID, myConfig.downloadServiceURL);
        url += zipUrl || apiConfig.DOWNLOAD_INTERNAL_ATTACHMENT_CONTROLLER + "?projectId=" + file.projectId + "&attachmentId=" + file.attachmentId;
        jQuery.fileDownload(url, {
            preparingMessageHtml: lang.get("perparing-your-files-please-wait"),
            failMessageHtml: lang.get("problem-downloading-your-file-please-try-again")
        });
    };

    api.viewFile = function(param, dcId, target) {
        if (myConfig.applicationId) {
            param.applicationId = myConfig.applicationId;
        }
        var target = target || '_FILE_VIEWER_' + param.revisionId
        api.submitForm({
            target: target,
            method: 'GET',
            url: apiConfig.FILE_VIEW_PAGE,
            param: param,
            _dcId: dcId
        });
    };
    api.getLockedActivitiesObject = function(str) {
        if (!str || str == -1) {
            str = '';
        }
        var lockedObjects = str.toString().split(',');
        return {
            attributes: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_EDIT_ATTRIBUTES.toString()) != -1),
            distribution: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_FILE_DISTRIBUTION.toString()) != -1),
            status: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_UPDATE_STATUS.toString()) != -1),
            comment: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_ADD_COMMENT.toString()) != -1),
            revisionUpload: (lockedObjects.indexOf(apiConfig.ACTIVITY_CONSTANT.ACTIVITY_REVISION_UPLOAD.toString()) != -1)
        }
    }
    api.openDiscussion = function(param, dcId) {
        param.callFor = "comments";

        api.submitForm({
            target: '_VIEWER_' + param.revisionId,
            method: 'GET',
            url: apiConfig.FILE_VIEW_PAGE,
            param: param,
            _dcId: dcId
        });
    };

    api.openApp = function(param, dcId) {
        var target = '_VIEW_FORM_' + param.commId;
        if (target == window.name) {
            target = '_blank';
        }

        api.submitForm({
            target: target,
            method: 'GET',
            url: apiConfig.VIEW_FORM,
            param: param,
            _dcId: dcId
        });
    };

    api.openAttachment = function(param, dcId) {
        var isMsgIdZero = (param.msgId && param.msgId.split('$$')[0] == '0');
        if (isMsgIdZero && param.commingFrom != "customObject") {
            param.commingFrom = "internalAttachment";
        }

        if (api.isMobile() && myConfig.applicationId == 3) {
            api.fileViewForMobile({
                target: '_self',
                url: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
                param: param,
                method: 'GET',
                _dcId: param.dcId || dcId
            }, true);
            return;
        }

        var method = param.method || 'GET';
        delete param.method;

        if(window['platformName']) {
            // Disabled attachment view temporary for external platforms i.e naviswork
            // window['openExternalUrl']({
            //     endPoint: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
            //     params: param
            // });
            return;
        }

        api.submitForm({
            target: '_FILE_VIEWER_' + (param.attachmentId || param.revisionId),
            url: apiConfig.ATTACH_FILE_VIEWER_PREFERENCE,
            param: param,
            _dcId: dcId
        });
    };

    api.checkActionValidation = function(param) {
        var selData = null,
            isValidate = true;
        if (!param || !param.selectedList || !param.selectedList.length) {
            return;
        }
        for (var i = 0; i < param.selectedList.length; i++) {
            selData = param.selectedList[i];
            if (selData.actions && selData.actions.split('$$')[0] !== param.validateAction && !selData.date) {
                isValidate = false;
            }
        }
        return isValidate;
    };

    api.encodeHtml = function(value) {
        return value.replace(/'/g, "&apos;");
    };

    api.sanitizeHtml = function(html) {
        if(!html) {
            return html;
        }

        // Sanitize untrusted HTML (to prevent XSS) with a configuration specified by a Whitelist.
        return filterXSS(html, {
            stripIgnoreTagBody: ['script'],
            stripIgnoreTag: true, allowCommentTag: false
        })
    };

    api.sanitizeComments = function(comments) {
        if(!comments || !comments.length) {
            return comments;
        }

        for(var i = 0; i < comments.length; i++) {
            var msgVO = comments[i] && comments[i].messageVO;
            if(!msgVO) {
                continue;
            }
            
            for(var j = 0; j < msgVO.length; j++) {
                if(msgVO[j]) {
                    msgVO[j].comment_text = api.sanitizeHtml(msgVO[j].comment_text);
                }
            }
        }
        return comments;
    };

    api.returnErrorCode = function(xhr) {
        var div = angular.element("<div>");
        div.append(xhr.data);

        var errorDom = div.find("#errorCode");
        if (errorDom.length) {
            return errorDom.html().trim();
        }

        return "";
    };

    api.showServerErrMsg = function(xhr) {
        if (myConfig.applicationId == 2) {
            var isOnline = qtObject.systemOnlineCallBack();
            if (!isOnline) {
                api.showNetworkMsg();
            }
        }

        if (myConfig.applicationId != 2 && !navigator.onLine) {
            api.showNetworkMsg();
        }

        if (!xhr || xhr.status == -1) {
            return;
        }

        xhr.errorCode = api.returnErrorCode(xhr);
        Notification.error({
            title: lang.get("server-error") + ': ' + (xhr.errorTitle || ''),
            message: '<div class="text-large">' +
                lang.get('error-while-processing-your-request') + ': ' + xhr.errorCode +
                '</div>'
        });
    };
    api.showNetworkMsg = function() {
        Notification.clearAll();
        Notification.error({
            title: lang.get("network-error"),
            message: '<div class="text-large">' +
                lang.get('not-able-to-connect-server') +
                '</div>'
        });
    };
    api.showWarningMsg = function(opt) {
        Notification.warning({
            title: opt.title,
            message: '<div class="text-large">' + opt.msg + '</div>'
        });
    };

    api.sortArray = function(array, key, order) {
        order = (order) ? order : "asc";
        if (order == "asc") {
            return array.sort(function(a, b) {
                var x = a[key];
                var y = b[key];
                return ((x < y) ? -1 : ((x > y) ? 1 : 0))
            })
        } else {
            if (order == "desc") {
                return array.sort(function(a, b) {
                    var x = a[key];
                    var y = b[key];
                    return ((y < x) ? -1 : ((y > x) ? 1 : 0))
                })
            }
        }
    };

    var nativeNotification = $window.Notification;

    api.windowNotification = function(data, callback) {

        if (!nativeNotification) {
            return;
        } else if (nativeNotification.permission === 'denied') {
            return;
        } else if (nativeNotification.permission === 'default') {
            nativeNotification.requestPermission(function(permission) {
                return;
            });
        } else if (nativeNotification.permission === 'granted' && data) {
            var notificationObj = new nativeNotification(data.title, data.option);
            if (notificationObj) {
                notificationObj.onclick = function() {
                    callback(data.param);
                    this.close();
                };
            }
            return notificationObj;
        }
    }

    api.timeAgo = function(data) {
        var strings = {
                suffixAgo: "ago",
                seconds: "few seconds",
                minutes: "%d minutes",
                hours: "%d hours",
                days: "%d days",
                months: "%d months",
                years: "%d years"
            },
            dateDifference = (new Date().getTime()) - data.time,
            words,
            seconds = Math.abs(dateDifference) / 1000,
            minutes = seconds / 60,
            hours = minutes / 60,
            days = hours / 24,
            years = days / 365,
            suffix = strings.suffixAgo;

        var substitute = function(stringOrFunction, number, strings) {
            number = Math.floor(number);
            return stringOrFunction.replace(/%d/i, number);
        };
        words = seconds < 60 && substitute(strings.seconds, seconds, strings) ||
            minutes < 60 && substitute(strings.minutes, minutes, strings) ||
            hours < 24 && substitute(strings.hours, hours, strings) ||
            days < 30 && substitute(strings.days, days, strings) ||
            days < 365 && substitute(strings.months, (days / 30), strings) ||
            substitute(strings.years, years, strings);
        return (words + ' ' + suffix);
    }

    api.getExt = function(name) {
        return name.substr(name.lastIndexOf('.') + 1);
    };
    
    api.isZip = function(name) {
        if(!name || typeof name !== 'string') {
            return false;
        }
        var ext = api.getExt(name.toLowerCase());
        if(['zip', 'rar'].indexOf(ext) > -1) {
            return true;
        }
        return false;
    };

    api.getFileExtImage = function(type) {
        var map = {
            'pdf': 'pdf',
            '000': '000',
            '906': '906',
            '907': '906',
            'dwg': 'dwg',
            'dwg_mf': 'dwg_mf',
            'dxf': 'dxf',
            'dwf': 'dwf',
            'dx': 'dx',
            'dg': 'dg',
            'prt': 'prt',
            'rlc': 'rlc',
            'cgm': 'cgm',
            'edm': 'edm',
            'g3': 'ctx',
            'g4': 'ctx',
            'cg4': 'ctx',
            'rnl': 'rnl',
            'cmi': 'cmi',
            'mi': 'mi',
            'plt': 'plt',
            'igs': 'igs',
            'iges': 'igs',
            'dgn': 'dgn',
            'dgn_mf': 'dgn_mf',
            'cit': 'cit',
            'rle': 'rle',
            'mvs': 'mvs',
            'dsn': 'dsn',
            'slddrw': 'sld',
            'mot': 'mot',
            'cal': 'cal',
            'gp4': 'cal',
            'mil': 'cal',
            'dcx': 'dcx',
            'edc': 'edc',
            'ftk': 'ftk',
            'iso': 'iso',
            'jpg': 'jpg',
            'jpeg': 'jpg',
            'pcx': 'pcx',
            'dif': 'dif',
            'tif': 'tif',
            'tiff': 'tif',
            'bmp': 'bmp',
            'cdr': 'cdr',
            'shw': 'shw',
            'dbf': 'dbf',
            'xdw': 'xdw',
            'xls': 'xls',
            'fax': 'fax',
            'html': 'html',
            'htm': 'htm',
            'ini': 'ini',
            'pps': 'pps',
            'ppt': 'ppt',
            'mpp': 'mpp',
            'vsd': 'vsd',
            'doc': 'doc',
            'wdb': 'wdb',
            'p65': 'p65',
            'wb1': 'wb1',
            'wb2': 'wb2',
            'wq1': 'wq1',
            'rtf': 'rtf',
            'sam': 'sam',
            'wri': 'wri',
            'wp5': 'wp5',
            'wp6': 'wp6',
            'wpd': 'wpd',
            'wpf': 'wpf',
            'ws': 'ws',
            'gif': 'gif',
            'log': 'txt',
            'txt': 'txt',
            'dll': 'dll',
            'zip': 'zip',
            'bak': 'bak',
            'url': 'url',
            'ico': 'ico',
            'avi': 'avi',
            'cab': 'cab',
            'cdf': 'cdf',
            'chm': 'chm',
            'css': 'css',
            'js': 'js',
            'msg': 'msg',
            'dot': 'dot',
            'eml': 'eml',
            'docx': 'docx',
            'dotx': 'dotx',
            'ppsx': 'ppsx',
            'pptx': 'pptx',
            'xlsx': 'xlsx',
            'kml': 'kml',
            'kmz': 'kmz',
            'asx': 'asx',
            'wax': 'wax',
            'm3u': 'm3u',
            'wpl': 'wpl',
            'wvx': 'wvx',
            'wmx': 'wmx',
            'dvr': 'ms=dvr-ms',
            'mid': 'mid',
            'rmi': 'rmi',
            'midi': 'midi',
            'mpeg': 'mpeg',
            'mpg': 'mpg',
            'm1v': 'm1v',
            'mp2': 'mp2',
            'mpa': 'mpa',
            'mpe': 'mpe',
            'mpc': 'mpc',
            'mp': '=mp+',
            'ogg': 'ogg',
            'ogm': 'ogm',
            'spx': 'spx',
            'wav': 'wav',
            'snd': 'snd',
            'au': 'au',
            'aif': 'aif',
            'aifc': 'aifc',
            'aiff': 'aiff',
            'wma': 'wma',
            'mp3': 'mp3',
            'mp4': 'mp4',
            'asf': 'asf',
            'wm': 'wm',
            'wmd': 'wmd',
            'wmv': 'wmv',
            'divx': 'divx',
            'div': 'div',
            'dat': 'dat',
            'dv': 'dv',
            'vob': 'vob',
            'ra': 'ra',
            'ram': 'ram',
            'rm': 'rm',
            'rmvb': 'rmvb',
            'mov': 'mov',
            'qt': 'qt',
            '3gp': '3gp',
            'aac': 'aac',
            'ac3': 'ac3',
            'amr': 'amr',
            'exe': 'exe',
            'fla': 'fla',
            'flv': 'flv',
            'swf': 'swf',
            'p3': 'p3',
            'p3c': 'p3c',
            'prx': 'prx',
            'stx': 'stx',
            'mps': 'mps',
            'd': 'd',
            'nwc': 'nwc',
            'nwd': 'nwd',
            'nwf': 'nwf',
            'png': 'png',
            'skp': 'skp',
            'smc': 'smc',
            'mdb': 'mdb',
            '7z': '7z',
            'ace': 'ace',
            'arc': 'arc',
            'arj': 'arj',
            'b64': 'b64',
            'bhx': 'bhx',
            'bz2': 'bz2',
            'dar': 'dar',
            'gz': 'gz',
            'gzip': 'gzip',
            'hqx': 'hqx',
            'ice': 'ice',
            'jar': 'jar',
            'lzh': 'lzh',
            'mim': 'mim',
            'pkzip': 'pkzip',
            'rar': 'rar',
            'sfark': 'sfark',
            'shar': 'shar',
            'tar': 'tar',
            'tgz': 'tgz',
            'tz': 'tz',
            'uu': 'uu',
            'uue': 'uue',
            'wim': 'wim',
            'xar': 'xar',
            'xxe': 'xxe',
            'xsf': 'xsf',
            'xsn': 'xsn',
            'rvt': 'rvt',
            'pts': 'pts',
            'ptx': 'ptx',
            'pptm': 'pptm',
            'dwfx': 'dwfx',
            'asn': 'asn',
            'all': 'all',
            'wmf': 'wmf',
            'potx': 'potx',
            'dotm': 'dotm',
            'xps': 'xps',
            'pot': 'pot',
            'ppsm': 'ppsm',
            'svg': 'svg',
            'pub': 'pub',
            'ppa': 'ppa',
            'xhtml': 'xhtml',
            'xod': 'xod',
            'odt':'odt',
            'ods':'ods',
            'caf':'caf',
            'oga':'oga',
            'm4a':'m4a',
            'flac':'flac',
            'opus':'opus',
            'jfif':'jfif'
        };
        type = type || "";
        type = type.toLowerCase();
        return (map[type] || 'noicon');
    };

    /**
     * Return extension type wise Map
     */
    api.getFileExtesions = function (type) {
        var map = {
            image: ["jpeg", "jpg", "gif", "png", "bmp", "ppm", "pgm", "pbm", "pnm", "webp", "bpg", "ico", "img", "pgf", "xisf", "wmf", "emf", "vml", "xps", "dwg"],
            audio: ["aa	", "aac", "aax", "act", "aiff", "amr", "ape", "au	", "awb", "dct", "dss", "dvf", "flac", "gsm", "ikla", "ivs", "m4a", "m4b", "m4p", "mmf", "mp3", "mpc", "msv", "ogg", "opus", "ra,", "raw", "sln", "tta", "vox", "wav", "wma", "wv	", "webm", "8sv"],
            video: ["webm", "mkv", "flv", "vob", "ogv", "ogg", "drc", "mng", "mng", "avi", "mov", "qt", "rm", "yuv", "rmvb", "asf", "amv", "mp4", "m4p", "m4v", "mpg", "mp2", "mpeg", "mpe", "mpv", "m2v", "svi", "3gp", "3g2", "mxf", "roq", "nsv", "f4v", "f4p", "f4a", "f4b"],
            code: ["asp", "jsp", "js", "xml", "bat", "cmd", "class", "cpp", "def", "dll", "dtd", "exe", "font", "html", "htm", "java", "css", "ts", "json"],
            powerpoint: ["ppt", "pot", "pps", "pptx", "pptm", "potx", "potm", "ppam", "ppsx", "ppsm", "sldx", "sldm"],
            word: ["doc", "dot", "wbk", "docx", "docm", "dotx", "dotm", "docb"],
            zip: ["zip", "lib", "jar", "war", "ear", "iso", "rar", "7z"],
            excel: ["xls", "xlsm", "xlt", "xlm", "xltm", "xltx", "xlsx", "xlsb", "xla", "xlam", "xll", "xlw", "csv"],
            pdf: ["pdf"]
        }

        if (type && map[type]) {
            return map[type];
        }

        return map;
    };

    /**
		 * @description add file exension key in the data
		 * @param {*} attachment Data
		 * @memberof TableListingComponent
		 */
    api.setFileExtInAttach = function (data) {
        for (var i = 0; i < data.length; i++) {
            var attachment = data[i];
            var fileName = attachment.fileName || attachment.FileName || "";
            var fileSize = attachment.fileSize || attachment.FileSize;
            if (!fileName) {
                return;
            }
    
            if (typeof fileSize !== "string" || fileSize.indexOf('B') == -1) {
                attachment.fileSize = attachment.FileSize = (fileSize / 1024 / 1024).toFixed(2) + ' MB';
            }
    
            if (typeof attachment.attachedDate !== "string") {
                var userformat = window['INIT_JSP_GLOBAL'].formatsForJqueryCalender[window['USP'].languageId];
                attachment.attachedDate && (attachment.attachedDate = api.formatDate(userformat, new Date(attachment.attachedDate)));
            }           

            var splitArray = fileName.split('.');
            var ext = splitArray[splitArray.length - 1];
            var extClass = "text";

            var extObj = api.getFileExtesions();
            for (var key in extObj) {
                if (extObj.hasOwnProperty(key)) {
                    var extArray = extObj[key];
                    if (extArray.indexOf(ext) > -1) {
                        extClass = key;
                        break;
                    }
                }
            }
            attachment['fileExt'] = extClass;
        }
    };

    api.getSortFileSize = function(size) {
        size = size || 0;
        var s = Math.round(((size > (1024 * 1024)) ? (((size * 100) / (1024 * 1024)) / 100) : (((size * 100) / 1024) / 100)));
        s += (size > 1024 * 1024) ? ' MB' : ' KB';

        return s;
    };

    api.openReview = function(data, extra) {
        var url, param = {
			dcId: data.dcId,
			revisionId: data.revisionId,
			callFor: 'reviews',
			reviewInstanceId: data.customObjectInstanceId,
			reviewCommentId: data.customObjectCommentId,
			documentTypeId: data.docTypeId || data.documentTypeId,
			hasOnlineViewerSupport: data.hasOnlineViewerSupport,
			isFromFileViewForDomain: 'true',
			isFromFileListing: 'true',
			projectId: data.projectId,
			isDraft: false
		};

		url = apiConfig.FILE_VIEW_PAGE;
		param['folderId'] = data.folderId;
		param['documentId'] = data.documentId || 0;
		param['viewerId'] = data.viewerId || 0;

		if(api.isMobile() && myConfig.applicationId == 3){
			if(myConfig.isOfflineMode){
				api.sendEventToIpad("offlineCommentAssociationClick:"+JSON.stringify(param));
				return;
			}
			api.fileViewForMobile({
				target: '_self',
				url: apiConfig.FILE_VIEW_MOBILE,
				param: param,
				method: 'GET',
				_dcId: data.dcId
			});
			return;
		}

		if (extra) {
			for (var key in extra) {
				param[key] = extra[key];
			}
		}

		api.submitForm({
			target: '_VIEWER_' + data.revisionId,
			url: url,
			param: param,
			method: 'GET',
			_dcId: data.dcId
		});
    }
}])

.service('downloadAssocDoc', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'download', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, download, api, Notification) {
    var downloadAssocDoc = this;
    var downloadXhr = false;
    var resData = null;
    downloadAssocDoc.init = function(opt, callback) {
        downloadAssocDoc.directLink(opt, callback);
    };

    downloadAssocDoc.directLink = function(opt, callback) {
        resData = opt;
        var param = {
                revIds: [],
                revisions: [],
                isFromDirectLink: true,
                isDiffProject: false,
                projectIds: []
            },
            selectedRowsData = JSON.parse(opt.downloadRevDocListJSON),
            docData = null;

        if (selectedRowsData.length == 0) {
            Notification.error({ title: lang.get("adoddle"), message: lang.get("no-document-associations-found") });
            callback && callback();
            return false;
        } else {
            for (var i = 0; i < selectedRowsData.length; i++) {
                docData = selectedRowsData[i];
                param.revisions.push({
                    revisionId: docData.revisionId,
                    isLock: docData.isLock,
                    dcId: docData.dcId,
                    projectId: docData.projectId,
                    hasMarkup: docData.hasMarkup,
                    hasAttachment: docData.hasAttachment,
                    zipFileName: docData.zipFileName
                });
                param.revIds.push(docData.revisionId);
                if (param.projectIds.indexOf(docData.projectId) == -1) {
                    param.projectIds.push(docData.projectId);
                }
            }

            if (param.revisions.length) {
                param.isDiffProject = param.projectIds.length > 1;
                param.callForm = param.isDiffProject ? "MultiProjectDownload" : "DownloadBtn";
                downloadAssocDoc.displayDownloadPage(param, callback);
            } else {
                callback && callback();
            }
        }
    };

    downloadAssocDoc.displayDownloadPage = function(param, callback) {
        var revData = param.revisions[0];
        var isFromDirectLink = param.isFromDirectLink;
        if (!isFromDirectLink) {
            callback && callback();
            return;
        }

        if (downloadXhr) {
            return;
        }

        if (myConfig.applicationId != 2)
            Notification.success('<div class="bold-msg text-center">' + lang.get("download-has-been-started") + '</div>');

        var strUrl = "";
        if (resData.isLimitExist) {
            strUrl = resData.nonCDNDownloadUrl;
        }
        var urlController = apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION_CONTROLLER;
        if (resData.isFromPublicDomain) {
            urlController = apiConfig.PUBLIC_DOWNLOAD_CONTROLLER;
        }
        else {
            if(!strUrl) {
                strUrl = myConfig.downloadServiceURL;
            }
        }
        downloadXhr = api.ajax({
            url: urlController,
            data: {
                extra: JSON.stringify(param),
                projectID: revData.projectId,
                isFromDirectLink: isFromDirectLink,
                includeInternalAttachment: resData.downloadSecondaryFile,
                action_id: apiConfig.MULTI_DC_DOWNLOAD_BATCH_DOCUMENT_ACTION,
                downloadWithSimplePath: myConfig.downloadWithSimplePath
            },
            _dcId: revData.dcId,
            _cdnUrl: strUrl
        });

        downloadXhr.then(function(data) {
            downloadXhr = false;
            data.url = apiConfig.PROGRESS_ZIP_CREATION_CONTROLLER;
            if (resData.isFromPublicDomain) {
                data.url = apiConfig.PUBLIC_DOWNLOAD_CONTROLLER;
            }
            data.actionUrl = data.sourcePath;
            data.projectId = revData.projectId;
            data.isFromDirectLink = isFromDirectLink;
            download.createZipFile(data, callback);
        }, function(xhr) {
            callback && callback();
            downloadXhr = false;
            xhr.errorTitle = lang.get("server-error");
            api.showServerErrMsg(xhr);
        });
    };
}])

.service('validate', ['api', 'lang', function(api, lang) {
    var validation = this;

    var invalidHtmlArray = ['javas&#99;ript', 'javascript:', '<script', '</script>', 'vbscript:', 'livescript:', '<s&#99;ript>', '<img', 'onload=',
        '<input', '<select', '<textarea', '<form', '<head', '<body', '<html', 'datasrc=', '<iframe', 'text/javascript', 'eval(', 'expression(',
        'url(', '&{[', 'alert(', 'alert=', 'alert`', '\x3cscript', 'javascript#', '<meta', '%3cscript', 'document.cookie', 'window.location', '<EMBED', '</EMBED>', 'onerror=', 'window.open(', 'onclick=', 
        'prompt=', 'prompt`', 'prompt(', 'oncopy=', 'oncut=', 'onpaste=', 'ondbllclick=', 'onmouseover=', 'onmousedown=', 'onmouseenter=', 'onmouseleave=', 'onmousemove=', 'onmouseout=', 'onmouseup=', 'onscroll=', 
        'ontouchcancel=', 'ontouchend=', 'ontouchmove=', 'ontouchstart=', 'confirm`', 'confirm(', 'confirm=', 'oninput=',  '=javascript',
        '=&#34;javascript', '=(javascript', '=`javascript', 'xlink:href', '<button' 
    ];

    var richTextExceptionTags = ['<img'];

    validation.required = function(value) {
        var isValid = true;

        if (typeof value === "string") {
            value = value.trim();
        }

        if (!value || !value.length) {
            isValid = false;
        }

        return {
            valid: isValid,
            error: lang.get("field-required")
        };
    };

    validation.maxLength = function(value, length) {
        var isValid = true;

        if (value && value.length > length) {
            isValid = false;
        }

        return {
            valid: isValid,
            error: lang.get("workflow-description-too-loang").replace("{0}", length)
        };
    };

    validation.number = function(value) {
        var isValidNum = true;

        if (value) {
            // Accept Regular Number or float Number only
            var regIsNum = /^\d+(\.\d+)*$/;
            isValidNum = regIsNum.test(value);
        }

        return {
            valid: isValidNum,
            error: lang.get("invalid-decimal")
        };
    };

    validation.integer = function(value) {
        var isValidInt = true;

        if (value) {
            // Accept positive or Negative Number only
            var regIsInt = /^(\-{0,1})\d+$/;
            isValidInt = regIsInt.test(value);

            var MAX_INT = 2147483647;
            var MIN_INT = -2147483647;
            var intValue = parseInt(value);

            if (intValue >= MAX_INT || intValue <= MIN_INT) {
                isValidInt = false;
            }
        }

        return {
            valid: isValidInt,
            error: lang.get("invalid-integer")
        };
    };

    validation.decimal = function(value) {
        var isValid = true;

        if (value) {
            isValid = !isNaN(parseFloat(value)) && isFinite(value);
        }

        return {
            valid: isValid,
            error: lang.get("invalid-decimal")
        };
    };

    validation.email = function(value) {
        var isValidEmailAdd = true;

        if (value) {
            // Accept Email Format with or without underscore
            var regIsEmailFormat = /^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+){0,1}\@[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+){0,3}$/;
            isValidEmailAdd = regIsEmailFormat.test(value);
        }

        return {
            valid: isValidEmailAdd,
            error: lang.get("invalid-emailAddress")
        };
    };

    validation.date = function(value) {
        var isValid = true;

        if (value) {
            var split = value.split('::');
            try {
                api.parseDate(split[1], split[0]);
            } catch (e) {
                isValid = false;
            }
        }

        return {
            valid: isValid,
            error: lang.get("invalid-date")
        };
    };

    validation.alphaWithSpace = function(value) {
        var isValidString = true;

        if (value) {
            var regIsAlpha = /^\s*[a-zA-Z\s]+\s*$/;
            isValidString = regIsAlpha.test(value);
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-letters")
        };
    };

    //It check string contain HTML tag or not.
    validation.invalidHTMLtag = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                var codeAt = value.charCodeAt(i);
                if (codeAt < 32 || codeAt == 35) {
                    isValidString = false;
                    break;
                }
            }

            if (isValidString) {
                isValidString = validation.hasCodeContent(value).valid;
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-character-entered")
        };
    };

    //It check string contain HTML tag or not.
    validation.hasCodeContent = function(value, richText) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").replace(/\s/g, "").toLowerCase();
        value = value.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
        var isValidString = true;

        if (value) {
            for (var i = 0; i < invalidHtmlArray.length; i++) {
                if (richText && richTextExceptionTags.indexOf(invalidHtmlArray[i]) != -1) {
                    continue;
                }
                if (value.indexOf(invalidHtmlArray[i]) > -1) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalidCharForCommentRichbox")
        };
    };

    //It check string contain HTML tag or not.
    validation.hasInvalidChar = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        value = value.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                var codeAt = value.charCodeAt(i);
                if (codeAt < 32) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalidCharForCommentRichbox")
        };
    };

    validation.invalidchars = function(value) {
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32 || value.charCodeAt(i) == 63) {
                    isValidString = false;
                    break;
                }
            }
            if (value) {
                var nospecial = /^[^\/'\/\\:*?<>|;%#~\"]+$/;
                isValidString = nospecial.test(value);
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };

    validation.letterAndNumber = function(value) {
        value = value.replace(/\r/g, " ").replace(/\n/g, " ").toLowerCase();
        isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32) {
                    isValidString = false;
                    break;
                }
            }

            var invalidStringArray = ['#', '|', '"', '/', '\\', ':', '*', '?', '<', '>', '|', ';', '%', '#', '~', '&'];
            invalidStringArray = invalidStringArray.concat(invalidHtmlArray);

            for (var i = 0; i < invalidStringArray.length; i++) {
                if (value.indexOf(invalidStringArray[i]) != -1) {
                    isValidString = false;
                    break;
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("invalid-characters-entered")
        };
    };

    validation.docrefInvalidChars = function(value) {
        var isValidString = true;

        if (value) {
            var nospecial = /"|#|:|;|\x3F|\x7C|<|>|%|\\|\/|~|\*|—/;
            var matches = value.match(nospecial);

            if (matches && matches.length > 0) {
                isValidString = false;
            } else {
                for (var i = 0; i < value.length; i++) {
                    if (value.charCodeAt(i) < 32) {
                        isValidString = false;
                        break;
                    }
                }
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };

    validation.invalidFileName = function(value) {
        var isValidString = true;

        if (value) {
            for (var i = 0; i < value.length; i++) {
                if (value.charCodeAt(i) < 32 || value.charCodeAt(i) == 63) {
                    isValidString = false;
                    break;
                }
            }

            if (value) {
                var nospecial = /^[^\\:*?<>|;%#~\"]+$/;
                isValidString = nospecial.test(value);
            }
        }

        return {
            valid: isValidString,
            error: lang.get("special-character-validation").replace("166(A6)", "|")
        };
    };
}])

.service('ddchild', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    var loadedChilds = [];
    var callbacks = {};
    var childsMap = {};

    this.register = function(childScope, name) {
        loadedChilds.push({
            name: name,
            scope: childScope
        });
        childsMap[name] = childScope;

        if (callbacks[name] && callbacks[name].length) {
            for (var i = 0; i < callbacks[name].length; i++) {
                var cb = callbacks[name][i];
                cb();
            }

            callbacks[name] = [];
        }
    }

    this.getChildScope = function(name) {
        return childsMap[name];
    };

    this.isLoaded = function(name) {
        for (var i = 0; i < loadedChilds.length; i++) {
            var s = loadedChilds[i];
            if (s.name == name) {
                return true;
            }
        }
        return false;
    }

    this.onLoad = function(name, callback) {
        if (!callbacks[name]) {
            callbacks[name] = [];
        }

        callbacks[name].push(callback);
    }
}])

.service('attachmentApi', ['lang', 'validate', function(lang, validate) {
    this.inlineAttachments = [];

    this.register = function(scope, ctrl) {
        this.inlineAttachments.push([scope, ctrl]);
    };

    this.unregister = function(scope, ctrl) {
        for (var i = 0; i < this.inlineAttachments.length; i++) {
            var inst = this.inlineAttachments[i];
            if (inst[0] === scope && inst[1] === ctrl) {
                this.inlineAttachments.splice(i, 1);
                break;
            }
        }
    }

    this.invalidFileName = function(filename) {
        return validate.invalidFileName(filename);
    };

    this.validate = function() {
        var obj = { valid: true, type: 'alert' };
        var inlineAttachments = this.inlineAttachments;
        if (!inlineAttachments.length) {
            return obj;
        }

        for (var i = 0; i < inlineAttachments.length; i++) {
            var inst = inlineAttachments[i];
            var ctrl = inst[1];
            if (ctrl.fileRequired) {
                if (ctrl.isUploading) {
                    obj.valid = false;
                    obj.msg = lang.get("please-wait-your-file-is-uploading");
                    return obj;
                } else if (!ctrl.removeFileIcon) {
                    obj.valid = false;
                    obj.msg = lang.get("form-submit-validation-msg");
                    return obj;
                }
            }
        }

        for (var i = 0; i < inlineAttachments.length; i++) {
            var inst = inlineAttachments[i];
            var ctrl = inst[1];
            if (ctrl.isUploading) {
                obj.valid = false;
                obj.type = "confirm";
                obj.msg = "Warning:\nPlease wait while your file(s) is being uploaded" +
                    "\nClick on 'OK' If you wish to submit form without the pending attachment(s), or click 'Cancel' to return and complete attaching the file(s).";
                return obj;
            }
        }

        return obj;
    };
}])

.service('asyncService', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, api, Notification) {
    var asyncService = this;

    /**
     * Rets which os
     * @returns  
     * This script sets OSName variable as follows:
     * "Windows"    for all versions of Windows
     * "MacOS"      for all versions of Macintosh OS
     * "Linux"      for all versions of Linux
     * "UNIX"       for all other UNIX flavors 
     * "Unknown OS" indicates failure to detect the OS
     */
    asyncService.retWhichOS = function() {
        var nu = navigator.userAgent;
        var OSName="Unknown OS";
        if (nu.indexOf("Win")!=-1) OSName="Windows";
        if (nu.indexOf("Mac")!=-1) OSName="MacOS";
        if (nu.indexOf("X11")!=-1) OSName="UNIX";
        if (nu.indexOf("Linux")!=-1) OSName="Linux";
        return OSName;
    };

    asyncService.editFileAsync = function(data, callBackFn) {
        var editXhr = api.ajax({
            url: apiConfig.ASYNC_NOTIFICATION,
            _dcId: (data || {}).dcId,
            method: 'POST',
            data: JSON.stringify({
                calledFrom: 'form-association',
                osType : asyncService.retWhichOS(),
                documentFolderPath: data.documentFolderPath || data.filePath,
                filename: data.fileName,
                docRef: data.docRef,
                uploadFilename: data.uploadFilename,
                documentId: data.documentId || data.docId,
                folderId: data.folderId,
                projectId: data.projectId,
                revisionId: data.revisionId,
                totalFileSize: parseInt(data.fileSize.replace(' KB', ''), 10),
                description: data.description,
                purposeOfIssue: data.purposeOfIssue,
                revisionNum: data.revisionNum,
                status: data.status,
                title: data.title
            }),
            headers: { 
                'Content-Type': 'application/json', 
            },
            responseType: 'text',
        }).then(function(response) {
            editXhr = false;
            if (!response) {
                return;
            }
            
            callBackFn(response);
        }, function(err) {
            editXhr = false;
            callBackFn('');
            Notification.error({
                title: lang.get("server-error"),
                message: ''
            });
        });
    };
    
    asyncService.checkOutOnly = function(proid, selectedFileData, succFn) {
        selectedFileData = selectedFileData;
        var checkOutRevIds = [],checkOutDocIds = [];

        for (var i = 0; i < selectedFileData.length; i++) {
            checkOutRevIds.push(selectedFileData[i].revisionId);
            checkOutDocIds.push(selectedFileData[i].documentId);
        }

        var paramsObj = {
            useDirectUrl: true, 
            projectId: proid, 
            revisionId: checkOutRevIds.join(','), 
            action_id: apiConfig.REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK 
        };
    
        var cvXhr = api.ajax({
            url: apiConfig.REV_VALID_FOR_CHECKOUT_ON_RIGHTCLICK_CONTROLLER,
            _dcId: (selectedFileData[0] || {}).dcId,
            _cdnUrl: myConfig.downloadServiceURL,
            method: 'POST',
            data: paramsObj,
            contentType: 'application/json'			
        }).then(function(data) {
            if (data.validRevisionsForCheckout) {
                cvXhr = false;
                paramsObj.revisionId = data.validRevisionsForCheckout;
                paramsObj.action_id = apiConfig.CHECKOUT_REV;
                asyncService.editFileAsync(selectedFileData[0], function(editFileResp) {
                    if (editFileResp != "successful") {
                        window['openAsyncAppPopup']({
                            data : data,
                            asyncAppUrl : editFileResp.match(/href="([^"]*)/)[1] || ''
                        } , function() {
                        
                        });
                        succFn && succFn(selectedFileData);
                    } else if(!editFileResp){
                       
                    }
                });
            } else { 
                var crdXhr = api.ajax({
                    url: apiConfig.GET_CHECKOUT_REVISION_DETAILS_CONTROLLER,
                    _dcId: (selectedFileData[0] || {}).dcId,
                    _cdnUrl: myConfig.downloadServiceURL,
                    method: 'POST',
                    data: {
                        useDirectUrl: true, 
                        projectID: proid, 
                        revisionId: checkOutRevIds.join(','), 
                        action_id: apiConfig.GET_CHECKOUT_REV_DETAILS 
                    },
                    contentType: 'application/json'			
                }).then(function(data) {
                    crdXhr = false;
                    cvXhr = false;

                    var rowHtml = '';
                    if (data.alreadyCheckedOutRevisionList && data.alreadyCheckedOutRevisionList.length) { 
                        rowHtml += lang.get('document-is-already-checked-out') + ". <br/>" 
                    }

                    if (data.linkedRevisionList && data.linkedRevisionList.length) { 
                        rowHtml += lang.get('selected-document-is-link') + ". <br/>" 
                    }

                    if (data.noAccessRevisionList && data.noAccessRevisionList.length) { 
                        rowHtml += lang.get('publish-permission-not-available') + ".<br/>" 
                    }

                    if (data.notLatestRevisionList && data.notLatestRevisionList.length) { 
                        rowHtml += lang.get('document-not-access-latest-revsion-desc') + ".<br/>" 
                    }

                    if (data.paperlessRevisionList && data.paperlessRevisionList.length) { 
                        rowHtml += lang.get('document-is-paper-document-placeholder') 
                    }
                    
                    if (rowHtml.length) {
                        Notification.warning({
                            title: lang.get("adoddle"),
                            message: rowHtml
                        });
                    }
                }, function(err) {
                    crdXhr = false;
                    cvXhr = false;
                });
            }            
        }, function(err) {
            cvXhr = false;
        });

        return cvXhr;
    };

    asyncService.Notification = function() {
        
    };
}])

.service('socketService', ['$window', '$timeout', 'apiConfig', 'myConfig', 'lang', 'api', 'Notification', function($window, $timeout, apiConfig, myConfig, lang, api, Notification) {
    var socketService = this;
    var websocketInsts = {};
        
    socketService.connect = function(url, handleFnObj) {
        var socket = websocketInsts[url];
        if(!socket || socket.readyState === WebSocket.CLOSED) {
            socket = new WebSocket(url);
            websocketInsts[url] = socket;
        }

        socket.onopen = function(event){
            handleFnObj.onopen && handleFnObj.onopen(event);
        };
        
        socket.onmessage = function(event) {
            handleFnObj.onmessage && handleFnObj.onmessage(event);
        };

        socket.onclose = function(event) {
            socket.keepAlive();
            // handleFnObj.onclose && onclose.onclose(event);
        };

        socket.onerror = function(event) {
            socket.keepAlive();
            // handleFnObj.onerror && handleFnObj.onerror(event);
        };

        socket.keepAlive = function () {
            setTimeout(function() {
                var sessionState = localStorage.getItem('sessionState');
                if (sessionState != 'Inactive') {
                    socketService.connect(url, handleFnObj);
                }
            }, 5000);
        };

        return socket;
    }
}])

/**
 * Dropdown communication service.
 * This module will provide communication between two dropdown as service.
 * @module ddService
 */
.service('ddService', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    var openScope = null;
    var dockScope = null;

    this.getOpened = function() {
        return openScope;
    };

    this.open = function(dropdownScope, element) {
        if (!openScope && dockScope) {
            openScope = dockScope;
        }

        if (openScope && openScope !== dropdownScope && (dropdownScope.dockable || !openScope.isDock)) {
            openScope.isOpen = false;
            if (dockScope && dockScope.isDock) {
                dockScope.isOpen = false;

                $rootScope.$broadcast("dd:changed", { name: dockScope.name, visible: dockScope.isOpen, event: 'visibility' });
            }
        }

        var isDock = false;
        try {
            isDock = localStorage.getItem('dock');
            if (isDock === "true")
                isDock = true;
            else if (isDock === "false")
                isDock = false;
        } catch (e) {}

        if (dropdownScope.dockable) {
            dropdownScope.isDock = isDock;
            if (isDock) {
                dockScope = dropdownScope;
                angular.element(window).scrollTop(0);
            }
        }

        openScope = dropdownScope;

        $document.off('click', closeDropdown);
        $document.on('click', closeDropdown);
        $document.off('keydown', this.keybindFilter);
        $document.on('keydown', this.keybindFilter);
    };

    this.close = function(dropdownScope, element) {
        if (openScope === dropdownScope) {
            if (dockScope === openScope) {
                //				dockScope.isDock = false;
                dockScope = null;
            }
            openScope = null;
            $document.off('click', closeDropdown);
            $document.off('keydown', this.keybindFilter);
        }
    };

    this.closeOpenDropdown = function(dropdownScope) {
        if (openScope) {
            
            openScope.isOpen = false;
            openScope.expanded = false;
            openScope.focusToggleElement();

            if (!$rootScope.$$phase) {
                openScope.$apply();
            }
            openScope = null;
            
            if (dockScope === openScope) {
                dockScope = null;
            }
            openScope = null;
            $document.off('click', closeDropdown);
            $document.off('keydown', this.keybindFilter);
        }
    }

    this.dock = function(dropdownScope, element) {
        if (dockScope && dockScope !== dropdownScope) {
            //			dockScope.isDock = false;
            dockScope.isOpen = false;
        }
        dockScope = dropdownScope;
        $timeout(function() {
            if (!dockScope.isDock && dockScope.isOpen) {
                openScope = dropdownScope;
            }
        });

        if (dropdownScope.isDock) {
            angular.element(window).scrollTop(0);
        }
    };

    var closeDropdown = function(evt) {
        // This method may still be called during the same mouse
        // event that
        // unbound this event handler. So check openScope before
        // proceeding.
        if (!openScope || openScope.isDock || openScope.expanded) {
            return;
        }

        if (evt && openScope.getAutoClose() === 'disabled') {
            return;
        }

        if (evt && evt.which === 3) {
            return;
        }

        var toggleElement = openScope.getToggleElement();
        if (evt && toggleElement &&
            toggleElement[0].contains(evt.target)) {
            return;
        }

        var dropdownElement = openScope.getDropdownElement();
        if (evt && openScope.getAutoClose() === 'outsideClick' &&
            dropdownElement &&
            dropdownElement[0].contains(evt.target)) {
            return;
        }

        if (evt && openScope.getAutoClose() === 'outsideClick' &&
        
            $(evt.target).closest('mat-option,ngb-datepicker,mat-datepicker-content, .context-menu-list, .no-auto-close').length) {
            return;
        }

        openScope.isOpen = false;
        openScope.expanded = false;
        openScope.focusToggleElement();

        if (!$rootScope.$$phase) {
            openScope.$apply();
        }

        $rootScope.$broadcast("dd:changed", { name: openScope.name, visible: openScope.isOpen, event: 'visibility' });
        openScope = null;
    };

    this.keybindFilter = function(evt) {
        if (!openScope || openScope.isDock)
            return;
        if (evt.which === 27) {
            evt.stopPropagation();
            openScope.focusToggleElement();
            closeDropdown();
        } else if (openScope.isKeynavEnabled() && [38, 40].indexOf(evt.which) !== -1 &&
            openScope.isOpen && !openScope.isDock) {
            evt.preventDefault();
            evt.stopPropagation();
            openScope.focusDropdownEntry && openScope.focusDropdownEntry(evt.which);
        }
    };
}])

/**
 * htmlformservice service.
 * This module will provide distribution to html apps as service.
 * @module htmlformservice
 */
.service('htmlformservice', ['$document', '$rootScope', '$timeout', function($document, $rootScope, $timeout) {
    this.distSelect;
    this.associateCloseCompleate;
    this.associateLocationComplete;
    this.associateDeleteCompleate;
    this.assocFileService;
    
    this.registerDistSelectScope = function(scope) {
        this.distSelect = scope;
    }

    /**
     * To get associatedLocation data in HTML5 form.
     * This callback function called after Location associted completed
     * Which returns newly associated object and association scope 
     * this.associateLocationComplete need to define in Custom HTML5 form's js. i.e weekly.checklist.js
     */
    this.associateLocationCallback = function(args) {
        this.associateLocationComplete && this.associateLocationComplete(args);
    }

    /**
     * To get associated data in HTML5 form.
     * This callback function called after associted completed
     * Which returns newly associated object and association scope 
     * this.associateCloseCompleate need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.associateAndCloseCallback = function(args) {
        this.associateCloseCompleate && this.associateCloseCompleate(args);
    }

    /**
     * Handle remove associate callback.
     * Which returns removed object and listing scope 
     * this.associateDeleteCompleate need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.associateDeleteCallback = function(args) {
        this.associateDeleteCompleate && this.associateDeleteCompleate(args);
    }

    /**
     * Handler used to get association's scope and ctrl object from assoc.data.tab.js
     * this.assocFileService need to define in Custom HTML5 form's js. i.e lor.workpack.js
     */
    this.assocFileHandler = function(scope, ctrl){
        this.assocFileService = {
            scope: scope, ctrl: ctrl
        };
    }
}])
angular.module("adoddle").controller('FormViewController',
	['$scope', '$element', '$window', '$timeout', '$uibModal', 'api', 'apiConfig', 'myConfig','Notification', 'lang',
		function ($scope, $element, $window, $timeout, $uibModal, api, apiConfig, myConfig, Notification, lang) {
			var ctrl = this;
			var body = document.body;
			var docElement = document.documentElement;
			var mainThread = undefined;
			$scope.loginLoader = false;
			$scope.mainThread = {};

			var init = function () {
				onComplete();
				listen();
			};

			var listen = function () {
				// listen for threads
				$scope.$on('thread:load', onThreadLoad);
			
				// make header sticky on scroll
				angular.element($window).bind("scroll", angular.bind(ctrl, function () {
					var scrollTop = body.scrollTop || (docElement && docElement.scrollTop) || 0;
					var $header = $element.find('.thread-header');
					if (scrollTop > 5)
						$header.addClass('fixed');
					else
						$header.removeClass('fixed');
				}));


				$scope.$on('dd:changed', onDDOpenClose);
			};

			/**
			 * invoke on dropdown open / close
			 */
			var onDDOpenClose = function (event, dd) {
				$timeout(function () {
					angular.element(window).resize();
				}, 50);
			};

			var onThreadLoad = function (e, threadList) {
				if (mainThread || !threadList || !threadList.length) {
					return;
				}

				mainThread = threadList[0];
				if (!mainThread.status) {
					mainThread.status = 'N/A';
				}
				onComplete();
			};

			var onComplete = function () {
				if (mainThread) {
					$scope.mainThread = mainThread;
				}
			}

			/**
			 * invoke on Login button click in the public form. 
			 */
			$scope.loginMarketplace = function () {
				loginModal();
			};		

			/**
			 *  Open login modal and handled child controller events. 
			 */
			var loginModal = function () {
				
				//In modal controller call
				var childController = function ($scope, $uibModalInstance) {
						
					// Login button click event 
					$scope.userLogin = function () {					
						var data ={
							email: this.email && this.email.trim(),
							password: this.password
						}
						
						if (data.email === '' || data.password === '') {	
							Notification.error({ message: lang.get("passwordinvalidmsg") });						
							return;
						}

						// Check for valid password and email and returned USP object
						$scope.loginLoader = true;					
						var xhr = api.ajax({
							url: "commonapi/login",
							data: data,
							errormsg: 'Oops Login Error!',
							ApiKey: window.marketplaceApiKey
						});

						xhr.then(function (data) {							
							var data = JSON.parse(data.entity);						
							var paramData = {
								action_id: 1733,
								projectId: myConfig.projectId,
								formTypeId: myConfig.formTypeId,
								formId: myConfig.formId,
								msgId: myConfig.msgId,
								commId: myConfig.commId								
							}
							$uibModalInstance.close({ my: 'data' });
							// Pass Old hased value parameter and returned new hased value parameter to open form.
							var xhrData = api.ajax({
								url: "adoddlepublic/publicViewForm",
								data: paramData,
								errormsg: 'Oops Login Error!',
								ApiKey: window.marketplaceApiKey
							});
							xhrData.then(function (resData) {								
								$scope.loginLoader = false;
								//Submit new parameter
								api.submitForm({
									target: '_self',
									method: 'POST',
									url: resData.hasFormAccess ? apiConfig.VIEW_FORM : "/adoddlepublic/publicViewForm.jsp",
									param: resData
								});
							}, function (xhrData) {
								$scope.loginLoader = false;
							});						
						}, function (xhr) {
							$scope.loginLoader = false;
							if (xhr.data === 'Invalid credentials.') {
								Notification.error({ message: lang.get("passwordinvalidmsg") });	
								return;
							}
							if (xhr.data === 'Account locked.') {
								Notification.error({ message: lang.get("account-lock") });								
								return;
							}
						});
					}

					// Password textbox keydown event 
					$scope.onEnterLogin = function ($event) {
						if ($event.keyCode == 13) {
							$scope.userLogin();
						}
					}

					// Cancel button click event  to close modal
					$scope.cancel = function () {
						$uibModalInstance.dismiss();
					};

					// Sign up click evebt to redirect in the marketplace page.
					$scope.signUpFun = function (){
						window.open(window.marketPlaceServiceURL + "?origin=true&signup=true","_blank");
					};		

					// In forgot password click event to redirect in the forgot password page.
					$scope.forgotPasswordFun = function (){
						window.open(myConfig.portalUrl + 'widget/web/guest/home?p_p_id=58&amp;p_p_lifecycle=0&amp;p_p_state=normal&amp;p_p_mode=view&amp;_58_struts_action=%2Flogin%2Fview&amp;_58_cmd=forgot-password', '_blank');
					};
				}

				// Open Login modal
				$uibModal.open({
					animation: true,
					templateUrl: 'marketplaceLogin.html',
					controller: childController,
					backdrop: 'static',
					keyboard: false,
					windowClass: 'marketplace-center-modal'
				});
			};
			init();
		}]);
angular.module("adoddle")
	.component('customCommonDropdown', {
		transclude : {
		    leftHeader: '?leftHeader'
		},
		bindings : {
			isOpen : '<',
			dialog : '<',
			dockable: '<',
			draggable : '<',
			expandable: '<',
			alwaysExpanded: '<',
			hideClose: '<',
			btnText : '<',
			btnId : '@',
			btnTitle: '@',
			btnDisabled: '<',
			isDock : '<',
			keynavEnabled : '<',
			targetBtn : '@',
			ddName : '@',
			ddTitle : '@',
			caret : '@',
			icon : '@',
			imgIcon : '@',
			svgIcon: '@',
			help: '@',
			autoClose : '@',
			placement : '@',
			appendTo : '@',
			applyLoading : '<',
			loadingTitle : '@',
			showLeftHeader: '<',
			autoOpen: '<'
		},
		template : '<div class="component-wrapper" auto-close="::$ctrl.autoClose" ng-class="{open: isOpen}"> ' +
						'<button ng-disabled="$ctrl.btnDisabled" type="button" class="btn btn-default button-toggle" ng-click="$ctrl.onToggleBtnClick()" title="{{($ctrl.applyLoading ? $ctrl.loadingTitle : ($ctrl.btnTitle || $ctrl.ddTitle))}}" id="{{::$ctrl.btnId}}" ng-hide="::(!$ctrl.icon && !$ctrl.btnText && !$ctrl.imgIcon)"> ' +
							'<i ng-if="::$ctrl.icon" class="fa" ng-class="::$ctrl.icon"></i> ' +
							'<img ng-if="::$ctrl.imgIcon" class="img-icon" ng-src="{{$ctrl.imgIcon}}" /> ' +
							'<span ng-if="::$ctrl.svgIcon" ng-bind-html="trustedHtml($ctrl.svgIcon)" style="margin-right:3px;"></span> ' +
							'<span ng-bind="$ctrl.btnText"></span> ' +
							'<span ng-if="::$ctrl.caret" class="caret"></span> ' +
							'<div ng-if="::$ctrl.applyLoading" class="loading small"></div> ' +
						'</button>' +
						'<main ng-class="{open: isOpen}" main-name="{{name}}">' +
							'<div ng-if="::$ctrl.dialog" class="dropdown-menu dropdown-menu-right data-panel" ng-class="{docked: ($ctrl.alwaysExpanded || isDock || expanded), expanded: ($ctrl.alwaysExpanded || expanded || isMobile)}"> ' +
						        '<div class="ibox">' +
						            '<div class="ibox-title clearfix" ng-style="{\'cursor\': $ctrl.draggable ? \'move\' : \'default\' }">' +
						                '<div class="pull-left ibox-left-header" ng-if="$ctrl.showLeftHeader" ng-transclude="leftHeader"></div>' +
						                '<div class="pull-right"> ' +
						                	'<span class="action-btns"></span> ' +
						                    '<button ng-if="::$ctrl.help" class="btn btn-default btn-xs" title="{{::langTitle.help}}"><i class="fa fa-question"></i></button> ' +
						                    '<button ng-if="::$ctrl.expandable" class="btn btn-default btn-xs button-expand" ng-click="$ctrl.minMax()" title="{{expanded ? langTitle.minimize : langTitle.maximize}}"> ' +
												'<i class="fa" ng-class="{\'fa-expand\': !expanded, \'fa-compress\': expanded}"></i> ' +
											'</button> ' +
						                    '<button ng-if="!expanded && $ctrl.dockable" class="btn btn-default btn-xs button-dock" ng-click="$ctrl.applyDock($event)" title="{{isDock ? langTitle.undock : langTitle.dock}}"> ' + 
												'<i class="fa fa-thumb-tack"></i> ' +
											'</button> ' +
						                    '<button ng-if="$ctrl.hideClose != true" class="btn btn-default btn-xs close-link" title="{{::langTitle.close}}" ng-click="$ctrl.onToggleBtnClick()"> ' +
						                        '<i class="fa fa-times"></i> ' +
						                    '</button> ' +
						                '</div>' +
						                '<h5 ng-bind="($ctrl.dockTitle || $ctrl.ddTitle)"></h5>' +
						            '</div>' +
						            '<div class="ibox-content clearfix" ng-transclude></div>' +
									'<div class="ibox-popups"></div>' +
						        '</div>' +
							'</div>' +
							'<ul ng-if="::!$ctrl.dialog" class="dropdown-menu dropdown-menu-right" ng-class="::$ctrl.dropdownSize" ng-transclude></ul>' +
						'</main>' +
					'</div>',
	controller : ['$scope', '$element', '$rootScope', '$timeout', 'ddService', 'lang', 'api', 'ddchild', '$sce',
	function($scope, $element, $rootScope, $timeout, ddService, lang, api, ddchild, $sce) {
		var ctrl = this;

		$scope.trustedHtml = function (plainText) {
			return $sce.trustAsHtml(plainText);
		}
		
		// initialization
		ctrl.$onInit = function() {
			if(window.isOfflineMode){
				ctrl.btnId != "offline-status-btn" && (ctrl.btnText = lang.get(ctrl.btnText) || ctrl.btnText);
			}
			$scope.name = ctrl.ddName;
			$scope.isDock = ctrl.isDock;
			$scope.isOpen = ctrl.isOpen;
			$scope.dockable = ctrl.dockable;
			$scope.isMobile = api.isMobile();
			
			$scope.langTitle = {
				dock: lang.get('click-to-dock-content'),
				undock: lang.get('click-to-un-dock-content'),
				minimize: lang.get('minimize'),
				maximize: lang.get('maximise'),
				help: lang.get('help'),
				close: lang.get('close')
			};
			
			ctrl.toggleElement = $element.find('button');
			ctrl.dropdownMenu = $element.find("main");
			
			if ($scope.isOpen || ctrl.autoOpen === true) {
				layout();
			}
			
			if (ctrl.appendTo) {
				var appendToEL = document.getElementById(ctrl.appendTo) || 'body';
				$timeout(function() {
					angular.element(appendToEL).append(ctrl.dropdownMenu);
				});
			}
			
			listen();
			applyDraggable();
		};
		
		var listen = function() {
			if(window.$) {
				$(document).on('adoddle-sidebar-opened', function(){
					if($scope.isOpen && $scope.isDock) {
						$scope.$broadcast('dd:close', {
							force: true,
							name: ctrl.ddName
						})
					}
				});
			}

			$scope.$on('dd:close', function(event, data) {
				if ($scope.isOpen && ((data && data.force && data.name && data.name == ctrl.ddName) || !$scope.isDock)) {
					ctrl.btnToggle();
					triggerChange(data, 'visibility');
			  	}
			});
			
			$scope.$on('dd:open', function(event, data) {
				if (data.name != ctrl.ddName) {
					return;
				}
				
				ctrl.dockTitle = data.dockTitle;

				if(!$scope.isOpen) {
					$timeout(function() {				// wait for outside click to perform
						ctrl.btnToggle(data);
					});
				} else {
					triggerChange(data, 'visibility');
				}
			});
			
			$element.on('$destroy', function() {
				ctrl.dropdownMenu.remove();
			});
		};

		var applyDraggable = function() {
			if(!ctrl.draggable) {
				return;
			}

			$timeout(function() {
				ctrl.$dialog = ctrl.dropdownMenu.find("> div.dropdown-menu");
				if(ctrl.$dialog.length) {
					var $title = ctrl.$dialog.find('.ibox-title');
					var $handler = $title.length ? $title : $dialog;
					ctrl.$dialog.draggable({
						cursor:'move',
						containment: "document", 
						handle: $handler,
						distance: 10
					});
				}
			}, 0);
		}
		
		var triggerChange = function(data, type) {

			if(window.$) {
				$(document).trigger('custom-common-dropdown-changed', {
					type: type,
					isOpen: $scope.isOpen,
					isDock: $scope.isDock
				});
			}

			var expanded = $scope.expanded;
			if(data && data.hasOwnProperty('expanded')) {
				$scope.expanded = data.expanded;
				addClassToBody();
			}

			var dd = { name : $scope.name, visible : $scope.isOpen, expanded : $scope.expanded, event: type };
			if(typeof data == 'object') {
				dd = angular.merge(dd, data);
			}

			$rootScope.$broadcast("dd:changed", dd);
			if(!ddchild.isLoaded($scope.name)) {
				ddchild.onLoad($scope.name, function() {
					$rootScope.$broadcast("dd:changed", dd);
				});
			}
		};

		var layout = function() {
			setPosision();

			setTimeout(function() {
				$scope.isOpen && setPosision();
				if (ctrl.autoOpen === true) {
					 ctrl.onToggleBtnClick();
					 ctrl.autoOpen = false;
				}
			}, 1000);
		}

		var setPosision = function() {
			var targetElement = ctrl.targetBtn ? document.getElementById(ctrl.targetBtn) : ctrl.toggleElement[0];
			var offsetPos = targetElement.getBoundingClientRect();
			
			var posOffsetObj = {
				'left' : offsetPos.left,
				'top' : offsetPos.top,
				'right' : offsetPos.right,
				'bottom' : offsetPos.bottom,
				'width' : targetElement.clientWidth,
				'height' : targetElement.clientHeight
			};
			
			var $boxContent = ctrl.dropdownMenu.find('.ibox-content');
			if ($boxContent.length) {
				$boxContent.css('max-height', (window.innerHeight - posOffsetObj.bottom - 45) + 'px');
			}
			
			if(!ctrl.appendTo) {
				return;
			}
			
			var cssObj = { 'top' : (posOffsetObj.top + posOffsetObj.height) + 'px' };
			if(ctrl.placement == 'left') {
				cssObj.left = posOffsetObj.left + 'px';
			} else {
				cssObj.right = (document.body.clientWidth - posOffsetObj.right) + 'px';
			}
			
			ctrl.dropdownMenu.children().css(cssObj);
		};

		var putPopups = function() {
			var appendPopups = function() {
				var $popups = ctrl.dropdownMenu.find('.ibox').find('.child-popup');
				if($popups.length) {
					var $popupsContainer = ctrl.dropdownMenu.find('.ibox-popups');
					$popupsContainer.append($popups);
					return true;
				}
				
				return false;
			};
			
			setTimeout(function() {
				var found = appendPopups();
				if(!found) {
					setTimeout(function() {
						appendPopups();
					}, 2000);
				}
			}, 1000);
		};
		
		var putTitleActions = function() {
			// take actions in header
			var appendTitleActions = function() {
				var $actions = ctrl.dropdownMenu.find('.ibox-content').find('.title-actions');
				if($actions.length) {
					var $actionHolder = ctrl.dropdownMenu.find('.action-btns');
					$actionHolder.append($actions);
					return true;
				}
				
				return false;
			};
			
			setTimeout(function() {
				var found = appendTitleActions();
				if(!found) {
					setTimeout(function() {
						appendTitleActions();
					}, 2000);
				}
			}, 1000);
		};
		
		$scope.getToggleElement = function() {
			return ctrl.toggleElement;
		};

		$scope.getDropdownElement = function() {
			return ctrl.dropdownMenu;
		};

		$scope.getAutoClose = function() {
			return ctrl.autoClose;
		};

		$scope.focusToggleElement = angular.noop;

		ctrl.onToggleBtnClick = function() {
			var openedScope = ddService.getOpened();
			if(openedScope && openedScope.name) {
				var childScope = ddchild.getChildScope(openedScope.name);

				if(childScope && childScope.hasCancelPrompt) {
					childScope.openCancelPrompt(function(){
						ctrl.btnToggle();
					});
					return;
				}
			}
			ctrl.btnToggle();
		};

		ctrl.btnToggle = function(data) {
			if(ctrl.btnDisabled) {
				return;
			}
			ctrl.draggable && ctrl.$dialog && ctrl.$dialog.removeAttr('style');
			$scope.isOpen = !$scope.isOpen;
			
			if ($scope.isOpen) {
				layout();
				
				putTitleActions();
				putPopups();
				
				ddService.open($scope);
				
				$timeout(function() {
					ctrl.dropdownMenu.find('.close-link').focus();		
				});
			} else {
				$scope.expanded && ctrl.minMax(true);
				ddService.close($scope);
			}
			
			if($scope.isMobile) {
				ctrl.minMax(!$scope.isOpen);
			}
			triggerChange(data, 'visibility');
		};
		
		var addClassToBody = function () {
			if($scope.expanded) {
				angular.element('body').addClass('dd-expanded');
				angular.element('html, body').css({overflow: 'hidden', height: '100%'});
			} else {
				angular.element('body').removeClass('dd-expanded');
				angular.element('html, body').css({overflow: '', height: ''});
				
				if($scope.isOpen && !$scope.isDock) {
					layout();
				}
			}
		};

		ctrl.minMax = function(forceToClose) {
			if(forceToClose) {
				$scope.expanded = false;
			} else {
				$scope.expanded = !$scope.expanded;
			}
			
			addClassToBody();
			
			triggerChange(null, 'size');
		};

		ctrl.applyDock = function(e) {
			$scope.isDock = !$scope.isDock;
			ddService.dock($scope);
			
			if(!$scope.isDock) {
				layout();
				ctrl.draggable && ctrl.$dialog && ctrl.$dialog.removeAttr('style');
			}
			
			try {
				localStorage.setItem('dock', $scope.isDock);
			} catch(e) {}
			
			triggerChange(null, 'dock');
		};

		$scope.isKeynavEnabled = function() {
			return ctrl.keynavEnabled || true;
		};
	}]		
});
angular.module("adoddle").component('msgDetail', {
	templateUrl: 'msgDetail.html',
	controller: ['$scope', '$rootScope', '$filter', '$timeout', '$window', 'lang', 'api', 'apiConfig', 'myConfig', 'downloadAssocDoc',
		function ($scope, $rootScope, $filter, $timeout, $window, lang, api, apiConfig, myConfig, downloadAssocDoc) {
			var ctrl = this;
			var isBroadcastMsg = 0;

			// initialization
			ctrl.$onInit = function () {
				ctrl.xhr = false;

				$scope.msgDetail = undefined;
				$scope.msgThread = undefined;
				$scope.mainThread = undefined;
				$scope.isDirectLinkOpen = false;
				$scope.priv = {
					canPrint: false,
					canAccessAuditInfo: false
				};

				fetch();
				listen();
			};

			var listen = function () {
				$scope.$on("thread:load", onThreadLoad);
				$scope.$on('thread:change', onThreadChange);

				$window.addEventListener('message', function(e) {
					if(typeof e.data !== 'string') { return; }
					var data = e.data.split('::');
					if(data[0] == 'close') {						
						if(data[1] && data[1] == "reload") {
							if(data[2] && data[2] == "parentreload") {
								// refresh for Projects Listing in Market Place.
								$window.top.opener.postMessage(JSON.stringify({refreshOppo:true}), "*");									
							}
							$window.location.reload();
						}						
					}
				}, false);
			};

			var unescapeStr = function (s) {
				var t = document.createElement('textarea');
				t.innerHTML = s || "";
				return t.value;
			};

			var onSuccess = function (response) {
				$timeout(function () {
					ctrl.xhr = false;
				});

				var data = response[0];
				if(response.error){
					angular.element(document.getElementById('formWrapper')).html(response.message);
				  }
				else if (data.allowViewRes === 'true') { // remove script string
					if (data.html) {
						data.html = data.html.replace("<!--#Script##Script#-->", "");
						angular.element(document.getElementById('formWrapper')).html(data.html);
					}
				} else {
					angular.element(document.getElementById('formWrapper')).html(lang.get('restrict-message-for-tender-response'));
				}

				// sort the users names
				data.sent = unescapeStr(data.sent);
				data.sent = data.sent ? $filter('orderBy')(data.sent.split(/[\s]*,[\s]*/)) : [];

				$scope.msgDetail = data;
				isBroadcastMsgLoad();

				// set AppBuilderFormIDCode variable which is used in infojet
				if (data.allowViewRes === 'true' && $window.InfoJet_Init) {
					$window.AppBuilderFormIDCode = data.appBuilderFormIDCode;
					$window.customMethod_onLoad_OnPostbackEnd && $window.customMethod_onLoad_OnPostbackEnd();
					$window.InfoJet_Init();
				}
			};

			var fetch = function () {
				var thread = $scope.msgThread || {}, formTypeId = myConfig.formTypeId;
				if (!myConfig.viewAlwaysFormAssociation) {
					formTypeId = thread.formTypeId || myConfig.formTypeId;
				}

				var obj = {
					action_id: apiConfig.VIEW_FORM_MSG_DETAILS_ACTION,
					currentPageNo: 1,
					commId: myConfig.commId,
					projectId: myConfig.projectId,
					msgId: thread.msgId || myConfig.msgId,
					folderId: thread.folderId || myConfig.folderId || "",
					formNum: thread.formNum || "",
					form_type_id: formTypeId,
					callerApp: 10, //CALLER_ADODDLE,
					viewAlwaysFormAssociation: myConfig.viewAlwaysFormAssociation,
					assocParentProjectId: myConfig.assocParentProjectId
				};

				if (myConfig.assocParentFormTypeId) {
					obj.assocParentFormTypeId = myConfig.assocParentFormTypeId;
				}

				ctrl.xhr && ctrl.xhr.abort();
				var xhr = api.ajax({
					url: apiConfig.PUBLIC_VIEW_FORM,
					data: obj,
					_dcId: thread.dcId
				});

				xhr.then(onSuccess, function (xhr) {
					if (xhr.status != -1)
						ctrl.xhr = xhr;
					else
						ctrl.xhr = false;
					xhr.errorTitle = lang.get("message-details-error-msg");
					api.showServerErrMsg(xhr);
				});

				$timeout(function () {
					ctrl.xhr = xhr;
				});
			};

			var setInitialMsgDetails = function (thread, threadLoad) {
				if (threadLoad && $scope.msgDetail) {
					$scope.msgDetail.sent = thread.sentNames ? thread.sentNames : $scope.msgDetail.sent;
					$scope.msgDetail.sent = $filter('orderBy')($scope.msgDetail.sent || []);
					return;
				}

				$scope.msgDetail = {
					originatorUserId: thread.hashedMsgOriginatorId,
					originatorImage: thread.originator,
					msgOriginator: thread.originatorDisplayName,
					sent: $filter('orderBy')(thread.sentNames || []),
					updated: thread.msgCreatedDate
				};
			};

			var onThreadChange = function (event, thread) {
				$scope.msgThread = thread;

				setInitialMsgDetails(thread);
				fetch();
			};

			var onThreadLoad = function (event, data) {
				if (!data || !data.length) {
					return;
				}

				$scope.mainThread = data[0];

				var i, thread, targetMsgId = myConfig.msgId;
				if ($scope.msgThread) {
					targetMsgId = $scope.msgThread.msgId;
				}

				for (i = 0; i < data.length; i++) {
					thread = data[i];
					if (parseInt(thread.msgId.split("$$")[0]) == parseInt(targetMsgId.split("$$")[0])) {
						$scope.msgThread = thread;
						setInitialMsgDetails(thread, true);
						break;
					}
				}

				isBroadcastMsgLoad();
			}

			var isBroadcastMsgLoad = function () {
				//This function broadcasts only after receiving response from communications ids 114 & 115
				if (isBroadcastMsg > 0) {
					$timeout(function () {
						$rootScope.$broadcast('msg:load', $scope.msgDetail);
					}, 100);
					return;
				}

				isBroadcastMsg++;
			}

			$window.launchCreateForm = function (appBuilderFIDC) { };

			$window.launchCreateFormFromView = function (appBuilderFIDC) { };

			$window.setAssocAndAttachFlag = function (extraParam) { };

			$window.editOriForXsnLink = function (editORIDraftMsgId, parentMsgId, formTypeId, projectId, formId) { };

			$window.downloadAllAttachAndAssocZip = function () { };

			var downloadAllAttachAssocXhr = false;
			$window.downloadAllAttachAndAssocLatestRevZip = function () {
				if (downloadAllAttachAssocXhr) {
					return;
				}
				downloadAllAttachAssocXhr = api.ajax({
					url: apiConfig.DOWNLOAD_DOCUMENT_FROM_PUBLIC_FORM,
					data: {
						action_id: apiConfig.PUBLIC_SAVE_MODEL_ACTION_LATEST_REV_ZIP,
						rmft: myConfig.formTypeId,
						msgId: ($scope.msgThread || {}).msgId || myConfig.msgId,
						formId: myConfig.formId,
						project_id: myConfig.projectId
					}
				});

				downloadAllAttachAssocXhr.then(function (data) {
					downloadAssocDoc.init({
						projectId: data.hashProjectId,
						nonCDNDownloadUrl: data.nonCDNDownloadUrl,
						isLimitExist: data.isLimitExist,
						baseUrl: myConfig.baseUrl,
						downloadSecondaryFile: data.downloadSecondaryFile,
						downloadRevDocListJSON: data.downloadRevDocListJSON,
						isFromPublicDomain : true,
					}, function () {
						downloadAllAttachAssocXhr = false;
					});
				}, function (xhr) {
					downloadAllAttachAssocXhr = false;
					xhr.errorTitle = lang.get("server-error");
					api.showServerErrMsg(xhr);
				});
			};

		}],
	bindings: {

	}
});

angular.module("adoddle").component('formThread', {
	templateUrl: 'formThread.html',
	controller: ['$scope', '$element', '$rootScope', '$timeout', 'api', 'apiConfig', 'myConfig', 'lang', 'ddchild',
		function ($scope, $element, $rootScope, $timeout, api, apiConfig, myConfig, lang, ddchild) {
			var ctrl = this;

			// initialization
			ctrl.$onInit = function () {
				ctrl.xhr = false;
				ctrl.data = undefined;
				ctrl.targetMsgId = undefined;
				ctrl.activeMsgId = undefined;

				$scope.mainThread = undefined;
				$scope.unreadCount = 0;

				localStorage && fetch(null, localStorage.getItem('dock'));

				ddchild.register($scope, 'form-thread');
			};

			var updateUnreadCount = function () {
				var data = $scope.formData;
				if (!data || !data.length) {
					return;
				}

				var i, thread, count = 0, indent,
					msgIdList = [],
					marginTop = 10,
					threadHeight = 61;

				for (i = 0; i < data.length; i++) {
					thread = data[i];
					if (thread.noOfActions > 0) {
						count += thread.noOfActions;
					}

					indent = thread.indent;

					var pMsgId = thread.parentMsgId + "";
					if (msgIdList.indexOf(pMsgId) > -1) {
						var cnt = (i - msgIdList.indexOf(pMsgId) - 1);
						thread.distance = (cnt * threadHeight) + (cnt * marginTop) + marginTop + (threadHeight / 2);
					}

					msgIdList.push(thread.msgId.split('$$')[0]);
				}

				$scope.unreadCount = count;
			}

			var setTargetMsgId = function (data) {
				var i, thread;
				ctrl.targetMsgId = myConfig.msgId;
				ctrl.activeMsgId = myConfig.msgId;
				if (myConfig.toOpen == "FromForms") {
					for (i = 0; i < data.length; i++) {
						thread = data[i];
						if (parseInt(thread.msgId.split("$$")[0]) > parseInt(ctrl.targetMsgId.split("$$")[0])) {
							ctrl.targetMsgId = thread.msgId;
						}
					}
				}
			};

			var findThread = function (msgId) {
				if (!msgId)
					return;

				var i, j, thread, data = $scope.formData;

				for (i = 0; i < data.length; i++) {
					thread = data[i];
					if (thread.msgId.split("$$")[0] == msgId.split("$$")[0]) {
						return thread;
					}
				}
			};

			var fetch = function (silent, openOnLoad) {
				if (ctrl.xhr && ctrl.xhr.abort) {
					return;
				}

				var paramsObj = {
					action_id: apiConfig.VIEW_FORM_ACTION,
					currentPageNo: 1,
					commId: myConfig.commId,
					projectId: myConfig.projectId,
					msgId: myConfig.msgId
				};

				if (myConfig.viewAlwaysFormAssociation) {
					paramsObj.viewAlwaysFormAssociation = myConfig.viewAlwaysFormAssociation;
					paramsObj.formTypeId = myConfig.formTypeId;
					paramsObj.assocParentProjectId = myConfig.assocParentProjectId;
					paramsObj.assocParentFormTypeId = myConfig.assocParentFormTypeId;
				}

				var xhr = api.ajax({
					url: apiConfig.PUBLIC_VIEW_FORM,
					data: paramsObj
				});

				if (!silent) {
					ctrl.xhr = xhr;
				}

				xhr.then(function (data) {
					ctrl.xhr = false;
					data = data || {};

					!ctrl.targetMsgId && setTargetMsgId(data.data);

					$scope.formData = data.data;
					$scope.mainThread = data.data[0];
					updateUnreadCount();

					angular.element('#form-thread-btn').append(angular.element('#thread-unread-count'));

					$timeout(function () {
						$rootScope.$broadcast("thread:load", data.data);

						if (openOnLoad === 'true') {
							$rootScope.$broadcast('dd:open', { name: 'form-thread' });
						}
					});
				}, function (xhr) {
					if (xhr.status != -1)
						ctrl.xhr = xhr;
					else
						ctrl.xhr = false;
					xhr.errorTitle = lang.get("form-thread-data-error-msg");
					api.showServerErrMsg(xhr);
				});
			};

			var changeMsg = function (msg) {
				if (typeof msg != 'object') {
					msg = findThread(msg);
				}

				if (ctrl.activeMsgId == msg.msgId) {
					return;
				}

				ctrl.activeMsgId = msg.msgId;

				// close dropdown
				$rootScope.$broadcast("dd:close");
				$rootScope.$broadcast("thread:change", msg);
			};

			ctrl.refresh = function (silent) {
				fetch(silent);
			};

			ctrl.threadClick = function (event, msg) {
				changeMsg(msg);
			};
		}],
	bindings: {
		trigger: '<'
	}
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyIsInB1YmxpYy5mb3JtLnZpZXcuanMiLCJjdXN0b20uZHJvcGRvd24uanMiLCJwdWJsaWMubXNnLmRldGFpbC5qcyIsInB1YmxpYy5mb3JtLnRocmVhZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2p1SkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDN0tBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDL1lBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQzVPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6InBvc3RQdWJsaWNWaWV3Rm9ybUJ1bmRsZTEuanMiLCJzb3VyY2VzQ29udGVudCI6WyJhbmd1bGFyLm1vZHVsZShcImFkb2RkbGVcIilcclxuICAgIC5jb25maWcoWyckY29tcGlsZVByb3ZpZGVyJywgJyRzY2VEZWxlZ2F0ZVByb3ZpZGVyJywgJyRxUHJvdmlkZXInLCAnTm90aWZpY2F0aW9uUHJvdmlkZXInLFxyXG4gICAgICAgIGZ1bmN0aW9uKCRjb21waWxlUHJvdmlkZXIsICRzY2VEZWxlZ2F0ZVByb3ZpZGVyLCAkcVByb3ZpZGVyLCBOb3RpZmljYXRpb25Qcm92aWRlcikge1xyXG4gICAgICAgICAgICAvLyByZW1vdmUgbG9va2luZyBmb3IgY3NzIGFuZCBjb21tZW50IGRpcmVjdGl2ZXNcclxuICAgICAgICAgICAgJGNvbXBpbGVQcm92aWRlci5jb21tZW50RGlyZWN0aXZlc0VuYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICAkY29tcGlsZVByb3ZpZGVyLmNzc0NsYXNzRGlyZWN0aXZlc0VuYWJsZWQoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgJHNjZURlbGVnYXRlUHJvdmlkZXIucmVzb3VyY2VVcmxXaGl0ZWxpc3QoW1xyXG4gICAgICAgICAgICAgICAgLy8gQWxsb3cgc2FtZSBvcmlnaW4gcmVzb3VyY2UgbG9hZHMuXHJcbiAgICAgICAgICAgICAgICAnc2VsZicsXHJcbiAgICAgICAgICAgICAgICAvLyBBbGxvdyBsb2FkaW5nIGZyb20gb3VyIGFzc2V0cyBkb21haW4uICBOb3RpY2UgdGhlIGRpZmZlcmVuY2UgYmV0d2VlbiAqIGFuZCAqKi5cclxuICAgICAgICAgICAgICAgICdodHRwczovLyouYXNpdGUuY29tLyoqJyxcclxuICAgICAgICAgICAgICAgICdodHRwOi8vKi5hc2l0ZS5hc2l0ZWhxLmNvbS8qKicsXHJcbiAgICAgICAgICAgICAgICAnaHR0cHM6Ly9pb3RzYi5hc2l0ZS5jb20vKionLFxyXG4gICAgICAgICAgICAgICAgJ2h0dHBzOi8vaW90LmFzaXRlLmNvbS8qKidcclxuICAgICAgICAgICAgXSk7XHJcblxyXG4gICAgICAgICAgICAvL2NvbmZpZ3VyZSB0aGUgZXJyb3IgaGFuZGxpbmcgYmVoYXZpb3JcclxuICAgICAgICAgICAgLy9zZXQgdG8gZmFsc2UgYnkgZGVmYXVsdCB0byBwcmV2ZW50IHVud2FudGVkIGVycm9ycyBvbiBhamF4IGZhaWxcclxuICAgICAgICAgICAgJHFQcm92aWRlci5lcnJvck9uVW5oYW5kbGVkUmVqZWN0aW9ucyhmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICAvLyBkZWZhdWx0IG5vdGlmaWNhdGlvbiBzZXR0aW5nc1xyXG4gICAgICAgICAgICBOb3RpZmljYXRpb25Qcm92aWRlci5zZXRPcHRpb25zKHtcclxuICAgICAgICAgICAgICAgIGRlbGF5OiA1MDAwLFxyXG4gICAgICAgICAgICAgICAgc3RhcnRUb3A6IDIwLFxyXG4gICAgICAgICAgICAgICAgc3RhcnRSaWdodDogMTAsXHJcbiAgICAgICAgICAgICAgICB2ZXJ0aWNhbFNwYWNpbmc6IDIwLFxyXG4gICAgICAgICAgICAgICAgaG9yaXpvbnRhbFNwYWNpbmc6IDIwLFxyXG4gICAgICAgICAgICAgICAgcG9zaXRpb25YOiAnY2VudGVyJyxcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uWTogJ3RvcCdcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgXSlcclxuXHJcbi52YWx1ZSgnZ2xvYmFsVmFyJywge1xyXG4gICAgcmV0YWluTm9PZlNob3c6IDEwXHJcbn0pXHJcblxyXG4vKipcclxuICogbGFuZ3VhZ2Ugc2VydmljZS5cclxuICogVGhpcyBtb2R1bGUgd2lsbCBwcm92aWRlIGludGVybmF0aW9uYWxpemF0aW9uLlxyXG4gKiBAbW9kdWxlIGFwaVxyXG4gKi9cclxuLnNlcnZpY2UoJ2xhbmcnLCBbJyR3aW5kb3cnLCBmdW5jdGlvbigkd2luZG93KSB7XHJcbiAgICB0aGlzLmdldCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiAkd2luZG93Lkxhbmd1YWdlLmdldC5hcHBseSgkd2luZG93Lkxhbmd1YWdlLCBhcmd1bWVudHMpO1xyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLmdldExhbmdPYmogPSBmdW5jdGlvbigpIHtcclxuICAgICAgICByZXR1cm4gJHdpbmRvdy5MYW5ndWFnZS5nZXRMYW5nT2JqKCk7XHJcbiAgICB9O1xyXG59XSlcclxuXHJcblxyXG4vKipcclxuICogYXBpQ29uZmlnIGNvbnN0YW50cy5cclxuICogVGhpcyBjb25zdGFudHMgcmVwcmVzZW50cyB0aGUgYWpheCBjb250cm9sbGVycywganNwIHVybHMsIGFjdGlvbiBpZHMsIHByaXZpbGVnZXMsIGV0Yy4uLlxyXG4gKiBAbW9kdWxlIGZvcm1BcHBcclxuICovXHJcbi5jb25zdGFudCgnYXBpQ29uZmlnJywge1xyXG4gICAgLy8gY29udHJvbGxlcnNcclxuICAgIExBTkdVQUdFX0NPTlRST0xMRVI6ICcvYWRvZGRsZS9sYW5ndWFnZScsXHJcbiAgICBEQVNIQk9BUkRfQ09OVFJPTExFUjogJy9hZG9kZGxlL2Rhc2hib2FyZCcsXHJcbiAgICBIT01FX0NPTlRST0xMRVI6ICcvYWRvZGRsZS9ob21lJyxcclxuICAgIExJU1RJTkdfQ09OVFJPTExFUjogJy9hZG9kZGxlL2xpc3RpbmcnLFxyXG4gICAgQ09NTVVOSUNBVElPTlNfQ09OVFJPTExFUjogJy9hZG9kZGxlL2NvbW11bmljYXRpb25zJyxcclxuICAgIFBVQkxJQ19WSUVXX0ZPUk06ICcvYWRvZGRsZXB1YmxpYy9wdWJsaWNWaWV3Rm9ybScsXHJcbiAgICBET0NVTUVOVF9DT05UUk9MTEVSOiAnL2Fkb2RkbGUvZmlsZXMnLFxyXG4gICAgUFJPSkVDVFNfQ09OVFJPTExFUjogJy9hZG9kZGxlL3Byb2plY3RzJyxcclxuICAgIEFDVElPTlNfQ09OVFJPTExFUjogJy9hZG9kZGxlL2FjdGlvbnMnLFxyXG4gICAgQVBQU19DT05UUk9MTEVSOiAnL2Fkb2RkbGUvYXBwcycsXHJcbiAgICBET1dOTE9BRF9DT05UUk9MTEVSOiAnL2Fkb2RkbGUvZG93bmxvYWQnLFxyXG4gICAgUFVCTElDX0RPV05MT0FEX0NPTlRST0xMRVI6ICcvYWRvZGRsZXB1YmxpYy9wdWJsaWNEb3dubG9hZCcsXHJcbiAgICBHRVRfRklFTERfRU5BQkxFX1BST0pFQ1Q6ICcvYWRvZGRsZW5hdmlnYXRvcmFwaS93b3Jrc3BhY2UvZmllbGRFbmFibGVkU2VsZWN0ZWRQcm9qZWN0cycsXHJcbiAgICBESVNUUklCVVRJT05fQ09OVFJPTExFUjogJy9hZG9kZGxlL2Rpc3QnLFxyXG4gICAgVVBMT0FEX0NPTlRST0xMRVI6ICcvYWRvZGRsZS91cGxvYWQnLFxyXG4gICAgQURPRERMRV9VUExPQURfQ09OVFJPTExFUjogJy9hZG9kZGxlL2Fkb2RkbGVVcGxvYWQnLFxyXG4gICAgUFJPQ1VSRU1FTlRfQ09OVFJPTExFUjogJy9hZG9kZGxlL3Byb2N1cmVtZW50JyxcclxuICAgIE1PREVMU19DT05UUk9MTEVSOiAnL2Fkb2RkbGUvbW9kZWxzJyxcclxuICAgIEhPT1BTX01BUktVUF9DT05UUk9MTEVSOiAnL2Fkb2RkbGUvaG9vcHNtYXJrdXAnLFxyXG4gICAgSE9PUFNfQ09OVFJPTExFUjogJy9hZG9kZGxlL2hvb3BzJyxcclxuICAgIEZFREVSQVRFRF9NT0RFTFNfQ09OVFJPTExFUjogJy9hZG9kZGxlL29iamVjdE1hbmFnZXJDb250cm9sbGVyJyxcclxuICAgIEVYUE9SVF9DT05UUk9MTEVSOiAnL2Fkb2RkbGUvZXhwb3J0JyxcclxuICAgIEFTSVRFX1BPUFVQX0NPTlRST0xMRVI6ICcvYWRvZGRsZS9nZXRQb3B1cERhdGEnLFxyXG4gICAgU0VBUkNIX0ZJTFRFUl9DT05UUk9MTEVSOiAnL2Fkb2RkbGUvZmlsdGVyJyxcclxuICAgIEJBVENIX0NPTlRST0xMRVI6IFwiL2Fkb2RkbGUvYmF0Y2hcIixcclxuICAgIENSRUFURV9DT01NRU5UX0NPTlRST0xMRVI6ICcvYWRvZGRsZS9DcmVhdGVDb21tZW50JyxcclxuICAgIE1PREVMU19DT01NRU5UU19DT05UUk9MTEVSOiBcIi9hZG9kZGxlL01vZGVsQ29tbWVudFwiLFxyXG4gICAgU0FWRV9DT01NRU5UX0NPTlRST0xMRVI6IFwiL2Fkb2RkbGUvU2F2ZUNvbW1lbnRcIixcclxuICAgIFNBVkVfQkFUQ0hfQ09NTUVOVF9DT05UUk9MTEVSOiBcIi9hZG9kZGxlL1NhdmVCYXRjaENvbW1lbnRcIixcclxuICAgIFNIQVJFX0xJTktfQ09OVFJPTExFUjogXCIvYWRvZGRsZS9zaGFyZWxpbmtcIixcclxuICAgIEdFVF9VU0VSX1NIQVJFX1BFUk1JU1NJT046ICdzaGFyZWxpbmsvZ2V0VXNlclBlcm1pc3Npb24nLFxyXG4gICAgQ09OVEFDVF9DT05UUk9MTEVSOiBcIi9hZG9kZGxlL2NvbnRhY3RzXCIsXHJcbiAgICBET1dOTE9BRF9ET0NVTUVOVF9GUk9NX0ZPUk06IFwiL2Fkb2RkbGUvZG93bmxvYWREb2NBc3NvY2lhdGlvbnNcIixcclxuICAgIERPV05MT0FEX0RPQ1VNRU5UX0ZST01fUFVCTElDX0ZPUk06IFwiL2Fkb2RkbGVwdWJsaWMvcHVibGljRG93bmxvYWRcIixcclxuICAgIFVTRVJfUFJFRkVSRU5DRVNfQ09OVFJPTExFUjogJy9hZG9kZGxlL3ByZWZlcmVuY2VzJyxcclxuICAgIFBVQkxJU0hfUERGX0NPTlRST0xMRVI6ICcvYWRvZGRsZS9QdWJsaXNoUGRmJyxcclxuICAgIFdPTV9ESUFHUkFNX0NPTlRST0xMRVI6ICcvYWRvZGRsZS93b20vZGlhZ3JhbS12aWV3ZXInLFxyXG4gICAgV09NX1dPUktGTE9XU19DT05UUk9MTEVSOiAnL2Fkb2RkbGUvd29tL3dvcmtmbG93JyxcclxuXHJcbiAgICAvLyBjb21tb25hcGlcclxuICAgIEdFVF9DVVNUT01fT0JKRUNUX1RFTVBMQVRFX0xJU1Q6ICcvY29tbW9uYXBpL2Fkb2RkbGVDdXN0b21PYmplY3QvZ2V0Q3VzdG9tT2JqZWN0VGVtcGxhdGVMaXN0JyxcclxuICAgIEdFVF9DVVNUT01fT0JKRUNUX0NPTU1FTlRfTElTVDogJy9jb21tb25hcGkvYWRvZGRsZUN1c3RvbU9iamVjdC9nZXRDdXN0b21PYmplY3RDb21tZW50TGlzdCcsXHJcbiAgICBDUkVBVEVfQ1VTVE9NX09CSkVDVF9DT01NRU5UOiAnL2NvbW1vbmFwaS9hZG9kZGxlQ3VzdG9tT2JqZWN0L2NyZWF0ZUN1c3RvbU9iamVjdENvbW1lbnQnLFxyXG4gICAgU0FWRV9DVVNUT01fT0JKRUNUX01PREVMX1ZJRVc6ICcvY29tbW9uYXBpL2Fkb2RkbGVDdXN0b21PYmplY3Qvc2F2ZUN1c3RvbU9iamVjdFZpZXcnLFxyXG4gICAgU0FWRV9DVVNUT01fT0JKRUNUX0NPTU1FTlQ6ICcvY29tbW9uYXBpL2Fkb2RkbGVDdXN0b21PYmplY3Qvc2F2ZUN1c3RvbU9iamVjdENvbW1lbnQnLFxyXG4gICAgVVBEQVRFX0NVU1RPTV9PQkpFQ1RfQ09NTUVOVF9BQ1RJT046ICcvY29tbW9uYXBpL2Fkb2RkbGVDdXN0b21PYmplY3QvdXBkYXRlQ3VzdG9tT2JqZWN0Q29tbWVudEFjdGlvbicsXHJcbiAgICBHRVRfQ1VTVE9NX09CSkVDVF9BVURJVF9UUkFJTF9ERVRBSUxfTElTVDogJy9jb21tb25hcGkvYWRvZGRsZUN1c3RvbU9iamVjdC9nZXRDdXN0b21PYmplY3RBdWRpdFRyYWlsRGV0YWlsTGlzdCcsXHJcbiAgICBHRVRfUkVWSUVXU19GT1JfQ09PUkRJTkFUSU9OX0FDVElPTjogJy9jb21tb25hcGkvYWRvZGRsZUN1c3RvbU9iamVjdC9nZXRSZXZpZXdzRm9yQ29vcmRpbmF0aW9uQWN0aW9uJyxcclxuICAgIFNBVkVfQ1VTVE9NX09CSkVDVF9SRVZJRVdfQ09PUkRJTkFUSU9OOiAnL2NvbW1vbmFwaS9hZG9kZGxlQ3VzdG9tT2JqZWN0L3NhdmVDdXN0b21PYmplY3RSZXZpZXdDb29yZGluYXRpb24nLFxyXG4gICAgRVhQT1JUX0JDRl9JU1NVRTogJy9jb21tb25hcGkvaXNzdWUvZXhwb3J0SXNzdWVCQ0YnLFxyXG4gICAgUFJFUEFSRV9FWFBPUlRfQkNGX0lTU1VFOiAnL2NvbW1vbmFwaS9pc3N1ZS9wcmVwYXJlRXhwb3J0SXNzdWVCQ0YnLFxyXG4gICAgTEFOR1VBR0VfQ09OVFJPTExFUl9LRVlfVkFMVUU6ICcvY29tbW9uYXBpL2xhbmd1YWdlL2dldExhbmd1YWdlS2V5VmFsdWVzJyxcclxuICAgIEdFVF9MT0NBVElPTl9UUkVFOiAnL2NvbW1vbmFwaS9wZmxvY2F0aW9uc2VydmljZS9nZXRMb2NhdGlvblRyZWUnLFxyXG4gICAgR0VUX1hPRF9GSUxFOiAnL2NvbW1vbmFwaS93ZWJ2aWV3ZXJzZXJ2aWNlL2Rvd25sb2FkWE9EJyxcclxuICAgIE1BUktVUFNfTElTVElOR19DT05UUk9MTEVSOiBcIi9jb21tb25hcGkvbWFya3Vwcy9saXN0aW5nXCIsXHJcbiAgICBTRUFSQ0hfUkVTT1VSQ0VfTElTVDogXCIvY29tbW9uYXBpL3NoYXJlL2dldFJlc291cmNlc1wiLFxyXG4gICAgRklMTF9TSEFSRV9GSUxURVJfUkVTT1VSQ0VfTElTVDogXCIvY29tbW9uYXBpL3NoYXJlL2dldFJlc291cmNlc0J5SWRcIixcclxuICAgIEdFVF9XT1JLU1BBQ0VfU0VUVElORzogJy9jb21tb25hcGkvd29ya3NwYWNlL2dldFdvcmtzcGFjZVNldHRpbmcnLFxyXG4gICAgVklFV19NQVJLVVA6ICcvY29tbW9uYXBpL3dlYnZpZXdlcnNlcnZpY2Uvdmlld01hcmt1cCcsXHJcbiAgICBDSEVDS19VU0VSX0xBVEVTVF9SRVZJU0lPTl9BUEk6ICcvY29tbW9uYXBpL2RvY3VtZW50L2NoZWNrVXNlckxhdGVzdFJldmlzaW9uJyxcclxuICAgIE1BUktVUF9MSVNUOiAnL2NvbW1vbmFwaS9tYXJrdXBzL2xpc3RpbmcnLFxyXG4gICAgR0VUX1dPUktTUEFDRV9TRVRUSU5HX01BUktVUDogJy9jb21tb25hcGkvbWFya3Vwcy9nZXR3b3Jrc3BhY2VzZXR0aW5nJyxcclxuICAgIEdFVF9NQVJLVVBJRF9CWU5BTUU6ICcvY29tbW9uYXBpL21hcmt1cHMvZ2V0TWFya3VwSWRCeU5hbWUnLFxyXG4gICAgUFJFX1VQTE9BRF9WQUxJREFUSU9OX0FQSV9VUkw6ICcvY29tbW9uYXBpL2V2ZW50L3VwbG9hZEV2ZW50VmFsaWRhdGlvbicsXHJcbiAgICBHRVRfRklMRV9BVFRSSUJVVEVTX0FQSTogJy9jb21tb25hcGkvZG9jdW1lbnQvZ2V0RmlsZUF0dHJpYnV0ZXMnLFxyXG4gICAgVVBEQVRFX0ZJTEVfQVRUUklCVVRFU19BUEk6ICcvY29tbW9uYXBpL2RvY3VtZW50L3VwZGF0ZUZpbGVBdHRyaWJ1dGVzJyxcclxuICAgIEFDVElWQVRFX1VTRVJfU0VTU0lPTjogJy9jb21tb25hcGkvbG9naW4vYWN0aXZhdGVVc2VyU2Vzc2lvbicsXHJcbiAgICBHRVRfU0VTU0lPTl9USU1FT1VUX0RFVEFJTFM6ICcvY29tbW9uYXBpL2xvZ2luL2dldFNlc3Npb25UaW1lb3V0RGV0YWlscycsXHJcbiAgICBNRURJQV9DT01QTEVURV9BQ1RJT046ICdjb21tb25hcGkvbWVkaWEvY29tcGxldGVBY3Rpb24nLFxyXG4gICAgR0VUX0RJU1RfV0lTRV9VU0VSX0xJU1Q6ICdjb21tb25hcGkvbWFuYWdlQWRvZGRsZU9iamVjdFByaXZhY3kvZ2V0VXNlckxpc3RGb3JHaXZlblJlc291cmNlJyxcclxuICAgIEdFVF9MT0NBVElPTl9ERVRBSUxTX0JZX0xPQ0FUSU9OOiAnY29tbW9uYXBpL3BmbG9jYXRpb25zZXJ2aWNlL2dldExvY2F0aW9uRGV0YWlsc0J5TG9jYXRpb25JZHMnLFxyXG4gICAgR0VUX09CU0VSVkFUSU9OX0xJU1RfQllfUExBTjogJ2NvbW1vbmFwaS9wZm9ic2VydmF0aW9uc2VydmljZS9nZXRPYnNlcnZhdGlvbkxpc3RCeVBsYW4nLFxyXG5cdEdFVF9BQ1RJVklUWV9MT0NLX0lEUzogXCIvY29tbW9uYXBpL2xvY2svZ2V0T2JqZWN0QWN0aXZpdHlMb2NrZWRJZHNcIixcclxuICAgIEdFVF9QUk9KRUNUX0FQUERFVEFJTF9CWV9GT1JNX1RZUEVfTkFNRTogXCIvY29tbW9uYXBpL2Zvcm0vZ2V0UHJvamVjdEFwcFR5cGVEZXRhaWxzQnlGb3JtVHlwZU5hbWVcIiwgICAgXHJcbiAgICBUSFVNQk5BSUxfVklFV19URU1QX1BBVEg6IFwiL2NvbW1vbmFwaS90aHVtYm5haWwvdmlld1RlbXBUaHVtYlwiLFxyXG4gICAgVEhVTUJOQUlMX1ZJRVdfUEFUSDogXCIvY29tbW9uYXBpL3RodW1ibmFpbC92aWV3VGh1bWJcIixcclxuICAgIEhFTFBfRklMRV9DT05URU5UOiAnL2NvbnRleHRoZWxwZXIvJyxcclxuICAgIFZJRVdfRUxFQVJOSU5HOiBcIi9hZG9kZGxlL3ZpZXcvZXh0ZXJuYWxhcHAvZWxlYXJuaW5nLmpzcFwiLFxyXG4gICAgSEVMUF9GSUxFX0ZSRUVNSVVNX0NPTlRFTlQ6IFwiL0ZyZWVtaXVtX2NvbnRleHRoZWxwZXIvXCIsXHJcbiAgICBHRVRfRVhUUkFDVEVEX1pJUF9GSUxFOiAnL2NvbW1vbmFwaS93ZWJ2aWV3ZXJzZXJ2aWNlL2dldEZpbGVzV2l0aEluQ29tcHJlc3NlZEZpbGUnLFxyXG4gICAgU0FWRV9DVVNUT01fT0JKRUNUIDogJy9jb21tb25hcGkvYWRvZGRsZUN1c3RvbU9iamVjdC9zYXZlQ3VzdG9tT2JqZWN0JyxcclxuICAgIFVQREFURV9DVVNUT01fT0JKRUNUIDogJy9jb21tb25hcGkvYWRvZGRsZUN1c3RvbU9iamVjdC91cGRhdGVDdXN0b21PYmplY3QnLFxyXG4gICAgR0VUX0NVU1RPTV9PQkpFQ1RfVEVNUExBVEUgOiAnL2NvbW1vbmFwaS9hZG9kZGxlQ3VzdG9tT2JqZWN0L2dldEN1c3RvbU9iamVjdFRlbXBsYXRlJyxcclxuICAgIFNBVkVfQ1VTVE9NX09CSkVDVF9DT01NRU5UOiAnL2NvbW1vbmFwaS9hZG9kZGxlQ3VzdG9tT2JqZWN0L3NhdmVDdXN0b21PYmplY3RDb21tZW50JyxcclxuICAgIFxyXG4gICAgLy9Gb3IgUERGVHJvbiBjYWxpYnJhdGlvbiBkYXRhXHJcbiAgICBDQUxJQlJBVElPTl8yRF8zRF9BUEkgOiAnL2NvbW1vbmFwaS8yZDNkY2FsaWJyYXRpb24nLFxyXG5cclxuICAgIC8vIERvd25sb2FkXHJcbiAgICBJU19ET0NVTUVOVF9ET1dOTE9BRF9SRVNUUklDVEVEOiAnL2Rvd25sb2FkL2RvY3VtZW50L2lzRG93bmxvYWRSZXN0cmljdGVkJyxcclxuICAgIERPV05MT0FEX1NJTkdMRV9ET0NVTUVOVDogJy9kb3dubG9hZC9kb2N1bWVudC9zaW5nbGUnLFxyXG4gICAgQ0FOX0RPV05MT0FEX0ZPTERFUl9MRVZFTDogJy9kb3dubG9hZC9mb2xkZXIvY2FuRG93bmxvYWRGb2xkZXJMZXZlbCcsXHJcbiAgICBET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9DT05UUk9MTEVSOiAnL2Rvd25sb2FkL2RvY3VtZW50L2JhdGNoJyxcclxuICAgIERPV05MT0FEX0JBVENIX0RPQ1VNRU5UX1BBR0VfQ09OVFJPTExFUjogJy9kb3dubG9hZC9kb2N1bWVudC9kb3dubG9hZEJhdGNoRG9jdW1lbnRQYWdlJyxcclxuICAgIENIRUNLX0RPQ1VNRU5UX0RPV05MT0FEX0xJTUlUOiAnL2Rvd25sb2FkL2RvY3VtZW50L2NoZWNrRG93bmxvYWRMaW1pdCcsXHJcbiAgICBQUk9HUkVTU19aSVBfQ1JFQVRJT05fQ09OVFJPTExFUjogJy9kb3dubG9hZC9kb2N1bWVudC9nZXRaaXBQcm9ncmVzcycsXHJcbiAgICBET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9XSVRIX01BUktVUFNfQUNUSU9OX0NPTlRST0xMRVI6ICcvZG93bmxvYWQvZG9jdW1lbnQvYmF0Y2hXaXRoTWFya3VwJyxcclxuICAgIFBST0dSRVNTX0dFTkVSQVRFX01BUktVUF9BU19QREZfQ09OVFJPTExFUjogJy9kb3dubG9hZC9kb2N1bWVudC9tYXJrdXBQREZwcm9ncmVzcycsXHJcbiAgICBET1dOTE9BRF9URU1QX1pJUF9GSUxFX0NPTlRST0xMRVI6ICcvZG93bmxvYWQvZG9jdW1lbnQvZG93bmxvYWRUZW1wWmlwRmlsZScsXHJcbiAgICBBU1lOQ19OT1RJRklDQVRJT046ICcvY29tbW9uYXBpL2RvY3VtZW50L2FTeW5jTm90aWZpY2F0aW9uJywgLy8gc2VuZCBub3RpZmljYXRpb24gdG8gYVN5bmMgYXBwXHJcbiAgICBSRVZfVkFMSURfRk9SX0NIRUNLT1VUX09OX1JJR0hUQ0xJQ0tfQ09OVFJPTExFUjogJy9kb3dubG9hZC9kb2N1bWVudC9jaGVja1ZhbGlkRm9yQ2hlY2tPdXRPblJpZ2h0Q2xpY2snLFxyXG4gICAgQ0hFQ0tPVVRfUkVWSVNJT05fQ09OVFJPTExFUjogJy9kb3dubG9hZC9jaGVja291dC9jaGVja291dFJldmlzaW9uJyxcclxuICAgIEdFVF9DSEVDS09VVF9SRVZJU0lPTl9ERVRBSUxTX0NPTlRST0xMRVI6ICcvZG93bmxvYWQvY2hlY2tvdXQvZ2V0Q2hlY2tvdXRSZXZpc2lvbkRldGFpbHMnLFxyXG4gICAgQ0hFQ0tfQVZBSUxBQklMSVRZX09GX0RPV05MT0FEX0RPQ1VNRU5UX0NPTlRST0xMRVI6ICcvZG93bmxvYWQvZG9jdW1lbnQvY2hlY2tBdmFpbGFiaWxpdHlPZkRvd25sb2FkRG9jdW1lbnQnLFxyXG5cdERPV05MT0FEX0lOVEVSTkFMX0FUVEFDSE1FTlRfQ09OVFJPTExFUjogJy9kb3dubG9hZC9kb2N1bWVudC9pbnRlcm5hbEF0dGFjaG1lbnQnLFxyXG4gICAgRE9XTkxPQURfRVhUUkFDVEVEX1pJUF9GSUxFOiAnL2Rvd25sb2FkL2RvY3VtZW50L2V4dHJhY3RlZEZpbGUnLFxyXG4gICAgTVVMVElfRENfRE9XTkxPQURfQkFUQ0hfRE9DVU1FTlRfQUNUSU9OX0NPTlRST0xMRVI6ICcvZG93bmxvYWQvZG9jdW1lbnQvbXVsdGlEQ0JhdGNoJyxcclxuICAgIFVORE9fQ0hFQ0tPVVRfQ09OVFJPTExFUjogJy9kb3dubG9hZC9jaGVja291dC91bmRvQ2hlY2tvdXQnLFxyXG4gICAgRE9XTkxPQURfQ1VTVE9NX0ZPUk1fQVRUQUNITUVOVDogJy9kb3dubG9hZC9kb2N1bWVudC9kb3dubG9hZEN1c3RvbUZvcm1BdHRhY2htZW50JyxcclxuICAgIERPV05MT0FEX0ZPUk1fQVNTT0NJQVRJT05fQllQQVNTX1NFQ1VSSVRZOiAnL2Rvd25sb2FkL2RvY3VtZW50L2Rvd25sb2FkRm9ybUFzc29jaWF0aW9uQnlQYXNzU2VjdXJpdHknLFxyXG5cclxuICAgIC8vIGpzcFxyXG4gICAgRklMRV9WSUVXX01PQklMRTogXCIvYWRvZGRsZS92aWV3ZXIvZmlsZVZpZXcuanNwXCIsXHJcbiAgICBWSUVXX0ZPUk06IFwiL2Fkb2RkbGUvdmlldy9jb21tdW5pY2F0aW9ucy92aWV3Rm9ybS5qc3BcIixcclxuICAgIFBSSU5UX1ZJRVdfRk9STTogXCIvYWRvZGRsZS92aWV3L2NvbW11bmljYXRpb25zL2FwcHMvcHJpbnRWaWV3Rm9ybS5qc3BcIixcclxuICAgIEJBVENIX1BSSU5UX0ZPUk1fUEFHRTogXCIvYWRvZGRsZS92aWV3L2NvbW11bmljYXRpb25zL2FwcHMvYmF0Y2hQcmludEZvcm0uanNwXCIsXHJcbiAgICBGSUxFX1ZJRVdfUEFHRTogXCIvYWRvZGRsZS92aWV3ZXIvZmlsZVZpZXcuanNwXCIsXHJcbiAgICBBVFRBQ0hfRklMRV9WSUVXRVJfUFJFRkVSRU5DRTogXCIvYWRvZGRsZS92aWV3ZXIvYXR0YWNoRmlsZW9wZW5WaWV3ZXJwcmVmZXJlbmNlLmpzcFwiLFxyXG4gICAgVVBMT0FEX1JFRElSRUNUX1JFU1VMVDogXCIvYWRvZGRsZS9yZXN1bHQuanNwXCIsXHJcbiAgICBWSUVXX01PREVMX0ZPUl9XRUI6ICcvYWRvZGRsZS92aWV3ZXIvbW9kZWxWaWV3LmpzcCcsXHJcbiAgICBDT05JR1VSQUJMRV9DT0xVTU5fQ09OVFJPTExFUjogJy9hZG9kZGxlL2NvbmZpZ2NvbnRyb2xsZXInLFxyXG4gICAgQVRUQUNIX0ZJTEVfVklFV0VSX1BSRUZFUkVOQ0U6ICcvYWRvZGRsZS92aWV3ZXIvYXR0YWNoRmlsZW9wZW5WaWV3ZXJwcmVmZXJlbmNlLmpzcCcsXHJcbiAgICBIVE1MX0NPTVBBUkVfRE9DOiAnL2Fkb2RkbGUvdmlld2VyL2NvbXBhcmVEb2NzSFRNTFZpZXdlci5qc3AnLFxyXG4gICAgQUNUSVZFWF9DT01QQVJFX0RPQzogJy9hZG9kZGxlL3ZpZXdlci9jb21wYXJlLmpzcCcsXHJcbiAgICBWSUVXRVJfUEFSRU5UX1JFRlJFU0g6ICcvYWRvZGRsZS92aWV3ZXIvdmlld2VyUmVmcmVzaFBhcmVudC5qc3AnLFxyXG4gICAgU1RBUlRfU1RPUF9XQVRDSEVSOiAnL2NvbW1vbmFwaS93YXRjaCcsXHJcbiAgICBVUERBVEVfREFTSEJPQVJEX05PVElGSUNBVElPTjogJy9jb21tb25hcGkvd2F0Y2gvdXBkYWVEYXNoYm9hcmROb3RpZmljYXRpb25zU3RhdHVzJyxcclxuICAgIEdFVF9EQVNIQk9BUkRfTk9USUZJQ0FUSU9OOiAnL2NvbW1vbmFwaS93YXRjaC9nZXREYXNoYm9hcmROb3RpZmljYXRpb25zJyxcclxuICAgIE5PVElDRV9DT01NT05BUElfQUxMTk9USUNFOiAnL2NvbW1vbmFwaS9ub3RpY2UvYWN0aXZlTm90aWNlJyxcclxuICAgIE5PVElDRV9DT01NT05BUElfRElTTUlTUzogJy9jb21tb25hcGkvbm90aWNlL2Rpc21pc3MnLFxyXG4gICAgSU1BR0VfUEFUSDogJy9jb21tb25hcGkvdXNlci91c2VySW1nP3VzZXJJZD0nLFxyXG4gICAgV0FUQ0hfQ0hFQ0tfUEVSTUlTU0lPTjogJ2NvbW1vbmFwaS93YXRjaC9jaGVja1Blcm1pc3Npb24nLFxyXG4gICAgTE9DQUxfU1RPUkFHRTogJy9hZG9kZGxlL3ZpZXcvY29tbW9uL2xvY2FsU3RvcmFnZS5qc3AnLFxyXG4gICAgR0VUX0VYVEVSTkFMX09CSkVDVF9NQVBQSU5HOiAnL2NvbW1vbmFwaS9tb2RlbC9nZXRNb2RlbE9iamVjdEV4dGVybmFsTWFwcGluZycsXHJcbiAgICBHRVRfREFUQV9JTlNJR0hUX0RBU0hCT0FSRF9VUkw6Jy9jb21tb25hcGkvbW9kZWwvZ2V0TW9kZWxEYXRhSW5zaWdodERhc2hib2FyZFVSTE1hcHBpbmcnLFxyXG5cclxuICAgIC8vIGFjdGlvbiBpZHNcclxuICAgIEdFVF9ESVNUX0dST1VQX1VTRVJTOiA4NDAsXHJcbiAgICBMSVNUX1dPUktGTE9XUzogMSxcclxuICAgIEFET0RETEVfRk9MREVSX1RSRUU6IDIsXHJcbiAgICBXT1JLRkxPV19QUk9HUkVTUzogNCxcclxuICAgIEFET0RETEVfV09SS1NQQUNFX1RSRUU6IDUsXHJcbiAgICBBRE9ERExFX0RJU1RSSUJVVEVfRklMRVM6IDEwLFxyXG4gICAgRElTVFJJQlVURV9GT1JNOiAxMSxcclxuICAgIEFET0RETEVfV09SS1NQQUNFX0FORF9GT0xERVJfVFJFRV9MRVZFTDogMTQsXHJcbiAgICBBRE9ERExFX0FQUF9UWVBFX1dPUktTUEFDRV9UUkVFOiAxNixcclxuICAgIEFET0RETEVfQVBQX1RZUEVfRk9STV9UUkVFOiAxNyxcclxuICAgIENPTU1JVF9ESVNUUklCVVRJT046IDE5LFxyXG4gICAgQ09NUExFVEVfRk9SX0FDS05PV0xFREdFTUVOVF9BQ1RJT046IDIwLFxyXG4gICAgQ09NUExFVEVfRk9SX0FDVElPTjogMjEsXHJcbiAgICBGT1JNX0RJU1RfVkFMSURBVElPTjogMjYsXHJcbiAgICBQUkVWSU9VU0xZX0ZPUk1fRElTVF9VU0VSX0xJU1Q6IDI3LFxyXG4gICAgQURPRERMRV9MSVNUSU5HX0FDVElPTjogMTAwLFxyXG4gICAgU0FWRV9DT05GSUdVUkFCTEVfQ09MVU1OX0FDVElPTjogMTAyLFxyXG4gICAgRE9XTkxPQURfU0lOR0xFX0RPQ1VNRU5UX0FDVElPTjogMTAzLFxyXG4gICAgRE9XTkxPQURfSU5URVJOQUxfQVRUQUNITUVOVDogMTk3LFxyXG4gICAgR0VUX0xJU1RfRk9SX0RJU1RSSUJVVElPTjogMTA3LFxyXG4gICAgVklFV19GT1JNX0FDVElPTjogMTE0LFxyXG4gICAgVklFV19GT1JNX01TR19ERVRBSUxTX0FDVElPTjogMTE1LFxyXG4gICAgR0VUX0ZJTEVfQVRUUklCVVRFU19TRVQ6IDExNyxcclxuICAgIERJU1BMQVlfQVBQX1RFTVBMQVRFU19MSVNUOiAxMTgsXHJcbiAgICBET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9QQUdFOiAxMTksXHJcbiAgICBET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9BQ1RJT046IDEyMCxcclxuICAgIEdFVF9GSUxFX1BSRVZfUkVWSVNJT05fREVUQUlMUzogMTIyLFxyXG4gICAgVVBEQVRFX0NPTU1FTlRfQUNUSU9OOiAxMjQsXHJcbiAgICBET1dOTE9BRF9URU1QX1pJUF9GSUxFOiAxMjUsXHJcbiAgICBQUk9HUkVTU19aSVBfQ1JFQVRJT046IDEyNixcclxuICAgIERJU1BMQVlfUFJJTlRfVklFV19GT1JNOiAxMzIsXHJcbiAgICBHRVRfRklMRV9OQU1FX0ZPUl9SRVZJU0lPTjogMTM2LFxyXG4gICAgR0VUX1VQTE9BRF9TRVRUSU5HOiAxMzcsXHJcbiAgICBVUExPQURfRklMRV9WQUxJREFUSU9OOiAxMzgsXHJcbiAgICBVUExPQURfRklMRV9SVUxFU19WQUxJREFUSU9OOiAxMzksXHJcbiAgICBGSUxFX0RJU1RfVkFMSURBVElPTjogMTQwLFxyXG4gICAgVklFV19GSUxFX0RJU0NVU1NJT05TOiAxNDgsXHJcbiAgICBWSUVXX0ZJTEVfSElTVE9SWTogMTQ5LFxyXG4gICAgVklFV19GT1JNX0hJU1RPUlk6IDE1MCxcclxuICAgIEdFVF9TRUxFQ1RFRF9SRVZfQVRUUklCVVRFX1ZPOiAxNjIsXHJcbiAgICBBRE9ERExFX0ZPUk1fUEVSTUlTU0lPTlM6IDE2NyxcclxuICAgIE1VTFRJX0RDX0RPV05MT0FEX0JBVENIX0RPQ1VNRU5UX0FDVElPTjogMTY4LFxyXG4gICAgTU9WRV9GSUxFU19UT19URU1QX0xPQ0FUSU9OOiAxNzIsXHJcbiAgICBDSEVDS19SRVZfUkVTVFJJQ1RfRk9SX0RPV05MT0FEOiAxNzUsXHJcbiAgICBVUERBVEVfQVVESVRfVFJBSUxfRk9STV9BVFRBQ0hNRU5UOiAxNzksXHJcbiAgICBHRVRfRk9MREVSX1BFUk1JU1NJT05fVkFMVUU6IDgxOCxcclxuICAgIEFQUExFVF9VUExPQURfUEFHRTogMTc2LFxyXG4gICAgVVBEQVRFX01TR19TVEFUVVM6IDE4MSxcclxuICAgIENPUFlfRElTVFJJQlVUSU9OX0ZST01fUFJFVklPVVNfRElTVFJJQlVUSU9OOiAxODIsXHJcbiAgICBDT01NSVRfVVBMT0FEX0ZJTEVTX0RFVEFJTDogMTg0LFxyXG4gICAgRElTUExBWV9QUklOVF9WSUVXX0ZPUk1fQUxMOiAxODUsXHJcbiAgICBHRVRfUFVCTElTSEVEX0RPQ1NfRk9SX1BBTENFSE9MREVSOiAxOTIsXHJcbiAgICBWSUVXX0ZJTEVfQVRUQUNITUVOVF9BU1NPQ0lBVElPTjogMTkyLFxyXG4gICAgQ0hFQ0tfRk9SX0FLQU1BSV9ET1dOTE9BRF9MSU1JVDogMTkzLFxyXG4gICAgQ0hFQ0tfQVZBSUxBQklMSVRZX09GX0RPV05MT0FEX0RPQ1VNRU5UOiAxOTgsXHJcbiAgICBHRVRfVVNFUl9BUFBMSUNBVElPTl9QUklWSUxFR0VTOiAyMDcsXHJcbiAgICBHRVRfVVNFUl9BUFBMSUNBVElPTl9QUklWSUxFR0VTX01VTFRJOiAxMzQyLFxyXG4gICAgR0VUX0ZPUk1fVFlQRV9QUklWSUxFR0VTOiAyMTAsXHJcbiAgICBET0NVTUVOVF9DT01QTEVURV9GT1JfSU5GT1JNQVRJT046IDIyNixcclxuICAgIERFQUNUSVZBVEVfRk9STV9BQ1RJT05fTElTVDogMzE2LFxyXG4gICAgREVBQ1RJVkFURV9GT1JNX0FDVElPTjogMzE3LFxyXG4gICAgUkVBQ1RJVkFURV9GT1JNX0FDVElPTl9MSVNUOiAzMTgsXHJcbiAgICBSRUFDVElWQVRFX0ZPUk1fQUNUSU9OOiAzMTksXHJcbiAgICBQUk9DVVJFTUVOVF9HRVRfU0tOX1ZBTElEQVRJT05fQ0FMTF9PRkY6IDQyNixcclxuICAgIFNUQVRVU19DSEFOR0VfQUNUSU9OOiA1MDEsXHJcbiAgICBTVEFUVVNfQ0hBTkdFX1NJTkdMRV9TVUJNSVQ6IDUwMixcclxuICAgIERJU1BMQVlfRk9STV9DSEFOR0VfU1RBVFVTOiA1NzEsXHJcbiAgICBTVUJNSVRfRk9STV9DSEFOR0VfU1RBVFVTOiA1NzIsXHJcbiAgICBGT1JNX0RJU1RSSUJVVElPTl9DTEVBUl9BQ1RJT05fTElTVDogNTczLFxyXG4gICAgRk9STV9ESVNUX0NMRUFSX0FDVElPTl9TVUJNSVQ6IDU3NCxcclxuICAgIEZPUk1fRElTVF9ERUxFR0FURV9BQ1RJT05fTElTVDogNTc1LFxyXG4gICAgRk9STV9ESVNUX0RFTEVHQVRFX0FDVElPTl9TVUJNSVQ6IDU3NixcclxuICAgIENIRUNLX0lOVkVOVE9SX0ZJTEVfSEFTX1JFUVVJUkVEX0FUVEFDSE1FTlQ6IDU3OSxcclxuICAgIFNBVkVfTU9ERUxfQUNUSU9OOiA2MDcsXHJcbiAgICBTQVZFX01PREVMX0FDVElPTl9MQVRFU1RfUkVWX1pJUDogNjA4LFxyXG4gICAgUFVCTElDX1NBVkVfTU9ERUxfQUNUSU9OX0xBVEVTVF9SRVZfWklQOiAxOTAxLFxyXG4gICAgR0VUX1ZJRVdTX09GX01PREVMOiA2MjUsXHJcbiAgICBHRVRfQVNTT0NfTElTVFNfTU9ERUw6IDYyNyxcclxuICAgIEdFVF9IV0ZfTU9ERUxfRklMRV9TVEFUVVM6IDYzMSxcclxuICAgIFZJRVdfTU9ERUxfSElTVE9SWTogNjMyLFxyXG4gICAgR0VUX1VTRVJfU0VBUkNIX0ZJTFRFUlNfQ09MVU1OUzogNzAwLFxyXG4gICAgREVMRVRFX1VTRVJfU0VBUkNIX0ZJTFRFUjogNzAzLFxyXG4gICAgR0VUX1VTRVJfU0VBUkNIX0ZJTFRFUlM6IDcwMSxcclxuICAgIEVESVRfVVNFUl9TRUFSQ0hfRklMVEVSOiA3MDIsXHJcbiAgICBTQVZFX1VTRVJfU0VBUkNIX0ZJTFRFUjogNzA0LFxyXG4gICAgVU5TQVZFRF9VU0VSX1NFQVJDSF9GSUxURVI6IDcwNSxcclxuICAgIFNFQVJDSF9GSUxURVJfREFUQTogNzA2LFxyXG4gICAgR0VUX1NFQVJDSF9GSUVMRF9WQUxVRVM6IDcwNyxcclxuICAgIFNFQVJDSF9ERUZBVUxUX0ZJRUxEU19SRVNVTFQ6IDcwOCxcclxuICAgIERPQ1VNRU5UX0RJU1RSSUJVVElPTl9DTEVBUl9BQ1RJT05fTElTVDogNzE2LFxyXG4gICAgRE9DVU1FTlRfRElTVFJJQlVUSU9OX0NMRUFSX0FDVElPTl9TVUJNSVQ6IDcxNyxcclxuICAgIERPQ1VNRU5UX0RJU1RSSUJVVElPTl9ERUxFR0FURV9BQ1RJT05fTElTVDogNzE4LFxyXG4gICAgRE9DVU1FTlRfRElTVFJJQlVUSU9OX0RFTEVHQVRFX0FDVElPTl9TVUJNSVQ6IDcxOSxcclxuICAgIERFQUNUSVZBVEVfRklMRV9BQ1RJT05fTElTVDogODIzLFxyXG4gICAgREVBQ1RJVkFURV9GSUxFX0FDVElPTjogODI0LFxyXG4gICAgUkVBQ1RJVkFURV9GSUxFX0FDVElPTl9MSVNUOiA4MjUsXHJcbiAgICBSRUFDVElWQVRFX0ZJTEVfQUNUSU9OOiA4MjYsXHJcbiAgICBJTklUSUFURV9DUkVBVEVfT1JJX01TRzogOTAzLFxyXG4gICAgSU5JVElBVEVfQ1JFQVRFX0ZXRF9NU0c6IDkwNCxcclxuICAgIElOSVRJQVRFX0NSRUFURV9SRVNfTVNHOiA5MDUsXHJcbiAgICBCQVRDSF9GSUxFU19GT1JfQUNLTk9XTEVER0VNRU5UOiA5NTEsXHJcbiAgICBCQVRDSF9GSUxFU19GT1JfQ09NTUVOVF9JTkNPUlBPUkFUSU9OOiA5NTIsXHJcbiAgICBCQVRDSF9GSUxFU19GT1JfQUNUSU9OOiA5NTMsXHJcbiAgICBJTklUSUFURV9FRElUX0ZPUk1fTVNHX0NPTU1JVEVEOiA5NTMsXHJcbiAgICBCQVRDSF9GSUxFU19GT1JfQ09NTUVOVF9DT09SRElOQVRJT046IDk1NCxcclxuICAgIEFDVElPTl9DT01NRU5UX0NPT1JESU5BVElPTl9JTlZJRVc6IDk1NSxcclxuICAgIElOSVRJQVRFX0lNUE9SVF9GT1JNOiA5NTksXHJcbiAgICBJTklUSUFURV9JTVBPUlRfRk9STV9GT1JfRURJVF9PUkk6IDk2NCxcclxuICAgIENIRUNLX0NPTkNVUlJFTkNZX0lTU1VFOiA5NjUsXHJcbiAgICBDSEVDS19FRElUX09SSV9EUkFGVF9NRVNTQUdFOiA5NjYsXHJcbiAgICBDSEVDS19NQVhfSU5TVEFOQ0VfQ1JFQVRJT046IDk2NyxcclxuICAgIEdFVF9GT0xERVJfTElTVF9QT1BVUDogMTAwMixcclxuICAgIFNBVkVfQVRUQUNIX0VYVF9ET0M6IDExMjUsXHJcbiAgICBVUExPQURfQ0hVTktfRklMRTogMTIwMSxcclxuICAgIEJBVENIX0ZJTEVTX0ZPUl9JTkZPUk1BVElPTjogMTMwMSxcclxuICAgIEdFVF9GSUxFX1ZJRVdfQVRUUklCVVRFU19ERVRBSUxTOiAxMzA1LFxyXG4gICAgR0VUX0FEUklWRV9GSUxFX1ZJRVdfQVRUUklCVVRFU19ERVRBSUxTOiAxMzA2LFxyXG4gICAgREFTSEJPQVJEX0dFVF9VU0VSU19UT19TSEFSRTogMTMzMSxcclxuICAgIENIRUNLT1VUX1JFVjogMTM2NyxcclxuICAgIEdFVF9DSEVDS09VVF9SRVZfREVUQUlMUzogMTM2OCxcclxuICAgIEVYUE9SVF9ET0NVTUVOVF9ISVNUT1JZOiAxNDA0LFxyXG4gICAgUkVWX1ZBTElEX0ZPUl9DSEVDS09VVF9PTl9SSUdIVENMSUNLOiAxMzY5LFxyXG4gICAgVkFMSURBVEVfRE9DX05BTUlOR19SVUxFOiAxNDA0LFxyXG4gICAgRVhQT1JUX0ZPUk1fSElTVE9SWTogMTQwNSxcclxuICAgIEVYUE9SVF9GSUxFX0FTU09DSUFUSU9OU19MSU5LX0lORk86IDE0MDgsXHJcbiAgICBTQVZFX0FTX1BERl9BVURJVDogMTUwMSxcclxuICAgIFNBVkVfQVNfVElGRl9BVURJVDogMTUwMixcclxuICAgIFNBVkVfQVNfQ1NGX0FVRElUOiAxNTA2LFxyXG4gICAgU0FWRV9GSUxFX1ZJRVdFUl9VU0VSX1BSRUZFUkVOQ0VfSUQ6IDE1MDcsXHJcbiAgICBDT01QQVJFX0ZJTEVTOiAxNTA4LFxyXG4gICAgR0VORVJBVEVfTEVHQUNZX01BUktVUDogMTUwOSxcclxuICAgIEdFTkVSQVRFX0xFR0FDWV9NQVJLVVBfQ09OU09MSURBVEVEIDogMTUxMCxcclxuICAgIFJJR0hUX0NMSUNLX1BSSU5UX1ZJRVdfRk9STV9BTEw6IDE3MDMsXHJcbiAgICBHRVRfQ09OVEFDVFM6IDE3MDAsXHJcbiAgICBVUERBVEVfRkxBRzogMTcxMCxcclxuICAgIEdFVF9VU0VSX0ZMQUc6IDE3MTEsXHJcbiAgICBHRVRfQVRUQUNITUVOVF9BTkRfQVNTT0NJQVRJT05TOiAxNzIxLFxyXG4gICAgQ0hFQ0tfQ0FOX0RPV05MT0FEX0ZPTERFUl9MRVZFTDogMjU2LFxyXG4gICAgR0VUX1VTRVJfU0VMRUNURURfQ09MVU1OUzogMTcyMixcclxuICAgIEdFVF9BTExfTElTVElOR19IRUFERVI6IDE3MzQsXHJcbiAgICBTRVRfU0VMRUNURURfVklFV19UWVBFOiAxNzI2LFxyXG4gICAgU0FWRV9DT01NRU5UOiAxNzI4LFxyXG4gICAgU0FWRV9EUkFGVF9DT01NRU5UOiAxNzI5LFxyXG4gICAgSU5TRVJUX01PREVMX1ZJRVdfSElTVE9SWTogNjQyLFxyXG4gICAgU0FWRV9BU1NPQ0lBVEVfRE9DUzogMTAxNSxcclxuICAgIEdFVF9BU1NPQ0lBVEVfRE9DOiAxMDEzLFxyXG4gICAgU0FWRV9BVURJVF9UUkFJTF9GT1JfRE9DVU1FTlRfQVNTT0NJQVRJT046IDEwMTYsXHJcbiAgICBHRVRfVVNFUlNfTU9ERUxfRElTVF9MSVNUOiA2MTYsXHJcbiAgICBET1dOTE9BRF9NT0RFTF9USUxFOiA2NDAsXHJcbiAgICBTRVRfTU9ERUxfVElMRTogNjM5LFxyXG4gICAgUkVOQU1FX01PREVMX1ZJRVc6IDYzNixcclxuICAgIEdFVF9WSUVXX0RBVEE6IDc4MCxcclxuICAgIFNBVkVfTU9ERUxfVklFVzogNjMwLFxyXG4gICAgR0VUX0lGQ19PQkpFQ1RfVFlQRTogMTAwNCxcclxuICAgIEdFVF9BTExfQklNX0xJU1Q6IDEwMDcsXHJcbiAgICBPQkpFQ1RfQkFTSUNfU0VBUkNIOiAxMDA2LFxyXG4gICAgR0VUX09CSkVDVF9QUk9QRVJUSUVTOiAxMDAzLFxyXG4gICAgVVJJX09CSkVDVF9BRFZBTkNFRF9TRUFSQ0g6IDEwMDksXHJcbiAgICBBRERfT0JKRUNUX1RPX0xJU1Q6IDEwMTEsXHJcbiAgICBTQVZFX01PREVMX0xJU1Q6IDEwMDUsXHJcbiAgICBVUklfR0VUX0JJTV9MSVNUX0RFVEFJTDogMTAwOCxcclxuICAgIFVQREFURV9CSU1fT0JKRUNUX0xJU1Q6IDEwMTQsXHJcbiAgICBHRVRfSE9PUFNfRklMRV9NQVJLVVA6IDYzNSxcclxuICAgIENIRUNLX0ZJTEVfUEVSTUlTU0lPTjogNSxcclxuICAgIENIRUNLX0ZPTERFUl9QRVJNSVNTSU9OOiA0LFxyXG4gICAgQ0hFQ0tfRk9SX0FLQU1BSV9VUExPQURfTElNSVQ6IDE5OSxcclxuICAgIERPV05MT0FEX0JBVENIX0RPQ1VNRU5UX1dJVEhfTUFSS1VQU19BQ1RJT046IDE3MzEsXHJcbiAgICBQUk9HUkVTU19HRU5FUkFURV9NQVJLVVBfQVNfUERGOiAxNzMyLFxyXG4gICAgR0VUX1NFQVJDSF9QUk9KRUNUX0xJU1RfT0ZGTElORTogMjIxLFxyXG5cdEdFVF9QUk9KRUNUX0xJU1RfT0ZGTElORTogMjIyLFxyXG5cdEdFVF9GT0xERVJfTElTVF9PRkZMSU5FOiAyMjMsXHJcbiAgICBHRVRfU1VCRk9MREVSX0xJU1RfT0ZGTElORTogMjI0LFxyXG4gICAgT0ZGTElORV9HRVRfT0JTRVJWQVRJT05fTElTVF9CWV9QTEFOX0FDVElPTklEOiAyMjUsXHJcbiAgICBPRkZMSU5FX0dFVF9NQVJLVVBTX0xJU1Q6IDIyNyxcclxuICAgIE9GRkxJTkVfU0FWRV9DT01NRU5UOiAyMjgsXHJcbiAgICBPRkZMSU5FX1NBVkVfRFJBRlRfQ09NTUVOVDogMjI5LFxyXG4gICAgT0ZGTElORV9HRVRfTUFSS1VQSURfQllOQU1FOiAyMzAsXHJcbiAgICBERUxFVEVfVEhVTUJOQUlMX1RFTVBfRklMRVM6IDEyMDYsXHJcbiAgICBHRU5FUkFURV9MSVRFX1BERjogMTkwMixcclxuICAgIFxyXG4gICAgLy8gbGlzdGluZyB0eXBlc1xyXG4gICAgRklMRV9MSVNUSU5HOiAxLFxyXG4gICAgQ09NTVVOSUNBVElPTl9GT1JNX0xJU1RJTkc6IDMxLFxyXG4gICAgRElTQ1VTU0lPTl9MSVNUSU5HOiAzMixcclxuICAgIFJFVklFV19MSVNUSU5HOiAxNDcsXHJcbiAgICBUUkFOU01JVFRBTFM6IDIxLFxyXG4gICAgQVBQU19UUkFOU01JVFRBTFM6IDIyLFxyXG4gICAgRklFTERfVFJBTlNNSVRUQUxfTElTVElORzogMjMsXHJcbiAgICBUUkFOU01JVFRBTFNfVFJBTlNNSVRUQUxfTElTVElORzogMTU5LFxyXG4gICAgQ09OVFJBQ1RfVFJBTlNNSVRUQUxfTElTVElORzogMjQsXHJcbiAgICBGTV9UUkFOU01JVFRBTF9MSVNUSU5HOiAyNSxcclxuICAgIEZJTkFOQ0VfVFJBTlNNSVRUQUxfTElTVElORzogMjYsXHJcbiAgICBQUE1fVFJBTlNNSVRUQUxfTElTVElORzogMjcsXHJcbiAgICBIUl9UUkFOU01JVFRBTF9MSVNUSU5HOiAyOCxcclxuICAgIEhfQU5EX1NfVFJBTlNNSVRUQUxfTElTVElORzogMjksXHJcbiAgICBQUE1UX1RSQU5TTUlUVEFMX0xJU1RJTkc6IDMwLFxyXG4gICAgU0VBUkNIX1RZUEVfQ09OVEFDVFNfTElTVElORzogNjIsXHJcbiAgICBBUFBfR0xPQkFMX1NFQVJDSF9MSVNUSU5HOiAzOSxcclxuICAgIEZJRUxEX0ZPUk1fTElTVElORzogNTEsXHJcbiAgICBDT05UUkFDVF9GT1JNX0xJU1RJTkc6IDUyLFxyXG4gICAgRk1fRk9STV9MSVNUSU5HOiA1MyxcclxuICAgIEZJTkFOQ0VfRk9STV9MSVNUSU5HOiA1NCxcclxuICAgIFBQTV9GT1JNX0xJU1RJTkc6IDU1LFxyXG4gICAgSFJfRk9STV9MSVNUSU5HOiA1NixcclxuICAgIEhfQU5EX1NfRk9STV9MSVNUSU5HOiA1NyxcclxuICAgIE1BUktFVFBMQUNFX0ZPUk1fTElTVElORzogMTI4LFxyXG4gICAgTUFSS0VUUExBQ0VfVFJBTlNNSVRUQUxfTElTVElORzogMTI5LFxyXG4gICAgU1VTVEFJTkFCSUxJVFlfRk9STV9MSVNUSU5HOiAxNTMsXHJcbiAgICBBUFBTX1RSQU5TTUlUVEFMX0ZPUk1fTElTVElORzogMTU4LFxyXG4gICAgQURNSU5fRkVUQ0hfUlVMRV9MSVNUSU5HOiA0NSxcclxuICAgIFBST0pFQ1RfTElTVElOR19UWVBFOiA0MixcclxuICAgIE1PREVMX0xJU1RJTkdfVFlQRTogNDcsXHJcbiAgICBBRE1JTl9MSVNUSU5HX1RZUEU6IDQ0LFxyXG4gICAgTU9ERUxfR0xPQkFMX1NFQVJDSF9MSVNUSU5HOiA4LFxyXG4gICAgQ09NTVVOSUNBVElPTl9GT1JNX1RFTVBMQVRFX0xJU1RJTkc6IDMzLFxyXG4gICAgQUxMX0FQUF9UWVBFU19MSVNUSU5HOiAzNCxcclxuICAgIFBST0NVUkVNRU5UX0NBVEFMT0dVRV9EQVRBX0xJU1RJTkc6IDM1LFxyXG4gICAgUFJPQ1VSRU1FTlRfQ0FUQUxPR1VFX0JBU0tFVF9MSVNUSU5HOiAzNixcclxuICAgIERFU0NJUExJTkVfV0lTRV9NT0RFTFJFVklTSU9OU19MSVNUSU5HOiAzNyxcclxuICAgIE1PREVMX1BFTkRJTkdfQUNUSU9OU19ET0NVTUVOVF9MSVNUSU5HOiAzOCxcclxuICAgIEFMTF9BUFBTX0FORF9QUk9DVVJFTUVOVF9NRVNTQUdFU19MSVNUSU5HOiAzOSxcclxuICAgIFBSSU5UX09QVElPTlNfVkFMVUVfQUxMOiA2MyxcclxuICAgIFBST0NVUkVNRU5UX0xJU1RJTkc6IDQsXHJcbiAgICBORVdfUFJPQ1VSRU1FTlRfTElTVElORzogMTI2LFxyXG4gICAgQ0FUQUxPR19MSVNUSU5HOiAxMDEsXHJcbiAgICBMRUdBQ1lfUkVQT1JUX0xJU1RJTkc6IDYwLFxyXG4gICAgU0VBUkNIX1RZUEVfVEVNUExBVEVfTElTVElORzogNTgsXHJcbiAgICBQUE1UX0ZPUk1fTElTVElORzogNTksXHJcbiAgICBTQ0hFRFVMSU5HX1JFUE9SVF9MSVNUSU5HX1RZUEU6IDYxLFxyXG4gICAgQUNMX01BVFJJWF9SRVBPUlQ6IDkwLFxyXG4gICAgTUFOQUdFX0RJU1RSSUJVVElPTl9HUk9VUDogOTEsXHJcbiAgICBNQU5BR0VfQVBQX0xJU1RJTkdfVFlQRTogNDksXHJcbiAgICBDT05UQUNUX0xJU1RJTkdfVFlQRTogNjIsXHJcbiAgICBXT1JLRkxPV19MSVNUSU5HX1RZUEU6IDY0LFxyXG4gICAgV09NX0lOU1RfTElTVElOR19UWVBFOiA2NixcclxuICAgIFdPUktGTE9XU19SVUxFX0xJU1RJTkc6IDY3LFxyXG4gICAgV09SS0ZMT1dTX0FDVElPTl9MSVNUSU5HOiA2OCxcclxuICAgIERJUkVDVE9SWV9DQVRBTE9VR0VfREFUQV9MSVNUSU5HOiA2MyxcclxuICAgIERPQ19NQUlMQk9YX0xJU1RJTkc6IDQ2LFxyXG4gICAgRk9STV9NQUlMQk9YX0xJU1RJTkc6IDQ4LFxyXG4gICAgQVNTSUdORURfRk9STVRZUEVfTElTVElORzogNDksXHJcbiAgICBET0NVTUVOVF9ISVNUT1JZX0VYUE9SVDogOTIsXHJcbiAgICBQVUJMSUNfRk9MREVSX0xJU1RJTkc6IDk0LFxyXG4gICAgRk9STV9ISVNUT1JZX0VYUE9SVDogOTMsXHJcbiAgICBFWFBPUlRfRklMRV9BU1NPQ0lBVElPTlNfTElOS19JTkZPX0xJU1RJTkdfVFlQRTogOTcsXHJcbiAgICBOT1RJQ0VfTElTVElORzogNjksXHJcbiAgICBNQU5BR0VfVVNFUl9MSVNUSU5HOiA3MCxcclxuICAgIEFTU09DSUFUSU9OX01BUktVUF9MSVNUSU5HOiAxMDIsXHJcbiAgICBBU1NPQ0lBVElPTl9TVEFUSUNfTElTVElORzogMTAzLFxyXG4gICAgQVNTT0NJQVRFRF9GT1JNX0xJU1RJTkc6IDcxLFxyXG4gICAgQVRUQUNITUVOVF9MSVNUSU5HOiA3MixcclxuICAgIEFTU09DSUFURURfRklMRV9MSVNUSU5HOiA3MyxcclxuICAgIEFTU09DSUFURURfRElTQ1VTU0lPTl9MSVNUSU5HOiA3NCxcclxuICAgIEFTU09DSUFURURfU0VMRUNURURfRklMRV9MSVNUSU5HOiA3NyxcclxuICAgIEFTU09DSUFURURfU0VMRUNURURfRElTQ1VTU0lPTl9MSVNUSU5HOiA3OCxcclxuICAgIEFTU09DSUFURURfU0VMRUNURURfRk9STV9MSVNUSU5HOiA3OSxcclxuICAgIEFTU09DSUFURURfU0VMRUNURURfUkVWSUVXX0xJU1RJTkc6IDE0OCxcclxuICAgIEFTU09DSUFURURfUkVWSUVXX0xJU1RJTkc6IDE0OSxcclxuICAgIENSRUFURV9GT1JNX0FUVEFDSE1FTlRfTElTVElORzogMTM5LFxyXG4gICAgV09SS1NQQUNFX0FDQ0VTU19MT0dfTElTVElORzogODAsXHJcblxyXG4gICAgLy8gQVBQTElDQVRJT04gUFJJVklMRUdFU1xyXG4gICAgUFJJVl9FRElUX1VTRVJTOiAxLFxyXG4gICAgUFJJVl9FRElUX09yZ2FuaXNhdGlvbnM6IDIsXHJcbiAgICBQUklWX01BTkFHRV9TWVNURU1fTk9USUNFUzogMyxcclxuICAgIFBSSVZfTUFOQUdFX0ZPUk1fVEVNUExBVEVTOiA0LFxyXG4gICAgUFJJVl9NQU5BR0VfUk9MRV9URU1QTEFURVM6IDUsXHJcbiAgICBQUklWX01BTkFHRV9EUkFXSU5HX1NFUklFU19URU1QTEFURVM6IDYsXHJcbiAgICBQUklWX01BTkFHRV9SRVBST0dSQVBISUNTOiA3LFxyXG4gICAgUFJJVl9DUkVBVEVfUkVQUk9fT1JERVI6IDgsXHJcblxyXG4gICAgLy8gUFJPSkVDVCBQUklWSUxFR0VTXHJcbiAgICBQUklWX01BTkFHRV9XT1JLU1BBQ0VfUk9MRVNfVVNFUlM6IDksXHJcbiAgICBQUklWX01BTkFHRV9QUk9KRUNUX1JPTEVTOiAxMCxcclxuICAgIFBSSVZfQVNTSUdOX1VTRVJTX1BSSVZJTEVHRVM6IDExLFxyXG4gICAgUFJJVl9WSUVXX1VTRVJfUFJJVklMRUdFUzogMTIsXHJcbiAgICBQUklWX01BTkFHRV9OT1RJQ0VTOiAxMyxcclxuICAgIFBSSVZfQVNTSUdOX0ZPUk1TX1RPX1BST0pFQ1Q6IDE0LFxyXG4gICAgUFJJVl9FRElUX1BST0pFQ1RfRk9STV9TRVRUSU5HUzogMTUsXHJcbiAgICBQUklWX01BTkFHRV9QUk9KRUNUX1dPUktQQUNLQUdFUzogMTYsXHJcbiAgICBQUklWX01BTkFHRV9QUk9KRUNUX0RPQ1VNRU5UX1NUQVRVUzogMTcsXHJcbiAgICBQUklWX01BTkFHRV9QUk9KRUNUX0RSQVdJTkdfU0VSSVJFUzogMTgsXHJcbiAgICBQUklWX0NSRUFURV9GT0xERVI6IDE5LFxyXG4gICAgUFJJVl9BTUVORF9GT0xERVJfUEVSTUlTU0lPTlM6IDIwLFxyXG4gICAgUFJJVl9BU1NJR05fRE9DVU1FTlRfQVRUUklCVVRFUzogMjEsXHJcbiAgICBQUklWX0RFQUNUSVZBVEVfRE9DVU1FTlRTOiAyMixcclxuICAgIFBSSVZfRElTVFJJQlVURV9ET0NVTUVOVFM6IDIzLFxyXG4gICAgUFJJVl9DUkVBVEVfQ09NTUVOVFM6IDI0LFxyXG4gICAgUFJJVl9DQU5fQkVfQVNTSUdORURfQUNUSU9OX0NIQU5HRV9TVEFUVVM6IDI1LFxyXG4gICAgUFJJVl9DQU5fQkVfQVNTSUdORURfQUNUSU9OX0RJU1RSSUJVVEU6IDI2LFxyXG4gICAgUFJJVl9DQU5fQkVfQVNTSUdORURfQUNUSU9OX0lOQ19DT01NRU5UUzogMjcsXHJcbiAgICBQUklWX01BTkFHRV9QUk9KRUNUX0RJU1RSSVVCVElJT05fR1JPVVBTOiAyOCxcclxuICAgIFBSSVZfVklFV19SRVBPUlRTOiAyOSxcclxuICAgIFBSSVZfRk9STV9QUk9KRUNUX1BSSVZfQ1JFQVRFOiAzMCxcclxuICAgIFBSSVZfRk9STV9QUk9KRUNUX1BSSVZfQ09OVFJPTDogMzEsXHJcbiAgICBQUklWX0NSRUFURV9QQVJFTlRfRk9MREVSUzogMzIsXHJcbiAgICBQUklWX0ZPUk1fUFJPSkVDVF9QUklWX1ZJRVc6IDMzLFxyXG4gICAgUFJJVl9DSEFOR0VfU1RBVFVTOiAzNCxcclxuICAgIFBSSVZfRk9STV9OT19BQ0NFU1M6IDM1LFxyXG4gICAgUFJJVl9GT1JNX1ZJRVdfQUxMX1BSSVZBVEVfRk9STVM6IDM2LFxyXG4gICAgUFJJVl9QVVJQT1NFT0ZfRE9DX0lTU1VFOiAzNyxcclxuICAgIFBSSVZfTUFOQUdFX09SR0FOSVpBVElPTl9QTEFDRUhPTERFUlM6IDM4LFxyXG4gICAgUFJJVl9NQU5BR0VfUFJPSkVDVF9QTEFDRUhPTERFUlM6IDM5LFxyXG4gICAgUFJJVl9DQU5fQ0xFQVJfQUNUSU9OU19PUkc6IDQwLFxyXG4gICAgUFJJVl9DQU5fQ0xFQVJfQUNUSU9OU19QUk9KRUNUOiA0MSxcclxuICAgIFBSSVZfQ0FOX0NMRUFSX0FDVElPTlNfT1dOOiA0MixcclxuICAgIFBSSVZfQ0FOX0RFTEVHQVRFX0FDVElPTlNfT1JHOiA0MyxcclxuICAgIFBSSVZfQ0FOX0RFTEVHQVRFX0FDVElPTlNfUFJPSkVDVDogNDQsXHJcbiAgICBQUklWX0NBTl9ERUxFR0FURV9BQ1RJT05TX09XTjogNDUsXHJcbiAgICBQUklWX0NBTl9DTEVBUl9DT01NRU5UUzogNDYsXHJcbiAgICBQUklWX0FDQ0VTU19ERUFDVElWQVRFRF9ET0NVTUVOVFM6IDQ3LFxyXG4gICAgUFJJVl9NQU5BR0VfUFJPSkVDVF9QQVBFUl9ET0NVTUVOVFM6IDQ4LFxyXG4gICAgUFJJVl9DQU5fREVBQ1RJVkFURV9VU0VSU19GUk9NX1BST0pFQ1Q6IDQ5LFxyXG4gICAgUFJJVl9DQU5fQVNTSUdOX1BST1hZX1VTRVJTOiA1MCxcclxuICAgIFZBTFVFX0FMTE9XX0NVU1RPTV9ESVNUUklCVVRJT05fQUxMX09SRzogNTEsXHJcbiAgICBQUklWX01BTkFHRV9TUEFDRVM6IDUyLFxyXG4gICAgUFJJVl9NQU5BR0VfVVNFUl9TVUJTQ1JJUFRJT05TOiA1OCxcclxuICAgIFBSSVZfTUFOQUdFX1BST0pFQ1RTX0FMTF9PUkdTOiA1OSxcclxuICAgIFBSSVZfTUFOQUdFX1BST0pFQ1RfTUFJTEJPWDogNjAsXHJcbiAgICBQUklWX0VESVRfUFJPSkVDVF9ERVRBSUxTOiA2MSxcclxuICAgIFZBTFVFX0FMTE9XX0NVU1RPTV9ESVNUUklCVVRJT05fT1dOX09SRzogNjIsXHJcbiAgICBQUklWX0NBTl9DUkVBVEVfRkxBVF9GRUVfQkFTRURfUFJPSkVDVFM6IDYzLFxyXG4gICAgUFJJVl9DQU5fQ1JFQVRFX1NVQlNDUklQVElPTl9QUk9KRUNUUzogNjQsXHJcbiAgICBQUklWX0NBTl9DT05GSUdVUkVfRE9DVU1FTlRfTkFNSU5HOiA2NyxcclxuICAgIFBSSVZfQ0FOX0FDRVNTX0FVRElUX0lORk86IDY5LFxyXG4gICAgUFJJVl9DQU5fQ1JFQVRFX0NPTU1FTlQ6IDcwLFxyXG4gICAgUFJJVl9BU1NJR05fUk9MRV9NRU1CRVJTSElQX0FMTF9PUkc6IDcxLFxyXG4gICAgUFJJVl9BU1NJR05fUk9MRV9NRU1CRVJTSElQX09XTl9PUkc6IDcyLFxyXG4gICAgUFJJVl9DQU5fU0FWRV9XT1JLU1BBQ0VfQVNfVEVNUExBVEU6IDczLFxyXG4gICAgUFJJVl9DQU5fTUFOQUdFX0ZPUk1fU1RBVFVTRVM6IDc0LFxyXG4gICAgUFJJVl9GT1JNX1ZJRVdfUFJJVkFURV9PV05fT1JHOiA3NSxcclxuICAgIFBSSVZfQ0FOX01BTkFHRV9VU0VSX1BSRUZFUkVOQ0VTOiA3NixcclxuICAgIFBSSVZfQ0FOX0RFQUNUSVZBVEVfT1dOX0ZPUk1TOiA3NyxcclxuICAgIFBSSVZfQ0FOX0RFQUNUSVZBVEVfQUxMX0ZPUk1TOiA3OCxcclxuICAgIFBSSVZfRk9STV9WSUVXX0RSQUZUX09XTl9PUkc6IDc5LFxyXG4gICAgUFJJVl9GT1JNX1ZJRVdfRFJBRlRfQUxMX09SRzogODAsXHJcbiAgICBQUklWX0NBTl9ET1dOTE9BRF9ET0NVTUVOVFM6IDgxLFxyXG4gICAgUFJJVl9DQU5fUFJJTlRfRE9DVU1FTlRTOiA4MixcclxuICAgIFBSSVZfQ0FOX0FDQ0VTU19XT1JLU1BBQ0VfV0lUSE9VVF9TVUJTQ1JJUFRJT046IDgzLFxyXG4gICAgUFJJVl9DQU5fQUNDRVNTX1dPUktTUEFDRV9DQUxFTkRBUjogODQsXHJcbiAgICBDQU5fQUNDRVNTX0RJU1RSSUJVVElPTl9NT0RVTEU6IDg1LFxyXG4gICAgQ0FOX0FDQ0VTU19ERVNJR05fV09SS0ZMT1c6IDg2LFxyXG4gICAgQ0FOX0FDQ0VTU19QUkVRVUFMSUZJQ0FUSU9OX01PRFVMRTogODcsXHJcbiAgICBDQU5fQUNDRVNTX0JJRERJTkdfTU9EVUxFOiA4OCxcclxuICAgIENBTl9BQ0NFU1NfQ09OU1RSVUNUSU9OX01PRFVMRTogODksXHJcbiAgICBQUklWX0NBTl9DUkVBVEVfRE9DVU1FTlRfTUFOQUdFUl9QV0Y6IDkwLFxyXG4gICAgUFJJVl9DQU5fQ1JFQVRFX0RPQ1VNRU5UX01BTkFHRVJfUFdTOiA5MSxcclxuICAgIFBSSVZfQ0FOX0NSRUFURV9ET0NVTUVOVF9NQU5BR0VSX0VXUzogOTIsXHJcbiAgICBQUklWX0NBTl9DUkVBVEVfRE9DVU1FTlRfTUFOQUdFUl9TV1M6IDkzLFxyXG4gICAgUFJJVl9DQU5fQ1JFQVRFX0RPQ1VNRU5UX01BTkFHRVJfVFdTOiA5NCxcclxuICAgIFBSSVZfQ0FOX0NSRUFURV9ET0NVTUVOVF9NQU5BR0VSX1BNVzogOTUsXHJcbiAgICBQUklWX0NBTl9BQ0NFU1NfTkFWSUdBVE9SOiA5NixcclxuICAgIFBSSVZfTUFOQUdFX0FQUFM6IDk3LFxyXG4gICAgUFJJVl9NQU5BR0VfQVBQX1NFVFRJTkdTOiA5OCxcclxuICAgIENBTl9CQVRDSF9DSEFOR0VfU1RBVFVTX09GX09XTl9GT1JNOiA5OSxcclxuICAgIENBTl9SRU9QRU5fQ0xPU0VEX0ZPUk06IDEwMCxcclxuICAgIENBTl9BU1NJR05fVE9fV09SS1NQQUNFX1dJVEhPVVRfQUNDRVBUQU5DRTogMTAxLFxyXG4gICAgQ0FOX0FNRU5EX0FMTF9GT0xERVJfUEVSTUlTU0lPTlM6IDEwMixcclxuICAgIENBTl9TSEFSRV9TRUFSQ0hfVklFV1M6IDEwOSxcclxuICAgIENBTl9NQU5BR0VfUFJPSkVDVFNfTU9ERUxTOiAxMTAsXHJcbiAgICBDQU5fQkFUQ0hfQ0hBTkdFX1NUQVRVU19PRl9BTExfRk9STVM6IDExMSxcclxuICAgIFBSSVZfQ0FOX01BTkFHRV9QUk9KRUNUU19NT0RFTFNfVklFV1M6IDExMixcclxuICAgIFBSSVZfQ0FOX0NSRUFURV9BREhPQ19SRVBPUlQ6IDExMyxcclxuICAgIFBSSVZfTUFOQUdFX1dPUktGTE9XX1JVTEVTOiAxMTQsXHJcbiAgICBDQU5fREVBQ1RJVkFURV9GT1JNX0FDVElPTlNfT1dOX09SRzogMTE1LFxyXG4gICAgQ0FOX0RFQUNUSVZBVEVfRk9STV9BQ1RJT05TX0FMTF9PUkc6IDExNixcclxuICAgIENBTl9SRUFDVElWQVRFX0ZPUk1fQUNUSU9OU19PV05fT1JHOiAxMTcsXHJcbiAgICBDQU5fUkVBQ1RJVkFURV9GT1JNX0FDVElPTlNfQUxMX09SRzogMTE4LFxyXG4gICAgQ0FOX0RFQUNUSVZBVEVfRE9DVU1FTlRfQUNUSU9OU19PV05fT1JHOiAxMTksXHJcbiAgICBDQU5fREVBQ1RJVkFURV9ET0NVTUVOVF9BQ1RJT05TX0FMTF9PUkc6IDEyMCxcclxuICAgIENBTl9SRUFDVElWQVRFX0RPQ1VNRU5UX0FDVElPTlNfT1dOX09SRzogMTIxLFxyXG4gICAgQ0FOX1JFQUNUSVZBVEVfRE9DVU1FTlRfQUNUSU9OU19BTExfT1JHOiAxMjIsXHJcbiAgICBDQU5fQ1JFQVRFX1VTRVJfQU5EX09SR1M6IDEyMyxcclxuICAgIFBSSVZfQ0FOX01BTkFHRV9PQkpFQ1RfTElTVFM6IDEyNCxcclxuICAgIFBSSVZfQ0FOX01BTkFHRV9DT05GSUdVUkFCTEVfQVRUUklCVVRFUzogMTI1LFxyXG4gICAgUFJJVl9DQU5fTU9WRV9ET0M6IDEyNixcclxuICAgIENBTl9DUkVBVEVfZUlOVk9JQ0U6IDEyNyxcclxuICAgIE1BTkFHRV9QVU5DSE9VVF9DQVRBTE9HVUVfUkVTVFJJQ1RJT046IDEyOCxcclxuICAgIENBTl9DUkVBVEVfUFJJVkFURV9DT01NRU5UUzogMTI5LFxyXG4gICAgQ0FOX1JFT1BFTl9BTExfQ0xPU0VEX0ZPUk1TX0FETUlOOiAxMzAsXHJcbiAgICBDQU5fQ09OVFJPTExfTEFZT1VUX0FMTF9PUkc6IDEzMSxcclxuICAgIFBSSVZfV09SS1NQQUNFX05PX0FDQ0VTUzogMCxcclxuICAgIFBSSVZfV09SS1NQQUNFX0FETUlOOiAxMDIzLFxyXG4gICAgQ0FOX01BTkFHRV9QUk9KRUNUU19GSUVMRDogMTM1LFxyXG4gICAgQ0FOX0NSRUFURV9ORVdfVVNFUlNfQU5EX09SR19BTExfT1JHOiAxMzYsXHJcbiAgICBTQVZFX1NPUlRfREVUQUlMU19GT1JfVVNFUjogMzM1LFxyXG4gICAgRE9DVU1FTlRfQVNTT0NJQVRFRF9DT01NU19BQ1RJT046IDEyMSxcclxuICAgIFZJRVdfTU9ERUxfRElTQ1VTU0lPTlM6IDE1MixcclxuICAgIFVQTE9BRF9GSUxFX1ZBTElEQVRJT05fTkVXOiA4MDIsXHJcbiAgICBHRVRfUFJPSkVDVF9MSVNUX1BPUFVQOiAxMDAxLFxyXG4gICAgU0FWRV9VU0VSX1NFTF9QUk9KRUNUUzogODEwLFxyXG4gICAgQ0FOX1ZJRVdfSElTVE9SSUNfTUFSS1VQUzoxNjMsXHJcbiAgICBNQVJLX1JFVklFV19QUklWQVRFOjE3MixcclxuICAgIENBTl9NQU5BR0VfUkVWSUVXX0ZMQUdTOiAxNzMsXHJcbiAgICBDQU5fQ1JFQVRFX0lTU1VFOiAxNjYsXHJcbiAgICBDQU5fQ1JFQVRFX0lTU1VFX0NPTU1FTlQ6IDE2NyxcclxuICAgIENBTl9DUkVBVEVfRklMRVNfRlJPTV9ET0NVTUVOVF9URU1QTEFURVM6IDE3OSxcclxuXHJcbiAgICAvLyBvdGhlciBjb21tb25cclxuICAgIFBSSU5UX09QVElPTlNfVkFMVUVfQUxMOiA2MyxcclxuICAgIENBTExFUl9BUFA6IDEwLFxyXG4gICAgT0JKRUNUX1RZUEVfRklMVEVSOiAxMDIsXHJcblxyXG4gICAgLy8gQ3VzdG9tIE9iamVjdCBjb25zdGFudHNcclxuICAgIGN1c3RvbU9iamVjdDoge1xyXG4gICAgICAgIERPQ1VNRU5UX0NPTlRFWFRfSUQ6IDEsXHJcbiAgICAgICAgQVBQX0NPTlRFWFRfSUQ6IDIsXHJcbiAgICAgICAgTU9ERUxfQ09OVEVYVF9JRDogMyxcclxuICAgICAgICBNT0RFTF9WSUVXX0NMQVNTX05BTUU6ICdtb2RlbFZpZXcnLFxyXG4gICAgICAgIERJU1RSSUJVVElPTl9DTEFTU19OQU1FOiAnZGlzdHJpYnV0aW9uJyxcclxuICAgICAgICBDT01NRU5UX0NMQVNTX05BTUU6ICdjb21tZW50J1xyXG4gICAgfSxcclxuXHJcbiAgICAvL0ZvbGRlciBwZXJtaXNzaW9uc1xyXG4gICAgZm9sZGVyUGVybWlzc2lvbjoge1xyXG4gICAgICAgIFZJRVdfT05MWTogMjMsXHJcbiAgICAgICAgRk9MREVSX0FETUlOX1BFUk1JU1NJT046IDEwMjMsXHJcbiAgICAgICAgRk9MREVSX1BVQkxJU0hfQU5EX0xJTktfUEVSTUlTU0lPTjogMjM5LFxyXG4gICAgICAgIEZPTERFUl9QVUJMSVNIX1BFUk1JU1NJT046IDExMVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBhcHAgYWN0aW9uIGlkIG1hcFxyXG4gICAgYXBwQWN0aW9uTWFwOiB7XHJcbiAgICAgICAgUkVBRDogMCxcclxuICAgICAgICBGT1JfUkVTUE9ORDogMyxcclxuICAgICAgICBGT1JfRElTVFJJQlVUSU9OOiA2LFxyXG4gICAgICAgIEZPUl9JTkZPUk1BVElPTjogNyxcclxuICAgICAgICBGT1JfQUNLTk9XTEVER0VNRU5UOiAzNyxcclxuICAgICAgICBGT1JfU1RBVFVTX0NIQU5HRTogMTQsXHJcbiAgICAgICAgRk9SX1JFVklFV19EUkFGVDogMzQsXHJcbiAgICAgICAgRk9SX0FDVElPTjogMzYsXHJcbiAgICAgICAgRk9SX0FTU0lHTl9TVEFUVVM6IDIsXHJcbiAgICAgICAgRk9SX0FUVEFDSEVEX0RPQzogNSxcclxuICAgICAgICBSRUxFQVNFX1JFU1BPTlNFOiA0XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGRvY3VtZW50IGFjdGlvbiBpZCBtYXBcclxuICAgIGRvY0FjdGlvbk1hcDoge1xyXG4gICAgICAgIEZPUl9BQ0tOT1dMRURHRU1FTlQ6IDgsXHJcbiAgICAgICAgRk9SX0NPTU1FTlQ6IDksXHJcbiAgICAgICAgRk9SX0NPTU1FTlRfQ09PUkRJTkFUSU9OOiAxMCxcclxuICAgICAgICBGT1JfQ09NTUVOVF9JTkNPUlA6IDExLFxyXG4gICAgICAgIEZPUl9ESVNUUklCVVRJT046IDEyLFxyXG4gICAgICAgIEZPUl9TVEFUVVNfQ0hBTkdFOiAxNCxcclxuICAgICAgICBGT1JfQUNUSU9OOiAzNSxcclxuICAgICAgICBGT1JfSU5GT1JNQVRJT046IDEzLFxyXG4gICAgICAgIEZPUl9QVUJMSVNISU5HOiAyOFxyXG4gICAgfSxcclxuXHJcblx0U0hBUkVfT0JKRUNUX1RZUEVfSUQ6IHtcclxuXHRcdFdPUktTUEFDRTogMSxcclxuXHRcdEZPTERFUjogMixcclxuXHRcdEZJTEU6IDNcclxuXHR9LFxyXG5cclxuXHRTSEFSRV9QRVJNSVNTSU9OOiB7XHJcblx0XHROT05FOiAwLFxyXG5cdFx0T1dORVI6IDEsXHJcblx0XHRFRElUT1I6IDIsXHJcblx0XHRWSUVXRVI6IDNcclxuXHR9LFxyXG4gICAgXHJcbiAgICBBRFJJVkVfRklMRV9QRVJNSVNTSU9OOiB7XHJcbiAgICAgICAgVklFV19GSUxFOiA1LFxyXG4gICAgICAgIENSRUFURV9DT01NRU5UOiAxMSxcclxuICAgICAgICBET1dOTE9BRF9GSUxFOiA0XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZWQgbW9zdGx5IGZvciBjcmVhdGUgZm9ybSBhcmVhXHJcbiAgICBmcm9tOiB7XHJcbiAgICAgICAgTU9ERUxfTkVXX0ZPUk06IDQsXHJcbiAgICAgICAgVklFV19GT1JNOiAzLFxyXG4gICAgICAgIEFTU09DX0ZJTEVfRklMRVRBQjogNSxcclxuICAgICAgICBBU1NPQ19GSUxFX0ZJTEVWSUVXRVI6IDYsXHJcbiAgICAgICAgQVNTT0NfRElTQ1VTU0lPTl9ESVNDVVNTSU9OVEFCOiA3LFxyXG4gICAgICAgIEFTU09DX0RJU0NVU1NJT05fRklMRVZJRVdFUjogOCxcclxuICAgICAgICBBU1NPQ19BUFBfQVBQVEFCOiA5LFxyXG4gICAgICAgIEFTU09DX0FQUF9GT1JNVklFV0VSOiAxMCxcclxuICAgICAgICBGSUxFX1RBQl9UUkVFOiAxMSxcclxuICAgICAgICBDQUxMX09GRl9GT1JNOiAxMixcclxuICAgICAgICBDUkVBVEVfTkVXX0JUTl9BUFBfVEFCOiAxMyxcclxuICAgICAgICBBU1NPQ19GSUxFX0RBU0hCT0FSRF9UQUI6IDE0LFxyXG4gICAgICAgIEFTU09DX0ZJTEVfU0VBUkNIX1RBQjogMTUsXHJcbiAgICAgICAgQVNTT0NfQVBQX0RBU0hCT0FSRF9UQUI6IDE2LFxyXG4gICAgICAgIEFTU09DX0FQUF9TRUFSQ0hfVEFCOiAxNyxcclxuICAgICAgICBBU1NPQ19ESVNDVVNTSU9OX0RBU0hCT0FSRF9UQUI6IDE4LFxyXG4gICAgICAgIEFTU09DX0RJU0NVU1NJT05fU0VBUkNIX1RBQjogMTksXHJcbiAgICAgICAgQ1JFQVRFX05FV19GT1JNX0RBU0hCT0FSRF9UQUI6IDIwLFxyXG4gICAgICAgIENSRUFURV9ORVdfRk9STV9TRUFSQ0hfVEFCOiAyMSxcclxuICAgICAgICBGT1JNX1ZJRVdFUjogMjIsXHJcbiAgICAgICAgQVNTT0NfQUxMX0ZPUk1fVklFV0VSOiAyMyxcclxuICAgICAgICBFRElUX1JFUE9SVF9UQUI6IDI0LFxyXG4gICAgICAgIE9QRU5fQU5ZX0RSQUZUOiAyNSxcclxuICAgICAgICBDQU5DRUxfQUZURVJfQVVUT19TQVZFRDogMjYsXHJcbiAgICAgICAgRURJVF9ORVdfT1JJX1ZJRVdfRk9STTogMjcsXHJcbiAgICAgICAgRFJBRlRfRElTQ0FSREVEOiAyOCxcclxuICAgICAgICBFRElUX09SSV9GUk9NX1hTTl9MSU5LOiAyOSxcclxuICAgICAgICBSRVNQT05EX0FDVElPTl9QUk9KRUNUX0ZPUk06IDMwLFxyXG4gICAgICAgIENSRUFURV9GUk9NX1BSSU5UVklFVzogMzEsXHJcbiAgICAgICAgQ0hFQ0tfRk9STV9DTE9TRTogOTY4XHJcbiAgICB9LFxyXG5cclxuICAgIEFDVElWSVRZX0NPTlNUQU5UOiB7XHJcbiAgICAgICAgQUNUSVZJVFlfUkVWSVNJT05fVVBMT0FEOiAxMDEsXHJcbiAgICAgICAgQUNUSVZJVFlfRklMRV9ESVNUUklCVVRJT046IDEwMixcclxuICAgICAgICBBQ1RJVklUWV9FRElUX0FUVFJJQlVURVM6IDEwMyxcclxuICAgICAgICBBQ1RJVklUWV9VUERBVEVfU1RBVFVTOiAxMDQsXHJcbiAgICAgICAgQUNUSVZJVFlfQUREX0NPTU1FTlQ6IDEwNSxcclxuICAgICAgICBBQ1RJVklUWV9LRVlfUkVWSVNJT05fVVBMT0FEOiAxMDAxLFxyXG4gICAgICAgIEFDVElWSVRZX0tFWV9GSUxFX0RJU1RSSUJVVElPTjogMTAwMixcclxuICAgICAgICBBQ1RJVklUWV9LRVlfRURJVF9BVFRSSUJVVEVTOiAxMDAzLFxyXG4gICAgICAgIEFDVElWSVRZX0tFWV9VUERBVEVfU1RBVFVTOiAxMDA0LFxyXG4gICAgICAgIEFDVElWSVRZX0tFWV9BRERfQ09NTUVOVDogMTAwNSxcclxuICAgIH0sXHJcblxyXG4gICAgZW50aXR5OiB7XHJcbiAgICAgICAgQVBQOiAxLFxyXG4gICAgICAgIEZJTEU6IDIsXHJcbiAgICAgICAgRElTQ1VTU0lPTjogNFxyXG4gICAgfSxcclxuXHJcbiAgICBhcHBUeXBlOiB7XHJcbiAgICAgICAgQ09OVEFDVFM6IDAsXHJcbiAgICAgICAgQ09NTVVOSUNBVElPTjogMSxcclxuICAgICAgICBGSUVMRDogMixcclxuICAgICAgICBDT05UUkFDVFM6IDMsXHJcbiAgICAgICAgUFJPQ1VSRU1FTlQ6IDExLFxyXG4gICAgICAgIEVYQ0hBTkdFOiA0LFxyXG4gICAgICAgIEZNOiA1LFxyXG4gICAgICAgIEZJTkFOQ0U6IDYsXHJcbiAgICAgICAgUFBNOiA3LFxyXG4gICAgICAgIEhSOiA4LFxyXG4gICAgICAgIEhfQU5EX1M6IDksXHJcbiAgICAgICAgUFBNVDogMTAsXHJcbiAgICAgICAgRklMRVM6IDEsXHJcbiAgICAgICAgRElTQ1VTU0lPTlM6IDAsXHJcbiAgICAgICAgVFJBTlNNSVRUQUxTOiAxLFxyXG4gICAgICAgIE1BUktFVFBMQUNFOiAxMixcclxuICAgICAgICBTVVNUQUlOQUJJTElUWTogMjEsXHJcbiAgICAgICAgQVBQU19UUkFOU01JVFRBTFM6IDIyLFxyXG4gICAgfSxcclxuXHJcbiAgICBDT01NRU5UX1RZUEU6IHtcclxuICAgICAgICBOT1JNQUw6IDEsXHJcbiAgICAgICAgTk9DT01NRU5UOiAyLFxyXG4gICAgICAgIFJFUExZOiA0XHJcbiAgICB9LFxyXG5cclxuICAgIFVTRVJfVklFV0VSX1BSRUZFUkVOQ0U6IHtcclxuICAgICAgICBIVE1MX1ZJRVdFUjogNSxcclxuICAgICAgICBBQ1RJVkVYX1ZJRVdFUjogNixcclxuICAgICAgICBQREZUUk9OX1ZJRVdFUjogN1xyXG4gICAgfSxcclxuXHJcbiAgICBVUExPQURfVFlQRToge1xyXG4gICAgICAgIEZJTEU6IDEsXHJcbiAgICAgICAgQVRUQUNITUVOVDogMixcclxuICAgICAgICBDT01NRU5UOiA1LFxyXG4gICAgICAgIEZPUk06IDQsXHJcbiAgICAgICAgSU5MSU5FX0ZPUk06IDYsXHJcbiAgICAgICAgTU9ERUxfQVRUQUNITUVOVDoxMVxyXG4gICAgfSxcclxuXHJcbiAgICBGSUxFU0FUVFJJQlVURVNfRVhDRVBUSU9OQ09ERToge1xyXG4gICAgICAgIENPREVfTElOS0VEX0ZJTEU6IDIwMTksXHJcbiAgICAgICAgQ09ERV9ERUFDVElWQVRFRF9GSUxFOiAyMDIwLFxyXG4gICAgICAgIENPREVfRklMRV9DSEVDS0VEX09VVDogMjAyMSxcclxuICAgICAgICBDT0RFX1ZBTElEX0VYSVNUSU5HX0ZJTEVTOiAyMDIyLFxyXG4gICAgICAgIENPREVfRVhURU5TSU9OX0xFU1NfRklMRU5BTUU6IDIwMjMsXHJcbiAgICAgICAgQ09ERV9QSF9BTFJFQURZX1VQTE9BREVEX05PVF9QVUJMSVNIX0FDVElPTjogMjAxMyxcclxuICAgICAgICBDT0RFX0RPQ1JFRl9BU1NPQ19XSVRIX0RJRkZfTU9ERUw6IDIwMzMsXHJcbiAgICAgICAgQ09ERV9SRVZJU0lPTl9VUExPQURfQUNUSVZJVFlfTE9DSzogMTAwMVxyXG4gICAgfSxcclxuXHJcbiAgICBWQUxJREFUSU9OX1RZUEU6IHtcclxuICAgICAgICBWQUxJREFUSU9OX09OX0VOVEVSX0RPQ19ERVRBSUxTOiAxXHJcbiAgICB9LFxyXG5cclxuICAgIGluaXRDb21wb25lbnRNYXBPYmo6IHtcclxuICAgICAgICBcIkFwcHNcIjogXCJhcHBcIixcclxuICAgICAgICBcIkhpc3RvcnlcIjogXCJoaXN0b3J5XCIsXHJcbiAgICAgICAgXCJyZXBseVwiOiBcImRpc2N1c3Npb25zXCIsXHJcbiAgICAgICAgXCJkaXNjdXNzaW9uc1wiOiBcImRpc2N1c3Npb25zXCIsXHJcbiAgICAgICAgXCJjcmVhdGVDb21tZXRcIjogXCJjcmVhdGUtY29tbWVudFwiLFxyXG4gICAgICAgIFwiY29vcmRpbmF0aW9uXCI6IFwiY29tbWVudC1jb29yZGluYXRpb25cIixcclxuICAgICAgICBcImluY29ycG9yYXRpb25cIjogXCJjb21tZW50LWluY29ycG9yYXRpb25cIixcclxuICAgICAgICBcImRpc3RyaWJ1dGlvblwiOiBcImZpbGUtZGlzdHJpYnV0aW9uXCIsXHJcbiAgICAgICAgXCJwdWJsaXNoXCI6IFwiYXR0YWNoLWRvY1wiLFxyXG4gICAgICAgIFwiQVNTSUdOX1NUQVRVU1wiOiBcInN0YXR1cy1jaGFuZ2VcIixcclxuICAgICAgICBcIkFTU09DX0FUVEFDSFwiOiBcImFzc29jLWF0dGFjaFwiLFxyXG4gICAgICAgIFwiZmlsZUluZm9cIjogXCJmaWxlLWluZm9cIlxyXG4gICAgfSxcclxuXHJcbiAgICBhdHRhY2hBc3NvY0xhYmVsTWFwOiB7XHJcbiAgICAgICAgJ0ZJTEVTJzogJ0ZpbGVzJyxcclxuICAgICAgICAnRElTQ1VTU0lPTlMnOiAnRGlzY3Vzc2lvbnMnLFxyXG4gICAgICAgICdGT1JNUyc6ICdGb3JtcycsXHJcbiAgICAgICAgJ0FUVEFDSE1FTlRTJzogJ0F0dGFjaG1lbnRzJyxcclxuICAgICAgICAnVklFV1MnOiAnVmlld3MnXHJcbiAgICB9LFxyXG5cclxuICAgIEZPUk1fU1RBVFVTOiB7XHJcbiAgICAgICAgY2xvc2VkOiAnQ2xvc2VkJ1xyXG4gICAgfSxcclxuXHJcbiAgICBET0NfVFlQRV9JRDoge1xyXG4gICAgICAgICdOT1JNQUwnOiAxLFxyXG4gICAgICAgICdQTEFDRUhPTERFUic6IDJcclxuICAgIH0sXHJcbiAgICAvL05PT0RMRS04NDAxNCBzb2xyIGRhdGEgbWFwcGluZyBpbiBtc2cuZGV0YWlsLmpzIGdsb2JhbCBmb3IgeHNuIGFuZCBodG1sNSBmb3JtIGxhdW5jaCBtYXBwaW5nIC0gZ2VuZXJpYyBmb3IgYm90aCB0eXBlcyBvZiBhcHBzIC0gcHRhaGlsaWFuaVxyXG4gICAgU09MUl9EQVRBX01BUFBJTkc6IHtcclxuICAgICAgICAnY29udHJvbGxlclVzZXJJZCc6ICdjb250cm9sbGVyX3VzZXJfaWQnLFxyXG4gICAgICAgICdjb250cm9sbGVyVXNlclR5cGVJZCc6ICdjb250cm9sbGVyX3VzZXJfdHlwZV9pZCcsXHJcbiAgICAgICAgJ2Zvcm1Db2RlJzogJ2Zvcm1fY29kZV9uYW1lJyxcclxuICAgICAgICAnZm9ybUNyZWF0aW9uRGF0ZSc6ICdmb3JtX2NyZWF0aW9uX2RhdGUnLFxyXG4gICAgICAgICdmb3JtSWQnOiAnZm9ybV9pZCcsXHJcbiAgICAgICAgJ2Zvcm1Obyc6ICdmb3JtX251bScsXHJcbiAgICAgICAgJ2Zvcm1Ob0ludCc6ICdmb3JtX251bScsXHJcbiAgICAgICAgJ2Zvcm1TdGF0dXNJZCc6ICdzdGF0dXNfaWQnLFxyXG4gICAgICAgICdmb3JtVGl0bGUnOiAndGl0bGUnLFxyXG4gICAgICAgICdmb3JtVHlwZUlkJzogJ2Zvcm1fdHlwZV9pZCcsXHJcbiAgICAgICAgJ2Zvcm1UeXBlTmFtZSc6ICdmb3JtX3R5cGVfbmFtZScsXHJcbiAgICAgICAgJ2Zvcm1fc3RhdHVzX25hbWUnOiAnc3RhdHVzX25hbWUnLFxyXG4gICAgICAgICdmb3JtY29kZV9udW0nOiAnZm9ybV9jb2RlJyxcclxuICAgICAgICAnaGFzQXR0YWNobWVudCc6ICdoYXNfYXR0YWNobWVudCcsXHJcbiAgICAgICAgJ21zZ0NyZWF0aW9uRGF0ZSc6ICdtc2dfY3JlYXRpb25fZGF0ZScsXHJcbiAgICAgICAgJ21zZ0lkJzogJ21zZ19pZCcsXHJcbiAgICAgICAgJ21zZ05vJzogJ21zZ19udW0nLFxyXG4gICAgICAgICdtc2dTdGF0dXNJZCc6ICdtc2dfc3RhdHVzX2lkJyxcclxuICAgICAgICAnbXNnVHlwZUlkJzogJ21zZ190eXBlX2lkJyxcclxuICAgICAgICAnbXNnX29yaV91c2VyX25hbWUnOiAnb3JpZ2luYXRvcl9uYW1lJyxcclxuICAgICAgICAnb3JpZ2luYXRvclByb3h5VXNlcklkJzogJ29yaWdpbmF0b3JfcHJveHlfdXNlcl9pZCcsXHJcbiAgICAgICAgJ29yaWdpbmF0b3JVc2VySWQnOiAnb3JpZ2luYXRvcl91c2VyX2lkJyxcclxuICAgICAgICAncHJvamVjdElkJzogJ3Byb2plY3RfaWQnLFxyXG4gICAgICAgICdzdGF0dXNfbmFtZSc6ICdzdGF0dXNfbmFtZScsXHJcbiAgICAgICAgJ3VzZXJSZWYnOiAndXNlcl9yZWYnLFxyXG4gICAgICAgICdtc2dDb250ZW50MSc6ICdtc2dfY29udGVudDEnLFxyXG4gICAgICAgICdtc2dDb250ZW50Mic6ICdtc2dfY29udGVudDInLFxyXG4gICAgICAgICdtc2dDb250ZW50JzogJ21zZ19jb250ZW50JyxcclxuICAgICAgICAnbXNnQ29udGVudDMnOiAnbXNnX2NvbnRlbnQzJ1xyXG4gICAgfSxcclxuXHJcbiAgICBESVNUUklCVVRJT05fTEVWRUw6IHtcclxuICAgICAgICBcIlJPTEVTXCI6IDEsXHJcbiAgICAgICAgXCJPUkdBTklTQVRJT05TXCI6IDIsXHJcbiAgICAgICAgXCJVU0VSU1wiOiAzLFxyXG4gICAgICAgIFwiVVNFUl9HUk9VUFNcIjogNCxcclxuICAgICAgICBcIkRJU1RSSUJVVElPTl9HUk9VUFNcIjogNVxyXG4gICAgfSxcclxuXHJcbiAgICBQUkVGSVhfRElTVFJJQlVUSU9OX0xFVkVMOiB7XHJcbiAgICAgICAgXCIxXCI6IFwiKFIpXCIsXHJcbiAgICAgICAgXCIyXCI6IFwiKE8pXCIsXHJcbiAgICAgICAgXCIzXCI6IFwiKFUpXCIsXHJcbiAgICAgICAgXCI0XCI6IFwiKFVHKVwiLFxyXG4gICAgICAgIFwiNVwiOiBcIihEKVwiXHJcbiAgICB9LFxyXG5cclxuICAgIFBERlRST05fU1VQUE9SVEVEX0VYVEVOU0lPTjogXCJER04sRFdGLERXRyxEWEYsUERGLFhQUyxYT0QsSFRNLEhUTUwsWEhUTUwsU1ZHLFRYVCxCTVAsSUNPLEdJRixKUEcsSlBFRyxQTkcsVElGLFRJRkYsRE9DLERPQ00sRE9DWCxET1QsRE9UTSxET1RYLFBPVCxQT1RYLFBQQSxQUFMsUFBTTSxQUFNYLFBQVCxQUFRNLFBQVFgsUFVCLFhMUyxYTFNCLFhMU00sWExTWCxYTFQsWExUTSxYTFRYLFJURlwiLFxyXG4gICAgVEhVTUJOQUlMX1NVUFBPUlRFRF9FWFRFTlNJT04gOiBcIkpQRyxKUEVHLFBORyxHSUYsVElGRixQREYsQk1QXCIsXHJcbiAgICBPRkZMSU5FX1RIVU1CTkFJTF9TVVBQT1JURURfRVhURU5TSU9OIDogXCJKUEcsSlBFRyxQTkdcIixcclxuICAgIENCSU1fUExVR0lOUzogXCJuYXZpc3dvcmt8cmV2aXRcIixcclxuXHJcbiAgICAvLyBBZGQgc3Vic2NyaXB0aW9uIGlkc1xyXG4gICAgQVZBSUxBQkxFX1VTRVJfVEFCUzogW1xyXG4gICAgICAgICczJyxcclxuICAgICAgICAnNScsXHJcbiAgICAgICAgJzExJyxcclxuICAgICAgICAnMzAnLFxyXG4gICAgICAgICczMScsXHJcbiAgICAgICAgJzMyJyxcclxuICAgICAgICAnMzMnLFxyXG4gICAgICAgICczNCcsXHJcbiAgICAgICAgJzM1JyxcclxuICAgICAgICAnMzYnLFxyXG4gICAgICAgICczNydcclxuICAgIF1cclxufSlcclxuXHJcbi5maWx0ZXIoJ3N0YXJ0RnJvbScsIGZ1bmN0aW9uKCkge1xyXG4gICAgcmV0dXJuIGZ1bmN0aW9uKGlucHV0LCBzdGFydCkge1xyXG4gICAgICAgIHN0YXJ0ID0gK3N0YXJ0OyAvL3BhcnNlIHRvIGludFxyXG4gICAgICAgIHJldHVybiBpbnB1dC5zbGljZShzdGFydCk7XHJcbiAgICB9XHJcbn0pXHJcblxyXG4vKipcclxuICogIEludm9rZSBvbiBvZmZsaW5lQ3JlYXRlRm9ybS5odG1sIGFuZCBvZmZsaW5lVmlld0Zvcm0uaHRtbCBwYWdlIGluIG9mZmxpbmUgaHRtbDUgZm9ybS5cclxuICogIFRoaXMgZmlsdGVyIHdpbGwgcHJvdmlkZSBpbnRlcm5hdGlvbmFsaXphdGlvbi5cclxuICovXHJcbi5maWx0ZXIoJ29mZmxpbmVMYW5nJywgZnVuY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24oaW5wdXQpIHtcclxuICAgICAgICByZXR1cm4gTGFuZ3VhZ2UuZ2V0KGlucHV0KTtcclxuICAgIH07XHJcbn0pXHJcblxyXG4vKipcclxuICogQmFzZWQgRG9tYWluIFNlcnZpY2VcclxuICogVGhpcyBzZXJ2aWNlIGlzIHVzZSBmb3IgbWFrZSBkYyBzcGVjaWZpYyB1cmxcclxuICovXHJcbi5zZXJ2aWNlKCdtYW5hZ2VEYXRhQ2VudGVyJywgWyckd2luZG93JywgJyR0aW1lb3V0JywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICdsYW5nJywgZnVuY3Rpb24oJHdpbmRvdywgJHRpbWVvdXQsIGFwaUNvbmZpZywgbXlDb25maWcsIGxhbmcpIHtcclxuICAgIHZhciBtYW5hZ2VEYXRhQ2VudGVyID0gdGhpcztcclxuXHJcbiAgICB3aW5kb3cubWFuYWdlRGF0YUNlbnRlckdsb2JhbCA9IG1hbmFnZURhdGFDZW50ZXI7XHJcbiAgICAvKlxyXG4gICAgICogRm9sbG93aW5nIGZ1bmN0aW9uIGlzIHVzZWQgZm9yIGluaXRpYWxpemUgbWFuYWdlIGRhdGEgY2VudGVyIHNlcnZpY2VcclxuICAgICAqL1xyXG4gICAgbWFuYWdlRGF0YUNlbnRlci5pbml0ID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgbWFuYWdlRGF0YUNlbnRlci5tYW5pcHVsYXRlRENKc29uKCk7XHJcbiAgICAgICAgbWFuYWdlRGF0YUNlbnRlci5tYW5pcHVsYXRlQ29udGVudEFjY2VsZXJhdGlvbkpzb24oKTtcclxuICAgICAgICBtYW5hZ2VEYXRhQ2VudGVyLnNldFJlZ0V4KCk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8qXHJcbiAgICAgKiBGb2xsb3dpbmcgZnVuY3Rpb24gaXMgdXNlZCBmb3IgbWFwcGluZyBvYmogYmFzZWQgb24gZGNJZCBhbmQgaXRzIHN1ZmZpeFxyXG4gICAgICovXHJcbiAgICBtYW5hZ2VEYXRhQ2VudGVyLm1hbmlwdWxhdGVEQ0pzb24gPSBmdW5jdGlvbigpIHtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG15Q29uZmlnLlVTRVJfRENfSlNPTi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBteUNvbmZpZy5kY01hcFN1ZmZpeFtteUNvbmZpZy5VU0VSX0RDX0pTT05baV0uaWRdID0gbXlDb25maWcuVVNFUl9EQ19KU09OW2ldLnN1ZmZpeFxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLypcclxuICAgICAqIEZvbGxvd2luZyBmdW5jdGlvbiBpcyB1c2VkIGZvciBtYXBwaW5nIG9iaiB3aXRoIENvbnRlbnQgQWNjZWxlcmF0aW9uIFN1ZmZpeFxyXG4gICAgICovXHJcbiAgICBtYW5hZ2VEYXRhQ2VudGVyLm1hbmlwdWxhdGVDb250ZW50QWNjZWxlcmF0aW9uSnNvbiA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbXlDb25maWcuQ09OVEVOVF9BQ0NFTEVSQVRJT05fSlNPTi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBteUNvbmZpZy5jYU1hcFN1ZmZpeFtteUNvbmZpZy5DT05URU5UX0FDQ0VMRVJBVElPTl9KU09OW2ldLmlkXSA9IG15Q29uZmlnLkNPTlRFTlRfQUNDRUxFUkFUSU9OX0pTT05baV0uc3VmZml4XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvKlxyXG4gICAgICogRm9sbG93aW5nIGZ1bmN0aW9uIGlzIHVzZWQgZm9yIGdlbmVyYXRlIHJlZ3VsYXIgZXhwcmVzc2lvbiBiYXNlZCBvbiBVU0VSX0RDX0pTT04gJiBDT05URU5UX0FDQ0xFUkFUSU9OX0pTT05cclxuICAgICAqL1xyXG4gICAgbWFuYWdlRGF0YUNlbnRlci5zZXRSZWdFeCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzdHIgPSBcIlwiO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDw9IE9iamVjdC5rZXlzKG15Q29uZmlnLlVTRVJfRENfSlNPTikubGVuZ3RoIC0gMTsgaSsrKSB7XHJcbiAgICAgICAgICAgIHZhciBkY0pzb25EYXRhID0gbXlDb25maWcuVVNFUl9EQ19KU09OW2ldO1xyXG4gICAgICAgICAgICBpZiAoZGNKc29uRGF0YS5zdWZmaXggIT0gXCJcIikge1xyXG4gICAgICAgICAgICAgICAgc3RyICs9IGRjSnNvbkRhdGEuc3VmZml4ICsgXCJcXFxcLnxcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDw9IE9iamVjdC5rZXlzKG15Q29uZmlnLkNPTlRFTlRfQUNDRUxFUkFUSU9OX0pTT04pLmxlbmd0aCAtIDE7IGorKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGFjY2VsZXJhdGlvbkpzb25EYXRhID0gbXlDb25maWcuQ09OVEVOVF9BQ0NFTEVSQVRJT05fSlNPTltqXTtcclxuICAgICAgICAgICAgICAgIGlmIChpID09IE9iamVjdC5rZXlzKG15Q29uZmlnLlVTRVJfRENfSlNPTikubGVuZ3RoIC0gMSAmJiBqID09IE9iamVjdC5rZXlzKG15Q29uZmlnLkNPTlRFTlRfQUNDRUxFUkFUSU9OX0pTT04pLmxlbmd0aCAtIDEpIHtcclxuICAgICAgICAgICAgICAgICAgICBzdHIgKz0gZGNKc29uRGF0YS5zdWZmaXggKyBhY2NlbGVyYXRpb25Kc29uRGF0YS5zdWZmaXggKyBcIlxcXFwuXCJcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3RyICs9IGRjSnNvbkRhdGEuc3VmZml4ICsgYWNjZWxlcmF0aW9uSnNvbkRhdGEuc3VmZml4ICsgXCJcXFxcLnxcIlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG15Q29uZmlnLmRjUmVnRXggPSBuZXcgUmVnRXhwKHN0ciwgJ2knKTtcclxuICAgIH07XHJcblxyXG4gICAgbWFuYWdlRGF0YUNlbnRlci5kb21haW5SZXBsYWNlID0gZnVuY3Rpb24ocmV0dXJuVXJsKSB7XHJcbiAgICAgICAgdmFyIGRjRXh0RXhpc3RlZFVybHMgPSBteUNvbmZpZy5kY0V4dG5FeGlzdGVkTGlzdCB8fCBcIlwiO1xyXG4gICAgICAgIHZhciBpbmRleCA9IHJldHVyblVybC5pbmRleE9mKFwiLlwiKTtcclxuICAgICAgICB2YXIgdXJsQmVmb3JlRG90ID0gcmV0dXJuVXJsLnN1YnN0cmluZygwLCBpbmRleCArIDEpOyAvL2dldCB0aGUgZmlyc3QgcGFydCBvZiBVUkwgd2hlcmUgQ0ROL0RDIGV4dGVuc2lvbiBhcHBlbmRlZC4gbGlrZSBodHRwczovL2Rtc2FrLlxyXG4gICAgICAgIGlmIChkY0V4dEV4aXN0ZWRVcmxzKSB7XHJcbiAgICAgICAgICAgIHZhciBhcnJheSA9IGRjRXh0RXhpc3RlZFVybHMuc3BsaXQoXCIsXCIpO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZGNFeGlzdEluVXJsID0gYXJyYXlbaV07XHJcbiAgICAgICAgICAgICAgICB2YXIgbiA9IHVybEJlZm9yZURvdC5pbmRleE9mKGRjRXhpc3RJblVybCk7XHJcbiAgICAgICAgICAgICAgICBpZiAobiA+IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHVybERjRXh0ID0gdXJsQmVmb3JlRG90LnN1YnN0cmluZyhuLCB1cmxCZWZvcmVEb3QubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICB1cmxCZWZvcmVEb3QgPSB1cmxCZWZvcmVEb3QucmVwbGFjZSh1cmxEY0V4dCwgZGNFeGlzdEluVXJsKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXJsQmVmb3JlRG90O1xyXG4gICAgfTtcclxuXHJcbiAgICAvKlxyXG4gICAgICogRm9sbG93aW5nIGZ1bmN0aW9uIGlzIHVzZWQgZm9yIHJldHVybiBiYXNlVXJsL2ZpbmFsUGF0aCBiYXNlZCBvbiBAZGNJZFxyXG4gICAgICovXHJcbiAgICBtYW5hZ2VEYXRhQ2VudGVyLmdldFVybCA9IGZ1bmN0aW9uKGRjSWQsIGNkblVybCwgbm9uRWRnZWNhc3QpIHtcclxuICAgICAgICBpZiAoIWRjSWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBkY1N1ZmZpeCA9IG15Q29uZmlnLmRjTWFwU3VmZml4W2RjSWRdO1xyXG4gICAgICAgIHZhciBjb250ZW50QWNjZWxlcmF0aW9uU3VmZml4ID0gXCJcIjtcclxuICAgICAgICBpZiAoIW5vbkVkZ2VjYXN0ICYmIGRjSWQgPT0gMSAmJiBteUNvbmZpZy5VU0VSX0NETl9UWVBFX0lEID09IFwiMVwiKSB7XHJcbiAgICAgICAgICAgIGNvbnRlbnRBY2NlbGVyYXRpb25TdWZmaXggPSBteUNvbmZpZy5jYU1hcFN1ZmZpeFtkY0lkXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGZpbmFsUGF0aCA9IGNkblVybCB8fCBteUNvbmZpZy5iYXNlVXJsO1xyXG4gICAgICAgIHZhciBzcGxpdFBhdGggPSBmaW5hbFBhdGguc3BsaXQoXCIuXCIpO1xyXG4gICAgICAgIHNwbGl0UGF0aFswXSArPSBcIi5cIjtcclxuICAgICAgICBzcGxpdFBhdGhbMF0gPSBtYW5hZ2VEYXRhQ2VudGVyLmRvbWFpblJlcGxhY2Uoc3BsaXRQYXRoWzBdKTtcclxuICAgICAgICBzcGxpdFBhdGhbMF0gPSBzcGxpdFBhdGhbMF0ucmVwbGFjZShteUNvbmZpZy5kY1JlZ0V4LCBcIlwiKSArIGRjU3VmZml4ICsgY29udGVudEFjY2VsZXJhdGlvblN1ZmZpeDtcclxuICAgICAgICByZXR1cm4gc3BsaXRQYXRoLmpvaW4oXCIuXCIpXHJcbiAgICB9O1xyXG5cclxuICAgIG1hbmFnZURhdGFDZW50ZXIuaW5pdCgpO1xyXG59XSlcclxuXHJcbi8qXHJcbiAqIERvd25sb2FkIFNlcnZpY2VcclxuICogVGhpcyBtb2R1bGUgd2lsbCBtYW5hZ2UgZG93bmxvYWQgZnVuY3Rpb25hbGl0eSBsaWtlIGJlbG93OiBcclxuICogXHQtXHRGZXRjaCBhamF4IGNhbGwgZm9yIGRvd25sb2FkIHNldHRpbmdcclxuXHRcdC1cdHBhc3MgZG93bmxvYWQgc2V0dGluZyBkYXRhIHRvIGl0cyBjYWxsYmFjayBmdW5cclxuXHRcclxuXHQtXHRDaGVjayBkb3dubG9hZCBmb3Igc2luZ2xlIGZpbGUgb3Igbm90XHQgXHJcbiAqL1xyXG4uc2VydmljZSgnZG93bmxvYWQnLCBbJyR3aW5kb3cnLCAnJHRpbWVvdXQnLCAnTm90aWZpY2F0aW9uJywgJ2xhbmcnLCAnYXBpJywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICckdWliTW9kYWwnLCAnbWFuYWdlRGF0YUNlbnRlcicsIGZ1bmN0aW9uKCR3aW5kb3csICR0aW1lb3V0LCBOb3RpZmljYXRpb24sIGxhbmcsIGFwaSwgYXBpQ29uZmlnLCBteUNvbmZpZywgJHVpYk1vZGFsLCBtYW5hZ2VEYXRhQ2VudGVyKSB7XHJcbiAgICB2YXIgZG93bmxvYWQgPSB0aGlzLFxyXG4gICAgICAgIHByb2plY3RJZHMgPSBbXSxcclxuICAgICAgICBwYXJhbVJldiA9IHtcclxuICAgICAgICAgICAgcmV2aXNpb25zOiBbXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGFyYW1EY0lkID0ge30sXHJcbiAgICAgICAgZXJyb3JDb2RlID0gW107XHJcblxyXG4gICAgZG93bmxvYWQuaW5pdCA9IGZ1bmN0aW9uKGRhdGEsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgTm90aWZpY2F0aW9uLmNsZWFyQWxsKCk7XHJcblxyXG4gICAgICAgIGlmIChteUNvbmZpZy5hcHBsaWNhdGlvbklkICE9IDIpIHtcclxuICAgICAgICAgICAgTm90aWZpY2F0aW9uLnN1Y2Nlc3MoJzxkaXYgY2xhc3M9XCJib2xkLW1zZyB0ZXh0LWNlbnRlclwiPicgKyBsYW5nLmdldChcImRvd25sb2FkLWhhcy1iZWVuLXN0YXJ0ZWRcIikgKyAnPC9kaXY+Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChkb3dubG9hZC5pc1NpbmdsZUZpbGUoZGF0YSkpIHtcclxuICAgICAgICAgICAgZG93bmxvYWQuZmlsZShkYXRhLCBkYXRhLnByb2plY3RJZCk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChkb3dubG9hZC5oYXNNdWx0cGxlUHJvamVjdChkYXRhKSkge1xyXG4gICAgICAgICAgICBkb3dubG9hZC5zZXRQcm9qZWN0SWRzKGRhdGEpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGRhdGEuZG93bmxvYWRQcmVmICYmIChkYXRhLmRvd25sb2FkUHJlZi5pc0luY2x1ZGVNYXJrdXAgfHwgZGF0YS5kb3dubG9hZFByZWYuaXNFbWJlZFFSQ29kZSkpIHtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkLnppcChkYXRhLnNlbGVjdGVkRmlsZXMsIGRhdGEuZG93bmxvYWRQcmVmLCBjYWxsYmFjayk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBkb3dubG9hZC5tdWx0aXBsZVByb2ooZGF0YSwgY2FsbGJhY2spO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZG93bmxvYWQuemlwKGRhdGEuc2VsZWN0ZWRGaWxlcywgZGF0YS5kb3dubG9hZFByZWYsIGNhbGxiYWNrKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGRvd25sb2FkLmhhc011bHRwbGVQcm9qZWN0ID0gZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgIHZhciBwcm9qZWN0SWQgPSBkYXRhLnNlbGVjdGVkRmlsZXNbMF0ucHJvamVjdElkO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGF0YS5zZWxlY3RlZEZpbGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChwcm9qZWN0SWQgIT0gZGF0YS5zZWxlY3RlZEZpbGVzW2ldLnByb2plY3RJZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH07XHJcblxyXG4gICAgZG93bmxvYWQuc2V0UHJvamVjdElkcyA9IGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICBlcnJvckNvZGUgPSBwcm9qZWN0SWRzID0gcGFyYW1SZXYucmV2aXNpb25zID0gW107XHJcbiAgICAgICAgcGFyYW1EY0lkID0ge307XHJcblxyXG4gICAgICAgIHZhciBwcmRJZHMgPSBbXSxcclxuICAgICAgICAgICAgcmV2SWRzID0gW10sXHJcbiAgICAgICAgICAgIG9iaiA9IHt9O1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGF0YS5zZWxlY3RlZEZpbGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIG9iaiA9IHtcclxuICAgICAgICAgICAgICAgIGRjSWQ6IGRhdGEuc2VsZWN0ZWRGaWxlc1tpXS5kY0lkLFxyXG4gICAgICAgICAgICAgICAgaXNMb2NrOiBkYXRhLnNlbGVjdGVkRmlsZXNbaV0uaXNMb2NrLFxyXG4gICAgICAgICAgICAgICAgcmV2aXNpb25JZDogZGF0YS5zZWxlY3RlZEZpbGVzW2ldLnJldmlzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IGRhdGEuc2VsZWN0ZWRGaWxlc1tpXS5wcm9qZWN0SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXZJZHMucHVzaChvYmopO1xyXG4gICAgICAgICAgICBpZiAoIXBhcmFtRGNJZFtkYXRhLnNlbGVjdGVkRmlsZXNbaV0uZGNJZF0pIHtcclxuICAgICAgICAgICAgICAgIHBhcmFtRGNJZFtkYXRhLnNlbGVjdGVkRmlsZXNbaV0uZGNJZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV2aXNpb25zOiBbXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBwYXJhbURjSWRbZGF0YS5zZWxlY3RlZEZpbGVzW2ldLmRjSWRdLnJldmlzaW9ucy5wdXNoKGRhdGEuc2VsZWN0ZWRGaWxlc1tpXSk7XHJcblxyXG4gICAgICAgICAgICBwcmRJZHMucHVzaChkYXRhLnNlbGVjdGVkRmlsZXNbaV0ucHJvamVjdElkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcGFyYW1SZXYucmV2aXNpb25zID0gcmV2SWRzO1xyXG4gICAgICAgIHByb2plY3RJZHMgPSBwcmRJZHM7XHJcbiAgICB9O1xyXG5cclxuICAgIGRvd25sb2FkLm11bHRpcGxlUHJvaiA9IGZ1bmN0aW9uKGRhdGEsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgZGF0YS5yZXZpc2lvbklkcyA9IHBhcmFtUmV2O1xyXG4gICAgICAgIGRvd25sb2FkLnJldHVybk5vbkFrYW1haVVSTChkYXRhLCBmdW5jdGlvbihyZXNEYXRhKSB7XHJcbiAgICAgICAgICAgIHZhciBjZG5Vcmw7XHJcbiAgICAgICAgICAgIGlmIChyZXNEYXRhLmlzTGltaXRFeGlzdCkge1xyXG4gICAgICAgICAgICAgICAgY2RuVXJsID0gcmVzRGF0YS5ub25DRE5Eb3dubG9hZFVybDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgY291bnRlciA9IDA7XHJcbiAgICAgICAgICAgIGZvciAoa2V5IGluIHBhcmFtRGNJZCkge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1EY0lkW2tleV0uZGNJZCA9IGtleTtcclxuICAgICAgICAgICAgICAgIHBhcmFtRGNJZFtrZXldLmNkblVybCA9IGNkblVybDtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkLmNoZWNrQXZhaWxGb3JEb3dubG9hZChwYXJhbURjSWRba2V5XSwgZnVuY3Rpb24ocmVzRGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNEYXRhICYmIHJlc0RhdGEubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yQ29kZS5wdXNoKHJlc0RhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjb3VudGVyKys7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHBhcmFtRGNJZCkubGVuZ3RoID09PSBjb3VudGVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkLnN0YXJ0QmF0Y2hGaWxlcyhkYXRhLCBjYWxsYmFjayk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLmVycm9yICYmIGVycm9yQ29kZS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEuZXJyb3IoZXJyb3JDb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgZG93bmxvYWQuY2hlY2tSZXZSZXN0cmljdGlvbiA9IGZ1bmN0aW9uKGRhdGEsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgdmFyIHBhcmFtT2JqID17XHJcbiAgICAgICAgICAgIHByb2plY3RJZDogZGF0YS5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgIHJldmlzaW9uSWQ6IGRhdGEucmV2aXNpb25JZCxcclxuICAgICAgICAgICAgZm9ybVByb2plY3RJZDogbXlDb25maWcucHJvamVjdElkXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKG15Q29uZmlnLmZvcm1UeXBlSWQgJiYgbXlDb25maWcuZm9ybVR5cGVJZCAhPT1cIm51bGxcIiAmJiBteUNvbmZpZy5mb3JtVHlwZUlkLmluZGV4T2YoXCIkJFwiKSAhPSAtMSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHBhcmFtT2JqLmZvcm1UeXBlSWQgPSBteUNvbmZpZy5mb3JtVHlwZUlkO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG4gICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5JU19ET0NVTUVOVF9ET1dOTE9BRF9SRVNUUklDVEVELFxyXG4gICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgIGRhdGEgOnBhcmFtT2JqXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHhoci50aGVuKGZ1bmN0aW9uKHJlc3BEYXRhKSB7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHJlc3BEYXRhKTtcclxuICAgICAgICB9LCBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICAgICAgJHdpbmRvdy5hbGVydChsYW5nLmdldChcInNvbWV0aGluZy13ZW50LXdyb25nXCIpKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBkb3dubG9hZC5jaGVja0F2YWlsRm9yRG93bmxvYWQgPSBmdW5jdGlvbihkYXRhLCBjYWxsYmFjaykge1xyXG4gICAgICAgIHZhciB4aHIgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkNIRUNLX0FWQUlMQUJJTElUWV9PRl9ET1dOTE9BRF9ET0NVTUVOVF9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICBpc011bHRpUHJvamVjdDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIGV4dHJhOiBhbmd1bGFyLnRvSnNvbihkYXRhKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBfZGNJZDogZGF0YS5kY0lkLFxyXG4gICAgICAgICAgICBfY2RuVXJsOiBkYXRhLmNkblVybCB8fCBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgeGhyLnRoZW4oZnVuY3Rpb24ocmVzcERhdGEpIHtcclxuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2socmVzcERhdGEpO1xyXG4gICAgICAgIH0sIGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgICAgICAkd2luZG93LmFsZXJ0KGxhbmcuZ2V0KFwic29tZXRoaW5nLXdlbnQtd3JvbmdcIikpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5zdGFydEJhdGNoRmlsZXMgPSBmdW5jdGlvbihkYXRhLCBjYWxsYmFjaykge1xyXG4gICAgICAgIHZhciB1cmwgPSBhcGlDb25maWcuTVVMVElfRENfRE9XTkxPQURfQkFUQ0hfRE9DVU1FTlRfQUNUSU9OX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgIHByb2plY3RJZCA9IGRhdGEucHJvamVjdElkLFxyXG4gICAgICAgICAgICBzZWxlY3RNdWx0aURDVUtQcm9qSWQgPSBkYXRhLnNlbGVjdE11bHRpRENVS1Byb2pJZDtcclxuICAgICAgICAgICAgaXNGcm9tTXVsdGlEQ0JhdGNoID0gZGF0YS5pc0Zyb21NdWx0aURDQmF0Y2ggfHwgZmFsc2U7XHJcblxyXG4gICAgICAgIHZhciBwYXJhbXNPYmogPSB7XHJcbiAgICAgICAgICAgIGV4dHJhOiBKU09OLnN0cmluZ2lmeShwYXJhbVJldiksXHJcbiAgICAgICAgICAgIHByb2plY3RJZHM6IFwiXCIsXHJcbiAgICAgICAgICAgIHByb2plY3RJRDogcHJvamVjdElkLFxyXG4gICAgICAgICAgICBpc0Zyb21NdWx0aURDQmF0Y2g6aXNGcm9tTXVsdGlEQ0JhdGNoXHJcblxyXG4gICAgICAgIH07XHJcbiAgICAgICAgaWYgKGRhdGEuYnlQYXNzUGFyYW0pIHtcclxuICAgICAgICAgICAgcGFyYW1zT2JqLmFkYWRzID0gXCJ0cnVlXCI7XHJcbiAgICAgICAgICAgIHBhcmFtc09iai5oYXNoZWRUb2tlbiA9IGRhdGEuYnlQYXNzUGFyYW0uYWxsb3dEb3dubG9hZFRva2VuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciB4aHIgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogdXJsLFxyXG4gICAgICAgICAgICBkYXRhOiBwYXJhbXNPYmosXHJcbiAgICAgICAgICAgIF9jZG5Vcmw6IG15Q29uZmlnLmRvd25sb2FkU2VydmljZVVSTCxcclxuICAgICAgICAgICAgX2RjSWQ6IGRhdGEuZGNJZFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB4aHIudGhlbihmdW5jdGlvbihyZXNwRGF0YSkge1xyXG4gICAgICAgICAgICBpZiAocmVzcERhdGEudmFsaWRGb3JEb3dubG9hZCA9PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgeGhyLmVycm9yVGl0bGUgPSBsYW5nLmdldChcImRpc2FibGVkLWVuYWJsZWQtZG93bmxvYWQtYnV0dG9uXCIpO1xyXG4gICAgICAgICAgICAgICAgYXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXNwRGF0YS5wcm9qZWN0SWQgPSBwcm9qZWN0SWQ7XHJcbiAgICAgICAgICAgICAgICByZXNwRGF0YS5pc011bHRpRENVS1Byb2pJZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICByZXNwRGF0YS5zZWxlY3RNdWx0aURDVUtQcm9qSWQgPSBzZWxlY3RNdWx0aURDVUtQcm9qSWQ7XHJcbiAgICAgICAgICAgICAgICByZXNwRGF0YS5pc0Zyb21NdWx0aURDQmF0Y2ggPSBpc0Zyb21NdWx0aURDQmF0Y2g7XHJcbiAgICAgICAgICAgICAgICBpZiAoZGF0YS5kb3dubG9hZFByZWYgJiYgKGRhdGEuZG93bmxvYWRQcmVmLmlzSW5jbHVkZU1hcmt1cCB8fCBkYXRhLmRvd25sb2FkUHJlZi5pc0VtYmVkUVJDb2RlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi53YXJuaW5nKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJzxkaXYgY2xhc3M9XCJ0ZXh0LWxhcmdlXCI+JyArIGxhbmcuZ2V0KFwicGxlYXNlLXdhaXQtZmlsZXMtcHJvY2Vzc2Qtd2hpbGVcIikgKyAnPC9kaXY+JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsYXk6IGZhbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZG93bmxvYWQuZG93bmxvYWRJbmNsdWRlTWFya3VwcyhkYXRhLCB1bmRlZmluZWQsIGNhbGxiYWNrKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZG93bmxvYWQuY3JlYXRlWmlwRmlsZShyZXNwRGF0YSwgY2FsbGJhY2spO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgICR3aW5kb3cuYWxlcnQobGFuZy5nZXQoXCJzb21ldGhpbmctd2VudC13cm9uZ1wiKSk7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGRvd25sb2FkLmhhc0FueVNldHRpbmdBcHBsaWVkID0gZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgIHZhciBwcmVmID0gZGF0YTtcclxuICAgICAgICByZXR1cm4gcHJlZi5pc1BhcmVudERvYyB8fCBwcmVmLmlzSW5jbHVkZU1hcmt1cCB8fCBwcmVmLmlzRW1iZWRRUkNvZGUgfHwgcHJlZi5oYXNDb21tZW50QXR0YWNoZWREb2NzIHx8IHByZWYuaGFzQ29tbWVudEFzc29jRG9jcyB8fCBwcmVmLmlzQXNzb2NGaWxlcztcclxuICAgIH07XHJcblxyXG4gICAgZG93bmxvYWQuaXNTaW5nbGVGaWxlID0gZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgIHZhciBmbGFnID0gZmFsc2UsXHJcbiAgICAgICAgICAgIHByZWYgPSBkYXRhLmRvd25sb2FkUHJlZixcclxuICAgICAgICAgICAgc2VsZWN0ZWRQcmVmID0gdGhpcy5pc011bHRpUHJlZlNlbGVjdGVkKHByZWYpO1xyXG5cclxuICAgICAgICBpZiAoZGF0YS5zZWxlY3RlZEZpbGVzLmxlbmd0aCA9PT0gMSAmJiAhcHJlZi5pc0luY2x1ZGVNYXJrdXAgJiYgIXByZWYuaXNFbWJlZFFSQ29kZSAmJiAhcHJlZi5oYXNDb21tZW50QXNzb2NEb2NzICYmICFwcmVmLmhhc0NvbW1lbnRBdHRhY2hlZERvY3MgJiYgIXByZWYuaXNBc3NvY0ZpbGVzICYmICFwcmVmLmlzWFJFRikge1xyXG4gICAgICAgICAgICBmbGFnID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2UgaWYgKHNlbGVjdGVkUHJlZiA9PT0gMSkge1xyXG4gICAgICAgICAgICBmbGFnID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIGlmIChwcmVmLmhhc0NvbW1lbnRBdHRhY2hlZERvY3MgJiYgcHJlZi5jb21tZW50QXR0YWNoZWREb2NzQ291bnQgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChwcmVmLmhhc0NvbW1lbnRBc3NvY0RvY3MgJiYgcHJlZi5jb21tZW50QXNzb2NEb2NzQ291bnQgPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChwcmVmLmlzQXNzb2NGaWxlcyAmJiB0aGlzLmFueUZpbGVIYXNBdHRhY2htZW50KGRhdGEpKSB7XHJcbiAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChwcmVmLmlzSW5jbHVkZU1hcmt1cCAmJiAocHJlZi5tYXJrVXBEb2NzQ291bnQgPiAxIHx8IChwcmVmLm1hcmtVcERvY3NDb3VudCA9PT0gMSAmJiBkYXRhLnNlbGVjdGVkRmlsZXMubGVuZ3RoID4gMSkpKSB7XHJcbiAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChwcmVmLmlzUGFyZW50RG9jICYmIGRhdGEuc2VsZWN0ZWRGaWxlcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIChwcmVmLmlzSW5jbHVkZU1hcmt1cCB8fCBwcmVmLmlzRW1iZWRRUkNvZGUpICYmIChmbGFnID0gZmFsc2UpO1xyXG4gICAgICAgIHJldHVybiBmbGFnO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5hbnlGaWxlSGFzQXR0YWNobWVudCA9IGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICB2YXIgY291bnQgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRhdGEuc2VsZWN0ZWRGaWxlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgZmlsZU9iaiA9IGRhdGEuc2VsZWN0ZWRGaWxlc1tpXTtcclxuICAgICAgICAgICAgaWYgKGZpbGVPYmouaGFzQXR0YWNobWVudCkge1xyXG4gICAgICAgICAgICAgICAgY291bnQgKz0gMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIChjb3VudCA+IDEpO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5pc011bHRpUHJlZlNlbGVjdGVkID0gZnVuY3Rpb24oZG93bmxvYWRQcmVmKSB7XHJcbiAgICAgICAgdmFyIGNoZWNrTGVuZ3RoID0gMDtcclxuXHJcbiAgICAgICAgdmFyIGFycmF5ID0gW2Rvd25sb2FkUHJlZi5pc1BhcmVudERvYywgZG93bmxvYWRQcmVmLmlzQXNzb2NGaWxlcywgZG93bmxvYWRQcmVmLmlzWFJFRixcclxuICAgICAgICAgICAgZG93bmxvYWRQcmVmLmhhc0NvbW1lbnRBc3NvY0RvY3MsIGRvd25sb2FkUHJlZi5oYXNDb21tZW50QXR0YWNoZWREb2NzLCBkb3dubG9hZFByZWYuaXNJbmNsdWRlTWFya3VwLCBkb3dubG9hZFByZWYuaXNFbWJlZFFSQ29kZVxyXG4gICAgICAgIF07XHJcblxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGFycmF5W2ldKSB7XHJcbiAgICAgICAgICAgICAgICBjaGVja0xlbmd0aCsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY2hlY2tMZW5ndGg7XHJcbiAgICB9O1xyXG5cclxuICAgIGRvd25sb2FkLnJldHVybk5vbkFrYW1haVVSTCA9IGZ1bmN0aW9uKHBhcmFtLCBjYWxsYmFjaykge1xyXG4gICAgICAgIGlmKCFteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwpe1xyXG4gICAgICAgICAgICBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwgPSB3aW5kb3cuZG93bmxvYWRTZXJ2aWNlVVJMO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG4gICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5DSEVDS19ET0NVTUVOVF9ET1dOTE9BRF9MSU1JVCxcclxuICAgICAgICAgICAgX2NkblVybDogbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICB1c2VySWQ6IG15Q29uZmlnLlVTUC51c2VySUQsXHJcbiAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IHBhcmFtLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgIGV4dHJhOiBKU09OLnN0cmluZ2lmeShwYXJhbS5yZXZpc2lvbklkcylcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB4aHIudGhlbihmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKGRhdGEpO1xyXG4gICAgICAgIH0sIGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgICAgICAkd2luZG93LmFsZXJ0KGxhbmcuZ2V0KFwic29tZXRoaW5nLXdlbnQtd3JvbmdcIikpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5mZXRjaFByZWYgPSBmdW5jdGlvbihkYXRhLCBjYWxsYmFjaykge1xyXG4gICAgICAgIHJldHVybiBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkRPV05MT0FEX0JBVENIX0RPQ1VNRU5UX1BBR0VfQ09OVFJPTExFUixcclxuICAgICAgICAgICAgX2NkblVybDogbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICBleHRyYTogYW5ndWxhci50b0pzb24oeyBcInJldmlzaW9uc1wiOiBkYXRhLnNlbGVjdGVkRmlsZXMgfSksXHJcbiAgICAgICAgICAgICAgICBpc0Zyb21BdHRhY2htZW50OiAoKGRhdGEuY3VycmVudEVudGl0eVR5cGUgPT09IGFwaUNvbmZpZy5hdHRhY2hBc3NvY0xhYmVsTWFwLkFUVEFDSE1FTlRTKSA/IFwidHJ1ZVwiIDogdW5kZWZpbmVkKSxcclxuICAgICAgICAgICAgICAgIHByb2plY3RJRDogZGF0YS5wcm9qZWN0SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5maWxlID0gZnVuY3Rpb24oZmlsZSwgcHJvamVjdElkKSB7XHJcbiAgICAgICAgaWYgKG15Q29uZmlnLmFwcGxpY2F0aW9uSWQgPT0gMikge1xyXG4gICAgICAgICAgICBxdE9iamVjdC5kb3dubG9hZEZpbGUoSlNPTi5zdHJpbmdpZnkoZmlsZS5kb3dubG9hZFByZWYpLCBmaWxlLnNlbGVjdGVkRmlsZXNbMF0uZmlsZU5hbWUpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgZGF0YVRvU2VuZCA9IHtcclxuICAgICAgICAgICAgcHJvamVjdElEOiBmaWxlLnByb2plY3RJZCxcclxuICAgICAgICAgICAgaXNGcm9tWHJlZlJldmlzaW9uRGV0YWlsczogZmFsc2UsXHJcbiAgICAgICAgICAgIGV4dHJhOiBKU09OLnN0cmluZ2lmeShmaWxlLmRvd25sb2FkUHJlZilcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAoZmlsZS5zZWxlY3RlZEZpbGVzWzBdLmN1ckZvcm1CeVBhc3NTZXR0aW5nICYmIGZpbGUuc2VsZWN0ZWRGaWxlc1swXS5jdXJGb3JtQnlQYXNzU2V0dGluZy52aWV3QWx3YXlzRG9jQXNzb2NpYXRpb24pIHtcclxuICAgICAgICAgICAgZGF0YVRvU2VuZC5hZGFkcyA9IHRydWU7XHJcbiAgICAgICAgICAgIGRhdGFUb1NlbmQuaGFzaGVkVG9rZW4gPSBmaWxlLnNlbGVjdGVkRmlsZXNbMF0uY3VyRm9ybUJ5UGFzc1NldHRpbmcuYWxsb3dEb3dubG9hZFRva2VuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgYXBpLnN1Ym1pdEZvcm0oe1xyXG4gICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5ET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgIHBhcmFtOiBkYXRhVG9TZW5kLFxyXG4gICAgICAgICAgICB0YXJnZXQ6ICdfc2VsZidcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgZG93bmxvYWQuc2F2ZUFzUGRmID0gZnVuY3Rpb24oZmlsZSl7XHJcblxyXG4gICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG5cclxuICAgICAgICBpZiAobXlDb25maWcuYXBwbGljYXRpb25JZCAhPSAyKSB7XHJcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5zdWNjZXNzKCc8ZGl2IGNsYXNzPVwiYm9sZC1tc2cgdGV4dC1jZW50ZXJcIj4nICsgbGFuZy5nZXQoXCJkb3dubG9hZC1oYXMtYmVlbi1zdGFydGVkXCIpICsgJzwvZGl2PicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB2YXIgc2VsZWN0ZWRGaWxlcyA9IFt7XHJcbiAgICAgICAgICAgIGZpbGVOYW1lOiBmaWxlLmZpbGVOYW1lLFxyXG4gICAgICAgICAgICByZXZpc2lvbklkOiBmaWxlLnJldmlzaW9uSWQsXHJcbiAgICAgICAgICAgIGlzTG9jazogZmlsZS5pc0xvY2sgPyBcInRydWVcIiA6IFwiXCIsXHJcbiAgICAgICAgICAgIGRjSWQ6IGZpbGUuZGNJZCxcclxuICAgICAgICAgICAgcHJvamVjdElkOiBmaWxlLnByb2plY3RJZCxcclxuICAgICAgICAgICAgZm9sZGVySWQ6IGZpbGUuZm9sZGVySWQsXHJcbiAgICAgICAgICAgIGRvY0lkOiBmaWxlLmRvY3VtZW50SWRcclxuICAgICAgICB9XTtcclxuXHJcbiAgICAgICAgZG93bmxvYWQucmV0dXJuTm9uQWthbWFpVVJMKHtcclxuICAgICAgICAgICAgcHJvamVjdElkOiBmaWxlLnByb2plY3RJZCxcclxuICAgICAgICAgICAgcmV2aXNpb25JZHM6IHtcclxuICAgICAgICAgICAgICAgIHJldmlzaW9uczogc2VsZWN0ZWRGaWxlc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICB2YXIgdXJsID0gXCJcIjtcclxuXHJcbiAgICAgICAgICAgIC8vIENvbXB1dGUgYmFzZSB1cmxcclxuICAgICAgICAgICAgaWYgKGRhdGEuaXNMaW1pdEV4aXN0KSB7XHJcbiAgICAgICAgICAgICAgICB1cmwgPSBkYXRhLm5vbkNETkRvd25sb2FkVXJsO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdXJsID0gbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMO1xyXG4gICAgICAgICAgICAgICAgdXJsID0gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwobXlDb25maWcuTE9DQUxfRENfSUQsIHVybCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHZhciBkb3dubG9hZFByZWYgPSB7XHJcbiAgICAgICAgICAgICAgICBpc0luY2x1ZGVNYXJrdXA6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBpc1BhcmVudERvYzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBpc1hSRUY6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgaXNSZW5hbWVXaXRoRG9jUmVmOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGlzQXBwZW5lZFJldk5vOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGlzQXBwZW5kRG9jVGl0bGU6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgaXNBcHBlbmVkSXNzTm86IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZnJvbVNhdmVBc1BERjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHJldklkczogW2ZpbGUucmV2aXNpb25JZC5zcGxpdCgnJCQnKVswXV1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8qKiBhbHNvIHNhdmVBc1BERiBmcm9tIFVXViBwcm9qZWN0LiAqL1xyXG4gICAgICAgICAgICBpZihmaWxlLnByb2plY3RWaWV3ZXJJZCAmJiBmaWxlLnByb2plY3RWaWV3ZXJJZCA9PSA3KXtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkUHJlZltcInByb2plY3RWaWV3ZXJJZFwiXSA9IGZpbGUucHJvamVjdFZpZXdlcklkO1xyXG4gICAgICAgICAgICAgICAgaWYgKGZpbGUgJiYgZmlsZS5pc0F0dGFjaG1lbnRGb3JtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRQcmVmW1wiY29taW5nRnJvbVwiXSA9ICdhdHRhY2htZW50JztcclxuICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFByZWZbXCJtc2dJZFwiXSA9IG1zZ0lkO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFByZWZbXCJjb21pbmdGcm9tXCJdID0gJ3NhdmVBc1BERic7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICBcclxuICAgICAgICAgICAgdmFyIGRhdGFUb1NlbmQgPSB7XHJcbiAgICAgICAgICAgICAgICBleHRyYTogSlNPTi5zdHJpbmdpZnkoZG93bmxvYWRQcmVmKSxcclxuICAgICAgICAgICAgICAgIHVzZXJJRDogbXlDb25maWcuVVNQLnVzZXJJRCxcclxuICAgICAgICAgICAgICAgIHNhdmVBc1BERjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHByb2plY3RJRDogZmlsZS5wcm9qZWN0SWRcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGFwaS5zdWJtaXRGb3JtKHtcclxuICAgICAgICAgICAgICAgIHVybDogdXJsICsgYXBpQ29uZmlnLkRPV05MT0FEX0JBVENIX0RPQ1VNRU5UX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgICAgICBwYXJhbTogZGF0YVRvU2VuZCxcclxuICAgICAgICAgICAgICAgIHRhcmdldDogJ19zZWxmJ1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBkb3dubG9hZC56aXAgPSBmdW5jdGlvbihzZWxlY3RlZEl0ZW1zLCBkb3dubG9hZFByZWYsIGNhbGxiYWNrKSB7XHJcblxyXG4gICAgICAgIGRvd25sb2FkLnJldHVybk5vbkFrYW1haVVSTCh7XHJcbiAgICAgICAgICAgIHByb2plY3RJZDogc2VsZWN0ZWRJdGVtc1swXS5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgIHJldmlzaW9uSWRzOiB7XHJcbiAgICAgICAgICAgICAgICAncmV2aXNpb25zJzogc2VsZWN0ZWRJdGVtc1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICB2YXIgdXJsID0gXCJcIjtcclxuICAgICAgICAgICAgZG93bmxvYWRQcmVmID0gZG93bmxvYWRQcmVmIHx8IHt9O1xyXG4gICAgICAgICAgICBpZiAoZGF0YS5pc0xpbWl0RXhpc3QgfHwgZG93bmxvYWRQcmVmLmlzSW5jbHVkZU1hcmt1cCA9PT0gdHJ1ZSB8fCBkb3dubG9hZFByZWYuaXNJbmNsdWRlTWFya3VwID09PSBcInRydWVcIiB8fCBkb3dubG9hZFByZWYuaXNFbWJlZFFSQ29kZSA9PT0gdHJ1ZSB8fCBkb3dubG9hZFByZWYuaXNFbWJlZFFSQ29kZSA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICAgICAgICAgIHVybCA9IGRhdGEubm9uQ0RORG93bmxvYWRVcmw7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB1cmwgPSBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkw7XHJcbiAgICAgICAgICAgICAgICB1cmwgPSBtYW5hZ2VEYXRhQ2VudGVyLmdldFVybChteUNvbmZpZy5MT0NBTF9EQ19JRCwgdXJsKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdmFyIHBhcmFtc09iaiA9IHtcclxuICAgICAgICAgICAgICAgIGV4dHJhOiBKU09OLnN0cmluZ2lmeShkb3dubG9hZFByZWYpLFxyXG4gICAgICAgICAgICAgICAgcHJvamVjdElEOiBzZWxlY3RlZEl0ZW1zWzBdLnByb2plY3RJZFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdmFyIHhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgICAgIHVybDogdXJsICsgYXBpQ29uZmlnLkRPV05MT0FEX0JBVENIX0RPQ1VNRU5UX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgICAgICBkYXRhOiBwYXJhbXNPYmpcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB4aHIudGhlbihmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBkYXRhLnByb2plY3RJZCA9IHNlbGVjdGVkSXRlbXNbMF0ucHJvamVjdElkO1xyXG4gICAgICAgICAgICAgICAgaWYgKGRvd25sb2FkUHJlZiAmJiAoZG93bmxvYWRQcmVmLmlzSW5jbHVkZU1hcmt1cCB8fCBkb3dubG9hZFByZWYuaXNFbWJlZFFSQ29kZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICBOb3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICc8ZGl2IGNsYXNzPVwidGV4dC1sYXJnZVwiPicgKyBsYW5nLmdldChcInBsZWFzZS13YWl0LWZpbGVzLXByb2Nlc3NkLXdoaWxlXCIpICsgJzwvZGl2PicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGF5OiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEudXJsID0gdXJsICsgYXBpQ29uZmlnLlBST0dSRVNTX1pJUF9DUkVBVElPTl9DT05UUk9MTEVSO1xyXG4gICAgICAgICAgICAgICAgICAgIGRvd25sb2FkLmRvd25sb2FkSW5jbHVkZU1hcmt1cHMoZGF0YSwgdW5kZWZpbmVkLCBjYWxsYmFjaywgZG93bmxvYWRQcmVmLmlzRW1iZWRRUkNvZGUpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLnVybCA9IHVybCArIGFwaUNvbmZpZy5QUk9HUkVTU19aSVBfQ1JFQVRJT05fQ09OVFJPTExFUjtcclxuICAgICAgICAgICAgICAgICAgICBkb3dubG9hZC5jcmVhdGVaaXBGaWxlKGRhdGEsIGNhbGxiYWNrKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgICAgICAkd2luZG93LmFsZXJ0KGxhbmcuZ2V0KFwic29tZXRoaW5nLXdlbnQtd3JvbmdcIikpO1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgZG93bmxvYWQuZ2V0RXJyb3JNZXNzYWdlID0gZnVuY3Rpb24oZXJyb3JGaWxlc0xpc3QpIHtcclxuICAgICAgICB2YXIgZXJyb3JNZXNzYWdlID0gXCJcIjtcclxuICAgICAgICBzd2l0Y2ggKGVycm9yRmlsZXNMaXN0LmVycm9yQ29kZSkge1xyXG4gICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBsYW5nLmdldCgnc3lzdGVtLXRhc2stbm90LWNvbmZpZ3VyZWQnKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBsYW5nLmdldCgnZm9sZGVyLXNldHRpbmctZW5hYmxlcXJjb2RlLW5vdC1lbmFibGVkJyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gbGFuZy5nZXQoJ2ZpbGUtZm9ybWF0LW5vdC1zdXBwb3J0ZWQtcXJjb2RlJyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlID0gbGFuZy5nZXQoJ2VtYmVkZGluZy1xcmNvZGUtZmlsZS10cnktc3VwcG9ydCcpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UgPSBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZXJyb3JNZXNzYWdlO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZC5kb3dubG9hZEluY2x1ZGVNYXJrdXBzID0gZnVuY3Rpb24obWFya1VwRGF0YSwgZGF0YSwgY2FsbGJhY2ssIGlzRW1iZWRRUkNvZGUpIHtcclxuICAgICAgICB2YXIgbWFya3VwR2VuZXJhdGVkID0gXCJnZW5lcmF0ZWRcIjtcclxuICAgICAgICB2YXIgbWFya3VwUVJDb2RlID0gXCJmYWlsZWRcIjtcclxuICAgICAgICB2YXIgbWFya3VwSW5jbHVkZU1hcmt1cCA9IFwiZmFpbGVkXCI7XHJcbiAgICAgICAgdmFyIG1hcmt1cEludm9rZSA9IGRhdGEgPyBkYXRhLm1hcmt1cHNQcm9ncmVzcyA6IFwiXCI7XHJcbiAgICAgICAgdmFyIGVycm9yRmlsZXNMaXN0ID0gZGF0YSA/IGRhdGEuZXJyb3JGaWxlcyA6IFtdO1xyXG4gICAgICAgIHZhciBjX251bWJlciA9IGRhdGEgPyBkYXRhLmNfbnVtYmVyIDogMDtcclxuICAgICAgICBpZiAobWFya3VwSW52b2tlID09IG1hcmt1cEdlbmVyYXRlZCkge1xyXG4gICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICAgICAgaWYgKGlzRW1iZWRRUkNvZGUgJiYgZXJyb3JGaWxlc0xpc3QgJiYgZXJyb3JGaWxlc0xpc3QubGVuZ3RoICYmIGNfbnVtYmVyICE9IDEpIHtcclxuICAgICAgICAgICAgICAgIHZhciBjaGlsZENvbnRyb2xsZXIgPSBmdW5jdGlvbigkc2NvcGUsICR1aWJNb2RhbEluc3RhbmNlLCBlcnJvckZpbGVzTGlzdCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZXJyb3JGaWxlc0xpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JGaWxlc0xpc3RbaV0uZXJyb3JDb2RlTWVzc2FnZSA9IGRvd25sb2FkLmdldEVycm9yTWVzc2FnZShlcnJvckZpbGVzTGlzdFtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmVycm9yRmlsZSA9IGVycm9yRmlsZXNMaXN0O1xyXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5pc0NvbnRpbnVlRG93bmxvYWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuYWxsRmlsZXNGYWlsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuY29udGludWVEb3dubG9hZCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAkdWliTW9kYWxJbnN0YW5jZS5jbG9zZSh7IG15OiAnZGF0YScgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB4aHIgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5ET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9XSVRIX01BUktVUFNfQUNUSU9OX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvamVjdElEOiBtYXJrVXBEYXRhLmlzTXVsdGlEQ1VLUHJvaklkID8gbWFya1VwRGF0YS5zZWxlY3RNdWx0aURDVUtQcm9qSWQgOiBtYXJrVXBEYXRhLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJrVXBzUHJvZ3Jlc3NLZXk6IG1hcmtVcERhdGEucHVibGlzaE1hcmt1cHNQcm9ncmVzc0tleVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgeGhyLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5wcm9qZWN0SWQgPSBtYXJrVXBEYXRhLnByb2plY3RJZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEudXJsID0gbWFya1VwRGF0YS51cmw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZC5jcmVhdGVaaXBGaWxlKGRhdGEsIGNhbGxiYWNrKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5jYW5jZWwgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJHVpYk1vZGFsSW5zdGFuY2UuZGlzbWlzcygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICR1aWJNb2RhbC5vcGVuKHtcclxuICAgICAgICAgICAgICAgICAgICBhbmltYXRpb246IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdteU1vZGFsQ29udGVudC5odG1sJyxcclxuICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiBjaGlsZENvbnRyb2xsZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2Ryb3A6ICdzdGF0aWMnLFxyXG4gICAgICAgICAgICAgICAgICAgIGtleWJvYXJkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yRmlsZXNMaXN0OiBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvckZpbGVzTGlzdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHZhciBkYXRhSlNPTiA9IHtcclxuICAgICAgICAgICAgICAgICAgICBhY3Rpb25faWQ6IGFwaUNvbmZpZy5ET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9XSVRIX01BUktVUFNfQUNUSU9OLFxyXG4gICAgICAgICAgICAgICAgICAgIHByb2plY3RJRDogbWFya1VwRGF0YS5pc011bHRpRENVS1Byb2pJZCA/IG1hcmtVcERhdGEuc2VsZWN0TXVsdGlEQ1VLUHJvaklkIDogbWFya1VwRGF0YS5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbWFya1Vwc1Byb2dyZXNzS2V5OiBtYXJrVXBEYXRhLnB1Ymxpc2hNYXJrdXBzUHJvZ3Jlc3NLZXlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmKGVycm9yRmlsZXNMaXN0ICYmIGVycm9yRmlsZXNMaXN0Lmxlbmd0aCl7ICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICB2YXIgY2hpbGRDb250cm9sbGVyID0gZnVuY3Rpb24oJHNjb3BlLCAkdWliTW9kYWxJbnN0YW5jZSwgZXJyb3JGaWxlc0xpc3QpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlcnJvckZpbGVzTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRvY3VtZW50VHlwZUlkID0gZXJyb3JGaWxlc0xpc3RbaV0uZG9jdW1lbnRUeXBlSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdHlwZSA9IGRvY3VtZW50VHlwZUlkID09IDEyID8gbGFuZy5nZXQoJ3R5cGUtbWFya3VwJykgOiBsYW5nLmdldCgndHlwZS1wYXJlbnQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yRmlsZXNMaXN0W2ldLmRvY1R5cGUgPSB0eXBlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmVycm9yRmlsZSA9IGVycm9yRmlsZXNMaXN0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuaXNDb250aW51ZURvd25sb2FkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS5hbGxGaWxlc0ZhaWwgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuY29udGludWVEb3dubG9hZCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJHVpYk1vZGFsSW5zdGFuY2UuY2xvc2UoeyBteTogJ2RhdGEnIH0pOyAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjX251bWJlciA9PSAxICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwaS5zdWJtaXRGb3JtKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuRE9XTkxPQURfQkFUQ0hfRE9DVU1FTlRfV0lUSF9NQVJLVVBTX0FDVElPTl9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtOiBkYXRhSlNPTixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiAnX3NlbGYnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuRE9XTkxPQURfQkFUQ0hfRE9DVU1FTlRfV0lUSF9NQVJLVVBTX0FDVElPTl9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IGRhdGFKU09OXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeGhyLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLnByb2plY3RJZCA9IG1hcmtVcERhdGEucHJvamVjdElkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLnVybCA9IG1hcmtVcERhdGEudXJsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZC5jcmVhdGVaaXBGaWxlKGRhdGEsIGNhbGxiYWNrKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuY2FuY2VsID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkdWliTW9kYWxJbnN0YW5jZS5kaXNtaXNzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICR1aWJNb2RhbC5vcGVuKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2luY2x1ZGVNYXJrdXBFcnJvci5odG1sJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogY2hpbGRDb250cm9sbGVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZHJvcDogJ3N0YXRpYycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleWJvYXJkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JGaWxlc0xpc3Q6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvckZpbGVzTGlzdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY19udW1iZXIgPT0gMSApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXBpLnN1Ym1pdEZvcm0oe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuRE9XTkxPQURfQkFUQ0hfRE9DVU1FTlRfV0lUSF9NQVJLVVBTX0FDVElPTl9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX2NkblVybDogbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW06IGRhdGFKU09OLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiAnX3NlbGYnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB4aHIgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5ET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9XSVRIX01BUktVUFNfQUNUSU9OX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiBkYXRhSlNPTlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgeGhyLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5wcm9qZWN0SWQgPSBtYXJrVXBEYXRhLnByb2plY3RJZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEudXJsID0gbWFya1VwRGF0YS51cmw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZC5jcmVhdGVaaXBGaWxlKGRhdGEsIGNhbGxiYWNrKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9IGVsc2UgaWYgKGlzRW1iZWRRUkNvZGUgJiYgbWFya3VwSW52b2tlID09IG1hcmt1cFFSQ29kZSkge1xyXG4gICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICAgICAgdmFyIGNoaWxkRmFpbENvbnRyb2xsZXIgPSBmdW5jdGlvbigkc2NvcGUsICR1aWJNb2RhbEluc3RhbmNlLCBlcnJvckZpbGVzTGlzdCkge1xyXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlcnJvckZpbGVzTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yRmlsZXNMaXN0W2ldLmVycm9yQ29kZU1lc3NhZ2UgPSBkb3dubG9hZC5nZXRFcnJvck1lc3NhZ2UoZXJyb3JGaWxlc0xpc3RbaV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgJHNjb3BlLmVycm9yRmlsZSA9IGVycm9yRmlsZXNMaXN0O1xyXG4gICAgICAgICAgICAgICAgJHNjb3BlLmlzQ29udGludWVEb3dubG9hZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAkc2NvcGUuYWxsRmlsZXNGYWlsID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAkc2NvcGUub2sgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAkdWliTW9kYWxJbnN0YW5jZS5kaXNtaXNzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgJHVpYk1vZGFsLm9wZW4oe1xyXG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdteU1vZGFsQ29udGVudC5odG1sJyxcclxuICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6IGNoaWxkRmFpbENvbnRyb2xsZXIsXHJcbiAgICAgICAgICAgICAgICBiYWNrZHJvcDogJ3N0YXRpYycsXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JGaWxlc0xpc3Q6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3JGaWxlc0xpc3Q7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgaWYobWFya3VwSW52b2tlICYmIG1hcmt1cEludm9rZS50b0xvd2VyQ2FzZSgpID09IG1hcmt1cEluY2x1ZGVNYXJrdXApe1xyXG4gICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5jbGVhckFsbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBjaGlsZEZhaWxDb250cm9sbGVyID0gZnVuY3Rpb24oJHNjb3BlLCAkdWliTW9kYWxJbnN0YW5jZSkgeyAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuaXNDb250aW51ZURvd25sb2FkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmFsbEZpbGVzRmFpbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUub2sgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICR1aWJNb2RhbEluc3RhbmNlLmRpc21pc3MoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9ICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAkdWliTW9kYWwub3Blbih7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGlvbjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdpbmNsdWRlTWFya3VwRXJyb3IuaHRtbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6IGNoaWxkRmFpbENvbnRyb2xsZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tkcm9wOiAnc3RhdGljJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5QUk9HUkVTU19HRU5FUkFURV9NQVJLVVBfQVNfUERGX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9jZG5Vcmw6IG15Q29uZmlnLmRvd25sb2FkU2VydmljZVVSTCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9qZWN0SUQ6IG1hcmtVcERhdGEuaXNNdWx0aURDVUtQcm9qSWQgPyBtYXJrVXBEYXRhLnNlbGVjdE11bHRpRENVS1Byb2pJZCA6IG1hcmtVcERhdGEucHJvamVjdElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFya1Vwc1Byb2dyZXNzS2V5OiBtYXJrVXBEYXRhLnB1Ymxpc2hNYXJrdXBzUHJvZ3Jlc3NLZXlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHhoci50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZC5kb3dubG9hZEluY2x1ZGVNYXJrdXBzKG1hcmtVcERhdGEsIHsgXCJtYXJrdXBzUHJvZ3Jlc3NcIjogZGF0YS5tYXJrdXBzUHJvZ3Jlc3MudG9Mb3dlckNhc2UoKSwgXCJlcnJvckZpbGVzXCI6IGRhdGEuZXJyb3JGaWxlcywgXCJjX251bWJlclwiOiBkYXRhLmNfbnVtYmVyIH0sIGNhbGxiYWNrLCBpc0VtYmVkUVJDb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSwzMDAwKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0sIDUwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIHZhciB6aXBQcm9ncmVzcyA9IHt9O1xyXG4gICAgZG93bmxvYWQuY3JlYXRlWmlwRmlsZSA9IGZ1bmN0aW9uKHppcERhdGEsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgaWYgKCF6aXBQcm9ncmVzc1t6aXBEYXRhLmZpbGVOYW1lXSkge1xyXG4gICAgICAgICAgICB6aXBQcm9ncmVzc1t6aXBEYXRhLmZpbGVOYW1lXSA9IHt9O1xyXG4gICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICAgICAgLy8gcHJvZ3JlZXNzIGJhciBtYWRlIGhlcmUgd2l0aCB0aGUgc2FtZSBkaXYgdXNlZCB3aGlsZSB2aWV3aW5nIGZpbGUgYW5kIGZvcm0uXHJcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiAnPGRpdiBpZD1cIm5vdGlmaWNhdGlvbi1wcm9ncmVzc1wiIGNsYXNzPVwicGFnZS1wcm9ncmVzc1wiIHN0eWxlPVwicG9zaXRpb246cmVsYXRpdmVcIj48ZGl2IGNsYXNzPVwicHJvZ3Jlc3NcIj48L2Rpdj48L2Rpdj4nLFxyXG4gICAgICAgICAgICAgICAgZGVsYXk6IGZhbHNlXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHBhcmFtT2JqID0ge1xyXG4gICAgICAgICAgICBhY3Rpb25faWQ6IGFwaUNvbmZpZy5QUk9HUkVTU19aSVBfQ1JFQVRJT04sXHJcbiAgICAgICAgICAgIHppcEZpbGU6IHppcERhdGEuZmlsZU5hbWVcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICF6aXBEYXRhLmlzTXVsdGlEQ1VLUHJvaklkICYmIChwYXJhbU9iai5wcm9qZWN0SUQgPSB6aXBEYXRhLnByb2plY3RJZCk7XHJcblxyXG4gICAgICAgIHZhciBhcGlPcHRpb25zID0ge1xyXG4gICAgICAgICAgICB1cmw6IHppcERhdGEudXJsIHx8IGFwaUNvbmZpZy5QUk9HUkVTU19aSVBfQ1JFQVRJT05fQ09OVFJPTExFUixcclxuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcclxuICAgICAgICAgICAgX2NkblVybDogbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHBhcmFtT2JqXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZih6aXBEYXRhLnVybCAmJiB6aXBEYXRhLnVybC5pbmRleE9mKGFwaUNvbmZpZy5QVUJMSUNfRE9XTkxPQURfQ09OVFJPTExFUikgPT09IDApIHtcclxuICAgICAgICAgICAgYXBpT3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgICAgIHVybDogemlwRGF0YS51cmwsXHJcbiAgICAgICAgICAgICAgICBkYXRhOiBwYXJhbU9ialxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgeGhyID0gYXBpLmFqYXgoYXBpT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIHppcFByb2dyZXNzW3ppcERhdGEuZmlsZU5hbWVdLnhociA9IHhocjtcclxuICAgICAgICBpZiAoemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV0uY19udW1iZXIgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICB6aXBQcm9ncmVzc1t6aXBEYXRhLmZpbGVOYW1lXS5wcm9ncmVzcyA9IDA7XHJcbiAgICAgICAgICAgIHppcFByb2dyZXNzW3ppcERhdGEuZmlsZU5hbWVdLmNfbnVtYmVyID0gMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHhoci50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgaWYgKGRhdGEuY19udW1iZXIgPT0gJy0xJykge1xyXG4gICAgICAgICAgICAgICAgdmFyIHBhcmFtID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNfbnVtYmVyOiBkYXRhLmNfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgIHByb2plY3RfaWQ6IHppcERhdGEuaXNNdWx0aURDVUtQcm9qSWQgPyB6aXBEYXRhLnNlbGVjdE11bHRpRENVS1Byb2pJZCA6IHppcERhdGEucHJvamVjdElkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdW50OiB6aXBEYXRhLmNvdW50LFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc3RQYXRoOiB6aXBEYXRhLmRlc3RQYXRoLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiB6aXBEYXRhLmZpbGVOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGlzRXh0cmFjdDogZGF0YS5pc0V4dHJhY3QsXHJcbiAgICAgICAgICAgICAgICAgICAgaXNGb3JEaXJlY3RMaW5rOiB6aXBEYXRhLmlzRnJvbURpcmVjdExpbmssXHJcbiAgICAgICAgICAgICAgICAgICAgaXNGcm9tTXVsdGlEQ0JhdGNoOiB6aXBEYXRhLmlzRnJvbU11bHRpRENCYXRjaCB8fCBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAobXlDb25maWcuYXBwbGljYXRpb25JZCA9PSAyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW0uYWN0aW9uX2lkID0gYXBpQ29uZmlnLkRPV05MT0FEX1RFTVBfWklQX0ZJTEU7XHJcbiAgICAgICAgICAgICAgICAgICAgcXRPYmplY3Quc2FtZURjTXVsdGlGaWxlc0Rvd25sb2FkKEpTT04uc3RyaW5naWZ5KHBhcmFtKSwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV07XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV07XHJcbiAgICAgICAgICAgICAgICBhcGkuc3VibWl0Rm9ybSh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXJsOiB6aXBEYXRhLmFjdGlvblVybCB8fCBhcGlDb25maWcuRE9XTkxPQURfVEVNUF9aSVBfRklMRV9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtOiBwYXJhbSxcclxuICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICAgICAgICAgICAgICAgIF9jZG5Vcmw6IG15Q29uZmlnLmRvd25sb2FkU2VydmljZVVSTCxcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6ICdfc2VsZidcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV0uY19udW1iZXIgPSBkYXRhLmNfbnVtYmVyO1xyXG4gICAgICAgICAgICAgICAgaWYgKGRhdGEuY19udW1iZXIgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV0ucHJvZ3Jlc3MgPSBkYXRhLmNfbnVtYmVyO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV0udGltZW91dCA9ICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGRvd25sb2FkLmNyZWF0ZVppcEZpbGUoemlwRGF0YSwgY2FsbGJhY2spO1xyXG4gICAgICAgICAgICAgICAgfSwgMjAwMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICAgICAgTm90aWZpY2F0aW9uLmNsZWFyQWxsKCk7XHJcbiAgICAgICAgICAgIGlmICh4aHIuc3RhdHVzICE9IC0xKSB7XHJcbiAgICAgICAgICAgICAgICB6aXBQcm9ncmVzc1t6aXBEYXRhLmZpbGVOYW1lXS5zdGF0dXMgPSBsYW5nLmdldChcImZhaWxlZFwiKTtcclxuICAgICAgICAgICAgICAgICR3aW5kb3cuYWxlcnQobGFuZy5nZXQoXCJkb3dubG9hZC1mYWlsZWRcIikpO1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHppcFByb2dyZXNzW3ppcERhdGEuZmlsZU5hbWVdLnhociA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgemlwUHJvZ3Jlc3NbemlwRGF0YS5maWxlTmFtZV0uc3RhdHVzID0gbGFuZy5nZXQoXCJhYm9ydGVkXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGRvd25sb2FkLmNhbmNlbFppcFByb2dyZXNzID0gZnVuY3Rpb24oZmlsZU5hbWUpIHtcclxuICAgICAgICAvLyBhYm9ydCByZXF1ZXN0XHJcbiAgICAgICAgdmFyIHhociA9IHppcFByb2dyZXNzW2ZpbGVOYW1lXS54aHI7XHJcbiAgICAgICAgeGhyICYmIHhoci5hYm9ydCgpO1xyXG5cclxuICAgICAgICAvLyBjYW5jZWwgdGltZW91dFxyXG4gICAgICAgICR0aW1lb3V0LmNhbmNlbCh6aXBQcm9ncmVzc1tmaWxlTmFtZV0udGltZW91dCk7XHJcbiAgICB9O1xyXG59XSlcclxuXHJcblxyXG4vKipcclxuICogYXBpIHNlcnZpY2UuXHJcbiAqIFRoaXMgbW9kdWxlIHdpbGwgcHJvdmlkZSBYTUxIdHRwUmVxdWVzdCBzZXJ2aWNlLlxyXG4gKiBAbW9kdWxlIGFwaVxyXG4gKi9cclxuLnNlcnZpY2UoJ2FwaScsIFsnJGh0dHAnLCAnJHdpbmRvdycsICckcScsICckdGltZW91dCcsICdsYW5nJywgJ215Q29uZmlnJywgJ2FwaUNvbmZpZycsICdOb3RpZmljYXRpb24nLCAnbWFuYWdlRGF0YUNlbnRlcicsICckdWliTW9kYWwnLCBmdW5jdGlvbigkaHR0cCwgJHdpbmRvdywgJHEsICR0aW1lb3V0LCBsYW5nLCBteUNvbmZpZywgYXBpQ29uZmlnLCBOb3RpZmljYXRpb24sIG1hbmFnZURhdGFDZW50ZXIsICR1aWJNb2RhbCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBGb3IgYWxsIHRoZSBodHRwIGNhbGxzLlxyXG4gICAgICogQGFsaWFzIG1vZHVsZTpBcGkvQWpheFxyXG4gICAgICovXHJcblxyXG4gICAgdmFyIGFwaSA9IHRoaXM7XHJcblxyXG4gICAgYXBpLmxpbmtpZnkgPSBmdW5jdGlvbihtc2cpIHtcclxuICAgICAgICBpZiAoIW1zZykgcmV0dXJuIFwiXCI7XHJcblxyXG4gICAgICAgIHZhciByZXBsYWNlZFRleHQgPSBtc2csXHJcbiAgICAgICAgICByZXBsYWNlUGF0dGVybjEsXHJcbiAgICAgICAgICByZXBsYWNlUGF0dGVybjIsXHJcbiAgICAgICAgICByZXBsYWNlUGF0dGVybjM7XHJcblxyXG4gICAgICAgIC8vQ2hhbmdlIGVtYWlsIGFkZHJlc3NlcyB0byBtYWlsdG86OiBsaW5rcy5cclxuICAgICAgICByZXBsYWNlUGF0dGVybjMgPSAvKChbYS16QS1aMC05XFwtXFxfXFwuXSkrQFthLXpBLVpcXF9dKz8oXFwuW2EtekEtWl17Miw2fSkrKS9naW07XHJcbiAgICAgICAgcmVwbGFjZWRUZXh0ID0gcmVwbGFjZWRUZXh0LnJlcGxhY2UoXHJcbiAgICAgICAgICByZXBsYWNlUGF0dGVybjMsXHJcbiAgICAgICAgICAnPGEgaHJlZj1cIm1haWx0bzokMVwiPiQxPC9hPidcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICAvL1VSTHMgc3RhcnRpbmcgd2l0aCBodHRwOi8vLCBodHRwczovLywgb3IgZnRwOi8vXHJcbiAgICAgICAgcmVwbGFjZVBhdHRlcm4xID0gLyhcXGIoaHR0cHM/fGZ0cCk6XFwvXFwvWy1BLVowLTkrJkAjJFxcLyU/PX5ffCE6LC47XSpbLUEtWjAtOSsmQCMkXFwvJT1+X3wkXSkvZ2ltO1xyXG4gICAgICAgIHJlcGxhY2VkVGV4dCA9IHJlcGxhY2VkVGV4dC5yZXBsYWNlKFxyXG4gICAgICAgICAgcmVwbGFjZVBhdHRlcm4xLFxyXG4gICAgICAgICAgJzxhIGhyZWY9XCIkMVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIj4kMTwvYT4nXHJcbiAgICAgICAgKTtcclxuICAgIFxyXG4gICAgICAgIC8vVVJMcyBzdGFydGluZyB3aXRoIFwid3d3LlwiICh3aXRob3V0IC8vIGJlZm9yZSBpdCwgb3IgaXQnZCByZS1saW5rIHRoZSBvbmVzIGRvbmUgYWJvdmUpLlxyXG4gICAgICAgIHJlcGxhY2VQYXR0ZXJuMiA9IC8oXnxbXlxcL10pKHd3d1xcLltcXFNdKyhcXGJ8JCkpL2dpbTtcclxuICAgICAgICByZXBsYWNlZFRleHQgPSByZXBsYWNlZFRleHQucmVwbGFjZShcclxuICAgICAgICAgIHJlcGxhY2VQYXR0ZXJuMixcclxuICAgICAgICAgICckMTxhIGhyZWY9XCJodHRwOi8vJDJcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCI+JDI8L2E+J1xyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXBsYWNlZFRleHQ7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5pc0lFID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgcmV0dXJuICgobmF2aWdhdG9yLnVzZXJBZ2VudC5pbmRleE9mKFwiLk5FVCBDTFJcIikgPiAtMSkgfHwgKG5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZihcIk1TSUVcIikgPiAtMSkgfHxcclxuICAgICAgICAgICAgISFuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9UcmlkZW50XFwvLykgfHwgISFuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9FZGdlXFwvLykpO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuaXNJRTkgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICByZXR1cm4gKG5hdmlnYXRvci51c2VyQWdlbnQuaW5kZXhPZignTVNJRSA5JykgPiAtMSB8fCAhJHdpbmRvdy5Gb3JtRGF0YSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5lc2NhcGVBbXAgPSBmdW5jdGlvbihzdHIpIHtcclxuICAgICAgICBpZiAoIXN0ciB8fCB0eXBlb2Ygc3RyICE9PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICByZXR1cm4gXCJcIjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHN0ci5yZXBsYWNlKC8mL2csICcmYW1wOycpO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuaXNNb2JpbGUgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgY2hlY2sgPSBmYWxzZTtcclxuICAgICAgICAoZnVuY3Rpb24oYSkge1xyXG4gICAgICAgICAgICBpZiAoL0FuZHJvaWR8d2ViT1N8aVBob25lfGlQYWR8aVBvZHxCbGFja0JlcnJ5fElFTW9iaWxlfE9wZXJhIE1pbmkoYW5kcm9pZHxiYlxcZCt8bWVlZ28pLittb2JpbGV8YXZhbnRnb3xiYWRhXFwvfGJsYWNrYmVycnl8YmxhemVyfGNvbXBhbHxlbGFpbmV8ZmVubmVjfGhpcHRvcHxpZW1vYmlsZXxpcChob25lfG9kfGFkKXxpcmlzfGtpbmRsZXxsZ2UgfG1hZW1vfG1pZHB8bW1wfG1vYmlsZS4rZmlyZWZveHxuZXRmcm9udHxvcGVyYSBtKG9ifGluKWl8cGFsbSggb3MpP3xwaG9uZXxwKGl4aXxyZSlcXC98cGx1Y2tlcnxwb2NrZXR8cHNwfHNlcmllcyg0fDYpMHxzeW1iaWFufHRyZW98dXBcXC4oYnJvd3NlcnxsaW5rKXx2b2RhZm9uZXx3YXB8d2luZG93cyBjZXx4ZGF8eGlpbm8vaS50ZXN0KGEpIHx8IC8xMjA3fDYzMTB8NjU5MHwzZ3NvfDR0aHB8NTBbMS02XWl8Nzcwc3w4MDJzfGEgd2F8YWJhY3xhYyhlcnxvb3xzXFwtKXxhaShrb3xybil8YWwoYXZ8Y2F8Y28pfGFtb2l8YW4oZXh8bnl8eXcpfGFwdHV8YXIoY2h8Z28pfGFzKHRlfHVzKXxhdHR3fGF1KGRpfFxcLW18ciB8cyApfGF2YW58YmUoY2t8bGx8bnEpfGJpKGxifHJkKXxibChhY3xheil8YnIoZXx2KXd8YnVtYnxid1xcLShufHUpfGM1NVxcL3xjYXBpfGNjd2F8Y2RtXFwtfGNlbGx8Y2h0bXxjbGRjfGNtZFxcLXxjbyhtcHxuZCl8Y3Jhd3xkYShpdHxsbHxuZyl8ZGJ0ZXxkY1xcLXN8ZGV2aXxkaWNhfGRtb2J8ZG8oY3xwKW98ZHMoMTJ8XFwtZCl8ZWwoNDl8YWkpfGVtKGwyfHVsKXxlcihpY3xrMCl8ZXNsOHxleihbNC03XTB8b3N8d2F8emUpfGZldGN8Zmx5KFxcLXxfKXxnMSB1fGc1NjB8Z2VuZXxnZlxcLTV8Z1xcLW1vfGdvKFxcLnd8b2QpfGdyKGFkfHVuKXxoYWllfGhjaXR8aGRcXC0obXxwfHQpfGhlaVxcLXxoaShwdHx0YSl8aHAoIGl8aXApfGhzXFwtY3xodChjKFxcLXwgfF98YXxnfHB8c3x0KXx0cCl8aHUoYXd8dGMpfGlcXC0oMjB8Z298bWEpfGkyMzB8aWFjKCB8XFwtfFxcLyl8aWJyb3xpZGVhfGlnMDF8aWtvbXxpbTFrfGlubm98aXBhcXxpcmlzfGphKHR8dilhfGpicm98amVtdXxqaWdzfGtkZGl8a2VqaXxrZ3QoIHxcXC8pfGtsb258a3B0IHxrd2NcXC18a3lvKGN8ayl8bGUobm98eGkpfGxnKCBnfFxcLyhrfGx8dSl8NTB8NTR8XFwtW2Etd10pfGxpYnd8bHlueHxtMVxcLXd8bTNnYXxtNTBcXC98bWEodGV8dWl8eG8pfG1jKDAxfDIxfGNhKXxtXFwtY3J8bWUocmN8cmkpfG1pKG84fG9hfHRzKXxtbWVmfG1vKDAxfDAyfGJpfGRlfGRvfHQoXFwtfCB8b3x2KXx6eil8bXQoNTB8cDF8diApfG13YnB8bXl3YXxuMTBbMC0yXXxuMjBbMi0zXXxuMzAoMHwyKXxuNTAoMHwyfDUpfG43KDAoMHwxKXwxMCl8bmUoKGN8bSlcXC18b258dGZ8d2Z8d2d8d3QpfG5vayg2fGkpfG56cGh8bzJpbXxvcCh0aXx3dil8b3Jhbnxvd2cxfHA4MDB8cGFuKGF8ZHx0KXxwZHhnfHBnKDEzfFxcLShbMS04XXxjKSl8cGhpbHxwaXJlfHBsKGF5fHVjKXxwblxcLTJ8cG8oY2t8cnR8c2UpfHByb3h8cHNpb3xwdFxcLWd8cWFcXC1hfHFjKDA3fDEyfDIxfDMyfDYwfFxcLVsyLTddfGlcXC0pfHF0ZWt8cjM4MHxyNjAwfHJha3N8cmltOXxybyh2ZXx6byl8czU1XFwvfHNhKGdlfG1hfG1tfG1zfG55fHZhKXxzYygwMXxoXFwtfG9vfHBcXC0pfHNka1xcL3xzZShjKFxcLXwwfDEpfDQ3fG1jfG5kfHJpKXxzZ2hcXC18c2hhcnxzaWUoXFwtfG0pfHNrXFwtMHxzbCg0NXxpZCl8c20oYWx8YXJ8YjN8aXR8dDUpfHNvKGZ0fG55KXxzcCgwMXxoXFwtfHZcXC18diApfHN5KDAxfG1iKXx0MigxOHw1MCl8dDYoMDB8MTB8MTgpfHRhKGd0fGxrKXx0Y2xcXC18dGRnXFwtfHRlbChpfG0pfHRpbVxcLXx0XFwtbW98dG8ocGx8c2gpfHRzKDcwfG1cXC18bTN8bTUpfHR4XFwtOXx1cChcXC5ifGcxfHNpKXx1dHN0fHY0MDB8djc1MHx2ZXJpfHZpKHJnfHRlKXx2ayg0MHw1WzAtM118XFwtdil8dm00MHx2b2RhfHZ1bGN8dngoNTJ8NTN8NjB8NjF8NzB8ODB8ODF8ODN8ODV8OTgpfHczYyhcXC18ICl8d2ViY3x3aGl0fHdpKGcgfG5jfG53KXx3bWxifHdvbnV8eDcwMHx5YXNcXC18eW91cnx6ZXRvfHp0ZVxcLS9pLnRlc3QoYS5zdWJzdHIoMCwgNCkpKVxyXG4gICAgICAgICAgICAgICAgY2hlY2sgPSB0cnVlO1xyXG4gICAgICAgIH0pKG5hdmlnYXRvci51c2VyQWdlbnQgfHwgbmF2aWdhdG9yLnZlbmRvciB8fCB3aW5kb3cub3BlcmEpO1xyXG4gICAgICAgIGlmIChteUNvbmZpZy5hcHBsaWNhdGlvbklkID09IDMgJiYgbmF2aWdhdG9yLnBsYXRmb3JtID09ICdNYWNJbnRlbCcpIHtcclxuICAgICAgICAgICAgY2hlY2sgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gY2hlY2s7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5pc05hdmlnYXRvciA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiAobXlDb25maWcuYXBwbGljYXRpb25JZCA9PSAyKTtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLm9wZW5IZWxwUGFnZSA9IGZ1bmN0aW9uKG9wdCkge1xyXG4gICAgICAgIHZhciBpc0N1c3RvbVRleHRBcHBsaWVkID0gd2luZG93WydJTklUX0pTUF9HTE9CQUwnXVsnaXNDdXN0b21UZXh0QXBwbGllZCddXHJcbiAgICAgICAgdmFyIGVkaXRpb25JZCA9IHdpbmRvd1snSU5JVF9KU1BfR0xPQkFMJ11bJ2VkaXRpb25JZCddXHJcblxyXG4gICAgICAgIHZhciBzdHJVcmwgPSAob3B0LnJvb3RQYXRoIHx8IFwiXCIpICsgKG9wdC5jb250ZW50Zm9sZGVyIHx8IGFwaUNvbmZpZy5IRUxQX0ZJTEVfQ09OVEVOVCkgKyBteUNvbmZpZy51c2VyTGFuZ3VhZ2UgKyAoaXNDdXN0b21UZXh0QXBwbGllZCA/IFwiX1wiICsgZWRpdGlvbklkIDogXCJcIikgKyBcIi9cIiArIG9wdC5uYW1lICsgXCIuaHRtXCI7XHJcbiAgICAgICAgdmFyICRoZWxwQ29udGVudCA9ICQoJyNoZWxwLWNvbnRlbnQnKTtcclxuICAgICAgICAkaGVscENvbnRlbnQubG9hZChzdHJVcmwsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAkaGVscENvbnRlbnQucmVtb3ZlQ2xhc3MoXCJjbG9zZVwiKS5hZGRDbGFzcyhcIm9wZW5cIik7XHJcbiAgICAgICAgICAgICRoZWxwQ29udGVudC5maW5kKCcuZWxlYXJuaW5nLXVybCcpLmF0dHIoJ2hyZWYnLCBhcGlDb25maWcuVklFV19FTEVBUk5JTkcpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuc2VuZEV2ZW50VG9JcGFkID0gZnVuY3Rpb24oc3RyRXZlbnQpIHtcclxuICAgICAgICB2YXIgaWZyYW1lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIklGUkFNRVwiKTtcclxuICAgICAgICBpZnJhbWUuc2V0QXR0cmlidXRlKFwic3JjXCIsIFwianMtZnJhbWU6XCIgKyBzdHJFdmVudCk7XHJcbiAgICAgICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKGlmcmFtZSk7XHJcbiAgICAgICAgaWZyYW1lLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoaWZyYW1lKTtcclxuICAgICAgICBpZnJhbWUgPSBudWxsO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuc2V0U2Nyb2xsVG9wUG9zID0gZnVuY3Rpb24oZWxlbSwgcG9zVmFsKSB7XHJcbiAgICAgICAgZWxlbS5zY3JvbGxUb3AgPSBwb3NWYWw7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zZW5kTWFpbCA9IGZ1bmN0aW9uKGNvbnRlbnQpIHtcclxuICAgICAgICBpZiAoYXBpLmlzSUUoKSkge1xyXG4gICAgICAgICAgICB2YXIgaWZyYW1lID0gYW5ndWxhci5lbGVtZW50KCc8aWZyYW1lIGlkPVwiaWZyYW1lVGVtcE1haWxUb1wiIHNyYz1cIicgKyBjb250ZW50ICsgJ1wiIHdpZHRoPVwiMFwiIGhlaWdodD1cIjBcIiA+Jyk7XHJcbiAgICAgICAgICAgIGFuZ3VsYXIuZWxlbWVudChcImJvZHlcIikuYXBwZW5kKGlmcmFtZSk7XHJcbiAgICAgICAgICAgIGlmcmFtZS5yZW1vdmUoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAkd2luZG93LmxvY2F0aW9uLmhyZWYgPSBjb250ZW50O1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgYXBpLmdldFVybEJ5RGNJZCA9IGZ1bmN0aW9uKGRjSWQpIHtcclxuICAgICAgICByZXR1cm4gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwoZGNJZCB8fCBhcGlDb25maWcuTE9DQUxfRENfSUQpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBTdG9yZSBhY3Rpb24gaWQgd2lzZSByZXNvbHZlIG1ldGhvZC5cclxuICAgIHZhciBvZmZsaW5lQWN0aW9uV2lzZVJlc29sdmVMaXN0ID0gW107XHJcblxyXG4gICAgYXBpLmFqYXggPSBmdW5jdGlvbihvYmopIHtcclxuXHJcbiAgICAgICAgLy8gVXNlIGluIG9mZmxpbmUgSHRtbDUgZm9ybS5cclxuICAgICAgICBpZiAobXlDb25maWcuaXNPZmZsaW5lTW9kZSkge1xyXG4gICAgICAgICAgICAvLyB1c2UgIGpzLWZyYW1lIGluIHRoZSBvZmZsaW5lIGh0bWw1Rm9ybS5cclxuICAgICAgICAgICAgYXBpLnNlbmRFdmVudFRvSXBhZChhbmd1bGFyLnRvSnNvbihvYmopKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBhY3Rpb25JRCA9IG9iai5kYXRhLmFjdGlvbl9pZDtcclxuXHJcbiAgICAgICAgICAgIC8vIFVuaXF1ZSBhY3Rpb24gaWQgcGFzcy5cclxuICAgICAgICAgICAgLy9TYW1lIGFjdGlvbmlkKDE3MjIpIHBhc3MgaW4gZmlsZXMsZGlzY3Vzc2lvbnMgYW5kIGFwcHMgY29sdW1uIGxpc3Rpbmc7XHJcbiAgICAgICAgICAgIGlmIChhY3Rpb25JRCA9PSBhcGlDb25maWcuR0VUX1VTRVJfU0VMRUNURURfQ09MVU1OUykge1xyXG4gICAgICAgICAgICAgICAgLy9QYXNzIGlkIHdpdGggdHlwZVxyXG4gICAgICAgICAgICAgICAgYWN0aW9uSUQgPSBhY3Rpb25JRCArIFwiX1wiICsgb2JqLmRhdGEudHlwZTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChhY3Rpb25JRCA9PSBhcGlDb25maWcuR0VUX0FUVEFDSE1FTlRfQU5EX0FTU09DSUFUSU9OUykge1xyXG4gICAgICAgICAgICAgICAgLy9QYXNzIGFjdGlvbklEIHdpdGggcmVxdWVzdGVkRW50aXR5VHlwZShWaWV3cy9MaXN0cy9BbGwpXHJcbiAgICAgICAgICAgICAgICBhY3Rpb25JRCA9IGFjdGlvbklEICsgXCJfXCIgKyBvYmouZGF0YS5yZXF1ZXN0ZWRFbnRpdHlUeXBlO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYoYWN0aW9uSUQgPT0gYXBpQ29uZmlnLkdFVF9VU0VSX0FQUExJQ0FUSU9OX1BSSVZJTEVHRVMpe1xyXG4gICAgICAgICAgICAgICAgb2JqLmRhdGEudHlwZSAmJiAoYWN0aW9uSUQgPSBhY3Rpb25JRCArIFwiX1wiICsgIG9iai5kYXRhLnR5cGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBTdG9yZSBhY3Rpb24gaWQgd2lzZSByZXNvbHZlIG1ldGhvZC5cclxuICAgICAgICAgICAgICAgIG9mZmxpbmVBY3Rpb25XaXNlUmVzb2x2ZUxpc3RbYWN0aW9uSURdID0gcmVzb2x2ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL0ludm9rZSBvbiBNb2JpbGUgc2lkZSBjYWxsYmFjayBtZXRob2QuXHJcbiAgICAgICAgICAgICAgICB3aW5kb3cub2ZmbGluZU1vZGVDYWxsYmFjayA9IGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL1NldCByZXNwb25zZSBkYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc0RhdGEgPSBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb25JZCA9IGRhdGEuYWN0aW9uSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFjdGlvbklkcyA9IFthcGlDb25maWcuSU5JVElBVEVfQ1JFQVRFX09SSV9NU0csIGFwaUNvbmZpZy5DSEVDS19FRElUX09SSV9EUkFGVF9NRVNTQUdFLCBhcGlDb25maWcuSU5JVElBVEVfRURJVF9GT1JNX01TR19DT01NSVRFRCwgYXBpQ29uZmlnLklOSVRJQVRFX0NSRUFURV9SRVNfTVNHLCBhcGlDb25maWcuSU5JVElBVEVfQ1JFQVRFX0ZXRF9NU0csIGFwaUNvbmZpZy5TVUJNSVRfRk9STV9DSEFOR0VfU1RBVFVTLCBhcGlDb25maWcuQ09NUExFVEVfRk9SX0FDVElPTiwgYXBpQ29uZmlnLkNPTVBMRVRFX0ZPUl9BQ0tOT1dMRURHRU1FTlRfQUNUSU9OXTsgXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFjdGlvbklkcy5pbmRleE9mKGRhdGEuYWN0aW9uSWQpICE9IC0xICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNEYXRhID0gZGF0YS5yZXNwb25zZURhdGE7IC8vSW4gcmVzcG9uc2UgVVJMIHBhc3MuXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkYXRhLmFjdGlvbklkID09IGFwaUNvbmZpZy5HRVRfVVNFUl9TRUxFQ1RFRF9DT0xVTU5TKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbklkID0gZGF0YS5hY3Rpb25JZCArIFwiX1wiICsgZGF0YS50eXBlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNEYXRhID0gZGF0YTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRhdGEuYWN0aW9uSWQgPT0gYXBpQ29uZmlnLkdFVF9BVFRBQ0hNRU5UX0FORF9BU1NPQ0lBVElPTlMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uSWQgPSBkYXRhLmFjdGlvbklkICsgXCJfXCIgKyBkYXRhLnJlcXVlc3RlZEVudGl0eVR5cGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc0RhdGEgPSBKU09OLnBhcnNlKGRhdGEucmVzcG9uc2VEYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB9ZWxzZSBpZiAoZGF0YS5hY3Rpb25JZCA9PSBhcGlDb25maWcuR0VUX1VTRVJfQVBQTElDQVRJT05fUFJJVklMRUdFUykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLnR5cGUgJiYgKGFjdGlvbklkID0gZGF0YS5hY3Rpb25JZCArIFwiX1wiICsgZGF0YS50eXBlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzRGF0YSA9IEpTT04ucGFyc2UoZGF0YS5yZXNwb25zZURhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc0RhdGEgPSBKU09OLnBhcnNlKGRhdGEucmVzcG9uc2VEYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vUmVzb2x2ZSBtZXRob2QgY2FsbFxyXG4gICAgICAgICAgICAgICAgICAgIG9mZmxpbmVBY3Rpb25XaXNlUmVzb2x2ZUxpc3RbYWN0aW9uSWRdICYmIG9mZmxpbmVBY3Rpb25XaXNlUmVzb2x2ZUxpc3RbYWN0aW9uSWRdKHJlc0RhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cnl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJGFwcGx5KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2goZSl7fSAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHZhciBkZWZlcnJlZCA9ICRxLmRlZmVyKCk7XHJcblxyXG4gICAgICAgICAgICBpZihvYmoudXJsLmluZGV4T2YoJ2h0dHAnKSAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG9iai5fZGNJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9iai51cmwgPSBtYW5hZ2VEYXRhQ2VudGVyLmdldFVybChvYmouX2RjSWQsIG9iai5fY2RuVXJsKSArIG9iai51cmw7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9iai5fZGNJZDtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgb2JqLl9jZG5Vcmw7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKG9iai5fY2RuVXJsICYmICFvYmouX2RjSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmoudXJsID0gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwobXlDb25maWcuTE9DQUxfRENfSUQsIG9iai5fY2RuVXJsKSArIG9iai51cmw7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9iai5fY2RuVXJsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAob2JqLm1ldGhvZCAmJiBvYmoubWV0aG9kLnRvTG93ZXJDYXNlKCkgPT0gJ2dldCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChvYmoudXJsLmluZGV4T2YoJz8nKSA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9iai51cmwgKz0gJz90PScgKyBEYXRlLm5vdygpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmoudXJsICs9ICcmdD0nICsgRGF0ZS5ub3coKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdmFyIGRlZk9wdGlvbnMgPSB7XHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgICAgIGRhdGFUeXBlOiAnanNvbicsXHJcbiAgICAgICAgICAgICAgICBjYWNoZTogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICB3aXRoQ3JlZGVudGlhbHM6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkOyBjaGFyc2V0PVVURi04JyB9LFxyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtUmVxdWVzdDogZnVuY3Rpb24ob2JqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmogPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmo7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB2YXIgc3RyID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBvYmopXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0ci5wdXNoKGVuY29kZVVSSUNvbXBvbmVudChwKSArIFwiPVwiICsgZW5jb2RlVVJJQ29tcG9uZW50KG9ialtwXSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3RyLmpvaW4oXCImXCIpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHRpbWVvdXQ6IGRlZmVycmVkLnByb21pc2VcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGlmKG9iai5yZXNwb25zZVR5cGUgPT09ICd0ZXh0JyB8fCBvYmouZGF0YVR5cGUgPT09ICd0ZXh0Jykge1xyXG4gICAgICAgICAgICAgICAgZGVmT3B0aW9ucy50cmFuc2Zvcm1SZXNwb25zZSA9IGZ1bmN0aW9uKGRhdGEsIGhlYWRlcnNHZXR0ZXIsIHN0YXR1cykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlwiICsgZGF0YTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKG9iai5BcGlLZXkpIHtcclxuICAgICAgICAgICAgICAgIGRlZk9wdGlvbnMuaGVhZGVyc1tcIkFwaUtleVwiXSA9IG9iai5BcGlLZXk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChvYmouYVNlc3Npb25JRCkge1xyXG4gICAgICAgICAgICAgICAgZGVmT3B0aW9ucy5oZWFkZXJzW1wiQVNlc3Npb25JRFwiXSA9IG9iai5hU2Vzc2lvbklEO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9iaiA9IGFuZ3VsYXIuZXh0ZW5kKGRlZk9wdGlvbnMsIG9iaik7XHJcblxyXG4gICAgICAgICAgICB2YXIgdW5hdXRob3Jpc2VkUmVkaXJlY3QgPSBmdW5jdGlvbihyZXNwb25zZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZSB8fCAhYW5ndWxhci5pc1N0cmluZyhyZXNwb25zZS5kYXRhKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5pbmRleE9mKCdVbmF1dGhvcmlzZWQgQWNjZXNzJykgPiAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFuZ3VsYXIuZWxlbWVudCgnYm9keScpLmhpZGUoKTtcclxuICAgICAgICAgICAgICAgICAgICB0b3AubG9jYXRpb24uaHJlZiA9IG15Q29uZmlnLmFkb2RkbGVTeXN0ZW1XZWJVUkwgKyBcInVuYXV0aG9yaXNlZFwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5pbmRleE9mKCdTZXNzaW9uIFRpbWVkIE91dCcpID4gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBhcGkuc2V0U2Vzc2lvblN0YXRlKCdzZXNzaW9uU3RhdGUnLCAnSW5hY3RpdmUnKTtcclxuICAgICAgICAgICAgICAgICAgICBhcGkub3BlbkxvZ2luTW9kYWwoKTtcclxuICAgICAgICAgICAgICAgICAgICAvKiBhbmd1bGFyLmVsZW1lbnQoJ2JvZHknKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wLmxvY2F0aW9uLmhyZWYgPSBteUNvbmZpZy5hZG9kZGxlU3lzdGVtV2ViVVJMICsgXCJzZXNzaW9uLXRpbWVkLW91dFwiO1x0XHRcdCAqL1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5pbmRleE9mKCdTZXNzaW9uIE92ZXJyaWRlbicpID4gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBhbmd1bGFyLmVsZW1lbnQoJ2JvZHknKS5oaWRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wLmxvY2F0aW9uLmhyZWYgPSBteUNvbmZpZy5hZG9kZGxlU3lzdGVtV2ViVVJMICsgXCJzZXNzaW9uLW92ZXJyaWRlblwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHZhciByZXF1ZXN0ID0gJGh0dHAob2JqKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBwcm9taXNlID0gcmVxdWVzdC50aGVuKFxyXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24ocmVzcG9uc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB1bmF1dGhvcmlzZWRSZWRpcmVjdChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iai51cmwuaW5kZXhPZihhcGlDb25maWcuR0VUX1NFU1NJT05fVElNRU9VVF9ERVRBSUxTKSA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcGkuc2V0c2Vzc2lvblRpbW91dFRpbWVyKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24ocmVzcG9uc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB1bmF1dGhvcmlzZWRSZWRpcmVjdChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iai51cmwuaW5kZXhPZihhcGlDb25maWcuR0VUX1NFU1NJT05fVElNRU9VVF9ERVRBSUxTKSA9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcGkuc2V0c2Vzc2lvblRpbW91dFRpbWVyKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGFwaS5zaG93U2VydmVyRXJyb3JDb2RlKHJlc3BvbnNlKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoJHEucmVqZWN0KHJlc3BvbnNlKSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBwcm9taXNlLmFib3J0ID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICBkZWZlcnJlZC5yZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBwcm9taXNlWydmaW5hbGx5J10oZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICBwcm9taXNlLmFib3J0ID0gYW5ndWxhci5ub29wO1xyXG4gICAgICAgICAgICAgICAgZGVmZXJyZWQgPSByZXF1ZXN0ID0gcHJvbWlzZSA9IG51bGw7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHByb21pc2U7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgIH07XHJcblxyXG4gICAgYXBpLnNob3dTZXJ2ZXJFcnJvckNvZGUgPSBmdW5jdGlvbihlcnIpIHtcclxuICAgICAgICBsZXQgY29udGVudFR5cGUgPSBlcnIuaGVhZGVycygnQ29udGVudC1UeXBlJyk7XHJcbiAgICAgICAgaWYgKCFjb250ZW50VHlwZSB8fCAhZXJyLmRhdGEpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBlcnJvckNvZGU7XHJcbiAgICAgICAgaWYgKGNvbnRlbnRUeXBlLnN0YXJ0c1dpdGgoJ3RleHQvaHRtbCcpKSB7XHJcbiAgICAgICAgICBlcnJvckNvZGUgPSB3aW5kb3dbJyQnXShlcnIuZGF0YSkuZmluZChcIiNlcnJvckNvZGVcIikudGV4dCgpLnJlcGxhY2UoL1tcXG5cXHJcXHNdKy9nLCAnJylcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZXJyb3JDb2RlID0gZXJyLmRhdGEuZXJyb3JDb2RlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWVycm9yQ29kZSl7XHJcbiAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgTm90aWZpY2F0aW9uLmVycm9yKHtcclxuICAgICAgICAgICAgdGl0bGU6ICdUZWNobmljYWwgSW5mb3JtYXRpb24gKGZvciBzdXBwb3J0IHBlcnNvbm5lbCknLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiAnPGRpdiBjbGFzcz1cInRleHQtbGFyZ2VcIj4nICsgJ0Vycm9yIGNvZGU6ICcrIGVycm9yQ29kZSArICc8YSBocmVmPVwiamF2YXNjcmlwdDo7XCInKycgc3R5bGU9XCJjb2xvcjogI2ZmZjsgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7IG1hcmdpbi1sZWZ0OiAyMHB4O1wiIG9uY2xpY2s9XCJjb3B5RXJyb3JDb2RlQ2xpY2tlZCgpXCIgJysnXCI+JyArJ0NvcHknK1xyXG4gICAgICAgICAgICAnPC9hPjwvZGl2PicsXHJcbiAgICAgICAgICAgIGRlbGF5OiAxNTAwMDBcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgd2luZG93Wydjb3B5RXJyb3JDb2RlQ2xpY2tlZCddPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgd2luZG93LnByb21wdChMYW5ndWFnZS5nZXQoXCJjb3B5LXRvLWNsaXBib2FyZFwiKSwgZXJyb3JDb2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zZXRMb2NhbFN0b3JhZ2VJZnJhbXMgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAobXlDb25maWcuaXNQYWdlUHVibGljKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYW5ndWxhci5lbGVtZW50KCdib2R5JykuZmluZCgnLmxvY2FsLXN0b3JhZ2UtaWZyYW1lJykucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHZhciB1cmxzID0gW107XHJcbiAgICAgICAgICAgIHZhciB1c2VyQWNjZXNzaWJsZURDSWRzID0gd2luZG93WydVU1AnXSAmJiB3aW5kb3dbJ1VTUCddLnVzZXJBY2Nlc3NpYmxlRENJZHMgfHwgW107XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gdXNlckFjY2Vzc2libGVEQ0lkcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgdXJscy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICBwYXRoTmVlZGVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVybDogbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwodXNlckFjY2Vzc2libGVEQ0lkc1tpXSlcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvd1snYWRvZGRsZUFwcEVuZ2luZVVSTCddICYmIHVzZXJBY2Nlc3NpYmxlRENJZHNbaV0gIT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVybHMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGhOZWVkZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmw6IG1hbmFnZURhdGFDZW50ZXIuZ2V0VXJsKHVzZXJBY2Nlc3NpYmxlRENJZHNbaV0sIHdpbmRvd1snYWRvZGRsZUFwcEVuZ2luZVVSTCddLnJlcGxhY2UoJy5jb20vYXBwYnVpbGRlcicsICcuY29tL2xvY2FsU3RvcmFnZScpKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB1cmxzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoTmVlZGVkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiB3aW5kb3dbJ2Fkb2RkbGVBcHBFbmdpbmVVUkwnXS5yZXBsYWNlKCcuY29tL2FwcGJ1aWxkZXInLCAnLmNvbS9sb2NhbFN0b3JhZ2UnKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdXJscy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGlmcmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xyXG4gICAgICAgICAgICAgICAgaWZyYW1lLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGlmcmFtZSk7XHJcbiAgICAgICAgICAgICAgICBpZnJhbWUuY2xhc3NMaXN0LmFkZCgnbG9jYWwtc3RvcmFnZS1pZnJhbWUnKTtcclxuICAgICAgICAgICAgICAgIGlmcmFtZS5zcmMgPSB1cmxzW2ldLnVybCArICh1cmxzW2ldLnBhdGhOZWVkZWQgPyBhcGlDb25maWcuTE9DQUxfU1RPUkFHRSA6ICcnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICB9XHJcblxyXG4gICAgYXBpLmxvYWRMb2NhbFN0b3JhZ2VJRnJhbWUgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAvL1RoaXMgZnVuY3Rpb25hbGl0eSBpcyBub3Qgc3VwcG9ydGVkIGluIG9mZmxpbmUgaHRtbDUgZm9ybS5cclxuICAgICAgICBpZiAoIW15Q29uZmlnLmlzT2ZmbGluZU1vZGUpIHtcclxuICAgICAgICAgICAgYXBpLnNldExvY2FsU3RvcmFnZUlmcmFtcygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhcGkuc2V0U2Vzc2lvblN0YXRlID0gZnVuY3Rpb24obmFtZSwgdmFsdWUpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShuYW1lLCB2YWx1ZSk7XHJcbiAgICAgICAgICAgIHZhciBpZnJhbWVFbHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdsb2NhbC1zdG9yYWdlLWlmcmFtZScpO1xyXG4gICAgICAgICAgICBpZiAoIWlmcmFtZUVscy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGlmcmFtZUVscy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWZyYW1lRWxzW2ldLmNvbnRlbnRXaW5kb3cucG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdGF0ZTogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgfSksICcqJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKG5hbWUsIHZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHdpbmRvd1snc2V0U2Vzc2lvblN0YXRlJ10gPSBmdW5jdGlvbihuYW1lLCB2YWx1ZSkge1xyXG4gICAgICAgIGFwaS5zZXRTZXNzaW9uU3RhdGUobmFtZSwgdmFsdWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgdGltZXI7XHJcbiAgICBhcGkuc2V0c2Vzc2lvblRpbW91dFRpbWVyID0gZnVuY3Rpb24oZHVyYXRpb24pIHtcclxuICAgICAgICBpZiAobXlDb25maWcuaXNQYWdlUHVibGljKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGFwcElkID0gbXlDb25maWcuYXBwbGljYXRpb25JZCB8fCB3aW5kb3cuYXBwbGljYXRpb25JZCB8fCAxO1xyXG4gICAgICAgIGlmIChhcHBJZCAhPSAxKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gUmV0dXJuIHdoZW4gU1NPIGxvZ2luXHJcbiAgICAgICAgaWYgKHdpbmRvd1snVVNQJ10gJiYgd2luZG93WydVU1AnXS5sb2dpbk1ldGhvZFR5cGUgPT09IDIpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aW1lciAmJiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgICAgIGlmIChkdXJhdGlvbiAmJiBwYXJzZUZsb2F0KGR1cmF0aW9uKSA+IDApIHtcclxuICAgICAgICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KGFwaS5jaGVja1Nlc3Npb25UaW1lb3V0LCBwYXJzZUZsb2F0KGR1cmF0aW9uKSAqIDYwMDAwKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHBhcnNlRmxvYXQobXlDb25maWcuVVNQLnNlc3Npb25UaW1lb3V0RHVyYXRpb24pID4gMCkge1xyXG4gICAgICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoYXBpLmNoZWNrU2Vzc2lvblRpbWVvdXQsIHBhcnNlRmxvYXQobXlDb25maWcuVVNQLnNlc3Npb25UaW1lb3V0RHVyYXRpb24pICogNjAwMDApO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgYXBpLmNoZWNrU2Vzc2lvblRpbWVvdXQgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkdFVF9TRVNTSU9OX1RJTUVPVVRfREVUQUlMUyxcclxuICAgICAgICAgICAgZGF0YToge30sXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICB9KS50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgYXBpLnNldFNlc3Npb25TdGF0ZSgnc2Vzc2lvblN0YXRlJywgIWRhdGEudGltZW91dCA/ICdBY3RpdmUnIDogJ0luYWN0aXZlJyk7XHJcbiAgICAgICAgICAgIGlmIChkYXRhLnRpbWVvdXQpIHtcclxuICAgICAgICAgICAgICAgIGFwaS5vcGVuTG9naW5Nb2RhbCgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYXBpLnNldHNlc3Npb25UaW1vdXRUaW1lcihwYXJzZUZsb2F0KGRhdGEucmVtYWluaW5nTWlsbGlTZWNvbmQpIC8gNjAwMDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgIGlmICghbmF2aWdhdG9yLm9uTGluZSkge1xyXG4gICAgICAgICAgICAgICAgYXBpLnNldHNlc3Npb25UaW1vdXRUaW1lcihwYXJzZUZsb2F0KCcxMDAwMCcpIC8gNjAwMDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zZXRzZXNzaW9uVGltb3V0VGltZXIoKTtcclxuXHJcbiAgICB2YXIgbG9naW5Qb3B1cDtcclxuICAgIGFwaS5vcGVuTG9naW5Nb2RhbCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGlmIChsb2dpblBvcHVwIHx8IHdpbmRvdy50b3AgIT0gd2luZG93KSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gUmV0dXJuIHdoZW4gU1NPIGxvZ2luXHJcbiAgICAgICAgaWYgKHdpbmRvd1snVVNQJ10gJiYgd2luZG93WydVU1AnXS5sb2dpbk1ldGhvZFR5cGUgPT09IDIpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsb2dpblBvcHVwID0gJHVpYk1vZGFsLm9wZW4oe1xyXG4gICAgICAgICAgICBjb21wb25lbnQ6ICdsb2dpbicsXHJcbiAgICAgICAgICAgIGtleWJvYXJkOiBmYWxzZSxcclxuICAgICAgICAgICAgYmFja2Ryb3A6ICdzdGF0aWMnLFxyXG4gICAgICAgICAgICB3aW5kb3dDbGFzczogJ2xvZ2luLW1vZGFsJyxcclxuICAgICAgICAgICAgYmFja2Ryb3BDbGFzczogJ2xvZ2luLWJhY2tkcm9wJ1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGxvZ2luUG9wdXAuY2xvc2VkLnRoZW4oZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGxvZ2luUG9wdXAgPSAnJztcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgdmFyIGNvbmZpcm1Nb2RlbDtcclxuICAgIGFwaS5vcGVuQ29uZmlybUJveCA9IGZ1bmN0aW9uKG9wdGlvbnMpIHtcclxuICAgICAgICBjb25maXJtTW9kZWwgPSAkdWliTW9kYWwub3Blbih7XHJcbiAgICAgICAgICAgIHdpbmRvd0NsYXNzOiBcImNvbmZpcm0tcG9wdXBcIixcclxuICAgICAgICAgICAgYmFja2Ryb3BDbGFzczogJ2NvbmZpcm0tYmFja2Ryb3AnLFxyXG4gICAgICAgICAgICB0ZW1wbGF0ZTogXCI8ZGl2IGNsYXNzPSdkaWFsb2ctb3ZlbGF5Jz5cIiArXHJcbiAgICAgICAgICAgICAgICBcIjxkaXYgY2xhc3M9J2RpYWxvZyc+PGhlYWRlcj5cIiArXHJcbiAgICAgICAgICAgICAgICBcIiA8aDM+IHt7ICRjdHJsQ29uZmlybU1vZGVsLm9wdGlvbnMudGl0bGV9fSA8L2gzPiBcIiArXHJcbiAgICAgICAgICAgICAgICBcIjwvaGVhZGVyPlwiICtcclxuICAgICAgICAgICAgICAgIFwiPGRpdiBjbGFzcz0nZGlhbG9nLW1zZyc+XCIgK1xyXG4gICAgICAgICAgICAgICAgXCIgPHA+IHt7ICRjdHJsQ29uZmlybU1vZGVsLm9wdGlvbnMubXNnfX0gPC9wPiBcIiArXHJcbiAgICAgICAgICAgICAgICBcIjwvZGl2PlwiICtcclxuICAgICAgICAgICAgICAgIFwiPGZvb3Rlcj5cIiArXHJcbiAgICAgICAgICAgICAgICBcIjxkaXYgY2xhc3M9J2NvbnRyb2xzJz5cIiArXHJcbiAgICAgICAgICAgICAgICBcIiA8YnV0dG9uIGNsYXNzPSdidG4gYnRuLWRhbmdlcicgbmctY2xpY2s9JyRjdHJsQ29uZmlybU1vZGVsLmNhbGxiYWNrKCknPlwiICsgbGFuZy5nZXQoJ29rJykgKyBcIjwvYnV0dG9uPiBcIiArXHJcbiAgICAgICAgICAgICAgICBcIiA8YnV0dG9uIGNsYXNzPSdidG4gYnRuLWRlZmF1bHQnIG5nLWNsaWNrPSckY3RybENvbmZpcm1Nb2RlbC5jbG9zZVBvcHVwKCknPlwiICsgbGFuZy5nZXQoJ2NhbmNlbCcpICsgXCI8L2J1dHRvbj4gXCIgK1xyXG4gICAgICAgICAgICAgICAgXCI8L2Rpdj5cIiArXHJcbiAgICAgICAgICAgICAgICBcIjwvZm9vdGVyPlwiICtcclxuICAgICAgICAgICAgICAgIFwiPC9kaXY+XCIgK1xyXG4gICAgICAgICAgICAgICAgXCI8L2Rpdj5cIixcclxuICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmxDb25maXJtTW9kZWwnLFxyXG4gICAgICAgICAgICBjb250cm9sbGVyOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuY2FsbGJhY2sgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25maXJtTW9kZWwuZGlzbWlzcygnY2FuY2VsJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYodGhpcy5vcHRpb25zLmNhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy5jYWxsYmFjaygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5vcHRpb25zLnRhcmdldEZyYW1lKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy50YXJnZXRGcmFtZS5wb3N0TWVzc2FnZSgnb3BlbkNvbmZpcm1hdGlvbjpjb25maXJtZWQnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5jbG9zZVBvcHVwID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlybU1vZGVsLmRpc21pc3MoJ2NhbmNlbCcpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBrZXlib2FyZDogZmFsc2UsXHJcbiAgICAgICAgICAgIGJhY2tkcm9wOiAnc3RhdGljJyxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25maXJtTW9kZWwuY2xvc2VkLnRoZW4oZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGNvbmZpcm1Nb2RlbCA9ICcnO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHdpbmRvd1snb3BlbkxvZ2luTW9kYWwnXSA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGFwaS5vcGVuTG9naW5Nb2RhbCgpO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkudW5pcUJ5SWQgPSBmdW5jdGlvbihjb2xsZWN0aW9uLCBrZXluYW1lKSB7XHJcbiAgICAgICAgdmFyIG91dHB1dCA9IFtdLFxyXG4gICAgICAgICAgICBrZXlzID0gW107XHJcblxyXG4gICAgICAgIGFuZ3VsYXIuZm9yRWFjaChjb2xsZWN0aW9uLCBmdW5jdGlvbihpdGVtKSB7XHJcbiAgICAgICAgICAgIHZhciBrZXkgPSBpdGVtW2tleW5hbWVdO1xyXG4gICAgICAgICAgICBpZiAoa2V5cy5pbmRleE9mKGtleSkgPT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICBrZXlzLnB1c2goa2V5KTtcclxuICAgICAgICAgICAgICAgIG91dHB1dC5wdXNoKGl0ZW0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBvdXRwdXQ7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5wYXJzZVN0ciA9IGZ1bmN0aW9uKHMsIG8sIHJlKSB7XHJcbiAgICAgICAgdmFyIHRoYXQgPSB0aGlzO1xyXG4gICAgICAgIHJlID0gcmUgfHwgKC9cXHtcXHMqKFteXFx8XFx9XSs/KVxccyooPzpcXHwoW15cXH1dKikpP1xccypcXH0vZyk7XHJcbiAgICAgICAgcmV0dXJuICgocy5yZXBsYWNlKSA/IHMucmVwbGFjZShyZSwgZnVuY3Rpb24obWF0Y2gsIGtleSkge1xyXG4gICAgICAgICAgICByZXR1cm4gKG9ba2V5XSAhPT0gdW5kZWZpbmVkIHx8IG9ba2V5XSAhPT0gbnVsbCkgPyBvW2tleV0gOiBtYXRjaDtcclxuICAgICAgICB9KSA6IHMpO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuZ2V0UGFyYW1PYmogPSBmdW5jdGlvbih3aW4pIHtcclxuICAgICAgICB3aW4gPSB3aW4gfHwgJHdpbmRvdztcclxuICAgICAgICB2YXIgaHJlZiA9IHdpbi5sb2NhdGlvbi5ocmVmO1xyXG4gICAgICAgIHZhciBzZWFyY2ggPSBocmVmLnNwbGl0KCc/JylbMV07XHJcbiAgICAgICAgdmFyIG9iaiA9IHt9O1xyXG5cclxuICAgICAgICBpZiAoIXNlYXJjaCkge1xyXG4gICAgICAgICAgICByZXR1cm4gb2JqO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHBhcmFtQXJyYXkgPSBzZWFyY2guc3BsaXQoJyYnKTtcclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhcmFtQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdmFyIHBhcmFtID0gcGFyYW1BcnJheVtpXS5zcGxpdCgnPScpO1xyXG4gICAgICAgICAgICBvYmpbcGFyYW1bMF1dID0gcGFyYW1bMV07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gb2JqO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuZ2V0TGFzdE1vZGlmaWVkUHJvZmlsZVRpbWUgPSBmdW5jdGlvbihpbWFnZXBhdGgpIHtcclxuICAgICAgICBpZiAoIWltYWdlcGF0aCkge1xyXG4gICAgICAgICAgICByZXR1cm4gJzAnO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgbGFzdE1vZGlQaWNEYXRlID0gaW1hZ2VwYXRoLnNwbGl0KCc/JylbMV0gfHwgJyc7XHJcbiAgICAgICAgbGFzdE1vZGlQaWNEYXRlID0gbGFzdE1vZGlQaWNEYXRlLnNwbGl0KCcmJylbMF0gfHwgJyc7XHJcbiAgICAgICAgdmFyIGxhc3RNb2RpUGljRGF0ZUFycmF5ID0gbGFzdE1vZGlQaWNEYXRlLnNwbGl0KCc9Jyk7XHJcbiAgICAgICAgaWYgKGxhc3RNb2RpUGljRGF0ZUFycmF5WzBdICYmIGxhc3RNb2RpUGljRGF0ZUFycmF5WzBdID09ICd2Jykge1xyXG4gICAgICAgICAgICBsYXN0TW9kaVBpY0RhdGUgPSBsYXN0TW9kaVBpY0RhdGVBcnJheVsxXSB8fCAnJztcclxuICAgICAgICAgICAgbGFzdE1vZGlQaWNEYXRlID0gbGFzdE1vZGlQaWNEYXRlLnNwbGl0KCcjJylbMF0gfHwgJyc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGFzdE1vZGlQaWNEYXRlID0gJzAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGxhc3RNb2RpUGljRGF0ZTtcclxuICAgIH07XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBsYW5ndWFnZSBzcGVjaWZpYyBkYXlzIGFuZCBtb250aCBuYW1lc1xyXG4gICAgICovXHJcbiAgICBhcGkuZ2V0Q2FsZW5kYXJOYW1lcyA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICdEQVlfTkFNRVNfU0hPUlRFU1QnOiBsYW5nLmdldChcImFiYnItc29ydC1kYXktbmFtZS1hcnJheVwiKS5zcGxpdCgnLCcpLCAvLyBcIlN1LE1vLFR1LFdlLFRoLEZyLFNhXCJcclxuICAgICAgICAgICAgJ0RBWV9OQU1FU19TSE9SVCc6IGxhbmcuZ2V0KFwiYWJici1kYXktbmFtZS1hcnJheVwiKS5zcGxpdCgnLCcpLCAvLyBcIlN1bixNb24sVHVlLFdlZCxUaHUsRnJpLFNhdFwiXHJcbiAgICAgICAgICAgICdEQVlfTkFNRVMnOiBsYW5nLmdldChcImRheS1uYW1lLWFycmF5XCIpLnNwbGl0KCcsJyksIC8vIFwiU3VuZGF5LE1vbmRheSxUdWVzZGF5LFdlZG5lc2RheSxUaHVyc2RheSxGcmlkYXksU2F0dXJkYXlcIlxyXG4gICAgICAgICAgICAnTU9OVEhfTkFNRVNfU0hPUlQnOiBsYW5nLmdldChcImFiYnItbW9udGgtYXJyYXlcIikuc3BsaXQoJywnKSwgLy8gXCJKYW4sRmViLE1hcixBcHIsTWF5LEp1bixKdWwsQXVnLFNlcCxPY3QsTm92LERlY1wiXHJcbiAgICAgICAgICAgICdNT05USF9OQU1FUyc6IGxhbmcuZ2V0KFwibW9udGgtYXJyYXlcIikuc3BsaXQoJywnKSAvLyBcIkphbnVhcnksRmVicnVhcnksTWFyY2gsQXByaWwsTWF5LEp1bmUsSnVseSxBdWd1c3QsU2VwdGVtYmVyLE9jdG9iZXIsTm92ZW1iZXIsRGVjZW1iZXJcIlxyXG4gICAgICAgIH07XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogZGF0ZSB1dGlsaXRpZXNcclxuICAgICAqL1xyXG4gICAgdmFyIF90aWNrc1RvMTk3MCA9ICgoKDE5NzAgLSAxKSAqIDM2NSArIE1hdGguZmxvb3IoMTk3MCAvIDQpIC0gTWF0aC5mbG9vcigxOTcwIC8gMTAwKSArIE1hdGguZmxvb3IoMTk3MCAvIDQwMCkpICogMjQgKiA2MCAqIDYwICogMTAwMDAwMDApO1xyXG4gICAgYXBpLmdldER1cmF0aW9uID0gZnVuY3Rpb24oZGF0ZSkge1xyXG4gICAgICAgIGlmICghZGF0ZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gJyc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgdG9kYXlVVENTcGxpdCA9IG5ldyBEYXRlKCkudG9VVENTdHJpbmcoKS5zcGxpdChcIiBcIilbNF0uc3BsaXQoXCI6XCIpO1xyXG4gICAgICAgIHZhciBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIHZhciB0aW1lem9uZU9mZnNldCA9IDE5ODAwMDAwO1xyXG4gICAgICAgIHZhciB1dGNEYXRlID0gbmV3IERhdGUoRGF0ZS5VVEMobm93LmdldFVUQ0Z1bGxZZWFyKCksIG5vdy5nZXRVVENNb250aCgpLCBub3cuZ2V0VVRDRGF0ZSgpKSk7XHJcbiAgICAgICAgdXRjRGF0ZS5zZXRIb3VycyhwYXJzZUludCh0b2RheVVUQ1NwbGl0WzBdKSArIChteUNvbmZpZy50aW1lem9uZU9mZnNldCAvICgzNjAwICogMTAwMCkpLCB0b2RheVVUQ1NwbGl0WzFdLCB0b2RheVVUQ1NwbGl0WzJdKTtcclxuXHJcbiAgICAgICAgdmFyIGR1ZURhdGUgPSBuZXcgRGF0ZShEYXRlLlVUQyhkYXRlLmdldEZ1bGxZZWFyKCksIGRhdGUuZ2V0TW9udGgoKSwgZGF0ZS5nZXREYXRlKCkpKTtcclxuICAgICAgICBkdWVEYXRlLnNldEhvdXJzKDIzLCA1OSwgMDAsIDAwKTtcclxuXHJcbiAgICAgICAgdmFyIGRtaWxpID0gZHVlRGF0ZS5nZXRUaW1lKCk7XHJcbiAgICAgICAgdmFyIHRtaWxpID0gdXRjRGF0ZS5nZXRUaW1lKCk7XHJcbiAgICAgICAgdmFyIGRpZmYgPSBkbWlsaSAtIHRtaWxpO1xyXG5cclxuICAgICAgICB2YXIgZGlmZl9kYXlzID0gcGFyc2VJbnQoZGlmZiAvICgyNCAqIDYwICogNjAgKiAxMDAwKSk7IC8vIGluIGRheXNcclxuICAgICAgICB2YXIgZGlmZl9ob3VycyA9IHBhcnNlSW50KGRpZmYgLyAoNjAgKiA2MCAqIDEwMDApKTsgLy8gaW4gaG91cnNcclxuXHJcbiAgICAgICAgaWYgKGRpZmZfaG91cnMgPiAyMylcclxuICAgICAgICAgICAgcmV0dXJuIChkaWZmX2RheXMgKyAnIGQnKTtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIHJldHVybiAoZGlmZl9ob3VycyArICcgaCcpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBGb3JtYXQgYSBudW1iZXIsIHdpdGggbGVhZGluZyB6ZXJvIGlmIG5lY2Vzc2FyeVxyXG4gICAgYXBpLmFkZFplcm8gPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBudW0gPSBcIlwiICsgdmFsdWU7XHJcbiAgICAgICAgaWYgKG51bS5sZW5ndGggPCAxMCkge1xyXG4gICAgICAgICAgICBudW0gPSBcIjBcIiArIG51bTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG51bTtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLmZvcm1hdERhdGUgPSBmdW5jdGlvbihmb3JtYXQsIGRhdGUpIHtcclxuICAgICAgICBpZiAoIWRhdGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIFwiXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgaUZvcm1hdCxcclxuICAgICAgICAgICAgbmFtZU1hcCA9IGFwaS5nZXRDYWxlbmRhck5hbWVzKCksXHJcbiAgICAgICAgICAgIGRheU5hbWVzU2hvcnQgPSBuYW1lTWFwLkRBWV9OQU1FU19TSE9SVCxcclxuICAgICAgICAgICAgZGF5TmFtZXMgPSBuYW1lTWFwLkRBWV9OQU1FUyxcclxuICAgICAgICAgICAgbW9udGhOYW1lc1Nob3J0ID0gbmFtZU1hcC5NT05USF9OQU1FU19TSE9SVCxcclxuICAgICAgICAgICAgbW9udGhOYW1lcyA9IG5hbWVNYXAuTU9OVEhfTkFNRVMsXHJcblxyXG4gICAgICAgICAgICAvLyBDaGVjayB3aGV0aGVyIGEgZm9ybWF0IGNoYXJhY3RlciBpcyBkb3VibGVkXHJcbiAgICAgICAgICAgIGxvb2tBaGVhZCA9IGZ1bmN0aW9uKG1hdGNoKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgbWF0Y2hlcyA9IChpRm9ybWF0ICsgMSA8IGZvcm1hdC5sZW5ndGggJiYgZm9ybWF0LmNoYXJBdChpRm9ybWF0ICsgMSkgPT09IG1hdGNoKTtcclxuICAgICAgICAgICAgICAgIGlmIChtYXRjaGVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaUZvcm1hdCsrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG1hdGNoZXM7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGZvcm1hdE51bWJlciA9IGZ1bmN0aW9uKG1hdGNoLCB2YWx1ZSwgbGVuKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgbnVtID0gXCJcIiArIHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKGxvb2tBaGVhZChtYXRjaCkpIHtcclxuICAgICAgICAgICAgICAgICAgICB3aGlsZSAobnVtLmxlbmd0aCA8IGxlbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBudW0gPSBcIjBcIiArIG51bTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVtO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAvLyBGb3JtYXQgYSBuYW1lLCBzaG9ydCBvciBsb25nIGFzIHJlcXVlc3RlZFxyXG4gICAgICAgICAgICBmb3JtYXROYW1lID0gZnVuY3Rpb24obWF0Y2gsIHZhbHVlLCBzaG9ydE5hbWVzLCBsb25nTmFtZXMpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAobG9va0FoZWFkKG1hdGNoKSA/IGxvbmdOYW1lc1t2YWx1ZV0gOiBzaG9ydE5hbWVzW3ZhbHVlXSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG91dHB1dCA9IFwiXCIsXHJcbiAgICAgICAgICAgIGxpdGVyYWwgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKGRhdGUpIHtcclxuICAgICAgICAgICAgZm9yIChpRm9ybWF0ID0gMDsgaUZvcm1hdCA8IGZvcm1hdC5sZW5ndGg7IGlGb3JtYXQrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGxpdGVyYWwpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybWF0LmNoYXJBdChpRm9ybWF0KSA9PT0gXCInXCIgJiYgIWxvb2tBaGVhZChcIidcIikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGl0ZXJhbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBmb3JtYXQuY2hhckF0KGlGb3JtYXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChmb3JtYXQuY2hhckF0KGlGb3JtYXQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQgKz0gZm9ybWF0TnVtYmVyKFwiZFwiLCBkYXRlLmdldERhdGUoKSwgMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIkRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBmb3JtYXROYW1lKFwiRFwiLCBkYXRlLmdldERheSgpLCBkYXlOYW1lc1Nob3J0LCBkYXlOYW1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm9cIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBmb3JtYXROdW1iZXIoXCJvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWF0aC5yb3VuZCgobmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCksIGRhdGUuZ2V0RGF0ZSgpKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShkYXRlLmdldEZ1bGxZZWFyKCksIDAsIDApLmdldFRpbWUoKSkgLyA4NjQwMDAwMCksIDMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJtXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQgKz0gZm9ybWF0TnVtYmVyKFwibVwiLCBkYXRlLmdldE1vbnRoKCkgKyAxLCAyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiTVwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0cHV0ICs9IGZvcm1hdE5hbWUoXCJNXCIsIGRhdGUuZ2V0TW9udGgoKSwgbW9udGhOYW1lc1Nob3J0LCBtb250aE5hbWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwieVwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0cHV0ICs9IChsb29rQWhlYWQoXCJ5XCIpID8gZGF0ZS5nZXRGdWxsWWVhcigpIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGF0ZS5nZXRZZWFyKCkgJSAxMDAgPCAxMCA/IFwiMFwiIDogXCJcIikgKyBkYXRlLmdldFllYXIoKSAlIDEwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcInRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSAoZGF0ZS5nZXRIb3VycygpICsgXCI6XCIgKyBkYXRlLmdldE1pbnV0ZXMoKSArIFwiOlwiICsgZGF0ZS5nZXRTZWNvbmRzKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJwXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQgKz0gYXBpLmdldER1cmF0aW9uKGRhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJAXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQgKz0gZGF0ZS5nZXRUaW1lKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIiFcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBkYXRlLmdldFRpbWUoKSAqIDEwMDAwICsgX3RpY2tzVG8xOTcwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCInXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9va0FoZWFkKFwiJ1wiKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBcIidcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGl0ZXJhbCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dHB1dCArPSBmb3JtYXQuY2hhckF0KGlGb3JtYXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gb3V0cHV0O1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkucGFyc2VEYXRlID0gZnVuY3Rpb24oZm9ybWF0LCB2YWx1ZSkge1xyXG4gICAgICAgIGlmIChmb3JtYXQgPT0gbnVsbCB8fCB2YWx1ZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRocm93IGxhbmcuZ2V0KFwiaW52YWxpZC1hcmd1bWVudHNcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YWx1ZSA9ICh0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgPyB2YWx1ZS50b1N0cmluZygpIDogdmFsdWUgKyBcIlwiKTtcclxuICAgICAgICBpZiAodmFsdWUgPT09IFwiXCIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgaUZvcm1hdCwgZGltLCBleHRyYSxcclxuICAgICAgICAgICAgaVZhbHVlID0gMCxcclxuICAgICAgICAgICAgc2hvcnRZZWFyQ3V0b2ZmID0gMjYsXHJcbiAgICAgICAgICAgIG5hbWVNYXAgPSBhcGkuZ2V0Q2FsZW5kYXJOYW1lcygpLFxyXG4gICAgICAgICAgICBkYXlOYW1lc1Nob3J0ID0gbmFtZU1hcC5EQVlfTkFNRVNfU0hPUlQsXHJcbiAgICAgICAgICAgIGRheU5hbWVzID0gbmFtZU1hcC5EQVlfTkFNRVMsXHJcbiAgICAgICAgICAgIG1vbnRoTmFtZXNTaG9ydCA9IG5hbWVNYXAuTU9OVEhfTkFNRVNfU0hPUlQsXHJcbiAgICAgICAgICAgIG1vbnRoTmFtZXMgPSBuYW1lTWFwLk1PTlRIX05BTUVTLFxyXG4gICAgICAgICAgICB5ZWFyID0gLTEsXHJcbiAgICAgICAgICAgIHRpbWUgPSAtMSxcclxuICAgICAgICAgICAgbW9udGggPSAtMSxcclxuICAgICAgICAgICAgZGF5ID0gLTEsXHJcbiAgICAgICAgICAgIGRveSA9IC0xLFxyXG4gICAgICAgICAgICBsaXRlcmFsID0gZmFsc2UsXHJcbiAgICAgICAgICAgIGRhdGUsXHJcbiAgICAgICAgICAgIC8vIENoZWNrIHdoZXRoZXIgYSBmb3JtYXQgY2hhcmFjdGVyIGlzIGRvdWJsZWRcclxuICAgICAgICAgICAgbG9va0FoZWFkID0gZnVuY3Rpb24obWF0Y2gpIHtcclxuICAgICAgICAgICAgICAgIHZhciBtYXRjaGVzID0gKGlGb3JtYXQgKyAxIDwgZm9ybWF0Lmxlbmd0aCAmJiBmb3JtYXQuY2hhckF0KGlGb3JtYXQgKyAxKSA9PT0gbWF0Y2gpO1xyXG4gICAgICAgICAgICAgICAgaWYgKG1hdGNoZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBpRm9ybWF0Kys7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbWF0Y2hlcztcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy8gRXh0cmFjdCBhIG51bWJlciBmcm9tIHRoZSBzdHJpbmcgdmFsdWVcclxuICAgICAgICAgICAgZ2V0TnVtYmVyID0gZnVuY3Rpb24obWF0Y2gpIHtcclxuICAgICAgICAgICAgICAgIHZhciBpc0RvdWJsZWQgPSBsb29rQWhlYWQobWF0Y2gpLFxyXG4gICAgICAgICAgICAgICAgICAgIHNpemUgPSAobWF0Y2ggPT09IFwiQFwiID8gMTQgOiAobWF0Y2ggPT09IFwiIVwiID8gMjAgOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAobWF0Y2ggPT09IFwieVwiICYmIGlzRG91YmxlZCA/IDQgOiAobWF0Y2ggPT09IFwib1wiID8gMyA6IDIpKSkpLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pblNpemUgPSAobWF0Y2ggPT09IFwieVwiID8gc2l6ZSA6IDEpLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpZ2l0cyA9IG5ldyBSZWdFeHAoXCJeXFxcXGR7XCIgKyBtaW5TaXplICsgXCIsXCIgKyBzaXplICsgXCJ9XCIpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChtYXRjaCA9PT0gXCJ0XCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBudW0gPSB2YWx1ZS5zdWJzdHJpbmcoaVZhbHVlKS5tYXRjaChuZXcgUmVnRXhwKFwiXlxcXFxkezEsMn06XFxcXGR7MSwyfTpcXFxcZHsxLDJ9XCIpKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbnVtID0gdmFsdWUuc3Vic3RyaW5nKGlWYWx1ZSkubWF0Y2gobmV3IFJlZ0V4cChcIl5cXFxcZHtcIiArIG1pblNpemUgKyBcIixcIiArIHNpemUgKyBcIn1cIikpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKCFudW0pIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBsYW5nLmdldChcIm1pc3NpbmctbnVtYmVyLWF0LXBvc2l0aW9uXCIpICsgaVZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlWYWx1ZSArPSBudW1bMF0ubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgaWYgKG1hdGNoID09PSBcInRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudW1bMF07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KG51bVswXSwgMTApO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAvLyBFeHRyYWN0IGEgbmFtZSBmcm9tIHRoZSBzdHJpbmcgdmFsdWUgYW5kIGNvbnZlcnQgdG8gYW4gaW5kZXhcclxuICAgICAgICAgICAgZ2V0TmFtZSA9IGZ1bmN0aW9uKG1hdGNoLCBzaG9ydE5hbWVzLCBsb25nTmFtZXMpIHtcclxuICAgICAgICAgICAgICAgIHZhciBpbmRleCA9IC0xLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWVzID0gJC5tYXAobG9va0FoZWFkKG1hdGNoKSA/IGxvbmdOYW1lcyA6IHNob3J0TmFtZXMsIGZ1bmN0aW9uKHYsIGspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtrLCB2XVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pLnNvcnQoZnVuY3Rpb24oYSwgYikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gLShhWzFdLmxlbmd0aCAtIGJbMV0ubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAkLmVhY2gobmFtZXMsIGZ1bmN0aW9uKGksIHBhaXIpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbmFtZSA9IHBhaXJbMV07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlLnN1YnN0cihpVmFsdWUsIG5hbWUubGVuZ3RoKS50b0xvd2VyQ2FzZSgpID09PSBuYW1lLnRvTG93ZXJDYXNlKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggPSBwYWlyWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpVmFsdWUgKz0gbmFtZS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBsYW5nLmdldChcInVua25vd24tbmFtZS1hdC1wb3NpdGlvblwiKSArIGlWYWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy8gQ29uZmlybSB0aGF0IGEgbGl0ZXJhbCBjaGFyYWN0ZXIgbWF0Y2hlcyB0aGUgc3RyaW5nIHZhbHVlXHJcbiAgICAgICAgICAgIGNoZWNrTGl0ZXJhbCA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlLmNoYXJBdChpVmFsdWUpICE9PSBmb3JtYXQuY2hhckF0KGlGb3JtYXQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbGFuZy5nZXQoXCJ1bmV4cGVjdGVkLWxpdGVyYWwtYXQtcG9zaXRpb25cIikgKyBpVmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpVmFsdWUrKztcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZm9yIChpRm9ybWF0ID0gMDsgaUZvcm1hdCA8IGZvcm1hdC5sZW5ndGg7IGlGb3JtYXQrKykge1xyXG4gICAgICAgICAgICBpZiAobGl0ZXJhbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGZvcm1hdC5jaGFyQXQoaUZvcm1hdCkgPT09IFwiJ1wiICYmICFsb29rQWhlYWQoXCInXCIpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGl0ZXJhbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjaGVja0xpdGVyYWwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAoZm9ybWF0LmNoYXJBdChpRm9ybWF0KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRheSA9IGdldE51bWJlcihcImRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJEXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldE5hbWUoXCJEXCIsIGRheU5hbWVzU2hvcnQsIGRheU5hbWVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm9cIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG95ID0gZ2V0TnVtYmVyKFwib1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm1cIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgbW9udGggPSBnZXROdW1iZXIoXCJtXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwiTVwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aCA9IGdldE5hbWUoXCJNXCIsIG1vbnRoTmFtZXNTaG9ydCwgbW9udGhOYW1lcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJ5XCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHllYXIgPSBnZXROdW1iZXIoXCJ5XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwidFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aW1lID0gZ2V0TnVtYmVyKFwidFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcIkBcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZSA9IG5ldyBEYXRlKGdldE51bWJlcihcIkBcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aCA9IGRhdGUuZ2V0TW9udGgoKSArIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRheSA9IGRhdGUuZ2V0RGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwiIVwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlID0gbmV3IERhdGUoKGdldE51bWJlcihcIiFcIikgLSBfdGlja3NUbzE5NzApIC8gMTAwMDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aCA9IGRhdGUuZ2V0TW9udGgoKSArIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRheSA9IGRhdGUuZ2V0RGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwiJ1wiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9va0FoZWFkKFwiJ1wiKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tMaXRlcmFsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaXRlcmFsID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja0xpdGVyYWwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGlWYWx1ZSA8IHZhbHVlLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBleHRyYSA9IHZhbHVlLnN1YnN0cihpVmFsdWUpO1xyXG4gICAgICAgICAgICBpZiAoIS9eXFxzKy8udGVzdChleHRyYSkpIHtcclxuICAgICAgICAgICAgICAgIHRocm93IGxhbmcuZ2V0KFwiZXh0cmEtdW5wYXJzZWQtY2hhci1pbi1kYXRlXCIpICsgZXh0cmE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh5ZWFyID09PSAtMSkge1xyXG4gICAgICAgICAgICB5ZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoeWVhciA8IDEwMCkge1xyXG4gICAgICAgICAgICB5ZWFyICs9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKSAtIG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKSAlIDEwMCArXHJcbiAgICAgICAgICAgICAgICAoeWVhciA8PSBzaG9ydFllYXJDdXRvZmYgPyAwIDogLTEwMCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgX2RheWxpZ2h0U2F2aW5nQWRqdXN0ID0gZnVuY3Rpb24oZGF0ZSkge1xyXG4gICAgICAgICAgICBpZiAoIWRhdGUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGRhdGUuc2V0SG91cnMoZGF0ZS5nZXRIb3VycygpID4gMTIgPyBkYXRlLmdldEhvdXJzKCkgKyAyIDogMCk7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHZhciBfZ2V0RGF5c0luTW9udGggPSBmdW5jdGlvbih5ZWFyLCBtb250aCkge1xyXG4gICAgICAgICAgICByZXR1cm4gMzIgLSBfZGF5bGlnaHRTYXZpbmdBZGp1c3QobmV3IERhdGUoeWVhciwgbW9udGgsIDMyKSkuZ2V0RGF0ZSgpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChkb3kgPiAtMSkge1xyXG4gICAgICAgICAgICBtb250aCA9IDE7XHJcbiAgICAgICAgICAgIGRheSA9IGRveTtcclxuICAgICAgICAgICAgZG8ge1xyXG4gICAgICAgICAgICAgICAgZGltID0gX2dldERheXNJbk1vbnRoKHllYXIsIG1vbnRoIC0gMSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoZGF5IDw9IGRpbSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbW9udGgrKztcclxuICAgICAgICAgICAgICAgIGRheSAtPSBkaW07XHJcbiAgICAgICAgICAgIH0gd2hpbGUgKHRydWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZGF0ZSA9IF9kYXlsaWdodFNhdmluZ0FkanVzdChuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEsIGRheSkpO1xyXG4gICAgICAgIGlmIChkYXRlLmdldEZ1bGxZZWFyKCkgIT09IHllYXIgfHwgZGF0ZS5nZXRNb250aCgpICsgMSAhPT0gbW9udGggfHwgZGF0ZS5nZXREYXRlKCkgIT09IGRheSkge1xyXG4gICAgICAgICAgICB0aHJvdyBsYW5nLmdldChcImludmFsaWQtZGF0ZVwiKTsgLy8gRS5nLiAzMS8wMi8wMFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRpbWUgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHZhciB0aW1lU3BsaXQgPSB0aW1lLnNwbGl0KCc6Jyk7XHJcbiAgICAgICAgICAgIGRhdGUuc2V0SG91cnModGltZVNwbGl0WzBdKTtcclxuICAgICAgICAgICAgZGF0ZS5zZXRNaW51dGVzKHRpbWVTcGxpdFsxXSk7XHJcbiAgICAgICAgICAgIGRhdGUuc2V0U2Vjb25kcyh0aW1lU3BsaXRbMl0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGRhdGU7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS50cnlUb1BhcnNlRGF0ZSA9IGZ1bmN0aW9uKHZhbHVlLCBmb3JtYXQpIHtcclxuICAgICAgICB2YXIgcG9zc2libGVGb3JtYXQgPSBbJ3l5LW1tLWRkJywgJ3l5L21tL2RkJywgJ2RkL21tL3l5JywgJ2RkLW1tLXl5JyxcclxuICAgICAgICAgICAgJ3l5LW0tZCcsICd5eS9tL2QnLCAnZC9tL3l5JywgJ2QtbS15eScsXHJcbiAgICAgICAgICAgICd5LW1tLWRkJywgJ3kvbW0vZGQnLCAnZGQvbW0veScsICdkZC1tbS15JyxcclxuICAgICAgICAgICAgJ3kvbS9kJywgJ3kvbS9kJywgJ2QvbS95JywgJ2QtbS15J1xyXG4gICAgICAgIF07XHJcblxyXG4gICAgICAgIHZhciBkYXRlID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcG9zc2libGVGb3JtYXQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdmFyIGRhdGVGb3JtYXQgPSBwb3NzaWJsZUZvcm1hdFtpXTtcclxuICAgICAgICAgICAgaWYgKCFmb3JtYXQgfHwgZGF0ZUZvcm1hdCAhPSBmb3JtYXQpIHtcclxuICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0ZSA9IGFwaS5wYXJzZURhdGUoZGF0ZUZvcm1hdCwgdmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIWRhdGUpXHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH07XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBmYWxsYmFjayBmdW5jdGlvbiB0byBjb3B5IHRoZSB0ZXh0IGZvciBlYXJsaWVyIGJyb3dzZXJzIFxyXG4gICAgICovXHJcbiAgICB2YXIgbGFuZ3VhZ2UgPSBsYW5nLmdldExhbmdPYmooKTtcclxuICAgIGFwaS5jb3B5VG9DbGlwYm9hcmQgPSBmdW5jdGlvbihlLCB0ZXh0KSB7XHJcbiAgICAgICAgJHdpbmRvdy5wcm9tcHQobGFuZ3VhZ2VbXCJjb3B5LXRvLWNsaXBib2FyZFwiXSwgdGV4dCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5oYXNBY2Nlc3MgPSBmdW5jdGlvbihzdHIsIGtleSkge1xyXG4gICAgICAgIGlmICghc3RyKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiAoc3RyLmluZGV4T2YoXCIsXCIgKyBhcGlDb25maWdba2V5XSArIFwiLFwiKSA+IC0xKVxyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuaGFzRm9sZGVyUGVybWlzc2lvbiA9IGZ1bmN0aW9uKFxyXG4gICAgICAgIGZvbGRlclBlcm1pc3Npb25WYWx1ZXMsXHJcbiAgICAgICAgZm9sZGVySWQsXHJcbiAgICAgICAga2V5XHJcbiAgICApe1xyXG4gICAgICAgIGZvbGRlcklkID0gZm9sZGVySWQuc3BsaXQoXCIkJFwiKVswXTtcclxuICAgICAgICByZXR1cm4gZm9sZGVyUGVybWlzc2lvblZhbHVlc1tmb2xkZXJJZF0gPT0gYXBpQ29uZmlnLmZvbGRlclBlcm1pc3Npb25ba2V5XTtcclxuICAgIH1cclxuXHJcbiAgICBhcGkuaGFzRm9sZGVyVXBsb2FkUGVybWlzc2lvbiA9IGZ1bmN0aW9uKHBlcm1pc3Npb25EYXRhLCBmb2xkZXJJZCkge1xyXG4gICAgICAgIHJldHVybiAoYXBpLmhhc0ZvbGRlclBlcm1pc3Npb24ocGVybWlzc2lvbkRhdGEuZm9sZGVyUGVybWlzc2lvblZhbHVlcywgZm9sZGVySWQsICdGT0xERVJfQURNSU5fUEVSTUlTU0lPTicpIHx8XHJcbiAgICAgICAgYXBpLmhhc0ZvbGRlclBlcm1pc3Npb24ocGVybWlzc2lvbkRhdGEuZm9sZGVyUGVybWlzc2lvblZhbHVlcywgZm9sZGVySWQsICdGT0xERVJfUFVCTElTSF9BTkRfTElOS19QRVJNSVNTSU9OJykgfHxcclxuICAgICAgICBhcGkuaGFzRm9sZGVyUGVybWlzc2lvbihwZXJtaXNzaW9uRGF0YS5mb2xkZXJQZXJtaXNzaW9uVmFsdWVzLCBmb2xkZXJJZCwgJ0ZPTERFUl9QVUJMSVNIX1BFUk1JU1NJT04nKSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5oYXNQZXJtaXNzaW9uVG9DaGVja291dEZpbGUgPSBmdW5jdGlvbihzZWxlY3RlZFJvd3MsIHBlcm1pc3Npb25zRGF0YSkge1xyXG4gICAgICAgIHZhciBpc0VuYWJsZUNoZWNrb3V0ID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgc2VsZWN0ZWRSb3dzLnNvbWUoZnVuY3Rpb24ocm93KSB7XHJcbiAgICAgICAgICAgIHZhciBwZXJtaXNzaW9uVmFsdWUgPSBwZXJtaXNzaW9uc0RhdGEuZm9sZGVyUGVybWlzc2lvblZhbHVlc1tyb3cuZm9sZGVySWQuc3BsaXQoXCIkJFwiKVswXV07XHJcbiAgICAgICAgICAgIGlmICggcm93LmlzTGluayB8fCByb3cuaXNfbGluayB8fCByb3cuZG9jdW1lbnRUeXBlSWQgPT0gYXBpQ29uZmlnLkRPQ19UWVBFX0lELlBMQUNFSE9MREVSIHx8IHJvdy5jaGVja091dFN0YXR1cyB8fCBwZXJtaXNzaW9uVmFsdWUgPT09IGFwaUNvbmZpZy5mb2xkZXJQZXJtaXNzaW9uLlZJRVdfT05MWSB8fCAhYXBpLmhhc0ZvbGRlclVwbG9hZFBlcm1pc3Npb24ocGVybWlzc2lvbnNEYXRhLCByb3cuZm9sZGVySWQpKSB7XHJcbiAgICAgICAgICAgICAgICBpc0VuYWJsZUNoZWNrb3V0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBpc0VuYWJsZUNoZWNrb3V0O1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuaXNMb2NrZWQgPSBmdW5jdGlvbihzdHIsIGtleSkge1xyXG4gICAgICAgIGlmICghc3RyKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIChzdHIuaW5kZXhPZihhcGlDb25maWcuQUNUSVZJVFlfQ09OU1RBTlRba2V5XSkgPiAtMSlcclxuICAgIH07XHJcblxyXG4gICAgYXBpLnN1Ym1pdERvd25sb2FkRm9ybSA9IGZ1bmN0aW9uKG9wdGlvbikge1xyXG4gICAgICAgIFxyXG4gICAgICAgICQoXCIjZG93bmxvYWRGcmFtZVwiKS5yZW1vdmUoKTtcclxuICAgICAgICB2YXIgJGlmcmFtZSA9ICQoJzxpZnJhbWUgc3JjPVwiXCIgaWQ9XCJkb3dubG9hZEZyYW1lXCIgbmFtZT1cImRvd25sb2FkRnJhbWVcIiBzdHlsZT1cIndpZHRoOiAwcHg7aGVpZ2h0OjBweDtib3JkZXI6IDBweDtcIj48L2lmcmFtZT4nKTtcclxuICAgICAgICB2YXIgZm9ybSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2Zvcm0nKTtcclxuXHJcbiAgICAgICAgZm9ybS50YXJnZXQgPSBcImRvd25sb2FkRnJhbWVcIjtcclxuXHJcbiAgICAgICAgaWYgKG9wdGlvbi5wYXJhbSlcclxuICAgICAgICAgICAgb3B0aW9uLnBhcmFtLmFwcGxpY2F0aW9uSWQgPSBteUNvbmZpZy5hcHBsaWNhdGlvbklkO1xyXG5cclxuICAgICAgICBpZihvcHRpb24udXJsLmluZGV4T2YoJ2h0dHAnKSAhPT0gMCkge1xyXG5cclxuICAgICAgICAgICAgaWYgKG9wdGlvbi5fZGNJZCkge1xyXG4gICAgICAgICAgICAgICAgb3B0aW9uLnVybCA9IG1hbmFnZURhdGFDZW50ZXIuZ2V0VXJsKG9wdGlvbi5fZGNJZCwgb3B0aW9uLl9jZG5VcmwpICsgb3B0aW9uLnVybDtcclxuICAgICAgICAgICAgICAgIGRlbGV0ZSBvcHRpb24uX2RjSWQ7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgb3B0aW9uLl9jZG5Vcmw7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChvcHRpb24uX2NkblVybCAmJiAhb3B0aW9uLl9kY0lkKSB7XHJcbiAgICAgICAgICAgICAgICBvcHRpb24udXJsID0gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwobXlDb25maWcuTE9DQUxfRENfSUQsIG9wdGlvbi5fY2RuVXJsKSArIG9wdGlvbi51cmw7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgb3B0aW9uLl9jZG5Vcmw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICBmb3JtLmFjdGlvbiA9IG9wdGlvbi51cmw7XHJcbiAgICAgICAgZm9ybS5tZXRob2QgPSBvcHRpb24ubWV0aG9kIHx8ICdQT1NUJztcclxuXHJcbiAgICAgICAgZm9yICh2YXIgbmFtZSBpbiBvcHRpb24ucGFyYW0pIHtcclxuICAgICAgICAgICAgdmFyIGlucHV0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKTtcclxuICAgICAgICAgICAgaW5wdXQudHlwZSA9ICdoaWRkZW4nO1xyXG4gICAgICAgICAgICBpbnB1dC5uYW1lID0gbmFtZTtcclxuICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBvcHRpb24ucGFyYW1bbmFtZV07XHJcbiAgICAgICAgICAgIGZvcm0uYXBwZW5kQ2hpbGQoaW5wdXQpO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZm9ybSk7XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCgkaWZyYW1lKTtcclxuICAgICAgICBmb3JtLnN1Ym1pdCgpO1xyXG4gICAgICAgIGFuZ3VsYXIuZWxlbWVudChmb3JtKS5yZW1vdmUoKTtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLnN1Ym1pdEZvcm0gPSBmdW5jdGlvbihvcHRpb24pIHtcclxuICAgICAgICB2YXIgZm9ybSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2Zvcm0nKTtcclxuXHJcbiAgICAgICAgdmFyIHRhcmdldCA9IG9wdGlvbi50YXJnZXQgfHwgJ19ibGFuayc7XHJcbiAgICAgICAgaWYgKGFwaS5pc05hdmlnYXRvcigpKVxyXG4gICAgICAgICAgICB0YXJnZXQgPSAnX3NlbGYnO1xyXG5cclxuICAgICAgICBmb3JtLnRhcmdldCA9IHRhcmdldDtcclxuXHJcbiAgICAgICAgaWYgKG9wdGlvbi5wYXJhbSkge1xyXG4gICAgICAgICAgICBpZiAobXlDb25maWcuYXBwbGljYXRpb25JZCkge1xyXG4gICAgICAgICAgICAgICAgb3B0aW9uLnBhcmFtLmFwcGxpY2F0aW9uSWQgPSBteUNvbmZpZy5hcHBsaWNhdGlvbklkO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgb3B0aW9uLnBhcmFtLmFwcGxpY2F0aW9uSWQgPSBhcHBsaWNhdGlvbklkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZihvcHRpb24udXJsLmluZGV4T2YoJ2h0dHAnKSAhPT0gMCkge1xyXG5cclxuICAgICAgICAgICAgaWYgKG9wdGlvbi5fZGNJZCkge1xyXG4gICAgICAgICAgICAgICAgb3B0aW9uLnVybCA9IG1hbmFnZURhdGFDZW50ZXIuZ2V0VXJsKG9wdGlvbi5fZGNJZCwgb3B0aW9uLl9jZG5VcmwsIG9wdGlvbi5ub25fZWRnZUNhc3QpICsgb3B0aW9uLnVybDtcclxuICAgICAgICAgICAgICAgIGRlbGV0ZSBvcHRpb24uX2RjSWQ7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgb3B0aW9uLl9jZG5Vcmw7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChvcHRpb24uX2NkblVybCAmJiAhb3B0aW9uLl9kY0lkKSB7XHJcbiAgICAgICAgICAgICAgICBvcHRpb24udXJsID0gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwobXlDb25maWcuTE9DQUxfRENfSUQsIG9wdGlvbi5fY2RuVXJsKSArIG9wdGlvbi51cmw7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgb3B0aW9uLl9jZG5Vcmw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICBmb3JtLmFjdGlvbiA9IG9wdGlvbi51cmw7XHJcbiAgICAgICAgZm9ybS5tZXRob2QgPSBvcHRpb24ubWV0aG9kIHx8ICdQT1NUJztcclxuXHJcbiAgICAgICAgZm9yICh2YXIgbmFtZSBpbiBvcHRpb24ucGFyYW0pIHtcclxuICAgICAgICAgICAgdmFyIGlucHV0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKTtcclxuICAgICAgICAgICAgaW5wdXQudHlwZSA9ICdoaWRkZW4nO1xyXG4gICAgICAgICAgICBpbnB1dC5uYW1lID0gbmFtZTtcclxuICAgICAgICAgICAgaW5wdXQudmFsdWUgPSBvcHRpb24ucGFyYW1bbmFtZV07XHJcbiAgICAgICAgICAgIGZvcm0uYXBwZW5kQ2hpbGQoaW5wdXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChmb3JtKTtcclxuICAgICAgICBmb3JtLnN1Ym1pdCgpO1xyXG4gICAgICAgIGFuZ3VsYXIuZWxlbWVudChmb3JtKS5yZW1vdmUoKTtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLmZpbGVWaWV3Rm9yTW9iaWxlID0gZnVuY3Rpb24ob3B0aW9uLCBoZWFkZXJIaWRlKSB7XHJcblxyXG4gICAgICAgIGlmIChteUNvbmZpZy5hcHBsaWNhdGlvbklkICE9PSAzKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeXtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2FwcFN0YXRpY0NvbnRlbnRWZXJzaW9uJywgd2luZG93LnN0YXRpY0NvbnRlbnRWZXJzaW9uKTtcclxuICAgICAgICB9IGNhdGNoKGVycil7fVxyXG5cclxuICAgICAgICBpZiAob3B0aW9uLnBhcmFtKSB7XHJcbiAgICAgICAgICAgIG9wdGlvbi5wYXJhbS5hcHBsaWNhdGlvbklkID0gMztcclxuICAgICAgICAgICAgb3B0aW9uLnBhcmFtLmlvcyA9IHRydWU7XHJcbiAgICAgICAgICAgIG9wdGlvbi5wYXJhbS5pc0FuZHJvaWQgPSB0cnVlO1xyXG4gICAgICAgICAgICBvcHRpb24ucGFyYW0uaXNOZXdVSSA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgJGZpbGVWaWV3UG9ydCA9IGFuZ3VsYXIuZWxlbWVudChcIiNmaWxlVmlld1BvcnRcIik7XHJcbiAgICAgICAgJGZpbGVWaWV3UG9ydC5yZW1vdmVDbGFzcyhcImNsb3NlXCIpLmFkZENsYXNzKFwib3BlblwiKTtcclxuXHJcblxyXG4gICAgICAgICRmaWxlVmlld1BvcnQuZmluZChcImJ1dHRvbi5jbG9zZVwiKVswXS5vbmNsaWNrID0gZnVuY3Rpb24oZSkge1xyXG4gICAgICAgICAgICAkZmlsZVZpZXdQb3J0LnJlbW92ZUNsYXNzKFwib3BlblwiKS5hZGRDbGFzcyhcImNsb3NlXCIpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgICQoXCIjbXNnV2luZG93XCIpLnJlbW92ZSgpO1xyXG4gICAgICAgIHZhciBmb3JtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZm9ybScpO1xyXG4gICAgICAgIGFuZ3VsYXIuZWxlbWVudChcIiNmaWxlVmlld1BvcnRCb2R5XCIpLmFwcGVuZCgnPGlmcmFtZSBpZD1cIm1zZ1dpbmRvd1wiIG5hbWU9XCJtc2dXaW5kb3dcIiBzdHlsZT1cIndpZHRoOjEwMCU7IGhlaWdodDoxMDAlOyBib3JkZXI6IG5vbmU7IGJhY2tncm91bmQ6IHdoaXRlO1wiID48L2lmcmFtZT4nKTtcclxuICAgICAgICBmb3JtLnRhcmdldCA9IFwibXNnV2luZG93XCI7XHJcbiAgICAgICAgJGZpbGVWaWV3UG9ydC5maW5kKFwiZGl2Lm1vZGFsLWhlYWRlclwiKS5oaWRlKCk7XHJcblxyXG4gICAgICAgIC8vZm9ybS50YXJnZXQgPSBvcHRpb24udGFyZ2V0IHx8ICdfYmxhbmsnO1xyXG5cclxuICAgICAgICBpZiAob3B0aW9uLl9kY0lkKSB7XHJcbiAgICAgICAgICAgIG9wdGlvbi51cmwgPSBtYW5hZ2VEYXRhQ2VudGVyLmdldFVybChvcHRpb24uX2RjSWQpICsgb3B0aW9uLnVybDtcclxuICAgICAgICAgICAgZGVsZXRlIG9wdGlvbi5fZGNJZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvcm0uYWN0aW9uID0gb3B0aW9uLnVybDtcclxuICAgICAgICBmb3JtLm1ldGhvZCA9IG9wdGlvbi5tZXRob2QgfHwgJ1BPU1QnO1xyXG5cclxuICAgICAgICBmb3IgKHZhciBuYW1lIGluIG9wdGlvbi5wYXJhbSkge1xyXG4gICAgICAgICAgICB2YXIgaW5wdXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpO1xyXG4gICAgICAgICAgICBpbnB1dC50eXBlID0gJ2hpZGRlbic7XHJcbiAgICAgICAgICAgIGlucHV0Lm5hbWUgPSBuYW1lO1xyXG4gICAgICAgICAgICBpbnB1dC52YWx1ZSA9IG9wdGlvbi5wYXJhbVtuYW1lXTtcclxuICAgICAgICAgICAgZm9ybS5hcHBlbmRDaGlsZChpbnB1dCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGZvcm0pO1xyXG4gICAgICAgIGZvcm0uc3VibWl0KCk7XHJcbiAgICAgICAgYW5ndWxhci5lbGVtZW50KGZvcm0pLnJlbW92ZSgpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEZldGNoIGN1c3RvbSBvYmplY3QgdGVtcGxhdGUgbGlzdFxyXG4gICAgICogQHBhcmFtIHtmbn0gY2FsbGJhY2tcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwcm9qZWN0SWRcclxuICAgICAqL1xyXG4gICAgYXBpLmdldEN1c3RvbU9iamVjdFRlbXBsYXRlTGlzdCA9IGZ1bmN0aW9uKGNhbGxiYWNrLCBjdXN0b21PYmplY3RDb250ZXh0SWQsIHByb2plY3RJZCkge1xyXG4gICAgICAgIHZhciBjdXN0b21PYmplY3RUZW1wbGF0ZXMgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkdFVF9DVVNUT01fT0JKRUNUX1RFTVBMQVRFX0xJU1QsXHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIGN1c3RvbU9iamVjdDogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIHByb2plY3RJZDogcHJvamVjdElkIHx8IG15Q29uZmlnLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21PYmplY3RDb250ZXh0SWQ6IGN1c3RvbU9iamVjdENvbnRleHRJZCxcclxuICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcInRleHRcIixcclxuICAgICAgICAgICAgICAgICAgICBlbmFibGVkOiB0cnVlXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGN1c3RvbU9iamVjdFRlbXBsYXRlcy50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZGF0YSk7XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgICR3aW5kb3cuYWxlcnQoJ0Vycm9yIHdoaWxlIGZldGNoaW5nIEN1c3RvbSB0ZW1wbGF0ZXMhJyk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBjdXN0b21PYmplY3RUZW1wbGF0ZXM7XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogZmV0Y2ggdGhlIHBlcm1pc3Npb24gZm9yIHZpZXcgZm9ybVxyXG4gICAgICogQHBhcmFtIHtmbn0gY2FsbGJhY2tcclxuICAgICAqIEBwYXJhbSB7Ym9sZWFufSByZWZyZXNoXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gcHJvamVjdElkXHJcbiAgICAgKi9cclxuICAgIHZhciB2aWV3UGVybWlzc2lvbiA9IHVuZGVmaW5lZDtcclxuICAgIGFwaS5nZXRWaWV3UGVybWlzc2lvbiA9IGZ1bmN0aW9uKGNhbGxiYWNrLCByZWZyZXNoLCBwcm9qZWN0SWQsIG9mZmxpbmVUeXBlKSB7XHJcblxyXG4gICAgICAgIHZhciB0aGVuID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHZpZXdQZXJtaXNzaW9uLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgdmlld1Blcm1pc3Npb24gPSBkYXRhO1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZGF0YSk7XHJcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgICAgICAgICAgJHdpbmRvdy5hbGVydChsYW5nLmdldChcInBlcm1pc3Npb24tY2hlY2stZmFpbGVkXCIpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXJlZnJlc2ggJiYgdmlld1Blcm1pc3Npb24pIHtcclxuICAgICAgICAgICAgaWYgKG15Q29uZmlnLmlzT2ZmbGluZU1vZGUgfHwgdmlld1Blcm1pc3Npb24uYWJvcnQpIHtcclxuICAgICAgICAgICAgICAgIHRoZW4oKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHZpZXdQZXJtaXNzaW9uKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2aWV3UGVybWlzc2lvbiA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuREFTSEJPQVJEX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIGFjdGlvbl9pZDogYXBpQ29uZmlnLkdFVF9VU0VSX0FQUExJQ0FUSU9OX1BSSVZJTEVHRVMsXHJcbiAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IHByb2plY3RJZCB8fCBteUNvbmZpZy5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiBteUNvbmZpZy5pc09mZmxpbmVNb2RlID8gb2ZmbGluZVR5cGUgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGVuKCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5nZXRVc2VyU2hhcmVQZXJtaXNzaW9uID0gZnVuY3Rpb24ob2JqZWN0SWQsIG9iamVjdFR5cGVJZCwgY2FsbGJhY2spIHtcclxuICAgICAgICB2YXIgcGVybWlzc2lvbkNoZWNrZXIgPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogd2luZG93LmFzaXRlV29ya3NTZXJ2aWNlVVJMICsgYXBpQ29uZmlnLkdFVF9VU0VSX1NIQVJFX1BFUk1JU1NJT04sXHJcbiAgICAgICAgICAgIGFTZXNzaW9uSUQ6IHdpbmRvd1snVVNQJ11bJ2FTZXNzaW9uSWQnXSxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgcHJvamVjdElkOiBteUNvbmZpZy5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICBvYmplY3RJZDogb2JqZWN0SWQsXHJcbiAgICAgICAgICAgICAgICBvYmplY3RUeXBlSWQ6IG9iamVjdFR5cGVJZFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHBlcm1pc3Npb25DaGVja2VyLnRoZW4oZnVuY3Rpb24ocGVybWlzc2lvbkRhdGEpIHtcclxuICAgICAgICAgICAgdmFyIGZpbHRlckZvckNvbW1lbnRBbmRWaWV3RmlsZSA9IHBlcm1pc3Npb25EYXRhLmFzaXRld29ya3NGZWF0dXJlQ29uZmlnLmZpbHRlcihcclxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkYXRhLm9wZXJhdGlvbklkID09PSBhcGlDb25maWcuQURSSVZFX0ZJTEVfUEVSTUlTU0lPTi5WSUVXX0ZJTEUgfHwgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEub3BlcmF0aW9uSWQgPT09IGFwaUNvbmZpZy5BRFJJVkVfRklMRV9QRVJNSVNTSU9OLkNSRUFURV9DT01NRU5UIHx8IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLm9wZXJhdGlvbklkID09PSBhcGlDb25maWcuQURSSVZFX0ZJTEVfUEVSTUlTU0lPTi5ET1dOTE9BRF9GSUxFO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLy9TZXQgcGVybWlzc2lvbiBiYXNlZCBvbiBvdGhlciBwYXJhbWV0ZXIgaWYgYXNpdGUgd29ya3MgZmVhdHVyZSBjb25maWcgaXMgZW1wdHlcclxuICAgICAgICAgICAgaWYoIWZpbHRlckZvckNvbW1lbnRBbmRWaWV3RmlsZS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGZpbHRlckZvckNvbW1lbnRBbmRWaWV3RmlsZS5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICBvcGVyYXRpb25JZDogYXBpQ29uZmlnLkFEUklWRV9GSUxFX1BFUk1JU1NJT04uVklFV19GSUxFLFxyXG4gICAgICAgICAgICAgICAgICAgIGlzQWxsb3dlZDogcGVybWlzc2lvbkRhdGEuaXNPd25lciB8fCBwZXJtaXNzaW9uRGF0YS5wZXJtaXNzaW9uVHlwZUlkICE9IGFwaUNvbmZpZy5TSEFSRV9QRVJNSVNTSU9OLk5PTkVcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgZmlsdGVyRm9yQ29tbWVudEFuZFZpZXdGaWxlLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdGlvbklkOiBhcGlDb25maWcuQURSSVZFX0ZJTEVfUEVSTUlTU0lPTi5DUkVBVEVfQ09NTUVOVCxcclxuICAgICAgICAgICAgICAgICAgICBpc0FsbG93ZWQ6IHBlcm1pc3Npb25EYXRhLmlzT3duZXIgfHwgKHBlcm1pc3Npb25EYXRhLnBlcm1pc3Npb25UeXBlSWQgIT0gYXBpQ29uZmlnLlNIQVJFX1BFUk1JU1NJT04uVklFV0VSICYmIHBlcm1pc3Npb25EYXRhLnBlcm1pc3Npb25UeXBlSWQgIT0gYXBpQ29uZmlnLlNIQVJFX1BFUk1JU1NJT04uTk9ORSlcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgIFxyXG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhmaWx0ZXJGb3JDb21tZW50QW5kVmlld0ZpbGUpO1xyXG4gICAgICAgIH0sIGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhbe1xyXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uSWQ6IGFwaUNvbmZpZy5BRFJJVkVfRklMRV9QRVJNSVNTSU9OLlZJRVdfRklMRSxcclxuICAgICAgICAgICAgICAgIGlzQWxsb3dlZDogZmFsc2VcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uSWQ6IGFwaUNvbmZpZy5BRFJJVkVfRklMRV9QRVJNSVNTSU9OLkNSRUFURV9DT01NRU5ULFxyXG4gICAgICAgICAgICAgICAgaXNBbGxvd2VkOiBmYWxzZVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBvcGVyYXRpb25JZDogYXBpQ29uZmlnLkFEUklWRV9GSUxFX1BFUk1JU1NJT04uRE9XTkxPQURfRklMRSxcclxuICAgICAgICAgICAgICAgIGlzQWxsb3dlZDogZmFsc2VcclxuICAgICAgICAgICAgfV0pO1xyXG4gICAgICAgICAgICAkd2luZG93LmFsZXJ0KGxhbmcuZ2V0KFwicGVybWlzc2lvbi1jaGVjay1mYWlsZWRcIikpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZmV0Y2ggdGhlIHBlcm1pc3Npb24gZm9yIHZpZXcgZm9ybVxyXG4gICAgICogQHBhcmFtIHtmbn0gY2FsbGJhY2tcclxuICAgICAqIEBwYXJhbSB7Ym9sZWFufSByZWZyZXNoXHJcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gcHJvamVjdElkXHJcbiAgICAgKi9cclxuICAgIGFwaS5nZXRVc2VyQWNjZXNzRm9yTXVsdGlQcm9qZWN0ID0gZnVuY3Rpb24oY2FsbGJhY2ssIHByb2plY3RJZHMpIHtcclxuICAgICAgICB2YXIgbXVsdGlQcm9qUGVybWlzc2lvbiA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuREFTSEJPQVJEX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIGFjdGlvbl9pZDogYXBpQ29uZmlnLkdFVF9VU0VSX0FQUExJQ0FUSU9OX1BSSVZJTEVHRVNfTVVMVEksXHJcbiAgICAgICAgICAgICAgICBwcm9qZWN0SWRzOiBwcm9qZWN0SWRzXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgbXVsdGlQcm9qUGVybWlzc2lvbi50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZGF0YSk7XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgICR3aW5kb3cuYWxlcnQobGFuZy5nZXQoXCJwZXJtaXNzaW9uLWNoZWNrLWZhaWxlZFwiKSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBtdWx0aVByb2pQZXJtaXNzaW9uO1xyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgZm9ybVNwZWNpZmljUGVybWlzc2lvbiA9IHt9O1xyXG4gICAgLy8gY2FsbCB0byBmZXRjaCBzcGVjaWZpYyBmb3JtIHBlcm1pc3Npb25cclxuICAgIGFwaS5nZXRGb3JtU3BlY2lmaWNQZXJtaXNzaW9uID0gZnVuY3Rpb24ocGFyYW0sIGNhbGxiYWNrLCByZWZyZXNoKSB7XHJcbiAgICAgICAgdmFyIHRoZW4gPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgZm9ybVNwZWNpZmljUGVybWlzc2lvbltwYXJhbS5mb3JtVHlwZUlkc10udGhlbihmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICBkYXRhID0gZGF0YVswXSB8fCBkYXRhIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgZm9ybVNwZWNpZmljUGVybWlzc2lvbltwYXJhbS5mb3JtVHlwZUlkc10gPSBkYXRhO1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZGF0YSk7XHJcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgICAgICAgICAgJHdpbmRvdy5hbGVydChsYW5nLmdldChcInBlcm1pc3Npb24tY2hlY2stZmFpbGVkXCIpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXJlZnJlc2ggJiYgZm9ybVNwZWNpZmljUGVybWlzc2lvbltwYXJhbS5mb3JtVHlwZUlkc10pIHtcclxuICAgICAgICAgICAgaWYgKGZvcm1TcGVjaWZpY1Blcm1pc3Npb25bcGFyYW0uZm9ybVR5cGVJZHNdLmFib3J0KSB7XHJcbiAgICAgICAgICAgICAgICB0aGVuKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhmb3JtU3BlY2lmaWNQZXJtaXNzaW9uW3BhcmFtLmZvcm1UeXBlSWRzXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9ybVNwZWNpZmljUGVybWlzc2lvbltwYXJhbS5mb3JtVHlwZUlkc10gPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkRBU0hCT0FSRF9DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICBhY3Rpb25faWQ6IGFwaUNvbmZpZy5HRVRfRk9STV9UWVBFX1BSSVZJTEVHRVMsXHJcbiAgICAgICAgICAgICAgICBmb3JtVHlwZUlkczogcGFyYW0uZm9ybVR5cGVJZHMsIC8vbXlDb25maWcuaExhdGVzdEZvcm1UeXBlLFxyXG4gICAgICAgICAgICAgICAgcGFyYW1Qcm9qZWN0SWRzOiBwYXJhbS5wYXJhbVByb2plY3RJZHMgLy9teUNvbmZpZy5wcm9qZWN0SWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGVuKCk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogZmV0Y2ggdGhlIHdvcmtzcGFjZSBzZXR0aW5nXHJcbiAgICAgKiBAcGFyYW0ge2ZufSBjYWxsYmFja1xyXG4gICAgICogQHBhcmFtIHtib2xlYW59IHJlZnJlc2hcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwcm9qZWN0SWRcclxuICAgICAqL1xyXG4gICAgdmFyIHdvcmtzcGFjZVNldHRpbmdzID0ge307XHJcbiAgICBhcGkuZ2V0V29ya3NwYWNlU2V0dGluZ3MgPSBmdW5jdGlvbihjYWxsYmFjaywgcmVmcmVzaCwgcHJvamVjdElkKSB7XHJcbiAgICAgICAgcHJvamVjdElkID0gcHJvamVjdElkIHx8IG15Q29uZmlnLnByb2plY3RJZDtcclxuICAgICAgICB2YXIgdGhlbiA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB3b3Jrc3BhY2VTZXR0aW5nc1twcm9qZWN0SWRdLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgd29ya3NwYWNlU2V0dGluZ3NbcHJvamVjdElkXSA9IGRhdGE7XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayh3b3Jrc3BhY2VTZXR0aW5nc1twcm9qZWN0SWRdKTtcclxuICAgICAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgICAgICAkd2luZG93LmFsZXJ0KCdFcnJvciB3aGlsZSBmZXRjaGluZyBXb3Jrc3BhY2UgU2V0dGluZ3MhJyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFyZWZyZXNoICYmIHdvcmtzcGFjZVNldHRpbmdzW3Byb2plY3RJZF0pIHtcclxuICAgICAgICAgICAgaWYgKHdvcmtzcGFjZVNldHRpbmdzW3Byb2plY3RJZF0uYWJvcnQpIHtcclxuICAgICAgICAgICAgICAgIHRoZW4oKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHdvcmtzcGFjZVNldHRpbmdzW3Byb2plY3RJZF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHdvcmtzcGFjZVNldHRpbmdzW3Byb2plY3RJZF0gPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkdFVF9XT1JLU1BBQ0VfU0VUVElORyxcclxuICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgcHJvamVjdElkOiBwcm9qZWN0SWQsXHJcbiAgICAgICAgICAgICAgICB1c2VySWQ6IG15Q29uZmlnLlVTUC51c2VySURcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGVuKCk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogZmV0Y2ggdGhlIHdvcmtzcGFjZSBzZXR0aW5nXHJcbiAgICAgKiBAcGFyYW0ge2ZufSBjYWxsYmFja1xyXG4gICAgICogQHBhcmFtIHtib2xlYW59IHJlZnJlc2hcclxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBwcm9qZWN0SWRcclxuICAgICAqL1xyXG4gICAgdmFyIHdvcmtzcGFjZVNldHRpbmdzRm9yTWFya1VwcyA9IHt9O1xyXG4gICAgYXBpLmdldFdvcmtzcGFjZVNldHRpbmdzRm9yTWFya3VwcyA9IGZ1bmN0aW9uKGNhbGxiYWNrLCByZWZyZXNoLCBwcm9qZWN0SWQpIHtcclxuICAgICAgICBwcm9qZWN0SWQgPSBwcm9qZWN0SWQgfHwgbXlDb25maWcucHJvamVjdElkO1xyXG4gICAgICAgIHZhciB0aGVuID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHdvcmtzcGFjZVNldHRpbmdzRm9yTWFya1Vwc1twcm9qZWN0SWRdLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHNldHRpbmdzID0ge307XHJcbiAgICAgICAgICAgICAgICB2YXIgc2V0dGluZ19vcHRpb24gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlQcm9wOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIjBcIjogXCJibG9ja1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCIxXCI6IFwiYmxvY2tcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiMlwiOiBcIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjBcIjogeyBcImNoZWNrZWRcIjogZmFsc2UsIFwiZGlzYWJsZWRcIjogZmFsc2UgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCIxXCI6IHsgXCJjaGVja2VkXCI6IHRydWUsIFwiZGlzYWJsZWRcIjogdHJ1ZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjJcIjogeyBcImNoZWNrZWRcIjogZmFsc2UgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0dGluZ0lkID0gZGF0YS5jaGVja0NyZWF0ZUNvbW1lbnRQcmVmO1xyXG4gICAgICAgICAgICAgICAgc2V0dGluZ3Muc2F2ZUFzTWFya3VwT3B0aW9ucyA9IHNldHRpbmdfb3B0aW9uW3NldHRpbmdJZF07XHJcbiAgICAgICAgICAgICAgICBzZXR0aW5ncy5kaXNwbGF5TWFya3VwQ2hlY2tCb3ggPSBzZXR0aW5nX29wdGlvblsnZGlzcGxheVByb3AnXVtzZXR0aW5nSWRdO1xyXG4gICAgICAgICAgICAgICAgc2V0dGluZ3Muc2V0dGluZ0lkID0gc2V0dGluZ0lkO1xyXG4gICAgICAgICAgICAgICAgc2V0dGluZ3MuY2hlY2tQcmludERvY3VtZW50UG9pID0gZGF0YS5jaGVja1ByaW50RG9jdW1lbnRQb2k7XHJcbiAgICAgICAgICAgICAgICBzZXR0aW5ncy5jaGVja1ByaW50RG9jdW1lbnRTdGF0dXMgPSBkYXRhLmNoZWNrUHJpbnREb2N1bWVudFN0YXR1cztcclxuICAgICAgICAgICAgICAgIHNldHRpbmdzLmNoZWNrVmlld0RvY3VtZW50UG9pID0gZGF0YS5jaGVja1ZpZXdEb2N1bWVudFBvaTtcclxuICAgICAgICAgICAgICAgIHNldHRpbmdzLmNoZWNrVmlld0RvY3VtZW50U3RhdHVzID0gZGF0YS5jaGVja1ZpZXdEb2N1bWVudFN0YXR1cztcclxuXHJcbiAgICAgICAgICAgICAgICB3b3Jrc3BhY2VTZXR0aW5nc0Zvck1hcmtVcHNbcHJvamVjdElkXSA9IHNldHRpbmdzO1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2sod29ya3NwYWNlU2V0dGluZ3NGb3JNYXJrVXBzW3Byb2plY3RJZF0pO1xyXG4gICAgICAgICAgICB9LCBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICAgICAgICAgICR3aW5kb3cuYWxlcnQoJ0Vycm9yIHdoaWxlIGZldGNoaW5nIFdvcmtzcGFjZSBTZXR0aW5ncyEnKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXJlZnJlc2ggJiYgd29ya3NwYWNlU2V0dGluZ3NGb3JNYXJrVXBzW3Byb2plY3RJZF0pIHtcclxuICAgICAgICAgICAgaWYgKHdvcmtzcGFjZVNldHRpbmdzRm9yTWFya1Vwc1twcm9qZWN0SWRdLmFib3J0KSB7XHJcbiAgICAgICAgICAgICAgICB0aGVuKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayh3b3Jrc3BhY2VTZXR0aW5nc0Zvck1hcmtVcHNbcHJvamVjdElkXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgd29ya3NwYWNlU2V0dGluZ3NGb3JNYXJrVXBzW3Byb2plY3RJZF0gPSBhcGkuYWpheCh7XHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkdFVF9XT1JLU1BBQ0VfU0VUVElOR19NQVJLVVAsXHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHByb2plY3RJZDogcHJvamVjdElkLFxyXG4gICAgICAgICAgICAgICAgdXNlcklkOiBteUNvbmZpZy5VU1AudXNlcklEXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhlbigpO1xyXG4gICAgfTtcclxuXHJcbiAgICB2YXIgaW5mb3JtUGFyZW50V2luVGltZW91dCA9IHVuZGVmaW5lZDtcclxuICAgIGFwaS5pbmZvcm1QYXJlbnRXaW4gPSBmdW5jdGlvbih1cGRhdGVEZXRhaWwpIHtcclxuICAgICAgICAkdGltZW91dC5jYW5jZWwoaW5mb3JtUGFyZW50V2luVGltZW91dCk7XHJcbiAgICAgICAgaW5mb3JtUGFyZW50V2luVGltZW91dCA9ICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBteUNvbmZpZy5pc0Zyb21GaWxlVmlld0ZvckRvbWFpbiAhPSB1bmRlZmluZWQgJiYgbXlDb25maWcuaXNGcm9tRmlsZVZpZXdGb3JEb21haW4gPT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBhbmd1bGFyLmVsZW1lbnQoJyNpZnJtUmVmcmVzaFBhcmVudCcpLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciB1cGRhdGVEZXRhaWxTdHIgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4gdXBkYXRlRGV0YWlsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZURldGFpbFN0ci5wdXNoKGtleSArIFwiX1wiICsgdXBkYXRlRGV0YWlsW2tleV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVEZXRhaWxTdHIgPSB1cGRhdGVEZXRhaWxTdHIuam9pbihcIi0tXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBpZnJhbWUgPSBhbmd1bGFyLmVsZW1lbnQoJzxpZnJhbWUgaWQ9XCJpZnJtUmVmcmVzaFBhcmVudFwiIHNyYz1cIicgKyBiYXNlVXJsICsgYXBpQ29uZmlnLlZJRVdFUl9QQVJFTlRfUkVGUkVTSCArIFwiP3E9X1wiICsgbmV3IERhdGUoKS5nZXRUaW1lKCkgKyBcIiZ1cGRhdGVQYXJhbT1cIiArIHVwZGF0ZURldGFpbFN0ciArICdcIiB3aWR0aD1cIjBcIiBoZWlnaHQ9XCIwXCIgc3R5bGU9XCJwb3NpdGlvbjogYWJzb2x1dGU7IGJvcmRlcjogbm9uZTsgbWFyZ2luOiAwO1wiPicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGFuZ3VsYXIuZWxlbWVudChcImJvZHlcIikuYXBwZW5kKGlmcmFtZSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFwaS5pc0lFKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAkd2luZG93Lm9wZW5lci51cGRhdGVUYWJsZURhdGEuaW5pdFVwZGF0ZUJ5UHJpbWFyeUtleSh1cGRhdGVEZXRhaWwpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAkd2luZG93Lm9wZW5lci5wb3N0TWVzc2FnZShcInVwZGF0ZURhdGFcIiArIGFuZ3VsYXIudG9Kc29uKHVwZGF0ZURldGFpbCksIFwiKlwiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB9LCAyMDApO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkucmV0dXJuTm9uQWthbWFpVVJMID0gZnVuY3Rpb24ocGFyYW0sIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgdmFyIHhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuREFTSEJPQVJEX0NPTlRST0xMRVIsXHJcbiAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIHVzZXJJZDogbXlDb25maWcuVVNQLnVzZXJJRCxcclxuICAgICAgICAgICAgICAgIHByb2plY3RJZDogcGFyYW0ucHJvamVjdElkLFxyXG4gICAgICAgICAgICAgICAgZXh0cmE6IEpTT04uc3RyaW5naWZ5KHBhcmFtLnJldmlzaW9uSWRzKSxcclxuICAgICAgICAgICAgICAgIGFjdGlvbl9pZDogYXBpQ29uZmlnLkNIRUNLX0ZPUl9BS0FNQUlfRE9XTkxPQURfTElNSVRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHhoci50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZGF0YSlcclxuICAgICAgICB9LCBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICAgICAgJHdpbmRvdy5hbGVydChsYW5nLmdldChcInNvbWV0aGluZy13ZW50LXdyb25nXCIpKVxyXG4gICAgICAgIH0pXHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5kb3dubG9hZEZpbGUgPSBmdW5jdGlvbihmaWxlLCBwcm9qZWN0SWQsIGV4dHJhKSB7XHJcbiAgICAgICAgYXBpLnJldHVybk5vbkFrYW1haVVSTCh7XHJcbiAgICAgICAgICAgIHByb2plY3RJZDogZmlsZS5wcm9qZWN0SWQsXHJcbiAgICAgICAgICAgIHJldmlzaW9uSWRzOiB7XHJcbiAgICAgICAgICAgICAgICByZXZpc2lvbnM6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV2aXNpb25JZDogZmlsZS5yZXZpc2lvbklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGRjSWQ6IGZpbGUuZGNJZCxcclxuICAgICAgICAgICAgICAgICAgICBwcm9qZWN0SWQ6IGZpbGUucHJvamVjdElkLFxyXG4gICAgICAgICAgICAgICAgICAgIGlzTG9jazogXCJcIlxyXG4gICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgdmFyIHVybCA9IG15Q29uZmlnLmRvd25sb2FkU2VydmljZVVSTDtcclxuXHJcbiAgICAgICAgICAgIGlmIChkYXRhLmlzTGltaXRFeGlzdCkge1xyXG4gICAgICAgICAgICAgICAgdXJsID0gZGF0YS5ub25DRE5Eb3dubG9hZFVybFxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdXJsID0gbWFuYWdlRGF0YUNlbnRlci5nZXRVcmwobXlDb25maWcuTE9DQUxfRENfSUQsIHVybCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHVybCArPSBhcGlDb25maWcuRE9XTkxPQURfU0lOR0xFX0RPQ1VNRU5UICsgXCI/cmV2aXNpb25JZD1cIiArIGZpbGUucmV2aXNpb25JZCArIFwiJnByb2plY3RJZD1cIiArIGZpbGUucHJvamVjdElkO1xyXG4gICAgICAgICAgICBpZiAoZXh0cmEpIHtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBleHRyYSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChleHRyYS5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCArPSAnJicgKyBrZXkgKyAnPScgKyBleHRyYVtrZXldO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBqUXVlcnkuZmlsZURvd25sb2FkKHVybCwge1xyXG4gICAgICAgICAgICAgICAgcHJlcGFyaW5nTWVzc2FnZUh0bWw6IGxhbmcuZ2V0KFwicGVycGFyaW5nLXlvdXItZmlsZXMtcGxlYXNlLXdhaXRcIiksXHJcbiAgICAgICAgICAgICAgICBmYWlsTWVzc2FnZUh0bWw6IGxhbmcuZ2V0KFwicHJvYmxlbS1kb3dubG9hZGluZy15b3VyLWZpbGUtcGxlYXNlLXRyeS1hZ2FpblwiKVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuZG93bmxvYWRBdHRhY2htZW50RmlsZSA9IGZ1bmN0aW9uKGZpbGUsIHppcFVybCkge1xyXG4gICAgICAgIHZhciB1cmwgPSBtYW5hZ2VEYXRhQ2VudGVyLmdldFVybChteUNvbmZpZy5MT0NBTF9EQ19JRCwgbXlDb25maWcuZG93bmxvYWRTZXJ2aWNlVVJMKTtcclxuICAgICAgICB1cmwgKz0gemlwVXJsIHx8IGFwaUNvbmZpZy5ET1dOTE9BRF9JTlRFUk5BTF9BVFRBQ0hNRU5UX0NPTlRST0xMRVIgKyBcIj9wcm9qZWN0SWQ9XCIgKyBmaWxlLnByb2plY3RJZCArIFwiJmF0dGFjaG1lbnRJZD1cIiArIGZpbGUuYXR0YWNobWVudElkO1xyXG4gICAgICAgIGpRdWVyeS5maWxlRG93bmxvYWQodXJsLCB7XHJcbiAgICAgICAgICAgIHByZXBhcmluZ01lc3NhZ2VIdG1sOiBsYW5nLmdldChcInBlcnBhcmluZy15b3VyLWZpbGVzLXBsZWFzZS13YWl0XCIpLFxyXG4gICAgICAgICAgICBmYWlsTWVzc2FnZUh0bWw6IGxhbmcuZ2V0KFwicHJvYmxlbS1kb3dubG9hZGluZy15b3VyLWZpbGUtcGxlYXNlLXRyeS1hZ2FpblwiKVxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkudmlld0ZpbGUgPSBmdW5jdGlvbihwYXJhbSwgZGNJZCwgdGFyZ2V0KSB7XHJcbiAgICAgICAgaWYgKG15Q29uZmlnLmFwcGxpY2F0aW9uSWQpIHtcclxuICAgICAgICAgICAgcGFyYW0uYXBwbGljYXRpb25JZCA9IG15Q29uZmlnLmFwcGxpY2F0aW9uSWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciB0YXJnZXQgPSB0YXJnZXQgfHwgJ19GSUxFX1ZJRVdFUl8nICsgcGFyYW0ucmV2aXNpb25JZFxyXG4gICAgICAgIGFwaS5zdWJtaXRGb3JtKHtcclxuICAgICAgICAgICAgdGFyZ2V0OiB0YXJnZXQsXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkZJTEVfVklFV19QQUdFLFxyXG4gICAgICAgICAgICBwYXJhbTogcGFyYW0sXHJcbiAgICAgICAgICAgIF9kY0lkOiBkY0lkXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgYXBpLmdldExvY2tlZEFjdGl2aXRpZXNPYmplY3QgPSBmdW5jdGlvbihzdHIpIHtcclxuICAgICAgICBpZiAoIXN0ciB8fCBzdHIgPT0gLTEpIHtcclxuICAgICAgICAgICAgc3RyID0gJyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHZhciBsb2NrZWRPYmplY3RzID0gc3RyLnRvU3RyaW5nKCkuc3BsaXQoJywnKTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBhdHRyaWJ1dGVzOiAobG9ja2VkT2JqZWN0cy5pbmRleE9mKGFwaUNvbmZpZy5BQ1RJVklUWV9DT05TVEFOVC5BQ1RJVklUWV9FRElUX0FUVFJJQlVURVMudG9TdHJpbmcoKSkgIT0gLTEpLFxyXG4gICAgICAgICAgICBkaXN0cmlidXRpb246IChsb2NrZWRPYmplY3RzLmluZGV4T2YoYXBpQ29uZmlnLkFDVElWSVRZX0NPTlNUQU5ULkFDVElWSVRZX0ZJTEVfRElTVFJJQlVUSU9OLnRvU3RyaW5nKCkpICE9IC0xKSxcclxuICAgICAgICAgICAgc3RhdHVzOiAobG9ja2VkT2JqZWN0cy5pbmRleE9mKGFwaUNvbmZpZy5BQ1RJVklUWV9DT05TVEFOVC5BQ1RJVklUWV9VUERBVEVfU1RBVFVTLnRvU3RyaW5nKCkpICE9IC0xKSxcclxuICAgICAgICAgICAgY29tbWVudDogKGxvY2tlZE9iamVjdHMuaW5kZXhPZihhcGlDb25maWcuQUNUSVZJVFlfQ09OU1RBTlQuQUNUSVZJVFlfQUREX0NPTU1FTlQudG9TdHJpbmcoKSkgIT0gLTEpLFxyXG4gICAgICAgICAgICByZXZpc2lvblVwbG9hZDogKGxvY2tlZE9iamVjdHMuaW5kZXhPZihhcGlDb25maWcuQUNUSVZJVFlfQ09OU1RBTlQuQUNUSVZJVFlfUkVWSVNJT05fVVBMT0FELnRvU3RyaW5nKCkpICE9IC0xKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGFwaS5vcGVuRGlzY3Vzc2lvbiA9IGZ1bmN0aW9uKHBhcmFtLCBkY0lkKSB7XHJcbiAgICAgICAgcGFyYW0uY2FsbEZvciA9IFwiY29tbWVudHNcIjtcclxuXHJcbiAgICAgICAgYXBpLnN1Ym1pdEZvcm0oe1xyXG4gICAgICAgICAgICB0YXJnZXQ6ICdfVklFV0VSXycgKyBwYXJhbS5yZXZpc2lvbklkLFxyXG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5GSUxFX1ZJRVdfUEFHRSxcclxuICAgICAgICAgICAgcGFyYW06IHBhcmFtLFxyXG4gICAgICAgICAgICBfZGNJZDogZGNJZFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkub3BlbkFwcCA9IGZ1bmN0aW9uKHBhcmFtLCBkY0lkKSB7XHJcbiAgICAgICAgdmFyIHRhcmdldCA9ICdfVklFV19GT1JNXycgKyBwYXJhbS5jb21tSWQ7XHJcbiAgICAgICAgaWYgKHRhcmdldCA9PSB3aW5kb3cubmFtZSkge1xyXG4gICAgICAgICAgICB0YXJnZXQgPSAnX2JsYW5rJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGFwaS5zdWJtaXRGb3JtKHtcclxuICAgICAgICAgICAgdGFyZ2V0OiB0YXJnZXQsXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLlZJRVdfRk9STSxcclxuICAgICAgICAgICAgcGFyYW06IHBhcmFtLFxyXG4gICAgICAgICAgICBfZGNJZDogZGNJZFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkub3BlbkF0dGFjaG1lbnQgPSBmdW5jdGlvbihwYXJhbSwgZGNJZCkge1xyXG4gICAgICAgIHZhciBpc01zZ0lkWmVybyA9IChwYXJhbS5tc2dJZCAmJiBwYXJhbS5tc2dJZC5zcGxpdCgnJCQnKVswXSA9PSAnMCcpO1xyXG4gICAgICAgIGlmIChpc01zZ0lkWmVybyAmJiBwYXJhbS5jb21taW5nRnJvbSAhPSBcImN1c3RvbU9iamVjdFwiKSB7XHJcbiAgICAgICAgICAgIHBhcmFtLmNvbW1pbmdGcm9tID0gXCJpbnRlcm5hbEF0dGFjaG1lbnRcIjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChhcGkuaXNNb2JpbGUoKSAmJiBteUNvbmZpZy5hcHBsaWNhdGlvbklkID09IDMpIHtcclxuICAgICAgICAgICAgYXBpLmZpbGVWaWV3Rm9yTW9iaWxlKHtcclxuICAgICAgICAgICAgICAgIHRhcmdldDogJ19zZWxmJyxcclxuICAgICAgICAgICAgICAgIHVybDogYXBpQ29uZmlnLkFUVEFDSF9GSUxFX1ZJRVdFUl9QUkVGRVJFTkNFLFxyXG4gICAgICAgICAgICAgICAgcGFyYW06IHBhcmFtLFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcclxuICAgICAgICAgICAgICAgIF9kY0lkOiBwYXJhbS5kY0lkIHx8IGRjSWRcclxuICAgICAgICAgICAgfSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBtZXRob2QgPSBwYXJhbS5tZXRob2QgfHwgJ0dFVCc7XHJcbiAgICAgICAgZGVsZXRlIHBhcmFtLm1ldGhvZDtcclxuXHJcbiAgICAgICAgaWYod2luZG93WydwbGF0Zm9ybU5hbWUnXSkge1xyXG4gICAgICAgICAgICAvLyBEaXNhYmxlZCBhdHRhY2htZW50IHZpZXcgdGVtcG9yYXJ5IGZvciBleHRlcm5hbCBwbGF0Zm9ybXMgaS5lIG5hdmlzd29ya1xyXG4gICAgICAgICAgICAvLyB3aW5kb3dbJ29wZW5FeHRlcm5hbFVybCddKHtcclxuICAgICAgICAgICAgLy8gICAgIGVuZFBvaW50OiBhcGlDb25maWcuQVRUQUNIX0ZJTEVfVklFV0VSX1BSRUZFUkVOQ0UsXHJcbiAgICAgICAgICAgIC8vICAgICBwYXJhbXM6IHBhcmFtXHJcbiAgICAgICAgICAgIC8vIH0pO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBhcGkuc3VibWl0Rm9ybSh7XHJcbiAgICAgICAgICAgIHRhcmdldDogJ19GSUxFX1ZJRVdFUl8nICsgKHBhcmFtLmF0dGFjaG1lbnRJZCB8fCBwYXJhbS5yZXZpc2lvbklkKSxcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuQVRUQUNIX0ZJTEVfVklFV0VSX1BSRUZFUkVOQ0UsXHJcbiAgICAgICAgICAgIHBhcmFtOiBwYXJhbSxcclxuICAgICAgICAgICAgX2RjSWQ6IGRjSWRcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLmNoZWNrQWN0aW9uVmFsaWRhdGlvbiA9IGZ1bmN0aW9uKHBhcmFtKSB7XHJcbiAgICAgICAgdmFyIHNlbERhdGEgPSBudWxsLFxyXG4gICAgICAgICAgICBpc1ZhbGlkYXRlID0gdHJ1ZTtcclxuICAgICAgICBpZiAoIXBhcmFtIHx8ICFwYXJhbS5zZWxlY3RlZExpc3QgfHwgIXBhcmFtLnNlbGVjdGVkTGlzdC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhcmFtLnNlbGVjdGVkTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBzZWxEYXRhID0gcGFyYW0uc2VsZWN0ZWRMaXN0W2ldO1xyXG4gICAgICAgICAgICBpZiAoc2VsRGF0YS5hY3Rpb25zICYmIHNlbERhdGEuYWN0aW9ucy5zcGxpdCgnJCQnKVswXSAhPT0gcGFyYW0udmFsaWRhdGVBY3Rpb24gJiYgIXNlbERhdGEuZGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgaXNWYWxpZGF0ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpc1ZhbGlkYXRlO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuZW5jb2RlSHRtbCA9IGZ1bmN0aW9uKHZhbHVlKSB7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoLycvZywgXCImYXBvcztcIik7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zYW5pdGl6ZUh0bWwgPSBmdW5jdGlvbihodG1sKSB7XHJcbiAgICAgICAgaWYoIWh0bWwpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGh0bWw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBTYW5pdGl6ZSB1bnRydXN0ZWQgSFRNTCAodG8gcHJldmVudCBYU1MpIHdpdGggYSBjb25maWd1cmF0aW9uIHNwZWNpZmllZCBieSBhIFdoaXRlbGlzdC5cclxuICAgICAgICByZXR1cm4gZmlsdGVyWFNTKGh0bWwsIHtcclxuICAgICAgICAgICAgc3RyaXBJZ25vcmVUYWdCb2R5OiBbJ3NjcmlwdCddLFxyXG4gICAgICAgICAgICBzdHJpcElnbm9yZVRhZzogdHJ1ZSwgYWxsb3dDb21tZW50VGFnOiBmYWxzZVxyXG4gICAgICAgIH0pXHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zYW5pdGl6ZUNvbW1lbnRzID0gZnVuY3Rpb24oY29tbWVudHMpIHtcclxuICAgICAgICBpZighY29tbWVudHMgfHwgIWNvbW1lbnRzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICByZXR1cm4gY29tbWVudHM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgY29tbWVudHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdmFyIG1zZ1ZPID0gY29tbWVudHNbaV0gJiYgY29tbWVudHNbaV0ubWVzc2FnZVZPO1xyXG4gICAgICAgICAgICBpZighbXNnVk8pIHtcclxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBmb3IodmFyIGogPSAwOyBqIDwgbXNnVk8ubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGlmKG1zZ1ZPW2pdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbXNnVk9bal0uY29tbWVudF90ZXh0ID0gYXBpLnNhbml0aXplSHRtbChtc2dWT1tqXS5jb21tZW50X3RleHQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBjb21tZW50cztcclxuICAgIH07XHJcblxyXG4gICAgYXBpLnJldHVybkVycm9yQ29kZSA9IGZ1bmN0aW9uKHhocikge1xyXG4gICAgICAgIHZhciBkaXYgPSBhbmd1bGFyLmVsZW1lbnQoXCI8ZGl2PlwiKTtcclxuICAgICAgICBkaXYuYXBwZW5kKHhoci5kYXRhKTtcclxuXHJcbiAgICAgICAgdmFyIGVycm9yRG9tID0gZGl2LmZpbmQoXCIjZXJyb3JDb2RlXCIpO1xyXG4gICAgICAgIGlmIChlcnJvckRvbS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGVycm9yRG9tLmh0bWwoKS50cmltKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gXCJcIjtcclxuICAgIH07XHJcblxyXG4gICAgYXBpLnNob3dTZXJ2ZXJFcnJNc2cgPSBmdW5jdGlvbih4aHIpIHtcclxuICAgICAgICBpZiAobXlDb25maWcuYXBwbGljYXRpb25JZCA9PSAyKSB7XHJcbiAgICAgICAgICAgIHZhciBpc09ubGluZSA9IHF0T2JqZWN0LnN5c3RlbU9ubGluZUNhbGxCYWNrKCk7XHJcbiAgICAgICAgICAgIGlmICghaXNPbmxpbmUpIHtcclxuICAgICAgICAgICAgICAgIGFwaS5zaG93TmV0d29ya01zZygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAobXlDb25maWcuYXBwbGljYXRpb25JZCAhPSAyICYmICFuYXZpZ2F0b3Iub25MaW5lKSB7XHJcbiAgICAgICAgICAgIGFwaS5zaG93TmV0d29ya01zZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCF4aHIgfHwgeGhyLnN0YXR1cyA9PSAtMSkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB4aHIuZXJyb3JDb2RlID0gYXBpLnJldHVybkVycm9yQ29kZSh4aHIpO1xyXG4gICAgICAgIE5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgICAgIHRpdGxlOiBsYW5nLmdldChcInNlcnZlci1lcnJvclwiKSArICc6ICcgKyAoeGhyLmVycm9yVGl0bGUgfHwgJycpLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiAnPGRpdiBjbGFzcz1cInRleHQtbGFyZ2VcIj4nICtcclxuICAgICAgICAgICAgICAgIGxhbmcuZ2V0KCdlcnJvci13aGlsZS1wcm9jZXNzaW5nLXlvdXItcmVxdWVzdCcpICsgJzogJyArIHhoci5lcnJvckNvZGUgK1xyXG4gICAgICAgICAgICAgICAgJzwvZGl2PidcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBhcGkuc2hvd05ldHdvcmtNc2cgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICBOb3RpZmljYXRpb24uY2xlYXJBbGwoKTtcclxuICAgICAgICBOb3RpZmljYXRpb24uZXJyb3Ioe1xyXG4gICAgICAgICAgICB0aXRsZTogbGFuZy5nZXQoXCJuZXR3b3JrLWVycm9yXCIpLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiAnPGRpdiBjbGFzcz1cInRleHQtbGFyZ2VcIj4nICtcclxuICAgICAgICAgICAgICAgIGxhbmcuZ2V0KCdub3QtYWJsZS10by1jb25uZWN0LXNlcnZlcicpICtcclxuICAgICAgICAgICAgICAgICc8L2Rpdj4nXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG4gICAgYXBpLnNob3dXYXJuaW5nTXNnID0gZnVuY3Rpb24ob3B0KSB7XHJcbiAgICAgICAgTm90aWZpY2F0aW9uLndhcm5pbmcoe1xyXG4gICAgICAgICAgICB0aXRsZTogb3B0LnRpdGxlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiAnPGRpdiBjbGFzcz1cInRleHQtbGFyZ2VcIj4nICsgb3B0Lm1zZyArICc8L2Rpdj4nXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5zb3J0QXJyYXkgPSBmdW5jdGlvbihhcnJheSwga2V5LCBvcmRlcikge1xyXG4gICAgICAgIG9yZGVyID0gKG9yZGVyKSA/IG9yZGVyIDogXCJhc2NcIjtcclxuICAgICAgICBpZiAob3JkZXIgPT0gXCJhc2NcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gYXJyYXkuc29ydChmdW5jdGlvbihhLCBiKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgeCA9IGFba2V5XTtcclxuICAgICAgICAgICAgICAgIHZhciB5ID0gYltrZXldO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICgoeCA8IHkpID8gLTEgOiAoKHggPiB5KSA/IDEgOiAwKSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAob3JkZXIgPT0gXCJkZXNjXCIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhcnJheS5zb3J0KGZ1bmN0aW9uKGEsIGIpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgeCA9IGFba2V5XTtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgeSA9IGJba2V5XTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKCh5IDwgeCkgPyAtMSA6ICgoeSA+IHgpID8gMSA6IDApKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgdmFyIG5hdGl2ZU5vdGlmaWNhdGlvbiA9ICR3aW5kb3cuTm90aWZpY2F0aW9uO1xyXG5cclxuICAgIGFwaS53aW5kb3dOb3RpZmljYXRpb24gPSBmdW5jdGlvbihkYXRhLCBjYWxsYmFjaykge1xyXG5cclxuICAgICAgICBpZiAoIW5hdGl2ZU5vdGlmaWNhdGlvbikge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfSBlbHNlIGlmIChuYXRpdmVOb3RpZmljYXRpb24ucGVybWlzc2lvbiA9PT0gJ2RlbmllZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH0gZWxzZSBpZiAobmF0aXZlTm90aWZpY2F0aW9uLnBlcm1pc3Npb24gPT09ICdkZWZhdWx0Jykge1xyXG4gICAgICAgICAgICBuYXRpdmVOb3RpZmljYXRpb24ucmVxdWVzdFBlcm1pc3Npb24oZnVuY3Rpb24ocGVybWlzc2lvbikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKG5hdGl2ZU5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uID09PSAnZ3JhbnRlZCcgJiYgZGF0YSkge1xyXG4gICAgICAgICAgICB2YXIgbm90aWZpY2F0aW9uT2JqID0gbmV3IG5hdGl2ZU5vdGlmaWNhdGlvbihkYXRhLnRpdGxlLCBkYXRhLm9wdGlvbik7XHJcbiAgICAgICAgICAgIGlmIChub3RpZmljYXRpb25PYmopIHtcclxuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbk9iai5vbmNsaWNrID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2soZGF0YS5wYXJhbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gbm90aWZpY2F0aW9uT2JqO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhcGkudGltZUFnbyA9IGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICB2YXIgc3RyaW5ncyA9IHtcclxuICAgICAgICAgICAgICAgIHN1ZmZpeEFnbzogXCJhZ29cIixcclxuICAgICAgICAgICAgICAgIHNlY29uZHM6IFwiZmV3IHNlY29uZHNcIixcclxuICAgICAgICAgICAgICAgIG1pbnV0ZXM6IFwiJWQgbWludXRlc1wiLFxyXG4gICAgICAgICAgICAgICAgaG91cnM6IFwiJWQgaG91cnNcIixcclxuICAgICAgICAgICAgICAgIGRheXM6IFwiJWQgZGF5c1wiLFxyXG4gICAgICAgICAgICAgICAgbW9udGhzOiBcIiVkIG1vbnRoc1wiLFxyXG4gICAgICAgICAgICAgICAgeWVhcnM6IFwiJWQgeWVhcnNcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBkYXRlRGlmZmVyZW5jZSA9IChuZXcgRGF0ZSgpLmdldFRpbWUoKSkgLSBkYXRhLnRpbWUsXHJcbiAgICAgICAgICAgIHdvcmRzLFxyXG4gICAgICAgICAgICBzZWNvbmRzID0gTWF0aC5hYnMoZGF0ZURpZmZlcmVuY2UpIC8gMTAwMCxcclxuICAgICAgICAgICAgbWludXRlcyA9IHNlY29uZHMgLyA2MCxcclxuICAgICAgICAgICAgaG91cnMgPSBtaW51dGVzIC8gNjAsXHJcbiAgICAgICAgICAgIGRheXMgPSBob3VycyAvIDI0LFxyXG4gICAgICAgICAgICB5ZWFycyA9IGRheXMgLyAzNjUsXHJcbiAgICAgICAgICAgIHN1ZmZpeCA9IHN0cmluZ3Muc3VmZml4QWdvO1xyXG5cclxuICAgICAgICB2YXIgc3Vic3RpdHV0ZSA9IGZ1bmN0aW9uKHN0cmluZ09yRnVuY3Rpb24sIG51bWJlciwgc3RyaW5ncykge1xyXG4gICAgICAgICAgICBudW1iZXIgPSBNYXRoLmZsb29yKG51bWJlcik7XHJcbiAgICAgICAgICAgIHJldHVybiBzdHJpbmdPckZ1bmN0aW9uLnJlcGxhY2UoLyVkL2ksIG51bWJlcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB3b3JkcyA9IHNlY29uZHMgPCA2MCAmJiBzdWJzdGl0dXRlKHN0cmluZ3Muc2Vjb25kcywgc2Vjb25kcywgc3RyaW5ncykgfHxcclxuICAgICAgICAgICAgbWludXRlcyA8IDYwICYmIHN1YnN0aXR1dGUoc3RyaW5ncy5taW51dGVzLCBtaW51dGVzLCBzdHJpbmdzKSB8fFxyXG4gICAgICAgICAgICBob3VycyA8IDI0ICYmIHN1YnN0aXR1dGUoc3RyaW5ncy5ob3VycywgaG91cnMsIHN0cmluZ3MpIHx8XHJcbiAgICAgICAgICAgIGRheXMgPCAzMCAmJiBzdWJzdGl0dXRlKHN0cmluZ3MuZGF5cywgZGF5cywgc3RyaW5ncykgfHxcclxuICAgICAgICAgICAgZGF5cyA8IDM2NSAmJiBzdWJzdGl0dXRlKHN0cmluZ3MubW9udGhzLCAoZGF5cyAvIDMwKSwgc3RyaW5ncykgfHxcclxuICAgICAgICAgICAgc3Vic3RpdHV0ZShzdHJpbmdzLnllYXJzLCB5ZWFycywgc3RyaW5ncyk7XHJcbiAgICAgICAgcmV0dXJuICh3b3JkcyArICcgJyArIHN1ZmZpeCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXBpLmdldEV4dCA9IGZ1bmN0aW9uKG5hbWUpIHtcclxuICAgICAgICByZXR1cm4gbmFtZS5zdWJzdHIobmFtZS5sYXN0SW5kZXhPZignLicpICsgMSk7XHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICBhcGkuaXNaaXAgPSBmdW5jdGlvbihuYW1lKSB7XHJcbiAgICAgICAgaWYoIW5hbWUgfHwgdHlwZW9mIG5hbWUgIT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGV4dCA9IGFwaS5nZXRFeHQobmFtZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICBpZihbJ3ppcCcsICdyYXInXS5pbmRleE9mKGV4dCkgPiAtMSkge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfTtcclxuXHJcbiAgICBhcGkuZ2V0RmlsZUV4dEltYWdlID0gZnVuY3Rpb24odHlwZSkge1xyXG4gICAgICAgIHZhciBtYXAgPSB7XHJcbiAgICAgICAgICAgICdwZGYnOiAncGRmJyxcclxuICAgICAgICAgICAgJzAwMCc6ICcwMDAnLFxyXG4gICAgICAgICAgICAnOTA2JzogJzkwNicsXHJcbiAgICAgICAgICAgICc5MDcnOiAnOTA2JyxcclxuICAgICAgICAgICAgJ2R3Zyc6ICdkd2cnLFxyXG4gICAgICAgICAgICAnZHdnX21mJzogJ2R3Z19tZicsXHJcbiAgICAgICAgICAgICdkeGYnOiAnZHhmJyxcclxuICAgICAgICAgICAgJ2R3Zic6ICdkd2YnLFxyXG4gICAgICAgICAgICAnZHgnOiAnZHgnLFxyXG4gICAgICAgICAgICAnZGcnOiAnZGcnLFxyXG4gICAgICAgICAgICAncHJ0JzogJ3BydCcsXHJcbiAgICAgICAgICAgICdybGMnOiAncmxjJyxcclxuICAgICAgICAgICAgJ2NnbSc6ICdjZ20nLFxyXG4gICAgICAgICAgICAnZWRtJzogJ2VkbScsXHJcbiAgICAgICAgICAgICdnMyc6ICdjdHgnLFxyXG4gICAgICAgICAgICAnZzQnOiAnY3R4JyxcclxuICAgICAgICAgICAgJ2NnNCc6ICdjdHgnLFxyXG4gICAgICAgICAgICAncm5sJzogJ3JubCcsXHJcbiAgICAgICAgICAgICdjbWknOiAnY21pJyxcclxuICAgICAgICAgICAgJ21pJzogJ21pJyxcclxuICAgICAgICAgICAgJ3BsdCc6ICdwbHQnLFxyXG4gICAgICAgICAgICAnaWdzJzogJ2lncycsXHJcbiAgICAgICAgICAgICdpZ2VzJzogJ2lncycsXHJcbiAgICAgICAgICAgICdkZ24nOiAnZGduJyxcclxuICAgICAgICAgICAgJ2Rnbl9tZic6ICdkZ25fbWYnLFxyXG4gICAgICAgICAgICAnY2l0JzogJ2NpdCcsXHJcbiAgICAgICAgICAgICdybGUnOiAncmxlJyxcclxuICAgICAgICAgICAgJ212cyc6ICdtdnMnLFxyXG4gICAgICAgICAgICAnZHNuJzogJ2RzbicsXHJcbiAgICAgICAgICAgICdzbGRkcncnOiAnc2xkJyxcclxuICAgICAgICAgICAgJ21vdCc6ICdtb3QnLFxyXG4gICAgICAgICAgICAnY2FsJzogJ2NhbCcsXHJcbiAgICAgICAgICAgICdncDQnOiAnY2FsJyxcclxuICAgICAgICAgICAgJ21pbCc6ICdjYWwnLFxyXG4gICAgICAgICAgICAnZGN4JzogJ2RjeCcsXHJcbiAgICAgICAgICAgICdlZGMnOiAnZWRjJyxcclxuICAgICAgICAgICAgJ2Z0ayc6ICdmdGsnLFxyXG4gICAgICAgICAgICAnaXNvJzogJ2lzbycsXHJcbiAgICAgICAgICAgICdqcGcnOiAnanBnJyxcclxuICAgICAgICAgICAgJ2pwZWcnOiAnanBnJyxcclxuICAgICAgICAgICAgJ3BjeCc6ICdwY3gnLFxyXG4gICAgICAgICAgICAnZGlmJzogJ2RpZicsXHJcbiAgICAgICAgICAgICd0aWYnOiAndGlmJyxcclxuICAgICAgICAgICAgJ3RpZmYnOiAndGlmJyxcclxuICAgICAgICAgICAgJ2JtcCc6ICdibXAnLFxyXG4gICAgICAgICAgICAnY2RyJzogJ2NkcicsXHJcbiAgICAgICAgICAgICdzaHcnOiAnc2h3JyxcclxuICAgICAgICAgICAgJ2RiZic6ICdkYmYnLFxyXG4gICAgICAgICAgICAneGR3JzogJ3hkdycsXHJcbiAgICAgICAgICAgICd4bHMnOiAneGxzJyxcclxuICAgICAgICAgICAgJ2ZheCc6ICdmYXgnLFxyXG4gICAgICAgICAgICAnaHRtbCc6ICdodG1sJyxcclxuICAgICAgICAgICAgJ2h0bSc6ICdodG0nLFxyXG4gICAgICAgICAgICAnaW5pJzogJ2luaScsXHJcbiAgICAgICAgICAgICdwcHMnOiAncHBzJyxcclxuICAgICAgICAgICAgJ3BwdCc6ICdwcHQnLFxyXG4gICAgICAgICAgICAnbXBwJzogJ21wcCcsXHJcbiAgICAgICAgICAgICd2c2QnOiAndnNkJyxcclxuICAgICAgICAgICAgJ2RvYyc6ICdkb2MnLFxyXG4gICAgICAgICAgICAnd2RiJzogJ3dkYicsXHJcbiAgICAgICAgICAgICdwNjUnOiAncDY1JyxcclxuICAgICAgICAgICAgJ3diMSc6ICd3YjEnLFxyXG4gICAgICAgICAgICAnd2IyJzogJ3diMicsXHJcbiAgICAgICAgICAgICd3cTEnOiAnd3ExJyxcclxuICAgICAgICAgICAgJ3J0Zic6ICdydGYnLFxyXG4gICAgICAgICAgICAnc2FtJzogJ3NhbScsXHJcbiAgICAgICAgICAgICd3cmknOiAnd3JpJyxcclxuICAgICAgICAgICAgJ3dwNSc6ICd3cDUnLFxyXG4gICAgICAgICAgICAnd3A2JzogJ3dwNicsXHJcbiAgICAgICAgICAgICd3cGQnOiAnd3BkJyxcclxuICAgICAgICAgICAgJ3dwZic6ICd3cGYnLFxyXG4gICAgICAgICAgICAnd3MnOiAnd3MnLFxyXG4gICAgICAgICAgICAnZ2lmJzogJ2dpZicsXHJcbiAgICAgICAgICAgICdsb2cnOiAndHh0JyxcclxuICAgICAgICAgICAgJ3R4dCc6ICd0eHQnLFxyXG4gICAgICAgICAgICAnZGxsJzogJ2RsbCcsXHJcbiAgICAgICAgICAgICd6aXAnOiAnemlwJyxcclxuICAgICAgICAgICAgJ2Jhayc6ICdiYWsnLFxyXG4gICAgICAgICAgICAndXJsJzogJ3VybCcsXHJcbiAgICAgICAgICAgICdpY28nOiAnaWNvJyxcclxuICAgICAgICAgICAgJ2F2aSc6ICdhdmknLFxyXG4gICAgICAgICAgICAnY2FiJzogJ2NhYicsXHJcbiAgICAgICAgICAgICdjZGYnOiAnY2RmJyxcclxuICAgICAgICAgICAgJ2NobSc6ICdjaG0nLFxyXG4gICAgICAgICAgICAnY3NzJzogJ2NzcycsXHJcbiAgICAgICAgICAgICdqcyc6ICdqcycsXHJcbiAgICAgICAgICAgICdtc2cnOiAnbXNnJyxcclxuICAgICAgICAgICAgJ2RvdCc6ICdkb3QnLFxyXG4gICAgICAgICAgICAnZW1sJzogJ2VtbCcsXHJcbiAgICAgICAgICAgICdkb2N4JzogJ2RvY3gnLFxyXG4gICAgICAgICAgICAnZG90eCc6ICdkb3R4JyxcclxuICAgICAgICAgICAgJ3Bwc3gnOiAncHBzeCcsXHJcbiAgICAgICAgICAgICdwcHR4JzogJ3BwdHgnLFxyXG4gICAgICAgICAgICAneGxzeCc6ICd4bHN4JyxcclxuICAgICAgICAgICAgJ2ttbCc6ICdrbWwnLFxyXG4gICAgICAgICAgICAna216JzogJ2tteicsXHJcbiAgICAgICAgICAgICdhc3gnOiAnYXN4JyxcclxuICAgICAgICAgICAgJ3dheCc6ICd3YXgnLFxyXG4gICAgICAgICAgICAnbTN1JzogJ20zdScsXHJcbiAgICAgICAgICAgICd3cGwnOiAnd3BsJyxcclxuICAgICAgICAgICAgJ3d2eCc6ICd3dngnLFxyXG4gICAgICAgICAgICAnd214JzogJ3dteCcsXHJcbiAgICAgICAgICAgICdkdnInOiAnbXM9ZHZyLW1zJyxcclxuICAgICAgICAgICAgJ21pZCc6ICdtaWQnLFxyXG4gICAgICAgICAgICAncm1pJzogJ3JtaScsXHJcbiAgICAgICAgICAgICdtaWRpJzogJ21pZGknLFxyXG4gICAgICAgICAgICAnbXBlZyc6ICdtcGVnJyxcclxuICAgICAgICAgICAgJ21wZyc6ICdtcGcnLFxyXG4gICAgICAgICAgICAnbTF2JzogJ20xdicsXHJcbiAgICAgICAgICAgICdtcDInOiAnbXAyJyxcclxuICAgICAgICAgICAgJ21wYSc6ICdtcGEnLFxyXG4gICAgICAgICAgICAnbXBlJzogJ21wZScsXHJcbiAgICAgICAgICAgICdtcGMnOiAnbXBjJyxcclxuICAgICAgICAgICAgJ21wJzogJz1tcCsnLFxyXG4gICAgICAgICAgICAnb2dnJzogJ29nZycsXHJcbiAgICAgICAgICAgICdvZ20nOiAnb2dtJyxcclxuICAgICAgICAgICAgJ3NweCc6ICdzcHgnLFxyXG4gICAgICAgICAgICAnd2F2JzogJ3dhdicsXHJcbiAgICAgICAgICAgICdzbmQnOiAnc25kJyxcclxuICAgICAgICAgICAgJ2F1JzogJ2F1JyxcclxuICAgICAgICAgICAgJ2FpZic6ICdhaWYnLFxyXG4gICAgICAgICAgICAnYWlmYyc6ICdhaWZjJyxcclxuICAgICAgICAgICAgJ2FpZmYnOiAnYWlmZicsXHJcbiAgICAgICAgICAgICd3bWEnOiAnd21hJyxcclxuICAgICAgICAgICAgJ21wMyc6ICdtcDMnLFxyXG4gICAgICAgICAgICAnbXA0JzogJ21wNCcsXHJcbiAgICAgICAgICAgICdhc2YnOiAnYXNmJyxcclxuICAgICAgICAgICAgJ3dtJzogJ3dtJyxcclxuICAgICAgICAgICAgJ3dtZCc6ICd3bWQnLFxyXG4gICAgICAgICAgICAnd212JzogJ3dtdicsXHJcbiAgICAgICAgICAgICdkaXZ4JzogJ2RpdngnLFxyXG4gICAgICAgICAgICAnZGl2JzogJ2RpdicsXHJcbiAgICAgICAgICAgICdkYXQnOiAnZGF0JyxcclxuICAgICAgICAgICAgJ2R2JzogJ2R2JyxcclxuICAgICAgICAgICAgJ3ZvYic6ICd2b2InLFxyXG4gICAgICAgICAgICAncmEnOiAncmEnLFxyXG4gICAgICAgICAgICAncmFtJzogJ3JhbScsXHJcbiAgICAgICAgICAgICdybSc6ICdybScsXHJcbiAgICAgICAgICAgICdybXZiJzogJ3JtdmInLFxyXG4gICAgICAgICAgICAnbW92JzogJ21vdicsXHJcbiAgICAgICAgICAgICdxdCc6ICdxdCcsXHJcbiAgICAgICAgICAgICczZ3AnOiAnM2dwJyxcclxuICAgICAgICAgICAgJ2FhYyc6ICdhYWMnLFxyXG4gICAgICAgICAgICAnYWMzJzogJ2FjMycsXHJcbiAgICAgICAgICAgICdhbXInOiAnYW1yJyxcclxuICAgICAgICAgICAgJ2V4ZSc6ICdleGUnLFxyXG4gICAgICAgICAgICAnZmxhJzogJ2ZsYScsXHJcbiAgICAgICAgICAgICdmbHYnOiAnZmx2JyxcclxuICAgICAgICAgICAgJ3N3Zic6ICdzd2YnLFxyXG4gICAgICAgICAgICAncDMnOiAncDMnLFxyXG4gICAgICAgICAgICAncDNjJzogJ3AzYycsXHJcbiAgICAgICAgICAgICdwcngnOiAncHJ4JyxcclxuICAgICAgICAgICAgJ3N0eCc6ICdzdHgnLFxyXG4gICAgICAgICAgICAnbXBzJzogJ21wcycsXHJcbiAgICAgICAgICAgICdkJzogJ2QnLFxyXG4gICAgICAgICAgICAnbndjJzogJ253YycsXHJcbiAgICAgICAgICAgICdud2QnOiAnbndkJyxcclxuICAgICAgICAgICAgJ253Zic6ICdud2YnLFxyXG4gICAgICAgICAgICAncG5nJzogJ3BuZycsXHJcbiAgICAgICAgICAgICdza3AnOiAnc2twJyxcclxuICAgICAgICAgICAgJ3NtYyc6ICdzbWMnLFxyXG4gICAgICAgICAgICAnbWRiJzogJ21kYicsXHJcbiAgICAgICAgICAgICc3eic6ICc3eicsXHJcbiAgICAgICAgICAgICdhY2UnOiAnYWNlJyxcclxuICAgICAgICAgICAgJ2FyYyc6ICdhcmMnLFxyXG4gICAgICAgICAgICAnYXJqJzogJ2FyaicsXHJcbiAgICAgICAgICAgICdiNjQnOiAnYjY0JyxcclxuICAgICAgICAgICAgJ2JoeCc6ICdiaHgnLFxyXG4gICAgICAgICAgICAnYnoyJzogJ2J6MicsXHJcbiAgICAgICAgICAgICdkYXInOiAnZGFyJyxcclxuICAgICAgICAgICAgJ2d6JzogJ2d6JyxcclxuICAgICAgICAgICAgJ2d6aXAnOiAnZ3ppcCcsXHJcbiAgICAgICAgICAgICdocXgnOiAnaHF4JyxcclxuICAgICAgICAgICAgJ2ljZSc6ICdpY2UnLFxyXG4gICAgICAgICAgICAnamFyJzogJ2phcicsXHJcbiAgICAgICAgICAgICdsemgnOiAnbHpoJyxcclxuICAgICAgICAgICAgJ21pbSc6ICdtaW0nLFxyXG4gICAgICAgICAgICAncGt6aXAnOiAncGt6aXAnLFxyXG4gICAgICAgICAgICAncmFyJzogJ3JhcicsXHJcbiAgICAgICAgICAgICdzZmFyayc6ICdzZmFyaycsXHJcbiAgICAgICAgICAgICdzaGFyJzogJ3NoYXInLFxyXG4gICAgICAgICAgICAndGFyJzogJ3RhcicsXHJcbiAgICAgICAgICAgICd0Z3onOiAndGd6JyxcclxuICAgICAgICAgICAgJ3R6JzogJ3R6JyxcclxuICAgICAgICAgICAgJ3V1JzogJ3V1JyxcclxuICAgICAgICAgICAgJ3V1ZSc6ICd1dWUnLFxyXG4gICAgICAgICAgICAnd2ltJzogJ3dpbScsXHJcbiAgICAgICAgICAgICd4YXInOiAneGFyJyxcclxuICAgICAgICAgICAgJ3h4ZSc6ICd4eGUnLFxyXG4gICAgICAgICAgICAneHNmJzogJ3hzZicsXHJcbiAgICAgICAgICAgICd4c24nOiAneHNuJyxcclxuICAgICAgICAgICAgJ3J2dCc6ICdydnQnLFxyXG4gICAgICAgICAgICAncHRzJzogJ3B0cycsXHJcbiAgICAgICAgICAgICdwdHgnOiAncHR4JyxcclxuICAgICAgICAgICAgJ3BwdG0nOiAncHB0bScsXHJcbiAgICAgICAgICAgICdkd2Z4JzogJ2R3ZngnLFxyXG4gICAgICAgICAgICAnYXNuJzogJ2FzbicsXHJcbiAgICAgICAgICAgICdhbGwnOiAnYWxsJyxcclxuICAgICAgICAgICAgJ3dtZic6ICd3bWYnLFxyXG4gICAgICAgICAgICAncG90eCc6ICdwb3R4JyxcclxuICAgICAgICAgICAgJ2RvdG0nOiAnZG90bScsXHJcbiAgICAgICAgICAgICd4cHMnOiAneHBzJyxcclxuICAgICAgICAgICAgJ3BvdCc6ICdwb3QnLFxyXG4gICAgICAgICAgICAncHBzbSc6ICdwcHNtJyxcclxuICAgICAgICAgICAgJ3N2Zyc6ICdzdmcnLFxyXG4gICAgICAgICAgICAncHViJzogJ3B1YicsXHJcbiAgICAgICAgICAgICdwcGEnOiAncHBhJyxcclxuICAgICAgICAgICAgJ3hodG1sJzogJ3hodG1sJyxcclxuICAgICAgICAgICAgJ3hvZCc6ICd4b2QnLFxyXG4gICAgICAgICAgICAnb2R0Jzonb2R0JyxcclxuICAgICAgICAgICAgJ29kcyc6J29kcycsXHJcbiAgICAgICAgICAgICdjYWYnOidjYWYnLFxyXG4gICAgICAgICAgICAnb2dhJzonb2dhJyxcclxuICAgICAgICAgICAgJ200YSc6J200YScsXHJcbiAgICAgICAgICAgICdmbGFjJzonZmxhYycsXHJcbiAgICAgICAgICAgICdvcHVzJzonb3B1cycsXHJcbiAgICAgICAgICAgICdqZmlmJzonamZpZidcclxuICAgICAgICB9O1xyXG4gICAgICAgIHR5cGUgPSB0eXBlIHx8IFwiXCI7XHJcbiAgICAgICAgdHlwZSA9IHR5cGUudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICByZXR1cm4gKG1hcFt0eXBlXSB8fCAnbm9pY29uJyk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmV0dXJuIGV4dGVuc2lvbiB0eXBlIHdpc2UgTWFwXHJcbiAgICAgKi9cclxuICAgIGFwaS5nZXRGaWxlRXh0ZXNpb25zID0gZnVuY3Rpb24gKHR5cGUpIHtcclxuICAgICAgICB2YXIgbWFwID0ge1xyXG4gICAgICAgICAgICBpbWFnZTogW1wianBlZ1wiLCBcImpwZ1wiLCBcImdpZlwiLCBcInBuZ1wiLCBcImJtcFwiLCBcInBwbVwiLCBcInBnbVwiLCBcInBibVwiLCBcInBubVwiLCBcIndlYnBcIiwgXCJicGdcIiwgXCJpY29cIiwgXCJpbWdcIiwgXCJwZ2ZcIiwgXCJ4aXNmXCIsIFwid21mXCIsIFwiZW1mXCIsIFwidm1sXCIsIFwieHBzXCIsIFwiZHdnXCJdLFxyXG4gICAgICAgICAgICBhdWRpbzogW1wiYWFcdFwiLCBcImFhY1wiLCBcImFheFwiLCBcImFjdFwiLCBcImFpZmZcIiwgXCJhbXJcIiwgXCJhcGVcIiwgXCJhdVx0XCIsIFwiYXdiXCIsIFwiZGN0XCIsIFwiZHNzXCIsIFwiZHZmXCIsIFwiZmxhY1wiLCBcImdzbVwiLCBcImlrbGFcIiwgXCJpdnNcIiwgXCJtNGFcIiwgXCJtNGJcIiwgXCJtNHBcIiwgXCJtbWZcIiwgXCJtcDNcIiwgXCJtcGNcIiwgXCJtc3ZcIiwgXCJvZ2dcIiwgXCJvcHVzXCIsIFwicmEsXCIsIFwicmF3XCIsIFwic2xuXCIsIFwidHRhXCIsIFwidm94XCIsIFwid2F2XCIsIFwid21hXCIsIFwid3ZcdFwiLCBcIndlYm1cIiwgXCI4c3ZcIl0sXHJcbiAgICAgICAgICAgIHZpZGVvOiBbXCJ3ZWJtXCIsIFwibWt2XCIsIFwiZmx2XCIsIFwidm9iXCIsIFwib2d2XCIsIFwib2dnXCIsIFwiZHJjXCIsIFwibW5nXCIsIFwibW5nXCIsIFwiYXZpXCIsIFwibW92XCIsIFwicXRcIiwgXCJybVwiLCBcInl1dlwiLCBcInJtdmJcIiwgXCJhc2ZcIiwgXCJhbXZcIiwgXCJtcDRcIiwgXCJtNHBcIiwgXCJtNHZcIiwgXCJtcGdcIiwgXCJtcDJcIiwgXCJtcGVnXCIsIFwibXBlXCIsIFwibXB2XCIsIFwibTJ2XCIsIFwic3ZpXCIsIFwiM2dwXCIsIFwiM2cyXCIsIFwibXhmXCIsIFwicm9xXCIsIFwibnN2XCIsIFwiZjR2XCIsIFwiZjRwXCIsIFwiZjRhXCIsIFwiZjRiXCJdLFxyXG4gICAgICAgICAgICBjb2RlOiBbXCJhc3BcIiwgXCJqc3BcIiwgXCJqc1wiLCBcInhtbFwiLCBcImJhdFwiLCBcImNtZFwiLCBcImNsYXNzXCIsIFwiY3BwXCIsIFwiZGVmXCIsIFwiZGxsXCIsIFwiZHRkXCIsIFwiZXhlXCIsIFwiZm9udFwiLCBcImh0bWxcIiwgXCJodG1cIiwgXCJqYXZhXCIsIFwiY3NzXCIsIFwidHNcIiwgXCJqc29uXCJdLFxyXG4gICAgICAgICAgICBwb3dlcnBvaW50OiBbXCJwcHRcIiwgXCJwb3RcIiwgXCJwcHNcIiwgXCJwcHR4XCIsIFwicHB0bVwiLCBcInBvdHhcIiwgXCJwb3RtXCIsIFwicHBhbVwiLCBcInBwc3hcIiwgXCJwcHNtXCIsIFwic2xkeFwiLCBcInNsZG1cIl0sXHJcbiAgICAgICAgICAgIHdvcmQ6IFtcImRvY1wiLCBcImRvdFwiLCBcIndia1wiLCBcImRvY3hcIiwgXCJkb2NtXCIsIFwiZG90eFwiLCBcImRvdG1cIiwgXCJkb2NiXCJdLFxyXG4gICAgICAgICAgICB6aXA6IFtcInppcFwiLCBcImxpYlwiLCBcImphclwiLCBcIndhclwiLCBcImVhclwiLCBcImlzb1wiLCBcInJhclwiLCBcIjd6XCJdLFxyXG4gICAgICAgICAgICBleGNlbDogW1wieGxzXCIsIFwieGxzbVwiLCBcInhsdFwiLCBcInhsbVwiLCBcInhsdG1cIiwgXCJ4bHR4XCIsIFwieGxzeFwiLCBcInhsc2JcIiwgXCJ4bGFcIiwgXCJ4bGFtXCIsIFwieGxsXCIsIFwieGx3XCIsIFwiY3N2XCJdLFxyXG4gICAgICAgICAgICBwZGY6IFtcInBkZlwiXVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGUgJiYgbWFwW3R5cGVdKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBtYXBbdHlwZV07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbWFwO1xyXG4gICAgfTtcclxuXHJcbiAgICAvKipcclxuXHRcdCAqIEBkZXNjcmlwdGlvbiBhZGQgZmlsZSBleGVuc2lvbiBrZXkgaW4gdGhlIGRhdGFcclxuXHRcdCAqIEBwYXJhbSB7Kn0gYXR0YWNobWVudCBEYXRhXHJcblx0XHQgKiBAbWVtYmVyb2YgVGFibGVMaXN0aW5nQ29tcG9uZW50XHJcblx0XHQgKi9cclxuICAgIGFwaS5zZXRGaWxlRXh0SW5BdHRhY2ggPSBmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgYXR0YWNobWVudCA9IGRhdGFbaV07XHJcbiAgICAgICAgICAgIHZhciBmaWxlTmFtZSA9IGF0dGFjaG1lbnQuZmlsZU5hbWUgfHwgYXR0YWNobWVudC5GaWxlTmFtZSB8fCBcIlwiO1xyXG4gICAgICAgICAgICB2YXIgZmlsZVNpemUgPSBhdHRhY2htZW50LmZpbGVTaXplIHx8IGF0dGFjaG1lbnQuRmlsZVNpemU7XHJcbiAgICAgICAgICAgIGlmICghZmlsZU5hbWUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZmlsZVNpemUgIT09IFwic3RyaW5nXCIgfHwgZmlsZVNpemUuaW5kZXhPZignQicpID09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICBhdHRhY2htZW50LmZpbGVTaXplID0gYXR0YWNobWVudC5GaWxlU2l6ZSA9IChmaWxlU2l6ZSAvIDEwMjQgLyAxMDI0KS50b0ZpeGVkKDIpICsgJyBNQic7XHJcbiAgICAgICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGF0dGFjaG1lbnQuYXR0YWNoZWREYXRlICE9PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgdXNlcmZvcm1hdCA9IHdpbmRvd1snSU5JVF9KU1BfR0xPQkFMJ10uZm9ybWF0c0ZvckpxdWVyeUNhbGVuZGVyW3dpbmRvd1snVVNQJ10ubGFuZ3VhZ2VJZF07XHJcbiAgICAgICAgICAgICAgICBhdHRhY2htZW50LmF0dGFjaGVkRGF0ZSAmJiAoYXR0YWNobWVudC5hdHRhY2hlZERhdGUgPSBhcGkuZm9ybWF0RGF0ZSh1c2VyZm9ybWF0LCBuZXcgRGF0ZShhdHRhY2htZW50LmF0dGFjaGVkRGF0ZSkpKTtcclxuICAgICAgICAgICAgfSAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICB2YXIgc3BsaXRBcnJheSA9IGZpbGVOYW1lLnNwbGl0KCcuJyk7XHJcbiAgICAgICAgICAgIHZhciBleHQgPSBzcGxpdEFycmF5W3NwbGl0QXJyYXkubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgICAgIHZhciBleHRDbGFzcyA9IFwidGV4dFwiO1xyXG5cclxuICAgICAgICAgICAgdmFyIGV4dE9iaiA9IGFwaS5nZXRGaWxlRXh0ZXNpb25zKCk7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBleHRPYmopIHtcclxuICAgICAgICAgICAgICAgIGlmIChleHRPYmouaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBleHRBcnJheSA9IGV4dE9ialtrZXldO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChleHRBcnJheS5pbmRleE9mKGV4dCkgPiAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHRDbGFzcyA9IGtleTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGF0dGFjaG1lbnRbJ2ZpbGVFeHQnXSA9IGV4dENsYXNzO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgYXBpLmdldFNvcnRGaWxlU2l6ZSA9IGZ1bmN0aW9uKHNpemUpIHtcclxuICAgICAgICBzaXplID0gc2l6ZSB8fCAwO1xyXG4gICAgICAgIHZhciBzID0gTWF0aC5yb3VuZCgoKHNpemUgPiAoMTAyNCAqIDEwMjQpKSA/ICgoKHNpemUgKiAxMDApIC8gKDEwMjQgKiAxMDI0KSkgLyAxMDApIDogKCgoc2l6ZSAqIDEwMCkgLyAxMDI0KSAvIDEwMCkpKTtcclxuICAgICAgICBzICs9IChzaXplID4gMTAyNCAqIDEwMjQpID8gJyBNQicgOiAnIEtCJztcclxuXHJcbiAgICAgICAgcmV0dXJuIHM7XHJcbiAgICB9O1xyXG5cclxuICAgIGFwaS5vcGVuUmV2aWV3ID0gZnVuY3Rpb24oZGF0YSwgZXh0cmEpIHtcclxuICAgICAgICB2YXIgdXJsLCBwYXJhbSA9IHtcclxuXHRcdFx0ZGNJZDogZGF0YS5kY0lkLFxyXG5cdFx0XHRyZXZpc2lvbklkOiBkYXRhLnJldmlzaW9uSWQsXHJcblx0XHRcdGNhbGxGb3I6ICdyZXZpZXdzJyxcclxuXHRcdFx0cmV2aWV3SW5zdGFuY2VJZDogZGF0YS5jdXN0b21PYmplY3RJbnN0YW5jZUlkLFxyXG5cdFx0XHRyZXZpZXdDb21tZW50SWQ6IGRhdGEuY3VzdG9tT2JqZWN0Q29tbWVudElkLFxyXG5cdFx0XHRkb2N1bWVudFR5cGVJZDogZGF0YS5kb2NUeXBlSWQgfHwgZGF0YS5kb2N1bWVudFR5cGVJZCxcclxuXHRcdFx0aGFzT25saW5lVmlld2VyU3VwcG9ydDogZGF0YS5oYXNPbmxpbmVWaWV3ZXJTdXBwb3J0LFxyXG5cdFx0XHRpc0Zyb21GaWxlVmlld0ZvckRvbWFpbjogJ3RydWUnLFxyXG5cdFx0XHRpc0Zyb21GaWxlTGlzdGluZzogJ3RydWUnLFxyXG5cdFx0XHRwcm9qZWN0SWQ6IGRhdGEucHJvamVjdElkLFxyXG5cdFx0XHRpc0RyYWZ0OiBmYWxzZVxyXG5cdFx0fTtcclxuXHJcblx0XHR1cmwgPSBhcGlDb25maWcuRklMRV9WSUVXX1BBR0U7XHJcblx0XHRwYXJhbVsnZm9sZGVySWQnXSA9IGRhdGEuZm9sZGVySWQ7XHJcblx0XHRwYXJhbVsnZG9jdW1lbnRJZCddID0gZGF0YS5kb2N1bWVudElkIHx8IDA7XHJcblx0XHRwYXJhbVsndmlld2VySWQnXSA9IGRhdGEudmlld2VySWQgfHwgMDtcclxuXHJcblx0XHRpZihhcGkuaXNNb2JpbGUoKSAmJiBteUNvbmZpZy5hcHBsaWNhdGlvbklkID09IDMpe1xyXG5cdFx0XHRpZihteUNvbmZpZy5pc09mZmxpbmVNb2RlKXtcclxuXHRcdFx0XHRhcGkuc2VuZEV2ZW50VG9JcGFkKFwib2ZmbGluZUNvbW1lbnRBc3NvY2lhdGlvbkNsaWNrOlwiK0pTT04uc3RyaW5naWZ5KHBhcmFtKSk7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblx0XHRcdGFwaS5maWxlVmlld0Zvck1vYmlsZSh7XHJcblx0XHRcdFx0dGFyZ2V0OiAnX3NlbGYnLFxyXG5cdFx0XHRcdHVybDogYXBpQ29uZmlnLkZJTEVfVklFV19NT0JJTEUsXHJcblx0XHRcdFx0cGFyYW06IHBhcmFtLFxyXG5cdFx0XHRcdG1ldGhvZDogJ0dFVCcsXHJcblx0XHRcdFx0X2RjSWQ6IGRhdGEuZGNJZFxyXG5cdFx0XHR9KTtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChleHRyYSkge1xyXG5cdFx0XHRmb3IgKHZhciBrZXkgaW4gZXh0cmEpIHtcclxuXHRcdFx0XHRwYXJhbVtrZXldID0gZXh0cmFba2V5XTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdGFwaS5zdWJtaXRGb3JtKHtcclxuXHRcdFx0dGFyZ2V0OiAnX1ZJRVdFUl8nICsgZGF0YS5yZXZpc2lvbklkLFxyXG5cdFx0XHR1cmw6IHVybCxcclxuXHRcdFx0cGFyYW06IHBhcmFtLFxyXG5cdFx0XHRtZXRob2Q6ICdHRVQnLFxyXG5cdFx0XHRfZGNJZDogZGF0YS5kY0lkXHJcblx0XHR9KTtcclxuICAgIH1cclxufV0pXHJcblxyXG4uc2VydmljZSgnZG93bmxvYWRBc3NvY0RvYycsIFsnJHdpbmRvdycsICckdGltZW91dCcsICdhcGlDb25maWcnLCAnbXlDb25maWcnLCAnbGFuZycsICdkb3dubG9hZCcsICdhcGknLCAnTm90aWZpY2F0aW9uJywgZnVuY3Rpb24oJHdpbmRvdywgJHRpbWVvdXQsIGFwaUNvbmZpZywgbXlDb25maWcsIGxhbmcsIGRvd25sb2FkLCBhcGksIE5vdGlmaWNhdGlvbikge1xyXG4gICAgdmFyIGRvd25sb2FkQXNzb2NEb2MgPSB0aGlzO1xyXG4gICAgdmFyIGRvd25sb2FkWGhyID0gZmFsc2U7XHJcbiAgICB2YXIgcmVzRGF0YSA9IG51bGw7XHJcbiAgICBkb3dubG9hZEFzc29jRG9jLmluaXQgPSBmdW5jdGlvbihvcHQsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgZG93bmxvYWRBc3NvY0RvYy5kaXJlY3RMaW5rKG9wdCwgY2FsbGJhY2spO1xyXG4gICAgfTtcclxuXHJcbiAgICBkb3dubG9hZEFzc29jRG9jLmRpcmVjdExpbmsgPSBmdW5jdGlvbihvcHQsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgcmVzRGF0YSA9IG9wdDtcclxuICAgICAgICB2YXIgcGFyYW0gPSB7XHJcbiAgICAgICAgICAgICAgICByZXZJZHM6IFtdLFxyXG4gICAgICAgICAgICAgICAgcmV2aXNpb25zOiBbXSxcclxuICAgICAgICAgICAgICAgIGlzRnJvbURpcmVjdExpbms6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBpc0RpZmZQcm9qZWN0OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIHByb2plY3RJZHM6IFtdXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNlbGVjdGVkUm93c0RhdGEgPSBKU09OLnBhcnNlKG9wdC5kb3dubG9hZFJldkRvY0xpc3RKU09OKSxcclxuICAgICAgICAgICAgZG9jRGF0YSA9IG51bGw7XHJcblxyXG4gICAgICAgIGlmIChzZWxlY3RlZFJvd3NEYXRhLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5lcnJvcih7IHRpdGxlOiBsYW5nLmdldChcImFkb2RkbGVcIiksIG1lc3NhZ2U6IGxhbmcuZ2V0KFwibm8tZG9jdW1lbnQtYXNzb2NpYXRpb25zLWZvdW5kXCIpIH0pO1xyXG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZWxlY3RlZFJvd3NEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBkb2NEYXRhID0gc2VsZWN0ZWRSb3dzRGF0YVtpXTtcclxuICAgICAgICAgICAgICAgIHBhcmFtLnJldmlzaW9ucy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICByZXZpc2lvbklkOiBkb2NEYXRhLnJldmlzaW9uSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgaXNMb2NrOiBkb2NEYXRhLmlzTG9jayxcclxuICAgICAgICAgICAgICAgICAgICBkY0lkOiBkb2NEYXRhLmRjSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgcHJvamVjdElkOiBkb2NEYXRhLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgICAgICBoYXNNYXJrdXA6IGRvY0RhdGEuaGFzTWFya3VwLFxyXG4gICAgICAgICAgICAgICAgICAgIGhhc0F0dGFjaG1lbnQ6IGRvY0RhdGEuaGFzQXR0YWNobWVudCxcclxuICAgICAgICAgICAgICAgICAgICB6aXBGaWxlTmFtZTogZG9jRGF0YS56aXBGaWxlTmFtZVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBwYXJhbS5yZXZJZHMucHVzaChkb2NEYXRhLnJldmlzaW9uSWQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhcmFtLnByb2plY3RJZHMuaW5kZXhPZihkb2NEYXRhLnByb2plY3RJZCkgPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbS5wcm9qZWN0SWRzLnB1c2goZG9jRGF0YS5wcm9qZWN0SWQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAocGFyYW0ucmV2aXNpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgcGFyYW0uaXNEaWZmUHJvamVjdCA9IHBhcmFtLnByb2plY3RJZHMubGVuZ3RoID4gMTtcclxuICAgICAgICAgICAgICAgIHBhcmFtLmNhbGxGb3JtID0gcGFyYW0uaXNEaWZmUHJvamVjdCA/IFwiTXVsdGlQcm9qZWN0RG93bmxvYWRcIiA6IFwiRG93bmxvYWRCdG5cIjtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkQXNzb2NEb2MuZGlzcGxheURvd25sb2FkUGFnZShwYXJhbSwgY2FsbGJhY2spO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZG93bmxvYWRBc3NvY0RvYy5kaXNwbGF5RG93bmxvYWRQYWdlID0gZnVuY3Rpb24ocGFyYW0sIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgdmFyIHJldkRhdGEgPSBwYXJhbS5yZXZpc2lvbnNbMF07XHJcbiAgICAgICAgdmFyIGlzRnJvbURpcmVjdExpbmsgPSBwYXJhbS5pc0Zyb21EaXJlY3RMaW5rO1xyXG4gICAgICAgIGlmICghaXNGcm9tRGlyZWN0TGluaykge1xyXG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZG93bmxvYWRYaHIpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKG15Q29uZmlnLmFwcGxpY2F0aW9uSWQgIT0gMilcclxuICAgICAgICAgICAgTm90aWZpY2F0aW9uLnN1Y2Nlc3MoJzxkaXYgY2xhc3M9XCJib2xkLW1zZyB0ZXh0LWNlbnRlclwiPicgKyBsYW5nLmdldChcImRvd25sb2FkLWhhcy1iZWVuLXN0YXJ0ZWRcIikgKyAnPC9kaXY+Jyk7XHJcblxyXG4gICAgICAgIHZhciBzdHJVcmwgPSBcIlwiO1xyXG4gICAgICAgIGlmIChyZXNEYXRhLmlzTGltaXRFeGlzdCkge1xyXG4gICAgICAgICAgICBzdHJVcmwgPSByZXNEYXRhLm5vbkNETkRvd25sb2FkVXJsO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgdXJsQ29udHJvbGxlciA9IGFwaUNvbmZpZy5NVUxUSV9EQ19ET1dOTE9BRF9CQVRDSF9ET0NVTUVOVF9BQ1RJT05fQ09OVFJPTExFUjtcclxuICAgICAgICBpZiAocmVzRGF0YS5pc0Zyb21QdWJsaWNEb21haW4pIHtcclxuICAgICAgICAgICAgdXJsQ29udHJvbGxlciA9IGFwaUNvbmZpZy5QVUJMSUNfRE9XTkxPQURfQ09OVFJPTExFUjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmKCFzdHJVcmwpIHtcclxuICAgICAgICAgICAgICAgIHN0clVybCA9IG15Q29uZmlnLmRvd25sb2FkU2VydmljZVVSTDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBkb3dubG9hZFhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiB1cmxDb250cm9sbGVyLFxyXG4gICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICBleHRyYTogSlNPTi5zdHJpbmdpZnkocGFyYW0pLFxyXG4gICAgICAgICAgICAgICAgcHJvamVjdElEOiByZXZEYXRhLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgIGlzRnJvbURpcmVjdExpbms6IGlzRnJvbURpcmVjdExpbmssXHJcbiAgICAgICAgICAgICAgICBpbmNsdWRlSW50ZXJuYWxBdHRhY2htZW50OiByZXNEYXRhLmRvd25sb2FkU2Vjb25kYXJ5RmlsZSxcclxuICAgICAgICAgICAgICAgIGFjdGlvbl9pZDogYXBpQ29uZmlnLk1VTFRJX0RDX0RPV05MT0FEX0JBVENIX0RPQ1VNRU5UX0FDVElPTixcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkV2l0aFNpbXBsZVBhdGg6IG15Q29uZmlnLmRvd25sb2FkV2l0aFNpbXBsZVBhdGhcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgX2RjSWQ6IHJldkRhdGEuZGNJZCxcclxuICAgICAgICAgICAgX2NkblVybDogc3RyVXJsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGRvd25sb2FkWGhyLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgICAgICAgICBkb3dubG9hZFhociA9IGZhbHNlO1xyXG4gICAgICAgICAgICBkYXRhLnVybCA9IGFwaUNvbmZpZy5QUk9HUkVTU19aSVBfQ1JFQVRJT05fQ09OVFJPTExFUjtcclxuICAgICAgICAgICAgaWYgKHJlc0RhdGEuaXNGcm9tUHVibGljRG9tYWluKSB7XHJcbiAgICAgICAgICAgICAgICBkYXRhLnVybCA9IGFwaUNvbmZpZy5QVUJMSUNfRE9XTkxPQURfQ09OVFJPTExFUjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkYXRhLmFjdGlvblVybCA9IGRhdGEuc291cmNlUGF0aDtcclxuICAgICAgICAgICAgZGF0YS5wcm9qZWN0SWQgPSByZXZEYXRhLnByb2plY3RJZDtcclxuICAgICAgICAgICAgZGF0YS5pc0Zyb21EaXJlY3RMaW5rID0gaXNGcm9tRGlyZWN0TGluaztcclxuICAgICAgICAgICAgZG93bmxvYWQuY3JlYXRlWmlwRmlsZShkYXRhLCBjYWxsYmFjayk7XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oeGhyKSB7XHJcbiAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgIGRvd25sb2FkWGhyID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJzZXJ2ZXItZXJyb3JcIik7XHJcbiAgICAgICAgICAgIGFwaS5zaG93U2VydmVyRXJyTXNnKHhocik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG59XSlcclxuXHJcbi5zZXJ2aWNlKCd2YWxpZGF0ZScsIFsnYXBpJywgJ2xhbmcnLCBmdW5jdGlvbihhcGksIGxhbmcpIHtcclxuICAgIHZhciB2YWxpZGF0aW9uID0gdGhpcztcclxuXHJcbiAgICB2YXIgaW52YWxpZEh0bWxBcnJheSA9IFsnamF2YXMmIzk5O3JpcHQnLCAnamF2YXNjcmlwdDonLCAnPHNjcmlwdCcsICc8L3NjcmlwdD4nLCAndmJzY3JpcHQ6JywgJ2xpdmVzY3JpcHQ6JywgJzxzJiM5OTtyaXB0PicsICc8aW1nJywgJ29ubG9hZD0nLFxyXG4gICAgICAgICc8aW5wdXQnLCAnPHNlbGVjdCcsICc8dGV4dGFyZWEnLCAnPGZvcm0nLCAnPGhlYWQnLCAnPGJvZHknLCAnPGh0bWwnLCAnZGF0YXNyYz0nLCAnPGlmcmFtZScsICd0ZXh0L2phdmFzY3JpcHQnLCAnZXZhbCgnLCAnZXhwcmVzc2lvbignLFxyXG4gICAgICAgICd1cmwoJywgJyZ7WycsICdhbGVydCgnLCAnYWxlcnQ9JywgJ2FsZXJ0YCcsICdcXHgzY3NjcmlwdCcsICdqYXZhc2NyaXB0IycsICc8bWV0YScsICclM2NzY3JpcHQnLCAnZG9jdW1lbnQuY29va2llJywgJ3dpbmRvdy5sb2NhdGlvbicsICc8RU1CRUQnLCAnPC9FTUJFRD4nLCAnb25lcnJvcj0nLCAnd2luZG93Lm9wZW4oJywgJ29uY2xpY2s9JywgXHJcbiAgICAgICAgJ3Byb21wdD0nLCAncHJvbXB0YCcsICdwcm9tcHQoJywgJ29uY29weT0nLCAnb25jdXQ9JywgJ29ucGFzdGU9JywgJ29uZGJsbGNsaWNrPScsICdvbm1vdXNlb3Zlcj0nLCAnb25tb3VzZWRvd249JywgJ29ubW91c2VlbnRlcj0nLCAnb25tb3VzZWxlYXZlPScsICdvbm1vdXNlbW92ZT0nLCAnb25tb3VzZW91dD0nLCAnb25tb3VzZXVwPScsICdvbnNjcm9sbD0nLCBcclxuICAgICAgICAnb250b3VjaGNhbmNlbD0nLCAnb250b3VjaGVuZD0nLCAnb250b3VjaG1vdmU9JywgJ29udG91Y2hzdGFydD0nLCAnY29uZmlybWAnLCAnY29uZmlybSgnLCAnY29uZmlybT0nLCAnb25pbnB1dD0nLCAgJz1qYXZhc2NyaXB0JyxcclxuICAgICAgICAnPSYjMzQ7amF2YXNjcmlwdCcsICc9KGphdmFzY3JpcHQnLCAnPWBqYXZhc2NyaXB0JywgJ3hsaW5rOmhyZWYnLCAnPGJ1dHRvbicgXHJcbiAgICBdO1xyXG5cclxuICAgIHZhciByaWNoVGV4dEV4Y2VwdGlvblRhZ3MgPSBbJzxpbWcnXTtcclxuXHJcbiAgICB2YWxpZGF0aW9uLnJlcXVpcmVkID0gZnVuY3Rpb24odmFsdWUpIHtcclxuICAgICAgICB2YXIgaXNWYWxpZCA9IHRydWU7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS50cmltKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXZhbHVlIHx8ICF2YWx1ZS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgaXNWYWxpZCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdmFsaWQ6IGlzVmFsaWQsXHJcbiAgICAgICAgICAgIGVycm9yOiBsYW5nLmdldChcImZpZWxkLXJlcXVpcmVkXCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5tYXhMZW5ndGggPSBmdW5jdGlvbih2YWx1ZSwgbGVuZ3RoKSB7XHJcbiAgICAgICAgdmFyIGlzVmFsaWQgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUgJiYgdmFsdWUubGVuZ3RoID4gbGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHZhbGlkOiBpc1ZhbGlkLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJ3b3JrZmxvdy1kZXNjcmlwdGlvbi10b28tbG9hbmdcIikucmVwbGFjZShcInswfVwiLCBsZW5ndGgpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5udW1iZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkTnVtID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIC8vIEFjY2VwdCBSZWd1bGFyIE51bWJlciBvciBmbG9hdCBOdW1iZXIgb25seVxyXG4gICAgICAgICAgICB2YXIgcmVnSXNOdW0gPSAvXlxcZCsoXFwuXFxkKykqJC87XHJcbiAgICAgICAgICAgIGlzVmFsaWROdW0gPSByZWdJc051bS50ZXN0KHZhbHVlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHZhbGlkOiBpc1ZhbGlkTnVtLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJpbnZhbGlkLWRlY2ltYWxcIilcclxuICAgICAgICB9O1xyXG4gICAgfTtcclxuXHJcbiAgICB2YWxpZGF0aW9uLmludGVnZXIgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkSW50ID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIC8vIEFjY2VwdCBwb3NpdGl2ZSBvciBOZWdhdGl2ZSBOdW1iZXIgb25seVxyXG4gICAgICAgICAgICB2YXIgcmVnSXNJbnQgPSAvXihcXC17MCwxfSlcXGQrJC87XHJcbiAgICAgICAgICAgIGlzVmFsaWRJbnQgPSByZWdJc0ludC50ZXN0KHZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBNQVhfSU5UID0gMjE0NzQ4MzY0NztcclxuICAgICAgICAgICAgdmFyIE1JTl9JTlQgPSAtMjE0NzQ4MzY0NztcclxuICAgICAgICAgICAgdmFyIGludFZhbHVlID0gcGFyc2VJbnQodmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGludFZhbHVlID49IE1BWF9JTlQgfHwgaW50VmFsdWUgPD0gTUlOX0lOVCkge1xyXG4gICAgICAgICAgICAgICAgaXNWYWxpZEludCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZEludCxcclxuICAgICAgICAgICAgZXJyb3I6IGxhbmcuZ2V0KFwiaW52YWxpZC1pbnRlZ2VyXCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5kZWNpbWFsID0gZnVuY3Rpb24odmFsdWUpIHtcclxuICAgICAgICB2YXIgaXNWYWxpZCA9IHRydWU7XHJcblxyXG4gICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICBpc1ZhbGlkID0gIWlzTmFOKHBhcnNlRmxvYXQodmFsdWUpKSAmJiBpc0Zpbml0ZSh2YWx1ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZCxcclxuICAgICAgICAgICAgZXJyb3I6IGxhbmcuZ2V0KFwiaW52YWxpZC1kZWNpbWFsXCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5lbWFpbCA9IGZ1bmN0aW9uKHZhbHVlKSB7XHJcbiAgICAgICAgdmFyIGlzVmFsaWRFbWFpbEFkZCA9IHRydWU7XHJcblxyXG4gICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAvLyBBY2NlcHQgRW1haWwgRm9ybWF0IHdpdGggb3Igd2l0aG91dCB1bmRlcnNjb3JlXHJcbiAgICAgICAgICAgIHZhciByZWdJc0VtYWlsRm9ybWF0ID0gL15bYS16QS1aMC05X10rKFxcLlthLXpBLVowLTlfXSspezAsMX1cXEBbYS16QS1aMC05X10rXFwuW2EtekEtWjAtOV9dKyhcXC5bYS16QS1aMC05X10rKXswLDN9JC87XHJcbiAgICAgICAgICAgIGlzVmFsaWRFbWFpbEFkZCA9IHJlZ0lzRW1haWxGb3JtYXQudGVzdCh2YWx1ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZEVtYWlsQWRkLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJpbnZhbGlkLWVtYWlsQWRkcmVzc1wiKVxyXG4gICAgICAgIH07XHJcbiAgICB9O1xyXG5cclxuICAgIHZhbGlkYXRpb24uZGF0ZSA9IGZ1bmN0aW9uKHZhbHVlKSB7XHJcbiAgICAgICAgdmFyIGlzVmFsaWQgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgdmFyIHNwbGl0ID0gdmFsdWUuc3BsaXQoJzo6Jyk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhcGkucGFyc2VEYXRlKHNwbGl0WzFdLCBzcGxpdFswXSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdmFsaWQ6IGlzVmFsaWQsXHJcbiAgICAgICAgICAgIGVycm9yOiBsYW5nLmdldChcImludmFsaWQtZGF0ZVwiKVxyXG4gICAgICAgIH07XHJcbiAgICB9O1xyXG5cclxuICAgIHZhbGlkYXRpb24uYWxwaGFXaXRoU3BhY2UgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkU3RyaW5nID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIHZhciByZWdJc0FscGhhID0gL15cXHMqW2EtekEtWlxcc10rXFxzKiQvO1xyXG4gICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gcmVnSXNBbHBoYS50ZXN0KHZhbHVlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHZhbGlkOiBpc1ZhbGlkU3RyaW5nLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJpbnZhbGlkLWxldHRlcnNcIilcclxuICAgICAgICB9O1xyXG4gICAgfTtcclxuXHJcbiAgICAvL0l0IGNoZWNrIHN0cmluZyBjb250YWluIEhUTUwgdGFnIG9yIG5vdC5cclxuICAgIHZhbGlkYXRpb24uaW52YWxpZEhUTUx0YWcgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhbHVlID0gdmFsdWUucmVwbGFjZSgvXFxyL2csIFwiIFwiKS5yZXBsYWNlKC9cXG4vZywgXCIgXCIpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgdmFyIGlzVmFsaWRTdHJpbmcgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGNvZGVBdCA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29kZUF0IDwgMzIgfHwgY29kZUF0ID09IDM1KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZFN0cmluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoaXNWYWxpZFN0cmluZykge1xyXG4gICAgICAgICAgICAgICAgaXNWYWxpZFN0cmluZyA9IHZhbGlkYXRpb24uaGFzQ29kZUNvbnRlbnQodmFsdWUpLnZhbGlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZFN0cmluZyxcclxuICAgICAgICAgICAgZXJyb3I6IGxhbmcuZ2V0KFwiaW52YWxpZC1jaGFyYWN0ZXItZW50ZXJlZFwiKVxyXG4gICAgICAgIH07XHJcbiAgICB9O1xyXG5cclxuICAgIC8vSXQgY2hlY2sgc3RyaW5nIGNvbnRhaW4gSFRNTCB0YWcgb3Igbm90LlxyXG4gICAgdmFsaWRhdGlvbi5oYXNDb2RlQ29udGVudCA9IGZ1bmN0aW9uKHZhbHVlLCByaWNoVGV4dCkge1xyXG4gICAgICAgIHZhbHVlID0gdmFsdWUucmVwbGFjZSgvXFxyL2csIFwiIFwiKS5yZXBsYWNlKC9cXG4vZywgXCIgXCIpLnJlcGxhY2UoL1xccy9nLCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHZhbHVlID0gdmFsdWUucmVwbGFjZSgvJmx0Oy9nLCBcIjxcIikucmVwbGFjZSgvJmd0Oy9nLCBcIj5cIik7XHJcbiAgICAgICAgdmFyIGlzVmFsaWRTdHJpbmcgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBpbnZhbGlkSHRtbEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmljaFRleHQgJiYgcmljaFRleHRFeGNlcHRpb25UYWdzLmluZGV4T2YoaW52YWxpZEh0bWxBcnJheVtpXSkgIT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5pbmRleE9mKGludmFsaWRIdG1sQXJyYXlbaV0pID4gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHZhbGlkOiBpc1ZhbGlkU3RyaW5nLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJpbnZhbGlkQ2hhckZvckNvbW1lbnRSaWNoYm94XCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgLy9JdCBjaGVjayBzdHJpbmcgY29udGFpbiBIVE1MIHRhZyBvciBub3QuXHJcbiAgICB2YWxpZGF0aW9uLmhhc0ludmFsaWRDaGFyID0gZnVuY3Rpb24odmFsdWUpIHtcclxuICAgICAgICB2YWx1ZSA9IHZhbHVlLnJlcGxhY2UoL1xcci9nLCBcIiBcIikucmVwbGFjZSgvXFxuL2csIFwiIFwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHZhbHVlID0gdmFsdWUucmVwbGFjZSgvJmx0Oy9nLCBcIjxcIikucmVwbGFjZSgvJmd0Oy9nLCBcIj5cIik7XHJcbiAgICAgICAgdmFyIGlzVmFsaWRTdHJpbmcgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGNvZGVBdCA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29kZUF0IDwgMzIpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHZhbGlkOiBpc1ZhbGlkU3RyaW5nLFxyXG4gICAgICAgICAgICBlcnJvcjogbGFuZy5nZXQoXCJpbnZhbGlkQ2hhckZvckNvbW1lbnRSaWNoYm94XCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5pbnZhbGlkY2hhcnMgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkU3RyaW5nID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5jaGFyQ29kZUF0KGkpIDwgMzIgfHwgdmFsdWUuY2hhckNvZGVBdChpKSA9PSA2Mykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzVmFsaWRTdHJpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgICAgIHZhciBub3NwZWNpYWwgPSAvXlteXFwvJ1xcL1xcXFw6Kj88Pnw7JSN+XFxcIl0rJC87XHJcbiAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gbm9zcGVjaWFsLnRlc3QodmFsdWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZFN0cmluZyxcclxuICAgICAgICAgICAgZXJyb3I6IGxhbmcuZ2V0KFwic3BlY2lhbC1jaGFyYWN0ZXItdmFsaWRhdGlvblwiKS5yZXBsYWNlKFwiMTY2KEE2KVwiLCBcInxcIilcclxuICAgICAgICB9O1xyXG4gICAgfTtcclxuXHJcbiAgICB2YWxpZGF0aW9uLmxldHRlckFuZE51bWJlciA9IGZ1bmN0aW9uKHZhbHVlKSB7XHJcbiAgICAgICAgdmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cXHIvZywgXCIgXCIpLnJlcGxhY2UoL1xcbi9nLCBcIiBcIikudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICBpc1ZhbGlkU3RyaW5nID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5jaGFyQ29kZUF0KGkpIDwgMzIpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHZhciBpbnZhbGlkU3RyaW5nQXJyYXkgPSBbJyMnLCAnfCcsICdcIicsICcvJywgJ1xcXFwnLCAnOicsICcqJywgJz8nLCAnPCcsICc+JywgJ3wnLCAnOycsICclJywgJyMnLCAnficsICcmJ107XHJcbiAgICAgICAgICAgIGludmFsaWRTdHJpbmdBcnJheSA9IGludmFsaWRTdHJpbmdBcnJheS5jb25jYXQoaW52YWxpZEh0bWxBcnJheSk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGludmFsaWRTdHJpbmdBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlLmluZGV4T2YoaW52YWxpZFN0cmluZ0FycmF5W2ldKSAhPSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzVmFsaWRTdHJpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdmFsaWQ6IGlzVmFsaWRTdHJpbmcsXHJcbiAgICAgICAgICAgIGVycm9yOiBsYW5nLmdldChcImludmFsaWQtY2hhcmFjdGVycy1lbnRlcmVkXCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5kb2NyZWZJbnZhbGlkQ2hhcnMgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkU3RyaW5nID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIHZhciBub3NwZWNpYWwgPSAvXCJ8I3w6fDt8XFx4M0Z8XFx4N0N8PHw+fCV8XFxcXHxcXC98fnxcXCp84oCULztcclxuICAgICAgICAgICAgdmFyIG1hdGNoZXMgPSB2YWx1ZS5tYXRjaChub3NwZWNpYWwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKG1hdGNoZXMgJiYgbWF0Y2hlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHZhbHVlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlLmNoYXJDb2RlQXQoaSkgPCAzMikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgdmFsaWQ6IGlzVmFsaWRTdHJpbmcsXHJcbiAgICAgICAgICAgIGVycm9yOiBsYW5nLmdldChcInNwZWNpYWwtY2hhcmFjdGVyLXZhbGlkYXRpb25cIikucmVwbGFjZShcIjE2NihBNilcIiwgXCJ8XCIpXHJcbiAgICAgICAgfTtcclxuICAgIH07XHJcblxyXG4gICAgdmFsaWRhdGlvbi5pbnZhbGlkRmlsZU5hbWUgPSBmdW5jdGlvbih2YWx1ZSkge1xyXG4gICAgICAgIHZhciBpc1ZhbGlkU3RyaW5nID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5jaGFyQ29kZUF0KGkpIDwgMzIgfHwgdmFsdWUuY2hhckNvZGVBdChpKSA9PSA2Mykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzVmFsaWRTdHJpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgbm9zcGVjaWFsID0gL15bXlxcXFw6Kj88Pnw7JSN+XFxcIl0rJC87XHJcbiAgICAgICAgICAgICAgICBpc1ZhbGlkU3RyaW5nID0gbm9zcGVjaWFsLnRlc3QodmFsdWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB2YWxpZDogaXNWYWxpZFN0cmluZyxcclxuICAgICAgICAgICAgZXJyb3I6IGxhbmcuZ2V0KFwic3BlY2lhbC1jaGFyYWN0ZXItdmFsaWRhdGlvblwiKS5yZXBsYWNlKFwiMTY2KEE2KVwiLCBcInxcIilcclxuICAgICAgICB9O1xyXG4gICAgfTtcclxufV0pXHJcblxyXG4uc2VydmljZSgnZGRjaGlsZCcsIFsnJGRvY3VtZW50JywgJyRyb290U2NvcGUnLCAnJHRpbWVvdXQnLCBmdW5jdGlvbigkZG9jdW1lbnQsICRyb290U2NvcGUsICR0aW1lb3V0KSB7XHJcbiAgICB2YXIgbG9hZGVkQ2hpbGRzID0gW107XHJcbiAgICB2YXIgY2FsbGJhY2tzID0ge307XHJcbiAgICB2YXIgY2hpbGRzTWFwID0ge307XHJcblxyXG4gICAgdGhpcy5yZWdpc3RlciA9IGZ1bmN0aW9uKGNoaWxkU2NvcGUsIG5hbWUpIHtcclxuICAgICAgICBsb2FkZWRDaGlsZHMucHVzaCh7XHJcbiAgICAgICAgICAgIG5hbWU6IG5hbWUsXHJcbiAgICAgICAgICAgIHNjb3BlOiBjaGlsZFNjb3BlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgY2hpbGRzTWFwW25hbWVdID0gY2hpbGRTY29wZTtcclxuXHJcbiAgICAgICAgaWYgKGNhbGxiYWNrc1tuYW1lXSAmJiBjYWxsYmFja3NbbmFtZV0ubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2FsbGJhY2tzW25hbWVdLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgY2IgPSBjYWxsYmFja3NbbmFtZV1baV07XHJcbiAgICAgICAgICAgICAgICBjYigpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjYWxsYmFja3NbbmFtZV0gPSBbXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5nZXRDaGlsZFNjb3BlID0gZnVuY3Rpb24obmFtZSkge1xyXG4gICAgICAgIHJldHVybiBjaGlsZHNNYXBbbmFtZV07XHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuaXNMb2FkZWQgPSBmdW5jdGlvbihuYW1lKSB7XHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsb2FkZWRDaGlsZHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdmFyIHMgPSBsb2FkZWRDaGlsZHNbaV07XHJcbiAgICAgICAgICAgIGlmIChzLm5hbWUgPT0gbmFtZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMub25Mb2FkID0gZnVuY3Rpb24obmFtZSwgY2FsbGJhY2spIHtcclxuICAgICAgICBpZiAoIWNhbGxiYWNrc1tuYW1lXSkge1xyXG4gICAgICAgICAgICBjYWxsYmFja3NbbmFtZV0gPSBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNhbGxiYWNrc1tuYW1lXS5wdXNoKGNhbGxiYWNrKTtcclxuICAgIH1cclxufV0pXHJcblxyXG4uc2VydmljZSgnYXR0YWNobWVudEFwaScsIFsnbGFuZycsICd2YWxpZGF0ZScsIGZ1bmN0aW9uKGxhbmcsIHZhbGlkYXRlKSB7XHJcbiAgICB0aGlzLmlubGluZUF0dGFjaG1lbnRzID0gW107XHJcblxyXG4gICAgdGhpcy5yZWdpc3RlciA9IGZ1bmN0aW9uKHNjb3BlLCBjdHJsKSB7XHJcbiAgICAgICAgdGhpcy5pbmxpbmVBdHRhY2htZW50cy5wdXNoKFtzY29wZSwgY3RybF0pO1xyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnVucmVnaXN0ZXIgPSBmdW5jdGlvbihzY29wZSwgY3RybCkge1xyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5pbmxpbmVBdHRhY2htZW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgaW5zdCA9IHRoaXMuaW5saW5lQXR0YWNobWVudHNbaV07XHJcbiAgICAgICAgICAgIGlmIChpbnN0WzBdID09PSBzY29wZSAmJiBpbnN0WzFdID09PSBjdHJsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlubGluZUF0dGFjaG1lbnRzLnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuaW52YWxpZEZpbGVOYW1lID0gZnVuY3Rpb24oZmlsZW5hbWUpIHtcclxuICAgICAgICByZXR1cm4gdmFsaWRhdGUuaW52YWxpZEZpbGVOYW1lKGZpbGVuYW1lKTtcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy52YWxpZGF0ZSA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBvYmogPSB7IHZhbGlkOiB0cnVlLCB0eXBlOiAnYWxlcnQnIH07XHJcbiAgICAgICAgdmFyIGlubGluZUF0dGFjaG1lbnRzID0gdGhpcy5pbmxpbmVBdHRhY2htZW50cztcclxuICAgICAgICBpZiAoIWlubGluZUF0dGFjaG1lbnRzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICByZXR1cm4gb2JqO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBpbmxpbmVBdHRhY2htZW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgaW5zdCA9IGlubGluZUF0dGFjaG1lbnRzW2ldO1xyXG4gICAgICAgICAgICB2YXIgY3RybCA9IGluc3RbMV07XHJcbiAgICAgICAgICAgIGlmIChjdHJsLmZpbGVSZXF1aXJlZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGN0cmwuaXNVcGxvYWRpbmcpIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmoudmFsaWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBvYmoubXNnID0gbGFuZy5nZXQoXCJwbGVhc2Utd2FpdC15b3VyLWZpbGUtaXMtdXBsb2FkaW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmo7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCFjdHJsLnJlbW92ZUZpbGVJY29uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JqLnZhbGlkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JqLm1zZyA9IGxhbmcuZ2V0KFwiZm9ybS1zdWJtaXQtdmFsaWRhdGlvbi1tc2dcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iajtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBpbmxpbmVBdHRhY2htZW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgaW5zdCA9IGlubGluZUF0dGFjaG1lbnRzW2ldO1xyXG4gICAgICAgICAgICB2YXIgY3RybCA9IGluc3RbMV07XHJcbiAgICAgICAgICAgIGlmIChjdHJsLmlzVXBsb2FkaW5nKSB7XHJcbiAgICAgICAgICAgICAgICBvYmoudmFsaWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIG9iai50eXBlID0gXCJjb25maXJtXCI7XHJcbiAgICAgICAgICAgICAgICBvYmoubXNnID0gXCJXYXJuaW5nOlxcblBsZWFzZSB3YWl0IHdoaWxlIHlvdXIgZmlsZShzKSBpcyBiZWluZyB1cGxvYWRlZFwiICtcclxuICAgICAgICAgICAgICAgICAgICBcIlxcbkNsaWNrIG9uICdPSycgSWYgeW91IHdpc2ggdG8gc3VibWl0IGZvcm0gd2l0aG91dCB0aGUgcGVuZGluZyBhdHRhY2htZW50KHMpLCBvciBjbGljayAnQ2FuY2VsJyB0byByZXR1cm4gYW5kIGNvbXBsZXRlIGF0dGFjaGluZyB0aGUgZmlsZShzKS5cIjtcclxuICAgICAgICAgICAgICAgIHJldHVybiBvYmo7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBvYmo7XHJcbiAgICB9O1xyXG59XSlcclxuXHJcbi5zZXJ2aWNlKCdhc3luY1NlcnZpY2UnLCBbJyR3aW5kb3cnLCAnJHRpbWVvdXQnLCAnYXBpQ29uZmlnJywgJ215Q29uZmlnJywgJ2xhbmcnLCAnYXBpJywgJ05vdGlmaWNhdGlvbicsIGZ1bmN0aW9uKCR3aW5kb3csICR0aW1lb3V0LCBhcGlDb25maWcsIG15Q29uZmlnLCBsYW5nLCBhcGksIE5vdGlmaWNhdGlvbikge1xyXG4gICAgdmFyIGFzeW5jU2VydmljZSA9IHRoaXM7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZXRzIHdoaWNoIG9zXHJcbiAgICAgKiBAcmV0dXJucyAgXHJcbiAgICAgKiBUaGlzIHNjcmlwdCBzZXRzIE9TTmFtZSB2YXJpYWJsZSBhcyBmb2xsb3dzOlxyXG4gICAgICogXCJXaW5kb3dzXCIgICAgZm9yIGFsbCB2ZXJzaW9ucyBvZiBXaW5kb3dzXHJcbiAgICAgKiBcIk1hY09TXCIgICAgICBmb3IgYWxsIHZlcnNpb25zIG9mIE1hY2ludG9zaCBPU1xyXG4gICAgICogXCJMaW51eFwiICAgICAgZm9yIGFsbCB2ZXJzaW9ucyBvZiBMaW51eFxyXG4gICAgICogXCJVTklYXCIgICAgICAgZm9yIGFsbCBvdGhlciBVTklYIGZsYXZvcnMgXHJcbiAgICAgKiBcIlVua25vd24gT1NcIiBpbmRpY2F0ZXMgZmFpbHVyZSB0byBkZXRlY3QgdGhlIE9TXHJcbiAgICAgKi9cclxuICAgIGFzeW5jU2VydmljZS5yZXRXaGljaE9TID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIG51ID0gbmF2aWdhdG9yLnVzZXJBZ2VudDtcclxuICAgICAgICB2YXIgT1NOYW1lPVwiVW5rbm93biBPU1wiO1xyXG4gICAgICAgIGlmIChudS5pbmRleE9mKFwiV2luXCIpIT0tMSkgT1NOYW1lPVwiV2luZG93c1wiO1xyXG4gICAgICAgIGlmIChudS5pbmRleE9mKFwiTWFjXCIpIT0tMSkgT1NOYW1lPVwiTWFjT1NcIjtcclxuICAgICAgICBpZiAobnUuaW5kZXhPZihcIlgxMVwiKSE9LTEpIE9TTmFtZT1cIlVOSVhcIjtcclxuICAgICAgICBpZiAobnUuaW5kZXhPZihcIkxpbnV4XCIpIT0tMSkgT1NOYW1lPVwiTGludXhcIjtcclxuICAgICAgICByZXR1cm4gT1NOYW1lO1xyXG4gICAgfTtcclxuXHJcbiAgICBhc3luY1NlcnZpY2UuZWRpdEZpbGVBc3luYyA9IGZ1bmN0aW9uKGRhdGEsIGNhbGxCYWNrRm4pIHtcclxuICAgICAgICB2YXIgZWRpdFhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgdXJsOiBhcGlDb25maWcuQVNZTkNfTk9USUZJQ0FUSU9OLFxyXG4gICAgICAgICAgICBfZGNJZDogKGRhdGEgfHwge30pLmRjSWQsXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBkYXRhOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICBjYWxsZWRGcm9tOiAnZm9ybS1hc3NvY2lhdGlvbicsXHJcbiAgICAgICAgICAgICAgICBvc1R5cGUgOiBhc3luY1NlcnZpY2UucmV0V2hpY2hPUygpLFxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnRGb2xkZXJQYXRoOiBkYXRhLmRvY3VtZW50Rm9sZGVyUGF0aCB8fCBkYXRhLmZpbGVQYXRoLFxyXG4gICAgICAgICAgICAgICAgZmlsZW5hbWU6IGRhdGEuZmlsZU5hbWUsXHJcbiAgICAgICAgICAgICAgICBkb2NSZWY6IGRhdGEuZG9jUmVmLFxyXG4gICAgICAgICAgICAgICAgdXBsb2FkRmlsZW5hbWU6IGRhdGEudXBsb2FkRmlsZW5hbWUsXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudElkOiBkYXRhLmRvY3VtZW50SWQgfHwgZGF0YS5kb2NJZCxcclxuICAgICAgICAgICAgICAgIGZvbGRlcklkOiBkYXRhLmZvbGRlcklkLFxyXG4gICAgICAgICAgICAgICAgcHJvamVjdElkOiBkYXRhLnByb2plY3RJZCxcclxuICAgICAgICAgICAgICAgIHJldmlzaW9uSWQ6IGRhdGEucmV2aXNpb25JZCxcclxuICAgICAgICAgICAgICAgIHRvdGFsRmlsZVNpemU6IHBhcnNlSW50KGRhdGEuZmlsZVNpemUucmVwbGFjZSgnIEtCJywgJycpLCAxMCksXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZGF0YS5kZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICAgIHB1cnBvc2VPZklzc3VlOiBkYXRhLnB1cnBvc2VPZklzc3VlLFxyXG4gICAgICAgICAgICAgICAgcmV2aXNpb25OdW06IGRhdGEucmV2aXNpb25OdW0sXHJcbiAgICAgICAgICAgICAgICBzdGF0dXM6IGRhdGEuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgdGl0bGU6IGRhdGEudGl0bGVcclxuICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgXHJcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAndGV4dCcsXHJcbiAgICAgICAgfSkudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xyXG4gICAgICAgICAgICBlZGl0WGhyID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICghcmVzcG9uc2UpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgY2FsbEJhY2tGbihyZXNwb25zZSk7XHJcbiAgICAgICAgfSwgZnVuY3Rpb24oZXJyKSB7XHJcbiAgICAgICAgICAgIGVkaXRYaHIgPSBmYWxzZTtcclxuICAgICAgICAgICAgY2FsbEJhY2tGbignJyk7XHJcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogbGFuZy5nZXQoXCJzZXJ2ZXItZXJyb3JcIiksXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiAnJ1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcbiAgICBcclxuICAgIGFzeW5jU2VydmljZS5jaGVja091dE9ubHkgPSBmdW5jdGlvbihwcm9pZCwgc2VsZWN0ZWRGaWxlRGF0YSwgc3VjY0ZuKSB7XHJcbiAgICAgICAgc2VsZWN0ZWRGaWxlRGF0YSA9IHNlbGVjdGVkRmlsZURhdGE7XHJcbiAgICAgICAgdmFyIGNoZWNrT3V0UmV2SWRzID0gW10sY2hlY2tPdXREb2NJZHMgPSBbXTtcclxuXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZWxlY3RlZEZpbGVEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNoZWNrT3V0UmV2SWRzLnB1c2goc2VsZWN0ZWRGaWxlRGF0YVtpXS5yZXZpc2lvbklkKTtcclxuICAgICAgICAgICAgY2hlY2tPdXREb2NJZHMucHVzaChzZWxlY3RlZEZpbGVEYXRhW2ldLmRvY3VtZW50SWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHBhcmFtc09iaiA9IHtcclxuICAgICAgICAgICAgdXNlRGlyZWN0VXJsOiB0cnVlLCBcclxuICAgICAgICAgICAgcHJvamVjdElkOiBwcm9pZCwgXHJcbiAgICAgICAgICAgIHJldmlzaW9uSWQ6IGNoZWNrT3V0UmV2SWRzLmpvaW4oJywnKSwgXHJcbiAgICAgICAgICAgIGFjdGlvbl9pZDogYXBpQ29uZmlnLlJFVl9WQUxJRF9GT1JfQ0hFQ0tPVVRfT05fUklHSFRDTElDSyBcclxuICAgICAgICB9O1xyXG4gICAgXHJcbiAgICAgICAgdmFyIGN2WGhyID0gYXBpLmFqYXgoe1xyXG4gICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5SRVZfVkFMSURfRk9SX0NIRUNLT1VUX09OX1JJR0hUQ0xJQ0tfQ09OVFJPTExFUixcclxuICAgICAgICAgICAgX2RjSWQ6IChzZWxlY3RlZEZpbGVEYXRhWzBdIHx8IHt9KS5kY0lkLFxyXG4gICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICBkYXRhOiBwYXJhbXNPYmosXHJcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vanNvbidcdFx0XHRcclxuICAgICAgICB9KS50aGVuKGZ1bmN0aW9uKGRhdGEpIHtcclxuICAgICAgICAgICAgaWYgKGRhdGEudmFsaWRSZXZpc2lvbnNGb3JDaGVja291dCkge1xyXG4gICAgICAgICAgICAgICAgY3ZYaHIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHBhcmFtc09iai5yZXZpc2lvbklkID0gZGF0YS52YWxpZFJldmlzaW9uc0ZvckNoZWNrb3V0O1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zT2JqLmFjdGlvbl9pZCA9IGFwaUNvbmZpZy5DSEVDS09VVF9SRVY7XHJcbiAgICAgICAgICAgICAgICBhc3luY1NlcnZpY2UuZWRpdEZpbGVBc3luYyhzZWxlY3RlZEZpbGVEYXRhWzBdLCBmdW5jdGlvbihlZGl0RmlsZVJlc3ApIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZWRpdEZpbGVSZXNwICE9IFwic3VjY2Vzc2Z1bFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvd1snb3BlbkFzeW5jQXBwUG9wdXAnXSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhIDogZGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzeW5jQXBwVXJsIDogZWRpdEZpbGVSZXNwLm1hdGNoKC9ocmVmPVwiKFteXCJdKikvKVsxXSB8fCAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9ICwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VjY0ZuICYmIHN1Y2NGbihzZWxlY3RlZEZpbGVEYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYoIWVkaXRGaWxlUmVzcCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7IFxyXG4gICAgICAgICAgICAgICAgdmFyIGNyZFhociA9IGFwaS5hamF4KHtcclxuICAgICAgICAgICAgICAgICAgICB1cmw6IGFwaUNvbmZpZy5HRVRfQ0hFQ0tPVVRfUkVWSVNJT05fREVUQUlMU19DT05UUk9MTEVSLFxyXG4gICAgICAgICAgICAgICAgICAgIF9kY0lkOiAoc2VsZWN0ZWRGaWxlRGF0YVswXSB8fCB7fSkuZGNJZCxcclxuICAgICAgICAgICAgICAgICAgICBfY2RuVXJsOiBteUNvbmZpZy5kb3dubG9hZFNlcnZpY2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VEaXJlY3RVcmw6IHRydWUsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9qZWN0SUQ6IHByb2lkLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV2aXNpb25JZDogY2hlY2tPdXRSZXZJZHMuam9pbignLCcpLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uX2lkOiBhcGlDb25maWcuR0VUX0NIRUNLT1VUX1JFVl9ERVRBSUxTIFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJ1x0XHRcdFxyXG4gICAgICAgICAgICAgICAgfSkudGhlbihmdW5jdGlvbihkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JkWGhyID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgY3ZYaHIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJvd0h0bWwgPSAnJztcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5hbHJlYWR5Q2hlY2tlZE91dFJldmlzaW9uTGlzdCAmJiBkYXRhLmFscmVhZHlDaGVja2VkT3V0UmV2aXNpb25MaXN0Lmxlbmd0aCkgeyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm93SHRtbCArPSBsYW5nLmdldCgnZG9jdW1lbnQtaXMtYWxyZWFkeS1jaGVja2VkLW91dCcpICsgXCIuIDxici8+XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5saW5rZWRSZXZpc2lvbkxpc3QgJiYgZGF0YS5saW5rZWRSZXZpc2lvbkxpc3QubGVuZ3RoKSB7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dIdG1sICs9IGxhbmcuZ2V0KCdzZWxlY3RlZC1kb2N1bWVudC1pcy1saW5rJykgKyBcIi4gPGJyLz5cIiBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLm5vQWNjZXNzUmV2aXNpb25MaXN0ICYmIGRhdGEubm9BY2Nlc3NSZXZpc2lvbkxpc3QubGVuZ3RoKSB7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dIdG1sICs9IGxhbmcuZ2V0KCdwdWJsaXNoLXBlcm1pc3Npb24tbm90LWF2YWlsYWJsZScpICsgXCIuPGJyLz5cIiBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLm5vdExhdGVzdFJldmlzaW9uTGlzdCAmJiBkYXRhLm5vdExhdGVzdFJldmlzaW9uTGlzdC5sZW5ndGgpIHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd0h0bWwgKz0gbGFuZy5nZXQoJ2RvY3VtZW50LW5vdC1hY2Nlc3MtbGF0ZXN0LXJldnNpb24tZGVzYycpICsgXCIuPGJyLz5cIiBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLnBhcGVybGVzc1JldmlzaW9uTGlzdCAmJiBkYXRhLnBhcGVybGVzc1JldmlzaW9uTGlzdC5sZW5ndGgpIHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd0h0bWwgKz0gbGFuZy5nZXQoJ2RvY3VtZW50LWlzLXBhcGVyLWRvY3VtZW50LXBsYWNlaG9sZGVyJykgXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyb3dIdG1sLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBOb3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogbGFuZy5nZXQoXCJhZG9kZGxlXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogcm93SHRtbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbihlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjcmRYaHIgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBjdlhociA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0gICAgICAgICAgICBcclxuICAgICAgICB9LCBmdW5jdGlvbihlcnIpIHtcclxuICAgICAgICAgICAgY3ZYaHIgPSBmYWxzZTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGN2WGhyO1xyXG4gICAgfTtcclxuXHJcbiAgICBhc3luY1NlcnZpY2UuTm90aWZpY2F0aW9uID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgXHJcbiAgICB9O1xyXG59XSlcclxuXHJcbi5zZXJ2aWNlKCdzb2NrZXRTZXJ2aWNlJywgWyckd2luZG93JywgJyR0aW1lb3V0JywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICdsYW5nJywgJ2FwaScsICdOb3RpZmljYXRpb24nLCBmdW5jdGlvbigkd2luZG93LCAkdGltZW91dCwgYXBpQ29uZmlnLCBteUNvbmZpZywgbGFuZywgYXBpLCBOb3RpZmljYXRpb24pIHtcclxuICAgIHZhciBzb2NrZXRTZXJ2aWNlID0gdGhpcztcclxuICAgIHZhciB3ZWJzb2NrZXRJbnN0cyA9IHt9O1xyXG4gICAgICAgIFxyXG4gICAgc29ja2V0U2VydmljZS5jb25uZWN0ID0gZnVuY3Rpb24odXJsLCBoYW5kbGVGbk9iaikge1xyXG4gICAgICAgIHZhciBzb2NrZXQgPSB3ZWJzb2NrZXRJbnN0c1t1cmxdO1xyXG4gICAgICAgIGlmKCFzb2NrZXQgfHwgc29ja2V0LnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5DTE9TRUQpIHtcclxuICAgICAgICAgICAgc29ja2V0ID0gbmV3IFdlYlNvY2tldCh1cmwpO1xyXG4gICAgICAgICAgICB3ZWJzb2NrZXRJbnN0c1t1cmxdID0gc29ja2V0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc29ja2V0Lm9ub3BlbiA9IGZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICAgICAgaGFuZGxlRm5PYmoub25vcGVuICYmIGhhbmRsZUZuT2JqLm9ub3BlbihldmVudCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBcclxuICAgICAgICBzb2NrZXQub25tZXNzYWdlID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgaGFuZGxlRm5PYmoub25tZXNzYWdlICYmIGhhbmRsZUZuT2JqLm9ubWVzc2FnZShldmVudCk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgc29ja2V0Lm9uY2xvc2UgPSBmdW5jdGlvbihldmVudCkge1xyXG4gICAgICAgICAgICBzb2NrZXQua2VlcEFsaXZlKCk7XHJcbiAgICAgICAgICAgIC8vIGhhbmRsZUZuT2JqLm9uY2xvc2UgJiYgb25jbG9zZS5vbmNsb3NlKGV2ZW50KTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzb2NrZXQub25lcnJvciA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgIHNvY2tldC5rZWVwQWxpdmUoKTtcclxuICAgICAgICAgICAgLy8gaGFuZGxlRm5PYmoub25lcnJvciAmJiBoYW5kbGVGbk9iai5vbmVycm9yKGV2ZW50KTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBzb2NrZXQua2VlcEFsaXZlID0gZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdmFyIHNlc3Npb25TdGF0ZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzZXNzaW9uU3RhdGUnKTtcclxuICAgICAgICAgICAgICAgIGlmIChzZXNzaW9uU3RhdGUgIT0gJ0luYWN0aXZlJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHNvY2tldFNlcnZpY2UuY29ubmVjdCh1cmwsIGhhbmRsZUZuT2JqKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgNTAwMCk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHNvY2tldDtcclxuICAgIH1cclxufV0pXHJcblxyXG4vKipcclxuICogRHJvcGRvd24gY29tbXVuaWNhdGlvbiBzZXJ2aWNlLlxyXG4gKiBUaGlzIG1vZHVsZSB3aWxsIHByb3ZpZGUgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHR3byBkcm9wZG93biBhcyBzZXJ2aWNlLlxyXG4gKiBAbW9kdWxlIGRkU2VydmljZVxyXG4gKi9cclxuLnNlcnZpY2UoJ2RkU2VydmljZScsIFsnJGRvY3VtZW50JywgJyRyb290U2NvcGUnLCAnJHRpbWVvdXQnLCBmdW5jdGlvbigkZG9jdW1lbnQsICRyb290U2NvcGUsICR0aW1lb3V0KSB7XHJcbiAgICB2YXIgb3BlblNjb3BlID0gbnVsbDtcclxuICAgIHZhciBkb2NrU2NvcGUgPSBudWxsO1xyXG5cclxuICAgIHRoaXMuZ2V0T3BlbmVkID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgcmV0dXJuIG9wZW5TY29wZTtcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5vcGVuID0gZnVuY3Rpb24oZHJvcGRvd25TY29wZSwgZWxlbWVudCkge1xyXG4gICAgICAgIGlmICghb3BlblNjb3BlICYmIGRvY2tTY29wZSkge1xyXG4gICAgICAgICAgICBvcGVuU2NvcGUgPSBkb2NrU2NvcGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob3BlblNjb3BlICYmIG9wZW5TY29wZSAhPT0gZHJvcGRvd25TY29wZSAmJiAoZHJvcGRvd25TY29wZS5kb2NrYWJsZSB8fCAhb3BlblNjb3BlLmlzRG9jaykpIHtcclxuICAgICAgICAgICAgb3BlblNjb3BlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAoZG9ja1Njb3BlICYmIGRvY2tTY29wZS5pc0RvY2spIHtcclxuICAgICAgICAgICAgICAgIGRvY2tTY29wZS5pc09wZW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoXCJkZDpjaGFuZ2VkXCIsIHsgbmFtZTogZG9ja1Njb3BlLm5hbWUsIHZpc2libGU6IGRvY2tTY29wZS5pc09wZW4sIGV2ZW50OiAndmlzaWJpbGl0eScgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBpc0RvY2sgPSBmYWxzZTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpc0RvY2sgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZG9jaycpO1xyXG4gICAgICAgICAgICBpZiAoaXNEb2NrID09PSBcInRydWVcIilcclxuICAgICAgICAgICAgICAgIGlzRG9jayA9IHRydWU7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKGlzRG9jayA9PT0gXCJmYWxzZVwiKVxyXG4gICAgICAgICAgICAgICAgaXNEb2NrID0gZmFsc2U7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgaWYgKGRyb3Bkb3duU2NvcGUuZG9ja2FibGUpIHtcclxuICAgICAgICAgICAgZHJvcGRvd25TY29wZS5pc0RvY2sgPSBpc0RvY2s7XHJcbiAgICAgICAgICAgIGlmIChpc0RvY2spIHtcclxuICAgICAgICAgICAgICAgIGRvY2tTY29wZSA9IGRyb3Bkb3duU2NvcGU7XHJcbiAgICAgICAgICAgICAgICBhbmd1bGFyLmVsZW1lbnQod2luZG93KS5zY3JvbGxUb3AoMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9wZW5TY29wZSA9IGRyb3Bkb3duU2NvcGU7XHJcblxyXG4gICAgICAgICRkb2N1bWVudC5vZmYoJ2NsaWNrJywgY2xvc2VEcm9wZG93bik7XHJcbiAgICAgICAgJGRvY3VtZW50Lm9uKCdjbGljaycsIGNsb3NlRHJvcGRvd24pO1xyXG4gICAgICAgICRkb2N1bWVudC5vZmYoJ2tleWRvd24nLCB0aGlzLmtleWJpbmRGaWx0ZXIpO1xyXG4gICAgICAgICRkb2N1bWVudC5vbigna2V5ZG93bicsIHRoaXMua2V5YmluZEZpbHRlcik7XHJcbiAgICB9O1xyXG5cclxuICAgIHRoaXMuY2xvc2UgPSBmdW5jdGlvbihkcm9wZG93blNjb3BlLCBlbGVtZW50KSB7XHJcbiAgICAgICAgaWYgKG9wZW5TY29wZSA9PT0gZHJvcGRvd25TY29wZSkge1xyXG4gICAgICAgICAgICBpZiAoZG9ja1Njb3BlID09PSBvcGVuU2NvcGUpIHtcclxuICAgICAgICAgICAgICAgIC8vXHRcdFx0XHRkb2NrU2NvcGUuaXNEb2NrID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBkb2NrU2NvcGUgPSBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wZW5TY29wZSA9IG51bGw7XHJcbiAgICAgICAgICAgICRkb2N1bWVudC5vZmYoJ2NsaWNrJywgY2xvc2VEcm9wZG93bik7XHJcbiAgICAgICAgICAgICRkb2N1bWVudC5vZmYoJ2tleWRvd24nLCB0aGlzLmtleWJpbmRGaWx0ZXIpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5jbG9zZU9wZW5Ecm9wZG93biA9IGZ1bmN0aW9uKGRyb3Bkb3duU2NvcGUpIHtcclxuICAgICAgICBpZiAob3BlblNjb3BlKSB7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBvcGVuU2NvcGUuaXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgIG9wZW5TY29wZS5leHBhbmRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBvcGVuU2NvcGUuZm9jdXNUb2dnbGVFbGVtZW50KCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoISRyb290U2NvcGUuJCRwaGFzZSkge1xyXG4gICAgICAgICAgICAgICAgb3BlblNjb3BlLiRhcHBseSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wZW5TY29wZSA9IG51bGw7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAoZG9ja1Njb3BlID09PSBvcGVuU2NvcGUpIHtcclxuICAgICAgICAgICAgICAgIGRvY2tTY29wZSA9IG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3BlblNjb3BlID0gbnVsbDtcclxuICAgICAgICAgICAgJGRvY3VtZW50Lm9mZignY2xpY2snLCBjbG9zZURyb3Bkb3duKTtcclxuICAgICAgICAgICAgJGRvY3VtZW50Lm9mZigna2V5ZG93bicsIHRoaXMua2V5YmluZEZpbHRlcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuZG9jayA9IGZ1bmN0aW9uKGRyb3Bkb3duU2NvcGUsIGVsZW1lbnQpIHtcclxuICAgICAgICBpZiAoZG9ja1Njb3BlICYmIGRvY2tTY29wZSAhPT0gZHJvcGRvd25TY29wZSkge1xyXG4gICAgICAgICAgICAvL1x0XHRcdGRvY2tTY29wZS5pc0RvY2sgPSBmYWxzZTtcclxuICAgICAgICAgICAgZG9ja1Njb3BlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBkb2NrU2NvcGUgPSBkcm9wZG93blNjb3BlO1xyXG4gICAgICAgICR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBpZiAoIWRvY2tTY29wZS5pc0RvY2sgJiYgZG9ja1Njb3BlLmlzT3Blbikge1xyXG4gICAgICAgICAgICAgICAgb3BlblNjb3BlID0gZHJvcGRvd25TY29wZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoZHJvcGRvd25TY29wZS5pc0RvY2spIHtcclxuICAgICAgICAgICAgYW5ndWxhci5lbGVtZW50KHdpbmRvdykuc2Nyb2xsVG9wKDApO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgdmFyIGNsb3NlRHJvcGRvd24gPSBmdW5jdGlvbihldnQpIHtcclxuICAgICAgICAvLyBUaGlzIG1ldGhvZCBtYXkgc3RpbGwgYmUgY2FsbGVkIGR1cmluZyB0aGUgc2FtZSBtb3VzZVxyXG4gICAgICAgIC8vIGV2ZW50IHRoYXRcclxuICAgICAgICAvLyB1bmJvdW5kIHRoaXMgZXZlbnQgaGFuZGxlci4gU28gY2hlY2sgb3BlblNjb3BlIGJlZm9yZVxyXG4gICAgICAgIC8vIHByb2NlZWRpbmcuXHJcbiAgICAgICAgaWYgKCFvcGVuU2NvcGUgfHwgb3BlblNjb3BlLmlzRG9jayB8fCBvcGVuU2NvcGUuZXhwYW5kZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGV2dCAmJiBvcGVuU2NvcGUuZ2V0QXV0b0Nsb3NlKCkgPT09ICdkaXNhYmxlZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGV2dCAmJiBldnQud2hpY2ggPT09IDMpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdmFyIHRvZ2dsZUVsZW1lbnQgPSBvcGVuU2NvcGUuZ2V0VG9nZ2xlRWxlbWVudCgpO1xyXG4gICAgICAgIGlmIChldnQgJiYgdG9nZ2xlRWxlbWVudCAmJlxyXG4gICAgICAgICAgICB0b2dnbGVFbGVtZW50WzBdLmNvbnRhaW5zKGV2dC50YXJnZXQpKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZhciBkcm9wZG93bkVsZW1lbnQgPSBvcGVuU2NvcGUuZ2V0RHJvcGRvd25FbGVtZW50KCk7XHJcbiAgICAgICAgaWYgKGV2dCAmJiBvcGVuU2NvcGUuZ2V0QXV0b0Nsb3NlKCkgPT09ICdvdXRzaWRlQ2xpY2snICYmXHJcbiAgICAgICAgICAgIGRyb3Bkb3duRWxlbWVudCAmJlxyXG4gICAgICAgICAgICBkcm9wZG93bkVsZW1lbnRbMF0uY29udGFpbnMoZXZ0LnRhcmdldCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGV2dCAmJiBvcGVuU2NvcGUuZ2V0QXV0b0Nsb3NlKCkgPT09ICdvdXRzaWRlQ2xpY2snICYmXHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgICQoZXZ0LnRhcmdldCkuY2xvc2VzdCgnbWF0LW9wdGlvbixuZ2ItZGF0ZXBpY2tlcixtYXQtZGF0ZXBpY2tlci1jb250ZW50LCAuY29udGV4dC1tZW51LWxpc3QsIC5uby1hdXRvLWNsb3NlJykubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9wZW5TY29wZS5pc09wZW4gPSBmYWxzZTtcclxuICAgICAgICBvcGVuU2NvcGUuZXhwYW5kZWQgPSBmYWxzZTtcclxuICAgICAgICBvcGVuU2NvcGUuZm9jdXNUb2dnbGVFbGVtZW50KCk7XHJcblxyXG4gICAgICAgIGlmICghJHJvb3RTY29wZS4kJHBoYXNlKSB7XHJcbiAgICAgICAgICAgIG9wZW5TY29wZS4kYXBwbHkoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICRyb290U2NvcGUuJGJyb2FkY2FzdChcImRkOmNoYW5nZWRcIiwgeyBuYW1lOiBvcGVuU2NvcGUubmFtZSwgdmlzaWJsZTogb3BlblNjb3BlLmlzT3BlbiwgZXZlbnQ6ICd2aXNpYmlsaXR5JyB9KTtcclxuICAgICAgICBvcGVuU2NvcGUgPSBudWxsO1xyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLmtleWJpbmRGaWx0ZXIgPSBmdW5jdGlvbihldnQpIHtcclxuICAgICAgICBpZiAoIW9wZW5TY29wZSB8fCBvcGVuU2NvcGUuaXNEb2NrKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYgKGV2dC53aGljaCA9PT0gMjcpIHtcclxuICAgICAgICAgICAgZXZ0LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICBvcGVuU2NvcGUuZm9jdXNUb2dnbGVFbGVtZW50KCk7XHJcbiAgICAgICAgICAgIGNsb3NlRHJvcGRvd24oKTtcclxuICAgICAgICB9IGVsc2UgaWYgKG9wZW5TY29wZS5pc0tleW5hdkVuYWJsZWQoKSAmJiBbMzgsIDQwXS5pbmRleE9mKGV2dC53aGljaCkgIT09IC0xICYmXHJcbiAgICAgICAgICAgIG9wZW5TY29wZS5pc09wZW4gJiYgIW9wZW5TY29wZS5pc0RvY2spIHtcclxuICAgICAgICAgICAgZXZ0LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgIGV2dC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgb3BlblNjb3BlLmZvY3VzRHJvcGRvd25FbnRyeSAmJiBvcGVuU2NvcGUuZm9jdXNEcm9wZG93bkVudHJ5KGV2dC53aGljaCk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufV0pXHJcblxyXG4vKipcclxuICogaHRtbGZvcm1zZXJ2aWNlIHNlcnZpY2UuXHJcbiAqIFRoaXMgbW9kdWxlIHdpbGwgcHJvdmlkZSBkaXN0cmlidXRpb24gdG8gaHRtbCBhcHBzIGFzIHNlcnZpY2UuXHJcbiAqIEBtb2R1bGUgaHRtbGZvcm1zZXJ2aWNlXHJcbiAqL1xyXG4uc2VydmljZSgnaHRtbGZvcm1zZXJ2aWNlJywgWyckZG9jdW1lbnQnLCAnJHJvb3RTY29wZScsICckdGltZW91dCcsIGZ1bmN0aW9uKCRkb2N1bWVudCwgJHJvb3RTY29wZSwgJHRpbWVvdXQpIHtcclxuICAgIHRoaXMuZGlzdFNlbGVjdDtcclxuICAgIHRoaXMuYXNzb2NpYXRlQ2xvc2VDb21wbGVhdGU7XHJcbiAgICB0aGlzLmFzc29jaWF0ZUxvY2F0aW9uQ29tcGxldGU7XHJcbiAgICB0aGlzLmFzc29jaWF0ZURlbGV0ZUNvbXBsZWF0ZTtcclxuICAgIHRoaXMuYXNzb2NGaWxlU2VydmljZTtcclxuICAgIFxyXG4gICAgdGhpcy5yZWdpc3RlckRpc3RTZWxlY3RTY29wZSA9IGZ1bmN0aW9uKHNjb3BlKSB7XHJcbiAgICAgICAgdGhpcy5kaXN0U2VsZWN0ID0gc2NvcGU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBUbyBnZXQgYXNzb2NpYXRlZExvY2F0aW9uIGRhdGEgaW4gSFRNTDUgZm9ybS5cclxuICAgICAqIFRoaXMgY2FsbGJhY2sgZnVuY3Rpb24gY2FsbGVkIGFmdGVyIExvY2F0aW9uIGFzc29jaXRlZCBjb21wbGV0ZWRcclxuICAgICAqIFdoaWNoIHJldHVybnMgbmV3bHkgYXNzb2NpYXRlZCBvYmplY3QgYW5kIGFzc29jaWF0aW9uIHNjb3BlIFxyXG4gICAgICogdGhpcy5hc3NvY2lhdGVMb2NhdGlvbkNvbXBsZXRlIG5lZWQgdG8gZGVmaW5lIGluIEN1c3RvbSBIVE1MNSBmb3JtJ3MganMuIGkuZSB3ZWVrbHkuY2hlY2tsaXN0LmpzXHJcbiAgICAgKi9cclxuICAgIHRoaXMuYXNzb2NpYXRlTG9jYXRpb25DYWxsYmFjayA9IGZ1bmN0aW9uKGFyZ3MpIHtcclxuICAgICAgICB0aGlzLmFzc29jaWF0ZUxvY2F0aW9uQ29tcGxldGUgJiYgdGhpcy5hc3NvY2lhdGVMb2NhdGlvbkNvbXBsZXRlKGFyZ3MpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogVG8gZ2V0IGFzc29jaWF0ZWQgZGF0YSBpbiBIVE1MNSBmb3JtLlxyXG4gICAgICogVGhpcyBjYWxsYmFjayBmdW5jdGlvbiBjYWxsZWQgYWZ0ZXIgYXNzb2NpdGVkIGNvbXBsZXRlZFxyXG4gICAgICogV2hpY2ggcmV0dXJucyBuZXdseSBhc3NvY2lhdGVkIG9iamVjdCBhbmQgYXNzb2NpYXRpb24gc2NvcGUgXHJcbiAgICAgKiB0aGlzLmFzc29jaWF0ZUNsb3NlQ29tcGxlYXRlIG5lZWQgdG8gZGVmaW5lIGluIEN1c3RvbSBIVE1MNSBmb3JtJ3MganMuIGkuZSBsb3Iud29ya3BhY2suanNcclxuICAgICAqL1xyXG4gICAgdGhpcy5hc3NvY2lhdGVBbmRDbG9zZUNhbGxiYWNrID0gZnVuY3Rpb24oYXJncykge1xyXG4gICAgICAgIHRoaXMuYXNzb2NpYXRlQ2xvc2VDb21wbGVhdGUgJiYgdGhpcy5hc3NvY2lhdGVDbG9zZUNvbXBsZWF0ZShhcmdzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEhhbmRsZSByZW1vdmUgYXNzb2NpYXRlIGNhbGxiYWNrLlxyXG4gICAgICogV2hpY2ggcmV0dXJucyByZW1vdmVkIG9iamVjdCBhbmQgbGlzdGluZyBzY29wZSBcclxuICAgICAqIHRoaXMuYXNzb2NpYXRlRGVsZXRlQ29tcGxlYXRlIG5lZWQgdG8gZGVmaW5lIGluIEN1c3RvbSBIVE1MNSBmb3JtJ3MganMuIGkuZSBsb3Iud29ya3BhY2suanNcclxuICAgICAqL1xyXG4gICAgdGhpcy5hc3NvY2lhdGVEZWxldGVDYWxsYmFjayA9IGZ1bmN0aW9uKGFyZ3MpIHtcclxuICAgICAgICB0aGlzLmFzc29jaWF0ZURlbGV0ZUNvbXBsZWF0ZSAmJiB0aGlzLmFzc29jaWF0ZURlbGV0ZUNvbXBsZWF0ZShhcmdzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEhhbmRsZXIgdXNlZCB0byBnZXQgYXNzb2NpYXRpb24ncyBzY29wZSBhbmQgY3RybCBvYmplY3QgZnJvbSBhc3NvYy5kYXRhLnRhYi5qc1xyXG4gICAgICogdGhpcy5hc3NvY0ZpbGVTZXJ2aWNlIG5lZWQgdG8gZGVmaW5lIGluIEN1c3RvbSBIVE1MNSBmb3JtJ3MganMuIGkuZSBsb3Iud29ya3BhY2suanNcclxuICAgICAqL1xyXG4gICAgdGhpcy5hc3NvY0ZpbGVIYW5kbGVyID0gZnVuY3Rpb24oc2NvcGUsIGN0cmwpe1xyXG4gICAgICAgIHRoaXMuYXNzb2NGaWxlU2VydmljZSA9IHtcclxuICAgICAgICAgICAgc2NvcGU6IHNjb3BlLCBjdHJsOiBjdHJsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufV0pIiwiYW5ndWxhci5tb2R1bGUoXCJhZG9kZGxlXCIpLmNvbnRyb2xsZXIoJ0Zvcm1WaWV3Q29udHJvbGxlcicsXHJcblx0Wyckc2NvcGUnLCAnJGVsZW1lbnQnLCAnJHdpbmRvdycsICckdGltZW91dCcsICckdWliTW9kYWwnLCAnYXBpJywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsJ05vdGlmaWNhdGlvbicsICdsYW5nJyxcclxuXHRcdGZ1bmN0aW9uICgkc2NvcGUsICRlbGVtZW50LCAkd2luZG93LCAkdGltZW91dCwgJHVpYk1vZGFsLCBhcGksIGFwaUNvbmZpZywgbXlDb25maWcsIE5vdGlmaWNhdGlvbiwgbGFuZykge1xyXG5cdFx0XHR2YXIgY3RybCA9IHRoaXM7XHJcblx0XHRcdHZhciBib2R5ID0gZG9jdW1lbnQuYm9keTtcclxuXHRcdFx0dmFyIGRvY0VsZW1lbnQgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XHJcblx0XHRcdHZhciBtYWluVGhyZWFkID0gdW5kZWZpbmVkO1xyXG5cdFx0XHQkc2NvcGUubG9naW5Mb2FkZXIgPSBmYWxzZTtcclxuXHRcdFx0JHNjb3BlLm1haW5UaHJlYWQgPSB7fTtcclxuXHJcblx0XHRcdHZhciBpbml0ID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdG9uQ29tcGxldGUoKTtcclxuXHRcdFx0XHRsaXN0ZW4oKTtcclxuXHRcdFx0fTtcclxuXHJcblx0XHRcdHZhciBsaXN0ZW4gPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0Ly8gbGlzdGVuIGZvciB0aHJlYWRzXHJcblx0XHRcdFx0JHNjb3BlLiRvbigndGhyZWFkOmxvYWQnLCBvblRocmVhZExvYWQpO1xyXG5cdFx0XHRcclxuXHRcdFx0XHQvLyBtYWtlIGhlYWRlciBzdGlja3kgb24gc2Nyb2xsXHJcblx0XHRcdFx0YW5ndWxhci5lbGVtZW50KCR3aW5kb3cpLmJpbmQoXCJzY3JvbGxcIiwgYW5ndWxhci5iaW5kKGN0cmwsIGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRcdHZhciBzY3JvbGxUb3AgPSBib2R5LnNjcm9sbFRvcCB8fCAoZG9jRWxlbWVudCAmJiBkb2NFbGVtZW50LnNjcm9sbFRvcCkgfHwgMDtcclxuXHRcdFx0XHRcdHZhciAkaGVhZGVyID0gJGVsZW1lbnQuZmluZCgnLnRocmVhZC1oZWFkZXInKTtcclxuXHRcdFx0XHRcdGlmIChzY3JvbGxUb3AgPiA1KVxyXG5cdFx0XHRcdFx0XHQkaGVhZGVyLmFkZENsYXNzKCdmaXhlZCcpO1xyXG5cdFx0XHRcdFx0ZWxzZVxyXG5cdFx0XHRcdFx0XHQkaGVhZGVyLnJlbW92ZUNsYXNzKCdmaXhlZCcpO1xyXG5cdFx0XHRcdH0pKTtcclxuXHJcblxyXG5cdFx0XHRcdCRzY29wZS4kb24oJ2RkOmNoYW5nZWQnLCBvbkRET3BlbkNsb3NlKTtcclxuXHRcdFx0fTtcclxuXHJcblx0XHRcdC8qKlxyXG5cdFx0XHQgKiBpbnZva2Ugb24gZHJvcGRvd24gb3BlbiAvIGNsb3NlXHJcblx0XHRcdCAqL1xyXG5cdFx0XHR2YXIgb25ERE9wZW5DbG9zZSA9IGZ1bmN0aW9uIChldmVudCwgZGQpIHtcclxuXHRcdFx0XHQkdGltZW91dChmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRhbmd1bGFyLmVsZW1lbnQod2luZG93KS5yZXNpemUoKTtcclxuXHRcdFx0XHR9LCA1MCk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgb25UaHJlYWRMb2FkID0gZnVuY3Rpb24gKGUsIHRocmVhZExpc3QpIHtcclxuXHRcdFx0XHRpZiAobWFpblRocmVhZCB8fCAhdGhyZWFkTGlzdCB8fCAhdGhyZWFkTGlzdC5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdG1haW5UaHJlYWQgPSB0aHJlYWRMaXN0WzBdO1xyXG5cdFx0XHRcdGlmICghbWFpblRocmVhZC5zdGF0dXMpIHtcclxuXHRcdFx0XHRcdG1haW5UaHJlYWQuc3RhdHVzID0gJ04vQSc7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdG9uQ29tcGxldGUoKTtcclxuXHRcdFx0fTtcclxuXHJcblx0XHRcdHZhciBvbkNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdGlmIChtYWluVGhyZWFkKSB7XHJcblx0XHRcdFx0XHQkc2NvcGUubWFpblRocmVhZCA9IG1haW5UaHJlYWQ7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvKipcclxuXHRcdFx0ICogaW52b2tlIG9uIExvZ2luIGJ1dHRvbiBjbGljayBpbiB0aGUgcHVibGljIGZvcm0uIFxyXG5cdFx0XHQgKi9cclxuXHRcdFx0JHNjb3BlLmxvZ2luTWFya2V0cGxhY2UgPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0bG9naW5Nb2RhbCgpO1xyXG5cdFx0XHR9O1x0XHRcclxuXHJcblx0XHRcdC8qKlxyXG5cdFx0XHQgKiAgT3BlbiBsb2dpbiBtb2RhbCBhbmQgaGFuZGxlZCBjaGlsZCBjb250cm9sbGVyIGV2ZW50cy4gXHJcblx0XHRcdCAqL1xyXG5cdFx0XHR2YXIgbG9naW5Nb2RhbCA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHQvL0luIG1vZGFsIGNvbnRyb2xsZXIgY2FsbFxyXG5cdFx0XHRcdHZhciBjaGlsZENvbnRyb2xsZXIgPSBmdW5jdGlvbiAoJHNjb3BlLCAkdWliTW9kYWxJbnN0YW5jZSkge1xyXG5cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdC8vIExvZ2luIGJ1dHRvbiBjbGljayBldmVudCBcclxuXHRcdFx0XHRcdCRzY29wZS51c2VyTG9naW4gPSBmdW5jdGlvbiAoKSB7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR2YXIgZGF0YSA9e1xyXG5cdFx0XHRcdFx0XHRcdGVtYWlsOiB0aGlzLmVtYWlsICYmIHRoaXMuZW1haWwudHJpbSgpLFxyXG5cdFx0XHRcdFx0XHRcdHBhc3N3b3JkOiB0aGlzLnBhc3N3b3JkXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdGlmIChkYXRhLmVtYWlsID09PSAnJyB8fCBkYXRhLnBhc3N3b3JkID09PSAnJykge1x0XHJcblx0XHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLmVycm9yKHsgbWVzc2FnZTogbGFuZy5nZXQoXCJwYXNzd29yZGludmFsaWRtc2dcIikgfSk7XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdFx0XHQvLyBDaGVjayBmb3IgdmFsaWQgcGFzc3dvcmQgYW5kIGVtYWlsIGFuZCByZXR1cm5lZCBVU1Agb2JqZWN0XHJcblx0XHRcdFx0XHRcdCRzY29wZS5sb2dpbkxvYWRlciA9IHRydWU7XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHR2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdFx0XHRcdHVybDogXCJjb21tb25hcGkvbG9naW5cIixcclxuXHRcdFx0XHRcdFx0XHRkYXRhOiBkYXRhLFxyXG5cdFx0XHRcdFx0XHRcdGVycm9ybXNnOiAnT29wcyBMb2dpbiBFcnJvciEnLFxyXG5cdFx0XHRcdFx0XHRcdEFwaUtleTogd2luZG93Lm1hcmtldHBsYWNlQXBpS2V5XHJcblx0XHRcdFx0XHRcdH0pO1xyXG5cclxuXHRcdFx0XHRcdFx0eGhyLnRoZW4oZnVuY3Rpb24gKGRhdGEpIHtcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdHZhciBkYXRhID0gSlNPTi5wYXJzZShkYXRhLmVudGl0eSk7XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0dmFyIHBhcmFtRGF0YSA9IHtcclxuXHRcdFx0XHRcdFx0XHRcdGFjdGlvbl9pZDogMTczMyxcclxuXHRcdFx0XHRcdFx0XHRcdHByb2plY3RJZDogbXlDb25maWcucHJvamVjdElkLFxyXG5cdFx0XHRcdFx0XHRcdFx0Zm9ybVR5cGVJZDogbXlDb25maWcuZm9ybVR5cGVJZCxcclxuXHRcdFx0XHRcdFx0XHRcdGZvcm1JZDogbXlDb25maWcuZm9ybUlkLFxyXG5cdFx0XHRcdFx0XHRcdFx0bXNnSWQ6IG15Q29uZmlnLm1zZ0lkLFxyXG5cdFx0XHRcdFx0XHRcdFx0Y29tbUlkOiBteUNvbmZpZy5jb21tSWRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcdCR1aWJNb2RhbEluc3RhbmNlLmNsb3NlKHsgbXk6ICdkYXRhJyB9KTtcclxuXHRcdFx0XHRcdFx0XHQvLyBQYXNzIE9sZCBoYXNlZCB2YWx1ZSBwYXJhbWV0ZXIgYW5kIHJldHVybmVkIG5ldyBoYXNlZCB2YWx1ZSBwYXJhbWV0ZXIgdG8gb3BlbiBmb3JtLlxyXG5cdFx0XHRcdFx0XHRcdHZhciB4aHJEYXRhID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdFx0XHRcdFx0dXJsOiBcImFkb2RkbGVwdWJsaWMvcHVibGljVmlld0Zvcm1cIixcclxuXHRcdFx0XHRcdFx0XHRcdGRhdGE6IHBhcmFtRGF0YSxcclxuXHRcdFx0XHRcdFx0XHRcdGVycm9ybXNnOiAnT29wcyBMb2dpbiBFcnJvciEnLFxyXG5cdFx0XHRcdFx0XHRcdFx0QXBpS2V5OiB3aW5kb3cubWFya2V0cGxhY2VBcGlLZXlcclxuXHRcdFx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdFx0XHR4aHJEYXRhLnRoZW4oZnVuY3Rpb24gKHJlc0RhdGEpIHtcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0XHQkc2NvcGUubG9naW5Mb2FkZXIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdFx0XHRcdC8vU3VibWl0IG5ldyBwYXJhbWV0ZXJcclxuXHRcdFx0XHRcdFx0XHRcdGFwaS5zdWJtaXRGb3JtKHtcclxuXHRcdFx0XHRcdFx0XHRcdFx0dGFyZ2V0OiAnX3NlbGYnLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcclxuXHRcdFx0XHRcdFx0XHRcdFx0dXJsOiByZXNEYXRhLmhhc0Zvcm1BY2Nlc3MgPyBhcGlDb25maWcuVklFV19GT1JNIDogXCIvYWRvZGRsZXB1YmxpYy9wdWJsaWNWaWV3Rm9ybS5qc3BcIixcclxuXHRcdFx0XHRcdFx0XHRcdFx0cGFyYW06IHJlc0RhdGFcclxuXHRcdFx0XHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdFx0XHRcdH0sIGZ1bmN0aW9uICh4aHJEYXRhKSB7XHJcblx0XHRcdFx0XHRcdFx0XHQkc2NvcGUubG9naW5Mb2FkZXIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdFx0XHR9KTtcdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdFx0fSwgZnVuY3Rpb24gKHhocikge1xyXG5cdFx0XHRcdFx0XHRcdCRzY29wZS5sb2dpbkxvYWRlciA9IGZhbHNlO1xyXG5cdFx0XHRcdFx0XHRcdGlmICh4aHIuZGF0YSA9PT0gJ0ludmFsaWQgY3JlZGVudGlhbHMuJykge1xyXG5cdFx0XHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLmVycm9yKHsgbWVzc2FnZTogbGFuZy5nZXQoXCJwYXNzd29yZGludmFsaWRtc2dcIikgfSk7XHRcclxuXHRcdFx0XHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdFx0aWYgKHhoci5kYXRhID09PSAnQWNjb3VudCBsb2NrZWQuJykge1xyXG5cdFx0XHRcdFx0XHRcdFx0Tm90aWZpY2F0aW9uLmVycm9yKHsgbWVzc2FnZTogbGFuZy5nZXQoXCJhY2NvdW50LWxvY2tcIikgfSk7XHRcdFx0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdFx0Ly8gUGFzc3dvcmQgdGV4dGJveCBrZXlkb3duIGV2ZW50IFxyXG5cdFx0XHRcdFx0JHNjb3BlLm9uRW50ZXJMb2dpbiA9IGZ1bmN0aW9uICgkZXZlbnQpIHtcclxuXHRcdFx0XHRcdFx0aWYgKCRldmVudC5rZXlDb2RlID09IDEzKSB7XHJcblx0XHRcdFx0XHRcdFx0JHNjb3BlLnVzZXJMb2dpbigpO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdFx0Ly8gQ2FuY2VsIGJ1dHRvbiBjbGljayBldmVudCAgdG8gY2xvc2UgbW9kYWxcclxuXHRcdFx0XHRcdCRzY29wZS5jYW5jZWwgPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRcdCR1aWJNb2RhbEluc3RhbmNlLmRpc21pc3MoKTtcclxuXHRcdFx0XHRcdH07XHJcblxyXG5cdFx0XHRcdFx0Ly8gU2lnbiB1cCBjbGljayBldmVidCB0byByZWRpcmVjdCBpbiB0aGUgbWFya2V0cGxhY2UgcGFnZS5cclxuXHRcdFx0XHRcdCRzY29wZS5zaWduVXBGdW4gPSBmdW5jdGlvbiAoKXtcclxuXHRcdFx0XHRcdFx0d2luZG93Lm9wZW4od2luZG93Lm1hcmtldFBsYWNlU2VydmljZVVSTCArIFwiP29yaWdpbj10cnVlJnNpZ251cD10cnVlXCIsXCJfYmxhbmtcIik7XHJcblx0XHRcdFx0XHR9O1x0XHRcclxuXHJcblx0XHRcdFx0XHQvLyBJbiBmb3Jnb3QgcGFzc3dvcmQgY2xpY2sgZXZlbnQgdG8gcmVkaXJlY3QgaW4gdGhlIGZvcmdvdCBwYXNzd29yZCBwYWdlLlxyXG5cdFx0XHRcdFx0JHNjb3BlLmZvcmdvdFBhc3N3b3JkRnVuID0gZnVuY3Rpb24gKCl7XHJcblx0XHRcdFx0XHRcdHdpbmRvdy5vcGVuKG15Q29uZmlnLnBvcnRhbFVybCArICd3aWRnZXQvd2ViL2d1ZXN0L2hvbWU/cF9wX2lkPTU4JmFtcDtwX3BfbGlmZWN5Y2xlPTAmYW1wO3BfcF9zdGF0ZT1ub3JtYWwmYW1wO3BfcF9tb2RlPXZpZXcmYW1wO181OF9zdHJ1dHNfYWN0aW9uPSUyRmxvZ2luJTJGdmlldyZhbXA7XzU4X2NtZD1mb3Jnb3QtcGFzc3dvcmQnLCAnX2JsYW5rJyk7XHJcblx0XHRcdFx0XHR9O1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0Ly8gT3BlbiBMb2dpbiBtb2RhbFxyXG5cdFx0XHRcdCR1aWJNb2RhbC5vcGVuKHtcclxuXHRcdFx0XHRcdGFuaW1hdGlvbjogdHJ1ZSxcclxuXHRcdFx0XHRcdHRlbXBsYXRlVXJsOiAnbWFya2V0cGxhY2VMb2dpbi5odG1sJyxcclxuXHRcdFx0XHRcdGNvbnRyb2xsZXI6IGNoaWxkQ29udHJvbGxlcixcclxuXHRcdFx0XHRcdGJhY2tkcm9wOiAnc3RhdGljJyxcclxuXHRcdFx0XHRcdGtleWJvYXJkOiBmYWxzZSxcclxuXHRcdFx0XHRcdHdpbmRvd0NsYXNzOiAnbWFya2V0cGxhY2UtY2VudGVyLW1vZGFsJ1xyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9O1xyXG5cdFx0XHRpbml0KCk7XHJcblx0XHR9XSk7IiwiYW5ndWxhci5tb2R1bGUoXCJhZG9kZGxlXCIpXHJcblx0LmNvbXBvbmVudCgnY3VzdG9tQ29tbW9uRHJvcGRvd24nLCB7XHJcblx0XHR0cmFuc2NsdWRlIDoge1xyXG5cdFx0ICAgIGxlZnRIZWFkZXI6ICc/bGVmdEhlYWRlcidcclxuXHRcdH0sXHJcblx0XHRiaW5kaW5ncyA6IHtcclxuXHRcdFx0aXNPcGVuIDogJzwnLFxyXG5cdFx0XHRkaWFsb2cgOiAnPCcsXHJcblx0XHRcdGRvY2thYmxlOiAnPCcsXHJcblx0XHRcdGRyYWdnYWJsZSA6ICc8JyxcclxuXHRcdFx0ZXhwYW5kYWJsZTogJzwnLFxyXG5cdFx0XHRhbHdheXNFeHBhbmRlZDogJzwnLFxyXG5cdFx0XHRoaWRlQ2xvc2U6ICc8JyxcclxuXHRcdFx0YnRuVGV4dCA6ICc8JyxcclxuXHRcdFx0YnRuSWQgOiAnQCcsXHJcblx0XHRcdGJ0blRpdGxlOiAnQCcsXHJcblx0XHRcdGJ0bkRpc2FibGVkOiAnPCcsXHJcblx0XHRcdGlzRG9jayA6ICc8JyxcclxuXHRcdFx0a2V5bmF2RW5hYmxlZCA6ICc8JyxcclxuXHRcdFx0dGFyZ2V0QnRuIDogJ0AnLFxyXG5cdFx0XHRkZE5hbWUgOiAnQCcsXHJcblx0XHRcdGRkVGl0bGUgOiAnQCcsXHJcblx0XHRcdGNhcmV0IDogJ0AnLFxyXG5cdFx0XHRpY29uIDogJ0AnLFxyXG5cdFx0XHRpbWdJY29uIDogJ0AnLFxyXG5cdFx0XHRzdmdJY29uOiAnQCcsXHJcblx0XHRcdGhlbHA6ICdAJyxcclxuXHRcdFx0YXV0b0Nsb3NlIDogJ0AnLFxyXG5cdFx0XHRwbGFjZW1lbnQgOiAnQCcsXHJcblx0XHRcdGFwcGVuZFRvIDogJ0AnLFxyXG5cdFx0XHRhcHBseUxvYWRpbmcgOiAnPCcsXHJcblx0XHRcdGxvYWRpbmdUaXRsZSA6ICdAJyxcclxuXHRcdFx0c2hvd0xlZnRIZWFkZXI6ICc8JyxcclxuXHRcdFx0YXV0b09wZW46ICc8J1xyXG5cdFx0fSxcclxuXHRcdHRlbXBsYXRlIDogJzxkaXYgY2xhc3M9XCJjb21wb25lbnQtd3JhcHBlclwiIGF1dG8tY2xvc2U9XCI6OiRjdHJsLmF1dG9DbG9zZVwiIG5nLWNsYXNzPVwie29wZW46IGlzT3Blbn1cIj4gJyArXHJcblx0XHRcdFx0XHRcdCc8YnV0dG9uIG5nLWRpc2FibGVkPVwiJGN0cmwuYnRuRGlzYWJsZWRcIiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgYnV0dG9uLXRvZ2dsZVwiIG5nLWNsaWNrPVwiJGN0cmwub25Ub2dnbGVCdG5DbGljaygpXCIgdGl0bGU9XCJ7eygkY3RybC5hcHBseUxvYWRpbmcgPyAkY3RybC5sb2FkaW5nVGl0bGUgOiAoJGN0cmwuYnRuVGl0bGUgfHwgJGN0cmwuZGRUaXRsZSkpfX1cIiBpZD1cInt7OjokY3RybC5idG5JZH19XCIgbmctaGlkZT1cIjo6KCEkY3RybC5pY29uICYmICEkY3RybC5idG5UZXh0ICYmICEkY3RybC5pbWdJY29uKVwiPiAnICtcclxuXHRcdFx0XHRcdFx0XHQnPGkgbmctaWY9XCI6OiRjdHJsLmljb25cIiBjbGFzcz1cImZhXCIgbmctY2xhc3M9XCI6OiRjdHJsLmljb25cIj48L2k+ICcgK1xyXG5cdFx0XHRcdFx0XHRcdCc8aW1nIG5nLWlmPVwiOjokY3RybC5pbWdJY29uXCIgY2xhc3M9XCJpbWctaWNvblwiIG5nLXNyYz1cInt7JGN0cmwuaW1nSWNvbn19XCIgLz4gJyArXHJcblx0XHRcdFx0XHRcdFx0JzxzcGFuIG5nLWlmPVwiOjokY3RybC5zdmdJY29uXCIgbmctYmluZC1odG1sPVwidHJ1c3RlZEh0bWwoJGN0cmwuc3ZnSWNvbilcIiBzdHlsZT1cIm1hcmdpbi1yaWdodDozcHg7XCI+PC9zcGFuPiAnICtcclxuXHRcdFx0XHRcdFx0XHQnPHNwYW4gbmctYmluZD1cIiRjdHJsLmJ0blRleHRcIj48L3NwYW4+ICcgK1xyXG5cdFx0XHRcdFx0XHRcdCc8c3BhbiBuZy1pZj1cIjo6JGN0cmwuY2FyZXRcIiBjbGFzcz1cImNhcmV0XCI+PC9zcGFuPiAnICtcclxuXHRcdFx0XHRcdFx0XHQnPGRpdiBuZy1pZj1cIjo6JGN0cmwuYXBwbHlMb2FkaW5nXCIgY2xhc3M9XCJsb2FkaW5nIHNtYWxsXCI+PC9kaXY+ICcgK1xyXG5cdFx0XHRcdFx0XHQnPC9idXR0b24+JyArXHJcblx0XHRcdFx0XHRcdCc8bWFpbiBuZy1jbGFzcz1cIntvcGVuOiBpc09wZW59XCIgbWFpbi1uYW1lPVwie3tuYW1lfX1cIj4nICtcclxuXHRcdFx0XHRcdFx0XHQnPGRpdiBuZy1pZj1cIjo6JGN0cmwuZGlhbG9nXCIgY2xhc3M9XCJkcm9wZG93bi1tZW51IGRyb3Bkb3duLW1lbnUtcmlnaHQgZGF0YS1wYW5lbFwiIG5nLWNsYXNzPVwie2RvY2tlZDogKCRjdHJsLmFsd2F5c0V4cGFuZGVkIHx8IGlzRG9jayB8fCBleHBhbmRlZCksIGV4cGFuZGVkOiAoJGN0cmwuYWx3YXlzRXhwYW5kZWQgfHwgZXhwYW5kZWQgfHwgaXNNb2JpbGUpfVwiPiAnICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAnPGRpdiBjbGFzcz1cImlib3hcIj4nICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgJzxkaXYgY2xhc3M9XCJpYm94LXRpdGxlIGNsZWFyZml4XCIgbmctc3R5bGU9XCJ7XFwnY3Vyc29yXFwnOiAkY3RybC5kcmFnZ2FibGUgPyBcXCdtb3ZlXFwnIDogXFwnZGVmYXVsdFxcJyB9XCI+JyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICAnPGRpdiBjbGFzcz1cInB1bGwtbGVmdCBpYm94LWxlZnQtaGVhZGVyXCIgbmctaWY9XCIkY3RybC5zaG93TGVmdEhlYWRlclwiIG5nLXRyYW5zY2x1ZGU9XCJsZWZ0SGVhZGVyXCI+PC9kaXY+JyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICAnPGRpdiBjbGFzcz1cInB1bGwtcmlnaHRcIj4gJyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICBcdCc8c3BhbiBjbGFzcz1cImFjdGlvbi1idG5zXCI+PC9zcGFuPiAnICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgICAgICAgICAnPGJ1dHRvbiBuZy1pZj1cIjo6JGN0cmwuaGVscFwiIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi14c1wiIHRpdGxlPVwie3s6OmxhbmdUaXRsZS5oZWxwfX1cIj48aSBjbGFzcz1cImZhIGZhLXF1ZXN0aW9uXCI+PC9pPjwvYnV0dG9uPiAnICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgICAgICAgICAnPGJ1dHRvbiBuZy1pZj1cIjo6JGN0cmwuZXhwYW5kYWJsZVwiIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi14cyBidXR0b24tZXhwYW5kXCIgbmctY2xpY2s9XCIkY3RybC5taW5NYXgoKVwiIHRpdGxlPVwie3tleHBhbmRlZCA/IGxhbmdUaXRsZS5taW5pbWl6ZSA6IGxhbmdUaXRsZS5tYXhpbWl6ZX19XCI+ICcgK1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQnPGkgY2xhc3M9XCJmYVwiIG5nLWNsYXNzPVwie1xcJ2ZhLWV4cGFuZFxcJzogIWV4cGFuZGVkLCBcXCdmYS1jb21wcmVzc1xcJzogZXhwYW5kZWR9XCI+PC9pPiAnICtcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdCc8L2J1dHRvbj4gJyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICAgICAgJzxidXR0b24gbmctaWY9XCIhZXhwYW5kZWQgJiYgJGN0cmwuZG9ja2FibGVcIiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4teHMgYnV0dG9uLWRvY2tcIiBuZy1jbGljaz1cIiRjdHJsLmFwcGx5RG9jaygkZXZlbnQpXCIgdGl0bGU9XCJ7e2lzRG9jayA/IGxhbmdUaXRsZS51bmRvY2sgOiBsYW5nVGl0bGUuZG9ja319XCI+ICcgKyBcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0JzxpIGNsYXNzPVwiZmEgZmEtdGh1bWItdGFja1wiPjwvaT4gJyArXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQnPC9idXR0b24+ICcgK1xyXG5cdFx0XHRcdFx0XHQgICAgICAgICAgICAgICAgICAgICc8YnV0dG9uIG5nLWlmPVwiJGN0cmwuaGlkZUNsb3NlICE9IHRydWVcIiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4teHMgY2xvc2UtbGlua1wiIHRpdGxlPVwie3s6OmxhbmdUaXRsZS5jbG9zZX19XCIgbmctY2xpY2s9XCIkY3RybC5vblRvZ2dsZUJ0bkNsaWNrKClcIj4gJyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICAgICAgICAgICc8aSBjbGFzcz1cImZhIGZhLXRpbWVzXCI+PC9pPiAnICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgICAgICAgICAnPC9idXR0b24+ICcgK1xyXG5cdFx0XHRcdFx0XHQgICAgICAgICAgICAgICAgJzwvZGl2PicgK1xyXG5cdFx0XHRcdFx0XHQgICAgICAgICAgICAgICAgJzxoNSBuZy1iaW5kPVwiKCRjdHJsLmRvY2tUaXRsZSB8fCAkY3RybC5kZFRpdGxlKVwiPjwvaDU+JyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICc8L2Rpdj4nICtcclxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgJzxkaXYgY2xhc3M9XCJpYm94LWNvbnRlbnQgY2xlYXJmaXhcIiBuZy10cmFuc2NsdWRlPjwvZGl2PicgK1xyXG5cdFx0XHRcdFx0XHRcdFx0XHQnPGRpdiBjbGFzcz1cImlib3gtcG9wdXBzXCI+PC9kaXY+JyArXHJcblx0XHRcdFx0XHRcdCAgICAgICAgJzwvZGl2PicgK1xyXG5cdFx0XHRcdFx0XHRcdCc8L2Rpdj4nICtcclxuXHRcdFx0XHRcdFx0XHQnPHVsIG5nLWlmPVwiOjohJGN0cmwuZGlhbG9nXCIgY2xhc3M9XCJkcm9wZG93bi1tZW51IGRyb3Bkb3duLW1lbnUtcmlnaHRcIiBuZy1jbGFzcz1cIjo6JGN0cmwuZHJvcGRvd25TaXplXCIgbmctdHJhbnNjbHVkZT48L3VsPicgK1xyXG5cdFx0XHRcdFx0XHQnPC9tYWluPicgK1xyXG5cdFx0XHRcdFx0JzwvZGl2PicsXHJcblx0Y29udHJvbGxlciA6IFsnJHNjb3BlJywgJyRlbGVtZW50JywgJyRyb290U2NvcGUnLCAnJHRpbWVvdXQnLCAnZGRTZXJ2aWNlJywgJ2xhbmcnLCAnYXBpJywgJ2RkY2hpbGQnLCAnJHNjZScsXHJcblx0ZnVuY3Rpb24oJHNjb3BlLCAkZWxlbWVudCwgJHJvb3RTY29wZSwgJHRpbWVvdXQsIGRkU2VydmljZSwgbGFuZywgYXBpLCBkZGNoaWxkLCAkc2NlKSB7XHJcblx0XHR2YXIgY3RybCA9IHRoaXM7XHJcblxyXG5cdFx0JHNjb3BlLnRydXN0ZWRIdG1sID0gZnVuY3Rpb24gKHBsYWluVGV4dCkge1xyXG5cdFx0XHRyZXR1cm4gJHNjZS50cnVzdEFzSHRtbChwbGFpblRleHQpO1xyXG5cdFx0fVxyXG5cdFx0XHJcblx0XHQvLyBpbml0aWFsaXphdGlvblxyXG5cdFx0Y3RybC4kb25Jbml0ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdGlmKHdpbmRvdy5pc09mZmxpbmVNb2RlKXtcclxuXHRcdFx0XHRjdHJsLmJ0bklkICE9IFwib2ZmbGluZS1zdGF0dXMtYnRuXCIgJiYgKGN0cmwuYnRuVGV4dCA9IGxhbmcuZ2V0KGN0cmwuYnRuVGV4dCkgfHwgY3RybC5idG5UZXh0KTtcclxuXHRcdFx0fVxyXG5cdFx0XHQkc2NvcGUubmFtZSA9IGN0cmwuZGROYW1lO1xyXG5cdFx0XHQkc2NvcGUuaXNEb2NrID0gY3RybC5pc0RvY2s7XHJcblx0XHRcdCRzY29wZS5pc09wZW4gPSBjdHJsLmlzT3BlbjtcclxuXHRcdFx0JHNjb3BlLmRvY2thYmxlID0gY3RybC5kb2NrYWJsZTtcclxuXHRcdFx0JHNjb3BlLmlzTW9iaWxlID0gYXBpLmlzTW9iaWxlKCk7XHJcblx0XHRcdFxyXG5cdFx0XHQkc2NvcGUubGFuZ1RpdGxlID0ge1xyXG5cdFx0XHRcdGRvY2s6IGxhbmcuZ2V0KCdjbGljay10by1kb2NrLWNvbnRlbnQnKSxcclxuXHRcdFx0XHR1bmRvY2s6IGxhbmcuZ2V0KCdjbGljay10by11bi1kb2NrLWNvbnRlbnQnKSxcclxuXHRcdFx0XHRtaW5pbWl6ZTogbGFuZy5nZXQoJ21pbmltaXplJyksXHJcblx0XHRcdFx0bWF4aW1pemU6IGxhbmcuZ2V0KCdtYXhpbWlzZScpLFxyXG5cdFx0XHRcdGhlbHA6IGxhbmcuZ2V0KCdoZWxwJyksXHJcblx0XHRcdFx0Y2xvc2U6IGxhbmcuZ2V0KCdjbG9zZScpXHJcblx0XHRcdH07XHJcblx0XHRcdFxyXG5cdFx0XHRjdHJsLnRvZ2dsZUVsZW1lbnQgPSAkZWxlbWVudC5maW5kKCdidXR0b24nKTtcclxuXHRcdFx0Y3RybC5kcm9wZG93bk1lbnUgPSAkZWxlbWVudC5maW5kKFwibWFpblwiKTtcclxuXHRcdFx0XHJcblx0XHRcdGlmICgkc2NvcGUuaXNPcGVuIHx8IGN0cmwuYXV0b09wZW4gPT09IHRydWUpIHtcclxuXHRcdFx0XHRsYXlvdXQoKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0aWYgKGN0cmwuYXBwZW5kVG8pIHtcclxuXHRcdFx0XHR2YXIgYXBwZW5kVG9FTCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGN0cmwuYXBwZW5kVG8pIHx8ICdib2R5JztcclxuXHRcdFx0XHQkdGltZW91dChmdW5jdGlvbigpIHtcclxuXHRcdFx0XHRcdGFuZ3VsYXIuZWxlbWVudChhcHBlbmRUb0VMKS5hcHBlbmQoY3RybC5kcm9wZG93bk1lbnUpO1xyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHRsaXN0ZW4oKTtcclxuXHRcdFx0YXBwbHlEcmFnZ2FibGUoKTtcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciBsaXN0ZW4gPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0aWYod2luZG93LiQpIHtcclxuXHRcdFx0XHQkKGRvY3VtZW50KS5vbignYWRvZGRsZS1zaWRlYmFyLW9wZW5lZCcsIGZ1bmN0aW9uKCl7XHJcblx0XHRcdFx0XHRpZigkc2NvcGUuaXNPcGVuICYmICRzY29wZS5pc0RvY2spIHtcclxuXHRcdFx0XHRcdFx0JHNjb3BlLiRicm9hZGNhc3QoJ2RkOmNsb3NlJywge1xyXG5cdFx0XHRcdFx0XHRcdGZvcmNlOiB0cnVlLFxyXG5cdFx0XHRcdFx0XHRcdG5hbWU6IGN0cmwuZGROYW1lXHJcblx0XHRcdFx0XHRcdH0pXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCRzY29wZS4kb24oJ2RkOmNsb3NlJywgZnVuY3Rpb24oZXZlbnQsIGRhdGEpIHtcclxuXHRcdFx0XHRpZiAoJHNjb3BlLmlzT3BlbiAmJiAoKGRhdGEgJiYgZGF0YS5mb3JjZSAmJiBkYXRhLm5hbWUgJiYgZGF0YS5uYW1lID09IGN0cmwuZGROYW1lKSB8fCAhJHNjb3BlLmlzRG9jaykpIHtcclxuXHRcdFx0XHRcdGN0cmwuYnRuVG9nZ2xlKCk7XHJcblx0XHRcdFx0XHR0cmlnZ2VyQ2hhbmdlKGRhdGEsICd2aXNpYmlsaXR5Jyk7XHJcblx0XHRcdCAgXHR9XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRcclxuXHRcdFx0JHNjb3BlLiRvbignZGQ6b3BlbicsIGZ1bmN0aW9uKGV2ZW50LCBkYXRhKSB7XHJcblx0XHRcdFx0aWYgKGRhdGEubmFtZSAhPSBjdHJsLmRkTmFtZSkge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdFx0XHRjdHJsLmRvY2tUaXRsZSA9IGRhdGEuZG9ja1RpdGxlO1xyXG5cclxuXHRcdFx0XHRpZighJHNjb3BlLmlzT3Blbikge1xyXG5cdFx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24oKSB7XHRcdFx0XHQvLyB3YWl0IGZvciBvdXRzaWRlIGNsaWNrIHRvIHBlcmZvcm1cclxuXHRcdFx0XHRcdFx0Y3RybC5idG5Ub2dnbGUoZGF0YSk7XHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0dHJpZ2dlckNoYW5nZShkYXRhLCAndmlzaWJpbGl0eScpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHRcdFxyXG5cdFx0XHQkZWxlbWVudC5vbignJGRlc3Ryb3knLCBmdW5jdGlvbigpIHtcclxuXHRcdFx0XHRjdHJsLmRyb3Bkb3duTWVudS5yZW1vdmUoKTtcclxuXHRcdFx0fSk7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBhcHBseURyYWdnYWJsZSA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRpZighY3RybC5kcmFnZ2FibGUpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCR0aW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdGN0cmwuJGRpYWxvZyA9IGN0cmwuZHJvcGRvd25NZW51LmZpbmQoXCI+IGRpdi5kcm9wZG93bi1tZW51XCIpO1xyXG5cdFx0XHRcdGlmKGN0cmwuJGRpYWxvZy5sZW5ndGgpIHtcclxuXHRcdFx0XHRcdHZhciAkdGl0bGUgPSBjdHJsLiRkaWFsb2cuZmluZCgnLmlib3gtdGl0bGUnKTtcclxuXHRcdFx0XHRcdHZhciAkaGFuZGxlciA9ICR0aXRsZS5sZW5ndGggPyAkdGl0bGUgOiAkZGlhbG9nO1xyXG5cdFx0XHRcdFx0Y3RybC4kZGlhbG9nLmRyYWdnYWJsZSh7XHJcblx0XHRcdFx0XHRcdGN1cnNvcjonbW92ZScsXHJcblx0XHRcdFx0XHRcdGNvbnRhaW5tZW50OiBcImRvY3VtZW50XCIsIFxyXG5cdFx0XHRcdFx0XHRoYW5kbGU6ICRoYW5kbGVyLFxyXG5cdFx0XHRcdFx0XHRkaXN0YW5jZTogMTBcclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSwgMCk7XHJcblx0XHR9XHJcblx0XHRcclxuXHRcdHZhciB0cmlnZ2VyQ2hhbmdlID0gZnVuY3Rpb24oZGF0YSwgdHlwZSkge1xyXG5cclxuXHRcdFx0aWYod2luZG93LiQpIHtcclxuXHRcdFx0XHQkKGRvY3VtZW50KS50cmlnZ2VyKCdjdXN0b20tY29tbW9uLWRyb3Bkb3duLWNoYW5nZWQnLCB7XHJcblx0XHRcdFx0XHR0eXBlOiB0eXBlLFxyXG5cdFx0XHRcdFx0aXNPcGVuOiAkc2NvcGUuaXNPcGVuLFxyXG5cdFx0XHRcdFx0aXNEb2NrOiAkc2NvcGUuaXNEb2NrXHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdHZhciBleHBhbmRlZCA9ICRzY29wZS5leHBhbmRlZDtcclxuXHRcdFx0aWYoZGF0YSAmJiBkYXRhLmhhc093blByb3BlcnR5KCdleHBhbmRlZCcpKSB7XHJcblx0XHRcdFx0JHNjb3BlLmV4cGFuZGVkID0gZGF0YS5leHBhbmRlZDtcclxuXHRcdFx0XHRhZGRDbGFzc1RvQm9keSgpO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHR2YXIgZGQgPSB7IG5hbWUgOiAkc2NvcGUubmFtZSwgdmlzaWJsZSA6ICRzY29wZS5pc09wZW4sIGV4cGFuZGVkIDogJHNjb3BlLmV4cGFuZGVkLCBldmVudDogdHlwZSB9O1xyXG5cdFx0XHRpZih0eXBlb2YgZGF0YSA9PSAnb2JqZWN0Jykge1xyXG5cdFx0XHRcdGRkID0gYW5ndWxhci5tZXJnZShkZCwgZGF0YSk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdChcImRkOmNoYW5nZWRcIiwgZGQpO1xyXG5cdFx0XHRpZighZGRjaGlsZC5pc0xvYWRlZCgkc2NvcGUubmFtZSkpIHtcclxuXHRcdFx0XHRkZGNoaWxkLm9uTG9hZCgkc2NvcGUubmFtZSwgZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHQkcm9vdFNjb3BlLiRicm9hZGNhc3QoXCJkZDpjaGFuZ2VkXCIsIGRkKTtcclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHJcblx0XHR2YXIgbGF5b3V0ID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdHNldFBvc2lzaW9uKCk7XHJcblxyXG5cdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdCRzY29wZS5pc09wZW4gJiYgc2V0UG9zaXNpb24oKTtcclxuXHRcdFx0XHRpZiAoY3RybC5hdXRvT3BlbiA9PT0gdHJ1ZSkge1xyXG5cdFx0XHRcdFx0IGN0cmwub25Ub2dnbGVCdG5DbGljaygpO1xyXG5cdFx0XHRcdFx0IGN0cmwuYXV0b09wZW4gPSBmYWxzZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sIDEwMDApO1xyXG5cdFx0fVxyXG5cclxuXHRcdHZhciBzZXRQb3Npc2lvbiA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHR2YXIgdGFyZ2V0RWxlbWVudCA9IGN0cmwudGFyZ2V0QnRuID8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoY3RybC50YXJnZXRCdG4pIDogY3RybC50b2dnbGVFbGVtZW50WzBdO1xyXG5cdFx0XHR2YXIgb2Zmc2V0UG9zID0gdGFyZ2V0RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuXHRcdFx0XHJcblx0XHRcdHZhciBwb3NPZmZzZXRPYmogPSB7XHJcblx0XHRcdFx0J2xlZnQnIDogb2Zmc2V0UG9zLmxlZnQsXHJcblx0XHRcdFx0J3RvcCcgOiBvZmZzZXRQb3MudG9wLFxyXG5cdFx0XHRcdCdyaWdodCcgOiBvZmZzZXRQb3MucmlnaHQsXHJcblx0XHRcdFx0J2JvdHRvbScgOiBvZmZzZXRQb3MuYm90dG9tLFxyXG5cdFx0XHRcdCd3aWR0aCcgOiB0YXJnZXRFbGVtZW50LmNsaWVudFdpZHRoLFxyXG5cdFx0XHRcdCdoZWlnaHQnIDogdGFyZ2V0RWxlbWVudC5jbGllbnRIZWlnaHRcclxuXHRcdFx0fTtcclxuXHRcdFx0XHJcblx0XHRcdHZhciAkYm94Q29udGVudCA9IGN0cmwuZHJvcGRvd25NZW51LmZpbmQoJy5pYm94LWNvbnRlbnQnKTtcclxuXHRcdFx0aWYgKCRib3hDb250ZW50Lmxlbmd0aCkge1xyXG5cdFx0XHRcdCRib3hDb250ZW50LmNzcygnbWF4LWhlaWdodCcsICh3aW5kb3cuaW5uZXJIZWlnaHQgLSBwb3NPZmZzZXRPYmouYm90dG9tIC0gNDUpICsgJ3B4Jyk7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGlmKCFjdHJsLmFwcGVuZFRvKSB7XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR2YXIgY3NzT2JqID0geyAndG9wJyA6IChwb3NPZmZzZXRPYmoudG9wICsgcG9zT2Zmc2V0T2JqLmhlaWdodCkgKyAncHgnIH07XHJcblx0XHRcdGlmKGN0cmwucGxhY2VtZW50ID09ICdsZWZ0Jykge1xyXG5cdFx0XHRcdGNzc09iai5sZWZ0ID0gcG9zT2Zmc2V0T2JqLmxlZnQgKyAncHgnO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGNzc09iai5yaWdodCA9IChkb2N1bWVudC5ib2R5LmNsaWVudFdpZHRoIC0gcG9zT2Zmc2V0T2JqLnJpZ2h0KSArICdweCc7XHJcblx0XHRcdH1cclxuXHRcdFx0XHJcblx0XHRcdGN0cmwuZHJvcGRvd25NZW51LmNoaWxkcmVuKCkuY3NzKGNzc09iaik7XHJcblx0XHR9O1xyXG5cclxuXHRcdHZhciBwdXRQb3B1cHMgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0dmFyIGFwcGVuZFBvcHVwcyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdHZhciAkcG9wdXBzID0gY3RybC5kcm9wZG93bk1lbnUuZmluZCgnLmlib3gnKS5maW5kKCcuY2hpbGQtcG9wdXAnKTtcclxuXHRcdFx0XHRpZigkcG9wdXBzLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0dmFyICRwb3B1cHNDb250YWluZXIgPSBjdHJsLmRyb3Bkb3duTWVudS5maW5kKCcuaWJveC1wb3B1cHMnKTtcclxuXHRcdFx0XHRcdCRwb3B1cHNDb250YWluZXIuYXBwZW5kKCRwb3B1cHMpO1xyXG5cdFx0XHRcdFx0cmV0dXJuIHRydWU7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdFx0fTtcclxuXHRcdFx0XHJcblx0XHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0dmFyIGZvdW5kID0gYXBwZW5kUG9wdXBzKCk7XHJcblx0XHRcdFx0aWYoIWZvdW5kKSB7XHJcblx0XHRcdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0XHRhcHBlbmRQb3B1cHMoKTtcclxuXHRcdFx0XHRcdH0sIDIwMDApO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSwgMTAwMCk7XHJcblx0XHR9O1xyXG5cdFx0XHJcblx0XHR2YXIgcHV0VGl0bGVBY3Rpb25zID0gZnVuY3Rpb24oKSB7XHJcblx0XHRcdC8vIHRha2UgYWN0aW9ucyBpbiBoZWFkZXJcclxuXHRcdFx0dmFyIGFwcGVuZFRpdGxlQWN0aW9ucyA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdHZhciAkYWN0aW9ucyA9IGN0cmwuZHJvcGRvd25NZW51LmZpbmQoJy5pYm94LWNvbnRlbnQnKS5maW5kKCcudGl0bGUtYWN0aW9ucycpO1xyXG5cdFx0XHRcdGlmKCRhY3Rpb25zLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0dmFyICRhY3Rpb25Ib2xkZXIgPSBjdHJsLmRyb3Bkb3duTWVudS5maW5kKCcuYWN0aW9uLWJ0bnMnKTtcclxuXHRcdFx0XHRcdCRhY3Rpb25Ib2xkZXIuYXBwZW5kKCRhY3Rpb25zKTtcclxuXHRcdFx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH07XHJcblx0XHRcdFxyXG5cdFx0XHRzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdHZhciBmb3VuZCA9IGFwcGVuZFRpdGxlQWN0aW9ucygpO1xyXG5cdFx0XHRcdGlmKCFmb3VuZCkge1xyXG5cdFx0XHRcdFx0c2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuXHRcdFx0XHRcdFx0YXBwZW5kVGl0bGVBY3Rpb25zKCk7XHJcblx0XHRcdFx0XHR9LCAyMDAwKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sIDEwMDApO1xyXG5cdFx0fTtcclxuXHRcdFxyXG5cdFx0JHNjb3BlLmdldFRvZ2dsZUVsZW1lbnQgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0cmV0dXJuIGN0cmwudG9nZ2xlRWxlbWVudDtcclxuXHRcdH07XHJcblxyXG5cdFx0JHNjb3BlLmdldERyb3Bkb3duRWxlbWVudCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRyZXR1cm4gY3RybC5kcm9wZG93bk1lbnU7XHJcblx0XHR9O1xyXG5cclxuXHRcdCRzY29wZS5nZXRBdXRvQ2xvc2UgPSBmdW5jdGlvbigpIHtcclxuXHRcdFx0cmV0dXJuIGN0cmwuYXV0b0Nsb3NlO1xyXG5cdFx0fTtcclxuXHJcblx0XHQkc2NvcGUuZm9jdXNUb2dnbGVFbGVtZW50ID0gYW5ndWxhci5ub29wO1xyXG5cclxuXHRcdGN0cmwub25Ub2dnbGVCdG5DbGljayA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHR2YXIgb3BlbmVkU2NvcGUgPSBkZFNlcnZpY2UuZ2V0T3BlbmVkKCk7XHJcblx0XHRcdGlmKG9wZW5lZFNjb3BlICYmIG9wZW5lZFNjb3BlLm5hbWUpIHtcclxuXHRcdFx0XHR2YXIgY2hpbGRTY29wZSA9IGRkY2hpbGQuZ2V0Q2hpbGRTY29wZShvcGVuZWRTY29wZS5uYW1lKTtcclxuXHJcblx0XHRcdFx0aWYoY2hpbGRTY29wZSAmJiBjaGlsZFNjb3BlLmhhc0NhbmNlbFByb21wdCkge1xyXG5cdFx0XHRcdFx0Y2hpbGRTY29wZS5vcGVuQ2FuY2VsUHJvbXB0KGZ1bmN0aW9uKCl7XHJcblx0XHRcdFx0XHRcdGN0cmwuYnRuVG9nZ2xlKCk7XHJcblx0XHRcdFx0XHR9KTtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0Y3RybC5idG5Ub2dnbGUoKTtcclxuXHRcdH07XHJcblxyXG5cdFx0Y3RybC5idG5Ub2dnbGUgPSBmdW5jdGlvbihkYXRhKSB7XHJcblx0XHRcdGlmKGN0cmwuYnRuRGlzYWJsZWQpIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHRcdFx0Y3RybC5kcmFnZ2FibGUgJiYgY3RybC4kZGlhbG9nICYmIGN0cmwuJGRpYWxvZy5yZW1vdmVBdHRyKCdzdHlsZScpO1xyXG5cdFx0XHQkc2NvcGUuaXNPcGVuID0gISRzY29wZS5pc09wZW47XHJcblx0XHRcdFxyXG5cdFx0XHRpZiAoJHNjb3BlLmlzT3Blbikge1xyXG5cdFx0XHRcdGxheW91dCgpO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdHB1dFRpdGxlQWN0aW9ucygpO1xyXG5cdFx0XHRcdHB1dFBvcHVwcygpO1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdGRkU2VydmljZS5vcGVuKCRzY29wZSk7XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHRjdHJsLmRyb3Bkb3duTWVudS5maW5kKCcuY2xvc2UtbGluaycpLmZvY3VzKCk7XHRcdFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdCRzY29wZS5leHBhbmRlZCAmJiBjdHJsLm1pbk1heCh0cnVlKTtcclxuXHRcdFx0XHRkZFNlcnZpY2UuY2xvc2UoJHNjb3BlKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0aWYoJHNjb3BlLmlzTW9iaWxlKSB7XHJcblx0XHRcdFx0Y3RybC5taW5NYXgoISRzY29wZS5pc09wZW4pO1xyXG5cdFx0XHR9XHJcblx0XHRcdHRyaWdnZXJDaGFuZ2UoZGF0YSwgJ3Zpc2liaWxpdHknKTtcclxuXHRcdH07XHJcblx0XHRcclxuXHRcdHZhciBhZGRDbGFzc1RvQm9keSA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0aWYoJHNjb3BlLmV4cGFuZGVkKSB7XHJcblx0XHRcdFx0YW5ndWxhci5lbGVtZW50KCdib2R5JykuYWRkQ2xhc3MoJ2RkLWV4cGFuZGVkJyk7XHJcblx0XHRcdFx0YW5ndWxhci5lbGVtZW50KCdodG1sLCBib2R5JykuY3NzKHtvdmVyZmxvdzogJ2hpZGRlbicsIGhlaWdodDogJzEwMCUnfSk7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0YW5ndWxhci5lbGVtZW50KCdib2R5JykucmVtb3ZlQ2xhc3MoJ2RkLWV4cGFuZGVkJyk7XHJcblx0XHRcdFx0YW5ndWxhci5lbGVtZW50KCdodG1sLCBib2R5JykuY3NzKHtvdmVyZmxvdzogJycsIGhlaWdodDogJyd9KTtcclxuXHRcdFx0XHRcclxuXHRcdFx0XHRpZigkc2NvcGUuaXNPcGVuICYmICEkc2NvcGUuaXNEb2NrKSB7XHJcblx0XHRcdFx0XHRsYXlvdXQoKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblxyXG5cdFx0Y3RybC5taW5NYXggPSBmdW5jdGlvbihmb3JjZVRvQ2xvc2UpIHtcclxuXHRcdFx0aWYoZm9yY2VUb0Nsb3NlKSB7XHJcblx0XHRcdFx0JHNjb3BlLmV4cGFuZGVkID0gZmFsc2U7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0JHNjb3BlLmV4cGFuZGVkID0gISRzY29wZS5leHBhbmRlZDtcclxuXHRcdFx0fVxyXG5cdFx0XHRcclxuXHRcdFx0YWRkQ2xhc3NUb0JvZHkoKTtcclxuXHRcdFx0XHJcblx0XHRcdHRyaWdnZXJDaGFuZ2UobnVsbCwgJ3NpemUnKTtcclxuXHRcdH07XHJcblxyXG5cdFx0Y3RybC5hcHBseURvY2sgPSBmdW5jdGlvbihlKSB7XHJcblx0XHRcdCRzY29wZS5pc0RvY2sgPSAhJHNjb3BlLmlzRG9jaztcclxuXHRcdFx0ZGRTZXJ2aWNlLmRvY2soJHNjb3BlKTtcclxuXHRcdFx0XHJcblx0XHRcdGlmKCEkc2NvcGUuaXNEb2NrKSB7XHJcblx0XHRcdFx0bGF5b3V0KCk7XHJcblx0XHRcdFx0Y3RybC5kcmFnZ2FibGUgJiYgY3RybC4kZGlhbG9nICYmIGN0cmwuJGRpYWxvZy5yZW1vdmVBdHRyKCdzdHlsZScpO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0XHR0cnkge1xyXG5cdFx0XHRcdGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdkb2NrJywgJHNjb3BlLmlzRG9jayk7XHJcblx0XHRcdH0gY2F0Y2goZSkge31cclxuXHRcdFx0XHJcblx0XHRcdHRyaWdnZXJDaGFuZ2UobnVsbCwgJ2RvY2snKTtcclxuXHRcdH07XHJcblxyXG5cdFx0JHNjb3BlLmlzS2V5bmF2RW5hYmxlZCA9IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRyZXR1cm4gY3RybC5rZXluYXZFbmFibGVkIHx8IHRydWU7XHJcblx0XHR9O1xyXG5cdH1dXHRcdFxyXG59KTsiLCJhbmd1bGFyLm1vZHVsZShcImFkb2RkbGVcIikuY29tcG9uZW50KCdtc2dEZXRhaWwnLCB7XHJcblx0dGVtcGxhdGVVcmw6ICdtc2dEZXRhaWwuaHRtbCcsXHJcblx0Y29udHJvbGxlcjogWyckc2NvcGUnLCAnJHJvb3RTY29wZScsICckZmlsdGVyJywgJyR0aW1lb3V0JywgJyR3aW5kb3cnLCAnbGFuZycsICdhcGknLCAnYXBpQ29uZmlnJywgJ215Q29uZmlnJywgJ2Rvd25sb2FkQXNzb2NEb2MnLFxyXG5cdFx0ZnVuY3Rpb24gKCRzY29wZSwgJHJvb3RTY29wZSwgJGZpbHRlciwgJHRpbWVvdXQsICR3aW5kb3csIGxhbmcsIGFwaSwgYXBpQ29uZmlnLCBteUNvbmZpZywgZG93bmxvYWRBc3NvY0RvYykge1xyXG5cdFx0XHR2YXIgY3RybCA9IHRoaXM7XHJcblx0XHRcdHZhciBpc0Jyb2FkY2FzdE1zZyA9IDA7XHJcblxyXG5cdFx0XHQvLyBpbml0aWFsaXphdGlvblxyXG5cdFx0XHRjdHJsLiRvbkluaXQgPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0Y3RybC54aHIgPSBmYWxzZTtcclxuXHJcblx0XHRcdFx0JHNjb3BlLm1zZ0RldGFpbCA9IHVuZGVmaW5lZDtcclxuXHRcdFx0XHQkc2NvcGUubXNnVGhyZWFkID0gdW5kZWZpbmVkO1xyXG5cdFx0XHRcdCRzY29wZS5tYWluVGhyZWFkID0gdW5kZWZpbmVkO1xyXG5cdFx0XHRcdCRzY29wZS5pc0RpcmVjdExpbmtPcGVuID0gZmFsc2U7XHJcblx0XHRcdFx0JHNjb3BlLnByaXYgPSB7XHJcblx0XHRcdFx0XHRjYW5QcmludDogZmFsc2UsXHJcblx0XHRcdFx0XHRjYW5BY2Nlc3NBdWRpdEluZm86IGZhbHNlXHJcblx0XHRcdFx0fTtcclxuXHJcblx0XHRcdFx0ZmV0Y2goKTtcclxuXHRcdFx0XHRsaXN0ZW4oKTtcclxuXHRcdFx0fTtcclxuXHJcblx0XHRcdHZhciBsaXN0ZW4gPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0JHNjb3BlLiRvbihcInRocmVhZDpsb2FkXCIsIG9uVGhyZWFkTG9hZCk7XHJcblx0XHRcdFx0JHNjb3BlLiRvbigndGhyZWFkOmNoYW5nZScsIG9uVGhyZWFkQ2hhbmdlKTtcclxuXHJcblx0XHRcdFx0JHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgZnVuY3Rpb24oZSkge1xyXG5cdFx0XHRcdFx0aWYodHlwZW9mIGUuZGF0YSAhPT0gJ3N0cmluZycpIHsgcmV0dXJuOyB9XHJcblx0XHRcdFx0XHR2YXIgZGF0YSA9IGUuZGF0YS5zcGxpdCgnOjonKTtcclxuXHRcdFx0XHRcdGlmKGRhdGFbMF0gPT0gJ2Nsb3NlJykge1x0XHRcdFx0XHRcdFxyXG5cdFx0XHRcdFx0XHRpZihkYXRhWzFdICYmIGRhdGFbMV0gPT0gXCJyZWxvYWRcIikge1xyXG5cdFx0XHRcdFx0XHRcdGlmKGRhdGFbMl0gJiYgZGF0YVsyXSA9PSBcInBhcmVudHJlbG9hZFwiKSB7XHJcblx0XHRcdFx0XHRcdFx0XHQvLyByZWZyZXNoIGZvciBQcm9qZWN0cyBMaXN0aW5nIGluIE1hcmtldCBQbGFjZS5cclxuXHRcdFx0XHRcdFx0XHRcdCR3aW5kb3cudG9wLm9wZW5lci5wb3N0TWVzc2FnZShKU09OLnN0cmluZ2lmeSh7cmVmcmVzaE9wcG86dHJ1ZX0pLCBcIipcIik7XHRcdFx0XHRcdFx0XHRcdFx0XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcdCR3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcblx0XHRcdFx0XHRcdH1cdFx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9LCBmYWxzZSk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgdW5lc2NhcGVTdHIgPSBmdW5jdGlvbiAocykge1xyXG5cdFx0XHRcdHZhciB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGV4dGFyZWEnKTtcclxuXHRcdFx0XHR0LmlubmVySFRNTCA9IHMgfHwgXCJcIjtcclxuXHRcdFx0XHRyZXR1cm4gdC52YWx1ZTtcclxuXHRcdFx0fTtcclxuXHJcblx0XHRcdHZhciBvblN1Y2Nlc3MgPSBmdW5jdGlvbiAocmVzcG9uc2UpIHtcclxuXHRcdFx0XHQkdGltZW91dChmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRjdHJsLnhociA9IGZhbHNlO1xyXG5cdFx0XHRcdH0pO1xyXG5cclxuXHRcdFx0XHR2YXIgZGF0YSA9IHJlc3BvbnNlWzBdO1xyXG5cdFx0XHRcdGlmKHJlc3BvbnNlLmVycm9yKXtcclxuXHRcdFx0XHRcdGFuZ3VsYXIuZWxlbWVudChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9ybVdyYXBwZXInKSkuaHRtbChyZXNwb25zZS5tZXNzYWdlKTtcclxuXHRcdFx0XHQgIH1cclxuXHRcdFx0XHRlbHNlIGlmIChkYXRhLmFsbG93Vmlld1JlcyA9PT0gJ3RydWUnKSB7IC8vIHJlbW92ZSBzY3JpcHQgc3RyaW5nXHJcblx0XHRcdFx0XHRpZiAoZGF0YS5odG1sKSB7XHJcblx0XHRcdFx0XHRcdGRhdGEuaHRtbCA9IGRhdGEuaHRtbC5yZXBsYWNlKFwiPCEtLSNTY3JpcHQjI1NjcmlwdCMtLT5cIiwgXCJcIik7XHJcblx0XHRcdFx0XHRcdGFuZ3VsYXIuZWxlbWVudChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9ybVdyYXBwZXInKSkuaHRtbChkYXRhLmh0bWwpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRhbmd1bGFyLmVsZW1lbnQoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2Zvcm1XcmFwcGVyJykpLmh0bWwobGFuZy5nZXQoJ3Jlc3RyaWN0LW1lc3NhZ2UtZm9yLXRlbmRlci1yZXNwb25zZScpKTtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdC8vIHNvcnQgdGhlIHVzZXJzIG5hbWVzXHJcblx0XHRcdFx0ZGF0YS5zZW50ID0gdW5lc2NhcGVTdHIoZGF0YS5zZW50KTtcclxuXHRcdFx0XHRkYXRhLnNlbnQgPSBkYXRhLnNlbnQgPyAkZmlsdGVyKCdvcmRlckJ5JykoZGF0YS5zZW50LnNwbGl0KC9bXFxzXSosW1xcc10qLykpIDogW107XHJcblxyXG5cdFx0XHRcdCRzY29wZS5tc2dEZXRhaWwgPSBkYXRhO1xyXG5cdFx0XHRcdGlzQnJvYWRjYXN0TXNnTG9hZCgpO1xyXG5cclxuXHRcdFx0XHQvLyBzZXQgQXBwQnVpbGRlckZvcm1JRENvZGUgdmFyaWFibGUgd2hpY2ggaXMgdXNlZCBpbiBpbmZvamV0XHJcblx0XHRcdFx0aWYgKGRhdGEuYWxsb3dWaWV3UmVzID09PSAndHJ1ZScgJiYgJHdpbmRvdy5JbmZvSmV0X0luaXQpIHtcclxuXHRcdFx0XHRcdCR3aW5kb3cuQXBwQnVpbGRlckZvcm1JRENvZGUgPSBkYXRhLmFwcEJ1aWxkZXJGb3JtSURDb2RlO1xyXG5cdFx0XHRcdFx0JHdpbmRvdy5jdXN0b21NZXRob2Rfb25Mb2FkX09uUG9zdGJhY2tFbmQgJiYgJHdpbmRvdy5jdXN0b21NZXRob2Rfb25Mb2FkX09uUG9zdGJhY2tFbmQoKTtcclxuXHRcdFx0XHRcdCR3aW5kb3cuSW5mb0pldF9Jbml0KCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0dmFyIGZldGNoID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdHZhciB0aHJlYWQgPSAkc2NvcGUubXNnVGhyZWFkIHx8IHt9LCBmb3JtVHlwZUlkID0gbXlDb25maWcuZm9ybVR5cGVJZDtcclxuXHRcdFx0XHRpZiAoIW15Q29uZmlnLnZpZXdBbHdheXNGb3JtQXNzb2NpYXRpb24pIHtcclxuXHRcdFx0XHRcdGZvcm1UeXBlSWQgPSB0aHJlYWQuZm9ybVR5cGVJZCB8fCBteUNvbmZpZy5mb3JtVHlwZUlkO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0dmFyIG9iaiA9IHtcclxuXHRcdFx0XHRcdGFjdGlvbl9pZDogYXBpQ29uZmlnLlZJRVdfRk9STV9NU0dfREVUQUlMU19BQ1RJT04sXHJcblx0XHRcdFx0XHRjdXJyZW50UGFnZU5vOiAxLFxyXG5cdFx0XHRcdFx0Y29tbUlkOiBteUNvbmZpZy5jb21tSWQsXHJcblx0XHRcdFx0XHRwcm9qZWN0SWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRcdG1zZ0lkOiB0aHJlYWQubXNnSWQgfHwgbXlDb25maWcubXNnSWQsXHJcblx0XHRcdFx0XHRmb2xkZXJJZDogdGhyZWFkLmZvbGRlcklkIHx8IG15Q29uZmlnLmZvbGRlcklkIHx8IFwiXCIsXHJcblx0XHRcdFx0XHRmb3JtTnVtOiB0aHJlYWQuZm9ybU51bSB8fCBcIlwiLFxyXG5cdFx0XHRcdFx0Zm9ybV90eXBlX2lkOiBmb3JtVHlwZUlkLFxyXG5cdFx0XHRcdFx0Y2FsbGVyQXBwOiAxMCwgLy9DQUxMRVJfQURPRERMRSxcclxuXHRcdFx0XHRcdHZpZXdBbHdheXNGb3JtQXNzb2NpYXRpb246IG15Q29uZmlnLnZpZXdBbHdheXNGb3JtQXNzb2NpYXRpb24sXHJcblx0XHRcdFx0XHRhc3NvY1BhcmVudFByb2plY3RJZDogbXlDb25maWcuYXNzb2NQYXJlbnRQcm9qZWN0SWRcclxuXHRcdFx0XHR9O1xyXG5cclxuXHRcdFx0XHRpZiAobXlDb25maWcuYXNzb2NQYXJlbnRGb3JtVHlwZUlkKSB7XHJcblx0XHRcdFx0XHRvYmouYXNzb2NQYXJlbnRGb3JtVHlwZUlkID0gbXlDb25maWcuYXNzb2NQYXJlbnRGb3JtVHlwZUlkO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0Y3RybC54aHIgJiYgY3RybC54aHIuYWJvcnQoKTtcclxuXHRcdFx0XHR2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdFx0dXJsOiBhcGlDb25maWcuUFVCTElDX1ZJRVdfRk9STSxcclxuXHRcdFx0XHRcdGRhdGE6IG9iaixcclxuXHRcdFx0XHRcdF9kY0lkOiB0aHJlYWQuZGNJZFxyXG5cdFx0XHRcdH0pO1xyXG5cclxuXHRcdFx0XHR4aHIudGhlbihvblN1Y2Nlc3MsIGZ1bmN0aW9uICh4aHIpIHtcclxuXHRcdFx0XHRcdGlmICh4aHIuc3RhdHVzICE9IC0xKVxyXG5cdFx0XHRcdFx0XHRjdHJsLnhociA9IHhocjtcclxuXHRcdFx0XHRcdGVsc2VcclxuXHRcdFx0XHRcdFx0Y3RybC54aHIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJtZXNzYWdlLWRldGFpbHMtZXJyb3ItbXNnXCIpO1xyXG5cdFx0XHRcdFx0YXBpLnNob3dTZXJ2ZXJFcnJNc2coeGhyKTtcclxuXHRcdFx0XHR9KTtcclxuXHJcblx0XHRcdFx0JHRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdFx0Y3RybC54aHIgPSB4aHI7XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgc2V0SW5pdGlhbE1zZ0RldGFpbHMgPSBmdW5jdGlvbiAodGhyZWFkLCB0aHJlYWRMb2FkKSB7XHJcblx0XHRcdFx0aWYgKHRocmVhZExvYWQgJiYgJHNjb3BlLm1zZ0RldGFpbCkge1xyXG5cdFx0XHRcdFx0JHNjb3BlLm1zZ0RldGFpbC5zZW50ID0gdGhyZWFkLnNlbnROYW1lcyA/IHRocmVhZC5zZW50TmFtZXMgOiAkc2NvcGUubXNnRGV0YWlsLnNlbnQ7XHJcblx0XHRcdFx0XHQkc2NvcGUubXNnRGV0YWlsLnNlbnQgPSAkZmlsdGVyKCdvcmRlckJ5JykoJHNjb3BlLm1zZ0RldGFpbC5zZW50IHx8IFtdKTtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdCRzY29wZS5tc2dEZXRhaWwgPSB7XHJcblx0XHRcdFx0XHRvcmlnaW5hdG9yVXNlcklkOiB0aHJlYWQuaGFzaGVkTXNnT3JpZ2luYXRvcklkLFxyXG5cdFx0XHRcdFx0b3JpZ2luYXRvckltYWdlOiB0aHJlYWQub3JpZ2luYXRvcixcclxuXHRcdFx0XHRcdG1zZ09yaWdpbmF0b3I6IHRocmVhZC5vcmlnaW5hdG9yRGlzcGxheU5hbWUsXHJcblx0XHRcdFx0XHRzZW50OiAkZmlsdGVyKCdvcmRlckJ5JykodGhyZWFkLnNlbnROYW1lcyB8fCBbXSksXHJcblx0XHRcdFx0XHR1cGRhdGVkOiB0aHJlYWQubXNnQ3JlYXRlZERhdGVcclxuXHRcdFx0XHR9O1xyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0dmFyIG9uVGhyZWFkQ2hhbmdlID0gZnVuY3Rpb24gKGV2ZW50LCB0aHJlYWQpIHtcclxuXHRcdFx0XHQkc2NvcGUubXNnVGhyZWFkID0gdGhyZWFkO1xyXG5cclxuXHRcdFx0XHRzZXRJbml0aWFsTXNnRGV0YWlscyh0aHJlYWQpO1xyXG5cdFx0XHRcdGZldGNoKCk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgb25UaHJlYWRMb2FkID0gZnVuY3Rpb24gKGV2ZW50LCBkYXRhKSB7XHJcblx0XHRcdFx0aWYgKCFkYXRhIHx8ICFkYXRhLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0JHNjb3BlLm1haW5UaHJlYWQgPSBkYXRhWzBdO1xyXG5cclxuXHRcdFx0XHR2YXIgaSwgdGhyZWFkLCB0YXJnZXRNc2dJZCA9IG15Q29uZmlnLm1zZ0lkO1xyXG5cdFx0XHRcdGlmICgkc2NvcGUubXNnVGhyZWFkKSB7XHJcblx0XHRcdFx0XHR0YXJnZXRNc2dJZCA9ICRzY29wZS5tc2dUaHJlYWQubXNnSWQ7XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRmb3IgKGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0dGhyZWFkID0gZGF0YVtpXTtcclxuXHRcdFx0XHRcdGlmIChwYXJzZUludCh0aHJlYWQubXNnSWQuc3BsaXQoXCIkJFwiKVswXSkgPT0gcGFyc2VJbnQodGFyZ2V0TXNnSWQuc3BsaXQoXCIkJFwiKVswXSkpIHtcclxuXHRcdFx0XHRcdFx0JHNjb3BlLm1zZ1RocmVhZCA9IHRocmVhZDtcclxuXHRcdFx0XHRcdFx0c2V0SW5pdGlhbE1zZ0RldGFpbHModGhyZWFkLCB0cnVlKTtcclxuXHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRpc0Jyb2FkY2FzdE1zZ0xvYWQoKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0dmFyIGlzQnJvYWRjYXN0TXNnTG9hZCA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHQvL1RoaXMgZnVuY3Rpb24gYnJvYWRjYXN0cyBvbmx5IGFmdGVyIHJlY2VpdmluZyByZXNwb25zZSBmcm9tIGNvbW11bmljYXRpb25zIGlkcyAxMTQgJiAxMTVcclxuXHRcdFx0XHRpZiAoaXNCcm9hZGNhc3RNc2cgPiAwKSB7XHJcblx0XHRcdFx0XHQkdGltZW91dChmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRcdCRyb290U2NvcGUuJGJyb2FkY2FzdCgnbXNnOmxvYWQnLCAkc2NvcGUubXNnRGV0YWlsKTtcclxuXHRcdFx0XHRcdH0sIDEwMCk7XHJcblx0XHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRpc0Jyb2FkY2FzdE1zZysrO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQkd2luZG93LmxhdW5jaENyZWF0ZUZvcm0gPSBmdW5jdGlvbiAoYXBwQnVpbGRlckZJREMpIHsgfTtcclxuXHJcblx0XHRcdCR3aW5kb3cubGF1bmNoQ3JlYXRlRm9ybUZyb21WaWV3ID0gZnVuY3Rpb24gKGFwcEJ1aWxkZXJGSURDKSB7IH07XHJcblxyXG5cdFx0XHQkd2luZG93LnNldEFzc29jQW5kQXR0YWNoRmxhZyA9IGZ1bmN0aW9uIChleHRyYVBhcmFtKSB7IH07XHJcblxyXG5cdFx0XHQkd2luZG93LmVkaXRPcmlGb3JYc25MaW5rID0gZnVuY3Rpb24gKGVkaXRPUklEcmFmdE1zZ0lkLCBwYXJlbnRNc2dJZCwgZm9ybVR5cGVJZCwgcHJvamVjdElkLCBmb3JtSWQpIHsgfTtcclxuXHJcblx0XHRcdCR3aW5kb3cuZG93bmxvYWRBbGxBdHRhY2hBbmRBc3NvY1ppcCA9IGZ1bmN0aW9uICgpIHsgfTtcclxuXHJcblx0XHRcdHZhciBkb3dubG9hZEFsbEF0dGFjaEFzc29jWGhyID0gZmFsc2U7XHJcblx0XHRcdCR3aW5kb3cuZG93bmxvYWRBbGxBdHRhY2hBbmRBc3NvY0xhdGVzdFJldlppcCA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRpZiAoZG93bmxvYWRBbGxBdHRhY2hBc3NvY1hocikge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRkb3dubG9hZEFsbEF0dGFjaEFzc29jWGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdFx0dXJsOiBhcGlDb25maWcuRE9XTkxPQURfRE9DVU1FTlRfRlJPTV9QVUJMSUNfRk9STSxcclxuXHRcdFx0XHRcdGRhdGE6IHtcclxuXHRcdFx0XHRcdFx0YWN0aW9uX2lkOiBhcGlDb25maWcuUFVCTElDX1NBVkVfTU9ERUxfQUNUSU9OX0xBVEVTVF9SRVZfWklQLFxyXG5cdFx0XHRcdFx0XHRybWZ0OiBteUNvbmZpZy5mb3JtVHlwZUlkLFxyXG5cdFx0XHRcdFx0XHRtc2dJZDogKCRzY29wZS5tc2dUaHJlYWQgfHwge30pLm1zZ0lkIHx8IG15Q29uZmlnLm1zZ0lkLFxyXG5cdFx0XHRcdFx0XHRmb3JtSWQ6IG15Q29uZmlnLmZvcm1JZCxcclxuXHRcdFx0XHRcdFx0cHJvamVjdF9pZDogbXlDb25maWcucHJvamVjdElkXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSk7XHJcblxyXG5cdFx0XHRcdGRvd25sb2FkQWxsQXR0YWNoQXNzb2NYaHIudGhlbihmdW5jdGlvbiAoZGF0YSkge1xyXG5cdFx0XHRcdFx0ZG93bmxvYWRBc3NvY0RvYy5pbml0KHtcclxuXHRcdFx0XHRcdFx0cHJvamVjdElkOiBkYXRhLmhhc2hQcm9qZWN0SWQsXHJcblx0XHRcdFx0XHRcdG5vbkNETkRvd25sb2FkVXJsOiBkYXRhLm5vbkNETkRvd25sb2FkVXJsLFxyXG5cdFx0XHRcdFx0XHRpc0xpbWl0RXhpc3Q6IGRhdGEuaXNMaW1pdEV4aXN0LFxyXG5cdFx0XHRcdFx0XHRiYXNlVXJsOiBteUNvbmZpZy5iYXNlVXJsLFxyXG5cdFx0XHRcdFx0XHRkb3dubG9hZFNlY29uZGFyeUZpbGU6IGRhdGEuZG93bmxvYWRTZWNvbmRhcnlGaWxlLFxyXG5cdFx0XHRcdFx0XHRkb3dubG9hZFJldkRvY0xpc3RKU09OOiBkYXRhLmRvd25sb2FkUmV2RG9jTGlzdEpTT04sXHJcblx0XHRcdFx0XHRcdGlzRnJvbVB1YmxpY0RvbWFpbiA6IHRydWUsXHJcblx0XHRcdFx0XHR9LCBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRcdGRvd25sb2FkQWxsQXR0YWNoQXNzb2NYaHIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdH0sIGZ1bmN0aW9uICh4aHIpIHtcclxuXHRcdFx0XHRcdGRvd25sb2FkQWxsQXR0YWNoQXNzb2NYaHIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJzZXJ2ZXItZXJyb3JcIik7XHJcblx0XHRcdFx0XHRhcGkuc2hvd1NlcnZlckVyck1zZyh4aHIpO1xyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9O1xyXG5cclxuXHRcdH1dLFxyXG5cdGJpbmRpbmdzOiB7XHJcblxyXG5cdH1cclxufSk7XHJcbiIsImFuZ3VsYXIubW9kdWxlKFwiYWRvZGRsZVwiKS5jb21wb25lbnQoJ2Zvcm1UaHJlYWQnLCB7XHJcblx0dGVtcGxhdGVVcmw6ICdmb3JtVGhyZWFkLmh0bWwnLFxyXG5cdGNvbnRyb2xsZXI6IFsnJHNjb3BlJywgJyRlbGVtZW50JywgJyRyb290U2NvcGUnLCAnJHRpbWVvdXQnLCAnYXBpJywgJ2FwaUNvbmZpZycsICdteUNvbmZpZycsICdsYW5nJywgJ2RkY2hpbGQnLFxyXG5cdFx0ZnVuY3Rpb24gKCRzY29wZSwgJGVsZW1lbnQsICRyb290U2NvcGUsICR0aW1lb3V0LCBhcGksIGFwaUNvbmZpZywgbXlDb25maWcsIGxhbmcsIGRkY2hpbGQpIHtcclxuXHRcdFx0dmFyIGN0cmwgPSB0aGlzO1xyXG5cclxuXHRcdFx0Ly8gaW5pdGlhbGl6YXRpb25cclxuXHRcdFx0Y3RybC4kb25Jbml0ID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdGN0cmwueGhyID0gZmFsc2U7XHJcblx0XHRcdFx0Y3RybC5kYXRhID0gdW5kZWZpbmVkO1xyXG5cdFx0XHRcdGN0cmwudGFyZ2V0TXNnSWQgPSB1bmRlZmluZWQ7XHJcblx0XHRcdFx0Y3RybC5hY3RpdmVNc2dJZCA9IHVuZGVmaW5lZDtcclxuXHJcblx0XHRcdFx0JHNjb3BlLm1haW5UaHJlYWQgPSB1bmRlZmluZWQ7XHJcblx0XHRcdFx0JHNjb3BlLnVucmVhZENvdW50ID0gMDtcclxuXHJcblx0XHRcdFx0bG9jYWxTdG9yYWdlICYmIGZldGNoKG51bGwsIGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdkb2NrJykpO1xyXG5cclxuXHRcdFx0XHRkZGNoaWxkLnJlZ2lzdGVyKCRzY29wZSwgJ2Zvcm0tdGhyZWFkJyk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgdXBkYXRlVW5yZWFkQ291bnQgPSBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0dmFyIGRhdGEgPSAkc2NvcGUuZm9ybURhdGE7XHJcblx0XHRcdFx0aWYgKCFkYXRhIHx8ICFkYXRhLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0dmFyIGksIHRocmVhZCwgY291bnQgPSAwLCBpbmRlbnQsXHJcblx0XHRcdFx0XHRtc2dJZExpc3QgPSBbXSxcclxuXHRcdFx0XHRcdG1hcmdpblRvcCA9IDEwLFxyXG5cdFx0XHRcdFx0dGhyZWFkSGVpZ2h0ID0gNjE7XHJcblxyXG5cdFx0XHRcdGZvciAoaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0XHR0aHJlYWQgPSBkYXRhW2ldO1xyXG5cdFx0XHRcdFx0aWYgKHRocmVhZC5ub09mQWN0aW9ucyA+IDApIHtcclxuXHRcdFx0XHRcdFx0Y291bnQgKz0gdGhyZWFkLm5vT2ZBY3Rpb25zO1xyXG5cdFx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRcdGluZGVudCA9IHRocmVhZC5pbmRlbnQ7XHJcblxyXG5cdFx0XHRcdFx0dmFyIHBNc2dJZCA9IHRocmVhZC5wYXJlbnRNc2dJZCArIFwiXCI7XHJcblx0XHRcdFx0XHRpZiAobXNnSWRMaXN0LmluZGV4T2YocE1zZ0lkKSA+IC0xKSB7XHJcblx0XHRcdFx0XHRcdHZhciBjbnQgPSAoaSAtIG1zZ0lkTGlzdC5pbmRleE9mKHBNc2dJZCkgLSAxKTtcclxuXHRcdFx0XHRcdFx0dGhyZWFkLmRpc3RhbmNlID0gKGNudCAqIHRocmVhZEhlaWdodCkgKyAoY250ICogbWFyZ2luVG9wKSArIG1hcmdpblRvcCArICh0aHJlYWRIZWlnaHQgLyAyKTtcclxuXHRcdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0XHRtc2dJZExpc3QucHVzaCh0aHJlYWQubXNnSWQuc3BsaXQoJyQkJylbMF0pO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0JHNjb3BlLnVucmVhZENvdW50ID0gY291bnQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdHZhciBzZXRUYXJnZXRNc2dJZCA9IGZ1bmN0aW9uIChkYXRhKSB7XHJcblx0XHRcdFx0dmFyIGksIHRocmVhZDtcclxuXHRcdFx0XHRjdHJsLnRhcmdldE1zZ0lkID0gbXlDb25maWcubXNnSWQ7XHJcblx0XHRcdFx0Y3RybC5hY3RpdmVNc2dJZCA9IG15Q29uZmlnLm1zZ0lkO1xyXG5cdFx0XHRcdGlmIChteUNvbmZpZy50b09wZW4gPT0gXCJGcm9tRm9ybXNcIikge1xyXG5cdFx0XHRcdFx0Zm9yIChpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0XHRcdFx0dGhyZWFkID0gZGF0YVtpXTtcclxuXHRcdFx0XHRcdFx0aWYgKHBhcnNlSW50KHRocmVhZC5tc2dJZC5zcGxpdChcIiQkXCIpWzBdKSA+IHBhcnNlSW50KGN0cmwudGFyZ2V0TXNnSWQuc3BsaXQoXCIkJFwiKVswXSkpIHtcclxuXHRcdFx0XHRcdFx0XHRjdHJsLnRhcmdldE1zZ0lkID0gdGhyZWFkLm1zZ0lkO1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0dmFyIGZpbmRUaHJlYWQgPSBmdW5jdGlvbiAobXNnSWQpIHtcclxuXHRcdFx0XHRpZiAoIW1zZ0lkKVxyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cclxuXHRcdFx0XHR2YXIgaSwgaiwgdGhyZWFkLCBkYXRhID0gJHNjb3BlLmZvcm1EYXRhO1xyXG5cclxuXHRcdFx0XHRmb3IgKGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0dGhyZWFkID0gZGF0YVtpXTtcclxuXHRcdFx0XHRcdGlmICh0aHJlYWQubXNnSWQuc3BsaXQoXCIkJFwiKVswXSA9PSBtc2dJZC5zcGxpdChcIiQkXCIpWzBdKSB7XHJcblx0XHRcdFx0XHRcdHJldHVybiB0aHJlYWQ7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0dmFyIGZldGNoID0gZnVuY3Rpb24gKHNpbGVudCwgb3Blbk9uTG9hZCkge1xyXG5cdFx0XHRcdGlmIChjdHJsLnhociAmJiBjdHJsLnhoci5hYm9ydCkge1xyXG5cdFx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0dmFyIHBhcmFtc09iaiA9IHtcclxuXHRcdFx0XHRcdGFjdGlvbl9pZDogYXBpQ29uZmlnLlZJRVdfRk9STV9BQ1RJT04sXHJcblx0XHRcdFx0XHRjdXJyZW50UGFnZU5vOiAxLFxyXG5cdFx0XHRcdFx0Y29tbUlkOiBteUNvbmZpZy5jb21tSWQsXHJcblx0XHRcdFx0XHRwcm9qZWN0SWQ6IG15Q29uZmlnLnByb2plY3RJZCxcclxuXHRcdFx0XHRcdG1zZ0lkOiBteUNvbmZpZy5tc2dJZFxyXG5cdFx0XHRcdH07XHJcblxyXG5cdFx0XHRcdGlmIChteUNvbmZpZy52aWV3QWx3YXlzRm9ybUFzc29jaWF0aW9uKSB7XHJcblx0XHRcdFx0XHRwYXJhbXNPYmoudmlld0Fsd2F5c0Zvcm1Bc3NvY2lhdGlvbiA9IG15Q29uZmlnLnZpZXdBbHdheXNGb3JtQXNzb2NpYXRpb247XHJcblx0XHRcdFx0XHRwYXJhbXNPYmouZm9ybVR5cGVJZCA9IG15Q29uZmlnLmZvcm1UeXBlSWQ7XHJcblx0XHRcdFx0XHRwYXJhbXNPYmouYXNzb2NQYXJlbnRQcm9qZWN0SWQgPSBteUNvbmZpZy5hc3NvY1BhcmVudFByb2plY3RJZDtcclxuXHRcdFx0XHRcdHBhcmFtc09iai5hc3NvY1BhcmVudEZvcm1UeXBlSWQgPSBteUNvbmZpZy5hc3NvY1BhcmVudEZvcm1UeXBlSWQ7XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHR2YXIgeGhyID0gYXBpLmFqYXgoe1xyXG5cdFx0XHRcdFx0dXJsOiBhcGlDb25maWcuUFVCTElDX1ZJRVdfRk9STSxcclxuXHRcdFx0XHRcdGRhdGE6IHBhcmFtc09ialxyXG5cdFx0XHRcdH0pO1xyXG5cclxuXHRcdFx0XHRpZiAoIXNpbGVudCkge1xyXG5cdFx0XHRcdFx0Y3RybC54aHIgPSB4aHI7XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHR4aHIudGhlbihmdW5jdGlvbiAoZGF0YSkge1xyXG5cdFx0XHRcdFx0Y3RybC54aHIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdGRhdGEgPSBkYXRhIHx8IHt9O1xyXG5cclxuXHRcdFx0XHRcdCFjdHJsLnRhcmdldE1zZ0lkICYmIHNldFRhcmdldE1zZ0lkKGRhdGEuZGF0YSk7XHJcblxyXG5cdFx0XHRcdFx0JHNjb3BlLmZvcm1EYXRhID0gZGF0YS5kYXRhO1xyXG5cdFx0XHRcdFx0JHNjb3BlLm1haW5UaHJlYWQgPSBkYXRhLmRhdGFbMF07XHJcblx0XHRcdFx0XHR1cGRhdGVVbnJlYWRDb3VudCgpO1xyXG5cclxuXHRcdFx0XHRcdGFuZ3VsYXIuZWxlbWVudCgnI2Zvcm0tdGhyZWFkLWJ0bicpLmFwcGVuZChhbmd1bGFyLmVsZW1lbnQoJyN0aHJlYWQtdW5yZWFkLWNvdW50JykpO1xyXG5cclxuXHRcdFx0XHRcdCR0aW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KFwidGhyZWFkOmxvYWRcIiwgZGF0YS5kYXRhKTtcclxuXHJcblx0XHRcdFx0XHRcdGlmIChvcGVuT25Mb2FkID09PSAndHJ1ZScpIHtcclxuXHRcdFx0XHRcdFx0XHQkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2RkOm9wZW4nLCB7IG5hbWU6ICdmb3JtLXRocmVhZCcgfSk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pO1xyXG5cdFx0XHRcdH0sIGZ1bmN0aW9uICh4aHIpIHtcclxuXHRcdFx0XHRcdGlmICh4aHIuc3RhdHVzICE9IC0xKVxyXG5cdFx0XHRcdFx0XHRjdHJsLnhociA9IHhocjtcclxuXHRcdFx0XHRcdGVsc2VcclxuXHRcdFx0XHRcdFx0Y3RybC54aHIgPSBmYWxzZTtcclxuXHRcdFx0XHRcdHhoci5lcnJvclRpdGxlID0gbGFuZy5nZXQoXCJmb3JtLXRocmVhZC1kYXRhLWVycm9yLW1zZ1wiKTtcclxuXHRcdFx0XHRcdGFwaS5zaG93U2VydmVyRXJyTXNnKHhocik7XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHR2YXIgY2hhbmdlTXNnID0gZnVuY3Rpb24gKG1zZykge1xyXG5cdFx0XHRcdGlmICh0eXBlb2YgbXNnICE9ICdvYmplY3QnKSB7XHJcblx0XHRcdFx0XHRtc2cgPSBmaW5kVGhyZWFkKG1zZyk7XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0XHRpZiAoY3RybC5hY3RpdmVNc2dJZCA9PSBtc2cubXNnSWQpIHtcclxuXHRcdFx0XHRcdHJldHVybjtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdGN0cmwuYWN0aXZlTXNnSWQgPSBtc2cubXNnSWQ7XHJcblxyXG5cdFx0XHRcdC8vIGNsb3NlIGRyb3Bkb3duXHJcblx0XHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KFwiZGQ6Y2xvc2VcIik7XHJcblx0XHRcdFx0JHJvb3RTY29wZS4kYnJvYWRjYXN0KFwidGhyZWFkOmNoYW5nZVwiLCBtc2cpO1xyXG5cdFx0XHR9O1xyXG5cclxuXHRcdFx0Y3RybC5yZWZyZXNoID0gZnVuY3Rpb24gKHNpbGVudCkge1xyXG5cdFx0XHRcdGZldGNoKHNpbGVudCk7XHJcblx0XHRcdH07XHJcblxyXG5cdFx0XHRjdHJsLnRocmVhZENsaWNrID0gZnVuY3Rpb24gKGV2ZW50LCBtc2cpIHtcclxuXHRcdFx0XHRjaGFuZ2VNc2cobXNnKTtcclxuXHRcdFx0fTtcclxuXHRcdH1dLFxyXG5cdGJpbmRpbmdzOiB7XHJcblx0XHR0cmlnZ2VyOiAnPCdcclxuXHR9XHJcbn0pO1xyXG4iXX0=
