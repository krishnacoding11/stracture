/*!
 * This JS useful for open web Report from Apps  
 * Author: ANKIT THAKKAR
 * Date  : 9 Sep 2014 
 */
var plainParamArray = {};
var xpathParamsArray = {};

 
function showSelectedReportfromApp(form_template_name,format,reportType,valueArray,reportName){
	
	setReportCriteria(form_template_name,format,reportType);
	
	var formElement = document.createElement('form');
	formElement.name = "openReport";
	formElement.action = INIT_JSP_GLOBAL.expoContext+"xsl/customform_report_download.jsp";
	formElement.target = "_openReport";
	formElement.method = "post";
	var formInputs= '';
	
	for(var key in plainParamArray){
        formInputs += '<input type="hidden" name="'+key+'" value="'+plainParamArray[key]+'" />';
     }	
	for(var key in xpathParamsArray){
		formInputs += '<input type="hidden" name="xpath_'+key+'" value="'+xpathParamsArray[key]+'" />';
	}
	if(typeof valueArray != 'undefined'){
		formInputs += '<input type="hidden" name="rc_param_value" value="' + valueArray + '" />';
		formInputs += '<input type="hidden" name="rc_report_name" value="' + reportName + '" />';
	}
	formInputs += '<input type="hidden" name="applicationId" value="' + applicationId + '" />';
	formElement.innerHTML= formInputs;
	
	var _body = document.getElementsByTagName('body') [0];	
	_body.appendChild(formElement);
	
	openPleaseWaitPage(formElement.target);
	
	window.setTimeout(function(){ formElement.submit(); },800);
	
}

function openPleaseWaitPage(winName){
	var sW=460, sH=400;
	var wL = parseInt((screen.availWidth - sW) / 2);
	var wT = parseInt((screen.availHeight - sH) / 2);
	var winFeatures = "toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=yes,left="+wL+",top="+wT+",width= "+ sW +",height= "+ sH;
	if(applicationId != 3){
		window.open(contextpath+"/view/common/blankPage.jsp",winName, winFeatures);
	}
		
}

function setReportCriteria(form_template_name, format, reportType) {

	var projectId = viewForm_PID;
	var formId = document.getElementById('formId').value;
	var form_Template_Name = form_template_name; // "EA PPMT - Project   Summary Report (Draft-Submitted)";
	var action_id = 9001;
	var date = new Date();
	var datetime = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
	datetime = "_" + getFormattedMonthDate(datetime) + "_" + date.getHours() + date.getMinutes() + date.getSeconds();

	plainParamArray['projectId'] = viewForm_PID;
	plainParamArray['rc_project_id'] = viewForm_PID;
	plainParamArray['formId'] = formId;
	plainParamArray['action_id'] = action_id;
	plainParamArray['isTemplate'] = true;
	plainParamArray['appId'] = 0;
	plainParamArray['datetime'] = datetime;
	plainParamArray['isFromReportDropDown'] = true; //for getting proxy user as userid in reporting

	if (form_Template_Name != "") {
		plainParamArray['report_title'] = form_template_name;
		plainParamArray['Format_value'] = format;
		xpathParamsArray['rc_form_id'] = "form_code";
		if (reportType == 'Ext') {
			if (form_Template_Name == "PPMT_DS_017_Project Summary Report (Draft-Submitted) V1_5") {}
			else if (form_Template_Name == "EA_PPMT_Monthly_Funding_Report-FCRM") {
				xpathParamsArray['rc_region_id'] = "/myFields/FORM_CUSTOM_FIELDS/ORI_MSG_Custom_Fields/PROJECT_RECORD/PROJECT_LOCATION/Region";
			} else if (form_Template_Name == "Staff Status Report" || form_Template_Name == "Company Timesheet Report by Approval Date" || form_Template_Name == "Company Timesheet Report by Week" || form_Template_Name == "Timesheets Received Checklist Report" || form_Template_Name == "Billable vs Actual Cost Report" || form_Template_Name == "Staff Member Timesheet Report" || form_Template_Name == "Rejected Timesheet Report" || form_Template_Name == "Pending Timesheets Report" || form_Template_Name == "Unapproved Timesheet Report" || form_Template_Name == "Project WBS Status Report" || form_Template_Name == "Staff Status ReportCSV" || form_Template_Name == "Company Timesheet Report by Approval DateCSV" || form_Template_Name == "Company Timesheet Report by WeekCSV" || form_Template_Name == "Timesheets Received Checklist ReportCSV" || form_Template_Name == "Billable vs Actual Cost ReportCSV" || form_Template_Name == "Staff Member Timesheet ReportCSV" || form_Template_Name == "Rejected Timesheet ReportCSV" || form_Template_Name == "Pending Timesheets ReportCSV" || form_Template_Name == "Unapproved Timesheet ReportCSV" || form_Template_Name == "Project WBS Status ReportCSV" || form_Template_Name == "Aurecon Report" || form_Template_Name == "Aurecon ReportCSV") {
				var Get_String = IJ_GetSinFld("Data_Filter_Final");
				var strSplit = Get_String.split('|');
				plainParamArray['rc_proj_ids'] = strSplit[0];
				plainParamArray['rc_company_ids'] = strSplit[1];
				plainParamArray['rc_staff_ids'] = strSplit[2];
				plainParamArray['rc_year_from'] = strSplit[3];
				plainParamArray['rc_year_to'] = strSplit[4];
				plainParamArray['rc_week_from'] = strSplit[5];
				plainParamArray['rc_week_to'] = strSplit[6];
				plainParamArray['rc_company_codes'] = IJ_GetSinFld('my:Filter_FormCode');

				if (form_Template_Name == "Timesheets Received Checklist Report" || form_Template_Name == "Company Timesheet Report by Week" || form_Template_Name == "Unapproved Timesheet Report" || form_Template_Name == "Company Timesheet Report by WeekCSV" || form_Template_Name == "Unapproved Timesheet ReportCSV" || form_Template_Name == "Aurecon Report" || form_Template_Name == "Aurecon ReportCSV") {
					plainParamArray['rc_status'] = strSplit[7];
					plainParamArray['rc_reporttype'] = "0";
				}

				if (form_Template_Name == "Timesheets Received Checklist ReportCSV") {
					plainParamArray['rc_status'] = strSplit[7];
					plainParamArray['rc_reporttype'] = "2";
				}

				if (form_Template_Name == "Staff Member Timesheet Report" || form_Template_Name == "Staff Member Timesheet ReportCSV") {
					plainParamArray['rc_status'] = strSplit[7];
					plainParamArray['rc_reporttype'] = "0|Staff";
				}

				if (form_Template_Name == "Company Timesheet Report by Approval Date" || form_Template_Name == "Billable vs Actual Cost Report" || form_Template_Name == "Company Timesheet Report by Approval DateCSV" || form_Template_Name == "Billable vs Actual Cost ReportCSV") {
					plainParamArray['rc_status'] = strSplit[7];
					plainParamArray['rc_reporttype'] = "1";
				}

				if (form_Template_Name == "Project WBS Status Report" || form_Template_Name == "Project WBS Status ReportCSV") {
					plainParamArray['rc_status'] = strSplit[7];
				}

				if (form_Template_Name == "Company Timesheet Report by Approval Date" || form_Template_Name == "Company Timesheet Report by Week" || form_Template_Name == "Unapproved Timesheet Report" || form_Template_Name == "Company Timesheet Report by Approval DateCSV" || form_Template_Name == "Company Timesheet Report by WeekCSV" || form_Template_Name == "Unapproved Timesheet ReportCSV" || form_Template_Name == "Aurecon Report" || form_Template_Name == "Aurecon ReportCSV") {
					plainParamArray['rc_start_date'] = strSplit[8];
					plainParamArray['rc_end_date'] = strSplit[9];
				}
			} else if (form_Template_Name == "EA_BIM_PAS1192_01_PIDP_COBie" || form_Template_Name == "EA_BIM_PAS1192_02_PIDP_ProjectXML" || form_Template_Name == "ASI_BIM_PAS1192_01_PIDP_COBie") {
				var Get_String = IJ_GetSinFld("my:Project_FormID");
				plainParamArray['rc_project_title'] = Get_String.trim();
			} else if (form_Template_Name == "EA_IDP_BIM_PAS1192_01_PIDP_COBie") {
				var Get_String = IJ_GetSinFld("my:Project_FormID");
				plainParamArray['rc_project_title'] = Get_String.trim();
				plainParamArray['action_id'] = "9005";
				plainParamArray['formTypeId'] = formtypeid.split('$')[0];
			} else if (form_Template_Name == "EA_IDP_BIM_PAS1192_01_PIDP_COBie_Validation") {
				var Get_String = IJ_GetSinFld("my:Project_FormID");
				plainParamArray['rc_project_title'] = Get_String.trim();
				plainParamArray['rc_file_name'] = GetFileNameFromXSN;
			} else if (form_Template_Name == "Company Band Rate Report") {
				var Get_String = IJ_GetSinFld("my:tmpComp");
				plainParamArray['rc_search_nop'] = Get_String.trim();
			} else if (form_Template_Name == "Project Bulk Timesheet Report") {
				xpathParamsArray['rc_form_id'] = "form_id";
			} else if (form_Template_Name == "TTTCommentingFormExport" || form_Template_Name == "RCR Associated Doc Comnt Register" || form_Template_Name == "AGL Associated Doc Comnt Report" || form_Template_Name == "LOR Associated Doc Comnt Register" || form_Template_Name == "Associate Doc Comnt Register" || form_Template_Name == "RCR Associated Doc Report" || form_Template_Name == "Associated_Document_Sheet") {
				var userID = JSON.parse($('#DS_WORKINGUSER_ID').val()).Items.Item[0].Value.split('|')[0].trim() || "";
				plainParamArray['rc_report_author_user_id'] = userID;
			} else if (form_Template_Name == "Native_Home Demonstration_Report" || form_Template_Name == "Native_HL_Home Demonstration_Report" || form_Template_Name == "Native_HL_Defect_Notice_Report" || form_Template_Name == "Native_Home Demonstration_Report" || form_Template_Name == "Native_HL_Snag_List_Report" || form_Template_Name == "Native_Defect_Notice_Report" || form_Template_Name == "Native_Snag_List_Report") {
				xpathParamsArray['rc_form_type_id'] = 'form_type_id';
			} else if (form_Template_Name == "NNG-ChangeOrderSummary-UAT") {
				if (currentWorkOrderflag) {
					plainParamArray.rc_wo_ids = IJ_GetSinFld('my:Work_Order_Number');
				} else {
					plainParamArray.rc_wo_ids = "ALL";
				}
				var workingUserId = getdataFromSecondayDataSource("DS_WORKINGUSER_ID", "Name", "Value", "", "");
				var userID = workingUserId && workingUserId.split('|')[0].trim();
				plainParamArray.rc_report_author_user_id = userID;
				if (PurchaseOrderflag) {
					plainParamArray.rc_is_wo = "2";
					plainParamArray.rc_con_ids = "ALL";
					if (currentPurchaseOrderflag) {
						plainParamArray.rc_po_ids = IJ_GetSinFld('my:PurchaseOrderNumber');
					} else {
						plainParamArray.rc_po_ids = "ALL";
					}
				} else {
					plainParamArray.rc_is_wo = "1";
					plainParamArray.rc_con_ids = IJ_GetSinFld("my:DS_Orig_Org_Id");
				}
			}
		} else if (form_Template_Name == "EA_WEM_XX_002_WCFN_Report") {
			plainParamArray['rc_form_id'] = IJ_GetSinFld('my:DS_FORMID');
		}
	}
}


function getFormattedMonthDate(date){
    var reg=/(.*?)\/(.*?)\/(.*?)$/;
    var res = date.replace(reg,function(match,a,b,c){
        var months=Date.monthAbbreviations;
        return (a<10?"0"+a:a)+"-"+months[(b-1)]+"-"+c;
    });
    return res;
}
