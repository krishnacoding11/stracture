function RevitFileObjectList(viewer) {
    var _self = this;
    this.webviewer = viewer;

    this.revitObjectList = "#revitObjectList";

    this._viewerRevitFileListSelector = "#viewer-revitFileList-dialog";
    this._initElements();
    var addObjectListBtn = document.getElementById("add-object-list");
    addObjectListBtn.onclick = function ToggleColorsusingselectedNodeIDs() {
        _self.showpopup();
    };

    $('#viewerContainer-canvas-container').mouseup(function (event) {
        var pickConfig = new Communicator.PickConfig(Communicator.SelectionMask.All);
        //Get theb position on face/edge using pick from point API
        var position = new Communicator.Point2(event.clientX, event.clientY);
        _self.webviewer.view.pickFromPoint(position, pickConfig).then(function (selection) {
            if (selection.getSelectionType() === Communicator.SelectionType.None) {
                var childsrevitObjectList = document.getElementById("revitObjectList").childNodes;

                for (var i = 0; i < childsrevitObjectList.length; i++) {
                    if (childsrevitObjectList[i].style) childsrevitObjectList[i].style.backgroundColor = "transparent";
                }
            }
            selectionArray = [];
            // if (selection.getSelectionType() !== Communicator.SelectionType.None) {   }
        });
    });

}


RevitFileObjectList.prototype._initElements = function () {
    var _self = this;

    $("#viewer-revitFileList-dialog-container").draggable({
        handle: ".hoops-ui-window-header"
    });
    $("INPUT.color-picker").each(function () {
        $(this).minicolors({
            position: $(this).attr("data-position") || "bottom left",
            format: "rgb",
            control: "hue"
        })
    });
    $("#viewer-revitFileList-ok-button").on("click",
        function () {
            // c._applySettings();
            // _self.resetCompare();
            // document.getElementById("resetcompare").style.display = "none";
            // $("#compare").show();
            $("#viewer-revitFileList-dialog").hide();
        });
    $("#viewer-revitFileList-cancel-button").on("click", function () {
        $("#viewer-revitFileList-dialog").hide()
        // $("#Comparison-list").show();
    });
    $("#viewer-revitFileList-apply-button").on("click", function () {
        return __awaiter(c, void 0, void 0, function () {
            return __generator(this, function (a) {
                switch (a.label) {
                    case 0:
                        return [4, this._applySettings()];
                    case 1:
                        return a.sent(), [2]
                }
            })
        })
    });
}


RevitFileObjectList.prototype.showpopup = function () {
    var a = $(this._viewerRevitFileListSelector),
        c = a.width(),
        b = a.height();
    if (void 0 !== c && void 0 !== b) {
        var d = this.webviewer.view.getCanvasSize();
        a.css({
            left: (d.x -
                c) / 2 + "px",
            top: (d.y - b) / 2 + "px"
        })
    }
    $(this._viewerRevitFileListSelector).show();
    a.draggable({
        handle: ".hoops-ui-window-header"
    });

}

RevitFileObjectList.prototype.remove = function (array, element) {
    // function remove(array, element) {
        const index = array.indexOf(element);
        if (index != -1)
            array.splice(index, 1);
    }


RevitFileObjectList.prototype.addToList = async function (nodeid) {
    var bodyid = null;
    var _self = this;
    // var child1 = hwv.getModel().getNodeChildren(Number(nodeid)); //nodeid = windows

    // if (child1.length > 0) // node id - itself is body
    // {
    //     var child2 = hwv.getModel().getNodeChildren(child1[0]);
    //     if (child2.length == 0) { // nodeId was product and this is body
    //         if (hwv.model.getNodeName(Number(child1[0])).includes("body")) {
    //             bodyid = Number(child1[0]);
    //             // return true;
    //         } else if (child1.length == 1) {
    //             bodyid = Number(child1[0]);
    //         }
    //     } else {
    //         var child3 = hwv.getModel().getNodeChildren(child2[0]);
    //         if (child3.length == 0) // nodeId was product and this is body
    //         {
    //             if (hwv.model.getNodeName(Number(child2[0])).includes("body")) {

    //                 bodyid = Number(child2[0]);
    //             }
    //         } else {
    //             return;
    //         }
    //     }
    // } else {
    //     bodyid = nodeid
    // }

    /*if (bodyid)*/ {

        var grandparentnodeid = Number(nodeid);
        var grandparentname = hwv.model.getNodeName(Number(nodeid));
        var genericid = null;
        var rootNodeId = hwv.model.getRootNode();
        var modelRoot = hwv.model.getNodeChildren(rootNodeId)[0];
        var fileType = hwv.model.getModelFileTypeFromNode(modelRoot);
        if (fileType === Communicator.FileType.Ifc)
        {
            genericid = hwv.model.getNodeGenericId(grandparentnodeid);
        }
        else if (fileType === Communicator.FileType.Revit)
        {
            var props = await hwv.model.getNodeProperties(nodeid);
            genericid = props["persistentId"];
        }
        var revitObjectList = document.getElementById("revitObjectList");
        var newdiv = document.createElement("div");
        newdiv.className = "noderow";
        newdiv.id = grandparentnodeid;
        var docref = hwv.model.getModelFileNameFromNode(grandparentnodeid);
        var seconddiv = document.createElement("div");
        seconddiv.className = "boxsquare green";
        // seconddiv.className ="red";
        var label = document.createElement("label");
        //label.innerHTML = grandparentname + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";


        // filetype = getFiletype(grandparentnodeid);
        var rootNodeId = hwv.model.getRootNode();
        var modelRoot = hwv.model.getNodeChildren(rootNodeId)[0];
        var fileType = hwv.model.getModelFileTypeFromNode(modelRoot);
        if (fileType === Communicator.FileType.Revit)
        {
        // if (filetype == 2) {
            var nodetypeid = hwv.model.getNodeParent(grandparentnodeid);
            var nodetypename = hwv.model.getNodeName(nodetypeid);
            label.innerHTML = nodetypename + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";

        } else {
            var nodetype = hwv.model.getNodeGenericType(grandparentnodeid);
            label.innerHTML = nodetype + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
        }

        label.className = "ellipsis";

        newdiv.appendChild(seconddiv);
        newdiv.appendChild(label);

        newdiv.onmouseover = function (event) {
            if (event.currentTarget.style.backgroundColor == "transparent" ||
                event.currentTarget.style.backgroundColor == "")
                event.currentTarget.style.backgroundColor = "lightgray";
        };
        newdiv.onmouseout = function (event) {
            if (event.currentTarget.style.backgroundColor == "lightgray")
                event.currentTarget.style.backgroundColor = "transparent";
        };

        newdiv.onclick = function () {
            // hwv.selectionManager.clear();
            var childs = document.getElementById("revitObjectList").childNodes;

            if (event.currentTarget.style.backgroundColor !== "lightskyblue") {
                event.currentTarget.style.backgroundColor = "lightskyblue";
                selectionArray.push(Number(event.currentTarget.id));
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            } else {
                event.currentTarget.style.backgroundColor = "transparent";
                _self.remove(selectionArray, Number(event.currentTarget.id))
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            }
        };


        revitObjectList.appendChild(newdiv);
        this.showpopup();
    }

}