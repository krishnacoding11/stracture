// var nodeIDsUpdatedArray = [];
// var nodeIDsBUpdatedArray = [];
// var nodeIDsTUpdatedArray = [];
// var nodeIDsUpdatedArrayFromList = [];
// var globalIDsUpdatedArray = [];
// var nodeIDsCreatedArray = [];
// var globalIDsCreatedArray = [];
// var nodeIDsDeletedArray = [];
// var globalIDsDeletedArray = [];
// var uniqueModelsNodes = [];
// var uniqueMultipleModelsNodes = [];
// var uniqueMultipleBaseModelsNodes = [];
// var uniqueMultipleTargetModelsNodes = [];
// var unchangedobjectsleafnodes = [];
// var IFCSPACESleafnodes = [];
// var collectionOfSpacesIds = [];
// var filetype = 0;
// var allnodespidsMap = {};
// var this.allnodescogMap = {};
// var allnodeslocalpidsMap = {};

// var allnodesNamesMap = {};
// var selectionArray = [];
// var AllBaseNodeIds = [],
//     AllTargetNodeIds = [];
var RevitFileObjectListObj = null;
var starttime = null;
allnodeslocalproperties = {};

function ModelCompare(viewer) {
    var _self = this;
    this.webviewer = viewer;
    this.nodeStructure = {};
    this.updatedGidArrayfirst = [];
    this.deletedGidArrayfirst = [];
    this.firstModelsGlobalIdArray = [];
    this.secondModelsGlobalIdArray = [];
    this.updatedGidArraySecond = [];
    this.deletedGidArraySecond = [];
    this._viewerModelCompareSelector = "#viewer-modelcompare-dialog";
    this.selectiontablabel = "#selectiontablabel";
    this.resulttablabel = "#resulttablabel";
    this.selectiontab = "#selectiontab";
    this.resulttab = "#resulttab";
    this.newaddedtablabel = "#newaddedtab";
    this.modifiedtablabel = "#modifiedtab";
    this.Bmodifiedtablabel = "#bmodifiedtab";
    this.Tmodifiedtablabel = "#tmodifiedtab";
    this.removedtablabel = "#removedtab";
    this.unchangedtablabel = "#unchangedtab";
    this.newaddedtabeye = "#newaddedtabeye";
    this.modifiedtabeye = "#modifiedtabeye";
    this.removedtabeye = "#removedtabeye";

    this.modifiedtab = "#modifiedlist";
    this.newaddedtab = "#addedlist";
    this.removedtab = "#removedlist";
    this.basemodelinput = "#basemodelinput";
    this.comparemodelinput = "#comparemodelinput";
    this.targetmodelinput = "#targetmodelinput";
    this.ComparisonListButton = "#Comparison-list";

    this.nodeIDsUpdatedArray = [];
    this.nodeIDsBUpdatedArray = [];
    this.nodeIDsTUpdatedArray = [];
    this.nodeIDsUpdatedArrayFromList = [];
    this.globalIDsUpdatedArray = [];
    this.nodeIDsCreatedArray = [];
    this.globalIDsCreatedArray = [];
    this.nodeIDsDeletedArray = [];
    this.globalIDsDeletedArray = [];
    this.uniqueModelsNodes = [];
    this.uniqueMultipleModelsNodes = [];
    this.uniqueMultipleBaseModelsNodes = [];
    this.uniqueMultipleTargetModelsNodes = [];
    this.unchangedobjectsleafnodes = [];
    this.filetype = 0;
    this.allnodespidsMap = {};
    this.allnodescogMap = {};
    this.allnodeslocalpidsMap = {};
    this.allnodesNamesMap = {};
    this.selectionArray = [];
    this.AllBaseNodeIds = [];
    this.AllTargetNodeIds = [];

    this.addednodesCount = 0; 
    this.updatednodesCount = 0; 
    this.updatedDeletedCount = 0;

    this.addedListReady = false;
    this.updatedListReady = false;
    this.DeletedListReady = false;

    this.redcolor = new Communicator.Color(255, 0, 0);
    this.greencolor = new Communicator.Color(0, 255, 0);
    this.ambercolor = new Communicator.Color(255, 191, 0);

    this.doc1 = null;
    this.workbookElem = null;
    this.worksheetElem1 = null;
    this.worksheetElem2 = null;
    this.worksheetElem3 = null;
    this.worksheetElem = [];
    this.tableElem = [];


    RevitFileObjectListObj = new RevitFileObjectList(viewer);
    this._initElements();
}


ModelCompare.prototype.testSpec = function () {
    console.log("testing model compare object");

    return 1;
}

ModelCompare.prototype.startProgress = async function () {
    document.getElementById("middleLoader").style.display = "block";
    document.getElementById("viewerContainer").style.opacity = "0.30";
    document.getElementById("toolBar").style.opacity = "0.30";
    this.updateProgressBar(2);
}

ModelCompare.prototype.compareFiles = async function (selectednodes) {

    try {
        this.nodeIDsUpdatedArray = [];
        this.nodeIDsBUpdatedArray = [];
        this.nodeIDsTUpdatedArray = [];
        this.nodeIDsUpdatedArrayFromList = [];
        this.nodeIDsCreatedArray = [];
        this.nodeIDsDeletedArray = [];
        this.globalIDsUpdatedArray = [];
        this.globalIDsCreatedArray = [];
        this.globalIDsDeletedArray = [];
        starttime = Math.floor(Date.now() / 1000);
        this.addedListReady = false;
        this.updatedListReady = false;
        this.DeletedListReady = false;
        var _self = this;

        var rootNodeId = this.webviewer.getModel().getRootNode();
        // this.uniqueModelsNodes = selectednodes;
        this.uniqueMultipleModelsNodes = selectednodes;
        // document.getElementById("middleLoader").style.display = "block";
        // document.getElementById("viewerContainer").style.opacity = "0.30";
        // document.getElementById("toolBar").style.opacity = "0.30";
        this.webviewer.getModel().setNodesVisibility(this.uniqueMultipleModelsNodes, true);
        this.webviewer.selectionManager.clear()
        this.nodeStructure.parent = rootNodeId;
        this.filetype = this.getFiletype(this.uniqueMultipleModelsNodes[0]);

        var AllglobalIDsBaseModels = [],
            AllglobalIDsTargetModels = [];
        var AllleafNodeIDForBaseModels = [],
            AllleafNodeIDForTargetModels = [];
        var leafnodesGidBaseMap = {},
            NodesGidBaseMap = {};
        var leafnodesGidTargetMap = {},
            NodesGidTargetMap = {};
        this.AllBaseNodeIds = [];
        this.AllTargetNodeIds = [];
        var AllBaseLeafNodeIds = [],
            AllTargetLeafNodeIds = [];
        var allBasenodespidsMap = {},
            allTargetnodespidsMap = {};
        var allnodesPropertiesMap = {};
        var allBasenodesSurfaceAreaMap = {},
            allTargetnodesSurfaceAreaMap = {};

        _self.updateProgressBar(2);

        this.allnodeslocalpidsMap = {};
        var halfcount = this.uniqueMultipleModelsNodes.length / 2;
        for (var i = 0; i < this.uniqueMultipleModelsNodes.length / 2; i++) {
            this.uniqueMultipleBaseModelsNodes.push(this.uniqueMultipleModelsNodes[i]);
            this.uniqueMultipleTargetModelsNodes.push(this.uniqueMultipleModelsNodes[i + halfcount]);
        }
        _self.updateProgressBar(5);
        setTimeout(async function () {


            _self.collectallnodeids(_self.uniqueMultipleBaseModelsNodes, _self.AllBaseNodeIds, AllBaseLeafNodeIds);
            _self.collectallnodeids(_self.uniqueMultipleTargetModelsNodes, _self.AllTargetNodeIds, AllTargetLeafNodeIds);

            _self.updateProgressBar(17);

            setTimeout(async function () {
                await Promise.all([_self.collectAllPids(AllBaseLeafNodeIds, allBasenodespidsMap, allBasenodesSurfaceAreaMap),
                    _self.collectAllPids(AllTargetLeafNodeIds, allTargetnodespidsMap, allTargetnodesSurfaceAreaMap)
                ]);
                _self.updateProgressBar(29);

                setTimeout(async function () {
                    await Promise.all([_self.getAllnodesObjectarray(_self.uniqueMultipleBaseModelsNodes, AllglobalIDsBaseModels, AllleafNodeIDForBaseModels, leafnodesGidBaseMap, NodesGidBaseMap, allBasenodespidsMap),
                        _self.getAllnodesObjectarray(_self.uniqueMultipleTargetModelsNodes, AllglobalIDsTargetModels, AllleafNodeIDForTargetModels, leafnodesGidTargetMap, NodesGidTargetMap, allTargetnodespidsMap)
                    ]);
                    _self.updateProgressBar(38);

                    // var leafnodesbbBaseMap = {};
                    // var leafnodesbbTargetMap = {};
                    // var AllBBsBaseModelArr = [],
                    //     AllBBsTargetModelArr = [];
                    // await Promise.all([ _self.collectBoundingboxMap(AllleafNodeIDForBaseModels, leafnodesbbBaseMap, AllBBsBaseModelArr),
                    //                     _self.collectBoundingboxMap(AllleafNodeIDForTargetModels, leafnodesbbTargetMap, AllBBsTargetModelArr)]);


                    let intersection = AllglobalIDsBaseModels.filter(x => AllglobalIDsTargetModels.includes(x));
                    let differenceofglobalIDBase = AllglobalIDsBaseModels.filter(x => !AllglobalIDsTargetModels.includes(x));
                    let differenceofglobalIDTarget = AllglobalIDsTargetModels.filter(x => !AllglobalIDsBaseModels.includes(x));
                    _self.updateProgressBar(41);

                    setTimeout(async function () {
                        _self.calculateNodeIds(NodesGidBaseMap, differenceofglobalIDBase, true);
                        _self.calculateNodeIds(NodesGidTargetMap, differenceofglobalIDTarget, false);
                        _self.updateProgressBar(48);

                        setTimeout(async function () {

                            // let differenceofBBidsBase = AllBBsBaseModelArr.filter(x => !AllBBsTargetModelArr.includes(x));
                            // let differenceofBBidsTarget = AllBBsTargetModelArr.filter(x => !AllBBsBaseModelArr.includes(x));
                            // let intersectionofBBids = AllBBsBaseModelArr.filter(x => AllBBsTargetModelArr.includes(x));

                            // let differencenodeidsBasedOnBBArrayBase = differencenodeidsBasedOnBB(leafnodesbbBaseMap, differenceofBBidsBase);
                            // let differencenodeidsBasedOnBBArrayTarget = differencenodeidsBasedOnBB(leafnodesbbTargetMap, differenceofBBidsTarget);
                            // let intersectionnodeidsBaseBasedOnBBArray = differencenodeidsBasedOnBB(leafnodesbbBaseMap, intersectionofBBids);
                            // let intersectionnodeidsTargetBasedOnBBArray = differencenodeidsBasedOnBB(leafnodesbbTargetMap, intersectionofBBids);

                            let updatednodeIdsArray = [];
                            var leafnodesVertexcountBaseMap = {};
                            var leafnodesVertexcountTargetMap = {};
                            var AllVCsBaseModelArr = [],
                                AllVCsTargetModelArr = [];
                            var baseNodesNamesMap = {};
                            var targetNodesNamesMap = {};
                            var baseNodesNamesMapArray = [];
                            var targetNodesNamesMaparray = [];

                            await Promise.all([_self.collectAllIFCNames(_self.nodeIDsCreatedArray, targetNodesNamesMap, targetNodesNamesMaparray),
                                _self.collectAllIFCNames(_self.nodeIDsDeletedArray, baseNodesNamesMap, baseNodesNamesMapArray)
                            ]);

                            _self.updateProgressBar(62);
                            setTimeout(async function () {
                                var nodesbbBaseMap = {};
                                var nodesbbTargetMap = {};
                                var BBsBaseModelArr = [],
                                    BBsTargetModelArr = [];

                                await Promise.all([_self.collectBoundingboxMap(_self.nodeIDsDeletedArray, nodesbbBaseMap, BBsBaseModelArr),
                                    _self.collectBoundingboxMap(_self.nodeIDsCreatedArray, nodesbbTargetMap, BBsTargetModelArr)
                                ]);
                                _self.updateProgressBar(71);
                                setTimeout(async function () {
                                    await Promise.all([_self.collectVertexCountMap(AllleafNodeIDForBaseModels, leafnodesVertexcountBaseMap, AllVCsBaseModelArr),
                                        _self.collectVertexCountMap(AllleafNodeIDForTargetModels, leafnodesVertexcountTargetMap, AllVCsTargetModelArr)
                                    ]);
                                    _self.updateProgressBar(76);
                                    setTimeout(async function () {

                                        if (_self.filetype == 2) {

                                            _self.checkNamesDuplicationRvt(baseNodesNamesMap, baseNodesNamesMapArray, targetNodesNamesMap,
                                                targetNodesNamesMaparray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr,
                                                leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap);
                                        } else {
                                            _self.checkNamesDuplication(baseNodesNamesMap, baseNodesNamesMapArray, targetNodesNamesMap,
                                                targetNodesNamesMaparray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr,
                                                leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap);
                                        }

                                        _self.updateProgressBar(81);
                                        setTimeout(async function () {
                                            if (_self.filetype == 2) {
                                                var basepidcreatedmap = {},
                                                    targetpiddeletedmap = {},
                                                    baseCOGMap = {},
                                                    targetCOGmap = {},
                                                    basepidcreatedarray = [],
                                                    targetpiddeletedarray = [];
                                                await Promise.all([_self.getPIDsForAddedAndRemoved(_self.nodeIDsCreatedArray, targetpiddeletedmap, targetpiddeletedarray, targetCOGmap),
                                                    _self.getPIDsForAddedAndRemoved(_self.nodeIDsDeletedArray, basepidcreatedmap, basepidcreatedarray, baseCOGMap)
                                                ]);

                                                _self.checkpidDuplication(basepidcreatedmap, basepidcreatedarray, targetpiddeletedmap,
                                                    targetpiddeletedarray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr);


                                                //Third cycle
                                                var basecogcreatedmap = {},
                                                    targetcogdeletedmap = {},
                                                    basecogcreatedarray = [],
                                                    targetcogdeletedarray = [];
                                                await Promise.all([_self.getCOGsForAddedAndRemoved(_self.nodeIDsCreatedArray, targetcogdeletedmap, targetcogdeletedarray),
                                                    _self.getCOGsForAddedAndRemoved(_self.nodeIDsDeletedArray, basecogcreatedmap, basecogcreatedarray)
                                                ]);

                                                _self.checkcogDuplication(basecogcreatedmap, basecogcreatedarray, targetcogdeletedmap,
                                                    targetcogdeletedarray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr);






                                            }

                                            _self.updateProgressBar(87);
                                            setTimeout(async function () {

                                                // this.changeColorbyGlobalId(addednodes, redcolor, true);
                                                // this.changeColorbyNodesExceptUpdated(differencenodeidsBasedOnBBArrayBase, updatednodeIdsArray, redcolor, true);

                                                // this.changeColorbyGlobalId(NodesGidTargetMap, differenceofglobalIDTarget, greencolor, false);
                                                // this.changeColorbyNodesExceptUpdated(differencenodeidsBasedOnBBArrayTarget, updatednodeIdsArray, greencolor, false);
                                                _self.createXMLBase();
                                                await Promise.all([_self.populateAddedinresult(_self.nodeIDsCreatedArray, allnodesPropertiesMap),
                                                    _self.populateDeletedinresult(_self.nodeIDsDeletedArray, allnodesPropertiesMap)
                                                ]);


                                                _self.changeColorbyGlobalIdbygloablarray();

                                               // console.log("third cycle to identify modified from added and deleted list start : ", Math.floor(Date.now() / 1000) - starttime , " sec");
                                                await _self.findUpdatednodesFromintersectionArrayandVC(intersection, leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap, leafnodesGidBaseMap, leafnodesGidTargetMap,
                                                    NodesGidBaseMap, NodesGidTargetMap, allBasenodesSurfaceAreaMap, allTargetnodesSurfaceAreaMap, updatednodeIdsArray);

                                               // console.log("third cycle to identify modified from added and deleted list end : ", Math.floor(Date.now() / 1000) - starttime , " sec");
                                                

                                                    _self.updateProgressBar(91);
                                                //    console.log("after 91% : ", Math.floor(Date.now() / 1000) - starttime , " sec");

                                                setTimeout(async function () {
                                                    _self.populatenodeIDsUpdatedArray(updatednodeIdsArray);
                                                    _self.populateUpdatedinresult(_self.nodeIDsUpdatedArray, allnodesPropertiesMap);
                                                    _self.changeColorbyNodes(_self.nodeIDsUpdatedArrayFromList, _self.ambercolor);
                                                    _self.updateProgressBar(99);
                                              //      console.log("after 99% : ", Math.floor(Date.now() / 1000) - starttime , " sec");

                                                    _self.removeIFCSPACESfromUnchanged();

                                                    // document.getElementById("middleLoader").style.display = "none";

                                                    // document.getElementById("viewerContainer").style.opacity = "1.0";
                                                    // document.getElementById("toolBar").style.opacity = "1.0";

                                                    // this.showpopup();
                                                    // $(this.ComparisonListButton).hide();
                                                    // document.getElementById("compare-tab-added").scroll({
                                                    //     top: 0,
                                                    //     behavior: 'smooth',
                                                    // }) 
                                                }, 1);
                                            }, 1);
                                        }, 1);
                                    }, 1);
                                }, 1);
                            }, 1);
                        }, 1);
                    }, 1);
                }, 1);
            }, 1);
        }, 1);
    } catch (err) {
        console.error(err);
        document.getElementById("middleLoader").style.display = "none";
        document.getElementById("viewerContainer").style.opacity = "1.0";
        document.getElementById("toolBar").style.opacity = "1.0";
    }

}

ModelCompare.prototype._initElements = function () {
    var _self = this;

    $("#viewer-modelcompare-dialog-container").draggable({
        handle: ".hoops-ui-window-header"
    });
    $("INPUT.color-picker").each(function () {
        $(this).minicolors({
            position: $(this).attr("data-position") || "bottom left",
            format: "rgb",
            control: "hue"
        })
    });

    $("#viewer-modelcompare-exportlist-button").on("click",
        function () {
            var outerhtml = _self.workbookElem.outerHTML;
			var isFirefox = typeof InstallTrigger !== 'undefined';
			// if(outerhtml.indexOf('<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:spreadsheet">') == -1) { https://jsfiddle.net/6spj1059/
			if(isFirefox) {
				outerhtml = outerhtml.replaceAll('<WorksheetOptions>', '<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">');
				outerhtml = outerhtml.replaceAll('<Workbook ', '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" ');
			}
			_self.download('<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?>' + outerhtml, "ModelCompare.xml", "text/xml");
        });
    $("#viewer-modelcompare-ok-button").on("click",
        function () {
            // c._applySettings();
            _self.resetCompare();
            document.getElementById("resetcompare").style.display = "none";
            $("#compare").show();
            $("#viewer-modelcompare-dialog").hide();
        });
    $("#viewer-modelcompare-cancel-button").on("click", function () {
        $("#viewer-modelcompare-dialog").hide()
        $("#Comparison-list").show();
    });
    $("#viewer-modelcompare-apply-button").on("click", function () {
        return __awaiter(c, void 0, void 0, function () {
            return __generator(this, function (a) {
                switch (a.label) {
                    case 0:
                        return [4, this._applySettings()];
                    case 1:
                        return a.sent(), [2]
                }
            })
        })
    });

    $('#viewerContainer-canvas-container').mouseup(function (event) {
        var pickConfig = new Communicator.PickConfig(Communicator.SelectionMask.All);
        //Get theb position on face/edge using pick from point API
        var position = new Communicator.Point2(event.clientX, event.clientY);
        _self.webviewer.view.pickFromPoint(position, pickConfig).then(function (selection) {

            if (selection.getSelectionType() === Communicator.SelectionType.None) {
                var childsadded = document.getElementById("addedlist").childNodes;
                var childsremoved = document.getElementById("removedlist").childNodes;
                var childsmodified = document.getElementById("modifiedlist").childNodes;
                var childsrevitObjectList = document.getElementById("revitObjectList").childNodes;

                var childs = [...childsadded, ...childsmodified, ...childsremoved, ...childsrevitObjectList];
                for (var i = 0; i < childs.length; i++) {
                    if (childs[i].style) childs[i].style.backgroundColor = "transparent";
                }
            }
            _self.selectionArray = [];
            // if (selection.getSelectionType() !== Communicator.SelectionType.None) {   }
        });
    });

    $(this.selectiontablabel).on("click", function () {
        // _self._switchTab1("select")
    });
    $(this.resulttablabel).on("click", function () {
        _self._switchTab1("result")
    });
    $(this.newaddedtablabel).on("click", function () {
        _self._switchTab2("newadd");
    });
    $(this.modifiedtablabel).on("click", function () {
        _self._switchTab2("modified");
    });
    $(this.Bmodifiedtablabel).on("click", function () {
        _self._switchTab2("bmodified");
    });
    $(this.Tmodifiedtablabel).on("click", function () {
        _self._switchTab2("tmodified");
    });
    $(this.removedtablabel).on("click", function () {
        _self._switchTab2("removetab");
    });
    $(this.unchangedtablabel).on("click", function () {
        _self._switchTab2("unchanged");

    });

    $(this.newaddedtabeye).on("click", function () {
        _self.isolateobject("newadd")
    });
    $(this.modifiedtabeye).on("click", function () {
        _self.isolateobject("modified")
    });
    $(this.removedtabeye).on("click", function () {
        _self.isolateobject("removetab");

    });

    $(this.basemodelinput).on("click", function () {
        $(_self.basemodelinput).addClass("active");
        $(_self.comparemodelinput).removeClass("active");
        $(_self.targetmodelinput).removeClass("active");
        if (_self.uniqueMultipleModelsNodes.length) {
            hwv.model.setNodesVisibility(_self.uniqueMultipleModelsNodes, true).then(function () {
                hwv.model.setNodesVisibility(_self.uniqueMultipleTargetModelsNodes, false);
                hwv.model.setNodesVisibility(_self.uniqueMultipleBaseModelsNodes, true);
                _self._enableAllTabs();

                _self.basetargetswitch("newadd");

                var bm = $(_self.Bmodifiedtablabel);
                var tm = $(_self.Tmodifiedtablabel);
                bm.addClass("selected");
                tm.removeClass("selected");

                tm.addClass("disablelabel").off('click');
                if (bm.hasClass("disablelabel")) {
                    bm.removeClass("disablelabel").on("click", function () {
                        _self._switchTab2("bmodified");
                    });
                }
                _self.enableBModified();
                _self.disableTModified();

                var modifiedlistcount = document.getElementById("modifiedlistcount");
                modifiedlistcount.innerHTML = _self.nodeIDsBUpdatedArray.length;
                //update total figure of modified object

            });
        }

    });

    $(this.comparemodelinput).on("click", function () {
        $(_self.basemodelinput).removeClass("active");
        $(_self.comparemodelinput).addClass("active");
        $(_self.targetmodelinput).removeClass("active");
        if (_self.uniqueMultipleModelsNodes.length) {
            hwv.model.setNodesVisibility(_self.uniqueMultipleBaseModelsNodes, true);
            hwv.model.setNodesVisibility(_self.uniqueMultipleTargetModelsNodes, true);
            _self._enableAllTabs();

            _self.basetargetswitch("compare");

            var bm = $(_self.Bmodifiedtablabel);
            var tm = $(_self.Tmodifiedtablabel);
            tm.addClass("selected");
            bm.removeClass("selected");

            // bm.addClass("disablelabel").off('click');
            if (bm.hasClass("disablelabel")) {
                bm.removeClass("disablelabel").on("click", function () {
                    _self._switchTab2("bmodified");
                });
            }
            if (tm.hasClass("disablelabel")) {
                tm.removeClass("disablelabel").on("click", function () {
                    _self._switchTab2("tmodified");
                });
            }
            _self.enableTModified();
            _self.disableBModified();

            var modifiedlistcount = document.getElementById("modifiedlistcount");
            modifiedlistcount.innerHTML = _self.nodeIDsTUpdatedArray.length;
            //update total figure of modified object
        }
    });

    $(this.targetmodelinput).on("click", function () {
        $(_self.basemodelinput).removeClass("active");
        $(_self.comparemodelinput).removeClass("active");
        $(_self.targetmodelinput).addClass("active");
        if (_self.uniqueMultipleModelsNodes.length) {
            hwv.model.setNodesVisibility(_self.uniqueMultipleModelsNodes, true).then(function () {

                hwv.model.setNodesVisibility(_self.uniqueMultipleBaseModelsNodes, false);
                hwv.model.setNodesVisibility(_self.uniqueMultipleTargetModelsNodes, true);
                _self._enableAllTabs();
                _self.basetargetswitch("removetab");

                var bm = $(_self.Bmodifiedtablabel);
                var tm = $(_self.Tmodifiedtablabel);
                tm.addClass("selected");
                bm.removeClass("selected");

                bm.addClass("disablelabel").off('click');
                if (tm.hasClass("disablelabel")) {
                    tm.removeClass("disablelabel").on("click", function () {
                        _self._switchTab2("tmodified");
                    });
                }
                _self.enableTModified();
                _self.disableBModified();

                var modifiedlistcount = document.getElementById("modifiedlistcount");
                modifiedlistcount.innerHTML = _self.nodeIDsTUpdatedArray.length;
            });
        }
    });

    $(this.ComparisonListButton).on("click", function () {
        _self.showpopup();
        $(_self.ComparisonListButton).hide();
    });
}

ModelCompare.prototype._switchTab1 = function (a) {
    var c = $(this.selectiontablabel),
        d = $(this.resulttablabel),
        s = $(this.selectiontab),
        r = $(this.resulttab);

    c.removeClass("selected");
    d.removeClass("selected");
    s.removeClass("selected");
    r.removeClass("selected");
    switch (a) {
        case "select":
            c.addClass("selected");
            s.addClass("selected");
            // d.addClass("selected");
            break;
        case "result":
            d.addClass("selected");
            r.addClass("selected");
            break;

    }
};

ModelCompare.prototype.isolateobject = function (handle) {
    switch (handle) {
        case "newadd":
            hwv.view.isolateNodes(this.nodeIDsCreatedArray, null, true);
            break;
        case "modified":
            hwv.view.isolateNodes(this.nodeIDsUpdatedArrayFromList, null, true);
            break;
        case "removetab":
            hwv.view.isolateNodes(this.nodeIDsDeletedArray, null, true);
            break;
    }
}

ModelCompare.prototype._switchTab2 = function (handle) {

    var a = $(this.newaddedtablabel),
        m = $(this.modifiedtablabel),
        bm = $(this.Bmodifiedtablabel),
        tm = $(this.Tmodifiedtablabel),
        r = $(this.removedtablabel),
        u = $(this.unchangedtablabel),
        at = $(this.newaddedtab),
        mt = $(this.modifiedtab),
        rt = $(this.removedtab),
        _self = this;


    switch (handle) {
        case "newadd":
            if (a.hasClass("selected")) {

                a.removeClass("selected");
                at.removeClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsCreatedArray, false);
            } else {
                a.addClass("selected");
                at.addClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsCreatedArray, true);
            }
            break;
        case "modified":
            if (m.hasClass("selected")) {
                m.removeClass("selected");
                // mt.removeClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsUpdatedArray, false);
                if (bm.hasClass("selected") && !bm.hasClass("disablelabel")) {
                    this.disableBModified();
                }
                if (tm.hasClass("selected") && !tm.hasClass("disablelabel")) {
                    this.disableTModified();
                }

                tm.addClass("disablelabel").off('click');
                bm.addClass("disablelabel").off('click');
            } else {
                m.addClass("selected");
                // mt.addClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsUpdatedArray, false);
                if (bm.hasClass("selected")) {
                    this.enableBModified();
                }
                if (tm.hasClass("selected")) {
                    this.enableTModified();
                }


                if (bm.hasClass("disablelabel")) {
                    bm.removeClass("disablelabel").on("click", function () {
                        _self._switchTab2("bmodified");
                    });
                }

                if (tm.hasClass("disablelabel")) {
                    tm.removeClass("disablelabel").on("click", function () {
                        _self._switchTab2("tmodified");
                    });
                }
                if ($(_self.basemodelinput).hasClass("active")) {
                    this.disableTModified();
                    tm.addClass("disablelabel").off('click');
                }

                if ($(_self.targetmodelinput).hasClass("active")) {
                    this.disableBModified();
                    bm.addClass("disablelabel").off('click');
                }

            }
            break;
        case "removetab":
            if (r.hasClass("selected")) {
                r.removeClass("selected");
                rt.removeClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsDeletedArray, false);
            } else {
                r.addClass("selected");
                rt.addClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsDeletedArray, true);
            }
            break;
        case "unchanged":
            if (u.hasClass("selected")) {
                u.removeClass("selected");
                hwv.model.setNodesVisibility(this.unchangedobjectsleafnodes, false);

            } else {
                u.addClass("selected");
                hwv.model.setNodesVisibility(this.unchangedobjectsleafnodes, true);

            }
            break;
        case "bmodified":
            if (bm.hasClass("selected")) {
                bm.removeClass("selected");
                this.disableBModified();
            } else {
                bm.addClass("selected");
                this.enableBModified();
            }
            break;
        case "tmodified":
            if (tm.hasClass("selected")) {
                tm.removeClass("selected");
                this.disableTModified();
            } else {
                tm.addClass("selected");
                this.enableTModified();
            }
            break;
    }
};

ModelCompare.prototype.basetargetswitch = function (handle) {

    var a = $(this.newaddedtablabel),
        m = $(this.modifiedtablabel),
        r = $(this.removedtablabel),
        u = $(this.unchangedtablabel),
        at = $(this.newaddedtab),
        mt = $(this.modifiedtab),
        rt = $(this.removedtab);


    a.addClass("disablelabel").off('click');
    r.addClass("disablelabel").off('click');

    var _self = this;

    switch (handle) {
        case "newadd":
            if (a.hasClass("selected")) {

                a.removeClass("selected");
                at.removeClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsCreatedArray, false);
                // a.addClass("disablelabel").off('click');
                r.removeClass("disablelabel").on('click', function () {
                    _self._switchTab2("removetab");
                });
            }
            break;
        case "removetab":
            if (r.hasClass("selected")) {
                r.removeClass("selected");
                rt.removeClass("selected");
                hwv.model.setNodesVisibility(this.nodeIDsDeletedArray, false);

                a.removeClass("disablelabel").on('click', function () {
                    _self._switchTab2("newadd");
                });
                // r.addClass("disablelabel").off('click');
            }
            break;
        case "compare":
            r.removeClass("disablelabel").on('click', function () {
                _self._switchTab2("removetab");
            });

            a.removeClass("disablelabel").on('click', function () {
                _self._switchTab2("newadd");
            });
            break;
    }
};

ModelCompare.prototype._enableAllTabs = function (handle) {

    var a = $(this.newaddedtablabel),
        m = $(this.modifiedtablabel),
        r = $(this.removedtablabel),
        u = $(this.unchangedtablabel),
        at = $(this.newaddedtab),
        mt = $(this.modifiedtab),
        rt = $(this.removedtab);
    // bm = $(this.Bmodifiedtablabel),
    // tm = $(this.Tmodifiedtablabel);

    if (!u.hasClass("selected")) {
        u.addClass("selected");
    }

    if (!a.hasClass("selected")) {
        a.addClass("selected");
        at.addClass("selected");
    }

    if (!m.hasClass("selected")) {
        m.addClass("selected");
        mt.addClass("selected");
    }
    if (!r.hasClass("selected")) {
        r.addClass("selected");
        rt.addClass("selected");
    }

    // if(!bm.hasClass("selected"))
    // {
    //     bm.addClass("selected");
    // }

    // if(!tm.hasClass("selected"))
    // {
    //     tm.addClass("selected");
    // }
};

ModelCompare.prototype.setNodesVisibilitybyArray = async function (nodeIDsCreatedArray, visibilityBool) {
    for (var i in nodeIDsCreatedArray) {
        hwv.model.setNodesVisibility([Number(nodeIDsCreatedArray[i])], visibilityBool);
    }
}

ModelCompare.prototype.showpopup = function () {
    var a = $(this._viewerModelCompareSelector),
        c = a.width(),
        b = a.height();
    if (void 0 !== c && void 0 !== b) {
        var d = this.webviewer.view.getCanvasSize();
        a.css({
            left: (d.x -
                c) / 2 + "px",
            top: (d.y - b) / 2 + "px"
        })
    }
    $(this._viewerModelCompareSelector).show();
    a.draggable({
        handle: ".hoops-ui-window-header"
    });

}

ModelCompare.prototype.populateAddedinresultUI = function (addednodes, allnodesPropertiesMap) {
    var addednodesCount = 0;
    var _self = this;
    for (var i in addednodes) {
        var grandparentnodeid = addednodes[i];
        var grandparentname = hwv.model.getNodeName(grandparentnodeid);
        var genericid = null;
        if (this.filetype == 2) {
            // var properties = await hwv.model.getNodeProperties(Number(grandparentnodeid));
            // genericid = properties["persistentId"];

            genericid = this.allnodespidsMap[Number(grandparentnodeid)];

            var childs = hwv.model.getNodeChildren(Number(grandparentnodeid));
            if (childs.length > 0) {
                var childs1 = hwv.model.getNodeChildren(childs[0]);
                if (childs1.length > 0) {
                    var grandchild = childs1[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = grandparentname + "_" + cog;
                } else {
                    var grandchild = childs[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = grandparentname + "_" + cog;
                }
            } else {
                var grandchild = Number(grandparentnodeid);
                var cog = this.allnodescogMap[grandchild];
                genericid = grandparentname + "_" + cog;
            }
        } else {
            genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
        }

        var addedlist = document.getElementById("addedlist");
        var newdiv = document.createElement("div");
        newdiv.className = "noderow";
        newdiv.id = grandparentnodeid;
        var docref = hwv.model.getModelFileNameFromNode(grandparentnodeid);
        var seconddiv = document.createElement("div");
        seconddiv.className = "boxsquare green";
        // seconddiv.className ="red";
        var label = document.createElement("label");
        var properties = allnodesPropertiesMap[Number(grandparentnodeid)];
        // var properties = await hwv.model.getNodeProperties(grandparentnodeid);
        var nodeType = properties.TYPE;
        if (nodeType) {
            var strLength = nodeType.length;
            var spaceStr = nodeType.substring(strLength-1, strLength);
            nodeType = (spaceStr == " ") ? nodeType.substring(0, strLength-1) : nodeType;
        }

        if (nodeType == "IFCSPACE" || nodeType == "SPACE") {
            this.remove(this.nodeIDsCreatedArray, grandparentnodeid);
            continue;
        }
        if (nodeType == "IFCBUILDINGSTOREY" || nodeType == "BUILDINGSTOREY") {
            this.remove(this.nodeIDsCreatedArray, grandparentnodeid);
            continue;
        }

        var dataExport = [];
        if (nodeType) {
            if (properties.TYPE.substring(0, 3) == "IFC") {
                nodeType = properties.TYPE.slice(3);
            }
            var objectName = properties[properties.TYPE + "/Name"];
            var objectType = properties[properties.TYPE + "/ObjectType"];
            label.innerHTML = nodeType + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
            // dataExport = [grandparentnodeid, nodeType, objectName, grandparentname, genericid, docref];
            if(objectType)
                dataExport = [ nodeType, objectName, objectType, genericid, docref];
            else
                dataExport = [ nodeType, objectName, grandparentname, genericid, docref];
        } else {
            if (this.filetype == 2) {
                var nodetypeid = hwv.model.getNodeParent(grandparentnodeid);
                var nodetypename = hwv.model.getNodeName(nodetypeid);
                label.innerHTML = nodetypename + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [grandparentnodeid, nodetypename, grandparentname, nodetypename, genericid, docref];
                dataExport = [ nodetypename, grandparentname, nodetypename, genericid, docref];

            } else {
                label.innerHTML = grandparentname + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [grandparentnodeid, grandparentname, grandparentname, grandparentname, genericid, docref];
                dataExport = [ grandparentname, grandparentname, grandparentname, genericid, docref];
            }
        }
        label.className = "ellipsis";

        newdiv.appendChild(seconddiv);
        newdiv.appendChild(label);

        // export logic

        var cell = [],
            data = [];
        var Rowremoved = this.doc1.createElement("Row");

        for (var j = 0; j < dataExport.length; j++) {
            cell[j] = this.doc1.createElement("Cell");
            data[j] = this.doc1.createElement("Data");
            data[j].setAttribute("ss:Type", "String");
            data[j].innerHTML = String(dataExport[j]).replace(/&/g, "");
            cell[j].appendChild(data[j]);
            Rowremoved.appendChild(cell[j]);
        }
        this.tableElem[1].appendChild(Rowremoved);
        ////
        newdiv.onclick = function () {
            // hwv.selectionManager.clear();
            var childs = document.getElementById("addedlist").childNodes;
            // for (var i=0; i < childs.length; i++) {
            //     if(childs[i].style) childs[i].style.backgroundColor = "transparent";
            // };
            if (event.currentTarget.style.backgroundColor !== "lightskyblue") {
                event.currentTarget.style.backgroundColor = "lightskyblue";
                _self.selectionArray.push(Number(event.currentTarget.id));
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            } else {
                event.currentTarget.style.backgroundColor = "transparent";
                _self.remove(_self.selectionArray, Number(event.currentTarget.id))
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            }
        };

        newdiv.onmouseover = function (event) {
            if (event.currentTarget.style.backgroundColor == "transparent" ||
                event.currentTarget.style.backgroundColor == "")
                event.currentTarget.style.backgroundColor = "lightgray";
        };
        newdiv.onmouseout = function (event) {
            if (event.currentTarget.style.backgroundColor == "lightgray")
                event.currentTarget.style.backgroundColor = "transparent";
        };

        addedlist.appendChild(newdiv);
        addednodesCount = addednodesCount + 1;
    }
    return addednodesCount;

}

ModelCompare.prototype.createXMLBase = function () {
    this.doc1 = document.implementation.createDocument("", "", null);
    var pi = this.doc1.createProcessingInstruction('xml', 'version="1.0"');
    var pi2 = this.doc1.createProcessingInstruction('mso-application', 'progid="Excel.sheet"');
    this.doc1.insertBefore(pi, this.doc1.firstChild);
    this.doc1.insertBefore(pi2, this.doc1.firstChild);

    this.workbookElem = this.doc1.createElement("Workbook");
    this.workbookElem.setAttribute("xmlns", "urn:schemas-microsoft-com:office:spreadsheet");
    this.workbookElem.setAttribute("xmlns:o", "urn:schemas-microsoft-com:office:office");
    this.workbookElem.setAttribute("xmlns:x", "urn:schemas-microsoft-com:office:excel");
    this.workbookElem.setAttribute("xmlns:ss", "urn:schemas-microsoft-com:office:spreadsheet");
    this.workbookElem.setAttribute("xmlns:html", "http://www.w3.org/TR/REC-html40");


    //Create Style element
    var Styles =  this.doc1.createElement("Styles");
    var style = [];
    style[0] = this.doc1.createElement("Style");
    style[0].setAttribute("ss:ID", "s25");

    //Borders
    var Borders = [];
    Borders[0] = this.doc1.createElement("Borders");
    var border = []; 
    var borderPosition = ['Bottom', 'Left', 'Right', 'Top'];
    for (var k = 0; k < borderPosition.length; k++) {
        border[k] = this.doc1.createElement("Border");
        border[k].setAttribute("ss:Position", borderPosition[k]);
        border[k].setAttribute("ss:LineStyle", "Continuous");
        border[k].setAttribute("ss:Weight", "1");
        Borders[0].appendChild(border[k]);
    }
    style[0].appendChild(Borders[0]);

    //Font
    var Font = this.doc1.createElement("Font");
    Font.setAttribute("x:Family", "Swiss");
    Font.setAttribute("ss:Color", "#FFFFFF");
    Font.setAttribute("ss:Size", "11");
    Font.setAttribute("ss:Bold", "1");
    style[0].appendChild(Font);

    //Alignment
    var Alignment1 = this.doc1.createElement("Alignment");
    Alignment1.setAttribute("ss:Vertical", "Center");
    style[0].appendChild(Alignment1);

    //Interior
    var Interior = this.doc1.createElement("Interior");
    Interior.setAttribute("ss:Color", "#0066CC");
    Interior.setAttribute("ss:Pattern", "Solid");
    style[0].appendChild(Interior);
    Styles.appendChild(style[0]);


    //Second Style
    style[1] = this.doc1.createElement("Style");
    style[1].setAttribute("ss:ID", "s26");

    Borders[1] = this.doc1.createElement("Borders");
    var border1 = []; 
    for (var k = 0; k < borderPosition.length; k++) {
        border1[k] = this.doc1.createElement("Border");
        border1[k].setAttribute("ss:Position", borderPosition[k]);
        border1[k].setAttribute("ss:LineStyle", "Continuous");
        border1[k].setAttribute("ss:Weight", "1");
        Borders[1].appendChild(border1[k]);
    }
    style[1].appendChild(Borders[1]);
    Styles.appendChild(style[1]);

    style[2] = this.doc1.createElement("Style");
    style[2].setAttribute("ss:ID", "s27");
    var Font2 = this.doc1.createElement("Font");
    Font2.setAttribute("x:Family", "Swiss");
    Font2.setAttribute("ss:Size", "14");
    Font2.setAttribute("ss:Bold", "1");
    style[2].appendChild(Font2);
    
    var Alignment2 = this.doc1.createElement("Alignment");
    Alignment2.setAttribute("ss:Vertical", "Center");
    style[2].appendChild(Alignment2);
    Styles.appendChild(style[2]);

    style[3] = this.doc1.createElement("Style");
    style[3].setAttribute("ss:ID", "s28");
    var Font3 = this.doc1.createElement("Font");
    Font3.setAttribute("x:Family", "Swiss");
    // Font3.setAttribute("ss:Size", "14");
    Font3.setAttribute("ss:Bold", "1");
    style[3].appendChild(Font3);
    Styles.appendChild(style[3]);


    this.workbookElem.appendChild(Styles);
    

    this.worksheetElem[0] = this.doc1.createElement("Worksheet");
    this.worksheetElem[0].setAttribute("ss:Name", "Instructions");

    
    this.tableElem[0] = this.doc1.createElement("Table");
    this.tableElem[0].setAttribute("ss:ExpandedColumnCount", "2");
    this.tableElem[0].setAttribute("ss:ExpandedRowCount", "7");
    this.tableElem[0].setAttribute("ss:FullColumns", "1");
    this.tableElem[0].setAttribute("ss:FullRows", "1");

    var Row = [],
        Column = [],
        cell = [],
        data = [],
        RowInstructionData = ['Model Comparison Result','Client Organization', 'Project Name', 'Model Name','Report Generated by' ,'Report Generated On'];

    for (var k = 0; k < 2; k++) {
        Column[k] = this.doc1.createElement("Column");
        Column[k].setAttribute("ss:AutoFitWidth", "0");
        Column[k].setAttribute("ss:Width", "300");
        this.tableElem[0].appendChild(Column[k]);
    }

    
    for (var m = 0; m < RowInstructionData.length; m++) {
        
        Row[m] = this.doc1.createElement("Row");
        
        Row[m].setAttribute("ss:Height", "50");
        for (var j = 0; j < 2; j++) {
            cell[j] = this.doc1.createElement("Cell");
            data[j] = this.doc1.createElement("Data");
            data[j].setAttribute("ss:Type", "String");
            if(m == 0)
            {
                cell[j].setAttribute("ss:StyleID", "s27");
                if(j == 0)
                data[j].innerHTML = RowInstructionData[m];
            }
            else if(j == 0)
            {
                cell[j].setAttribute("ss:StyleID", "s25");
                data[j].innerHTML = RowInstructionData[m];
            }
            else if(j == 1)
            {
                cell[j].setAttribute("ss:StyleID", "s26");
            }
            cell[j].appendChild(data[j]);
            Row[m].appendChild(cell[j]);
        }
        this.tableElem[0].appendChild(Row[m]);
    }


    this.worksheetElem[0].appendChild(this.tableElem[0]);
    
    this.workbookElem.appendChild(this.worksheetElem[0]);

    this.worksheetElem[1] = this.doc1.createElement("Worksheet");
    this.worksheetElem[1].setAttribute("ss:Name", "New Added");
    this.worksheetElem[2] = this.doc1.createElement("Worksheet");
    this.worksheetElem[2].setAttribute("ss:Name", "Removed");
    // this.worksheetElem[2] = this.doc1.createElement("Worksheet");
    // this.worksheetElem[2].setAttribute("ss:Name", "Modified");
    
    this.worksheetElem[3] = this.doc1.createElement("Worksheet");
    this.worksheetElem[3].setAttribute("ss:Name", "Modified(Base)");
    
    this.worksheetElem[4] = this.doc1.createElement("Worksheet");
    this.worksheetElem[4].setAttribute("ss:Name", "Modified (Target)");

    Row = [],
    Column = [];
    var TabColorCodes = [41, 17, 10, 52, 52]
    for (var i = 1; i < this.worksheetElem.length; i++) {
        this.tableElem[i] = this.doc1.createElement("Table");

        //addColumSize
        // <Column ss:AutoFitWidth="0" ss:Width="110.25"/>
        //    <Column ss:AutoFitWidth="0" ss:Width="181.5"/>
        //    <Column ss:AutoFitWidth="0" ss:Width="212.25"/>
        //    <Column ss:AutoFitWidth="0" ss:Width="152.25"/>
        //    <Column ss:AutoFitWidth="0" ss:Width="153.75"/>

        for (var j = 0; j < 5; j++) {
            Column[j] = this.doc1.createElement("Column");
            Column[j].setAttribute("ss:AutoFitWidth", "0");
            Column[j].setAttribute("ss:Width", "230");
            this.tableElem[i].appendChild(Column[j]);
        }


        var cell = [],
            data = [];
            // var columnHeaderData = ['nodeID', 'Object Class', 'Name','Type' ,'GUID' , 'File'];
            var columnHeaderData = [ 'Object Class', 'Name','Type' ,'GUID' , 'File'];
        
        // if (this.filetype == 2) {
        //     columnHeaderData = ['nodeID', 'Object Class', 'Name', 'GUID' , 'File'];
        // }
        Row[i] = this.doc1.createElement("Row");

        for (var j = 0; j < columnHeaderData.length; j++) {
            cell[j] = this.doc1.createElement("Cell");
            data[j] = this.doc1.createElement("Data");
            cell[j].setAttribute("ss:StyleID", "s28");
            data[j].setAttribute("ss:Type", "String");
            data[j].innerHTML = columnHeaderData[j];
            cell[j].appendChild(data[j]);
            Row[i].appendChild(cell[j]);
        }
        this.tableElem[i].appendChild(Row[i]);

        this.worksheetElem[i].appendChild(this.tableElem[i]);

        var worksheetoptions = this.doc1.createElement("WorksheetOptions");
        worksheetoptions.setAttribute("xmlns","urn:schemas-microsoft-com:office:excel");
        var tabColor = this.doc1.createElement("TabColorIndex");
        tabColor.innerHTML = TabColorCodes[i];
        worksheetoptions.appendChild(tabColor);
        this.worksheetElem[i].appendChild(worksheetoptions);

        this.workbookElem.appendChild(this.worksheetElem[i]);

    }
    // this.worksheetElem[i].appendChild(this.tableElem[i]);


}

ModelCompare.prototype.populateAddedinresult = async function (nodeIDsCreatedArray) {
    var addednodes = [];
    this.addednodesCount = 0;
    for (var i in nodeIDsCreatedArray) {
        var grandparentnodeid = Number(nodeIDsCreatedArray[i]); // for global ids
        var grandparentname = hwv.model.getNodeName(grandparentnodeid);
        // remove(this.unchangedobjectsleafnodes, grandparentnodeid);
        // removeAllLeafNodesFromParent(grandparentnodeid);
        if (!grandparentname || grandparentname == null)
            continue;


        if (hwv.model.getNodeName(Number(nodeIDsCreatedArray[i])).indexOf("body") >= 0) //for leaf nodes
        {
            grandparentnodeid = hwv.model.getNodeParent(Number(nodeIDsCreatedArray[i]));
            grandparentname = hwv.model.getNodeName(grandparentnodeid);
        }
        if (hwv.model.getNodeName(grandparentnodeid).includes("Product")) {
            grandparentnodeid = hwv.model.getNodeParent(grandparentnodeid);
            grandparentname = hwv.model.getNodeName(grandparentnodeid);
        }


        var genericid = null;
        if (this.filetype == 2) {

            genericid = this.allnodespidsMap[Number(grandparentnodeid)];
        } else {
            genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
        }

        if (genericid === null) {
            continue;
        }

        if (addednodes.indexOf(grandparentnodeid) >= 0) {
            continue;
        } else {
            addednodes.push(grandparentnodeid);
        }


        this.globalIDsCreatedArray.push(genericid);
    }

    //console.log("Populate added async call start : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    var propertiesPromiseArray = [],
        promiseArrayBB = [];
    for (var i in addednodes) {
        propertiesPromiseArray[i] = hwv.model.getNodeProperties(addednodes[i]);
        promiseArrayBB[i] = hwv.model.getNodesBounding([addednodes[i]]).catch(error => {
            return error
        });
    }
    var promiseResolveArray = await Promise.all(propertiesPromiseArray.map(p => p.catch(e => e)));
    var promiseResolveArrayBB = await Promise.all(promiseArrayBB.map(p => p.catch(e => e)));

    var allnodesLocalPropertiesMap = {};
    for (var x in addednodes) {
        if (promiseResolveArray[x] && promiseResolveArrayBB[x] !== undefined) {
            var nodename = hwv.model.getNodeName(addednodes[x]);
            var bob = this.bbStringForm(promiseResolveArrayBB[x].max, promiseResolveArrayBB[x].min);
            allnodesLocalPropertiesMap[addednodes[x]] = promiseResolveArray[x];
            this.allnodespidsMap[addednodes[x]] = nodename + "_" + bob;
        }
    };

//    console.log("Populate added async call middle : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    this.addednodesCount = this.populateAddedinresultUI(addednodes, allnodesLocalPropertiesMap);

//    console.log("Populate added async call end : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    for (var i in nodeIDsCreatedArray) {
        var addednodeid = Number(nodeIDsCreatedArray[i]);
        this.remove(this.unchangedobjectsleafnodes, addednodeid);
        this.removeAllLeafNodesFromParent(addednodeid);
    }

    var addedlistcount = document.getElementById("addedlistcount");
    addedlistcount.innerHTML = this.addednodesCount;
    this.addedListReady = true;
    if (this.addedListReady && this.updatedListReady && this.DeletedListReady) {
        document.getElementById("middleLoader").style.display = "none";
        document.getElementById("viewerContainer").style.opacity = "1.0";
        document.getElementById("toolBar").style.opacity = "1.0";
        this.showpopup();
        $(this.ComparisonListButton).hide();
        document.getElementById("compare-tab-added").scroll({
            top: 0,
            behavior: 'smooth',
        })
    }

}


ModelCompare.prototype.populateUpdatedinresultUI = function (updatednodes, allnodesPropertiesMap ) {
    var updatednodesCount = 0;
    var _self = this;
    for (var i in updatednodes) {
        var finalnodeid = updatednodes[i];
        var finalnodename = hwv.model.getNodeName(finalnodeid);
        var genericid = null;
        if (this.filetype == 2) {
            // var properties = await hwv.model.getNodeProperties(Number(grandparentnodeid));
            // genericid = properties["persistentId"];

            genericid = this.allnodespidsMap[Number(finalnodeid)];


            var childs = hwv.model.getNodeChildren(Number(finalnodeid));
            if (childs.length > 0) {
                var childs1 = hwv.model.getNodeChildren(childs[0]);
                if (childs1.length > 0) {
                    var grandchild = childs1[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = finalnodename + "_" + cog;
                } else {
                    var grandchild = childs[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = finalnodename + "_" + cog;
                }
            } else {
                var grandchild = Number(finalnodeid);
                var cog = this.allnodescogMap[grandchild];
                genericid = finalnodename + "_" + cog;
            }
        } else {
            genericid = hwv.model.getNodeGenericId(Number(finalnodeid));
        }

        var addedlist = document.getElementById("modifiedlist");
        var newdiv = document.createElement("div");
        newdiv.className = "noderow";
        newdiv.id = finalnodeid;
        var docref = hwv.model.getModelFileNameFromNode(finalnodeid);
        var seconddiv = document.createElement("div");
        seconddiv.className = "boxsquare amber";
        // seconddiv.className ="red";
        var label = document.createElement("label");
        var properties = allnodesPropertiesMap[Number(finalnodeid)]
        // var properties = await hwv.model.getNodeProperties(finalnodeid);
        var nodeType = properties.TYPE;
        if (nodeType) {
            var strLength = nodeType.length;
            var spaceStr = nodeType.substring(strLength-1, strLength);
            nodeType = (spaceStr == " ") ? nodeType.substring(0, strLength-1) : nodeType;
        }

        if (nodeType == "IFCSPACE" || nodeType == "SPACE") {
            // remove(this.nodeIDsUpdatedArray, finalnodeid);
            continue;
        }
        if (nodeType == "IFCBUILDINGSTOREY" || nodeType == "BUILDINGSTOREY") {

            // remove(this.nodeIDsUpdatedArray, finalnodeid);
            continue;
        }

        var dataExport = [];
        if (nodeType) {
            if (properties.TYPE.substring(0, 3) == "IFC") {
                nodeType = properties.TYPE.slice(3);
            }
            var objectName = properties[properties.TYPE + "/Name"];
            var objectType = properties[properties.TYPE + "/ObjectType"];
            label.innerHTML = nodeType + " (Name: " + finalnodename + ", ID: " + genericid + ", " + "docref: " + docref + " )";
            // dataExport = [grandparentnodeid, nodeType, objectName, grandparentname, genericid, docref];
            if(objectType)
                dataExport = [ nodeType, objectName, objectType, genericid, docref];
            else
                dataExport = [ nodeType, objectName, finalnodename, genericid, docref];
                
            // dataExport = [finalnodeid, nodeType, objectName, finalnodename, genericid, docref];
        } else {
            if (this.filetype == 2) {
                var nodetypeid = hwv.model.getNodeParent(finalnodeid);
                var nodetypename = hwv.model.getNodeName(nodetypeid);
                label.innerHTML = nodetypename + " (Name: " + finalnodename + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [finalnodeid, nodetypename, finalnodename, nodetypename, genericid, docref];
                dataExport = [ nodetypename, finalnodename, nodetypename, genericid, docref];

            } else {
                label.innerHTML = finalnodename + " (Name: " + finalnodename + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [finalnodeid, finalnodename, finalnodename, finalnodename, genericid, docref];
                dataExport = [ finalnodename, finalnodename, finalnodename, genericid, docref];
            }
        }
        label.className = "ellipsis";

        newdiv.appendChild(seconddiv);
        newdiv.appendChild(label);

        // export logic

        var cell = [],
            data = [];
        var Rowupdated = this.doc1.createElement("Row");

        for (var j = 0; j < dataExport.length; j++) {
            cell[j] = this.doc1.createElement("Cell");
            data[j] = this.doc1.createElement("Data");
            data[j].setAttribute("ss:Type", "String");
            data[j].innerHTML = String(dataExport[j]).replace(/&/g, "");
            cell[j].appendChild(data[j]);
            Rowupdated.appendChild(cell[j]);
        }
        // this.tableElem[2].appendChild(Rowupdated);
        ////


        if (this.AllBaseNodeIds.includes(finalnodeid)) {
            this.nodeIDsBUpdatedArray.push(finalnodeid);
            this.tableElem[3].appendChild(Rowupdated);
        } else {
            this.nodeIDsTUpdatedArray.push(finalnodeid);
            this.tableElem[4].appendChild(Rowupdated);
        }

        newdiv.onclick = function () {
            // hwv.selectionManager.clear();
            var childs = document.getElementById("modifiedlist").childNodes;
            // for (var i=0; i < childs.length; i++) {
            //     if(childs[i].style) childs[i].style.backgroundColor = "transparent";
            // };

            if (event.currentTarget.style.backgroundColor !== "lightskyblue") {
                event.currentTarget.style.backgroundColor = "lightskyblue";
                _self.selectionArray.push(Number(event.currentTarget.id));
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            } else {
                event.currentTarget.style.backgroundColor = "transparent";
                _self.remove(_self.selectionArray, Number(event.currentTarget.id))
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            }
        };

        newdiv.onmouseover = function (event) {
            if (event.currentTarget.style.backgroundColor == "transparent" ||
                event.currentTarget.style.backgroundColor == "")
                event.currentTarget.style.backgroundColor = "lightgray";
        };
        newdiv.onmouseout = function (event) {
            if (event.currentTarget.style.backgroundColor == "lightgray")
                event.currentTarget.style.backgroundColor = "transparent";
        };

        addedlist.appendChild(newdiv);
        updatednodesCount = updatednodesCount + 1;
    }
    return updatednodesCount;
}


ModelCompare.prototype.populateUpdatedinresult = async function (nodeIDsUpdatedArray, allnodesPropertiesMap) {
    var updatednodes = [];
    this.updatednodesCount = 0;
    for (var i in nodeIDsUpdatedArray) {

        var grandparentnodeid = Number(nodeIDsUpdatedArray[i]); // for global ids
        var grandparentname = hwv.model.getNodeName(grandparentnodeid);
        this.remove(this.unchangedobjectsleafnodes, grandparentnodeid);
        this.removeAllLeafNodesFromParent(grandparentnodeid);
        if (!grandparentname || grandparentname == null)
            continue;

        var genericid = null;
        var finalnodename = null;
        var finalnodeid = null;


        if (hwv.model.getNodeName(Number(nodeIDsUpdatedArray[i])).indexOf("body") >= 0) //for leaf nodes
        {
            var parentnode = hwv.model.getNodeParent(Number(nodeIDsUpdatedArray[i]));
            var parentname = hwv.model.getNodeName(parentnode);

            var parentgenericid = null;
            if (this.filetype == 2) {
                parentgenericid = this.allnodespidsMap[Number(parentnode)];
            } else {
                parentgenericid = hwv.model.getNodeGenericId(Number(parentnode));
            }

            // var parentgenericid = hwv.model.getNodeGenericId(Number(parentnode));
            if (parentgenericid === null) {
                grandparentnodeid = hwv.model.getNodeParent(parentnode);
                grandparentname = hwv.model.getNodeName(grandparentnodeid);
                var genericid = null;
                if (this.filetype == 2) {
                    // var properties = await hwv.model.getNodeProperties(Number(grandparentnodeid));
                    // genericid = properties["persistentId"];
                    genericid = this.allnodespidsMap[Number(grandparentnodeid)];
                } else {
                    genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
                }
                // genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));                
                finalnodeid = Number(grandparentnodeid);
                finalnodename = grandparentname;
            } else {
                genericid = parentgenericid;
                finalnodeid = Number(parentnode);
                finalnodename = parentname;
            }

        } else {
            // grandparentnodeid = hwv.model.getNodeParent(parentnode);
            // grandparentname  = hwv.model.getNodeName(grandparentnodeid);
            var genericid = null;
            if (this.filetype == 2) {
                // var properties = await hwv.model.getNodeProperties(Number(grandparentnodeid));
                // genericid = properties["persistentId"];

                genericid = this.allnodespidsMap[Number(grandparentnodeid)];
            } else {
                genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
            }
            // genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));                
            finalnodeid = Number(grandparentnodeid);
            finalnodename = grandparentname;
        }



        if (this.filetype != 2) {
            if (genericid === null) {
                continue;
            }

            if (this.globalIDsDeletedArray.includes(genericid) || this.globalIDsCreatedArray.includes(genericid))
                continue;
        }

        if (updatednodes.indexOf(finalnodeid) >= 0) {
            continue;
        } else {
            updatednodes.push(finalnodeid);
        }

        this.nodeIDsUpdatedArrayFromList.push(finalnodeid);
    }

    var propertiesPromiseArray = [],
        promiseArrayBB = [];
    for (var i in updatednodes) {
        propertiesPromiseArray[i] = hwv.model.getNodeProperties(updatednodes[i]);
        promiseArrayBB[i] = hwv.model.getNodesBounding([updatednodes[i]]).catch(error => {
            return error
        });
    }
    var promiseResolveArray = await Promise.all(propertiesPromiseArray.map(p => p.catch(e => e)));
    var promiseResolveArrayBB = await Promise.all(promiseArrayBB.map(p => p.catch(e => e)));
    var allnodesLocalPropertiesMap = {};
    for (var x in updatednodes) {
        if (promiseResolveArray[x] && promiseResolveArrayBB[x] !== undefined) {
            var nodename = hwv.model.getNodeName(updatednodes[x]);
            var bob = this.bbStringForm(promiseResolveArrayBB[x].max, promiseResolveArrayBB[x].min);
            allnodesLocalPropertiesMap[updatednodes[x]] = promiseResolveArray[x];
            this.allnodespidsMap[updatednodes[x]] = nodename + "_" + bob;
        }
    };

    this.updatednodesCount = this.populateUpdatedinresultUI(updatednodes, allnodesLocalPropertiesMap);

    // for(var i in this.nodeIDsUpdatedArray){
    //     var updatednodeid = Number(this.nodeIDsUpdatedArray[i]); 
    //     remove(this.unchangedobjectsleafnodes, updatednodeid);
    //     removeAllLeafNodesFromParent(updatednodeid);
    // }

    var modifiedlistcount = document.getElementById("modifiedlistcount");
    modifiedlistcount.innerHTML = this.updatednodesCount;


    var bm = $(this.Bmodifiedtablabel);
    var tm = $(this.Tmodifiedtablabel);
    bm.removeClass("selected");
    tm.addClass("selected");

    this.disableBModified();

    this.updatedListReady = true;
    if (this.addedListReady && this.updatedListReady && this.DeletedListReady) {
        document.getElementById("middleLoader").style.display = "none";
        document.getElementById("viewerContainer").style.opacity = "1.0";
        document.getElementById("toolBar").style.opacity = "1.0";
        this.showpopup();
        $(this.ComparisonListButton).hide();
        document.getElementById("compare-tab-added").scroll({
            top: 0,
            behavior: 'smooth',
        })
    }
}

ModelCompare.prototype.populateDeletedinresultUI = function (deletednodes, allnodesPropertiesMap) {
    var updatedDeletedCount = 0;
    var _self = this;
    for (var i in deletednodes) {
        var grandparentnodeid = deletednodes[i];
        var grandparentname = hwv.model.getNodeName(grandparentnodeid);
        var genericid = null;
        if (this.filetype == 2) {
            // var properties = await hwv.model.getNodeProperties(Number(grandparentnodeid));
            // genericid = properties["persistentId"];

            genericid = this.allnodespidsMap[Number(grandparentnodeid)];
            // get all nodes name and its cog

            var childs = hwv.model.getNodeChildren(grandparentnodeid);
            if (childs.length > 0) {
                var childs1 = hwv.model.getNodeChildren(childs[0]);
                if (childs1.length > 0) {
                    var grandchild = childs1[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = grandparentname + "_" + cog;
                } else {
                    var grandchild = childs[0];
                    var cog = this.allnodescogMap[grandchild];
                    genericid = grandparentname + "_" + cog;
                }
            } else {
                var grandchild = grandparentnodeid;
                var cog = this.allnodescogMap[grandchild];
                genericid = grandparentname + "_" + cog;
            }
        } else {
            genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
        }


        var removedlist = document.getElementById("removedlist");
        var newdiv = document.createElement("div");
        newdiv.className = "noderow";
        newdiv.id = grandparentnodeid;
        var docref = hwv.model.getModelFileNameFromNode(grandparentnodeid);
        var seconddiv = document.createElement("div");
        seconddiv.className = "boxsquare red";
        // seconddiv.className ="red";
        var label = document.createElement("label");
        var properties = allnodesPropertiesMap[Number(grandparentnodeid)]
        // var properties = await hwv.model.getNodeProperties(grandparentnodeid);
        var nodeType = properties.TYPE;
        if (nodeType) {
            var strLength = nodeType.length;
            var spaceStr = nodeType.substring(strLength-1, strLength);
            nodeType = (spaceStr == " ") ? nodeType.substring(0, strLength-1) : nodeType;
        }

        if (nodeType == "IFCSPACE" || nodeType == "SPACE") {
            this.remove(this.nodeIDsDeletedArray, grandparentnodeid);
            continue;
        }
        if (nodeType == "IFCBUILDINGSTOREY" || nodeType == "BUILDINGSTOREY") {
            this.remove(this.nodeIDsDeletedArray, grandparentnodeid);
            continue;
        }

        var dataExport = [];
        if (nodeType) {
            if (properties.TYPE.substring(0, 3) == "IFC") {
                nodeType = properties.TYPE.slice(3);
            }
            var objectName = properties[properties.TYPE + "/Name"];
            var objectType = properties[properties.TYPE + "/ObjectType"];
            label.innerHTML = nodeType + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
            // dataExport = [grandparentnodeid, nodeType, objectName, grandparentname, genericid, docref];
            if(objectType)
                dataExport = [ nodeType, objectName, objectType, genericid, docref];
            else
                dataExport = [ nodeType, objectName, grandparentname, genericid, docref];
            // dataExport = [grandparentnodeid, nodeType, objectName, grandparentname, genericid, docref];
        } else {
            if (this.filetype == 2) {
                var nodetypeid = hwv.model.getNodeParent(grandparentnodeid);
                var nodetypename = hwv.model.getNodeName(nodetypeid);
                label.innerHTML = nodetypename + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [grandparentnodeid, nodetypename, grandparentname, nodetypename, genericid, docref];
                dataExport = [ nodetypename, grandparentname, nodetypename, genericid, docref];

            } else {
                label.innerHTML = grandparentname + " (Name: " + grandparentname + ", ID: " + genericid + ", " + "docref: " + docref + " )";
                // dataExport = [grandparentnodeid, grandparentname, grandparentname, grandparentname, genericid, docref];
                dataExport = [ grandparentname, grandparentname, grandparentname, genericid, docref];
            }
        }
        label.className = "ellipsis";

        newdiv.appendChild(seconddiv);
        newdiv.appendChild(label);
        // export logic

        var cell = [],
            data = [];
        var Rowremoved = this.doc1.createElement("Row");


        for (var j = 0; j < dataExport.length; j++) {
            try {
                cell[j] = this.doc1.createElement("Cell");
                data[j] = this.doc1.createElement("Data");
                data[j].setAttribute("ss:Type", "String");
                data[j].innerHTML = String(dataExport[j]).replace(/&/g, "");
                cell[j].appendChild(data[j]);
                Rowremoved.appendChild(cell[j]);
            } catch (e) {
                console.log(e);
            }
        }

        this.tableElem[2].appendChild(Rowremoved);
        ////
        newdiv.onclick = function () {
            // hwv.selectionManager.clear();
            var childs = document.getElementById("removedlist").childNodes;
            // for (var i=0; i < childs.length; i++) {
            //     if(childs[i].style) childs[i].style.backgroundColor = "transparent";
            // };

            if (event.currentTarget.style.backgroundColor !== "lightskyblue") {
                event.currentTarget.style.backgroundColor = "lightskyblue";
                _self.selectionArray.push(Number(event.currentTarget.id));
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            } else {
                event.currentTarget.style.backgroundColor = "transparent";
                _self.remove(_self.selectionArray, Number(event.currentTarget.id))
                hwv.selectionManager.selectNode(Number(event.currentTarget.id), Communicator.SelectionMode.Toggle);
            }
        };

        newdiv.onmouseover = function (event) {
            if (event.currentTarget.style.backgroundColor == "transparent" ||
                event.currentTarget.style.backgroundColor == "")
                event.currentTarget.style.backgroundColor = "lightgray";
        };
        newdiv.onmouseout = function (event) {
            if (event.currentTarget.style.backgroundColor == "lightgray")
                event.currentTarget.style.backgroundColor = "transparent";
        };

        removedlist.appendChild(newdiv);
        updatedDeletedCount = updatedDeletedCount + 1;
    }
    return updatedDeletedCount;
}

ModelCompare.prototype.populateDeletedinresult = async function (nodeIDsDeletedArray, allnodesPropertiesMap) {
    var deletednodes = [];
    this.updatedDeletedCount = 0;
    for (var i in nodeIDsDeletedArray) {
        var grandparentnodeid = Number(nodeIDsDeletedArray[i]); // for global ids
        var grandparentname = hwv.model.getNodeName(grandparentnodeid);
        // remove(this.unchangedobjectsleafnodes, grandparentnodeid);
        // removeAllLeafNodesFromParent(grandparentnodeid);
        if (!grandparentname || grandparentname == null)
            continue;


        if (hwv.model.getNodeName(Number(nodeIDsDeletedArray[i])) != null) {

            if (hwv.model.getNodeName(Number(nodeIDsDeletedArray[i])).includes("body")) {
                grandparentnodeid = hwv.model.getNodeParent(Number(nodeIDsDeletedArray[i]));
                grandparentname = hwv.model.getNodeName(grandparentnodeid);
            }
            if (hwv.model.getNodeName(grandparentnodeid).includes("Product")) {
                grandparentnodeid = hwv.model.getNodeParent(grandparentnodeid);
                grandparentname = hwv.model.getNodeName(grandparentnodeid);
            }
        }
        // var genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
        var genericid = null;
        if (this.filetype == 2) {
            genericid = this.allnodespidsMap[Number(grandparentnodeid)];
        } else {
            genericid = hwv.model.getNodeGenericId(Number(grandparentnodeid));
        }

        if (genericid === null) {
            continue;
        }

        if (deletednodes.indexOf(grandparentnodeid) >= 0) {
            continue;
        } else {
            deletednodes.push(grandparentnodeid);
        }

        this.globalIDsDeletedArray.push(genericid);

    }
    
//    console.log("Populate deleted async call start : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    var propertiesPromiseArray = [],
        promiseArrayBB = [];
    for (var i in deletednodes) {
        propertiesPromiseArray[i] = hwv.model.getNodeProperties(deletednodes[i]);
        promiseArrayBB[i] = hwv.model.getNodesBounding([deletednodes[i]]).catch(error => {
            return error
        });
    }
    
    var promiseResolveArray = await Promise.all(propertiesPromiseArray.map(p => p.catch(e => e)));
    var promiseResolveArrayBB = await Promise.all(promiseArrayBB.map(p => p.catch(e => e)));
    var allnodesLocalPropertiesMap = {};
    for (var x in deletednodes) {
        if (promiseResolveArray[x] && promiseResolveArrayBB[x] !== undefined) {
            var nodename = hwv.model.getNodeName(deletednodes[x]);
            var bob = this.bbStringForm(promiseResolveArrayBB[x].max, promiseResolveArrayBB[x].min);
            allnodesLocalPropertiesMap[deletednodes[x]] = promiseResolveArray[x];
            this.allnodespidsMap[deletednodes[x]] = nodename + "_" + bob;
        }
    };

//    console.log("Populate deleted async call middle : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    this.updatedDeletedCount = this.populateDeletedinresultUI(deletednodes, allnodesLocalPropertiesMap);

    
//    console.log("Populate deleted async call end : ", Math.floor(Date.now() / 1000) - starttime , " sec");
    for (var i in nodeIDsDeletedArray) {
        var deletednodeid = Number(nodeIDsDeletedArray[i]);
        this.remove(this.unchangedobjectsleafnodes, deletednodeid);
        this.removeAllLeafNodesFromParent(deletednodeid);
    }

    var removedlistcount = document.getElementById("removedlistcount");
    removedlistcount.innerHTML = this.updatedDeletedCount;
    this.DeletedListReady = true;
    if (this.addedListReady && this.updatedListReady && this.DeletedListReady) {
        document.getElementById("middleLoader").style.display = "none";
        document.getElementById("viewerContainer").style.opacity = "1.0";
        document.getElementById("toolBar").style.opacity = "1.0";
        this.showpopup();
        $(this.ComparisonListButton).hide();
        document.getElementById("compare-tab-added").scroll({
            top: 0,
            behavior: 'smooth',
        })
    }
}

ModelCompare.prototype.resetCompare = function () {

    var a = $(this.newaddedtablabel),
        m = $(this.modifiedtablabel),
        r = $(this.removedtablabel),
        u = $(this.unchangedtablabel),
        at = $(this.newaddedtab),
        mt = $(this.modifiedtab),
        rt = $(this.removedtab),
        bm = $(this.Bmodifiedtablabel),
        tm = $(this.Tmodifiedtablabel),
        _self = this;

    $("#viewer-modelcompare-ok-button").unbind("click");
    $("#viewer-modelcompare-cancel-button").unbind("click");

    if (!a.hasClass("selected")) {
        a.addClass("selected");
        at.addClass("selected");
        // hwv.model.setNodesVisibility(nodeIDsCreatedArray, true);
    }

    if (!m.hasClass("selected")) {
        m.addClass("selected");
        mt.addClass("selected");
        // hwv.model.setNodesVisibility(this.nodeIDsUpdatedArray, true);
    }

    if (!r.hasClass("selected")) {
        r.addClass("selected");
        rt.addClass("selected");
        // hwv.model.setNodesVisibility(this.nodeIDsDeletedArray, true);
    }

    if (!u.hasClass("selected")) {
        u.addClass("selected");
        // hwv.model.setNodesVisibility(this.unchangedobjectsleafnodes, true);

    }

    $(_self.basemodelinput).removeClass("active");
    $(_self.comparemodelinput).addClass("active");
    $(_self.targetmodelinput).removeClass("active");
    $(_self.comparemodelinput).click();

    this.nodeStructure = {};
    this.updatedGidArrayBase = [];
    this.deletedGidArrayBase = [];
    this.firstModelsGlobalIdArray = [];
    this.secondModelsGlobalIdArray = [];
    this.updatedGidArraySecond = [];
    this.deletedGidArraySecond = [];
    this.webviewer.selectionManager.clear()
    // this.webviewer.getModel().reset();

    this.nodeIDsUpdatedArray = [];
    this.nodeIDsUpdatedArrayFromList = [];
    this.nodeIDsCreatedArray = [];
    this.nodeIDsDeletedArray = [];

    this.globalIDsUpdatedArray = [];
    this.globalIDsCreatedArray = [];
    this.globalIDsDeletedArray = [];
    this.unchangedobjectsleafnodes = [];

    this.uniqueModelsNodes = [];
    this.uniqueMultipleBaseModelsNodes = [];
    this.uniqueMultipleTargetModelsNodes = [];
    this.unchangedobjectsleafnodes = [];
    this.filetype = 0;
    this.allnodespidsMap = {};
    this.allnodeslocalpidsMap = {};
    this.allnodesNamesMap = {};
    this.selectionArray = [];
    this.addednodesCount = 0;
    this.updatednodesCount = 0;
    this.updatedDeletedCount = 0;

    this.webviewer.getModel().resetModelOpacity();
    this.webviewer.getModel().resetModelTransparency();
    this.webviewer.getModel().resetNodesColor();
    this.webviewer.getModel().setNodesVisibility(this.uniqueMultipleModelsNodes, true);
    this.uniqueMultipleModelsNodes = [];

    $(this.selectiontablabel).unbind("click");
    $(this.resulttablabel).unbind("click");
    $(this.newaddedtablabel).unbind("click");
    $(this.modifiedtablabel).unbind("click");
    $(this.removedtablabel).unbind("click");
    $(this.unchangedtablabel).unbind("click");
    $(this.newaddedtabeye).unbind("click");
    $(this.modifiedtabeye).unbind("click");
    $(this.removedtabeye).unbind("click");
    $(this.basemodelinput).unbind("click");
    $(this.comparemodelinput).unbind("click");
    $(this.targetmodelinput).unbind("click");
    $(this.ComparisonListButton).unbind("click");
    $(this.Bmodifiedtablabel).unbind("click");
    $(this.Tmodifiedtablabel).unbind("click");

    $('#addedlist').empty();
    $('#modifiedlist').empty();
    $('#removedlist').empty();
    $("#viewer-modelcompare-dialog").hide();
    $("#Comparison-list").hide();

}




ModelCompare.prototype.remove = function (array, element) {
// function remove(array, element) {
    const index = array.indexOf(element);
    if (index != -1)
        array.splice(index, 1);
}

ModelCompare.prototype.removeAllLeafNodesFromParent = function(parentnode) {

    var childs = hwv.model.getNodeChildren(parentnode);
    if (childs.length == 0) {
        this.remove(this.unchangedobjectsleafnodes, parentnode);
    }

    if (childs.length) {
        for (var i in childs) {
            this.removeAllLeafNodesFromParent(childs[i]);
        }
    }
}

ModelCompare.prototype.segregateGlobalIds = function (nodeIDsUpdatedArray, firstmodelRootNode, secondModelRootNode) {

    nodeIDsUpdatedArray.forEach(globalid => {
        if (globalid) {
            if (hwv.model.getNodeIdsByGenericIds([globalid.data]) < secondModelRootNode)
                this.firstModelsGlobalIdArray.push(globalid.data);
            if (hwv.model.getNodeIdsByGenericIds([globalid.data]) > secondModelRootNode)
                this.secondModelsGlobalIdArray.push(globalid.data);
        }
    });

    this.firstModelsGlobalIdArray.forEach(globalid => {
        if (globalid) {
            if (this.secondModelsGlobalIdArray.indexOf(globalid) >= 0)
                this.updatedGidArrayfirst.push(globalid);
            else
                this.deletedGidArrayfirst.push(globalid);
        }
    });

    this.secondModelsGlobalIdArray.forEach(globalid => {
        if (globalid) {
            if (this.firstModelsGlobalIdArray.indexOf(globalid) >= 0)
                this.updatedGidArraySecond.push(globalid); // avoiding of duplication in array (updatedGidArraySecond) is yet to implement
            else
                this.deletedGidArraySecond.push(globalid);
        }
    });

}

ModelCompare.prototype.changeColorbyNodesExceptUpdated = function (nodeidArray, exceptids, color, removed) {
    var nodeopacity = {};
    var colorMap = {};
    nodeidArray.forEach(nodeid => {
        if (nodeid && !(exceptids.indexOf(nodeid) >= 0)) {
            try {
                if (!(this.nodeIDsDeletedArray.indexOf(nodeid) >= 0) && removed)
                    this.nodeIDsDeletedArray.push(Number(nodeid));
                if (!(this.nodeIDsCreatedArray.indexOf(nodeid) >= 0) && !removed)
                    this.nodeIDsCreatedArray.push(Number(nodeid));

                // nodeopacity[nodeid] = 1.0;
                // this.webviewer.getModel().setNodesOpacities(nodeopacity);
                colorMap[nodeid] = color;
                this.webviewer.getModel().setNodesColors(colorMap);
                // this.webviewer.getModel().setDepthRange([nodeid], 0.00001, 0.999999);
            } catch (err) {
                // console.log("Exception at : ",nodeid);
            }
        }
    });
}

ModelCompare.prototype.populatenodeIDsUpdatedArray = function (nodeidArray) {

    nodeidArray.forEach(nodeid => {
        if (nodeid) {
            if (!(this.nodeIDsUpdatedArray.indexOf(nodeid) >= 0) &&
                !(this.nodeIDsDeletedArray.indexOf(nodeid) >= 0) &&
                !(this.nodeIDsCreatedArray.indexOf(nodeid) >= 0)) {
                this.nodeIDsUpdatedArray.push(Number(nodeid));

            }
        }
    });
}

ModelCompare.prototype.removeIFCSPACESfromUnchanged = function () {
    var spacenodelist = hwv.model.getNodesByGenericType("IFCSPACE")

    if (spacenodelist)
        for (const key of spacenodelist) {
            const element = key;

            var childs = hwv.model.getNodeChildren(element);
            if (childs.length > 0) {
                for (const i in childs) {
                    const nodeid = childs[i];
                    if (this.unchangedobjectsleafnodes.indexOf(nodeid) >= 0)
                        this.remove(this.unchangedobjectsleafnodes, nodeid);

                }
            }
        }

}

ModelCompare.prototype.changeColorbyNodes = function (nodeidArray, color) {
    var nodeopacity = {};
    var colorMap = {};
    nodeidArray.forEach(nodeid => {
        if (nodeid) {
            try {

                this.removeAllLeafNodesFromParent(Number(nodeid));
                this.nodeIDsUpdatedArray.push(Number(nodeid));
                nodeopacity[nodeid] = 0.8;
                this.webviewer.getModel().setNodesOpacities(nodeopacity);
                colorMap[nodeid] = color;
                this.webviewer.getModel().setNodesColors(colorMap);

            } catch (err) {}
        }
    });
}

ModelCompare.prototype.changeColorbyNodesoriginal = function (nodeidArray, color) {
    var nodeopacity = {};
    var colorMap = {};
    nodeidArray.forEach(nodeid => {
        if (nodeid) {
            try {
                if (!(this.nodeIDsUpdatedArray.indexOf(nodeid) >= 0) &&
                    !(this.nodeIDsDeletedArray.indexOf(nodeid) >= 0) &&
                    !(this.nodeIDsCreatedArray.indexOf(nodeid) >= 0)) {
                    this.nodeIDsUpdatedArray.push(Number(nodeid));
                    nodeopacity[nodeid] = 0.8;
                    this.webviewer.getModel().setNodesOpacities(nodeopacity);
                    colorMap[nodeid] = color;
                    this.webviewer.getModel().setNodesColors(colorMap);
                    // this.webviewer.getModel().setDepthRange([nodeid], 0.00001, 0.999999);
                }
            } catch (err) {
                // console.log("Exception at : ",nodeid);
            }
        }
    });
}


ModelCompare.prototype.calculateNodeIds = function (NodesGidMap, gidArray, removed) {
    var nodeopacity = {};
    var colorMap = {};
    var gid = null;
    gidArray.forEach(globalid => {
        if (globalid) {
            var nodeid = Number(Object.keys(NodesGidMap).find(key => NodesGidMap[key] === globalid));

            if (!(this.nodeIDsDeletedArray.indexOf(nodeid) >= 0) && removed)
                this.nodeIDsDeletedArray.push(Number(nodeid));
            if (!(this.nodeIDsCreatedArray.indexOf(nodeid) >= 0) && !removed)
                this.nodeIDsCreatedArray.push(Number(nodeid));
        }
    });
}

ModelCompare.prototype.getPIDsForAddedAndRemoved = async function (nodeIDsArray, pidcreatedmap, pidcreatedarray, COGMap) {
    let promiseArray = [];
    for (var x in nodeIDsArray) {
        let promiseprop = hwv.model.getNodeProperties(nodeIDsArray[x]).catch(error => {
            return error
        });
        promiseArray.push(promiseprop);
    }

    var promiseResolveArray = await Promise.all(promiseArray);
    for (var x in nodeIDsArray) {
        if (promiseResolveArray[x] !== undefined && promiseResolveArray[x] !== null) {
            // pidcreatedmap[nodeIDsArray[x]] = promiseResolveArray[x]["persistentId"] ;
            // pidcreatedarray.push(promiseResolveArray[x]["persistentId"]);
            pidcreatedmap[nodeIDsArray[x]] = promiseResolveArray[x]["persistentId"];
            pidcreatedarray.push(promiseResolveArray[x]["persistentId"]);

            // COGMap[nodeIDsArray[x]] =  cogStringForm(promiseResolveArray[x]["COG"]);

            // this.allnodespidsMap[allnodeids[x]] = promiseResolveArray[x]["persistentId"]+ "_" + bob;
        }
    };
}

ModelCompare.prototype.getCOGsForAddedAndRemoved = async function (nodeIDsArray, cogcreatedmap, cogcreatedarray) {
    let promiseArray = [];
    for (var x in nodeIDsArray) {
        let promiseprop = hwv.model.getNodeProperties(nodeIDsArray[x]).catch(error => {
            return error
        });
        promiseArray.push(promiseprop);
    }

    var promiseResolveArray = await Promise.all(promiseArray);
    for (var x in nodeIDsArray) {
        if (promiseResolveArray[x] !== undefined && promiseResolveArray[x] !== null) {
            // pidcreatedmap[nodeIDsArray[x]] = promiseResolveArray[x]["persistentId"] ;
            // pidcreatedarray.push(promiseResolveArray[x]["persistentId"]);
            cogcreatedmap[nodeIDsArray[x]] = this.cogStringForm(promiseResolveArray[x]["COG"]);
            cogcreatedarray.push(this.cogStringForm(promiseResolveArray[x]["COG"]));

            // COGMap[nodeIDsArray[x]] =  cogStringForm(promiseResolveArray[x]["COG"]);

            // this.allnodespidsMap[allnodeids[x]] = promiseResolveArray[x]["persistentId"]+ "_" + bob;
        }
    };
}

ModelCompare.prototype.changeColorbyGlobalIdbygloablarray = function () {
    var nodeopacity = {};
    var colorMap = {};

    for (var nodeid in this.nodeIDsCreatedArray) {
        try {
            // nodeopacity[nodeid] = 1.0;
            // this.webviewer.getModel().setNodesOpacities(nodeopacity);
            colorMap[this.nodeIDsCreatedArray[nodeid]] = this.greencolor;
            this.webviewer.getModel().setNodesColors(colorMap);
            // this.webviewer.getModel().setDepthRange([nodeid], 0.001, 0.9999);
        } catch (err) {
            // console.log("Exception at : ",globalid);
        }
    }

    for (var nodeid in this.nodeIDsDeletedArray) {
        try {
            // nodeopacity[nodeid] = 1.0;
            // this.webviewer.getModel().setNodesOpacities(nodeopacity);
            colorMap[this.nodeIDsDeletedArray[nodeid]] = this.redcolor;
            this.webviewer.getModel().setNodesColors(colorMap);
            // this.webviewer.getModel().setDepthRange([nodeid], 0.001, 0.9999);
        } catch (err) {
            // console.log("Exception at : ",globalid);
        }
    }

}


ModelCompare.prototype.changeColorbyGlobalId = function (NodesGidMap, gidArray, color, removed) {
    var nodeopacity = {};
    var colorMap = {};
    var gid = null;
    gidArray.forEach(globalid => {
        if (globalid) {
            var nodeid = Number(Object.keys(NodesGidMap).find(key => NodesGidMap[key] === globalid));

            if (!(this.nodeIDsDeletedArray.indexOf(nodeid) >= 0) && removed)
                this.nodeIDsDeletedArray.push(Number(nodeid));
            if (!(this.nodeIDsCreatedArray.indexOf(nodeid) >= 0) && !removed)
                this.nodeIDsCreatedArray.push(Number(nodeid));

            try {
                // nodeopacity[nodeid] = 1.0;
                // this.webviewer.getModel().setNodesOpacities(nodeopacity);
                colorMap[nodeid] = color;
                this.webviewer.getModel().setNodesColors(colorMap);
                // this.webviewer.getModel().setDepthRange([nodeid], 0.001, 0.9999);
            } catch (err) {
                // console.log("Exception at : ",globalid);
            }
        }
    });


}


ModelCompare.prototype.initpopup = function () {
    var a = $(this._viewerSettingsSelector),
        c = a.width(),
        b = a.height();
    if (void 0 !== c && void 0 !== b) {
        var d = this._viewer.view.getCanvasSize();
        a.css({
            left: (d.x -
                c) / 2 + "px",
            top: (d.y - b) / 2 + "px"
        })
    }
    $(this._viewerModelCompareSelector).show();
    a.draggable({
        handle: ".hoops-ui-window-header"
    });

}



ModelCompare.prototype.compareBoundingBoxofnodes = async function (nodeid1, nodeid2) {
    let promiseArray = []
    promiseArray.push(hwv.model.getNodesBounding([Number(nodeid1)]));
    promiseArray.push(hwv.model.getNodesBounding([Number(nodeid2)]));

    var bb = await Promise.all(promiseArray);
    if (bb[0].max.x.toFixed(3) == bb[1].max.x.toFixed(3) &&
        bb[0].max.y.toFixed(3) == bb[1].max.y.toFixed(3) &&
        bb[0].max.z.toFixed(3) == bb[1].max.z.toFixed(3) &&
        bb[0].min.x.toFixed(3) == bb[1].min.x.toFixed(3) &&
        bb[0].min.y.toFixed(3) == bb[1].min.y.toFixed(3) &&
        bb[0].min.z.toFixed(3) == bb[1].min.z.toFixed(3)) {
        return true;
    } else {
        return false;
    }
}

ModelCompare.prototype.findUpdatednodesFromintersectionArrayandVC = async function (intersection, leafnodesVertexcountFirstMap, leafnodesVertexcountSecondMap,
    leafnodesGidFirstMap, leafnodesGidSecondMap,
    NodesGidFirstMap, NodesGidSecondMap, allFirstnodesSurfaceAreaMap, allSecondnodesSurfaceAreaMap, updatednodeIdsArray) {
    var promisearr = [];
    for (var i in intersection) {
        var gid = intersection[i];

        var firstnode = Number(Object.keys(NodesGidFirstMap).find(key => NodesGidFirstMap[key] === gid));
        var secondnode = Number(Object.keys(NodesGidSecondMap).find(key => NodesGidSecondMap[key] === gid));

        if (this.checkIfGidIsParent(firstnode)) {
            if (firstnode != null && secondnode != null) {

                promisearr[i] = this.findUpdatednodesFromintersectionArrayandVC1(gid, firstnode, firstnode, secondnode, intersection, leafnodesVertexcountFirstMap, leafnodesVertexcountSecondMap,
                    leafnodesGidFirstMap, leafnodesGidSecondMap, NodesGidFirstMap, NodesGidSecondMap, allFirstnodesSurfaceAreaMap, allSecondnodesSurfaceAreaMap, updatednodeIdsArray);

                // await findUpdatednodesFromintersectionArrayandVC1(gid, secondnode, firstnode, secondnode, intersection, leafnodesVertexcountFirstMap, leafnodesVertexcountSecondMap,
                //     leafnodesGidFirstMap, leafnodesGidSecondMap, NodesGidFirstMap, NodesGidSecondMap, updatednodeIdsArray);
            }
        }
    }
    await Promise.all(promisearr);
}

ModelCompare.prototype.checkIfGidIsParent = function(nodeID) {
    var child1 = hwv.getModel().getNodeChildren(nodeID); //nodeid = windows

    if (child1.length == 0) { // itself is body
        return true;
    } else {
        var child2 = hwv.getModel().getNodeChildren(child1[0]);
        if (child2.length == 0) // nodeId was product and this is body
            return true;
        else {
            var child3 = hwv.getModel().getNodeChildren(child2[0]);
            if (child3.length == 0) // nodeId was product and this is body
                return true;
            else
                return false;
        }
    }
}


var currentParentnode = null;
var currentParentGuid = null;
ModelCompare.prototype.findUpdatednodesFromintersectionArrayandVC1 = async function (GloabalId, nodeID, firstnode, secondnode, intersection, leafnodesVertexcountFirstMap, leafnodesVertexcountSecondMap,
    leafnodesGidFirstMap, leafnodesGidSecondMap, NodesGidFirstMap, NodesGidSecondMap, allFirstnodesSurfaceAreaMap, allSecondnodesSurfaceAreaMap, updatednodeIdsArray) {

    var gid = GloabalId;


    var childs1 = hwv.getModel().getNodeChildren(nodeID);
    var childs2 = hwv.getModel().getNodeChildren(secondnode);

    // child1 length and child2 length has to be same

    if (childs1.length == 0) {
        var firstvccount = leafnodesVertexcountFirstMap[firstnode];
        var secondvccount = leafnodesVertexcountSecondMap[secondnode];

        var firstsurfacearea = allFirstnodesSurfaceAreaMap[firstnode];
        var secondsurfacearea = allSecondnodesSurfaceAreaMap[secondnode];

        if (firstvccount !== undefined && secondvccount !== undefined && firstvccount !== -1 && secondvccount !== -1) {
            if (firstvccount != secondvccount) {
                // updatednodeIdsArray.push(hwv.getModel().getNodeParent(nodeID));
                if (!updatednodeIdsArray.includes(nodeID))
                    updatednodeIdsArray.push(Number(nodeID));
                if (!updatednodeIdsArray.includes(secondnode))
                    updatednodeIdsArray.push(Number(secondnode));
                // if (childs1.length == 0) 
                // updatednodeIdsArray.push(secondnode);
            } else {
                if (firstsurfacearea != secondsurfacearea) {
                    if (!updatednodeIdsArray.includes(nodeID))
                        updatednodeIdsArray.push(Number(nodeID));
                    if (!updatednodeIdsArray.includes(secondnode))
                        updatednodeIdsArray.push(Number(secondnode));
                }
            }
        }
    } else {
        // We have to check every node. here we are just skipping the gid if it does not have childs. 
        var promisearr = [];
        for (var i in childs1) {
            promisearr[i] = this.findUpdatednodesFromintersectionArrayandVC1(GloabalId, childs1[i], childs1[i], childs2[i], intersection, leafnodesVertexcountFirstMap, leafnodesVertexcountSecondMap,
                leafnodesGidFirstMap, leafnodesGidSecondMap,
                NodesGidFirstMap, NodesGidSecondMap, allFirstnodesSurfaceAreaMap, allSecondnodesSurfaceAreaMap, updatednodeIdsArray);
        }
        await Promise.all(promisearr);
    }

}

// ModelCompare.prototype.findUpdatednodesFromintersectionArray = async function (intersection, AllleafNodeIDForFirstModel, AllleafNodeIDForSecondModel, leafnodesGidFirstMap, leafnodesGidSecondMap, updatednodeIdsArray) {
//     for (var i in intersection) {
//         var gid = intersection[i];
//         var firstnode = Object.keys(leafnodesGidFirstMap).find(key => leafnodesGidFirstMap[key] === gid);
//         var secondnode = Object.keys(leafnodesGidSecondMap).find(key => leafnodesGidSecondMap[key] === gid);

//         if (firstnode != null && secondnode != null) {
//             var sameGeometryFlag = await this.compareBoundingBoxofnodes(firstnode, secondnode);
//             if (!sameGeometryFlag) {
//                 updatednodeIdsArray.push(Number(firstnode));
//             }
//         }

//     }
// }

ModelCompare.prototype.differencenodeidsBasedOnBB = function(leafnodesbbMap, differenceofBBids) {
    var differencenodeidsBasedOnBBArray = [];
    for (var x in differenceofBBids) {
        differencenodeidsBasedOnBBArray.push(Object.keys(leafnodesbbMap).find(key => leafnodesbbMap[key] === differenceofBBids[x]));
    }
    return differencenodeidsBasedOnBBArray;
}

ModelCompare.prototype.collectBoundingboxMap = async function(AllleafNodeIDForFirstModel, leafnodesbbMap, AllBBsModelArr) {
    let promiseArray = [];
    for (var x in AllleafNodeIDForFirstModel) {
        let promiseBB = hwv.model.getNodesBounding([AllleafNodeIDForFirstModel[x]]).catch(error => {
            return error
        });
        promiseArray.push(promiseBB);
    }

    var promiseResolveArray = await Promise.all(promiseArray);
    for (var x in AllleafNodeIDForFirstModel) {
        if (promiseResolveArray[x] !== undefined) {
            leafnodesbbMap[AllleafNodeIDForFirstModel[x]] = this.bbStringForm(promiseResolveArray[x].max, promiseResolveArray[x].min);
            AllBBsModelArr.push(this.bbStringForm(promiseResolveArray[x].max, promiseResolveArray[x].min));
        }
    };
}

ModelCompare.prototype.collectVertexCountMap = async function (AllleafNodeIDForFirstModel, leafnodesVCMap, AllVCsModelArr) {
    let promiseArray = [];
    for (var x in AllleafNodeIDForFirstModel) {
        let promiseBB = hwv.model.getNodeMeshData(AllleafNodeIDForFirstModel[x]);
        promiseArray.push(promiseBB);
    }
    var promiseResolveArray = await Promise.all(promiseArray.map(p => p.catch(e => e)));

    for (var x in AllleafNodeIDForFirstModel) {
        if (promiseResolveArray[x].faces) {
            leafnodesVCMap[AllleafNodeIDForFirstModel[x]] = promiseResolveArray[x].faces.vertexCount;
        } else {
            leafnodesVCMap[AllleafNodeIDForFirstModel[x]] = -1;
        }
    };
}

// ModelCompare.prototype.collectVertexCountForParentNode = async function (parentNode) {
//     var sumofVertexCount = 0;
//     var childs = hwv.model.getNodeChildren(parentNode);
//     for (var x in childs) {
//         await hwv.model.getNodeMeshData(childs[x]).then(
//             res => {
//                 sumofVertexCount = sumofVertexCount + res.faces.vertexCount;
//             },
//             rej => {
//                 sumofVertexCount = sumofVertexCount + 0;
//             }
//         );
//     }
//     return sumofVertexCount;
// }

ModelCompare.prototype.bbStringForm = function (max, min) {

    if (max !== undefined && min !== undefined) {
        return this.toFixedCustom(max.x, 1) + " " + this.toFixedCustom(max.y, 1) + " " + this.toFixedCustom(max.z, 1) + " " + this.toFixedCustom(min.x, 1) + " " + this.toFixedCustom(min.y, 1) + " " + this.toFixedCustom(min.z, 1);
    } else {
        return null;
    }
}

ModelCompare.prototype.cogStringForm = function (cogString) {
    if (cogString !== undefined) {
        var cogCoords = cogString.split(" ");

        if (cogCoords !== undefined && cogCoords.length > 2) {
            var x = this.toFixedCustom(parseInt(cogCoords[0].split(":")[1].replace(/\,/g, '')), 1);
            var z = this.toFixedCustom(parseInt(cogCoords[2].split(":")[1].replace(/\,/g, '')), 1);
            var y = this.toFixedCustom(parseInt(cogCoords[1].split(":")[1].replace(/\,/g, '')), 1);

            return this.toFixedCustom(x, 1) + " " + this.toFixedCustom(y, 1) + " " + this.toFixedCustom(z, 1);
        } else {
            return null;
        }
    } else {
        return null;
    }
}

ModelCompare.prototype.toFixedCustom = function (num, fixed) {
    var re = new RegExp('^-?\\d+(?:\.\\d{0,' + (fixed || -1) + '})?');
    return num.toString().match(re)[0];
}

ModelCompare.prototype.collectallnodeids = function (nodeIdsArray, allnodeids, allLeafnodeids) {
    for (let index = 0; index < nodeIdsArray.length; index++) {
        const nodeId = nodeIdsArray[index];
        this.collectallnodeidsarray(nodeId, allnodeids, allLeafnodeids);
    }
}

ModelCompare.prototype.collectallnodeidsarray = function (nodeId, allnodeids, allLeafnodeids) {
    var childs = hwv.model.getNodeChildren(nodeId);
    //check if nodes are spaces
    var nameifSpace = hwv.model.getNodeName(nodeId);
    // if( nameifSpace === "IFCSPACE")
    //   return;


    if (childs.length == 0) {
        allLeafnodeids.push(nodeId);
        allnodeids.push(nodeId);
    }
    if (childs.length) {
        for (var i in childs) {
            allnodeids.push(childs[i]);
            this.collectallnodeidsarray(childs[i], allnodeids, allLeafnodeids);
        }
    }
}
ModelCompare.prototype.collectAllPids = async function (allnodeids, allnodeslocalpidsMap, allnodeslocalSurfaceAreaMap) {
    let promiseArrayProps = [],
        promiseArrayBB = [];
    for (var x in allnodeids) {
        let promisePropsBB = hwv.model.getNodeProperties(allnodeids[x]).catch(error => {
            return error
        });
        let promiseBB = hwv.model.getNodesBounding([allnodeids[x]]).catch(error => {
            return error
        });
        promiseArrayBB.push(promiseBB);
        promiseArrayProps.push(promisePropsBB);
    };

    var promiseResolveArray = await Promise.all(promiseArrayProps.map(p => p.catch(e => e)));
    var promiseResolveArrayBB = await Promise.all(promiseArrayBB.map(p => p.catch(e => e)));

    for (var x in allnodeids) {
        if (promiseResolveArray[x] && promiseResolveArrayBB[x] !== undefined) {
            var nodename = hwv.model.getNodeName(allnodeids[x]);
            var parentName = hwv.model.getNodeName(hwv.model.getNodeParent(allnodeids[x]));
            var bob = this.bbStringForm(promiseResolveArrayBB[x].max, promiseResolveArrayBB[x].min);
            allnodeslocalpidsMap[allnodeids[x]] = promiseResolveArray[x]["persistentId"];// + "_" + bob;
            // allnodeslocalpidsMap[allnodeids[x]] = parentName + "_" + bob;
            allnodeslocalSurfaceAreaMap[allnodeids[x]] = promiseResolveArray[x]["Surface Area"];
//            allnodeslocalproperties[allnodeids[x]] = promiseResolveArray[x];
            this.allnodespidsMap[allnodeids[x]] = promiseResolveArray[x]["persistentId"];// + "_" + bob;
            // this.allnodespidsMap[allnodeids[x]] = parentName + "_" + bob;
            this.allnodescogMap[allnodeids[x]] = promiseResolveArray[x]["COG"];
        }
    };
}

ModelCompare.prototype.collectAllIFCNames = async function (allnodeids, NodesNamesMap, NodesNamesMaparray) {
    let promiseArrayProps = [];
    for (var x in allnodeids) {
        let promisePropsBB = hwv.model.getNodeProperties(allnodeids[x]);
        promiseArrayProps.push(promisePropsBB);
    };

    var promiseResolveArray = await Promise.all(promiseArrayProps.map(p => p.catch(e => e)));

    for (var x in allnodeids) {
        if (promiseResolveArray[x]) {
            var type = promiseResolveArray[x]["TYPE"];
			if (type) {
				type = type.replace(" ", '');
			}
			var name = promiseResolveArray[x][type + "/Name"];
			if (name) {
				name = name.slice(0, -1);
			}
            NodesNamesMap[allnodeids[x]] = type + "_" + name
            this.allnodesNamesMap[allnodeids[x]] = type + "_" + name;
            NodesNamesMaparray.push(type + "_" + name);
        }
    };
}

ModelCompare.prototype.checkcogDuplication = function (basecogcreatedmap, basecogcreatedarray, targetcogdeletedmap,
    targetcogdeletedarray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr) {
    for (var x in basecogcreatedarray) {
        var basecog = basecogcreatedarray[x];
        if (basecog) {
            if (targetcogdeletedarray.includes(basecog)) {

                var basenode = Number(Object.keys(basecogcreatedmap).find(key => basecogcreatedmap[key] === basecog));
                var targetnode = Number(Object.keys(targetcogdeletedmap).find(key => targetcogdeletedmap[key] === basecog));

                delete basecogcreatedmap[basenode];
                delete targetcogdeletedmap[targetnode];

                var bbBase = nodesbbBaseMap[basenode];
                var bbTarget = nodesbbTargetMap[targetnode];

                if (bbBase == bbTarget) {
                    this.remove(this.nodeIDsCreatedArray, targetnode);
                    this.remove(this.nodeIDsDeletedArray, basenode);
                } else {
                    if (hwv.model.getNodeName(Number(targetnode))?.indexOf("body") >= 0) //for leaf nodes
                    {
                        var parentnode = hwv.model.getNodeParent(targetnode);
                        var childs = hwv.model.getNodeChildren(parentnode);

                        for (const key in childs) {
                            const element = childs[key];
                            this.remove(this.nodeIDsCreatedArray, element);
                        }
                    } else {
                        this.remove(this.nodeIDsCreatedArray, targetnode);
                    }
                    if (hwv.model.getNodeName(Number(basenode))?.indexOf("body") >= 0) //for leaf nodes
                    {
                        var parentnode = hwv.model.getNodeParent(basenode);
                        var childs = hwv.model.getNodeChildren(parentnode);

                        for (const key in childs) {
                            const element = childs[key];
                            this.remove(this.nodeIDsDeletedArray, element);
                        }
                    } else {
                        this.remove(this.nodeIDsDeletedArray, basenode);
                    }
                    // remove(this.nodeIDsCreatedArray, targetnode);
                    // remove(this.nodeIDsDeletedArray, basenode);
                    this.nodeIDsUpdatedArray.push(basenode);
                    this.nodeIDsUpdatedArray.push(targetnode);
                }


            }
        }
    }
}

ModelCompare.prototype.checkpidDuplication = function (basepidcreatedmap, basepidcreatedarray, targetpiddeletedmap,
    targetpiddeletedarray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr) {
    for (var x in basepidcreatedarray) {
        var basepid = basepidcreatedarray[x];
        if (targetpiddeletedarray.includes(basepid)) {

            // var basenode = Number(Object.keys(basepidcreatedmap).find(key => basepidcreatedmap[key] === basepid));
            // var targetnode = Number(Object.keys(targetpiddeletedmap).find(key => targetpiddeletedmap[key] === basepid));
            var basenodes = Object.keys(basepidcreatedmap).filter(key => basepidcreatedmap[key] === basepid);
            var targetnodes = Object.keys(targetpiddeletedmap).filter(key => targetpiddeletedmap[key] === basepid);

            if (basenodes.length == 1 && targetnodes.length == 1) {

                var basenode = Number(basenodes[0]);
                var targetnode = Number(targetnodes[0]);

                delete basepidcreatedmap[basenode];
                delete targetpiddeletedmap[targetnode];

                var bbBase = nodesbbBaseMap[basenode];
                var bbTarget = nodesbbTargetMap[targetnode];

                if (bbBase == bbTarget) {
                    this.remove(this.nodeIDsCreatedArray, targetnode);
                    this.remove(this.nodeIDsDeletedArray, basenode);
                } else {
                    if (hwv.model.getNodeName(Number(targetnode)).indexOf("body") >= 0) //for leaf nodes
                    {
                        var parentnode = hwv.model.getNodeParent(targetnode);
                        var childs = hwv.model.getNodeChildren(parentnode);

                        for (const key in childs) {
                            const element = childs[key];
                            this.remove(this.nodeIDsCreatedArray, element);
                        }
                    } else {
                        this.remove(this.nodeIDsCreatedArray, targetnode);
                    }
                    if (hwv.model.getNodeName(Number(basenode)).indexOf("body") >= 0) //for leaf nodes
                    {
                        var parentnode = hwv.model.getNodeParent(basenode);
                        var childs = hwv.model.getNodeChildren(parentnode);

                        for (const key in childs) {
                            const element = childs[key];
                            this.remove(this.nodeIDsDeletedArray, element);
                        }
                    } else {
                        this.remove(this.nodeIDsDeletedArray, basenode);
                    }
                    this.nodeIDsUpdatedArray.push(basenode);
                    this.nodeIDsUpdatedArray.push(targetnode);
                }

            }

        }
    }
}

// function checkNamesDuplication(baseNodesNamesMap, baseNodesNamesMapArray, targetNodesNamesMap,
//     targetNodesNamesMaparray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr,
//     leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap) {
 ModelCompare.prototype.checkNamesDuplication = function(baseNodesNamesMap, baseNodesNamesMapArray, targetNodesNamesMap,
        targetNodesNamesMaparray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr,
        leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap) {

    for (var x in baseNodesNamesMapArray) {
        var nodename = baseNodesNamesMapArray[x];
        if (targetNodesNamesMaparray.includes(nodename)) {

            var basenode = Number(Object.keys(baseNodesNamesMap).find(key => baseNodesNamesMap[key] === nodename));
            var targetnode = Number(Object.keys(targetNodesNamesMap).find(key => targetNodesNamesMap[key] === nodename));

            //check bb
            var bbBase = nodesbbBaseMap[basenode];
            var bbTarget = nodesbbTargetMap[targetnode];

            if (bbBase == bbTarget) {
                var vcBase = this.sumvertexCount(basenode, leafnodesVertexcountBaseMap);
                var vcTarget = this.sumvertexCount(targetnode, leafnodesVertexcountTargetMap);
                // if(vcBase == vcTarget)
                {
                    this.remove(this.nodeIDsCreatedArray, targetnode);
                    this.remove(this.nodeIDsDeletedArray, basenode);
                }
            }
        }
    }
}

 ModelCompare.prototype.checkNamesDuplicationRvt = function(baseNodesNamesMap, baseNodesNamesMapArray, targetNodesNamesMap,
    targetNodesNamesMaparray, nodesbbBaseMap, BBsBaseModelArr, nodesbbTargetMap, BBsTargetModelArr,
    leafnodesVertexcountBaseMap, leafnodesVertexcountTargetMap) {

    for (var x in BBsBaseModelArr) {
        var nodename = BBsBaseModelArr[x];
        if (BBsTargetModelArr.includes(nodename)) {

            var basenode = Number(Object.keys(nodesbbBaseMap).find(key => nodesbbBaseMap[key] === nodename));
            var targetnode = Number(Object.keys(nodesbbTargetMap).find(key => nodesbbTargetMap[key] === nodename));

            // check if pid is same or not..

            //check bb
            var bbBase = nodesbbBaseMap[basenode];
            var bbTarget = nodesbbTargetMap[targetnode];

            if (bbBase == bbTarget) {
                var vcBase = this.sumvertexCount(basenode, leafnodesVertexcountBaseMap);
                var vcTarget = this.sumvertexCount(targetnode, leafnodesVertexcountTargetMap);
                // if(vcBase == vcTarget)
                {
                    this.remove(this.nodeIDsCreatedArray, targetnode);
                    this.remove(this.nodeIDsDeletedArray, basenode);
                }
            }
        }
    }
}

ModelCompare.prototype.sumvertexCount = function(nodeID, VertexcountMap) {
    var child1 = hwv.getModel().getNodeChildren(nodeID); //nodeid = windows
    var vertexcount = 0;
    if (child1.length == 0) { // itself is body
        vertexcount = vertexcount + VertexcountMap[nodeID];
    } else {
        for (var i in child1) {
            var child2 = hwv.getModel().getNodeChildren(child1[i]);
            if (child2.length == 0) // nodeId was product and this is body
            {
                vertexcount = vertexcount + VertexcountMap[child1[i]]
                // return vertexcount[nodeID]

                // return true;
            } else {
                for (var j in child2) {
                    var child3 = hwv.getModel().getNodeChildren(child2[j]);
                    if (child3.length == 0) // nodeId was product and this is body
                    {
                        vertexcount = vertexcount + VertexcountMap[child2[j]]
                        //return true;
                    }
                }
            }
        }

    }
    return vertexcount;
}

ModelCompare.prototype.getAllnodesObjectarray = async function(nodeIdsArray, gidarraylocal, AllleafNodeIDForModel, leafnodesGidMap, NodesGidMap) {
    for (let index = 0; index < nodeIdsArray.length; index++) {
        const nodeId = nodeIdsArray[index];
        await this.getAllnodesObject(nodeId, gidarraylocal, AllleafNodeIDForModel, leafnodesGidMap, NodesGidMap);
    }
}

ModelCompare.prototype.getAllnodesObject = async function(nodeId, gidarraylocal, AllleafNodeIDForModel, leafnodesGidMap, NodesGidMap) {
    // var IFCglobalId = hwv.model.getNodeGenericId(nodeId);

    var IFCglobalId = null;

    var nodeName = hwv.model.getNodeName(nodeId);



    if (this.filetype == 2) {
		IFCglobalId = this.allnodespidsMap[nodeId];
        var properties = await hwv.model.getNodeProperties(nodeId);
        IFCglobalId = properties["persistentId"];

    } else {
        // return hwv.model.getNodeGenericId(nodeId);
        IFCglobalId = hwv.model.getNodeGenericId(nodeId);
    }
    // leafnodesGidMap[nodeId] = IFCglobalId;

    if (IFCglobalId) {

        gidarraylocal.push(IFCglobalId);
        NodesGidMap[nodeId] = IFCglobalId;
    }

    var childs = hwv.model.getNodeChildren(nodeId);

    if (childs.length == 0) {
        leafnodesGidMap[nodeId] = IFCglobalId;
        AllleafNodeIDForModel.push(nodeId);
        this.unchangedobjectsleafnodes.push(nodeId);

    }
    if (childs.length) {
        for (var i in childs) {
            // var nodeName = hwv.model.getNodeName(childs[i]);
            // if( hwv.model.getNodeGenericType(childs[i]) == "IFCSPACE")
            //     await getAllnodesObject(childs[i], gidarraylocal, AllleafNodeIDForModel, leafnodesGidMap, NodesGidMap, true);

            await this.getAllnodesObject(childs[i], gidarraylocal, AllleafNodeIDForModel, leafnodesGidMap, NodesGidMap);
        }
    }
}

// function iterateCollectGlobalId(tree) {
//     if (tree.IFCglobalId && tree.IFCglobalId.type == 'updated')
//         this.nodeIDsUpdatedArray.push(tree.IFCglobalId);
//     if (tree.IFCglobalId && tree.IFCglobalId.type == 'created')
//         this.nodeIDsCreatedArray.push(tree.IFCglobalId);
//     if (tree.IFCglobalId && tree.IFCglobalId.type == 'deleted')
//         this.nodeIDsDeletedArray.push(tree.IFCglobalId);
//     if (tree.children && tree.children != [])
//         for (var x in tree.children)
//             iterateCollectGlobalId(tree.children[x]);
// }

// function iterate(obj) {
//     for (var property in obj) {
//         if (obj.hasOwnProperty(property)) {
//             if (typeof obj[property] == "object") {
//                 iterate(obj[property]);
//             } else {
//                 console.log(property + "   " + obj[property]);
//             }
//         }
//     }
// }

// async function getNodesIFCGUID(nodeid) {
//     if (this.filetype == 2) {
//         // var properties = await hwv.model.getNodeProperties(nodeid);
//         // var guid = properties["persistentId"];
//         IFCglobalId = this.allnodespidsMap[nodeid];
//         return guid;
//     } else {
//         // return hwv.model.getNodeGenericId(nodeid);
//         var IFCglobalId = hwv.model.getNodeGenericId(nodeid);
//         return IFCglobalId;
//     }
// }

 ModelCompare.prototype.getFiletype = function(nodeid) {
    var docref = hwv.model.getModelFileNameFromNode(nodeid);
    var ext = docref.split(".")[1];

    switch (ext) {
        case "ifc" || "IFC":
            this.filetype = 1;
            break;
        case "rvt" || "RVT":
            this.filetype = 2;
            break;

        default:
            this.filetype = 0;
            break;
    }
    return this.filetype;
}

ModelCompare.prototype.updateProgressBar = async function(progress) {
    this.updateProgressBarasync(progress);
}

ModelCompare.prototype.updateProgressBarasync = function(progress) {
    document.getElementById("progressbar").style.width = progress + "%";
    document.getElementById("progressbar").innerHTML = progress + "%";
}

ModelCompare.prototype.enableBModified = function() {
    hwv.model.setNodesVisibility(this.nodeIDsBUpdatedArray, true);
    for (const key in this.nodeIDsBUpdatedArray) {
        if (this.nodeIDsBUpdatedArray.hasOwnProperty(key)) {
            const element = this.nodeIDsBUpdatedArray[key];
            var nodelistitem = document.getElementById(element)
            nodelistitem.style.display = "block";
        }
    }
    var modifiedlistcount = document.getElementById("modifiedlistcount");
    modifiedlistcount.innerHTML = this.nodeIDsTUpdatedArray.length;

}

ModelCompare.prototype.disableBModified = function() {
    hwv.model.setNodesVisibility(this.nodeIDsBUpdatedArray, false);
    for (const key in this.nodeIDsBUpdatedArray) {
        if (this.nodeIDsBUpdatedArray.hasOwnProperty(key)) {
            const element = this.nodeIDsBUpdatedArray[key];
            var nodelistitem = document.getElementById(element)
            nodelistitem.style.display = "none";
        }
    }
    var modifiedlistcount = document.getElementById("modifiedlistcount");
    modifiedlistcount.innerHTML = this.nodeIDsTUpdatedArray.length;

}

ModelCompare.prototype.enableTModified = function() {
    hwv.model.setNodesVisibility(this.nodeIDsTUpdatedArray, true);
    for (const key in this.nodeIDsTUpdatedArray) {
        if (this.nodeIDsTUpdatedArray.hasOwnProperty(key)) {
            const element = this.nodeIDsTUpdatedArray[key];
            var nodelistitem = document.getElementById(element)
            nodelistitem.style.display = "block";
        }
    }
    var modifiedlistcount = document.getElementById("modifiedlistcount");
    modifiedlistcount.innerHTML = this.nodeIDsTUpdatedArray.length;

}

ModelCompare.prototype.disableTModified = function() {
    hwv.model.setNodesVisibility(this.nodeIDsTUpdatedArray, false);
    for (const key in this.nodeIDsTUpdatedArray) {
        if (this.nodeIDsTUpdatedArray.hasOwnProperty(key)) {
            const element = this.nodeIDsTUpdatedArray[key];
            var nodelistitem = document.getElementById(element)
            nodelistitem.style.display = "none";
        }
    }
    var modifiedlistcount = document.getElementById("modifiedlistcount");
    modifiedlistcount.innerHTML = this.nodeIDsTUpdatedArray.length;

}

ModelCompare.prototype.download = function(text, name, type) {

    let a = document.createElement('a')
    var file = new Blob([text], {
        type: type
    });
    a.href = URL.createObjectURL(file);
    a.download = a.href.split('/').pop();
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}