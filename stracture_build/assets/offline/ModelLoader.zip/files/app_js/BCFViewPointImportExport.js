//Enum representing the viewpoint generation source
var vpGenerationSource = [];
vpGenerationSource[vpGenerationSource.none = 0] = "none";
vpGenerationSource[vpGenerationSource.import = 1] = "import";
vpGenerationSource[vpGenerationSource.capture = 2] = "capture";

function BCFViewpoint(viewer) {
	this._viewer = viewer;
	this._camera = null;
	this._colorMap = {};
	this._defaultVisibility = false;
	this._visibilityExceptions = [];
	this._selection = [];
	//image data
	this._viewData = "";
	//represents imported or captured
	this._generationSrc = vpGenerationSource.none;
}

BCFViewpoint.prototype.activate = function () {
	var _self = this;
	this._viewer.view.setCamera(this._camera);
	this._viewer.model.resetNodesColor();
	//iterate color map and apply color to faces of each node
	for (var key in this._colorMap) {
		var nodeID = [];
		nodeID.push(+key);
		hwv.model.setNodesFaceColor(nodeID, this._colorMap[nodeID]);
	}

	this._viewer.model.setNodesVisibility([this._viewer.model.getAbsoluteRootNode()], this._defaultVisibility).then(function () {
		if (0 < _self._visibilityExceptions.length) {
			array = [];
			_self._visibilityExceptions.forEach(function (a) {
				array.push(a)
			});
			_self._viewer.model.setNodesVisibility(array, !_self._defaultVisibility);
		}
	});

	//Add node to selection
	hwv.selectionManager.clear();
	for (var index = 0; index < this._selection.length; index++) {
		hwv.selectionManager.selectNode(this._selection[index], Communicator.SelectionMode.Add);
	}


}

BCFViewpoint.prototype.Reset = function () {
	//Clear selection
	this._viewer.selectionManager.clear();
	//call reset on viewer
	this._viewer.model.reset();
	//Clear color that belongs to this viewpoint, also take care of colors applied using "Assign color" feature which are ovverriden by viewpoint
	for (var key in this._colorMap) {
		var nodeIDArray = [];
		nodeIDArray.push(+key);
		this._viewer.model.unsetNodesFaceColor(nodeIDArray);
	}

	if (toggleStateForModelColors === false) {
		for (var key in nodeIDVsColorMap) {
			var nodeID = [];
			nodeID.push(+key);
			hwv.model.setNodesFaceColor(nodeID, nodeIDVsColorMap[nodeID]);
		}
	}
}

BCFViewpoint._getnodeIDUsingUniqueIDs = async function (uniqueIDsJsonObj, viewer) {
	var nodeIDArray = [];
	if ((uniqueIDsJsonObj.ifcGuid !== undefined)) {
		var nodeArray = viewer.model.getNodeIdsByGenericIds([uniqueIDsJsonObj.ifcGuid]);
		if ((nodeArray[0] !== null) && (nodeArray[0] !== undefined)) {
			nodeIDArray.push(nodeArray[0]);
		}
		else if (uniqueIDsJsonObj.persistanID !== undefined) {
			if ((persistentIDVsNodeArray[uniqueIDsJsonObj.persistanID] !== undefined)) {

				if ((uniqueIDsJsonObj.COG !== undefined) && (uniqueIDsJsonObj.COG !== "")) {
					var nodeArrayForPID = persistentIDVsNodeArray[uniqueIDsJsonObj.persistanID];

					//Check the exact node matching COG
					for (var ii = 0; ii < nodeArrayForPID.length; ii++) {
						var COGStringForArrayNode = await GetCOGForNode(nodeArrayForPID[ii]);
						if (COGStringForArrayNode === uniqueIDsJsonObj.COG) {
							//if body doesnt contain "body_" string, consider the body node, otherwise get its parent
							if (hwv.model.getNodeName(nodeArrayForPID[ii]).includes("body"))
								nodeArray.push(hwv.model.getNodeParent(nodeArrayForPID[ii]));
							else
								nodeArray.push(nodeArrayForPID[ii]);
						}
					}

					if ((nodeArray[0] !== null) && (nodeArray[0] !== undefined)) {
						nodeIDArray.push(nodeArray[0]);
					}
				}
				else {
					nodeIDArray = persistentIDVsNodeArray[uniqueIDsJsonObj.persistanID];
				}
			}
		}
	}
	return nodeIDArray;
}

BCFViewpoint.prototype.GetUniqueIDJsonFromNodeID = async function (nodeID) {
	var uniqueIDJsonObj = {};
	//Ifc GUID
	uniqueIDJsonObj.ifcGuid = "";
	//persistent ID
	uniqueIDJsonObj.persistanID = -111;
	//COG
	uniqueIDJsonObj.COG = "";
	if (fileType === Communicator.FileType.Ifc) {
		var nodeIDWithGenericID = GetParentNodeWithGenericID(nodeID);
		var ifcGuid = this._viewer.model.getNodeGenericId(nodeIDWithGenericID);
		if ((ifcGuid !== "") && (ifcGuid !== null)) {
			uniqueIDJsonObj.ifcGuid = ifcGuid;
		}
	}
	else if (fileType === Communicator.FileType.Revit) {
		let persistID = await GetGUIDFromNodeID(nodeID);
		if (persistID != undefined) {
			uniqueIDJsonObj.persistanID = persistID;
		}
		//COG of the child body, for reference when there are multiple nodes representing same persistent ID among different part node
		let COG = await GetCOGForNode(nodeID);
		if (COG != undefined) {
			uniqueIDJsonObj.COG = COG;
		}

	}
	return uniqueIDJsonObj;
}

BCFViewpoint.prototype._GetComponentJson = function (uniqueIDJsonObj) {
	return {
		ifc_guid: uniqueIDJsonObj.ifcGuid,
		rvt_persistentID: uniqueIDJsonObj.persistanID,
		originating_system: "Hoops Communicator",
		authoring_tool_id: "",		
		COG: uniqueIDJsonObj.COG
	}

}

BCFViewpoint._GetUniqueIDJson = function (componentJsonObj) {
	return {
		ifcGuid: componentJsonObj.ifc_guid,
		persistanID: componentJsonObj.rvt_persistentID,
		COG: componentJsonObj.COG	
	}

}


BCFViewpoint.prototype.toJSON = async function () {

	var bcfDataJson = {};
	//Camera
	var CameraHCJSONObj = this._camera.toJson();
	//perspective camera json object as per BCF schema
	var perspectiveCamJsonObj = {};
	perspectiveCamJsonObj.camera_view_point = CameraHCJSONObj.position;
	perspectiveCamJsonObj.target = CameraHCJSONObj.target;
	perspectiveCamJsonObj.camera_up_vector = CameraHCJSONObj.up;
	perspectiveCamJsonObj.width = CameraHCJSONObj.width;
	perspectiveCamJsonObj.height = CameraHCJSONObj.height;
	perspectiveCamJsonObj.nearLimit = CameraHCJSONObj.nearLimit;
	perspectiveCamJsonObj.projection = CameraHCJSONObj.projection;
	perspectiveCamJsonObj.className = CameraHCJSONObj.className;
	//fov
	//perspectiveCam.field_of_view = 
	//LookAt/Direction vector
	var lookAtVector = Communicator.Point3.subtract(Communicator.Point3.fromJson(perspectiveCamJsonObj.target), Communicator.Point3.fromJson(perspectiveCamJsonObj.camera_view_point)).normalize();
	perspectiveCamJsonObj.camera_direction = lookAtVector.toJson();

	//Set perspective cam to BCF JSON object
	bcfDataJson.perspective_camera = perspectiveCamJsonObj;

	//snapshot data
	var snapshotJsonObj = {};
	snapshotJsonObj.snapshot_type = "jpg";
	snapshotJsonObj.snapshot_data = this._viewData;
	//Set snapshot to BCF JSON object
	bcfDataJson.snapshot = snapshotJsonObj;

	//Visibility
	//var visibilityJsonObj = {};
	bcfDataJson.visibility = {};
	bcfDataJson.visibility.default_visibility = this._defaultVisibility;
	bcfDataJson.visibility.exceptions = [];
	//Visibility exceptions
	for (var ii = 0; ii < this._visibilityExceptions.length; ii++) {
		var uniqueIDJsonObj = await this.GetUniqueIDJsonFromNodeID(this._visibilityExceptions[ii]);
		var componentJsonObj = this._GetComponentJson(uniqueIDJsonObj);
		
		bcfDataJson.visibility.exceptions.push(componentJsonObj);
	}

	//Color
	//var coloringJsonObj = {};
	bcfDataJson.coloring = [];
	var nodeIDArray = Object.keys(this._colorMap);
	for (var ii = 0; ii < nodeIDArray.length; ii++) {
		if (this._colorMap.hasOwnProperty(nodeIDArray[ii])) {
			var colorJsonObj = {};
			colorJsonObj.color = {};
			var colorHC = this._colorMap[nodeIDArray[ii]];
			if (colorHC != undefined) {
				colorJsonObj.r = colorHC.r;
				colorJsonObj.g = colorHC.g;
				colorJsonObj.b = colorHC.b;
				//Hex color
				var hexColor = rgb2Hex(colorHC.r, colorHC.g, colorHC.b);
				colorJsonObj.color = hexColor;

			}
			var uniqueIDJsonObj = await this.GetUniqueIDJsonFromNodeID(Number(nodeIDArray[ii]));
			var componentJsonObj = this._GetComponentJson(uniqueIDJsonObj);
			colorJsonObj.components = [];
			colorJsonObj.components.push(componentJsonObj);

			bcfDataJson.coloring.push(colorJsonObj);
		}
	}

	//selection
	//var selectionJsonObj = {};
	bcfDataJson.selection = [];
	for (var ii = 0; ii < this._selection.length; ii++) {
		var uniqueIDJsonObj = await this.GetUniqueIDJsonFromNodeID(this._selection[ii]);
		var componentJsonObj = this._GetComponentJson(uniqueIDJsonObj);
		
		bcfDataJson.selection.push(componentJsonObj);
	}
	return bcfDataJson;
}

BCFViewpoint.fromJSON = async function (json, viewer) {
	//Create viewpoint object to fill view data from json object
	var bcfViewpt = new BCFViewpoint(viewer);

	var perspectiveCameraJson = json.perspective_camera;
	var HoopsCameraJson = {};
	HoopsCameraJson.position = perspectiveCameraJson.camera_view_point;
	HoopsCameraJson.target = perspectiveCameraJson.target;
	HoopsCameraJson.up = perspectiveCameraJson.camera_up_vector;
	HoopsCameraJson.width = perspectiveCameraJson.width;
	HoopsCameraJson.height = perspectiveCameraJson.height;
	HoopsCameraJson.nearLimit = perspectiveCameraJson.nearLimit;
	HoopsCameraJson.projection = perspectiveCameraJson.projection;
	HoopsCameraJson.className = perspectiveCameraJson.className;

	var cameraHC = Communicator.Camera.fromJson(HoopsCameraJson);
	bcfViewpt._camera = cameraHC;

	//Visibility
	var visibilityJsonObj = json.visibility;
	if (visibilityJsonObj != null) {
		bcfViewpt._defaultVisibility = visibilityJsonObj.default_visibility;
		for (var index = 0; index < visibilityJsonObj.exceptions.length; index++) {
			var uniqueIDJsonObj = this._GetUniqueIDJson(visibilityJsonObj.exceptions[index]);
			var nodeIDArray = await this._getnodeIDUsingUniqueIDs(uniqueIDJsonObj, viewer);
			for (var x in nodeIDArray) {
				bcfViewpt._visibilityExceptions.push(nodeIDArray[x]);
			}
		}
	}

	//Selection
	var selectionJsonObj = json.selection;
	if (selectionJsonObj != null) {
		for (var index = 0; index < selectionJsonObj.length; index++) {
			var uniqueIDJsonObj = this._GetUniqueIDJson(selectionJsonObj[index]);
			var nodeIDArray = await this._getnodeIDUsingUniqueIDs(uniqueIDJsonObj, viewer);
			for (var x in nodeIDArray) {
				bcfViewpt._selection.push(nodeIDArray[x]);
			}
		}
	}

	//Coloring
	var coloringJsonObj = json.coloring;
	if (coloringJsonObj != null) {
		for (var index = 0; index < coloringJsonObj.length; index++) {
			var colorHC = new Communicator.Color(coloringJsonObj[index].r, coloringJsonObj[index].g, coloringJsonObj[index].b);
			for (var ii = 0; ii < coloringJsonObj[index].components.length; ii++) {
				var componentJsonObj = coloringJsonObj[index].components[ii];
				var uniqueIDJsonObj = this._GetUniqueIDJson(componentJsonObj);
				var nodeIDArray = await this._getnodeIDUsingUniqueIDs(uniqueIDJsonObj, viewer);
				for (var x in nodeIDArray) {
					bcfViewpt._colorMap[nodeIDArray[x]] = colorHC;
				}
			}
		}
	}

	return bcfViewpt;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function BCFViewpointManager(viewer) {
	this._viewer = viewer;
	this._bcfViewpoints = [];
	this.fileReader = new FileReader();

	////////////////////
	this._current = 0;
	////////////////////
}

//Attach UI to BCFViewpointManager
BCFViewpointManager.prototype.AttachUIWithBCFVPManager = function () {
	var _self = this;
	///////////////////////////////////////////////////////////////////////////
	var idCaptureViewPoint = document.getElementById("bcf-json-capture-viewpoint-for-export");
	idCaptureViewPoint.onclick = function CaptuteViewPointclicked() {
		_self.CreateBCFViewpoint();
	}

	$("#bcf-json-file-close-button").button().on("click", function () {
		$("#save-Asite-json-dialog").hide()
	});

	//Launch the "save-Asite-json-dialog" dialog
	var bcfJSonFileSaveDiv = document.getElementById("bcf-json-file-save-div");
	bcfJSonFileSaveDiv.onclick = function LaunchExportAsiteJsonFileDialog() {
		document.getElementById("save-Asite-json-dialog").style.display = "block";
	};

	//Make dialog draggable
	$("#save-Asite-json-dialog").draggable({
		handle: ".hoops-ui-window-header"
	});

	var idExportViewPoint = document.getElementById("bcf-json-file-save-button");
	idExportViewPoint.onclick = function ExportViewPointclicked() {
		var fileName = document.getElementById("bcf-json-file-name-text").value;
		if (fileName !== "") {
			_self.ExportViewPoint(fileName);
		}
	}
	//////////////////////////////////////////////////////////////////////////////

	$("#bcf-json-open-file-close-button").button().on("click", function () {
		$("#open-Asite-json-dialog").hide()
	});
	//Launch the "open-Asite-json-dialog" dialog
	var bcfJSonFileSaveDiv = document.getElementById("bcf-json-file-open-div");
	bcfJSonFileSaveDiv.onclick = function LaunchExportAsiteJsonFileDialog() {
		document.getElementById("open-Asite-json-dialog").style.display = "block";
	};
	//Make dialog draggable
	$("#open-Asite-json-dialog").draggable({
		handle: ".hoops-ui-window-header"
	});

	$("#bcf-json-file-open").on("change", function (e) {
		//Set the onLoad function
		_self.fileReader.onload = function ExportViewPointclicked() {
			_self.ImportViewPoint();
		}
		//
		_self.fileReader.readAsText(this.files[0]);
	});
	//////////////////////////////////////////////////////////////////////////////
	var idActivateNextViewPoint_1 = document.getElementById("bcf-json-activate-next-viewpoint-openDlg");
	idActivateNextViewPoint_1.onclick = function ActivateNextViewPoint_1() {
		_self.ActivateNext();
	}
	var idActivateNextViewPoint_2 = document.getElementById("bcf-json-activate-next-viewpoint-saveDlg");
	idActivateNextViewPoint_2.onclick = function ActivateNextViewPoint_2() {
		_self.ActivateNext();
	}

	//////////////////////

}


BCFViewpointManager.prototype.CreateBCFViewpoint = function () {
	var _self = this;

	var visibility = this._viewer.model.getVisibilityState(this._viewer.model.getAbsoluteRootNode());
	//var colorMap = this._viewer.model.getNodeColorMap(this._viewer.model.getAbsoluteRootNode(), Communicator.ElementType.Faces);

	Promise.all([visibility]).then(async values => {
		var bcfViewpt = new BCFViewpoint(this._viewer);
		//set viewpoint generation source
		bcfViewpt._generationSrc = vpGenerationSource.capture;
		var camera = _self._viewer.view.getCamera();
		var selection = _self._viewer.selectionManager.exportSelectionData();

		bcfViewpt._camera = camera;
		//image data
		let image = await _self._viewer.takeSnapshot();
		var viewData = _self.GetImageDataUri(image.src);		
		bcfViewpt._viewData = viewData;

		//visibility
		var visibilityState = values[0];
		bcfViewpt._defaultVisibility = visibilityState.defaultVisibility;
		bcfViewpt._visibilityExceptions = Array.from(visibilityState.visibilityExceptions);

		//Get the coolor map info from @Assign color@ feature. Do not use HC color applying functionality.
		for (var key in nodeIDVsColorMap) {
			bcfViewpt._colorMap[key] = nodeIDVsColorMap[key];
		}

		for (var index = 0; index < selection.length; index++) {
			bcfViewpt._selection.push(selection[index].nodeId);
		}

		_self._bcfViewpoints.push(bcfViewpt);
		return bcfViewpt;
	});
}

BCFViewpointManager.prototype.ActivateNext = function () {
	if (this._bcfViewpoints.length === 0) return;

	this._current = this._current + 1;
	if (this._current >= this._bcfViewpoints.length)
		this._current = 0;

	this._bcfViewpoints[this._current].activate();

}

BCFViewpointManager.prototype.ResetViewPoint = function () {
	if (this._bcfViewpoints.length === 0) return;

	this._bcfViewpoints[this._current].Reset();
}

BCFViewpointManager.prototype.ImportViewPoint = async function () {
	var filedata = this.fileReader.result;
	var asiteJsonObj = JSON.parse(filedata);
	var BCFViewPointDataArray = asiteJsonObj.BCFData;

	if (BCFViewPointDataArray != undefined) {
		for (var ii = 0; ii < BCFViewPointDataArray.length; ii++) {
			//Convert viewpoint json to viewpoitn object
			var viewPoint = await BCFViewpoint.fromJSON(BCFViewPointDataArray[ii], this._viewer)
			//set viewpoint generation source
			viewPoint._generationSrc = vpGenerationSource.import;
			//Add viewpoint to manager collection if viewpoints
			this._bcfViewpoints.push(viewPoint);

		}
	}
}

BCFViewpointManager.prototype.ExportViewPoint = async function (fileName) {
	if (fileName !== "") {
		var count = 1;
		//iterate over the viewpoints and create json objects
		for (var ii = 0; ii < this._bcfViewpoints.length; ii++) {
			//export only captured viewpoints
			if (this._bcfViewpoints[ii]._generationSrc === vpGenerationSource.capture) {
				//Asite viewpoint json object
				var asiteBCFJson = {};
				var bcfData = [];
				asiteBCFJson.BCFData = bcfData;

				//Create file name as per viewpoint count
				var currentFileName = fileName + "_" + count + ".json";
				var currentViewPoint = this._bcfViewpoints[ii];
				var bcfDatareturn = await currentViewPoint.toJSON();
				asiteBCFJson.BCFData.push(bcfDatareturn);
				//Convert asite json data to string vefore saving to file	
				var asiteBCFJsonString = JSON.stringify(asiteBCFJson);
				//Save the file
				var blob = new Blob([asiteBCFJsonString], { type: "application/json" });
				saveAs(blob, currentFileName);
				count++;
			}
		}
		//flush the viewpoints which were captured from export viewpoint UI
		var tempbcfViewpoints = [];
		for (var ii = 0; ii < this._bcfViewpoints.length; ii++) {
			if (this._bcfViewpoints[ii]._generationSrc === vpGenerationSource.import) {
				tempbcfViewpoints.push(this._bcfViewpoints[ii]);
			}
		}
		this._bcfViewpoints = tempbcfViewpoints;
	}
}


BCFViewpointManager.prototype.GetImageDataUri = function (data) {
	var image = new Image();
	image.src = data;
	var canvas = document.createElement('canvas');
	canvas.width = image.naturalWidth; // or 'width' if you want a special/scaled size
	canvas.height = image.naturalHeight; // or 'height' if you want a special/scaled size

	canvas.getContext('2d').drawImage(image, 0, 0);

	//get as Data URI
	var base64JpegData = canvas.toDataURL("image/jpeg");
	return base64JpegData;
}


