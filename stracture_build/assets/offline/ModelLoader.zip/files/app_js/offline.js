var nCircle = {};
var totalNumberOfModels = 0;
var models = [];
var _models = [];
var rootNode = -1;
var mode = 1;
var revisionIdVsStartingNodeMap = new Map();
var revisionIdVsEndingNodeMap = new Map();

var bFirstModelLoaded = false;

var defaultCamera = {
  "position": {
      "x": -52878.1932246269,
      "y": -22903.766197415538,
      "z": 33399.50497348295
  },
  "target": {
      "x": -44.93355800000154,
      "y": -1557.7447610517877,
      "z": 21287.499999999996
  },
  "up": {
      "x": 0.19277235636755818,
      "y": 0.07788508370153652,
      "z": 0.9781476025413056
  },
  "width": 58255.527259584414,
  "height": 58255.527259584414,
  "projection": 1,
  "nearLimit": 0.01,
  "className": "Communicator.Camera"
};

function _base64ToUint8Array(base64) {
  var binary_string = window.atob(base64);
  var len = binary_string.length;
  //console.log("base64 buffer len : ", len);
  var bytes = new Uint8Array(len);
  for (var i = 0; i < len; i++) {
    bytes[i] = binary_string.charCodeAt(i);
  }
  return bytes;
}

function getBase64(file) {
  var reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = function () {
    //console.log("DataURL:");
    //console.log(reader.result);
  };
  reader.onerror = function (error) {
    //console.log("Error: ", error);
  };
}

function LoadFederatedEx() {
  ++loadedModels;
  console.log(`Loaded Models in LoadFederatedEx : ${loadedModels}  at Time : ${Date.now()}`)
  window.flutter_inappwebview.callHandler("getModelsLoaded", loadedModels);

  if(mode)
    revisionIdVsEndingNodeMap.set(models[loadedModels - 1].split('/').pop(),hwv.model.getLowestAvailableNodeId());


  let _model = _models.shift();


  if (_model == undefined) {
    bDeactivateStreaming = true;

    setTimeout(()=>{
      if(bDeactivateStreaming){
        window.flutter_inappwebview.callHandler("streamingDeactivated");
        bDeactivateStreaming = false;
      }
    }, 5000)

    return;
  } else {

    if (mode) {
      revisionIdVsStartingNodeMap.set(_model.split('/').pop(),hwv.model.getLowestAvailableNodeId());

      hwv.model
        .loadSubtreeFromModel(hwv.model.getAbsoluteRootNode(), _model.trim())
        .then(
          (nodeId) => {
            console.log(`Loaded Model : ${_model} at nodeId : ${nodeId}`);
            LoadFederatedEx();
          },
          (error) => {
            console.log(
              `Error Occured while Loading Model : ${_model} + ${error}`
            );
      
          }
        );
    } else {
      hwv.model
        .loadSubtreeFromScsBuffer(
          hwv.model.getAbsoluteRootNode(),
          _base64ToUint8Array(_model.trim())
        )
        .then(
          (nodeId) => {
            console.log(`Loaded Model at nodeId : ${nodeId}`);

            //recurse
            LoadFederatedEx();
          },
          (error) => {
            console.log(
              `Error Occured while Loading Model : ${_model} + ${error}`
            );

          }
        );
    }
  }
}


var hwv = null;
var ui = null;
var md = new MobileDetect(window.navigator.userAgent);

function LoadOnlineModel(SC_MODEL_DATA2, url) {
  // let array = Array.from(SC_MODEL_DATA2);

  models = SC_MODEL_DATA2.split(",");
  _models = SC_MODEL_DATA2.split(",");
  console.log(SC_MODEL_DATA2);
  loadedModels = 0;
  console.log(`Loaded Models in LoadOnlineModel : ${loadedModels}  at Time : ${Date.now()}`)

  let hc_options = {};

  if (url) {
    revisionIdVsStartingNodeMap.set(_models[0].split('/').pop(),0);
    hc_options = {
      containerId: "viewerContainer",
      calculateDefaultViewAxes : false,
      model: _models.shift(),
      endpointUri: url,
      streamingMode: Communicator.StreamingMode.Interactive,
      rendererType: Communicator.RendererType.Client,
      streamCutoffScale: 2.0,
      memoryLimit: 256,
      boundingPreviewMode: Communicator.BoundingPreviewMode.None,
    };
  } else {
    hc_options = {
      containerId: "viewerContainer",
      buffer: _base64ToUint8Array(_models.shift()),
      calculateDefaultViewAxes : false,
    };
  }



  try {
    mode = url == undefined ? 0 : 1;
    hwv = new Communicator.WebViewer(hc_options);

    window.onresize = function (event) {
      hwv.resizeCanvas();
    };

    var _screenConfiguration = Communicator.ScreenConfiguration.Mobile;

    var uiConfig = {
      containerId: "content",
      screenConfiguration: _screenConfiguration,
      showModelBrowser: false,
      showToolbar: false,
    };

    ui = new Communicator.Ui.Desktop.DesktopUi(hwv, uiConfig);
    ui._contextMenu.hide();

    hwv.setClientTimeout(24 * 60, 23 * 60);

    document.body.addEventListener(
      "touchmove",
      function (e) {
        if (e.target == document.getElementsByClassName("mobile")[0]) {
          e.preventDefault();
        }
      },
      { useCapture: true, passive: false }
    );

    document.body.addEventListener(
      "touchstart",
      function (e) {
        if (e.target == document.getElementsByClassName("mobile")[0]) {
          e.preventDefault();
        }
      },
      { useCapture: true, passive: false }
    );

    document.body.addEventListener(
      "touchend",
      function (e) {
        if (e.target == document.getElementsByClassName("mobile")[0]) {
          e.preventDefault();
        }
      },
      { useCapture: true, passive: false }
    );

    //Call this method from nCircle_Implementation.js to execute functionality.
    nCircleMain(hwv, ui);

    hwv.start();

    hwv.view.getAxisTriad().disable();
  } catch (error) {
    console.log(error);
  }
}

nCircle.Model = (function(){

  var fileMap = new Map();
  var modelQueue = [];

  return {
    loadFile: function(fileDetails){

      if(fileMap.has(fileDetails.fileName))
        return;

      if(hwv == null){
        fileMap.set(fileDetails.fileName,0);
        LoadOnlineModel(fileDetails.scsBuffer)
        return;
      }

      if(!bFirstModelLoaded){
        setTimeout(()=>{
          let parentNode = hwv.model.createNode(fileDetails.fileName);
          hwv.model.loadSubtreeFromScsBuffer(parentNode,_base64ToUint8Array(fileDetails.scsBuffer)).then(()=>{
            ++loadedModels;
            console.log(`Loaded Models : ${loadedModels}  at Time : ${Date.now()}`)
            window.flutter_inappwebview.callHandler("getModelsLoaded", loadedModels);

          });
          fileMap.set(fileDetails.fileName,parentNode);
        },1000);
      }
      else{
        let parentNode = hwv.model.createNode(fileDetails.fileName);
        hwv.model.loadSubtreeFromScsBuffer(parentNode,_base64ToUint8Array(fileDetails.scsBuffer)).then(()=>{
          ++loadedModels;
          console.log(`Loaded Models : ${loadedModels}  at Time : ${Date.now()}`)
          window.flutter_inappwebview.callHandler("getModelsLoaded", loadedModels);

        });
        fileMap.set(fileDetails.fileName,parentNode);
      }


      //let rootNode = hwv.model.getAbsoluteRootNode();
    
    },

    deleteFile : function(fileName){
      if(fileMap.has(fileName)){

      if(fileMap.size == 1){
        this.clear();
        return;
      }

      hwv.model.deleteNode(fileMap.get(fileName));
      --loadedModels;
      console.log(`Loaded Models after Delete : ${loadedModels}  at Time : ${Date.now()}`)
      window.flutter_inappwebview.callHandler("getModelsDeleted", "Unloading Models");
      //window.flutter_inappwebview.callHandler("getModelsLoaded", loadedModels);
      fileMap.delete(fileName);
    }
    },

    clear : function(){
      hwv.model.clear();
      fileMap.clear();
      loadedModels = 0;
      console.log(`Loaded Models after Clear : ${loadedModels}  at Time : ${Date.now()}`)
      //window.flutter_inappwebview.callHandler("getModelsLoaded", loadedModels);
      window.flutter_inappwebview.callHandler("getModelsDeleted", "Unloading Models");


    },

    getFileMap(){
      return fileMap;
    },
  }


})();