"use strict";
/// <reference path= "../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "Field.Calibration.ts" />
/// <reference path = "Field.PageCalibration.ts" />
var Field;
(function (Field) {
    var Calibration;
    (function (Calibration) {
        class CalibrationManager {
            /**
             *
             * @param viewer
             */
            constructor(viewer) {
                this.isNavigationToolActive = false;
                this.matrix3 = math.matrix();
                this.matrix2 = math.matrix();
                this.viewer = viewer;
                this.navigationTool = new NavigationTool(this.viewer);
                this.pageNaviagtionTool = new Calibration.PageNavigationTool();
                this.fPoint3 = null;
                this.sPoint3 = null;
                this.fPoint2 = null;
                this.sPoint2 = null;
                /* Setup Event Listeners */
                this.registerCustomEventListeners(this);
            }
            /**
             *
             */
            enableNavigation() {
                this.isNavigationToolActive = true;
                this.navigationTool.enableTool();
                this.pageNaviagtionTool.enableTool();
            }
            getNavigationOperatorStatus() {
                return this.isNavigationToolActive;
            }
            /**
             *
             */
            disableNavigation() {
                this.isNavigationToolActive = false;
                this.navigationTool.disableTool();
                this.pageNaviagtionTool.disableTool();
            }
            /**
             *
             * @returns
             */
            getPageNavigationTool() {
                return this.pageNaviagtionTool;
            }
            /**
             *
             * @returns
             */
            getNavigationTool() {
                return this.navigationTool;
            }
            /**
             *
             * @returns
             */
            getCalibrationPoints() {
                if (!(this.fPoint2 && this.sPoint2 && this.fPoint3 && this.sPoint3)) {
                    throw new Error("getPointDetial called before all points were set");
                }
                const pointDetail = {
                    fPoint2: this.fPoint2,
                    sPoint2: this.sPoint2,
                    fPoint3: this.fPoint3,
                    sPoint3: this.sPoint3
                };
                return pointDetail;
            }
            /**
             *
             * @param pointDetail
             */
            setCalibrationPoints(pointDetail) {
                this.fPoint2 = pointDetail.fPoint2;
                this.sPoint2 = pointDetail.sPoint2;
                this.fPoint3 = pointDetail.fPoint3;
                this.sPoint3 = pointDetail.sPoint3;
                const event = new CustomEvent("onComputeCalibration");
                window.dispatchEvent(event);
                if (!this.isNavigationToolActive) {
                    this.enableNavigation();
                }
            }
            /**
             *
             * @param z
             */
            setHeight(z) {
                this.navigationTool.setHeight(z);
            }
            /**
             *
             * @param self
             */
            registerCustomEventListeners(self) {
                window.addEventListener('onComputeCalibration', (event) => {
                    if (!(self.fPoint2 && self.sPoint2 && self.fPoint3 && self.sPoint3)) {
                        throw Error("Calibration Points not Set");
                    }
                    const Matrices = Calibration.getCalibrationMatrices(self.fPoint3, self.sPoint3, self.fPoint2, self.sPoint2);
                    const m = Matrices[0];
                    const n = Matrices[1];
                    self.matrix2 = m;
                    self.matrix3 = n;
                    console.log('Calibration Computed');
                    self.navigationTool.setMatrix(n);
                    self.pageNaviagtionTool.setMatrix(m);
                    this.viewer.view.setProjectionMode(Communicator.Projection.Perspective);
                });
            }
        }
        Calibration.CalibrationManager = CalibrationManager;
        class NavigationTool {
            /**
             *
             * @param viewer
             */
            constructor(viewer) {
                this.matrix = math.matrix();
                this.viewer = viewer;
                const self = this;
                this.height = 0;
                this.onCameraUpdateWrapper = function (camera) {
                    self.onCameraUpdate(camera);
                };
                this.onLocationUpdateWrapper = function (event) {
                    const position = event.detail.position;
                    self.onLocationUpdate(position);
                };
            }
            /**
             *
             * @param camera
             */
            onCameraUpdate(camera) {
                const event = new CustomEvent("onCameraUpdate", { detail: { camera: camera } });
                window.dispatchEvent(event);
            }
            /**
             *
             */
            enableTool() {
                this.viewer.setCallbacks({ camera: this.onCameraUpdateWrapper });
                window.addEventListener("onLocationUpdate", this.onLocationUpdateWrapper);
            }
            /**
             *
             */
            disableTool() {
                this.viewer.unsetCallbacks({ camera: this.onCameraUpdateWrapper });
                window.removeEventListener("onLocationUpdate", this.onLocationUpdateWrapper);
            }
            /**
             *
             * @param matrix
             */
            setMatrix(matrix) {
                this.matrix = matrix;
            }
            /**
             *
             * @param height
             */
            setHeight(height) {
                this.height = height;
            }
            /**
             *
             * @param point
             */
            onLocationUpdate(point) {
                const position = Calibration.transform(this.matrix, point);
                position.z = this.height;
                this.updateCamera(position);
            }
            /**
             *
             * @param position
             */
            updateCamera(position) {
                const camera = this.viewer.view.getCamera();
                const pos = camera.getPosition();
                const target = camera.getTarget();
                const deltaPosition = Communicator.Point3.subtract(position, pos);
                const newTarget = Communicator.Point3.add(target, deltaPosition);
                const upVector = new Communicator.Point3(0, 0, 1);
                const lookAtVector = Communicator.Point3.subtract(newTarget, position).normalize();
                const rightVector = Communicator.Point3.cross(lookAtVector, upVector).normalize();
                const newUpVector = Communicator.Point3.cross(rightVector, lookAtVector).normalize();
                camera.setPosition(position);
                camera.setTarget(newTarget);
                camera.setUp(newUpVector);
                this.viewer.view.setCamera(camera);
            }
        }
        Calibration.NavigationTool = NavigationTool;
    })(Calibration = Field.Calibration || (Field.Calibration = {}));
})(Field || (Field = {}));
