"use strict";
/// <reference path= "../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "../../node_modules/mathjs/types/index.d.ts" />
var Field;
(function (Field) {
    var Calibration;
    (function (Calibration) {
        function normalize(point) {
            return new Communicator.Point2(point.x / point.length(), point.y / point.length());
        }
        Calibration.normalize = normalize;
        /**
         *
         * @param point point which is to be rotated
         * @param pivot pivot point around which input point is to be rotated
         * @param angle Angle in Degrees
         * @returns rotated point
         */
        function rotatePointAroundPivot(point, pivot, angle) {
            const rpoint = Communicator.Point2.zero();
            const radians = angle * Math.PI / 180;
            rpoint.x = pivot.x + ((point.x - pivot.x) * Math.cos(radians)) - ((pivot.y - point.y) * Math.sin(radians));
            rpoint.y = pivot.y + ((pivot.y - point.y) * Math.cos(radians)) - ((point.x - pivot.x) * Math.sin(radians));
            return rpoint;
        }
        Calibration.rotatePointAroundPivot = rotatePointAroundPivot;
        /**
         *
         * @param srcPoint1
         * @param srcPoint2
         * @param srcPoint3
         * @param destPoint1
         * @param destPoint2
         * @param destPoint3
         * @returns Affine Transformation Matrix that transform Source Points to Destination Points
         */
        function getAffineTransformation(srcPoint1, srcPoint2, srcPoint3, destPoint1, destPoint2, destPoint3) {
            const srcMatrix = math.matrix([
                [srcPoint1.x, srcPoint2.x, srcPoint3.x],
                [srcPoint1.y, srcPoint2.y, srcPoint3.y],
                [1, 1, 1],
            ]);
            const destMatrix = math.matrix([
                [destPoint1.x, destPoint2.x, destPoint3.x],
                [destPoint1.y, destPoint2.y, destPoint3.y],
            ]);
            const srcInvMatrix = math.inv(srcMatrix);
            if (srcInvMatrix === null) {
                throw new Error("Cannot Invert Src Matrix");
            }
            const transformMatrix = math.multiply(destMatrix, srcInvMatrix);
            /* 2 x 3 Affine Matrix */
            return transformMatrix;
        }
        Calibration.getAffineTransformation = getAffineTransformation;
        /**
         *
         * @param m Transformation Matrix
         * @param point Point to be Transformed
         * @returns Transformed Point
         */
        function transform(m, point) {
            const t = math.multiply(m, [[point.x], [point.y], [1]]);
            return new Communicator.Point3(t.get([0, 0]), t.get([1, 0]), 1);
        }
        Calibration.transform = transform;
        /**
         *
         * @param fPoint3
         * @param sPoint3
         * @param fPoint2
         * @param sPoint2
         * @returns
         */
        function getCalibrationMatrices(fPoint3, sPoint3, fPoint2, sPoint2) {
            const rPoint3 = rotatePointAroundPivot(sPoint3, fPoint3, -90);
            const rPoint2 = rotatePointAroundPivot(sPoint2, fPoint2, 90);
            const m = getAffineTransformation(fPoint3, sPoint3, rPoint3, fPoint2, sPoint2, rPoint2);
            const n = getAffineTransformation(fPoint2, sPoint2, rPoint2, fPoint3, sPoint3, rPoint3);
            return [m, n];
        }
        Calibration.getCalibrationMatrices = getCalibrationMatrices;
    })(Calibration = Field.Calibration || (Field.Calibration = {}));
})(Field || (Field = {}));
