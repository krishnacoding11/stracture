"use strict";
var Field;
(function (Field) {
    var Calibration;
    (function (Calibration) {
        class PageNavigationTool {
            /**
             *
             * @param viewer
             */
            constructor() {
                this.matrix = math.matrix([]);
                this.target = null;
                const self = this;
                this.onCameraUpdateWrapper = function (event) {
                    const camera = event.detail.camera;
                    self.onCameraUpdate(Communicator.Point2.fromPoint3(camera.getPosition()), Communicator.Point2.fromPoint3(camera.getTarget()));
                };
            }
            /**
             *
             * @param position
             * @param target
             */
            onCameraUpdate(position, target) {
                const p = Communicator.Point2.fromPoint3(Calibration.transform(this.matrix, position));
                const t = Communicator.Point2.fromPoint3(Calibration.transform(this.matrix, target));
                /* Update Target */
                this.target = t;
                this.updateMarkup(p, this.target);
            }
            updateMarkup(position, target) {
                const angle = this.getImageRotation(position, target);
                const cursorString = `${position.x} ${position.y} ${angle}`;
                console.log(cursorString);
                window.flutter_inappwebview.callHandler('getCalibrationPoints', cursorString);
            }
            /**
             *
             * @param matrix
             */
            setMatrix(matrix) {
                this.matrix = matrix;
            }
            /**
             *
             * @param position
             */
            setPosition(position) {
                const event = new CustomEvent("onLocationUpdate", { detail: { position: position } });
                window.dispatchEvent(event);
            }
            /**
             *
             */
            enableTool() {
                window.addEventListener('onCameraUpdate', this.onCameraUpdateWrapper);
            }
            /**
             *
             */
            disableTool() {
                window.removeEventListener('onCameraUpdate', this.onCameraUpdateWrapper);
            }
            /**
             *
             * @param position
             * @param target
             * @returns
             */
            getImageRotation(position, target) {
                const front = new Communicator.Point3(target.x, target.y, 0).subtract(new Communicator.Point3(position.x, position.y, 0));
                const up = new Communicator.Point3(position.x, position.y * 1000, 0).subtract(new Communicator.Point3(position.x, position.y, 0));
                const dot = Communicator.Point3.dot(front, up);
                const det = front.x * up.y - front.y * up.x;
                return (Math.atan2(det, dot) * 180 / Math.PI) + 180;
            }
            /**
             *
             * @param point
             * @returns
             */
            getPoint3FromPoint2(point) {
                return new Communicator.Point3(point.x, point.y, 0);
            }
        }
        Calibration.PageNavigationTool = PageNavigationTool;
    })(Calibration = Field.Calibration || (Field.Calibration = {}));
})(Field || (Field = {}));
