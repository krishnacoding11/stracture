"use strict";
/// <reference path= "../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "./FPin/FPinMarkup.ts" />
var Field;
(function (Field) {
    Field.Event = {
        TPinCreated: 'onTPinCreated'
    };
    class PinManager {
        constructor(viewer) {
            this.fileType = Communicator.FileType.Ifc;
            this.time = Date.now();
            this.activePinCount = 0;
            this.pinMap = {};
            this.uniqueIdMap = {};
            this.viewer = viewer;
            this.measureManager = this.viewer.measureManager;
            this.pinOperator = new Field.Operator.TPinOperator(this.viewer);
            this.pinOperatorId = this.viewer.operatorManager.registerCustomOperator(this.pinOperator);
            const fType = this.viewer.model.getModelFileTypeFromNode(this.viewer.model.getNodeChildren(this.viewer.model.getAbsoluteRootNode())[0]);
            if (fType != null)
                this.fileType = fType;
            this.onPinCreatedCallbackFn = (event) => {
                console.log(event.detail);
            };
        }
        rangeSearch(kdtree, point, distance = 1000) {
            if (!kdtree)
                return [];
            if (!kdtree.value)
                return [];
            const nodes = [];
            if (Communicator.Point3.distance(kdtree.value.position, point) < distance) {
                nodes.push(kdtree.value);
            }
            const left = this.rangeSearch(kdtree.left, point, distance);
            const right = this.rangeSearch(kdtree.right, point, distance);
            return nodes.concat(left).concat(right);
        }
        /* Simple Median Split KDTree */
        makeTree(points, axis = 0) {
            if (!points.length)
                return null;
            if (points.length == 1) {
                return {
                    value: points[0],
                    axis: axis,
                    left: null,
                    right: null
                };
            }
            points.sort((a, b) => {
                if (axis == 0)
                    return a.position.x - b.position.x;
                else if (axis == 1)
                    return a.position.y - b.position.y;
                else
                    return a.position.z - b.position.z;
            });
            const medianIndex = Math.floor((points.length - 1) / 2);
            const median = points[medianIndex];
            const l = points.slice(0, medianIndex);
            const r = points.slice(medianIndex + 1, points.length);
            const node = {
                value: median,
                axis: axis,
                left: this.makeTree(l, (axis + 1) % 3),
                right: this.makeTree(r, (axis + 1) % 3)
            };
            return node;
        }
        setPinCallback(pinCallbackFn) {
            this.onPinCreatedCallbackFn = pinCallbackFn;
        }
        async setPins(points) {
            const pinObjects = points.map((point) => {
                return {
                    position: point,
                    uuid: Communicator.UUID.create()
                };
            });
            const tree = this.makeTree(pinObjects);
            const includeMap = new Map();
            pinObjects.forEach((pinObj) => {
                ++this.activePinCount;
                if (includeMap.has(pinObj.uuid))
                    return;
                const result = this.rangeSearch(tree, pinObj.position, 3000);
                /* exclude already included pins */
                const filteredRes = result.filter((res) => {
                    return !includeMap.has(res.uuid);
                });
                /* update include map */
                filteredRes.forEach((res) => {
                    includeMap.set(res.uuid, true);
                });
                if (filteredRes.length == 1) {
                    const pin = new Field.Markup.FPinMarkup(this.viewer);
                    pin.setPosition(filteredRes[0].position);
                    pin.setSize(new Communicator.Point2(60, 60));
                    this.measureManager.addMeasurement(pin);
                    this.measureManager.finalizeMeasurement(pin);
                }
                else {
                    const pin = new Field.Markup.SPinMarkup(this.viewer);
                    filteredRes.forEach((res) => {
                        pin.insertPin({ position: res.position });
                    });
                    this.measureManager.addMeasurement(pin);
                    this.measureManager.finalizeMeasurement(pin);
                }
            });
        }
        getActivePinCount() {
            return this.activePinCount;
        }
        clear() {
            Object.keys(this.pinMap).forEach((nodeId) => {
                const pinMarkup = this.pinMap[nodeId];
                this.viewer.measureManager.removeMeasurement(pinMarkup);
                delete this.pinMap[nodeId];
            });
            this.activePinCount = 0;
        }
        enablePinOperator() {
            this.viewer.operatorManager.set(this.pinOperatorId, 1);
            window.addEventListener(Field.Event.TPinCreated, this.onPinCreatedCallbackFn);
        }
        disablePinOperator() {
            this.viewer.operatorManager.set(Communicator.OperatorId.Select, 1);
            window.removeEventListener(Field.Event.TPinCreated, this.onPinCreatedCallbackFn);
        }
        getPinOperator() {
            return this.pinOperator;
        }
        /**
         * @hidden
         */
        async makeUniqueIdMap(clearMap = false) {
            //Clear the map if clearMap is true
            if (clearMap)
                this.uniqueIdMap = {};
            let nodeArray = [];
            const rootID = this.viewer.model.getAbsoluteRootNode();
            this.traverse(rootID, nodeArray);
            const nodeArrayLength = nodeArray.length;
            //Get properties for nodeArray
            const nodeChunkArray = [];
            const chunkSize = 30000;
            for (let index = 0; index < nodeArrayLength; index += chunkSize) {
                nodeChunkArray.push(nodeArray.slice(index, index + chunkSize));
            }
            this.time = Date.now();
            await this.resolveArray(nodeChunkArray);
        }
        /**
         * @hidden
         */
        async resolveArray(nodeArray) {
            const chunk = nodeArray.shift();
            if (!chunk)
                throw Error();
            const promiseArray = [];
            for (const node in chunk) {
                let promiseprop = this.viewer.model.getNodeProperties(chunk[node]).catch(error => {
                    return error;
                });
                promiseArray.push(promiseprop);
            }
            const promiseResolveArray = await Promise.all(promiseArray);
            if (!promiseResolveArray)
                throw Error();
            for (const nodeID in chunk) {
                if (promiseResolveArray[nodeID] !== undefined && promiseResolveArray[nodeID] !== null) {
                    const promiseResolvedNode = promiseResolveArray[nodeID];
                    if (!promiseResolvedNode)
                        throw Error();
                    let key = "persistentId";
                    if (this.fileType == Communicator.FileType.Ifc) {
                        key = promiseResolvedNode.TYPE + "/GlobalId";
                    }
                    const uniqueId = promiseResolvedNode[key];
                    if (uniqueId != undefined) {
                        if (this.uniqueIdMap[uniqueId] != null)
                            this.uniqueIdMap[uniqueId].push(chunk[nodeID]);
                        else {
                            const nodeArr = [];
                            nodeArr.push(chunk[nodeID]);
                            this.uniqueIdMap[uniqueId] = nodeArr;
                        }
                    }
                }
            }
            console.log(`Completed In : ${(Date.now() - this.time) / 1000} seconds`);
            const event = new CustomEvent("pinReady");
            window.dispatchEvent(event);
        }
        /**
         * @hidden
         */
        traverse(nodeId, nodeArray) {
            const type = this.viewer.model.getNodeType(nodeId);
            if (type === Communicator.NodeType.Part ||
                type === Communicator.NodeType.PartInstance ||
                type === Communicator.NodeType.AssemblyNode ||
                type === Communicator.NodeType.Body ||
                type === Communicator.NodeType.BodyInstance) {
                var children = this.viewer.model.getNodeChildren(nodeId);
                for (var i = 0, len = children.length; i < len; i++) {
                    //Collect properties promise for nodes
                    nodeArray.push(children[i]);
                    this.traverse(children[i], nodeArray);
                }
            }
        }
    }
    Field.PinManager = PinManager;
})(Field || (Field = {}));
