"use strict";
/// <reference path= "../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "./PinElement.ts" />
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        /** @hidden */
        class PinMarkup extends Communicator.Markup.Measure.MeasureMarkup {
            constructor(viewer) {
                super(viewer);
                this.uniqueId = Communicator.UUID.create();
                this.position = Communicator.Point3.zero();
                this.size = new Communicator.Point2(60, 60);
                this.imageURL = '';
                this.nodeId = 0;
                this.pinElementId = null;
                this.className = "Field.Markup.PinMarkup";
                this._callbacks = {
                    selectionArray: () => {
                        this.onDeselect();
                    },
                };
                this._viewer.setCallbacks(this._callbacks);
            }
            setNodeId(nodeId) {
                this.nodeId = nodeId;
            }
            setPosition(point) {
                this.position.assign(point);
            }
            getPosition() {
                return this.position.copy();
            }
            setSize(size) {
                this.size.assign(size);
                this.pinElement.setSize(size);
            }
            getSize() {
                return this.size.copy();
            }
            setImage(text) {
                this.imageURL = text;
                this.pinElement.setImage(text);
            }
            getImage() {
                return this.imageURL;
            }
            setOpacity(opacity) {
                this.pinElement.setOpacity(opacity);
            }
            getOpacity() {
                return this.pinElement.getOpacity();
            }
            draw() {
                if (this._behindView)
                    return;
                const screenPos = Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(this.position));
                this.pinElement.setPosition(screenPos);
                if (this.pinElementId === null) {
                    this.pinElementId = this._viewer.markupManager.addMarkupElement(this.pinElement.getImageArea());
                    this._viewer.markupManager.refreshMarkup();
                }
            }
            hit(point) {
                return this.hitWithTolerance(point, 0);
            }
            hitWithTolerance(point, pickTolerance) {
                const element = this.pinElement.getImageArea();
                const screenPos = new Communicator.Point2(parseFloat(element.style.left || "0"), parseFloat(element.style.top || "0"));
                const size = new Communicator.Point2(parseFloat(element.style.width || "0"), parseFloat(element.style.height || "0"));
                return Communicator.Util.isPointInRect2d(point, screenPos, size, pickTolerance);
            }
            getClassName() {
                return this.className;
            }
            remove() {
                if (this.pinElementId) {
                    this._viewer.markupManager.removeMarkupElement(this.pinElementId);
                    this.pinElementId = null;
                }
                if (this._callbacks !== null) {
                    this._viewer.unsetCallbacks(this._callbacks);
                    this._callbacks = null;
                }
                super.remove();
            }
            // Serialization methods
            /**
             * Creates an object ready for JSON serialization.
             * @returns The prepared object.
             */
            async toJson() {
                return await this._toJson();
            }
            async _toJson() {
                const fileType = this._viewer.model.getModelFileTypeFromNode(this.nodeId);
                const nodeName = this._viewer.model.getNodeName(this.nodeId);
                const nodeData = await this._viewer.model.getNodeProperties(this.nodeId);
                if (nodeName == null) {
                    throw Error("invalid node id : Node Name not Found");
                }
                if (nodeData == null)
                    throw Error("invalid node id : Node Data not Found");
                let guid = '';
                let objectType = '';
                if (fileType == Communicator.FileType.Ifc) {
                    const genericId = this._viewer.model.getNodeGenericId(this.nodeId);
                    if (genericId != null)
                        guid = genericId;
                }
                else if (nodeData.persistentId)
                    guid = nodeData.persistentId.trim();
                if (nodeData.TYPE)
                    objectType = nodeData.TYPE;
                else if (nodeData['Other/Family and Type'])
                    objectType = nodeData['Other/Family and Type'];
                else
                    throw new Error('Invalid node id : nodeProperties.TYPE not Found');
                const archive = {
                    uniqueId: this.uniqueId,
                    position: this.position.toJson(),
                    image: this.imageURL,
                    nodeId: this.nodeId,
                    guid: guid,
                    nodeName: nodeName,
                    objectType: objectType,
                    fileType: fileType == Communicator.FileType.Ifc ? 1 : 2,
                };
                return archive;
            }
        }
        PinMarkup.className = "Field.Markup.Pin";
        Markup.PinMarkup = PinMarkup;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
