"use strict";
/// <reference path= "../../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "../PinElement.ts" />
/// <reference path= "./SPinElement.ts" />
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class SPinMarkup extends Markup.PinMarkup {
            constructor(viewer) {
                super(viewer);
                this.prevMouseDownTime = Date.now();
                this.isDoubleClick = false;
                this.pinArray = [];
                this.bHidden = true;
                this.pinBounding = new Communicator.Box();
                this.pinBounding.max = new Communicator.Point3(Number.MIN_SAFE_INTEGER, Number.MIN_SAFE_INTEGER, Number.MIN_SAFE_INTEGER);
                this.pinBounding.min = new Communicator.Point3(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
                this.imageURL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAYAAADhu0ooAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAVkSURBVGhD7VhLbBtFGN7Z9SOlbWJZTaCHtoSHEAWJShyqIBAWB25IBSSkigNcOcOlEiD1WnHkyAFOFC5UFY8iJFQOBYREi0ShdShJSgOJndjBSbxrex/D/413krXr2rs7TmOk/VZfZmd2Z3a++R8zsZYgQYIECRIkSJAgQYIECUYJzC9jo/DZidw+VytohvaE3xQJXNMWHdv77utXzt/wm3YEykKf//SF6WzaeJcm/LrfFA2cX+caP/3FS+c/Qa3dOHzofhkXemu9ZXCPq4xzH3fZQSoxhvLC3wkqA6OvMfNe4aH8ofG3WUZ/td0cDWRNR3P5WbfpfayndZvoudzlOmeceXqHhR1HW7hw8tyCX40EFaEGMf3kOzMP33v0wCl9zDjZbo4OzrUl+vMXY8wWdcaFTJpdh1DP0z768uVzH/rVSIjrclggMNWqNTOe46VEa0wwph1kOjtOIz4NMo09Q+Wz9KgQJOmfpjKWi6vElhDqmE6ac6UYDQ14NBXwJLnQoaEqlD7u6eRgAz9KVhJXEKKFzKnT1f2sFzxbeE6aGHneqpZglHHJo3jfWUpBgr4gWW5F4WCdmue4EJologzRYxvKLieCc4BFKbNSrrl9ixTtdHl0UTEQvkUzROm+oaEsFBb1byMBAoPorveCv19La95doTQ/+mA8sVFBX5EC5fdCf1dZqIO9jrEQjteJrRiNAlcsaJChoSyU9j/YNJTQbnGoxxIMP9pmKKi7LhDyc8E4DBOTw8RwhIaAyK7c6xCI+0iCt2cb2X2VhYqsG+LAMBTQLhQAVij0Kg3dom7TqTWqjTlr1Sp20py1KuYfVsW6gee26VRoc3X9bjuOuJZAPxzF9j7y2mNHjxQOv5XJZU/ggblcv1q+vHzJKjfWURcwhIfirMcoeYlr6tjU4xMP5o7raWO//9ZA0Njvf/vGN2fotoYq0UF7GOCEEQcQir6ZA8emJnPTEzPGWOpRPGisWrPzX81///fFWwtrxWqJWF67RrwuylL190qp+lulPH5kIrvv0P77jYwxjn5hYJv2T/Ofz12i2wYRIjuduQ+UXVccAQMga7nM0DERrHiduNlFtJlW1VpxGs6/dK+C0B6pbNE8LPrAxFNGtm1Re9P+s3K18vPm4sYKVYUoouUTC9Ak2rrB7PSelGlv2Ev1pfqs2WbxNpbq1xor1q/0f+/l9ZvrPy7/8M+cP04kiw4nRp87/GZmPPsiHlgl80LxbPGDxYs38ZMHRCHhyOwID4ITjBHvISI+9xDxH0mvgzr6QRAWC3FZIWIBEf9YuNAxOpysG0jyzGBOdjwFS8It14jVHkQ7Jr5BxLvS8r0IQViwFhE/tcCKobcViaFvLxSjnpZKYWKYJGISYraYz+dhDYgEsRiDiPfQB4sBl40ldieSkUeZFC4FC4AQLdmoVqsyUUE4hMDCq12Ee4KyjncgGP0wZjAcQkFZaK8gSWfJqu1Vx4TkvazLRYBLwlJwYxl73QLlPYRKq6Ivxri7QmMAE4Rg6d6w7J3cWLo43oFI9Nkd1xXoypV2/18dMEFpXUwargzCwjL5BCmfxxYJKAt1rabr0PnWbbnLoN2ya16zNSjtB8VKdw7e9yKexRIJqBwYsEhpykZZOv45rQ37llk2f6kt1K6Ur5TmrJIFd5MW2HX0c7F+QD8k3L3EnE/cox2xhASDGIMrQmwsKwwTqq4La8GtgtsIhMHNIG7XBUrEFSpFQBBEyr1RnnCak5OTIyU2rusC7Rhtn1VxdsU9IK0L8dK6uw4VoeiLZIZYhUiZ2CAMAmWm/N9bFEB/WFYSQNxKjoRIQFUogDGC40hxIyMyQYIECUYEmvYfHNGOrWdw74MAAAAASUVORK5CYII=';
                this._viewer.setCallbacks({ camera: (camera) => {
                        if (!this._behindView) {
                            const distance = Communicator.Point3.distance(camera.getPosition(), this.position);
                            if (distance < 10000) {
                                this.pinElement.hide();
                                if (this.bHidden) {
                                    this.pinArray.forEach((pin) => {
                                        this._viewer.measureManager.addMeasurement(pin);
                                        this._viewer.measureManager.finalizeMeasurement(pin);
                                    });
                                    this.bHidden = false;
                                }
                            }
                            else {
                                if (!this.bHidden) {
                                    this.pinArray.forEach((pin) => {
                                        this._viewer.measureManager.removeMeasurement(pin);
                                    });
                                    this.bHidden = true;
                                    this.pinElement.show();
                                }
                            }
                        }
                    } });
                const onMouseDownCallbackFn = (event) => {
                    event.stopPropagation();
                    if (Date.now() - this.prevMouseDownTime < 250) {
                        this.isDoubleClick = true;
                    }
                    this.prevMouseDownTime = Date.now();
                };
                const onMouseUpCallbackFn = (event) => {
                    event.stopPropagation();
                    if (this.isDoubleClick) {
                        this._viewer.view.fitBounding(this.pinBounding);
                    }
                    else {
                        if (this.bHidden) {
                            if (this.pinElement.getOpacity() < 0.9) {
                                this.pinElement.setOpacity(1.0);
                                const newSize = this.size.copy().scale(2);
                                this.setSize(newSize);
                                this.pinElement.setFontSize(20);
                            }
                            else {
                                this.pinElement.setOpacity(0.5);
                                const newSize = this.size.copy().scale(0.5);
                                this.setSize(newSize);
                                this.pinElement.setFontSize(10);
                            }
                        }
                    }
                    this.isDoubleClick = false;
                };
                this.pinElement = new Markup.SPinElement(onMouseDownCallbackFn, onMouseUpCallbackFn);
                this.setImage(this.imageURL);
                this.pinElement.setSize(this.size);
                this.pinElement.setOpacity(0.5);
            }
            insertPin(pinObject) {
                const pin = new Markup.FPinMarkup(this._viewer);
                // pin.setNodeId(pinObject.nodeId);
                pin.setImage('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAyCAYAAAAayliMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGvElEQVR4nO1Ya2xTdRQ/Y723L1bWsbL31nXd1nZru/X29rFnHxM0op8cIfGDxISogYjER/igyUAjgl/wkTjhg8bXB1+JET5oTEgkUQdMIo+YAAmPbUjUrdtK4jcwv7tzSVfXMmjHIPYkJ21ue//nd/7nnN85/z9RQQpSkIIUpCAFmZPkgD+SjAf3XYvLh6/FAxeuxQM3oMm4nMCzZCy4D/+he02SA/4Ig76xKI0FLszE5E3LjZsSkZA1G/DpuHwyEQ8cyfR7Mu7/AGssC/irfYHG2Vjg4kLAZuOBGXwS0ZoDjiZJcSYmj2WKRuJuO3Gp22/LBD4Rk8c3rFnjZQdsQ82NfYmYPDbUXIfP8UxOTK8NNN4t/CsygYd+5ml5gohc7IDrBVv1wFRMHhdFsW0k5H4jW12cDrvKlgz19evXi4ioaCYe3JkJxExMnhUEoYOIPKIouomoXRTFdiLCd+8zDTUPZyvumai0Exu0FPgV8KfDPns2AMcC7veJCA4AtJOIWqCiKLrYCd/Zno5vM68hJ0YCjtVsL78ODA4OFiei0kfZHJjo9R0/39v5zcU+39eXe3xfXe7zfakqnuG3iT7f8WxrTEbkV4moOJ9OFHFYxWy5r+qJkOe10W739lNdnmd/7/ZuPdfXseW3Hs+2o13tz5/t6fzw1n1CTrhcLjGfqQQHis+EpOBimtSPobbNRqOxkohWm83mVURUSkTlBoOh6mS3d9di1jjm97RGIhENbHPt5STK7p/v7dy4GOOTUfnMFlsNcr+srKzMBCdMJlPZcLvNn4hm6AXx+Xqpz/cUbMJ2Tg7wy8hH/ZWItHsxxpVeEJVPfdzW4iWiVXDgaMjzyHRUvrzY98ci0g7YHBoayosDCOXKsX7fnsUCUHU2Lk9Db/e9sV7fHiIysu2cUqiIQ2k63+N9+XaB3Kle6vfthU0u5pwd0JaWlpae6PY8dyvDExHpOLrt/nbb+nddzUEiskDfdtpDX3S0Pv5TsH3vWL80eqt1fgm1PcnFnzMb4WUdEZnfdDSEMxm82u8/t8/RuFUQhIAgCMj9Vp1O10BENURUS0SNoig6uMkF8d+/o9Ifmdb71GtfB5t2u12LOsi1BhQHAAijQroxAAmZTA8RUZcgCDLGCCICWBsRNeh0OkyaTZiL2IEA/ruppnJwOuZP/ocAYvI4O1/GtnNqaiusVqviABHVn+7yvpNu8AfZ9RYRhYnIj3kHY4Mois06nQ7TZQM70aiOFIIgdMIJjUbTNRr2fJ6+Hjo2bJlMJtjUchbcmQMcPqUG9Hp93drVpuBMLDAvCgel1l2YcYioDcCJCDtei2ZmNBoriAhaqdfrazkqrTwXSSPB9gPpDrxkq4kTUR1s5qMGbrKQwWCoFkWxdTTsHU41+L3kfEUURScDr0LX5QI0EVEJK76buairuSacZ7o7PkldazTgHuZaqeZ3hHywkMZisazE6YqI7AMWc89kVL6iGp2KyuO7muq78TuPDgYOvcgqoBg5nw3sXGX6WDEV808gBWEDa1VUVBjVcYJyFBSRAeMAdhnz/ea6ikcno/4r85lIep1Bajj1lNxN+Y51NIclt+OvqHQoHfzTdRXrkYZcN4iWnt/JTZiJsIOrkEacwx0wCMPzcjgWuJCMBz9IDoQiiUgHdlqRfyIh68wD8qaFLgCmGDzTL2qoqry8HGmXt4lUHScMJSUl5UyLoETPNmvVOrDGnXbcq/3+ke3W2geZvZD79Uyf2P28pI8inAYipktmFdCiA+dc0ONI2PNixluHBfTPqPwzOjPNndrU05uNWSuvu38zjVBQtbW1ehQqZntwO1gJisJD8/nO73psolfaPxuXlWuV9KuWiX5p/yGfa4NKp+LcUVNpeliTC1ypo3ycAxaKgobDiyKDQTiBvIUTzWr3Bch0Bw76nRs5cnYGDW1Jod9SZinNkh7sJUkSQHEqHep0unqtVtvEYOCIEpUjsnuHCv5ouG03A3ZyxJSo0RzjVKrgsfZSgU8VGBA4EuB9C7NTg1artTNA1IZnNOwe/jXkeU8URVyz4IrFmdKtMehZuHdgLQEXB3QXRD3ka7hBqdGwMKhGjgKGuk6efTA6OLRarY1HCjRFMzdIbUrvyPt1SlZHsGMIOw98AGNmJsEOK5FQmYrTpYKdXcnvCGhWeS/Y27mpU7ss568OVIt+wecAa0q64BloWAWudGissywOpDoC5RQoxjEQRc7TJECXYzTGM045tUEtL/AMokZEiQaYhRlLl1Kk9yRwVealFU+Tgsrt9zLwhUR1RGWX+wo83W+7XZD/rfwLPZXcZ7kdEDQAAAAASUVORK5CYII=');
                pin.setPosition(pinObject.position);
                this.pinArray.push(pin);
                // this.nodeArray.push(pinObject.nodeId);
                this.pinBounding.max.x = Math.max(this.pinBounding.max.x, pinObject.position.x);
                this.pinBounding.max.y = Math.max(this.pinBounding.max.y, pinObject.position.y);
                this.pinBounding.max.z = Math.max(this.pinBounding.max.z, pinObject.position.z);
                this.pinBounding.min.x = Math.min(this.pinBounding.min.x, pinObject.position.x);
                this.pinBounding.min.y = Math.min(this.pinBounding.min.y, pinObject.position.y);
                this.pinBounding.min.z = Math.min(this.pinBounding.min.z, pinObject.position.z);
                if (this.position.equals(Communicator.Point3.zero())) {
                    this.position = this.position.add(pinObject.position);
                }
                else
                    this.position = this.position.add(pinObject.position).scale(0.5);
                this.pinElement.setText(`${this.pinArray.length}`);
            }
            static fromJson(objData, viewer) {
                const pinMarkup = new Markup.FPinMarkup(viewer);
                pinMarkup.setNodeId(objData.nodeId);
                pinMarkup.setPosition(Communicator.Point3.fromJson(objData.position));
                if (objData.image)
                    pinMarkup.setImage(objData.image);
                return pinMarkup;
            }
            static construct(obj, viewer) {
                return Markup.FPinMarkup.fromJson(obj, viewer);
            }
        }
        SPinMarkup.className = "Field.Markup.Pin";
        Markup.SPinMarkup = SPinMarkup;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
