"use strict";
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class SPinElement {
            constructor(onMouseDownCallbackFn, onMouseUpCallbackFn) {
                this.position = Communicator.Point2.zero();
                this._currentSize = SPinElement._defaultSize.copy();
                this.pinContainer = document.createElement("div");
                this.pinContainer.style.position = "absolute";
                this.pinContainer.style.width = `${SPinElement._defaultSize.x}px`;
                this.pinContainer.style.height = `${SPinElement._defaultSize.y}px`;
                this.pinContainer.style.zIndex = "1000000";
                this.pinContainer.style.resize = "none";
                this.pinContainer.style.pointerEvents = 'all';
                this.pinTextContainer = document.createElement("div");
                this.pinTextContainer.style.position = 'absolute';
                this.pinTextContainer.style.top = '35%';
                this.pinTextContainer.style.left = '50%';
                this.pinTextContainer.style.transform = 'translate(-50%,-35%)';
                this.pinTextContainer.style.color = 'white';
                this.pinTextContainer.style.fontSize = '10px';
                this.pinImage = document.createElement("img");
                this.pinImage.style.width = '100%';
                this.pinContainer.appendChild(this.pinImage);
                this.pinContainer.appendChild(this.pinTextContainer);
                this.pinContainer.onmousedown = onMouseDownCallbackFn;
                this.pinContainer.onmouseup = onMouseUpCallbackFn;
            }
            hide() {
                this.pinContainer.style.display = 'none';
            }
            show() {
                this.pinContainer.style.display = 'block';
            }
            setOpacity(opacity) {
                this.pinImage.style.opacity = `${opacity}`;
            }
            setImage(dataURL) {
                this.pinImage.src = dataURL;
            }
            setPosition(pos) {
                this.position.assign(pos);
                this.pinContainer.style.left = `${pos.x - this._currentSize.x * 0.5}px`;
                this.pinContainer.style.top = `${pos.y - this._currentSize.y}px`;
            }
            setSize(size) {
                if (!this._currentSize.equals(size)) {
                    this._currentSize.assign(size);
                    this.pinContainer.style.width = `${size.x}px`;
                    this.pinContainer.style.height = `${size.y}px`;
                    this.setPosition(this.position);
                }
            }
            setFontSize(size) {
                this.pinTextContainer.style.fontSize = `${size}px`;
            }
            getFontSize() {
                return 0;
            }
            setText(text) {
                this.pinTextContainer.innerHTML = text;
            }
            getOpacity() {
                return parseFloat(this.pinImage.style.opacity);
            }
            getSize() {
                return this._currentSize;
            }
            focus() {
                this.pinContainer.focus();
                this.pinContainer.style.pointerEvents = "auto";
                this.pinContainer.style.resize = "both";
            }
            blur() {
                this.pinContainer.blur();
                this.pinContainer.style.pointerEvents = "none";
                this.pinContainer.style.resize = "none";
            }
            getImageArea() {
                return this.pinContainer;
            }
            toJson() {
            }
        }
        SPinElement._defaultSize = new Communicator.Point2(40, 40);
        Markup.SPinElement = SPinElement;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
