"use strict";
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class PinElement {
            constructor() {
                this.position = Communicator.Point2.zero();
                this.createImage();
            }
            createImage() {
                this._currentSize = PinElement._defaultSize.copy();
                this.pinImage = document.createElement("img");
                this.pinImage.style.position = "absolute";
                this.pinImage.style.width = `${PinElement._defaultSize.x}px`;
                this.pinImage.style.height = `${PinElement._defaultSize.y}px`;
                this.pinImage.style.zIndex = "1000000";
                this.pinImage.style.resize = "none";
                this.pinImage.style.pointerEvents = 'all';
            }
            hide() {
                this.pinImage.style.display = 'none';
            }
            show() {
                this.pinImage.style.display = 'block';
            }
            setOpacity(opacity) {
                this.pinImage.style.opacity = `${opacity}`;
            }
            setImage(dataURL) {
                this.pinImage.src = dataURL;
            }
            setPosition(pos) {
                this.position.assign(pos);
                this.pinImage.style.left = `${pos.x - this._currentSize.x * 0.5}px`;
                this.pinImage.style.top = `${pos.y - this._currentSize.y}px`;
            }
            setSize(size) {
                if (!this._currentSize.equals(size)) {
                    this._currentSize.assign(size);
                    this.pinImage.style.width = `${size.x}px`;
                    this.pinImage.style.height = `${size.y}px`;
                    this.setPosition(this.position);
                }
            }
            getOpacity() {
                return parseFloat(this.pinImage.style.opacity);
            }
            getSize() {
                return this._currentSize;
            }
            focus() {
                this.pinImage.focus();
                this.pinImage.style.pointerEvents = "auto";
                this.pinImage.style.resize = "both";
            }
            blur() {
                this.pinImage.blur();
                this.pinImage.style.pointerEvents = "none";
                this.pinImage.style.resize = "none";
            }
            getImageArea() {
                return this.pinImage;
            }
            toJson() {
            }
        }
        PinElement._defaultSize = new Communicator.Point2(60, 60);
        Markup.PinElement = PinElement;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
