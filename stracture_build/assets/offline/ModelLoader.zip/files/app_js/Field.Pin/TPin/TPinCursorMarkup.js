"use strict";
/// <reference path= "../../../external/Communicator/hoops_web_viewer.d.ts" />
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class TPinCursorMarkup extends Communicator.Markup.Measure.MeasureMarkup {
            ;
            constructor(viewer) {
                super(viewer);
                this._snappedCursorSprite = new Communicator.Markup.Shape.LineCollection();
                this.isRectangleSpriteActive = false;
                this.pointRadius = 0;
                this.cursorColor = new Communicator.Color(255, 171, 76);
                this._name = "TPinCursorMarkup";
                this._snappedCursorSprite.setStrokeColor(this.cursorColor);
                this._snappedCursorSprite.setStrokeWidth(2);
                this._snappedCursorSprite.setEndcapType(Communicator.Markup.Shape.EndcapType.Circle);
                this._snappedCursorSprite.setStartEndcapColor(this.cursorColor);
                this._snappedCursorSprite.setEndEndcapColor(this.cursorColor);
                this._snappedCursorSprite.setStartEndcapSize(1);
                this._snappedCursorSprite.setEndEndcapSize(1);
                this._snappedCursorSprite.clear();
                this._markupId = viewer.markupManager.registerMarkup(this);
            }
            setColor(color) {
                this.cursorColor = color;
            }
            setPointRadius(radius) {
                this.pointRadius = radius;
            }
            draw() {
                const renderer = this._viewer.markupManager.getRenderer();
                renderer.drawLines(this._snappedCursorSprite);
            }
            disableRectangle() {
                this.isRectangleSpriteActive = false;
                this._snappedCursorSprite.clear();
            }
            setPosition(point) {
                const r = this.getRectangeSpriteStatus();
                const center = point;
                this._snappedCursorSprite.clear();
                if (r) {
                    this._snappedCursorSprite.addLine(new Communicator.Point2(center.x - this.pointRadius, center.y - this.pointRadius), new Communicator.Point2(center.x - this.pointRadius, center.y + this.pointRadius));
                    this._snappedCursorSprite.addLine(new Communicator.Point2(center.x + this.pointRadius, center.y - this.pointRadius), new Communicator.Point2(center.x + this.pointRadius, center.y + this.pointRadius));
                    this._snappedCursorSprite.addLine(new Communicator.Point2(center.x - this.pointRadius, center.y + this.pointRadius), new Communicator.Point2(center.x + this.pointRadius, center.y + this.pointRadius));
                    this._snappedCursorSprite.addLine(new Communicator.Point2(center.x - this.pointRadius, center.y - this.pointRadius), new Communicator.Point2(center.x + this.pointRadius, center.y - this.pointRadius));
                }
                else {
                    this._snappedCursorSprite.clear();
                }
            }
            getRectangeSpriteStatus() {
                return this.isRectangleSpriteActive;
            }
            enableRectangle() {
                this.isRectangleSpriteActive = true;
            }
            destroy() {
                this._viewer.markupManager.unregisterMarkup(this._markupId);
            }
        }
        Markup.TPinCursorMarkup = TPinCursorMarkup;
        class TPinCursor {
            constructor(viewer) {
                this._cursorMarkup = null;
                this._updateCursorSpriteAction = new Communicator.Util.CurrentAction(true);
                this._viewer = viewer;
                this.snappingConfig = {
                    enabled: true,
                    preferVertices: true,
                };
            }
            async getSelectionCursorPoints(mousePosition, useSnapping, previousPickPoint) {
                var _a, _b, _c;
                const config = new Communicator.PickConfig(useSnapping ? Communicator.SelectionMask.All : Communicator.SelectionMask.Face);
                if (useSnapping) {
                    // Allows picking of lines even if we're not hovering the model.
                    config.enableProximityFaces = true;
                    config.restrictLinesAndPointsToSelectedFaceInstances = false;
                }
                const selectionItem = await this._viewer.view.pickFromPoint(mousePosition, config);
                if (selectionItem.overlayIndex() !== 0) {
                    (_a = this._cursorMarkup) === null || _a === void 0 ? void 0 : _a.disableRectangle();
                    return null;
                }
                let worldPosition = selectionItem.getPosition();
                let screenPosition = mousePosition;
                if (this.snappingConfig.enabled) {
                    const lineEntity = selectionItem.getLineEntity();
                    const pointEntity = selectionItem.getPointEntity();
                    const faceEntity = selectionItem.getFaceEntity();
                    if (lineEntity || pointEntity || faceEntity) {
                        let worldSnapPosition = null;
                        if (lineEntity !== null) {
                            worldSnapPosition = this._getLineSnapPoint(lineEntity, useSnapping, previousPickPoint);
                        }
                        else if (pointEntity !== null) {
                            worldSnapPosition = pointEntity.getPosition();
                        }
                        else if (faceEntity !== null && faceEntity.isProximityFace()) {
                            worldSnapPosition = faceEntity.getPosition();
                        }
                        if (worldSnapPosition !== null) {
                            worldPosition = worldSnapPosition;
                            (_b = this._cursorMarkup) === null || _b === void 0 ? void 0 : _b.enableRectangle();
                            screenPosition = Communicator.Operator.Common.worldPointToScreenPoint(this._viewer, worldPosition);
                        }
                        else {
                            (_c = this._cursorMarkup) === null || _c === void 0 ? void 0 : _c.disableRectangle();
                        }
                    }
                }
                return new Communicator.Operator.Common.SelectionPoints(worldPosition, screenPosition, selectionItem);
            }
            updateCursorSprite(mousePosition, useSnapping, firstSelectedPoint) {
                this._updateCursorSpriteAction.set(() => {
                    return this._updateCursorSpriteImpl(mousePosition, useSnapping, firstSelectedPoint);
                });
            }
            async _updateCursorSpriteImpl(mousePosition, useSnapping, firstSelectedPoint) {
                if (this._cursorMarkup !== null) {
                    if (useSnapping) {
                        const selection = await this.getSelectionCursorPoints(mousePosition, useSnapping, firstSelectedPoint);
                        if (selection !== null) {
                            this._cursorMarkup.setPosition(selection.screenPosition);
                            this.activateCursorSprite();
                        }
                        else {
                            this.activateCursorSprite();
                        }
                    }
                    else {
                        this._cursorMarkup.setPosition(mousePosition);
                    }
                }
                //this._draw(); // TODO: this belongs in the calling operator
            }
            draw() {
                if (this._cursorMarkup !== null)
                    this._cursorMarkup.draw();
            }
            activateCursorSprite() {
            }
            /**
             * Finds the best point to use for the given lineEntity given the snapping behavior and settings.
             */
            _getLineSnapPoint(lineEntity, useSnapping, firstSelectedPoint) {
                // Always favor vertex snapping if it's viable
                const bestVertexPosition = this.snappingConfig.preferVertices
                    ? lineEntity.getBestVertex()
                    : null;
                if (bestVertexPosition !== null) {
                    return bestVertexPosition;
                }
                // The currently selected position from the line entity will be correct unless we want to find
                // the snap-based center of the second-point line
                const selectedPosition = lineEntity.getPosition();
                if (!useSnapping || firstSelectedPoint == null) {
                    return selectedPosition;
                }
                // Getting here means we're snapping and selecting the second point. We need to support either
                //   1) Snapping to the closest point on the line from our original point if we're *near* that closest point OR
                //   2) Just snapping to the line if we're not near the closest point.
                // Thus, we need to figure out the closest point to make that decision. But first we have to figure out
                // which line segment from the set in the selection contains the current selection point. (It would be
                // nice if the selection information indicated that segment, but that's a deeper change into
                // the selection code and really needs it's own JIRA card)
                const points = lineEntity.getPoints();
                const onLineEpsilon = 1.0e-10;
                const firstSegmentVertexIndex = (() => {
                    for (let i = 0; i < points.length - 1; i++) {
                        if (Communicator.Util.isPointOnLineSegment(points[i], points[i + 1], selectedPosition, onLineEpsilon)) {
                            return i;
                        }
                    }
                    // Punt if we didn't find a match and just use the first segment. Should never happen
                    // unless maybe we have a bad epsilon
                    return 0;
                })();
                // Find closest point on that selected line segment from our first selection point
                const p0 = points[firstSegmentVertexIndex];
                const p1 = points[firstSegmentVertexIndex + 1];
                // Avoid throwing an error when line points are missing, i.e. capping geometry
                if (p0 === undefined || p1 === undefined) {
                    return selectedPosition;
                }
                const closestLinePoint = Communicator.Util.closestPointFromPointToSegment(p0, p1, firstSelectedPoint);
                // Determine if we are within the acceptable tolerance of the closest point on the second line
                const closestScreenPoint = Communicator.Operator.Common.worldPointToScreenPoint(this._viewer, closestLinePoint);
                const selectedScreenPoint = Communicator.Operator.Common.worldPointToScreenPoint(this._viewer, selectedPosition);
                const pixelDistanceSq = Communicator.Point2.subtract(closestScreenPoint, selectedScreenPoint).squaredLength();
                const pickTolerance = this._viewer.selectionManager.getPickTolerance();
                const toleranceSq = pickTolerance * pickTolerance;
                return pixelDistanceSq <= toleranceSq ? closestLinePoint : selectedPosition;
            }
            _clearCursorMarkup() {
                if (this._cursorMarkup !== null) {
                    this._cursorMarkup.destroy();
                    this._cursorMarkup = null;
                }
            }
            onOperatorActivate() {
                this._clearCursorMarkup();
                this._cursorMarkup = new TPinCursorMarkup(this._viewer);
                // For 2D drawings, make the background sheet selectable while we're active so
                // the user can point-to-point measure anything on the drawing
                //
                // TODO: Known issue here if hwv.switchToModel() is called while we're active, and the
                // switch is from a 3D to 2D, the background won't be selectable. But there are other issues
                // with the measurement operator already when switching models... fix them then. COM-2021
                if (this._viewer.sheetManager.isDrawingSheetActive()) {
                    this._viewer.sheetManager.setBackgroundSelectionEnabled(true);
                }
            }
            onOperatorDeactivate() {
                this._clearCursorMarkup();
                // Restore the no-selection behavior for 2D drawings when we're done. Note that if a model-switch to 3D
                // happened while we're active, the background selection will be disabled by the sheet manager so it's
                // fine that it won't get called here.
                if (this._viewer.sheetManager.isDrawingSheetActive()) {
                    this._viewer.sheetManager.setBackgroundSelectionEnabled(false);
                }
            }
        }
        Markup.TPinCursor = TPinCursor;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
