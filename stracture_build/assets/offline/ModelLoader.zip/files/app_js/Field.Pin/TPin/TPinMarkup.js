"use strict";
/// <reference path= "../../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "../PinElement.ts" />
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        /** @hidden */
        class TPinMarkup extends Markup.PinMarkup {
            constructor(viewer) {
                super(viewer);
                this.className = "Field.Markup.TPin";
                this.imageURL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAyCAYAAAAayliMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGvElEQVR4nO1Ya2xTdRQ/Y723L1bWsbL31nXd1nZru/X29rFnHxM0op8cIfGDxISogYjER/igyUAjgl/wkTjhg8bXB1+JET5oTEgkUQdMIo+YAAmPbUjUrdtK4jcwv7tzSVfXMmjHIPYkJ21ue//nd/7nnN85/z9RQQpSkIIUpCAFmZPkgD+SjAf3XYvLh6/FAxeuxQM3oMm4nMCzZCy4D/+he02SA/4Ig76xKI0FLszE5E3LjZsSkZA1G/DpuHwyEQ8cyfR7Mu7/AGssC/irfYHG2Vjg4kLAZuOBGXwS0ZoDjiZJcSYmj2WKRuJuO3Gp22/LBD4Rk8c3rFnjZQdsQ82NfYmYPDbUXIfP8UxOTK8NNN4t/CsygYd+5ml5gohc7IDrBVv1wFRMHhdFsW0k5H4jW12cDrvKlgz19evXi4ioaCYe3JkJxExMnhUEoYOIPKIouomoXRTFdiLCd+8zDTUPZyvumai0Exu0FPgV8KfDPns2AMcC7veJCA4AtJOIWqCiKLrYCd/Zno5vM68hJ0YCjtVsL78ODA4OFiei0kfZHJjo9R0/39v5zcU+39eXe3xfXe7zfakqnuG3iT7f8WxrTEbkV4moOJ9OFHFYxWy5r+qJkOe10W739lNdnmd/7/ZuPdfXseW3Hs+2o13tz5/t6fzw1n1CTrhcLjGfqQQHis+EpOBimtSPobbNRqOxkohWm83mVURUSkTlBoOh6mS3d9di1jjm97RGIhENbHPt5STK7p/v7dy4GOOTUfnMFlsNcr+srKzMBCdMJlPZcLvNn4hm6AXx+Xqpz/cUbMJ2Tg7wy8hH/ZWItHsxxpVeEJVPfdzW4iWiVXDgaMjzyHRUvrzY98ci0g7YHBoayosDCOXKsX7fnsUCUHU2Lk9Db/e9sV7fHiIysu2cUqiIQ2k63+N9+XaB3Kle6vfthU0u5pwd0JaWlpae6PY8dyvDExHpOLrt/nbb+nddzUEiskDfdtpDX3S0Pv5TsH3vWL80eqt1fgm1PcnFnzMb4WUdEZnfdDSEMxm82u8/t8/RuFUQhIAgCMj9Vp1O10BENURUS0SNoig6uMkF8d+/o9Ifmdb71GtfB5t2u12LOsi1BhQHAAijQroxAAmZTA8RUZcgCDLGCCICWBsRNeh0OkyaTZiL2IEA/ruppnJwOuZP/ocAYvI4O1/GtnNqaiusVqviABHVn+7yvpNu8AfZ9RYRhYnIj3kHY4Mois06nQ7TZQM70aiOFIIgdMIJjUbTNRr2fJ6+Hjo2bJlMJtjUchbcmQMcPqUG9Hp93drVpuBMLDAvCgel1l2YcYioDcCJCDtei2ZmNBoriAhaqdfrazkqrTwXSSPB9gPpDrxkq4kTUR1s5qMGbrKQwWCoFkWxdTTsHU41+L3kfEUURScDr0LX5QI0EVEJK76buairuSacZ7o7PkldazTgHuZaqeZ3hHywkMZisazE6YqI7AMWc89kVL6iGp2KyuO7muq78TuPDgYOvcgqoBg5nw3sXGX6WDEV808gBWEDa1VUVBjVcYJyFBSRAeMAdhnz/ea6ikcno/4r85lIep1Bajj1lNxN+Y51NIclt+OvqHQoHfzTdRXrkYZcN4iWnt/JTZiJsIOrkEacwx0wCMPzcjgWuJCMBz9IDoQiiUgHdlqRfyIh68wD8qaFLgCmGDzTL2qoqry8HGmXt4lUHScMJSUl5UyLoETPNmvVOrDGnXbcq/3+ke3W2geZvZD79Uyf2P28pI8inAYipktmFdCiA+dc0ONI2PNixluHBfTPqPwzOjPNndrU05uNWSuvu38zjVBQtbW1ehQqZntwO1gJisJD8/nO73psolfaPxuXlWuV9KuWiX5p/yGfa4NKp+LcUVNpeliTC1ypo3ycAxaKgobDiyKDQTiBvIUTzWr3Bch0Bw76nRs5cnYGDW1Jod9SZinNkh7sJUkSQHEqHep0unqtVtvEYOCIEpUjsnuHCv5ouG03A3ZyxJSo0RzjVKrgsfZSgU8VGBA4EuB9C7NTg1artTNA1IZnNOwe/jXkeU8URVyz4IrFmdKtMehZuHdgLQEXB3QXRD3ka7hBqdGwMKhGjgKGuk6efTA6OLRarY1HCjRFMzdIbUrvyPt1SlZHsGMIOw98AGNmJsEOK5FQmYrTpYKdXcnvCGhWeS/Y27mpU7ss568OVIt+wecAa0q64BloWAWudGissywOpDoC5RQoxjEQRc7TJECXYzTGM045tUEtL/AMokZEiQaYhRlLl1Kk9yRwVealFU+Tgsrt9zLwhUR1RGWX+wo83W+7XZD/rfwLPZXcZ7kdEDQAAAAASUVORK5CYII=';
                this.pinElement = new Markup.TPinElement();
                this.setImage(this.imageURL);
            }
            static fromJson(objData, viewer) {
                const pinMarkup = new TPinMarkup(viewer);
                pinMarkup.setNodeId(objData.nodeId);
                pinMarkup.setPosition(Communicator.Point3.fromJson(objData.position));
                if (objData.image)
                    pinMarkup.setImage(objData.image);
                return pinMarkup;
            }
            static construct(obj, viewer) {
                return TPinMarkup.fromJson(obj, viewer);
            }
        }
        Markup.TPinMarkup = TPinMarkup;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
