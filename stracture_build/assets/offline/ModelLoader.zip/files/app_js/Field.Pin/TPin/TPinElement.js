"use strict";
/// <reference path = '../PinElement.ts'/>
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class TPinElement extends Markup.PinElement {
            constructor() {
                super();
                this.animDuration = 1000;
                this.animAmplitude = 10;
                const pinAnimationKeyframes = new KeyframeEffect(this.pinImage, // element to animate
                [
                    { transform: `translateY(0px)` },
                    { transform: `translateY(${this.animAmplitude}px)` },
                    { transform: `translateY(0px)` },
                ], { duration: this.animDuration,
                    iterations: Number.POSITIVE_INFINITY, });
                this.pinAnimation = new Animation(pinAnimationKeyframes, document.timeline);
                this.pinAnimation.play();
            }
            refreshAnimation() {
                this.pinAnimation.cancel();
                const pinAnimationKeyframes = new KeyframeEffect(this.pinImage, // element to animate
                [
                    { transform: `translateY(0px)` },
                    { transform: `translateY(${this.animAmplitude}px)` },
                    { transform: `translateY(0px)` },
                ], { duration: this.animDuration,
                    iterations: Number.POSITIVE_INFINITY, });
                this.pinAnimation = new Animation(pinAnimationKeyframes, document.timeline);
                this.pinAnimation.play();
            }
            setAnimationDuration(duration) {
                this.animDuration = duration;
                this.refreshAnimation();
            }
            setAnimationAmplitude(amplitude) {
                this.animAmplitude = amplitude;
                this.refreshAnimation();
            }
            getAnimationDuration() {
                return this.animDuration;
            }
            getAnimationAmplitude() {
                return this.animAmplitude;
            }
        }
        Markup.TPinElement = TPinElement;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
