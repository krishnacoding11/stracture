"use strict";
/// <reference path= "../../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "TPinMarkup.ts" />
/// <reference path= "TPinCursorMarkup.ts" />
var Field;
(function (Field) {
    var Operator;
    (function (Operator) {
        class TPinOperator extends Communicator.Operator.OperatorBase {
            /**
             *
             * @param viewer
             */
            constructor(viewer) {
                super(viewer);
                this.measureManager = this._viewer.measureManager;
                this.cursor = new Field.Markup.TPinCursor(this._viewer);
                this.cameraInteractionActive = false;
                this.bDebug = false;
                this.markup = null;
                const self = this;
                this._viewer.setCallbacks({
                    beginInteraction: () => {
                        this.onBeginInteraction();
                    },
                    endInteraction: () => {
                        this.onEndInteraction();
                    },
                });
                this.enableDebuggingWrapper = function () {
                    self.bDebug = true;
                };
                this.disableDebuggingWrapper = function () {
                    self.bDebug = false;
                };
            }
            /**
             *
             * @param event
             */
            onTouchStart(event) {
                super.onTouchStart(event);
            }
            /**
             *
             * @param event
             */
            async onTouchMove(event) {
                this._viewer.markupManager.refreshMarkup();
                super.onTouchMove(event);
            }
            /**
             *
             * @param event
             * @returns
             */
            onTouchEnd(event) {
                if (!this.isActive())
                    return;
                this._viewer.focusInput(true);
                this.updateMarkup(event.getPosition());
                super.onTouchEnd(event);
            }
            /**
             *
             * @param event
             */
            onMouseDown(event) {
                super.onMouseDown(event);
            }
            /**
             *
             * @param event
             */
            onMouseMove(event) {
                super.onMouseMove(event);
                this._viewer.markupManager.refreshMarkup();
            }
            /**
             *
             * @param event
             * @returns
             */
            onMouseUp(event) {
                if (!this.isActive())
                    return;
                if (!this._ptFirst.equals(event.getPosition()))
                    return;
                this._viewer.focusInput(true);
                this.updateMarkup(event.getPosition());
                super.onMouseUp(event);
                return;
            }
            /**
             *
             */
            clear() {
                if (this.markup)
                    this.measureManager.removeMeasurement(this.markup);
                this.markup = null;
            }
            /**
             *
             */
            onActivate() {
                this.cursor.onOperatorActivate();
                this.markup = null;
            }
            /**
             *
             */
            onDeactivate() {
                this.cursor.onOperatorDeactivate();
                this.measureManager.removeMeasurement(this.markup);
                this.markup = null;
            }
            /**
             *
             * @param position
             */
            createMarkup(position) {
                this.markup = new Field.Markup.TPinMarkup(this._viewer);
                this.measureManager.addMeasurement(this.markup);
                this.markup.setPosition(position);
                this.markup.setSize(new Communicator.Point2(40, 40));
                this.markup.setOpacity(1.0);
            }
            /**
             *
             * @param position
             */
            updateMarkup(position) {
                this.cursor.getSelectionCursorPoints(position, true, this.markup ? this.markup.getPosition() : null).then(async (selection) => {
                    if (selection === null) {
                        return;
                    }
                    if (selection.worldPosition === null)
                        return;
                    const worldPosition = selection.worldPosition.copy();
                    selection.selectionItem.getNodeId();
                    if (this._viewer.sheetManager.isDrawingSheetActive())
                        worldPosition.z = 0;
                    if (this.markup === null) {
                        this.createMarkup(worldPosition);
                        const selectedNodeId = selection.selectionItem.getNodeId();
                        if (selectedNodeId != null) {
                            let nodeId = selectedNodeId;
                            if (this._viewer.model.getNodeType(selectedNodeId) == Communicator.NodeType.BodyInstance) {
                                const parent = this._viewer.model.getNodeParent(selectedNodeId);
                                if (parent != null)
                                    nodeId = parent;
                            }
                            if (this._viewer.model.getModelFileTypeFromNode(nodeId) == Communicator.FileType.Ifc) {
                                if (this._viewer.model.getNodeGenericId(nodeId) == null) {
                                    const parent = this._viewer.model.getNodeParent(nodeId);
                                    if (parent != null)
                                        nodeId = parent;
                                }
                            }
                            this.markup.setNodeId(nodeId);
                        }
                    }
                    const markup = this.markup;
                    this.measureManager.finalizeMeasurement(markup);
                    markup === null || markup === void 0 ? void 0 : markup.toJson().then((pinDetail) => {
                        const event = new CustomEvent(Field.Event.TPinCreated, { detail: pinDetail });
                        window.dispatchEvent(event);
                    });
                });
            }
            /**
             *
             */
            onBeginInteraction() {
                this.cameraInteractionActive = true;
            }
            /**
             *
             */
            onEndInteraction() {
                this.cameraInteractionActive = false;
            }
        }
        Operator.TPinOperator = TPinOperator;
    })(Operator = Field.Operator || (Field.Operator = {}));
})(Field || (Field = {}));
