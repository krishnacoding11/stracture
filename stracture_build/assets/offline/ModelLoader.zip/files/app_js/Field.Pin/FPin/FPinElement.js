"use strict";
/// <reference path = '../PinElement.ts'/>
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class FPinElement extends Markup.PinElement {
            constructor(onMouseDownCallbackFn, onMouseUpCallbackFn) {
                super();
                this.pinImage.onmousedown = onMouseDownCallbackFn;
                this.pinImage.onmouseup = onMouseUpCallbackFn;
            }
        }
        Markup.FPinElement = FPinElement;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
