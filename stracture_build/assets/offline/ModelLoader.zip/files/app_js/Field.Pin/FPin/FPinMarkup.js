"use strict";
/// <reference path= "../../../external/Communicator/hoops_web_viewer.d.ts" />
/// <reference path= "../PinElement.ts" />
var Field;
(function (Field) {
    var Markup;
    (function (Markup) {
        class FPinMarkup extends Markup.PinMarkup {
            constructor(viewer) {
                super(viewer);
                this.prevMouseDownTime = Date.now();
                this.isDoubleClick = false;
                this.pinBounding = new Communicator.Box();
                this.imageURL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAyCAYAAAAayliMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAfjSURBVHgB7Vl5bFTVGv/de+fOMNPpdEpT+yrjs/CS96R9Lz6tG/8Y0KhRcUXqH5pYE4PiDm64pJbNXTFGrTFoNOKWmrjgEjUq0cSIEXdwCWjVAQS00IXOzF3O9fvunDvcKS1zpx2iif2S03Pm3LN8v28753wFJmiCJmiCJujvTArGQU4XmlABUuajB2OkMQEgxtupWkGzk6gM9cDBYgLyBMqksgA4jqPgUaWDNuvE/iCBBcqluL+cKWUB2HUfptXEsAn7ixzsSmfwr9QCZ6eiKE6QKSEEJzWs4zB/x28DuKfjdax8cm2sf2hoiLsUl408+dsFisVioLHeN2fbXbj2gASukTOSDWGcScw/CdbHCPP3YgoByDUdQKM/BQAZAx/VX4eurvdg2rYdY96oRGUdi0QiUVlXUfG+x2hsFY+T/VUN1+PhnIUN3rq2g2mtra0qAlpHIA20tbXxgpot9gC2BDSqIi/Mw1GnHZpbvves3LB67/7HP8AV85/Dd4aNwYjkhPdYt26dNnfuXNHd3Y1xA2Dpz5o1S2loaNAMa5tWFSn6rAkHSljDFIyB6hNIUKU6zh5pG5YrGG3Hjh0WRjHDsgCQPXLFkg/5N5Jkk+R4I1g20ne+ifMssbdZarSLbckNVYhFJ+FpTUNK12DzVP9YuYe2Zs0aXqekHwR1YrWmpka1RF+BOVVxF7bCIZcJl255Bb9wTbat5HK5wsaTJk1y62w2q1DbWXRSNt+vw6KxtqLsGSvyALxSkoIAcJnu6+sbaUEhgTCgxO4H8Ey+e7jdZ4vaLH1uhWkuAbWLFiQALCzaD5UCULS41yaGWb2i8FtFIhbGMSiDKOK4GlGRLTITZr6pqUnp6ekpuUYQAP64vqeTNif1q8LJuf1CoP+LNG4jl3FCrBVZM2jWEvuGSYV///8g3KSpqOY2mdWIoTwI80EBuFRdXU1/B4r6SP0FrVgOBmbcG3mJ+gTbNdcM2m//Z7ciufRUnOPNP7wJc5adHto8zI9BJuRqobOz0y0VATCcnGGORtKu/nlZ7nZua2quYFqKknW86JWM4kSWvPetrgpzbj7FmsPa86/t2X8p5ssCMDAwUGSnxJFDknY8h2UfOKAaZ2EMxHNH6q+YBsih2CZHikKFPpZiz+94in2ApFyITqlaXLWvtbf14+VkDEfSeXIg/+Z5fhMqRYEAjMJ8EbEPTF8afpAOPkH2b3F0Ybt3HhkdwJZdWD21I9xxx2nGIQtOwPPcxz7lNyEq+zyNg5qQM4oTFxZmH/jwGutMVRFSA1lHDDu5+4awjq7jrdzevBOvpm7EEro86G1H4nz/uIpqwLND8oGRPitqSCMQtmvHrQeL20dbZ9MOPDt9iX7fp4vMi8lkGqd16Mt0HcoPS8xbpyQx2z9WngNeKB3fVYKZT6VSUq3FINiJP9tkb2mdghf9/aqM/xx96uI4niNPUx1mtx9tdv9vKVbmR5ni61txEfnIbIyDAplQOp12zwHDF+7oHjOdz4GbVuOXxW9FFlHbMxfvAsYHlL5rBVI1URzBIB44Fw/RZe6SrveRXt+Jec3/wLzhe2XNvJQqepCROh1ecNN2fPPP2nwfmwwx17X2RzxuiZxKUYitn05d21U5ayBjQt/Sh08YgATduKINXTecjHcPri22e49+6sV6uSfa29tLOnGQGx9LMpJIJKL9/f3VmQfxxqQQpmM/ED1sNkcuwwxqDlLJcBd8963RmNsnyUggiHlEo1Gx/DVcTk/ALagw8ZqLV+MCajrJZNJ9LweZF1QDOhXiPxoXQsSuPDbXdM7hOKLlQJyh+DZSNSRKaYds/FvTxoB3vciZ2L19EN8vfBGr3voK25GXPvtBhoRnURHjBaA0NzfrGzZsiFBGIU4ZhSoJSA2Hw45hGHwTcyV2bqueeOJCc9VoIFjKZ61E2xufu8FAk8WzApOi2m4KBsz8buQfEfxW2CcADQEAtLS0KJlMRqOMgsqkaVqICn/jtsL9BEb9Mm3ahokPjzsEdKCh6PVMkt+6sBvzn12Lnd66uq4rpFEGb9P8HAkjIxk3Zs6caVPgEKWYC5JWceh9Ksh8bDrMDLoeZElKWZY8F7460BhBbfd2evfb+PWZj2Wex0erPsZyCp+/AoWHkGWapiEZHqL5Qx7zDKi+vr5iPuBmJohY5KHa2toIbRwZHBzkEKzRncfN4RAu/s6mRYLVIx8sNM87eiqu5vlfpvHYocvwKDNHkjak2dl+MPxt8uTJud7eXpa+RULj7yVBBE4tShCeQ7tgZK3G43GVADGYMI2LkIY4qRX+6TZ0UmgcaKYrBDNI1pehNXIE1pBMCwrPHOHc7ATFfjYbEwGzcmUB8I1XvSLfrV4WjcGEIbNzpIXojGnmZD0E55316KW+DJnhUCgUyrIpMpONjY1i69atzKigbJyghJbHeEnbHxOxFmSa0QVC2TPOoGm0OWuFnTZOV446qg+i8h8qLWQy/6X637KPv3EUi5CZsAbdQqHSE8q4/l9RDnlA3DYXBkJ1mDJ4VRIEZ+umypKSzMchQ7A3zxMKvzvHQmN9EzsyY+e2JRjBfXV1dfQ6EwrZu6AbLJsK3+/5gWMQMGvjxo1F6RjfOn8JGu4LVRQO47IdllqqKMeB0utlUiEskm8YlKTlVz9HFpsOxMB3nD+NfLbsj1iBc53l0v4yQHbK4jTMX8zWJ2iCJP0BMQ9qjDUzb30AAAAASUVORK5CYII=';
                this.pinBounding.max = new Communicator.Point3(Number.MIN_SAFE_INTEGER, Number.MIN_SAFE_INTEGER, Number.MIN_SAFE_INTEGER);
                this.pinBounding.min = new Communicator.Point3(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
                const onMouseDownCallbackFn = (event) => {
                    event.stopPropagation();
                    if (Date.now() - this.prevMouseDownTime < 750) {
                        this.isDoubleClick = true;
                    }
                    this.prevMouseDownTime = Date.now();
                };
                const onMouseUpCallbackFn = (event) => {
                    event.stopPropagation();
                    if (this.isDoubleClick) {
                        this._viewer.view.fitBounding(this.pinBounding);
                    }
                    else {
                        if (this.pinElement.getOpacity() < 0.9) {
                            this.pinElement.setOpacity(1.0);
                            const newSize = this.size.copy().scale(2);
                            this.setSize(newSize);
                        }
                        else {
                            this.pinElement.setOpacity(0.5);
                            const newSize = this.size.copy().scale(0.5);
                            this.setSize(newSize);
                        }
                    }
                    this.isDoubleClick = false;
                };
                this.pinElement = new Markup.FPinElement(onMouseDownCallbackFn, onMouseUpCallbackFn);
                this.setImage(this.imageURL);
                this.pinElement.setSize(this.size);
                this.pinElement.setOpacity(0.5);
            }
            setPosition(point) {
                super.setPosition(point);
                this.pinBounding.max.x = point.x + 1000;
                this.pinBounding.max.y = point.y + 1000;
                this.pinBounding.max.z = point.z + 1000;
                this.pinBounding.min.x = point.x - 1000;
                this.pinBounding.min.y = point.y - 1000;
                this.pinBounding.min.z = point.z - 1000;
            }
            static fromJson(objData, viewer) {
                const pinMarkup = new FPinMarkup(viewer);
                pinMarkup.setNodeId(objData.nodeId);
                pinMarkup.setPosition(Communicator.Point3.fromJson(objData.position));
                if (objData.image)
                    pinMarkup.setImage(objData.image);
                return pinMarkup;
            }
            static construct(obj, viewer) {
                return FPinMarkup.fromJson(obj, viewer);
            }
        }
        FPinMarkup.className = "Field.Markup.Pin";
        Markup.FPinMarkup = FPinMarkup;
    })(Markup = Field.Markup || (Field.Markup = {}));
})(Field || (Field = {}));
