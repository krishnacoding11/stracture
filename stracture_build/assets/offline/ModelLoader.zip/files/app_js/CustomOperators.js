

//This file consist of custom operators. Following are the operators (circle, rectangle, textnote, polyline) copied from HC and customized.
(function (d) {
	(function (h) {
		(function (f) {
			var a = function (a) {
				function c(b) {
					b = a.call(this, b) || this;
					b._uniqueId = d.GUID.create();
					b._centerPt = d.Point3.zero();
					b._radiusPt = d.Point3.zero();
					b._circleShape = new h.Shape.Circle;
					b._previousDragPlanePosition = d.Point3.zero();
					b._circleShape.setFillOpacity(0);
					b._circleShape.setStrokeColor(new d.Color(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b));
					this.strokeWidth = redlineMarkupLineThickness;
					b._circleShape.setStrokeWidth(this.strokeWidth);
					return b
				}
				__extends(c, a);
				//Setter to manage thickness of Circle
				c.prototype.setLineThickness = function (thickness) {
					this._circleShape.setStrokeWidth(parseInt(thickness));
					this.strokeWidth = thickness;
				};
				//Getter to manage thickness of Circle
				c.prototype.getLineThickness = function () {
					return this.strokeWidth;
				};
				c.prototype.setCenter = function (b) {
					this._centerPt.assign(b)
				};
				c.prototype.getCenter = function () {
					return this._centerPt.copy()
				};
				c.prototype.setRadiusPoint =
					function (b) {
						this._radiusPt.assign(b)
					};
				c.prototype.getRadiusPoint = function () {
					return this._radiusPt.copy()
				};
				c.prototype.getUniqueId = function () {
					return this._uniqueId
				};
				c.prototype._update = function () {
					var b = this._viewer.view,
						a = d.Point2.fromPoint3(b.projectPoint(this._centerPt));
					b = d.Point2.fromPoint3(b.projectPoint(this._radiusPt));
					b = d.Point2.distance(a, b);
					this._circleShape.set(a, b)
				};
				c.prototype.draw = function () {
					this._update();
					this._viewer.markupManager.getRenderer().drawCircle(this._circleShape)
				};
				c.prototype.hit =
					function (b) {
						this._update();
						var a = this._circleShape.getStrokeWidth();
						b = d.Point2.distance(this._circleShape.getCenter(), b) - this._circleShape.getRadius();
						return Math.abs(b) <= a
					};
				c.prototype.hitWithTolerance = function (b, a) {
					this._update();
					a = this._circleShape.getStrokeWidth() + a;
					b = d.Point2.distance(this._circleShape.getCenter(), b) - this._circleShape.getRadius();
					return Math.abs(b) <= a
				};
				c.prototype.onSelect = function () {
					this._circleShape.setStrokeWidth(this._circleShape.getStrokeWidth() + 2)
				};
				c.prototype.onDeselect = function () {
					this._circleShape.setStrokeWidth(this._circleShape.getStrokeWidth() - 2)
				};
				c.prototype.isValid = function () {
					return this._circleShape.getRadius() > c._validRadiusTolerance
				};
				c.prototype.onDragStart = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !== b && this._previousDragPlanePosition.assign(b);
					return !1
				};
				c.prototype.onDragMove = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !== b && (a = d.Point3.subtract(b, this._previousDragPlanePosition), this._centerPt.add(a), this._radiusPt.add(a), this._previousDragPlanePosition.assign(b));
					return !0
				};
				c.prototype.toJson = function () {
					return this._toJson()
				};
				c.prototype._toJson = function () {
					return {
						uniqueId: this._uniqueId,
						centerPoint: this._centerPt.toJson(),
						radiusPoint: this._radiusPt.toJson(),
						color: this._circleShape.getStrokeColor().toJson(),
						thickness: this._circleShape.getStrokeWidth(),
						className: this.getClassName()
					}
				};
				c.prototype.forJson = function () {
					return this.toJson()
				};
				c.fromJson = function (b, a) {
					a = new c(a);
					a._uniqueId = b.uniqueId;
					a.setCenter(d.Point3.fromJson(b.centerPoint));
					a.setRadiusPoint(d.Point3.fromJson(b.radiusPoint));
					a._circleShape.setStrokeColor(d.Color.fromJson(b.color));
					a.setLineThickness(b.thickness);
					return a
				};
				c.construct = function (b, a) {
					return c.fromJson(b, a)
				};
				c.prototype.getClassName =
					function () {
						return "Communicator.Markup.Redline.RedlineCircleEx"
					};
				c._validRadiusTolerance = 1;
				return c
			}(f.RedlineItem);
			f.RedlineCircleEx = a
		})(h.Redline || (h.Redline = {}))
	})(d.Markup || (d.Markup = {}))
})(Communicator || (Communicator = {}));


(function (d) {
	(function (h) {
		var f = function (a) {
			function e(c) {
				c = a.call(this, c) || this;
				c._redlineCircle = null;
				c._previewHandle = null;
				c._centerSet = !1;
				return c
			}
			__extends(e, a);
			e.prototype.createRedlineItem = function (a) {
				var b = this._viewer.view;
				this._redlineCircle = new d.Markup.Redline.RedlineCircleEx(this._viewer);
				this._previewHandle = this._viewer.markupManager.registerMarkup(this._redlineCircle);
				a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
				null !== a && (this._centerSet = !0, this._redlineCircle.setCenter(a), this._redlineCircle.setRadiusPoint(a));
				return this._redlineCircle
			};
			e.prototype.updateRedlineItem = function (a) {
				var b = this._viewer.view;
				this._redlineCircle && (a = b.getCamera().getCameraPlaneIntersectionPoint(a, b), null !== a && (this._centerSet || (this._centerSet = !0, this._redlineCircle.setCenter(a)), this._redlineCircle.setRadiusPoint(a), this._viewer.markupManager.refreshMarkup()))
			};
			e.prototype.finalizeRedlineItem = function (a) {
				a = this._viewer.markupManager;
				var b = null;
				this._redlineCircle && (this._redlineCircle.isValid() && (b = this._redlineCircle), this._redlineCircle =
					null, null !== this._previewHandle && (a.unregisterMarkup(this._previewHandle), this._previewHandle = null), a.refreshMarkup());
				return b
			};
			e.prototype.onDeactivate = function () {
				//hide the Redline Markup Config Dialog, in case it is shown
				//document.getElementById("Redline-markup-config").style.display = "none";
			};
			return e
		}(d.RedlineOperator);
		h.RedlineCircleOperatorEx = f
	})(d.Operator || (d.Operator = {}))
})(Communicator || (Communicator = {}));



(function (d) {
	(function (h) {
		(function (f) {
			var a = function (a) {
				function c(b) {
					b = a.call(this, b) || this;
					b._uniqueId = d.GUID.create();
					b._point1 = d.Point3.zero();
					b._point2 = d.Point3.zero();
					b._rectangleShape = new h.Shape.Rectangle;
					b._previousDragPlanePosition = d.Point3.zero();
					b._rectangleShape.setFillOpacity(0);
					b._rectangleShape.setStrokeColor(new d.Color(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b));
					this.strokeWidth = redlineMarkupLineThickness;
					b._rectangleShape.setStrokeWidth(this.strokeWidth);
					return b
				}
				__extends(c, a);
				//Setter to manage thickness of rectangle sides
				c.prototype.setLineThickness = function (thickness) {
					this._rectangleShape.setStrokeWidth(parseInt(thickness));
					this.strokeWidth = thickness;
				};
				//Getter to manage thickness of rectangle sides
				c.prototype.getLineThickness = function () {
					return this.strokeWidth;
				};
				c.prototype.setPoint1 = function (b) {
					this._point1.assign(b)
				};
				c.prototype.getPoint1 = function () {
					return this._point1.copy()
				};
				c.prototype.setPoint2 = function (b) {
					this._point2.assign(b)
				};
				c.prototype.getPoint2 = function () {
					return this._point2.copy()
				};
				c.prototype.getUniqueId = function () {
					return this._uniqueId
				};
				c.prototype._update = function () {
					var b = this._viewer.view,
						a = b.projectPoint(this._point1),
						c = b.projectPoint(this._point2);
					b = new d.Point2(Math.min(a.x, c.x), Math.min(a.y, c.y));
					a = new d.Point2(Math.max(a.x, c.x), Math.max(a.y, c.y));
					a = d.Point2.subtract(a, b);
					this._rectangleShape.setPosition(b);
					this._rectangleShape.setSize(a)
				};
				c.prototype.draw =
					function () {
						this._update();
						this._viewer.markupManager.getRenderer().drawRectangle(this._rectangleShape)
					};
				c.prototype.hit = function (b) {
					this._update();
					var a = this._rectangleShape.getStrokeWidth(),
						c = this._rectangleShape.getPosition(),
						e = this._rectangleShape.getSize(),
						f = new d.Point2(c.x + e.x, c.y),
						h = new d.Point2(c.x, c.y + e.y);
					e = new d.Point2(c.x + e.x, c.y + e.y);
					return d.Util.isPointOnLineSegment2d(b, c, f, a) || d.Util.isPointOnLineSegment2d(b, f, e, a) || d.Util.isPointOnLineSegment2d(b, e, h, a) || d.Util.isPointOnLineSegment2d(b,
						h, c, a) ? !0 : !1
				};
				c.prototype.hitWithTolerance = function (b, a) {
					this._update();
					a = this._rectangleShape.getStrokeWidth() + a;
					var c = this._rectangleShape.getPosition(),
						e = this._rectangleShape.getSize(),
						g = new d.Point2(c.x + e.x, c.y),
						f = new d.Point2(c.x, c.y + e.y);
					e = new d.Point2(c.x + e.x, c.y + e.y);
					return d.Util.isPointOnLineSegment2d(b, c, g, a) || d.Util.isPointOnLineSegment2d(b, g, e, a) || d.Util.isPointOnLineSegment2d(b, e, f, a) || d.Util.isPointOnLineSegment2d(b, f, c, a) ? !0 : !1
				};
				c.prototype.onSelect = function () {
					this._rectangleShape.setStrokeWidth(this._rectangleShape.getStrokeWidth() + 2)
				};
				c.prototype.onDeselect = function () {
					this._rectangleShape.setStrokeWidth(this._rectangleShape.getStrokeWidth() - 2)
				};
				c.prototype.isValid = function () {
					var b = this._rectangleShape.getSize();
					return b.x > c._validSizeTolerance.x && b.y > c._validSizeTolerance.y
				};
				c.prototype.onDragStart = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !== b && this._previousDragPlanePosition.assign(b);
					return !1
				};
				c.prototype.onDragMove = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !==
						b && (a = d.Point3.subtract(b, this._previousDragPlanePosition), this._point1.add(a), this._point2.add(a), this._previousDragPlanePosition.assign(b));
					return !0
				};
				c.prototype.toJson = function () {
					return this._toJson()
				};
				c.prototype._toJson = function () {
					return {
						uniqueId: this._uniqueId,
						className: this.getClassName(),
						point1: this._point1.toJson(),
						point2: this._point2.toJson(),
						color: this._rectangleShape.getStrokeColor().toJson(),
						thickness: this._rectangleShape.getStrokeWidth()
					}
				};
				c.prototype.forJson = function () {
					return this.toJson()
				};
				c.fromJson = function (b, a) {
					a = new c(a);
					a._uniqueId = b.uniqueId;
					a.setPoint1(d.Point3.fromJson(b.point1));
					a.setPoint2(d.Point3.fromJson(b.point2));
					a._rectangleShape.setStrokeColor(d.Color.fromJson(b.color));
					a.setLineThickness(b.thickness);
					return a
				};
				c.construct = function (b, a) {
					return c.fromJson(b, a)
				};
				c.prototype.getClassName = function () {
					return "Communicator.Markup.Redline.RedlineRectangleEx"
				};
				c._validSizeTolerance = new d.Point2(5, 5);
				return c
			}(f.RedlineItem);
			f.RedlineRectangleEx = a
		})(h.Redline || (h.Redline = {}))
	})(d.Markup || (d.Markup = {}))
})(Communicator || (Communicator = {}));

(function (d) {
(function (h) {
    var f = function (a) {
        function e(c) {
            c = a.call(this, c) || this;
            c._redlineRectangle = null;
            c._previewHandle = null;
            return c
        }
        __extends(e, a);
        e.prototype.createRedlineItem = function (a) {
            var b = this._viewer.view;
            a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
            this._redlineRectangle = new d.Markup.Redline.RedlineRectangleEx(this._viewer);
            null !== a && (this._redlineRectangle.setPoint1(a), this._redlineRectangle.setPoint2(a));
            this._previewHandle = this._viewer.markupManager.registerMarkup(this._redlineRectangle);
            return this._redlineRectangle
        };
        e.prototype.updateRedlineItem = function (a) {
            if (this._redlineRectangle) {
                var b = this._viewer.view;
                a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
                null !== a && this._redlineRectangle.setPoint2(a);
                this._viewer.markupManager.refreshMarkup()
            }
        };
        e.prototype.finalizeRedlineItem = function (a) {
            a = null;
            if (this._redlineRectangle && this._previewHandle) {
                var b = this._viewer.markupManager;
                this._redlineRectangle.isValid() && (a = this._redlineRectangle);
                b.unregisterMarkup(this._previewHandle);
                this._redlineRectangle = this._previewHandle = null;
                b.refreshMarkup()
            }
            return a
		};
		e.prototype.onDeactivate = function () {
			//hide the Redline Markup Config Dialog, in case it is shown
			//document.getElementById("Redline-markup-config").style.display = "none";
		};
        return e
    }(d.RedlineOperator);
    h.RedlineRectangleOperatorEx = f
})(d.Operator || (d.Operator = {}))
})(Communicator || (Communicator = {}));

(function (d) {
	(function (h) {
		(function (f) {
			var a = function (a) {
				function c(b) {
					b = a.call(this, b) || this;
					b._uniqueId = d.GUID.create();
					b._points = [];
					b._polylineShape = new h.Shape.Polyline;
					b._previousDragPlanePosition = d.Point3.zero();
					this.strokeWidth = redlineMarkupLineThickness;
					b._polylineShape.setStrokeWidth(this.strokeWidth);
					b._polylineShape.setStrokeColor(new d.Color(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b));
					return b
				}
				__extends(c, a);
				//Setter to manage thickness of polyline
				c.prototype.setLineThickness = function (thickness) {
					this._polylineShape.setStrokeWidth(parseInt(thickness));
					this.strokeWidth = thickness;
				};
				//Getter to manage thickness of polyline
				c.prototype.getLineThickness = function () {
					return this.strokeWidth;
				};
				c.prototype.addPoint = function (b) {
					this._points.push(b.copy())
				};
				c.prototype.getPoints = function () {
					var b = [];
					this._points.forEach(function (a) {
						b.push(a.copy())
					});
					return b
				};
				c.prototype._update =
					function () {
						var b = this._viewer.view;
						this._polylineShape.clearPoints();
						for (var a = 0, c = this._points; a < c.length; a++) {
							var e = d.Point2.fromPoint3(b.projectPoint(c[a]));
							this._polylineShape.pushPoint(e)
						}
					};
				c.prototype.draw = function () {
					this._update();
					this.isValid() && this._viewer.markupManager.getRenderer().drawPolyline(this._polylineShape)
				};
				c.prototype.hit = function (b) {
					this._update();
					var a = this._polylineShape.getStrokeWidth(),
						c = this._polylineShape.getPoints();
					if (1 < c.length)
						for (var e = 1; e < c.length; e++)
							if (d.Util.isPointOnLineSegment2d(b,
									c[e - 1], c[e], a)) return !0;
					return !1
				};
				c.prototype.hitWithTolerance = function (b, a) {
					this._update();
					a = this._polylineShape.getStrokeWidth() + a;
					var c = this._polylineShape.getPoints();
					if (1 < c.length)
						for (var e = 1; e < c.length; e++)
							if (d.Util.isPointOnLineSegment2d(b, c[e - 1], c[e], a)) return !0;
					return !1
				};
				c.prototype.onSelect = function () {
					//this._polylineShape.setStrokeWidth(this._polylineShape.getStrokeWidth() + 2)
				};
				c.prototype.onDeselect = function () {
					//this._polylineShape.setStrokeWidth(this._polylineShape.getStrokeWidth() - 2)
				};
				c.prototype.getClassName = function () {
					return "Communicator.Markup.Redline.RedlinePolylineEx"
				};
				c.prototype.isValid = function () {
					return 1 < this._points.length
				};
				c.prototype.onDragStart = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !== b && this._previousDragPlanePosition.assign(b);
					return !1
				};
				c.prototype.onDragMove = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					if (null !== b) {
						a = d.Point3.subtract(b, this._previousDragPlanePosition);
						for (var c = 0, e = this._points; c < e.length; c++) e[c].add(a);
						this._polylineShape.clearPoints();
						this._previousDragPlanePosition.assign(b)
					}
					return !0
				};
				c.prototype.toJson = function () {
					return this._toJson()
				};
				c.prototype._toJson = function () {
					for (var b = [], a = 0, c = this._points; a < c.length; a++) b.push(c[a].toJson());
					return {
						uniqueId: this._uniqueId,
						points: b,
						color: this._polylineShape.getStrokeColor().toJson(),
						thickness: this._polylineShape.getStrokeWidth()
					}
				};
				c.prototype.forJson = function () {
					return this.toJson()
				};
				c.fromJson = function (b, a) {
					a = new c(a);
					a._uniqueId = b.uniqueId;
					a._polylineShape.setStrokeColor(d.Color.fromJson(b.color));
					a.setLineThickness(b.thickness);
					var e = 0;
					for (b = b.points; e < b.length; e++) a.addPoint(d.Point3.fromJson(b[e]));
					
					return a
				};
				c.construct = function (b, a) {
					return c.fromJson(b, a)
				};
				return c
			}(f.RedlineItem);
			f.RedlinePolylineEx = a
		})(h.Redline || (h.Redline = {}))
	})(d.Markup || (d.Markup = {}))
})(Communicator || (Communicator = {}));

(function (d) {
	(function (h) {
		var f = function (a) {
			function e(c) {
				c = a.call(this, c) || this;
				c._redlinePolyline = null;
				c._previewHandle = null;
				return c
			}
			__extends(e, a);
			e.prototype.createRedlineItem = function (a) {
				var b = this._viewer.view;
				this._redlinePolyline = new d.Markup.Redline.RedlinePolylineEx(this._viewer);
				this._previewHandle = this._viewer.markupManager.registerMarkup(this._redlinePolyline);
				a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
				null !== a && this._redlinePolyline.addPoint(a);
				return this._redlinePolyline
			};
			e.prototype.updateRedlineItem = function (a) {
				if (this._redlinePolyline) {
					var b = this._viewer.view;
					a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
					null !== a && (this._redlinePolyline.addPoint(a), this._viewer.markupManager.refreshMarkup())
				}
			};
			e.prototype.finalizeRedlineItem = function (a) {
				a = this._viewer.markupManager;
				var b = null;
				this._redlinePolyline && (this._redlinePolyline.isValid() && (b = this._redlinePolyline), this._redlinePolyline = null, null !== this._previewHandle && (a.unregisterMarkup(this._previewHandle), this._previewHandle =
					null), a.refreshMarkup());
				return b
			};
			e.prototype.onDeactivate = function () {
				//hide the Redline Markup Config Dialog, in case it is shown
				//document.getElementById("Redline-markup-config").style.display = "none";
			};
			return e
		}(d.RedlineOperator);
		h.RedlinePolylineOperatorEx = f
	})(d.Operator || (d.Operator = {}))
})(Communicator || (Communicator = {}));


(function (d) {
	(function (h) {
		(function (f) {
			var a = function () {
				function a(a, b) {
					this._sizeChanged = !1;
					this._sizeUpdateCallback = a;
					this._textUpdateCallback = b;
					this._createTextBox()
				}
				a.prototype._createTextBox = function () {
					var c = this;
					this._currentSize = a._defaultSize.copy();
					this._textArea = document.createElement("textarea");
					this._textArea.placeholder ="Type Here..."; 
					this._textArea.style.position = "absolute";
					this._textArea.style.width = a._defaultSize.x + "px";
					this._textArea.style.height = a._defaultSize.y + "px";
					this._textArea.style.zIndex = "1";
					this._textArea.style.pointerEvents =
						"none";
					this._textArea.style.resize = "none";
					this.setBorderWidth(2);
					this._textArea.onmousemove = function (a) {
						a.stopPropagation();
						a = new d.Point2(parseInt(c._textArea.style.width, 10), parseInt(c._textArea.style.height, 10));
						c.setSize(a)
					};
					this._textArea.onmouseup = function (a) {
						a.stopPropagation();
						c._sizeChanged && (c._sizeChanged = !1, c._sizeUpdateCallback(c._currentSize))
					};
					this._textArea.oninput = function () {
						c._textUpdateCallback(c._textArea.value)
					}
				};
				a.prototype.setPosition = function (a) {
					this._textArea.style.left = a.x +
						"px";
					this._textArea.style.top = a.y + "px"
				};
				//Modifed methid. This methos only changed the width, doesnt change outline style and color any more
				a.prototype.setBorderWidth = function (a) {
					this._textArea.style.outlineWidth = a + "px"
				};
				a.prototype.setText = function (a) {
					this._textArea.textContent = a
				};
				a.prototype.setSize = function (a) {
					this._currentSize.equals(a) || (this._sizeChanged = !0, this._currentSize.assign(a), this._textArea.style.width = a.x + "px", this._textArea.style.height = a.y + "px")
				};
				a.prototype.focus = function () {
					this._textArea.focus();
					this._textArea.style.pointerEvents = "auto";
					this._textArea.style.resize = "both"
				};
				a.prototype.blur = function () {
					this._textArea.blur();
					this._textArea.style.pointerEvents = "none";
					this._textArea.style.resize = "none"
				};
				a.prototype.getTextArea = function () {
					return this._textArea
				};
				a._defaultSize = new d.Point2(100, 100);
				return a
			}
			();
			f.RedlineTextElementEx = a
		})(h.Redline || (h.Redline = {}))
	})(d.Markup || (d.Markup = {}))
})(Communicator || (Communicator = {}));


(function (d) {
	(function (h) {
		(function (f) {
			var a = function (a) {
				function c(b, e) {
					
					void 0 === e && (e = c.defaultText);
					var g = a.call(this, b) || this;
					g._uniqueId = d.GUID.create();
					g._position = d.Point3.zero();
					g._size = new d.Point2(100, 100);
					g._redlineElementId = null;
					g._previousDragPlanePosition = d.Point3.zero();
					g._text = e;
					g._redlineTextElement = new f.RedlineTextElementEx(function (b) {
						g.setSize(b)
					}, function (b) {
						g.setText(b)
					});
					//g._redlineTextElement.setText(g._text);
					g._callbacks = {
						selectionArray: function () {
							g.onDeselect()
						}
					};
					g._viewer.setCallbacks(g._callbacks);
					//Set the global variable status of redline markup UI
					g._redlineTextElement._textArea.style.fontSize = redlineMarkupTextSize + "px";
					g._redlineTextElement._textArea.style.color = rgb2Hex(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b);
					g._redlineTextElement._textArea.style.outlineColor = rgb2Hex(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b);
					g._redlineTextElement._textArea.style.outlineStyle = "solid";
					g._redlineTextElement._textArea.style.fontWeight = redlineMarkupTextBold;
					g._redlineTextElement._textArea.style.fontStyle = redlineMarkupTextItalic;
					g._redlineTextElement._textArea.style.textDecoration = redlineMarkupTextUnderline;
					return g
				}

				c._redlineItems = new Set();

				__extends(c, a);
				c.prototype.setPosition = function (b) {
					this._position.assign(b)
				};
				c.prototype.getPosition = function () {
					return this._position.copy()
				};
				c.prototype.setSize = function (b) {
					this._viewer.trigger("redlineUpdated", this);
					this._size.assign(b)
				};
				c.prototype.setText = function (b) {
					this._viewer.trigger("redlineUpdated", this);
					this._text = b
				};
				c.prototype.draw = function () {
						nCircle.Ui.Toolbar.addRedlineItem(this._redlineElementId);
					
					var b = d.Point2.fromPoint3(this._viewer.view.projectPoint(this._position));
					this._redlineTextElement.setPosition(b);
					null === this._redlineElementId &&
						(this._redlineElementId = this._viewer.markupManager.addMarkupElement(this._redlineTextElement.getTextArea()))
				};
				c.prototype.hit = function (b) {
					var a = this._redlineTextElement.getTextArea(),
						c = new d.Point2(parseFloat(a.style.left || "0"), parseFloat(a.style.top || "0"));
					a = new d.Point2(parseFloat(a.style.width || "0"), parseFloat(a.style.height || "0"));
					return d.Util.isPointInRect2d(b, c, a)
				};
				c.prototype.hitWithTolerance = function (b, a) {
					var c = this._redlineTextElement.getTextArea(),
						e = new d.Point2(parseFloat(c.style.left ||
							"0"), parseFloat(c.style.top || "0"));
					c = new d.Point2(parseFloat(c.style.width || "0"), parseFloat(c.style.height || "0"));
					return d.Util.isPointInRect2d(b, e, c, a)
				};
				c.prototype.getClassName = function () {
					return c.className
				};
				c.prototype.onSelect = function () {
					this._redlineTextElement.setBorderWidth(4);
					this._redlineTextElement.focus()
				};
				c.prototype.onDeselect = function () {
					this._redlineTextElement.setBorderWidth(2);
					this._redlineTextElement.blur()
				};
				c.prototype.isValid = function () {
					return 0 < this._text.length
				};
				c.prototype.remove =
					function () {
						
						if(!this.isValid()){
							this._redlineElementId && (this._viewer.markupManager.removeMarkupElement(this._redlineElementId),this._redlineElementId = null);
							null !== this._callbacks && (this._viewer.unsetCallbacks(this._callbacks), this._callbacks = null);
							a.prototype.remove.call(this)
						}
						else{
							nCircle.Ui.Toolbar.addRedlineItem(this._redlineElementId);
						}
				};
				
				
					
				c.prototype.onDragStart = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
					null !== b && this._previousDragPlanePosition.assign(b);
					return !1
				};
				c.prototype.onDragMove = function (b) {
					var a = this._viewer.view;
					b = a.getCamera().getCameraPlaneIntersectionPoint(b,
						a);
					if (null !== b) {
						a = d.Point3.subtract(b, this._previousDragPlanePosition);
						var c = this.getPosition();
						c.add(a);
						this.setPosition(c);
						this._previousDragPlanePosition.assign(b)
					}
					return !0
				};
				c.prototype.toJson = function () {
					return this._toJson()
				};
				c.prototype._toJson = function () {
					return {
						uniqueId: this._uniqueId,
						className: this.getClassName(),
						position: this._position.toJson(),
						size: this._size.toJson(),
						text: this._text,
						fontsize: this._redlineTextElement._textArea.style.fontSize, // = textSize + "px";
						textColor: this._redlineTextElement._textArea.style.color,//= rgb2Hex(color.r, color.g, color.b);
						outlineColor: this._redlineTextElement._textArea.style.outlineColor,// = rgb2Hex(color.r, color.g, color.b);
						fontWeight: this._redlineTextElement._textArea.style.fontWeight,// = isTextBold ? "bold" : "";
						textItalic: this._redlineTextElement._textArea.style.fontStyle,// = isTextItalic ? "italic" : "";
						textUnderline: this._redlineTextElement._textArea.style.textDecoration,// = isTextUnderline ? "underline" : "";
					}
				};
				c.prototype.forJson = function () {
					return this.toJson()
				};
				c.fromJson = function (b, a) {
					a = new c(a, b.text);
					a._uniqueId =
						b.uniqueId;
					a.setPosition(d.Point3.fromJson(b.position));
					a.setSize(d.Point2.fromJson(b.size));
					a._redlineTextElement._textArea.style.fontSize = b.fontsize;
					a._redlineTextElement._textArea.style.color = b.textColor;
					a._redlineTextElement._textArea.style.outlineColor = b.outlineColor;
					a._redlineTextElement._textArea.style.fontWeight = b.fontWeight;
					a._redlineTextElement._textArea.style.fontStyle = b.textItalic;
					a._redlineTextElement._textArea.style.textDecoration = b.textUnderline;
					return a
				};
				c.construct = function (b, a) {
					return c.fromJson(b, a)
				};
				c.className = "Communicator.Markup.Redline.RedlineTextEx";
				c.defaultText = "";
				return c
			}(f.RedlineItem);
			f.RedlineTextEx = a
		})(h.Redline || (h.Redline = {}))
	})(d.Markup || (d.Markup = {}))
})(Communicator || (Communicator = {}));

(function (d) {
	(function (h) {
		var f = function (a) {
			function e(c) {
				c = a.call(this, c) || this;
				c._redlineText = null;
				return c
			}
			__extends(e, a);
			e.prototype.createRedlineItem = function (a) {
				return this._redlineText = new d.Markup.Redline.RedlineTextEx(this._viewer)
			};
			e.prototype.finalizeRedlineItem = function (a) {
				if (null === this._redlineText) return null;
				var b = this._viewer.view,
					c = this._redlineText;
				a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
				null !== a && c.setPosition(a);
				this._redlineText = null;
				return c
			};
			e.prototype.onDeactivate = function () {
				//hide the Redline Markup Config Dialog, in case it is shown
				//document.getElementById("Redline-markup-config").style.display = "none";
			};
			//Validation method for text markup when, selection is switched from one to another.
			e.prototype._markupIsTextArea = function (a) {
				return a ? a.getClassName() === d.Markup.Redline.RedlineTextEx.className : !1
			};

			e.prototype.onKeyUp = function(){
				return;
			}

			return e

			

		}(d.RedlineOperator);
		h.RedlineTextOperatorEx = f
	})(d.Operator || (d.Operator = {}))
})(Communicator || (Communicator = {}));
