nCircle.Measurement = (function () {
  var Area = (function () {
    return {
      finalize: function () {
        if (measureAreaOperator) {
          measureAreaOperator.onDoubleClick();
          hwv.view.setCamera(hwv.view.getCamera());
        }
      },
      undo: function () {
        if (hwv) hwv.measureManager.removeLastMeasurement();
      },
    };
  })();

  return {
    Area,
  };
})();

class AngleOperator extends Communicator.Operator.OperatorBase {
  constructor(viewer, measureManager, zoomOperator) {
    super();
    this._viewer = viewer;
    this._measureManager = measureManager;
    this._measureMarkup = null;
    this._zoomLensOperator = zoomOperator;
  }

  WorldToWindow(viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  }

  async onTouchStart(event) {
    await this._zoomLensOperator.onTouchStart(event);
  }

  async onTouchMove(event) {
    await this._zoomLensOperator.onTouchMove(event);
  }

  //Draw the three points when mouse clicked
  async onTouchEnd(event) {
    await this._zoomLensOperator.onTouchEnd(event);

    let target = this._zoomLensOperator.getTargetPoint();

    if (target.x == 0 && target.y == 0) return;

    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.All
    );
    //Get position on face/edge to draw point through all stages of markup
    this._viewer.view
      .pickFromPoint(new Communicator.Point2(target.x, target.y), pickConfig)
      .then((selection) => {
        if (selection.getSelectionType() !== Communicator.SelectionType.None) {
          if (0 === selection.overlayIndex()) {
            let line = null;
            let point = null;
            let point2d = null;
            let position3d = selection.getPosition();
            if ((line = selection.getLineEntity()) !== null) {
              position3d = this.getLineSnapPoint(line, true);
            } else if ((point = selection.getPointEntity()) !== null) {
              position3d = point.getPosition();
            }

            //Convert point from world space to window space
            point2d = this.WorldToWindow(this._viewer, position3d);
            //Trigger the measurementBegin callback event
            if (2 >= this.getStage()) this._viewer.trigger("measurementBegin");
            //Create markup object when first point is  picked
            null === this._measureMarkup &&
              ((this._measureMarkup = new MeasureThreePointsAngleMarkup(
                this._viewer
              )),
              this._measureManager.addMeasurement(this._measureMarkup));
            //Set the points on through stages one by one.
            if (this.getStage() === 0)
              this._measureMarkup.setFirstPointPosition(position3d, point2d);
            else if (this.getStage() === 1)
              this._measureMarkup.setSecondPointPosition(position3d, point2d);
            else if (this.getStage() === 2)
              this._measureMarkup.setThirdPointPosition(position3d, point2d);
            //Draw the markup through eash stage
            this.draw();
            //Finlize/releae markup to measure manager, when all stages are complete
            if (this.getStage() > 2) {
              //this._measureMarkup.finalize();
              this._measureManager.finalizeMeasurement(this._measureMarkup);
              this._measureMarkup = null;
            }

            this._viewer.markupManager.refreshMarkup();
          }
        }
      });

    //super.onMouseUp(event);
  }

  //Get the current stage of markup
  getStage() {
    return null === this._measureMarkup ? 0 : this._measureMarkup.getStage();
  }

  //Draw the cursor markup and three point angle markup
  draw() {
    if (this.getStage() > 3 && null !== this._measureMarkup)
      this._measureMarkup.draw();

    this._viewer.markupManager.refreshMarkup();
  }

  //Perform sniping/picking of points on faces/edges when mouse cursor is moved
  getLineSnapPoint(line, useSnapping) {
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  }

  //On activate, create cursor markup
  onActivate() {
    this._viewer.isDrawingSheetActive() &&
      this._viewer.setBackgroundSelectionEnabled(!0);
  }

  //On deactivate, destroy cursor markup
  async onDeactivate() {
    if (this._measureMarkup != null) {
      this._measureManager.removeMeasurement(this._measureMarkup);
      this._measureMarkup = null;
    }

    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    this._viewer.isDrawingSheetActive() &&
      this._viewer.setBackgroundSelectionEnabled(!1);
  }
}

class AreaOperator extends Communicator.Operator.OperatorBase {
  constructor(viewer, measureManager, zoomLensOperator) {
    super();
    this._viewer = viewer;
    this._measureManager = measureManager;
    //Markup to find area for polygonal region
    this._measureMarkup = null;
    this._zoomLensOperator = zoomLensOperator;
    this._polygonPoints = [];
  }

  async onTouchStart(event) {
    await this._zoomLensOperator.onTouchStart(event);
  }

  async onTouchMove(event) {
    await this._zoomLensOperator.onTouchMove(event);
  }

  //Draw the points when mouse clicked
  async onTouchEnd(event) {
    await this._zoomLensOperator.onTouchEnd(event);
    let target = this._zoomLensOperator.getTargetPoint();

    if (target.x == 0 && target.y == 0) return;

    let _target = new Communicator.Point2(target.x, target.y);

    let closePolygon = this._polygonPoints.filter((point) => {
      return Communicator.Point2.distance(point, _target) < 20;
    });

    if (closePolygon.length != 0) {
      this.calculateArea();
      hwv.view.setCamera(hwv.view.getCamera());
      return;
    }

    this._polygonPoints.push(new Communicator.Point2(target.x, target.y));

    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.All
    );
    //Get position on face/edge to draw point through all stages of markup
    this._viewer.view
      .pickFromPoint(new Communicator.Point2(target.x, target.y), pickConfig)
      .then((selection) => {
        if (selection.getSelectionType() !== Communicator.SelectionType.None) {
          if (0 === selection.overlayIndex()) {
            var line = null;
            var point = null;
            var point2d = null;
            var position3d = selection.getPosition();
            if ((line = selection.getLineEntity()) !== null) {
              position3d = this.getLineSnapPoint(line, true);
            } else if ((point = selection.getPointEntity()) !== null) {
              position3d = point.getPosition();
            }

            //Convert point from world space to window space
            point2d = this.WorldToWindow(this._viewer, position3d);
            //Create markup object when first point is picked
            null === this._measureMarkup &&
              ((this._measureMarkup = new MeasureAreaMarkup(this._viewer)),
              this._measureManager.addMeasurement(this._measureMarkup));
            //Set the points one by one.
            this._measureMarkup.setNextPointPosition(position3d);
            //Trigger the measurementBegin callback to change markup color on markupmanager.
            if (0 === this.getStage())
              this._viewer._getCallbackManager().trigger("measurementBegin");
            //Draw the markup
            this.draw();
            this._viewer.markupManager.refreshMarkup();
          }
        }
      });

    event.setHandled(true);
  }

  //Get the current stage of markup
  getStage() {
    return null === this._measureMarkup ? 0 : this._measureMarkup.getStage();
  }

  //Conversion of point from world space window space
  WorldToWindow(viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  }

  //Draw the cursor markup and area measure markup
  draw() {
    if (null !== this._measureMarkup) this._measureMarkup.draw();

    this._viewer.markupManager.refreshMarkup();
  }

  //Perform sniping/picking of points on faces/edges when mouse cursor is moved
  getLineSnapPoint(line, useSnapping) {
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  }

  //On deactivate, destroy cursor markup
  async onDeactivate() {
    null !== this._measureMarkup &&
      (this._measureManager.removeMeasurement(this._measureMarkup),
      (this._measureMarkup = null));
      this._polygonPoints = [];
    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    
    //this._viewer.isDrawingSheetActive() && this._viewer.setBackgroundSelectionEnabled(!1)
  }

  calculateArea() {
    if (this._measureMarkup !== null) {
      if (this._measureMarkup.point3d.length >= 3) {
        this._measureMarkup.finalize();
        this._measureManager.finalizeMeasurement(this._measureMarkup);
        this._measureMarkup = null;
        this._polygonPoints = [];
      } else {
        hwv.measureManager.removeLastMeasurement();
        this._measureMarkup = null;
        this._polygonPoints = [];
      }
    }
  }
}

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.WorldToWindow =
  function (viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onMouseDown =
  function () {};

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onMouseMove =
  function () {};

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onMouseUp =
  function () {};

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onTouchStart =
  async function (event) {
    await zoomLensOperator.onTouchStart(event);
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onTouchMove =
  async function (event) {
    await zoomLensOperator.onTouchMove(event);
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onDeactivate =
  async function () {
    null !== this._measureMarkup &&
      (this._measureManager.removeMeasurement(this._measureMarkup),
      (this._measureMarkup = null));
    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.getLineSnapPoint =
  function (line, useSnapping) {
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onTouchEnd =
  async function (event) {
    await zoomLensOperator.onTouchEnd(event);

    let target = zoomLensOperator.getTargetPoint();

    if (target.x == 0 && target.y == 0) return;

    let mousePos = new Communicator.Point2(target.x, target.y);

    const stage = this._getStage();

    //console.log(stage);

    // const useSnapping = this._useSnapping(event);
    const mousePosition = mousePos;

    await this._updateMeasurementPoints(mousePosition, true);

    if (this._measureMarkup != null)
      if (this._measureMarkup._positions.length > 1) {
        await this._finalizeMeasurement(mousePosition, true);
        this._measureMarkup = null;
      
      }
    event.setHandled(true);

    hwv.view.setCamera(hwv.view.getCamera());
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype._updateMeasurementPoints =
  async function (mousePosition, useSnapping) {
    const stage = this._getStage();
    //console.assert(stage < Stage.TwoPointsSelected);

    this._viewer.trigger("measurementBegin");

    const firstSelectedPoint = this._getFirstPickPosition();

    const selection = await this._cursor.getSelectionCursorPoints(
      mousePosition,
      useSnapping,
      firstSelectedPoint
    );

    if (selection == null) return;

    if (
      selection.selectionItem.getSelectionType() ==
      Communicator.SelectionType.None
    )
      return;

    if (this._measureMarkup === null) {
      this._measureMarkup =
        new Communicator.Markup.Measure.MeasurePointPointDistanceMarkup(
          this._viewer
        );
      this._measureManager.addMeasurement(this._measureMarkup);
    }

    // COM-3095: when a drawing is active, Take point on 2d drawing plane (Z = 0)
    const measurementPos = selection.worldPosition.copy();
    if (this._viewer.sheetManager.isDrawingSheetActive()) {
      measurementPos.z = 0.0;
    }

    if (this._measureMarkup._positions.length == 0) {
      this._measureMarkup.setFirstPointPosition(measurementPos);
      this._measureMarkup.setUnitMultiplier(
        selection.selectionItem.isNodeSelection()
          ? this._viewer.model.getNodeUnitMultiplier(
              selection.selectionItem.getNodeId()
            )
          : 1
      );
    } else {
      const firstPosition = this._getFirstPickPosition();
      if (firstPosition == null) return;
      if (
        !selection.worldPosition.equalsWithTolerance(firstPosition, 0.0000001)
      ) {
        this._measureMarkup.setSecondPointPosition(measurementPos);
        this._measureMarkup.adjust(selection.screenPosition);
      }
    }

    this._draw();
  };

Communicator.Operator.MeasurePointPointDistanceOperator.prototype._draw =
  function () {
    let refresh = false;

    const stage = this._getStage();
    if (stage <= 1) {
      //this._cursor.draw();
      refresh = true;
    }

    if (this._measureMarkup !== null) {
      this._measureMarkup.draw();
      refresh = true;
    }

    if (refresh) {
      this._viewer.markupManager.refreshMarkup();
    }
  };
