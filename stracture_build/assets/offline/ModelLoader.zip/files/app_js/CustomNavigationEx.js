var gTouchMoveEvent = null;
var gTouchStartEvent = null;

window.addEventListener("touchstart", (event) => {
  //console.log('external touch start called');
  //if(event.touches.length ==2)
    gTouchStartEvent = event;
  //else 
  //  gTouchStartEvent = null;
  
});

window.addEventListener("touchmove", (event) => {
  //console.log('external touch move called');
    gTouchMoveEvent = event;
  //else 
    //gTouchMoveEvent = null;
  
});

window.addEventListener("touchend",()=>{
  gTouchMoveEvent = null;
  gTouchStartEvent = null;

})

class CustomCameraZoomOperator extends Communicator.Operator.OperatorBase {
  /** @hidden */
  constructor(viewer) {
    super(viewer);
    this._mouseMoveZoomDelta = 3;
    this._mouseWheelZoomDelta = 0.25;
    this._pinchZoomModifier = 2.5;
    this._zoomToMousePosition = true;
    this._dollyZoomEnabled = false;
    this._adjustCameraTarget = false;
    this._preserveViewAngle = true;
    this._pinchZoomMultiplier = 2.5;
    this._mouseMoveZoomFactor = 1; //| -1 = 1; // TODO: Create and use [[const enum ZoomFactor { Inverted = -1, Normal = 1; }]]
    this._mouseWheelZoomFactor = 1; // / TODO: see above

    this._secondaryTouchId = null;
    this._tertiaryTouchId = null;

    this._lastTouch1 = Communicator.Point2.zero();
    this._lastTouch2 = Communicator.Point2.zero();
    this._lastTouch3 = Communicator.Point2.zero();

    this._pinchZoomMultiplier = 2.5;
    this._bounding = null;
    this._panMultiplier = 0.35;
    this._cameraPtPrevious = Communicator.Point3.zero();
    this._Touch1StartPositionAsite = Communicator.Point2.zero();
    this._Touch2StartPositionAsite = Communicator.Point2.zero();

    this._Touch1CurrentPosition = Communicator.Point2.zero();
    this._Touch2CurrentPosition = Communicator.Point2.zero();
    this._Touch1PreviousPosition = Communicator.Point2.zero();
    this._Touch2PreviousPosition = Communicator.Point2.zero();

    this._prevTouch2 = Communicator.Point2.zero();
    this._event = 0;
    this._dragCount = 0;
    this._zoomCount = 0;
    this._panCount = 0;
    this._previousDeltaPan = 0;
  }

  /**
   * When true, scrolling up will zoom towards the model.
   * @param inverted
   */
  setMouseWheelZoomInverted(inverted) {
    if (inverted) {
      this._mouseWheelZoomFactor = -1;
    } else {
      this._mouseWheelZoomFactor = 1;
    }
  }

  getMouseWheelZoomInverted() {
    return this._mouseWheelZoomFactor === -1;
  }

  /**
   * When true, moving the mouse up will zoom towards the model.
   * @param inverted
   */
  setMouseMoveZoomInverted(inverted) {
    if (inverted) {
      this._mouseMoveZoomFactor = -1;
    } else {
      this._mouseMoveZoomFactor = 1;
    }
  }

  getMouseMoveZoomInverted() {
    return this._mouseMoveZoomFactor === -1;
  }

  /**
   * Sets the delta to zoom when moving the mouse
   * @param delta
   */
  setMouseMoveZoomDelta(delta) {
    this._mouseMoveZoomDelta = delta;
  }

  /**
   * Gets the mouse move zoom delta
   * @returns number
   */
  getMouseMoveZoomDelta() {
    return this._mouseMoveZoomDelta;
  }

  /**
   * Sets the delta to zoom when scrolling
   * @param delta
   */
  setMouseWheelZoomDelta(delta) {
    this._mouseWheelZoomDelta = delta;
  }

  /**
   * Gets the scrollwheel zoom delta
   * @returns number
   */
  getMouseWheelZoomDelta() {
    return this._mouseWheelZoomDelta;
  }

  /**
   * When set, the zoom will be towards the mouse position. When not set, the zoom will be from the center of the screen.
   * @param zoom
   */
  setZoomToMousePosition(zoom) {
    this._zoomToMousePosition = zoom;
  }

  /**
   * @returns boolean When true, the zoom will be towards the mouse position. When false, the zoom will be towards the center of the screen.
   */
  getZoomToMousePosition() {
    return this._zoomToMousePosition;
  }

  /**
   * When dolly zoom is enabled, the camera position will move towards the camera target when zooming.
   * @moveCameraPositon
   */
  setDollyZoomEnabled(dollyZoomEnabled) {
    this._dollyZoomEnabled = dollyZoomEnabled;
  }

  /**
   * Returns true if dolly zoom is enabled.
   */
  getDollyZoomEnabled() {
    return this._dollyZoomEnabled;
  }

  /**
   * When enabled, the camera target will be updated to the selection position while zooming.
   * This can provide a better zoom behavior in perspective projection mode,
   * but comes at the cost of performing a selection on the model during each mouse scroll,
   * which may not be ideal for performance on large models.
   *
   * This setting is disabled by default.
   */
  setMouseWheelAdjustCameraTarget(value) {
    this._adjustCameraTarget = value;
  }

  /**
   * Returns whether the camera target will be updated to the selection
   * position while zooming. See [[setMouseWheelAdjustCameraTarget]].
   */
  getMouseWheelAdjustCameraTarget() {
    return this._adjustCameraTarget;
  }

  /**
   * Sets whether to maintain a constant view angle while zooming. If
   * enabled, when zooming causes the camera's field of view to shrink or
   * grow, the camera's position will also be moved toward or away from
   * the target, respectively.
   *
   * This may prevent confusing camera behavior when perspective
   * projection is used or might be used. When using only orthographic
   * projection, it is better to disable this.
   *
   * If mouse wheel zoom is being using in conjunction with window zoom
   * this setting should be the same in both.
   *
   * This setting is enabled by default.
   */
  setPreserveViewAngle(value) {
    this._preserveViewAngle = value;
  }

  /**
   * Gets whether to maintain a constant view angle while zooming. See
   * [[setPreserveViewAngle]].
   */
  getPreserveViewAngle() {
    return this._preserveViewAngle;
  }

  /** @hidden */
  async onMouseMove(event) {
    super.onMouseMove(event);

    if (this.isDragging() && this.isActive()) {
      const view = this._viewer.view;

      const currentWindowPosition = view.pointToWindowPosition(this._ptCurrent);
      const prevWindowPosition = view.pointToWindowPosition(this._ptPrevious);

      const deltaY = currentWindowPosition.y - prevWindowPosition.y;
      const deltaX = currentWindowPosition.x - prevWindowPosition.x;
      const delta =
        this._mouseMoveZoomDelta *
        this._mouseMoveZoomFactor *
        (deltaY - deltaX);

      if (this._dollyZoomEnabled) {
        await this._dollyZoom(delta, undefined, undefined, true);
      } else {
        await this._doZoom(delta);
      }
    }
  }

  /** @hidden */
  async onMousewheel(event) {
    const delta =
      this._mouseWheelZoomDelta *
      this._mouseWheelZoomFactor *
      event.getWheelDelta();
    if (this._dollyZoomEnabled) {
      await this._dollyZoom(-delta, undefined, event.getPosition());
    } else {
      await this._doZoom(delta, undefined, event.getPosition());
    }
  }

  /** @hidden */
  onTouchStart(event) {
   // console.log('internal touch start called');

    const view = this._viewer.view;
    const camera = view.getCamera();
    this._dragCount = 0;
    this._zoomCount = 0;
    this._panCount = 0;

    if(nCircle.Ui.Toolbar.isMeasurementOperatorsActive())
      return;

    if(gTouchStartEvent != null && gTouchStartEvent.touches.length == 2){
    //if (this._primaryTouchId === null) {
      this._primaryTouchId = gTouchStartEvent.touches.item(0).identifier;
      //event.getId();
      this._lastTouch1 =  new Communicator.Point2(gTouchStartEvent.touches.item(0).clientX,gTouchStartEvent.touches.item(0).clientY); //event.getPosition().copy(); //screen space coordinates
      this._Touch1StartPositionAsite =  new Communicator.Point2(gTouchStartEvent.touches.item(0).clientX,gTouchStartEvent.touches.item(0).clientY);//event.getPosition().copy();
      this._Touch1CurrentPosition =  new Communicator.Point2(gTouchStartEvent.touches.item(0).clientX,gTouchStartEvent.touches.item(0).clientY);//event.getPosition().copy();
     // console.log(
     //   `Setting this._Touch1StartPositionAsite  ${this._Touch1StartPositionAsite.x}  ${this._Touch1StartPositionAsite.y} `
     // );
    //} else if (
    //  this._secondaryTouchId === null /*&&
    //  event.getId() != this._primaryTouchId*/
    //) {
      this._secondaryTouchId = gTouchMoveEvent.touches.item(1).identifier;
      this._lastTouch2 =  new Communicator.Point2(gTouchStartEvent.touches.item(1).clientX,gTouchStartEvent.touches.item(1).clientY); //event.getPosition().copy(); //screen space coordinates
      this._Touch2StartPositionAsite =  new Communicator.Point2(gTouchStartEvent.touches.item(1).clientX,gTouchStartEvent.touches.item(1).clientY);//event.getPosition().copy();
      this._Touch2CurrentPosition =  new Communicator.Point2(gTouchStartEvent.touches.item(1).clientX,gTouchStartEvent.touches.item(1).clientY);//event.getPosition().copy();
     // console.log(
     //   `Setting this._Touch2StartPositionAsite  ${this._Touch2StartPositionAsite.x}  ${this._Touch2StartPositionAsite.y} `
     // );
    }
  //  }
    // } else if (this._tertiaryTouchId === null) {
    //   this._tertiaryTouchId = event.getId();
    //   this._lastTouch3 = event.getPosition().copy(); //screen space cooridinates
    // }

    //set up variables for starting the touch zoom process
   // if (this._primaryTouchId !== null && this._secondaryTouchId !== null) {
      //Record the Distance between the touches
      this._prevLen = Communicator.Point2.subtract(
        view.pointToWindowPosition(this._lastTouch2),
        view.pointToWindowPosition(this._lastTouch1)
      ).length();

      const PanMidPoint = Communicator.Point2.add(
        this._lastTouch2,
        this._lastTouch1
      ).scale(0.5);
      //console.log(`Pan Mid point : ${PanMidPoint.x} , ${PanMidPoint.y}`);
      const intersectionPoint = camera.getCameraPlaneIntersectionPoint(
        PanMidPoint,
        view
      );

      //record intersection point before panning
      if (intersectionPoint) {
        this._cameraPtPrevious.assign(intersectionPoint);
      }

      //Enable Dragging only if 2 Fingers are pressed
      this._dragging = true;
      this._prevTouch2.assign(this._lastTouch2);
    //}
  }

  async onTouchMove(event) {
    //console.log(`onTouchMove ${Date.now()}  this._Touch1StartPositionAsite : ${this._Touch1StartPositionAsite.x} ${this._Touch1StartPositionAsite.y}, this._Touch2StartPositionAsite : ${this._Touch2StartPositionAsite.x} ${this._Touch2StartPositionAsite.y}`);
    //console.log('internal touch move called');

    //console.log(`event.getId() : ${event.getId()}`);

    if(nCircle.Ui.Toolbar.isMeasurementOperatorsActive())
      return;

    
    this._dragCount++;
    if (this._dragCount < 4) return;

    const view = this._viewer.view;
    const id = event.getId();
    //const position = event.getPosition().copy();
    const camera = view.getCamera();

    
    if(gTouchMoveEvent != null && gTouchMoveEvent.touches.length == 2){
 //   if (id === this._primaryTouchId) {
      this._lastTouch1.assign(new Communicator.Point2(gTouchMoveEvent.touches.item(0).clientX,gTouchMoveEvent.touches.item(0).clientY));
      this._Touch1CurrentPosition = this._lastTouch1.copy();
      
      //this._Touch1CurrentPosition = this._Touch1StartPositionAsite.copy();
      //console.log(`this._Touch1CurrentPosition set = ${this._Touch1CurrentPosition.x}  ${this._Touch1CurrentPosition.y} `);
   // } else if (id === this._secondaryTouchId) {
      this._lastTouch2.assign(new Communicator.Point2(gTouchMoveEvent.touches.item(1).clientX,gTouchMoveEvent.touches.item(1).clientY));
      this._Touch2CurrentPosition = this._lastTouch2.copy();
      //console.log(`this._Touch2CurrentPosition set = ${this._Touch2CurrentPosition.x}  ${this._Touch2CurrentPosition.y} `);
    //}
    
    if(this._dragCount == 4){
      this._Touch2StartPositionAsite = this._Touch2CurrentPosition.copy();
      this._Touch1StartPositionAsite = this._Touch1CurrentPosition.copy();
	  this._prevLen = Communicator.Point2.subtract(
        view.pointToWindowPosition(this._lastTouch2),
        view.pointToWindowPosition(this._lastTouch1)
      ).length();

      const PanMidPoint = Communicator.Point2.add(
        this._lastTouch2,
        this._lastTouch1
      ).scale(0.5);
      //console.log(`Pan Mid point : ${PanMidPoint.x} , ${PanMidPoint.y}`);
      const intersectionPoint = camera.getCameraPlaneIntersectionPoint(
        PanMidPoint,
        view
      );

      //record intersection point before panning
      if (intersectionPoint) {
        this._cameraPtPrevious.assign(intersectionPoint);
      }
	  return;

    }
    /*if (this._secondaryTouchId == null || this._primaryTouchId == null) {
      return;
    }*/

    //if (
      //this._dragging //&&
      /*(id === this._secondaryTouchId || id === this._primaryTouchId)*/
    //) {
      //Calculate everything:

      //Pan calculations:
      const newPanMidPoint = Communicator.Point2.add(
        this._lastTouch2,
        this._lastTouch1
      ).scale(0.5);

      //console.log(`newPan Mid point : ${newPanMidPoint.x} , ${newPanMidPoint.y} `);
      const intersectionPoint = camera.getCameraPlaneIntersectionPoint(
        newPanMidPoint,
        view
      );
      let delta = Communicator.Point3.zero();

      //record intersection point after panning
      if (intersectionPoint) {
        delta = Communicator.Point3.subtract(
          intersectionPoint,
          this._cameraPtPrevious
        ).scale(this._panMultiplier);
      }

      //Zoom calculations:
      const l1 = Communicator.Point2.subtract(
        view.pointToWindowPosition(this._lastTouch2),
        view.pointToWindowPosition(this._lastTouch1)
      ).length();

      const zoomFactor = (this._prevLen - l1) * this._pinchZoomMultiplier;
      //NOTE : this._midPt HAS TO BE IN SCREEN SPACE COORDINATES
      let midPoint = Communicator.Point2.add(
        this._lastTouch2,
        this._lastTouch1
      ).scale(0.5);

      let TouchStartMidPoint = Communicator.Point2.add(
        this._Touch1StartPositionAsite,
        this._Touch2StartPositionAsite
      ).scale(0.5);

      let TouchCurrentMidPoint = Communicator.Point2.add(
        this._Touch1CurrentPosition,
        this._Touch2CurrentPosition
      ).scale(0.5);

      let TouchStartDistance = Communicator.Point2.subtract(
        this._Touch1StartPositionAsite,
        this._Touch2StartPositionAsite
      ).length();

      let TouchCurrentDistance = Communicator.Point2.subtract(
        this._Touch1CurrentPosition,
        this._Touch2CurrentPosition
      ).length();

      let deltaPan = Communicator.Point2.subtract(
        TouchStartMidPoint,
        TouchCurrentMidPoint
      ).length();

      let deltaZoom = TouchStartDistance - TouchCurrentDistance;

      //console.log(`Date.now()  deltaPan : ${deltaPan} , deltaZoom = ${deltaZoom}`);
      

      if (
        (this._panCount > 10 && this._zoomCount < 10) ||
        (Math.abs(deltaPan) > Math.abs(deltaZoom) && this._zoomCount < 10)
      ) {
        //console.log(` PAN : zoomFactor = ${zoomFactor} , delta = ${delta.length()}`);
        //console.log(`Date.now()  deltaPan : ${deltaPan} , deltaZoom = ${deltaZoom}   PAN`);
		
		
        //console.log(
        //  `${Date.now()} TS1:  ${this._Touch1StartPositionAsite.x}, ${this._Touch1StartPositionAsite.y} TS2: ${this._Touch2StartPositionAsite.x}, ${this._Touch2StartPositionAsite.y} CP1 : ${this._Touch1CurrentPosition.x}, ${this._Touch1CurrentPosition.y} CP2 : ${this._Touch2CurrentPosition.x}, ${this._Touch2CurrentPosition.y} deltaPan : ${deltaPan} , deltaZoom = ${deltaZoom} delta = ${delta.length()} ${delta.x} ${delta.y} ${delta.z} PC: ${this._panCount} ZC: ${this._zoomCount}PAN `
        //);
        camera.dolly(delta);
        view.setCamera(camera);
        this._panCount++;
		
		this._Touch1PreviousPosition = this._Touch1CurrentPosition.copy();
		this._Touch2PreviousPosition = this._Touch1CurrentPosition.copy();
		
		this._previousDeltaPan = deltaPan;	
      } else {
        //console.log(`Date.now()  deltaPan : ${deltaPan} , deltaZoom = ${deltaZoom}    ZOOM`);
        //console.log(`ZOOM : zoomFactor = ${zoomFactor} , delta = ${delta.length()}`);
       // console.log(
       //   `${Date.now()} TS1:  ${this._Touch1StartPositionAsite.x}, ${this._Touch1StartPositionAsite.y} TS2: ${this._Touch2StartPositionAsite.x}, ${this._Touch2StartPositionAsite.y} CP1 : ${this._Touch1CurrentPosition.x}, ${this._Touch1CurrentPosition.y} CP2 : ${this._Touch2CurrentPosition.x}, ${this._Touch2CurrentPosition.y} deltaPan : ${deltaPan} , deltaZoom = ${deltaZoom} delta = ${delta.length()} ${delta.x} ${delta.y} ${delta.z} PC: ${this._panCount} ZC: ${this._zoomCount}  Zoom`
       // );
        await this._dollyZoom(-zoomFactor, undefined, midPoint, true);
        this._prevLen = l1;
        this._zoomCount++;
		
		this._Touch1PreviousPosition = this._Touch1CurrentPosition.copy();
		this._Touch2PreviousPosition = this._Touch1CurrentPosition.copy();
      }
    }
  }

  /** @hidden */
  onTouchEnd(event) {

    //gTouchMoveEvent = null;
    //gTouchStartEvent = null;

    const id = event.getId();
//
    //if (this._primaryTouchId === id) this._primaryTouchId = null;
    //else if (this._secondaryTouchId === id) this._secondaryTouchId = null;
    this._event = 0;
    this._dragCount = 0;
    this._dragging = false;
  }

  /** @hidden */
  onDeactivate() {
    this._primaryTouchId = null;
    this._secondaryTouchId = null;
  }

  _updateCameraViewAngle(camera) {
    const radians = Communicator.Util.degreesToRadians(90);
    const tan = Math.tan(radians / 2);
    const length = Communicator.Point3.subtract(
      camera.getTarget(),
      camera.getPosition()
    ).length();
    const width = length * tan;
    camera.setWidth(width);
    camera.setHeight(width);
    return camera;
  }

  async _dollyZoom(
    delta,
    camera = this._viewer.view.getCamera(),
    mousePosition,
    dollyTarget = false
  ) {
    const view = this._viewer.view;
    camera.setProjection(Communicator.Projection.Perspective);

    const cameraPosition = camera.getPosition();
    const cameraTarget = camera.getTarget();

    if (mousePosition) {
      const modelBounding =
        this._bounding == null
          ? await this._viewer.model.getModelBounding(false, false, false)
          : this._bounding;
      this._bounding = modelBounding;

      //Model Bounding Box Extents : Min,Max and minTargetDistance = (Max - Min) / 100
      const extentsLength = modelBounding.extents().length();
      const minTargetDistance = extentsLength / 200;
      let selection = null;

      try {
        selection = await this._viewer.view.pickFromPoint(
          mousePosition,
          new Communicator.PickConfig()
        );
      } catch (e) {
        return false;
      }

      const selectionPosition = selection.getPosition();

      // Adjust camera target based on selection position
      if (selectionPosition !== null) {
        const a = Communicator.Point3.subtract(cameraTarget, cameraPosition);
        const event = Communicator.Point3.subtract(
          selectionPosition,
          cameraPosition
        );
        const newTarget = Communicator.Point3.add(
          cameraPosition,
          a.scale(
            Communicator.Point3.dot(a, event) / Communicator.Point3.dot(a, a)
          )
        );
        camera.setTarget(newTarget);
      }

      let eyeVector = Communicator.Point3.subtract(
        camera.getTarget(),
        cameraPosition
      );

      // Dolly target forward if the position is too close
      if (eyeVector.length() < minTargetDistance) {
        camera.setTarget(
          Communicator.Point3.add(
            cameraTarget,
            eyeVector
              .copy()
              .normalize()
              .scale(minTargetDistance * 4)
          )
        );
      }

      eyeVector = Communicator.Point3.subtract(
        camera.getTarget(),
        cameraPosition
      );
      camera.setPosition(
        Communicator.Point3.add(
          cameraPosition,
          eyeVector.copy().scale((delta > 0 ? 1 : -1) * Math.abs(delta))
        )
      );
    } else {
      const eyeVector = Communicator.Point3.subtract(
        cameraTarget,
        cameraPosition
      ).scale(delta / 10);
      camera.setPosition(Communicator.Point3.add(cameraPosition, eyeVector));

      if (dollyTarget) {
        camera.setTarget(Communicator.Point3.add(cameraTarget, eyeVector));
      }
    }

    camera = this._updateCameraViewAngle(camera);

    this._viewer.pauseRendering(() => {
      if (mousePosition) {
        //point before zoom
        const intersectionPoint = camera.getCameraPlaneIntersectionPoint(
          mousePosition,
          this._viewer.view
        );

        view.setCamera(camera);

        // point after zoom
        const intersectionPoint2 = camera.getCameraPlaneIntersectionPoint(
          mousePosition,
          this._viewer.view
        );
        if (intersectionPoint !== null && intersectionPoint2 !== null) {
          //move the camera by delta = (old intersection - new intersection)
          camera.dolly(
            Communicator.Point3.subtract(intersectionPoint2, intersectionPoint)
          );
        }
      }

      view.setCamera(camera);
    });
  }

  async _doZoom(delta, camera = this._viewer.view.getCamera(), mousePosition) {
    const view = this._viewer.view;
    const zoom = 1.0 / (1.0 - delta);

    if (mousePosition && this._zoomToMousePosition) {
      if (this._adjustCameraTarget) {
        const selection = await this._viewer.view.pickFromPoint(
          mousePosition,
          new Communicator.PickConfig()
        );
        if (selection !== undefined && selection.isEntitySelection()) {
          const reverseEyeVector = camera
            .getPosition()
            .subtract(camera.getTarget());

          const a = Communicator.Point3.subtract(
            camera.getTarget(),
            camera.getPosition()
          );
          const b = Communicator.Point3.subtract(
            selection.getPosition(),
            camera.getPosition()
          );
          const newTarget = camera
            .getPosition()
            .add(a.scale(Communicator.Point3.dot(a, b) / Point3.dot(a, a)));

          camera.setTarget(newTarget);
          camera.setPosition(
            Communicator.Point3.add(newTarget, reverseEyeVector)
          );
        }
      }

      this._viewer.pauseRendering(() => {
        const intersectionPoint = camera.getCameraPlaneIntersectionPoint(
          mousePosition,
          this._viewer.view
        );
        this._zoomHelper(zoom, camera);

        // pan
        const intersectionPoint2 = camera.getCameraPlaneIntersectionPoint(
          mousePosition,
          this._viewer.view
        );
        if (intersectionPoint !== null && intersectionPoint2 !== null) {
          camera.dolly(
            Communicator.Point3.subtract(intersectionPoint2, intersectionPoint)
          );
        }
        view.setCamera(camera);
      });
    } else {
      this._zoomHelper(zoom, camera);
    }
  }

  _zoomHelper(zoom, camera) {
    const view = this._viewer.view;

    camera.setWidth(camera.getWidth() * zoom);
    camera.setHeight(camera.getHeight() * zoom);

    if (
      this._preserveViewAngle &&
      !this._viewer.sheetManager.isDrawingSheetActive()
    ) {
      const position = camera.getPosition();
      const target = camera.getTarget();

      const newDelta = Communicator.Point3.subtract(target, position).scale(
        zoom
      );
      camera.setPosition(Communicator.Point3.subtract(target, newDelta));
    }

    view.setCamera(camera);
  }
}

class CustomCameraPanOperator extends Communicator.Operator.OperatorBase {
  /** @hidden */
  constructor(viewer) {
    super(viewer);
    // this._cameraPtPrevious = Communicator.Point3.zero();
    // this._panMultiplier = 0.5;
    // this._prevLen = 0;
    // this._panFactor = 100;
    // this._lastTouch2 = Communicator.Point2.zero();
    // this._lastTouch1 = Communicator.Point2.zero();
    // this._dragging = false;
    // this._secondaryTouchId = null;
    // this._primaryTouchId = null;
  }

  /** @hidden */
  onTouchStart(event) {
    //handled in zoom operator
  }

  /** @hidden */
  onTouchMove(event) {
    //handled in zoom operator
  }

  onTouchEnd(event) {
    //handled in zoom operator
  }
}

class CustomCameraNavigationOperator extends Communicator.Operator
  .OperatorBase {
  /** @hidden */
  constructor(viewer, orbitOperator, panOperator, zoomOperator) {
    super(viewer);

    this._activeOperator = null;
    this._activeTouchCount = 0;
    this._touchMoveCount = 0;
    this._returnToOrbit = false;
    this._bimNavigationEnabled = false;

    this._orbitOperator = orbitOperator;
    this._panOperator = panOperator;
    this._zoomOperator = zoomOperator;
  }

  /**
   * When BIM navigation is enabled, the following controls for orbit, pan, and zoom are set:
   * Left mouse button: orbit
   * Middle mouse wheel: zoom
   * Middle mouse button: pan
   * Right mouse button: zoom
   * @param bimNavigation
   */
  setBimNavigationEnabled(bimNavigation) {
    this._bimNavigationEnabled = bimNavigation;

    const orbitOperator = this._orbitOperator;
    const zoomOperator = this._zoomOperator;
    const panOperator = this._panOperator;

    orbitOperator.clearMapping();
    zoomOperator.clearMapping();
    panOperator.clearMapping();

    orbitOperator.setMapping(Button.Left);
    orbitOperator.setBimOrbitEnabled(bimNavigation);
    zoomOperator.setDollyZoomEnabled(bimNavigation);

    if (bimNavigation) {
      orbitOperator.setPrimaryButton(Button.Left);
      zoomOperator.setMapping(Button.Right);
      panOperator.setMapping(Button.Middle);

      this._setBimCamera();
    } else {
      orbitOperator.addMapping(Button.Middle);
      orbitOperator.setPrimaryButton(Button.Middle);
      zoomOperator.addMapping(Button.Left, KeyModifiers.Shift);
      panOperator.addMapping(Button.Right);
      panOperator.addMapping(Button.Left, KeyModifiers.Control);
    }
  }

  _setBimCamera() {
    const camera = this._viewer.view.getCamera();
    const forward = Communicator.Point3.subtract(
      camera.getPosition(),
      camera.getTarget()
    ).normalize();

    const viewAxes = this._viewer.model.getViewAxes();
    const viewAxesUp = viewAxes.upVector.copy();

    const left = Communicator.Point3.cross(forward, viewAxesUp);
    const up = Communicator.Point3.cross(left, forward);

    camera.setUp(up);
    camera.setProjection(Projection.Perspective);

    this._viewer.view.setCamera(camera);
  }

  /**
   * Returns true if BIM navigation is enabled.
   */
  getBimNavigationEnabled() {
    return this._bimNavigationEnabled;
  }

  /** @hidden */
  onViewOrientationChange() {
    this._activeTouchCount = 0;
    this._returnToOrbit = false;
  }

  /** @hidden */
  onMouseDown(event) {
    super.onMouseDown(event);

    this._setActiveOperatorForMouseInput(event);

    if (this._activeOperator) {
      if (this._bimNavigationEnabled) {
        this._setBimCamera();
      }

      this._activeOperator.onMouseDown(event);
    }
  }

  /** @hidden */
  onMouseMove(event) {
    super.onMouseMove(event);

    if (this._activeOperator && this._dragging && this._dragCount > 3) {
      this._activeOperator.onMouseMove(event);
    }
  }

  /** @hidden */
  onMouseUp(event) {
    if (this._activeOperator) {
      this._activeOperator.onMouseUp(event);
    }

    if (!(this._activeOperator instanceof CameraOrbitOperator)) {
      this._orbitOperator._removeMarkup();
    }

    super.onMouseUp(event);
  }

  /** @hidden */
  async onMousewheel(event) {
    await this._zoomOperator.onMousewheel(event);
  }

  /** @hidden */
  onTouchStart(event) {
    this._zoomOperator.onTouchStart(event);

    ++this._activeTouchCount;

    if (this._viewer.sheetManager.isDrawingSheetActive()) {
      //this._panOperator.onTouchStart(event);
      this._orbitOperator.onDeactivate();
    }

    if (this._activeTouchCount === 1) {
      this._primaryTouchId = event.getId();
      this._orbitOperator.onTouchStart(event);
      //this._zoomOperator.onTouchStart(event);
      //this._panOperator.onTouchStart(event);
    }

    if (this._activeTouchCount === 2) {
      this._orbitOperator.onDeactivate();
      //this._panOperator.onTouchStart(event);
    }

    //event.setHandled(true);
  }

  /** @hidden */
  onTouchMove(event) {
    this._zoomOperator.onTouchMove(event);

    ++this._touchMoveCount;
    let _activeOperator = nCircle.Ui.Toolbar.getActiveOperator();
    let _moveCount = 0;
    if (
      _activeOperator == markupAreaMeasureHandle ||
      _activeOperator == measureAngleOperatorHandle ||
      _activeOperator === Communicator.OperatorId.MeasurePointPointDistance
    )
      _moveCount = 30;
    else _moveCount = 15;

    if (this._touchMoveCount > _moveCount) {
      //user just released finger - restart orbit mode
      if (this._returnToOrbit) {
        this._orbitOperator.onTouchStart(event);
        this._returnToOrbit = false;
      } else if (this._activeTouchCount === 1) {
        this._orbitOperator.onTouchMove(event);
        //  this._panOperator.onTouchMove(event);
      }
      // else if (this._activeTouchCount === 2) {
      //  this._zoomOperator.onTouchMove(event);
      //  //this._panOperator.onTouchMove(event);
      //}
    }

    //call for every touchmove
    //if (this._activeTouchCount === 2) {
    //    this._zoomOperator.onTouchMove(event);
    //  //  //this._panOperator.onTouchMove(event);
    //}

    //event.setHandled(true);
  }

  /** @hidden */
  onTouchEnd(event) {
    this._zoomOperator.onTouchEnd(event);

    if (this._activeTouchCount === 2) {
      //at this point we are going to be going back to single touch orbit
      this._returnToOrbit = true;
    }

    // this._panOperator.onTouchEnd(event);
    this._orbitOperator.onTouchEnd(event);

    if (this._activeTouchCount > 0) {
      --this._activeTouchCount;
    }

    if (this._activeTouchCount === 0) {
      this._touchMoveCount = 0;
    }
  }

  /** @hidden */
  stopInteraction() {
    const ps = [];
    let p;

    p = super.stopInteraction();
    if (p !== undefined) {
      ps.push(p);
    }

    this._activeTouchCount = 0;
    this._touchMoveCount = 0;

    p = this._zoomOperator.onDeactivate();
    if (p !== undefined) {
      ps.push(p);
    }

    p = this._panOperator.onDeactivate();
    if (p !== undefined) {
      ps.push(p);
    }

    p = this._orbitOperator.onDeactivate();
    if (p !== undefined) {
      ps.push(p);
    }

    return Communicator.Util.waitForAll(ps);
  }

  _setActiveOperatorForMouseInput(event) {
    const orbitOperator = this._orbitOperator;
    const panOperator = this._panOperator;
    const zoomOperator = this._zoomOperator;

    this._activeOperator = null;

    if (this._viewer.sheetManager.isDrawingSheetActive()) {
      this._activeOperator = panOperator;
    } else {
      if (orbitOperator.checkMapping(event)) {
        this._activeOperator = orbitOperator;
      } else if (zoomOperator.checkMapping(event)) {
        this._activeOperator = zoomOperator;
      } else if (panOperator.checkMapping(event)) {
        this._activeOperator = panOperator;
      }
    }
  }

  /** @hidden */
  onDeactivate() {
    super.onDeactivate();

    this._orbitOperator.onDeactivate();
    this._panOperator.onDeactivate();
    this._zoomOperator.onDeactivate();
  }
}

var OrbitOperator = (function () {
  var _degreesPerPixel = 1.0;
  var _degreesPerPixelForX = 0.75;
  var _degreesPerPixelForY = 0.1;

  function setWalkOperatorTiltAngle(position, target) {
    const walkOp = hwv.view._viewer.operatorManager.getOperator(
      Communicator.OperatorId.Walk
    );
    const eye = Communicator.Point3.subtract(target, position);
    const projectedEye = new Communicator.Point3(eye.x, eye.y, 0);

    let deg = (Math.acos(projectedEye.length() / eye.length()) * 180) / Math.PI;

    if (position.z < target.z) {
      if (deg <= 43) walkOp._tilt = Math.max(-deg, -43);
      //nCircle.Navigation.WalkOperator.setTilt(Math.max(-deg, -43));
      else if (deg > 43 && deg < 45) walkOp._tilt = -43;

      //nCircle.Navigation.WalkOperator.setTilt(-43);
    } else {
      if (deg <= 43) walkOp._tilt = Math.min(deg, 43);
      //nCircle.Navigation.WalkOperator.setTilt( Math.min(deg, 43));
      else if (deg > 43 && deg < 45) walkOp._tilt = 43;
      //nCircle.Navigation.WalkOperator.setTilt(43);
    }
  }

  function getMouseMoveOffsetForRotation() {
    return [
      -this._mouseMoveOffset.x * _degreesPerPixelForX,
      this._mouseMoveOffset.y * _degreesPerPixelForY,
    ];
  }

  function orbitTurnTiltWithTarget(turnTilt, delta) {
    const view = this._viewer.view;
    const camera = view.getCamera();
    let position = camera.getPosition().subtract(delta);
    let target = camera.getTarget().subtract(delta);
    let up = camera.getUp().normalize();

    //for tilt
    //const originalEye = Communicator.Point3.subtract(target,position).normalize();

    const forward = Communicator.Point3.subtract(target, position).normalize();
    const left = Communicator.Point3.cross(up, forward).normalize();

    const turn = turnTilt[0];
    const tilt = turnTilt[1];
    //pitch
    let matrixTilt = new Communicator.Matrix();
    //yaw
    let matrixTurn = new Communicator.Matrix();

    if (this._bimOrbitEnabled) {
      const viewAxes = this._viewer.model.getViewAxes();
      const viewAxesUp = viewAxes.upVector.copy();

      // Rotate around camera left axis using y translation
      matrixTilt = this._getClampedRotationMatrix(left, tilt, up, viewAxesUp);
      // Rotate around the view axes up axis using x translation
      matrixTurn = Communicator.Matrix.createFromOffAxisRotation(
        viewAxesUp,
        turn / 4
      );

      const newPosition = matrixTurn.transform(matrixTilt.transform(position));
      const newTarget = matrixTurn.transform(matrixTilt.transform(target));
      const newUp = matrixTurn.transform(
        matrixTilt.transform(Communicator.Point3.add(position, up))
      );

      newUp.subtract(newPosition);

      position = newPosition;
      target = newTarget;
      up = newUp;
    } else {
      // Tilt around left axis using y translation
      matrixTilt = Communicator.Matrix.createFromOffAxisRotation(left, tilt);

      // Turn around up axis using x translation
      matrixTurn = Communicator.Matrix.createFromOffAxisRotation(up, turn);

      // Concatenate tilt/turn
      const matrixTiltTurn = Communicator.Matrix.multiply(
        matrixTurn,
        matrixTilt
      );

      const newPosition = matrixTiltTurn.transform(position);
      const newTarget = matrixTiltTurn.transform(target);
      const newUp = matrixTiltTurn.transform(
        Communicator.Point3.add(position, up)
      );

      newUp.subtract(newPosition);

      position = newPosition;
      target = newTarget;
      up = newUp;
    }

    position.add(delta);
    target.add(delta);

    camera.setPosition(position);
    camera.setTarget(target);
    camera.setUp(up);

    setWalkOperatorTiltAngle(position, target);

    view.setCamera(camera);
  }

  function getClampedRotationMatrix(axis, degrees, up, viewAxesUp) {
    const matrixTilt = Communicator.Matrix.createFromOffAxisRotation(
      axis,
      degrees
    );

    const newUp = Communicator.Point3.zero();
    matrixTilt.transform(up, newUp);

    const degreesUp = Math.asin(Communicator.Point3.dot(viewAxesUp, newUp));
    if (degreesUp <= 1 / Math.sqrt(2) + 0.1) {
      return new Communicator.Matrix();
    } else {
      return matrixTilt;
    }
  }

  function onTouchStart(b) {
    if (null === this._primaryTouchId) {
      this._primaryTouchId = b.getId();
      let a = b.getPosition();
      a = new Communicator.Event.MouseInputEvent(
        a.x,
        a.y,
        Communicator.Button.Left,
        b.getButtons(),
        Communicator.KeyModifiers.None,
        Communicator.MouseInputType.Down
      );
      this.onMouseDown(a);
    }
    b.setHandled(this.setHandled());
  }

  async function onTouchMove(b) {
    if (this._primaryTouchId === b.getId()) {
      var a = b.getPosition();
      a = new Communicator.Event.MouseInputEvent(
        a.x,
        a.y,
        Communicator.Button.Left,
        b.getButtons(),
        Communicator.KeyModifiers.None,
        Communicator.MouseInputType.Move
      );
      this.onMouseMove(a);
    }
    b.setHandled(this.setHandled());
  }

  function onTouchEnd(b) {
    if (this._primaryTouchId === b.getId()) {
      var a = b.getPosition();
      a = new Communicator.Event.MouseInputEvent(
        a.x,
        a.y,
        Communicator.Button.Left,
        b.getButtons(),
        Communicator.KeyModifiers.None,
        Communicator.MouseInputType.Up
      );
      this.onMouseUp(a);
      this._primaryTouchId = null;
    }
    b.setHandled(this.setHandled());
  }

  async function navCubeOnTouchEnd(event) {
    if (
      this._navCube.getEnabled() &&
      Communicator.Point2.subtract(
        this._ptFirst,
        this._ptCurrent
      ).squaredLength() < 25
    ) {
      const selection = await this._viewer.view.pickFromPoint(
        this._ptFirst,
        this._pickConfig
      );
      const camera = this._viewer.view.getCamera();
      var walkOp = this._viewer.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );
      //console.log(walkOp);
      const target = camera.getTarget();
      const position = camera.getPosition();

      const delta = Communicator.Point3.subtract(target, position);
      const l1 = delta.length();

      if (this._majorAxis === 0) delta.x = 0;
      else if (this._majorAxis === 1) delta.y = 0;
      else if (this._majorAxis === 2) delta.z = 0;

      const l2 = delta.length();
      const deg = Math.acos(l2 / l1) * (180.0 / Math.PI);

      walkOp._tilt = deg;
      await this._navCube.onClickSelection(selection);
    }
    //OperatorBase.prototype.onMouseUp.call(this,event);
  }

  return (() => {
    //let orbitOperator = hwv.operatorManager.getOperator(Communicator.OperatorId.Orbit);
    //OB_Z_Inclination_Issue
    Communicator.Operator.CameraOrbitOperator.prototype._getMouseMoveOffsetForRotation =
      getMouseMoveOffsetForRotation;

    //Clamp Tilt Angle to 45* to match with Look Joystick
    Communicator.Operator.CameraOrbitOperator.prototype._getClampedRotationMatrix =
      getClampedRotationMatrix;
    Communicator.Operator.CameraOrbitOperator.prototype._orbitByTurnTiltWithTarget =
      orbitTurnTiltWithTarget;

    //Touch Events
    Communicator.Operator.CameraOrbitBaseOperator.prototype.onTouchStart =
      onTouchStart;
    Communicator.Operator.CameraOrbitBaseOperator.prototype.onTouchEnd =
      onTouchEnd;
    Communicator.Operator.CameraOrbitBaseOperator.prototype.onTouchMove =
      onTouchMove;

    Communicator.Operator.CameraOrbitBaseOperator._bimOrbitEnabled = true;
    Communicator.Operator.CameraOrbitBaseOperator._degreesPerPixel =
      _degreesPerPixel;
    Communicator.Operator.CameraOrbitOperator._primaryButton =
      Communicator.Button.Left;

    Communicator.Operator.NavCubeOperator.prototype.onMouseUp =
      navCubeOnTouchEnd;

    return {
      setDegreesPerPixel: function (degreesPerPixel) {
        _degreesPerPixel = degreesPerPixel;
      },

      getDegreesPerPixel: function () {
        return _degreesPerPixel;
      },
    };
  })();
})();

//call in scene ready
function NavigationChanges() {
  const custZoomOp = new CustomCameraZoomOperator(hwv);
  Communicator.OperatorId.custZoomOpId =
    hwv.operatorManager.registerCustomOperator(custZoomOp);

  const custPanOp = new CustomCameraPanOperator(hwv);
  Communicator.OperatorId.custPanOpId =
    hwv.operatorManager.registerCustomOperator(custPanOp);

  var orbitOperator = hwv.operatorManager.getOperator(
    Communicator.OperatorId.Orbit
  );

  orbitOperator.setBimOrbitEnabled(true);
  orbitOperator.setPrimaryButton(Communicator.Button.Left);

  const custNavigationOp = new CustomCameraNavigationOperator(
    hwv,
    orbitOperator,
    custPanOp,
    custZoomOp
  );
  Communicator.OperatorId.custNavigationOpId =
    hwv.operatorManager.registerCustomOperator(custNavigationOp);

  hwv.operatorManager.set(Communicator.OperatorId.custNavigationOpId, 0);
}

function setZoomMultiplier(multiplier){

}

function setPanMultiplier(multiplier){

}