class RedlineTextOperatorEx extends Communicator.RedlineOperator {
    constructor(viewer) {
      super(viewer);
      this._redlineText;
      this._redlinteTextItems = new Set();
    }
  
    createRedlineItem(_position) {
      this._redlineText = new RedlineTextEx(
        this._viewer
      );
      this._redlineText.setPosition(_position);
      return this._redlineText;
    }
  
    addItem(item){
      this._redlinteTextItems.add(item);
    }
  
    finalizeRedlineItem(position) {
      if (this._redlineText === null) {
        return null;
      }
  
      const view = this._viewer.view;
      const redlineText = this._redlineText;
      const cameraPoint = view
        .getCamera()
        .getCameraPlaneIntersectionPoint(position, view);
  
      if (cameraPoint !== null) {
        redlineText.setPosition(cameraPoint);
      }
      this._redlineText = null;
      return redlineText;
    }
  
    clear(){
      Array.from(this._redlinteTextItems).forEach((item) => {
          this._viewer.markupManager.removeMarkupElement(item);
        });
      
      this._redlinteTextItems.clear();
      hwv.view.setCamera(hwv.view.getCamera());
      //hwv.redraw();
    }
  }
  
  class RedlineTextElementEx {
    static _defaultSize = new Communicator.Point2(100, 100);
  
    constructor(sizeUpdateCallback, textUpdateCallback) {
      this._textArea;
      this._currentSize;
      this._sizeChanged = false;
  
      this._sizeUpdateCallback = sizeUpdateCallback;
      this._textUpdateCallback = textUpdateCallback;
      this._createTextBox();
    }
  
    _createTextBox() {
      this._currentSize = RedlineTextElementEx._defaultSize.copy();
  
      this._textArea = document.createElement("textarea");
      this._textArea.style.position = "absolute";
      this._textArea.placeholder = RedlineTextEx.defaultText;
  
      this._textArea.style.width = `${RedlineTextElementEx._defaultSize.x}px`;
      this._textArea.style.height = `${RedlineTextElementEx._defaultSize.y}px`;
      this._textArea.style.zIndex = "100000";
      this._textArea.style.pointerEvents = "none";
      this._textArea.style.resize = "none";
      this.setBorderWidth(2);
  
      this.setAdditionalParameters();
      
  
      // Workaround to have html2canvas to break words
      this._textArea.style.letterSpacing = "1px";
  
      this.setBorderWidth(2);
  
      this._textArea.onmousemove = (event) => {
        event.stopPropagation();
        const size = new Communicator.Point2(
          parseInt(this._textArea.style.width, 10),
          parseInt(this._textArea.style.height, 10)
        );
        this.setSize(size);
      };
  
      this._textArea.onmouseup = (event) => {
        event.stopPropagation();
        if (this._sizeChanged) {
          this._sizeChanged = false;
          this._sizeUpdateCallback(this._currentSize);
        }
      };
  
      const textFunc = () => {
        this._textUpdateCallback(this._textArea.value);
      };
  
      this._textArea.oninput = textFunc;
    }
  
    setAdditionalParameters(){
      this._textArea.style.fontSize = redlineMarkupTextSize + "px";
        this._textArea.style.color = rgb2Hex(Number(redlineMarkupColor.r), Number(redlineMarkupColor.g), Number(redlineMarkupColor.b));
        this._textArea.style.outlineColor = rgb2Hex(redlineMarkupColor.r, redlineMarkupColor.g, redlineMarkupColor.b);
        this._textArea.style.outlineStyle = "solid";
        this._textArea.style.fontWeight = redlineMarkupTextBold;
        this._textArea.style.fontStyle = redlineMarkupTextItalic;
        this._textArea.style.textDecoration = redlineMarkupTextUnderline;
    }
  
    setPosition(pos) {
      this._textArea.style.left = `${pos.x}px`;
      this._textArea.style.top = `${pos.y}px`;
    }
  
    setBorderWidth(borderWidth) {
      this._textArea.style.outlineWidth = `${borderWidth}px`;
    }
  
    setText(text) {
      this._textArea.textContent = text;
    }
  
    setSize(size) {
      if (!this._currentSize.equals(size)) {
        this._sizeChanged = true;
        this._currentSize.assign(size);
        this._textArea.style.width = `${size.x}px`;
        this._textArea.style.height = `${size.y}px`;
      }
    }
  
    focus() {
      this._textArea.focus();
      this._textArea.style.pointerEvents = "auto";
      this._textArea.style.resize = "both";
    }
  
    blur() {
      this._textArea.blur();
      this._textArea.style.pointerEvents = "none";
      this._textArea.style.resize = "none";
    }
  
    getTextArea() {
      return this._textArea;
    }
  }
  
  class RedlineTextEx extends Communicator.Markup.Redline.RedlineItem {
    static className = "Communicator.Markup.Redline.RedlineText";
    static defaultText = "Type Here...";
    constructor(viewer, text) {
      super(viewer);
      this._uniqueId = Communicator.UUID.create();
  
      this._position = Communicator.Point3.zero();
      this._size = new Communicator.Point2(100, 100);
      this._text;
  
      this._redlineTextElement = null;
      this._redlineElementId = null;
  
      this._previousDragPlanePosition = Communicator.Point3.zero();
  
      this._callbacks;
  
      if(!text)
        this._text = "";
      
      else
      this._text = text;
  
      const sizeUpdateFunc = (size) => {
        this.setSize(size);
      };
  
      const textUpdateFunc = (newText) => {
        this.setText(newText);
      };
  
      this._redlineTextElement = new RedlineTextElementEx(
        sizeUpdateFunc,
        textUpdateFunc
      );
  
      this._redlineTextElement.setText(this._text);
  
      this._callbacks = {
        selectionArray: () => {
          this.onDeselect();
        },
      };
      this._viewer.setCallbacks(this._callbacks);
    }
  
    setPosition(point) {
      this._position.assign(point);
    }
  
    getPosition() {
      return this._position.copy();
    }
  
    setSize(size) {
      this._size.assign(size);
      this._redlineTextElement.setSize(size);
      this._viewer.trigger("redlineUpdated", this);
    }
  
    getSize() {
      return this._size.copy();
    }
  
    setText(text) {
      this._text = text;
      this._redlineTextElement.setText(text);
      this._viewer.trigger("redlineUpdated", this);
    }
  
    getText() {
      return this._text;
    }
  
    draw() {
      const screenPos = Communicator.Point2.fromPoint3(
        this._viewer.view.projectPoint(this._position)
      );
  
      this._redlineTextElement.setPosition(screenPos);
  
      if (this._redlineElementId === null) {
        this._redlineElementId = this._viewer.markupManager.addMarkupElement(
          this._redlineTextElement.getTextArea()
        );
        hwv.operatorManager.getOperator(Communicator.OperatorId.CustomTextOperatorEx).addItem(this._redlineElementId);
      }
    }
  
    hit(point) {
      return this.hitWithTolerance(point, 0);
    }
  
    hitWithTolerance(point, pickTolerance) {
      const element = this._redlineTextElement.getTextArea();
      const screenPos = new Communicator.Point2(
        parseFloat(element.style.left || "0"),
        parseFloat(element.style.top || "0")
      );
      const size = new Communicator.Point2(
        parseFloat(element.style.width || "0"),
        parseFloat(element.style.height || "0")
      );
  
      return Communicator.Util.isPointInRect2d(
        point,
        screenPos,
        size,
        pickTolerance
      );
    }
  
    getClassName() {
      return RedlineTextEx.className;
    }
  
    onSelect() {
      this._redlineTextElement.setBorderWidth(4);
      this._redlineTextElement.focus();
    }
  
    onDeselect() {
      this._redlineTextElement.setBorderWidth(2);
      this._redlineTextElement.blur();
    }
  
    isValid() {
      return this._text.length > 0;
    }
  
    remove() {
  
      if(!this.isValid()){
      if (this._redlineElementId) {
        this._viewer.markupManager.removeMarkupElement(this._redlineElementId);
        this._redlineElementId = null;
      }
  
      if (this._callbacks !== null) {
        this._viewer.unsetCallbacks(this._callbacks);
        this._callbacks = null;
      }
  
      super.remove();
    }
    }
  
    // drag methods and drop methods
  
    onDragStart(position) {
      const view = this._viewer.view;
      const cameraPoint = view
        .getCamera()
        .getCameraPlaneIntersectionPoint(position, view);
      if (cameraPoint !== null) {
        this._previousDragPlanePosition.assign(cameraPoint);
      }
      return false;
    }
  
    onDragMove(position) {
      const view = this._viewer.view;
      const cameraPoint = view
        .getCamera()
        .getCameraPlaneIntersectionPoint(position, view);
      if (cameraPoint !== null) {
        const delta = Communicator.Point3.subtract(
          cameraPoint,
          this._previousDragPlanePosition
        );
  
        const textPos = this.getPosition();
        textPos.add(delta);
        this.setPosition(textPos);
  
        this._previousDragPlanePosition.assign(cameraPoint);
      }
      return true;
    }
  
    // Serialization methods
  
    /**
     * Creates an object ready for JSON serialization.
     * @returns The prepared object.
     */
    toJson() {
      return this._toJson();
    }
  
    _toJson() {
      return {
        uniqueId: this._uniqueId,
        className: this.getClassName(),
        position: this._position.toJson(),
        size: this._size.toJson(),
        text: this._text,
        fontsize: this._redlineTextElement._textArea.style.fontSize,
              textColor: this._redlineTextElement._textArea.style.color,
              outlineColor: this._redlineTextElement._textArea.style.outlineColor,
              fontWeight: this._redlineTextElement._textArea.style.fontWeight,
              textItalic: this._redlineTextElement._textArea.style.fontStyle,
              textUnderline: this._redlineTextElement._textArea.style.textDecoration,
      };
    }
  
    /** @deprecated Use [[toJson]] instead. */
    forJson() {
      return this.toJson();
    }
  
    /**
     * Creates a new [[RedlineText]] from an object given by [[toJson]].
     * @param objData An object given by [[toJson]].
     * @returns The prepared object.
     */
    static fromJson(objData, viewer) {
      const obj = objData;
  
      const redlineText = new RedlineTextEx(viewer, obj.text);
  
      redlineText._uniqueId = obj.uniqueId;
      redlineText.setPosition(Communicator.Point3.fromJson(obj.position));
      redlineText.setSize(Communicator.Point2.fromJson(obj.size));
      redlineText._redlineTextElement._textArea.style.fontSize      = obj.fontsize;
          redlineText._redlineTextElement._textArea.style.color         = obj.textColor;
          redlineText._redlineTextElement._textArea.style.outlineColor  = obj.outlineColor;
          redlineText._redlineTextElement._textArea.style.fontWeight    = obj.fontWeight;
          redlineText._redlineTextElement._textArea.style.fontStyle     = obj.textItalic;
          redlineText._redlineTextElement._textArea.style.textDecoration= obj.textUnderline;
  
      return redlineText;
    }
  
    /** @deprecated Use [[fromJson]] instead. */
    static construct(obj, viewer) {
      return RedlineTextEx.fromJson(obj, viewer);
    }
  }
  
  