var degreesPerPixelForX = 1.1; //This is used to inc/dec the mouse sensitivity in horizontal direction
var degreesPerPixelForY = 0.1; //This is used to inc/dec the mouse sensitivity in verticle direction
var zoomDeltaForMouseMove = 3; //This variable is used to inc/dec the zoom speed on mouse move, default value is 3.
var panSpeedForMouseMove = 0.1; //This variable is used to inc/dec speed of Pan speed
var progressiveZoomDeltaForMouseScroll = 0.05; //This variable is used to inc/dec the progressive zoom speed on mouse scroll which is implemented by ncircletech.
var CamPostargetDistance = null; //variable to maintain distance betweeen camera target and position
var arcRadiusScaleFactor = 0.5; // Angle using three points : Scale factor for calculating arc radius using length scaleing of smallest line
var progressiveZoomDeltaForTouchPinch = 2.5; //
var resetwalkposition;
//Global variables to match Asite settings - START
var frameRatePerSec = 5;
var hiddenLineOpacity = 0;
var backFacesVisible = true;
var cappingGeomVisibility = true;
var enableFaceNLineSel = true;
var rotateAroundCamCenter = false;
var enableAmbientOcclusion = false;
var enableAntiAliasing = true;
var enableBloom = false;
var enableSilhouetteEdge = false;
var enableReflectionPlanes = false;
var enableShadows = false;
var showAxisTriad = false;
var showNavCube = true;
var enableEyeDomeLighting = false;
var topBGColor = new Communicator.Color(225.0, 225.0, 225.0);
var bottomBGColor = new Communicator.Color(255, 255, 255);
var cappingFaceColor = new Communicator.Color(194, 0, 0);
var cappingLineColor = new Communicator.Color(0, 98, 255);
var bodySelectionColor = new Communicator.Color(255, 255, 0);
var faceNLineSelectionColor = new Communicator.Color(255, 255, 0);
var measurementColor = new Communicator.Color(0, 255, 0);
var pmiColorOverride = true;
var pmiColor = new Communicator.Color(0, 0, 0);

var zoomLensOperator = null;
var zoomLensOperatorHandle = -1;
var distanceOperatorHandle = -1;
var bError = false;
var bDeactivateStreaming = false;

//walk mode (Mouse/Keyboard)
var walkMode = Communicator.WalkMode.Mouse;
// left/right movement speed while using Keyboard walk
var keyBoardWalkRotationSpeed = 20;
// forward/back walk speed while using Keyboard walk
var keyboardWalkSpeed = 1500;
//Elevation speed decides up / down movement of using keyboard walk mode (default keys - x/c)
var elevationSpeed = 2000;
//Field of view
var viewAngle = 100;
//Enable mouse look functionality in walk mode
var enableMouseLook = true;
//Mouse look speed is for functionality in mouse walk mode(shift + left mouse) / keyboard walk mode (left mouse)
var mouseLookSpeed = 100;
var enableCollisionDetection = true;
// left/right movement speed while using mouse walk
var mouseWalkRotationSpeed = 30;
// forward/back walk speed while using mouse walk
var mouseWalkSpeed = 1.0;
//Active measurement tool operator
var activeMeasureOperatorId = Communicator.OperatorId.Invalid;

//Point to point Measure markup sphere radius
var ptpMarkupSphereRadius = 10; //5.0; // Default value is 2.5
//Point to point Measure markup line color (includes arrows color at line ends)
var ptpMarkupLineColor = new Communicator.Color(0, 0, 255); //Default color is black
//Point to Point Measure markup point shape color
var ptpPointShapeColor = new Communicator.Color(255, 0, 0);
//Point to point Measure markup line thickness
var ptpMarkupLineThickness = 1.7; //1.3; //Default value is 1.5
//Point to point Measure markup text font size
var ptpMarkupTextFontSize = 17; //Default value is 12
//Point to point Measure markup text box and text color
var ptpMarkupTextBoxColor = new Communicator.Color(0, 0, 255); //Default color is black
//Distance between txt and out box boundary. This need to be adjusted if ptpMarkupTextFontSize is changed
var ptpMarkupTextBoxPadding = 8; //Default value is 5
//Handle to Measure Angle using three point operator
var measureAngleOperatorHandle = -1;
//Handle to Redline StraightLine markup
var markupStraightLineHandle = -1;
//Handle to Redline Arrow markup
var markupArrowHandle = -1;
//Handle to Redline Cloud markup
var markupCloudHandle = -1;
//Handle for Area Measure operator
var markupAreaMeasureHandle = -1;
//Handle for Area Measure operator
var markupPinHandle = -1;
//Cloud markup arc symbol radius
var cloudMarkupArcRadius = 8;
//Cloud Markup arc side count
var cloudMarkupArcSideCount = 10;
//Arrow Markup end cal size
var arrowMarkupEndCapSize = 4; //Default value is 9, inc/dec the size end cap (arrow/circle)
//variable to keep record of selected markup (singlr/multiple), deselection  will empty all the items.
var selected3DPinMarkups = [];
//Object to store 3D Pin markup Flag (name, color) set.
var objectFlags = { FlagOne: "#cccc00", FlagTwo: "#ff66ff" };
//object to store the show/hide status of 3D Pin markup Flag (Flagname-status) (show - true, hide - false
var objectFlagsVisibilityState = { FlagOne: true, FlagTwo: true };
//varible to store 3D Pin Markup Flag selection dialog container
var pinElementContainer = null;
//Variable to adjust the size of 3D Pin markup. (length of stem and radius of circle)
var pinMarkupSize = 10;
//variable to adjust highlight size od 3D Pin. (adds the number to Pins length of stem and radius of circle)
var pinHighlightsize = 4;
//Dashed line length (length of single dash)
var dashedLineSingleDashLength = 30;
//Redline custom operator handles
var redlineCircleExOperatorHandle = -1;
var redlineRectangleExOperatorHandle = -1;
var redlinePolylineExOperatorHandle = -1;
var redlineTextOperatorHandle = -1;
var measureAreaOperator = null;
//Variables to store the status of Redline Markup UI. Used them while creating next Redline Markup.
var redlineMarkupColor = Communicator.Color.red(); //Used for color picker
var redlineMarkupLineThickness = 2;
var redlineMarkupTextSize = 14;
var redlineMarkupTextBold = "";
var redlineMarkupTextItalic = "";
var redlineMarkupTextUnderline = "";
var redlineMarkupArrowHeadType = Communicator.Markup.Shape.EndcapType.Arrowhead;
//Object (key-value) for color settings on model objects identified by model compare feature
var nodeIDVsColorMap = {};
var nodeIDVsGenericIDMap = {};
var toggleStateForModelColors = false; //false represents unsetting of color on nodes
var genericIdVsNodeIdArrayMap = {};
var nodeIDVsColorTempMap = {};
//To identify the file type
var fileType = Communicator.FileType.Unknown;
//Variable to inc/decr the length of dashes in a dshed line. This is division factor (range: 100,200 - 900,1000)
var divisionFactorForDashLength = 4500; //default value is 700. Increase the factor value to decrease the dash length
//Bounding box of model
var boundBoxModel = null;
//Variable to detect double click in viewport
var firstMouseDownTime = null;
var doubleClickInterval = 200;
//Toggle state of model tree nodes
var toggleStateModelTreeNodes = true; //true repesent hide the nodes, false represent show the nodes.
//To change the tolerance (in pixel) for picking a point on model
var pickTolerance = 1; //Default HC value is 20
//Pin markup stem thickness (setStrokeWidth)
var pinMarkupStemThickness = 2;
//Pin markup circle opacity
var pinMarkupOpacity = 0.4;
//Global variables to match Asite settings - END
//Unit types required for length conversion between one type to another
var loadedModels = 0;
var unitType = [];

var calibrationManager = null;
var PinManager = null;


unitType[(unitType.mm = 0)]               = "mm";
unitType[(unitType.cm = 1)]               = "cm";
unitType[(unitType.m = 2)]                = "m";
unitType[(unitType.inch = 3)]             = "inch";
unitType[(unitType.feet = 4)]             = "foot";
unitType[(unitType.fractional_inch = 5)]  = "fractional inch";
unitType[(unitType.fractional_foot = 6)]   = "fractional foot";
//Multiplier required for conversion between one type to another
var unitMultiplier = [];
unitMultiplier[(unitMultiplier.mm = 1)] = "mm";
unitMultiplier[(unitMultiplier.cm = 10)] = "cm";
unitMultiplier[(unitMultiplier.m = 1000)] = "m";
unitMultiplier[(unitMultiplier.inch = 25.4)] = "inch";
unitMultiplier[(unitMultiplier.feet = 12 * 25.4)] = "feet";
//Precision (number) for Measurement value
var measureValuePrecision = [];
measureValuePrecision[(measureValuePrecision.zero = 0)]  = "zero";
measureValuePrecision[(measureValuePrecision.one = 1)]   = "one";
measureValuePrecision[(measureValuePrecision.two = 2)]   = "two";
measureValuePrecision[(measureValuePrecision.three = 3)] = "three";
measureValuePrecision[(measureValuePrecision.four = 4)]  = "four";
measureValuePrecision[(measureValuePrecision.five = 5)]  = "five";
//Unit types required for angle conversion
var angleUnitType = [];
angleUnitType[(angleUnitType.Degrees = 0)]                = "Degrees";
angleUnitType[(angleUnitType.DegreesMinutesSeconds = 1)]  = "DegreesMinutesSeconds";
angleUnitType[(angleUnitType.Radians = 2)]                = "Radians";
//Unit types for measured area Area
var areaUnitType = [];
areaUnitType[(areaUnitType.sqmm = 0)]     = "mm";
areaUnitType[(areaUnitType.sqcm = 1)]     = "cm";
areaUnitType[(areaUnitType.sqm = 2)]      = "m";
areaUnitType[(areaUnitType.sqinch = 3)]   = "inch";
areaUnitType[(areaUnitType.sqfeet = 4)]   = "foot";
areaUnitType[(areaUnitType.acre = 5)]     = "Acre";
areaUnitType[(areaUnitType.hectare = 6)]  = "hectare";
//Object validation status (3DPin)
var pinObjectStatus = [];
pinObjectStatus[(pinObjectStatus.same = 0)] = "same";
pinObjectStatus[(pinObjectStatus.deleted = 1)] = "deleted";
pinObjectStatus[(pinObjectStatus.modifiedBB = 2)] = "modifiedBB";
pinObjectStatus[(pinObjectStatus.modifiedName = 3)] = "modifiedName";
pinObjectStatus[(pinObjectStatus.none = 4)] = "none";

//BCF ViewPoint Manager
var bcfViewPointMangerObj = null;

//BCF ViewPoint Manager
var typePropertiesImportObj = null;
//map to reprsent persistent Id Vs node array
var persistentIDVsNodeArray = {};
//Map to reperesent the nodes which are made transparent, "value" used in pairs added is dummy , we just need node Ids as "Key". Map is used, since its easy to delete item from map than array
var transparentNodeMap = {};
//Temporary Map to reperesent the nodes which are made transparent,  when a viewpoint is activate
var transparentNodeTempMap = {};
//Array to represents the nodes selected for "isolate"
var isolateNodesArray = [];
//Array to represents the nodes selected for "Focus"
var focusNodesArray = [];
//Temporary array to repesetnt the nodes selected for "Focus" when a viewpoint is activate
var focusNodesTempArray = [];
//Map to represent space node ID vs Guid
var spaceNodeIDVsGuidMap = {};
//Flag which is made true when a viewpoint is activated, made false when viewpoint is reset
var isViewPointActive = false;
// RK - 2
var collectUniqueModelsNodes = [];
var modelBrowserContextMenu = null;
var viewerContextMenu = null;
var RevitFileObjectListObj = null;
var modelCompareObj = null;
var selectedForCompare = [];
var AllTreeTabNodeIds = [];
var AllLeafNodeIds = [];
var allTreeTabNodesPropertiesMap = {};
var typeTreeUpdated = false;
var selectionArray = [];
var enablePanMode = false;
var WalkPanelObj = null;
//RK - 2
//Default unit for measurement tool (updates from UI)
var desiredUnitForMeasurement = unitType.mm;
//Precision for measurement value
var measureValueForPrecision = measureValuePrecision.zero;
//Angle Unit for measurement
var AngleUnitForMeasurement = angleUnitType.Degrees;
//Area unit for measurement
var AreaUnitForMeasurement = areaUnitType.sqm;

function rgb2Hex(r, g, b) {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

/*function hex2rgb(hex) {
  return ['0x' + hex[1] + hex[2] | 0, '0x' + hex[3] + hex[4] | 0, '0x' + hex[5] + hex[6] | 0];
  }
*/

function hexToRgb(hex) {
  // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
  var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  hex = hex.replace(shorthandRegex, function (m, r, g, b) {
    return r + r + g + g + b + b;
  });

  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}

//Convert string "rgb(88, 241, 14)" to color object
function rgbStringToColorObject(a) {
  a = a.replace(/[^\d,]/g, "").split(",");
  if (a.length === 3) {
    return new Communicator.Color(Number(a[0]), Number(a[1]), Number(a[2]));
  }
  return null;
}

function colorObjectToRgbString(color) {
  if (!color) {
    return "";
  }
  return (
    "rgb(" +
    Math.round(color.r) +
    "," +
    Math.round(color.g) +
    "," +
    Math.round(color.b) +
    ")"
  );
}

//Update Redline markup Configuration UI with the data from created/selected markup
var UpdateMarkupUI = function (hwv) {
  //reset the configuration dialog
  ResetMarkupConfigDialog();

  //Get the selected markup. When new markup drawn, it is added to selection.
  var markup = hwv.markupManager.getSelectedMarkup();
  if (markup) {
    var markupName = markup.getClassName();
    var color = null,
      lineThickness = null,
      textSize = null,
      arrow = null,
      textBoldStyle = "",
      textUnderlineStyle = "",
      textItalicStyle = "";
    switch (markupName) {
      case "RedlineStraightline":
        arrow = markup.getEndEndcapType();
      case "RedlineCloud":
        color = markup.getLineColor();
        lineThickness = markup.getLineThickness();
        break;
      case "Communicator.Markup.Redline.RedlineRectangleEx":
        color = markup._rectangleShape.getStrokeColor();
        lineThickness = markup.getLineThickness();
        break;
      case "Communicator.Markup.Redline.RedlineCircleEx":
        color = markup._circleShape.getStrokeColor();
        lineThickness = markup.getLineThickness();
        break;
      case "Communicator.Markup.Redline.RedlinePolylineEx":
        color = markup._polylineShape.getStrokeColor();
        lineThickness = markup.getLineThickness();
        break;
      case "Communicator.Markup.Redline.RedlineTextEx":
        textSize = markup._redlineTextElement._textArea.style.fontSize;
        if (textSize === null || textSize === "") textSize = "14px";
        textSize = textSize.replace(/\D/g, ""); // retrive just the number part.
        color = markup._redlineTextElement._textArea.style.color;
        //Set the default colot to text box text as red (empty string represents black color). Border color is already set as Red using HC code.
        if (color === "") {
          color = Communicator.Color.red();
          markup._redlineTextElement._textArea.style.color = rgb2Hex(255, 0, 0);
        } else {
          color = rgbStringToColorObject(color);
          //Set text border color here as the border color is reset to red by HC selection code and changed color is lost. Use text color to update border color again.
          markup._redlineTextElement._textArea.style.outlineColor = rgb2Hex(
            color.r,
            color.g,
            color.b
          );
        }

        textBoldStyle = markup._redlineTextElement._textArea.style.fontWeight;
        textItalicStyle = markup._redlineTextElement._textArea.style.fontStyle;
        textUnderlineStyle =
          markup._redlineTextElement._textArea.style.textDecoration;

        break;
    }

    //Update configuration Ui with data from selected markup.
    if ($("#redline-markup-color").hasClass("color-picker"))
      $("#redline-markup-color").minicolors(
        "value",
        colorObjectToRgbString(color)
      );
    else if (color)
      document.getElementById("redline-markup-color").value = rgb2Hex(
        color.r,
        color.g,
        color.b
      );

    if (lineThickness)
      document.getElementById("redline-markup-line-thickness").value =
        lineThickness;
    if (textSize)
      document.getElementById("redline-markup-text-size").value = textSize;
    textBoldStyle === ""
      ? (document.getElementById(
          "redline-markup-config-text-bold"
        ).style.border = "")
      : (document.getElementById(
          "redline-markup-config-text-bold"
        ).style.border = "solid");
    textItalicStyle === ""
      ? (document.getElementById(
          "redline-markup-config-text-italic"
        ).style.border = "")
      : (document.getElementById(
          "redline-markup-config-text-italic"
        ).style.border = "solid");
    textUnderlineStyle === ""
      ? (document.getElementById(
          "redline-markup-config-text-underline"
        ).style.border = "")
      : (document.getElementById(
          "redline-markup-config-text-underline"
        ).style.border = "solid");
    if (arrow)
      document.getElementById("redline-markup-arrow-head-type").value =
        arrow === Communicator.Markup.Shape.EndcapType.Arrowhead
          ? "Arrow"
          : "Dot";
  }
};

//Update the data modified from UI to selected markup.
var UpdateMarkup = function (hwv, markup) {
  //Get the selected markup. When new markup drawn, it is added to selection.
  markup = markup ? markup : hwv.markupManager.getSelectedMarkup();
  if (markup) {
    var color = null;
    if ($("#redline-markup-color").hasClass("color-picker"))
      color = rgbStringToColorObject($("#redline-markup-color").val());
    else {
      var hex = document.getElementById("redline-markup-color").value;
      color = hexToRgb(hex);
    }

    var lineThickness = document.getElementById(
      "redline-markup-line-thickness"
    ).value;
    var arrowType = document.getElementById(
      "redline-markup-arrow-head-type"
    ).value;
    var arrow =
      arrowType === "Arrow"
        ? Communicator.Markup.Shape.EndcapType.Arrowhead
        : Communicator.Markup.Shape.EndcapType.Circle;
    var textSize = document.getElementById("redline-markup-text-size").value;
    var isTextBold =
      document
        .getElementById("redline-markup-config-text-bold")
        .style.border.indexOf("solid") >= 0;
    var isTextItalic =
      document
        .getElementById("redline-markup-config-text-italic")
        .style.border.indexOf("solid") >= 0;
    var isTextUnderline =
      document
        .getElementById("redline-markup-config-text-underline")
        .style.border.indexOf("solid") >= 0;

    //Update global variables which will be used while drawing next redline markup.
    redlineMarkupColor.set(color.r, color.g, color.b);
    redlineMarkupLineThickness = parseInt(lineThickness);
    redlineMarkupTextSize = parseInt(textSize);
    redlineMarkupTextBold = isTextBold ? "bold" : "";
    redlineMarkupTextItalic = isTextItalic ? "italic" : "";
    redlineMarkupTextUnderline = isTextUnderline ? "underline" : "";
    redlineMarkupArrowHeadType = arrow;

    var markupName = markup.getClassName();
    switch (markupName) {
      case "RedlineStraightline":
        markup.setEndEndcapType(arrow);
      case "RedlineCloud":
        markup.setLineColor(new Communicator.Color(color.r, color.g, color.b));
        markup.setLineThickness(parseInt(lineThickness));
        break;
      case "Communicator.Markup.Redline.RedlineRectangleEx":
        markup._rectangleShape.setStrokeColor(
          new Communicator.Color(color.r, color.g, color.b)
        );
        markup.setLineThickness(parseInt(lineThickness));
        break;
      case "Communicator.Markup.Redline.RedlineCircleEx":
        markup._circleShape.setStrokeColor(
          new Communicator.Color(color.r, color.g, color.b)
        );
        markup.setLineThickness(parseInt(lineThickness));
        break;
      case "Communicator.Markup.Redline.RedlinePolylineEx":
        markup._polylineShape.setStrokeColor(
          new Communicator.Color(color.r, color.g, color.b)
        );
        markup.setLineThickness(parseInt(lineThickness));
        break;
      case "Communicator.Markup.Redline.RedlineTextEx":
        //markup._redlineTextElement._textArea.style.outline = lineThickness + "px solid " + hex;
        //markup._redlineTextElement._textArea.style.outlineColor = hex;
        markup._redlineTextElement._textArea.style.fontSize = textSize + "px";
        markup._redlineTextElement._textArea.style.color = rgb2Hex(
          color.r,
          color.g,
          color.b
        );
        markup._redlineTextElement._textArea.style.outlineColor = rgb2Hex(
          color.r,
          color.g,
          color.b
        );
        markup._redlineTextElement._textArea.style.fontWeight = isTextBold
          ? "bold"
          : "";
        markup._redlineTextElement._textArea.style.fontStyle = isTextItalic
          ? "italic"
          : "";
        markup._redlineTextElement._textArea.style.textDecoration =
          isTextUnderline ? "underline" : "";
        break;
    }

    hwv.markupManager.refreshMarkup();
  }
};

///////////////Custom Operators- Start////////////////////////////////////

//Class to draw markup when cursor/mouse pointer moves when operator is active
class cursorMarkup extends Communicator.Markup.Measure.MeasureMarkup {
  constructor(viewer) {
    super();
    this._viewer = viewer;
    this._cursorSprite = new Communicator.Markup.Shape.Circle();
    this._name = "CursorMarkup";
    this._cursorSprite.setFillColor(
      this._viewer.measureManager.getMeasurementColor()
    );
    this._markupId = this._viewer.markupManager.registerMarkup(this);
  }

  draw() {
    this._viewer.markupManager.getRenderer().drawCircle(this._cursorSprite);
  }

  enable(a) {
    this._cursorSprite.setRadius(a ? 10.0 : 0);
  }

  setPosition(a) {
    this._cursorSprite.setCenter(a);
  }

  destroy() {
    this._viewer.markupManager.unregisterMarkup(this._markupId);
  }
}

//Markup class to find angle by placing three points on face/edge
window.MeasureThreePointsAngleMarkup = class MeasureThreePointsAngleMarkup extends (
  Communicator.Markup.Measure.MeasureMarkup
) {
  constructor(viewer) {
    super();
    this._viewer = viewer;
    //Three circle shapes to represent points picked face/edges
    this._firstPointShape = new Communicator.Markup.Shape.Circle();
    this._secondPointShape = new Communicator.Markup.Shape.Circle();
    this._thirdPointShape = new Communicator.Markup.Shape.Circle();
    this._name = "MeasureThreePointsAngle";
    //Sphere point radius
    this._pointShapeRadius = 5.0;
    //Set properties to sphere shape points
    this.initCircle(this._firstPointShape);
    this.initCircle(this._secondPointShape);
    this.initCircle(this._thirdPointShape);
    //Line shape entities to draw two lines using three points
    this._lineShapes = [];
    for (var e = 0; 3 > e; e++)
      this._lineShapes.push(new Communicator.Markup.Shape.Line()),
        this._lineShapes[e].setStrokeColor(ptpMarkupLineColor),
        this._lineShapes[e].setEndEndcapColor(ptpMarkupLineColor),
        this._lineShapes[e].setStartEndcapColor(ptpMarkupLineColor),
        this._lineShapes[e].setStrokeWidth(ptpMarkupLineThickness);
    //2d points projected on canvas to draw shapes
    this.point2d = [];
    //Text box to display angle between two lines
    this._textShape = new Communicator.Markup.Shape.TextBox();
    this._textShape.getBoxPortion().setFillOpacity(1);
    this._textShape.getBoxPortion().setStrokeColor(ptpMarkupTextBoxColor);
    this._textShape._text.setFontSize(ptpMarkupTextFontSize);
    this._textShape._text.setFillColor(ptpMarkupTextBoxColor);
    this._textShape.setPadding(ptpMarkupTextBoxPadding);
    //Poly line shape to draw angle symbol (arc) between two lines
    this._polyLineGeometryShape = new Communicator.Markup.Shape.Polyline();
    this._polyLineGeometryShape.setStrokeWidth(ptpMarkupLineThickness);
    this._polyLineGeometryShape.setStrokeColor(ptpMarkupLineColor);
    this._polyLineGeometryShape.setEndcapType(
      Communicator.Markup.Shape.EndcapType.Arrowhead
    );
    //this._polyLineGeometryShape.setStartEndcapSize(ptpMarkupSphereRadius);
    //this._polyLineGeometryShape.setEndEndcapSize(ptpMarkupSphereRadius);
    this._polyLineGeometryShape.setStartEndcapColor(ptpMarkupLineColor);
    this._polyLineGeometryShape.setEndEndcapColor(ptpMarkupLineColor);
    //Angle value in Degrees
    this._angleInDegrees = 0;
    //3d position of points located
    this._positions = [];
  }

  //Set properties to sphere shape points
  initCircle(shape) {
    shape.setRadius(ptpMarkupSphereRadius);
    shape.setFillColor(this._viewer.measureManager.getMeasurementColor());
  }

  finalize() {
    this._stage++;
  }

  //Get stages while markup drawing
  getStage() {
    return this._stage;
  }

  //Set first point data (3d, 2d) when clicked first time
  setFirstPointPosition(positions3d, point2d) {
    this._stage = 1;
    this._positions[0] = positions3d.copy();
    //this.point2d[0] = point2d.copy();
  }

  //Set first point data (3d, 2d)	when clicked second time
  setSecondPointPosition(positions3d, point2d) {
    this._stage = 2;
    this._positions[1] = positions3d.copy();
    //this.point2d[1] = point2d.copy();
  }

  //Set first point data (3d, 2d)	when clicked third time
  setThirdPointPosition(positions3d, point2d) {
    this._stage = 3;
    this._positions[2] = positions3d.copy();
    //this.point2d[2] = point2d.copy();
  }

  //Update the markup creation process through each stage
  update() {
    super.update();

    //update the point status to the shapes in each stage
    switch (this._stage) {
      case 1:
        //Compute first point using 3d to 2d point projection
        this.point2d[0] = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._positions[0])
        );
        this._firstPointShape.setCenter(this.point2d[0]);
        break;
      case 2:
        //Compute first, second point using 3d to 2d point projection
        for (var e = 0; e < this._positions.length; e++) {
          var projectedPoint = this._viewer.view.projectPoint(
            this._positions[e]
          );
          0 >= projectedPoint.z;
          this.point2d[e] = Communicator.Point2.fromPoint3(
            this._viewer.view.projectPoint(this._positions[e])
          );
        }
        this._firstPointShape.setCenter(this.point2d[0]);
        this._secondPointShape.setCenter(this.point2d[1]);
        break;
      case 3:
        //Compute first, second, third point using 3d to 2d point projection
        for (var e = 0; e < this._positions.length; e++) {
          var projectedPoint = this._viewer.view.projectPoint(
            this._positions[e]
          );
          0 >= projectedPoint.z;
          this.point2d[e] = Communicator.Point2.fromPoint3(
            this._viewer.view.projectPoint(this._positions[e])
          );
        }
        this._firstPointShape.setCenter(this.point2d[0]);
        this._secondPointShape.setCenter(this.point2d[1]);
        this._thirdPointShape.setCenter(this.point2d[2]);

        //Angle calculated by using vector drawn from three points
        var vectorOne = Communicator.Point3.subtract(
          this._positions[0],
          this._positions[1]
        );
        var vectorTwo = Communicator.Point3.subtract(
          this._positions[2],
          this._positions[1]
        );
        this._angleInDegrees = Communicator.Util.computeAngleBetweenVector(
          vectorOne,
          vectorTwo
        );
        var axisOfRotation = 0;
        if (this._angleInDegrees === 180 || this._angleInDegrees === 0) {
          var tempVec = vectorOne.copy();
          tempVec.normalize();
          if (tempVec.x == 0) {
            axisOfRotation = new Communicator.Point3(1, 0, 0);
          } else if (tempVec.y == 0) {
            axisOfRotation = new Communicator.Point3(0, 1, 0);
          } else if (tempVec.z == 0) {
            axisOfRotation = new Communicator.Point3(0, 0, 1);
          } else {
            axisOfRotation = new Communicator.Point3(
              -tempVec.y,
              tempVec.x,
              tempVec.z
            );
          }
        } else {
          //Axis of rotation to find rotation matrix used to calculated set of points for arc
          axisOfRotation = Communicator.Point3.cross(vectorTwo, vectorOne);
          axisOfRotation.normalize();
        }

        //Get smallest line among two, find the radius for arc based on smallest line
        var smallestVector =
          vectorOne.length() < vectorTwo.length() ? vectorOne : vectorTwo;
        var radiusVector = vectorTwo
          .copy()
          .normalize()
          .scale(smallestVector.length() * arcRadiusScaleFactor);
        var pointForRotation = Communicator.Point3.add(
          radiusVector,
          this._positions[1]
        );
        pointForRotation = Communicator.Point3.subtract(
          pointForRotation,
          this._positions[1]
        );

        //Rotation matrix to calculate set of points for arc bt rotating start point
        var rotMatrix = new Communicator.Matrix();
        var arcPointsArray = [];
        //Calculation of set ot points for arc using roatation matrix based on angle offset
        for (
          var Offset = this._angleInDegrees / 30, angle = 0;
          angle <= this._angleInDegrees;
          angle += Offset
        ) {
          var rotatedPoint = new Communicator.Point3(0, 0, 0);
          Communicator.Util.computeOffaxisRotation(
            axisOfRotation,
            angle,
            rotMatrix
          );
          rotMatrix.transform(pointForRotation, rotatedPoint);
          arcPointsArray.push(
            new Communicator.Point3.add(rotatedPoint, this._positions[1])
          );
        }
        //Set the points on polyline shape object required to draw arc
        this._polyLineGeometryShape.clearPoints();
        for (var c = 0, e = arcPointsArray; c < e.length; c++)
          this._polyLineGeometryShape.pushPoint(
            Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(e[c]))
          );

        //Set text box text and position display the angle value
        this._textShape &&
          this._textShape.setTextString(
            PerformAngleConversion(
              this._angleInDegrees,
              AngleUnitForMeasurement
            )
          );
        //Set text box position at centre of arc/polyline
        var arcMidPoint = arcPointsArray[Math.round(arcPointsArray.length / 2)];
      
        var textBoxPos = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(arcMidPoint)
        );
        this._textShape && this._textShape.setPosition(textBoxPos);

        //Draw the lines using three point.
        this._lineShapes[0].set(this.point2d[0], this.point2d[1]);
        this._lineShapes[1].set(this.point2d[1], this.point2d[2]);
      
        break;
    }
    return true;
  }

  //Draw the markup - angle between two lines drawn using three points
  draw() {
    if (
      this._visibility &&
      0 === this._viewer.explodeManager.getMagnitude() &&
      this.update()
    ) {
      var rendrer = this._viewer.markupManager.getRenderer();
      switch (this._stage) {
        case 1:
          //Render first point/sphere shape
          rendrer.drawCircle(this._firstPointShape);
          break;
        case 2:
          //Render first, second point/sphere shape
          rendrer.drawCircle(this._firstPointShape);
          rendrer.drawCircle(this._secondPointShape);
          break;
        case 3:
          //Render first, second, third point/sphere shape
          rendrer.drawCircle(this._firstPointShape);
          rendrer.drawCircle(this._secondPointShape);
          rendrer.drawCircle(this._thirdPointShape);
          //render the arc
          rendrer.drawPolyline(this._polyLineGeometryShape);
          //render text box
          rendrer.drawTextBox(this._textShape);
          //Render lines
          for (var a = 0, c = this._lineShapes; a < c.length; a++)
            rendrer.drawLine(c[a]);
      }
    }
  }

  toJson() {
    return {
      name: this._name,
      firstPointCenter: this._positions[0].toJson(),
      firstPointRadius: this._firstPointShape.getRadius(),
      firstPointColor: this._firstPointShape.getFillColor().toJson(),
      secondPointCenter: this._positions[1].toJson(),
      secondPointRadius: this._secondPointShape.getRadius(),
      secondPointColor: this._secondPointShape.getFillColor().toJson(),
      thirdPointcenter: this._positions[2].toJson(),
      thirdPointRadius: this._thirdPointShape.getRadius(),
      thirdPointColor: this._thirdPointShape.getFillColor().toJson(),
      textBoxColor: this._textShape.getBoxPortion().getStrokeColor(),
      textFontSize: this._textShape._text.getFontSize(),
      textFillColor: this._textShape._text.getFillColor(),
      textPadding: this._textShape.getPadding(),
      arcThickness: this._polyLineGeometryShape.getStrokeWidth(),
      arcColor: this._polyLineGeometryShape.getStrokeColor(),
      arcStartCapColor: this._polyLineGeometryShape
        .getStartEndcapColor()
        .toJson(),
      arcEndCapColor: this._polyLineGeometryShape.getEndEndcapColor().toJson(),
      //text: this._textShape.getTextString(),
      //angleInDegree: this._angleInDegrees,
      lineColor: this._lineShapes[0].getStrokeColor(),
      lineEndCapColor: this._lineShapes[0].getEndEndcapColor(),
      lineStartCapColor: this._lineShapes[0].getStartEndcapColor(),
      lineThickness: this._lineShapes[0].getStrokeWidth(),
      className: this.getClassName(),
    };
  }
  forJson() {
    return this.toJson();
  }
  static fromJson(c, d) {
    d = new MeasureThreePointsAngleMarkup(d);
    d._name = c.name;
    d._positions[0] = Communicator.Point3.fromJson(c.firstPointCenter);
    d._firstPointShape.setRadius(c.firstPointRadius);
    d._firstPointShape.setFillColor(
      Communicator.Color.fromJson(c.firstPointColor)
    );
    d._positions[1] = Communicator.Point3.fromJson(c.secondPointCenter);
    d._secondPointShape.setRadius(c.secondPointRadius);
    d._secondPointShape.setFillColor(
      Communicator.Color.fromJson(c.secondPointColor)
    );
    d._positions[2] = Communicator.Point3.fromJson(c.thirdPointcenter);
    d._thirdPointShape.setRadius(c.thirdPointRadius);
    d._thirdPointShape.setFillColor(
      Communicator.Color.fromJson(c.thirdPointColor)
    );
    d._textShape
      .getBoxPortion()
      .setStrokeColor(Communicator.Color.fromJson(c.textBoxColor));
    d._textShape._text.setFontSize(c.textFontSize);
    d._textShape._text.setFillColor(
      Communicator.Color.fromJson(c.textFillColor)
    );
    d._textShape.setPadding(c.textPadding);
    d._polyLineGeometryShape.setStrokeWidth(
      Communicator.Color.fromJson(c.arcThickness)
    );
    d._polyLineGeometryShape.setStrokeColor(
      Communicator.Color.fromJson(c.arcColor)
    );
    //d._angleInDegrees = c.angleInDegree;
    d._polyLineGeometryShape.setStartEndcapColor(
      Communicator.Color.fromJson(c.arcStartCapColor)
    );
    d._polyLineGeometryShape.setEndEndcapColor(
      Communicator.Color.fromJson(c.arcStartCapColor)
    );

    for (var index = 0; index < d._lineShapes.length; index++) {
      d._lineShapes[index].setStrokeColor(
        Communicator.Color.fromJson(c.lineColor)
      );
      d._lineShapes[index].setEndEndcapColor(
        Communicator.Color.fromJson(c.lineEndCapColor)
      );
      d._lineShapes[index].setStartEndcapColor(
        Communicator.Color.fromJson(c.lineStartCapColor)
      );
      d._lineShapes[index].setStrokeWidth(c.lineThickness);
    }
    d._stage = 3;
    return d;
  }
  static construct(a, c) {
    return MeasureThreePointsAngleMarkup.fromJson(a, c);
  }

  getClassName() {
    return "MeasureThreePointsAngleMarkup";
  }
};

//Operator class to draw markup for angle between three points
class MeasureThreePointsAngleOperator extends Communicator.Operator
  .OperatorBase {
  constructor(viewer, measureManager) {
    super();
    this._viewer = viewer;
    this._measureManager = measureManager;
    //Markup to draw angle between three points
    this._measureMarkup = null;
    //markup to display point based on current mouse arrow position
    this._cursorMarkup = null;
    //Shortcut keycode to delete markup
    this.ctrlDown = false;
  }

  //Conversion of point from world space window space
  WorldToWindow(viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  }
  //Display cursor markup, update markup points during itermediates stages
  onMouseMove(event) {
    super.onMouseMove(event);

    this.activateCursorSprite();
    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.Point
    );
    //Get theb position on face/edge using pick from point API
    this._viewer.view
      .pickFromPoint(event.getPosition(), pickConfig)
      .then((selection) => {
        if (selection.getSelectionType() !== Communicator.SelectionType.None) {
          if (0 === selection.overlayIndex()) {
            var line = null;
            var point = null;
            var position = selection.getPosition();
            if ((line = selection.getLineEntity()) !== null) {
              position = this.getLineSnapPoint(line, true);
            } else if ((point = selection.getPointEntity()) !== null) {
              position = point.getPosition();
            }
            //Convert point from world space to window space
            position = this.WorldToWindow(this._viewer, position);
            //Update cursor markup with window space point
            this._cursorMarkup.setPosition(position);
            //Draw markup through all stages.
            this.draw();
            //Prevent propogation of event to Navigation operaotor in last stage of this markup creation
            if (this.getStage() > 2) {
              event.setHandled(true);
            }
          }
        }
      });
  }

  //Draw the three points when mouse clicked
  onMouseUp(event) {
    if (this.isActive()) {
      this.activateCursorSprite();
      var stage = this.getStage();
      if (3 > this._dragCount) {
        const pickConfig = new Communicator.PickConfig(
          Communicator.SelectionMask.All
        );
        //Get position on face/edge to draw point through all stages of markup
        this._viewer.view
          .pickFromPoint(event.getPosition(), pickConfig)
          .then((selection) => {
            if (
              selection.getSelectionType() !== Communicator.SelectionType.None
            ) {
              if (0 === selection.overlayIndex()) {
                var line = null;
                var point = null;
                var point2d = null;
                var position3d = selection.getPosition();
                if ((line = selection.getLineEntity()) !== null) {
                  position3d = this.getLineSnapPoint(line, true);
                } else if ((point = selection.getPointEntity()) !== null) {
                  position3d = point.getPosition();
                }

                //Convert point from world space to window space
                point2d = this.WorldToWindow(this._viewer, position3d);
                //Trigger the measurementBegin callback event
                if (2 >= this.getStage())
                  this._viewer.trigger("measurementBegin");
                //Create markup object when first point is  picked
                null === this._measureMarkup &&
                  ((this._measureMarkup =
                    new Communicator.Markup.MeasurePointPointDistanceMarkup(
                      this._viewer
                    )),
                  this._measureManager.addMeasurement(this._measureMarkup));
                //Set the points on through stages one by one.
                if (this.getStage() === 0)
                  this._measureMarkup.setFirstPointPosition(
                    position3d,
                    point2d
                  );
                else if (this.getStage() === 1)
                  this._measureMarkup.setSecondPointPosition(
                    position3d,
                    point2d
                  );
                else if (this.getStage() === 2)
                  this._measureMarkup.setThirdPointPosition(
                    position3d,
                    point2d
                  );
                //Draw the markup through eash stage
                this.draw();
                //Finlize/releae markup to measure manager, when all stages are complete
                if (this.getStage() > 2) {
                  //this._measureMarkup.finalize();
                  this._measureManager.finalizeMeasurement(this._measureMarkup);
                  this._measureMarkup = null;
                }

                this._viewer.markupManager.refreshMarkup();
              }
            }
          });
      }
    }
    super.onMouseUp(event);
  }

  //Get the current stage of markup
  getStage() {
    return null === this._measureMarkup ? 0 : this._measureMarkup.getStage();
  }

  //Draw the cursor markup and three point angle markup
  draw() {
    var a = !1;
    3 > this.getStage() &&
      null !== this._cursorMarkup &&
      (this._cursorMarkup.draw(), (a = !0));
    null !== this._measureMarkup && (this._measureMarkup.draw(), (a = !0));
    a && this._viewer.markupManager.refreshMarkup();
  }

  //Set cursor markup	radius
  activateCursorSprite() {
    null !== this._cursorMarkup && this._cursorMarkup.enable(!0);
  }

  //Perform sniping/picking of points on faces/edges when mouse cursor is moved
  getLineSnapPoint(line, useSnapping) {
    var a, b;
    console.assert(3 !== this.getStage());
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  }

  //On activate, create cursor markup
  onActivate() {
    this._cursorMarkup = new cursorMarkup(this._viewer);
    this._viewer.isDrawingSheetActive() &&
      this._viewer.setBackgroundSelectionEnabled(!0);
  }

  //On deactivate, destroy cursor markup
  onDeactivate() {
    null !== this._cursorMarkup &&
      (this._cursorMarkup.destroy(), (this._cursorMarkup = null));
    null !== this._measureMarkup &&
      (this._measureManager.removeMeasurement(this._measureMarkup),
      (this._measureMarkup = null));
    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    this._viewer.isDrawingSheetActive() &&
      this._viewer.setBackgroundSelectionEnabled(!1);
  }

  onKeyDown(a) {
    if (a.getKeyCode() === 17) this.ctrlDown = true;
    if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z) {
      hwv.measureManager.removeLastMeasurement();
      this._measureMarkup = null;
    }
  }
  onKeyUp(a) {
    if (a.getKeyCode() === 17) this.ctrlDown = false;
  }
}

//Markup class to find area of portion (polygonal) formed by located points
window.MeasureAreaMarkup = class MeasureAreaMarkup extends (
  Communicator.Markup.Measure.MeasureMarkup
) {
  constructor(viewer) {
    super();
    this._viewer = viewer;
    this._name = "MeasureAreaMarkup";
    //circle shape to represent points picked face/edges
    this.PointShapes = [];
    //2d points projected on canvas to draw shapes
    this.point2d = [];
    //3d points selected
    this.point3d = [];
    //Text box to display area of polygonal portion
    this._textShape = new Communicator.Markup.Shape.TextBox();
    this._textShape.getBoxPortion().setFillOpacity(1);
    this._textShape.getBoxPortion().setStrokeColor(ptpMarkupTextBoxColor);
    this._textShape._text.setFontSize(ptpMarkupTextFontSize);
    this._textShape._text.setFillColor(ptpMarkupTextBoxColor);
    this._textShape.setPadding(ptpMarkupTextBoxPadding);
    //Poly line shape to draw polygon formed using located points
    this._polyLineGeometryShape = new Communicator.Markup.Shape.Polyline();
    this._polyLineGeometryShape.setStrokeWidth(ptpMarkupLineThickness);
    this._polyLineGeometryShape.setStrokeColor(ptpMarkupLineColor);
    //polyline used to draw the triangles received from triangulation API (debug purpose)
    this.tringlePolyline = [];
    //Line collection used to draw dottecd line
    this._dottedLine = new Communicator.Markup.Shape.LineCollection();
    this._dottedLine.setStrokeWidth(ptpMarkupLineThickness);
    this._dottedLine.setStrokeColor(ptpMarkupLineColor);
    //3D point arrays for dashed lines
    this._pointArrayOne = [];
    this._pointArrayTwo = [];
    this._pointArrayThree = [];
  }

  //Set properties to sphere shape points
  initCircle(shape) {
    shape.setRadius(ptpMarkupSphereRadius);
    shape.setFillColor(ptpPointShapeColor);
  }

  finalize() {
    this._stage++;
    this._dottedLine.clear();
  }

  //Get stages while markup drawing
  getStage() {
    return this._stage;
  }

  //Set the point data after locating using operator
  setNextPointPosition(positions3d) {
    this.point3d.push(positions3d.copy());
    this._stage = 1;
  }

  convertSolidLineToDottedLine(pointOne, pointTwo) {
    var lineVector = Communicator.Point3.subtract(pointTwo, pointOne);
    var segmentLength = 0; //one dash lenght or lngth of spacme
    //Calculate the dash length based on distance between model center and camera position. Need to maintain dash length in case of zoom in or out
    var camPos = this._viewer.view.getCamera().getPosition();
    var lookAtVec = Communicator.Point3.subtract(
      boundBoxModel.center(),
      camPos
    );
    segmentLength = 10 * (lookAtVec.length() / divisionFactorForDashLength);

    var pointArray = [];
    for (
      var offsetLength = 0;
      offsetLength < lineVector.length();
      offsetLength += segmentLength
    ) {
      var tempVector = lineVector;
      var pointVector = tempVector.copy().normalize().scale(offsetLength);
      var point = Communicator.Point3.add(pointVector, pointOne);
      //point = Communicator.Point3.subtract(point, pointOne)
      pointArray.push(point.copy());
    }
    return pointArray;
  }

  adjust(b) {
    super.adjust(b);
    //Find 3d point on model
    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.All
    );
    //Get theb position on face/edge using pick from point API
    this._viewer.view.pickFromPoint(b, pickConfig).then((selection) => {
      if (selection.getSelectionType() !== Communicator.SelectionType.None) {
        if (0 === selection.overlayIndex()) {
          var pointCursor = selection.getPosition();
          var lastSnippedPoint = this.point3d[this.point3d.length - 1];
          var firstSnippedPoint = this.point3d[0];
          //Clear the old points in arrays
          this._pointArrayOne.length = 0;
          this._pointArrayTwo.length = 0;
          this._pointArrayThree.length = 0;
          //Line between Last snippet Point and Cursor point
          this._pointArrayOne = this.convertSolidLineToDottedLine(
            lastSnippedPoint,
            pointCursor
          );
          //Line between Cursor point and first snippet point
          this._pointArrayTwo = this.convertSolidLineToDottedLine(
            firstSnippedPoint,
            pointCursor
          );
          //Line between First snippet point and Last snippet point.
          this._pointArrayThree = this.convertSolidLineToDottedLine(
            lastSnippedPoint,
            firstSnippedPoint
          );
          //Dashed line 2d points to draw the shape
          this.UpdateDashedLine2DPoints();
        }
      }
    });
  }

  UpdateDashedLine2DPoints() {
    //Clear dotted line object
    this._dottedLine.clear();
    //Set this point array to line collection to draw dotted line. (Last snippet Point and Cursor point)
    for (var index = 0; index < this._pointArrayOne.length - 1; index++) {
      if (index % 2 == 0) {
        var point1 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayOne[index])
        );
        var point2 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayOne[index + 1])
        );
        this._dottedLine.addLine(point1, point2);
      }
    }
    //Cursor point and first snippet point
    for (var index = 0; index < this._pointArrayTwo.length - 1; index++) {
      if (index % 2 == 0) {
        var point1 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayTwo[index])
        );
        var point2 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayTwo[index + 1])
        );
        this._dottedLine.addLine(point1, point2);
      }
    }
    //First snippet point and Last snippet point.
    for (var index = 0; index < this._pointArrayThree.length - 1; index++) {
      if (index % 2 == 0) {
        var point1 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayThree[index])
        );
        var point2 = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pointArrayThree[index + 1])
        );
        this._dottedLine.addLine(point1, point2);
      }
    }
  }

  update() {
    super.update();

    //Prepare point shapes (sphere/circle) to draw in all stages.
    //Clear points in polyline shape so that updated point set can be added.
    this._polyLineGeometryShape.clearPoints();
    var xSum = 0,
      ySum = 0,
      pointCount = 0;
    pointCount = this.point3d.length;
    for (var index = 0; index < this.point3d.length; index++) {
      //Get the 2d projected points for shapes.
      var point2d = Communicator.Point2.fromPoint3(
        this._viewer.view.projectPoint(this.point3d[index])
      );
      //Circle/sphere shapes to denote points located
      this.PointShapes[index] = new Communicator.Markup.Shape.Circle();
      this.initCircle(this.PointShapes[index]);
      this.PointShapes[index].setCenter(point2d);
      //this.PointShapes[index].setStrokeColor()
      //Add updated points to polyline shape object.
      this._polyLineGeometryShape.pushPoint(point2d);
      xSum = xSum + point2d.x;
      ySum = ySum + point2d.y;
    }
    //Dashed line 2d points to draw the shape
    this.UpdateDashedLine2DPoints();

    //Stage 1 - Once finalized, calculate the polygon normal to use in triangulation API.
    if (this._stage === 2 && this.point3d.length >= 3) {
      //Add first point to end of polyline list to complete the polygon
      this._polyLineGeometryShape.pushPoint(
        Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this.point3d[0])
        )
      );
      //Find normal to polygon
      var vecOne = Communicator.Point3.subtract(
        this.point3d[0],
        this.point3d[1]
      );
      var vecTwo = Communicator.Point3.subtract(
        this.point3d[2],
        this.point3d[1]
      );
      var polygonNormal = Communicator.Point3.cross(vecOne, vecTwo);
      //Create float array having point coordinates to pass as argument in triangulation API
      var floarArray = [];
      for (var index = 0; index < this.point3d.length; index++) {
        floarArray.push(this.point3d[index].x);
        floarArray.push(this.point3d[index].y);
        floarArray.push(this.point3d[index].z);
      }
      //Append the first point at the end to complete polygon.
      floarArray.push(this.point3d[0].x);
      floarArray.push(this.point3d[0].y);
      floarArray.push(this.point3d[0].z);
      //API to calculate the triangulated set of points
      var PointsArray = this._viewer.model.triangulatePolygon(
        floarArray,
        polygonNormal
      );
      //Convert triangulated data (float array) to Point3d object. Its used to find area of each triangle.
      var trianglePoint3d = [];
      for (var index = 0; index < PointsArray.length; index += 3) {
        trianglePoint3d.push(
          new Communicator.Point3(
            PointsArray[index],
            PointsArray[index + 1],
            PointsArray[index + 2]
          )
        );
      }
      //Draw triangles to observe triangulation (only for debud purpose)
      //Find are of triangles and add them all to find total area
      this.tringlePolyline = []; // polyline used to draw triangulation (debug purpose)
      var totalArea = 0;
      for (var index = 0; index < trianglePoint3d.length; index += 3) {
        //polyline calculation for triangle after triangulation (debug purpose)
        /* var polyline = new Communicator.Markup.Shape.Polyline;
        polyline.setStrokeColor(Communicator.Color.red());
        polyline.pushPoint(Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(trianglePoint3d[index])));
        polyline.pushPoint(Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(trianglePoint3d[index + 1])));
        polyline.pushPoint(Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(trianglePoint3d[index + 2])));
        polyline.pushPoint(Communicator.Point2.fromPoint3(this._viewer.view.projectPoint(trianglePoint3d[index])));
        this.tringlePolyline.push(polyline); */

        var vec1 = Communicator.Point3.subtract(
          trianglePoint3d[index],
          trianglePoint3d[index + 1]
        );
        var vec2 = Communicator.Point3.subtract(
          trianglePoint3d[index + 2],
          trianglePoint3d[index + 1]
        );
        var crossProduct = Communicator.Point3.cross(vec1, vec2);
        var areaOfTriangle = crossProduct.length() / 2;
        totalArea += areaOfTriangle;
      }
      //Find centroid of polygon area
      var centroidPolygon = new Communicator.Point2(
        xSum / pointCount,
        ySum / pointCount
      );
      //Set text box text and position display the area value
      this._textShape &&
        this._textShape.setTextString(
          PerformAreaConversion(totalArea, AreaUnitForMeasurement)
        );
      this._textShape && this._textShape.setPosition(centroidPolygon);
      //Clear the dasshed lines
      this._dottedLine.clear();
    }
    return true;
  }

  //Draw the markup - area using set of points forming polygonal area
  draw() {
    if (
      this._visibility &&
      0 === this._viewer.explodeManager.getMagnitude() &&
      this.update()
    ) {
      var rendrer = this._viewer.markupManager.getRenderer();
      //Draw the circle/sphere symbol to represent located points
      for (var index = 0; index < this.PointShapes.length; index++) {
        rendrer.drawCircle(this.PointShapes[index]);
      }
      //Draw triangulation (debug purpose)
      /* for (var index = 0; index < this.tringlePolyline.length; index++)
        rendrer.drawPolyline(this.tringlePolyline[index]); */
      //Draw polygon represented by set of points
      rendrer.drawPolyline(this._polyLineGeometryShape);
      //Draw the text box representing area value with units
      rendrer.drawTextBox(this._textShape);
      //Draw dotted line
      rendrer.drawLines(this._dottedLine);
    }
  }

  toJson() {
    for (var pointSet = [], b = 0, f = this.point3d; b < f.length; b++)
      pointSet.push(f[b].toJson());
    return {
      name: this._name,
      areaPoints: pointSet,
      className: this.getClassName(),
    };
  }

  forJson() {
    return this.toJson();
  }

  static fromJson(c, d) {
    d = new MeasureAreaMarkup(d);
    for (var points = c.areaPoints, index = 0; index < points.length; index++) {
      var point = Communicator.Point3.fromJson(points[index]);
      d.point3d.push(point);
    }
    d._stage = 2;
    return d;
  }

  static construct(a, c) {
    return MeasureAreaMarkup.fromJson(a, c);
  }

  getClassName() {
    return "MeasureAreaMarkup";
  }
};

//Operator class to draw markup for area portion (polygonal) formed by located points
class MeasureAreaOperator extends Communicator.Operator.OperatorBase {
  constructor(viewer, measureManager) {
    super();
    this._viewer = viewer;
    this._measureManager = measureManager;
    //Markup to find area for polygonal region
    this._measureMarkup = null;
    //markup to display point based on current mouse arrow position
    this._cursorMarkup = null;
    //Shortcut keycode to delete markup
    this.ctrlDown = false;
  }

  //Conversion of point from world space window space
  WorldToWindow(viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  }
  //Display cursor markup, update markup points during itermediates stages
  onMouseMove(event) {
    super.onMouseMove(event);

    this.activateCursorSprite();
    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.All
    );
    //Get theb position on face/edge using pick from point API
    this._viewer.view
      .pickFromPoint(event.getPosition(), pickConfig)
      .then((selection) => {
        if (selection.getSelectionType() !== Communicator.SelectionType.None) {
          if (0 === selection.overlayIndex()) {
            var line = null;
            var point = null;
            var position = selection.getPosition();
            if ((line = selection.getLineEntity()) !== null) {
              position = this.getLineSnapPoint(line, true);
            } else if ((point = selection.getPointEntity()) !== null) {
              position = point.getPosition();
            }
            //Convert point from world space to window space
            position = this.WorldToWindow(this._viewer, position);
            //Update cursor markup with window space point
            this._cursorMarkup.setPosition(position);
            //Draw markup through all stages.
            this.draw();
            //Adjust the dotted line position
            if (this.getStage() === 1) {
              this._measureMarkup.adjust(position);
            }
            //Prevent propogation of event to Navigation operaotor in last stage of this markup creation
            if (this.getStage() > 2) {
              event.setHandled(true);
            }
          }
        }
      });
  }

  //Draw the points when mouse clicked
  onMouseUp(event) {
    if (this.isActive()) {
      this.activateCursorSprite();
      var stage = this.getStage();
      if (3 > stage) {
        const pickConfig = new Communicator.PickConfig(
          Communicator.SelectionMask.All
        );
        //Get position on face/edge to draw point through all stages of markup
        this._viewer.view
          .pickFromPoint(event.getPosition(), pickConfig)
          .then((selection) => {
            if (
              selection.getSelectionType() !== Communicator.SelectionType.None
            ) {
              if (0 === selection.overlayIndex()) {
                var line = null;
                var point = null;
                var point2d = null;
                var position3d = selection.getPosition();
                if ((line = selection.getLineEntity()) !== null) {
                  position3d = this.getLineSnapPoint(line, true);
                } else if ((point = selection.getPointEntity()) !== null) {
                  position3d = point.getPosition();
                }

                //Convert point from world space to window space
                point2d = this.WorldToWindow(this._viewer, position3d);
                //Create markup object when first point is picked
                null === this._measureMarkup &&
                  ((this._measureMarkup = new MeasureAreaMarkup(this._viewer)),
                  this._measureManager.addMeasurement(this._measureMarkup));
                //Set the points one by one.
                this._measureMarkup.setNextPointPosition(position3d);
                //Trigger the measurementBegin callback to change markup color on markupmanager.
                if (0 === this.getStage())
                  this._viewer
                    ._getCallbackManager()
                    .trigger("measurementBegin");
                //Draw the markup
                this.draw();
                this._viewer.markupManager.refreshMarkup();
              }
            }
          });
      }
    }
    super.onMouseUp(event);
    event.setHandled(true);
  }

  //Get the current stage of markup
  getStage() {
    return null === this._measureMarkup ? 0 : this._measureMarkup.getStage();
  }

  //Draw the cursor markup and area measure markup
  draw() {
    var a = !1;
    null !== this._cursorMarkup && (this._cursorMarkup.draw(), (a = !0));
    null !== this._measureMarkup && (this._measureMarkup.draw(), (a = !0));
    a && this._viewer.markupManager.refreshMarkup();
  }

  //Set cursor markup	radius
  activateCursorSprite() {
    null !== this._cursorMarkup && this._cursorMarkup.enable(!0);
  }

  //Perform sniping/picking of points on faces/edges when mouse cursor is moved
  getLineSnapPoint(line, useSnapping) {
    var a, b;
    console.assert(3 !== this.getStage());
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  }

  //On activate, create cursor markup
  onActivate() {
    this._cursorMarkup = new cursorMarkup(this._viewer);
    //this._viewer.isDrawingSheetActive() && this._viewer.setBackgroundSelectionEnabled(!0)
  }

  //On deactivate, destroy cursor markup
  onDeactivate() {
    null !== this._cursorMarkup &&
      (this._cursorMarkup.destroy(), (this._cursorMarkup = null));
    null !== this._measureMarkup &&
      (this._measureManager.removeMeasurement(this._measureMarkup),
      (this._measureMarkup = null));
    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    //this._viewer.isDrawingSheetActive() && this._viewer.setBackgroundSelectionEnabled(!1)
  }

  onKeyDown(a) {
    if (a.getKeyCode() === 17)
      // Control - 17
      this.ctrlDown = true;
    if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z) {
      hwv.measureManager.removeLastMeasurement();
      this._measureMarkup = null;
    }
    if (a.getKeyCode() === 13) {
      // Enter - 13
      //Finlize/releae markup to measure manager, when all stages are complete
      if (this._measureMarkup !== null) {
        if (this._measureMarkup.point3d.length >= 3) {
          this._measureMarkup.finalize();
          this._measureManager.finalizeMeasurement(this._measureMarkup);
          this._measureMarkup = null;
        } else {
          hwv.measureManager.removeLastMeasurement();
          this._measureMarkup = null;
        }
      }
    }
  }
  onKeyUp(a) {
    if (a.getKeyCode() === 17) this.ctrlDown = false;
  }

  onDoubleClick(a) {
    //Finlize/releae markup to measure manager, when all stages are complete
    if (this._measureMarkup !== null) {
      if (this._measureMarkup.point3d.length >= 3) {
        this._measureMarkup.finalize();
        this._measureManager.finalizeMeasurement(this._measureMarkup);
        this._measureMarkup = null;
      } else {
        hwv.measureManager.removeLastMeasurement();
        this._measureMarkup = null;
      }
    }
  }
}

//Markup class to find angle by placing three points on face/edge
window.PinMarkup = class Pin extends Communicator.Markup.Measure.MeasureMarkup {
  constructor(viewer, noteTextManager) {
    super();
    this._viewer = viewer;
    //Pin shape as circle + stem
    this._PinShapePartCircle = new Communicator.Markup.Shape.Circle();
    this._PinShapePartStem = new Communicator.Markup.Shape.Line();
    //Set current pin markup reference to
    //Markup name
    this._name = "Pin";
    //Sphere point radius
    this._pointShapeRadius = pinMarkupSize;
    //2d points projected on canvas to draw shapes
    this._pinCenter2d = null;
    //3d position of points located
    this._pinCenter3d = null;
    //stem length
    this.stemLength = pinMarkupSize;
    //Flag information - name, color
    this._flagName = Object.keys(objectFlags)[0];
    var color = hexToRgb(objectFlags[this._flagName]);
    this._flagColor = new Communicator.Color(color.r, color.g, color.b);
    //Flag to identify if markup is selected or not
    this.isSelected = false;
    //Flag to identify if markup is highlighted or not
    this.isHighlighted = false;
    //Set properties to sphere shape points
    this.initCircle(this._PinShapePartCircle);
    //Thickness values for selection/highlight
    this._selectThickness = 2;
    this._highlightThickness = 4;
    //Camera position at the time of Pin creation
    this._camera = null;
    //Node id of object on which the pin is placed
    this._nodeID = -111;
    //Bounding box of object on which the Pin is placed.
    this._bounding = null;
  }

  //Set properties to sphere shape point
  initCircle(shape) {
    shape.setRadius(this._pointShapeRadius);
    shape.setFillColor(this._flagColor);
  }

  finalize() {
    this._stage++;
  }

  //Get stages while markup drawing
  getStage() {
    return this._stage;
  }

  //Set center data (3d) when clicked
  setPinPosition(position3d) {
    this._stage = 1;
    this._pinCenter3d = position3d.copy();
  }

  //Set/Get the camera position when Pin is placed
  setCameraForPin(camera) {
    this._camera = camera.copy();
  }
  getCameraForPin() {
    return this._camera !== null ? this._camera.copy() : null;
  }

  //Set/Get boundings of object on which Pin is placed
  setBoundingForPin(bounding) {
    this._bounding = bounding.copy();
  }
  getBoundingForPin() {
    return this._bounding !== null ? this._bounding.copy() : null;
  }
  //Set/Get nodeID of object on which Pin is placed
  setNodeIDForPin(nodeID) {
    this._nodeID = nodeID;
  }
  getNodeIDForPin() {
    return this._nodeID;
  }
  //Update the markup creation process through each stage
  update() {
    super.update();

    //update the point status to the shapes in each stage
    switch (this._stage) {
      case 1:
        //Compute center point using 3d to 2d point projection
        this._pinCenter2d = Communicator.Point2.fromPoint3(
          this._viewer.view.projectPoint(this._pinCenter3d)
        );
        //Set color of flag
        this._PinShapePartCircle.setFillColor(this._flagColor);
        //Set points on pin shape part stem
        var StemPointOne = new Communicator.Point2(
          this._pinCenter2d.x,
          this._pinCenter2d.y
        );
        var StemPointTwo = new Communicator.Point2(
          this._pinCenter2d.x,
          this._pinCenter2d.y - this.stemLength
        );
        this._PinShapePartStem.set(StemPointOne, StemPointTwo);
        //Set the point on pin shape part circle
        this._PinShapePartCircle.setCenter(
          new Communicator.Point2(
            this._pinCenter2d.x,
            this._pinCenter2d.y - (this.stemLength + this._pointShapeRadius)
          )
        );
        //Set the updated 2d position for Pin element container
        var activeMarkup = pinElementContainer.getActivePinMarkup();
        //Disabled the code to set position of pin setting dialog based on Pin location movement in viewport
        // if (activeMarkup !== null && (activeMarkup._uniqueId === this._uniqueId))
        // 	pinElementContainer.setPosition(this._pinCenter2d);
        break;
    }
    return true;
  }

  //Draw the markup - Draw pin represented by sphere shape
  draw() {
    if (
      this._visibility &&
      0 === this._viewer.explodeManager.getMagnitude() &&
      this.update()
    ) {
      var rendrer = this._viewer.markupManager.getRenderer();
      switch (this._stage) {
        case 1:
          //Render Pin part circle
          rendrer.drawCircle(this._PinShapePartCircle);
          //Render Pin part stem
          rendrer.drawLine(this._PinShapePartStem);
      }
    }
  }

  toJson() {
    return {
      name: this._name,
      center: this._pinCenter3d.toJson(),
      flagName: this._flagName,
      flagColor: this._flagColor,
      flagCamera: this._camera.toJson(),
      flagedObjectID: this._nodeID,
      flagedObjectBounding: this._bounding.toJson(),
      className: this.getClassName(),
    };
  }
  forJson() {
    return this.toJson();
  }
  static fromJson(c, d) {
    d = new PinMarkup(d);
    d._pinCenter3d = Communicator.Point3.fromJson(c.center);
    d._flagName = c.flagName;
    d._flagColor = Communicator.Color.fromJson(c.flagColor);
    d._camera = Communicator.Camera.fromJson(c.flagCamera);
    d._nodeID = c.flagedObjectID;
    d._bounding = Communicator.Box.fromJson(c.flagedObjectBounding);
    d._stage = 1;
    return d;
  }
  static construct(a, c) {
    return PinMarkup.fromJson(a, c);
  }

  setFlag(flagName) {
    this._flagName = flagName;
    var rgbColor = hexToRgb(objectFlags[flagName]);
    this._flagColor.set(rgbColor.r, rgbColor.g, rgbColor.b);
  }

  getClassName() {
    return "PinMarkup";
  }

  hit(a) {
    this.update();
    //Clicked on circle part
    var distanceVec = Communicator.Point2.subtract(
      a,
      this._PinShapePartCircle.getCenter()
    );
    if (distanceVec.length() <= this._pointShapeRadius) return true;
    //Clicked on stem part
    var strokeWidth = this._PinShapePartStem.getStrokeWidth();
    if (
      Communicator.Util.isPointOnLineSegment2d(
        a,
        this._PinShapePartStem.getP1(),
        this._PinShapePartStem.getP2(),
        strokeWidth
      )
    )
      return true;
    return false;
  }

  onSelect() {
    this.isSelected = true;
    if (this.isHighlighted) return;
    this._PinShapePartCircle.setStrokeWidth(2);
    this._PinShapePartStem.setStrokeWidth(2);
    this._pointShapeRadius = pinMarkupSize + pinHighlightsize;
    this._PinShapePartCircle.setRadius(this._pointShapeRadius);
  }

  onDeselect() {
    this.isSelected = false;
    if (this.isHighlighted) return;
    this._PinShapePartCircle.setStrokeWidth(1);
    this._PinShapePartStem.setStrokeWidth(1);
    this._pointShapeRadius = pinMarkupSize;
    this._PinShapePartCircle.setRadius(pinMarkupSize);
  }

  onHighlight() {
    this._PinShapePartCircle.setStrokeWidth(4);
    this._PinShapePartStem.setStrokeWidth(4);
    this._pointShapeRadius = pinMarkupSize + pinHighlightsize;
    this._PinShapePartCircle.setRadius(this._pointShapeRadius);
    this.isHighlighted = true;
  }

  onUnHighlight() {
    this.isHighlighted = false;
    if (this.isSelected) {
      this.onSelect();
      return;
    }
    this._PinShapePartCircle.setStrokeWidth(1);
    this._PinShapePartStem.setStrokeWidth(1);
    this._pointShapeRadius = pinMarkupSize;
    this._PinShapePartCircle.setRadius(this._pointShapeRadius);
  }
};

//Operator class to handle Pin Markup
class PinOperator extends Communicator.Operator.OperatorBase {
  constructor(viewer, measureManager, noteTextManager) {
    super();
    this._viewer = viewer;
    this._measureManager = measureManager;
    this._noteTextManager = noteTextManager;
    //Markup to find area for polygonal region
    this._measureMarkup = null;
    //markup to display point based on current mouse arrow position
    this._cursorMarkup = null;
    //Shortcut keycode to delete markup
    this.ctrlDown = false;
  }

  //Conversion of point from world space window space
  WorldToWindow(viewer, point) {
    var b = new Communicator.Point4(point.x, point.y, point.z, 1);
    point = new Communicator.Point4(0, 0, 0, 0);
    viewer.view.getFullCameraMatrix().transform4(b, point);
    b = 1 / point.w;
    point = new Communicator.Point2(point.x * b, point.y * b);
    b = viewer.model.getClientDimensions();
    var a = b[0];
    b = b[1];
    point.x = 0.5 * a * (point.x + 1);
    point.y = 0.5 * b * (point.y + 1);
    point.x = Math.max(0, Math.min(point.x, a));
    point.y = b - Math.max(0, Math.min(point.y, b));
    return point;
  }
  //Display cursor markup, update markup points during itermediates stages
  onMouseMove(event) {
    super.onMouseMove(event);

    this.activateCursorSprite();
    const pickConfig = new Communicator.PickConfig(
      Communicator.SelectionMask.All
    );
    //Get the position on face/edge using pick from point API
    this._viewer.view
      .pickFromPoint(event.getPosition(), pickConfig)
      .then((selection) => {
        if (selection.getSelectionType() !== Communicator.SelectionType.None) {
          if (0 === selection.overlayIndex()) {
            var line = null;
            var point = null;
            var position = selection.getPosition();
            if ((line = selection.getLineEntity()) !== null) {
              position = this.getLineSnapPoint(line, true);
            } else if ((point = selection.getPointEntity()) !== null) {
              position = point.getPosition();
            }
            //Convert point from world space to window space
            position = this.WorldToWindow(this._viewer, position);
            //Update cursor markup with window space point
            this._cursorMarkup.setPosition(position);
            //Draw markup through all stages.
            this.draw();
            //Prevent propogation of event to Navigation operaotor in last stage of this markup creation
            if (this.getStage() > 1) {
              event.setHandled(true);
            }
          }
        }
      });
  }

  //Draw the points when mouse clicked
  onMouseUp(event) {
    if (this.isActive()) {
      this.activateCursorSprite();
      var stage = this.getStage();
      if (3 > this._dragCount) {
        const pickConfig = new Communicator.PickConfig(
          Communicator.SelectionMask.All
        );
        var _self = this;
        //Get position on face/edge to draw point through all stages of markup
        this._viewer.view
          .pickFromPoint(event.getPosition(), pickConfig)
          .then(async function (selection) {
            if (
              selection.getSelectionType() !== Communicator.SelectionType.None
            ) {
              if (0 === selection.overlayIndex()) {
                var line = null;
                var point = null;
                var point2d = null;
                var position3d = selection.getPosition();
                if ((line = selection.getLineEntity()) !== null) {
                  position3d = _self.getLineSnapPoint(line, true);
                } else if ((point = selection.getPointEntity()) !== null) {
                  position3d = point.getPosition();
                }

                //Convert point from world space to window space
                point2d = _self.WorldToWindow(_self._viewer, position3d);
                //Create markup object when point is picked
                null === _self._measureMarkup &&
                  ((_self._measureMarkup = new PinMarkup(
                    _self._viewer,
                    _self._noteTextManager
                  )),
                  _self._measureManager.addMeasurement(_self._measureMarkup));
                //Set the point for Pin markup.
                _self._measureMarkup.setPinPosition(position3d);
                //Set current camera to markup
                _self._measureMarkup.setCameraForPin(
                  _self._viewer.view.getCamera()
                );
                //Set node id of object on which pin is placed
                _self._measureMarkup.setNodeIDForPin(selection.getNodeId());
                //Set bounding of object on which pin is placed
                var nodeIDArray = [];
                nodeIDArray.push(selection.getNodeId());
                var boundingBox = await _self._viewer.model.getNodesBounding(
                  nodeIDArray
                );
                _self._measureMarkup.setBoundingForPin(boundingBox);
                //Trigger the measurementBegin callback to change markup color on markupmanager.
                if (0 === _self.getStage())
                  _self._viewer
                    ._getCallbackManager()
                    .trigger("measurementBegin");
                //Draw the markup
                _self.draw();
                //Finlize/releae markup to measure manager, when all stages are complete
                if (_self.getStage() > 0) {
                  //this._measureMarkup.finalize();
                  _self._measureManager.finalizeMeasurement(
                    _self._measureMarkup
                  );
                  //Launch Flag selection dialog
                  pinElementContainer.setPositionOffset(
                    new Communicator.Point2(12, -24)
                  );
                  pinElementContainer.setPosition(
                    _self._measureMarkup._pinCenter2d
                  );
                  //remove previously added flags
                  pinElementContainer.RemoveAllFlagItem();
                  //Add the flag names to item
                  for (let key in objectFlags) {
                    pinElementContainer.AddFlagItem(key, objectFlags[key]);
                  }
                  //Show the dialog
                  pinElementContainer.show(_self._measureMarkup);
                  _self._measureMarkup = null;
                }
                _self._viewer.markupManager.refreshMarkup();
              }
            }
          });
      }
    }
    super.onMouseUp(event);
  }

  //Get the current stage of markup
  getStage() {
    return null === this._measureMarkup ? 0 : this._measureMarkup.getStage();
  }

  //Draw the cursor markup and area measure markup
  draw() {
    var a = !1;
    null !== this._cursorMarkup && (this._cursorMarkup.draw(), (a = !0));
    null !== this._measureMarkup && (this._measureMarkup.draw(), (a = !0));
    a && this._viewer.markupManager.refreshMarkup();
  }

  //Set cursor markup	radius
  activateCursorSprite() {
    null !== this._cursorMarkup && this._cursorMarkup.enable(!0);
  }

  //Perform sniping/picking of points on faces/edges when mouse cursor is moved
  getLineSnapPoint(line, useSnapping) {
    var a, b;
    console.assert(3 !== this.getStage());
    var c = line.getBestVertex();
    if (null !== c) {
      return c;
    } else return line.getPosition();
  }

  //On activate, create cursor markup
  onActivate() {
    this._cursorMarkup = new cursorMarkup(this._viewer);
    //this._viewer.isDrawingSheetActive() && this._viewer.setBackgroundSelectionEnabled(!0)
  }

  //On deactivate, destroy cursor markup
  onDeactivate() {
    null !== this._cursorMarkup &&
      (this._cursorMarkup.destroy(), (this._cursorMarkup = null));
    null !== this._measureMarkup &&
      (this._measureManager.removeMeasurement(this._measureMarkup),
      (this._measureMarkup = null));
    //Set default color to green, need this in case operator is activated before completion of markup
    hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    //this._viewer.isDrawingSheetActive() && this._viewer.setBackgroundSelectionEnabled(!1)
  }

  onKeyDown(a) {
    if (a.getKeyCode() === 17)
      // Control - 17
      this.ctrlDown = true;
    if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z)
      hwv.measureManager.removeLastMeasurement();
  }
  onKeyUp(a) {
    if (a.getKeyCode() === 17)
      // Control - 17
      this.ctrlDown = false;
  }
}

//////Redline custom Markups - Start////////
//Markup class to draw straight line
window.RedlineStraightline = class RedlineStraightline extends (
  Communicator.Markup.Redline.RedlineItem
) {
  constructor(viewer) {
    super(viewer);
    this._uniqueId = Communicator.GUID.create();
    this._startPoint = Communicator.Point3.zero();
    this._endPoint = Communicator.Point3.zero();
    this.strokeWidth = redlineMarkupLineThickness;
    this._lineShape = new Communicator.Markup.Shape.Line();
    this._previousDragPlanePosition = Communicator.Point3.zero();
    this._lineShape.setStrokeColor(
      new Communicator.Color(
        redlineMarkupColor.r,
        redlineMarkupColor.g,
        redlineMarkupColor.b
      )
    );
    this._lineShape.setStrokeWidth(this.strokeWidth);
    this._lineShape.setEndEndcapSize(arrowMarkupEndCapSize);
    this._validRadiusTolerance = 1;
    this._setEndCap = false;
  }

  setLineThickness(thickness) {
    this._lineShape.setStrokeWidth(parseInt(thickness));
    this.strokeWidth = thickness;
  }

  getLineThickness() {
    return this.strokeWidth;
  }

  setLineColor(color) {
    this._lineShape.setStrokeColor(color);
    if (this._setEndCap) this._lineShape.setEndEndcapColor(color);
  }

  getLineColor() {
    return this._lineShape.getStrokeColor();
  }

  setEndEndcapType(endCaptype) {
    if (this._setEndCap) this._lineShape.setEndEndcapType(endCaptype);
  }

  getEndEndcapType(endCaptype) {
    if (this._setEndCap) return this._lineShape.getEndEndcapType();
    return null;
  }

  //Set start point of straight line
  setStartPoint(b) {
    this._startPoint.assign(b);
    this._endPoint.assign(b);
  }
  //Get start point of straight line
  getStartPoint() {
    return this._startPoint.copy();
  }
  //Set end point of straight line
  setEndPoint(b) {
    this._endPoint.assign(b);
  }
  //Get end point of straight line
  getEndPoint() {
    return this._endPoint.copy();
  }
  //Set the end cap type (arrow/circle) if required
  setEndEndcap() {
    this._lineShape.setEndEndcapType(redlineMarkupArrowHeadType);
    this._lineShape.setEndEndcapColor(
      new Communicator.Color(
        redlineMarkupColor.r,
        redlineMarkupColor.g,
        redlineMarkupColor.b
      )
    );
    this._setEndCap = true;
  }
  //Unique ID for markup object
  getUniqueId() {
    return this._uniqueId;
  }
  //Update straight line position on mouse during creation and its selec/move
  _update() {
    var startPoint2d = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._startPoint)
    );
    var endPoint2d = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._endPoint)
    );
    this._lineShape.set(startPoint2d, endPoint2d);
  }
  //Called when markup is beibg drawn, being updated on view change
  draw() {
    this._update();
    this.isValid() &&
      this._viewer.markupManager.getRenderer().drawLine(this._lineShape);
  }
  //To identofy if this markup object is selected on mouse click
  hit(b) {
    this._update();
    var strokeWidth = this._lineShape.getStrokeWidth();
    if (
      Communicator.Util.isPointOnLineSegment2d(
        b,
        this._lineShape.getP1(),
        this._lineShape.getP2(),
        strokeWidth
      )
    )
      return true;
    return false;
  }
  //Change the width of line when selected
  onSelect() {
    this._lineShape.setStrokeWidth(parseInt(this.strokeWidth) + 1);
  }
  //Change the width of line when deselected
  onDeselect() {
    this._lineShape.setStrokeWidth(this.strokeWidth);
  }
  //Check whether markup (straight line)
  isValid() {
    return (
      Communicator.Point2.distance(
        this._lineShape.getP1(),
        this._lineShape.getP2()
      ) > this._validRadiusTolerance
    );
  }
  //Drag start position to move markup after selection
  onDragStart(b) {
    var a = this._viewer.view;
    b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
    null !== b && this._previousDragPlanePosition.assign(b);
    return !1;
  }
  //Drag updated position to move markup after selection
  onDragMove(b) {
    var a = this._viewer.view;
    b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
    null !== b &&
      ((a = Communicator.Point3.subtract(b, this._previousDragPlanePosition)),
      this._startPoint.add(a),
      this._endPoint.add(a),
      this._previousDragPlanePosition.assign(b));
    return !0;
  }

  toJson() {
    return {
      uniqueId: this._uniqueId,
      startPoint: this._startPoint.toJson(),
      endPoint: this._endPoint.toJson(),
      className: this.getClassName(),
      lineColor: this._lineShape.getStrokeColor().toJson(),
      lineThickness: this._lineShape.getStrokeWidth(),
      lineEndCapSize: this._lineShape.getEndEndcapSize(),
      lineEndCapType: this._lineShape.getEndEndcapType(),
    };
  }

  forJson() {
    return this.toJson();
  }

  static fromJson(b, a) {
    a = new RedlineStraightline(a);
    a._uniqueId = b.uniqueId;
    a._startPoint = Communicator.Point3.fromJson(b.startPoint);
    a._endPoint = Communicator.Point3.fromJson(b.endPoint);
    a._lineShape.setStrokeColor(Communicator.Color.fromJson(b.lineColor));
    a._lineShape.setEndEndcapColor(Communicator.Color.fromJson(b.lineColor));
    a.setLineThickness(b.lineThickness);
    a._lineShape.setEndEndcapSize(b.lineEndCapSize);
    a._lineShape.setEndEndcapType(b.lineEndCapType);
    a._update();
    return a;
  }

  static construct(a, c) {
    return RedlineStraightline.fromJson(a, c);
  }

  //Markup class name
  getClassName() {
    return "RedlineStraightline";
  }
};

//operaotor class to handle straight line markup
class RedlineStraightlineOperator extends Communicator.RedlineOperator {
  constructor(viewer) {
    super(viewer);
    this._redlineStraightline = null;
    this._previewHandle = null;
  }

  //start point of straight line markup
  createRedlineItem(a) {
    var b = this._viewer.view;
    this._redlineStraightline = new RedlineStraightline(this._viewer);
    this._previewHandle = this._viewer.markupManager.registerMarkup(
      this._redlineStraightline
    );
    a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
    null !== a && this._redlineStraightline.setStartPoint(a);
    return this._redlineStraightline;
  }
  //update straight line markup end position
  updateRedlineItem(a) {
    if (this._redlineStraightline) {
      var b = this._viewer.view;
      a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
      null !== a &&
        (this._redlineStraightline.setEndPoint(a),
        this._viewer.markupManager.refreshMarkup());
    }
  }
  //finalize the straight line markup
  finalizeRedlineItem(a) {
    a = this._viewer.markupManager;
    var b = null;
    this._redlineStraightline &&
      (this._redlineStraightline.isValid() && (b = this._redlineStraightline),
      (this._redlineStraightline = null),
      null !== this._previewHandle &&
        (a.unregisterMarkup(this._previewHandle), (this._previewHandle = null)),
      a.refreshMarkup());
    return b;
  }
  //On deactivation of operator
  onDeactivate() {
    //hide the Redline Markup Config Dialog, in case it is shown
    document.getElementById("Redline-markup-config").style.display = "none";
  }
}

//operaotor class to handle arrow markup
class RedlineArrowOperator extends Communicator.RedlineOperator {
  constructor(viewer) {
    super(viewer);
    this._redlineArrow = null;
    this._previewHandle = null;
  }
  //start point of arrow markup
  createRedlineItem(a) {
    var b = this._viewer.view;
    this._redlineArrow = new RedlineStraightline(this._viewer);
    this._redlineArrow.setEndEndcap();
    this._previewHandle = this._viewer.markupManager.registerMarkup(
      this._redlineArrow
    );
    a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
    null !== a && this._redlineArrow.setStartPoint(a);
    return this._redlineArrow;
  }
  //update arrow markup end position
  updateRedlineItem(a) {
    if (this._redlineArrow) {
      var b = this._viewer.view;
      a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
      null !== a &&
        (this._redlineArrow.setEndPoint(a),
        this._viewer.markupManager.refreshMarkup());
    }
  }
  //finalize the arrow markup
  finalizeRedlineItem(a) {
    a = this._viewer.markupManager;
    var b = null;
    this._redlineArrow &&
      (this._redlineArrow.isValid() && (b = this._redlineArrow),
      (this._redlineArrow = null),
      null !== this._previewHandle &&
        (a.unregisterMarkup(this._previewHandle), (this._previewHandle = null)),
      a.refreshMarkup());
    return b;
  }
  //On deactivation of operator
  onDeactivate() {
    //hide the Redline Markup Config Dialog, in case it is shown
    document.getElementById("Redline-markup-config").style.display = "none";
  }
}

//Markup class to draw the cloud using polylines
window.RedlineCloud = class RedlineCloud extends (
  Communicator.Markup.Redline.RedlineItem
) {
  constructor(viewer) {
    super(viewer);
    this._uniqueId = Communicator.GUID.create();
    this._startPoint = Communicator.Point3.zero();
    this._endPoint = Communicator.Point3.zero();
    this.strokeWidth = redlineMarkupLineThickness;
    this.polylinForSetOfCircle =
      new Communicator.Markup.Shape.PolylineCollection();
    this._previousDragPlanePosition = Communicator.Point3.zero();
    this.polylinForSetOfCircle.setStrokeColor(
      new Communicator.Color(
        redlineMarkupColor.r,
        redlineMarkupColor.g,
        redlineMarkupColor.b
      )
    );
    this.polylinForSetOfCircle.setStrokeWidth(this.strokeWidth);
    this.validDiagonalLengthTolerance = 7.07106; //sqrt(50) = sides > 5
  }

  //Setter to manage thickness of polyline
  setLineThickness(thickness) {
    this.polylinForSetOfCircle.setStrokeWidth(parseInt(thickness));
    this.strokeWidth = thickness;
  }
  //Getter to manage thickness of polyline
  getLineThickness() {
    return this.strokeWidth;
  }
  //Setter to manage color of polyline
  setLineColor(color) {
    this.polylinForSetOfCircle.setStrokeColor(color);
  }
  //Getter to manage color of polyline
  getLineColor() {
    return this.polylinForSetOfCircle.getStrokeColor();
  }

  //Set start point of straight line
  setStartPoint(b) {
    this._startPoint.assign(b);
    this._endPoint.assign(b);
  }
  //Get start point of straight line
  getStartPoint() {
    return this._startPoint.copy();
  }
  //Set end point of straight line
  setEndPoint(b) {
    this._endPoint.assign(b);
  }
  //Get end point of straight line
  getEndPoint() {
    return this._endPoint.copy();
  }

  //Unique ID for markup object
  getUniqueId() {
    return this._uniqueId;
  }
  //Find angle of vector with X axis
  FindAngleWithXAxis(vecOne) {
    var angleInDeg = -Math.atan2(vecOne.y, vecOne.x) * (180 / Math.PI);
    return angleInDeg;
  }
  //Convert circle to plyline points
  CircleToPolyline(centre, radius, startAngle, endAngle, angleToXAxis) {
    var offsetForAngle = cloudMarkupArcSideCount;
    startAngle = startAngle + angleToXAxis;
    endAngle = endAngle + angleToXAxis;
    var polylineForCircle = new Communicator.Markup.Shape.Polyline();
    for (
      var offAngle = (endAngle - startAngle) / offsetForAngle,
        angle = startAngle;
      angle <= endAngle;
      angle += offAngle
    ) {
      var point2d = new Communicator.Point2(0, 0);
      point2d.x = centre.x + radius * Math.cos(-angle * (Math.PI / 180));
      point2d.y = centre.y + radius * Math.sin(-angle * (Math.PI / 180));
      polylineForCircle.pushPoint(
        new Communicator.Point2(point2d.x, point2d.y)
      );
    }
    return polylineForCircle;
  }

  //Create cloud shape line uisng set of polylines
  ConvertStraightLineToCloudline(startPoint, endPoint) {
    var lineOffsetCount = 0;
    var circleRadius = cloudMarkupArcRadius;
    var lineVec = Communicator.Point2.subtract(endPoint, startPoint);
    lineOffsetCount = lineVec.length() / (circleRadius * 2);
    var polylineForCircle = null;
    var angleToXAxis = 0;
    //Find angle offset for line which is not parallel to x axis, required to adjust the polyline points shifting
    angleToXAxis = this.FindAngleWithXAxis(lineVec);
    for (var offsetNo = 0; offsetNo < lineOffsetCount; offsetNo++) {
      var scaleFactor = circleRadius * 2 * offsetNo + circleRadius;
      if (offsetNo === Math.floor(lineOffsetCount)) {
        var lengthProcessed = circleRadius * 2 * offsetNo;
        var remainingOffset = lineVec.length() - lengthProcessed;
        var radiusForLastArc = remainingOffset / 2;
        scaleFactor = circleRadius * 2 * offsetNo + radiusForLastArc;
        circleRadius = radiusForLastArc;
      }
      var lineVecCopy = lineVec.copy();
      var scaledLineVec = lineVecCopy
        .scale(1 / lineVecCopy.length())
        .scale(scaleFactor);
      var pointForCenter = Communicator.Point2.add(scaledLineVec, startPoint);

      polylineForCircle = this.CircleToPolyline(
        pointForCenter,
        circleRadius,
        0,
        180,
        angleToXAxis
      );
      var pointsForOneCircle = polylineForCircle.getPoints();
      var arrayForPolylineFromCollection =
        this.polylinForSetOfCircle.createPolyline();
      for (var index = 0; index < pointsForOneCircle.length; index++) {
        arrayForPolylineFromCollection[index] = pointsForOneCircle[index];
      }
    }
  }

  //Update straight line position on mouse during creation and its selec/move
  _update() {
    var firstPoint = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._startPoint)
    );
    var thirdPoint = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._endPoint)
    );
    var SecondPoint = new Communicator.Point2(firstPoint.x, thirdPoint.y);
    var fourthPoint = new Communicator.Point2(thirdPoint.x, firstPoint.y);
    this.polylinForSetOfCircle.clear();

    if (
      (firstPoint.x < thirdPoint.x && firstPoint.y < thirdPoint.y) ||
      (firstPoint.x > thirdPoint.x && firstPoint.y > thirdPoint.y)
    ) {
      this.ConvertStraightLineToCloudline(SecondPoint, firstPoint);
      this.ConvertStraightLineToCloudline(thirdPoint, SecondPoint);
      this.ConvertStraightLineToCloudline(fourthPoint, thirdPoint);
      this.ConvertStraightLineToCloudline(firstPoint, fourthPoint);
    } else {
      this.ConvertStraightLineToCloudline(firstPoint, SecondPoint);
      this.ConvertStraightLineToCloudline(SecondPoint, thirdPoint);
      this.ConvertStraightLineToCloudline(thirdPoint, fourthPoint);
      this.ConvertStraightLineToCloudline(fourthPoint, firstPoint);
    }
  }
  //Called when markup is beibg drawn, being updated on view change
  draw() {
    if (this.isValid()) {
      this._update();
      this._viewer.markupManager
        .getRenderer()
        .drawPolylines(this.polylinForSetOfCircle);
    }
  }
  //To identofy if this markup object is selected on mouse click
  hit(b) {
    this._update();
    var strokeWidth = this.polylinForSetOfCircle.getStrokeWidth();
    var polylinesArray = this.polylinForSetOfCircle.getPolylines();

    for (var indexOne = 0; indexOne < polylinesArray.length; indexOne++) {
      var singlePolyLinePoints = polylinesArray[indexOne];
      for (
        var indexTwo = 0;
        indexTwo < singlePolyLinePoints.length - 1;
        indexTwo++
      ) {
        if (
          Communicator.Util.isPointOnLineSegment2d(
            b,
            singlePolyLinePoints[indexTwo],
            singlePolyLinePoints[indexTwo + 1],
            strokeWidth
          )
        )
          return true;
      }
    }
    return false;
  }
  //Change the width of line when selected
  onSelect() {
    this.polylinForSetOfCircle.setStrokeWidth(parseInt(this.strokeWidth) + 1);
  }
  //Change the width of line when deselected
  onDeselect() {
    this.polylinForSetOfCircle.setStrokeWidth(this.strokeWidth);
  }
  //Check whether markup (straight line)
  isValid() {
    var startPoint2d = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._startPoint)
    );
    var endPoint2d = Communicator.Point2.fromPoint3(
      this._viewer.view.projectPoint(this._endPoint)
    );
    return (
      Communicator.Point2.distance(startPoint2d, endPoint2d) >
      this.validDiagonalLengthTolerance
    );
  }
  //Drag start position to move markup after selection
  onDragStart(b) {
    var a = this._viewer.view;
    b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
    null !== b && this._previousDragPlanePosition.assign(b);
    return !1;
  }
  //Drag updated position to move markup after selection
  onDragMove(b) {
    var a = this._viewer.view;
    b = a.getCamera().getCameraPlaneIntersectionPoint(b, a);
    null !== b &&
      ((a = Communicator.Point3.subtract(b, this._previousDragPlanePosition)),
      this._startPoint.add(a),
      this._endPoint.add(a),
      this._previousDragPlanePosition.assign(b));
    return !0;
  }
  toJson() {
    return {
      uniqueId: this._uniqueId,
      startPoint: this._startPoint.toJson(),
      endPoint: this._endPoint.toJson(),
      className: this.getClassName(),
      cloudColor: this.polylinForSetOfCircle.getStrokeColor().toJson(),
      cloudThickness: this.polylinForSetOfCircle.getStrokeWidth(),
    };
  }

  forJson() {
    return this.toJson();
  }

  static fromJson(b, a) {
    a = new RedlineCloud(a);
    a._uniqueId = b.uniqueId;
    a._startPoint = Communicator.Point3.fromJson(b.startPoint);
    a._endPoint = Communicator.Point3.fromJson(b.endPoint);
    a.polylinForSetOfCircle.setStrokeColor(
      Communicator.Color.fromJson(b.cloudColor)
    );
    a.setLineThickness(b.cloudThickness);
    a._update();
    return a;
  }

  static construct(a, c) {
    return RedlineCloud.fromJson(a, c);
  }

  //Markup class name
  getClassName() {
    return "RedlineCloud";
  }
};

//operaotor class to handle arrow markup
class RedlineCloudOperator extends Communicator.RedlineOperator {
  constructor(viewer) {
    super(viewer);
    this._redlineCloud = null;
    this._previewHandle = null;
  }
  //start point of arrow markup
  createRedlineItem(a) {
    var b = this._viewer.view;
    this._redlineCloud = new RedlineCloud(this._viewer);
    this._previewHandle = this._viewer.markupManager.registerMarkup(
      this._redlineCloud
    );
    a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
    null !== a && this._redlineCloud.setStartPoint(a);
    return this._redlineCloud;
  }
  //update arrow markup end position
  updateRedlineItem(a) {
    if (this._redlineCloud) {
      var b = this._viewer.view;
      a = b.getCamera().getCameraPlaneIntersectionPoint(a, b);
      null !== a &&
        (this._redlineCloud.setEndPoint(a),
        this._viewer.markupManager.refreshMarkup());
    }
  }
  //finalize the arrow markup
  finalizeRedlineItem(a) {
    a = this._viewer.markupManager;
    var b = null;
    this._redlineCloud &&
      (this._redlineCloud.isValid() && (b = this._redlineCloud),
      (this._redlineCloud = null),
      null !== this._previewHandle &&
        (a.unregisterMarkup(this._previewHandle), (this._previewHandle = null)),
      a.refreshMarkup());
    return b;
  }
  //On deactivation of operator
  onDeactivate() {
    //hide the Redline Markup Config Dialog, in case it is shown
    document.getElementById("Redline-markup-config").style.display = "none";
  }
}

//////Redline custom Markups - End////////

//////////////////Custom Operators- End///////////////////////////////////

//function to load initial camera properties because in modelestructure load callback we were not getting initia_camera
async function initialize_hoops_camera(hwv) {
  if (hwv) {
    if(hwv.view._initialCamera){
    const camera = Communicator.Camera.fromJson(defaultCamera);
    hwv.view._fitCameraToBounding(camera,await hwv.model.getModelBounding())
    hwv.view._initialCamera = camera;
    hwv.view._initialCamera.setProjection(Communicator.Projection.Perspective);
    hwv.view.setProjectionMode(Communicator.Projection.Perspective);
    hwv.view.setCamera(hwv.view._initialCamera);
  }
  }
}

//Main function to be called in integration code where nCirlce implementation need to be used
function nCircleMain(hwv, ui) {
  // Set the perspective mode by default.
  hwv.setCallbacks({
    camera: (cam) => {
      
      bUpdateImage = true;
    },
    XHRonloadend: () => {
      //("XHR END");
    },
    webGlContextLost: () => {
      //Rendering Error
      console.log("Context Lost");

      window.flutter_inappwebview.callHandler("webGlContextLost");
    },
    streamingDeactivated: function () {
      if (bDeactivateStreaming) {
        console.log("Streaming Stopped");

        window.flutter_inappwebview.callHandler("streamingDeactivated");
        bDeactivateStreaming = false;
      }
    },
    timeout: () => {
      //Timeout Handler
      console.log("Timeout Error");
      window.flutter_inappwebview.callHandler("timeout");
    },

    //    websocketConnectionClosed: () => {
    //
    //      //Connection Close Handler
    //      console.log("webSocketConnection Close Error");
    //      window.flutter_inappwebview.callHandler('websocketConnectionClosed');
    //
    //    },
    missingModel: () => {
      if (!bError) {
        bError = true;
        console.log("Error Occured while Loading Model : Missing Model ");
        window.flutter_inappwebview.callHandler("modelLoadFailure");
      }
    },

    modelLoadFailure: (b,d) => {
      console.log(b);
      console.log(d);
      //Error While Loading  Handler
      if (!bError) {
        bError = true;
        console.log("Error Occured while Loading Model : Model Load Failure");
        window.flutter_inappwebview.callHandler("modelLoadFailure");
      }
    },

    subtreeLoaded: async () => {
      initialize_hoops_camera(hwv);
      nCircle.Ui.Toolbar.setCamera(hwv.view.getCamera());
    },

    
    modelStructureReady: async () => {
      //document.getElementById("contextMenuButton").remove()
      //Apply Asite settings using global variables


      rootNode = await hwv.model.getAbsoluteRootNode();

      Apply_Asite_Setting_Using_Global_Var(hwv);

      NavigationChanges();

      var redlineText =     new RedlineTextOperatorEx(hwv);
                Communicator.OperatorId.CustomTextOperatorEx = hwv.operatorManager.registerCustomOperator(redlineText);
      
      zoomLensOperator = new ZoomLensOperator(hwv);
      zoomLensOperatorHandle =
        hwv.operatorManager.registerCustomOperator(zoomLensOperator);

      //Angle using three point measure operator
      const measureThreePointsAngleOperator = new AngleOperator(
        hwv,
        hwv.measureManager,
        zoomLensOperator
      );
      measureThreePointsAngleOperator.addMapping(Communicator.Button.Left);
      measureAngleOperatorHandle = hwv.operatorManager.registerCustomOperator(
        measureThreePointsAngleOperator
      );


      //Redline Strightline markup operator
      const redlineStraightlineOperator = new RedlineStraightlineOperator(
        hwv,
        hwv.measureManager
      );
      markupStraightLineHandle = hwv.operatorManager.registerCustomOperator(
        redlineStraightlineOperator
      );
      //Redline Arrow markup operator
      const redlineArrowOperator = new RedlineArrowOperator(
        hwv,
        hwv.measureManager
      );
      markupArrowHandle =
        hwv.operatorManager.registerCustomOperator(redlineArrowOperator);

      //Redline cloud markup operator
      const redlineCloudOperator = new RedlineCloudOperator(
        hwv,
        hwv.measureManager
      );
      markupCloudHandle =
        hwv.operatorManager.registerCustomOperator(redlineCloudOperator);

      //Area measure markup
      measureAreaOperator = new AreaOperator(
        hwv,
        hwv.measureManager,
        zoomLensOperator
      );
      measureAreaOperator.addMapping(Communicator.Button.Left);
      markupAreaMeasureHandle =
        hwv.operatorManager.registerCustomOperator(measureAreaOperator);

      //Pin Markup
      const pinOperator = new PinOperator(
        hwv,
        hwv.measureManager,
        hwv._noteTextManager
      );
      pinOperator.addMapping(Communicator.Button.Left);
      markupPinHandle = hwv.operatorManager.registerCustomOperator(pinOperator);

      hwv.model.getModelBounding(!0, !1).then(function (box) {
        boundBoxModel = box.copy();
      });

      //typeTreeUpdated = false;
      var rootNodeId = hwv.model.getRootNode();
      var modelRoot = hwv.model.getNodeChildren(rootNodeId)[0];
      fileType = hwv.model.getModelFileTypeFromNode(modelRoot);

      if (hwv.view._initialCamera) {
        initialize_hoops_camera(hwv);
      }


      //To Disable the default floorplan, which is appearing on walkmode activation
      hwv.floorplanManager.setAutoActivate(
        Communicator.FloorplanAutoActivation.Never
      );

      /* dummy call to initialize calibrationManager */
      calibrationManager = new Field.Calibration.CalibrationManager(hwv);
      PinManager = new Field.PinManager(hwv);
      PinManager.setPinCallback((event)=>{
        const detail = event.detail;
        const bimObject = {
          GUID : detail.guid,
          //position : detail.position,
          object_name : detail.nodeName,
          obj_type : detail.objectType,
          file_type : detail.fileType,
          revision_id : getRevisionIdFromNodeId(detail.nodeId),
          tree_revision_id : getRevisionIdFromNodeId(detail.nodeId),
          revision_id_model : getRevisionIdFromNodeId(detail.nodeId)
        }

        console.log(JSON.stringify(bimObject));
        window.flutter_inappwebview.callHandler("setBimObjectData",JSON.stringify({ BimObjectsData : [bimObject] }))
      })




    },

    frameDrawn: () => {},

    // This callback is received when measurement value is set but before it is displayed to the user
    measurementValueSet: () => {
      SetDesiredUnitToMarkups(hwv);

      //Point Point Measure Tool : Change the markup colors
      //Get the operator
      var measurePointPointDistanceOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.MeasurePointPointDistance
      );
      var measureMarkup = measurePointPointDistanceOperator._measureMarkup;
      //Change arrow head color
      if (measureMarkup !== null) {
        //Set radius for point point measure sphere markup
        measureMarkup._firstPointShape.setRadius(ptpMarkupSphereRadius);
        measureMarkup._secondPointShape.setRadius(ptpMarkupSphereRadius);
        //Set the measure markup line and arrow color
        if (measureMarkup._lineShapes !== null) {
          for (var a = 0; a < measureMarkup._lineShapes.length; a++) {
            measureMarkup._lineShapes[a].setStrokeColor(ptpMarkupLineColor);
            measureMarkup._lineShapes[a].setStartEndcapColor(
              ptpMarkupLineColor
            );
            measureMarkup._lineShapes[a].setEndEndcapColor(ptpMarkupLineColor);
            //Adjust line thickness and line end (arrow) symbol size
            measureMarkup._lineShapes[a].setStrokeWidth(ptpMarkupLineThickness); //default value ia 1
            //Set text font size
            measureMarkup._textShape._text.setFontSize(ptpMarkupTextFontSize);
            measureMarkup._textShape._text.setFillColor(ptpMarkupTextBoxColor);
            //Set box border color
            measureMarkup._textShape._box._strokeColor = ptpMarkupTextBoxColor;
            measureMarkup._textShape.setPadding(ptpMarkupTextBoxPadding);
          }
        }
      }
    },

    contextMenu: function (position) {
      //console.log(position);
    },

    measurementBegin: () => {
      //Set the measure markup color as red when markup is located
      hwv.measureManager.setMeasurementColor(ptpPointShapeColor);
    },

    measurementCreated: () => {
      //Set back the measure markup color as green once markup is created. so that next mark up will start with green again
      hwv.measureManager.setMeasurementColor(new Communicator.Color(0, 255, 0));
    },

    sceneReady: () => {
      hwv.view.getNavCube().setAnchor(3);
      //hwv.view._navCube._dimension = 6;

      //var orbitOperator = hwv.operatorManager.getOperator(
      //  Communicator.OperatorId.Orbit
      //);

      //orbitOperator.setBimOrbitEnabled(true);
      //orbitOperator.setPrimaryButton(Communicator.Button.Left);

      //Tablet Portrait
      if (window.outerWidth > 768 && window.outerWidth < 1024) {
        if (window.innerHeight < 700) {
          nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
          nCircle.Ui.Toolbar.setNavcubeSize(6);
        } else {
          //console.log("Tablet Portrait");
          nCircle.Ui.Toolbar.setNavcubePosition(-50, -50);
          nCircle.Ui.Toolbar.setNavcubeSize(10);
        }
      } else if (window.outerWidth > 320 && window.outerWidth < 480) {
        //console.log("Mobile Portrait");
        nCircle.Ui.Toolbar.setNavcubePosition(-100, -70);
        nCircle.Ui.Toolbar.setNavcubeSize(12);
      }
    },
    readlineMarkupSelect: function (markup) {
      //UpdateMarkupUI(hwv);
      //document.getElementById("Redline-markup-config").style.display = "block";
    },

    readlineMarkupDeSelect: function (markup) {
      // as the markup line width is hard coded in the code, on deselect call it gets set to 4 and our applied settings are overriden
      // This callback is called after deslecttion of markup. Hence, update the UI values again so that we're again overriding the hardcoded values set by makups.
      //UpdateMarkup(hwv, markup);
      //document.getElementById("Redline-markup-config").style.display = "none";
    },

    measurementLoaded: (measureMarkup) => {
      //Set back the measure markup color as green once markup is created. so that next mark up will start with green again
      if (measureMarkup._name === "MeasurePointPointDistance") {
        measureMarkup._firstPointShape.setFillColor(ptpPointShapeColor);
        measureMarkup._secondPointShape.setFillColor(ptpPointShapeColor);
        for (var e = 0; 6 > e; e++) {
          measureMarkup._lineShapes[e].setStrokeColor(ptpMarkupLineColor);
          measureMarkup._lineShapes[e].setEndEndcapColor(ptpMarkupLineColor);
          measureMarkup._lineShapes[e].setStartEndcapColor(ptpMarkupLineColor);
          measureMarkup._lineShapes[e].setStrokeWidth(ptpMarkupLineThickness);
        }
        measureMarkup._textShape._text.setFillColor(ptpMarkupTextBoxColor);
        //Set box border color
        measureMarkup._textShape._box._strokeColor =
          ptpMarkupTextBoxColor.copy();
        measureMarkup._textShape._text.setFontSize(ptpMarkupTextFontSize);
        measureMarkup._textShape.setPadding(ptpMarkupTextBoxPadding);
      }
    },

    selectionArray: function (a) {
      //Check if file is Revit
      if (!a.length) return;
      //addPolygonMarkupForGivenSelectionSet(a);
      //addPolylineMarkupForGivenSelectionSet(a);
      var rootNodeId = hwv.model.getRootNode();
      var modelRoot = hwv.model.getNodeChildren(rootNodeId)[0];
      var fileType = hwv.model.getModelFileTypeFromNode(modelRoot);
      // if (fileType === Communicator.FileType.Revit) {
      //   //Get parent Node name
      //   var currentNodeID = a[a.length - 1].getSelection().getNodeId();
      //   var nodeType = hwv.model.getNodeType(currentNodeID);
      //   var parentNodeID = hwv.model.getNodeParent(currentNodeID);
      //   var parentName = hwv.model.getNodeName(parentNodeID);
      //   //Add TYPE property to the node being selected.
      //   //For body instance, physical properties are shown in prop window. So we can skip the step
      //   if (nodeType !== Communicator.NodeType.BodyInstance)
      //     hwv.model.addPropertyToNode(currentNodeID, "TYPE", parentName);
      //   else {
      //     var td1 = document.createElement("td");
      //     var td2 = document.createElement("td");
      //     td1.innerHTML = "TYPE";
      //     td2.innerHTML = parentName;
      //     var tr = document.createElement("tr");
      //     tr.appendChild(td1);
      //     tr.appendChild(td2);
      //     setTimeout(function () {
      //       $("#propertyTable > tr").eq(1).after(tr.outerHTML);
      //     }, 300);
      //  }
      //}
    },

    assemblyTreeReady: async function () {
    },

    firstModelLoaded: async function () {

      /* Call only Once */
      if(!bFirstModelLoaded){
      hwv.model.setViewAxes(new Communicator.Point3(0,-1,0),new Communicator.Point3(0,0,1))
      bFirstModelLoaded = true;
      const walkOp = hwv.view._viewer.operatorManager.getOperator(
        Communicator.OperatorId.Walk
        );
        walkOp._tilt = 12.0;
      LoadFederatedEx();
      }
    },
  });

  //Add UI for option to select default measurement unit
  //AddUIForMeasurementTool(hwv);

  //Set custom Redline operators
  SetCustomRedlineMarkup(hwv, ui);

  //Measurement tool customization/improvements
  Measurement_Tool_Improvement(hwv);

  PinMarkupEnhancement(hwv, ui);
  //WalkPanelObj = new WalkPanel(hwv);
  //Add customization, new item for context menu
  //Customize_Context_menu_Items(hwv, ui);
}

//Apply Asite settings using global variables
function Apply_Asite_Setting_Using_Global_Var(hwv) {
  try {
    //Set frames per second rate
    hwv.setMinimumFramerate(frameRatePerSec);
    //Set hidden line opacity value
    hwv.view.getHiddenLineSettings().setObscuredLineOpacity(hiddenLineOpacity);
    //Set the back face visibility
    hwv.view.setBackfacesVisible(backFacesVisible);
    //Set capping geometry visibility
    hwv.cuttingManager.setCappingGeometryVisibility(cappingGeomVisibility);
    //Enable Face/Line Selection
    hwv.selectionManager.setHighlightFaceElementSelection(enableFaceNLineSel);
    hwv.selectionManager.setHighlightLineElementSelection(enableFaceNLineSel);
    //Rotate Around Camera Center
    //hwv.operatorManager.getOperator(Communicator.OperatorId.Orbit).setOrbitFallbackMode(rotateAroundCamCenter ? Communicator.OrbitFallbackMode.CameraTarget : Communicator.OrbitFallbackMode.ModelCenter)
    //Enable Ambient Occlusion
    hwv.view.setAmbientOcclusionEnabled(enableAmbientOcclusion);
    //Enable Anti-Aliasing
    hwv.view.setAntiAliasingMode(
      enableAntiAliasing
        ? Communicator.AntiAliasingMode.SMAA
        : Communicator.AntiAliasingMode.None
    );
    //Enable Bloom
    hwv.view.setBloomEnabled(enableBloom);
    //Silhouette Edges
    hwv.view.setSilhouetteEnabled(enableSilhouetteEdge);
    //Reflection Planes
    hwv.view.setSimpleReflectionEnabled(enableReflectionPlanes);
    //Enable Shadows
    hwv.view.setSimpleShadowEnabled(enableShadows);
    //Show Axis Triad
    showAxisTriad
      ? hwv.view.getAxisTriad().enable()
      : hwv.view.getAxisTriad().disable();
    //Show Nav Cube
    showNavCube
      ? hwv.view.getNavCube().enable()
      : hwv.view.getNavCube().disable();
    //Enable Eye-Dome Lighing
    hwv.view.setEyeDomeLightingEnabled(enableEyeDomeLighting);
    //Background Color
    hwv.view.setBackgroundColor(topBGColor, bottomBGColor);
    //Capping Color
    hwv.cuttingManager.setCappingFaceColor(cappingFaceColor);
    hwv.cuttingManager.setCappingLineColor(cappingLineColor);
    //Selection Color
    //Body
    hwv.selectionManager.setNodeSelectionColor(bodySelectionColor);
    hwv.selectionManager.setNodeSelectionOutlineColor(bodySelectionColor);
    //Faces And Lines
    hwv.selectionManager.setNodeElementSelectionColor(faceNLineSelectionColor);
    hwv.selectionManager.setNodeElementSelectionOutlineColor(
      faceNLineSelectionColor
    );
    //Measurement Color
    hwv.measureManager.setMeasurementColor(measurementColor);
    //PMI Overrride Color
    hwv.model.setPmiColorOverride(pmiColorOverride);
    if (pmiColorOverride === true) hwv.model.setPmiColor(pmiColor);

    //Set pick tolerance (point sniping while using point to point measure tool)
    hwv.selectionManager.setPickTolerance(pickTolerance);
  } catch (e) {
    //console.log(e.message);
  }
}

//Orbit - Z-Axis inclination issue
function OB_Z_Inclination_Issue(hwv) {
  var OldCameragetMouseMoveOffsetForRotation =
    Communicator.Operator.CameraOrbitOperator.prototype
      ._getMouseMoveOffsetForRotation;
  Communicator.Operator.CameraOrbitOperator.prototype._getMouseMoveOffsetForRotation =
    function () {
      //Get orbit operator and try to control speed of rotation in x, y direction.
      var orbitOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Orbit
      );

      return [
        -orbitOperator._mouseMoveOffset.x * degreesPerPixelForX,
        orbitOperator._mouseMoveOffset.y * degreesPerPixelForY,
      ];
    };
}

//Reduce the Pan speed
function PN_Reduce_Pan_Speed(hwv) {
  //Reducing the Pan speed by scaling the delta/offset by which camera position updated
  Communicator.Operator.CameraPanOperator.prototype.onMouseMove = function (c) {
    Communicator.Operator.OperatorBase.prototype.onMouseMove.call(this, c);
    if (this.isActive() || this._viewer.isDrawingSheetActive()) {
      var b = this._viewer.view,
        e = b.getCamera();
      if ((c = e.getCameraPlaneIntersectionPoint(c.getPosition(), b)))
        (c = Communicator.Point3.subtract(c, this._cameraPtPrevious)),
          e.dolly(c.scale(panSpeedForMouseMove)),
          b.setCamera(e);
    }
  };
}

/////////////////////////////////////////////////////////////////////////////////////////Measurement Tool/////////////////////////////////////////////////////////////////////////////////////////

function GetParentNodeWithGenericID(nodeID) {
  if (hwv.model.getNodeType(nodeID) === Communicator.NodeType.BodyInstance) {
    for (var nextNodeID = nodeID; null !== nextNodeID; ) {
      if (null !== hwv.model.getNodeGenericId(nextNodeID)) return nextNodeID;
      nextNodeID = hwv.model.getNodeParent(nextNodeID);
    }
  }
  return nodeID;
}

//Measurement tool customization/improvements
function Measurement_Tool_Improvement(hwv) {
  //Support adjustment for precision while displaying measurement
  Communicator.Util.formatWithUnit = function (b, a) {
    a =
      0.01 > Math.abs(a - 25.4 / 72)
        ? "points"
        : 0.01 > Math.abs(a - 25.4)
        ? "inch"
        : 0.01 > Math.abs(a - 1)
        ? "mm"
        : 0.01 > Math.abs(a - 10)
        ? "cm"
        : 0.01 > Math.abs(a - 25.4 / 6)
        ? "picas"
        : 0.01 > Math.abs(a - 12 * 25.4)
        ? "ft"
        : 0.01 > Math.abs(a - 914.4)
        ? "yd"
        : 0.01 > Math.abs(a - 1e3)
        ? "m"
        : 0.01 > Math.abs(a - 1e6)
        ? "km"
        : 0.01 > Math.abs(a - 1609344)
        ? "mi"
        : "mm";
    for (
      var c, d = measureValueForPrecision;
      9 > d && ((c = b.toFixed(d)), 0 === parseFloat(c));
      d++
    );
    0 === parseFloat(c) && (c = "0");
    return c + a;
  };

  //Set the radius fro point point measure markup sphere
  Communicator.Operator.MeasurePointPointDistanceOperator.prototype._activateCursorSprite =
    function () {
      null !== this._cursorMarkup && this._cursorMarkup.enable(!0);
      null !== this._cursorMarkup &&
        null !== this._cursorMarkup._cursorSprite &&
        this._cursorMarkup._cursorSprite.setRadius(ptpMarkupSphereRadius);
    };

  Communicator.Markup.Measure.MeasurePointPointDistanceMarkup.prototype.initCircle =
    function (b) {
      b.setRadius(ptpMarkupSphereRadius);
      b.setFillColor(this._viewer.measureManager.getMeasurementColor());
    };

  Communicator.Operator.MeasureFaceFaceAngleOperator.prototype.ctrlDown = false;
  Communicator.Operator.MeasureFaceFaceAngleOperator.prototype.onKeyDown =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = true;
      if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z)
        null !== this._markup
          ? (this._markup.cleanup(),
            this._measureManager.removeMeasurement(this._markup),
            (this._markup = null))
          : this._measureManager.removeLastMeasurement();
    };
  Communicator.Operator.MeasureFaceFaceAngleOperator.prototype.onKeyUp =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = false;
    };

  Communicator.Operator.MeasureEdgeLengthOperator.prototype.ctrlDown = false;
  Communicator.Operator.MeasureEdgeLengthOperator.prototype.onKeyDown =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = true;
      if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z)
        null !== this._lengthMarkup
          ? (this._measureManager.removeMeasurement(this._lengthMarkup),
            (this._lengthMarkup = null))
          : this._measureManager.removeLastMeasurement(),
          null !== this._edgeMarkup && this._resetEdgeMarkup();
    };
  Communicator.Operator.MeasureEdgeLengthOperator.prototype.onKeyUp = function (
    a
  ) {
    if (a.getKeyCode() === 17) this.ctrlDown = false;
  };

  Communicator.Operator.MeasureFaceFaceDistanceOperator.prototype.ctrlDown = false;
  Communicator.Operator.MeasureFaceFaceDistanceOperator.prototype.onKeyDown =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = true;
      if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z)
        null !== this._markup
          ? (this._markup.cleanup(),
            this._measureManager.removeMeasurement(this._markup),
            (this._markup = null))
          : this._measureManager.removeLastMeasurement();
    };
  Communicator.Operator.MeasureFaceFaceDistanceOperator.prototype.onKeyUp =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = false;
    };

  Communicator.Operator.MeasurePointPointDistanceOperator.prototype.ctrlDown = false;
  Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onKeyDown =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = true;
      if (this.ctrlDown && a.getKeyCode() === Communicator.KeyCode.z)
        null !== this._measureMarkup
          ? (this._measureManager.removeMeasurement(this._measureMarkup),
            (this._measureMarkup = null))
          : this._measureManager.removeLastMeasurement();
    };
  Communicator.Operator.MeasurePointPointDistanceOperator.prototype.onKeyUp =
    function (a) {
      if (a.getKeyCode() === 17) this.ctrlDown = false;
    };

  //Modified select markup manager implementation to trigger select/deselect callbacks
  var oldSelectMarkupMethod = Communicator.MarkupManager.prototype.selectMarkup;
  Communicator.MarkupManager.prototype.selectMarkup = function (a) {
    var self = this;
    var oldSelectedMarkup = self.getSelectedMarkup();

    oldSelectMarkupMethod.call(self, a);

    if (oldSelectedMarkup && a !== oldSelectedMarkup)
      this._viewer._callbackManager.trigger(
        "readlineMarkupDeSelect",
        oldSelectedMarkup
      );
    if (a) this._viewer._callbackManager.trigger("readlineMarkupSelect", a);
  };

  //Change the color pallet control on Redline Markup UI based on type of browser
  var agentUser = window.navigator.userAgent;
  var posTrident = agentUser.indexOf("Trident/");
  if (posTrident > 0) {
    var tr = document.getElementById("Redline-markup-config-table").rows[0];
    var th = document.createElement("th");
    th.innerHTML =
      "<div><input type='text' id='redline-markup-color' class='color-picker'  /></div>";
    tr.appendChild(th);
    //Set the color pallet to class
    $("INPUT.color-picker").each(function () {
      $(this).minicolors({
        position: $(this).attr("data-position") || "bottom left",
        format: "rgb",
        control: "hue",
      });
    });
    //set a default color
    $("#redline-markup-color").minicolors("value", "rgb(0,255,0)");
  } else {
    var tr = document.getElementById("Redline-markup-config-table").rows[0];
    var th = document.createElement("th");
    th.innerHTML =
      "<input type='color' id='redline-markup-color' value='#ff0000' style='float: left'>";
    tr.appendChild(th);
  }

  //OnChange events to Redline markup configuration , updates selected markup with modified values
  // document
  //   .getElementById("redline-markup-color")
  //   .addEventListener("focusout", function () {
  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-line-thickness")
  //   .addEventListener("change", function () {
  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-text-size")
  //   .addEventListener("change", function () {
  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-arrow-head-type")
  //   .addEventListener("change", function () {
  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-config-text-bold")
  //   .addEventListener("click", function () {
  //     if (
  //       document.getElementById("redline-markup-config-text-bold").style
  //         .border === ""
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-bold"
  //       ).style.border = "solid";
  //     else if (
  //       document
  //         .getElementById("redline-markup-config-text-bold")
  //         .style.border.indexOf("solid") >= 0
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-bold"
  //       ).style.border = "";

  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-config-text-italic")
  //   .addEventListener("click", function () {
  //     if (
  //       document.getElementById("redline-markup-config-text-italic").style
  //         .border === ""
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-italic"
  //       ).style.border = "solid";
  //     else if (
  //       document
  //         .getElementById("redline-markup-config-text-italic")
  //         .style.border.indexOf("solid") >= 0
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-italic"
  //       ).style.border = "";

  //     UpdateMarkup(hwv);
  //   });
  // document
  //   .getElementById("redline-markup-config-text-underline")
  //   .addEventListener("click", function () {
  //     if (
  //       document.getElementById("redline-markup-config-text-underline").style
  //         .border === ""
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-underline"
  //       ).style.border = "solid";
  //     else if (
  //       document
  //         .getElementById("redline-markup-config-text-underline")
  //         .style.border.indexOf("solid") >= 0
  //     )
  //       document.getElementById(
  //         "redline-markup-config-text-underline"
  //       ).style.border = "";

  //     UpdateMarkup(hwv);
  //   });

  // //make Markup configuration dialog as draggable, so that it can be moved wherever we want
  // $("#Redline-markup-config").draggable({
  //   handle: ".hoops-ui-window-header",
  // });
  // //close button event on configuration dialog
  // $("#redline-markup-config-close-button")
  //   .button()
  //   .on("click", function () {
  //     $("#Redline-markup-config").hide();
  //   });

  //Launch Pin setting dialog
  var idPinSettingDiv = document.getElementById("pin-setting");

  // idPinSettingDiv.onclick = function LaunchPinSettingDialog() {
  //   // document.getElementById("viewer-3dpinsetting-dialog").style.display = "block";
  //   populateFlagInfoTable();
  //   //synch the status of elements in dialog using objects which represents visiblity, pin count etc.
  //   Synch3DPinSettingDialgElements();
  //   showpopupdialogue("#viewer-3dpinsetting-dialog");
  // };

  //Refresh the Pin status
  // var idRefreshPinsDiv = document.getElementById("refresh-pin");
  // idRefreshPinsDiv.onclick = async function RefreshThePinStatus() {
  //   //Get the Pin markups
  //   var measureMarkupArray = hwv.measureManager.getAllMeasurements();
  //   for (var index = 0; index < measureMarkupArray.length; index++) {
  //     if (measureMarkupArray[index].getName() === "Pin") {
  //       //Validate the Pin assocoated object based on its ID and bounding box
  //       //calculate the normal vector for ray firing
  //       var camPos = measureMarkupArray[index].getCameraForPin().getPosition();
  //       var pinPos = measureMarkupArray[index]._pinCenter3d;
  //       var pinToCameraVec = Communicator.Point3.subtract(camPos, pinPos);
  //       //Log the pin data
  //       var bodyNodeIDAssociatedWithPin =
  //         measureMarkupArray[index].getNodeIDForPin();
  //       var parentNodeIDAssociatedWithPin = GetParentNodeWithGenericID(
  //         measureMarkupArray[index].getNodeIDForPin()
  //       );
  //       //Get properties of object on which pin is placed
  //       var pinObjectProperties = await hwv.model.getNodeProperties(
  //         parentNodeIDAssociatedWithPin
  //       );

  //       console.log(
  //         "Pin node parent " +
  //           parentNodeIDAssociatedWithPin +
  //           " " +
  //           hwv.model.getNodeGenericId(parentNodeIDAssociatedWithPin) +
  //           " " +
  //           hwv.model.getNodeName(parentNodeIDAssociatedWithPin) +
  //           " " +
  //           "TYPE  " +
  //           pinObjectProperties["TYPE"] +
  //           "\n"
  //       );
  //       //Update the node name in pin object
  //       measureMarkupArray[index].setNodeNameForPin(
  //         hwv.model.getNodeName(parentNodeIDAssociatedWithPin)
  //       );

  //       //Fire ray to get the objects in path
  //       /* var ray = new Communicator.Ray(pinPos, pinToCameraVec);
  // 			var pickConfig = new Communicator.PickConfig(Communicator.SelectionMask.All);
  // 			var selectionArrayOne = await hwv.getView().pickAllFromRay(ray, pickConfig);
  // 			var selectionArrayTwo = await hwv.getView().pickAllFromRay(ray.negate(), pickConfig); */
  //       //Get bounding box of object associated with Pin to decide the radius for sphere selection
  //       var pinObjectBoundingBox =
  //         measureMarkupArray[index].getBoundingForPin();
  //       var boxcenter = pinObjectBoundingBox.center();
  //       var extents = pinObjectBoundingBox.extents();
  //       var sphereRadius = extents.length() / 10.0;
  //       var selectionItemsArray = [],
  //         selectionItemsSameTypeArray = [];
  //       //Get objects using spherical selection.
  //       selectionItemsArray = await FindObjectsUsingSphereSelection(
  //         boxcenter,
  //         sphereRadius
  //       );

  //       //var nodeIDArray = [];
  //       var raySelectBodyVsParentMap = {};
  //       //Copy all the node ids from selection item
  //       for (var ii = 0; ii < selectionItemsArray.length; ii++) {
  //         raySelectBodyVsParentMap[selectionItemsArray[ii].getNodeId()] =
  //           GetParentNodeWithGenericID(selectionItemsArray[ii].getNodeId());
  //       }

  //       //Get the properties using node id array
  //       var raySelectedNodesPropertiesMap = [];
  //       await collectallPropertiesAsync(
  //         Object.values(raySelectBodyVsParentMap),
  //         raySelectedNodesPropertiesMap
  //       );

  //       //Check the count of objects with same type and decide
  //       Object.keys(raySelectBodyVsParentMap).forEach(async function (key) {
  //         var raySelectedNodeProperties =
  //           raySelectedNodesPropertiesMap[
  //             raySelectBodyVsParentMap[Number(key)]
  //           ];
  //         if (
  //           raySelectedNodeProperties["TYPE"] !== undefined &&
  //           pinObjectProperties["TYPE"] !== undefined
  //         ) {
  //           if (
  //             raySelectedNodeProperties["TYPE"] === pinObjectProperties["TYPE"]
  //           ) {
  //             selectionItemsSameTypeArray.push(key);
  //           }
  //         }
  //       });

  //       //Validate the objects (same type) to get exact object
  //       var objectStatus = pinObjectStatus[4];
  //       var exactObjectNode = -111;
  //       var exactObjectNode = await FindExactObjectFromSelectedObjects(
  //         selectionItemsSameTypeArray,
  //         measureMarkupArray[index].getBoundingForPin()
  //       );
  //       if (exactObjectNode === null) objectStatus = pinObjectStatus[1];
  //       else {
  //         //compare the bounding boxes
  //         pinObjectBoundingBox = measureMarkupArray[index].getBoundingForPin();
  //         var nodeIDArray = [];
  //         nodeIDArray.push(exactObjectNode);
  //         var raySelectedNodeBoundingBox = await hwv.model.getNodesBounding(
  //           nodeIDArray
  //         );

  //         //log the ray selected node information
  //         //console.log("Ray selected node parent " + raySelectBodyVsParentMap[Number(key)] + " " + hwv.model.getNodeGenericId(raySelectBodyVsParentMap[Number(key)]) + " " + hwv.model.getNodeName(raySelectBodyVsParentMap[Number(key)]) + " " + "TYPE  " + raySelectedNodeProperties["TYPE"] + "\n");

  //         if (pinObjectBoundingBox.equals(raySelectedNodeBoundingBox)) {
  //           //compare node name
  //           var pinObjectNodeName = hwv.model.getNodeName(
  //             bodyNodeIDAssociatedWithPin
  //           );
  //           var raySelectedNodeName = hwv.model.getNodeName(exactObjectNode);
  //           if (pinObjectNodeName === raySelectedNodeName) {
  //             //Not modified
  //             objectStatus = pinObjectStatus[0];
  //           } else {
  //             //modified
  //             objectStatus = pinObjectStatus[3];
  //           }
  //         } else {
  //           //modified
  //           objectStatus = pinObjectStatus[2];
  //         }
  //       }

  //       //Add Pin status
  //       measureMarkupArray[index].setPinStatusForPin(objectStatus);
  //     }
  //   }
  // };
  //find exact object from object array. (param - body object id array,  BB of associated pin object id)
  async function FindExactObjectFromSelectedObjects(
    selectionItemsArray,
    bbOfPinAssocObject
  ) {
    var exactObjectNode = -111;
    if (selectionItemsArray.length === 0) return null;
    else if (selectionItemsArray.length === 1)
      exactObjectNode = selectionItemsArray[0];
    else if (selectionItemsArray.length > 1) {
      //Identify the exact object -
      //Find the object whose BB center is near to pin associated object BB center.
      var bbCenterDistancVsObjectIDMap = [];
      for (var ii = 0; ii < selectionItemsArray.length; ii++) {
        var distance = 0,
          nodeIDArray = [];
        nodeIDArray.push(Number(selectionItemsArray[ii]));
        var bbOfSelectedObject = await hwv.model.getNodesBounding(nodeIDArray);
        var diff = Communicator.Point3.subtract(
          bbOfSelectedObject.center(),
          bbOfPinAssocObject.center()
        );
        distance = Math.abs(
          Communicator.Point3.subtract(
            bbOfSelectedObject.center(),
            bbOfPinAssocObject.center()
          ).length()
        );
        bbCenterDistancVsObjectIDMap[distance] = selectionItemsArray[ii];
      }
      var num = Object.keys(bbCenterDistancVsObjectIDMap).map(Number);
      var shortestDistance = Math.min(...num);

      exactObjectNode = bbCenterDistancVsObjectIDMap[shortestDistance];
    }
    return Number(exactObjectNode);
  }

  //Iterate through the selection context handle to get selected nodes
  function CollectNodesUsingLoop(handle, selectionItemsArray) {
    var dummyArray = [];
    var loop = function (selectionItems) {
      if (selectionItems) {
        for (var ii = 0; ii < selectionItems.length; ii++)
          selectionItemsArray.push(selectionItems[ii]);
      } else return Promise.resolve(null);
      return hwv.getView().advanceIncrementalSelection(handle).then(loop);
    };
    return loop(dummyArray).then(function () {
      return hwv.getView().endIncrementalSelection(handle);
    });
  }
  //Find the selection items  using spherical selection
  async function FindObjectsUsingSphereSelection(center, radius) {
    //Pick configuration
    var incPickConfig = new Communicator.IncrementalPickConfig(
      Communicator.SelectionMask.All
    );
    //objects need not to be fully contained
    incPickConfig.mustBeFullyContained = false;
    var selectionItemsArray = [];
    var handle = await hwv
      .getView()
      .beginSphereSelection(center, radius, incPickConfig);
    var status = await CollectNodesUsingLoop(handle, selectionItemsArray);
    //return selection array
    return selectionItemsArray;
  }

  //Close Pin setting dialog when clicked on "close button"
  $("#3DPin-markup-flags-setting-close")
    .button()
    .on("click", function () {
      //Remove the table from dialog, as we create new table when dialog is launched
      var tableElement = document.getElementById("flagInfoTable");
      tableElement.parentNode.removeChild(tableElement);
      //Close the dialog
      document.getElementById("viewer-3dpinsetting-dialog").style.display =
        "none";
    });

  $("#3DPin-markup-flags-setting-Add")
    .button()
    .on("click", function () {
      //Reset the text box
      document.getElementById("3dpinsetting-addNewFlag-input").value = "";
      //Launch add flag dialog
      document.getElementById("addNewFlagTable").style.display = "block";
      //disable the "Add new flag" and "close" button on 3D pin setting dialog
      document.getElementById("3DPin-markup-flags-setting-Add").disabled = true;
      document.getElementById(
        "3DPin-markup-flags-setting-close"
      ).disabled = true;
    });

  //make Pin setting dialog as draggable, so that it can be moved wherever we want
  $("#viewer-3dpinsetting-dialog").draggable({
    handle: ".hoops-ui-window-header",
  });

  //Close the Add flag dialog
  $("#3dpinsetting-addNewFlag-cancel")
    .button()
    .on("click", function () {
      document.getElementById("addNewFlagTable").style.display = "none";
      //enable the "Add new flag" and "close" button on 3D pin setting dialog
      document.getElementById(
        "3DPin-markup-flags-setting-Add"
      ).disabled = false;
      document.getElementById(
        "3DPin-markup-flags-setting-close"
      ).disabled = false;
    });

  //Add color pallet to "Add new Flag" dialog based on browser
  var agentUser = window.navigator.userAgent;
  var colorTD = $("#3dpinsetting-addNewFlag-color-td");
  var posTrident = agentUser.indexOf("Trident/");
  if (posTrident > 0) {
    colorTD.append(
      '<div><input type="text" id="newflagcolor" class="color-picker" data-position="bottom left"></input></div>'
    );
    tr.appendChild(th);
    //Set the color pallet to class
    $("INPUT.color-picker").each(function () {
      $(this).minicolors({
        position: $(this).attr("data-position") || "bottom left",
        format: "rgb",
        control: "hue",
      });
    });
    //set a default color
    $("#newflagcolor").minicolors("value", "rgb(0,255,0)");
  } else {
    colorTD.append(
      '<input type="color" id="newflagcolor" value="#ff0000"></input>'
    );
  }

  //Save the new Flag item using data entered on Add Flag dialog
  $("#3dpinsetting-addNewFlag-save")
    .button()
    .on("click", function () {
      var newflagname = document.getElementById(
        "3dpinsetting-addNewFlag-input"
      );
      //Check if flag name already exists, if yes then retun back.
      if (
        objectFlags[newflagname.value] !== undefined ||
        newflagname.value === ""
      ) {
        alert("Flag name empty or already exists");
        return;
      }
      var hexColor = "";
      if ($("#newflagcolor").hasClass("color-picker")) {
        var color = rgbStringToColorObject(
          document.getElementById("newflagcolor").value
        );
        hexColor = rgb2Hex(color.r, color.g, color.b);
      } else hexColor = document.getElementById("newflagcolor").value;

      var table = document.getElementById("flagInfoTable");
      var rowCount = table.rows.length;
      var row = table.insertRow(rowCount);

      var cell = row.insertCell(0);
      cell.width = "40";
      cell.id = "td" + newflagname.value + "0";
      cell.innerHTML =
        '<input type="checkbox" id="flagnameCheckBox_' +
        newflagname.value +
        '" onchange="ChangeIndividualFlagPinVisibility(this)" checked></input>';

      var firstcell = row.insertCell(1);
      firstcell.width = "40";
      firstcell.id = "td" + newflagname.value + "1";
      firstcell.innerHTML =
        '<input type="radio" id="flagnameRadio_' +
        newflagname.value +
        '" onchange="ChangePinHighLightStatus(this)" name ="highlight">';

      var secondcell = row.insertCell(2);
      secondcell.width = "75";
      secondcell.id = "td" + newflagname.value + "2";
      secondcell.innerHTML =
        '<div id="flagnameColorBox_' +
        newflagname.value +
        '" class="boxsquare" style="background-color:' +
        hexColor +
        '"></div>';

      //Change the color pallet control on Pin flag setting UI based on type of browser
      var agentUser = window.navigator.userAgent;
      var posTrident = agentUser.indexOf("Trident/");
      if (posTrident > 0) {
        secondcell.innerHTML +=
          '<div style="display: none;" id="flagnameColorPalletParent_' +
          newflagname.value +
          '"><input type="text" id="flagnameColorPallet_' +
          newflagname.value +
          '" class="color-picker" style="display: none;"></div>';
        //Set the color pallet to class
        $("INPUT.color-picker").each(function () {
          $(this).minicolors({
            position: $(this).attr("data-position") || "bottom left",
            format: "rgb",
            control: "hue",
          });
        });
        //set a default color
        $("#flagnameColorPallet_" + newflagname.value).minicolors(
          "value",
          "rgb(0,255,0)"
        );
      } else {
        secondcell.innerHTML +=
          '<div><input type="color" id="flagnameColorPallet_' +
          newflagname.value +
          '" value="#ff0000" style="display: none;"></div>';
      }

      var thirdcell = row.insertCell(3);
      thirdcell.width = "125";
      thirdcell.id = "td" + newflagname.value + "3";
      var labelname = newflagname.value;
      thirdcell.innerHTML =
        '<label id="flagname_' +
        labelname +
        '" style="font-size: 12px;">' +
        labelname +
        "</label>" +
        '<input type="text" id="flagnameinput_' +
        labelname +
        '"   style= "display: none;" value="' +
        labelname +
        '"> </input>';

      var fourthcell = row.insertCell(4);
      fourthcell.width = "125";
      fourthcell.id = "td" + newflagname.value + "3";
      fourthcell.innerHTML =
        ' <div style="float: right"><button id="edit_' +
        newflagname.value +
        '"  style= "display: block;float: left" onclick="editFlagTableRow(this.id)">Edit</button><button id="apply_' +
        newflagname.value +
        '"  style= "display: none;float: left" onclick="applyFlagTableRow(this.id)">Apply</button><button id="delete_' +
        newflagname.value +
        '" style= "display: block;" onclick="deleteFlagTableRow(this.id)">Delete</button></div>';

      document.getElementById("addNewFlagTable").style.display = "none";
      //enable the "Add new flag" and "close" button on 3D pin setting dialog
      document.getElementById(
        "3DPin-markup-flags-setting-Add"
      ).disabled = false;
      document.getElementById(
        "3DPin-markup-flags-setting-close"
      ).disabled = false;

      //Add new flag item to flag object
      objectFlags[newflagname.value] = hexColor;
      //Add new flag name in visibility map
      objectFlagsVisibilityState[newflagname.value] = true;
    });

  //Polulate the list/table  with flag information
  function populateFlagInfoTable() {
    var posTrident = "";
    var myTableDiv = document.getElementById("flagInfoTableDiv");

    var table = document.createElement("TABLE");
    table.id = "flagInfoTable";
    table.border = "1";
    //Head of table
    var tableHead = document.createElement("THEAD");
    table.appendChild(tableHead);

    var trh = document.createElement("TR");
    tableHead.appendChild(trh);
    var th0 = document.createElement("TH");
    th0.width = "40";
    th0.id = "th" + key + "0";
    th0.align = "right";
    th0.innerHTML =
      '<input type="checkbox" id="flagnameCheckBox_Head"  onchange="ChangeAllFlagPinVisibility(this)" checked></input>';
    trh.appendChild(th0);

    var th1 = document.createElement("TH");
    th1.width = "70";
    th1.id = "th" + "1";
    th1.innerHTML = '<label style="font-size: 12px;">Highlight</label>';
    trh.appendChild(th1);

    var th2 = document.createElement("TH");
    th2.width = "75";
    th2.id = "th" + "2";
    th2.innerHTML = '<label style="font-size: 12px;">Color</label>';
    trh.appendChild(th2);

    var th3 = document.createElement("TH");
    th3.width = "125";
    th3.id = "th" + "3";
    th3.innerHTML = '<label style="font-size: 12px;">Flag Name</label>';
    trh.appendChild(th3);

    var th4 = document.createElement("TH");
    th4.width = "125";
    th4.id = "th" + "4";
    th4.innerHTML = '<label style="font-size: 12px;">Operation</label>';
    trh.appendChild(th4);

    //Body of table
    var tableBody = document.createElement("TBODY");
    table.appendChild(tableBody);

    for (let key in objectFlags) {
      var tr = document.createElement("TR");
      tableBody.appendChild(tr);

      var td0 = document.createElement("TD");
      td0.width = "40";
      td0.id = "td" + key + "0";
      td0.innerHTML =
        '<input type="checkbox" id="flagnameCheckBox_' +
        key +
        '" onchange="ChangeIndividualFlagPinVisibility(this)" checked></input>';
      tr.appendChild(td0);

      var td1 = document.createElement("TD");
      td1.width = "70";
      td1.id = "td" + key + "1";
      td1.innerHTML =
        '</input><input type="radio" id="flagnameRadio_' +
        key +
        '" onchange="ChangePinHighLightStatus(this)" name ="highlight">';
      tr.appendChild(td1);

      //for j = 0
      var td2 = document.createElement("TD");
      td2.width = "75";
      td2.id = "td" + key + "2";
      td2.innerHTML =
        '<div id="flagnameColorBox_' +
        key +
        '" class="boxsquare" style="background-color:' +
        objectFlags[key] +
        ';"></div>';
      //td1.backgroundColor = objectFlags[key];

      //Change the color pallet control on Pin flag setting UI based on type of browser
      var agentUser = window.navigator.userAgent;
      posTrident = agentUser.indexOf("Trident/");
      if (posTrident > 0) {
        td2.innerHTML +=
          '<div style="display: none;" id="flagnameColorPalletParent_' +
          key +
          '"><input type="text" id="flagnameColorPallet_' +
          key +
          '" class="color-picker" style="display: none;"></div>';
      } else {
        td2.innerHTML +=
          '<div><input type="color" id="flagnameColorPallet_' +
          key +
          '" value="#ff0000" style="display: none;"></div>';
      }
      tr.appendChild(td2);

      var td3 = document.createElement("TD");
      td3.width = "125";
      td3.id = "td" + key + "3";
      var labelname = key;
      td3.innerHTML =
        '<label id="flagname_' +
        key +
        '" style="font-size: 12px;">' +
        labelname +
        "</label>" +
        '<input type="text" id="flagnameinput_' +
        key +
        '"   style= "display: none;" value="' +
        labelname +
        '"> </input>';
      tr.appendChild(td3);

      var td4 = document.createElement("TD");
      td4.width = "125";
      td4.id = "td" + key + "4";
      td4.innerHTML =
        ' <div style="float: right"><button id="edit_' +
        key +
        '"  style= "display: block;float: left" onclick="editFlagTableRow(this.id)">Edit</button><button id="apply_' +
        key +
        '"  style= "display: none;float: left" onclick="applyFlagTableRow(this.id)">Apply</button><button id="delete_' +
        key +
        '" style= "display: block;" onclick="deleteFlagTableRow(this.id)">Delete</button></div>';
      tr.appendChild(td4);

      if (tr.sectionRowIndex === 0) {
        tr.querySelector("#delete_" + key).disabled = true;
      }
    }

    myTableDiv.appendChild(table);

    for (let key in objectFlags) {
      if (posTrident > 0) {
        //Set the color pallet to class
        $("INPUT.color-picker").each(function () {
          $(this).minicolors({
            position: $(this).attr("data-position") || "bottom left",
            format: "rgb",
            control: "hue",
          });
        });
        //set a default color
        $("#flagnameColorPallet_" + key).minicolors("value", "rgb(0,255,0)");
      }
    }
  }

  //Show dialog with reference to canvas size and
  var showpopupdialogue = function (dialogid) {
    var a = $(dialogid),
      c = a.width(),
      b = a.height();
    if (void 0 !== c && void 0 !== b) {
      var d = hwv.view.getCanvasSize();
      a.css({
        left: (d.x - c) / 2 + "px",
        top: (d.y - b) / 2 + "px",
      });
    }
    $(dialogid).show();
    a.draggable({
      handle: ".hoops-ui-window-header",
    });
  };
}

function UnhighlightAllPinMarkups() {
  var measureMarkupArray = hwv.measureManager.getAllMeasurements();
  for (var index = 0; index < measureMarkupArray.length; index++) {
    if (measureMarkupArray[index].getName() === "Pin") {
      if (measureMarkupArray[index].isHighlighted === true)
        measureMarkupArray[index].onUnHighlight();
    }
  }
}
//Function to set desired unit to curent/old measure markups
function SetDesiredUnitToMarkups(hwv) {
  //Array of measure markup type that are allowed for calculation
  var measureMarkupNamesArray = [
    "MeasureStraightEdgeLength",
    "MeasureFaceFaceDistance",
    "MeasurePointPointDistance",
  ];
  //Get ann measure markups (includes current one as well)
  var measureMarkupArray = hwv.measureManager.getAllMeasurements();
  //Iterate all markups to modify the text as per desired units.
  for (var b = 0; b < measureMarkupArray.length; b++) {
    var markupName = measureMarkupArray[b].getName();

    if (
      measureMarkupNamesArray[0] === markupName ||
      measureMarkupNamesArray[1] === markupName ||
      measureMarkupNamesArray[2] === markupName
    ) {
      var currentUnitMultiplier = measureMarkupArray[b].getUnitMultiplier();
      var measureValue = measureMarkupArray[b].getMeasurementValue();

      //Convert measure value from other units to mm
      var measureValueInMM = measureValue * currentUnitMultiplier;
      //Set unit multiplier to convert from mm to default unit (set through setting UI)
      measureMarkupArray[b]._unitMultiplier =
        GetUnitMultiplierFromMMToDesiredUnit(desiredUnitForMeasurement);
      measureMarkupArray[b]._measurementValue =
        measureValueInMM / measureMarkupArray[b]._unitMultiplier;
      //Farctional inch have custom text compose method as HC doesnt provide it.
      if (unitType.fractional_inch === desiredUnitForMeasurement) {
        measureMarkupArray[b].setMeasurementText(
          SetMeasurementText_fractional_inch(
            measureMarkupArray[b]._measurementValue
          )
        );
      }
      //Farctional foot have custom text compose method as HC doesnt provide it.
      else if (unitType.fractional_foot === desiredUnitForMeasurement) {
        measureMarkupArray[b].setMeasurementText(
          SetMeasurementText_fractional_foot(
            measureMarkupArray[b]._measurementValue
          )
        );
      }
      //Used HC method to compose measure text in case of non fractional unit as they are supported by HC
      else {
        measureMarkupArray[b].setMeasurementText(
          Communicator.Util.formatWithUnit(
            measureMarkupArray[b]._measurementValue,
            measureMarkupArray[b]._unitMultiplier
          )
        );
      }
    }
  }
}

function SetSelectOperator(hwv) {
  //Set default operator "Select" after reset
  hwv.operatorManager.set(Communicator.OperatorId.Select, 1);
  //Set "Select" opearator icon on tool bar
  var selectParts = document.getElementById("select-parts");
  selectParts = $(selectParts);
  var operatorClassName = selectParts.data("operatorclass");
  var parentSelect = selectParts.closest(".toolbar-submenu");
  var buttonSelect = $("#" + parentSelect.data("button"));
  var toolIconSelect = buttonSelect.find(".tool-icon");
  toolIconSelect.length &&
    (toolIconSelect.removeClass(buttonSelect.data("operatorclass").toString()),
    toolIconSelect.addClass(operatorClassName),
    buttonSelect.data("operatorclass", operatorClassName),
    (selectParts = selectParts.attr("title")),
    void 0 !== selectParts && buttonSelect.attr("title", selectParts));
}

//Add UI for different Measurement options
function AddUIForMeasurementTool(hwv) {
  //Combo box to select default Measurement unit type
  var a = $("#settings-tab-general");
  a.children()
    .eq(1)
    .append(
      "<div class='settings-block'><label>Length Measure Unit:</label><select id='settings-length-unit' class='right-align'><option value='0'>MM</option><option value='1'>CM</option><option value='2'>Meter</option><option value='3'>Inch</option><option value='4'>Feet</option><option value='5'>Fractional Inch</option><option value='6'>Fractional Feet & Inch</option></select><span class='clear-both'></span></div>"
    );

  //Combo box to select precision for Measurement value
  var a = $("#settings-tab-general");
  a.children()
    .eq(1)
    .append(
      "<div class='settings-block'><label>Measurement Precision:</label><select id='settings-measure-value-precision' class='right-align'><option value='0' selected>0</option><option value='1'>0.1</option><option value='2'>0.01</option><option value='3'>0.001</option><option value='4'>0.0001</option><option value='5'>0.00001</option></select><span class='clear-both'></span></div>"
    );

  //Combo box to select unit for measured angle value
  var a = $("#settings-tab-general");
  a.children()
    .eq(1)
    .append(
      "<div class='settings-block'><label>Angle Measure Unit:</label><select id='settings-angle-unit' class='right-align'><option value='0'>Degrees</option><option value='1'>Degrees, Minutes and Seconds</option><option value='2'>Radians</option></select><span class='clear-both'></span></div>"
    );

  //Combo box to select unit for measure area value
  var a = $("#settings-tab-general");
  a.children()
    .eq(1)
    .append(
      "<div class='settings-block'><label>Area Measure Unit:</label><select id='settings-area-unit' class='right-align'><option value='0'>mm2</option><option value='1'>cm2</option><option value='2' selected>m2</option><option value='3'>in2</option><option value='4'>ft2</option><option value='5'>Acres</option><option value='6'>Hectare</option></select><span class='clear-both'></span></div>"
    );

  //Get "Reset" Div element added on hoops_web_viewer_sample.html, set the onclick method

  var idOrbitButton = document.getElementById("operator-camera-orbit");
  var idWalkButton = document.getElementById("operator-camera-walk");
  idOrbitButton.addEventListener("click", function () {
    SetSelectOperator(hwv);
    $("#Redline-markup-config").hide();
  });
  idWalkButton.addEventListener("click", function () {
    SetSelectOperator(hwv);
    $("#Redline-markup-config").hide();
  });

  //Apply the Asite settings when clicked on "Apply" button from setting dialog
  var idSettingApplyBtn = document.getElementById(
    "viewer-settings-apply-button"
  );
  idSettingApplyBtn.onclick = function ApplyAsiteSettings() {
    //Selection state of unit type combo box
    var unitTypeItemIndex = Number(
      document.getElementById("settings-length-unit").value
    );
    //Selection state of precision combo box
    var precisionItemIndex = Number(
      document.getElementById("settings-measure-value-precision").value
    );
    //Selection state of angle unit combo box
    var angleUnitItemIndex = Number(
      document.getElementById("settings-angle-unit").value
    );
    //Selection state of area unit combo box
    var areaUnitItemIndex = Number(
      document.getElementById("settings-area-unit").value
    );

    switch (unitTypeItemIndex) {
      case 0:
        desiredUnitForMeasurement = unitType.mm;
        break;
      case 1:
        desiredUnitForMeasurement = unitType.cm;
        break;
      case 2:
        desiredUnitForMeasurement = unitType.m;
        break;
      case 3:
        desiredUnitForMeasurement = unitType.inch;
        break;
      case 4:
        desiredUnitForMeasurement = unitType.feet;
        break;
      case 5:
        desiredUnitForMeasurement = unitType.fractional_inch;
        break;
      case 6:
        desiredUnitForMeasurement = unitType.fractional_foot;
        break;
    }

    switch (precisionItemIndex) {
      case 0:
        measureValueForPrecision = measureValuePrecision.zero;
        break;
      case 1:
        measureValueForPrecision = measureValuePrecision.one;
        break;
      case 2:
        measureValueForPrecision = measureValuePrecision.two;
        break;
      case 3:
        measureValueForPrecision = measureValuePrecision.three;
        break;
      case 4:
        measureValueForPrecision = measureValuePrecision.four;
        break;
      case 5:
        measureValueForPrecision = measureValuePrecision.five;
        break;
    }

    switch (angleUnitItemIndex) {
      case 0:
        AngleUnitForMeasurement = angleUnitType.Degrees;
        break;
      case 1:
        AngleUnitForMeasurement = angleUnitType.DegreesMinutesSeconds;
        break;
      case 2:
        AngleUnitForMeasurement = angleUnitType.Radians;
        break;
    }

    switch (areaUnitItemIndex) {
      case 0:
        AreaUnitForMeasurement = areaUnitType.sqmm;
        break;
      case 1:
        AreaUnitForMeasurement = areaUnitType.sqcm;
        break;
      case 2:
        AreaUnitForMeasurement = areaUnitType.sqm;
        break;
      case 3:
        AreaUnitForMeasurement = areaUnitType.sqinch;
        break;
      case 4:
        AreaUnitForMeasurement = areaUnitType.sqfeet;
        break;
      case 5:
        AreaUnitForMeasurement = areaUnitType.acre;
        break;
      case 6:
        AreaUnitForMeasurement = areaUnitType.hectare;
        break;
    }

    //Change the text for already created measure markup with updated "desiredUnitForMeasurement"
    SetDesiredUnitToMarkups(hwv);
  };

  //Activate MeasureThreePointsAngleOperator operator on button click
  var idThreePointAngleMeasureBtn = document.getElementById(
    "measure-angle-three-points"
  );
  idThreePointAngleMeasureBtn.onclick =
    function ActiveThreePointAngleMeasureOperator() {
      hwv.operatorManager.set(measureAngleOperatorHandle, 1);
    };

  //Undo/delete the Measurements. Same as Ecs key functionality provided by HC
  var idMeasurementUndoBtn = document.getElementById("measurement-undo");
  idMeasurementUndoBtn.onclick = function UndoMeasurement() {
    hwv.measureManager.removeLastMeasurement();
  };
  // reset view button click
  var resetViewBtn = document.getElementById("reset-view");
  resetViewBtn.onclick = function ResetViewBtn() {
    var view = hwv.getView();
    view.setCamera(view._initialCamera);
    view.setProjectionMode(Communicator.Projection.Perspective);
  };
}

function SetCustomRedlineMarkup(hwv, ui) {
  const redlineCircleOperatorEx =
    new Communicator.Operator.RedlineCircleOperatorEx(hwv);
  redlineCircleExOperatorHandle = hwv.operatorManager.registerCustomOperator(
    redlineCircleOperatorEx
  );

  const redlineRectangleOperatorEx =
    new Communicator.Operator.RedlineRectangleOperatorEx(hwv);
  redlineRectangleExOperatorHandle = hwv.operatorManager.registerCustomOperator(
    redlineRectangleOperatorEx
  );

  const redlinePolylineOperatorEx =
    new Communicator.Operator.RedlinePolylineOperatorEx(hwv);

  redlinePolylineExOperatorHandle = hwv.operatorManager.registerCustomOperator(
    redlinePolylineOperatorEx
  );

  const redlineTextOperatorEx = new Communicator.Operator.RedlineTextOperatorEx(
    hwv
  );
  redlineTextOperatorHandle = hwv.operatorManager.registerCustomOperator(
    redlineTextOperatorEx
  );
}

function ResetMarkupConfigDialog() {
  var defColor = Communicator.Color.red();
  if ($("#redline-markup-color").hasClass("color-picker"))
    $("#redline-markup-color").minicolors(
      "value",
      colorObjectToRgbString(defColor)
    );
  else
    document.getElementById("redline-markup-color").value = rgb2Hex(
      defColor.r,
      defColor.g,
      defColor.b
    );

  document.getElementById("redline-markup-line-thickness").value = "4";
  document.getElementById("redline-markup-text-size").value = "14";
  document.getElementById("redline-markup-config-text-bold").style.border = "";
  document.getElementById("redline-markup-config-text-italic").style.border =
    "";
  document.getElementById("redline-markup-config-text-underline").style.border =
    "";
  document.getElementById("redline-markup-arrow-head-type").value = "Arrow";
}

//Convert decimal foot value to fractional foot value
function SetMeasurementText_fractional_foot(footDecimalvalue) {
  var fractions = 12;
  var sTemp = "";
  var fractionPart = Math.floor(footDecimalvalue);
  var inchValue = (footDecimalvalue - fractionPart) / (1 / fractions);
  var inchFractionValue = SetMeasurementText_fractional_inch(inchValue);

  if (fractionPart > 0) {
    if (inchFractionValue.indexOf('12"') === 0) {
      //Increment feet fraction value by one as the inch part is 12.
      fractionPart++;
      //Reset text for inch, as 12 inch is now 1 feet and its been added to fractionPart
      inchFractionValue = "";
    }

    sTemp = fractionPart + "'";
  }
  if (inchFractionValue !== "") {
    if (fractionPart > 0) sTemp += " - ";

    sTemp += inchFractionValue;
  }
  return sTemp;
}

//Convert decimal inch value to fractional inch value
function SetMeasurementText_fractional_inch(inchDecimalvalue) {
  var fractions = 16;
  var sTemp = "";
  var fractionPart = Math.floor(inchDecimalvalue);
  var numerator = Math.round(
    (inchDecimalvalue - fractionPart) / (1 / fractions)
  );
  var denominator = fractions;
  while (numerator % 2 == 0 && denominator % 2 == 0) {
    numerator /= 2;
    denominator /= 2;
  }
  if (numerator == 1 && denominator == 1) {
    fractionPart += 1;
    numerator = 0;
  }

  if (fractionPart > 0) {
    sTemp = fractionPart;
  } else {
    sTemp = "";
  }

  if (numerator > 0) {
    if (fractionPart > 0) sTemp += " ";

    sTemp += numerator + "/" + denominator;
  }
  if (sTemp !== "") sTemp += '"';
  return sTemp;
}

//Convert Degrees to Degree Min Sec and Radians. Considered precision for converted value
function PerformAngleConversion(angleValueInDeg, angleUnit) {
  var angleValueString = "";
  switch (angleUnit) {
    case angleUnitType.Degrees:
      angleValueString =
        angleValueInDeg.toFixed(measureValueForPrecision).toString() +
        "\u00B0 ";
      break;
    case angleUnitType.DegreesMinutesSeconds:
      var floorDegreeValue = Math.floor(angleValueInDeg);
      var minutes = Math.floor((angleValueInDeg - floorDegreeValue) * 60);
      var seconds = (angleValueInDeg - floorDegreeValue - minutes / 60) * 3600;
      angleValueString =
        floorDegreeValue +
        "\u00B0 " +
        minutes +
        "' " +
        seconds.toFixed(measureValueForPrecision) +
        '"';
      break;
    case angleUnitType.Radians:
      angleValueString =
        Communicator.Util.degreesToRadians(angleValueInDeg)
          .toFixed(measureValueForPrecision)
          .toString() + " rad";
      break;
  }
  return angleValueString;
}

function PerformAreaConversion(areaValueInMM, areaUnit) {
  var areaValueString = "",
    tempAreaValue = 0;
  switch (areaUnit) {
    case areaUnitType.sqmm:
      areaValueString =
        areaValueInMM.toFixed(measureValueForPrecision).toString() +
        " mm\u00B2 ";
      break;
    case areaUnitType.sqcm:
      tempAreaValue = 0.01 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() +
        " cm\u00B2 ";
      break;
    case areaUnitType.sqm:
      tempAreaValue = 0.000001 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() +
        " m\u00B2 ";
      break;
    case areaUnitType.sqinch:
      tempAreaValue = 0.00155 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() +
        " in\u00B2 ";
      break;
    case areaUnitType.sqfeet:
      tempAreaValue = 0.00001076 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() +
        " ft\u00B2 ";
      break;
    case areaUnitType.acre:
      tempAreaValue = 0.0000000002471 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() + " acres ";
      break;
    case areaUnitType.hectare:
      tempAreaValue = 0.0000000001 * areaValueInMM;
      areaValueString =
        tempAreaValue.toFixed(measureValueForPrecision).toString() +
        " hectare ";
      break;
  }
  return areaValueString;
}

//Get unit multiplier based on unit type
function GetUnitMultiplierFromMMToDesiredUnit(desiredUnitType) {
  var desiredUnitMultiplier = 0;

  switch (desiredUnitType) {
    case unitType.mm:
      desiredUnitMultiplier = unitMultiplier.mm;
      break;
    case unitType.cm:
      desiredUnitMultiplier = unitMultiplier.cm;
      break;
    case unitType.m:
      desiredUnitMultiplier = unitMultiplier.m;
      break;
    case unitType.inch:
      desiredUnitMultiplier = unitMultiplier.inch;
      break;
    case unitType.feet:
      desiredUnitMultiplier = unitMultiplier.feet;
      break;
    case unitType.fractional_inch:
      desiredUnitMultiplier = unitMultiplier.inch;
      break;
    case unitType.fractional_foot:
      desiredUnitMultiplier = unitMultiplier.feet;
      break;
  }
  return desiredUnitMultiplier;
}

function findPos(obj) {
  var curtop = 0;
  if (obj.offsetParent) {
    do {
      curtop += obj.offsetTop;
    } while ((obj = obj.offsetParent));
    return [curtop];
  }
}

function PinMarkupEnhancement(hwv, ui) {
  var modelTreeContainer = document.getElementById("modelTree");

  $(modelTreeContainer).on(
    "mouseenter",
    ".ui-modeltree-label",
    function (event) {
      //Remove the previous highlighted Pins if any
      UnhighlightAllPinMarkups();
      var $targetMeasurement = jQuery(event.target);
      var $MeasureListItem = $targetMeasurement.closest(".ui-modeltree-item");
      var measureItemHtmlId = $MeasureListItem.get(0).id;
      var idData = measureItemHtmlId.split("_");
      if (idData[0] === "measurement") {
        var measureMarkupArray = hwv.measureManager.getAllMeasurements();
        //Iterate all markups to identify selected pin markup.
        for (var index = 0; index < measureMarkupArray.length; index++) {
          if (measureMarkupArray[index].getName() === "Pin") {
            if (measureMarkupArray[index]._uniqueId === idData[1]) {
              measureMarkupArray[index].onHighlight();
              hwv.markupManager.refreshMarkup();
              break;
            }
          }
        }
      }
    }
  );

  $(modelTreeContainer).on(
    "mouseleave",
    ".ui-modeltree-label",
    function (event) {
      var $targetMeasurement = jQuery(event.target);
      var $MeasureListItem = $targetMeasurement.closest(".ui-modeltree-item");
      var measureItemHtmlId = $MeasureListItem.get(0).id;
      var idData = measureItemHtmlId.split("_");
      if (idData[0] === "measurement") {
        var measureMarkupArray = hwv.measureManager.getAllMeasurements();
        //Iterate all markups to identify selected pin markup.
        for (var index = 0; index < measureMarkupArray.length; index++) {
          if (measureMarkupArray[index].getName() === "Pin") {
            if (measureMarkupArray[index]._uniqueId === idData[1]) {
              measureMarkupArray[index].onUnHighlight();
              hwv.markupManager.refreshMarkup();
              break;
            }
          }
        }
      }
    }
  );

  //select the 3D Pin markup from model tree (multiple)
  $(modelTreeContainer).on("click", ".ui-modeltree-label", function (event) {
    if (!event.ctrlKey) {
      for (let index = 0; index < selected3DPinMarkups.length; index++) {
        if (selected3DPinMarkups[index].isSelected) {
          selected3DPinMarkups[index].onDeselect();
          var measurementEleID =
            "#measurement_" + selected3DPinMarkups[index]._uniqueId;
          $(measurementEleID).removeClass("selected");
        }
      }
      //empty the array/list
      selected3DPinMarkups.length = 0;
      //Unhighlight all the Pins
      UnhighlightAllPinMarkups();
    }
    //Show model browser Pin items as selected , as HC doesnt highlights the multiple pin
    for (let index = 0; index < selected3DPinMarkups.length; index++) {
      var measurementEleID =
        "#measurement_" + selected3DPinMarkups[index]._uniqueId;
      $(measurementEleID).addClass("selected");
    }
    var $targetMeasurement = jQuery(event.target);
    var $MeasureListItem = $targetMeasurement.closest(".ui-modeltree-item");
    var measureItemHtmlId = $MeasureListItem.get(0).id;
    var idData = measureItemHtmlId.split("_");
    if (idData[0] === "measurement") {
      //Iterate all markups to identify pin markup to be selected.
      var measureMarkupArray = hwv.measureManager.getAllMeasurements();
      for (var index = 0; index < measureMarkupArray.length; index++) {
        if (measureMarkupArray[index].getName() === "Pin") {
          if (measureMarkupArray[index]._uniqueId === idData[1]) {
            measureMarkupArray[index].onSelect();
            selected3DPinMarkups.push(measureMarkupArray[index]);
            //Show model browser Pin item selected , in case when moved from multiple select to single select and the single select item was part of multiple select.
            var measurementEleID =
              "#measurement_" + measureMarkupArray[index]._uniqueId;
            $(measurementEleID).addClass("selected");
            hwv.markupManager.refreshMarkup();
            break;
          }
        }
      }
    }
  });

}

function ColorSettingsOnComparedModelObjects(hwv, ui) {
  //Add color pallet element to "assign-color-model-nodes-dialog" dialog based on browser type.
  var divColorPicker = document.getElementById("color-picker-model-nodes-div");
  var agentUser = window.navigator.userAgent;
  var posTrident = agentUser.indexOf("Trident/");
  if (posTrident > 0) {
    divColorPicker.innerHTML =
      "<div><input type='text' id='color-picker-model-nodes' class='color-picker'  /></div>";
    //Set the color pallet to class
    $("INPUT.color-picker").each(function () {
      $(this).minicolors({
        position: $(this).attr("data-position") || "bottom left",
        format: "rgb",
        control: "hue",
      });
    });
    //set a default color
    $("#color-picker-model-nodes").minicolors("value", "rgb(0,255,0)");
    //adjust the dialog height and width
    document.getElementById(
      "assign-color-model-nodes-dialog-body"
    ).style.width = "230px";
    document.getElementById(
      "assign-color-model-nodes-dialog-body"
    ).style.height = "100px";
  } else {
    divColorPicker.innerHTML =
      "<input type='color' id='color-picker-model-nodes' value='#ff0000' style='float: left'>";
    //adjust the dialog height and width
    document.getElementById(
      "assign-color-model-nodes-dialog-body"
    ).style.width = "100%";
  }

  //methods to perform model color options
  async function AssignColorToNodes() {
    var modelNodeColor = new Communicator.Color(0, 0, 255);
    //get the color value of selected item/node, in case of multiple selection consider last selected node
    var selectionMgr = hwv.getSelectionManager();
    var nodeSelectionitems = selectionMgr.getResults();
    //Get the last selected node id
    var lastSelectedNodeID = [];
    lastSelectedNodeID.push(
      nodeSelectionitems[nodeSelectionitems.length - 1].getNodeId()
    );
    var colorOfNode = await hwv.model.getNodesFaceColor(lastSelectedNodeID);
    if (colorOfNode.length > 0 && colorOfNode[0] !== null) {
      //Upadte the color picker color using global variable
      if ($("#color-picker-model-nodes").hasClass("color-picker"))
        $("#color-picker-model-nodes").minicolors(
          "value",
          colorObjectToRgbString(colorOfNode[0])
        );
      else
        document.getElementById("color-picker-model-nodes").value = rgb2Hex(
          colorOfNode[0].r,
          colorOfNode[0].g,
          colorOfNode[0].b
        );
    }
    //Launch the "assign-color-model-nodes-dialog" dialog
    document.getElementById("assign-color-model-nodes-dialog").style.display =
      "block";
  }

  function RemoveColorFromNodes() {
    var selectionMgr = hwv.getSelectionManager();
    var rootNodeID = hwv.model.getAbsoluteRootNode();
    var nodeSelectionitems = selectionMgr.getResults();
    for (
      var selectionItems = nodeSelectionitems, index = 0;
      index < selectionItems.length;
      index++
    ) {
      var nodeId = [];
      nodeId.push(selectionItems[index].getNodeId());
      //UnSet the node face color if "Model color" button is highlighted
      if (toggleStateForModelColors === false)
        hwv.model.unsetNodesFaceColor(nodeId);

      delete nodeIDVsColorMap[nodeId];
      delete nodeIDVsGenericIDMap[nodeId];
    }
  }

  //Assign dafault colors to color control
  function UpdateColorFromDefaultBoxToColorControl(backgroundColor) {
    //Upadte the color picker color using global variable
    if ($("#color-picker-model-nodes").hasClass("color-picker")) {
      $("#color-picker-model-nodes").minicolors("value", backgroundColor);
    } else {
      var colorObject = rgbStringToColorObject(backgroundColor);
      var hexcolor = rgb2Hex(colorObject.r, colorObject.g, colorObject.b);
      document.getElementById("color-picker-model-nodes").value = hexcolor;
    }
  }

  //Add the onClick events on default color boxes
  document.getElementById("color-picker-default-color-1").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-2").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-3").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-4").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-5").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-6").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-7").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-8").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-9").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };
  document.getElementById("color-picker-default-color-10").onclick =
    function () {
      UpdateColorFromDefaultBoxToColorControl(this.style.backgroundColor);
    };

  //Add context menu item "Assign Color"
  viewerContextMenu = ui._contextMenu;
  if (viewerContextMenu) {
    viewerContextMenu.appendItem(
      "assignColor",
      "Assign Color",
      function (selectedNodeId) {
        AssignColorToNodes();
      }
    );

    viewerContextMenu.appendItem(
      "editColor",
      "Edit Color",
      function (selectedNodeId) {
        AssignColorToNodes();
      }
    );

    viewerContextMenu.appendItem(
      "removeColor",
      "Remove Color",
      function (selectedNodeId) {
        RemoveColorFromNodes();
      }
    );

    //Enable/disable the options "Assign color", "Remove color"
    // $("#viewerContainer-canvas-container").mouseup(function (event) {
    //   //Hide the options bydefault
    //   $("#assignColor").hide();
    //   $("#removeColor").hide();
    //   $("#editColor").hide();
    //   //Check items in selection manager
    //   var isEligible = false;
    //   var selectionMgr = hwv.getSelectionManager();
    //   var nodeSelectionitems = selectionMgr.getResults();
    //   for (
    //     var selectionItems = nodeSelectionitems, index = 0;
    //     index < selectionItems.length;
    //     index++
    //   ) {
    //     var nodeId = selectionItems[index].getNodeId();
    //     //Perform eligibility on nodes for revit/ifc file
    //     if (fileType === Communicator.FileType.Ifc) {
    //       var genID = hwv.model.getNodeGenericId(nodeId);
    //       if (genID !== null && genID !== "") isEligible = true;
    //     } else if (fileType === Communicator.FileType.Revit) {
    //       isEligible = RvtEligibilityForContextMenuItems(nodeId).isEligible;
    //     }

    //     //Show context menu items if eligible
    //     if (isEligible) {
    //       if (nodeIDVsColorMap.hasOwnProperty(nodeId)) {
    //         $("#removeColor").show();
    //         $("#editColor").show();
    //       } else {
    //         $("#assignColor").show();
    //       }
    //     }
    //   }
    // });

    var modelBrowserContextMenu = ui._modelBrowser._contextMenu;
    if (modelBrowserContextMenu) {
      modelBrowserContextMenu.appendItem(
        "assignColorMB",
        "Assign Color",
        function (selectedNodeId) {
          AssignColorToNodes();
        }
      );

      modelBrowserContextMenu.appendItem(
        "removeColorMB",
        "Remove Color",
        function (selectedNodeId) {
          RemoveColorFromNodes();
        }
      );

      modelBrowserContextMenu.appendItem(
        "editColorMB",
        "Edit Color",
        function (selectedNodeId) {
          AssignColorToNodes();
        }
      );
    }

    var modelTreeContainer = document.getElementById("modelTree");

    $(modelTreeContainer).on("click", ".ui-modeltree-label", function (event) {
      //Hide the options bydefault
      $("#assignColorMB").hide();
      $("#removeColorMB").hide();
      $("#editColorMB").hide();
      $("#addToList").hide();
      $("#addToListViewerContext").hide();

      //Check items in selection manager
      var isEligible = false;
      var selectionMgr = hwv.getSelectionManager();
      var nodeSelectionitems = selectionMgr.getResults();
      for (
        var selectionItems = nodeSelectionitems, index = 0;
        index < selectionItems.length;
        index++
      ) {
        var nodeId = selectionItems[index].getNodeId();
        //Perform eligibility on nodes for revit/ifc file
        if (fileType === Communicator.FileType.Ifc) {
          var genID = hwv.model.getNodeGenericId(nodeId);
          if (genID !== null && genID !== "") isEligible = true;
        } else if (fileType === Communicator.FileType.Revit) {
          isEligible = RvtEligibilityForContextMenuItems(nodeId).isEligible;
        }

        if (isEligible) {
          if (nodeIDVsColorMap.hasOwnProperty(nodeId)) {
            $("#removeColorMB").show();
            $("#editColorMB").show();
          } else {
            $("#assignColorMB").show();
          }
          $("#addToList").show();
          $("#addToListViewerContext").show();
        }
      }
    });

    //Apply color to model node, basically add entry to map when clicked on "Apply"
    $("#assign-color-model-nodes-apply")
      .button()
      .on("click", function () {
        //Get the GUID using Node ID of node. Node
        var selectionMgr = hwv.getSelectionManager();
        var rootNodeID = hwv.model.getAbsoluteRootNode();
        var nodeSelectionitems = selectionMgr.getResults();
        for (
          var selectionItems = nodeSelectionitems, index = 0;
          index < selectionItems.length;
          index++
        ) {
          var nodeId = [];
          nodeId.push(selectionItems[index].getNodeId());
          var hexColor = "";
          //Get color value from color picker in dialog
          if ($("#color-picker-model-nodes").hasClass("color-picker")) {
            var color = rgbStringToColorObject(
              document.getElementById("color-picker-model-nodes").value
            );
            hexColor = rgb2Hex(color.r, color.g, color.b);
          } else
            hexColor = document.getElementById(
              "color-picker-model-nodes"
            ).value;

          var rgbColor = hexToRgb(hexColor);
          var currentColor = new Communicator.Color(
            rgbColor.r,
            rgbColor.g,
            rgbColor.b
          );

          //Fill the maps
          nodeIDVsColorMap[nodeId] = currentColor;
          //Set the node face color if "Model color" button is highlighted
          if (toggleStateForModelColors === false)
            hwv.model.setNodesFaceColor(nodeId, currentColor);

          if (fileType === Communicator.FileType.Revit) {
            var parentNodeName = hwv.model.getNodeName(nodeId);
            var promiseBB = hwv.model
              .getNodesBounding([nodeId])
              .then(function (promiseBB) {
                var bobString = bbStringForm(promiseBB.max, promiseBB.min);
                nodeIDVsGenericIDMap[nodeId] = parentNodeName + "_" + bobString;
              });
          } else if (fileType === Communicator.FileType.Ifc) {
            var genericID = hwv.model.getNodeGenericId(nodeId);
            nodeIDVsGenericIDMap[nodeId] = genericID;
          }
        }
      });

    //Close the "Assign color" dialog
    $("#assign-color-model-nodes-close")
      .button()
      .on("click", function () {
        //close dialog
        document.getElementById(
          "assign-color-model-nodes-dialog"
        ).style.display = "none";
      });

    //Make the dialog draggable using its header
    $("#assign-color-model-nodes-dialog").draggable({
      handle: ".hoops-ui-window-header",
    });

    //Toggle between the show/hide of the color in objects using node ids.
    var modelColorsBtn = document.getElementById("model-colors");
    modelColorsBtn.onclick = function ToggleColorsusingselectedNodeIDs() {
      if (toggleStateForModelColors) {
        for (var key in nodeIDVsColorMap) {
          var nodeID = [];
          nodeID.push(+key);
          hwv.model.setNodesFaceColor(nodeID, nodeIDVsColorMap[nodeID]);
        }
        toggleStateForModelColors = false;
        //Change apperance of button text
        this.style.border = "groove";
      } else {
        for (var key in nodeIDVsColorMap) {
          var nodeID = [];
          nodeID.push(+key);
          hwv.model.unsetNodesFaceColor(nodeID);
        }
        toggleStateForModelColors = true;
        this.style.border = "";
      }
    };
  }
}

//Function to add functionality based on canvas events
function CanvasContainerEvents(hwv, ui) {
  var ele = $("#viewerContainer-canvas-container");
  $("#viewerContainer-canvas-container").keydown(function (event) {
    //If escape is pressed, exit from redline, measure operator
    if (event.which == 27) {
      //Do not perform escape functionality for walk operator
      var walkmodeOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.WalkMode
      );
      var walkMouseOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );
      var walkKeyboardOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.KeyboardWalk
      );
      //check if redline operator is active, if yes then deactivate
      var activeRedlineMarkup = hwv.markupManager.getSelectedMarkup();
      var activeMarkupView = hwv.markupManager.getActiveMarkupView();
      null !== activeRedlineMarkup &&
        Object.getPrototypeOf(activeRedlineMarkup) instanceof
          Communicator.Markup.Redline.RedlineItem &&
        null !== activeMarkupView &&
        (activeMarkupView.removeMarkup(activeRedlineMarkup),
        hwv.markupManager.selectMarkup(null));
      //Need to Check if measure operator is active, if yes then deactivate
      //Currently there is no API available to do this, so skipping the step

      //Set the select operator
      SetSelectOperator(hwv);
    }
  });

  //Add wheel event  (JQuery dont have wheel event, so use javascript)
  var ele = document.getElementById("viewerContainer");
  document
    .getElementById("viewerContainer")
    .addEventListener("wheel", function () {
      //Progressive zoom/infinite zoom

      if (CamPostargetDistance != null) {
        //Change the target position with respect to position movement to acheive deep zoom.
        if (
          Communicator.Projection.Perspective === hwv.view.getProjectionMode()
        ) {
          var cam = hwv.view.getCamera();
          var camPos = cam.getPosition();
          var camTarget = cam.getTarget();
          var lookAtvec = Communicator.Point3.subtract(camTarget, camPos);
          var len = lookAtvec.length();
          //Compare both look at vector by limiting their precision after decimal point
          if (CamPostargetDistance.toFixed(4) != len.toFixed(4)) {
            lookAtvec.normalize();
            var ratio = CamPostargetDistance / len;

            cam.setHeight(cam.getHeight() * ratio);
            cam.setWidth(cam.getWidth() * ratio);

            var newTarget = Communicator.Point3.add(
              camPos,
              lookAtvec.scale(CamPostargetDistance)
            );
            cam.setTarget(newTarget);
            hwv.view.setCamera(cam);
          }
        }

        // console.log(projectionMatrix.m);
        // console.log(fullMatrix.m);

        // for (const [key, value] of nodeIdVsBoundingBoxForLoadedModels) {

        // 	// var isInside = frustum.containsPoint(new Vector3(0,0,0));
        // 	var centerPt = value.center();
        // 	// var isInside = frustum.containsPoint(centerPt);
        // 	var isInside = frustum.intersectsBox(value);
        // 	// console.log(`${key} = ${isInside}`);
        // 	// If model is not inside the frustum then delete it
        // 	if(!isInside) {
        // 		var deletedNodeName = hwv.model.getNodeName(key);

        // 		hwv.model.deleteNode(key);
        // 		var index = modelsLoaded.indexOf(deletedNodeName + ".scs");
        // 		// console.log("Outside");
        // 		// console.log(deletedNodeName + " : " + "index from modelsLoaded");
        // 		if (index > -1) {
        // 			modelsLoaded.splice(index, 1);
        // 			// console.log("ModelsLoaded : " + modelsLoaded.length);
        // 		}
        // 		// modelsLoaded.forEach(element => {
        // 		//  	if(element.indexOf(deletedNodeName) > -1) {
        // 		// 		 modelsLoaded.delete()
        // 		// 	 }
        // 		// });
        // 	}
        // 	// Else if
        // 	else
        // 	{
        // 		var nodeName = nodeIdVsNodeName.get(key) + ".scs";
        // 		var index = modelsLoaded.indexOf(nodeName);

        // 		if (index == -1) {

        // 			// console.log("Inside");
        // 			// console.log(nodeName + " : " + "index from modelsLoaded : " + index);
        // 			// console.log("Models To Load : " + modelsToLoad.length);
        // 			modelsToLoad.forEach(element => {
        // 				// console.log(element);
        // 				if( element.indexOf(nodeName) > -1) {
        // 					console.log("loadModelInChunks called : " + element);
        // 					loadModelInChunks(element);
        // 				}
        // 			});
        // 		}
        // 	}
        // }

        // console.log("Wheel event listener");
      }
    });
}

function Customize_Context_menu_Items(hwv, ui) {
  //Comtext Menu item - "Transparent"
  //Repalce HC click function with customized function
  var transParentContectItemVP = undefined; // ui._contextMenu._contextItemMap["transparent"];
  var transParentContectItemMB = undefined;
  //  ui._modelBrowser._contextMenu._contextItemMap["transparent"];
  if (
    transParentContectItemVP !== undefined &&
    transParentContectItemMB !== undefined
  ) {
    var transParentContextMenuClick = function () {
      //Get the selection set
      var selectionSet = hwv.getSelectionManager().getResults();
      //Refer the appropriate transparent map
      var sourceTransparencyMap = null;
      if (isViewPointActive) sourceTransparencyMap = transparentNodeTempMap;
      else sourceTransparencyMap = transparentNodeMap;

      for (var index = 0; index < selectionSet.length; index++) {
        var selectedNode = selectionSet[index].getNodeId();
        //Check the node with the global map used for transparent nodes
        if (sourceTransparencyMap.hasOwnProperty(selectedNode)) {
          //Remove the transparency for node
          let nodeArray = [];
          nodeArray.push(selectedNode);
          hwv.model.resetNodesOpacity(nodeArray);
          //Remove the node from map, since transparency for node is removed
          delete sourceTransparencyMap[selectedNode];
        } else {
          //Set the transparency
          let nodeArray = [];
          nodeArray.push(selectedNode);
          hwv.model.setNodesOpacity(nodeArray, 0.5);
          //Add entry of transparent node in map
          sourceTransparencyMap[selectedNode] = 1;
        }
      }
    };
    transParentContectItemVP.action = transParentContectItemMB.action =
      transParentContextMenuClick;
  }

  //Comtext Menu item - "Isolate"
  //Repalce HC click function with customized function
  var isolateContectItemVP = undefined; // ui._contextMenu._contextItemMap["isolate"];
  var isolateContectItemMB = undefined;
  //ui._modelBrowser._contextMenu._contextItemMap["isolate"];
  if (
    isolateContectItemVP !== undefined &&
    isolateContectItemMB !== undefined
  ) {
    var isolatetContextMenuClick = async function () {
      //Get the selection set
      var selectionSet = hwv.getSelectionManager().getResults();
      //Collect all node IDs
      isolateNodesArray = [];
      for (var index = 0; index < selectionSet.length; index++) {
        //Add nodes to global array
        isolateNodesArray.push(selectionSet[index].getNodeId());
      }

      //Isolate the nodes
      //hwv.model.setNodesVisibility([hwv.model.getAbsoluteRootNode()], true);
      hwv.model.setNodesOpacity(isolateNodesArray, 1);
      await isolateNodesEx(isolateNodesArray, true);
      //Check if node selected for isolate are also part of transparent, if yes then make them transparent
      for (var index = 0; index < focusNodesArray.length; index++) {
        if (transparentNodeMap.hasOwnProperty(focusNodesArray[index])) {
          hwv.model.setNodesOpacity([focusNodesArray[index]], 0.5);
        }
      }
      //deselect the nodes after isolate
      hwv.getSelectionManager().clear();
      //Clear the "focus" data (if any)
      focusNodesArray = [];
    };
    isolateContectItemVP.action = isolateContectItemMB.action =
      isolatetContextMenuClick;
  }

  //Add the "Focus" context menu item.
  //Do not reset the focusNodesArray array since we need to keep on adding the items in array in entire session
  function focusContextItemClick() {
    //Get the selection set
    var selectionSet = hwv.getSelectionManager().getResults();

    //Refer the appropriate focus array
    var sourceFocusArr = null;
    if (isViewPointActive) sourceFocusArr = focusNodesTempArray;
    else sourceFocusArr = focusNodesArray;

    for (var index = 0; index < selectionSet.length; index++) {
      //Add nodes to global array
      sourceFocusArr.push(selectionSet[index].getNodeId());
    }
    //Set visibilty of entire model as true first, we need entire model to visible with transparency
    //hwv.model.setNodesVisibility([hwv.model.getAbsoluteRootNode()], true);
    //hwv.model.resetModelOpacity();
    hwv.model.setNodesOpacity([hwv.model.getAbsoluteRootNode()], 0.1);
    hwv.model.setNodesOpacity(sourceFocusArr, 1);
    //Check if node selected for focus are also part of transparent, if yes then make them transparent
    for (var index = 0; index < sourceFocusArr.length; index++) {
      //Refer the appropriate transparent map
      var sourceTransparencyMap = null;
      if (isViewPointActive) sourceTransparencyMap = transparentNodeTempMap;
      else sourceTransparencyMap = transparentNodeMap;
      if (sourceTransparencyMap.hasOwnProperty(sourceFocusArr[index])) {
        hwv.model.setNodesOpacity([sourceFocusArr[index]], 0.5);
      }
    }
    //deselect the nodes after isolate
    hwv.getSelectionManager().clear();
    //Clear the "Isolate" data (if any)
    isolateNodesArray = [];
  }

  var viewerContextMenu = undefined; //ui._contextMenu;
  if (viewerContextMenu) {
    viewerContextMenu.appendItem("focus", "Focus", function () {
      focusContextItemClick();
    });
  }
  var modelBrowserContextMenu = undefined; // ui._modelBrowser._contextMenu;
  if (modelBrowserContextMenu) {
    modelBrowserContextMenu.appendItem(
      "focus",
      "Focus",
      function (selectedNodeId) {
        focusContextItemClick();
      }
    );
  }
}

//Function to manage model tree related modifications
function ManageModeltree(hwv, ui) {
  //Toggle the visibility of body/product nodes in model tree.
  var modelTreeNodeVisibility = document.getElementById(
    "hide-model-tree-nodes"
  );
  modelTreeNodeVisibility.onclick = function ToggleModelTreeNodeVisibility() {
    if (toggleStateModelTreeNodes) {
      //Reset the model tree so that already opened body/product nodes get hided and tree comes to initial state
      // ui._modelBrowser._treeMap.get(0)._reset();
      toggleStateModelTreeNodes = false;
      //Change apperance of button text
      this.style.border = "groove";
    } else {
      toggleStateModelTreeNodes = true;
      this.style.border = "";
    }
  };

  //Update prototype of expandChildren method to manage the visibility of model tree nodes
  Communicator.Ui.Control.TreeControl.prototype._expandChildren = function (
    a,
    b
  ) {
    //If child nodes are body/product then dont allow expansion of child nodes
    // if (!toggleStateModelTreeNodes ) {
    // 	var nodeID = a.split("_")[1];
    // 		if(CheckNodeChildrenAsBody(nodeID)) {
    // 		//Disable or hide the expand div element for current node in tree for which expansion is blocked
    // 		var c = $("#" + a);
    // 		0 < c.length && (c.children(".ui-modeltree-container").children(".ui-modeltree-expandNode").hide());
    // 		return;
    // 		}
    // }
    //Original content of method as per HC 2020 (first release)
    var c = $("#" + a);
    if (a.indexOf("types_") >= 0) {
      var nodeIDArrays = [];
      AddLoadingSymbolToNode(a);
      setTimeout(function () {
        $(c)
          .find("li[id^='typespart_']")
          .each(function () {
            nodeIDArrays.push($(this).attr("id").split("_")[1]);
            var name = $(this).text();
          });

        changeTypeNames(nodeIDArrays, c, a);
      }, 50);
    }
    this.preloadChildrenIfNecessary(a);
    if (!this._freezeExpansion || b)
      0 < c.length &&
        (c.children(".ui-modeltree-children").show(),
        c
          .children(".ui-modeltree-container")
          .children(".ui-modeltree-expandNode")
          .addClass("expanded")),
        this._expandVisibilityChildren(a);
  };

  //Added the call back to model tree to post process the node names, as soon as they are added in tree
  // ui._modelBrowser._treeMap
  //   .get(0)
  //   ._tree.registerCallback("loadChildren", function (c) {
  //console.log("loadchildren " + c);
  //   ChangeModelTreeChildrenNodeName(c.split("_")[1], c);
  //   RemovePlusElementFmromNode(c.split("_")[1]);
  // });
}

async function changeTypeNames(nodeIDArrays, typeID, typeNodeID) {
  var allTreeTabNodesPropertiesMap = [];
  await collectallPropertiesAsync(nodeIDArrays, allTreeTabNodesPropertiesMap);
  typeID.find("li[id^='typespart_']").each(function () {
    var nodeID = $(this).attr("id").split("_")[1];
    if (
      Object.keys(allTreeTabNodesPropertiesMap).length > 0 &&
      allTreeTabNodesPropertiesMap[nodeID] !== undefined
    ) {
      var name = $(this).text();
      var typeName = allTreeTabNodesPropertiesMap[nodeID]["TYPE"];
      var objectRealName =
        allTreeTabNodesPropertiesMap[nodeID][typeName + "/Name"];
      typeTreeUpdated = true;
      if (name.indexOf("(" + objectRealName + ")") < 0) {
        $(this)
          .find(" > div > div")
          .each(function () {
            if ($(this).hasClass("ui-modeltree-label")) {
              $(this).text(name + " (" + objectRealName + ")");
            }
          });
      }
    }
  });
  setTimeout(function () {
    RemoveLoadingSymbolToNode(typeNodeID);
  }, 20);
}

//Add loading symbol to node
function AddLoadingSymbolToNode(nodeID) {
  if (nodeID == "part_-2") return;
  $("#" + nodeID)
    .find(" > div > div")
    .each(function () {
      if ($(this).hasClass("ui-modeltree-label")) {
        if (!$(this).children().hasClass("fa-spin")) {
          //Append the loading sybol icon to label text
          var labelLoadSymbol =
            " <i " +
            'id="loadsymbol_' +
            nodeID +
            '" ' +
            'class="fa fa-refresh fa-spin"></i>';
          $(this).append(labelLoadSymbol);
        }
      }
    });
}

//Add loading symbol to node
function RemoveLoadingSymbolToNode(nodeID) {
  $("#" + nodeID)
    .find(" > div > div")
    .each(function () {
      if ($(this).hasClass("ui-modeltree-label")) {
        //remove the loading sybol icon to label text
        $(this).find("i").remove();
      }
    });
}

async function collectallPropertiesAsync(nodeIDsArray, allNodesPropertiesMap) {
  let promiseArray = [];
  let nodeIDNameMap = {};
  for (var x in nodeIDsArray) {
    let promiseprop = hwv.model
      .getNodeProperties(Number(nodeIDsArray[x]))
      .catch((error) => {
        return error;
      });
    promiseArray.push(promiseprop);
  }
  var promiseResolveArray = await Promise.all(
    promiseArray.map((p) => p.catch((e) => e))
  );
  for (var x in nodeIDsArray) {
    if (
      promiseResolveArray[x] !== undefined &&
      promiseResolveArray[x] !== null
    ) {
      allNodesPropertiesMap[nodeIDsArray[x]] = promiseResolveArray[x];
    }
  }
}

//Hide the body/paent element
function HideItemFromModelBrowser(hwv, ui) {
  //Iterate all child element li with id starting with part_*
  $("#modelTree")
    .find("li[id^='part_']")
    .each(function () {
      var partEleID = $(this).attr("id");
      var thisLiEle = $(this);
      //Hide the body* and product* elements
      thisLiEle.find(" > div > div").each(function () {
        if ($(this).hasClass("ui-modeltree-label")) {
          var label = $(this).text(); // attribute title is also same as div text
          label = label.toLowerCase();
          if (label.indexOf("body") >= 0 || label.indexOf("product") >= 0) {
            //hide the visibility of current <li>
            thisLiEle.hide();
            //Hide the expand div of parent <li> element
            //var currentModelItemEle = thisLiEle.closest(".ui-modeltree-item");
            var parentModelItemEle = thisLiEle
              .parents(".ui-modeltree-item")
              .first();
            parentModelItemEle.find(" > div > div").each(function () {
              if ($(this).hasClass("ui-modeltree-expandNode")) {
                $(this).hide();
              }
            });
          }
        }
      });
    });
}

//Change the name of nodes created by HC as per the requirement
async function ChangeModelTreeChildrenNodeName(nodeID, a) {
  AddLoadingSymbolToNode(a);
  setTimeout(async function () {
    if (nodeID !== undefined && nodeID.indexOf("-") > 0) {
      nodeID = nodeID.split("-")[0];
    }
    var children = hwv.model.getNodeChildren(Number(nodeID));
    var childrenLength = children.length;
    //Get the file type untill we get a valid type. This need to be done as root node doesnt return valid type
    //We need to keep repeating , untill we get valid type
    fileType === 0 &&
      (fileType = hwv.model.getModelFileTypeFromNode(Number(nodeID)));

    if (fileType === Communicator.FileType.Ifc) {
      var treeTabNodesPropertiesMap = [];
      await collectallPropertiesAsync(children, treeTabNodesPropertiesMap);
      for (var index = 0; index < childrenLength; index++) {
        // var properties = await hwv.model.getNodeProperties(Number(children[index]));
        var properties = treeTabNodesPropertiesMap[Number(children[index])];
        //console.log(children[index] + " " + properties);
        var typeName = properties["TYPE"];
        if (typeName !== undefined) {
          var objectRealName = properties[typeName + "/Name"];
          var childNode = $("#part_" + children[index]);
          childNode.find(" > div > div").each(function () {
            if ($(this).hasClass("ui-modeltree-label")) {
              var name = hwv.model.getNodeName(Number(children[index]));
              name = name.toLowerCase();
              if (name.indexOf("product") < 0) {
                if (!CheckNodeAsBody(Number(children[index]))) {
                  $(this).text(typeName + "(" + objectRealName + ")");
                  $(this).attr("title", typeName + "(" + objectRealName + ")");
                }
              }
            }
          });
        }
      }
      setTimeout(function () {
        RemoveLoadingSymbolToNode(a);
      }, 20);
    } else if (fileType === Communicator.FileType.Revit) {
      for (var index = 0; index < childrenLength; index++) {
        var modifiedNodeName = "";
        //If node Id is leaf node, and its name is not "body*" or "product*"
        var childChildCount = hwv.model.getNodeChildren(
          Number(children[index])
        ).length;
        if (
          childChildCount === 0 &&
          !CheckNodeAsBody(Number(children[index]))
        ) {
          var nodeName = hwv.model.getNodeName(Number(children[index]));
          var parentName = hwv.model.getNodeName(
            hwv.model.getNodeParent(Number(children[index]))
          );
          modifiedNodeName = parentName + "(" + nodeName + ")";
        }

        // If node is immidiate parent of Product and body
        if (CheckNodeChildrenAsBody(Number(children[index]))) {
          //Get parent name
          var nodeName = hwv.model.getNodeName(Number(children[index]));
          var parentName = hwv.model.getNodeName(
            hwv.model.getNodeParent(Number(children[index]))
          );
          modifiedNodeName = parentName + "(" + nodeName + ")";
        }
        if (modifiedNodeName !== "") {
          var childNode = $("#part_" + children[index]);
          childNode.find(" > div > div").each(function () {
            if ($(this).hasClass("ui-modeltree-label")) {
              $(this).text(modifiedNodeName);
              $(this).attr("title", modifiedNodeName);
            }
          });
        }
      }
      setTimeout(function () {
        RemoveLoadingSymbolToNode(a);
      }, 20);
    }
  }, 20);
}

//Remove the "+" div element used for expansion, if its leaf node after hiding the "body*" or "product*" nodes
function RemovePlusElementFmromNode(nodeID) {
  //Get the childrens
  if (nodeID !== undefined && nodeID.indexOf("-") > 0) {
    nodeID = nodeID.split("-")[0];
  }

  var children = hwv.model.getNodeChildren(Number(nodeID));
  var childrenLength = children.length;
  //Iterate the childrens
  for (var index = 0; index < childrenLength; index++) {
    //check if this child node have children as "body*" or "product*",
    //if yes then remove "+" element from the child node
    if (CheckNodeChildrenAsBody(children[index])) {
      var childNode = $("#part_" + children[index]);
      childNode
        .children(".ui-modeltree-container")
        .children(".ui-modeltree-expandNode")
        .hide();
    }
  }
}

//Check if provided node have immediate children with name "body*" or "product*"
function CheckNodeChildrenAsBody(parentNodeID) {
  //Get child nodes
  var children = hwv.model.getNodeChildren(Number(parentNodeID));
  var childrenLength = children.length;
  // for (var index = 0; index < childrenLength; index++) {
  if (childrenLength > 0) {
    var nodeName = hwv.model.getNodeName(Number(children[0]));
    nodeName = nodeName.toLowerCase();
    if (nodeName.indexOf("product") >= 0) {
      var child1 = hwv.model.getNodeChildren(Number(children[0]));
      if (child1.length > 0) {
        var childnodeName1 = hwv.model.getNodeName(Number(child1[0]));
        if (childnodeName1.indexOf("body") < 0) {
          return false;
        }
      }
    }
    //check for name having string as "body*" or "product*"
    if (nodeName.indexOf("body") >= 0 || nodeName.indexOf("product") >= 0) {
      return true;
    } else {
      var child1 = hwv.model.getNodeChildren(Number(children[0]));
      if (child1.length > 0) return false;
    }
  }
  return false;
}

//Check if provided node is with name "body*" or "product*"
function CheckNodeAsBody(nodeID) {
  var nodeName = hwv.model.getNodeName(Number(nodeID));
  nodeName = nodeName.toLowerCase();
  //check for name having string as "body*" or "product*"
  if (nodeName.indexOf("body") >= 0 || nodeName.indexOf("product") >= 0) {
    return true;
  }
  return false;
}

async function isolateNodesEx(nodeArray, fitCamera) {
  //Get the file root nodes, so that the childrens of these file root nodes can be hide.
  var absoluteRootNode = hwv.model.getAbsoluteRootNode();
  var fileRootNodeArray = hwv.model.getNodeChildren(absoluteRootNode);

  //instead of hiding the absolute root Node, hide the children of file root node,
  //File root node visibility must not be affected due to "isolate" feature
  await hwv.model.setNodesVisibility(fileRootNodeArray, true);
  //hide the children
  for (var index = 0; index < fileRootNodeArray.length; index++) {
    var childrenNodeArray = hwv.model.getNodeChildren(fileRootNodeArray[index]);
    await hwv.model.setNodesVisibility(childrenNodeArray, false);
  }
  //show the selected nodes as part of isolation
  await hwv.model.setNodesVisibility(nodeArray, true);

  //Fit the view to nodes
  if (fitCamera) await hwv.view.fitNodes(nodeArray);
  //Clear the selection
  hwv.selectionManager.clear();
}
