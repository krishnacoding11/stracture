var Field = {};
Field.CustomOperators = {};
Field.CustomOperators.SelectionOperator = (function () {


  //override
  async function onMouseDown(event){
    if (!this._firstMouseDownTime) {
        this._firstMouseDownTime = Date.now();
        this._isDoubleClick = false;
    } else {
        if (Date.now() - this._firstMouseDownTime < this._doubleClickInterval) {
            this._isDoubleClick = true;
            this._firstMouseDownTime = null;
        } else {
            this._firstMouseDownTime = Date.now();
        }
    }

    if (this._isDoubleClick) {
        await this.onDoubleClick(event);
    } else {
        this._buttonModifierActive = this.checkMapping(event);
        if (this._buttonModifierActive) {
            const coords = event.getPosition();

            this._ptFirst.assign(coords);
            this._ptPrevious.assign(coords);
            this._ptCurrent.assign(coords);
        }
        this._dragging = true;
    }
}

  //override
  function onMouseUp(event) {
    //Disable Single Click Selection of nodes
    if (this.isActive()) {
      const pointDistance = Communicator.Point2.subtract(
        this._ptFirst,
        this._ptCurrent
      ).length();
      if (
        pointDistance < 5 &&
        (event.getButton() === this._selectionButton ||
          this._primaryTouchId !== null)
      ) {
        const view = this._viewer.view;

        let config = this._pickConfig;
        if (this._forceEffectiveSceneVisibilityMask !== null) {
          config = config.copy();
          config.forceEffectiveSceneVisibilityMask =
            this._forceEffectiveSceneVisibilityMask;
        }

        view.pickFromPoint(this._ptCurrent, config).then((selection) => {
          const cuttingManager = this._viewer.cuttingManager;
          const cuttingSelected =
            cuttingManager.getCuttingSectionFromNodeId(
              selection.getNodeId()
            ) !== null;
          const notePinSelected = this._noteTextManager.selectPin(selection);

          const pickedMarkup = this._viewer.markupManager.pickMarkupItem(
            this._ptCurrent
          );
          if (pickedMarkup instanceof Communicator.Markup.Redline.RedlineText) {
            this._viewer.markupManager.selectMarkup(pickedMarkup);
          }

          if (!notePinSelected && !cuttingSelected && pickedMarkup === null) {
            //if (selection.isNodeSelection()) {
            //    this._processSelectionClick(event, selection);
            //} else
            if (!this._isDoubleClick) {
              this._viewer.selectionManager.clear();
            }
          }
        });
      }
    }

    //super.onMouseUp(event);
  }

  //override
  async function onDoubleClick() {
    const view = this._viewer.view;

    let config = this._pickConfig;
    if (this._forceEffectiveSceneVisibilityMask !== null) {
      config = config.copy();
      config.forceEffectiveSceneVisibilityMask =
        this._forceEffectiveSceneVisibilityMask;
    }

    const selection  = await view.pickFromPoint(this._ptCurrent, config)
      const overlayIndex = selection.overlayIndex();
      if (overlayIndex !== 0 && overlayIndex !== null) {
        return;
      }

      if(!selection.getNodeId())
        return;

      const selectionManager = this._viewer.selectionManager;
      const item = selection;

      if(this._viewer.model.getNodeType(item.getNodeId()) === Communicator.NodeType.BodyInstance){
        const parentItem = Communicator.Selection.SelectionItem.create(this._viewer.model.getNodeParent(item.getNodeId()));
        
        if ((fileType === Communicator.FileType.Ifc) && (this._viewer.model.getNodeGenericId(parentItem.getNodeId()) === null)) {
          const actualParentItem = Communicator.Selection.SelectionItem.create(this._viewer.model.getNodeParent(parentItem.getNodeId()));
          selectionManager.set(actualParentItem);
        }
        else{
          selectionManager.set(parentItem);

        }
      }
      else  if ((fileType === Communicator.FileType.Ifc) && (this._viewer.model.getNodeGenericId(item.getNodeId()) === null)) {
        const actualParentItem = Communicator.Selection.SelectionItem.create(this._viewer.model.getNodeParent(item.getNodeId()));
        selectionManager.set(actualParentItem);
      }
      else{
        selectionManager.set(item);

      }

    
  }

  //Override
  Communicator.Operator.SelectionOperator.prototype.onMouseUp = onMouseUp;
  Communicator.Operator.SelectionOperator.prototype.onMouseDown = onMouseDown;
  Communicator.Operator.SelectionOperator.prototype.onDoubleClick = onDoubleClick;

})();
