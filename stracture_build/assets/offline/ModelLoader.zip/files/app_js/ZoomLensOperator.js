class ZoomLensOperator extends Communicator.Operator.OperatorBase {
  constructor(viewer) {
    super(viewer);
    this._glass = { x: 0, y: 0 };
    this._mouse = { x: 0, y: 0 };
    this._target = { x: 0, y: 0 };
    this._image = { x: 0, y: 0 };
    this._speed = 0.25;
    this._interval = 1000;
    this._startTimeStamp = Date.now();
    this._outerElement = document.querySelector("#glass");
    this._innerElement = document.querySelector("#glass-image");
    this._imageElement = null;
    this._zoomLevel = null;
    this._operatorActive = false;
    this._isActive = false;

  }

  setIsActive(active){
    this._isActive = active;
  }

  async updateImage() {
    this._imageElement = await this._viewer.takeSnapshot();
    this._imageElement.style.width = "100%";

    if (this._innerElement.childElementCount == 0) {
      this._innerElement.append(this._imageElement);
    } else {
      this._innerElement.replaceChild(
        this._imageElement,
        this._innerElement.children[this._innerElement.childElementCount - 1]
      );
    }
  }

  lerp(a, b, n) {
    return (1 - n) * a + b * n;
  }

  setZoomLevel() {}

  getTargetPoint() {
    let ret = this._target;
    this._target = {x : 0, y : 0};
    return ret;
    
  }

  async onActivate() {
    this._operatorActive = true;
  }

  onDeactivate() {}

  async onTouchMove(event) {
  

    if(this._isActive){

    //console.log("onTouchMove called");
    //this._viewer.pauseRendering();
    if (this._outerElement.style.display == "flex") {
      this._mouse.x = event.getPosition().x;
      this._mouse.y = event.getPosition().y;

      

      //For Smooth Movement
      this._glass.x = this._mouse.x//this.lerp(this._glass.x, this._mouse.x, this._speed);
      this._glass.y = this._mouse.y//this.lerp(this._glass.y, this._mouse.y, this._speed);

      //Calulate Image Position so that Mouse Position is alays at Center
      let boundingBox = document
        .querySelector("#content canvas")
        .getBoundingClientRect();

      //Convert to Percentage
      this._image.x =
        ((this._glass.x - boundingBox.left) / boundingBox.width) * -100;
      this._image.y =
        ((this._glass.y - boundingBox.top) / boundingBox.height) * -100;

      this._outerElement.style.transform = `translate(calc(${this._glass.x}px - 50%) ,calc(${this._glass.y}px - 100%))`;
      this._innerElement.style.transform = `translate(${this._image.x}%, ${this._image.y}%)`;

      this._target.x = this._glass.x;
      this._target.y = this._glass.y;
    }
    event.setHandled(true);
  }
  }

  async onTouchEnd(event) {

    if(event == null)
    {
      this._target.x = 0;
      this._target.y = 0;
    }

    console.log("onTouchEnd called");

    // this._viewer.resumeRendering();
    this._outerElement.style.display = "none";
    let outerElement = document.querySelector("#glass");
    outerElement.style.display = "none";
    if (event != null) event.setHandled(true);

  }

  async onTouchStart(event) {
    console.log("onTouchStart called");
    this.updateImage();
    


    this._glass = { x: event.getPosition().x, y: event.getPosition().y };
    this._mouse = { x: event.getPosition().x, y: event.getPosition().y };
    this._target = { x: 0, y: 0 };
    this._image = { x: event.getPosition().x, y: event.getPosition().y };

    this._mouse.x = event.getPosition().x;
    this._mouse.y = event.getPosition().y;

    this._glass.x = this._mouse.x
    this._glass.y = this._mouse.y

    let boundingBox = document
    .querySelector("#content canvas")
    .getBoundingClientRect();

  //Convert to Percentage
  this._image.x =
    ((this._glass.x - boundingBox.left) / boundingBox.width) * -100;
  this._image.y =
    ((this._glass.y - boundingBox.top) / boundingBox.height) * -100;

  this._outerElement.style.transform = `translate(calc(${this._glass.x}px - 50%) ,calc(${this._glass.y}px - 100%))`;
  this._innerElement.style.transform = `translate(${this._image.x}%, ${this._image.y}%)`;



    let op = nCircle.Ui.Toolbar.getActiveOperator();

    if (Date.now() - this._startTimeStamp > this._interval) {
    }
    if(this._isActive){
      this._target.x = this._mouse.x;
      this._target.y = this._mouse.y;
    this._outerElement.style.display = "flex";
    this._startTimeStamp = Date.now();
    let item = $("#glass");

    switch(getActiveOrientation())
    {
      case 'landscape':
        $("#glass").css({width : "15vw", height : "15vw"});
        break;
      case 'landscape-hybrid':
        $("#glass").css({width : "25vw", height : "25vw"});
        break;
      case 'portrait' :
        $("#glass").css({width : "15vw", height : "15vw"});
        break;
      case 'portrait-hybrid':
        $("#glass").css({width : "15vw", height : "15vw"});
        break;
    }
   
    //for(let i=0;i<25;++i)
    //  this.onTouchMove(event);

    setTimeout(() => {
     //console.log(op);
     if (nCircle.Ui.Toolbar.getActiveOperator() != op) {
       // zoomLensOperator.onTouchEnd(null);
       zoomLensOperator._target.x = 0;
       zoomLensOperator._target.y = 0;
     }
    }, 300);
  }
    event.setHandled(true);
  }
}


var bUpdateImage = false;

function getActiveOrientation(){

    let height = window.outerHeight;
    let width = window.outerWidth;

    //Landscape Hybrid Mode
    if((height < 800) && (width > 490 && width < 600) ){
      return 'landscape-hybrid'
    }
    //Portrait Hybrid Mode
    else if((height < 800) && (width < 900)){
      return 'portrait-hybrid'
    }
    else if((height < 800)){
      return 'landscape'
    }
    else {
      return 'portrait'
    }
}