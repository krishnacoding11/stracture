
nCircle.WebViewer = function () {

    var StatusCode = {
        SUCCESS: 0,
    }

    var bModelObjectAccesbile = false;
    var _rootNode = undefined;
    var _modelBounding = undefined;
    var _models = [];
    var _activeModels = 0;
    var _mostRecentError = null;
    var _errors = [];


    function createUserInteface() {
        let _screenConfiguration = Communicator.ScreenConfiguration.Mobile;

        let uiConfig = {
            containerId: "content",
            screenConfiguration: _screenConfiguration,
            showModelBrowser: false,
            showToolbar: false
        }

        ui = new Communicator.Ui.Desktop.DesktopUi(hwv, uiConfig);
        ui._contextMenu.hide();
    }

    function disableScroll() {
        document.body.addEventListener("touchmove", function (e) {
            if (e.target == document.getElementsByClassName("mobile")[0]) {
                e.preventDefault();
            }
        }, { useCapture: true, passive: false });

        document.body.addEventListener("touchstart", function (e) {
            if (e.target == document.getElementsByClassName("mobile")[0]) {
                e.preventDefault();
            }
        }, { useCapture: true, passive: false });

        document.body.addEventListener("touchend", function (e) {
            if (e.target == document.getElementsByClassName("mobile")[0]) {
                e.preventDefault();
            }
        }, { useCapture: true, passive: false });
    }

    function createViewer() {
        console.log("Create Viewer Called");
        hwv = new Communicator.WebViewer({
            containerId: "viewerContainer",
            empty: true,
            endpointUri: "wss://3dviewerqaak.asite.com/",
            model: _model,
            // streamingMode :Communicator.StreamingMode.Interactive,
            streamCutoffScale: 1.5,
            memoryLimit: 1500,
        });
    }


    async function loadModel(model) {
        let nodeId = undefined;
        try {
            nodeId = await hwv.model.loadSubtreeFromModel(_rootNode, model)
        }
        catch (error) {
            console.log("Error Loading Model : ",model);
            _setError('Error Loading Model ' + model);

            return false;
        }

        return true;
    }


    async function createRootNode(){
        try {
            _rootNode = await hwv.model.getAbsoluteRootNode();
            
        }
        catch (error) {
            console.log("Error Creating Root Node");
            _setError('Create Root Node Failed')
            return false;
        }

        return true;
    }


    async function loadFederatedModels(){

        let _failedModels = [];
        let _loadedModels = [];
        for(let i=0;i<_models.length; ++i){
            if(loadModel(model)){
                _loadedModels.push(model);
            }
            else{
                _failedModels.push(model);
            }
        }

        return {
            failedModels : _failedModels,
            loadedModels : _loadedModels,
        }
    }

    function _setError(error){
        _errors.push(error);
        _mostRecentError = error;
    }

    async function _init(){
        try {
            createViewer();
        }
        catch (error) {
            console.log(("Error Creating Webviewer"));
            _setError('Error Creating Viewer ');

        }

        createUserInteface();

        disableScroll();

        let bRootNodeCreated = await createRootNode();
                        if(bRootNodeCreated){
                            this.getModels();
                        }
    }

    return (() => {

               

        return {

            setModels: async function (models) {
                console.log(models);
                _models = models;
                let _data =  await loadFederatedModels();
                _activeModels = _data.loadedModels.length;

                //Model Loading Failure
                if(_data._failedModels.length){

                }
               
            },

            initModelLoading: async function () {

                _init();

            },

            getModels: function () {
                window.flutter_inappwebview.callHandler('getModels');
            },

            setError : function(error){
                _setError(error);
                
            }


        }
    })()

}()


window.onload = ()=>{
    nCircle.WebViewer.initModelLoading();
}