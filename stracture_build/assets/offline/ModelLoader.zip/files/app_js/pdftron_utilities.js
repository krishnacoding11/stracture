var filePath;
var isPDFLoaded = 0;
var currentFileName = "pdfPage";
var webViewerInstance = null;
var pdfTronCursorX = 0, pdfTronCursorY = 0;
var isControlKeyPressed = false;
var isCalibrationCancel = false;
var isCalibrationDone = false;
var removedMouseMove = false;
var polylineAnnotations = new Array();
var polygonAnnotations = new Array();
var polygonArrowMarkups = new Array();
let calibratedFilesArray =[];

var setPDFTronCursorPoint = function(x,y){
  pdfTronCursorX = x;
  pdfTronCursorY = y;
}


var initializeWebViewer = function() {
  WebViewer({
      path: "PDFTron-WebViewer/lib",
      preloadWorker: 'pdf',
      //initialDoc: "PDFTron-WebViewer/files/Hospital_00 Floor_1.pdf", //Hospital_2018 //Hospital_00 Floor_1.png //Hospital_00 Floor_1.pdf //Hospital_Elevation_East.pdf //Hospital_SectionAA.pdf
      //initialDoc: "PDFTron-WebViewer/files/01_Level 1_Office.pdf", //2018_Model_ALL //01_Level 1_Office.png 
      initialDoc: "PDFTron-WebViewer/files/02_Level-2_Apartment.pdf", //Apartment_A   //02_Level-2_Apartment.png   
      fullAPI: true,
      enableMeasurement: true,
      licenseKey: 'Insert commercial license key here after purchase',
      //pdftronServer: "http://localhost:49153",
      //webviewerServerURL : 'http://localhost:49153',
      //showLocalFilePicker: true,
      //licenseKey: "26A54FDD0437A80A73603E3AC992737860613FDDFF58BD3B95A545DA2A2CC9A07AD4B6F5C7",
      enableFilePicker: true,
    },
    document.getElementById("viewer")
  ).then((instance) => {
    webViewerInstance = instance;
    const { documentViewer, PDFNet, Annotations } = instance.Core;
    window.documentViewer = instance.Core.documentViewer;
    instance.UI.disableElement('measurementOverlay');
    const distanceMeasurementTool = documentViewer.getTool('AnnotationCreateDistanceMeasurement');
    distanceMeasurementTool.setStyles(() => ({
      StrokeThickness : [12, 'pt'],
      Color: new Annotations.Color(0, 205, 0),
      FillColor: new Annotations.Color(0, 205, 0),
      StrokeColor: new Annotations.Color(0, 205, 0),
    }));
    
    /*const fileInput = document.getElementById('selectFloor');
     fileInput.addEventListener('change', () => {
      // Get the file from the fileInput
      const file = fileInput.files[0];
      instance.UI.loadDocument(file, { filename: file.name });
      console.log(file.name);
    });  */

    registerOnLoadEventListener();
  });
}

var setPDFTronCursorPoint = function(x,y) {
  pdfTronCursorX = x;
  pdfTronCursorY = y;
}

var loadPDFFile = function() {
  const fileInput = document.getElementById('selectFloor');
  const file = fileInput.files[0];
  if(file != null)
  {
    webViewerInstance.UI.loadDocument(file, { filename: file.name });
    isPDFLoaded = 1;
    currentFileName = file.name.replace(/\.[^/.]+$/, "");
    fileInput.value = "";
  }
}

var flushMarkups = function() {
  const { annotationManager } = webViewerInstance.Core;
  const annots = annotationManager.getAnnotationsList();
  annotationManager.deleteAnnotations(annots);
}

var setDefaultOperator = function() {
  webViewerInstance.UI.setFitMode(webViewerInstance.UI.FitMode.FitWidth);
  webViewerInstance.UI.disableElements(["lineToolGroupButton"]);
  webViewerInstance.UI.setToolbarGroup(["toolbarGroup-View"]);
}

var getDocumentName = function() {
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  //console.log("Name :" + document.getFilename());
  return document.getFilename().replace(/\.[^/.]+$/, "");
}

var getPageWidth = function() {
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  //console.log("Width :" + document.getPageInfo(1).width);
  return document.getPageInfo(1).width;
}

var getPageHeight = function() {
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  //console.log("Height :" + document.getPageInfo(1).height);
  return document.getPageInfo(1).height;
}

var getPageRotation = function() {
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  return document.getPageRotation(1);
}

var setPDFFilePath = function(path) {
  /*Most browsers will give you only the file name, but there are exceptions like IE8 which will give you a fake path like:
  "C:\fakepath\myfile.ext" and older versions (IE <= 6) which actually will give you the full client file-system path (due its lack of security).*/
  filePath = path; 
}

var saveImageFromPDF = async function() {
  const {PDFNet} = webViewerInstance.Core;
  //var pdfDoc = await PDFNet.PDFDoc.createFromURL("PDFTron-WebViewer/files/Hospital_00 Floor_1.pdf"); 
  //GET http://localhost:11180/PDFTron-WebViewer/lib/ui/PDFTron-WebViewer/files/Hospital_00%20Floor_1.pdf 404 (Not Found)
  //var pdfDoc = await PDFNet.PDFDoc.createFromURL("D:\\Vijay.Shinde\\Asite\\Sample Files\\From Client\\DEMO_APARTMENT_RVT_IFC_PDF_DWG\\REV-2\\DRAWINGS\\FLOOR PLANS\\02_Level-2_Apartment.pdf"); 
  //PDFNet.js:1072 Not allowed to load local resource: file:///D:/Vijay.Shinde/Asite/Sample%20Files/From%20Client/DEMO_APARTMENT_RVT_IFC_PDF_DWG/REV-2/DRAWINGS/FLOOR%20PLANS/02_Level-2_Apartment.pdf
  //var pdfDoc = await PDFNet.PDFDoc.createFromURL(filePath);
  var pdfDoc = await PDFNet.PDFDoc.createFromURL("..\\..\\files/Hospital_00 Floor_1.pdf");
  const pdfDraw = await PDFNet.PDFDraw.create(92);
  const iterator = await pdfDoc.getPageIterator(1);
  const currentPage = await iterator.current();
  //pdfDraw.setDPI(900); 
  const pngBuffer = await pdfDraw.exportStream(currentPage, 'PNG');
  const pngFile = new Blob([pngBuffer.buffer], { type: 'image/png' }); 
  //await saveAs(pngFile, '..\\..\\files\\pdfPage.png');
  await saveAs(pngFile, 'pdfPage.png');//Need user interaction to select folder to save file in
  //pdfDraw.Export(currentPage, "..\\..\\files\\pdfPage.png", "PNG");
}

var exportImageFromCurrentPage = async function() {  
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  const pdfDoc = await document.getPDFDoc();
  const pdfDraw = await PDFNet.PDFDraw.create(92);
  const iterator = await pdfDoc.getPageIterator(1);
  const currentPage = await iterator.current();
  const pngBuffer = await pdfDraw.exportStream(currentPage, 'PNG');
  const pngFile = new Blob([pngBuffer.buffer], { type: 'image/png' });
  pdfDraw.setDPI(900); 
  await saveAs(pngFile, currentFileName + ".png");
}

var saveImageBufferFromCurrentPage = async function() {  
  const {documentViewer, PDFNet} = webViewerInstance.Core;
  const document = documentViewer.getDocument();
  const pdfDoc = await document.getPDFDoc();
  const pdfDraw = await PDFNet.PDFDraw.create(92);
  const iterator = await pdfDoc.getPageIterator(1);
  const currentPage = await iterator.current();
  return await pdfDraw.exportStream(currentPage, 'PNG');
}

var savePdf = function() {
  const options = {
    filename: 'myDocument.pdf',
    flags: webViewerInstance.Core.SaveOptions.LINEARIZED,
    downloadType: 'pdf'
  };  
  webViewerInstance.UI.downloadPdf(options);
}

var saveImageFromPDFArea = async function() {
  console.log("saveImageFromPDFArea");
  //const { documentViewer } = webViewerInstance.Core;
  //const doc = documentViewer.getDocument();
  //const page1 = 1;
  //doc.rotatePages([page1], webViewerInstance.Core.PageRotation.E_270);
  //documentViewer.refreshAll();
  //documentViewer.updateView();
  webViewerInstance.Core.documentViewer.getDocument().loadCanvasAsync({
    pageNumber : 1,
    //pageRotation : webViewerInstance.Core.PageRotation.E_270,
    //renderRect: new webViewerInstance.Core.PDFNet.Rect(546.79 ,1005.69,1097.39,1707.98),
    //renderRect: new webViewerInstance.Core.PDFNet.Rect(716,599,1353,1049),
    renderRect: new webViewerInstance.Core.PDFNet.Rect(1445.39,780.22,2073.09,2411.06),
    drawComplete: async (canvas, index) => {
      // The 'canvas' would be the cropped area of the page.
      // You can use 'toBlob' or 'toDataURl' extra the data from the canvas
      var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); // replace to avoid DOM exception
      window.location.href=image;
    }
  });
}

var saveImage = async function() {
  console.log("saveImage1");
  const doc = webViewerInstance.Core.documentViewer.getDocument();
  const pageNumber = 1;
  const zoom = 1; // render at twice the resolution
  doc.loadCanvasAsync({
    pageNumber,
    zoom,
    //renderRect: new webViewerInstance.Core.PDFNet.Rect(778.08,991.01,1488.51,1695.47),
    //renderRect: new webViewerInstance.Core.PDFNet.Rect(1465.58,820.19,2123.26,2341.35),
    //renderRect: {x1:778.08, y1:1002.95, x2:1476.57, y2:1701.44}, // The area to render
    //renderRect: { x1:1476.57, y1:1713.38, x2:2121.32, y2:2346.2},
    renderRect: { x1:298, y1:512, x2:550, y2:746}, //X1,Y1 should be less than X2,Y2 else pop up for save image won't be displayed
    drawComplete: async (thumbnail) => {
      //const corePageRotation = (doc.getPageRotation(pageNumber) / 90) % 4;
      //annotationManager.setAnnotationCanvasTransform(thumbnail.getContext('2d'), zoom, corePageRotation);
      // optionally comment out "drawAnnotations" below to exclude annotations
      //await webViewerInstance.Core.documentViewer.getAnnotationManager().drawAnnotations(pageNumber, thumbnail);
      // thumbnail is a HTMLCanvasElement or HTMLImageElement
      console.log(thumbnail);
      var image = thumbnail.toDataURL("image/png").replace("image/png", "image/octet-stream"); // replace to avoid DOM exception
      window.location.href=image;
    }
  });
}

var cropImage = async() => {
  webViewerInstance.setToolMode('CropPage');
  const applyCrop = webViewerInstance.Core.Tools.CropCreateTool.prototype.applyCrop;
  webViewerInstance.Core.Tools.CropCreateTool.prototype.applyCrop = function (e) {
    const annotation = webViewerInstance.Core.annotationManager.getAnnotationsList().find(annotation => annotation.ToolName === "CropPage")
    // get the positions of the crop that was added to extract information from
    const cropRect = annotation.getRect();
    webViewerInstance.Core.documentViewer.getDocument().loadCanvasAsync({
      pageNumber : annotation.PageNumber,
      renderRect: annotation.getRect(),
      drawComplete: async (canvas, index) => {
        // The 'canvas' would be the cropped area of the page.
        // You can use 'toBlob' or 'toDataURl' extra the data from the canvas
        var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); // replace to avoid DOM exception
        window.location.href=image;
      }
    });
    applyCrop.apply(this, arguments);
  };
}

//For Flutter app
var update2DMarkupArrow = function(){
  try {
    //console.log("UPDATE 2D MARKUP ARROW");
    if (calibration2D3D.isCalibrationPefromed == 0) {
      //console.log("2D markup isn't updated as Calibration operation isn't performed yet");
      return;
    }
    let position2D = calibration2D3D.get2DPointFrom3DPoint(hwv.view.getCamera().getPosition());
    setPDFTronCursorPoint(position2D.x,position2D.y);
    const navAngle = getNavigationAngle();
    let ptsAtOrigin = rotateNavigationCoordinates(navAngle);
    const p0 = new Communicator.Point3(ptsAtOrigin[0][0] + pdfTronCursorX, ptsAtOrigin[0][1] + pdfTronCursorY, 0);
    const p1 = new Communicator.Point3(ptsAtOrigin[1][0] + pdfTronCursorX, ptsAtOrigin[1][1] + pdfTronCursorY, 0);
    const p2 = new Communicator.Point3(ptsAtOrigin[2][0] + pdfTronCursorX, ptsAtOrigin[2][1] + pdfTronCursorY, 0);
    const p3 = new Communicator.Point3(ptsAtOrigin[3][0] + pdfTronCursorX, ptsAtOrigin[3][1] + pdfTronCursorY, 0);
   
    window.flutter_inappwebview.callHandler('getCalibrationPoints',p0.x + "  " + p0.y + "  " + p1.x + "  " + p1.y + "  "+ p2.x + "  " + p2.y + "  " + p3.x + "  " + p3.y)
                
    // Print.postMessage(p0.x + "  " + p0.y + "  " + p1.x + "  " + p1.y + "  "+ p2.x + "  " + p2.y + "  " + p3.x + "  " + p3.y);
  } 
  catch (e) {
    console.log(e.message);
  }     
}

//For POC
/* var update2DMarkupArrow = function(){
  try {
    console.log("UPDATE 2D MARKUP ARROW");
    if (calibration2D3D.isCalibrationPefromed == 0) {
      //console.log("2D markup isn't updated as Calibration operation isn't performed yet");
      return;
    }
    const { documentViewer, annotationManager, Annotations } = webViewerInstance.Core; 
    let position2D = calibration2D3D.get2DPointFrom3DPoint(hwv.view.getCamera().getPosition());
    setPDFTronCursorPoint(position2D.x,position2D.y);
    const navAngle = getNavigationAngle();
    let ptsAtOrigin = rotateNavigationCoordinates(navAngle);
    var polygonAnnotation = new Annotations.PolygonAnnotation({
      FillColor: new Annotations.Color(0, 205, 0),
      // PageNumber: 1,
      ToolName: 'update2DMarkupArrow',
    });
    polygonAnnotation.setRect(200,200,200,200);
    polygonAnnotation.disableRotationControl();
    polygonAnnotation.NoResize = true;
    polygonAnnotation.addPathPoint(ptsAtOrigin[0][0] + pdfTronCursorX, ptsAtOrigin[0][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[1][0] + pdfTronCursorX, ptsAtOrigin[1][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[2][0] + pdfTronCursorX, ptsAtOrigin[2][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[3][0] + pdfTronCursorX, ptsAtOrigin[3][1] + pdfTronCursorY);
    annotationManager.updateAnnotation(polygonAnnotation);
    annotationManager.redrawAnnotation(polygonAnnotation);
    documentViewer.refreshAll();
    documentViewer.updateView();
  } 
  catch (e) {
    console.log(e.message);
  }     
} */



var update2DMarkupArrowAtGivenPosition = function(position2D) {
  try {
    if (calibration2D3D.isCalibrationPefromed == 0) {
      //console.log("2D markup isn't updated as Calibration operation isn't performed yet");
      return;
    }
    const { documentViewer, annotationManager, Annotations } = webViewerInstance.Core;
    setPDFTronCursorPoint(position2D.x,position2D.y);
    const navAngle = getNavigationAngle();
    let ptsAtOrigin = rotateNavigationCoordinates(navAngle);
    var polygonAnnotation = new Annotations.PolygonAnnotation({
      FillColor: new Annotations.Color(0, 205, 0)
    });
    polygonAnnotation.addPathPoint(ptsAtOrigin[0][0] + pdfTronCursorX, ptsAtOrigin[0][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[1][0] + pdfTronCursorX, ptsAtOrigin[1][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[2][0] + pdfTronCursorX, ptsAtOrigin[2][1] + pdfTronCursorY);
    polygonAnnotation.addPathPoint(ptsAtOrigin[3][0] + pdfTronCursorX, ptsAtOrigin[3][1] + pdfTronCursorY);
    annotationManager.updateAnnotation(polygonAnnotation);
    annotationManager.redrawAnnotation(polygonAnnotation);
    documentViewer.refreshAll();
    documentViewer.updateView();
  } 
  catch (e) {
    console.log(e.message);
  }  
}

var addPolygonAnnotation = function([positions]) {
  try {
    if (calibration2D3D.isCalibrationPefromed == 0) {
      return;
    }
    //console.log("addPolygonAnnotation1");
    const { documentViewer, annotationManager, Annotations, PDFNet } = webViewerInstance.Core;
    var polygonAnnotation = new Annotations.PolygonAnnotation({
      FillColor: new Annotations.Color(255, 255, 0),
      Opacity : 0.6,
      ToolName: "addPolygonAnnotation",
    });

	  const solidBorderStyle = PDFNet.AnnotBorderStyle.create(PDFNet.AnnotBorderStyle.Style.e_solid, 4, 0, 0);
    solidBorderStyle.StrokeThickness = [12 ,'pt'];
    polygonAnnotation.setBorderStyle(solidBorderStyle);
    //polygonAnnotation.borderStyle = Annot.BorderStyle(Annot.BorderStyle.e_solid, 2, 0, 0)
    let length = positions.length;
    //console.log("length : "+length);
    //console.log("polygon");
    for (let i = 0; i < length; i++) {
      polygonAnnotation.addPathPoint(positions[i].x, positions[i].y);
      //console.log(positions[i].x + "," + positions[i].y);
    }
    annotationManager.addAnnotation(polygonAnnotation);
    annotationManager.redrawAnnotation(polygonAnnotation);
    documentViewer.refreshAll();
    documentViewer.updateView();
    //console.log("addPolygonAnnotation2");
  } 
  catch (e) {
    console.log(e.message);
  }  
}

var addPolylineAnnotation = function([positions]) { 
  try {
    if (calibration2D3D.isCalibrationPefromed == 0) {
      return;
    }
    const { annotationManager, Annotations } = webViewerInstance.Core;
    var polylineAnnotation = new Annotations.PolylineAnnotation({
      Color: new Annotations.Color(0, 205, 0),
      PageNumber: 1,
    });
    let length = positions.length;
    //console.log("polyline");
    for (let i = 0; i < length; i++) {
      //console.log(positions[i].x + "," + positions[i].y);
      polylineAnnotation.addPathPoint(positions[i].x, positions[i].y);
    }
    annotationManager.addAnnotation(polylineAnnotation);
    annotationManager.redrawAnnotation(polylineAnnotation);
    documentViewer.refreshAll();
    documentViewer.updateView();
  }
  catch (e) {
    console.log(e.message);
  }
}

var sleep = function(ms) {
  return new Promise(
    resolve => setTimeout(resolve, ms)
  );
}

var addPolygonAnnotation = function([positions]){
  try {
    if (calibration2D3D.isCalibrationPefromed == 0) {
      return;
    }
    let length = positions.length;
    console.log("length : "+length);
    for (let i = 0; i < length; i++) {
      console.log("Before 3D point" + positions[i].x + " " + positions[i].y);
      const p0 = new Communicator.Point3(positions[i].x, positions[i].y, 0);
      //Print.postMessage("addPolygonAnnotation" + "  " + p0.x + "  " + p0.y);
      console.log("After 3D point" + p0.x + " " + p0.y);
    }
  } 
  catch (e) {
    console.log(e.message);
  }  
}

var updateMultipleAnnotation = function() {
  const { annotationManager } = webViewerInstance.Core;
  annotationManager.addEventListener(
    "annotationChanged",
    (annotations, action) => {
      if (action === "add") {
        if (annotations[0].ToolName == "AnnotationCreateLine") {
          annotationManager.deleteAnnotations(annotations);
        }
        if (annotations[0].Subject == "Polyline") {
          polylineAnnotations.push(annotations);
        }
        if (polylineAnnotations.length > 3 && polylineAnnotations.length % 2 == 0 && isControlKeyPressed == false) {
          const polygonCount = polylineAnnotations.length / 2;
          for (var index = 0; index < polygonCount - 1; index++) {
            annotationManager.deleteAnnotations(polylineAnnotations[0]);
            annotationManager.deleteAnnotations(polylineAnnotations[1]);
            polylineAnnotations.shift();
            polylineAnnotations.shift();
          }
        }

        if(annotations[0].ToolName == "addPolygonAnnotation"){
          polygonAnnotations.push(annotations);
        }
        if (polygonAnnotations.length > 3 && polygonAnnotations.length % 2 == 0 && isControlKeyPressed == false) {
          const polygonCount = polygonAnnotations.length / 2;
          for (var index = 0; index < polygonCount - 1; index++) {
            annotationManager.deleteAnnotations(polygonAnnotations[0]);
            annotationManager.deleteAnnotations(polygonAnnotations[1]);
            polygonAnnotations.shift();
            polygonAnnotations.shift();
          }
        }

        if(annotations[0].ToolName == "update2DMarkupArrow"){
          polygonArrowMarkups.push(annotations);
        }
        if (polygonArrowMarkups.length > 3) {
            annotationManager.deleteAnnotations(polygonArrowMarkups[0]);
            annotationManager.deleteAnnotations(polygonArrowMarkups[1]);
            polygonArrowMarkups.shift();
            polygonArrowMarkups.shift();
        }
      }
    }
  );
}

var getMouseLocation = function(e) {
  const scrollElement = documentViewer.getScrollViewElement();
  const scrollLeft = scrollElement.scrollLeft || 0;
  const scrollTop = scrollElement.scrollTop || 0;
  return {
    x: e.pageX + scrollLeft,
    y: e.pageY + scrollTop,
  };
}

var mouseToPagePoint = function(e) {
  const displayMode = documentViewer.getDisplayModeManager().getDisplayMode();
  const windowPoint = getMouseLocation(e);
  const page = displayMode.getSelectedPages(windowPoint, windowPoint);
  const pageNumber = page.first !== null ? page.first : documentViewer.getCurrentPage();
  return {
    point: displayMode.windowToPage(windowPoint, pageNumber),
    pageNumber,
  };
}

var registerEventListener = function() {
  const { Annotations, documentViewer, annotationManager } = webViewerInstance.Core;
  documentViewer.addEventListener("pageComplete", () => {
    const lineAnnot = new Annotations.LineAnnotation({
      Color: new Annotations.Color(0, 205, 0),
      FillColor: new Annotations.Color(0, 205, 0),
      StrokeColor: new Annotations.Color(0, 205, 0),
      StrokeThickness: [1, "pt"],
      Listable: "true",
      ToolName: "AnnotationCreateArrow",
    });
    lineAnnot.disableRotationControl();
  
    var mouseClicked = false;
    //var annotationID = annot.Id;
    //const source = document.getElementById(annotationID);
    //source.addEventListener('drag', (event) => {console.log("dragging");}); 
  
    documentViewer.addEventListener("mouseLeftDown", (e) => {
      e.preventDefault();
      mouseClicked = true;
      const annot = annotationManager.getAnnotationByMouseEvent(e);
      annotationManager.selectAnnotations(annot);
      documentViewer.addEventListener("mouseMove", (e) => {
        if (!isCalibrationCancel && isCalibrationDone && mouseClicked) {
          e.preventDefault();
          const result = mouseToPagePoint(e);
          const pagePoint = result.point;
          var point2D = new Communicator.Point3(pagePoint.x, pagePoint.y, 0);
          var point3D = calibration2D3D.get3DPointFrom2DPoint(point2D);
          updateCamera(hwv, point3D);
        }
      });
    });

    documentViewer.addEventListener("mouseLeftUp", (e) => {
      mouseClicked = false;
    });
  
    // documentViewer.addEventListener("mouseMove", (e) =>  {
    //   const annot = annotationManager.getAnnotationByMouseEvent(e);
    //   annotationManager.selectAnnotations(annot);
    //   if (!isCalibrationCancel && isCalibrationDone && mouseClicked) {
    //     const result = mouseToPagePoint(e);
    //     const pagePoint = result.point;
    //     var point2D = new Communicator.Point3(pagePoint.x, pagePoint.y,0);
    //     var point3D = calibration2D3D.get3DPointFrom2DPoint(point2D);
    //     updateCamera(hwv, point3D);
    //     }
    //   }
    // );    
    
    let noOfClicks = 0;
    var collectionOfPageCoordinates = new Array();
    documentViewer.addEventListener("zoomUpdated", (zoom) => {
      // noOfClicks = 0;
      // collectionOfPageCoordinates = new Array();
    });
  
    documentViewer.addEventListener("mouseLeftDown", (e) => {
      if (isCalibrated) {
        const result = mouseToPagePoint(e);
        const pagePoint = result.point;
        const pageNumber = result.pageNumber;
        const oldPageNumber = lineAnnot.PageNumber;
        lineAnnot.PageNumber = pageNumber;
        e.preventDefault();
        if (e.which === 1) {
          collectionOfPageCoordinates.push(pagePoint.x);
          collectionOfPageCoordinates.push(pagePoint.y);
          noOfClicks++;
        }
        documentViewer.snapToNearest(pageNumber,collectionOfPageCoordinates[0],collectionOfPageCoordinates[1],documentViewer.snapMode) .then((snapPoint) => {
            const circleAnnot = new Annotations.EllipseAnnotation({
              Color: new Annotations.Color(0, 205, 0),
              FillColor: new Annotations.Color(0, 205, 0),
              X: snapPoint.x - 2,
              Y: snapPoint.y - 2,
              Width: 4,
              Height: 4,
            });
            annotationManager.updateAnnotation(circleAnnot);
            annotationManager.redrawAnnotation(circleAnnot);
          });
          if (noOfClicks == 2) {
            documentViewer.snapToNearest(pageNumber,collectionOfPageCoordinates[0],collectionOfPageCoordinates[1],documentViewer.snapMode) .then((snapPoint) => {
                lineAnnot.setStartPoint(snapPoint.x, snapPoint.y);
                lineAnnot.setStartStyle(Annotations.LineEndType.CIRCLE);
                var startPoint = new Communicator.Point3( snapPoint.x, snapPoint.y, 1 );
                calibration2D3D.calibrationStartPointPDFTron = startPoint;
            });
            documentViewer .snapToNearest( pageNumber, collectionOfPageCoordinates[2], collectionOfPageCoordinates[3], documentViewer.snapMode )
            .then((snapPoint) => {
                lineAnnot.setEndPoint(snapPoint.x, snapPoint.y);
                lineAnnot.setEndStyle(Annotations.LineEndType.CLOSED_ARROW);
                var endPoint = new Communicator.Point3(snapPoint.x, snapPoint.y, 1);
                calibration2D3D.calibrationEndPointPDFTron = endPoint;
            });
            calibration2D3D.map3DPointTo2D();
            update2DMarkupArrow();
            annotationManager.addAnnotation(lineAnnot);
            annotationManager.redrawAnnotation(lineAnnot);
            noOfClicks = 0;
            collectionOfPageCoordinates = new Array();
          }
        }
    });
  });
}

var registerOnLoadEventListener = function() {
  const { documentViewer, PDFNet, Annotations } = webViewerInstance.Core;
  documentViewer.addEventListener('annotationsLoaded',()=>{
    const {LINE_INTERSECTION, LINE_MID_POINT ,PATH_ENDPOINT, POINT_ON_LINE} = webViewerInstance.Tools.SnapModes
    const toolnames = Object.values(webViewerInstance.Tools.ToolNames).filter(
      (name) =>
        name.includes("CreateDistanceMeasurement") ||
        name.includes("CreatePerimeterMeasurement") ||
        name.includes("CreateArcMeasurement") ||
        name.includes("CreateAreaMeasurement") ||
        name.includes("CreateRectangularAreaMeasurement") ||
        name.includes("CreateLine") ||
        name.includes("CreatePolygon")
    );
    toolnames.forEach((toolName) => {
      const tool = documentViewer.getTool(toolName);
      tool.setSnapMode(LINE_INTERSECTION | LINE_MID_POINT | PATH_ENDPOINT | POINT_ON_LINE);
    });
  })

  documentViewer.addEventListener("documentLoaded", async () => {
    //console.log(getDocumentName());
    // license key for iOS and android
    //await PDFNet.initialize("Asite Solutions Limited(asite.com):OEM:Adoddle::IA+:AMS(20220328):26A54FDD0437A80A73603E3AC992737860613FDDFF58BD3B95A545DA2A2CC9A07AD4B6F5C7");
    await PDFNet.initialize();
    const doc = documentViewer.getDocument();
    const pdfDoc = await doc.getPDFDoc();
    await pdfDoc.requirePage(1);
    await PDFNet.runWithCleanup(async () => calibratePDFTron(false));
    //await PDFNet.runWithCleanup(async () => await saveImage1());
    webViewerInstance.UI.setToolbarGroup(["toolbarGroup-View"]);

    // Double click event
    var oldDoubleClick = webViewerInstance.Core.Tools.Tool.prototype.mouseDoubleClick;
    webViewerInstance.Core.Tools.Tool.prototype.mouseDoubleClick = function(e) {
    oldDoubleClick.call(this, e);
    if(!isCalibrationCancel){
      var pageCoordinate = this.pageCoordinates[0];
      var point2D = new Communicator.Point3(pageCoordinate.x, pageCoordinate.y,0);
      var point3D = calibration2D3D.get3DPointFrom2DPoint(point2D);
      updateCamera(hwv, point3D);
    }
  };

  // const panMouseDown = instance.Core.Tools.PanTool.prototype.mouseLeftDown;
  // instance.Core.Tools.PanTool.prototype.mouseLeftDown = function () {
  //   panMouseDown.apply(this, arguments);
  //   //instance.UI.setToolMode(Tools.ToolNames.ELLIPSE);
  //     const annot = new Annotations.RectangleAnnotation({
  //       X: arguments[0].data.pageCoordinate.x,
  //       Y: arguments[0].data.pageCoordinate.y,
  //       Width: 50,
  //       Height: 50,
  //       FillColor: new Annotations.Color(0, 128, 0), 
  //     });
  //     //instance.Core.annotationManager.updateAnnotation(annot);
  //     //instance.Core.annotationManager.redrawAnnotation(annot);

  //   /* console.log(
  //     "X =",
  //     arguments[0].data.pageCoordinate.x + " " + "Y =",
  //     arguments[0].data.pageCoordinate.y
  //   ); */
  // };   

  documentViewer.refreshAll();
  documentViewer.updateView();
  webViewerInstance.UI.setToolbarGroup(["toolbarGroup-View"]);

  currentFileName = doc.getFilename().replace(/\.[^/.]+$/, "");
  if(isPDFLoaded == 1)
  {
    exportImageFromCurrentPage();
    overlay.updateOverlay();
    isPDFLoaded = 0;
  }  
  });
}