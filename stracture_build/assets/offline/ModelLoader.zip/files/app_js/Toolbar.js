
nCircle.Ui = (function () {
  var Toolbar = (function () {
    var _viewer = null;
    var _cuttingPlaneController = null;
    var _noteTextManager = null;
    var _activeOperator = Communicator.OperatorId.Select;
    var _toggleStateForModelColors = false;
    var _modelBounding = null;
    var _bCuttingPlaneToggle = false;
    var _redlineItems = new Set();

    var pinchZoomMultipliers = [
      0.5, 0.75, 1, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75,
    ];
    var panMultipliers = [
      0.01, 0.025, 0.05, 0.1, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85,
    ];

    var walkMultipliers = [
      0.000390625,
      0.00078125,
      0.0015625 * 0.65,
      0.0015625 * 0.85,
      0.0015625,
      0.003125 * 0.65,
      0.003125 * 0.85,
      0.003125,
      0.00625 * 0.65,
      0.00625 * 0.85,
      0.00625,
    ];

    var CuttingSectionIndex = {
      X: 0,
      Y: 1,
      Z: 2,
      Face: 3,
      CadView: 4,
    };

    function _getAxis(planeAxis) {
      switch (planeAxis) {
        case "x":
          return CuttingSectionIndex.X;
        case "y":
          return CuttingSectionIndex.Y;
        case "z":
          return CuttingSectionIndex.Z;
        case "face":
          return CuttingSectionIndex.Face;
        default:
          return null;
      }
    }

    function _resetMarkups() {
      if (!_viewer) _viewer = hwv.view._viewer;

      var measureMarkupArray = _viewer.measureManager.getAllMeasurements();
      //Iterate all markups to identify selected pin markup.
      for (var index = 0; index < measureMarkupArray.length; index++) {
        if (measureMarkupArray[index].getName() !== "Pin")
          _viewer.measureManager.removeMeasurement(measureMarkupArray[index]);
        else measureMarkupArray[index].setVisibility(false);
      }

      _viewer.model.setNodesOpacity([_viewer.model.getAbsoluteRootNode()], 1);
      _viewer.model.setNodesVisibility(
        [_viewer.model.getAbsoluteRootNode()],
        true
      );
      //_viewer.model.resetNodesColor();

      _transparentNodeMap = [];
      _isolateNodesArray = [];
      _focusNodesArray = [];
    }

    function _setDefaultOperator() {
      _viewer.operatorManager.set(Communicator.OperatorId.Select, 1);
      _activeOperator = Communicator.OperatorId.Select;
      //if (hwv) { console.log("refresh"); hwv.view.setCamera(hwv.view.getCamera()) }
    }

    return {
      setCamera: function (camera) {
        if (camera != null) _cam = camera;
      },

      cuttingPlane: async function (action) {
        // _setDefaultOperator();
        if (!_cuttingPlaneController) {
          _cuttingPlaneController = ui._cuttingPlaneController;
          _cuttingPlaneController._modelBoundingMgr._modelBounding =
            await hwv.model.getModelBounding();
        }
        const axis = _getAxis(action);
        if (axis !== null) _cuttingPlaneController.toggle(axis);
        else if (action === "section")
          _cuttingPlaneController.toggleReferenceGeometry();
        else if (action === "toggle") {
          _cuttingPlaneController.toggleCuttingMode();
          if (!_bCuttingPlaneToggle) _bCuttingPlaneToggle = true;
          else _bCuttingPlaneToggle = false;
        } else if (action === "reset") {
          if (_bCuttingPlaneToggle) {
            _cuttingPlaneController.toggleCuttingMode();
            _bCuttingPlaneToggle = false;
          }
          _cuttingPlaneController.resetCuttingPlanes();
          _setDefaultOperator();
        }
      },

      reset: function () {
        if (!_viewer) _viewer = hwv.view._viewer;

        window.dispatchEvent(new CustomEvent("pinReset"));


        _resetMarkups();
        _setDefaultOperator();
        hwv.operatorManager
          .getOperator(Communicator.OperatorId.CustomTextOperatorEx)
          .clear();

        if (hwv) {
          //console.log("refresh");
          hwv.view.setCamera(hwv.view.getCamera());
        }
        ContextMenu.reset();
        //ContextMenu.resetColors();
        hwv.selectionManager.clear();
        hwv.model.resetModelHighlight();
      },

      home: async function () {
        if (!_viewer) _viewer = hwv.view._viewer;

        if (!_modelBounding)
          _modelBounding = await _viewer.model.getModelBounding(
            false,
            false,
            false
          );

        initialize_hoops_camera(hwv);

        window.dispatchEvent(new CustomEvent("pinReady"));


        if (!_viewer.sheetManager.isDrawingSheetActive()) {
          if (!_noteTextManager) _noteTextManager = _viewer.noteTextManager;

          _noteTextManager.setIsolateActive(false);
          _noteTextManager.updatePinVisibility();
        
        }

        const walkOp = hwv.view._viewer.operatorManager.getOperator(
          Communicator.OperatorId.Walk
        );

        walkOp._tilt = 12.0;
      },

      measurement: async function (action) {
        hwv.selectionManager.clear();
        hwv.model.resetModelHighlight();

        if (!_viewer) _viewer = hwv.view._viewer;

        //_viewer.operatorManager.set(zoomLensOperatorHandle, 1);

        //return;
        // zoomLensOperator.onTouchEnd(null);
        zoomLensOperator.updateImage();
        if (action == "angle")
          if (_activeOperator === measureAngleOperatorHandle) {
            _setDefaultOperator();
            //zoomLensOperator.onTouchEnd(null);
          } else {
            _viewer.operatorManager.set(measureAngleOperatorHandle, 1);
            _activeOperator = measureAngleOperatorHandle;
          }
        else if (action == "area")
          if (_activeOperator === markupAreaMeasureHandle) {
            _setDefaultOperator();
            //zoomLensOperator.onTouchEnd(null);
          } else {
            _viewer.operatorManager.set(markupAreaMeasureHandle, 1);
            _activeOperator = markupAreaMeasureHandle;
          }
        else if (action == "distance")
          if (
            _activeOperator ===
            Communicator.OperatorId.MeasurePointPointDistance
          ) {
            _setDefaultOperator();
            //zoomLensOperator.onTouchEnd(null);
          } else {
            _viewer.operatorManager.set(
              Communicator.OperatorId.MeasurePointPointDistance,
              1
            );
            _activeOperator = Communicator.OperatorId.MeasurePointPointDistance;
          }

        //zoomLensOperator.onTouchEnd(null);
      },

      markup: function (action) {
        hwv.selectionManager.clear();
        hwv.model.resetModelHighlight();

        if (!_viewer) _viewer = hwv.view._viewer;

        if (action == "redlineText") {
          if (_activeOperator === Communicator.OperatorId.CustomTextOperatorEx)
            _setDefaultOperator();
          else {
            _viewer.operatorManager.set(
              Communicator.OperatorId.CustomTextOperatorEx,
              1
            );
            _activeOperator = Communicator.OperatorId.CustomTextOperatorEx;
          }
        } else if (action == "redlineFreehand")
          if (_activeOperator === Communicator.OperatorId.RedlinePolyline)
            _setDefaultOperator();
          else {
            _viewer.operatorManager.set(
              Communicator.OperatorId.RedlinePolyline,
              1
            );
            _activeOperator = Communicator.OperatorId.RedlinePolyline;
            //hwv.markupManager._renderer._clear();
            //if (hwv) { console.log("refresh"); hwv.view.setCamera(hwv.view.getCamera()) }
          }
        else if (action == "clear") {
          _setDefaultOperator();

          hwv.operatorManager
            .getOperator(Communicator.OperatorId.CustomTextOperatorEx)
            .clear();

          if (hwv) {
            //console.log("refresh");
            hwv.view.setCamera(hwv.view.getCamera());
          }
        }
      },

      color: function () {
        _toggleStateForModelColors = !_toggleStateForModelColors;
        ContextMenu.toggleColors("color");
      },
      getColorState: function () {
        return _toggleStateForModelColors;
      },

      addRedlineItem: function (id) {
        _redlineItems.add(id);
      },
      getActiveOperator: function () {
        return _activeOperator;
      },

      isMeasurementOperatorsActive: function () {
        let activeOp = Toolbar.getActiveOperator();
        if (
          activeOp == measureAngleOperatorHandle ||
          activeOp == markupAreaMeasureHandle ||
          activeOp == Communicator.OperatorId.MeasurePointPointDistance
        )
          return true;

        return false;
      },
      onLongpressTouchEnd: function () {
        document
          .getElementById("panUp")
          .dispatchEvent(new TouchEvent("touchend"));
        document
          .getElementById("panDown")
          .dispatchEvent(new TouchEvent("touchend"));

        document
          .getElementById("stick1")
          .dispatchEvent(new TouchEvent("touchend"));

        document
          .getElementById("stick2")
          .dispatchEvent(new TouchEvent("touchend"));

        if (this.isMeasurementOperatorsActive()) {
          zoomLensOperator.setIsActive(false);
          //zoomLensOperator.onTouchEnd(new Communicator.Event.TouchInputEvent());
          //call active mesureoperator onTouchEnd to place points
          hwv.operatorManager
            .getOperator(this.getActiveOperator())
            .onTouchEnd(new Communicator.Event.TouchInputEvent());
        }
      },
      joystick: function () {
        Joystick.toggle();
      },

      setNavcubeSize: function (size) {
        let t = hwv.view.getNavCube();
        t._fieldSize = size;
        t.setAnchor(3);
      },

      setNavcubePosition: function (x, y) {
        if (!hwv) return;

        let t = hwv.view.getNavCube();
        t._position.x = x;
        t._position.y = y;
        t.setAnchor(3);
      },

      setAreaMeasurmentUnit: (unit) => {
        AreaUnitForMeasurement = areaUnitType[unit];
        SetDesiredUnitToMarkups(hwv);
        hwv.redraw();
      },
      setAngleMeasurementUnit: (unit) => {
        AngleUnitForMeasurement = angleUnitType[unit];
        SetDesiredUnitToMarkups(hwv);
        hwv.redraw();
      },
      setDistanceMeasurementUnit: (unit) => {
        desiredUnitForMeasurement = unitType[unit];
        SetDesiredUnitToMarkups(hwv);
        hwv.redraw();
      },
      setMeasurementPrecision: (precision) => {
        measureValueForPrecision = measureValuePrecision[precision];
        SetDesiredUnitToMarkups(hwv);
        hwv.redraw();
      },
      setNavigationMultiplier: (index) => {
        if (index != undefined && index > 0 && index <= 10) {
          hwv.operatorManager.getOperator(
            Communicator.OperatorId.custZoomOpId
          )._pinchZoomMultiplier = pinchZoomMultipliers[index - 1];
          hwv.operatorManager.getOperator(
            Communicator.OperatorId.custZoomOpId
          )._panMultiplier = panMultipliers[index];
          Joystick.setNavigationMultiplier(walkMultipliers[index]);
        }
        return;
      },
    };
  })();

  var ContextMenu = (function () {
    var prevLongpressPos = null;
    var _ctxMenu = null;
    //Map to reperesent the nodes which are made transparent, "value" used in pairs added is dummy , we just need node Ids as "Key". Map is used, since its easy to delete item from map than array
    var _transparentNodeMap = {};
    //Temporary Map to reperesent the nodes which are made transparent,  when a viewpoint is activate
    var _transparentNodeTempMap = {};
    //Array to represents the nodes selected for "isolate"
    var _isolateNodesArray = [];
    //Array to represents the nodes selected for "Focus"
    var _focusNodesArray = [];
    //Temporary array to repesetnt the nodes selected for "Focus" when a viewpoint is activate
    var _focusNodesTempArray = [];

    var _isViewPointActive = false;
    var _nodeIDVsGenericIDMap = {};
    var _nodeIDVsColorMap = {};

    Communicator.Ui.RightClickContextMenu.prototype.showElements =
      function () {};

    function toggleColorsusingselectedNodeIDs() {
      let _toggleStateForModelColors = Toolbar.getColorState();

      if (_toggleStateForModelColors) {
        for (var key in _nodeIDVsColorMap) {
          var nodeID = [];
          nodeID.push(+key);
          try {
            hwv.model.setNodesFaceColor(nodeID, _nodeIDVsColorMap[nodeID]);
          } catch (e) {
            delete _nodeIDVsColorMap[nodeID];
          }
        }
        _toggleStateForModelColors = false;
      } else {
        for (var key in _nodeIDVsColorMap) {
          var nodeID = [];
          nodeID.push(+key);
          try {
            hwv.model.unsetNodesFaceColor(nodeID);
          } catch (e) {
            delete _nodeIDVsColorMap[nodeID];
          }
        }
        _toggleStateForModelColors = true;
      }
    }

    async function _isolateNodesEx(nodeArray, fitCamera) {
      //Get the file root nodes, so that the childrens of these file root nodes can be hide.
      var absoluteRootNode = hwv.model.getAbsoluteRootNode();
      var fileRootNodeArray = hwv.model.getNodeChildren(absoluteRootNode);

      //instead of hiding the absolute root Node, hide the children of file root node,
      //File root node visibility must not be affected due to "isolate" feature
      await hwv.model.setNodesVisibility(fileRootNodeArray, true);
      //hide the children
      for (var index = 0; index < fileRootNodeArray.length; index++) {
        var childrenNodeArray = hwv.model.getNodeChildren(
          fileRootNodeArray[index]
        );
        await hwv.model.setNodesVisibility(childrenNodeArray, false);
      }
      //show the selected nodes as part of isolation
      await hwv.model.setNodesVisibility(nodeArray, true);

      //Fit the view to nodes
      if (fitCamera) await hwv.view.fitNodes(nodeArray);
      //Clear the selection
      hwv.selectionManager.clear();
    }

    async function handleIsolateNode() {
      var selectionSet = hwv.getSelectionManager().getResults();
      //Collect all node IDs
      _isolateNodesArray = [];
      for (var index = 0; index < selectionSet.length; index++) {
        //Add nodes to global array
        _isolateNodesArray.push(selectionSet[index].getNodeId());
      }

      //Isolate the nodes
      hwv.model.setNodesOpacity(_isolateNodesArray, 1);
      await _isolateNodesEx(_isolateNodesArray, true);
      //Check if node selected for isolate are also part of transparent, if yes then make them transparent
      for (var index = 0; index < _focusNodesArray.length; index++) {
        if (_transparentNodeMap.hasOwnProperty(_focusNodesArray[index])) {
          hwv.model.setNodesOpacity([_focusNodesArray[index]], 0.5);
        }
      }

      //deselect the nodes after isolate
      hwv.getSelectionManager().clear();
      //Clear the "focus" data (if any)
      _focusNodesArray = [];
    }

    async function handleFocus() {
      var selectionSet = hwv.getSelectionManager().getResults();

      //Refer the appropriate focus array
      var sourceFocusArr = null;
      if (_isViewPointActive) sourceFocusArr = _focusNodesTempArray;
      else sourceFocusArr = _focusNodesArray;

      for (var index = 0; index < selectionSet.length; index++) {
        //Add nodes to global array
        sourceFocusArr.push(selectionSet[index].getNodeId());
      }
      //Set visibilty of entire model as true first, we need entire model to visible with transparency

      hwv.model.setNodesOpacity([hwv.model.getAbsoluteRootNode()], 0.1);
      hwv.model.setNodesOpacity(sourceFocusArr, 1);
      //Check if node selected for focus are also part of transparent, if yes then make them transparent
      for (var index = 0; index < sourceFocusArr.length; index++) {
        //Refer the appropriate transparent map
        var sourceTransparencyMap = null;
        if (_isViewPointActive) sourceTransparencyMap = _transparentNodeTempMap;
        else sourceTransparencyMap = _transparentNodeMap;
        if (sourceTransparencyMap.hasOwnProperty(sourceFocusArr[index])) {
          hwv.model.setNodesOpacity([sourceFocusArr[index]], 0.5);
        }
      }
      //deselect the nodes after isolate
      hwv.getSelectionManager().clear();
      //Clear the "Isolate" data (if any)
      _isolateNodesArray = [];
    }

    function objectColorSuccess(data, map) {
      if (data && data.length) {
        _nodeIDVsColorMap = {};
        hwv.model.resetNodesColor();

        for (var i = 0, dataLength = data.length; i < dataLength; i++) {
          var d = data[i];
          var rgbColor = hexToRgb(d.color);
          var nodeId;
          var currentColor = new Communicator.Color(
            rgbColor.r,
            rgbColor.g,
            rgbColor.b
          ); //Fill the maps
          if (fileType === Communicator.FileType.Ifc) {
            nodeId = hwv.model.getNodeIdsByGenericIds([d.uniqueId])[0];
          } else {
            nodeId = getNodeIdFromOldNodeId(d.uniqueId);
          }
          console.log(`nodeId = ${nodeId}`);
          if (nodeId) {
            if (map) {
              if (fileType === Communicator.FileType.Ifc && map[d.uniqueId]) {
                var nIds = map[d.uniqueId];
                if (nIds && nIds.indexOf(nodeId) > -1) {
                  for (
                    var j = 0, nIdsLength = nIds.length;
                    j < nIdsLength;
                    j++
                  ) {
                    _nodeIDVsColorMap[nIds[j]] = currentColor;
                  }
                }
              } else {
                for (var gid in map) {
                  if (Object.hasOwnProperty.call(map, gid)) {
                    var nIds = map[gid];
                    if (nIds && nIds.indexOf(nodeId) > -1) {
                      for (
                        var j = 0, nIdsLength = nIds.length;
                        j < nIdsLength;
                        j++
                      ) {
                        _nodeIDVsColorMap[nIds[j]] = currentColor;
                      }
                      break;
                    }
                  }
                }
              }
            } else {
              _nodeIDVsColorMap[nodeId] = currentColor;
            }
          }
        }
        if (Toolbar.getColorState())
          for (var key in _nodeIDVsColorMap) {
            hwv.model.setNodesFaceColor([+key], _nodeIDVsColorMap[key]);
          }
      }
    }

    function handleAssignColor(color) {
      let selectionMgr = hwv.getSelectionManager();
      let rootNodeID = hwv.model.getAbsoluteRootNode();
      let nodeSelectionitems = selectionMgr.getResults();
      for (
        var selectionItems = nodeSelectionitems, index = 0;
        index < selectionItems.length;
        index++
      ) {
        let nodeId = [];
        nodeId.push(selectionItems[index].getNodeId());
        _nodeIDVsColorMap[nodeId] = color;
        //Set the node face color if "Model color" button is highlighted
        if (Toolbar.getColorState()) hwv.model.setNodesFaceColor(nodeId, color);

        if (fileType === Communicator.FileType.Revit) {
          let parentNodeName = hwv.model.getNodeName(nodeId);
          hwv.model.getNodesBounding([nodeId]).then(function (promiseBB) {
            let bobString = bbStringForm(promiseBB.max, promiseBB.min);
            _nodeIDVsGenericIDMap[nodeId] = parentNodeName + "_" + bobString;
          });
        } else if (fileType === Communicator.FileType.Ifc) {
          let genericID = hwv.model.getNodeGenericId(nodeId);
          if (genericID === null) {
            genericID = hwv.model.getNodeGenericId(
              hwv.model.getNodeParent(nodeId)
            );
          }
          _nodeIDVsGenericIDMap[nodeId] = genericID;
        }

        let hexColor = rgb2Hex(
          Number(color.r),
          Number(color.g),
          Number(color.b)
        );
        let uniqueId;

        if (fileType === Communicator.FileType.Ifc) {
          uniqueId = hwv.model.getNodeGenericId(nodeId[0]);
          if (uniqueId === null) {
            uniqueId = hwv.model.getNodeGenericId(
              hwv.model.getNodeParent(nodeId[0])
            );
          }
        } else {
          uniqueId = getNodeIdWithRevStr(nodeId[0]);
        }

        let colorObject = {
          color: hexColor,
          guid: uniqueId,
        };

        window.flutter_inappwebview.callHandler(
          "saveBimObjectColor",
          JSON.stringify(colorObject)
        );
      }
    }

    function handleRemoveColor() {
      var selectionMgr = hwv.getSelectionManager();
      var rootNodeID = hwv.model.getAbsoluteRootNode();
      var nodeSelectionitems = selectionMgr.getResults();
      for (
        var selectionItems = nodeSelectionitems, index = 0;
        index < selectionItems.length;
        index++
      ) {
        var nodeId = [];

        nodeId.push(selectionItems[index].getNodeId());
        // nodeId.push(selectionItems[index].getNodeId());
        //UnSet the node face color if "Model color" button is highlighted
        // if (Toolbar.getColorState() === false)
        hwv.model.unsetNodesFaceColor(nodeId);

        delete _nodeIDVsColorMap[nodeId];
        delete _nodeIDVsGenericIDMap[nodeId];

        let uniqueId;

        if (fileType === Communicator.FileType.Ifc) {
          uniqueId = hwv.model.getNodeGenericId(nodeId[0]);

          if (uniqueId === null) {
            uniqueId = hwv.model.getNodeGenericId(
              hwv.model.getNodeParent(nodeId[0])
            );
          }
        } else {
          uniqueId = getNodeIdWithRevStr(nodeId[0]);
        }

        let colorObject = {
          color: null,
          guid: uniqueId,
        };

        window.flutter_inappwebview.callHandler(
          "removeBimObjectColor",
          JSON.stringify(colorObject)
        );
      }
    }

    async function handleCreateForm(){
      PinManager.enablePinOperator();
      const event = new Communicator.Event.TouchInputEvent();

      if(!prevLongpressPos)
        throw Error("prevLongpressPos null | undefined");

      event._position = prevLongpressPos;
      event._buttons = 0;

      if(!PinManager)
        throw Error("PinManager null | undefined");

      PinManager.getPinOperator().onTouchStart(event);
      PinManager.getPinOperator().onTouchEnd(event);

    }

    async function handleFileAssoc() {
      var selectionSet = hwv.getSelectionManager().getResults();
      var guid;
      var nodeId = selectionSet[0].getNodeId();

      if (fileType === Communicator.FileType.Ifc) {
        guid = hwv.model.getNodeGenericId(nodeId);
        if (guid === null) {
          guid = hwv.model.getNodeGenericId(hwv.model.getNodeParent(nodeId));
        }
      } else {
        const nodeData = await hwv.model.getNodeProperties(nodeId);
        guid =
          nodeData &&
          ((nodeData.persistentId && nodeData.persistentId.trim()) ||
            (nodeData.GlobalId && nodeData.GlobalId.trim()));
      }

      const revisionId = getRevisionIdFromNodeId(nodeId);

      const bimObjectIdStr = "" + guid + "," + revisionId;
      console.log(bimObjectIdStr);

      window.flutter_inappwebview.callHandler("getBimObjectId", bimObjectIdStr);
    }

    // Do not save if model color button is disabled
    // This button will be disabled when BCF viewpoint is activated

    async function handleTransparency() {
      //Get the selection set
      var selectionSet = hwv.getSelectionManager().getResults();
      //Refer the appropriate transparent map
      var _sourceTransparencyMap = null;
      if (isViewPointActive) _sourceTransparencyMap = _transparentNodeTempMap;
      else _sourceTransparencyMap = _transparentNodeMap;

      for (var index = 0; index < selectionSet.length; index++) {
        var selectedNode = selectionSet[index].getNodeId();

        //Check the node with the global map used for transparent nodes
        if (_sourceTransparencyMap.hasOwnProperty(selectedNode)) {
          //Remove the transparency for node
          let nodeArray = [];
          nodeArray.push(selectedNode);
          hwv.model.resetNodesOpacity(nodeArray);
          //Remove the node from map, since transparency for node is removed
          delete _sourceTransparencyMap[selectedNode];
        } else {
          //Set the transparency
          let nodeArray = [];
          nodeArray.push(selectedNode);
          hwv.model.setNodesOpacity(nodeArray, 0.5);
          //Add entry of transparent node in map
          _sourceTransparencyMap[selectedNode] = 1;
        }
      }
    }

    async function handleViewObjectDetails() {
      var selectionSet = hwv.getSelectionManager().getResults();

      var nodeId = selectionSet[0].getNodeId();

      let properties = await hwv.model.getNodeProperties(nodeId);

      var objectDetailsSelctionArray = [];
      var objectDetailsSelctionObj = {
        Other: {
          "section-name": "Other",
          property: [],
        },
      };

      Object.keys(properties).forEach((key) => {
        if (key.indexOf("/") != -1) {
          var groupName = key.split("/")[0];
          var suffix = "";
          if (
            groupName.indexOf("MATERIAL") === 0 ||
            groupName.indexOf("MATERIALLAYER") === 0
          ) {
            suffix = " [" + groupName + "]";
            groupName = "Materials";
          }
          if (!objectDetailsSelctionObj[groupName]) {
            objectDetailsSelctionObj[groupName] = {
              "section-name": groupName,
              property: [],
            };
          }
          objectDetailsSelctionObj[groupName]["property"].push({
            "property-name": key.split("/")[1] + suffix,
            "property-value": properties[key],
          });
        } else {
          objectDetailsSelctionObj["Other"]["property"].push({
            "property-name": key,
            "property-value": properties[key],
          });
        }
      });

      if (objectDetailsSelctionObj.Other.property.length) {
        objectDetailsSelctionArray.push(objectDetailsSelctionObj.Other);
      }
      delete objectDetailsSelctionObj.Other;
      var typeObject, styleObject, parentObject;

      Object.keys(objectDetailsSelctionObj).forEach(function (key) {
        if (
          objectDetailsSelctionObj[key]["section-name"].indexOf("IFC") === 0
        ) {
          objectDetailsSelctionObj[key]["section-name"] =
            objectDetailsSelctionObj[key]["section-name"].replace("IFC", "");
        }

        var isStyleObject = false;
        if (
          objectDetailsSelctionObj[key]["section-name"].indexOf("STYLE") > -1 ||
          objectDetailsSelctionObj[key]["section-name"].indexOf("TYPE") > -1
        ) {
          var suffix = "STYLE";
          if (
            objectDetailsSelctionObj[key]["section-name"].indexOf("TYPE") > -1
          ) {
            suffix = "TYPE";
          }
          var split =
            objectDetailsSelctionObj[key]["section-name"].split(suffix);
          if (split[split.length - 1] === "") {
            isStyleObject = true;
            objectDetailsSelctionObj[key]["section-name"] =
              objectDetailsSelctionObj[key]["section-name"].substring(
                0,
                objectDetailsSelctionObj[key]["section-name"].lastIndexOf(
                  suffix
                )
              );
            objectDetailsSelctionObj[key]["section-name"] =
              objectDetailsSelctionObj[key]["section-name"] + " (Type)";
          }
        }
        if (parent && parent === key) {
          parentObject = objectDetailsSelctionObj[key];
        }
        // else if (nodeType === key) {
        // 	typeObject = objectDetailsSelctionObj[key];
        // }
        else if (isStyleObject) {
          styleObject = objectDetailsSelctionObj[key];
        } else {
          objectDetailsSelctionArray.push(objectDetailsSelctionObj[key]);
        }
      });
      objectDetailsSelctionObj = {};
      objectDetailsSelctionArray.sort(function (a, b) {
        var nameA = a["section-name"].toUpperCase(); // ignore upper and lowercase
        var nameB = b["section-name"].toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }

        // names must be equal
        return 0;
      });
      styleObject && objectDetailsSelctionArray.unshift(styleObject);
      typeObject && objectDetailsSelctionArray.unshift(typeObject);

      window.flutter_inappwebview.callHandler(
        "getObjectDetails",
        JSON.stringify({ details: objectDetailsSelctionArray })
      );
    }

    return {
      handle: async function (cords, action) {
        if (_ctxMenu == null) _ctxMenu = ui._contextMenu;

        _ctxMenu.hide();

        //NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin

        const selection = hwv.selectionManager.getLast();//_longpressSelection; //hwv.selectionManager.getFirst(); //_longpressSelection;

        // if (!selection) return;

        if (
          selection &&
          selection.getSelectionType() == Communicator.SelectionType.None
        )
          return;

        //hwv.selectionManager.set(selection);

        // let selection = hwv.selectionManager.getFirst();
        if (selection != null) {
          //hwv.selectionManager.set(selection);

          if (action == "transparent") handleTransparency();
          // _ctxMenu.action('transparent');
          else if (action == "isolate") handleIsolateNode();
          else if (action == "focus") handleFocus();
          else if (action.search("setColor") != -1) {
            let _color = action.split(",");
            handleAssignColor(
              new Communicator.Color(_color[1], _color[2], _color[3])
            );
          } else if (action == "detail") {
            handleViewObjectDetails();
          } else if (action == "removeColor") {
            handleRemoveColor();
          } else if (action == "assocFile") {
            handleFileAssoc();
          }
          else if(action == "createForm"){
            handleCreateForm();
          }

          //hwv.getSelectionManager().clear();
          _longpressSelection = null;
          hwv.model.resetModelHighlight();
          hwv.selectionManager.clear();
        }
      },

      setLongpressPositiion : function(position){
        prevLongpressPos = position;
      },

      toggleColors: function () {
        toggleColorsusingselectedNodeIDs();
      },

      reset: function () {
        _transparentNodeMap = {};
        //Temporary Map to reperesent the nodes which are made transparent,  when a viewpoint is activate
        _transparentNodeTempMap = {};
        //Array to represents the nodes selected for "isolate"
        _isolateNodesArray = [];
        //Array to represents the nodes selected for "Focus"
        _focusNodesArray = [];
        //Temporary array to repesetnt the nodes selected for "Focus" when a viewpoint is activate
        _focusNodesTempArray = [];

        //_nodeIDVsColorMap = {};

        // zoomLensOperator.onTouchEnd(null);
      },

      clearLongpressSelection: function () {
        _longpressSelection = null;
        hwv.selectionManager.clear();
      },

      setLongpressSelection: function (selection) {
        _longpressSelection = selection;
      },

      getBimObjectColor(colorObject) {
        response = colorObject;
        var responseArray = colorObject; //.split("%");
        console.log(responseArray);
        //responseArray.pop();
        console.log(responseArray);

        for (let i = 0; i < responseArray.length; ++i)
          //responseArray[i] = JSON.parse(responseArray[i]);
          console.log(
            ` color :  ${responseArray[i].color}, uniqueId : ${responseArray[i].uniqueId}`
          );

        objectColorSuccess(responseArray);
      },

      getBimObjectColorStatus: function () {
        let selectionMgr = hwv.getSelectionManager();
        let nodeSelectionitems = selectionMgr.getResults();
        for (
          var selectionItems = nodeSelectionitems, index = 0;
          index < selectionItems.length;
          index++
        ) {
          let nodeId = [];
          nodeId.push(selectionItems[index].getNodeId());

          if (_nodeIDVsColorMap[nodeId]) {
            const color = _nodeIDVsColorMap[nodeId];
            console.log(
              rgb2Hex(Number(color.r), Number(color.g), Number(color.b))
            );
            window.flutter_inappwebview.callHandler(
              "getBimObjectColorStatus",
              rgb2Hex(Number(color.r), Number(color.g), Number(color.b))
            );
          } else {
            const parentId = [hwv.model.getNodeParent(nodeId[0])];
            console.log(`parentId : ${parentId}`);
            if (_nodeIDVsColorMap[parentId]) {
              const color = _nodeIDVsColorMap[parentId];
              console.log(
                rgb2Hex(Number(color.r), Number(color.g), Number(color.b))
              );
              window.flutter_inappwebview.callHandler(
                "getBimObjectColorStatus",
                rgb2Hex(Number(color.r), Number(color.g), Number(color.b))
              );
            } else {
              window.flutter_inappwebview.callHandler(
                "getBimObjectColorStatus",
                ""
              );
            }
          }
        }
      },
    };
  })();

  var Joystick = (function () {
    var dragStatus = false;
    var walkDistance = 200;
    var walkDiv = "#viewer-walkpanel-dialog";
    var lookDiv = "#viewer-lookpanel-dialog";
    var bInitialized = false;
    var _walkJoystick = null;
    var _lookJoystick = null;
    var panUpTimer = null;
    var panDownTimer = null;
    var rotationDegreeAngle = 0.5;
    var _currentDistance = 0;
    var _maxWalkSpeed = 100;
    var _maxElevationSpeed = 100;
    var _minWalkSpeed = 100;
    var bHidden = true;
    var lastPanUpTouchStartTime = Date.now();
    var lastPanDownTouchStartTime = Date.now();
    var _currentView = {
      orientation: "Orientation.portrait",
      view: "3D",
      device: "Tablet",
    };
    var _deviceType = null;
    var _isIos = false;
    var eventCount = 0;
    var speedMultiplier = 300;

    var JoystickController = function (stickID, _maxDistance, deadzone) {
      // stickID: ID of HTML element (representing joystick) that will be dragged
      // _maxDistance: maximum amount joystick can move in any direction
      // deadzone: joystick must move at least this amount from origin to register value change

      var _id = stickID;
      var _stick = document.getElementById(stickID);
      var _maxDistance = _maxDistance;
      var _deadzone = deadzone;
      // location from which drag begins, used to calculate offsets
      var _dragStart = null;

      // track touch identifier in case multiple joysticks present
      var _touchId = null;

      var _active = false;
      var _value = { x: 0, y: 0 };

      let self = this;

      function handleDown(event) {
        _active = true;
        eventCount = 0;
        // all drag movements are instantaneous
        _stick.style.transition = "0s";

        // touch event fired before mouse event; prevent redundant mouse event from firing
        //event.preventDefault();
        //dragStatus = true;

        if (event.changedTouches)
          _dragStart = {
            x: event.changedTouches[0].clientX,
            y: event.changedTouches[0].clientY,
          };
        else _dragStart = { x: event.clientX, y: event.clientY };

        // if this is a touch event, keep track of which one
        if (event.changedTouches) _touchId = event.changedTouches[0].identifier;

        // event.stopPropogation();
      }

      function handleMove(event) {
        if (!_active) return;
        ++eventCount;

        // if this is a touch event, make sure it is the right one
        // also handle multiple simultaneous touchmove events
        let touchmoveId = null;
        dragStatus = true;

        if (event.changedTouches) {
          for (let i = 0; i < event.changedTouches.length; i++) {
            if (_touchId == event.changedTouches[i].identifier) {
              touchmoveId = i;
              event.clientX = event.changedTouches[i].clientX;
              event.clientY = event.changedTouches[i].clientY;
            }
          }

          if (touchmoveId == null) return;
        }

        const xDiff = event.clientX - _dragStart.x;
        const yDiff = event.clientY - _dragStart.y;
        const angle = Math.atan2(yDiff, xDiff);
        const distance = Math.min(_maxDistance, Math.hypot(xDiff, yDiff));
        const xPosition = distance * Math.cos(angle);
        const yPosition = distance * Math.sin(angle);

        // move _stick image to new position
        _stick.style.transform = `translate3d(${xPosition}px, ${yPosition}px, 0px)`;

        // _deadzone adjustment
        const distance2 =
          distance < _deadzone
            ? 0
            : (_maxDistance / (_maxDistance - _deadzone)) *
              (distance - _deadzone);
        const xPosition2 = distance2 * Math.cos(angle);
        const yPosition2 = distance2 * Math.sin(angle);
        const xPercent = parseFloat((xPosition2 / _maxDistance).toFixed(4));
        const yPercent = parseFloat((yPosition2 / _maxDistance).toFixed(4));
        _currentDistance = distance2;
        _value = { x: xPercent, y: yPercent };
      }

      function handleUp(event) {
        if (!_active) return;
        eventCount = 0;

        // transition the joystick position back to center
        _stick.style.transition = ".2s";
        _stick.style.transform = `translate3d(0px, 0px, 0px)`;

        // reset everything
        _value = { x: 0, y: 0 };
        _touchId = null;
        _active = false;

        dragStatus = false;
        //event.stopPropogation();
      }

      _stick.addEventListener("touchstart", handleDown, { passive: true });
      _stick.addEventListener("touchmove", handleMove, { passive: true });
      _stick.addEventListener("touchend", handleUp, { passive: true });

      return {
        getMaxDistance: function () {
          return _maxDistance;
        },
        getCurrentDistance: function () {
          return _currentDistance;
        },
        getX: function () {
          return _value.x;
        },
        getY: function () {
          return _value.y;
        },
      };
    };

    function _updateWalk(x, y) {
      var walkOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );

      //lerp between max and min speed
      let _walkSpeed = _maxWalkSpeed;
      //Upper Quadrant
      if (x < -0.35 && y > -0.46 && y < 0.46) {
        if (dragStatus) {
          console.log(`x : ${x}, y : ${y}, left`);
          walkOperator.walkLeft(_walkSpeed);
        }
      } else if (x > 0.35 && y > -0.46 && y < 0.46) {
        if (dragStatus) {
          console.log(`x : ${x}, y : ${y}, right`);
          walkOperator.walkRight(_walkSpeed);
        }
      } else if (y < 0) {
        //Upper Left
        if (x > -0.9 && x < -0.45 && y < -0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, left-up`);
            walkOperator.walkForward(_walkSpeed);
            walkOperator.walkLeft(_walkSpeed);
          }
        }
        //Up
        else if (x > -0.45 && x < 0.45 && y < -0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, up`);
            walkOperator.walkForward(_walkSpeed);
          }
        }
        //Upper Right
        else if (x > 0.45 && x < 0.9 && y < -0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, right-down`);
            walkOperator.walkForward(_walkSpeed);
            walkOperator.walkRight(_walkSpeed);
          }
        }
      }
      //Lower Quadrant
      else if (y > 0) {
        //Lower Left
        if (x > -0.9 && x < -0.45 && y > 0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, left-down`);
            walkOperator.walkBackward(_walkSpeed);
            walkOperator.walkLeft(_walkSpeed);
          }
        }
        //Down
        else if (x > -0.45 && x < 0.45 && y > 0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, down`);
            walkOperator.walkBackward(_walkSpeed);
          }
        }
        //Lower Right
        else if (x > 0.45 && x < 0.9 && y > 0.48) {
          if (dragStatus) {
            console.log(`x : ${x}, y : ${y}, right-down`);
            walkOperator.walkBackward(_walkSpeed);
            walkOperator.walkRight(_walkSpeed);
          }
        }
      }
    }

    async function _setupJoystickSpeed() {
      let modelBounding = await hwv.model.getModelBounding();
      //max speed = 12.5% of x-y bounds
      let bounds = Communicator.Point3.subtract(
        modelBounding.max,
        modelBounding.min
      );
      _maxWalkSpeed = Math.max(bounds.x, bounds.y) * speedMultiplier;
      _minWalkSpeed = Math.min(bounds.x, bounds.y) * speedMultiplier;
      _maxElevationSpeed = bounds.z * speedMultiplier;
    }

    function _updateLook(x, y) {
      var walkOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );

      if (x < -0.35 && y > -0.46 && y < 0.46) {
        //console.log(`x : ${x}, y : ${y}, left`);
        if (dragStatus) {
          walkOperator.rotateLeft(rotationDegreeAngle);
        }
      } else if (x > 0.35 && y > -0.46 && y < 0.46) {
        if (dragStatus) {
          //console.log(`x : ${x}, y : ${y}, right`);
          walkOperator.rotateRight(rotationDegreeAngle);
        }
      } else if (y < 0) {
        //Upper Left
        if (x > -0.9 && x < -0.45 && y < -0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, left-up`);
            walkOperator.tiltUp(rotationDegreeAngle);
            walkOperator.rotateLeft(rotationDegreeAngle);
          }
        }
        //Up
        else if (x > -0.45 && x < 0.45 && y < -0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, up`);
            walkOperator.tiltUp(rotationDegreeAngle);
          }
        }
        //Upper Right
        else if (x > 0.45 && x < 0.9 && y < -0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, right-up`);
            walkOperator.tiltUp(rotationDegreeAngle);
            walkOperator.rotateRight(rotationDegreeAngle);
          }
        }
      } else if (y > 0) {
        //Lower Left
        if (x > -0.9 && x < -0.45 && y > 0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, left-down`);
            walkOperator.tiltDown(rotationDegreeAngle);
            walkOperator.rotateLeft(rotationDegreeAngle);
          }
        }
        //Down
        else if (x > -0.45 && x < 0.45 && y > 0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, down`);
            walkOperator.tiltDown(rotationDegreeAngle);
          }
        }
        //Lower Right
        else if (x > 0.45 && x < 0.9 && y > 0.48) {
          if (dragStatus) {
            //console.log(`x : ${x}, y : ${y}, right-down`);
            walkOperator.tiltDown(rotationDegreeAngle);
            walkOperator.rotateRight(rotationDegreeAngle);
          }
        }
      }
    }

    function _updateFrame() {
      requestAnimationFrame(() => _updateFrame());
      _updateWalk(_walkJoystick.getX(), _walkJoystick.getY());
      _updateLook(_lookJoystick.getX(), _lookJoystick.getY());
    }

    function _setPosition(selector, leftOffset, topOffset) {
      var a = $(selector),
        c = a.width(),
        b = a.height();
      if (void 0 !== c && void 0 !== b) {
        var d = hwv.view.getCanvasSize();

        // a.css({
        //   left: d.x - c * leftOffset + "px",
        // });
      }
    }

    function moveUp() {
      var walkOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );
      walkOperator.walkDown(_maxElevationSpeed);
    }

    function moveDown() {
      var walkOperator = hwv.operatorManager.getOperator(
        Communicator.OperatorId.Walk
      );
      walkOperator.walkUp(_maxElevationSpeed);
    }

    function _hide() {
      $(walkDiv).hide();
      $(lookDiv).hide();
    }

    function _show() {
      $(walkDiv).show();
      $(lookDiv).show();
    }

    function _panButtons() {
      //Pan Buttons
      $("#panUp").on("touchstart", function () {
        // console.log("panUpTouchStart called");

        if (!dragStatus) {
          let src = document.getElementById("panUp").children[0].src;
          document.getElementById("panUp").children[0].src = src.replace(
            "Default",
            "Pressed"
          );
          moveUp();

          if (panUpTimer === null) {
            panUpTimer = setInterval(() => {
              moveUp();
            }, 10);
          }
        }
      });

      $("#panUp").on("touchend", function () {
        // console.log("panUpTouchEnd called");

        let src = document.getElementById("panUp").children[0].src;
        document.getElementById("panUp").children[0].src = src.replace(
          "Pressed",
          "Default"
        );

        clearInterval(panUpTimer);
        panUpTimer = null;
      });

      $("#panDown").on("touchstart", function () {
        if (!dragStatus) {
          let src = document.getElementById("panDown").children[0].src;
          document.getElementById("panDown").children[0].src = src.replace(
            "Default",
            "Pressed"
          );
          moveDown();

          if (panDownTimer === null) {
            panDownTimer = setInterval(() => {
              moveDown();
            }, 10);
          }
        }
      });

      $("#panDown").on("touchend", function () {
        let src = document.getElementById("panDown").children[0].src;
        document.getElementById("panDown").children[0].src = src.replace(
          "Pressed",
          "Default"
        );

        clearInterval(panDownTimer);
        panDownTimer = null;
      });
    }

    function _init() {
      _walkJoystick = new JoystickController("stick1", 42, 3);
      _lookJoystick = new JoystickController("stick2", 42, 3);
      //_zJoystick = new JoystickController("stick3",32,6);

      _setupJoystickSpeed(6);
      _updatePosition();

      _updateFrame();

      $(walkDiv + "-container").css({
        position: "unset",
      });

      $(lookDiv + "-container").css({
        position: "unset",
      });

      _panButtons();
    }

    function _updatePosition() {
      _setPosition(walkDiv, 1, 1.2);
      _setPosition(lookDiv, 3.5, 1.2);

      if (_currentView.device == "Tablet") {
        if (_currentView.orientation == "Orientation.landscape") {
          if (_currentView.view == "3D") {
            nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
            nCircle.Ui.Toolbar.setNavcubeSize(10);

            nCircle.Ui.Joystick.setHeight(30);
            nCircle.Ui.Joystick.setBottom(20);

            $("[id=joystickBase]").css({ width: "100px" });
            $("[id=joystickBall]").css({ width: "50px" });
            // $("#stick1")[0].style.left = "30px";
            // $("#stick1")[0].style.top =  "30px";
            // $("#stick2")[0].style.left = "30px";
            // $("#stick2")[0].style.top =  "30px";
          } else {
            if (_currentView.isIOS == "1") {
              $("[id=joystickBase]").css({ width: "90px" });
              $("[id=joystickBall]").css({ width: "45px" });
              // $("#stick1")[0].style.left = "30px";
              // $("#stick1")[0].style.top =  "30px";
              // $("#stick2")[0].style.left = "30px";
              // $("#stick2")[0].style.top =  "30px";

              nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
              nCircle.Ui.Toolbar.setNavcubeSize(8);

              nCircle.Ui.Joystick.setHeight(25);
              nCircle.Ui.Joystick.setBottom(15);
            } else {
              $("[id=joystickBase]").css({ width: "140px" });
              $("[id=joystickBall]").css({ width: "70px" });
              // $("#stick1")[0].style.left = "30px";
              // $("#stick1")[0].style.top =  "30px";
              // $("#stick2")[0].style.left = "30px";
              // $("#stick2")[0].style.top =  "30px";

              nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
              nCircle.Ui.Toolbar.setNavcubeSize(8);

              nCircle.Ui.Joystick.setHeight(25);
              nCircle.Ui.Joystick.setBottom(10);
            }
          }
        } else {
          if (_currentView.view == "3D") {
            $("[id=joystickBase]").css({ width: "100px" });
            $("[id=joystickBall]").css({ width: "50px" });
            // $("#stick1")[0].style.left =  "30px";
            // $("#stick1")[0].style.top =   "30px";
            // $("#stick2")[0].style.left =  "30px";
            // $("#stick2")[0].style.top =   "30px";

            nCircle.Ui.Toolbar.setNavcubePosition(-50, -50);
            nCircle.Ui.Toolbar.setNavcubeSize(10);

            nCircle.Ui.Joystick.setHeight(25);
            nCircle.Ui.Joystick.setBottom(0);
          } else {
            $("[id=joystickBase]").css({ width: "100px" });
            $("[id=joystickBall]").css({ width: "50px" });
            // $("#stick1")[0].style.left = "20px";
            // $("#stick1")[0].style.top =  "20px";
            // $("#stick2")[0].style.left = "20px";
            // $("#stick2")[0].style.top =  "20px";

            nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
            nCircle.Ui.Toolbar.setNavcubeSize(8);

            nCircle.Ui.Joystick.setHeight(28);
            nCircle.Ui.Joystick.setBottom(22);
          }
        }
      } else {
        if (_currentView.view == "3D") {
          $("[id=joystickBase]").css({ width: "160px" });
          $("[id=joystickBall]").css({ width: "80px" });
          // $("#stick1")[0].style.left = "15px";
          // $("#stick1")[0].style.top = "15px";
          // $("#stick2")[0].style.left = "15px";
          // $("#stick2")[0].style.top = "15px";

          nCircle.Ui.Toolbar.setNavcubePosition(-100, -70);
          nCircle.Ui.Toolbar.setNavcubeSize(12);
          nCircle.Ui.Joystick.setHeight(20);
          nCircle.Ui.Joystick.setBottom(12);
        } else {
          $("[id=joystickBase]").css({ width: "160px" });
          $("[id=joystickBall]").css({ width: "80px" });
          // $("#stick1")[0].style.left = "15px";
          // $("#stick1")[0].style.top = "15px";
          // $("#stick2")[0].style.left = "15px";
          // $("#stick2")[0].style.top = "15px";

          nCircle.Ui.Toolbar.setNavcubePosition(0, 0);
          nCircle.Ui.Toolbar.setNavcubeSize(10);
          nCircle.Ui.Joystick.setHeight(25);
          nCircle.Ui.Joystick.setBottom(22);
        }
      }

      if (hwv) {
        if (
          Toolbar.getActiveOperator() == redlineTextOperatorHandle ||
          Toolbar.getActiveOperator() == Communicator.OperatorId.RedlinePolyline
        )
          return;
        //console.log("refresh");
        if (bDeactivateStreaming) hwv.view.setCamera(hwv.view.getCamera());
      }
    }

    return {
      toggle: function () {
        if (bHidden) {
          if (!bInitialized) {
            _init();
            bInitialized = true;
            setTimeout(() => {
              _updatePosition(null);
            }, 1);
          }

          _show();
        } else _hide();

        bHidden = !bHidden;
      },

      setNavigationMultiplier(multiplier) {
        speedMultiplier = multiplier;
        _setupJoystickSpeed();
      },

      setWalkSpeed: function (speed) {},
      setLookSpeed: function (degreePerPixel) {},
      getWalkSpeed: function () {},
      getLookSpeed: function () {},

      setWalkJoystickPosition: function (left, top) {
        _setPosition(walkDiv, left, top);
      },
      setLookJoystickPosition: function (left, top) {
        _setPosition(lookDiv, left, top);
      },

      setWalkJoystickSize: function (left, top) {
        _setPosition(walkDiv, left, top);
      },
      setLookJoystickSize: function (left, top) {
        _setPosition(lookDiv, left, top);
      },

      onLongpressMove: async function (cords) {
        const canvasWidth = hwv.view.getCanvasSize().x;
        const canvasHeight = hwv.view.getCanvasSize().y;

        const heightDiff = canvasHeight - cords.height;
        const widthDiff = canvasWidth - cords.width;

        let newX = (cords.x * canvasWidth) / cords.width;
        let newY = (cords.y * canvasHeight) / cords.height;

        ContextMenu.setLongpressPositiion(new Communicator.Point2(newX,newY));


        let walkRect = document
          .getElementById("walkBase")
          .getBoundingClientRect();

        let lookRect = document
          .getElementById("lookBase")
          .getBoundingClientRect();

        let c = new Touch({
          identifier: 0,
          target: window,
          clientX: newX,
          clientY: newY,
        });
        let t = new TouchEvent("touchmove", {
          touches: [c],
          changedTouches: [c],
        });

        if (
          newX >= walkRect.left &&
          newX <= walkRect.right &&
          newY >= walkRect.top &&
          newY <= walkRect.bottom
        ) {
          t.target = "#stick1";
          document.getElementById("stick1").dispatchEvent(t);
          return;
        }

        if (
          newX >= lookRect.left &&
          newX <= lookRect.right &&
          newY >= lookRect.top &&
          newY <= lookRect.bottom
        ) {
          t.target = "#stick2";

          document.getElementById("stick2").dispatchEvent(t);

          return;
        }

        let e = new Communicator.Event.TouchInputEvent();
        e._position.x = newX;
        e._position.y = newY;
        zoomLensOperator.onTouchMove(e);
      },

      getJoystickOverlayState: async function (cords) {
        //Convert Flutter Coordinates to Canvas Coordinates
        const canvasWidth = hwv.view.getCanvasSize().x;
        const canvasHeight = hwv.view.getCanvasSize().y;

        const heightDiff = canvasHeight - cords.height;
        const widthDiff = canvasWidth - cords.width;

        let newX = (cords.x * canvasWidth) / cords.width;
        let newY = (cords.y * canvasHeight) / cords.height;

        ContextMenu.setLongpressPositiion(new Communicator.Point2(newX,newY));

        //Check if current target is panUp Button
        let panUpRect = document
          .getElementById("panUp")
          .getBoundingClientRect();

        let panDownRect = document
          .getElementById("panDown")
          .getBoundingClientRect();

        let walkRect = document
          .getElementById("walkBase")
          .getBoundingClientRect();

        let lookRect = document
          .getElementById("lookBase")
          .getBoundingClientRect();

        let c = new Touch({
          identifier: 0,
          target: window,
          clientX: newX,
          clientY: newY,
        });
        let t = new TouchEvent("touchstart", {
          touches: [c],
          changedTouches: [c],
        });

        if (
          newX >= walkRect.left &&
          newX <= walkRect.right &&
          newY >= walkRect.top &&
          newY <= walkRect.bottom
        ) {
          zoomLensOperator.onTouchEnd(null);
          t.target = "#walkBase";
          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";

          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
          document.getElementById("stick1").dispatchEvent(t);
          return;
        }

        if (
          newX >= lookRect.left &&
          newX <= lookRect.right &&
          newY >= lookRect.top &&
          newY <= lookRect.bottom
        ) {
          zoomLensOperator.onTouchEnd(null);

          t.target = "#lookBase";
          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";

          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
          document.getElementById("stick2").dispatchEvent(t);

          return;
        }

        //Check if current target is panUp Button
        if (
          newX >= panUpRect.left &&
          newX <= panUpRect.right &&
          newY >= panUpRect.top &&
          newY <= panUpRect.bottom
        ) {
          zoomLensOperator.onTouchEnd(null);

          t.target = "#panUp";
          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";

          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
          document.getElementById("panUp").dispatchEvent(t);

          return;
        }

        //Check if current target is panDown Button
        if (
          newX >= panDownRect.left &&
          newX <= panDownRect.right &&
          newY >= panDownRect.top &&
          newY <= panDownRect.bottom
        ) {
          zoomLensOperator.onTouchEnd(null);

          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";

          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
          document.getElementById("panDown").dispatchEvent(t);

          return;
        }

        let activeOp = Toolbar.getActiveOperator();
        if (
          activeOp == measureAngleOperatorHandle ||
          activeOp == markupAreaMeasureHandle ||
          activeOp == Communicator.OperatorId.MeasurePointPointDistance
        ) {
          let e = new Communicator.Event.TouchInputEvent();
          e._position.x = newX;
          e._position.y = newY;
          zoomLensOperator.setIsActive(true);
          zoomLensOperator.onTouchStart(e);
        }

        if (Toolbar.getActiveOperator() != Communicator.OperatorId.Select) {
          // console.log("Not Select Operator");
          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";
          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
          return false;
        }

        const mouseEvent = new Communicator.Event.MouseInputEvent();
        mouseEvent._modifiers = 0,
        mouseEvent._inputType = 1,
        mouseEvent._button = 0,
        mouseEvent._buttons = 0;
        mouseEvent._position.x = newX;
        mouseEvent._position.y = newY;

        await hwv.operatorManager
          .getOperator(Communicator.OperatorId.Select)
          .onMouseDown(mouseEvent);

          await hwv.operatorManager
          .getOperator(Communicator.OperatorId.Select)
          .onMouseDown(mouseEvent);

          
        /* success */
        if (hwv.selectionManager.getLast() && hwv.selectionManager.getLast().getNodeId()) {
          let _str = "0,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";

          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );

          //ContextMenu.setLongpressSelection();
          ContextMenu.getBimObjectColorStatus();
        } else {
          let _str = "1,";
          if (parseInt(cords.value)) _str = _str + "true";
          else _str = _str + "false";
          window.flutter_inappwebview.callHandler(
            "getJoystickCoordinates",
            _str
          );
        }


      },
      setHeight: function (height) {
        document.getElementById(walkDiv.replace("#", "")).style.height =
          "" + height + "%";
        document.getElementById(lookDiv.replace("#", "")).style.height =
          "" + height + "%";
      },
      setBottom: function (bottom) {
        document.getElementById(walkDiv.replace("#", "")).style.bottom =
          "" + bottom + "%";
        document.getElementById(lookDiv.replace("#", "")).style.bottom =
          "" + bottom + "%";
      },

      updatePosition: function (_view) {
        if (_view != undefined) {
          _deviceType = _view.device;
          //console.log("Device Type : ", _deviceType);
          _currentView = _view;
        }

        _updatePosition();

        setTimeout(() => {
          _updatePosition();
        }, 20);

        if (bHidden) return;

        if (_view != undefined)
          if (_view.hasOwnProperty("reload")) {
            this.toggle();
            //("Toggled");
            setTimeout(() => {
              this.toggle();
              // console.log("Toggled Again");
            }, 10);
          }
      },
      isJoystickHidden: () => {
        return bHidden;
      },
    };
  })();

  return {
    Toolbar,
    ContextMenu,
    Joystick,
  };
})();

window.addEventListener("resize", () => {
  //if (zoomLensOperator) zoomLensOperator.onTouchEnd(null);

  if (nCircle.Ui.Toolbar.isMeasurementOperatorsActive())
    zoomLensOperator.updateImage();
  setTimeout(() => {
    if (nCircle.Ui.Toolbar.isMeasurementOperatorsActive())
      zoomLensOperator.updateImage();
  }, 100);

  if (hwv && hwv.view) nCircle.Ui.Joystick.updatePosition(undefined);
  setTimeout(() => {
    if (hwv && hwv.view) nCircle.Ui.Joystick.updatePosition(undefined);
    //if (zoomLensOperator) zoomLensOperator.onTouchEnd(null);
  }, 20);
});

function getNodeIdFromOldNodeId(id, revisionId) {
  if (!id) {
    return;
  }
  //if (id.indexOf('|') === -1) {
  //    if (window.customTreeview.partsMap[id]) {
  //        return (window.customTreeview.partsMap[id]).global_id;
  //    }
  //    else {
  //        if (revisionId) {
  //            var revid = revisionId.split("$$")[0] + "##" + id;
  //            if (window.customTreeview.partsMapGuid[revid]) {
  //                return (window.customTreeview.partsMapGuid[revid]).global_id;
  //            }
  //        }
  //    }
  //}
  var split = id.split("|");
  var revId = split[0];
  var rootNodeId = revisionIdVsStartingNodeMap.get(revId);
  if (rootNodeId != undefined) {
    var currentGuid = Number(rootNodeId) + 1;
    var diffInGuid = Number(split[1] || "") - currentGuid;
    var currentTargetNodeGuid = Number(split[2] || "") - diffInGuid;
    console.log(`currentTargetNodeGuid : ${currentTargetNodeGuid}`);
    return currentTargetNodeGuid;
  }
}

function getNodeIdWithRevStr(nodeId) {
  let revId = getRevisionIdFromNodeId(nodeId);
  let rootId = revisionIdVsStartingNodeMap.get(revId) + 1;
  return revId + "|" + rootId + "|" + nodeId;
}

function getRevisionIdFromNodeId(nodeId) {
  var revId;
  revisionIdVsStartingNodeMap.forEach((start, key) => {
    let end = revisionIdVsEndingNodeMap.get(key);

    if (nodeId >= start && nodeId <= end) {
      revId = key;
    }
  });

  return revId;
}

async function getBimObjectDetails() {
  const nodeId = hwv.selectionManager.getLast().getNodeId();

  if (!nodeId) {
    throw Error("nodeId null | undefined");
  }

  const nodeData = await hwv.model.getNodeProperties(nodeId);

  const guid =
    nodeData &&
    ((nodeData.persistentId && nodeData.persistentId.trim()) ||
      (nodeData.hasOwnProperty(nodeData.TYPE + "/GlobalId") && nodeData[nodeData.TYPE + "/GlobalId"].trim()));
  const revisiodId = getRevisionIdFromNodeId(nodeId);
  const name = await hwv.model.getNodeName(nodeId) 
  const type = nodeData && nodeData.TYPE;

  console.log(
      {
        GUID: guid,
        obj_type: type,
        revision_id: revisiodId,
        object_name: name,
        tree_revision_id: revisiodId,
        revision_id_model: revisiodId,
        file_type: fileType,
      }
  )

  return JSON.stringify({
    BimObjectsData: [
      {
        GUID: guid,
        obj_type: type,
        revision_id: revisiodId,
        object_name: name,
        tree_revision_id: revisiodId,
        revision_id_model: revisiodId,
        file_type: 1,
      },
    ],
  });
}
